import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import { Converter, AuthService, GlobalMessageService, AuthStorageService, AuthRedirectService, UserIdService, RoutingService, CommandService, Command } from '@spartacus/core';
import { PunchoutRequisition, PunchoutSession, PunchoutStoreService, PunchoutDetectionService, PunchoutFacade, PunchoutSessionInput } from '@spartacus/punchout/root';
import { Observable } from 'rxjs';
import { MultiCartFacade } from '@spartacus/cart/base/root';
import { Store } from '@ngrx/store';

declare const PUNCHOUT_SESSION_NORMALIZER: InjectionToken<Converter<any, PunchoutSession>>;
declare const PUNCHOUT_REQUISITION_NORMALIZER: InjectionToken<Converter<any, PunchoutRequisition>>;

declare abstract class PunchoutAdapter {
    /**
     * Abstract method used to get Punchout Session
     * @param sessionId is the sesssion Id given by ARIBA via url
     */
    abstract getPunchoutSession(sessionId: string): Observable<PunchoutSession>;
    /**
     * Abstract method used to get Punchout Session Requisition data
     * @param sessionId is the sesssion Id given by ARIBA via url
     */
    abstract getPunchoutSessionRequisition(sessionId: string, discardCartEntries?: boolean): Observable<PunchoutRequisition>;
}

declare class PunchoutConnector {
    protected adapter: PunchoutAdapter;
    getPunchoutSession(sessionId: string): Observable<PunchoutSession>;
    getPunchoutSessionRequisition(sessionId: string, discardCartEntries?: boolean): Observable<PunchoutRequisition>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PunchoutConnector>;
}

declare class PunchoutAuthService {
    protected authService: AuthService;
    protected globalMessageService: GlobalMessageService;
    protected authStorageService: AuthStorageService;
    protected authRedirectService: AuthRedirectService;
    protected userIdService: UserIdService;
    protected store: Store<any>;
    protected punchoutStoreService: PunchoutStoreService;
    protected punchoutDetectionService: PunchoutDetectionService;
    protected routingService: RoutingService;
    silentLogout(isPageRefresh?: boolean): Observable<boolean>;
    loginWithToken(accessToken: string): void;
    isUserLoggedIn(): Observable<boolean>;
    endPunchoutSession(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutAuthService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PunchoutAuthService>;
}

declare class PunchoutService implements PunchoutFacade {
    protected punchoutConnector: PunchoutConnector;
    protected punchoutAuthService: PunchoutAuthService;
    protected commandService: CommandService;
    protected routingService: RoutingService;
    protected punchoutStoreService: PunchoutStoreService;
    protected multiCartFacade: MultiCartFacade;
    protected userIdService: UserIdService;
    protected globalMessageService: GlobalMessageService;
    /**
     * punchoutSession ajax request will always return same response during a punchout session.
     * To avoid multiple server calls, punchoutSession OCC API response  is stored into cachedPunchoutSessionResponse.
     */
    protected cachedPunchoutSessionResponse?: PunchoutSession;
    /**
     * getPunchoutSession workflow:
     * Logout silently
     * Get PunchoutSession from  occ api
     * Login silently
     * Load Cart
     * Only for EDIT mode: Fetch Requisition to store initial cart in CXML format.
     * Route to target page based on punchout session info
     * Redirect to Punchout Error page if error occurs
     */
    protected getPunchoutSessionCommand: Command<PunchoutSessionInput, PunchoutSession>;
    /**
     * getPunchoutRequisition workflow:
     * Ensure user is logged-in
     * get punchoutSessionId from PunchoutState
     * Redirect user to homePage if method is called from Requisition page manual navigation
     * Get PunchoutSessionRequisition from  occ api OR from PunchoutState
     * Redirect to Punchout Error page if error occurs
     */
    protected getPunchoutRequisitionCommand: Command<boolean, PunchoutRequisition>;
    /**
     * logoutPunchoutUser workflow:
     * clear punchout state
     * silent logout, meaning no notification displayed and redirection.
     */
    protected logoutPunchoutUserCommand: Command<void, boolean>;
    /**
     * endUserSession workflow:
     * clear punchout state,logout, redirect to login page, display message
     */
    protected endPunchoutSessionCommand: Command<void>;
    /**
     * closePunchoutSession workflow:
     * For EDIT operation:
     * - Initial cart snapshot gets sent in CXML, driven by closePunchoutSession flag.
     * For CREATE operation:
     * - Empty cart gets sent in CXML, driven by cancelRequisition flag.
     * For INSPECT operation:
     * - Current cart gets sent in CXML.
     */
    protected closePunchoutSessionCommand: Command<undefined, boolean>;
    /**
     * Request Punchout session calling occ api.
     * Returns cached value if server request has been already made.
     * @param punchoutSessionId
     * @returns
     */
    protected requestPunchoutSessionCommand: Command<string, PunchoutSession>;
    closePunchoutSession(): Observable<boolean>;
    initPunchoutSession(punchoutSessionInput: PunchoutSessionInput): Observable<PunchoutSession>;
    getPunchoutSessionRequisition(isInitialRequisition?: boolean): Observable<PunchoutRequisition | undefined>;
    logoutPunchoutUser(): Observable<boolean>;
    endPunchoutSession(): Observable<unknown>;
    requestPunchoutSession(punchoutSessionId: string): Observable<PunchoutSession>;
    submitRequisition(cancelRequisition: boolean): void;
    protected routeToTargetPage(punchoutSession: PunchoutSession): void;
    protected loadCart(cartId: string): Observable<string>;
    /**
     * Take a snapshot of initial requisition and store it in the state.
     * This is used to send the initial cart snapshot in CXML when the user
     * closes the punchout session via 'Close Session' button.
     *
     * This method is called only in EDIT mode.
     * @returns
     */
    protected setPunchoutInitialRequisition(): void;
    protected openRequisitionPage(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PunchoutService>;
}

declare class PunchoutCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PunchoutCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PunchoutCoreModule>;
}

export { PUNCHOUT_REQUISITION_NORMALIZER, PUNCHOUT_SESSION_NORMALIZER, PunchoutAdapter, PunchoutAuthService, PunchoutConnector, PunchoutCoreModule, PunchoutService };
