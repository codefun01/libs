import { CmsConfig, RoutingConfig, SemanticPathService, AuthHttpHeaderService, AuthService, AuthStorageService, OAuthLibWrapperService, RoutingService, GlobalMessageService, OccEndpointsService, AuthRedirectService, ExpiredRefreshTokenHandler, StatePersistenceService, RoutingConfigService, CmsActivatedRouteSnapshot } from '@spartacus/core';
import { LaunchRoute } from '@spartacus/storefront';
import * as i0 from '@angular/core';
import { OnDestroy, ComponentRef } from '@angular/core';
import { Observable, BehaviorSubject, Subscription } from 'rxjs';
import { Location } from '@angular/common';
import { Router, RouterStateSnapshot, GuardResult } from '@angular/router';

declare const defaultPunchoutCmsComponentsConfig: CmsConfig;

declare const defaultPunchoutRoutingConfig: RoutingConfig;

declare enum PunchOutLevel {
    STORE = "STORE",
    PRODUCT = "PRODUCT",
    AISLE = "AISLE",
    SHELF = "SHELF"
}
declare enum PunchOutOperation {
    CREATE = "CREATE",
    EDIT = "EDIT",
    INSPECT = "INSPECT"
}
interface PunchoutSessionInput {
    punchoutSessionId: string;
    isPageRefresh?: boolean;
}
interface PunchoutSession {
    customerId: string;
    cartId: string;
    punchOutLevel: PunchOutLevel;
    punchOutOperation: PunchOutOperation;
    selectedItem: string;
    token?: {
        accessToken: string;
        tokenType: string;
    };
}
interface PunchoutRequisition {
    browseFormPostUrl: string;
    orderAsCXML: string;
}
interface PunchoutState {
    punchoutSession?: PunchoutSession;
    punchoutSessionId?: string;
    cancelRequisition?: boolean;
    closePunchoutSession?: boolean;
    punchoutInitialRequisition?: PunchoutRequisition;
}

declare abstract class PunchoutNavigationGuardConfig {
    punchoutNavigation?: {
        [PunchOutOperation.EDIT]: {
            allowedUrls?: string[];
            allowedCxRoutes?: string[];
            redirectPage: string | LaunchRoute;
        };
        [PunchOutOperation.CREATE]: {
            allowedUrls?: string[];
            allowedCxRoutes?: string[];
            redirectPage: string | LaunchRoute;
        };
        [PunchOutOperation.INSPECT]: {
            allowedUrls?: string[];
            allowedCxRoutes?: string[];
            redirectPage: string | LaunchRoute;
        };
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutNavigationGuardConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PunchoutNavigationGuardConfig>;
}
declare module '@spartacus/core' {
    interface Config extends PunchoutNavigationGuardConfig {
    }
}

declare const defaultPunchoutNavigationGuardConfig: PunchoutNavigationGuardConfig;

declare function punchoutFacadeFactory(): PunchoutFacade;
declare abstract class PunchoutFacade {
    /**
     * Abstract method used to get Punchout Session, worflow:
     * occ api request, logout previous user, login punchout user, load cart
     * @param sessionId is the sesssion Id given by ARIBA via url param
     */
    abstract initPunchoutSession(punchoutSessionInput: PunchoutSessionInput): Observable<PunchoutSession>;
    /**
     * Abstract method used to get Punchout Session Requisition data
     */
    abstract getPunchoutSessionRequisition(): Observable<PunchoutRequisition | undefined>;
    /**
     * Abstract method used to logout punchout user
     */
    abstract logoutPunchoutUser(): Observable<boolean>;
    /**
     *  Abstract method used to end punchout session
     *  Flow: logout, clear punchout state and redirect to login page
     */
    abstract endPunchoutSession(): Observable<unknown>;
    /**
     * Abstract method used to close punchout session
     */
    abstract closePunchoutSession(): Observable<boolean>;
    /**
     * Abstract method used to get Punchout Session response from cx-server
     * @param sessionId is the sesssion Id given by ARIBA via url param
     */
    abstract requestPunchoutSession(punchoutSessionId: string): Observable<PunchoutSession>;
    abstract submitRequisition(cancelRequisition: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PunchoutFacade>;
}

declare const PUNCHOUT_FEATURE = "punchout";

declare class PunchoutNavigationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutNavigationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PunchoutNavigationModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PunchoutNavigationModule>;
}

declare class PunchoutRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PunchoutRootModule, never, [typeof PunchoutNavigationModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PunchoutRootModule>;
}

declare class PunchoutStoreService {
    protected readonly INITIAL_STATE: PunchoutState;
    protected punchoutState: BehaviorSubject<PunchoutState>;
    getPunchoutSessionId(): string | undefined;
    getPunchoutState(): Observable<PunchoutState>;
    setPunchoutState(payload: Partial<PunchoutState>): void;
    updatePunchoutState(payload: Partial<PunchoutState>): void;
    clearPunchoutState(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutStoreService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PunchoutStoreService>;
}

declare class PunchoutDetectionService {
    protected location: Location;
    protected punchoutStoreService: PunchoutStoreService;
    protected semanticPathService: SemanticPathService;
    /**
     * Check if browser url is the punchout initial session page.
     * With default config, the expected url shape is '/punchout/cxml/session?abcd'.
     * @returns boolean
     */
    isPunchoutSessionPage(): boolean;
    isPunchoutSession(): boolean | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutDetectionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PunchoutDetectionService>;
}

declare class PunchoutAuthHttpHeaderService extends AuthHttpHeaderService {
    protected authService: AuthService;
    protected authStorageService: AuthStorageService;
    protected oAuthLibWrapperService: OAuthLibWrapperService;
    protected routingService: RoutingService;
    protected globalMessageService: GlobalMessageService;
    protected occEndpointsService: OccEndpointsService;
    protected authRedirectService: AuthRedirectService;
    protected punchoutDetectionService: PunchoutDetectionService;
    protected punchoutFacade: PunchoutFacade;
    constructor(authService: AuthService, authStorageService: AuthStorageService, oAuthLibWrapperService: OAuthLibWrapperService, routingService: RoutingService, globalMessageService: GlobalMessageService, occEndpointsService: OccEndpointsService, authRedirectService: AuthRedirectService);
    /**
     * @override
     *
     * On backend errors indicating expired `refresh_token`, 2 punchout use cases:
     * - When initializing punchout session, previous token gets silently revoked, punchoutFacade can then create punchout session.
     * - When punchout session already exists, punchout session gets ended.
     * It is a workaround to address CXSPA-9608 - Public pages not displayed when token is invalid.
     * To be removed once CXSPA-9608 is closed.
     */
    handleExpiredRefreshToken(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutAuthHttpHeaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PunchoutAuthHttpHeaderService>;
}

declare class PunchoutExpiredRefreshTokenHandler implements ExpiredRefreshTokenHandler {
    protected punchoutDetectionService: PunchoutDetectionService;
    protected punchoutFacade: PunchoutFacade;
    /**
     * Returns whether punchout-specific refresh-token expiration handling was applied.
     * On backend errors indicating expired `refresh_token`, 2 punchout use cases:
     * - When initializing punchout session, previous token gets silently revoked, punchoutFacade can then create punchout session.
     * - When punchout session already exists, punchout session gets ended.
     * It is a workaround to address CXSPA-9608 - Public pages not displayed when token is invalid.
     * To be removed once CXSPA-9608 is closed.
     */
    handleExpiredRefreshTokenIfApplicable(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutExpiredRefreshTokenHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PunchoutExpiredRefreshTokenHandler>;
}

declare class PunchoutStatePersistenceService implements OnDestroy {
    protected statePersistenceService: StatePersistenceService;
    protected punchoutStoreService: PunchoutStoreService;
    protected punchoutFacade: PunchoutFacade;
    protected punchoutDetectionService: PunchoutDetectionService;
    protected subscription: Subscription;
    protected hasPunchoutStarted: boolean;
    protected readonly PUNCHOUT_STORAGE_KEY = "punchout";
    /**
     * Initializes the synchronization between state and browser storage.
     * Through getPunchoutSessionId(), storage is updated everytime PunchoutState is modified.
     */
    initSync(): void;
    /**
     * Gets and transforms state into the form that should
     * be saved in storage.
     */
    protected getPunchoutSessionId(): Observable<string | undefined>;
    /**
     * Function called on each browser storage read.
     * Used to update state from browser -> state.
     * storage stores minimum data: only punchoutSessionId.
     * Full PunchoutSession object is retrieved by calling punchoutFacade.initPunchoutSession
     */
    protected onRead(punchoutSessionId: string | undefined): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutStatePersistenceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PunchoutStatePersistenceService>;
}

declare class PunchoutUiRestrictionService {
    private rendererFactory;
    protected punchoutStoreService: PunchoutStoreService;
    protected authService: AuthService;
    protected readonly CSS_PUNCHOUT_SESSION_CLASS = "cxPunchoutSessionActive";
    protected renderer: i0.Renderer2;
    protected rootElement: HTMLElement | undefined;
    isPunchoutSessionActive(): Observable<boolean>;
    protected updateClass(punchoutActive: boolean): void;
    init(rootComponent: ComponentRef<any>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutUiRestrictionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PunchoutUiRestrictionService>;
}

declare class PunchoutNavigationGuard {
    protected router: Router;
    protected punchoutStoreService: PunchoutStoreService;
    protected authService: AuthService;
    protected routingService: RoutingService;
    protected globalMessageService: GlobalMessageService;
    protected punchoutFacade: PunchoutFacade;
    protected config: PunchoutNavigationGuardConfig;
    protected routingConfigService: RoutingConfigService;
    canActivate(route: CmsActivatedRouteSnapshot, _state: RouterStateSnapshot): Observable<GuardResult>;
    protected isAllowedUrls(route: CmsActivatedRouteSnapshot, punchoutOperation: PunchOutOperation, relativeUrl: string): boolean;
    protected isAllowedCxRoute(cxRoute: string, punchoutOperation: PunchOutOperation): boolean;
    protected getPunchoutOperation(cxRoute: string): Observable<PunchOutOperation | undefined>;
    protected handleWarning(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutNavigationGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PunchoutNavigationGuard>;
}

export { PUNCHOUT_FEATURE, PunchOutLevel, PunchOutOperation, PunchoutAuthHttpHeaderService, PunchoutDetectionService, PunchoutExpiredRefreshTokenHandler, PunchoutFacade, PunchoutNavigationGuard, PunchoutNavigationGuardConfig, PunchoutRootModule, PunchoutStatePersistenceService, PunchoutStoreService, PunchoutUiRestrictionService, defaultPunchoutCmsComponentsConfig, defaultPunchoutNavigationGuardConfig, defaultPunchoutRoutingConfig, punchoutFacadeFactory };
export type { PunchoutRequisition, PunchoutSession, PunchoutSessionInput, PunchoutState };
