import { HttpClient } from '@angular/common/http';
import { OccEndpointsService, LoggerService, ConverterService, OccEndpoint } from '@spartacus/core';
import { PunchoutAdapter } from '@spartacus/punchout/core';
import { PunchoutSession, PunchoutRequisition } from '@spartacus/punchout/root';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare class OccPunchoutAdapter implements PunchoutAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected logger: LoggerService;
    protected converter: ConverterService;
    getPunchoutSession(sessionId: string): Observable<PunchoutSession>;
    getPunchoutSessionRequisition(sessionId: string, discardCartEntries: boolean): Observable<PunchoutRequisition>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccPunchoutAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccPunchoutAdapter>;
}

interface PunchoutOccEndpoints {
    /**
     * Endpoint for the punchout session
     *
     * @member {string}
     */
    punchoutSession?: string | OccEndpoint;
    /**
     * Endpoint for the punchout Session Requisition
     *
     * @member {string}
     */
    punchoutSessionRequisition?: string | OccEndpoint;
}
declare module '@spartacus/core' {
    interface OccEndpoints extends PunchoutOccEndpoints {
        punchoutSession?: string | OccEndpoint;
        punchoutSessionRequisition?: string | OccEndpoint;
    }
}

declare class PunchoutOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PunchoutOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PunchoutOccModule>;
}

export { OccPunchoutAdapter, PunchoutOccModule };
export type { PunchoutOccEndpoints };
