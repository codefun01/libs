import * as i0 from '@angular/core';
import * as i1 from '@spartacus/punchout/components';
import * as i2 from '@spartacus/punchout/core';
import * as i3 from '@spartacus/punchout/occ';

declare class PunchoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PunchoutModule, never, [typeof i1.PunchoutComponentsModule, typeof i2.PunchoutCoreModule, typeof i3.PunchoutOccModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PunchoutModule>;
}

export { PunchoutModule };
