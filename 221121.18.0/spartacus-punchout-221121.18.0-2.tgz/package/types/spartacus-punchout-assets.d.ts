import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    punchout: {
        punchout: {
            backToRequisition: string;
            cancel: string;
            redirectToProcurementSystem: string;
            closeSession: string;
            initiatingUserSession: string;
            error: string;
            noSufficientPermissions: string;
        };
    };
};

declare const de: {
    punchout: {
        punchout: {
            backToRequisition: string;
            cancel: string;
            redirectToProcurementSystem: string;
            closeSession: string;
            initiatingUserSession: string;
            error: string;
            noSufficientPermissions: string;
        };
    };
};

declare const en: {
    punchout: {
        punchout: {
            backToRequisition: string;
            cancel: string;
            redirectToProcurementSystem: string;
            closeSession: string;
            initiatingUserSession: string;
            error: string;
            noSufficientPermissions: string;
        };
    };
};

declare const es: {
    punchout: {
        punchout: {
            backToRequisition: string;
            cancel: string;
            redirectToProcurementSystem: string;
            closeSession: string;
            initiatingUserSession: string;
            error: string;
            noSufficientPermissions: string;
        };
    };
};

declare const es_CO: {
    punchout: {
        punchout: {
            backToRequisition: string;
            cancel: string;
            redirectToProcurementSystem: string;
            closeSession: string;
            initiatingUserSession: string;
            error: string;
            noSufficientPermissions: string;
        };
    };
};

declare const fr: {
    punchout: {
        punchout: {
            backToRequisition: string;
            cancel: string;
            redirectToProcurementSystem: string;
            closeSession: string;
            initiatingUserSession: string;
            error: string;
            noSufficientPermissions: string;
        };
    };
};

declare const hi: {
    punchout: {
        punchout: {
            backToRequisition: string;
            cancel: string;
            redirectToProcurementSystem: string;
            closeSession: string;
            initiatingUserSession: string;
            error: string;
            noSufficientPermissions: string;
        };
    };
};

declare const hu: {
    punchout: {
        punchout: {
            backToRequisition: string;
            cancel: string;
            redirectToProcurementSystem: string;
            closeSession: string;
            initiatingUserSession: string;
            error: string;
            noSufficientPermissions: string;
        };
    };
};

declare const id: {
    punchout: {
        punchout: {
            backToRequisition: string;
            cancel: string;
            redirectToProcurementSystem: string;
            closeSession: string;
            initiatingUserSession: string;
            error: string;
            noSufficientPermissions: string;
        };
    };
};

declare const it: {
    punchout: {
        punchout: {
            backToRequisition: string;
            cancel: string;
            redirectToProcurementSystem: string;
            closeSession: string;
            initiatingUserSession: string;
            error: string;
            noSufficientPermissions: string;
        };
    };
};

declare const ja: {
    punchout: {
        punchout: {
            backToRequisition: string;
            cancel: string;
            redirectToProcurementSystem: string;
            closeSession: string;
            initiatingUserSession: string;
            error: string;
            noSufficientPermissions: string;
        };
    };
};

declare const ko: {
    punchout: {
        punchout: {
            backToRequisition: string;
            cancel: string;
            redirectToProcurementSystem: string;
            closeSession: string;
            initiatingUserSession: string;
            error: string;
            noSufficientPermissions: string;
        };
    };
};

declare const pl: {
    punchout: {
        punchout: {
            backToRequisition: string;
            cancel: string;
            redirectToProcurementSystem: string;
            closeSession: string;
            initiatingUserSession: string;
            error: string;
            noSufficientPermissions: string;
        };
    };
};

declare const pt: {
    punchout: {
        punchout: {
            backToRequisition: string;
            cancel: string;
            redirectToProcurementSystem: string;
            closeSession: string;
            initiatingUserSession: string;
            error: string;
            noSufficientPermissions: string;
        };
    };
};

declare const ru: {
    punchout: {
        punchout: {
            backToRequisition: string;
            cancel: string;
            redirectToProcurementSystem: string;
            closeSession: string;
            initiatingUserSession: string;
            error: string;
            noSufficientPermissions: string;
        };
    };
};

declare const zh: {
    punchout: {
        punchout: {
            backToRequisition: string;
            cancel: string;
            redirectToProcurementSystem: string;
            closeSession: string;
            initiatingUserSession: string;
            error: string;
            noSufficientPermissions: string;
        };
    };
};

declare const zh_TW: {
    punchout: {
        punchout: {
            backToRequisition: string;
            cancel: string;
            redirectToProcurementSystem: string;
            closeSession: string;
            initiatingUserSession: string;
            error: string;
            noSufficientPermissions: string;
        };
    };
};

declare const punchoutTranslationChunksConfig: TranslationChunksConfig;

declare const punchoutTranslations: {
    en: {
        punchout: {
            punchout: {
                backToRequisition: string;
                cancel: string;
                redirectToProcurementSystem: string;
                closeSession: string;
                initiatingUserSession: string;
                error: string;
                noSufficientPermissions: string;
            };
        };
    };
};

export { punchoutTranslationChunksConfig, punchoutTranslations, cs as punchoutTranslationsCs, de as punchoutTranslationsDe, en as punchoutTranslationsEn, es as punchoutTranslationsEs, es_CO as punchoutTranslationsEs_CO, fr as punchoutTranslationsFr, hi as punchoutTranslationsHi, hu as punchoutTranslationsHu, id as punchoutTranslationsId, it as punchoutTranslationsIt, ja as punchoutTranslationsJa, ko as punchoutTranslationsKo, pl as punchoutTranslationsPl, pt as punchoutTranslationsPt, ru as punchoutTranslationsRu, zh as punchoutTranslationsZh, zh_TW as punchoutTranslationsZh_TW };
