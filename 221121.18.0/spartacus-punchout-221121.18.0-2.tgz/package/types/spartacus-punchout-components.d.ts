import { PunchoutUiRestrictionService, PunchoutFacade, PunchoutRequisition } from '@spartacus/punchout/root';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import { OnInit, ElementRef } from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@angular/forms';
import { FormBuilder, FormGroup } from '@angular/forms';
import * as i3 from '@spartacus/core';
import { GlobalMessageService } from '@spartacus/core';
import * as i4 from '@spartacus/cart/base/components';
import * as i5 from '@spartacus/storefront';
import { ICON_TYPE } from '@spartacus/storefront';
import { ActivatedRoute } from '@angular/router';
import { ActiveCartFacade, Cart, OrderEntry } from '@spartacus/cart/base/root';

declare class PunchoutButtonsComponent {
    removeCancelButton: boolean;
    protected punchoutUiRestrictionService: PunchoutUiRestrictionService;
    protected punchoutFacade: PunchoutFacade;
    isPunchoutSessionActive$: Observable<boolean>;
    submitRequisition(cancelRequisition?: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutButtonsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PunchoutButtonsComponent, "cx-punchout-buttons", never, { "removeCancelButton": { "alias": "removeCancelButton"; "required": false; }; }, {}, never, never, true, never>;
}

declare class PunchoutCloseSessionComponent {
    protected punchoutFacade: PunchoutFacade;
    protected punchoutUiRestrictionService: PunchoutUiRestrictionService;
    isPunchoutSessionActive$: Observable<boolean>;
    clickCloseSessionButton(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutCloseSessionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PunchoutCloseSessionComponent, "cx-punchout-close-session", never, {}, {}, never, never, true, never>;
}

declare class PunchoutSessionComponent implements OnInit {
    protected activatedRoute: ActivatedRoute;
    protected punchoutFacade: PunchoutFacade;
    protected globalMessageService: GlobalMessageService;
    protected readonly PUNCHOUT_SESSION_KEY = "sid";
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutSessionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PunchoutSessionComponent, "cx-punchout-session", never, {}, {}, never, never, true, never>;
}

declare class PunchoutErrorComponent {
    iconTypes: typeof ICON_TYPE;
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutErrorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PunchoutErrorComponent, "cx-punchout-error", never, {}, {}, never, never, true, never>;
}

declare class PunchoutRequisitionComponent implements OnInit {
    protected punchoutFacade: PunchoutFacade;
    protected formBuilder: FormBuilder;
    punchoutFormElement: ElementRef<HTMLFormElement>;
    punchoutFormGroup: FormGroup;
    readonly FORM_CONTROL_NAME: {
        readonly ORDER: "order";
    };
    punchoutRequisition$: Observable<PunchoutRequisition | undefined>;
    ngOnInit(): void;
    protected listenAndSubmitForm(req: PunchoutRequisition | undefined): Observable<boolean>;
    protected isFormNativeElementAccessible(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutRequisitionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PunchoutRequisitionComponent, "cx-punchout-requsition", never, {}, {}, never, never, true, never>;
}

declare class PunchoutInspectCartComponent {
    protected activeCartService: ActiveCartFacade;
    protected punchoutComponentsService: PunchoutUiRestrictionService;
    isPunchoutSessionActive$: Observable<boolean>;
    cart$: Observable<Cart>;
    entries$: Observable<OrderEntry[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutInspectCartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PunchoutInspectCartComponent, "cx-punchout-inspect-cart", never, {}, {}, never, never, true, never>;
}

declare class PunchoutComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PunchoutComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PunchoutComponentsModule, never, [typeof i1.CommonModule, typeof i2.ReactiveFormsModule, typeof i3.I18nModule, typeof i4.CartSharedModule, typeof i5.IconModule, typeof PunchoutSessionComponent, typeof PunchoutErrorComponent, typeof PunchoutRequisitionComponent, typeof PunchoutButtonsComponent, typeof PunchoutCloseSessionComponent, typeof PunchoutInspectCartComponent], [typeof PunchoutSessionComponent, typeof PunchoutErrorComponent, typeof PunchoutRequisitionComponent, typeof PunchoutButtonsComponent, typeof PunchoutCloseSessionComponent, typeof PunchoutInspectCartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PunchoutComponentsModule>;
}

export { PunchoutButtonsComponent, PunchoutCloseSessionComponent, PunchoutComponentsModule, PunchoutErrorComponent, PunchoutInspectCartComponent, PunchoutRequisitionComponent, PunchoutSessionComponent };
