import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { PunchoutComponentsModule } from '@spartacus/punchout/components';
import { PunchoutCoreModule } from '@spartacus/punchout/core';
import { PunchoutOccModule } from '@spartacus/punchout/occ';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: PunchoutModule, imports: [PunchoutComponentsModule, PunchoutCoreModule, PunchoutOccModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutModule, imports: [PunchoutComponentsModule, PunchoutCoreModule, PunchoutOccModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [PunchoutComponentsModule, PunchoutCoreModule, PunchoutOccModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/*
 * Public API Surface of punchout
 */

/**
 * Generated bundle index. Do not edit.
 */

export { PunchoutModule };
//# sourceMappingURL=spartacus-punchout.mjs.map
