var punchout$w = {
	backToRequisition: "Zpět na požadavek",
	cancel: "Zrušit",
	redirectToProcurementSystem: "Zpět do nákupního systému",
	closeSession: "Zavřít relaci",
	initiatingUserSession: "Zahajuji relaci uživatele",
	error: "Relace byla nečekaně ukončena. Vraťte se do nákupního systému.",
	noSufficientPermissions: "Pro přístup na tuto stránku nemáte dostatečné oprávnění"
};
var punchout$x = {
	punchout: punchout$w
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const cs = {
    punchout: punchout$x,
};

var punchout$u = {
	backToRequisition: "Zurück zur Anforderung",
	cancel: "Abbrechen",
	redirectToProcurementSystem: "Zurück zur Beschaffung",
	closeSession: "Sitzung beenden",
	initiatingUserSession: "Benutzersitzung initiieren",
	error: "Die Sitzung wurde unerwartet beendet. Kehren Sie zum Beschaffungssystem zurück.",
	noSufficientPermissions: "Keine ausreichenden Berechtigungen für den Zugriff auf diese Seite"
};
var punchout$v = {
	punchout: punchout$u
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const de = {
    punchout: punchout$v,
};

var punchout$s = {
	backToRequisition: "Back to requisition",
	cancel: "Cancel",
	redirectToProcurementSystem: "Return to Procurement System",
	closeSession: "Close Session",
	initiatingUserSession: "Initiating user session",
	error: "The session has unexpectedly ended. Please return to the procurement system.",
	noSufficientPermissions: "No sufficient permissions to access this page"
};
var punchout$t = {
	punchout: punchout$s
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const en = {
    punchout: punchout$t,
};

var punchout$q = {
	backToRequisition: "Volver a solicitud",
	cancel: "Cancelar",
	redirectToProcurementSystem: "Volver a sistema de adquisición",
	closeSession: "Cerrar sesión",
	initiatingUserSession: "Iniciando sesión de usuario",
	error: "La sesión finalizó inesperadamente. Regrese al sistema de adquisición.",
	noSufficientPermissions: "Sin permisos suficientes para acceder a esta página"
};
var punchout$r = {
	punchout: punchout$q
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const es = {
    punchout: punchout$r,
};

var punchout$o = {
	backToRequisition: "Volver a solicitud",
	cancel: "Cancelar",
	redirectToProcurementSystem: "Volver a sistema de adquisición",
	closeSession: "Cerrar sesión",
	initiatingUserSession: "Iniciando sesión de usuario",
	error: "La sesión finalizó inesperadamente. Regrese al sistema de adquisición.",
	noSufficientPermissions: "Sin permisos suficientes para acceder a esta página"
};
var punchout$p = {
	punchout: punchout$o
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const es_CO = {
    punchout: punchout$p,
};

var punchout$m = {
	backToRequisition: "Retour à la demande d'achat",
	cancel: "Annuler",
	redirectToProcurementSystem: "Revenir au système d'approvisionnement",
	closeSession: "Terminer la session",
	initiatingUserSession: "Lancement de la session d'utilisateur",
	error: "La session s'est terminée de manière inattendue. Revenez dans le système d'approvisionnement.",
	noSufficientPermissions: "Vous n'avez pas les autorisations suffisantes pour accéder à cette page."
};
var punchout$n = {
	punchout: punchout$m
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const fr = {
    punchout: punchout$n,
};

var punchout$k = {
	backToRequisition: "मांग-पत्र पर वापस जाएं",
	cancel: "रद्द करें",
	redirectToProcurementSystem: "अधिप्राप्ति सिस्टम पर वापस जाएं",
	closeSession: "सत्र बंद करें",
	initiatingUserSession: "उपयोगकर्ता सत्र आरंभ हो रहा है",
	error: "सत्र अनपेक्षित रूप से समाप्त हो गया है. कृपया अधिप्राप्ति सिस्टम पर वापस जाएं.",
	noSufficientPermissions: "इस पृष्ठ पर पहुंच के लिए पर्याप्त अनुमति नहीं है."
};
var punchout$l = {
	punchout: punchout$k
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const hi = {
    punchout: punchout$l,
};

var punchout$i = {
	backToRequisition: "Vissza az igényléshez",
	cancel: "Mégse",
	redirectToProcurementSystem: "Vissza a beszerzési rendszerbe",
	closeSession: "Munkamenet bezárása",
	initiatingUserSession: "Felhasználói munkamenet indítása",
	error: "A munkamenet váratlanul leállt. Térjen vissza a beszerzési rendszerbe.",
	noSufficientPermissions: "Nem rendelkezik megfelelő jogosultsággal az oldal eléréséhez"
};
var punchout$j = {
	punchout: punchout$i
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const hu = {
    punchout: punchout$j,
};

var punchout$g = {
	backToRequisition: "Kembali ke permintaan pembelian",
	cancel: "Batalkan",
	redirectToProcurementSystem: "Kembali ke Sistem Pengadaan",
	closeSession: "Tutup Sesi",
	initiatingUserSession: "Menginisiasi sesi pengguna",
	error: "Sesi Anda telah berakhir secara tidak terduga. Silakan kembali ke sistem pengadaan.",
	noSufficientPermissions: "Anda tidak memiliki izin yang memadai untuk mengakses halaman ini"
};
var punchout$h = {
	punchout: punchout$g
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const id = {
    punchout: punchout$h,
};

var punchout$e = {
	backToRequisition: "Torna alla richiesta",
	cancel: "Annulla",
	redirectToProcurementSystem: "Torna al sistema di approvvigionamento",
	closeSession: "Chiudi sessione",
	initiatingUserSession: "Inizializzazione della sessione utente in corso",
	error: "La sessione è terminata in modo imprevisto. Tornare al sistema di approvvigionamento.",
	noSufficientPermissions: "Autorizzazioni insufficienti per accedere a questa pagina"
};
var punchout$f = {
	punchout: punchout$e
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const it = {
    punchout: punchout$f,
};

var punchout$c = {
	backToRequisition: "購入申請に戻る",
	cancel: "キャンセル",
	redirectToProcurementSystem: "調達システムに戻る",
	closeSession: "セッションを閉じる",
	initiatingUserSession: "ユーザセッションの開始中",
	error: "セッションが予期せずに終了しました。調達システムに戻ってください。",
	noSufficientPermissions: "このページにアクセスするのに十分な権限がありません"
};
var punchout$d = {
	punchout: punchout$c
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ja = {
    punchout: punchout$d,
};

var punchout$a = {
	backToRequisition: "요청으로 돌아가기",
	cancel: "취소",
	redirectToProcurementSystem: "조달 시스템으로 돌아가기",
	closeSession: "세션 닫기",
	initiatingUserSession: "사용자 세션 시작",
	error: "세션이 예기치 않게 종료되었습니다. 조달 시스템으로 돌아가십시오.",
	noSufficientPermissions: "이 페이지를 볼 수 있는 권한이 없습니다."
};
var punchout$b = {
	punchout: punchout$a
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ko = {
    punchout: punchout$b,
};

var punchout$8 = {
	backToRequisition: "Powrót do zapotrzebowania",
	cancel: "Anuluj",
	redirectToProcurementSystem: "Powrót do systemu zamówień",
	closeSession: "Zamknij sesję",
	initiatingUserSession: "Inicjowanie sesji użytkownika",
	error: "Sesja została niespodziewanie zakończona. Wróć do systemu zamówień.",
	noSufficientPermissions: "Niewystarczające uprawnienia dostępu do tej strony"
};
var punchout$9 = {
	punchout: punchout$8
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const pl = {
    punchout: punchout$9,
};

var punchout$6 = {
	backToRequisition: "Voltar à requisição",
	cancel: "Cancelar",
	redirectToProcurementSystem: "Voltar ao sistema de suprimento",
	closeSession: "Fechar sessão",
	initiatingUserSession: "Inicializando sessão de usuário",
	error: "A sessão encerrou inesperadamente. Retorne ao sistema de suprimento.",
	noSufficientPermissions: "Sem permissões suficientes para acessar esta página"
};
var punchout$7 = {
	punchout: punchout$6
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const pt = {
    punchout: punchout$7,
};

var punchout$4 = {
	backToRequisition: "Вернуться к заявке",
	cancel: "Отменить",
	redirectToProcurementSystem: "Вернуться в систему закупок",
	closeSession: "Закрыть сеанс",
	initiatingUserSession: "Запуск сеанса пользователя",
	error: "Сеанс внезапно завершился. Вернитесь в систему закупок.",
	noSufficientPermissions: "Нет полномочий на доступ к этой странице"
};
var punchout$5 = {
	punchout: punchout$4
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ru = {
    punchout: punchout$5,
};

var punchout$2 = {
	backToRequisition: "返回到请购单",
	cancel: "取消",
	redirectToProcurementSystem: "返回到采购系统",
	closeSession: "关闭会话",
	initiatingUserSession: "发起用户会话",
	error: "会话意外结束。请返回到采购系统。",
	noSufficientPermissions: "权限不足，无法访问此页面"
};
var punchout$3 = {
	punchout: punchout$2
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const zh = {
    punchout: punchout$3,
};

var punchout = {
	backToRequisition: "返回請購單",
	cancel: "取消",
	redirectToProcurementSystem: "返回採購系統",
	closeSession: "關閉工作階段",
	initiatingUserSession: "初始化使用者工作階段",
	error: "工作階段未預期結束。請返回採購系統。",
	noSufficientPermissions: "存取此頁面的權限不足"
};
var punchout$1 = {
	punchout: punchout
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const zh_TW = {
    punchout: punchout$1,
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const punchoutTranslationChunksConfig = {
    punchout: ['punchout'],
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const punchoutTranslations = {
    en: en,
};

/**
 * Generated bundle index. Do not edit.
 */

export { punchoutTranslationChunksConfig, punchoutTranslations, cs as punchoutTranslationsCs, de as punchoutTranslationsDe, en as punchoutTranslationsEn, es as punchoutTranslationsEs, es_CO as punchoutTranslationsEs_CO, fr as punchoutTranslationsFr, hi as punchoutTranslationsHi, hu as punchoutTranslationsHu, id as punchoutTranslationsId, it as punchoutTranslationsIt, ja as punchoutTranslationsJa, ko as punchoutTranslationsKo, pl as punchoutTranslationsPl, pt as punchoutTranslationsPt, ru as punchoutTranslationsRu, zh as punchoutTranslationsZh, zh_TW as punchoutTranslationsZh_TW };
//# sourceMappingURL=spartacus-punchout-assets.mjs.map
