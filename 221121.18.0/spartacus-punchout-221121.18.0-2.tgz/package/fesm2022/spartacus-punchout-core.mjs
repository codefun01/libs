import * as i0 from '@angular/core';
import { InjectionToken, inject, Injectable, NgModule } from '@angular/core';
import { AuthService, GlobalMessageService, AuthStorageService, AuthRedirectService, UserIdService, RoutingService, GlobalMessageType, OCC_USER_ID_CURRENT, AuthActions, CommandService } from '@spartacus/core';
import { PunchoutStoreService, PunchoutDetectionService, PunchOutOperation, PunchOutLevel, PunchoutFacade } from '@spartacus/punchout/root';
import { MultiCartFacade } from '@spartacus/cart/base/root';
import { tap, switchMap, from, map, of, take, throwError, catchError } from 'rxjs';
import { Store } from '@ngrx/store';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const PUNCHOUT_SESSION_NORMALIZER = new InjectionToken('PunchoutSessionNormalizer');
const PUNCHOUT_REQUISITION_NORMALIZER = new InjectionToken('PunchoutRequisitionNormalizer');

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutConnector {
    constructor() {
        this.adapter = inject(PunchoutAdapter);
    }
    getPunchoutSession(sessionId) {
        return this.adapter.getPunchoutSession(sessionId);
    }
    getPunchoutSessionRequisition(sessionId, discardCartEntries = false) {
        return this.adapter.getPunchoutSessionRequisition(sessionId, discardCartEntries);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ACCESS_TOKEN = 'access_token';
const ACCESS_TOKEN_STORED_AT = 'access_token_stored_at';
const TOKEN_TYPE = 'token_type';
class PunchoutAuthService {
    constructor() {
        this.authService = inject(AuthService);
        this.globalMessageService = inject(GlobalMessageService);
        this.authStorageService = inject(AuthStorageService);
        this.authRedirectService = inject(AuthRedirectService);
        this.userIdService = inject(UserIdService);
        this.store = inject(Store);
        this.punchoutStoreService = inject(PunchoutStoreService);
        this.punchoutDetectionService = inject(PunchoutDetectionService);
        this.routingService = inject(RoutingService);
    }
    silentLogout(isPageRefresh = false) {
        return this.isUserLoggedIn().pipe(tap(() => {
            if (!isPageRefresh) {
                this.punchoutStoreService.clearPunchoutState();
            }
        }), switchMap((isLoggedIn) => {
            return isLoggedIn
                ? from(this.authService.coreLogout()).pipe(map(() => {
                    this.globalMessageService.remove(GlobalMessageType.MSG_TYPE_CONFIRMATION);
                    return true;
                }))
                : of(false);
        }));
    }
    loginWithToken(accessToken) {
        // Code mostly based on auth lib we use and the way it handles token properties
        this.authStorageService.setItem(ACCESS_TOKEN, accessToken);
        this.authStorageService.setItem(ACCESS_TOKEN_STORED_AT, Date.now().toString());
        this.authStorageService.setItem(TOKEN_TYPE, 'Bearer');
        this.userIdService.setUserId(OCC_USER_ID_CURRENT);
        this.store.dispatch(new AuthActions.Login());
        this.globalMessageService.remove(GlobalMessageType.MSG_TYPE_CONFIRMATION);
    }
    isUserLoggedIn() {
        return this.authService.isUserLoggedIn().pipe(take(1));
    }
    endPunchoutSession() {
        this.punchoutStoreService.clearPunchoutState();
        this.globalMessageService.add({ key: 'httpHandlers.unauthorized.common' }, GlobalMessageType.MSG_TYPE_ERROR);
        if (this.punchoutDetectionService.isPunchoutSessionPage()) {
            this.authRedirectService.setRedirectUrl('/');
        }
        this.authService.coreLogout().finally(() => {
            this.routingService.go({
                cxRoute: 'punchoutError',
            });
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutAuthService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutAuthService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutAuthService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutService {
    constructor() {
        this.punchoutConnector = inject(PunchoutConnector);
        this.punchoutAuthService = inject(PunchoutAuthService);
        this.commandService = inject(CommandService);
        this.routingService = inject(RoutingService);
        this.punchoutStoreService = inject(PunchoutStoreService);
        this.multiCartFacade = inject(MultiCartFacade);
        this.userIdService = inject(UserIdService);
        this.globalMessageService = inject(GlobalMessageService);
        /**
         * getPunchoutSession workflow:
         * Logout silently
         * Get PunchoutSession from  occ api
         * Login silently
         * Load Cart
         * Only for EDIT mode: Fetch Requisition to store initial cart in CXML format.
         * Route to target page based on punchout session info
         * Redirect to Punchout Error page if error occurs
         */
        this.getPunchoutSessionCommand = this.commandService.create((payload) => {
            if (!payload?.punchoutSessionId) {
                this.punchoutAuthService.endPunchoutSession();
                return throwError(() => new Error('Punchout Session Id missing'));
            }
            return this.punchoutAuthService.silentLogout(payload?.isPageRefresh).pipe(switchMap(() => this.requestPunchoutSession(payload.punchoutSessionId)), map((punchoutSession) => {
                if (punchoutSession?.token?.accessToken) {
                    this.punchoutAuthService.loginWithToken(punchoutSession.token.accessToken);
                    this.loadCart(punchoutSession.cartId).subscribe();
                    this.punchoutStoreService.setPunchoutState({
                        punchoutSessionId: payload.punchoutSessionId,
                        punchoutSession: { ...punchoutSession },
                    });
                    if (punchoutSession.punchOutOperation === PunchOutOperation.EDIT &&
                        punchoutSession?.cartId &&
                        !payload?.isPageRefresh) {
                        this.setPunchoutInitialRequisition();
                    }
                    if (!payload?.isPageRefresh) {
                        this.routeToTargetPage(punchoutSession);
                    }
                }
                return punchoutSession;
            }), catchError((error) => {
                this.punchoutAuthService.endPunchoutSession();
                return throwError(() => new Error(error));
            }));
        });
        /**
         * getPunchoutRequisition workflow:
         * Ensure user is logged-in
         * get punchoutSessionId from PunchoutState
         * Redirect user to homePage if method is called from Requisition page manual navigation
         * Get PunchoutSessionRequisition from  occ api OR from PunchoutState
         * Redirect to Punchout Error page if error occurs
         */
        this.getPunchoutRequisitionCommand = this.commandService.create((isInitialRequisition) => {
            return this.punchoutAuthService.isUserLoggedIn().pipe(switchMap((isLoggedIn) => {
                return isLoggedIn
                    ? this.punchoutStoreService.getPunchoutState()
                    : throwError(() => new Error('User not loggedIn'));
            }), take(1), switchMap((punchoutState) => {
                // prevent manual navigation to requisition page
                // isInitialRequisition handles use case where this method is called out of Requisition page,
                // when fetching the initial requisition object from setPunchoutInitialRequisition().
                if (!isInitialRequisition &&
                    punchoutState?.closePunchoutSession === undefined &&
                    punchoutState?.cancelRequisition === undefined) {
                    this.globalMessageService.add({
                        key: 'punchout.noSufficientPermissions',
                    }, GlobalMessageType.MSG_TYPE_WARNING);
                    this.routingService.go({ cxRoute: 'home' });
                    return of();
                }
                // scenario where user pressed 'Close punchout session' button in EDIT Cart mode
                // initial cart requisition is returned to ARIBA
                if (punchoutState?.closePunchoutSession &&
                    punchoutState?.punchoutInitialRequisition?.browseFormPostUrl &&
                    punchoutState.punchoutInitialRequisition?.orderAsCXML) {
                    return of({ ...punchoutState.punchoutInitialRequisition });
                }
                const punchoutSessionId = punchoutState?.punchoutSessionId;
                return punchoutSessionId
                    ? this.punchoutConnector.getPunchoutSessionRequisition(punchoutSessionId, punchoutState?.cancelRequisition)
                    : throwError(() => new Error('Punchout Session Id missing'));
            }), catchError((error) => {
                this.punchoutAuthService.endPunchoutSession();
                return throwError(() => new Error(error));
            }));
        });
        /**
         * logoutPunchoutUser workflow:
         * clear punchout state
         * silent logout, meaning no notification displayed and redirection.
         */
        this.logoutPunchoutUserCommand = this.commandService.create(() => this.punchoutAuthService.silentLogout());
        /**
         * endUserSession workflow:
         * clear punchout state,logout, redirect to login page, display message
         */
        this.endPunchoutSessionCommand = this.commandService.create(() => of(true).pipe(tap(() => {
            this.punchoutAuthService.endPunchoutSession();
        })));
        /**
         * closePunchoutSession workflow:
         * For EDIT operation:
         * - Initial cart snapshot gets sent in CXML, driven by closePunchoutSession flag.
         * For CREATE operation:
         * - Empty cart gets sent in CXML, driven by cancelRequisition flag.
         * For INSPECT operation:
         * - Current cart gets sent in CXML.
         */
        this.closePunchoutSessionCommand = this.commandService.create(() => {
            return this.punchoutStoreService.getPunchoutState().pipe(take(1), map((punchoutState) => {
                if (punchoutState.punchoutSession?.punchOutOperation ===
                    PunchOutOperation.CREATE) {
                    this.punchoutStoreService.updatePunchoutState({
                        cancelRequisition: true,
                    });
                }
                else if (punchoutState.punchoutSession?.punchOutOperation ===
                    PunchOutOperation.EDIT) {
                    this.punchoutStoreService.updatePunchoutState({
                        closePunchoutSession: true,
                    });
                }
                this.openRequisitionPage();
                return true;
            }), catchError((error) => {
                this.punchoutAuthService.endPunchoutSession();
                return throwError(() => new Error(error));
            }));
        });
        /**
         * Request Punchout session calling occ api.
         * Returns cached value if server request has been already made.
         * @param punchoutSessionId
         * @returns
         */
        this.requestPunchoutSessionCommand = this.commandService.create((punchoutSessionId) => {
            return this.cachedPunchoutSessionResponse
                ? of(this.cachedPunchoutSessionResponse)
                : this.punchoutConnector.getPunchoutSession(punchoutSessionId).pipe(map((punchoutSession) => {
                    if (!punchoutSession?.token?.accessToken ||
                        !punchoutSession?.customerId ||
                        !punchoutSession?.cartId) {
                        throw new Error('Punchout login info missing');
                    }
                    this.cachedPunchoutSessionResponse = {
                        ...punchoutSession,
                        token: { ...punchoutSession.token },
                    };
                    return punchoutSession;
                }));
        });
    }
    closePunchoutSession() {
        return this.closePunchoutSessionCommand.execute(undefined);
    }
    initPunchoutSession(punchoutSessionInput) {
        return this.getPunchoutSessionCommand.execute(punchoutSessionInput);
    }
    getPunchoutSessionRequisition(isInitialRequisition = false) {
        return this.getPunchoutRequisitionCommand.execute(isInitialRequisition);
    }
    logoutPunchoutUser() {
        return this.logoutPunchoutUserCommand.execute();
    }
    endPunchoutSession() {
        return this.endPunchoutSessionCommand.execute();
    }
    requestPunchoutSession(punchoutSessionId) {
        return this.requestPunchoutSessionCommand.execute(punchoutSessionId);
    }
    submitRequisition(cancelRequisition) {
        this.punchoutStoreService.updatePunchoutState({ cancelRequisition });
        this.openRequisitionPage();
    }
    routeToTargetPage(punchoutSession) {
        if ((punchoutSession?.punchOutOperation === PunchOutOperation.CREATE ||
            punchoutSession?.punchOutOperation === PunchOutOperation.EDIT) &&
            punchoutSession?.punchOutLevel === PunchOutLevel.PRODUCT &&
            punchoutSession?.selectedItem) {
            this.routingService.go({
                cxRoute: 'product',
                params: { code: punchoutSession.selectedItem, name: '' },
            });
            return;
        }
        if (punchoutSession?.punchOutOperation === PunchOutOperation.EDIT) {
            this.routingService.go({ cxRoute: 'cart' });
            return;
        }
        if (punchoutSession?.punchOutOperation === PunchOutOperation.INSPECT) {
            this.routingService.go({ cxRoute: 'punchoutInspect' });
            return;
        }
        this.routingService.go('/');
    }
    loadCart(cartId) {
        return this.userIdService.takeUserId().pipe(take(1), tap((userId) => {
            this.multiCartFacade.loadCart({
                userId,
                cartId,
                extraData: {
                    active: true,
                },
            });
        }));
    }
    /**
     * Take a snapshot of initial requisition and store it in the state.
     * This is used to send the initial cart snapshot in CXML when the user
     * closes the punchout session via 'Close Session' button.
     *
     * This method is called only in EDIT mode.
     * @returns
     */
    setPunchoutInitialRequisition() {
        // isInitialRequisition is set to true as hitting initial Requisition use case.
        this.getPunchoutSessionRequisition(true)
            .pipe(take(1))
            .subscribe({
            next: (punchoutRequisition) => {
                if (punchoutRequisition) {
                    this.punchoutStoreService.updatePunchoutState({
                        punchoutInitialRequisition: { ...punchoutRequisition },
                    });
                }
            },
        });
    }
    openRequisitionPage() {
        this.globalMessageService.add({
            key: 'punchout.redirectToProcurementSystem',
        }, GlobalMessageType.MSG_TYPE_INFO);
        this.routingService.go({ cxRoute: 'punchoutRequisition' });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const facadeProviders = [
    PunchoutService,
    {
        provide: PunchoutFacade,
        useExisting: PunchoutService,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutCoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: PunchoutCoreModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutCoreModule, providers: [...facadeProviders, PunchoutConnector, PunchoutAuthService] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    providers: [...facadeProviders, PunchoutConnector, PunchoutAuthService],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { PUNCHOUT_REQUISITION_NORMALIZER, PUNCHOUT_SESSION_NORMALIZER, PunchoutAdapter, PunchoutAuthService, PunchoutConnector, PunchoutCoreModule, PunchoutService };
//# sourceMappingURL=spartacus-punchout-core.mjs.map
