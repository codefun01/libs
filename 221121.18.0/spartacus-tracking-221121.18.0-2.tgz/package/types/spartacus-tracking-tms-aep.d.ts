import * as i0 from '@angular/core';
import { ScriptLoader, CxEvent } from '@spartacus/core';
import { TmsCollectorConfig, TmsCollector, WindowObject } from '@spartacus/tracking/tms/core';

declare class AepModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AepModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AepModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AepModule>;
}

interface AepCollectorConfig extends TmsCollectorConfig {
    scriptUrl?: string;
}
declare module '@spartacus/tracking/tms/core' {
    interface TmsCollectors {
        aep?: AepCollectorConfig;
    }
}

/**
 * Default Adobe Experience Platform Launch collector.
 */
declare class AepCollectorService implements TmsCollector {
    protected scriptLoader: ScriptLoader;
    constructor(scriptLoader: ScriptLoader);
    /**
     * If the `TmsCollectorConfig.dataLayerProperty` is not specified, it uses the default `digitalData`
     */
    init(config: AepCollectorConfig, windowObject: WindowObject): void;
    pushEvent<T extends CxEvent>(config: TmsCollectorConfig, windowObject: WindowObject, event: T | any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AepCollectorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AepCollectorService>;
}

export { AepCollectorService, AepModule };
