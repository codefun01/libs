import * as i0 from '@angular/core';
import { CmsService, LoggerService } from '@spartacus/core';
import { PersonalizationConfig } from '@spartacus/tracking/personalization/root';
import { Observable } from 'rxjs';

interface PersonalizationAction {
    action_name: string;
    action_type: string;
    customization_name?: string;
    customization_code?: string;
    variation_name?: string;
    variation_code?: string;
}
interface PersonalizationContext {
    actions: PersonalizationAction[];
    segments: string[];
}

declare class PersonalizationCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PersonalizationCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PersonalizationCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PersonalizationCoreModule>;
}

declare class PersonalizationContextService {
    protected config: PersonalizationConfig;
    protected cmsService: CmsService;
    protected logger: LoggerService;
    constructor(config: PersonalizationConfig, cmsService: CmsService);
    getPersonalizationContext(): Observable<PersonalizationContext | undefined>;
    private buildPersonalizationContext;
    static ɵfac: i0.ɵɵFactoryDeclaration<PersonalizationContextService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PersonalizationContextService>;
}

export { PersonalizationContextService, PersonalizationCoreModule };
export type { PersonalizationAction, PersonalizationContext };
