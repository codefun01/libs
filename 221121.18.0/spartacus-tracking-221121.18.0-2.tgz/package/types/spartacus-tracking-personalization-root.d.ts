import * as i0 from '@angular/core';
import { CmsConfig, LoggerService, OccEndpointsService, WindowRef } from '@spartacus/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

declare abstract class PersonalizationConfig {
    personalization?: {
        enabled?: boolean;
        httpHeaderName?: {
            id: string;
            timestamp: string;
        };
        context?: {
            slotPosition: string;
            componentId: string;
        };
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<PersonalizationConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PersonalizationConfig>;
}
declare module '@spartacus/core' {
    interface Config extends PersonalizationConfig {
    }
}

declare const PERSONALIZATION_FEATURE = "personalization";

declare function defaultPersonalizationComponentsConfig(): CmsConfig;
declare class PersonalizationRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PersonalizationRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PersonalizationRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PersonalizationRootModule>;
}

declare class OccPersonalizationIdInterceptor implements HttpInterceptor {
    private config;
    private occEndpoints;
    private winRef;
    private personalizationId?;
    private requestHeader?;
    private enabled;
    protected readonly PERSONALIZATION_ID_KEY = "personalization-id";
    protected logger: LoggerService;
    constructor(config: PersonalizationConfig, occEndpoints: OccEndpointsService, winRef: WindowRef);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccPersonalizationIdInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccPersonalizationIdInterceptor>;
}

declare class OccPersonalizationTimeInterceptor implements HttpInterceptor {
    private config;
    private occEndpoints;
    private winRef;
    private timestamp?;
    private requestHeader?;
    private enabled;
    protected readonly PERSONALIZATION_TIME_KEY = "personalization-time";
    protected logger: LoggerService;
    constructor(config: PersonalizationConfig, occEndpoints: OccEndpointsService, winRef: WindowRef);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccPersonalizationTimeInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccPersonalizationTimeInterceptor>;
}

export { OccPersonalizationIdInterceptor, OccPersonalizationTimeInterceptor, PERSONALIZATION_FEATURE, PersonalizationConfig, PersonalizationRootModule, defaultPersonalizationComponentsConfig };
