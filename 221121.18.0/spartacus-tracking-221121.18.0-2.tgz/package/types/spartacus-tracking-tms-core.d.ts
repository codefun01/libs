import * as i0 from '@angular/core';
import { AbstractType, Type, OnDestroy, Injector, ModuleWithProviders } from '@angular/core';
import { CxEvent, EventService, WindowRef, LoggerService } from '@spartacus/core';
import { Subscription, Observable } from 'rxjs';

/**
 * Window object enriched with a custom property.
 * Intended to be used for specifying the data layer name.
 */
interface WindowObject extends Window {
    [prop: string]: any;
}
/**
 * Interface that a class can implement in order to be recognized as a TMS collector.
 */
interface TmsCollector {
    /**
     * Initializes the data layer.
     */
    init(config: TmsCollectorConfig, windowObject: WindowObject): void;
    /**
     * Pushes the provided event to the data layer.
     */
    pushEvent<T extends CxEvent>(config: TmsCollectorConfig, windowObject: WindowObject, event: T | any): void;
    /**
     * Maps the Spartacus event to another object.
     */
    map?<T extends CxEvent>(event: T): T | object;
}

/**
 * Collector configuration
 */
interface TmsCollectorConfig {
    /** Should be enabled in development mode only */
    debug?: boolean;
    /**
     * The name for the data layer object.
     */
    dataLayerProperty?: string;
    /**
     * Events to send to the configured TMS.
     */
    events?: AbstractType<CxEvent>[];
    /**
     * The collector service implementation.
     */
    collector?: Type<TmsCollector>;
}
interface TmsCollectors {
    [tms: string]: TmsCollectorConfig | undefined;
}
/**
 * TMS configuration
 */
declare abstract class TmsConfig {
    /**
     * Tag manager config
     */
    tagManager?: TmsCollectors;
    static ɵfac: i0.ɵɵFactoryDeclaration<TmsConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TmsConfig>;
}
declare module '@spartacus/core' {
    interface Config extends TmsConfig {
    }
}

/**
 * This service interacts with the configured data layer object by pushing the Spartacus events to it.
 */
declare class TmsService implements OnDestroy {
    protected eventsService: EventService;
    protected windowRef: WindowRef;
    protected tmsConfig: TmsConfig;
    protected injector: Injector;
    /**
     * Stores subscriptions to events.
     */
    protected subscription: Subscription;
    protected logger: LoggerService;
    constructor(eventsService: EventService, windowRef: WindowRef, tmsConfig: TmsConfig, injector: Injector);
    /**
     * Called only once to start collecting and dispatching events
     */
    collect(): void;
    /**
     * Maps the given events to an appropriate type that fits the specified TMS' structure.
     *
     * @param events - the events to map
     * @param collector - a name of the collector for which the events should be mapped
     */
    protected mapEvents<T extends CxEvent>(events: Observable<T>[]): Observable<T>;
    /**
     * Angular's callback
     */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TmsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TmsService>;
}

/**
 * The factory that conditionally (based on the configuration) starts collecting events
 */
declare function tmsFactory(service: TmsService): () => void;
declare class BaseTmsModule {
    static forRoot(): ModuleWithProviders<BaseTmsModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseTmsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BaseTmsModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BaseTmsModule>;
}

export { BaseTmsModule, TmsConfig, TmsService, tmsFactory };
export type { TmsCollector, TmsCollectorConfig, TmsCollectors, WindowObject };
