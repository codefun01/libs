import * as i0 from '@angular/core';
import { WindowRef, CxEvent } from '@spartacus/core';
import { TmsCollectorConfig, TmsCollector, WindowObject } from '@spartacus/tracking/tms/core';

declare class GtmModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GtmModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GtmModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GtmModule>;
}

interface GtmCollectorConfig extends TmsCollectorConfig {
    gtmId?: string;
}
declare module '@spartacus/tracking/tms/core' {
    interface TmsCollectors {
        gtm?: GtmCollectorConfig;
    }
}

/**
 * Default Google Tag Manager collector.
 */
declare class GtmCollectorService implements TmsCollector {
    protected winRef: WindowRef;
    constructor(winRef: WindowRef);
    /**
     * If the `TmsCollectorConfig.dataLayerProperty` is not specified, it uses the default `dataLayer`
     */
    init(config: GtmCollectorConfig, windowObject: WindowObject): void;
    pushEvent<T extends CxEvent>(config: TmsCollectorConfig, windowObject: WindowObject, event: T | any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GtmCollectorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GtmCollectorService>;
}

export { GtmCollectorService, GtmModule };
