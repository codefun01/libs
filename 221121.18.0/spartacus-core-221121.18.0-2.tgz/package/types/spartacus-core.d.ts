import * as i0 from '@angular/core';
import { Type, AbstractType, ModuleWithProviders, ErrorHandler, OnDestroy, Compiler, Injector, NgModuleRef, InjectionToken, PipeTransform, ClassProvider, FactoryProvider, Provider, DestroyRef, ValueProvider, ChangeDetectorRef, TemplateRef, ViewContainerRef, StaticProvider, Renderer2, ComponentRef } from '@angular/core';
import * as i2 from '@ngrx/store';
import { ActionsSubject, Action, Store, MemoizedSelector } from '@ngrx/store';
import * as i4 from '@ngrx/effects';
import { Actions } from '@ngrx/effects';
import * as i1 from '@angular/common';
import { Location as Location$1, DatePipe, DecimalPipe } from '@angular/common';
import * as _angular_router from '@angular/router';
import { UrlMatcher, Route, Routes, Router, ActivatedRouteSnapshot, RouterStateSnapshot, Params, NavigationExtras, NavigationBehaviorOptions, Data, DefaultUrlSerializer, UrlTree, NavigationEnd, NavigationCancel, GuardResult, CanActivate } from '@angular/router';
import * as i2$1 from 'angular-oauth2-oidc';
import { AuthConfig as AuthConfig$1, OAuthStorage, OAuthService, OAuthEvent, TokenResponse } from 'angular-oauth2-oidc';
import * as rxjs from 'rxjs';
import { Observable, Subscription, OperatorFunction, BehaviorSubject, ReplaySubject, Subject } from 'rxjs';
import * as _spartacus_core from '@spartacus/core';
import * as fromNgrxRouter from '@ngrx/router-store';
import { HttpParamsOptions, HttpParams, HttpRequest, HttpHandler, HttpInterceptor, HttpEvent, HttpErrorResponse, HttpClient, HttpHeaders, HttpContextToken, HttpParameterCodec } from '@angular/common/http';
import { InitOptions, i18n } from 'i18next';
import * as i18next_http_backend from 'i18next-http-backend';
import { HttpBackendOptions } from 'i18next-http-backend';
import * as node_modules_i18next from 'node_modules/i18next';
import { Meta } from '@angular/platform-browser';

declare enum StorageSyncType {
    NO_STORAGE = "NO_STORAGE",
    LOCAL_STORAGE = "LOCAL_STORAGE",
    SESSION_STORAGE = "SESSION_STORAGE"
}
declare enum StateTransferType {
    TRANSFER_STATE = "SSR"
}
declare abstract class StateConfig {
    state?: {
        ssrTransfer?: {
            keys?: {
                /**
                 * A set of state keys that should be transferred from server.
                 */
                [key: string]: StateTransferType | undefined;
            };
        };
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<StateConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StateConfig>;
}
declare module './spartacus-core' {
    interface Config extends StateConfig {
    }
}

interface ActionToEventMapping<T> {
    /**
     * String type of action (or types) to be mapped to the event
     */
    action: string | string[];
    /**
     * Event class type (constructor)
     */
    event: Type<T> | null;
    /**
     * Function mapping the instance of the action to the event
     */
    factory?: (action: any) => T;
}

/**
 * By default it delegates logged messages to the native `console` object.
 *
 * It's a good extension point for customizing the destination of logs
 * (e.g. to use a 3rd party logger library) or to enhance logs with more contextual data.
 */
declare class LoggerService {
    log(...args: Parameters<typeof console.log>): void;
    warn(...args: Parameters<typeof console.warn>): void;
    error(...args: Parameters<typeof console.error>): void;
    info(...args: Parameters<typeof console.info>): void;
    debug(...args: Parameters<typeof console.debug>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoggerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoggerService>;
}

/**
 * A service to register and observe event sources. Events are driven by event types, which are class signatures
 * for the given event.
 *
 * It is possible to register multiple sources to a single event, even without
 * knowing as multiple decoupled features can attach sources to the same
 * event type.
 */
declare class EventService {
    protected logger: LoggerService;
    /**
     * The various events meta are collected in a map, stored by the event type class
     */
    private eventsMeta;
    /**
     * Register an event source for the given event type.
     *
     * CAUTION: To avoid memory leaks, the returned teardown function should be called
     *  when the event source is no longer maintained by its creator
     * (i.e. in `ngOnDestroy` if the event source was registered in the component).
     *
     * @since 3.1 - registers the given `source$` for the parent classes of the given `eventType`.
     *
     * @param eventType the event type
     * @param source$ an observable that represents the source
     *
     * @returns a teardown function which unregisters the given event source
     */
    register<T>(eventType: AbstractType<T>, source$: Observable<T>): () => void;
    /**
     * Returns a stream of events for the given event type
     * @param eventTypes event type
     */
    get<T>(eventType: AbstractType<T>): Observable<T>;
    /**
     * Dispatches an instance of an individual event.
     * If the eventType is provided a new event will be created for that type and with the event data.
     *
     * @param event an event
     * @param eventType (optional) - type of event
     */
    dispatch<T extends object>(event: T, eventType?: Type<T>): void;
    /**
     * Returns the input subject used to dispatch a single event.
     * The subject is created on demand, when it's needed for the first time.
     * @param eventType type of event
     */
    private getInputSubject;
    /**
     * Returns the event meta object for the given event type
     */
    private getEventMeta;
    private createEventMeta;
    /**
     * Checks if the event type is a valid type (is a class with constructor).
     *
     * Should be used only in dev mode.
     */
    private validateEventType;
    /**
     * Validates if the given type (or its prototype chain) extends from the CxEvent.
     *
     * Should be used only in the dev mode.
     */
    private validateCxEvent;
    /**
     * Returns the given event source with runtime validation whether the emitted values are instances of given event type.
     *
     * Should be used only in dev mode.
     */
    private getValidatedEventStream;
    static ɵfac: i0.ɵɵFactoryDeclaration<EventService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EventService>;
}

/**
 * Registers streams of ngrx actions as events source streams
 */
declare class StateEventService {
    protected actionsSubject: ActionsSubject;
    protected eventService: EventService;
    constructor(actionsSubject: ActionsSubject, eventService: EventService);
    /**
     * Registers an event source stream of specific events
     * mapped from a given action type.
     *
     * @param mapping mapping from action to event
     *
     * @returns a teardown function that unregisters the event source
     */
    register<T>(mapping: ActionToEventMapping<T>): () => void;
    /**
     * Returns a stream of specific events mapped from a specific action.
     * @param mapping mapping from action to event
     */
    protected getFromAction<T>(mapping: ActionToEventMapping<T>): Observable<T>;
    /**
     * Creates an event instance for given class out from the action object.
     * Unless the `factory` parameter is given, the action's `payload` is used
     * as the argument for the event's constructor.
     *
     * @param action instance of an Action
     * @param mapping mapping from action to event
     * @param factory optional function getting an action instance and returning an event instance
     *
     * @returns instance of an Event
     */
    protected createEvent<T>(action: {
        type: string;
        payload?: any;
    }, eventType: Type<T>, factory?: (action: any) => T): T;
    static ɵfac: i0.ɵɵFactoryDeclaration<StateEventService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StateEventService>;
}

declare class WindowRef {
    protected platformId: Object;
    protected serverUrl?: string | undefined;
    protected serverOrigin?: string | undefined;
    readonly document: Document;
    constructor(document: any, platformId: Object, serverUrl?: string | undefined, serverOrigin?: string | undefined);
    /**
     * Returns true when invoked in browser context.
     * Use this method to check if you can access `window` and other browser globals.
     */
    isBrowser(): boolean;
    /**
     * Exposes global `window` object. In SSR when `window` is not available it returns `undefined`.
     * To detect if you can safely use `nativeWindow` use `isBrowser` to check execution platform.
     */
    get nativeWindow(): Window | undefined;
    /**
     * Exposes global `sessionStorage` object. In SSR when `sessionStorage` is not available it returns `undefined`.
     * To detect if you can safely use `sessionStorage` use `isBrowser` to check execution platform.
     */
    get sessionStorage(): Storage | undefined;
    /**
     * Exposes global `localStorage` object. In SSR when `localStorage` is not available it returns `undefined`.
     * To detect if you can safely use `localStorage` use `isBrowser` to check execution platform.
     */
    get localStorage(): Storage | undefined;
    /**
     * Returns the window/document location, unless it's not available (i.e. SSR).
     *
     * When there's no access to the location object, we mimic the location partially, by resolving
     * the request url (`SERVER_REQUEST_URL`) and origin (`SERVER_REQUEST_ORIGIN`) from the injector.
     * These values are injected in the server implementation so that we can resolve some of the location
     * values when we do server side rendering.
     */
    get location(): Partial<Location>;
    /**
     * Returns an observable for the window resize event and emits an event
     * every 300ms in case of resizing. An event is simulated initially.
     *
     * If there's no window object available (i.e. in SSR), a null value is emitted.
     */
    get resize$(): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<WindowRef, [null, null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WindowRef>;
}

declare class StatePersistenceService {
    protected winRef: WindowRef;
    constructor(winRef: WindowRef);
    /**
     * Helper to synchronize state to more persistent storage (localStorage, sessionStorage).
     * It is context aware, so you can keep different state for te same feature based on specified context.
     *
     * Eg. cart is valid only under the same base site. So you want to synchronize cart only with the same base site.
     * Usage for that case: `syncWithStorage({ key: 'cart', state$: activeCartSelector$, context$: this.siteContextParamsService.getValues([BASE_SITE_CONTEXT_ID]), onRead: (state) => setCorrectStateInStore(state) })`.
     * Active cart for the `electronics` base site will be stored under `spartacus⚿electronics⚿cart` and for apparel under `spartacus⚿apparel⚿cart`.
     *
     * On each context change onRead function will be executed with state from storage provided as a parameter.
     *
     * Omitting context$ will trigger onRead only once at initialization.
     *
     * @param key Key to use in storage for the synchronized state. Should be unique for each feature.
     * @param state$ State to be saved and later restored.
     * @param context$ Context for state
     * @param storageType Storage type to be used to persist state
     * @param onRead Function to be executed on each storage read after context change
     *
     * @returns Subscriptions for reading/writing in storage on context/state change
     */
    syncWithStorage<T>({ key, state$, context$, storageType, onRead, }: {
        key: string;
        state$: Observable<T>;
        context$?: Observable<string | Array<string>>;
        storageType?: StorageSyncType;
        onRead?: (stateFromStorage: T | undefined) => void;
    }): Subscription;
    /**
     * Helper to read state from persistent storage (localStorage, sessionStorage).
     * It is useful if you need synchronously access state saved with `syncWithStorage`.
     *
     * @param key Key to use in storage for state. Should be unique for each feature.
     * @param context Context value for state
     * @param storageType Storage type from to read state
     *
     * @returns State from the storage
     */
    readStateFromStorage<T>({ key, context, storageType, }: {
        key: string;
        context?: string | Array<string>;
        storageType?: StorageSyncType;
    }): T | undefined;
    protected generateKeyWithContext(context: string | Array<string>, key: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<StatePersistenceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StatePersistenceService>;
}

declare class StateModule {
    static forRoot(): ModuleWithProviders<StateModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<StateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StateModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StateModule>;
}

/**
 * The CxErrorHandler is the default ErrorHandler for Spartacus.
 * It is responsible for handling errors and passing them to the registered multi error handlers.
 *
 * The prefix `Cx` was used to distinguish it from Angular's `ErrorHandler` class.
 * For more, see Angular docs: https://angular.dev/api/core/ErrorHandler
 *
 */
declare class CxErrorHandler implements ErrorHandler {
    protected errorHandlers: _spartacus_core.MultiErrorHandler[];
    /**
     * Error handler method. Handles the error by passing it to the registered multi error handlers.
     * @param error - The error to be handled.
     */
    handleError(error: unknown): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CxErrorHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CxErrorHandler>;
}

declare class EffectsErrorHandlerModule {
    static forRoot(): ModuleWithProviders<EffectsErrorHandlerModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<EffectsErrorHandlerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EffectsErrorHandlerModule, never, [typeof i4.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EffectsErrorHandlerModule>;
}

interface ErrorAction extends Action {
    error: Object;
}

/**
 * Service responsible for capturing and handling NgRx error actions that implements `ErrorAction`.
 * It ensures that HTTP errors, which are already handled by `HttpErrorHandlerInterceptor`, are not processed
 * again to avoid duplicate error handling.
 */
declare class ErrorActionService {
    protected errorHandler: ErrorHandler;
    protected windowRef: WindowRef;
    handle(action: ErrorAction): void;
    /** Here we want to filter which error actions should be handled.
     * By default, we check if action implements interface ErrorAction  */
    isErrorAction(action: Action): action is ErrorAction;
    /**
     * Determine if the error should be handled by the `ErrorHandler`.
     *
     * Be default, we avoid sending unpredictable errors to the browser's console, to prevent
     * possibly exposing there potentially confidential user's data.
     * This isn't an issue in SSR, where pages are rendered anonymously.
     * Moreover, in SSR we want to capture all app's errors, so we can potentially send
     * a HTTP error response (e.g. 500 error page) from SSR to a client.
     */
    protected shouldHandleError(_error: unknown): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorActionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ErrorActionService>;
}

declare class HttpErrorHandlerModule {
    static forRoot(): ModuleWithProviders<HttpErrorHandlerModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<HttpErrorHandlerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HttpErrorHandlerModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HttpErrorHandlerModule>;
}

declare class ErrorHandlingModule {
    static forRoot(): ModuleWithProviders<ErrorHandlingModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorHandlingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ErrorHandlingModule, never, [typeof EffectsErrorHandlerModule, typeof HttpErrorHandlerModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ErrorHandlingModule>;
}

declare class CmsOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CmsOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CmsOccModule>;
}

interface CmsComponent {
    modifiedTime?: Date;
    name?: string;
    otherProperties?: any;
    typeCode?: string;
    uid?: string;
    /**
     * Defines detailed CMS component composition
     */
    composition?: {
        /**
         * List of inner component mappings
         */
        inner?: string[];
    };
    /**
     * Style classes can be added to the CMS banner component to enhance the UX.
     * The style classes are typically derived from the (CMS) backend and should
     * match an existing CSS selector.
     *
     * The styleClasses can contain a "list" of space separated style classes.
     */
    styleClasses?: string;
}
interface CmsComponentWithChildren extends CmsComponent {
    children?: string;
}
declare enum PageType {
    CONTENT_PAGE = "ContentPage",
    PRODUCT_PAGE = "ProductPage",
    CATEGORY_PAGE = "CategoryPage",
    CATALOG_PAGE = "CatalogPage"
}
interface CmsLinkComponent extends CmsComponent {
    url?: string;
    container?: boolean;
    external?: boolean;
    contentPage?: string;
    contentPageLabelOrId?: string;
    linkName?: string;
    target?: string | boolean;
    /**
     * Style rules can be added to the CMS Link component to enhance the UX.
     * The style attributes are typically derived from the (CMS) backend.
     *
     * The styleAttributes can contain a "list" of semicolon separated style rules.
     */
    styleAttributes?: string;
}
interface CmsSiteContextSelectorComponent extends CmsComponent {
    context?: string;
}
declare enum ScrollBehavior {
    AUTO = "auto",
    SMOOTH = "smooth"
}
interface CmsScrollToTopComponent extends CmsComponent {
    scrollBehavior?: ScrollBehavior;
    displayThreshold?: number;
}
interface CmsSearchBoxComponent extends CmsComponent {
    container?: boolean;
    maxSuggestions?: number;
    maxProducts?: number;
    displaySuggestions?: boolean;
    displayProducts?: boolean;
    displayProductImages?: boolean;
    waitTimeBeforeRequest?: number;
    minCharactersBeforeRequest?: number;
}
interface CmsParagraphComponent extends CmsComponent {
    content?: string;
    container?: string;
    title?: string;
}
interface CMSTabParagraphContainer extends CmsComponent {
    container?: string;
    components?: string;
}
interface CmsBannerComponentMedia {
    altText?: string;
    code?: string;
    mime?: string;
    url?: string;
}
interface CmsResponsiveBannerComponentMedia {
    desktop?: CmsBannerComponentMedia;
    mobile?: CmsBannerComponentMedia;
    tablet?: CmsBannerComponentMedia;
    widescreen?: CmsBannerComponentMedia;
}
interface CmsBannerComponent extends CmsComponent {
    headline?: string;
    content?: string;
    container?: string;
    media?: CmsBannerComponentMedia | CmsResponsiveBannerComponentMedia;
    urlLink?: string;
    external?: string | boolean;
    contentPage?: string;
    product?: string;
    category?: string;
}
declare enum CmsBannerCarouselEffect {
    FADE = "FADE",
    ZOOM = "ZOOM",
    CURTAIN = "CURTAINX",
    TURNDOWN = "TURNDOWN"
}
interface CmsBannerCarouselComponent extends CmsComponent {
    banners?: string;
    effect?: CmsBannerCarouselEffect;
}
interface CmsProductCarouselComponent extends CmsComponent {
    categoryCodes?: string;
    title?: string;
    productCodes?: string;
    container?: string;
    popup?: string;
    scroll?: string;
}
interface CmsProductReferencesComponent extends CmsComponent {
    title?: string;
    displayProductTitles?: string;
    displayProductPrices?: string;
    maximumNumberProducts?: number;
    productReferenceTypes?: string;
    container?: string;
}
interface CmsMiniCartComponent extends CmsComponent {
    container?: string;
    shownProductCount?: string;
    title?: string;
    totalDisplay?: string;
    lightboxBannerComponent?: CmsBannerComponent;
}
interface CmsPageTitleComponent extends CmsComponent {
    container?: string;
}
interface CmsBreadcrumbsComponent extends CmsPageTitleComponent {
}
interface CmsNavigationNode {
    uid?: string;
    title?: string;
    children?: Array<CmsNavigationNode>;
    entries?: Array<CmsNavigationEntry>;
}
interface CmsNavigationEntry {
    itemId?: string;
    itemSuperType?: string;
    itemType?: string;
}
interface CmsNavigationComponent extends CmsComponent {
    container?: string;
    styleClass?: string;
    wrapAfter?: string;
    notice?: string;
    showLanguageCurrency?: string;
    navigationNode?: CmsNavigationNode;
    resetMenuOnClose?: boolean;
}
interface CmsProductFacetNavigationComponent extends CmsComponent {
    container?: string;
    activeFacetValueCode?: string;
    searchResult?: string;
    minPerFacet?: string;
}
interface CmsAddToCartComponent extends CmsComponent {
    inventoryDisplay?: boolean;
}
interface CmsOrderDetailItemsComponent extends CmsComponent {
    enableAddToCart?: boolean;
    groupCartItems?: boolean;
}
interface CmsOrderDetailOverviewComponent extends CmsComponent {
    simple?: boolean;
}
interface CmsPDFDocumentComponent extends CmsComponent {
    pdfFile?: CmsBannerComponentMedia;
    title?: string;
    height?: number;
}
interface CmsVideoComponent extends CmsComponent {
    overlayTitle?: string;
    autoPlay?: string;
    loop?: string;
    mute?: string;
    containerSize?: ContainerSizeOptions;
    containerBackground?: ContainerBackgroundOptions;
    thumbnailSelector?: ContainerBackgroundOptions;
    videoContainerHeight?: number;
    video?: CmsBannerComponentMedia;
    container?: boolean;
    videoMedia?: CmsBannerComponentMedia | CmsResponsiveBannerComponentMedia;
    thumbnail?: CmsBannerComponentMedia | CmsResponsiveBannerComponentMedia;
    url?: string;
    category?: string;
    product?: string;
    contentPage?: string;
}
declare enum ContainerBackgroundOptions {
    NO_BACKGROUND = "NO_BACKGROUND",
    UPLOAD_RESPONSIVE_IMAGE = "UPLOAD_RESPONSIVE_IMAGE",
    UPLOAD_THUMBNAIL = "UPLOAD_THUMBNAIL"
}
declare enum ContainerSizeOptions {
    FIT_TO_CONTENT_SIZE = "FIT_TO_CONTENT_SIZE",
    DEFINE_CONTAINER_HEIGHT = "DEFINE_CONTAINER_HEIGHT"
}
interface CmsPickupItemDetails extends CmsComponent {
    showEdit: boolean;
    context: string;
}

interface ContentSlotComponentData {
    uid?: string;
    typeCode?: string;
    flexType?: string;
    properties?: any;
}

interface ContentSlotData {
    components?: ContentSlotComponentData[];
    properties?: any;
}

interface Page {
    pageId?: string;
    name?: string;
    description?: string;
    type?: string;
    title?: string;
    template?: string;
    loadTime?: number;
    slots?: {
        [key: string]: ContentSlotData;
    };
    properties?: any;
    label?: string;
    /**
     * Lists the page robot information for the given page: `INDEX`, `NOINDEX`, `FOLLOW` or `NOFOLLOW`
     */
    robots?: PageRobotsMeta[];
}
/**
 * Represents the cms structure for pages, slots and components.
 */
interface CmsStructureModel {
    page?: Page;
    components?: CmsComponent[];
}
/**
 * Represents the page meta data that can be used
 * to resolve page data and seo related data.
 */
interface PageMeta {
    /**
     * the page title is used for the page title tag which
     * is visible in the browser navigation as well as in the
     * Search Engine Result Page
     */
    title?: string;
    /**
     * The page heading is typically used in the UI.
     */
    heading?: string;
    /**
     * The page description is used in the Search Engine Result Page.
     */
    description?: string;
    /**
     * The robots information drives search engines to index the page and
     * follow links in the page.
     */
    robots?: PageRobotsMeta[];
    /**
     * Image that can be added to the og:image metatag.
     */
    image?: string;
    /**
     * The list of breadcrumbs that can be rendered in the page UI.
     */
    breadcrumbs?: BreadcrumbMeta[];
    /**
     * The canonical URL us used to avoid duplicates of the page being indexed by crawlers.
     */
    canonicalUrl?: string;
}
interface BreadcrumbMeta {
    label: string;
    link?: string | any[];
}
declare enum PageRobotsMeta {
    INDEX = "INDEX",
    NOINDEX = "NOINDEX",
    FOLLOW = "FOLLOW",
    NOFOLLOW = "NOFOLLOW"
}

/**
 * Utility service for managing dynamic imports of Angular services
 */
declare class LazyModulesService implements OnDestroy {
    protected compiler: Compiler;
    protected injector: Injector;
    protected events: EventService;
    protected logger: LoggerService;
    /**
     * Expose lazy loaded module references
     */
    readonly modules$: Observable<NgModuleRef<any>>;
    private readonly dependencyModules;
    private readonly eventSubscription;
    constructor(compiler: Compiler, injector: Injector, events: EventService);
    /**
     * Resolves module instance based dynamic import wrapped in an arrow function
     *
     * New module instance will be created with each call.
     *
     * @param moduleFunc
     * @param feature
     */
    resolveModuleInstance(moduleFunc: () => Promise<any>, feature?: string, dependencyModuleRefs?: NgModuleRef<any>[]): Observable<NgModuleRef<any>>;
    /**
     * Returns dependency module instance and initializes it when needed.
     *
     * Module will be instantiated only once, at first request for a this specific module class
     */
    resolveDependencyModuleInstance(moduleFunc: () => Promise<any>): Observable<NgModuleRef<any>>;
    /**
     * The purpose of this function is to run MODULE_INITIALIZER logic that can be provided
     * by a lazy loaded module.  The module is recieved as a function parameter.
     * This function returns an Observable to the module reference passed as an argument.
     *
     * @param {NgModuleRef<any>} moduleRef
     *
     * @returns {Observable<NgModuleRef<any>>}
     */
    runModuleInitializersForModule(moduleRef: NgModuleRef<any>): Observable<NgModuleRef<any>>;
    /**
     * This function accepts an array of functions and runs them all. For each function that returns a promise,
     * the resulting promise is stored in an array of promises.  That array of promises is returned.
     * It is not required for the functions to return a Promise.  All functions are run.  The return values
     * that are not a Promise are simply not stored and returned.
     *
     * @param {(() => any)[]} initFunctions An array of functions too be run.
     *
     * @return {Promise<any>[]} An array of Promise returned by the functions, if any,
     */
    runModuleInitializerFunctions(initFunctions: (() => any)[]): Promise<any>[];
    /**
     * Determine if the argument is shaped like a Promise
     */
    private isObjectPromise;
    /**
     * Resolve any Angular module from an function that return module or moduleFactory
     */
    private resolveModuleFactory;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LazyModulesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LazyModulesService>;
}

/**
 * UnifiedInjector provides a way to get instances of tokens not only once, from the root injector,
 * but also from lazy loaded module injectors that can be initialized over time.
 */
declare class UnifiedInjector {
    protected rootInjector: Injector;
    protected lazyModules: LazyModulesService;
    /**
     * Gather all the injectors, with the root injector as a first one
     *
     */
    readonly injectors$: Observable<Injector>;
    constructor(rootInjector: Injector, lazyModules: LazyModulesService);
    /**
     * Gen instances for specified tokens.
     *
     * When notFoundValue is provided, it will consistently emit once per injector,
     * even if injector doesn't contain instances for specified token.
     * Otherwise, emissions will only involve cases, where new instances will be found.
     *
     * @param token
     * @param notFoundValue
     */
    get<T>(token: Type<T> | InjectionToken<T> | AbstractType<T>, notFoundValue?: T): Observable<T>;
    /**
     * Get multi provided instances for a specified token
     *
     * @param token
     */
    getMulti<T>(token: Type<T> | InjectionToken<T> | AbstractType<T>): Observable<T[]>;
    getMulti<T>(token: any): Observable<T>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnifiedInjector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnifiedInjector>;
}

/**
 * Converter is used to convert source data model to target data model.
 * By convention, we distinguish two flows:
 *   - *Normalize* is the conversion from backend models to UI models
 *   - *Serialize* is the conversion of UI models to backend models (in case of submitting data to the backend).
 *
 * Converters can be stacked together to to apply decoupled customizations
 */
interface Converter<SOURCE, TARGET> {
    /**
     * Convert converts source model to target model. Can use optional target parameter,
     * used in case of stacking multiple converters (for example, to implement populator pattern).
     *
     * @param source Source data model
     * @param target Optional, partially converted target model
     */
    convert(source: SOURCE, target?: TARGET): TARGET;
}
declare class ConverterService implements OnDestroy {
    protected unifiedInjector: UnifiedInjector;
    protected subscriptions: Subscription;
    constructor(unifiedInjector: UnifiedInjector);
    private converters;
    private getConverters;
    /**
     * Will return true if converters for specified token were provided
     */
    hasConverters<S, T>(injectionToken: InjectionToken<Converter<S, T>>): boolean;
    /**
     * Pipeable operator to apply converter logic in a observable stream
     */
    pipeable<S, T>(injectionToken: InjectionToken<Converter<S, T>>): OperatorFunction<S, T>;
    /**
     * Pipeable operator to apply converter logic in a observable stream to collection of items
     */
    pipeableMany<S, T>(injectionToken: InjectionToken<Converter<S, T>>): OperatorFunction<S[], T[]>;
    /**
     * Apply converter logic specified by injection token to source data
     */
    convert<S, T>(source: S, injectionToken: InjectionToken<Converter<S, T>>): T;
    /**
     * Apply converter logic specified by injection token to a collection
     */
    convertMany<S, T>(sources: S[], injectionToken: InjectionToken<Converter<S, T>>): T[];
    private convertSource;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConverterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConverterService>;
}

declare namespace Occ {
    /**
     *
     * An interface representing Country.
     */
    interface Country {
        isocode?: string;
        name?: string;
    }
    /**
     *
     * An interface representing Region.
     */
    interface Region {
        countryIso?: string;
        isocode?: string;
        isocodeShort?: string;
        name?: string;
    }
    /**
     *
     * An interface representing RegionList.
     */
    interface RegionList {
        regions?: Region[];
    }
    interface AddressList {
        addresses?: Address[];
    }
    /**
     *
     * An interface representing Address.
     */
    interface Address {
        companyName?: string;
        country?: Country;
        defaultAddress?: boolean;
        email?: string;
        firstName?: string;
        formattedAddress?: string;
        id?: string;
        lastName?: string;
        line1?: string;
        line2?: string;
        phone?: string;
        cellphone?: string;
        postalCode?: string;
        region?: Region;
        district?: string;
        shippingAddress?: boolean;
        title?: string;
        titleCode?: string;
        town?: string;
        visibleInAddressBook?: boolean;
    }
    /**
     *
     * An interface representing AddressList.
     */
    interface AddressList {
        addresses?: Address[];
    }
    /**
     *
     * An interface representing ErrorModel.
     * Error message
     *
     */
    interface ErrorModel {
        /**
         * Descriptive, human readable error message.
         */
        message?: string;
        /**
         * Additional classification specific for each
         * error type e.g. 'noStock'.
         */
        reason?: string;
        /**
         * Identifier of the related object e.g. '1'.
         */
        subject?: string;
        /**
         * Type of the object related to the error
         * e.g. 'entry'.
         */
        subjectType?: string;
        /**
         * Type of the error e.g. 'LowStockError'.
         */
        type?: string;
    }
    /**
     *
     * An interface representing ErrorList.
     * List of errors
     *
     */
    interface ErrorList {
        errors?: ErrorModel[];
    }
    /**
     *
     * An interface representing AddressValidation.
     */
    interface AddressValidation {
        decision?: string;
        errors?: ErrorList;
        suggestedAddresses?: Address[];
    }
    /**
     *
     * An interface representing Price.
     */
    interface Price {
        currencyIso?: string;
        formattedValue?: string;
        maxQuantity?: number;
        minQuantity?: number;
        /**
         * Possible values include: 'BUY', 'FROM'
         */
        priceType?: PriceType;
        value?: number;
    }
    /**
     *
     * An interface representing Stock.
     */
    interface Stock {
        stockLevel?: number;
        stockLevelStatus?: string;
    }
    /**
     *
     * An interface representing Image.
     */
    interface Image {
        altText?: string;
        format?: string;
        galleryIndex?: number;
        /**
         * Possible values include: 'PRIMARY',
         * 'GALLERY'
         */
        imageType?: ImageType;
        url?: string;
    }
    /**
     *
     * An interface representing VariantOptionQualifier.
     */
    interface VariantOptionQualifier {
        image?: Image;
        name?: string;
        qualifier?: string;
        value?: string;
    }
    /**
     *
     * An interface representing VariantOption.
     */
    interface VariantOption {
        code?: string;
        priceData?: Price;
        stock?: Stock;
        url?: string;
        variantOptionQualifiers?: VariantOptionQualifier[];
    }
    /**
     *
     * An interface representing BaseOption.
     */
    interface BaseOption {
        options?: VariantOption[];
        selected?: VariantOption;
        variantType?: string;
    }
    /**
     *
     * An interface representing SearchQuery.
     */
    interface SearchQuery {
        value?: string;
    }
    /**
     *
     * An interface representing SearchState.
     */
    interface SearchState {
        query?: SearchQuery;
        url?: string;
    }
    /**
     *
     * An interface representing Breadcrumb.
     */
    interface Breadcrumb {
        facetCode?: string;
        facetName?: string;
        facetValueCode?: string;
        facetValueName?: string;
        removeQuery?: SearchState;
        truncateQuery?: SearchState;
    }
    /**
     *
     * An interface representing Component.
     */
    interface Component {
        modifiedTime?: Date;
        name?: string;
        otherProperties?: any;
        typeCode?: string;
        uid?: string;
    }
    /**
     *
     * An interface representing ComponentList.
     */
    interface ComponentList {
        component?: Component[] | any[];
    }
    /**
     *
     * An interface representing ContentSlot.
     */
    interface ContentSlot {
        components?: ComponentList;
        name?: string;
        position?: string;
        slotId?: string;
        slotShared?: boolean;
        slotStatus?: string;
        properties?: any;
    }
    /**
     *
     * An interface representing ContentSlotList.
     */
    interface ContentSlotList {
        contentSlot?: ContentSlot[];
    }
    /**
     *
     * An interface representing CMSPage.
     */
    interface CMSPage {
        contentSlots?: ContentSlotList;
        defaultPage?: boolean;
        name?: string;
        template?: string;
        title?: string;
        description?: string;
        typeCode?: string;
        uid?: string;
        label?: string;
        properties?: any;
        robotTag?: PageRobots;
    }
    /**
     * The page robot information is exposed with 4 string values.
     */
    enum PageRobots {
        INDEX_FOLLOW = "INDEX_FOLLOW",
        NOINDEX_FOLLOW = "NOINDEX_FOLLOW",
        INDEX_NOFOLLOW = "INDEX_NOFOLLOW",
        NOINDEX_NOFOLLOW = "NOINDEX_NOFOLLOW"
    }
    /**
     *
     * An interface representing CardType.
     */
    interface CardType {
        code?: string;
        name?: string;
    }
    /**
     *
     * An interface representing CardTypeList.
     */
    interface CardTypeList {
        cardTypes?: CardType[];
    }
    /**
     *
     * An interface representing PaymentType.
     */
    interface PaymentType {
        code?: string;
        displayName?: string;
    }
    /**
     *
     * An interface representing PaymentTypeList.
     */
    interface PaymentTypeList {
        paymentTypes?: PaymentType[];
    }
    /**
     *
     * An interface representing PromotionOrderEntryConsumed.
     */
    interface PromotionOrderEntryConsumed {
        adjustedUnitPrice?: number;
        code?: string;
        orderEntryNumber?: number;
        quantity?: number;
    }
    /**
     *
     * An interface representing PromotionRestriction.
     */
    interface PromotionRestriction {
        description?: string;
        restrictionType?: string;
    }
    /**
     *
     * An interface representing Promotion.
     */
    interface Promotion {
        code?: string;
        couldFireMessages?: string[];
        description?: string;
        enabled?: boolean;
        endDate?: Date;
        firedMessages?: string[];
        priority?: number;
        productBanner?: Image;
        promotionGroup?: string;
        promotionType?: string;
        restrictions?: PromotionRestriction[];
        startDate?: Date;
        title?: string;
    }
    /**
     *
     * An interface representing PromotionResult.
     */
    interface PromotionResult {
        consumedEntries?: PromotionOrderEntryConsumed[];
        description?: string;
        promotion?: Promotion;
    }
    /**
     *
     * An interface representing Currency.
     */
    interface Currency {
        active?: boolean;
        isocode?: string;
        name?: string;
        symbol?: string;
    }
    /**
     *
     * An interface representing Voucher.
     */
    interface Voucher {
        appliedValue?: Price;
        code?: string;
        currency?: Currency;
        description?: string;
        freeShipping?: boolean;
        name?: string;
        value?: number;
        valueFormatted?: string;
        valueString?: string;
        voucherCode?: string;
    }
    /**
     *
     * An interface representing DeliveryMode.
     */
    interface DeliveryMode {
        code?: string;
        deliveryCost?: Price;
        description?: string;
        name?: string;
    }
    /**
     *
     * An interface representing GeoPoint.
     */
    interface GeoPoint {
        latitude?: number;
        longitude?: number;
    }
    /**
     *
     * An interface representing Time.
     */
    interface Time {
        formattedHour?: string;
        hour?: number;
        minute?: number;
    }
    /**
     *
     * An interface representing SpecialOpeningDay.
     */
    interface SpecialOpeningDay {
        closed?: boolean;
        closingTime?: Time;
        comment?: string;
        date?: Date;
        formattedDate?: string;
        name?: string;
        openingTime?: Time;
    }
    /**
     *
     * An interface representing WeekdayOpeningDay.
     */
    interface WeekdayOpeningDay {
        closed?: boolean;
        closingTime?: Time;
        openingTime?: Time;
        weekDay?: string;
    }
    /**
     *
     * An interface representing OpeningSchedule.
     */
    interface OpeningSchedule {
        code?: string;
        name?: string;
        specialDayOpeningList?: SpecialOpeningDay[];
        weekDayOpeningList?: WeekdayOpeningDay[];
    }
    /**
     *
     * An interface representing PointOfService.
     */
    interface PointOfService {
        address?: Address;
        description?: string;
        displayName?: string;
        distanceKm?: number;
        features?: {
            [propertyName: string]: string;
        };
        formattedDistance?: string;
        geoPoint?: GeoPoint;
        mapIcon?: Image;
        name?: string;
        openingHours?: OpeningSchedule;
        storeContent?: string;
        storeImages?: Image[];
        url?: string;
    }
    /**
     *
     * An interface representing Category.
     */
    interface Category {
        code?: string;
        name?: string;
        image?: Image;
        url?: string;
    }
    /**
     *
     * An interface representing FeatureUnit.
     */
    interface FeatureUnit {
        name?: string;
        symbol?: string;
        unitType?: string;
    }
    /**
     *
     * An interface representing FeatureValue.
     */
    interface FeatureValue {
        value?: string;
    }
    /**
     *
     * An interface representing Feature.
     */
    interface Feature {
        code?: string;
        comparable?: boolean;
        description?: string;
        featureUnit?: FeatureUnit;
        featureValues?: FeatureValue[];
        name?: string;
        range?: boolean;
        type?: string;
    }
    /**
     *
     * An interface representing Classification.
     */
    interface Classification {
        code?: string;
        features?: Feature[];
        name?: string;
    }
    /**
     *
     * An interface representing FutureStock.
     */
    interface FutureStock {
        date?: Date;
        formattedDate?: string;
        stock?: Stock;
    }
    /**
     *
     * An interface representing PriceRange.
     */
    interface PriceRange {
        maxPrice?: Price;
        minPrice?: Price;
    }
    /**
     *
     * An interface representing ProductReference.
     */
    interface ProductReference {
        description?: string;
        preselected?: boolean;
        quantity?: number;
        referenceType?: string;
        target?: Product;
    }
    /**
     *
     * An interface representing Language.
     */
    interface Language {
        active?: boolean;
        isocode?: string;
        name?: string;
        nativeName?: string;
    }
    /**
     *
     * An interface representing User.
     */
    interface User {
        currency?: Currency;
        customerId?: string;
        deactivationDate?: Date;
        defaultAddress?: Address;
        displayUid?: string;
        firstName?: string;
        language?: Language;
        lastName?: string;
        name?: string;
        title?: string;
        titleCode?: string;
        uid?: string;
    }
    /**
     *
     * An interface representing Review.
     */
    interface Review {
        alias?: string;
        comment?: string;
        date?: Date;
        headline?: string;
        id?: string;
        principal?: User;
        rating?: number;
    }
    /**
     *
     * An interface representing VariantCategory.
     */
    interface VariantCategory {
        hasImage?: boolean;
        name?: string;
        priority?: number;
    }
    /**
     *
     * An interface representing VariantValueCategory.
     */
    interface VariantValueCategory {
        name?: string;
        sequence?: number;
        superCategories?: VariantCategory[];
    }
    /**
     *
     * An interface representing VariantMatrixElement.
     */
    interface VariantMatrixElement {
        elements?: VariantMatrixElement[];
        isLeaf?: boolean;
        parentVariantCategory?: VariantCategory;
        variantOption?: VariantOption;
        variantValueCategory?: VariantValueCategory;
    }
    /**
     *
     * An interface representing Product.
     */
    interface Product {
        availableForPickup?: boolean;
        averageRating?: number;
        baseOptions?: BaseOption[];
        baseProduct?: string;
        categories?: Category[];
        classifications?: Classification[];
        code?: string;
        description?: string;
        futureStocks?: FutureStock[];
        images?: Image[];
        manufacturer?: string;
        multidimensional?: boolean;
        name?: string;
        numberOfReviews?: number;
        potentialPromotions?: Promotion[];
        price?: Price;
        priceRange?: PriceRange;
        productReferences?: ProductReference[];
        purchasable?: boolean;
        reviews?: Review[];
        stock?: Stock;
        summary?: string;
        url?: string;
        variantMatrix?: VariantMatrixElement[];
        variantOptions?: VariantOption[];
        variantType?: string;
        volumePrices?: Price[];
        volumePricesFlag?: boolean;
    }
    /**
     *
     * An interface representing OrderEntry.
     */
    interface OrderEntry {
        basePrice?: Price;
        deliveryMode?: DeliveryMode;
        deliveryPointOfService?: PointOfService;
        entryNumber?: number;
        product?: Product;
        quantity?: number;
        totalPrice?: Price;
        updateable?: boolean;
        statusSummaryList?: StatusSummary[];
        configurationInfos?: ConfigurationInfo[];
    }
    /**
     *
     * An interface representing ConfigurationInfo.
     * Provides information about configuration values of the entry.
     */
    interface ConfigurationInfo {
        configurationLabel?: string;
        configurationValue?: string;
        configuratorType?: string;
        status?: string;
    }
    /**
     * Possible order entry statuses
     */
    enum OrderEntryStatus {
        Success = "SUCCESS",
        Info = "INFO",
        Warning = "WARNING",
        Error = "ERROR"
    }
    /**
     *
     * An interface representing StatusSummary.
     * Provides status including number of issues for configurable entry.
     */
    interface StatusSummary {
        numberOfIssues?: number;
        status?: OrderEntryStatus;
    }
    /**
     *
     * An interface representing DeliveryOrderEntryGroup.
     */
    interface DeliveryOrderEntryGroup {
        deliveryAddress?: Address;
        entries?: OrderEntry[];
        quantity?: number;
        totalPriceWithTax?: Price;
    }
    /**
     *
     * An interface representing PaymentDetails.
     */
    interface PaymentDetails {
        accountHolderName?: string;
        billingAddress?: Address;
        cardNumber?: string;
        cardType?: CardType;
        cvn?: string;
        defaultPayment?: boolean;
        expiryMonth?: string;
        expiryYear?: string;
        id?: string;
        issueNumber?: string;
        saved?: boolean;
        startMonth?: string;
        startYear?: string;
        subscriptionId?: string;
    }
    /**
     *
     * An interface representing PickupOrderEntryGroup.
     */
    interface PickupOrderEntryGroup {
        deliveryPointOfService?: PointOfService;
        distance?: number;
        entries?: OrderEntry[];
        quantity?: number;
        totalPriceWithTax?: Price;
    }
    /**
     *
     * An interface representing Principal.
     */
    interface Principal {
        name?: string;
        uid?: string;
    }
    /**
     *
     * An interface representing Cart.
     */
    interface Cart {
        appliedOrderPromotions?: PromotionResult[];
        appliedProductPromotions?: PromotionResult[];
        appliedVouchers?: Voucher[];
        calculated?: boolean;
        code?: string;
        deliveryAddress?: Address;
        deliveryCost?: Price;
        deliveryItemsQuantity?: number;
        deliveryMode?: DeliveryMode;
        deliveryOrderGroups?: DeliveryOrderEntryGroup[];
        description?: string;
        entries?: OrderEntry[];
        expirationTime?: Date;
        guid?: string;
        name?: string;
        net?: boolean;
        orderDiscounts?: Price;
        paymentInfo?: PaymentDetails;
        pickupItemsQuantity?: number;
        pickupOrderGroups?: PickupOrderEntryGroup[];
        potentialOrderPromotions?: PromotionResult[];
        potentialProductPromotions?: PromotionResult[];
        productDiscounts?: Price;
        saveTime?: Date;
        savedBy?: Principal;
        site?: string;
        store?: string;
        subTotal?: Price;
        totalDiscounts?: Price;
        totalItems?: number;
        totalPrice?: Price;
        totalPriceWithTax?: Price;
        totalTax?: Price;
        totalUnitCount?: number;
        user?: Principal;
        sapQuote?: SapQuote;
    }
    /**
     *
     * An interface representing the quote the cart is liked to.
     */
    interface SapQuote {
        code: string;
        sapPurchaseOrderNumber: string;
    }
    /**
     *
     * An interface representing CartList.
     */
    interface CartList {
        carts?: Cart[];
    }
    /**
     *
     * An interface representing CartModification.
     */
    interface CartModification {
        deliveryModeChanged?: boolean;
        entry?: OrderEntry;
        quantity?: number;
        quantityAdded?: number;
        statusCode?: string;
        statusMessage?: string;
    }
    /**
     *
     * An interface representing CategoryHierarchy.
     */
    interface CategoryHierarchy {
        id?: string;
        lastModified?: Date;
        name?: string;
        subcategories?: CategoryHierarchy[];
        url?: string;
    }
    /**
     *
     * An interface representing CatalogVersion.
     */
    interface CatalogVersion {
        categories?: CategoryHierarchy[];
        id?: string;
        lastModified?: Date;
        name?: string;
        url?: string;
    }
    /**
     *
     * An interface representing Catalog.
     */
    interface Catalog {
        catalogVersions?: CatalogVersion[];
        id?: string;
        lastModified?: Date;
        name?: string;
        url?: string;
    }
    /**
     *
     * An interface representing CatalogList.
     */
    interface CatalogList {
        catalogs?: Catalog[];
    }
    /**
     *
     * An interface representing ComponentIDList.
     */
    interface ComponentIDList {
        idList?: string[];
    }
    /**
     *
     * An interface representing ConsignmentEntry.
     */
    interface ConsignmentEntry {
        orderEntry?: OrderEntry;
        quantity?: number;
        shippedQuantity?: number;
    }
    /**
     *
     * An interface representing Consignment.
     */
    interface Consignment {
        code?: string;
        deliveryPointOfService?: PointOfService;
        entries?: ConsignmentEntry[];
        shippingAddress?: Address;
        status?: string;
        statusDate?: Date;
        trackingID?: string;
    }
    /**
     *
     * An interface representing CountryList.
     */
    interface CountryList {
        countries?: Country[];
    }
    /**
     *
     * An interface representing CurrencyList.
     */
    interface CurrencyList {
        currencies?: Currency[];
    }
    /**
     * An interface representing CustomerCoupon
     */
    interface CustomerCoupon {
        couponId?: string;
        name?: string;
        startDate?: string;
        endDate?: string;
        status?: string;
        description?: string;
        notificationOn?: boolean;
        allProductsApplicable?: boolean;
    }
    /**
     * An interface representing CustomerCouponSearchResult
     */
    interface CustomerCouponSearchResult {
        coupons?: CustomerCoupon[];
        sorts?: Sort[];
        pagination?: Pagination;
    }
    /**
     *
     * An interface representing DeliveryModeList.
     */
    interface DeliveryModeList {
        deliveryModes?: DeliveryMode[];
    }
    /**
     *
     * An interface representing FacetValue.
     */
    interface FacetValue {
        count?: number;
        name?: string;
        query?: SearchState;
        selected?: boolean;
    }
    /**
     *
     * An interface representing Facet.
     */
    interface Facet {
        category?: boolean;
        multiSelect?: boolean;
        name?: string;
        priority?: number;
        topValues?: FacetValue[];
        values?: FacetValue[];
        visible?: boolean;
    }
    /**
     *
     * An interface representing LanguageList.
     */
    interface LanguageList {
        languages?: Language[];
    }
    /**
     *
     * An interface representing Pagination.
     * Pagination info
     *
     */
    interface Pagination {
        /**
         * Number of elements on this page
         */
        count?: number;
        /**
         * Current page number
         */
        page?: number;
        /**
         * Total number of elements
         */
        totalCount?: number;
        /**
         * Total number of pages
         */
        totalPages?: number;
    }
    /**
     *
     * An interface representing Sort.
     * Sort option
     *
     */
    interface Sort {
        asc?: boolean;
        code?: string;
    }
    /**
     *
     * An interface representing ListAdaptedComponents.
     */
    interface ListAdaptedComponents {
        components?: any[];
        pagination?: Pagination;
        sorts?: Sort[];
    }
    /**
     *
     * An interface representing MemberList.
     */
    interface MemberList {
        members?: Principal[];
    }
    /**
     *
     * An interface representing OrderEntryList.
     */
    interface OrderEntryList {
        orderEntries?: OrderEntry[];
    }
    /**
     *
     * An interface representing OrderHistory.
     */
    interface OrderHistory {
        code?: string;
        guid?: string;
        placed?: Date;
        status?: string;
        statusDisplay?: string;
        total?: Price;
    }
    /**
     *
     * An interface representing PaginationModel.
     */
    interface PaginationModel {
        currentPage?: number;
        pageSize?: number;
        sort?: string;
        totalPages?: number;
        totalResults?: number;
    }
    /**
     *
     * An interface representing SortModel.
     */
    interface SortModel {
        code?: string;
        name?: string;
        selected?: boolean;
    }
    /**
     *
     * An interface representing OrderHistoryList.
     */
    interface OrderHistoryList {
        orders?: OrderHistory[];
        pagination?: PaginationModel;
        sorts?: SortModel[];
    }
    /**
     *
     * An interface representing OrderStatusUpdateElement.
     */
    interface OrderStatusUpdateElement {
        baseSiteId?: string;
        code?: string;
        status?: string;
    }
    /**
     *
     * An interface representing OrderStatusUpdateElementList.
     */
    interface OrderStatusUpdateElementList {
        orderStatusUpdateElements?: OrderStatusUpdateElement[];
    }
    /**
     *
     * An interface representing Order.
     */
    interface Order {
        appliedOrderPromotions?: PromotionResult[];
        appliedProductPromotions?: PromotionResult[];
        appliedVouchers?: Voucher[];
        calculated?: boolean;
        code?: string;
        consignments?: Consignment[];
        created?: Date;
        deliveryAddress?: Address;
        deliveryCost?: Price;
        deliveryItemsQuantity?: number;
        deliveryMode?: DeliveryMode;
        deliveryOrderGroups?: DeliveryOrderEntryGroup[];
        deliveryStatus?: string;
        deliveryStatusDisplay?: string;
        entries?: OrderEntry[];
        guestCustomer?: boolean;
        guid?: string;
        net?: boolean;
        orderDiscounts?: Price;
        paymentInfo?: PaymentDetails;
        pickupItemsQuantity?: number;
        pickupOrderGroups?: PickupOrderEntryGroup[];
        productDiscounts?: Price;
        site?: string;
        status?: string;
        statusDisplay?: string;
        store?: string;
        subTotal?: Price;
        totalDiscounts?: Price;
        totalItems?: number;
        totalPrice?: Price;
        totalPriceWithTax?: Price;
        totalTax?: Price;
        unconsignedEntries?: OrderEntry[];
        user?: Principal;
    }
    /**
     *
     * An interface representing ReturnRequest.
     */
    interface ReturnRequest {
        cancellable?: boolean;
        code?: string;
        creationTime?: Date;
        deliveryCost?: Price;
        order?: Order;
        refundDeliveryCost?: boolean;
        returnEntries?: ReturnRequestEntry[];
        returnLabelDownloadUrl?: string;
        rma?: string;
        status?: string;
        subTotal?: Price;
        totalPrice?: Price;
    }
    /**
     *
     * An interface representing ReturnRequestEntry.
     */
    interface ReturnRequestEntry {
        orderEntry?: OrderEntry;
        expectedQuantity?: number;
        refundAmount?: Price;
    }
    /**
     *
     * An interface representing PaymentDetailsList.
     */
    interface PaymentDetailsList {
        payments?: PaymentDetails[];
    }
    /**
     *
     * An interface representing PointOfServiceStock.
     */
    interface PointOfServiceStock {
        address?: Address;
        description?: string;
        displayName?: string;
        distanceKm?: number;
        features?: {
            [propertyName: string]: string;
        };
        formattedDistance?: string;
        geoPoint?: GeoPoint;
        mapIcon?: Image;
        name?: string;
        openingHours?: OpeningSchedule;
        stockInfo?: Stock;
        storeContent?: string;
        storeImages?: Image[];
        url?: string;
    }
    /**
     *
     * An interface representing ProductExpressUpdateElement.
     */
    interface ProductExpressUpdateElement {
        catalogId?: string;
        catalogVersion?: string;
        code?: string;
    }
    /**
     *
     * An interface representing ProductExpressUpdateElementList.
     */
    interface ProductExpressUpdateElementList {
        productExpressUpdateElements?: ProductExpressUpdateElement[];
    }
    /**
     *
     * An interface representing ProductList.
     */
    interface ProductList {
        catalog?: string;
        currentPage?: number;
        products?: Product[];
        totalPageCount?: number;
        totalProductCount?: number;
        version?: string;
    }
    /**
     *
     * An interface representing ProductReferenceList.
     */
    interface ProductReferenceList {
        references?: ProductReference[];
    }
    /**
     *
     * An interface representing SpellingSuggestion.
     */
    interface SpellingSuggestion {
        query?: string;
        suggestion?: string;
    }
    /**
     *
     * An interface representing ProductSearchPage.
     */
    interface ProductSearchPage {
        breadcrumbs?: Breadcrumb[];
        categoryCode?: string;
        currentQuery?: SearchState;
        facets?: Facet[];
        freeTextSearch?: string;
        keywordRedirectUrl?: string;
        pagination?: PaginationModel;
        products?: Product[];
        sorts?: SortModel[];
        spellingSuggestion?: SpellingSuggestion;
    }
    /**
     *
     * An interface representing PromotionList.
     */
    interface PromotionList {
        promotions?: Promotion[];
    }
    /**
     *
     * An interface representing PromotionResultList.
     */
    interface PromotionResultList {
        promotions?: PromotionResult[];
    }
    /**
     *
     * An interface representing ReviewList.
     */
    interface ReviewList {
        reviews?: Review[];
    }
    /**
     *
     * An interface representing SaveCartResult.
     */
    interface SaveCartResult {
        savedCartData?: Cart;
    }
    /**
     *
     * An interface representing StoreFinderSearchPage.
     */
    interface StoreFinderSearchPage {
        boundEastLongitude?: number;
        boundNorthLatitude?: number;
        boundSouthLatitude?: number;
        boundWestLongitude?: number;
        locationText?: string;
        pagination?: PaginationModel;
        sorts?: SortModel[];
        sourceLatitude?: number;
        sourceLongitude?: number;
        stores?: PointOfService[];
    }
    /**
     *
     * An interface representing StoreFinderStockSearchPage.
     */
    interface StoreFinderStockSearchPage {
        boundEastLongitude?: number;
        boundNorthLatitude?: number;
        boundSouthLatitude?: number;
        boundWestLongitude?: number;
        locationText?: string;
        pagination?: PaginationModel;
        product?: Product;
        sorts?: SortModel[];
        sourceLatitude?: number;
        sourceLongitude?: number;
        stores?: PointOfServiceStock[];
    }
    /**
     *
     * An interface representing Suggestion.
     */
    interface Suggestion {
        value?: string;
    }
    /**
     *
     * An interface representing SuggestionList.
     */
    interface SuggestionList {
        suggestions?: Suggestion[];
    }
    /**
     *
     * An interface representing Title.
     */
    interface Title {
        code?: string;
        name?: string;
    }
    /**
     *
     * An interface representing TitleList.
     */
    interface TitleList {
        titles?: Title[];
    }
    /**
     *
     * An interface representing UserGroup.
     */
    interface UserGroup {
        members?: Principal[];
        membersCount?: number;
        name?: string;
        subGroups?: UserGroup[];
        uid?: string;
    }
    interface StoreCount {
        count?: number;
        isoCode?: string;
        name?: string;
        type?: string;
    }
    interface StoreCountList {
        countriesAndRegionsStoreCount?: StoreCount[];
    }
    /**
     *
     * An interface representing VoucherList.
     */
    interface VoucherList {
        vouchers?: Voucher[];
    }
    /**
     * Defines values for PriceType.
     * Possible values include: 'BUY', 'FROM'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: PriceType = <PriceType>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum PriceType {
        BUY = "BUY",
        FROM = "FROM"
    }
    /**
     * Defines values for ImageType.
     * Possible values include: 'PRIMARY', 'GALLERY'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: ImageType = <ImageType>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum ImageType {
        PRIMARY = "PRIMARY",
        GALLERY = "GALLERY"
    }
    /**
     * Defines values for Fields.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields = <Fields>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields1.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields1 = <Fields1>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields1 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields2.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields2 = <Fields2>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields2 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields3.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields3 = <Fields3>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields3 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields4.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields4 = <Fields4>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields4 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields5.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields5 = <Fields5>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields5 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields6.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields6 = <Fields6>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields6 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for PageType.
     * Possible values include: 'ContentPage', 'ProductPage', 'CategoryPage',
     * 'CatalogPage'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: PageType = <PageType>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum PageType {
        CONTENT_PAGE = "ContentPage",
        PRODUCT_PAGE = "ProductPage",
        CATEGORY_PAGE = "CategoryPage",
        CATALOG_PAGE = "CatalogPage"
    }
    /**
     * Defines values for Fields7.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields7 = <Fields7>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields7 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields8.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields8 = <Fields8>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields8 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields9.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields9 = <Fields9>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields9 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields10.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields10 = <Fields10>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields10 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields11.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields11 = <Fields11>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields11 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields12.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields12 = <Fields12>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields12 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields13.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields13 = <Fields13>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields13 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields14.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields14 = <Fields14>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields14 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields15.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields15 = <Fields15>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields15 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields16.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields16 = <Fields16>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields16 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for SortEnum.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: SortEnum = <SortEnum>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum SortEnum {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields17.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields17 = <Fields17>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields17 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields18.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields18 = <Fields18>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields18 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields19.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields19 = <Fields19>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields19 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields20.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields20 = <Fields20>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields20 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields21.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields21 = <Fields21>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields21 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields22.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields22 = <Fields22>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields22 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields23.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields23 = <Fields23>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields23 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields24.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields24 = <Fields24>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields24 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields25.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields25 = <Fields25>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields25 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields26.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields26 = <Fields26>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields26 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields27.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields27 = <Fields27>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields27 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields28.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields28 = <Fields28>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields28 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields29.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields29 = <Fields29>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields29 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields30.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields30 = <Fields30>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields30 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields31.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields31 = <Fields31>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields31 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields32.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields32 = <Fields32>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields32 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields33.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields33 = <Fields33>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields33 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields34.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields34 = <Fields34>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields34 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields35.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields35 = <Fields35>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields35 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields36.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields36 = <Fields36>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields36 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields37.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields37 = <Fields37>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields37 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields38.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields38 = <Fields38>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields38 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields39.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields39 = <Fields39>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields39 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields40.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields40 = <Fields40>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields40 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields41.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields41 = <Fields41>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields41 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields42.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields42 = <Fields42>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields42 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields43.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields43 = <Fields43>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields43 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields44.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields44 = <Fields44>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields44 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields45.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields45 = <Fields45>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields45 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields46.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields46 = <Fields46>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields46 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields47.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields47 = <Fields47>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields47 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields48.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields48 = <Fields48>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields48 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields49.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields49 = <Fields49>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields49 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields50.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields50 = <Fields50>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields50 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields51.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields51 = <Fields51>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields51 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields52.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields52 = <Fields52>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields52 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields53.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields53 = <Fields53>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields53 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields54.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields54 = <Fields54>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields54 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields55.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields55 = <Fields55>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields55 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields56.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields56 = <Fields56>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields56 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields57.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields57 = <Fields57>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields57 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields58.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields58 = <Fields58>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields58 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields59.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields59 = <Fields59>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields59 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields60.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields60 = <Fields60>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields60 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Fields61.
     * Possible values include: 'BASIC', 'DEFAULT', 'FULL'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Fields61 = <Fields61>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Fields61 {
        BASIC = "BASIC",
        DEFAULT = "DEFAULT",
        FULL = "FULL"
    }
    /**
     * Defines values for Type.
     * Possible values include: 'all', 'product', 'order'
     * There could be more values for this enum apart from the ones defined here.If
     * you want to set a value that is not from the known values then you can do
     * the following:
     * let param: Type = <Type>"someUnknownValueThatWillStillBeValid";
     * @readonly
     * @enum {string}
     */
    enum Type {
        All = "all",
        Product = "product",
        Order = "order"
    }
    interface AnonymousConsent {
        templateCode?: string;
        version?: number;
        consentState?: CONSENT_STATUS;
    }
    enum CONSENT_STATUS {
        ANONYMOUS_CONSENT_GIVEN = "GIVEN",
        ANONYMOUS_CONSENT_WITHDRAWN = "WITHDRAWN"
    }
    interface ConsentTemplate {
        id?: string;
        name?: string;
        description?: string;
        version?: number;
        currentConsent?: Consent;
    }
    interface Consent {
        code?: string;
        consentGivenDate?: Date;
        consentWithdrawnDate?: Date;
    }
    interface ConsentTemplateList {
        consentTemplates?: ConsentTemplate[];
    }
    interface BaseSites {
        baseSites?: BaseSite[];
    }
    interface BaseSite {
        channel?: string;
        defaultLanguage?: Language;
        defaultPreviewCatalogId?: string;
        defaultPreviewCategoryCode?: string;
        defaultPreviewProductCode?: string;
        locale?: string;
        name?: string;
        theme?: string;
        uid?: string;
        stores?: BaseStore[];
        urlPatterns?: string[];
        urlEncodingAttributes?: string[];
        requiresAuthentication?: boolean;
    }
    interface BaseStore {
        currencies?: Currency[];
        defaultCurrency?: Currency;
        languages?: Language[];
        defaultLanguage?: Language;
    }
    interface ProductInterestEntry {
        interestType?: NotificationType;
        dateAdded?: string;
        expirationDate?: string;
    }
    interface ProductInterestEntryRelation {
        product?: Product;
        productInterestEntry?: ProductInterestEntry[];
    }
    interface ProductInterestSearchResult {
        results?: ProductInterestEntryRelation[];
        sorts?: Sort[];
        pagination?: Pagination;
    }
    enum NotificationType {
        BACK_IN_STOCK = "BACK_IN_STOCK"
    }
    interface Budget {
        active?: boolean;
        budget?: number;
        code?: string;
        currency?: Currency;
        endDate?: string;
        startDate?: string;
        name?: string;
        orgUnit?: B2BUnit;
        costCenters?: CostCenter[];
    }
    interface BudgetsList {
        budgets?: Budget[];
        pagination?: PaginationModel;
        sorts?: SortModel[];
    }
    interface CostCenter {
        active?: string;
        activeFlag?: boolean;
        code?: string;
        currency?: Currency;
        name?: string;
        originalCode?: string;
        unit?: B2BUnit;
    }
    interface CostCentersList {
        costCenters: CostCenter[];
        pagination?: PaginationModel;
        sorts?: SortModel[];
    }
    interface OrgUnitUserGroup {
        members?: B2BUser[];
        membersCoun?: number;
        name?: string;
        orgUnit?: B2BUnit;
        permissions?: Permission[];
        roles?: any;
        selected?: boolean;
        subGroups?: any;
        uid?: string;
    }
    interface OrgUnitUserGroupList {
        orgUnitUserGroups: OrgUnitUserGroup[];
        pagination?: PaginationModel;
        sorts?: SortModel[];
    }
    interface B2BUnitNode {
        active?: boolean;
        children?: B2BUnitNode[];
        id?: string;
        name?: string;
        parent?: string;
    }
    interface B2BUnitNodeList {
        unitNodes?: B2BUnitNode[];
    }
    interface B2BUser extends User {
        active?: boolean;
        approvers?: [];
        orgUnit?: B2BUnit;
        roles?: string[];
        selected?: boolean;
    }
    interface OrgUnitUserList {
        users: B2BUser[];
        pagination?: PaginationModel;
        sorts?: SortModel[];
    }
    interface B2BApprovalProcess {
        code?: string;
        name?: string;
    }
    interface B2BApprovalProcessList {
        approvalProcesses?: B2BApprovalProcess[];
    }
    interface B2BUnit {
        active?: boolean;
        addresses?: Address[];
        uid?: string;
        name?: string;
        parentOrgUnit?: Partial<B2BUnit>;
        approvalProcess?: B2BApprovalProcess;
        administrators?: B2BUser[];
        approvers?: B2BUser[];
        customers?: B2BUser[];
        managers?: B2BUser[];
    }
    interface OrderApprovalPermissionType {
        code?: string;
        name?: string;
    }
    interface OrderApprovalPermissionTypeList {
        orderApprovalPermissionTypes?: OrderApprovalPermissionType[];
    }
    enum Period {
        DAY = "DAY",
        WEEK = "WEEK",
        MONTH = "MONTH",
        QUARTER = "QUARTER",
        YEAR = "YEAR"
    }
    interface Permission {
        active?: boolean;
        code?: string;
        currency?: Currency;
        orderApprovalPermissionType?: OrderApprovalPermissionType;
        orgUnit?: B2BUnitNode;
        periodRange?: Period;
        selected?: boolean;
        treshold?: number;
    }
    interface PermissionsList {
        orderApprovalPermissions?: Permission[];
        pagination?: PaginationModel;
        sorts?: SortModel[];
    }
    interface ReplenishmentOrder {
        active?: boolean;
        appliedOrderPromotions?: PromotionResult[];
        appliedProductPromotions?: PromotionResult[];
        appliedVouchers?: Voucher[];
        calculated?: boolean;
        code?: string;
        costCenter?: CostCenter;
        deliveryAddress?: Address;
        deliveryCost?: Price;
        deliveryItemsQuantity?: number;
        deliveryMode?: DeliveryMode;
        deliveryOrderGroups?: DeliveryOrderEntryGroup[];
        description?: string;
        entries?: OrderEntry[];
        expirationTime?: string;
        firstDate?: string;
        guid?: string;
        name?: string;
        net?: boolean;
        orderDiscounts?: Price;
        paymentInfo?: PaymentDetails;
        paymentStatus?: string;
        paymentType?: PaymentType;
        pickupItemsQuantity?: number;
        pickupOrderGroups?: PickupOrderEntryGroup[];
        potentialOrderPromotions?: PromotionResult[];
        potentialProductPromotions?: PromotionResult[];
        productDiscounts?: Price;
        purchaseOrderNumber?: string;
        replenishmentOrderCode?: string;
        saveTime?: string;
        savedBy?: Principal;
        site?: string;
        store?: string;
        subTotal?: Price;
        totalDiscounts?: Price;
        totalItems?: number;
        totalPrice?: Price;
        totalPriceWithTax?: Price;
        totalTax?: Price;
        totalUnitCount?: number;
        trigger?: Trigger;
        user?: Principal;
    }
    interface ReplenishmentOrderList {
        replenishmentOrders?: ReplenishmentOrder[];
        pagination?: PaginationModel;
        sorts?: SortModel[];
    }
    interface Trigger {
        activationTime?: string;
        displayTimeTable?: string;
    }
    interface ScheduleReplenishmentForm {
        daysOfWeek?: DaysOfWeek[];
        nthDayOfMonth?: string;
        numberOfDays?: string;
        numberOfWeeks?: string;
        recurrencePeriod?: string;
        replenishmentStartDate?: string;
    }
    enum DaysOfWeek {
        MONDAY = "MONDAY",
        TUESDAY = "TUESDAY",
        WEDNESDAY = "WEDNESDAY",
        THURSDAY = "THURSDAY",
        FRIDAY = "FRIDAY",
        SATURDAY = "SATURDAY",
        SUNDAY = "SUNDAY"
    }
    enum OrderApprovalDecisionValue {
        APPROVE = "APPROVE",
        REJECT = "REJECT"
    }
    interface OrderApprovalDecision {
        decision?: OrderApprovalDecisionValue;
        comment?: string;
    }
    interface OrderApprovalRecord {
        approver?: Principal;
        comments?: string;
        permissionTypes?: OrderApprovalPermissionType[];
        statusDisplay?: string;
    }
    interface OrderApproval {
        approvalDecisionRequired?: boolean;
        code?: string;
        customerOrderApprovalRecords?: OrderApprovalRecord[];
        merchantOrderApprovalRecords?: OrderApprovalRecord[];
        order?: Order;
        trigger?: Trigger;
    }
    interface OrderApprovalsList {
        orderApprovals?: OrderApproval[];
        pagination?: PaginationModel;
        sorts?: SortModel[];
    }
    interface CartModificationList {
        cartModifications?: CartModification[];
    }
}

declare class OccCmsPageNormalizer implements Converter<Occ.CMSPage, CmsStructureModel> {
    convert(source: Occ.CMSPage, target?: CmsStructureModel): CmsStructureModel;
    /**
     * Converts the OCC cms page model to the `Page` in the `CmsStructureModel`.
     */
    protected normalizePageData(source: Occ.CMSPage, target: CmsStructureModel): void;
    /**
     * Adds a ContentSlotData for each page slot in the `CmsStructureModel`.
     */
    protected normalizePageSlotData(source: Occ.CMSPage, target: CmsStructureModel): void;
    /**
     * Registers the `ContentSlotComponentData` for each component.
     */
    protected normalizePageComponentData(source: Occ.CMSPage, target: CmsStructureModel): void;
    /**
     * Returns component properties if they exist
     */
    protected getComponentProperties(componentProperties: any): any;
    /**
     * Returns the flex type based on the configuration of component properties
     */
    protected getFlexTypeFromComponent(component: Occ.Component | any): string;
    /**
     * Adds the actual component data whenever available in the CMS page data.
     *
     * If the data is not populated in this payload, it is loaded separately
     * (`OccCmsComponentAdapter`).
     */
    protected normalizeComponentData(source: Occ.CMSPage, target: CmsStructureModel): void;
    /**
     * Normalizes the page robot string to an array of `PageRobotsMeta` items.
     */
    protected normalizeRobots(source: Occ.CMSPage, target: Page): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCmsPageNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCmsPageNormalizer>;
}

declare class GlobService {
    /**
     * For given list of glob-like patterns, returns a validator function.
     *
     * The validator returns true for given URL only when ANY of the positive patterns is matched and NONE of the negative ones.
     */
    getValidator(patterns: string[]): (url: string) => boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<GlobService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GlobService>;
}

declare class UrlMatcherService {
    protected globService: GlobService;
    constructor(globService: GlobService);
    /**
     * Returns a matcher that is always fails
     */
    getFalsy(): UrlMatcher;
    /**
     * Returns a matcher for given list of paths
     */
    getFromPaths(paths: string[]): UrlMatcher;
    /**
     * Returns a matcher that combines the given matchers
     * */
    getCombined(matchers: UrlMatcher[]): UrlMatcher;
    /**
     * Similar to Angular's defaultUrlMatcher. Differences:
     * - the `path` comes from function's argument, not from `route.path`
     * - the empty path `''` is handled here, but in Angular is handled one level higher in the match() function
     */
    protected getFromPath(path?: string): UrlMatcher;
    /**
     * Returns URL matcher that accepts almost everything (like `**` route), but not paths accepted by the given matcher
     */
    getOpposite(originalMatcher: UrlMatcher): UrlMatcher;
    /**
     * Returns URL matcher for the given list of glob-like patterns. Each pattern must start with `/` or `!/`.
     */
    getFromGlob(globPatterns: string[]): UrlMatcher;
    static ɵfac: i0.ɵɵFactoryDeclaration<UrlMatcherService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UrlMatcherService>;
}

type UrlMatcherFactory = (route: Route) => UrlMatcher;

/**
 * Injection token with url matcher factory for spartacus routes containing property `data.cxRoute`.
 * The provided url matcher matches the configured `paths` from routing config.
 *
 * If this matcher doesn't fit the requirements, it can be replaced with custom matcher
 * or additional matchers can be added for a specific route. See for example PRODUCT_DETAILS_URL_MATCHER.
 *
 * Note: Matchers will "match" a route, but do not contribute to the creation of the route, nor do they guard routes.
 */
declare const DEFAULT_URL_MATCHER: InjectionToken<UrlMatcherFactory>;

interface RoutesConfig {
    [routeName: string]: RouteConfig;
}
interface RouteConfig {
    /**
     * List of path aliases used to build the semantic links.
     * It's used also to match the URLs, unless the config property `matchers` is given for the same route.
     *
     * See https://angular.io/api/router/Route#path
     */
    paths?: string[];
    /**
     * Array of Angular `UrlMatcher`s and injection tokens of Spartacus `UrlMatcherFactory`.
     * All the url matchers (static and resolved from factories) will be used to match the route.
     * When not given (undefined or null), the configured `paths` will be used to match the the route.
     *
     * See https://angular.io/api/router/Route#matcher
     */
    matchers?: (UrlMatcher | InjectionToken<UrlMatcherFactory>)[];
    /**
     * Maps names of route params with params used to build the semantic link.
     */
    paramsMapping?: ParamsMapping;
    /**
     * Disables the url matcher for the route. But still allows for generation of semantic links.
     */
    disabled?: boolean;
    /**
     * When false, the route is public for unauthorized users even when the global flag `routing.protected` is true.
     * Other values (true, undefined) are ignored.
     */
    protected?: boolean;
    /**
     * When true, the page is considered as part of the user journey related to authorization (for example:
     * login, register, forgot password, logout, etc.)
     *
     * When user is redirected back after successful login, he won't land on any page marked as the auth flow, but on other
     * previously accessed page.
     */
    authFlow?: boolean;
}
interface ParamsMapping {
    [paramName: string]: string;
}

declare enum RouteLoadStrategy {
    /**
     * Don't reload the data on navigation if it was loaded before
     */
    ONCE = "once",
    /**
     * Always reload the data on navigation
     */
    ALWAYS = "always"
}
declare abstract class RoutingConfig {
    routing?: RoutingConfigDefinition;
    static ɵfac: i0.ɵɵFactoryDeclaration<RoutingConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RoutingConfig>;
}
interface RoutingConfigDefinition {
    /**
     * Configuration of semantic routes. Key is route's name. Value is the config specific to this route.
     */
    routes?: RoutesConfig;
    /**
     * When true, it closes the storefront for unauthorized users, except from routes that have individual config flag `protected: false`
     */
    protected?: boolean;
    /**
     * Global load strategy which is used as a fallback for loading data on each navigation
     */
    loadStrategy?: RouteLoadStrategy;
}
declare module './spartacus-core' {
    interface Config extends RoutingConfig {
    }
}

declare class RoutingConfigService {
    protected config: RoutingConfig;
    /**
     * Reversed routing config for quick lookup of the route name by the configured path.
     */
    protected routeNamesByPath: {
        [path: string]: string;
    };
    protected logger: LoggerService;
    constructor(config: RoutingConfig);
    /**
     * Returns the route config for the given route name.
     */
    getRouteConfig(routeName: string): RouteConfig | undefined;
    private warn;
    /**
     * Returns the configured route loading strategy.
     */
    getLoadStrategy(): RouteLoadStrategy;
    /**
     * Returns the route name of the configured path.
     *
     * For example, when the config is:
     * ```
     * routing: {
     *   routes: {
     *      addressBook: { paths: ['my-account/address-book'] }
     *   }
     * }
     * ```
     *
     * the `getRouteName('my-account/address-book')` returns `'addressBook'`.
     */
    getRouteName(path: string): string;
    /**
     * Initializes the property `routeNamesByPath`.
     *
     * The original config allows for reading configured path by the route name.
     * But this method builds up a structure with a 'reversed config'
     * to read quickly the route name by the path.
     */
    protected initRouteNamesByPath(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RoutingConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RoutingConfigService>;
}

declare class ConfigurableRoutesService {
    protected injector: Injector;
    protected routingConfigService: RoutingConfigService;
    protected urlMatcherService: UrlMatcherService;
    protected logger: LoggerService;
    constructor(injector: Injector, routingConfigService: RoutingConfigService, urlMatcherService: UrlMatcherService);
    protected initCalled: boolean;
    /**
     * Enhances existing Angular routes using the routing config of Spartacus.
     * Can be called only once.
     */
    init(): void;
    /**
     * Enhances existing Angular routes using the routing config of Spartacus.
     */
    protected configure(): void;
    /**
     * Sets the property `path` or `matcher` for the given routes, based on the Spartacus' routing configuration.
     *
     * @param routes list of Angular `Route` objects
     */
    protected configureRoutes(routes: Routes): Routes;
    /**
     * Sets the property `path` or `matcher` of the `Route`, based on the Spartacus' routing configuration.
     * Uses the property `data.cxRoute` to determine the name of the route.
     * It's the same name used as a key in the routing configuration: `routing.routes[ROUTE NAME]`.
     *
     * @param route Angular `Route` object
     */
    protected configureRoute(route: Route): Route;
    /**
     * Creates a single `UrlMatcher` based on given matchers and factories of matchers.
     *
     * @param route Route object
     * @param matchersOrFactories `UrlMatcher`s or injection tokens with a factory functions
     *  that create UrlMatchers based on the given route.
     */
    protected resolveUrlMatchers(route: Route, matchersOrFactories: RouteConfig['matchers']): UrlMatcher;
    /**
     * Creates an `UrlMatcher` based on the given route, using the factory function coming from the given injection token.
     *
     * @param route Route object
     * @param factoryToken injection token with a factory function that will create an UrlMatcher using given route
     */
    protected resolveUrlMatcherFactory(route: Route, factoryToken: InjectionToken<UrlMatcherFactory>): UrlMatcher;
    /**
     * Returns the name of the Route stored in its property `data.cxRoute`
     * @param route
     */
    protected getRouteName(route: Route): string;
    protected validateRouteConfig(routeConfig: RouteConfig | null | undefined, routeName: string, route: Route): void;
    private warn;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfigurableRoutesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfigurableRoutesService>;
}

interface ConsentTemplate {
    id?: string;
    name?: string;
    description?: string;
    version?: number;
    currentConsent?: Consent;
}
interface Consent {
    code?: string;
    consentGivenDate?: Date;
    consentWithdrawnDate?: Date;
}
interface AnonymousConsent {
    templateCode?: string;
    templateVersion?: number;
    consentState?: ANONYMOUS_CONSENT_STATUS;
}
declare enum ANONYMOUS_CONSENT_STATUS {
    GIVEN = "GIVEN",
    WITHDRAWN = "WITHDRAWN"
}
declare const ANONYMOUS_CONSENTS_HEADER = "X-Anonymous-Consents";

interface Pagination {
    count?: number;
    page?: number;
    totalCount?: number;
    totalPages?: number;
}
interface Sort {
    asc?: boolean;
    code?: string;
}

interface CustomerCoupon {
    couponId?: string;
    name?: string;
    startDate?: string;
    endDate?: string;
    status?: string;
    description?: string;
    notificationOn?: boolean;
    allProductsApplicable?: boolean;
}
interface CustomerCouponNotification {
    coupon?: CustomerCoupon;
    customer?: User;
    status?: string;
}
interface CustomerCouponSearchResult {
    coupons?: CustomerCoupon[];
    sorts?: Sort[];
    pagination?: Pagination;
}
interface CustomerCoupon2Customer {
    coupon?: CustomerCoupon;
    customer?: User;
}

interface Images {
    [imageType: string]: ImageGroup | ImageGroup[];
}
interface Image {
    altText?: string;
    role?: string;
    format?: string;
    galleryIndex?: number;
    imageType?: ImageType;
    url?: string;
    /**
     * Represents width for an image in the MediaComponent.
     *
     * This property do not originate from the CMS but was added
     * to allow for the manual setting of the width of
     * images displayed by the MediaComponent.
     */
    width?: number;
    /**
     * Represents height for an image in the MediaComponent.
     *
     * This property do not originate from the CMS but was added
     * to allow for the manual setting of the height of
     * images displayed by the MediaComponent.
     */
    height?: number;
}
declare enum ImageType {
    PRIMARY = "PRIMARY",
    GALLERY = "GALLERY"
}
interface ImageGroup {
    [format: string]: Image;
}

interface NotificationPreference {
    channel?: string;
    value?: string;
    enabled?: boolean;
    visible?: boolean;
}
interface NotificationPreferenceList {
    preferences?: NotificationPreference[];
}

interface CostCenter {
    active?: boolean;
    code?: string;
    name?: string;
    unit?: B2BUnit;
}
declare enum B2BUserRole {
    ADMIN = "b2badmingroup",
    CUSTOMER = "b2bcustomergroup",
    MANAGER = "b2bmanagergroup",
    APPROVER = "b2bapprovergroup"
}
declare enum B2BUserRight {
    UNITORDERVIEWER = "unitorderviewergroup"
}
interface B2BUnit {
    active?: boolean;
    addresses?: Address[];
    uid?: string;
    name?: string;
}
interface B2BUser extends User {
    active?: boolean;
    email?: string;
}
interface B2BApprovalProcess {
    code?: string;
    name?: string;
}
interface OrderApprovalPermissionType {
    code?: string;
    name?: string;
}

interface CardType {
    code?: string;
    name?: string;
}
interface PaymentDetails {
    accountHolderName?: string;
    billingAddress?: Address;
    cardNumber?: string;
    cardType?: CardType;
    cvn?: string;
    defaultPayment?: boolean;
    expiryMonth?: string;
    expiryYear?: string;
    id?: string;
    issueNumber?: string;
    saved?: boolean;
    startMonth?: string;
    startYear?: string;
    subscriptionId?: string;
}

interface PointOfService {
    address?: Address;
    description?: string;
    displayName?: string;
    distanceKm?: number;
    features?: {
        [propertyName: string]: string;
    };
    formattedDistance?: string;
    geoPoint?: GeoPoint;
    mapIcon?: Image;
    name?: string;
    openingHours?: OpeningSchedule;
    storeContent?: string;
    storeImages?: Image[];
    url?: string;
}
interface SpecialOpeningDay {
    closed?: boolean;
    closingTime?: Time;
    comment?: string;
    date?: Date;
    formattedDate?: string;
    name?: string;
    openingTime?: Time;
}
interface WeekdayOpeningDay {
    closed?: boolean;
    closingTime?: Time;
    openingTime?: Time;
    weekDay?: string;
}
interface OpeningSchedule {
    code?: string;
    name?: string;
    specialDayOpeningList?: SpecialOpeningDay[];
    weekDayOpeningList?: WeekdayOpeningDay[];
}

interface ProductInterestEntry {
    interestType?: NotificationType;
    dateAdded?: string;
    expirationDate?: string;
}
interface ProductInterestEntryRelation {
    product?: Product;
    productInterestEntry?: ProductInterestEntry[];
}
interface ProductInterestSearchResult {
    results?: ProductInterestEntryRelation[];
    sorts?: Sort[];
    pagination?: Pagination;
}
declare enum NotificationType {
    BACK_IN_STOCK = "BACK_IN_STOCK"
}

interface SearchQuery {
    value?: string;
}
interface SearchState {
    query?: SearchQuery;
    url?: string;
}
interface FacetValue {
    count?: number;
    name?: string;
    query?: SearchState;
    selected?: boolean;
}
interface Breadcrumb {
    facetCode?: string;
    facetName?: string;
    facetValueCode?: string;
    facetValueName?: string;
    removeQuery?: SearchState;
    truncateQuery?: SearchState;
}
interface Facet {
    category?: boolean;
    multiSelect?: boolean;
    name?: string;
    priority?: number;
    values?: FacetValue[];
    visible?: boolean;
    /**
     * Indicates whether the facet group is expanded in the UI. An expanded
     * does not necessarily show all facet value at once, this can be limited
     * by the so-called `topValueCount`.
     */
    expanded?: boolean;
    /**
     * Indicates the top values that will be shown instantly. The top values can be
     * controlled by business users per facet.
     */
    topValueCount?: number;
    /**
     * The OCC backend has topValues with duplicated facet data.
     * This is not used in the UI, but normalized in the `topValueCount` property.
     */
    topValues?: FacetValue[];
}
interface SpellingSuggestion {
    query?: string;
    suggestion?: string;
}
interface ProductSearchPage {
    breadcrumbs?: Breadcrumb[];
    categoryCode?: string;
    currentQuery?: SearchState;
    facets?: Facet[];
    freeTextSearch?: string;
    keywordRedirectUrl?: string;
    pagination?: PaginationModel;
    products?: Product[];
    sorts?: SortModel[];
    spellingSuggestion?: SpellingSuggestion;
}
interface Suggestion {
    value?: string;
}
interface ClearSearch {
    clearPageResults?: boolean;
    clearSearchboxResults?: boolean;
}

/**
 * Used to envelope data observable together with specified scope
 */
interface ScopedData<T> {
    scope?: string;
    data$?: Observable<T>;
}

interface Currency {
    active?: boolean;
    isocode?: string;
    name?: string;
    symbol?: string;
}
interface Time {
    formattedHour?: string;
    hour?: number;
    minute?: number;
}
interface GeoPoint {
    latitude?: number;
    longitude?: number;
}
interface Language {
    active?: boolean;
    isocode?: string;
    name?: string;
    nativeName?: string;
}
interface Principal {
    name?: string;
    uid?: string;
}
interface User {
    currency?: Currency;
    customerId?: string;
    deactivationDate?: Date;
    defaultAddress?: Address;
    defaultPointOfServiceName?: string;
    displayUid?: string;
    firstName?: string;
    language?: Language;
    lastName?: string;
    name?: string;
    title?: string;
    titleCode?: string;
    uid?: string;
    roles?: string[];
    orgUnit?: B2BUnit;
    lastCartId?: string;
    hasOrder?: boolean;
}
interface ListModel {
    ids: string[];
    pagination?: PaginationModel;
    sorts?: SortModel[];
}
interface EntitiesModel<T> {
    values: T[];
    pagination?: PaginationModel;
    sorts?: SortModel[];
}
interface PaginationModel {
    currentPage?: number;
    pageSize?: number;
    sort?: string;
    totalPages?: number;
    totalResults?: number;
}
interface SortModel {
    code?: string;
    name?: string;
    selected?: boolean;
}
interface Title {
    code?: string;
    name?: string;
}
interface ErrorModel {
    message?: string;
    reason?: string;
    subject?: string;
    subjectType?: string;
    type?: string;
}
declare class HttpErrorModel {
    message?: string;
    status?: number;
    statusText?: string;
    url?: string | null;
    details?: ErrorModel[];
}
interface BaseStore {
    currencies?: Currency[];
    defaultCurrency?: Currency;
    languages?: Language[];
    defaultLanguage?: Language;
    paymentProvider?: string;
}
interface BaseSite {
    channel?: string;
    defaultLanguage?: Language;
    defaultPreviewCatalogId?: string;
    defaultPreviewCategoryCode?: string;
    defaultPreviewProductCode?: string;
    locale?: string;
    name?: string;
    theme?: string;
    uid?: string;
    stores?: BaseStore[];
    urlPatterns?: string[];
    urlEncodingAttributes?: string[];
    baseStore?: BaseStore;
    requiresAuthentication?: boolean;
    isolated?: boolean;
    captchaConfig?: CaptchaConfig;
}
interface CaptchaConfig {
    enabled: boolean;
    publicKey?: string;
}
interface SiteTheme {
    i18nNameKey: string;
    className: string;
}

interface Country {
    isocode?: string;
    name?: string;
}
declare enum CountryType {
    BILLING = "BILLING",
    SHIPPING = "SHIPPING"
}
interface Region {
    countryIso?: string;
    isocode?: string;
    isocodeShort?: string;
    name?: string;
}
interface City {
    regionIso?: string;
    isocode?: string;
    name?: string;
}
interface CityDistrict {
    cityIso?: string;
    isocode?: string;
    name?: string;
}
interface Address {
    id?: string;
    title?: string;
    titleCode?: string;
    email?: string;
    firstName?: string;
    lastName?: string;
    companyName?: string;
    line1?: string;
    line2?: string;
    postalCode?: string;
    town?: string;
    city?: City;
    region?: Region;
    district?: string;
    cityDistrict?: CityDistrict;
    country?: Country;
    cellphone?: string;
    defaultAddress?: boolean;
    shippingAddress?: boolean;
    formattedAddress?: string;
    phone?: string;
    visibleInAddressBook?: boolean;
}
interface AddressValidation {
    decision?: string;
    errors?: {
        errors: ErrorModel[];
    };
    suggestedAddresses?: Address[];
}

interface VariantOptionQualifier {
    image?: Image;
    name?: string;
    qualifier?: VariantQualifier;
    value?: string;
}
interface PromotionRestriction {
    description?: string;
    restrictionType?: string;
}
interface FeatureUnit {
    name?: string;
    symbol?: string;
    unitType?: string;
}
interface FeatureValue {
    value?: string;
}
interface Feature {
    code?: string;
    comparable?: boolean;
    description?: string;
    featureUnit?: FeatureUnit;
    featureValues?: FeatureValue[];
    name?: string;
    range?: boolean;
    type?: string;
}
interface VariantCategory {
    hasImage?: boolean;
    name?: string;
    priority?: number;
}
interface VariantValueCategory {
    name?: string;
    sequence?: number;
    superCategories?: VariantCategory[];
}
declare enum VariantType {
    SIZE = "ApparelSizeVariantProduct",
    STYLE = "ApparelStyleVariantProduct",
    COLOR = "ElectronicsColorVariantProduct"
}
declare enum PriceType {
    BUY = "BUY",
    FROM = "FROM"
}
interface Price {
    currencyIso?: string;
    formattedValue?: string;
    maxQuantity?: number;
    minQuantity?: number;
    priceType?: PriceType;
    value?: number;
}
interface Stock {
    isValueRounded?: boolean;
    stockLevel?: number;
    stockLevelStatus?: string;
}
interface VariantOption {
    code?: string;
    priceData?: Price;
    stock?: Stock;
    url?: string;
    variantOptionQualifiers?: VariantOptionQualifier[];
}
interface Promotion {
    code?: string;
    couldFireMessages?: string[];
    description?: string;
    enabled?: boolean;
    endDate?: Date;
    firedMessages?: string[];
    priority?: number;
    productBanner?: Image;
    promotionGroup?: string;
    promotionType?: string;
    restrictions?: PromotionRestriction[];
    startDate?: Date;
    title?: string;
}
interface Category {
    code?: string;
    name?: string;
    image?: Image;
    url?: string;
}
interface Classification {
    code?: string;
    features?: Feature[];
    name?: string;
}
interface FutureStock {
    date?: Date;
    formattedDate?: string;
    stock?: Stock;
}
interface PriceRange {
    maxPrice?: Price;
    minPrice?: Price;
}
interface ProductReference {
    description?: string;
    preselected?: boolean;
    quantity?: number;
    referenceType?: string;
    target?: Product;
}
interface Review {
    alias?: string;
    comment?: string;
    date?: Date;
    headline?: string;
    id?: string;
    principal?: User;
    rating?: number;
}
interface VariantMatrixElement {
    elements?: VariantMatrixElement[];
    isLeaf?: boolean;
    parentVariantCategory?: VariantCategory;
    variantOption?: VariantOption;
    variantValueCategory?: VariantValueCategory;
}
interface ProductReferences {
    [referenceType: string]: ProductReference[];
}
interface BaseOption {
    options?: VariantOption[];
    selected?: VariantOption;
    variantType?: VariantType;
}
interface Product {
    availableForPickup?: boolean;
    averageRating?: number;
    baseOptions?: BaseOption[];
    baseProduct?: string;
    categories?: Category[];
    classifications?: Classification[];
    code?: string;
    description?: string;
    futureStocks?: FutureStock[];
    images?: Images;
    manufacturer?: string;
    multidimensional?: boolean;
    name?: string;
    /**
     * The product slug is used to create pretty URL for links to product detail pages.
     *
     * The slug typically avoid spaces (`%20`) or other characters that are encoded in the URL.
     */
    slug?: string;
    nameHtml?: string;
    numberOfReviews?: number;
    potentialPromotions?: Promotion[];
    price?: Price;
    priceRange?: PriceRange;
    productReferences?: ProductReferences;
    purchasable?: boolean;
    reviews?: Review[];
    stock?: Stock;
    summary?: string;
    url?: string;
    variantMatrix?: VariantMatrixElement[];
    variantOptions?: VariantOption[];
    variantType?: VariantType;
    volumePrices?: Price[];
    volumePricesFlag?: boolean;
    /**
     * Default unit of measure to be used for the product stock availability
     */
    sapUnit?: SapUnit;
    productTypes?: ProductTypes;
}
/**
 * Unit of measure used for the product stock availability
 */
interface SapUnit {
    code?: string;
    name?: string;
    availabilityCode?: string;
    sapCode?: string;
}
declare enum VariantQualifier {
    SIZE = "size",
    STYLE = "style",
    COLOR = "color",
    THUMBNAIL = "thumbnail",
    PRODUCT = "product",
    STYLE_SWATCH = "styleSwatch",
    ROLLUP_PROPERTY = "rollupProperty"
}
interface PointOfServiceStock {
    address?: Address;
    description?: string;
    displayName?: string;
    distanceKm?: number;
    features?: {
        [propertyName: string]: string;
    };
    formattedDistance?: string;
    geoPoint?: GeoPoint;
    mapIcon?: Image;
    name?: string;
    openingHours?: OpeningSchedule;
    stockInfo?: Stock;
    storeContent?: string;
    storeImages?: Image[];
    url?: string;
}
interface StoreFinderStockSearchPage {
    boundEastLongitude?: number;
    boundSouthLatitude?: number;
    boundWestLongitude?: number;
    locationText?: string;
    pagination?: PaginationModel;
    product?: Product;
    sorts?: SortModel[];
    sourceLatitude?: number;
    sourceLongitude?: number;
    stores?: PointOfServiceStock[];
}
interface ProductAvailabilities {
    quantity?: string;
    status?: string;
}
declare enum ProductTypes {
    PHYSICAL = "PHYSICAL",
    SERVICE = "SERVICE",
    SUBSCRIPTION = "SUBSCRIPTION"
}

interface UrlCommandRoute {
    cxRoute?: string;
    params?: {
        [param: string]: any;
    };
}
type UrlCommand = UrlCommandRoute | any;
type UrlCommands = UrlCommand | UrlCommand[];

declare class UrlParsingService {
    private router;
    constructor(router: Router);
    getPrimarySegments(url: string): string[];
    private _getPrimarySegmentsFromUrlTree;
    /**
     * Tells whether the given url matches the given path.
     *
     * @param urlSegments   string or array of url segments. When it's a string, the preceding
     *                      site-context params are ignored (i.e. '/electronics-spa/en/USD/...')
     *
     * @param pathSegments  string or array of path segments. Dynamic params are allowed in the
     *                      path shape, i.e. `/url/:param1/with/:param2`.
     */
    matchPath(urlSegments: string | string[], pathSegments: string | string[]): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<UrlParsingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UrlParsingService>;
}

declare class SemanticPathService {
    protected routingConfigService: RoutingConfigService;
    protected urlParser: UrlParsingService;
    readonly ROOT_URL: string[];
    constructor(routingConfigService: RoutingConfigService, urlParser: UrlParsingService);
    /**
     * Returns the first path alias configured for a given route name. It adds `/` at the beginning.
     */
    get(routeName: string): string | undefined;
    /**
     * Transforms the array of url commands. Each command can be:
     * a) string - will be left untouched
     * b) object { cxRoute: <route name> } - will be replaced with semantic path
     * c) object { cxRoute: <route name>, params: { ... } } - same as above, but with passed params
     *
     * If the first command is the object with the `cxRoute` property, returns an absolute url (with the first element of the array `'/'`)
     */
    transform(commands: UrlCommands): any[];
    private isRouteCommand;
    private shouldOutputAbsolute;
    private generateUrlPart;
    private standarizeRouteCommand;
    private provideParamsValues;
    private findPathWithFillableParams;
    private getParams;
    private getMappedParamName;
    static ɵfac: i0.ɵɵFactoryDeclaration<SemanticPathService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SemanticPathService>;
}

declare class ProductURLPipe implements PipeTransform {
    private semanticPath;
    constructor(semanticPath: SemanticPathService);
    transform(product: Product): any[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductURLPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ProductURLPipe, "cxProductUrl", true>;
}

declare class UrlPipe implements PipeTransform {
    private urlService;
    constructor(urlService: SemanticPathService);
    transform(commands: UrlCommands): any[];
    static ɵfac: i0.ɵɵFactoryDeclaration<UrlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<UrlPipe, "cxUrl", true>;
}

declare class UrlModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UrlModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UrlModule, never, [typeof i1.CommonModule, typeof UrlPipe, typeof ProductURLPipe], [typeof UrlPipe, typeof ProductURLPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UrlModule>;
}

/**
 * Global Configuration, can be used to inject configuration to any part of the app
 */
declare abstract class Config {
    static ɵfac: i0.ɵɵFactoryDeclaration<Config, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Config>;
}
/**
 * Default Configuration token, used to build Global Configuration, built from DefaultConfigChunks
 */
declare const DefaultConfig: InjectionToken<any>;
/**
 * Root Configuration token, used to build Global Configuration, built from ConfigChunks
 */
declare const RootConfig: InjectionToken<any>;
/**
 * Config chunk token, can be used to provide configuration chunk and contribute to the global configuration object.
 * Should not be used directly, use `provideConfig` or import `ConfigModule.withConfig` instead.
 */
declare const ConfigChunk: InjectionToken<Config[]>;
/**
 * Config chunk token, can be used to provide configuration chunk and contribute to the default configuration.
 * Should not be used directly, use `provideDefaultConfig` or `provideDefaultConfigFactory` instead.
 *
 * General rule is, that all config provided in libraries should be provided as default config.
 */
declare const DefaultConfigChunk: InjectionToken<Config[]>;

/**
 * Used to provide asynchronous config during app initialization
 */
interface ConfigInitializer {
    /**
     * List of config parts that are resolved by configFactory, e.g.:
     * 'context.baseSite', 'context.language'
     */
    scopes: string[];
    /**
     * Promise that returns config chunk
     */
    configFactory: () => Promise<Config>;
}
/**
 * A multi-token for providing ConfigInitializers.
 */
declare const CONFIG_INITIALIZER: InjectionToken<ConfigInitializer | null>;
/**
 * Add a `ConfigInitializer` to the application for asynchronous configuration.
 *
 * Creates a provider for the multi-token `CONFIG_INITIALIZER`.
 */
declare function provideConfigInitializer(initializer: Type<ConfigInitializer>): ClassProvider;
/**
 * Add a `ConfigInitializer` factory to the application for asynchronous configuration.
 *
 * Create a factory provider for the multi-token `CONFIG_INITIALIZER`.
 */
declare function provideConfigInitializerFactory(initializerFactory: () => ConfigInitializer | null): FactoryProvider;

/**
 * Provides support for CONFIG_INITIALIZERS
 */
declare class ConfigInitializerService {
    protected config: Config;
    protected initializerGuard: any;
    protected rootConfig: Config;
    protected logger: LoggerService;
    constructor(config: Config, initializerGuard: any, rootConfig: Config);
    protected ongoingScopes$: BehaviorSubject<string[] | undefined>;
    /**
     * Returns true if config is stable, i.e. all CONFIG_INITIALIZERS resolved correctly
     */
    get isStable(): boolean;
    /**
     * Recommended way to get config for code that can run before app will finish
     * initialization (APP_INITIALIZERS, selected service constructors)
     *
     * Used without parameters waits for the whole config to become stable
     *
     * Parameters allow to describe which part of the config should be stable using
     * string describing config part, e.g.:
     * 'siteContext', 'siteContext.language', etc.
     *
     * @param scopes String describing parts of the config we want to be sure are stable
     */
    getStable(...scopes: string[]): Observable<Config>;
    /**
     * Removes provided scopes from currently ongoingScopes
     *
     * @param scopes
     */
    protected finishScopes(scopes: string[]): void;
    /**
     * Return true if provided scopes are not part of ongoingScopes
     *
     * @param scopes
     * @param ongoingScopes
     */
    protected areReady(scopes: string[], ongoingScopes: string[]): boolean;
    /**
     * Check if two scopes overlap.
     *
     * Example of scopes that overlap:
     * 'test' and 'test', 'test.a' and 'test', 'test' and 'test.a'
     *
     * Example of scopes that do not overlap:
     * 'test' and 'testA', 'test.a' and 'test.b', 'test.nested' and 'test.nest'
     *
     * @param a ScopeA
     * @param b ScopeB
     */
    protected scopesOverlap(a: string, b: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfigInitializerService, [null, { optional: true; }, null]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfigInitializerService>;
}

declare abstract class SiteContextConfig {
    context?: {
        urlParameters?: string[];
        [contextName: string]: string[] | undefined;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteContextConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SiteContextConfig>;
}
declare module './spartacus-core' {
    interface Config extends SiteContextConfig {
    }
}

declare const SITE_CONTEXT_FEATURE = "siteContext";
interface StateWithSiteContext {
    [SITE_CONTEXT_FEATURE]: SiteContextState;
}
interface SiteContextState {
    languages: LanguagesState;
    currencies: CurrenciesState;
    baseSite: BaseSiteState;
}
interface CurrencyEntities {
    [isocode: string]: Currency;
}
interface CurrenciesState {
    entities: CurrencyEntities | null;
    activeCurrency: string | null;
}
interface LanguagesEntities {
    [isocode: string]: Language;
}
interface LanguagesState {
    entities: LanguagesEntities | null;
    activeLanguage: string | null;
}
interface BaseSiteState {
    entities: BaseSiteEntities | null;
    activeSite: string;
    details: BaseSite;
}
interface BaseSiteEntities {
    [uid: string]: BaseSite;
}

interface SiteContext<T> {
    getAll(): Observable<T[]>;
    getActive(): Observable<string>;
    setActive(isocode: string): void;
}

declare class BaseSiteService implements SiteContext<BaseSite> {
    protected store: Store<StateWithSiteContext>;
    protected config: SiteContextConfig;
    constructor(store: Store<StateWithSiteContext>, config: SiteContextConfig);
    /**
     * Represents the current baseSite uid.
     */
    getActive(): Observable<string>;
    /**
     * Get all base sites data
     */
    getAll(): Observable<BaseSite[]>;
    /**
     * Get base site data based on site uid
     */
    get(siteUid?: string): Observable<BaseSite | undefined>;
    setActive(baseSite: string): void;
    /**
     * Tells whether the value of the base site has been already initialized
     */
    isInitialized(): boolean;
    /**
     * Tells whether the given iso code is allowed.
     *
     * The list of allowed iso codes can be configured in the `context` config of Spartacus.
     */
    protected isValid(value: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseSiteService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BaseSiteService>;
}

declare class SecurePortalConfigInitializer implements ConfigInitializer {
    protected baseSiteService: BaseSiteService;
    protected configInit: ConfigInitializerService;
    readonly scopes: string[];
    readonly configFactory: () => Promise<RoutingConfig>;
    constructor(baseSiteService: BaseSiteService, configInit: ConfigInitializerService);
    /**
     * Emits the Routing config basing on the current base site data.
     *
     * Completes after emitting the value.
     */
    protected resolveConfig(): Observable<RoutingConfig>;
    protected getRoutingConfig(source: BaseSite | undefined): RoutingConfig;
    static ɵfac: i0.ɵɵFactoryDeclaration<SecurePortalConfigInitializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SecurePortalConfigInitializer>;
}

interface ExternalRoutesConfigDefinition {
    internal?: string[];
}
declare abstract class ExternalRoutesConfig {
    routing?: ExternalRoutesConfigDefinition;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExternalRoutesConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ExternalRoutesConfig>;
}
declare module './spartacus-core' {
    interface RoutingConfigDefinition extends ExternalRoutesConfigDefinition {
    }
}

declare class ExternalRoutesGuard {
    protected winRef: WindowRef;
    protected platformId: Object;
    constructor(winRef: WindowRef, platformId: Object);
    /**
     * Redirects to different storefront system for anticipated URL
     */
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean;
    /**
     * Redirects to anticipated URL using full page reload, not Angular routing
     */
    protected redirect(_: ActivatedRouteSnapshot, state: RouterStateSnapshot): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExternalRoutesGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ExternalRoutesGuard>;
}

/**
 * Prepends the external route that redirects to a different storefront system for configured URLs
 */
declare class ExternalRoutesModule {
    static forRoot(): ModuleWithProviders<ExternalRoutesModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExternalRoutesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ExternalRoutesModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ExternalRoutesModule>;
}

/**
 * Service that helps redirecting to different storefront systems for configured URLs
 */
declare class ExternalRoutesService {
    protected config: ExternalRoutesConfig;
    protected urlMatcherService: UrlMatcherService;
    protected injector: Injector;
    constructor(config: ExternalRoutesConfig, urlMatcherService: UrlMatcherService, injector: Injector);
    protected get internalUrlPatterns(): string[];
    /**
     * Prepends routes (to the Router.config) that are responsible for redirecting to a different storefront system
     */
    addRoutes(): void;
    /**
     * Returns routes that are responsible for redirection to different storefront systems
     */
    protected getRoutes(): Routes;
    /**
     * Returns the URL matcher for the external route
     */
    protected getUrlMatcher(): UrlMatcher;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExternalRoutesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ExternalRoutesService>;
}

/**
 * Helper service to expose all activated routes
 */
declare class ActivatedRoutesService {
    protected router: Router;
    constructor(router: Router);
    /**
     * Array of currently activated routes (from the root route to the leaf route).
     */
    readonly routes$: Observable<ActivatedRouteSnapshot[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActivatedRoutesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ActivatedRoutesService>;
}

/**
 * Service to expose all parameters for the router, including child routes.
 * This is convenient in case the parent route (component) requires awareness
 * of child routes parameters.
 */
declare class RoutingParamsService {
    protected router: Router;
    protected activatedRoutesService: ActivatedRoutesService;
    protected readonly params$: Observable<{
        [key: string]: string;
    }>;
    constructor(router: Router, activatedRoutesService: ActivatedRoutesService);
    /**
     * Get the list of all parameters of the full route. This includes
     * active child routes.
     */
    getParams(): Observable<{
        [key: string]: string;
    }>;
    protected findAllParam(routes: ActivatedRouteSnapshot[]): {
        [key: string]: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<RoutingParamsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RoutingParamsService>;
}

/**
 * The homepage id for the CMS homepage is not required when we query the backend.
 * CMS business users can have multiple pages, that they might switch quickly without
 * changing the page id. Therefore, we use a constant to keep track of the page in the
 * store, but are able to ignore the id while querying the backend.
 */
declare const HOME_PAGE_CONTEXT = "__HOMEPAGE__";
/**
 * SmartEdit preview page is loaded by previewToken which is added by interceptor
 */
declare const SMART_EDIT_CONTEXT = "smartedit-preview";
declare class PageContext {
    id: string;
    type?: PageType;
    constructor(id: string, type?: PageType);
}

declare const ROUTING_FEATURE = "router";
interface RouterState extends fromNgrxRouter.RouterReducerState<ActivatedRouterStateSnapshot> {
    nextState?: ActivatedRouterStateSnapshot;
}
interface ActivatedRouterStateSnapshot {
    url: string;
    queryParams: Params;
    params: Params;
    context: PageContext;
    cmsRequired: boolean;
    semanticRoute?: string;
}
interface State {
    [ROUTING_FEATURE]: RouterState;
}

declare class RoutingService {
    protected store: Store<RouterState>;
    protected winRef: WindowRef;
    protected semanticPathService: SemanticPathService;
    protected routingParamsService: RoutingParamsService;
    protected router: Router;
    protected location: Location$1;
    constructor(store: Store<RouterState>, winRef: WindowRef, semanticPathService: SemanticPathService, routingParamsService: RoutingParamsService, router: Router, location: Location$1);
    /**
     * Get the list of all parameters of the full route. This includes
     * active child routes.
     */
    getParams(): Observable<{
        [key: string]: string;
    }>;
    /**
     * Get the current router state
     */
    getRouterState(): Observable<RouterState>;
    /**
     * Get the `PageContext` from the state
     */
    getPageContext(): Observable<PageContext>;
    /**
     * Get the next `PageContext` from the state
     */
    getNextPageContext(): Observable<PageContext | undefined>;
    /**
     * Allow to change next page context for the ongoing navigation
     *
     * @param pageContext
     */
    changeNextPageContext(pageContext: PageContext): void;
    /**
     * Get the `isNavigating` info from the state
     */
    isNavigating(): Observable<boolean>;
    /**
     * Navigation with a new state into history
     * @param commands: url commands
     * @param extras: Represents the extra options used during navigation.
     *
     * @returns Promise that resolves to `true` when navigation succeeds,
     *          to `false` when navigation fails, or is rejected on error.
     */
    go(commands: UrlCommands, extras?: NavigationExtras): Promise<boolean>;
    /**
     * Resolves the relative url for the given `UrlCommands` and `NavigationExtras`.
     *
     * The absolute url can be resolved using `getFullUrl()`.
     */
    getUrl(commands: UrlCommands, extras?: NavigationExtras): string;
    /**
     * Returns the absolute url for the given `UrlCommands` and `NavigationExtras`.
     *
     * The absolute url uses the origin of the current location.
     */
    getFullUrl(commands: UrlCommands, extras?: NavigationExtras): string;
    /**
     * Navigation using absolute route path
     * @param url
     * @param extras: Represents the extra options used during navigation.
     *
     * @returns Promise that resolves to `true` when navigation succeeds,
     *          to `false` when navigation fails, or is rejected on error.
     */
    goByUrl(url: string, extras?: NavigationBehaviorOptions): Promise<boolean>;
    /**
     * Navigating back
     */
    back(): void;
    /**
     * Navigating forward
     */
    forward(): void;
    /**
     * Navigation with a new state into history
     * @param path
     * @param extras: Represents the extra options used during navigation.
     *
     * @returns Promise that resolves to `true` when navigation succeeds,
     *          to `false` when navigation fails, or is rejected on error.
     */
    protected navigate(path: any[], extras?: NavigationExtras): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RoutingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RoutingService>;
}

/**
 * An initializer function to be provided as a value for the multi-InjectionToken `LOCATION_INITIALIZED_MULTI`.
 *
 * The initializer will be called in an injection context.
 *
 * CAUTION: The injection context is lost after leaving the synchronous execution, so
 * any injections must be performed before moving into asynchronous execution.  Otherwise, you
 * must inject and store the `EnvironmentInjector` in a variable, then use `runInInjectionContext()`.
 */
type LocationInitializer = () => Promise<any>;
/**
 * Factory function used with a `FactoryProvider` to create a `LocationInitializer` value
 * for the multi-value InjectionToken `LOCATION_INITIALIZED_MULTI`.
 */
type LocationInitializerFactory = () => LocationInitializer;
/**
 * Wrapper InjectionToken for LOCATION_INITIALIZED token to allow multiple initializers.
 *
 * CAUTION: Don't use Router and don't perform any Router navigation in its implementations.
 * Only access the class `Location` from '@angular/common' if access to URL is needed.
 */
declare const LOCATION_INITIALIZED_MULTI: InjectionToken<LocationInitializer[]>;
/**
 * Creates a `FactoryProvider` to create a value for the multi-token `LOCATION_INITIALIZED_MULTI`
 */
declare function provideLocationInitializerFactory(factory: LocationInitializerFactory): {
    provide: InjectionToken<LocationInitializer[]>;
    multi: true;
    useFactory: LocationInitializerFactory;
};
/**
 * Creates a `ValueProvider` for the multi-token `LOCATION_INITIALIZED_MULTI`
 */
declare function provideLocationInitializer(initializer: LocationInitializer): {
    provide: InjectionToken<LocationInitializer[]>;
    multi: true;
    useValue: LocationInitializer;
};

interface CmsRouteData extends Data {
    cxCmsRouteContext?: PageContext;
    pageLabel?: string;
}
interface CmsRoute extends Route {
    data?: CmsRouteData;
}
interface CmsActivatedRouteSnapshot extends ActivatedRouteSnapshot {
    data: CmsRouteData;
}

declare class ClientAuthStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ClientAuthStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ClientAuthStoreModule, never, [typeof i1.CommonModule, typeof StateModule, typeof i2.StoreFeatureModule, typeof i4.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ClientAuthStoreModule>;
}

/**
 * Some of the OCC endpoints require Authorization header with the client token (eg. user registration).
 * This pattern should not be used in the frontend apps, but until OCC changes this requirement
 * we provide this module to support using those endpoints.
 *
 * After OCC improvements regarding client authentication this module can be safely removed.
 */
declare class ClientAuthModule {
    static forRoot(): ModuleWithProviders<ClientAuthModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClientAuthModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ClientAuthModule, never, [typeof i1.CommonModule, typeof ClientAuthStoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ClientAuthModule>;
}

declare const DEFAULT_SCOPE = "default";
interface OccEndpoint {
    default?: string;
    [scope: string]: string | undefined;
}
interface ProductOccEndpoint extends OccEndpoint {
    list?: string;
    details?: string;
    attributes?: string;
    variants?: string;
}
interface OccEndpoints {
    /**
     * Get product details for scope
     *
     * @member Object
     */
    product?: string | ProductOccEndpoint;
    /**
     * Get reviews for a product
     *
     * @member {string}
     */
    productReviews?: string | OccEndpoint;
    /**
     * Get a list of product references
     *
     * @member {string}
     */
    productReferences?: string | OccEndpoint;
    /**
     * Get a list of products and additional data
     *
     * @member {string}
     */
    productSearch?: string | OccEndpoint;
    /**
     * Get a list of available suggestions
     *
     * @member {string}
     */
    productSuggestions?: string | OccEndpoint;
    /**
     * Get CMS component details
     *
     * @member {string}
     */
    component?: string | OccEndpoint;
    /**
     * Get a list of CMS component details
     *
     * @member {string}
     */
    components?: string | OccEndpoint;
    /**
     * Get page data with list of cms content slots
     *
     * @member {string}
     */
    pages?: string | OccEndpoint;
    /**
     * Get page data with list of cms content slots
     *
     * @member {string}
     */
    page?: string | OccEndpoint;
    /**
     * Get a list of available languages
     *
     * @member {string}
     */
    languages?: string | OccEndpoint;
    /**
     * Get a list of available currencies
     *
     * @member {string}
     */
    currencies?: string | OccEndpoint;
    /**
     * Get a list of countries
     *
     * @member {string}
     */
    countries?: string | OccEndpoint;
    /**
     * Fetch the list of regions for the provided country
     *
     * @member {string}
     */
    regions?: string | OccEndpoint;
    /**
     * Fetch cities for an address region
     */
    addressCities?: string | OccEndpoint;
    /**
     * Fetch districts for an address city
     */
    addressDistricts?: string | OccEndpoint;
    /**
     * Payment details root endpoint.
     *
     * @member {string}
     */
    paymentDetailsAll?: string | OccEndpoint;
    /**
     * Endpoint for a specific payment method.
     *
     * @member {string}
     */
    paymentDetail?: string | OccEndpoint;
    /**
     * Endpoint for anonymous consent templates
     *
     * @member {string}
     */
    anonymousConsentTemplates?: string | OccEndpoint;
    /**
     * Endpoint for consent templates
     *
     * @member {string}
     */
    consentTemplates?: string | OccEndpoint;
    /**
     * Endpoint for a user's consents
     *
     * @member {string}
     */
    consents?: string | OccEndpoint;
    /**
     * Endpoint for a user's specific previously given consent.
     *
     * @member {string}
     */
    consentDetail?: string | OccEndpoint;
    /**
     * Endpoint for a user's addresses
     *
     * @member {string}
     */
    addresses?: string | OccEndpoint;
    /**
     * Endpoint for a user's specific address
     *
     * @member {string}
     */
    addressDetail?: string | OccEndpoint;
    /**
     * Endpoint for address verification
     *
     * @member {string}
     */
    addressVerification?: string | OccEndpoint;
    /**
     * Endpoint for create configuration
     *
     * @member {string}
     */
    createVariantConfiguration?: string;
    /**
     * Endpoint for create configuration for the textfield configurator
     *
     * @member {string}
     */
    createTextfieldConfiguration?: string;
    /**
     * Endpoint for add textfield configuration to cart
     *
     * @member {string}
     */
    addTextfieldConfigurationToCart?: string;
    /**
     * Endpoint for reading textfield configuration attached to the cart entry
     */
    readTextfieldConfigurationForCartEntry?: string;
    /**
     * Endpoint for updating textfield configuration attached to the cart entry
     */
    updateTextfieldConfigurationForCartEntry?: string;
    /**
     * Endpoint to read configuration
     *
     * @member {string}
     */
    readVariantConfiguration?: string;
    /**
     * Endpoint to update configuration
     *
     * @member {string}
     */
    updateVariantConfiguration?: string;
    /**
     * Endpoint to add configuration to cart
     *
     * @member {string}
     */
    addVariantConfigurationToCart?: string;
    /**
     * Endpoint for reading configuration attached to the cart entry
     */
    readVariantConfigurationForCartEntry?: string;
    /**
     * Endpoint for updating configuration attached to the cart entry
     */
    updateVariantConfigurationForCartEntry?: string;
    /**
     * Endpoint for reading configuration overview attached to the order entry
     */
    readVariantConfigurationOverviewForOrderEntry?: string;
    /**
     * Endpoint to read configuration price
     *
     * @member {string}
     */
    readVariantConfigurationPriceSummary?: string;
    /**
     * Endpoint to get configuration Overview
     *
     * @member {string}
     */
    getVariantConfigurationOverview?: string;
    /**
     * Endpoint for configurator variant search
     *
     * @member {string}
     */
    searchConfiguratorVariants?: string;
    /**
     * Endpoint for coupons
     *
     * @member {string}
     */
    customerCoupons?: string | OccEndpoint;
    /**
     * Endpoint for claiming coupon
     *
     * @member {string}
     */
    claimCoupon?: string | OccEndpoint;
    /**
     * Endpoint for claiming coupon with code in request body
     *
     * @member {string}
     */
    claimCustomerCoupon?: string | OccEndpoint;
    /**
     * Endpoint for coupons
     *
     * @member {string}
     */
    couponNotification?: string | OccEndpoint;
    /**
     * Endpoint for notification preference
     *
     * @member {string}
     */
    notificationPreference?: string | OccEndpoint;
    /**
     * Endpoint for product interests
     *
     * @member {string}
     */
    productInterests?: string | OccEndpoint;
    /**
     * Endpoint for getting product interests
     *
     * @member {string}
     */
    getProductInterests?: string | OccEndpoint;
    /**
     * Endpoint for getting all base sites
     *
     * @member {string}
     */
    baseSites?: string | OccEndpoint;
    /** Endpoint to returns active cost centers
     *
     * @member {string}
     */
    getActiveCostCenters?: string | OccEndpoint;
    /** Endpoint to returns categories
     *
     * @member {string}
     */
    productSearchByCategory?: string | OccEndpoint;
    /** Endpoint to returns Product Availabilities
     *
     * @member {string}
     */
    productAvailabilities?: string | OccEndpoint;
}

/**
 * Intended to be inherited by all other Spartacus' events.
 *
 * "One event to rule them all".
 */
declare abstract class CxEvent {
    /**
     * Event's type
     */
    static readonly type: string;
}

interface LoadingScopeConfig {
    /**
     * Specify scopes that should be included with this scope
     */
    include?: string[];
    /**
     * Max age for the scope in seconds
     */
    maxAge?: number;
    /**
     * Events for which to reload the product.
     */
    reloadOn?: Type<CxEvent>[];
}
interface LoadingScopesConfig {
    [scope: string]: LoadingScopeConfig | undefined;
}
interface LoadingScopes {
    [model: string]: LoadingScopesConfig | undefined;
}

interface BackendConfig {
    occ?: {
        baseUrl?: string;
        prefix?: string;
        /**
         * Indicates whether or not cross-site Access-Control requests should be made
         * using credentials such as cookies, authorization headers or TLS client certificates
         */
        useWithCredentials?: boolean;
        endpoints?: OccEndpoints;
    };
    media?: {
        /**
         * Media URLs are typically relative, so that the host can be configured.
         * Configurable media baseURLs are useful for SEO, multi-site,
         * switching environments, etc.
         */
        baseUrl?: string;
        /**
         * Media URL path prefix, to be appended to the baseUrl.
         * This is useful when media is hosted under a specific path.
         * For example, if media is hosted under '/api/storefront', then the prefix should be set to '/api/storefront'.
         */
        prefix?: string;
    };
    loadingScopes?: LoadingScopes;
}
declare abstract class OccConfig extends SiteContextConfig {
    backend?: BackendConfig;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccConfig>;
}
declare module './spartacus-core' {
    interface Config extends OccConfig {
    }
}

interface BaseOccUrlProperties {
    baseUrl?: boolean;
    prefix?: boolean;
    baseSite?: boolean;
}
interface DynamicAttributes {
    urlParams?: object;
    queryParams?: object;
    scope?: string;
}
declare class OccEndpointsService {
    private config;
    private baseSiteService;
    private _activeBaseSite;
    private get activeBaseSite();
    protected logger: LoggerService;
    constructor(config: OccConfig, baseSiteService: BaseSiteService);
    /**
     * Returns the value configured for a specific endpoint
     *
     * @param endpointKey the configuration key for the endpoint to return
     * @param scope endpoint configuration scope
     */
    getRawEndpointValue(endpoint: string, scope?: string): string;
    /**
     * Returns true when the endpoint is configured
     *
     * @param endpointKey the configuration key for the endpoint to return
     * @param scope endpoint configuration scope
     */
    isConfigured(endpoint: string, scope?: string): boolean;
    /**
     * Returns base OCC endpoint (baseUrl + prefix + baseSite) base on provided values
     *
     * @param baseUrlProperties Specify properties to not add to the url (baseUrl, prefix, baseSite)
     */
    getBaseUrl(baseUrlProperties?: BaseOccUrlProperties): string;
    /**
     * Returns a fully qualified OCC Url
     *
     * @param endpoint Name of the OCC endpoint key
     * @param attributes Dynamic attributes used to build the url
     * @param propertiesToOmit Specify properties to not add to the url (baseUrl, prefix, baseSite)
     */
    buildUrl(endpoint: string, attributes?: DynamicAttributes, propertiesToOmit?: BaseOccUrlProperties): string;
    protected getHttpParamsFromQueryParams(queryParams: any, options: HttpParamsOptions): HttpParams;
    private getEndpointFromConfig;
    private getEndpointForScope;
    /**
     * Add the base OCC url properties to the specified endpoint string
     *
     * @param endpointString String value for the url endpoint
     * @param propertiesToOmit Specify properties to not add to the url (baseUrl, prefix, baseSite)
     */
    private buildUrlFromEndpointString;
    private getPrefix;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccEndpointsService, [null, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccEndpointsService>;
}

interface ClientToken {
    access_token: string;
    token_type: string;
    expires_in: number;
    scope: string;
}

interface LoaderState<T> {
    loading?: boolean;
    error?: boolean;
    success?: boolean;
    value?: T;
}

declare const CLIENT_AUTH_FEATURE = "client-auth";
declare const CLIENT_TOKEN_DATA = "[Client auth] Client Token Data";
interface StateWithClientAuth {
    [CLIENT_AUTH_FEATURE]: ClientAuthState;
}
interface ClientAuthState {
    clientToken: LoaderState<ClientToken>;
}

/**
 * Serves a role of a facade on client token store.
 */
declare class ClientTokenService {
    protected store: Store<StateWithClientAuth>;
    constructor(store: Store<StateWithClientAuth>);
    /**
     * Returns a client token. The client token from the store is returned if there is one.
     * Otherwise a new token is fetched from the backend and saved in the store.
     */
    getClientToken(): Observable<ClientToken | undefined>;
    /**
     * Fetches a clientToken from the backend and saves it in the store where getClientToken can use it.
     * The new clientToken is returned.
     */
    refreshClientToken(): Observable<ClientToken>;
    protected isClientTokenLoaded(state: LoaderState<ClientToken>): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClientTokenService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ClientTokenService>;
}

/**
 * Service for handling `Authorization` header and errors for requests that
 * require client token (eg. user registration).
 */
declare class ClientErrorHandlingService {
    protected clientTokenService: ClientTokenService;
    constructor(clientTokenService: ClientTokenService);
    /**
     * Refreshes client token and retries the request with the new token.
     *
     * @param request
     * @param httpHandler
     */
    handleExpiredClientToken(request: HttpRequest<any>, next: HttpHandler): Observable<any>;
    /**
     * Clones the requests and provided `Authorization` header.
     *
     * @param request
     * @param token
     */
    protected createNewRequestWithNewToken(request: HttpRequest<any>, token: ClientToken): HttpRequest<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClientErrorHandlingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ClientErrorHandlingService>;
}

/**
 * Interceptor for handling requests with `USE_CLIENT_TOKEN` header.
 * Provides `Authorization` header with client token and handles errors related to client auth.
 */
declare class ClientTokenInterceptor implements HttpInterceptor {
    protected clientTokenService: ClientTokenService;
    protected clientErrorHandlingService: ClientErrorHandlingService;
    protected occEndpoints: OccEndpointsService;
    protected enableClientToken: boolean;
    constructor(clientTokenService: ClientTokenService, clientErrorHandlingService: ClientErrorHandlingService, occEndpoints: OccEndpointsService);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    protected getClientToken(isClientTokenRequest: boolean): Observable<ClientToken | undefined>;
    protected isClientTokenRequest(request: HttpRequest<any>): boolean;
    protected isExpiredToken(resp: HttpErrorResponse): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClientTokenInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ClientTokenInterceptor>;
}

type AuthLibConfig = Omit<AuthConfig$1, 'clientId' | 'dummyClientSecret' | 'siletRefreshTimeout' | 'loginUrl' | 'logoutUrl' | 'tokenEndpoint' | 'revocationEndpoint' | 'userinfoEndpoint'>;
declare abstract class AuthConfig {
    authentication?: {
        /**
         * OAuth client id.
         */
        client_id?: string;
        /**
         * Secret for client required by Hybris OAuth.
         */
        client_secret?: string;
        /**
         * Base url for auth server (for login, token, revoke endpoints).
         */
        baseUrl?: string;
        /**
         * Endpoint for getting token.
         */
        tokenEndpoint?: string;
        /**
         * Endpoint url for revoking tokens.
         */
        revokeEndpoint?: string;
        /**
         * Determine if the `Authorization` header should be sent with revocation requests.
         *
         * In particular, you must set this property to `true` when using the legacy Authorization
         * Server from SAP Commerce Cloud versions prior to September 2025. For SAP Commerce Cloud
         * versions from September 2025 onwards, which includes the rebuilt Authorization server,
         * set `sendAuthHeaderOnRevoke` to `false`.
         */
        sendAuthHeaderOnRevoke?: boolean;
        /**
         * Determine if client tokens should be requested and sent with the correspondingly marked
         * connector requests.
         *
         * In particular, you must set this property to `true` when using the legacy Authorization
         * Server from SAP Commerce Cloud versions prior to September 2025. For SAP Commerce Cloud
         * versions from September 2025 onwards, which includes the rebuilt Authorization server,
         * set `useClientTokens` to `false`.
         */
        useClientTokens?: boolean;
        /**
         * Url for login redirect for Implicit and Authorization Code Flow.
         */
        loginUrl?: string;
        /**
         * Redirect url after logout.
         */
        logoutUrl?: string;
        /**
         * Userinfo endpoint.
         */
        userinfoEndpoint?: string;
        /**
         * Config for angular-oauth-oidc library.
         */
        OAuthLibConfig?: AuthLibConfig;
        /**
         * Config for custom login page
         */
        customLoginPage?: {
            /**
             * Endpoint for Cross Site Request Forgery token and form name
             */
            csrfEndpoint?: string;
            /**
             * Endpoint for target (action) of form
             */
            loginFormEndpoint?: string;
        };
        initializerOptions?: {
            /**
             * Controls if the redirect URI should have the base site URL parameter added.
             *
             * ex: "https://example.com" to "https://example.com/electronics-spa"
             *
             * `true` - always add the base site URL parameter
             *
             * `"auto"` - add base site URL parameter only when base site is in the URL context parameters
             *
             * `false` - do not add base site URL parameter
             *
             * This is useful when hosting multiple sites on a single domain while using Spartacus as a Custom
             * Login Page.  This allows unique client IDs to be set for each site so the Custom Login Page URI
             * can be configured properly for each site.
             */
            addBaseSiteToRedirectUri?: boolean | 'auto';
            /**
             * Controls if the client ID should be suffixed with the base site.
             *
             * ex: "mobile_android_public" to "mobile_android_public_electronics-sap"
             *
             * `true` - always suffix client ID
             *
             * `"auto"` - suffix if base site is in URL context parameters
             *
             * `false` - do not suffix client ID
             *
             * This is useful when hosting multiple sites on a single domain while using Spartacus as a Custom
             * Login Page.  This allows unique client IDs to be set for each site so the Custom Login Page URI
             * can be configured properly for each site.
             */
            baseSiteSuffix?: boolean | 'auto';
        };
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthConfig>;
}
declare module './spartacus-core' {
    interface Config extends AuthConfig {
    }
}

/**
 * Supported OAuth flows.
 */
declare enum OAuthFlow {
    /**
     * Flow when username and password is passed to the application and then the application through API fetches tokens from OAuth server.
     */
    ResourceOwnerPasswordFlow = 0,
    /**
     * Flow with redirect to OAuth server where user inputs credentials and the are redirected back with token.
     */
    ImplicitFlow = 1,
    /**
     * Similar to Implicit flow, but user is redirected with code that need to later exchange through API for a token.
     */
    AuthorizationCode = 2
}

/**
 * Utility service on top of the authorization config.
 * Provides handy defaults, when not everything is set in the configuration.
 * Use this service instead of direct configuration.
 */
declare class AuthConfigService {
    protected authConfig: AuthConfig;
    protected occConfig: OccConfig;
    constructor(authConfig: AuthConfig, occConfig: OccConfig);
    /**
     * Utility to make access to authentication config easier.
     */
    private get config();
    /**
     * Get client_id
     *
     * @return client_id
     */
    getClientId(): string;
    /**
     * Get client_secret. OAuth server shouldn't require it from web apps (but Hybris OAuth server requires).
     *
     * @return client_secret
     */
    getClientSecret(): string;
    /**
     * Returns base url of the authorization server
     */
    getBaseUrl(): string;
    /**
     * Returns endpoint for getting the auth token
     */
    getTokenEndpoint(): string;
    /**
     * Returns url for redirect to the authorization server to get token/code
     */
    getLoginUrl(): string;
    /**
     * Retrieves the custom login form endpoint from the configuration.
     */
    getCustomLoginFormEndpoint(): string;
    /**
     * Retrieves the CSRF endpoint for custom login based on the configuration settings.
     */
    getCsrfEndpoint(): string;
    /**
     * Returns endpoint for token revocation (both access and refresh token).
     */
    getRevokeEndpoint(): string;
    /**
     * Determines if Custom Login Page feature is enabled
     */
    customLoginEnabled(): boolean;
    /**
     * Determines if an authorization header should be sent with revoke requests.
     */
    sendAuthHeaderOnRevoke(): boolean;
    /**
     * Returns logout url to redirect to on logout.
     */
    getLogoutUrl(): string;
    /**
     * Returns userinfo endpoint of the OAuth server.
     */
    getUserinfoEndpoint(): string;
    /**
     * Returns configuration specific for the angular-oauth2-oidc library.
     */
    getOAuthLibConfig(): AuthLibConfig;
    protected prefixEndpoint(endpoint: string): string;
    /**
     * Returns the type of the OAuth flow based on auth config.
     * Use when you have to perform particular action only in some of the OAuth flow scenarios.
     */
    getOAuthFlow(): OAuthFlow;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthConfigService>;
}

/**
 * Responsible for requesting from OAuth server `ClientToken` for a particular
 * auth client.
 */
declare class ClientAuthenticationTokenService {
    protected http: HttpClient;
    protected authConfigService: AuthConfigService;
    constructor(http: HttpClient, authConfigService: AuthConfigService);
    /**
     * Loads token with client authentication flow.
     *
     * @returns observable with ClientToken
     */
    loadClientAuthenticationToken(): Observable<ClientToken>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClientAuthenticationTokenService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ClientAuthenticationTokenService>;
}

type CSRFResponse = {
    headerName: string;
    parameterName: string;
    token: string;
};

/**
 * Service to handle CSRF (Cross-Site Request Forgery) protection mechanisms
 * by retrieving CSRF tokens as needed.
 *
 * This service provides a method to fetch the CSRF token from a configured
 * endpoint, which can be used to ensure secure communication by protecting
 * against CSRF attacks.
 */
declare class CrossSiteRequestForgeryService {
    protected http: HttpClient;
    protected authConfigService: AuthConfigService;
    /**
     * Returns CSRF Token
     */
    getCsrfToken(): rxjs.Observable<CSRFResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CrossSiteRequestForgeryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CrossSiteRequestForgeryService>;
}

declare const LOAD_CLIENT_TOKEN = "[Token] Load Client Token";
declare const LOAD_CLIENT_TOKEN_FAIL = "[Token] Load Client Token Fail";
declare const LOAD_CLIENT_TOKEN_SUCCESS = "[Token] Load Client Token Success";
declare class LoadClientToken extends LoaderLoadAction {
    readonly type = "[Token] Load Client Token";
    constructor();
}
declare class LoadClientTokenFail extends LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Token] Load Client Token Fail";
    constructor(payload: any);
}
declare class LoadClientTokenSuccess extends LoaderSuccessAction {
    payload: ClientToken;
    readonly type = "[Token] Load Client Token Success";
    constructor(payload: ClientToken);
}
type ClientTokenAction = LoadClientToken | LoadClientTokenFail | LoadClientTokenSuccess;

type clientTokenGroup_actions_d_ClientTokenAction = ClientTokenAction;
declare const clientTokenGroup_actions_d_LOAD_CLIENT_TOKEN: typeof LOAD_CLIENT_TOKEN;
declare const clientTokenGroup_actions_d_LOAD_CLIENT_TOKEN_FAIL: typeof LOAD_CLIENT_TOKEN_FAIL;
declare const clientTokenGroup_actions_d_LOAD_CLIENT_TOKEN_SUCCESS: typeof LOAD_CLIENT_TOKEN_SUCCESS;
type clientTokenGroup_actions_d_LoadClientToken = LoadClientToken;
declare const clientTokenGroup_actions_d_LoadClientToken: typeof LoadClientToken;
type clientTokenGroup_actions_d_LoadClientTokenFail = LoadClientTokenFail;
declare const clientTokenGroup_actions_d_LoadClientTokenFail: typeof LoadClientTokenFail;
type clientTokenGroup_actions_d_LoadClientTokenSuccess = LoadClientTokenSuccess;
declare const clientTokenGroup_actions_d_LoadClientTokenSuccess: typeof LoadClientTokenSuccess;
declare namespace clientTokenGroup_actions_d {
  export { clientTokenGroup_actions_d_LOAD_CLIENT_TOKEN as LOAD_CLIENT_TOKEN, clientTokenGroup_actions_d_LOAD_CLIENT_TOKEN_FAIL as LOAD_CLIENT_TOKEN_FAIL, clientTokenGroup_actions_d_LOAD_CLIENT_TOKEN_SUCCESS as LOAD_CLIENT_TOKEN_SUCCESS, clientTokenGroup_actions_d_LoadClientToken as LoadClientToken, clientTokenGroup_actions_d_LoadClientTokenFail as LoadClientTokenFail, clientTokenGroup_actions_d_LoadClientTokenSuccess as LoadClientTokenSuccess };
  export type { clientTokenGroup_actions_d_ClientTokenAction as ClientTokenAction };
}

declare const getClientTokenState: MemoizedSelector<StateWithClientAuth, LoaderState<ClientToken>>;

declare const getClientAuthState: MemoizedSelector<StateWithClientAuth, ClientAuthState>;

declare const clientTokenGroup_selectors_d_getClientAuthState: typeof getClientAuthState;
declare const clientTokenGroup_selectors_d_getClientTokenState: typeof getClientTokenState;
declare namespace clientTokenGroup_selectors_d {
  export {
    clientTokenGroup_selectors_d_getClientAuthState as getClientAuthState,
    clientTokenGroup_selectors_d_getClientTokenState as getClientTokenState,
  };
}

declare enum AuthNotificationType {
    LOGOUT = "logout"
}

declare class AuthMultisiteIsolationService {
    protected baseSiteService: BaseSiteService;
    protected readonly MULTISITE_SEPARATOR = "|";
    constructor(baseSiteService: BaseSiteService);
    /**
     * When isolation is turned on, a customer who registers for baseSiteA
     * can only log into baseSiteA, not baseSiteB.
     * To login into baseSiteB customer have to use the same e-mail and register an account
     * on baseSiteB.
     *
     * The strategy how to handle isolation is to use an additional decorator
     * passed as a suffix to the uid field.
     *
     * Example uid value for baseSiteA will be email@example.com|baseSiteA
     */
    getBaseSiteDecorator(): Observable<string>;
    /**
     * Method returns concatenated `userId` with the decorator suffix.
     *
     * @param userId The `userId` for given user
     */
    decorateUserId(userId: string): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthMultisiteIsolationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthMultisiteIsolationService>;
}

/**
 * Facade that provides easy access to currency state, actions and selectors.
 */
declare class CurrencyService implements SiteContext<Currency> {
    protected store: Store<StateWithSiteContext>;
    protected config: SiteContextConfig;
    private featureToggles;
    constructor(store: Store<StateWithSiteContext>, config: SiteContextConfig);
    /**
     * Represents all the currencies supported by the current store.
     */
    getAll(): Observable<Currency[]>;
    /**
     * Represents the isocode of the active currency.
     */
    getActive(): Observable<string>;
    /**
     * Sets the active language.
     */
    setActive(isocode: string): void;
    /**
     * Tells whether the value of the active currency has been already initialized
     */
    isInitialized(): boolean;
    /**
     * Tells whether the given iso code is allowed.
     *
     * The list of allowed iso codes can be configured in the `context` config of Spartacus.
     */
    protected isValid(value: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrencyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrencyService>;
}

/**
 * Facade that provides easy access to language state, actions and selectors.
 */
declare class LanguageService implements SiteContext<Language> {
    protected store: Store<StateWithSiteContext>;
    protected config: SiteContextConfig;
    constructor(store: Store<StateWithSiteContext>, config: SiteContextConfig);
    /**
     * Represents all the languages supported by the current store.
     */
    getAll(): Observable<Language[]>;
    /**
     * Represents the isocode of the active language.
     */
    getActive(): Observable<string>;
    /**
     * Sets the active language.
     */
    setActive(isocode: string): void;
    /**
     * Tells whether the value of the active language has been already initialized
     */
    isInitialized(): boolean;
    /**
     * Tells whether the given iso code is allowed.
     *
     * The list of allowed iso codes can be configured in the `context` config of Spartacus.
     */
    protected isValid(value: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<LanguageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LanguageService>;
}

declare abstract class ContextServiceMap {
    [context: string]: Type<SiteContext<any>>;
}
declare function serviceMapFactory(): {
    language: typeof LanguageService;
    currency: typeof CurrencyService;
    baseSite: typeof BaseSiteService;
};
declare const contextServiceMapProvider: Provider;

declare class SiteContextParamsService {
    private config;
    private injector;
    private serviceMap;
    protected logger: LoggerService;
    constructor(config: SiteContextConfig, injector: Injector, serviceMap: ContextServiceMap);
    getContextParameters(): string[];
    getUrlEncodingParameters(): string[];
    getParamValues(param: string): string[];
    getParamDefaultValue(param: string): string | undefined;
    getSiteContextService(param: string): SiteContext<any> | undefined;
    getValue(param: string): string | undefined;
    setValue(param: string, value: string): void;
    /**
     * Get active values for all provided context parameters
     *
     * @param params Context parameters
     *
     * @returns Observable emitting array of all passed active context values
     */
    getValues(params: string[]): Observable<Array<string>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteContextParamsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SiteContextParamsService>;
}

/**
 * Values of the site context parameters encoded in the URL.
 */
interface SiteContextUrlParams {
    [name: string]: string;
}
/**
 * UrlTree decorated with a custom property `siteContext`
 * for storing the values of the site context parameters.
 */
interface UrlTreeWithSiteContext extends UrlTree {
    siteContext?: SiteContextUrlParams;
}
/**
 * Angular URL Serializer aware of Spartacus site context parameters
 * encoded in the URL.
 */
declare class SiteContextUrlSerializer extends DefaultUrlSerializer {
    private siteContextParams;
    /**
     * Splits the URL into 2 parts: path and the query/fragment part
     */
    protected readonly URL_SPLIT: RegExp;
    /**
     * Names of site context parameters encoded in the URL
     */
    protected get urlEncodingParameters(): string[];
    /**
     * Tells whether any site context parameters should be encoded in the URL
     */
    protected get hasContextInRoutes(): boolean;
    constructor(siteContextParams: SiteContextParamsService);
    /**
     * @override Recognizes the site context parameters encoded in the prefix segments
     * of the given URL.
     *
     * It returns the UrlTree for the given URL shortened by the recognized params, but saves
     * the params' values in the custom property of UrlTree: `siteContext`.
     */
    parse(url: string): UrlTreeWithSiteContext;
    /**
     * Recognizes the site context parameters encoded in the prefix segments of the given URL.
     *
     * It returns the recognized site context params as well as the
     * URL shortened by the recognized params.
     */
    urlExtractContextParameters(url: string): {
        url: string;
        params: SiteContextUrlParams;
    };
    /**
     * Saves the given site context parameters in the custom property
     * of the given UrlTree: `siteContext`.
     */
    protected urlTreeIncludeContextParameters(urlTree: UrlTreeWithSiteContext, params: SiteContextUrlParams): void;
    /**
     * @override Serializes the given UrlTree to a string and prepends
     *  to it the current values of the site context parameters.
     */
    serialize(tree: UrlTreeWithSiteContext): string;
    /**
     * Returns the site context parameters stored in the custom property
     * of the UrlTree: `siteContext`.
     */
    urlTreeExtractContextParameters(urlTree: UrlTreeWithSiteContext): SiteContextUrlParams;
    /**
     * Prepends the current values of the site context parameters to the given URL.
     */
    protected urlIncludeContextParameters(url: string, params: SiteContextUrlParams): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteContextUrlSerializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SiteContextUrlSerializer>;
}

declare class AuthFlowRoutesService {
    protected config: RoutingConfig;
    protected urlParsingService: UrlParsingService;
    constructor(config: RoutingConfig, urlParsingService: UrlParsingService);
    protected _authFlowPaths: string[];
    /**
     * List of paths that are part user auth flow
     */
    protected get authFlowPaths(): string[];
    /**
     * Tells whether the given URL is a part of the user auth flow
     */
    isAuthFlow(url: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthFlowRoutesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthFlowRoutesService>;
}

/**
 * Service serves storage role for AuthRedirectService.
 * Used by AuthStatePersistenceService to store redirect url for OAuth flows that rely on redirects.
 */
declare class AuthRedirectStorageService {
    constructor();
    private redirectUrl$;
    /**
     * Get redirect url after logging in.
     *
     * @returns observable with the redirect url as string
     */
    getRedirectUrl(): Observable<string | undefined>;
    /**
     * Set url to redirect to after login.
     *
     * @param redirectUrl
     */
    setRedirectUrl(redirectUrl: string | undefined): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthRedirectStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthRedirectStorageService>;
}

/**
 * Responsible for saving last accessed page (or attempted) before login and for redirecting to that page after login.
 */
declare class AuthRedirectService implements OnDestroy {
    protected routing: RoutingService;
    protected router: Router;
    protected authRedirectStorageService: AuthRedirectStorageService;
    protected authFlowRoutesService: AuthFlowRoutesService;
    protected siteContextUrlSerializer: SiteContextUrlSerializer;
    private featureToggles;
    /**
     * This service is responsible for remembering the last page before the authentication. "The last page" can be:
     * 1. Just the previously opened page; or
     * 2. The page that we just tried to open, but AuthGuard cancelled it
     *
     * Then, after successful authentication it allows for redirecting to that remembered page via the `redirect()` method.
     *
     * For example:
     * 1. The user opens the product page, then clicks /login link and signs in
     *    -> Then we should redirect to the product page; or
     * 2. The user opens the product page, then he clicks /my-account link,
     *    but is automatically redirected to the login page by the AuthGuard, and he signs in
     *    -> Then we should redirect to the my-account page, not the product page
     */
    constructor(routing: RoutingService, router: Router, authRedirectStorageService: AuthRedirectStorageService, authFlowRoutesService: AuthFlowRoutesService);
    protected subscription: Subscription;
    /**
     * Normal navigations produce [NavigationEnd, NavigationEnd] pairs — saved in localStorage
     * Guard UrlTree redirects produce [NavigationCancel, NavigationEnd] pairs — skipped
     * The [NavigationCancel, NavigationEnd] pair must be caught to prevent
     * guard-driven redirects (post-logout navigation to '/') from
     * overwriting the saved redirect URL
     */
    protected init(): void;
    ngOnDestroy(): void;
    /**
     * Redirect to saved url (homepage if nothing is saved).
     */
    redirect(): void;
    /**
     * Saves the url of the current navigation as the redirect url, unless
     * the url is a part of the user login flow.
     */
    saveCurrentNavigationUrl(): void;
    /**
     * Save the url as the redirect url, unless it's a part of the user login flow.
     */
    setRedirectUrl(url: string): void;
    protected manageSavedRedirectUriOnTrueNavigations(): void;
    protected isNavEnd: (event: any) => event is NavigationEnd;
    protected isRedirect: (event: any) => event is NavigationCancel;
    /**
     * Sets the redirect URL to undefined.
     */
    protected clearRedirectUrl(): void;
    /**
     * For a given URL, removes the prefix with site-context params (e.g., baseSite, language, currency)
     *
     * @example
     * Supposing the configured site-context URL params are [baseSite, language, currency],
     * and given the url '/electronics-spa/en/USD/product/123',
     * it returns '/product/123'.
     */
    protected getUrlWithoutSiteContextParams(url: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthRedirectService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthRedirectService>;
}

/**
 * Structure of token used by the OAuth lib and across `UserAuthModule`.
 */
interface AuthToken {
    /**
     * Token used for `Authorization` header.
     */
    access_token: string;
    /**
     * Token to refresh the `access_token` when it expires.
     */
    refresh_token?: string;
    /**
     * Time when `access_token` expires.
     */
    expires_at?: string;
    /**
     * Scopes granted by the OAuth server.
     */
    granted_scopes?: string[];
    /**
     * Time when `access_token` was fetched from OAuth server and saved.
     */
    access_token_stored_at: string;
    /**
     * Type of the `access_token`. Most often `Bearer`.
     */
    token_type?: string;
}

/**
 * Storage service for AuthToken. Used as a storage for angular-oauth2-oidc library.
 */
declare class AuthStorageService extends OAuthStorage {
    /**
     * Extracted keys that are not `JSON.stringify` from reading the angular-oauth2-oidc source code
     */
    protected static readonly nonStringifiedOAuthLibKeys: string[];
    protected _token$: Observable<AuthToken>;
    protected decode(key: string, value: any): any;
    protected encode(key: string, value: any): any;
    /**
     * Returns complete token (all fields).
     *
     * @return observable emitting AuthToken
     */
    getToken(): Observable<AuthToken>;
    /**
     * Set current value of token.
     *
     * @param token
     */
    setToken(token: AuthToken): void;
    /**
     * Get parameter from the token (eg. access_token)
     *
     * @param key
     */
    getItem(key: string): any;
    /**
     * Removes parameter from the token (eg. access_token)
     *
     * @param key
     */
    removeItem(key: string): void;
    /**
     * Sets parameter of the token (eg. access_token)
     *
     * @param key
     */
    setItem(key: string, data: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthStorageService>;
}

declare function configInitializerFactory(configInitializer: ConfigInitializerService, initializers: ConfigInitializer[]): () => Promise<void>;
/**
 * @deprecated since 2211.22  - should not be a public API
 */
declare function locationInitializedFactory(configInitializer: ConfigInitializerService): Promise<Config>;
declare class ConfigInitializerModule {
    static forRoot(): ModuleWithProviders<ConfigInitializerModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfigInitializerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfigInitializerModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfigInitializerModule>;
}

declare abstract class FederatedLoginConfig {
    federatedLogin?: {
        enabled?: boolean;
        /** URL parameter name to use when passing context from an originating domain to a login domain. */
        contextParameterName?: string;
        /**
         * List of hosts that serve as a federated login page.
         *
         * Values are hostname and port.  Protocol is not used in default matching.
         *
         * i.e.
         * ```
         *   loginDomains: ['login.shop.com', 'test.login.local:4200']
         * ```
         */
        loginHosts?: string[];
        /**
         * Map of URL-safe keys to fully-qualified domains.
         *
         * These keys are used to pass the context from a domain to a federated login instance.
         *
         * ex:
         * ```
         * {
         *   sf1: 'https://storefront1.com',
         *   sf2: 'https://storefront2.com',
         * }
         */
        originMap?: Record<string, string>;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<FederatedLoginConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FederatedLoginConfig>;
}
declare module './spartacus-core' {
    interface Config extends FederatedLoginConfig {
    }
}

declare const federatedLoginProviders: i0.FactoryProvider[];
declare class FederatedLoginModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FederatedLoginModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FederatedLoginModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FederatedLoginModule>;
}

interface FederatedLoginContext {
    origin?: string;
    language?: string;
}

declare class FederatedLoginContextSerializerService {
    config: {
        enabled?: boolean;
        contextParameterName?: string;
        loginHosts?: string[];
        originMap?: Record<string, string>;
    } | undefined;
    serializeContext(context: FederatedLoginContext | undefined): string;
    deserializeContext(encodedContext: string | null | undefined): FederatedLoginContext;
    protected getOrigin(contextKey: string): string | undefined;
    protected getContextKey(origin: string): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<FederatedLoginContextSerializerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FederatedLoginContextSerializerService>;
}

declare const FEDERATED_LOGIN_STATE_KEY = "federatedLogin";
declare class FederatedLoginContextStorageService {
    winRef: WindowRef;
    storage: Storage | undefined;
    storageKey: string;
    read(): FederatedLoginContext | undefined;
    write(value: FederatedLoginContext): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FederatedLoginContextStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FederatedLoginContextStorageService>;
}

declare class FederatedLoginService {
    windowRef: WindowRef;
    config: {
        enabled?: boolean;
        contextParameterName?: string;
        loginHosts?: string[];
        originMap?: Record<string, string>;
    } | undefined;
    contextSerializerService: FederatedLoginContextSerializerService;
    contextStorage: FederatedLoginContextStorageService;
    languageService: LanguageService;
    enabled: boolean;
    /** Is the current domain a federated login domain */
    isLoginDomain: boolean;
    protected contextValue?: FederatedLoginContext;
    get origin(): string | undefined;
    get language(): string | undefined;
    /** Returns the context serialized and encoded as a parameter string */
    getParameters(): rxjs.Observable<string>;
    detectContext(): void;
    protected checkLoginDomain(): boolean;
    /** Validate stored origin is part of the context map */
    protected validateContext(contextValue: FederatedLoginContext | undefined): FederatedLoginContext | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<FederatedLoginService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FederatedLoginService>;
}

interface OAuthTryLoginResult {
    /**
     * Result returned by native `OAuthService.tryLogin()`.
     */
    result: boolean;
    /**
     * Indicated if the event 'token_received' was emitted during `OAuthService.tryLogin()`.
     * We can use this identify that we have returned from an external authorization page to Spartacus.
     * In cases where we don't receive this event, we can deduce that the token has been obtained from storage.
     */
    tokenReceived: boolean;
}

/**
 * Wrapper service on the library OAuthService. Normalizes the lib API for services.
 * Use this service when you want to access low level OAuth library methods.
 */
declare class OAuthLibWrapperService {
    protected oAuthService: OAuthService;
    protected authConfigService: AuthConfigService;
    protected platformId: Object;
    protected winRef: WindowRef;
    private featureToggles;
    events$: Observable<OAuthEvent>;
    protected semanticPathService: SemanticPathService;
    protected federatedLoginService: FederatedLoginService;
    protected federatedLoginParamsSub: Subscription | undefined;
    protected subscription: Subscription | undefined;
    protected configInitializerService: ConfigInitializerService;
    protected initialized: ReplaySubject<void>;
    constructor(oAuthService: OAuthService, authConfigService: AuthConfigService, platformId: Object, winRef: WindowRef);
    protected initialize(): void;
    protected generateCustomerLoginConfig(): {
        scope?: string | undefined;
        redirectUri: string;
        postLogoutRedirectUri?: string | undefined;
        redirectUriAsPostLogoutRedirectUriFallback?: boolean | undefined;
        resource?: string | undefined;
        rngUrl?: string | undefined;
        oidc?: boolean | undefined;
        requestAccessToken?: boolean | undefined;
        options?: any;
        issuer: string;
        clearHashAfterLogin?: boolean | undefined;
        customTokenParameters?: string[] | undefined;
        responseType?: string | undefined;
        showDebugInformation?: boolean | undefined;
        silentRefreshRedirectUri?: string | undefined;
        silentRefreshMessagePrefix?: string | undefined;
        silentRefreshShowIFrame?: boolean | undefined;
        silentRefreshTimeout?: number | undefined;
        requireHttps?: boolean | "remoteOnly" | undefined;
        strictDiscoveryDocumentValidation?: boolean | undefined;
        jwks?: object | undefined;
        customQueryParams?: object | undefined;
        silentRefreshIFrameName?: string | undefined;
        timeoutFactor?: number | undefined;
        sessionChecksEnabled?: boolean | undefined;
        sessionCheckIntervall?: number | undefined;
        sessionCheckIFrameUrl?: string | undefined;
        sessionCheckIFrameName?: string | undefined;
        disableAtHashCheck?: boolean | undefined;
        skipSubjectCheck?: boolean | undefined;
        useIdTokenHintForSilentRefresh?: boolean | undefined;
        skipIssuerCheck?: boolean | undefined;
        fallbackAccessTokenExpirationTimeInSec?: number | undefined;
        nonceStateSeparator?: string | undefined;
        useHttpBasicAuth?: boolean | undefined;
        clockSkewInSec?: number | undefined;
        decreaseExpirationBySec?: number | undefined;
        waitForTokenInMsec?: number | undefined;
        useSilentRefresh?: any;
        disablePKCE?: boolean | undefined;
        preserveRequestedRoute?: boolean | undefined;
        disableIdTokenTimer?: boolean | undefined;
        checkOrigin?: boolean | undefined;
        openUri?: ((uri: string) => void) | undefined;
        tokenEndpoint: string;
        loginUrl: string;
        clientId: string;
        dummyClientSecret: string;
        revocationEndpoint: string;
        logoutUrl: string;
        userinfoEndpoint: string;
    };
    protected generateBaseConfig(): {
        scope?: string | undefined;
        redirectUri: string;
        postLogoutRedirectUri?: string | undefined;
        redirectUriAsPostLogoutRedirectUriFallback?: boolean | undefined;
        resource?: string | undefined;
        rngUrl?: string | undefined;
        oidc?: boolean | undefined;
        requestAccessToken?: boolean | undefined;
        options?: any;
        issuer: string;
        clearHashAfterLogin?: boolean | undefined;
        customTokenParameters?: string[] | undefined;
        responseType?: string | undefined;
        showDebugInformation?: boolean | undefined;
        silentRefreshRedirectUri?: string | undefined;
        silentRefreshMessagePrefix?: string | undefined;
        silentRefreshShowIFrame?: boolean | undefined;
        silentRefreshTimeout?: number | undefined;
        requireHttps?: boolean | "remoteOnly" | undefined;
        strictDiscoveryDocumentValidation?: boolean | undefined;
        jwks?: object | undefined;
        customQueryParams?: object | undefined;
        silentRefreshIFrameName?: string | undefined;
        timeoutFactor?: number | undefined;
        sessionChecksEnabled?: boolean | undefined;
        sessionCheckIntervall?: number | undefined;
        sessionCheckIFrameUrl?: string | undefined;
        sessionCheckIFrameName?: string | undefined;
        disableAtHashCheck?: boolean | undefined;
        skipSubjectCheck?: boolean | undefined;
        useIdTokenHintForSilentRefresh?: boolean | undefined;
        skipIssuerCheck?: boolean | undefined;
        fallbackAccessTokenExpirationTimeInSec?: number | undefined;
        nonceStateSeparator?: string | undefined;
        useHttpBasicAuth?: boolean | undefined;
        clockSkewInSec?: number | undefined;
        decreaseExpirationBySec?: number | undefined;
        waitForTokenInMsec?: number | undefined;
        useSilentRefresh?: any;
        disablePKCE?: boolean | undefined;
        preserveRequestedRoute?: boolean | undefined;
        disableIdTokenTimer?: boolean | undefined;
        checkOrigin?: boolean | undefined;
        openUri?: ((uri: string) => void) | undefined;
        tokenEndpoint: string;
        loginUrl: string;
        clientId: string;
        dummyClientSecret: string;
        revocationEndpoint: string;
        logoutUrl: string;
        userinfoEndpoint: string;
    };
    /** Applies an AuthConfig to the internal oAuth service */
    protected applyConfiguration(config: AuthConfig$1): void;
    /** Enhances the provided configuration with Shared Login Page details */
    protected augmentForSharedLoginPage(baseConfig: AuthConfig$1): Observable<AuthConfig$1>;
    protected changeClientWhenInitialize(clientId: string): void;
    /**
     * Authorize with ResourceOwnerPasswordFlow.
     *
     * @param userId
     * @param password
     *
     * @return token response from the lib
     */
    authorizeWithPasswordFlow(userId: string, password: string): Promise<TokenResponse>;
    /**
     * Refresh access_token.
     */
    refreshToken(): void;
    /**
     * Revoke access tokens and clear tokens in lib state.
     */
    revokeAndLogout(): Promise<void>;
    /**
     * Clear tokens in library state (no revocation).
     */
    logout(): void;
    /**
     * Returns Open Id token. Might be empty, when it was not requested with the `responseType` config.
     *
     * @return id token
     */
    getIdToken(): string;
    /**
     * Initialize Implicit Flow or Authorization Code flows with the redirect to OAuth login url.
     */
    initLoginFlow(): void;
    /**
     * Tries to login user based on `code` or `token` present in the url.
     *
     * @param result The result returned by `OAuthService.tryLogin()`.
     *
     * @param tokenReceived Whether the event 'token_received' is emitted during `OAuthService.tryLogin()`.
     * We can use this identify that we have returned from an external authorization page to Spartacus).
     * In cases where we don't receive this event, the token has been obtained from storage.
     */
    tryLogin(): Promise<OAuthTryLoginResult>;
    refreshAuthConfig(): void;
    changeAuthConfigClientId(clientId: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OAuthLibWrapperService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OAuthLibWrapperService>;
}

/** Wire-format wrapper for cross-tab notifications. */
interface TabNotificationWrapper<T> {
    baseSite: string;
    payload: T;
}
/**
 * Type guard: asserts a `MessageEvent` carries a value shaped like a
 * `TabNotificationWrapper`. Subclasses don't need this — it's the first
 * gate inside the abstract pipe.
 */
declare function isTabNotificationWrapperEvent(event: MessageEvent): event is MessageEvent<TabNotificationWrapper<unknown>>;
/**
 * Abstract service used to communicate with Spartacus in other browser tabs.
 *
 * Default behavior isolates events per active base site (subclasses can
 * override `isolateBySite = false` if cross-site signalling is desired).
 *
 * Subclasses provide:
 * - `channelId` — the `BroadcastChannel` name (must be unique per concern).
 * - `isPayloadOfExpectedType(payload)` — runtime check that an incoming
 *   payload matches the expected `T`. Called only after the wire-format
 *   wrapper guard has passed; the value comes straight from another tab,
 *   so trust nothing about its shape.
 */
declare abstract class AbstractBrowserTabNotificationService<T> {
    protected abstract channelId: string;
    protected isolateBySite: boolean;
    protected baseSiteService: BaseSiteService;
    protected logger: LoggerService;
    protected windowRef: WindowRef;
    protected destroyRef: DestroyRef;
    protected channel: BroadcastChannel | undefined;
    protected outbound: Subject<T>;
    protected outboundStream: Observable<[T, string]>;
    /** Raw inbound `MessageEvent`s — kept untyped until guards run. */
    protected inboundEvents$: Subject<MessageEvent<any>>;
    /** Validated, fully-typed payloads. */
    notifications$: Observable<T>;
    /**
     * Initializes the service to send and receive notification events.
     *
     * Only starts listening in a browser context. The channel is closed
     * and outbound processing is unsubscribed automatically when the
     * Angular injector is destroyed.
     */
    listen(): void;
    /**
     * Sends `data` to other tabs. No-op when `listen()` was never called
     * (e.g. running on the server, or unsupported browser): the payload
     * is dropped silently.
     */
    sendNotification(data: T): void;
    protected passesSiteIsolation(wrapper: TabNotificationWrapper<T>, currentBaseSite: string): boolean;
    /**
     * Subclass-supplied runtime check that an incoming payload is the
     * expected `T`. Called only after the wrapper-shape guard has
     * passed — so `payload` is whatever the other tab put on the wire.
     */
    protected abstract isPayloadOfExpectedType(payload: unknown): payload is T;
}

declare const authNotificationServiceChannelId = "spartacus_auth_notification";
/**
 * Cross-tab signalling service for auth events (currently: logout).
 *
 * Notifications are scoped to the active base site by default, so two
 * Spartacus storefronts served from the same origin but different
 * `baseSite`s do not see each other's auth events.
 *
 * Note: this service does NOT bridge to {@link EventService}. Each tab
 * runs its own `coreLogout()` in response to an inbound notification,
 * which causes `LogoutEvent` to fire locally via `UserAuthEventBuilder`,
 * so existing in-tab listeners (cart, checkout, configurator, …) clean
 * up automatically.
 */
declare class AuthNotificationService extends AbstractBrowserTabNotificationService<AuthNotificationType> {
    protected channelId: string;
    protected isPayloadOfExpectedType(payload: unknown): payload is AuthNotificationType;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthNotificationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthNotificationService>;
}

/**
 * This implementation is OCC specific.
 * Different backend might have completely different need regarding user id.
 * It might not need user id at all and work based on access_token.
 * To implement custom solution provide your own implementation and customize services that use UserIdService
 */
declare class UserIdService {
    private _userId;
    /**
     * Sets current user id.
     *
     * @param userId
     */
    setUserId(userId: string): void;
    /**
     * This function provides the userId the OCC calls should use, depending
     * on whether there is an active storefront session or not.
     *
     * It returns the userId of the current storefront user or 'anonymous'
     * in the case there are no signed in user in the storefront.
     *
     * The user id of a regular customer session is 'current'. In the case of an
     * asm customer emulation session, the userId will be the customerId.
     */
    getUserId(): Observable<string>;
    /**
     * Utility method if you need userId to perform single action (eg. dispatch call to API).
     *
     * @param loggedIn Set to true if you want the observable to emit id only for logged in user. Throws in case of anonymous user.
     *
     * @returns Observable that emits once and completes with the last userId value.
     */
    takeUserId(loggedIn?: boolean): Observable<string>;
    /**
     * Sets user id to the default value for logged out user.
     */
    clearUserId(): void;
    /**
     * Checks if the userId is of emulated user type.
     */
    isEmulated(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserIdService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserIdService>;
}

/**
 * Auth service for normal user authentication.
 * Use to check auth status, login/logout with different OAuth flows.
 */
declare class AuthService {
    protected store: Store<StateWithClientAuth>;
    protected userIdService: UserIdService;
    protected oAuthLibWrapperService: OAuthLibWrapperService;
    protected authStorageService: AuthStorageService;
    protected authRedirectService: AuthRedirectService;
    protected routingService: RoutingService;
    protected authMultisiteIsolationService?: AuthMultisiteIsolationService | undefined;
    protected crossSiteRequestForgeryService: CrossSiteRequestForgeryService;
    /**
     * Indicates whether the access token is being refreshed
     */
    refreshInProgress$: Observable<boolean>;
    /**
     * Indicates whether the logout is being performed
     */
    logoutInProgress$: Observable<boolean>;
    protected isUsingASMClient$: Observable<boolean>;
    protected location: Location$1;
    protected winRef: WindowRef;
    protected csrfToken$: Observable<_spartacus_core.CSRFResponse>;
    private featureToggles;
    protected authNotificationService: AuthNotificationService;
    constructor(store: Store<StateWithClientAuth>, userIdService: UserIdService, oAuthLibWrapperService: OAuthLibWrapperService, authStorageService: AuthStorageService, authRedirectService: AuthRedirectService, routingService: RoutingService, authMultisiteIsolationService?: AuthMultisiteIsolationService | undefined);
    /**
     * Check params in url and if there is an code/token then try to login with those.
     */
    checkOAuthParamsInUrl(): Promise<void>;
    /**
     * Initialize Implicit/Authorization Code flow by redirecting to OAuth server.
     */
    loginWithRedirect(): boolean;
    /**
     * Loads a new user token with Resource Owner Password Flow.
     * @param userId
     * @param password
     */
    loginWithCredentials(userId: string, password: string): Promise<void>;
    /**
     * Retrieves the CSRF (Cross-Site Request Forgery) token for the custom login form.
     *
     * @return {string} The CSRF token used for preventing cross-site request forgery attacks.
     */
    getCsrfToken(): Observable<_spartacus_core.CSRFResponse>;
    /**
     * Loads a new user token with otp tokenCode and otp tokenId.
     * @param tokenId
     * @param tokenCode
     */
    otpLoginWithCredentials(tokenId: string, tokenCode: string): Promise<void>;
    /**
     * Revokes tokens and clears state for logged user (tokens, userId).
     * To perform logout it is best to use `logout` method. Use this method with caution.
     */
    coreLogout(): Promise<void>;
    /**
     * Returns `true` if the user is logged in; and `false` if the user is anonymous.
     */
    isUserLoggedIn(): Observable<boolean>;
    /**
     * Logout a storefront customer. It will initialize logout procedure by redirecting to the `logout` endpoint.
     */
    logout(): void;
    /**
     * Start or stop the refresh process
     */
    setRefreshProgress(progress: boolean): void;
    /**
     * Start or stop the logout process
     */
    setLogoutProgress(progress: boolean): void;
    protected subscribeToAuthNotifications(): void;
    /**
     * Refreshes the CSRF token by making a request to the server.
     * This is typically used to ensure that the client has a valid CSRF token for subsequent requests,
     * especially after a user logs in or when the token is about to expire.
     * @returns {Observable<string>} An observable that emits the refreshed CSRF token.
     */
    refreshCsrfToken(): Observable<_spartacus_core.CSRFResponse>;
    /**
     * Indicates whether the ASM module is enabled.
     */
    protected isAsmEnabled(): boolean;
    /**
     * Indicates whether ASM is launched through the URL,
     * using the asm flag in the URL.
     */
    protected isLaunched(): boolean;
    /**
     * check whether try to emulate customer from deeplink
     * */
    protected isEmulateInURL(): boolean;
    /**
     * Evaluates local storage where we persist the usage of ASM.
     */
    protected isUsedBefore(): boolean;
    /**
     * Handler for notifications from other browser tabs
     */
    protected handleAuthNotification(notification: AuthNotificationType): void;
    refreshAuthConfig(): void;
    isUsingASMClient(): Observable<boolean>;
    updateIsUsingASMClient(newValue: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthService>;
}

/**
 * Checks if there is currently logged in user.
 * Use to protect pages dedicated only for logged in users.
 */
declare class AuthGuard {
    protected authService: AuthService;
    protected authRedirectService: AuthRedirectService;
    protected router: Router;
    protected semanticPathService: SemanticPathService;
    constructor(authService: AuthService, authRedirectService: AuthRedirectService, router: Router, semanticPathService: SemanticPathService);
    canActivate(): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthGuard>;
}

declare class ProtectedRoutesService {
    protected config: RoutingConfig;
    protected urlParsingService: UrlParsingService;
    private nonProtectedPaths;
    protected get routingConfig(): RoutingConfig['routing'];
    /**
     * Returns 'protected' property (boolean) from routing config
     *
     * @returns boolean
     */
    get shouldProtect(): boolean;
    constructor(config: RoutingConfig, urlParsingService: UrlParsingService);
    /**
     * Tells if the url is protected
     */
    isUrlProtected(urlSegments: string[]): boolean;
    /**
     * Tells whether the url matches at least one of the paths
     */
    protected matchAnyPath(urlSegments: string[], pathsSegments: string[][]): boolean;
    /**
     * Tells whether the url matches the path
     */
    protected matchPath(urlSegments: string[], pathSegments: string[]): boolean;
    /**
     * Returns a list of paths that are not protected
     */
    protected getNonProtectedPaths(): string[];
    /**
     * Splits the url by slashes
     */
    protected getSegments(url: string): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ProtectedRoutesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProtectedRoutesService>;
}

declare class ProtectedRoutesGuard {
    protected service: ProtectedRoutesService;
    protected authGuard: AuthGuard;
    constructor(service: ProtectedRoutesService, authGuard: AuthGuard);
    /**
     * When the anticipated url is protected, it switches to the AuthGuard. Otherwise emits true.
     */
    canActivate(route: ActivatedRouteSnapshot): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProtectedRoutesGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProtectedRoutesGuard>;
}

declare function initConfigurableRoutes(service: ConfigurableRoutesService): () => void;
declare function initSecurePortalConfig(configInitializer: SecurePortalConfigInitializer, routingConfig: RoutingConfig): ConfigInitializer | null;
declare class RoutingModule {
    static forRoot(): ModuleWithProviders<RoutingModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RoutingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RoutingModule, never, [typeof i2.StoreFeatureModule, typeof i4.EffectsFeatureModule, typeof fromNgrxRouter.StoreRouterConnectingModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RoutingModule>;
}

declare const CHANGE_NEXT_PAGE_CONTEXT = "[Router] Change Next PageContext";
declare class ChangeNextPageContext implements Action {
    payload: PageContext;
    readonly type = "[Router] Change Next PageContext";
    constructor(payload: PageContext);
}
type RoutingAction = ChangeNextPageContext;

declare const routingGroup_actions_d_CHANGE_NEXT_PAGE_CONTEXT: typeof CHANGE_NEXT_PAGE_CONTEXT;
type routingGroup_actions_d_ChangeNextPageContext = ChangeNextPageContext;
declare const routingGroup_actions_d_ChangeNextPageContext: typeof ChangeNextPageContext;
type routingGroup_actions_d_RoutingAction = RoutingAction;
declare namespace routingGroup_actions_d {
  export { routingGroup_actions_d_CHANGE_NEXT_PAGE_CONTEXT as CHANGE_NEXT_PAGE_CONTEXT, routingGroup_actions_d_ChangeNextPageContext as ChangeNextPageContext };
  export type { routingGroup_actions_d_RoutingAction as RoutingAction };
}

declare const getRouterFeatureState: MemoizedSelector<any, State>;
declare const getRouterState: MemoizedSelector<any, RouterState>;
declare const getSemanticRoute: MemoizedSelector<any, string>;
declare const getPageContext: MemoizedSelector<any, PageContext>;
declare const getNextPageContext: MemoizedSelector<any, PageContext | undefined>;
declare const isNavigating: MemoizedSelector<any, boolean>;

declare const routingGroup_selectors_d_getNextPageContext: typeof getNextPageContext;
declare const routingGroup_selectors_d_getPageContext: typeof getPageContext;
declare const routingGroup_selectors_d_getRouterFeatureState: typeof getRouterFeatureState;
declare const routingGroup_selectors_d_getRouterState: typeof getRouterState;
declare const routingGroup_selectors_d_getSemanticRoute: typeof getSemanticRoute;
declare const routingGroup_selectors_d_isNavigating: typeof isNavigating;
declare namespace routingGroup_selectors_d {
  export {
    routingGroup_selectors_d_getNextPageContext as getNextPageContext,
    routingGroup_selectors_d_getPageContext as getPageContext,
    routingGroup_selectors_d_getRouterFeatureState as getRouterFeatureState,
    routingGroup_selectors_d_getRouterState as getRouterState,
    routingGroup_selectors_d_getSemanticRoute as getSemanticRoute,
    routingGroup_selectors_d_isNavigating as isNavigating,
  };
}

declare abstract class CmsComponentAdapter {
    /**
     * Abstract method must be used to load the component for a given `id` and `PageContext`.
     * The component can be loaded from alternative backend, as long as the structure
     * converts to the `CmsStructureModel`.
     *
     * @param pageContext The `PageContext` holding the page Id.
     */
    abstract load<T extends CmsComponent>(id: string, pageContext: PageContext, fields?: string): Observable<T>;
    /**
     * Abstract method to get components by list of ids.
     *
     * @param ids
     * @param pageContext
     */
    abstract findComponentsByIds(ids: string[], pageContext: PageContext): Observable<CmsComponent[]>;
}

/**
 * Auth state synced to browser storage.
 */
interface SyncedAuthState {
    userId?: string;
    token?: AuthToken;
    redirectUrl?: string;
}
/**
 * Responsible for saving the authorization data (userId, token, redirectUrl) in browser storage.
 */
declare class AuthStatePersistenceService implements OnDestroy {
    protected statePersistenceService: StatePersistenceService;
    protected userIdService: UserIdService;
    protected authStorageService: AuthStorageService;
    protected authRedirectStorageService: AuthRedirectStorageService;
    protected subscription: Subscription;
    constructor(statePersistenceService: StatePersistenceService, userIdService: UserIdService, authStorageService: AuthStorageService, authRedirectStorageService: AuthRedirectStorageService);
    /**
     * Identifier used for storage key.
     */
    protected key: string;
    /**
     * Initializes the synchronization between state and browser storage.
     */
    initSync(): void;
    /**
     * Gets and transforms state from different sources into the form that should
     * be saved in storage.
     */
    protected getAuthState(): Observable<SyncedAuthState>;
    /**
     * Function called on each browser storage read.
     * Used to update state from browser -> state.
     */
    protected onRead(state: SyncedAuthState | undefined): void;
    /**
     * Reads synchronously state from storage and returns it.
     */
    protected readStateFromStorage(): SyncedAuthState | undefined;
    /**
     * Check synchronously in browser storage if user is logged in (required by transfer state reducer).
     * For most cases `isUserLoggedIn` from the `AuthService` should be used instead of this.
     */
    isUserLoggedIn(): boolean;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthStatePersistenceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthStatePersistenceService>;
}

/**
 * Indicates that the user has logged out
 *
 * * The event is fired even for customer emulation
 * * The event is NOT fired for a ASM support agent authentication
 */
declare class LogoutEvent extends CxEvent {
    /**
     * Event's type
     */
    static readonly type = "LogoutEvent";
}
/**
 * Indicates that the user has logged in
 *
 * * The event is fired even for customer emulation
 * * The event is NOT fired for a ASM support agent authentication
 */
declare class LoginEvent extends CxEvent {
    /**
     * Event's type
     */
    static readonly type = "LoginEvent";
}

declare class UserAuthEventBuilder {
    protected stateEventService: StateEventService;
    protected eventService: EventService;
    protected authService: AuthService;
    constructor(stateEventService: StateEventService, eventService: EventService, authService: AuthService);
    /**
     * Registers user auth events
     */
    protected register(): void;
    /**
     * Register a login event
     */
    protected registerLoginEvent(): void;
    /**
     * Register a logout event
     */
    protected registerLogoutEvent(): void;
    /**
     * Returns logout event stream
     */
    protected buildLogoutEvent(): Observable<LogoutEvent>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAuthEventBuilder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserAuthEventBuilder>;
}

declare class UserAuthEventModule {
    constructor(_userAuthEventBuilder: UserAuthEventBuilder);
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAuthEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserAuthEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserAuthEventModule>;
}

/**
 * Authentication module for a user. Handlers requests for logged in users,
 * provides authorization services and storage for tokens.
 */
declare class UserAuthModule {
    static forRoot(): ModuleWithProviders<UserAuthModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAuthModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserAuthModule, never, [typeof i1.CommonModule, typeof i2$1.OAuthModule, typeof UserAuthEventModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserAuthModule>;
}

declare class AuthModule {
    static forRoot(): ModuleWithProviders<AuthModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AuthModule, never, [typeof i1.CommonModule, typeof UserAuthModule, typeof ClientAuthModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AuthModule>;
}

declare class SiteContextRoutesHandler implements OnDestroy {
    private siteContextParams;
    private serializer;
    private injector;
    constructor(siteContextParams: SiteContextParamsService, serializer: SiteContextUrlSerializer, injector: Injector);
    private subscription;
    private contextValues;
    private router;
    private location;
    /**
     * Tells whether there is a pending navigation at the moment, so we can avoid an infinite loop caused by the cyclic dependency:
     * - `subscribeChanges` method triggers a navigation on update of site context state
     * - `subscribeRouting` method updates the site context state on navigation
     */
    private isNavigating;
    /**
     * Initializes the two-way synchronization between the site context state and the URL.
     *
     * @deprecated since 2211.32. Use `initOnce()` instead for safe idempotent initialization.
     * This method now delegates to `initOnce()` internally.
     */
    init(): void;
    /**
     * ReplaySubject to track initialization state.
     * Emits once when URL context has been read and applied.
     */
    protected initialized$: ReplaySubject<unknown>;
    /**
     * Flag to ensure init logic runs only once.
     */
    private isInitialized;
    /**
     * Initializes the URL-to-state synchronization once and returns an Observable
     * that completes when the initial URL context values have been applied.
     *
     * Safe to call multiple times - subsequent calls return the same Observable
     * without re-executing the initialization logic.
     *
     * @returns Observable that emits and completes when URL context is initialized
     */
    initOnce(): Observable<unknown>;
    /**
     * Internal initialization logic
     */
    private initInternal;
    /**
     * After each change of the site context state, it modifies the current URL in place.
     * But it happens only for the parameters configured to be persisted in the URL.
     */
    private subscribeChanges;
    /**
     * After each Angular NavigationStart event it updates the site context state based on
     * site context params encoded in the anticipated URL.
     */
    private subscribeRouting;
    /**
     * Updates the site context state based on the context params encoded in the given URL
     *
     * @param url URL with encoded context params
     */
    private setContextParamsFromRoute;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteContextRoutesHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SiteContextRoutesHandler>;
}

declare class BaseSiteInitializer {
    protected baseSiteService: BaseSiteService;
    protected configInit: ConfigInitializerService;
    siteContextRoutesHandler: SiteContextRoutesHandler;
    constructor(baseSiteService: BaseSiteService, configInit: ConfigInitializerService);
    /**
     * Initializes the value of the base site
     *
     * @returns Promise that resolves when initialization is done.
     */
    initialize(): Promise<unknown>;
    /**
     * On subscription to the returned observable:
     *
     * Sets the default value taken from config, unless the active base site has been already initialized.
     */
    protected setFallbackValue(): Observable<unknown>;
    /**
     * Sets the active base site value based on the default value from the config,
     * unless the active base site has been already initialized.
     */
    protected setDefaultFromConfig(config: SiteContextConfig): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseSiteInitializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BaseSiteInitializer>;
}

type ConfigFactory = (...props: any[]) => Config;

/**
 * Helper function to provide configuration chunk using ConfigChunk token
 *
 * To provide default configuration in libraries provideDefaultConfig should be used instead.
 *
 * @param config Config object to merge with the global configuration
 */
declare function provideConfig(config?: Config, defaultConfig?: boolean): ValueProvider;
/**
 * Helper function to provide configuration with factory function, using ConfigChunk token
 *
 * To provide default configuration in libraries provideDefaultConfigFactory should be used instead.
 *
 * @param configFactory Factory Function that will generate config object
 * @param deps Optional dependencies to a factory function
 */
declare function provideConfigFactory(configFactory: ConfigFactory, deps?: any[], defaultConfig?: boolean): FactoryProvider;
/**
 * Helper function to provide default configuration chunk using DefaultConfigChunk token
 *
 * @param config Config object to merge with the default configuration
 */
declare function provideDefaultConfig(config?: Config): ValueProvider;
/**
 * Helper function to provide default configuration with factory function, using DefaultConfigChunk token
 *
 * @param configFactory Factory Function that will generate config object
 * @param deps Optional dependencies to a factory function
 */
declare function provideDefaultConfigFactory(configFactory: ConfigFactory, deps?: any[]): FactoryProvider;

declare const ConfigValidatorToken: InjectionToken<unknown>;
/**
 * ConfigValidator is used to validate config and display warning messages in development mode.
 *
 * In case of failed validation, should return a string with error message.
 */
type ConfigValidator = (config: Config) => string | void;
/**
 * Use to probide config validation at app bootstrap (when all config chunks are merged)
 *
 * @param configValidator
 */
declare function provideConfigValidator(configValidator: ConfigValidator): Provider;
declare function validateConfig(config: Config, configValidators: ConfigValidator[], logger: LoggerService): void;

declare function configValidatorFactory(configInitializer: ConfigInitializerService, validators: ConfigValidator[]): () => void;
/**
 * Should stay private in 1.x
 * as forRoot() is used internally by ConfigInitializerModule
 *
 * issue: #5279
 */
declare class ConfigValidatorModule {
    static forRoot(): ModuleWithProviders<ConfigValidatorModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfigValidatorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfigValidatorModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfigValidatorModule>;
}

declare class ConfigurationService implements OnDestroy {
    protected rootConfig: Config;
    protected defaultConfig: Config;
    protected unifiedInjector: UnifiedInjector;
    /**
     * Will emit unified configuration when some ambient configuration will appear
     *
     * Ambient configuration can appear when we lazy load module with configuration
     */
    readonly unifiedConfig$: Observable<Config>;
    /**
     * Global application configuration
     */
    readonly config: Config;
    private readonly ambientDefaultConfig;
    private readonly ambientConfig;
    private subscription;
    constructor(rootConfig: Config, defaultConfig: Config, unifiedInjector: UnifiedInjector, config: Config);
    private feedUnifiedConfig;
    private processConfig;
    private emitUnifiedConfig;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfigurationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfigurationService>;
}

declare class ConfigModule {
    constructor(_configurationService: ConfigurationService);
    /**
     * Import ConfigModule and contribute config to the global configuration
     *
     * To provide default configuration in libraries provideDefaultConfig should be used instead.
     *
     * @param config Config object to merge with the global configuration
     */
    static withConfig(config: Config): ModuleWithProviders<ConfigModule>;
    /**
     * Import ConfigModule and contribute config to the global configuration using factory function
     *
     * To provide default configuration in libraries provideDefaultConfigFactory should be used instead.
     *
     * @param configFactory Factory function that will generate configuration
     * @param deps Optional dependencies to factory function
     */
    static withConfigFactory(configFactory: ConfigFactory, deps?: any[]): ModuleWithProviders<ConfigModule>;
    /**
     * Module with providers, should be imported only once, if possible, at the root of the app.
     *
     * @param config
     */
    static forRoot(config?: Config): ModuleWithProviders<ConfigModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfigModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfigModule>;
}

interface FeatureTogglesInterface {
    /**
     * Adds a keyboard accessible zoom button to the `ProductImageZoomViewComponent`.
     */
    a11yKeyboardAccessibleZoom?: boolean;
    /**
     * When using CartItemListComponent as an outlet ([cxOutlet]="CartOutlets.CART_ITEM_LIST"):
     * prevents the form from being recreated when neither the items nor other dependent properties (e.g., readonly) have changed.
     */
    a11yPreventCartItemsFormRedundantRecreation?: boolean;
    /**
     * Adds label to 'StoreFinderSearchComponent' store search input field.
     */
    a11yStoreFinderLabel?: boolean;
    /**
     * Moves focus to the 'Back' button when store details are shown in the
     * store finder list, so keyboard users are not left without a focused element.
     */
    a11yStoreFinderFocusOnBackButton?: boolean;
    /**
     * Enables the dedicated B2B register section on the login page,
     * replacing the CMS-driven paragraph and link.
     */
    a11yB2BRegisterComponent?: boolean;
    /**
     * Replaces buttons resembling links with tetriary buttons in the following components:
     * `AddToWishListComponent`, `ProductIntroComponent`, `ProductImageZoomTriggerComponent`
     */
    a11yLinkBtnsToTertiaryBtns?: boolean;
    /**
     * Adds horizontal padding to the 'carousel-panel' to fix the issue where the focus only covers three sides of the 'Previous slide' and 'Next slide' buttons within the carousel section.
     * Affects: CarouselComponent
     */
    a11yAddPaddingToCarouselPanel?: boolean;
    /**
     * Introduces the read more directive in product list item summary
     * Affects: ProductListItemComponent
     */
    productListItemSummaryReadMore?: boolean;
    /**
     * Fixes accessibility issue in FutureStockAccordionComponent where aria-controls
     * references a non-existent element when accordion is collapsed.
     * When enabled, content element is always in DOM but hidden when collapsed,
     * ensuring aria-controls always references a valid ID.
     * Affects: FutureStockAccordionComponent
     */
    a11yFutureStockAccordionAriaControls?: boolean;
    /**
     * Use unicode characters for ng-select dropdown carets so that OS themes can override the defaults
     * by targetting text. This is not possible when using borders to draw shapes.
     */
    a11yNgSelectUnicodeCarets?: boolean;
    /**
     * When enabled, prevents Windows high contrast mode from overriding the Spartacus theme.
     * This ensures the application maintains its intended styling when the OS accessibility
     * mode is enabled, while still allowing users to manually select Spartacus high-contrast themes.
     */
    a11yPreventWindowsHighContrastOverride?: boolean;
    /**
     * Updates recent-searches UX in `SearchBoxComponent` and CDS recent searches.
     *
     * Before (disabled):
     * - `SearchBoxComponent` can show the results panel on desktop with an empty query.
     * - Recent searches are a simple link list without removal controls.
     * - Recent searches still render when there are no suggestions or products.
     *
     * After (enabled):
     * - On desktop, the results panel renders only for a non-empty query; clearing the query clears results and closes the panel.
     * - `RecentSearchesComponent` adds per-item (X) buttons and a "Clear" action via CDS `removePhrase()` / `clearPhrases()`.
     * - Recent searches are hidden in no-results states.
     */
    searchBoxRecentSearchesRemoval?: boolean;
    /**
     * Corrects `BottomHeaderSlot` layout when CDS registers `MerchandisingCarouselComponent`
     * beside `BreadcrumbComponent` (e.g. on search results pages in sample data).
     *
     * Before (disabled):
     * - `BottomHeaderSlot` lays out all children in a single flex row with no wrapping.
     * - `cx-breadcrumb` and `cx-merchandising-carousel` each grow to ~50% of the slot width.
     * - Breadcrumb title and trail are centered only within that half, so the block looks
     *   left-aligned on the page (unlike develop without CDS, where the carousel is absent
     *   and the breadcrumb is the sole child at full width).
     * - `cx-merchandising-carousel` stays in the flex row even when it has no data and
     *   renders no inner `cx-carousel`, leaving empty space beside the breadcrumb.
     *
     * After (enabled):
     * - `cx-breadcrumb` always spans 100% of the slot width on its own row.
     * - `cx-merchandising-carousel` is shown on a separate row only when it renders an
     *   inner `cx-carousel`; otherwise the host is hidden and does not affect layout.
     */
    cdsBottomHeaderSlotAdjustPosition?: boolean;
    /**
     * When enabled, sets the default oAuth configuration to use authorization code flow with PKCE.
     * This results in a more secure authorization scheme as the default configuration.
     *
     * NOTE: This flag should only be enabled when used with a CCv2 Authorization Server running the
     * September 2025 update or higher. The CCv2 Authorization Server only supports Authorization Code
     * flow for public clients from that version and onwards.
     */
    authorizationCodeFlowByDefault?: boolean;
    /**
     * When enabled, refreshes the CSRF token before submitting the login form in the
     * Authorization Code Flow. This ensures the token is valid even if the user has
     * waited on the login page past the Authorization Server session timeout, preventing
     * an HTTP 403 response from the backend that would otherwise strand the user on a
     * backend error page.
     *
     * NOTE: Only applies when `authorizationCodeFlowByDefault` is also enabled.
     */
    authorizationCodeFlowByDefaultCsrfTokenRefresh?: boolean;
    /**
     * When this feature toggle is enabled, the navigation menu will close when clicking on the same link.
     *
     * This is to improve the user experience on mobile devices, where the menu remains open
     * after clicking on a link that navigates to the same page.
     * Affects: `NavigationUIComponent`
     */
    navigationMenuCloseOnSameLinkClick?: boolean;
    /**
     * When enabled, translates the "Password expired" error message
     * to the user's selected language using Spartacus i18n.
     * Affects: `LoginComponent`
     */
    enablePasswordExpiredErrorTranslation?: boolean;
    /**
     * shows the Quote Purchase Order Number input field in the Quote Request form
     * and in the Quote Details page
     *
     * when set to `true`, the user will be able to enter a Purchase Order Number
     * when requesting a quote and see it in the quote details
     */
    enableQuotePurchaseOrderNumber?: boolean;
    /**
     * When enabled, fixes the issue with return order returnable quantity not being displayed correctly
     * on the `ReturnOrderComponent` when navigating to the return request details page.
     * Affects: `ReturnOrderComponent`
     */
    enableReturnOrderReturnableQuantityConsigmentFallback?: boolean;
    /**
     * When enabled, the media prefix from the backend config will be used
     * when constructing media URLs in the MediaService.
     * Affects: `MediaService`
     */
    enableMediaPrefix?: boolean;
    /**
     * Fixes focus ring on store name links overflowing into the address text below.
     * Affects: StoreFinderListItemComponent
     */
    a11yStoreFinderListItemFocus?: boolean;
    /**
     * Fixes double focus indicator on the search input field in `SearchBoxComponent`
     * when navigating with the keyboard.
     * A global `input:focus` rule in forms.scss applies `visible-focus()` to the input element,
     * while `.cx-label-inner-container:focus-within` also applies it to the container,
     * resulting in two visible focus rings simultaneously.
     * When enabled, the input's own focus outline is suppressed so only the container ring is shown.
     * Affects: SearchBoxComponent
     */
    a11yFixSearchBoxDoubleFocus?: boolean;
    /**
     * Fixes keyboard focus not being visible when tabbing between some buttons
     * on Customer Ticketing dialog.
     */
    a11yCustomerTicketingVisualFocusFix?: boolean;
    /**
     * Fixes keyboard focus and screen reader date announcement for the
     * chat messaging list items. Moves tabindex and aria-label to the
     * role="listitem" element so all messages are keyboard-reachable
     * and dates are announced by VoiceOver and JAWS.
     * Affects: MessagingComponent
     */
    a11yMessagingListKeyboardFocus?: boolean;
    /**
     * Applies a `10rem` inline-start padding to the order overview cards
     * (`.cx-order-details-cards`) on large screens. When disabled, the cards are
     * not pushed inward, avoiding the horizontal shift on wide viewports.
     */
    orderOverviewCardsInlinePadding?: boolean;
    /**
     * Adds Filter By label to product facets when in desktop mode.
     */
    a11yFacetFilterByLabel?: boolean;
    /**
     * When enabled, this fixes the issue of duplicated Order History headers on the Order History page.
     */
    removeDuplicatedOrderHistoryHeader?: boolean;
    /**
     * When enabled, the organization's table component will stop re-rendering its rows each data update.
     * This improves the screen reader experience of the notification message component.
     * Affects: `NotificationMessageComponent`, `CellComponent`, `UnitDetailsComponent`, `TableComponent`
     */
    a11yCardNotificationMessage?: boolean;
    /**
     * When enabled, increases the color contrast of the close button in the
     * global message component to meet WCAG contrast requirements.
     * Affects: `GlobalMessageComponent`
     */
    a11yIncreaseContastGlobalMessageCloseButton?: boolean;
    /**
     * When enabled, allows searching cost centers by name in the organization.
     */
    enableB2BCostCenterSearch?: boolean;
    /**
     * When enabled, allows searching B2B units by name in the organization administration.
     * This search is performed on the client side since the full unit tree is already loaded.
     */
    enableB2BUnitSearch?: boolean;
    /**
     * When enabled, allows searching B2B customers by name in the organization.
     */
    enableB2BCustomerSearch?: boolean;
    /**
     * When enabled (default: true), carousel navigation buttons call preventDefault on mousedown
     * to fix unwanted blur in Safari when the carousel is inside modals or search boxes (broken by default in Safari).
     *
     * Set to `false` if you rely on custom focus listeners (e.g. addEventListener('focus', ...)) on elements
     * that contain or interact with the carousel, since preventing mousedown default can affect focus behavior.
     * Affects: `CarouselComponent` (when preventNavigationFocus input is true, e.g. in SearchBoxComponent)
     */
    a11yCarouselPreventNavigationFocus?: boolean;
    /**
     * Sets the ng-select (readonly) input value from the selected option text,
     * so that JAWS screen reader announces the selected value instead of "blank" when ngSelect's input element is in focus.
     * Affects: `NgSelectA11yDirective`
     */
    a11yNgSelectReadonlyInputValue?: boolean;
    /**
     * Fixes doubled screen reader output by providing a static title and aria-label to the password visibility toggle.
     * Affects: `PasswordVisibilityToggleComponent`
     */
    a11yPasswordVisibilityToggle?: boolean;
    /**
     * When enabled, only active currencies will be displayed in the currency selector.
     * Currencies are filtered based on the `active` property returned from the backend.
     * Affects: `CurrencyService`
     */
    showOnlyActiveCurrencies?: boolean;
    /**
     * Improves accessibility of the "Added to Cart" dialog by using a semantic h2 heading
     * instead of a div for the dialog title. This provides better screen reader navigation
     * and follows WAI-ARIA dialog pattern best practices.
     * Affects: AddedToCartDialogComponent
     */
    a11yAddedToCartDialogHeading?: boolean;
    /**
     * Ensures the facet component displays elements with proper listbox semantics.
     * The screen reader should recognize links as listbox options and display visible-focus outlines correctly.
     * Affects: FacetComponent
     */
    a11yListSemanticsForFacets?: boolean;
    /**
     * In `ActiveFacetsComponent`, announces filter changes to screen readers.
     * Before: no announcement when a filter is added or removed from the applied filters section.
     * After: an assertive `aria-live` message is read out — "Filter added: <name>" or "Filter removed: <name>".
     */
    a11yFilteredFacetAnnouncement?: boolean;
    /**
     * Hides empty outlet wrapper elements in the cart item list table when they have no content.
     * Otherwise screen readers would interpret them as extra table columns.
     * Affects: CartItemListComponent
     */
    a11yCartItemListHideEmptyOutlets?: boolean;
    /**
     * When enabled, adds arrow key navigation between reviews and uses proper list
     * semantics so screen readers announce list position
     * Affects: ProductReviewsComponent
     */
    a11yReviewsKeyboardControls?: boolean;
    /**
     * Use on existing form buttons that are programatically disabled/enabled.
     * To use, duplicate button and use false in original and true in duplicate. The duplicated button
     * should be initialized as enabled, clickable and use cx-form-errors in outcomes where original button
     * is in disabled state.
     */
    a11yCartQuickOrderFormEnableSubmitAndAddValidation?: boolean;
    /**
     * When enabled, adds vocalization of dropdown item count when dropdown gains focus.
     * Affects: cxNgSelectA11y
     */
    a11yVocalizeDropdownItemCount?: boolean;
    /**
     * When enabled, keystrokes inside an ng-select (combobox dropdown) are treated
     * as navigation rather than form filling. This preserves the focus outline
     * (removes the `mouse-focus` class) when the user opens a dropdown with the
     * mouse and then navigates with the keyboard.
     * Affects: `NgSelectA11yDirective`
     */
    a11yRestoreFocusOnNgSelect?: boolean;
    /**
     * When enabled change disabled to aria-disabled on consent management buttons to keep focus when loading state toggle
     * Affects: ConsentManagementFormComponent
     */
    a11yKeepFocusOnConsentManagementButtons?: boolean;
    /**
     * When enabled, forms using CustomFormValidators.securePasswordValidators will include:
     * CustomFormValidators.mustEndWithLegalCharacter
     */
    useEnhancedSecurePasswordValidators?: boolean;
    /**
     * When enabled, uses `POST /carts/{cartId}/applyVoucher` with the voucherId
     * in the request body instead of `POST /carts/{cartId}/vouchers?voucherId={voucherId}`.
     * Requires the corresponding OCC endpoint to be available on the backend (from 2211.28 version).
     */
    enableApplyVoucherEndpoint?: boolean;
    /**
     * When enabled, uses `POST /carts/{cartId}/removeVoucher` with the voucherId
     * in the request body instead of `DELETE /carts/{cartId}/vouchers/{voucherId}`.
     * Requires the corresponding OCC endpoint to be available on the backend (from 2211.28 version).
     */
    enableRemoveVoucherEndpoint?: boolean;
    /**
     * When enabled, shows sort fields only at the top of the table.
     * When disabled, shows sort fields at both top and bottom.
     */
    showSortFieldsOnlyAtTop?: boolean;
    /**
     * When enabled, displays required field asterisks for form fields.
     */
    showRequiredAsterisks?: boolean;
    /**
     * Preserves keyboard focus on consent checkboxes after toggling.
     * Treats Space/Enter on checkbox/radio as navigation in VisibleFocusDirective
     * and restores focus after the consent form is temporarily disabled.
     * Affects: VisibleFocusDirective, ConsentManagementFormComponent, ConsentManagementComponent
     */
    a11yConsentManagementFocusPreservation?: boolean;
    /**
     * Preserves keyboard focus on the selected delivery mode radio button
     * during checkout when navigating with the keyboard.
     * Affects: CheckoutDeliveryModeComponent, VisibleFocusDirective
     */
    a11yDeliveryModeFocusPreservation?: boolean;
    /**
     * When enabled, wraps form controls in a `<fieldset>` with `aria-labelledby`
     * referencing the visible page heading, so screen readers announce the section
     * heading when any field in the group receives focus.
     * Affects: UpdateProfileComponent, MyAccountV2ProfileComponent,
     *          UpdatePasswordComponent, MyAccountV2PasswordComponent,
     *          UpdateEmailComponent, MyAccountV2EmailComponent,
     *          ConsentManagementComponent
     */
    a11yFormFieldSectionLegend?: boolean;
    /**
     * Improve auto focus during checkout process.
     * Affects: CheckoutPaymentMethodComponent
     */
    a11yImproveCheckoutFocus?: boolean;
    /**
     * When enabled, `AuthHttpHeaderService` executes DI-provided
     * `ExpiredRefreshTokenHandler` to take over `handleExpiredRefreshToken()` behavior in case of expired refresh token scenarios.
     * It avoids the need to override the entire AuthHttpHeaderService just to handle expired refresh token scenarios in a custom way, for example by ending punchout session when it's active.
     * Affects: `AuthHttpHeaderService`
     */
    enableExpiredRefreshTokenHandlers?: boolean;
    /**
     * When enabled, sytling is changed on navigation header and menu to be more cohesive.
     */
    alignNavigationMenuWithHeader?: boolean;
    /**
     * When enabled, fixes a known issue where the cart sometimes does not reload properly on context(language or currency) change,
     * deleting items from the cart (more specifically on the following sequence : logout - log back in - context change)
     */
    enableCartReloadOnContextChange?: boolean;
    opfPaymentVerificationCheckProcessingCartOnErrorOnly?: boolean;
    /**
     * When enabled, the Quick Order search input keeps focus after
     * the reset button is cleared, instead of losing focus to the
     * next tabbable element.
     * Affects: QuickOrderFormComponent
     */
    a11yQuickOrderResetFocus?: boolean;
    /**
     * When enabled, the "Notification Channels" link in the My Coupons page
     * is styled as a link (blue, underlined) instead of plain text.
     */
    a11yCouponNotificationChannelsLinkStyling?: boolean;
    /**
     * When enabled, fixes the caret visibility on the Language and Theme selectors
     * by wrapping the select and caret icon in a container that displays the
     * focus ring around both elements instead of overlapping the caret.
     * Affects: SiteContextSelectorComponent, SiteThemeSwitcherComponent
     */
    a11ySiteContextCaretClick?: boolean;
    /**
     * When enabled, fixes a known issue where the last remembered route after logout is the route to which the logout has redirected
     */
    redirectOnlyOnTrueNavigationEnd?: boolean;
    /**
     * When enabled, sanitizes the URL used to compute the page's canonical URL
     * (in `PageLinkService.getCanonicalUrl`). The URL is parsed and validated,
     * rejecting malformed URLs and any non-`http(s)` protocols (e.g. `javascript:`,
     * `data:`), which are replaced with an empty string.
     * Affects: PageLinkService
     */
    pageLinkSanitizeCanonicalUrl?: boolean;
    /**
     * When enabled, OPF components use `DestroyRef` + `takeUntilDestroyed` for
     * subscription management instead of manual `Subscription` objects and `ngOnDestroy`.
     */
    opfUseDestroyRef?: boolean;
    /**
     * When enabled, the address book and address form support hierarchical
     * address formats (e.g. Chinese addresses), which require selecting
     * region (province), city and district as chained dropdowns,
     * and skip OCC address verification for the supported countries.
     *
     * Also makes `OccUserAddressAdapter.loadAll()` request the FULL address
     * fields set, so that nested `city` / `cityDistrict` references are returned.
     *
     * Affects:
     * - `AddressBookComponent`
     * - `AddressFormComponent`
     * - `OccUserAddressAdapter`
     */
    enableHierarchicalAddressFormat?: boolean;
    opfCheckoutUseUpdatePaymentTransaction?: boolean;
    /**
     * When enabled, adds an 8px top margin to the "Add to Wish List" button
     * for consistent spacing.
     * Affects: AddToWishListComponent
     */
    a11yAddToWishListBtnMargin?: boolean;
    /**
     * When enabled, adds an inline margin of 6px to the required asterisk
     * next to the Terms & Conditions link on the registration page.
     * Affects: RegisterComponent, OtpLoginRegisterComponent
     */
    a11yRegistrationTermsAsteriskMargin?: boolean;
    /**
     * When enabled, applies a 6px bottom margin to product names in both
     * product grid and product list items for consistent spacing.
     * Affects: ProductGridItemComponent, ProductListItemComponent
     */
    a11yProductListItemNameMargin?: boolean;
    /**
     * When enabled, logging out on a tab will issue logout on all other open tabs.  This prevents leaking
     * authenticated data through stale tabs.
     */
    propagateLogoutToAllTabs?: boolean;
    /**
     * When enabled, adds support for asynchronous configuration of the oAuth service and adds a default
     * initializer to adjust the oauth client details based on URL context parameters.
     *
     * This flag only takes effect when the flag `authorizationCodeFlowByDefault` is enabled.
     */
    asyncAuthConfigInitializer?: boolean;
    /**
     * When enabled, adds site isolation decorator to the user credentials submitted during the Custom
     * Login Page form submission.
     */
    siteIsolationForCustomLoginPage?: boolean;
    /**
     * When enabled, the navigation menu buttons (e.g. "My Account") and dropdown
     * headers activate on spacebar key *release* (`keyup`) rather than key *press*
     * (`keydown`), preventing the action from firing repeatedly while the key is
     * held down.
     * Fixes WCAG 2.5.2 (Pointer Cancellation) ACC-270.16 (Level A).
     * Affects: `NavigationUIComponent`, 'NativeSelectSpaceDirective'
     */
    a11yNavigationSpaceKeyOnKeyUp?: boolean;
    /**
     * When enabled, the storefront's active theme follows the `theme` field of
     * the active base site (configured in SAP Commerce BackOffice). The theme
     * is applied as a CSS class on the app's root element by `ThemeService`.
     *
     * Without this toggle, the CMS `theme` field is ignored whenever the
     * storefront statically configures `context.baseSite` (the common case),
     * because `SiteContextConfigInitializer` does not run in that scenario.
     *
     * Precedence: static `config.context.theme` wins, then a user-picked
     * optional theme from the Theme Switcher (e.g. high-contrast), then the
     * CMS `BaseSite.theme`.
     *
     * Affects: `SiteThemeInitializer`
     */
    applyBaseSiteThemeFromCms?: boolean;
    /**
     * When enabled, only addresses with `shippingAddress` not explicitly set to `false`
     * are shown on the B2B checkout delivery address step.
     */
    b2bCheckoutShippingAddressFilter?: boolean;
    /**
     * Refines the `cx-tab` active/hover border: anchors it to the bottom of
     * the button, and rounds its bottom corners.
     */
    improvedTabStyling?: boolean;
    /**
     * When enabled, a guest cart is merged into the user cart after login even
     * when the login uses the OAuth 2.1 authorization-code flow (which fully
     * re-bootstraps the SPA and wipes in-memory state).
     *
     * The guest cart entries are persisted to storage before the redirect and
     * re-added to the user cart after login. This is needed because the backend
     * rejects a native merge of a guest cart (`"Cart is not anonymous"`), and the
     * guest cart is no longer reachable with the user token after login.
     *
     * NOTE: Most relevant when `authorizationCodeFlowByDefault` is enabled.
     *
     * Affects: `ActiveCartService`
     */
    mergeGuestCartOnCodeFlowLogin?: boolean;
    /**
     * When enabled, triggers a full page reload after a language switch so that
     * all `href` attributes (banners, navigation links, mini-cart, login) reflect
     * the new language immediately without requiring a manual page refresh.
     *
     * During SSR the reload is skipped — the server renders the page in the
     * requested language without any reload mechanism.
     *
     * Affects: `LanguagesEffects`
     */
    reloadOnLanguageChange?: boolean;
    /**
     * When enabled, the product configurator product card action buttons are
     * consistently disabled while a configuration update round trip is in
     * progress (`disableActions$`). In particular, the multi-select "Remove"
     * (secondary) button is disabled during loading to prevent triggering a
     * concurrent, potentially conflicting request.
     *
     * Affects: `ConfiguratorAttributeProductCardComponent`
     */
    productConfiguratorConsolidatedButtonDisabling?: boolean;
    /**
     * When enabled, the form-error icon glyph (`cx-form-errors`) uses the
     * `--cx-color-danger-accent` color instead of `--cx-color-inverse`, so it
     * stays legible on the danger background in the high-contrast dark theme
     * (black glyph instead of white).
     *
     * Affects: `FormErrorsComponent`
     */
    a11yFormErrorIconContrast?: boolean;
    /**
     * When enabled, the default theme's keyboard focus indicator color
     * (`--cx-color-visual-focus`) is darkened so the focus outline of all UI
     * elements (input fields, search box, comboboxes, checkboxes, radio buttons,
     * etc.) meets the WCAG 1.4.11 non-text contrast requirement of >=3:1 against
     * the adjacent surface.
     */
    a11yFocusIndicatorContrast?: boolean;
    /**
     * When enabled, disabled action buttons (`.btn-primary`, `.btn-secondary`,
     * `.btn-tertiary`) use the new `--cx-color-disabled` token instead of
     * `--cx-color-border-focus`, so their border/background/text meet the
     * WCAG 1.4.11 3:1 (7:1 in high-contrast themes) non-text contrast
     * requirement.
     */
    a11yDisabledButtonContrast?: boolean;
    /**
     * When enabled, the address form applies the `cxFocus` directive with autofocus
     * to manage initial keyboard focus.
     *
     * Affects: `AddressFormComponent`
     */
    a11yAddressFormInitialFocus?: boolean;
    /**
     * When enabled, after navigating to a `CategoryPage` (e.g. a Product Listing Page)
     * via a header navigation link, keyboard focus moves to the first anchor inside
     * `cx-breadcrumb` (resolved via `StorefrontComponent.categoryPageFocusSelector`)
     * rather than the first focusable element in `<main>`.
     * Falls back to the existing `cx-main` skip-link target when no breadcrumb is present
     * or the destination is not a CategoryPage.
     *
     * Affects: `StorefrontComponent`
     */
    a11yFocusBreadcrumbOnNavigation?: boolean;
    /**
     * When enabled, the navigation chevron (`--list-bg`) rendered on the
     * organization (My Company) list rows and detail navigation cards uses a
     * higher-contrast stroke so it meets the WCAG 1.4.11 non-text contrast
     * requirement (>=3:1 in the default theme; 7:1 in high-contrast themes).
     * The default-theme stroke changes from `#D3D6DA` (~1.4:1) to `#556b82`
     * (~5.3:1), and dedicated black/white strokes are applied in the
     * high-contrast light/dark themes.
     *
     * Affects: `ListComponent` (`cx-org-list`)
     */
    a11yNavigationChevronContrast?: boolean;
}

/**
 * Extra Spartacus Config that can be injected in e2e tests.
 *
 * Besides being a regular Spartacus Config interface,
 * it also allows for passing any "feature toggles" via the `features` property.
 */
interface TestConfig extends Config {
    features?: Config['features'] & FeatureTogglesInterface;
}
declare const TEST_CONFIG_COOKIE_NAME: InjectionToken<string>;
/**
 * Resolves JSON config from the cookie of the given name.
 *
 * Be aware of the cookie limitations (4096 bytes).
 *
 * CAUTION: DON'T USE IT IN PRODUCTION!
 */
declare const TEST_CONFIG: InjectionToken<any>;
interface TestConfigModuleOptions {
    cookie: string;
}
/**
 * Designed/intended to provide dynamic configuration for testing scenarios ONLY (e.g. e2e tests).
 *
 * CAUTION: DON'T USE IT IN PRODUCTION! IT HASN'T BEEN REVIEWED FOR SECURITY ISSUES.
 */
declare class TestConfigModule {
    /**
     * Injects JSON config from the cookie of the given name.
     *
     * Be aware of the cookie limitations (4096 bytes).
     *
     * CAUTION: DON'T USE IT IN PRODUCTION! IT HASN'T BEEN REVIEWED FOR SECURITY ISSUES.
     */
    static forRoot(options: TestConfigModuleOptions): ModuleWithProviders<TestConfigModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TestConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TestConfigModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TestConfigModule>;
}

declare function isObject(item: any): boolean;
declare function deepMerge(target?: Record<string, unknown>, ...sources: any[]): any;

declare class StringTemplate {
    /**
     * Populates the given template with the variables provided
     *
     * @param templateString template of the OCC endpoint
     * @param templateVariables variables to replace in the template
     * @param encodeVariable encode variable before placing it in the template
     */
    static resolve(templateString: string, templateVariables: Object, encodeVariable?: boolean): string;
}

declare class CurrencyStatePersistenceService {
    protected statePersistenceService: StatePersistenceService;
    protected currencyService: CurrencyService;
    protected config: SiteContextConfig;
    constructor(statePersistenceService: StatePersistenceService, currencyService: CurrencyService, config: SiteContextConfig);
    protected initialized$: ReplaySubject<unknown>;
    initSync(): Observable<unknown>;
    protected onRead(valueFromStorage: string | undefined): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrencyStatePersistenceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrencyStatePersistenceService>;
}

declare class CurrencyInitializer {
    protected currencyService: CurrencyService;
    protected currencyStatePersistenceService: CurrencyStatePersistenceService;
    protected configInit: ConfigInitializerService;
    siteContextRoutesHandler: SiteContextRoutesHandler;
    constructor(currencyService: CurrencyService, currencyStatePersistenceService: CurrencyStatePersistenceService, configInit: ConfigInitializerService);
    /**
     * Initializes the value of the active currency.
     *
     * @returns Promise that resolves when initialization is done.
     */
    initialize(): Promise<unknown>;
    /**
     * On subscription to the returned observable:
     *
     * Sets the default value taken from config, unless the active currency has been already initialized.
     */
    protected setFallbackValue(): Observable<unknown>;
    /**
     * Sets the active currency value based on the default value from the config,
     * unless the active currency has been already initialized.
     */
    protected setDefaultFromConfig(config: SiteContextConfig): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrencyInitializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrencyInitializer>;
}

declare class LanguageStatePersistenceService {
    protected statePersistenceService: StatePersistenceService;
    protected languageService: LanguageService;
    protected config: SiteContextConfig;
    constructor(statePersistenceService: StatePersistenceService, languageService: LanguageService, config: SiteContextConfig);
    protected initialized$: ReplaySubject<unknown>;
    /**
     * Initializes the synchronization of the active language with the local storage.
     *
     * @returns Observable that emits and completes when the value is read from the storage.
     */
    initSync(): Observable<unknown>;
    protected onRead(valueFromStorage: string | undefined): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LanguageStatePersistenceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LanguageStatePersistenceService>;
}

declare class LanguageInitializer {
    protected languageService: LanguageService;
    protected languageStatePersistenceService: LanguageStatePersistenceService;
    protected configInit: ConfigInitializerService;
    siteContextRoutesHandler: SiteContextRoutesHandler;
    federatedLoginService: FederatedLoginService;
    constructor(languageService: LanguageService, languageStatePersistenceService: LanguageStatePersistenceService, configInit: ConfigInitializerService);
    /**
     * Initializes the value of the active language.
     *
     * @returns Promise that resolves when initialization is done.
     */
    initialize(): Promise<unknown>;
    /**
     * On subscription to the returned observable:
     *
     * Sets the default value taken from config, unless the active language has been already initialized.
     */
    protected setFallbackValue(): Observable<unknown>;
    /**
     * Sets the active language value based on the default value from the config,
     * unless the active language has been already initialized.
     */
    protected setDefaultFromConfig(config: SiteContextConfig): void;
    protected setFromFederatedLoginContext(): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LanguageInitializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LanguageInitializer>;
}

declare class AuthConfigInitializer implements ConfigInitializer {
    readonly scopes: string[];
    readonly configFactory: () => Promise<AuthConfig>;
    protected configInit: ConfigInitializerService;
    protected baseSiteService: BaseSiteService;
    protected siteContextParamsService: SiteContextParamsService;
    protected windowRef: WindowRef;
    protected isSSR: boolean;
    protected resolveConfig(): Observable<AuthConfig>;
    protected generateClientId(activeBaseSite: string, config: AuthConfig): string | undefined;
    protected generateRedirectUri(activeBaseSite: string, config: AuthConfig): string | undefined;
    protected baseSiteInUrl(): boolean;
    protected getDefaultRedirectUri(): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthConfigInitializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthConfigInitializer>;
}

/**
 * @deprecated since 221121.1
 * Please use the `authorizationCodeFlowByDefault` feature toggle instead.
 */
declare const USE_AUTHORIZATION_CODE_FLOW_BY_DEFAULT: InjectionToken<boolean>;

/**
 * Service to share the CSRF token from the CustomLoginGuard with the form component.
 */
declare class CsrfStateService {
    protected csrf: CSRFResponse;
    get(): CSRFResponse;
    set(value: CSRFResponse): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CsrfStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CsrfStateService>;
}

interface Translatable {
    key?: string | string[];
    params?: TranslatableParams;
    raw?: string;
}
interface TranslatableParams {
    [param: string]: any;
}
declare function isTranslatable(input: any): input is Translatable;

declare enum GlobalMessageType {
    MSG_TYPE_CONFIRMATION = "[GlobalMessage] Confirmation",
    MSG_TYPE_ERROR = "[GlobalMessage] Error",
    MSG_TYPE_INFO = "[GlobalMessage] Information",
    MSG_TYPE_WARNING = "[GlobalMessage] Warning",
    MSG_TYPE_ASSISTIVE = "[GlobalMessage] Assistive"
}
interface GlobalMessage {
    text: Translatable;
    type: GlobalMessageType;
    timeout?: number;
}

type GlobalMessageTypeConfig = {
    timeout?: number;
};
declare abstract class GlobalMessageConfig {
    globalMessages?: {
        [GlobalMessageType.MSG_TYPE_CONFIRMATION]?: GlobalMessageTypeConfig;
        [GlobalMessageType.MSG_TYPE_INFO]?: GlobalMessageTypeConfig;
        [GlobalMessageType.MSG_TYPE_ERROR]?: GlobalMessageTypeConfig;
        [GlobalMessageType.MSG_TYPE_WARNING]?: GlobalMessageTypeConfig;
        [GlobalMessageType.MSG_TYPE_ASSISTIVE]?: GlobalMessageTypeConfig;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<GlobalMessageConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GlobalMessageConfig>;
}
declare module './spartacus-core' {
    interface Config extends GlobalMessageConfig {
    }
}

declare const GLOBAL_MESSAGE_FEATURE = "global-message";
interface StateWithGlobalMessage {
    [GLOBAL_MESSAGE_FEATURE]: GlobalMessageState;
}
interface GlobalMessageState {
    entities: GlobalMessageEntities;
}
interface GlobalMessageEntities {
    [messageType: string]: Translatable[];
}

declare class GlobalMessageService {
    protected store: Store<StateWithGlobalMessage>;
    constructor(store: Store<StateWithGlobalMessage>);
    /**
     * Get all global messages
     */
    get(): Observable<GlobalMessageEntities>;
    /**
     * Add one message into store
     * @param text: string | Translatable
     * @param type: GlobalMessageType object
     * @param timeout: number
     */
    add(text: string | Translatable, type: GlobalMessageType, timeout?: number): void;
    /**
     * Remove message(s) from store
     * @param type: GlobalMessageType
     * @param index:optional. Without it, messages will be removed by type; otherwise,
     * message will be removed from list by index.
     */
    remove(type: GlobalMessageType, index?: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GlobalMessageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GlobalMessageService>;
}

declare class GlobalMessageStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GlobalMessageStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GlobalMessageStoreModule, never, [typeof StateModule, typeof i2.StoreFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GlobalMessageStoreModule>;
}

declare class GlobalMessageModule {
    static forRoot(): ModuleWithProviders<GlobalMessageModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GlobalMessageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GlobalMessageModule, never, [typeof GlobalMessageStoreModule, typeof i4.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GlobalMessageModule>;
}

declare enum HttpResponseStatus {
    UNKNOWN = -1,
    BAD_REQUEST = 400,
    UNAUTHORIZED = 401,
    FORBIDDEN = 403,
    NOT_FOUND = 404,
    CONFLICT = 409,
    BAD_GATEWAY = 502,
    GATEWAY_TIMEOUT = 504,
    INTERNAL_SERVER_ERROR = 500
}

declare enum Priority {
    /**
     * Used as fallback, when there is no other matches
     */
    FALLBACK = -50,
    /**
     * Used mainly in libraries, easy overridable
     */
    LOW = -10,
    /**
     * Default priority
     */
    NORMAL = 0,
    /**
     * High priority for matches that should take precedence
     */
    HIGH = 10
}
/**
 * Base interface for implementing applicables in a consistent way
 *
 * Applicables are mainly used to find best matching one from multi provided
 * classes, like handlers, resolvers, etc.
 */
interface Applicable {
    /**
     * Returns true if applicable can be used to handle specified condition
     */
    hasMatch?(...params: any[]): boolean;
    /**
     * Returns priority or score for specified applicable.
     *
     * If multiple applicables can be applied to specified condition, the one
     * with highest priority or score wins.
     */
    getPriority?(...params: any[]): Priority | number;
}
/**
 * Helper logic to resolve best matching Applicable
 *
 * Finding best match is a two step process:
 * 1. Find all matching applicables
 *    - all applicables for which hasMatch(...matchParams) will return true
 *    - all applicables without hasMatch method (implicit always match)
 * 2. Find the applicable with highest priority
 *    - applicable with highest getPriority(...priorityParams) will win
 *    - applicable without getPriority method is treated as Priority.NORMAL or 0
 *    - applicables with the same priority are sorted by order of providers, the applicable that was provided later wins
 *
 * @param applicables - array or applicable-like instances
 * @param matchParams - array of parameters passed for hasMatch calls
 * @param priorityParams - array of parameters passed for getPriority calls
 */
declare function resolveApplicable<T extends Applicable>(applicables: T[], matchParams?: any[], priorityParams?: any[]): T | undefined;

declare abstract class HttpErrorHandler implements Applicable {
    protected globalMessageService: GlobalMessageService;
    protected platformId?: Object | undefined;
    constructor(globalMessageService: GlobalMessageService, platformId?: Object | undefined);
    /**
     * The http response status number which is handled by this handler.
     * Implementations can set the response status number, i.e. 404, so that
     * the handler can be found by the error interceptor.
     */
    responseStatus?: number;
    /**
     * Handles the error response for the response status that is register for the handler
     * @param { HttpRequest<any> } request : http request
     * @param { HttpErrorResponse } errorResponse : Http error response
     */
    abstract handleError(request: HttpRequest<any>, errorResponse: HttpErrorResponse): void;
    /**
     * Error handlers are matched by the error `responseStatus` (i.e. 404). On top of the matching status
     * a priority can be added to distinguish multiple handles for the same response status.
     */
    hasMatch(errorResponse: HttpErrorResponse): boolean;
    /**
     * Converts error description to translation key format.
     *
     * Example: 'User is disabled' will be transformed to 'user_is_disabled'.
     */
    getErrorTranslationKey(reason: string): string;
    abstract getPriority?(): Priority;
    /**
     * Returns true when invoked on the server (SSR).
     *
     * Added in 3.2, depends on the injected `platformId`.
     */
    protected isSsr(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<HttpErrorHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HttpErrorHandler>;
}

declare class BadGatewayHandler extends HttpErrorHandler {
    responseStatus: HttpResponseStatus;
    handleError(): void;
    getPriority(): Priority;
    static ɵfac: i0.ɵɵFactoryDeclaration<BadGatewayHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BadGatewayHandler>;
}

declare class BadRequestHandler extends HttpErrorHandler {
    responseStatus: HttpResponseStatus;
    private featureToggles;
    handleError(request: HttpRequest<any>, response: HttpErrorResponse): void;
    protected handleBadPassword(request: HttpRequest<any>, response: HttpErrorResponse): void;
    protected handleBadLoginResponse(_request: HttpRequest<any>, response: HttpErrorResponse): void;
    protected handleValidationError(_request: HttpRequest<any>, response: HttpErrorResponse): void;
    protected handleValidationErrorIleggalArgument(_request: HttpRequest<any>, response: HttpErrorResponse): void;
    protected handleGuestDuplicateEmail(_request: HttpRequest<any>, response: HttpErrorResponse): void;
    protected handleUnknownIdentifierError(_request: HttpRequest<any>, response: HttpErrorResponse): void;
    protected getErrors(response: HttpErrorResponse): ErrorModel[];
    getPriority(): Priority;
    static ɵfac: i0.ɵɵFactoryDeclaration<BadRequestHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BadRequestHandler>;
}

declare class ConflictHandler extends HttpErrorHandler {
    responseStatus: HttpResponseStatus;
    handleError(): void;
    getPriority(): Priority;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConflictHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConflictHandler>;
}

declare class ForbiddenHandler extends HttpErrorHandler {
    protected globalMessageService: GlobalMessageService;
    protected authService: AuthService;
    protected occEndpoints: OccEndpointsService;
    responseStatus: HttpResponseStatus;
    handleError(request: HttpRequest<any>): void;
    getPriority(): Priority;
    constructor(globalMessageService: GlobalMessageService, authService: AuthService, occEndpoints: OccEndpointsService);
    static ɵfac: i0.ɵɵFactoryDeclaration<ForbiddenHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ForbiddenHandler>;
}

declare class GatewayTimeoutHandler extends HttpErrorHandler {
    responseStatus: HttpResponseStatus;
    handleError(): void;
    getPriority(): Priority;
    static ɵfac: i0.ɵɵFactoryDeclaration<GatewayTimeoutHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GatewayTimeoutHandler>;
}

declare class InternalServerErrorHandler extends HttpErrorHandler {
    responseStatus: HttpResponseStatus;
    handleError(): void;
    getPriority(): Priority;
    static ɵfac: i0.ɵɵFactoryDeclaration<InternalServerErrorHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InternalServerErrorHandler>;
}

declare class NotFoundHandler extends HttpErrorHandler {
    responseStatus: HttpResponseStatus;
    handleError(): void;
    getPriority(): Priority;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotFoundHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NotFoundHandler>;
}

/**
 * Unknown Error Handler works as an fallback, to handle errors that were
 * not handled by any other error handlers
 */
declare class UnknownErrorHandler extends HttpErrorHandler {
    protected logger: LoggerService;
    responseStatus: HttpResponseStatus;
    /**
     * hasMatch always returns true, to mach all errors
     */
    hasMatch(_errorResponse: HttpErrorResponse): boolean;
    handleError(_request: HttpRequest<any>, errorResponse: HttpErrorResponse): void;
    /**
     * Fallback priority assures that the handler is used as a last resort
     */
    getPriority(): Priority;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnknownErrorHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnknownErrorHandler>;
}

declare const errorHandlers: Provider[];
declare const httpErrorInterceptors: Provider[];

declare const ADD_MESSAGE = "[Global-message] Add a Message";
declare const REMOVE_MESSAGE = "[Global-message] Remove a Message";
declare const REMOVE_MESSAGES_BY_TYPE = "[Global-message] Remove messages by type";
declare class AddMessage implements Action {
    payload: GlobalMessage;
    readonly type = "[Global-message] Add a Message";
    constructor(payload: GlobalMessage);
}
declare class RemoveMessage implements Action {
    payload: {
        type: GlobalMessageType;
        index: number;
    };
    readonly type = "[Global-message] Remove a Message";
    constructor(payload: {
        type: GlobalMessageType;
        index: number;
    });
}
declare class RemoveMessagesByType implements Action {
    payload: GlobalMessageType;
    readonly type = "[Global-message] Remove messages by type";
    constructor(payload: GlobalMessageType);
}
type GlobalMessageAction = AddMessage | RemoveMessage | RemoveMessagesByType;

declare const globalMessageGroup_actions_d_ADD_MESSAGE: typeof ADD_MESSAGE;
type globalMessageGroup_actions_d_AddMessage = AddMessage;
declare const globalMessageGroup_actions_d_AddMessage: typeof AddMessage;
type globalMessageGroup_actions_d_GlobalMessageAction = GlobalMessageAction;
declare const globalMessageGroup_actions_d_REMOVE_MESSAGE: typeof REMOVE_MESSAGE;
declare const globalMessageGroup_actions_d_REMOVE_MESSAGES_BY_TYPE: typeof REMOVE_MESSAGES_BY_TYPE;
type globalMessageGroup_actions_d_RemoveMessage = RemoveMessage;
declare const globalMessageGroup_actions_d_RemoveMessage: typeof RemoveMessage;
type globalMessageGroup_actions_d_RemoveMessagesByType = RemoveMessagesByType;
declare const globalMessageGroup_actions_d_RemoveMessagesByType: typeof RemoveMessagesByType;
declare namespace globalMessageGroup_actions_d {
  export { globalMessageGroup_actions_d_ADD_MESSAGE as ADD_MESSAGE, globalMessageGroup_actions_d_AddMessage as AddMessage, globalMessageGroup_actions_d_REMOVE_MESSAGE as REMOVE_MESSAGE, globalMessageGroup_actions_d_REMOVE_MESSAGES_BY_TYPE as REMOVE_MESSAGES_BY_TYPE, globalMessageGroup_actions_d_RemoveMessage as RemoveMessage, globalMessageGroup_actions_d_RemoveMessagesByType as RemoveMessagesByType };
  export type { globalMessageGroup_actions_d_GlobalMessageAction as GlobalMessageAction };
}

declare const getGlobalMessageState: MemoizedSelector<StateWithGlobalMessage, GlobalMessageState>;

declare const getGlobalMessageEntities: MemoizedSelector<StateWithGlobalMessage, GlobalMessageEntities>;
declare const getGlobalMessageEntitiesByType: (type: GlobalMessageType) => MemoizedSelector<StateWithGlobalMessage, Translatable[]>;
declare const getGlobalMessageCountByType: (type: GlobalMessageType) => MemoizedSelector<StateWithGlobalMessage, number>;

declare const globalMessageGroup_selectors_d_getGlobalMessageCountByType: typeof getGlobalMessageCountByType;
declare const globalMessageGroup_selectors_d_getGlobalMessageEntities: typeof getGlobalMessageEntities;
declare const globalMessageGroup_selectors_d_getGlobalMessageEntitiesByType: typeof getGlobalMessageEntitiesByType;
declare const globalMessageGroup_selectors_d_getGlobalMessageState: typeof getGlobalMessageState;
declare namespace globalMessageGroup_selectors_d {
  export {
    globalMessageGroup_selectors_d_getGlobalMessageCountByType as getGlobalMessageCountByType,
    globalMessageGroup_selectors_d_getGlobalMessageEntities as getGlobalMessageEntities,
    globalMessageGroup_selectors_d_getGlobalMessageEntitiesByType as getGlobalMessageEntitiesByType,
    globalMessageGroup_selectors_d_getGlobalMessageState as getGlobalMessageState,
  };
}

/**
 * This guard requests the CSRF token required for the custom login form as a way
 * to check for a valid Authorization Server session.
 *
 * It will redirect the user to restart the auth flow on failed requests, keeping
 * track of the redirects to avoid creating an infinite loop of redirects.
 */
declare class CustomLoginGuard implements CanActivate {
    protected authService: AuthService;
    protected authConfigService: AuthConfigService;
    protected router: Router;
    protected semanticPathService: SemanticPathService;
    protected windowRef: WindowRef;
    protected storage: Storage | undefined;
    protected globalMessageService: GlobalMessageService;
    protected csrfStateService: CsrfStateService;
    protected federatedLoginService: FederatedLoginService;
    canActivate(): Observable<GuardResult>;
    protected getRedirectCount(): number;
    protected setRedirectCount(count: number): void;
    protected clearRedirectCount(): void;
    protected createRoute(cxRoute: string): Observable<_angular_router.UrlTree>;
    protected showErrorMessage(message: Translatable): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomLoginGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomLoginGuard>;
}

/**
 * Protects routes on the federated login domain.
 *
 * When the current domain is a federated login domain (i.e. `FederatedLoginService.isLoginDomain`
 * is true), only routes whose Spartacus routing config entry has `authFlow: true` are accessible.
 * Any attempt to navigate to a non-auth-flow route is redirected to the equivalent page on the
 * origin storefront, falling back to the Spartacus `home` route when no origin is available.
 */
declare class FederatedLoginGuard implements CanActivate {
    protected federatedLoginService: FederatedLoginService;
    protected authFlowRoutesService: AuthFlowRoutesService;
    protected semanticPathService: SemanticPathService;
    protected router: Router;
    protected windowRef: WindowRef;
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<GuardResult>;
    /**
     * Determines if route should be served on the login domain.
     *
     * Default is only routes configured with `authFlow` set to `true`.
     */
    protected isValidRoute(_route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean;
    /**
     * Handles attempts to visit a an invalid route on the login domain.
     */
    protected handleInvalidRoute(_route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<GuardResult>;
    /**
     * Determines what to do for a route when there is a valid base site but no origin context available.
     *
     * Default behavior will attempt to route to `{ cxRoute: 'notFound' }`.
     */
    protected handleInvalidSiteContext(_route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FederatedLoginGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FederatedLoginGuard>;
}

/**
 * Checks if there isn't any logged in user.
 * Use to protect pages dedicated only for guests (eg. login page).
 */
declare class NotAuthGuard {
    protected authService: AuthService;
    protected semanticPathService: SemanticPathService;
    protected router: Router;
    constructor(authService: AuthService, semanticPathService: SemanticPathService, router: Router);
    canActivate(): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotAuthGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NotAuthGuard>;
}

/**
 * Handler for expired refresh token scenarios.
 * Example: when a punchout session is active, this handler can use
 * `handleExpiredRefreshTokenIfApplicable` to take over
 * `handleExpiredRefreshToken()` behavior, for example by ending the punchout
 * session.
 */
interface ExpiredRefreshTokenHandler {
    handleExpiredRefreshTokenIfApplicable?(): Observable<boolean>;
}
declare const EXPIRED_REFRESH_TOKEN_HANDLERS: InjectionToken<ExpiredRefreshTokenHandler[]>;

declare const DEFAULT_AUTH_HTTP_HEADER_SERVICE: InjectionToken<AuthHttpHeaderService>;
/**
 * Optional delegation hook for `AuthHttpHeaderService`.
 * Feature libraries (e.g. ASM) can provide their own `AuthHttpHeaderService`
 * override under this token so that other libs (e.g. Punchout) can delegate
 * to it without a hard compile-time import of the providing library.
 */
declare const DELEGATED_AUTH_HTTP_HEADER_SERVICE: InjectionToken<AuthHttpHeaderService>;
/**
 * Extendable service for `AuthInterceptor`.
 */
declare class AuthHttpHeaderService implements OnDestroy {
    protected authService: AuthService;
    protected authStorageService: AuthStorageService;
    protected oAuthLibWrapperService: OAuthLibWrapperService;
    protected routingService: RoutingService;
    protected occEndpoints: OccEndpointsService;
    protected globalMessageService: GlobalMessageService;
    protected authRedirectService: AuthRedirectService;
    private featureToggles;
    /**
     * Starts the refresh of the access token
     */
    protected refreshTokenTrigger$: Subject<AuthToken | undefined>;
    /**
     * Internal token streams which reads the latest from the storage.
     * Emits the token or `undefined`
     */
    protected token$: Observable<AuthToken | undefined>;
    /**
     * Compares the previous and the new token in order to stop the refresh or logout processes
     */
    protected stopProgress$: Observable<[AuthToken | undefined, AuthToken | undefined]>;
    /**
     * Refreshes the token only if currently there's no refresh nor logout in progress.
     * If the refresh token is not present, it triggers the logout process
     */
    protected refreshToken$: Observable<[AuthToken | undefined, boolean, boolean]>;
    /**
     * Kicks of the process by listening to the new token and refresh token processes.
     * This token should be used when retrying the failed http request.
     */
    protected tokenToRetryRequest$: Observable<AuthToken | undefined>;
    protected subscriptions: Subscription;
    protected handlers: ExpiredRefreshTokenHandler[];
    constructor(authService: AuthService, authStorageService: AuthStorageService, oAuthLibWrapperService: OAuthLibWrapperService, routingService: RoutingService, occEndpoints: OccEndpointsService, globalMessageService: GlobalMessageService, authRedirectService: AuthRedirectService);
    /**
     * Checks if request should be handled by this service (if it's OCC call).
     */
    shouldCatchError(request: HttpRequest<any>): boolean;
    shouldAddAuthorizationHeader(request: HttpRequest<any>): boolean;
    /**
     * Adds `Authorization` header for OCC calls.
     */
    alterRequest(request: HttpRequest<any>, token?: AuthToken): HttpRequest<any>;
    protected isOccUrl(url: string): boolean;
    protected isBaseSitesRequest(request: HttpRequest<any>): boolean;
    protected getAuthorizationHeader(request: HttpRequest<any>): string | null;
    protected createAuthorizationHeader(token?: AuthToken): {
        Authorization: string;
    } | {};
    /**
     * Refreshes access_token and then retries the call with the new token.
     */
    handleExpiredAccessToken(request: HttpRequest<any>, next: HttpHandler, initialToken: AuthToken | undefined): Observable<HttpEvent<AuthToken>>;
    /**
     * Logout user, redirected to login page and informs about expired session.
     */
    handleExpiredRefreshToken(): void;
    protected handleExpiredRefreshTokenFallback(): void;
    /**
     * Resolves handler-specific refresh token expiration handling.
     * This approach allows features like Punchout to handle expired tokens
     * without needing to override the entire AuthHttpHeaderService via DI,
     * which would create a conflict with other service overrides (e.g., ASM).
     */
    protected resolveHandlerRefreshTokenHandling(handler: ExpiredRefreshTokenHandler): Observable<boolean>;
    protected get authHttpHeaderHandlers(): ExpiredRefreshTokenHandler[];
    /**
     * Emits the token or `undefined` only when the refresh or the logout processes are finished.
     */
    getStableToken(): Observable<AuthToken | undefined>;
    /**
     * Returns a valid access token.
     * It will attempt to refresh it if the current one expired; emits after the new one is retrieved.
     */
    protected getValidToken(requestToken: AuthToken | undefined): Observable<AuthToken | undefined>;
    protected createNewRequestWithNewToken(request: HttpRequest<any>, token: AuthToken): HttpRequest<any>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthHttpHeaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthHttpHeaderService>;
}

/**
 * Responsible for catching auth errors and providing `Authorization` header for API calls.
 * Uses AuthHttpHeaderService for request manipulation and error handling. Interceptor only hooks into request send/received events.
 */
declare class AuthInterceptor implements HttpInterceptor {
    protected authHttpHeaderService: AuthHttpHeaderService;
    protected authConfigService: AuthConfigService;
    constructor(authHttpHeaderService: AuthHttpHeaderService, authConfigService: AuthConfigService);
    intercept(httpRequest: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    protected errorIsInvalidToken(errResponse: HttpErrorResponse): boolean;
    protected errorIsInvalidGrant(errResponse: HttpErrorResponse): boolean;
    protected isExpiredToken(resp: HttpErrorResponse): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthInterceptor>;
}

/**
 * This interceptor is dedicated for Hybris OAuth server which requires `Authorization` header for revoke token calls.
 */
declare class TokenRevocationInterceptor implements HttpInterceptor {
    protected authStorageService: AuthStorageService;
    protected authConfigService: AuthConfigService;
    constructor(authStorageService: AuthStorageService, authConfigService: AuthConfigService);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    protected isTokenRevocationRequest(request: HttpRequest<any>): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<TokenRevocationInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TokenRevocationInterceptor>;
}

declare const LOGIN = "[Auth] Login";
declare const LOGOUT = "[Auth] Logout";
declare class Login implements Action {
    readonly type = "[Auth] Login";
}
declare class Logout implements Action {
    readonly type = "[Auth] Logout";
}
type LoginLogoutAction = Login | Logout;

declare const authGroup_actions_d_LOGIN: typeof LOGIN;
declare const authGroup_actions_d_LOGOUT: typeof LOGOUT;
type authGroup_actions_d_Login = Login;
declare const authGroup_actions_d_Login: typeof Login;
type authGroup_actions_d_LoginLogoutAction = LoginLogoutAction;
type authGroup_actions_d_Logout = Logout;
declare const authGroup_actions_d_Logout: typeof Logout;
declare namespace authGroup_actions_d {
  export { authGroup_actions_d_LOGIN as LOGIN, authGroup_actions_d_LOGOUT as LOGOUT, authGroup_actions_d_Login as Login, authGroup_actions_d_Logout as Logout };
  export type { authGroup_actions_d_LoginLogoutAction as LoginLogoutAction };
}

declare const OAUTH_REDIRECT_FLOW_KEY = "oAuthRedirectCodeFlow";

declare class OccCmsComponentAdapter implements CmsComponentAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected readonly userIdService: UserIdService;
    protected headers: HttpHeaders;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    load<T extends CmsComponent>(id: string, pageContext: PageContext): Observable<T>;
    findComponentsByIds(ids: string[], pageContext: PageContext, fields?: string, currentPage?: number, pageSize?: number, sort?: string): Observable<CmsComponent[]>;
    protected getComponentEndPoint(id: string, pageContext: PageContext, userId?: string): string;
    protected getComponentsEndpoint(requestParams: any, fields: string, userId?: string): string;
    protected getPaginationParams(currentPage?: number, pageSize?: number, sort?: string): {
        [key: string]: string;
    };
    protected getContextParams(pageContext: PageContext): {
        [key: string]: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCmsComponentAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCmsComponentAdapter>;
}

/**
 * Before 1905, the OCC CMS component API required was using POST method
 * to load a (potentially large) number of components. With 1905, the endpoint
 * evaluated to use GET. Switching from POST to GET has been initially implemented
 * with the `legacy` flag, but from version 3.0 onwards, we're moving the
 * implementation to this optional Adapter.
 *
 * If you like to connect to a pre 1905 version, you can provide this adapter for the
 * `CmsComponentAdapter` injection token.
 */
declare class LegacyOccCmsComponentAdapter extends OccCmsComponentAdapter {
    findComponentsByIds(ids: string[], pageContext: PageContext, fields?: string, currentPage?: number, pageSize?: number, sort?: string): Observable<CmsComponent[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LegacyOccCmsComponentAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LegacyOccCmsComponentAdapter>;
}

/**
 * Abstract class that can be used to implement custom loader logic
 * in order to load CMS structure from third-party CMS system.
 */
declare abstract class CmsPageAdapter {
    /**
     * Abstract method must be used to load the page structure for a given `PageContext`.
     * The page can be loaded from alternative sources, as long as the structure
     * converts to the `CmsStructureModel`.
     *
     * @param pageContext The `PageContext` holding the page Id.
     */
    abstract load(pageContext: PageContext): Observable<CmsStructureModel>;
}

interface OccCmsPageRequest {
    pageLabelOrId?: string;
    pageType?: PageType;
    code?: string;
    fields?: string;
}
declare class OccCmsPageAdapter implements CmsPageAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected readonly userIdService: UserIdService;
    protected headers: HttpHeaders;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    /**
     * @override returns the OCC CMS page data for the given context and converts
     * the data by any configured `CMS_PAGE_NORMALIZER`.
     */
    load(pageContext: PageContext): Observable<CmsStructureModel>;
    /**
     * The OCC CMS API allows to query pages by a combination of pageType, label and code.
     *
     * When a `ContentPage` is requested, we use the `pageLabelOrId`:
     *
     * ```
     * "/pages?pageLabelOrId=/my-page&pageType=ContentPage"
     * ```
     *
     * Other pages are queried by code:
     *
     * ```
     * "/pages?code=1234&pageType=ProductPage"
     * ```
     *
     * The page context is ignored for a home page request or in case of a
     * `smartedit-preview` request.
     */
    protected getPagesRequestParams(context: PageContext): OccCmsPageRequest;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCmsPageAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCmsPageAdapter>;
}

declare class OccCostCenterNormalizer implements Converter<Occ.CostCenter, CostCenter> {
    convert(source: Occ.CostCenter, target?: CostCenter): CostCenter;
    /**
     * Returns the boolean value for a string property that is supposed
     * to be of type boolean.
     */
    protected normalizeBoolean(property: string | boolean | undefined): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCostCenterNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCostCenterNormalizer>;
}

declare class OccCostCenterSerializer implements Converter<CostCenter, Occ.CostCenter> {
    convert(source: CostCenter, target?: Occ.CostCenter): Occ.CostCenter;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCostCenterSerializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCostCenterSerializer>;
}

declare class OccCostCenterListNormalizer implements Converter<Occ.CostCentersList, EntitiesModel<CostCenter>> {
    private converter;
    constructor(converter: ConverterService);
    convert(source: Occ.CostCentersList, target?: EntitiesModel<CostCenter>): EntitiesModel<CostCenter>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCostCenterListNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCostCenterListNormalizer>;
}

declare class CostCenterOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CostCenterOccModule, never, [typeof i1.CommonModule, typeof ConfigModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CostCenterOccModule>;
}

declare class ProductImageNormalizer implements Converter<Occ.Product, Product> {
    protected config: OccConfig;
    constructor(config: OccConfig);
    convert(source: Occ.Product, target?: Product): Product;
    /**
     * @desc
     * Creates the image structure we'd like to have. Instead of
     * having a single list with all images despite type and format
     * we create a proper structure. With that we can do:
     * - images.primary.thumnail.url
     * - images.GALLERY[0].thumnail.url
     */
    normalize(source: Occ.Image[]): Images;
    protected getImageContainer(isList: boolean, images: Images, image: Occ.Image | any): ImageGroup;
    protected getImageGroups(images: Images, image: Occ.Image | any): ImageGroup[];
    /**
     * Traditionally, in an on-prem world, medias and other backend related calls
     * are hosted at the same platform, but in a cloud setup, applications are are
     * typically distributed cross different environments. For media, we use the
     * `backend.media.baseUrl` by default, but fallback to `backend.occ.baseUrl`
     * if none provided.
     */
    private normalizeImageUrl;
    private hasGalleryIndex;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductImageNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductImageNormalizer>;
}

declare class ProductReferenceNormalizer implements Converter<Occ.Product, Product> {
    convert(source: Occ.Product, target?: Product): Product;
    /**
     * @desc
     * Creates the reference structure we'd like to have. Instead of
     * having a single list with all references we create a proper structure.
     * With that we have a semantic API for the clients
     * - product.references.SIMILAR[0].code
     */
    protected normalize(source: Occ.ProductReference[]): ProductReferences;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductReferenceNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductReferenceNormalizer>;
}

declare class OccProductSearchPageNormalizer implements Converter<Occ.ProductSearchPage, ProductSearchPage> {
    private converterService;
    constructor(converterService: ConverterService);
    /**
     * Specifies the minimal number of top values in case
     * non have been setup by the business.
     */
    protected DEFAULT_TOP_VALUES: number;
    convert(source: Occ.ProductSearchPage, target?: ProductSearchPage): ProductSearchPage;
    protected normalizeFacets(target: ProductSearchPage): void;
    /**
     * The (current) backend returns facets with values that do not contribute
     * to the facet navigation much, as the number in the result list will not get
     * behavior, see https://jira.hybris.com/browse/CS-427.
     *
     * As long as this is not in place, we manually filter the facet from the list;
     * any facet that does not have a count < the total results will be dropped from
     * the facets.
     */
    protected normalizeUselessFacets(target: ProductSearchPage): void;
    protected normalizeFacetValues(target: ProductSearchPage): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccProductSearchPageNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccProductSearchPageNormalizer>;
}

declare class OccProductReferencesListNormalizer implements Converter<Occ.ProductReferenceList, ProductReference[]> {
    private converter;
    constructor(converter: ConverterService);
    convert(source: Occ.ProductReferenceList, target?: ProductReference[]): ProductReference[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OccProductReferencesListNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccProductReferencesListNormalizer>;
}

declare class ProductNameNormalizer implements Converter<Occ.Product, Product> {
    protected config: OccConfig;
    constructor(config: OccConfig);
    convert(source: Occ.Product, target?: Product): Product;
    /**
     * Sanitizes the name so that the name doesn't contain html elements.
     */
    protected normalize(name: string): string;
    /**
     * A pretty url should not have any encoded characters, which is why we replace
     * the following character in the product title.
     *
     * See https://developers.google.com/maps/documentation/urls/url-encoding for more
     * information on the characters.
     */
    protected reservedSlugCharacters: string;
    protected slugChar: string;
    private slugRegex;
    private sanitizeMultipleSlugChars;
    /**
     * Provides a title slug for the pretty URL.
     *
     * The name is sanitized from html, trimmed, converted to lowercase and special characters
     * which are encoded are replaced by the slug char (dash by default).
     */
    protected normalizeSlug(name: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductNameNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductNameNormalizer>;
}

declare abstract class ProductReferencesAdapter {
    /**
     * Abstract method used to load product references for a given product.
     * References can be loaded from alternative sources, as long as the structure
     * converts to the `ProductReference[]`.
     *
     * @param productCode The `productCode` for given product
     * @param referenceType Reference type according to enum ProductReferenceTypeEnum
     * @param pageSize Maximum number of product refrence to load
     */
    abstract load(productCode: string, referenceType?: string, pageSize?: number): Observable<ProductReference[]>;
}

declare class OccProductReferencesAdapter implements ProductReferencesAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    load(productCode: string, referenceType?: string, pageSize?: number): Observable<ProductReference[]>;
    protected getEndpoint(code: string, reference?: string, pageSize?: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccProductReferencesAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccProductReferencesAdapter>;
}

declare abstract class ProductReviewsAdapter {
    /**
     * Abstract method used to load reviews for a given product.
     * Reviews can be loaded from alternative sources, as long as the structure
     * converts to the `Review[]`.
     *
     * @param productCode The `productCode` for given product
     * @param maxCount Maximum number of review to load
     */
    abstract load(productCode: string, maxCount?: number): Observable<Review[]>;
    /**
     * Abstract method used to post review for a given product.
     *
     * @param productCode The `productCode` for given product
     * @param review Review to post
     */
    abstract post(productCode: string, review: any): Observable<Review>;
}

declare class OccProductReviewsAdapter implements ProductReviewsAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    load(productCode: string, maxCount?: number): Observable<Review[]>;
    post(productCode: string, review: any): Observable<Review>;
    protected getEndpoint(code: string, maxCount?: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccProductReviewsAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccProductReviewsAdapter>;
}

interface SearchConfig {
    pageSize?: number;
    currentPage?: number;
    sort?: string;
    /**
     * filters in a format of `filter:value` or `filter:value1,value2`
     * separated also by `:`
     * @example `allCategories:584:code:1,2,3:availableInStores:Chiba`
     */
    filters?: string;
    /**
     * find organizational customers using fuzzy matching on name.
     */
    query?: string;
}

declare abstract class ProductSearchAdapter {
    abstract search(query: string, searchConfig?: SearchConfig, scope?: string): Observable<ProductSearchPage>;
    abstract searchByCodes(codes: string[], scope?: string): Observable<{
        products: Product[];
    }>;
    abstract searchByCategory(category: string, scope?: string): Observable<{
        products: Product[];
    }>;
    abstract loadSuggestions(term: string, pageSize?: number): Observable<Suggestion[]>;
}

declare class OccProductSearchAdapter implements ProductSearchAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected router: Router | null;
    protected winRef: WindowRef;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    readonly DEFAULT_SEARCH_CONFIG: SearchConfig;
    search(query: string, searchConfig?: SearchConfig, scope?: string): Observable<ProductSearchPage>;
    searchByCodes(codes: string[], scope?: string): Observable<{
        products: Product[];
    }>;
    searchByCategory(category: string, scope?: string): Observable<{
        products: Product[];
    }>;
    loadSuggestions(term: string, pageSize?: number): Observable<Suggestion[]>;
    protected getSearchByCategoryEndpoint(categoryCode: string, scope?: string): string;
    protected getSearchEndpoint(query: string, searchConfig: SearchConfig, scope?: string): string;
    protected getSuggestionEndpoint(term: string, max: string): string;
    protected parseUrlForNavigation(url: string): [string[], NavigationExtras] | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccProductSearchAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccProductSearchAdapter>;
}

/**
 * Used in product connectors and adapter to load multiple product codes and scopes
 */
interface ScopedProductData extends ScopedData<Product> {
    code: string;
}

declare abstract class ProductAdapter {
    /**
     * Abstract method used to load product's details data.
     * Product's data can be loaded from alternative sources, as long as the structure
     * converts to the `Product`.
     *
     * @param productCode The `productCode` for given product
     * @param scope The product scope to load
     */
    abstract load(productCode: string, scope?: string): Observable<Product>;
    /**
     * Abstract method used to load data for multiple product and scopes
     * Adapter is able to optimize necessary backend calls and load
     * products in the most efficient way possible.
     *
     * @param products
     */
    abstract loadMany?(products: ScopedProductData[]): ScopedProductData[];
}

interface ScopedDataWithUrl {
    /** Url (with fields) to load scoped data */
    url?: string;
    /** scoped data model */
    scopedData: ScopedData<any>;
}
/**
 * Intermediate model to accommodate all data needed to perform occ fields optimizations
 * wrapping ScopedData with url and fields
 */
interface OccFieldsModel extends ScopedDataWithUrl {
    /** extracted fields object, used to extract data from broader model */
    fields: object;
}
/**
 * Grouped rest calls with optimal urls
 *
 * One url groups all scopes it covers with related occFieldsModels
 */
interface OccOptimimalUrlGroups {
    [optimalUrl: string]: {
        [scope: string]: OccFieldsModel;
    };
}
/**
 * Helper service for optimizing endpoint calls to occ backend
 */
declare class OccFieldsService {
    protected http: HttpClient;
    constructor(http: HttpClient);
    protected FIELDS_PARAM: string;
    /**
     * Merge similar occ endpoints calls by merging fields parameter
     *
     * We assume that different scopes are defined by different fields parameters,
     * so we are grouping all requests with the same urls (except fields definition)
     * and merging into one request with fields that will satisfy all separate ones.
     *
     * @param models
     */
    getOptimalUrlGroups(models: ScopedDataWithUrl[]): OccOptimimalUrlGroups;
    /**
     * Extract fields parameter from occ endpoint url
     *
     * @param urlWithFields
     */
    private splitFields;
    /**
     * Combine url with field parameters
     *
     * @param url
     * @param fields
     */
    private getUrlWithFields;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccFieldsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccFieldsService>;
}

declare class OccRequestsOptimizerService {
    protected http: HttpClient;
    protected occFields: OccFieldsService;
    constructor(http: HttpClient, occFields: OccFieldsService);
    /**
     * Optimize occ endpoint calls merging requests to the same url by merging field parameters
     *
     * @param scopedDataWithUrls
     * @param dataFactory
     */
    scopedDataLoad<T>(scopedDataWithUrls: ScopedDataWithUrl[], dataFactory?: (url: string) => Observable<T>): ScopedData<T>[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OccRequestsOptimizerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccRequestsOptimizerService>;
}

declare class OccProductAdapter implements ProductAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected requestsOptimizer: OccRequestsOptimizerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService, requestsOptimizer: OccRequestsOptimizerService);
    load(productCode: string, scope?: string): Observable<Product>;
    loadMany(products: ScopedProductData[]): ScopedProductData[];
    protected getEndpoint(code: string, scope?: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccProductAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccProductAdapter>;
}

declare enum ProductScope {
    LIST = "list",
    DETAILS = "details",
    ATTRIBUTES = "attributes",
    VARIANTS = "variants",
    CODE = "code",
    PRICE = "price",
    /** Fetch the default stock information. */
    STOCK = "stock",
    UNIT = "unit",
    PROMOTIONS = "promotions",
    LIST_ITEM = "list_item",
    MULTI_DIMENSIONAL = "multi_dimensional",
    MULTI_DIMENSIONAL_AVAILABILITY = "multi_dimensional_availability"
}

declare module './spartacus-core' {
    interface LoadingScopes {
        product?: ProductScopesConfig;
    }
}
interface ProductScopesConfig extends LoadingScopesConfig {
    list?: ProductLoadingScopeConfig;
    details?: ProductLoadingScopeConfig;
    attributes?: ProductLoadingScopeConfig;
    variants?: ProductLoadingScopeConfig;
    [scope: string]: ProductLoadingScopeConfig | undefined;
}
interface ProductLoadingScopeConfig extends LoadingScopeConfig {
    include?: (ProductScope | string)[];
}

declare class ProductOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductOccModule>;
}

declare abstract class ProductAvailabilityAdapter {
    /**
     * Abstract method used to load real time stock data for a product
     * @param productCode
     * @param unitSapCode
     * @returns {Observable<ProductAvailabilities>}
     */
    abstract loadRealTimeStock(productCode: string, unitSapCode: string): Observable<ProductAvailabilities>;
}

declare class OccProductAvailabilityAdapter implements ProductAvailabilityAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    loadRealTimeStock(productCode: string, unitSapCode: string): Observable<ProductAvailabilities>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccProductAvailabilityAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccProductAvailabilityAdapter>;
}

declare class BaseSiteNormalizer implements Converter<Occ.BaseSite, BaseSite> {
    constructor();
    convert(source: Occ.BaseSite, target?: BaseSite): BaseSite;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseSiteNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BaseSiteNormalizer>;
}

declare abstract class SiteAdapter {
    /**
     * Abstract method used to load languages.
     */
    abstract loadLanguages(): Observable<Language[]>;
    /**
     * Abstract method used to load currencies.
     */
    abstract loadCurrencies(): Observable<Currency[]>;
    /**
     * Abstract method used to get countries with optional type.
     */
    abstract loadCountries(type?: CountryType): Observable<Country[]>;
    /**
     * Abstract method used to get regions for a country.
     */
    abstract loadRegions(countryIsoCode: string): Observable<Region[]>;
    /**
     * Abstract method used to get base site data based on siteUid.
     */
    abstract loadBaseSite(siteUid?: string): Observable<BaseSite | undefined>;
    /**
     * Abstract method used to get all base sites data.
     */
    abstract loadBaseSites(): Observable<BaseSite[]>;
    /**
     * Abstract method used to get cities for a region.
     */
    abstract loadCities(regionIsocode: string): Observable<City[]>;
    /**
     * Abstract method used to get districts for a city.
     */
    abstract loadDistricts(cityIsocode: string): Observable<CityDistrict[]>;
}

declare class OccSiteAdapter implements SiteAdapter {
    protected http: HttpClient;
    protected occEndpointsService: OccEndpointsService;
    protected converterService: ConverterService;
    constructor(http: HttpClient, occEndpointsService: OccEndpointsService, converterService: ConverterService);
    loadLanguages(): Observable<Language[]>;
    loadCurrencies(): Observable<Currency[]>;
    loadCountries(type?: CountryType): Observable<Country[]>;
    loadRegions(countryIsoCode: string): Observable<Region[]>;
    /**
     * There is no OCC API to load one site based on Uid.
     * So, we have to load all sites, and find the one from the list.
     */
    loadBaseSite(siteUid?: string): Observable<BaseSite | undefined>;
    loadBaseSites(): Observable<BaseSite[]>;
    loadCities(regionIsocode: string): Observable<City[]>;
    loadDistricts(cityIsocode: string): Observable<CityDistrict[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccSiteAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccSiteAdapter>;
}

declare class SiteContextOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteContextOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SiteContextOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SiteContextOccModule>;
}

declare class SiteContextInterceptor implements HttpInterceptor {
    private languageService;
    private currencyService;
    private occEndpoints;
    private config;
    activeLang: string | undefined;
    activeCurr: string | undefined;
    constructor(languageService: LanguageService, currencyService: CurrencyService, occEndpoints: OccEndpointsService, config: SiteContextConfig);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteContextInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SiteContextInterceptor>;
}

declare const ANONYMOUS_CONSENTS_STORE_FEATURE = "anonymous-consents";
declare const ANONYMOUS_CONSENTS = "[Anonymous Consents] Anonymous Consents";
interface StateWithAnonymousConsents {
    [ANONYMOUS_CONSENTS_STORE_FEATURE]: AnonymousConsentsState;
}
interface AnonymousConsentsState {
    templates: LoaderState<ConsentTemplate[]>;
    consents: AnonymousConsent[];
    ui: {
        bannerDismissed: boolean;
        updated: boolean;
    };
}

declare class AnonymousConsentsService {
    protected store: Store<StateWithAnonymousConsents>;
    protected authService: AuthService;
    constructor(store: Store<StateWithAnonymousConsents>, authService: AuthService);
    /**
     * Retrieves the anonymous consent templates.
     */
    loadTemplates(): void;
    /**
     * Conditionally triggers the load of the anonymous consent templates if:
     *   - `loadIfMissing` parameter is set to `true`
     *   - the `templates` in the store are `undefined`
     *
     * Otherwise it just returns the value from the store.
     *
     * @param loadIfMissing setting to `true` will trigger the load of the templates if the currently stored templates are `undefined`
     */
    getTemplates(loadIfMissing?: boolean): Observable<ConsentTemplate[]>;
    /**
     * Returns the anonymous consent templates with the given template code.
     * @param templateCode a template code by which to filter anonymous consent templates.
     */
    getTemplate(templateCode: string): Observable<ConsentTemplate | undefined>;
    /**
     * Returns an indicator for the loading status for the anonymous consent templates.
     */
    getLoadTemplatesLoading(): Observable<boolean>;
    /**
     * Returns an indicator for the success status for the anonymous consent templates.
     */
    getLoadTemplatesSuccess(): Observable<boolean>;
    /**
     * Returns an indicator for the error status for the anonymous consent templates.
     */
    getLoadTemplatesError(): Observable<boolean>;
    /**
     * Resets the loading, success and error indicators for the anonymous consent templates.
     */
    resetLoadTemplatesState(): void;
    /**
     * Returns all the anonymous consents.
     */
    getConsents(): Observable<AnonymousConsent[]>;
    /**
     * Puts the provided anonymous consents into the store.
     */
    setConsents(consents: AnonymousConsent[]): void;
    /**
     * Returns the anonymous consent for the given template ID.
     *
     * As a side-effect, the method will call `getTemplates(true)` to load the templates if those are not present.
     *
     * @param templateId a template ID by which to filter anonymous consent templates.
     */
    getConsent(templateId: string): Observable<AnonymousConsent | undefined>;
    /**
     * Give a consent for the given `templateCode`
     * @param templateCode for which to give the consent
     */
    giveConsent(templateCode: string): void;
    /**
     * Sets all the anonymous consents' state to given.
     */
    giveAllConsents(): Observable<ConsentTemplate[]>;
    /**
     * Returns `true` if the provided `consent` is given.
     * @param consent a consent to test
     */
    isConsentGiven(consent: AnonymousConsent | undefined): boolean;
    /**
     * Withdraw a consent for the given `templateCode`
     * @param templateCode for which to withdraw the consent
     */
    withdrawConsent(templateCode: string): void;
    /**
     * Sets all the anonymous consents' state to withdrawn.
     */
    withdrawAllConsents(): Observable<ConsentTemplate[]>;
    /**
     * Returns `true` if the provided `consent` is withdrawn.
     * @param consent a consent to test
     */
    isConsentWithdrawn(consent: AnonymousConsent): boolean;
    /**
     * Toggles the dismissed state of the anonymous consents banner.
     * @param dismissed the banner will be dismissed if `true` is passed, otherwise it will be visible.
     */
    toggleBannerDismissed(dismissed: boolean): void;
    /**
     * Returns `true` if the banner was dismissed, `false` otherwise.
     */
    isBannerDismissed(): Observable<boolean>;
    /**
     * Returns `true` if the consent templates were updated on the back-end.
     * If the templates are not present in the store, it triggers the load.
     */
    getTemplatesUpdated(): Observable<boolean>;
    /**
     * Toggles the `updated` slice of the state
     * @param updated
     */
    toggleTemplatesUpdated(updated: boolean): void;
    /**
     * Returns `true` if either the banner is not dismissed or if the templates were updated on the back-end.
     * Otherwise, it returns `false`.
     */
    isBannerVisible(): Observable<boolean>;
    /**
     * Dispatches an action to trigger the check
     * whether the anonymous consent version have been updated
     */
    private checkConsentVersions;
    /**
     * Returns `true` if there's a mismatch in template versions between the provided `currentTemplates` and `newTemplates`
     * @param currentTemplates current templates to check
     * @param newTemplates new templates to check
     */
    detectUpdatedTemplates(currentTemplates: ConsentTemplate[], newTemplates: ConsentTemplate[]): boolean;
    /**
     * Serializes using `JSON.stringify()` and encodes using `encodeURIComponent()` methods
     * @param consents to serialize and encode
     */
    serializeAndEncode(consents: AnonymousConsent[]): string;
    /**
     * Decodes using `decodeURIComponent()` and deserializes using `JSON.parse()`
     * @param rawConsents to decode an deserialize
     */
    decodeAndDeserialize(rawConsents: string): AnonymousConsent[];
    /**
     *
     * Compares the given `newConsents` and `previousConsents` and returns `true` if there are differences (the `newConsents` are updates).
     * Otherwise it returns `false`.
     *
     * @param newConsents new consents to compare
     * @param previousConsents old consents to compare
     */
    consentsUpdated(newConsents: AnonymousConsent[], previousConsents: AnonymousConsent[]): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnonymousConsentsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AnonymousConsentsService>;
}

declare class AnonymousConsentNormalizer implements Converter<string, AnonymousConsent[]> {
    protected anonymousConsentsService: AnonymousConsentsService;
    constructor(anonymousConsentsService: AnonymousConsentsService);
    convert(source: string): AnonymousConsent[];
    static ɵfac: i0.ɵɵFactoryDeclaration<AnonymousConsentNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AnonymousConsentNormalizer>;
}

declare class OccUserInterestsNormalizer implements Converter<Occ.ProductInterestSearchResult, ProductInterestSearchResult> {
    private converter;
    constructor(converter: ConverterService);
    convert(source: Occ.ProductInterestSearchResult, target?: ProductInterestSearchResult): ProductInterestSearchResult;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccUserInterestsNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccUserInterestsNormalizer>;
}

declare abstract class AnonymousConsentTemplatesAdapter {
    /**
     * Abstract method used to load anonymous consents.
     */
    abstract loadAnonymousConsentTemplates(): Observable<ConsentTemplate[]>;
    /**
     * Loads anonymous consents in an optimal way.
     */
    abstract loadAnonymousConsents(): Observable<AnonymousConsent[]>;
}

declare class OccAnonymousConsentTemplatesAdapter implements AnonymousConsentTemplatesAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    loadAnonymousConsentTemplates(): Observable<ConsentTemplate[]>;
    loadAnonymousConsents(): Observable<AnonymousConsent[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccAnonymousConsentTemplatesAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccAnonymousConsentTemplatesAdapter>;
}

declare abstract class CustomerCouponAdapter {
    abstract getCustomerCoupons(userId: string, pageSize: number, currentPage?: number, sort?: string): Observable<CustomerCouponSearchResult>;
    abstract turnOnNotification(userId: string, couponCode: string): Observable<CustomerCouponNotification>;
    abstract turnOffNotification(userId: string, couponCode: string): Observable<{}>;
    abstract claimCustomerCouponWithCodeInBody(userId: string, couponVal: string): Observable<CustomerCoupon2Customer>;
    abstract claimCustomerCoupon(userId: string, couponCode: string): Observable<CustomerCoupon2Customer>;
    abstract disclaimCustomerCoupon(userId: string, couponCode: string): Observable<CustomerCoupon2Customer>;
}

declare class OccCustomerCouponAdapter implements CustomerCouponAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    getCustomerCoupons(userId: string, pageSize: number, currentPage?: number, sort?: string): Observable<CustomerCouponSearchResult>;
    turnOffNotification(userId: string, couponCode: string): Observable<{}>;
    turnOnNotification(userId: string, couponCode: string): Observable<CustomerCouponNotification>;
    claimCustomerCouponWithCodeInBody(userId: string, codeVal: string): Observable<CustomerCoupon2Customer>;
    claimCustomerCoupon(userId: string, couponCode: string): Observable<CustomerCoupon2Customer>;
    disclaimCustomerCoupon(userId: string, couponCode: string): Observable<CustomerCoupon2Customer>;
    private newHttpHeader;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCustomerCouponAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCustomerCouponAdapter>;
}

declare abstract class UserAddressAdapter {
    abstract loadAll(userId: string): Observable<Address[]>;
    abstract add(userId: string, address: Address): Observable<{}>;
    abstract update(userId: string, addressId: string, address: Address): Observable<{}>;
    abstract verify(userId: string, address: Address): Observable<AddressValidation>;
    abstract delete(userId: string, addressId: string): Observable<{}>;
}

declare class OccUserAddressAdapter implements UserAddressAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    private featureToggles;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    loadAll(userId: string): Observable<Address[]>;
    add(userId: string, address: Address): Observable<{}>;
    update(userId: string, addressId: string, address: Address): Observable<{}>;
    verify(userId: string, address: Address): Observable<AddressValidation>;
    delete(userId: string, addressId: string): Observable<{}>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccUserAddressAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccUserAddressAdapter>;
}

declare abstract class UserConsentAdapter {
    abstract loadConsents(userId: string): Observable<ConsentTemplate[]>;
    abstract giveConsent(userId: string, consentTemplateId: string, consentTemplateVersion: number): Observable<ConsentTemplate>;
    abstract withdrawConsent(userId: string, consentCode: string, consentId?: string): Observable<{}>;
}

declare class OccUserConsentAdapter implements UserConsentAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    loadConsents(userId: string): Observable<ConsentTemplate[]>;
    giveConsent(userId: string, consentTemplateId: string, consentTemplateVersion: number): Observable<ConsentTemplate>;
    withdrawConsent(userId: string, consentCode: string): Observable<{}>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccUserConsentAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccUserConsentAdapter>;
}

declare abstract class UserInterestsAdapter {
    /**
     * Abstract method used to load product interests for an user.
     *
     * @param userId The `userId` for given user
     * @param pageSize
     * @param currentPage
     * @param sort Sorting method
     * @param productCode The product code
     * @param  notificationType The notification type
     */
    abstract getInterests(userId: string, pageSize?: number, currentPage?: number, sort?: string, productCode?: string, notificationType?: NotificationType): Observable<ProductInterestSearchResult>;
    /**
     * Abstract method used to remove product interest for an user.
     *
     * @param userId The `userId` for given user
     * @param ProductInterestRelation The product interest to be removed.
     */
    abstract removeInterest(userId: string, item: ProductInterestEntryRelation): Observable<any[]>;
    /**
     * Abstract method to add a product interest for an user.
     *
     * @param userId The `userId` for given user
     * @param productCode The product code
     * @param notificationType The notification type
     */
    abstract addInterest(userId: string, productCode: string, notificationType: NotificationType): Observable<any>;
}

declare class OccUserInterestsAdapter implements UserInterestsAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected config: OccConfig;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, config: OccConfig, converter: ConverterService);
    getInterests(userId: string, pageSize?: number, currentPage?: number, sort?: string, productCode?: string, notificationType?: NotificationType): Observable<ProductInterestSearchResult>;
    removeInterest(userId: string, item: ProductInterestEntryRelation): Observable<any[]>;
    addInterest(userId: string, productCode: string, notificationType: NotificationType): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccUserInterestsAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccUserInterestsAdapter>;
}

declare abstract class UserNotificationPreferenceAdapter {
    /**
     * Abstract method used to load notification preferences for an user.
     *
     * @param userId The `userId` for given user
     */
    abstract loadAll(userId: string): Observable<NotificationPreference[]>;
    /**
     * Abstract method used to update notification preferences for an user.
     *
     * @param userId The `userId` for given user
     * @param preferences The notification preferences to be updated.
     */
    abstract update(userId: string, preferences: NotificationPreference[]): Observable<{}>;
}

declare class OccUserNotificationPreferenceAdapter implements UserNotificationPreferenceAdapter {
    protected http: HttpClient;
    protected converter: ConverterService;
    protected occEndpoints: OccEndpointsService;
    protected logger: LoggerService;
    constructor(http: HttpClient, converter: ConverterService, occEndpoints: OccEndpointsService);
    loadAll(userId: string): Observable<NotificationPreference[]>;
    update(userId: string, preferences: NotificationPreference[]): Observable<{}>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccUserNotificationPreferenceAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccUserNotificationPreferenceAdapter>;
}

declare abstract class UserPaymentAdapter {
    abstract loadAll(userId: string): Observable<PaymentDetails[]>;
    abstract delete(userId: string, paymentMethodID: string): Observable<{}>;
    abstract setDefault(userId: string, paymentMethodID: string): Observable<{}>;
}

declare class OccUserPaymentAdapter implements UserPaymentAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    loadAll(userId: string): Observable<PaymentDetails[]>;
    delete(userId: string, paymentMethodID: string): Observable<{}>;
    setDefault(userId: string, paymentMethodID: string): Observable<{}>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccUserPaymentAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccUserPaymentAdapter>;
}

declare class UserOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserOccModule>;
}

declare class BaseOccModule {
    static forRoot(): ModuleWithProviders<BaseOccModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BaseOccModule, never, [typeof CmsOccModule, typeof SiteContextOccModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BaseOccModule>;
}

declare const OCC_BASE_URL_META_TAG_NAME = "occ-backend-base-url";
declare const OCC_BASE_URL_META_TAG_PLACEHOLDER = "OCC_BACKEND_BASE_URL_VALUE";
declare const MEDIA_BASE_URL_META_TAG_NAME = "media-backend-base-url";
declare const MEDIA_BASE_URL_META_TAG_PLACEHOLDER = "MEDIA_BACKEND_BASE_URL_VALUE";
declare function occServerConfigFromMetaTagFactory(meta: Meta): OccConfig;
declare function mediaServerConfigFromMetaTagFactory(meta: Meta): OccConfig;
declare function provideConfigFromMetaTags(): Provider[];

declare const defaultOccConfig: OccConfig;

declare class MetaTagConfigModule {
    static forRoot(): ModuleWithProviders<MetaTagConfigModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MetaTagConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MetaTagConfigModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MetaTagConfigModule>;
}

declare function occConfigValidator(config: OccConfig): "Please configure backend.occ.baseUrl before using storefront library!" | undefined;

/**
 * Http interceptor to add cookies to all cross-site requests.
 */
declare class WithCredentialsInterceptor implements HttpInterceptor {
    protected config: OccConfig;
    constructor(config: OccConfig);
    /**
     * Intercepts each request and adds the `withCredential` flag to it
     * if it hasn't been added already.
     */
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    /**
     * indicates whether the request should use the WithCredentials flag.
     */
    protected requiresWithCredentials(request: HttpRequest<any>): boolean;
    private get occConfig();
    static ɵfac: i0.ɵɵFactoryDeclaration<WithCredentialsInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WithCredentialsInterceptor>;
}

declare class LoadingScopesService {
    protected config: OccConfig;
    constructor(config: OccConfig);
    /**
     * Aims to expand scopes based on loading scopes config.
     *
     * I.e. if 'details' scope includes 'list' scope by configuration, it'll return ['details', 'list']
     *
     * If scope data overlaps with each other, the data should be merged in the order of scopes provided,
     * i.e. the last scope is merged last, overwriting parts of the data already provided by preceding scope.
     * It should apply also to implicit scopes (that are included by configuration).
     *
     * @param model
     * @param scopes
     */
    expand(model: string, scopes: string[]): string[];
    /**
     * Return maxAge for product scope in milliseconds
     *
     * @param model
     * @param scope
     */
    getMaxAge(model: string, scope: string): number;
    /**
     *
     * Returns the configured triggers for which to reload the product.
     *
     * @param model for which to look up the scopes (usually a 'product')
     * @param scope for which to look up the config
     * @returns the configured triggers, or an empty array if not configured
     */
    getReloadTriggers(model: string, scope: string): Type<CxEvent>[];
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingScopesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoadingScopesService>;
}

declare const OCC_USER_ID_CURRENT = "current";
declare const OCC_USER_ID_ANONYMOUS = "anonymous";
declare const OCC_USER_ID_GUEST = "guest";

declare const occUserIds_d_OCC_USER_ID_ANONYMOUS: typeof OCC_USER_ID_ANONYMOUS;
declare const occUserIds_d_OCC_USER_ID_CURRENT: typeof OCC_USER_ID_CURRENT;
declare const occUserIds_d_OCC_USER_ID_GUEST: typeof OCC_USER_ID_GUEST;
declare namespace occUserIds_d {
  export {
    occUserIds_d_OCC_USER_ID_ANONYMOUS as OCC_USER_ID_ANONYMOUS,
    occUserIds_d_OCC_USER_ID_CURRENT as OCC_USER_ID_CURRENT,
    occUserIds_d_OCC_USER_ID_GUEST as OCC_USER_ID_GUEST,
  };
}

declare const USE_CLIENT_TOKEN = "cx-use-client-token";
declare const USE_CUSTOMER_SUPPORT_AGENT_TOKEN = "cx-use-csagent-token";
declare const USE_CAPTCHA_TOKEN = "sap-commerce-cloud-captcha-token";
declare class InterceptorUtil {
    static createHeader<T>(headerName: string, interceptorParam: T, headers?: HttpHeaders): HttpHeaders;
    static removeHeader(headerName: string, request: HttpRequest<any>): HttpRequest<any>;
    static getInterceptorParam<T>(headerName: string, headers: HttpHeaders): T | undefined;
}

declare const OCC_CART_ID_CURRENT = "current";

/**
 * Joins the multiple parts with '/' to create a url
 *
 * @param parts the distinct parts of the url to join
 */
declare function urlPathJoin(...parts: string[]): string;

interface OccHttpContext {
    /**
     * Indicates to the interceptor that the emulated customer ID should be sent to the OCC
     * to avoid ambiguity.
     * 'string' if the request has the user ID at hand.
     * 'boolean' (or, 'true') if the request does not have the user ID but still needs to send the emulated ID.
     * @see feature-libs/asm/root/interceptors/user-id-http-header.interceptor.ts
     */
    sendUserIdAsHeader?: string | boolean;
}
declare const OCC_HTTP_TOKEN: HttpContextToken<OccHttpContext>;

/**
 * Merge occ fields parameters
 *
 * @param fields Fields definition as string or object
 */
declare function mergeFields(fields: (string | object)[]): string;
/**
 * Optimize fields definition by removing not needed groups
 *
 * @param fields
 */
declare function optimizeFields(fields?: object): object;
/**
 * Parse string field definition to an AST object
 *
 * @param fields Fields string definition
 * @param startIndex Used for recurrence
 */
declare function parseFields(fields: string, startIndex?: number): [object, number] | object;
/**
 * Convert AST object fields definition to string representation
 *
 * @param fields
 */
declare function stringifyFields(fields: object): string;
/**
 * Extract part of the object described by fields definition
 *
 * @param data
 * @param fields
 */
declare function extractFields<T>(data: T, fields: string | object): T;

declare const OCC_USER_ID_CONSTANTS: InjectionToken<{
    [identifier: string]: string;
}>;

/**
 * This interceptor forwards all HTTP errors (e.g. 5xx or 4xx status response from backend)
 * to Angular `ErrorHandler`.
 *
 * Thanks to this, in SSR, any HTTP error from backend can potentially mark the Server-Side Rendering
 * as an error and therefore allow for sending an appropriate error response to a final client of SSR.
 *
 * NOTE: It handles not only HTTP errors, but also any RxJs errors
 * (e.g., `TimeoutError` from `timeout()` operator) thrown in any subsequent interceptor.
 *
 * CAUTION: It MUST be provided as the first one in the application to be able to
 *          catch errors from all subsequent interceptors.
 */
declare class HttpErrorHandlerInterceptor implements HttpInterceptor {
    protected errorHandler: ErrorHandler;
    protected occEndpointsService: OccEndpointsService;
    protected windowRef: WindowRef;
    protected userId: i0.Signal<string | undefined>;
    intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>>;
    /**
     * Determine if the error should be handled by the `ErrorHandler`.
     *
     * Be default, we avoid sending unpredictable errors to the browser's console, to prevent
     * possibly exposing there potentially confidential user's data.
     * This isn't an issue in SSR, where pages are rendered anonymously.
     * Moreover, in SSR we want to capture all app's errors, so we can potentially send
     * a HTTP error response (e.g. 500 error page) from SSR to a client.
     */
    protected shouldHandleError(_error: unknown): boolean;
    protected handleError(error: unknown): void;
    /**
     * Checks if the error corresponds to a CMS page not found HTTP error.
     *
     * @param error - The error object to check.
     * @returns `true` if the error corresponds to a CMS page not found HTTP error, `false` otherwise.
     */
    protected isCmsPageNotFoundHttpError(error: unknown): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<HttpErrorHandlerInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HttpErrorHandlerInterceptor>;
}

/**
 * Represents an outbound HTTP error that occurs when communicating with the backend.
 */
declare class OutboundHttpError extends Error {
    constructor(cause: unknown);
}
/**
 * Represents an outbound HTTP error specific to a CMS page not found.
 * Extends the base OutboundHttpError class.
 */
declare class CmsPageNotFoundOutboundHttpError extends OutboundHttpError {
    constructor(cause: unknown);
}

/**
 * Multi error handlers are responsible for act with errors handled by the CxErrorHandler.
 *
 * @method handleError - Handles the error.
 *
 * @public
 */
interface MultiErrorHandler {
    handleError(error: unknown): void;
}
/**
 * Injection token for multi error handlers.
 * Multi provided error handlers will be called in the order they are provided.
 */
declare const MULTI_ERROR_HANDLER: InjectionToken<MultiErrorHandler[]>;

/**
 * An error handler that logs errors using a logger service.
 * Intended to be used as part of a multi-error handler strategy.
 *
 * @see MultiErrorHandler
 */
declare class LoggingErrorHandler implements MultiErrorHandler {
    protected logger: LoggerService;
    handleError(error: Error): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoggingErrorHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoggingErrorHandler>;
}

declare const ENTITY_REMOVE_ACTION = "[ENTITY] REMOVE";
declare const ENTITY_REMOVE_ALL_ACTION = "[ENTITY] REMOVE ALL";
type EntityId = string | string[] | null;
interface EntityMeta {
    entityType: string;
    entityId?: EntityId;
    entityRemove?: boolean;
}
declare function entityMeta(type: string, id?: EntityId): EntityMeta;
declare function entityRemoveMeta(type: string, id: EntityId): EntityMeta;
declare function entityRemoveAllMeta(type: string): EntityMeta;
interface EntityAction extends Action {
    readonly payload?: any;
    readonly meta?: EntityMeta;
}
declare class EntityRemoveAction implements EntityAction {
    type: string;
    readonly meta: EntityMeta;
    constructor(entityType: string, id: EntityId);
}
declare class EntityRemoveAllAction implements EntityAction {
    type: string;
    readonly meta: EntityMeta;
    constructor(entityType: string);
}

declare const LOADER_LOAD_ACTION = "[LOADER] LOAD";
declare const LOADER_FAIL_ACTION = "[LOADER] FAIL";
declare const LOADER_SUCCESS_ACTION = "[LOADER] SUCCESS";
declare const LOADER_RESET_ACTION = "[LOADER] RESET";
interface LoaderMeta {
    entityType: string;
    loader: {
        load?: boolean;
        error?: any;
        success?: boolean;
    } | undefined;
}
interface LoaderAction extends Action {
    readonly payload?: any;
    readonly meta?: LoaderMeta;
}
declare function loadMeta(entityType: string): LoaderMeta;
declare function failMeta(entityType: string, error: any): LoaderMeta;
declare function successMeta(entityType: string): LoaderMeta;
declare function resetMeta(entityType: string): LoaderMeta;
declare class LoaderLoadAction implements LoaderAction {
    type: string;
    readonly meta: LoaderMeta;
    constructor(entityType: string);
}
declare class LoaderFailAction implements LoaderAction, ErrorAction {
    type: string;
    error: any;
    readonly meta: LoaderMeta;
    constructor(entityType: string, error: any);
}
declare class LoaderSuccessAction implements LoaderAction {
    type: string;
    readonly meta: LoaderMeta;
    constructor(entityType: string);
}
declare class LoaderResetAction implements LoaderAction {
    type: string;
    readonly meta: LoaderMeta;
    constructor(entityType: string);
}

declare const ENTITY_LOAD_ACTION = "[ENTITY] LOAD";
declare const ENTITY_FAIL_ACTION = "[ENTITY] LOAD FAIL";
declare const ENTITY_SUCCESS_ACTION = "[ENTITY] LOAD SUCCESS";
declare const ENTITY_RESET_ACTION = "[ENTITY] RESET";
interface EntityLoaderMeta extends EntityMeta, LoaderMeta {
}
interface EntityLoaderAction extends Action {
    readonly payload?: any;
    readonly meta?: EntityLoaderMeta;
}
declare function entityLoadMeta(entityType: string, id: EntityId): EntityLoaderMeta;
declare function entityFailMeta(entityType: string, id: EntityId, error: any): EntityLoaderMeta;
declare function entitySuccessMeta(entityType: string, id: EntityId): EntityLoaderMeta;
declare function entityResetMeta(entityType: string, id?: EntityId): EntityLoaderMeta;
declare class EntityLoadAction implements EntityLoaderAction {
    type: string;
    readonly meta: EntityLoaderMeta;
    constructor(entityType: string, id: EntityId);
}
declare class EntityFailAction implements EntityLoaderAction, ErrorAction {
    type: string;
    readonly meta: EntityLoaderMeta;
    error: any;
    constructor(entityType: string, id: EntityId, error: any);
}
declare class EntitySuccessAction implements EntityLoaderAction {
    payload?: any | undefined;
    type: string;
    readonly meta: EntityLoaderMeta;
    constructor(entityType: string, id: EntityId, payload?: any | undefined);
}
declare class EntityLoaderResetAction implements EntityLoaderAction {
    type: string;
    readonly meta: EntityLoaderMeta;
    constructor(entityType: string, id: EntityId);
}

interface EntityState<T> {
    entities: {
        [id: string]: T;
    };
}

type EntityLoaderState<T> = EntityState<LoaderState<T>>;

declare function entityLoaderStateSelector<T>(state: EntityLoaderState<T>, id: string): LoaderState<T>;
declare function entityValueSelector<T>(state: EntityLoaderState<T>, id: string): T;
declare function entityLoadingSelector<T>(state: EntityLoaderState<T>, id: string): boolean;
declare function entityErrorSelector<T>(state: EntityLoaderState<T>, id: string): boolean;
declare function entitySuccessSelector<T>(state: EntityLoaderState<T>, id: string): boolean;

/**
 * Higher order reducer that wraps LoaderReducer and EntityReducer enhancing
 * single state reducer to support multiple entities with generic loading flags
 */
declare function entityLoaderReducer<T, V extends LoaderAction = LoaderAction>(entityType: string, reducer?: (state: T | undefined, action: V | LoaderAction) => T | undefined): (state: EntityLoaderState<T> | undefined, action: EntityLoaderAction) => EntityLoaderState<T>;

declare const PROCESSES_INCREMENT_ACTION = "[PROCESSES LOADER] INCREMENT";
declare const PROCESSES_DECREMENT_ACTION = "[PROCESSES LOADER] DECREMENT";
declare const PROCESSES_LOADER_RESET_ACTION = "[PROCESSES LOADER] RESET";
interface ProcessesLoaderMeta extends LoaderMeta {
    entityType: string;
    processesCountDiff?: number | null;
}
interface ProcessesLoaderAction extends Action {
    readonly payload?: any;
    readonly meta?: ProcessesLoaderMeta;
}
declare function processesIncrementMeta(entityType: string): ProcessesLoaderMeta;
declare function processesDecrementMeta(entityType: string): ProcessesLoaderMeta;
declare function processesLoaderResetMeta(entityType: string): ProcessesLoaderMeta;
declare class ProcessesLoaderResetAction implements ProcessesLoaderAction {
    type: string;
    readonly meta: ProcessesLoaderMeta;
    constructor(entityType: string);
}
declare class ProcessesIncrementAction implements ProcessesLoaderAction {
    type: string;
    readonly meta: ProcessesLoaderMeta;
    constructor(entityType: string);
}
declare class ProcessesDecrementAction implements ProcessesLoaderAction {
    type: string;
    readonly meta: ProcessesLoaderMeta;
    constructor(entityType: string);
}

declare const ENTITY_PROCESSES_LOADER_RESET_ACTION = "[ENTITY] PROCESSES LOADER RESET";
declare const ENTITY_PROCESSES_INCREMENT_ACTION = "[ENTITY] PROCESSES INCREMENT";
declare const ENTITY_PROCESSES_DECREMENT_ACTION = "[ENTITY] PROCESSES DECREMENT";
interface EntityProcessesLoaderMeta extends EntityMeta, ProcessesLoaderMeta {
}
interface EntityProcessesLoaderAction extends Action {
    readonly payload?: any;
    readonly meta?: EntityProcessesLoaderMeta;
}
declare function entityProcessesLoaderResetMeta(entityType: string, id: string | string[]): EntityProcessesLoaderMeta;
declare function entityProcessesIncrementMeta(entityType: string, id: string | string[]): EntityProcessesLoaderMeta;
declare function entityProcessesDecrementMeta(entityType: string, id: string | string[]): EntityProcessesLoaderMeta;
declare class EntityProcessesLoaderResetAction implements EntityProcessesLoaderAction {
    type: string;
    readonly meta: EntityProcessesLoaderMeta;
    constructor(entityType: string, id: string | string[]);
}
declare class EntityProcessesIncrementAction implements EntityProcessesLoaderAction {
    type: string;
    readonly meta: EntityProcessesLoaderMeta;
    constructor(entityType: string, id: string | string[]);
}
declare class EntityProcessesDecrementAction implements EntityProcessesLoaderAction {
    type: string;
    readonly meta: EntityProcessesLoaderMeta;
    constructor(entityType: string, id: string | string[]);
}

interface ProcessesLoaderState<T> extends LoaderState<T> {
    processesCount?: number;
}

declare function isStableSelector<T>(state: ProcessesLoaderState<T>): boolean;
declare function hasPendingProcessesSelector<T>(state: ProcessesLoaderState<T>): boolean;

declare const initialProcessesState: ProcessesLoaderState<any>;
/**
 * Higher order reducer that adds processes count
 */
declare function processesLoaderReducer<T>(entityType: string, reducer?: (state: T | undefined, action: Action) => T): (state: ProcessesLoaderState<T>, action: ProcessesLoaderAction) => ProcessesLoaderState<T>;

type EntityProcessesLoaderState<T> = EntityState<ProcessesLoaderState<T>>;

declare function entityHasPendingProcessesSelector<T>(state: EntityProcessesLoaderState<T>, id: string): boolean;
declare function entityIsStableSelector<T>(state: EntityProcessesLoaderState<T>, id: string): boolean;
declare function entityProcessesLoaderStateSelector<T>(state: EntityProcessesLoaderState<T>, id: string): ProcessesLoaderState<T>;

/**
 * Higher order reducer that wraps ProcessesLoaderReducer and EntityReducer enhancing
 * single state reducer to support multiple entities with generic processesCount flag
 */
declare function entityProcessesLoaderReducer<T>(entityType: string, reducer?: (state: T | undefined, action: ProcessesLoaderAction) => T): (state: EntityProcessesLoaderState<T> | undefined, action: EntityProcessesLoaderAction) => EntityProcessesLoaderState<T>;

declare function entitySelector<T>(state: EntityState<T>, id: string): T | undefined;

declare const initialEntityState: EntityState<any>;
/**
 * Higher order reducer for reusing reducer logic for multiple entities
 *
 * Utilizes entityId meta field to target entity by id in actions
 */
declare function entityReducer<T, V extends Action = Action>(entityType: string, reducer: (state: T, action: Action | V) => T): (state: EntityState<T> | undefined, action: EntityAction) => EntityState<T>;

declare function getStateSlice<T, E>(keys: string[], excludeKeys: string[], state: T): E;

declare function loaderValueSelector<T>(state: LoaderState<T>): T;
declare function loaderLoadingSelector<T>(state: LoaderState<T>): boolean;
declare function loaderErrorSelector<T>(state: LoaderState<T>): boolean;
declare function loaderSuccessSelector<T>(state: LoaderState<T>): boolean;

declare const initialLoaderState: LoaderState<any>;
/**
 * Higher order reducer that adds generic loading flag to chunk of the state
 *
 * Utilizes "loader" meta field of actions to set specific flags for specific
 * action (LOAD, SUCCESS, FAIL, RESET)
 */
declare function loaderReducer<T, V extends Action = Action>(entityType: string, reducer?: (state: T | undefined, action: Action | V) => T | undefined): (state: LoaderState<T> | undefined, action: LoaderAction) => LoaderState<T>;

interface EntityListState<Type> {
    list: EntityLoaderState<ListModel>;
    entities: EntityLoaderState<Type>;
}

declare function serializeSearchConfig(config: SearchConfig, id?: string): string;
declare function denormalizeSearch<T>(state: EntityListState<T>, params?: SearchConfig): LoaderState<EntitiesModel<T>>;
declare function denormalizeCustomB2BSearch<T>(list: EntityLoaderState<ListModel>, entities: EntityLoaderState<T>, params?: SearchConfig, id?: string): LoaderState<EntitiesModel<T>>;
declare function normalizeListPage<T>(list: EntitiesModel<T>, id: string): {
    values: T[];
    page: ListModel;
};
declare function serializeParams(params: string | string[], searchConfig: SearchConfig): string;

declare const utilsGroup_d_ENTITY_FAIL_ACTION: typeof ENTITY_FAIL_ACTION;
declare const utilsGroup_d_ENTITY_LOAD_ACTION: typeof ENTITY_LOAD_ACTION;
declare const utilsGroup_d_ENTITY_PROCESSES_DECREMENT_ACTION: typeof ENTITY_PROCESSES_DECREMENT_ACTION;
declare const utilsGroup_d_ENTITY_PROCESSES_INCREMENT_ACTION: typeof ENTITY_PROCESSES_INCREMENT_ACTION;
declare const utilsGroup_d_ENTITY_PROCESSES_LOADER_RESET_ACTION: typeof ENTITY_PROCESSES_LOADER_RESET_ACTION;
declare const utilsGroup_d_ENTITY_REMOVE_ACTION: typeof ENTITY_REMOVE_ACTION;
declare const utilsGroup_d_ENTITY_REMOVE_ALL_ACTION: typeof ENTITY_REMOVE_ALL_ACTION;
declare const utilsGroup_d_ENTITY_RESET_ACTION: typeof ENTITY_RESET_ACTION;
declare const utilsGroup_d_ENTITY_SUCCESS_ACTION: typeof ENTITY_SUCCESS_ACTION;
type utilsGroup_d_EntityAction = EntityAction;
type utilsGroup_d_EntityFailAction = EntityFailAction;
declare const utilsGroup_d_EntityFailAction: typeof EntityFailAction;
type utilsGroup_d_EntityId = EntityId;
type utilsGroup_d_EntityListState<Type> = EntityListState<Type>;
type utilsGroup_d_EntityLoadAction = EntityLoadAction;
declare const utilsGroup_d_EntityLoadAction: typeof EntityLoadAction;
type utilsGroup_d_EntityLoaderAction = EntityLoaderAction;
type utilsGroup_d_EntityLoaderMeta = EntityLoaderMeta;
type utilsGroup_d_EntityLoaderResetAction = EntityLoaderResetAction;
declare const utilsGroup_d_EntityLoaderResetAction: typeof EntityLoaderResetAction;
type utilsGroup_d_EntityLoaderState<T> = EntityLoaderState<T>;
type utilsGroup_d_EntityMeta = EntityMeta;
type utilsGroup_d_EntityProcessesDecrementAction = EntityProcessesDecrementAction;
declare const utilsGroup_d_EntityProcessesDecrementAction: typeof EntityProcessesDecrementAction;
type utilsGroup_d_EntityProcessesIncrementAction = EntityProcessesIncrementAction;
declare const utilsGroup_d_EntityProcessesIncrementAction: typeof EntityProcessesIncrementAction;
type utilsGroup_d_EntityProcessesLoaderAction = EntityProcessesLoaderAction;
type utilsGroup_d_EntityProcessesLoaderMeta = EntityProcessesLoaderMeta;
type utilsGroup_d_EntityProcessesLoaderResetAction = EntityProcessesLoaderResetAction;
declare const utilsGroup_d_EntityProcessesLoaderResetAction: typeof EntityProcessesLoaderResetAction;
type utilsGroup_d_EntityProcessesLoaderState<T> = EntityProcessesLoaderState<T>;
type utilsGroup_d_EntityRemoveAction = EntityRemoveAction;
declare const utilsGroup_d_EntityRemoveAction: typeof EntityRemoveAction;
type utilsGroup_d_EntityRemoveAllAction = EntityRemoveAllAction;
declare const utilsGroup_d_EntityRemoveAllAction: typeof EntityRemoveAllAction;
type utilsGroup_d_EntityState<T> = EntityState<T>;
type utilsGroup_d_EntitySuccessAction = EntitySuccessAction;
declare const utilsGroup_d_EntitySuccessAction: typeof EntitySuccessAction;
declare const utilsGroup_d_LOADER_FAIL_ACTION: typeof LOADER_FAIL_ACTION;
declare const utilsGroup_d_LOADER_LOAD_ACTION: typeof LOADER_LOAD_ACTION;
declare const utilsGroup_d_LOADER_RESET_ACTION: typeof LOADER_RESET_ACTION;
declare const utilsGroup_d_LOADER_SUCCESS_ACTION: typeof LOADER_SUCCESS_ACTION;
type utilsGroup_d_LoaderAction = LoaderAction;
type utilsGroup_d_LoaderFailAction = LoaderFailAction;
declare const utilsGroup_d_LoaderFailAction: typeof LoaderFailAction;
type utilsGroup_d_LoaderLoadAction = LoaderLoadAction;
declare const utilsGroup_d_LoaderLoadAction: typeof LoaderLoadAction;
type utilsGroup_d_LoaderMeta = LoaderMeta;
type utilsGroup_d_LoaderResetAction = LoaderResetAction;
declare const utilsGroup_d_LoaderResetAction: typeof LoaderResetAction;
type utilsGroup_d_LoaderState<T> = LoaderState<T>;
type utilsGroup_d_LoaderSuccessAction = LoaderSuccessAction;
declare const utilsGroup_d_LoaderSuccessAction: typeof LoaderSuccessAction;
declare const utilsGroup_d_PROCESSES_DECREMENT_ACTION: typeof PROCESSES_DECREMENT_ACTION;
declare const utilsGroup_d_PROCESSES_INCREMENT_ACTION: typeof PROCESSES_INCREMENT_ACTION;
declare const utilsGroup_d_PROCESSES_LOADER_RESET_ACTION: typeof PROCESSES_LOADER_RESET_ACTION;
type utilsGroup_d_ProcessesDecrementAction = ProcessesDecrementAction;
declare const utilsGroup_d_ProcessesDecrementAction: typeof ProcessesDecrementAction;
type utilsGroup_d_ProcessesIncrementAction = ProcessesIncrementAction;
declare const utilsGroup_d_ProcessesIncrementAction: typeof ProcessesIncrementAction;
type utilsGroup_d_ProcessesLoaderAction = ProcessesLoaderAction;
type utilsGroup_d_ProcessesLoaderMeta = ProcessesLoaderMeta;
type utilsGroup_d_ProcessesLoaderResetAction = ProcessesLoaderResetAction;
declare const utilsGroup_d_ProcessesLoaderResetAction: typeof ProcessesLoaderResetAction;
type utilsGroup_d_ProcessesLoaderState<T> = ProcessesLoaderState<T>;
declare const utilsGroup_d_denormalizeCustomB2BSearch: typeof denormalizeCustomB2BSearch;
declare const utilsGroup_d_denormalizeSearch: typeof denormalizeSearch;
declare const utilsGroup_d_entityErrorSelector: typeof entityErrorSelector;
declare const utilsGroup_d_entityFailMeta: typeof entityFailMeta;
declare const utilsGroup_d_entityHasPendingProcessesSelector: typeof entityHasPendingProcessesSelector;
declare const utilsGroup_d_entityIsStableSelector: typeof entityIsStableSelector;
declare const utilsGroup_d_entityLoadMeta: typeof entityLoadMeta;
declare const utilsGroup_d_entityLoaderReducer: typeof entityLoaderReducer;
declare const utilsGroup_d_entityLoaderStateSelector: typeof entityLoaderStateSelector;
declare const utilsGroup_d_entityLoadingSelector: typeof entityLoadingSelector;
declare const utilsGroup_d_entityMeta: typeof entityMeta;
declare const utilsGroup_d_entityProcessesDecrementMeta: typeof entityProcessesDecrementMeta;
declare const utilsGroup_d_entityProcessesIncrementMeta: typeof entityProcessesIncrementMeta;
declare const utilsGroup_d_entityProcessesLoaderReducer: typeof entityProcessesLoaderReducer;
declare const utilsGroup_d_entityProcessesLoaderResetMeta: typeof entityProcessesLoaderResetMeta;
declare const utilsGroup_d_entityProcessesLoaderStateSelector: typeof entityProcessesLoaderStateSelector;
declare const utilsGroup_d_entityReducer: typeof entityReducer;
declare const utilsGroup_d_entityRemoveAllMeta: typeof entityRemoveAllMeta;
declare const utilsGroup_d_entityRemoveMeta: typeof entityRemoveMeta;
declare const utilsGroup_d_entityResetMeta: typeof entityResetMeta;
declare const utilsGroup_d_entitySelector: typeof entitySelector;
declare const utilsGroup_d_entitySuccessMeta: typeof entitySuccessMeta;
declare const utilsGroup_d_entitySuccessSelector: typeof entitySuccessSelector;
declare const utilsGroup_d_entityValueSelector: typeof entityValueSelector;
declare const utilsGroup_d_failMeta: typeof failMeta;
declare const utilsGroup_d_getStateSlice: typeof getStateSlice;
declare const utilsGroup_d_hasPendingProcessesSelector: typeof hasPendingProcessesSelector;
declare const utilsGroup_d_initialEntityState: typeof initialEntityState;
declare const utilsGroup_d_initialLoaderState: typeof initialLoaderState;
declare const utilsGroup_d_initialProcessesState: typeof initialProcessesState;
declare const utilsGroup_d_isStableSelector: typeof isStableSelector;
declare const utilsGroup_d_loadMeta: typeof loadMeta;
declare const utilsGroup_d_loaderErrorSelector: typeof loaderErrorSelector;
declare const utilsGroup_d_loaderLoadingSelector: typeof loaderLoadingSelector;
declare const utilsGroup_d_loaderReducer: typeof loaderReducer;
declare const utilsGroup_d_loaderSuccessSelector: typeof loaderSuccessSelector;
declare const utilsGroup_d_loaderValueSelector: typeof loaderValueSelector;
declare const utilsGroup_d_normalizeListPage: typeof normalizeListPage;
declare const utilsGroup_d_processesDecrementMeta: typeof processesDecrementMeta;
declare const utilsGroup_d_processesIncrementMeta: typeof processesIncrementMeta;
declare const utilsGroup_d_processesLoaderReducer: typeof processesLoaderReducer;
declare const utilsGroup_d_processesLoaderResetMeta: typeof processesLoaderResetMeta;
declare const utilsGroup_d_resetMeta: typeof resetMeta;
declare const utilsGroup_d_serializeParams: typeof serializeParams;
declare const utilsGroup_d_serializeSearchConfig: typeof serializeSearchConfig;
declare const utilsGroup_d_successMeta: typeof successMeta;
declare namespace utilsGroup_d {
  export { utilsGroup_d_ENTITY_FAIL_ACTION as ENTITY_FAIL_ACTION, utilsGroup_d_ENTITY_LOAD_ACTION as ENTITY_LOAD_ACTION, utilsGroup_d_ENTITY_PROCESSES_DECREMENT_ACTION as ENTITY_PROCESSES_DECREMENT_ACTION, utilsGroup_d_ENTITY_PROCESSES_INCREMENT_ACTION as ENTITY_PROCESSES_INCREMENT_ACTION, utilsGroup_d_ENTITY_PROCESSES_LOADER_RESET_ACTION as ENTITY_PROCESSES_LOADER_RESET_ACTION, utilsGroup_d_ENTITY_REMOVE_ACTION as ENTITY_REMOVE_ACTION, utilsGroup_d_ENTITY_REMOVE_ALL_ACTION as ENTITY_REMOVE_ALL_ACTION, utilsGroup_d_ENTITY_RESET_ACTION as ENTITY_RESET_ACTION, utilsGroup_d_ENTITY_SUCCESS_ACTION as ENTITY_SUCCESS_ACTION, utilsGroup_d_EntityFailAction as EntityFailAction, utilsGroup_d_EntityLoadAction as EntityLoadAction, utilsGroup_d_EntityLoaderResetAction as EntityLoaderResetAction, utilsGroup_d_EntityProcessesDecrementAction as EntityProcessesDecrementAction, utilsGroup_d_EntityProcessesIncrementAction as EntityProcessesIncrementAction, utilsGroup_d_EntityProcessesLoaderResetAction as EntityProcessesLoaderResetAction, utilsGroup_d_EntityRemoveAction as EntityRemoveAction, utilsGroup_d_EntityRemoveAllAction as EntityRemoveAllAction, utilsGroup_d_EntitySuccessAction as EntitySuccessAction, utilsGroup_d_LOADER_FAIL_ACTION as LOADER_FAIL_ACTION, utilsGroup_d_LOADER_LOAD_ACTION as LOADER_LOAD_ACTION, utilsGroup_d_LOADER_RESET_ACTION as LOADER_RESET_ACTION, utilsGroup_d_LOADER_SUCCESS_ACTION as LOADER_SUCCESS_ACTION, utilsGroup_d_LoaderFailAction as LoaderFailAction, utilsGroup_d_LoaderLoadAction as LoaderLoadAction, utilsGroup_d_LoaderResetAction as LoaderResetAction, utilsGroup_d_LoaderSuccessAction as LoaderSuccessAction, utilsGroup_d_PROCESSES_DECREMENT_ACTION as PROCESSES_DECREMENT_ACTION, utilsGroup_d_PROCESSES_INCREMENT_ACTION as PROCESSES_INCREMENT_ACTION, utilsGroup_d_PROCESSES_LOADER_RESET_ACTION as PROCESSES_LOADER_RESET_ACTION, utilsGroup_d_ProcessesDecrementAction as ProcessesDecrementAction, utilsGroup_d_ProcessesIncrementAction as ProcessesIncrementAction, utilsGroup_d_ProcessesLoaderResetAction as ProcessesLoaderResetAction, utilsGroup_d_denormalizeCustomB2BSearch as denormalizeCustomB2BSearch, utilsGroup_d_denormalizeSearch as denormalizeSearch, utilsGroup_d_entityErrorSelector as entityErrorSelector, utilsGroup_d_entityFailMeta as entityFailMeta, utilsGroup_d_entityHasPendingProcessesSelector as entityHasPendingProcessesSelector, utilsGroup_d_entityIsStableSelector as entityIsStableSelector, utilsGroup_d_entityLoadMeta as entityLoadMeta, utilsGroup_d_entityLoaderReducer as entityLoaderReducer, utilsGroup_d_entityLoaderStateSelector as entityLoaderStateSelector, utilsGroup_d_entityLoadingSelector as entityLoadingSelector, utilsGroup_d_entityMeta as entityMeta, utilsGroup_d_entityProcessesDecrementMeta as entityProcessesDecrementMeta, utilsGroup_d_entityProcessesIncrementMeta as entityProcessesIncrementMeta, utilsGroup_d_entityProcessesLoaderReducer as entityProcessesLoaderReducer, utilsGroup_d_entityProcessesLoaderResetMeta as entityProcessesLoaderResetMeta, utilsGroup_d_entityProcessesLoaderStateSelector as entityProcessesLoaderStateSelector, utilsGroup_d_entityReducer as entityReducer, utilsGroup_d_entityRemoveAllMeta as entityRemoveAllMeta, utilsGroup_d_entityRemoveMeta as entityRemoveMeta, utilsGroup_d_entityResetMeta as entityResetMeta, utilsGroup_d_entitySelector as entitySelector, utilsGroup_d_entitySuccessMeta as entitySuccessMeta, utilsGroup_d_entitySuccessSelector as entitySuccessSelector, utilsGroup_d_entityValueSelector as entityValueSelector, utilsGroup_d_failMeta as failMeta, utilsGroup_d_getStateSlice as getStateSlice, utilsGroup_d_hasPendingProcessesSelector as hasPendingProcessesSelector, utilsGroup_d_initialEntityState as initialEntityState, utilsGroup_d_initialLoaderState as initialLoaderState, utilsGroup_d_initialProcessesState as initialProcessesState, utilsGroup_d_isStableSelector as isStableSelector, utilsGroup_d_loadMeta as loadMeta, utilsGroup_d_loaderErrorSelector as loaderErrorSelector, utilsGroup_d_loaderLoadingSelector as loaderLoadingSelector, utilsGroup_d_loaderReducer as loaderReducer, utilsGroup_d_loaderSuccessSelector as loaderSuccessSelector, utilsGroup_d_loaderValueSelector as loaderValueSelector, utilsGroup_d_normalizeListPage as normalizeListPage, utilsGroup_d_processesDecrementMeta as processesDecrementMeta, utilsGroup_d_processesIncrementMeta as processesIncrementMeta, utilsGroup_d_processesLoaderReducer as processesLoaderReducer, utilsGroup_d_processesLoaderResetMeta as processesLoaderResetMeta, utilsGroup_d_resetMeta as resetMeta, utilsGroup_d_serializeParams as serializeParams, utilsGroup_d_serializeSearchConfig as serializeSearchConfig, utilsGroup_d_successMeta as successMeta };
  export type { utilsGroup_d_EntityAction as EntityAction, utilsGroup_d_EntityId as EntityId, utilsGroup_d_EntityListState as EntityListState, utilsGroup_d_EntityLoaderAction as EntityLoaderAction, utilsGroup_d_EntityLoaderMeta as EntityLoaderMeta, utilsGroup_d_EntityLoaderState as EntityLoaderState, utilsGroup_d_EntityMeta as EntityMeta, utilsGroup_d_EntityProcessesLoaderAction as EntityProcessesLoaderAction, utilsGroup_d_EntityProcessesLoaderMeta as EntityProcessesLoaderMeta, utilsGroup_d_EntityProcessesLoaderState as EntityProcessesLoaderState, utilsGroup_d_EntityState as EntityState, utilsGroup_d_LoaderAction as LoaderAction, utilsGroup_d_LoaderMeta as LoaderMeta, utilsGroup_d_LoaderState as LoaderState, utilsGroup_d_ProcessesLoaderAction as ProcessesLoaderAction, utilsGroup_d_ProcessesLoaderMeta as ProcessesLoaderMeta, utilsGroup_d_ProcessesLoaderState as ProcessesLoaderState };
}

declare const LOAD_ANONYMOUS_CONSENT_TEMPLATES = "[Anonymous Consents] Load Anonymous Consent Templates";
declare const LOAD_ANONYMOUS_CONSENT_TEMPLATES_SUCCESS = "[Anonymous Consents] Load Anonymous Consent Templates Success";
declare const LOAD_ANONYMOUS_CONSENT_TEMPLATES_FAIL = "[Anonymous Consents] Load Anonymous Consent Templates Fail";
declare const RESET_LOAD_ANONYMOUS_CONSENT_TEMPLATES = "[Anonymous Consents] Reset Load Anonymous Consent Templates";
declare const GET_ALL_ANONYMOUS_CONSENTS = "[Anonymous Consents] Get All Anonymous Consents";
declare const GET_ANONYMOUS_CONSENT = "[Anonymous Consents] Get Anonymous Consent";
declare const SET_ANONYMOUS_CONSENTS = "[Anonymous Consents] Set Anonymous Consents";
declare const GIVE_ANONYMOUS_CONSENT = "[Anonymous Consents] Give Anonymous Consent";
declare const WITHDRAW_ANONYMOUS_CONSENT = "[Anonymous Consents] Withdraw Anonymous Consent";
declare const TOGGLE_ANONYMOUS_CONSENTS_BANNER_DISMISSED = "[Anonymous Consents] Toggle Anonymous Consents Banner Dismissed";
declare const TOGGLE_ANONYMOUS_CONSENT_TEMPLATES_UPDATED = "[Anonymous Consents] Anonymous Consent Templates Updated";
declare const ANONYMOUS_CONSENT_CHECK_UPDATED_VERSIONS = "[Anonymous Consents] Check Updated Versions";
declare class LoadAnonymousConsentTemplates extends LoaderLoadAction {
    readonly type = "[Anonymous Consents] Load Anonymous Consent Templates";
    constructor();
}
declare class LoadAnonymousConsentTemplatesSuccess extends LoaderSuccessAction {
    payload: ConsentTemplate[];
    readonly type = "[Anonymous Consents] Load Anonymous Consent Templates Success";
    constructor(payload: ConsentTemplate[]);
}
declare class LoadAnonymousConsentTemplatesFail extends LoaderFailAction implements ErrorAction {
    readonly type = "[Anonymous Consents] Load Anonymous Consent Templates Fail";
    constructor(payload: any);
}
declare class ResetLoadAnonymousConsentTemplates extends LoaderResetAction {
    readonly type = "[Anonymous Consents] Reset Load Anonymous Consent Templates";
    constructor();
}
declare class GetAllAnonymousConsents {
    readonly type = "[Anonymous Consents] Get All Anonymous Consents";
    constructor();
}
declare class GetAnonymousConsent {
    templateCode: string;
    readonly type = "[Anonymous Consents] Get Anonymous Consent";
    constructor(templateCode: string);
}
declare class SetAnonymousConsents {
    payload: AnonymousConsent[];
    readonly type = "[Anonymous Consents] Set Anonymous Consents";
    constructor(payload: AnonymousConsent[]);
}
declare class GiveAnonymousConsent {
    templateCode: string;
    readonly type = "[Anonymous Consents] Give Anonymous Consent";
    constructor(templateCode: string);
}
declare class WithdrawAnonymousConsent {
    templateCode: string;
    readonly type = "[Anonymous Consents] Withdraw Anonymous Consent";
    constructor(templateCode: string);
}
declare class ToggleAnonymousConsentsBannerDissmissed {
    dismissed: boolean;
    readonly type = "[Anonymous Consents] Toggle Anonymous Consents Banner Dismissed";
    constructor(dismissed: boolean);
}
declare class ToggleAnonymousConsentTemplatesUpdated {
    updated: boolean;
    readonly type = "[Anonymous Consents] Anonymous Consent Templates Updated";
    constructor(updated: boolean);
}
declare class AnonymousConsentCheckUpdatedVersions {
    readonly type = "[Anonymous Consents] Check Updated Versions";
    constructor();
}
type AnonymousConsentsActions = LoadAnonymousConsentTemplates | LoadAnonymousConsentTemplatesSuccess | LoadAnonymousConsentTemplatesFail | ResetLoadAnonymousConsentTemplates | GetAllAnonymousConsents | SetAnonymousConsents | GetAnonymousConsent | GiveAnonymousConsent | WithdrawAnonymousConsent | ToggleAnonymousConsentsBannerDissmissed | ToggleAnonymousConsentTemplatesUpdated | AnonymousConsentCheckUpdatedVersions;

declare const anonymousConsentsGroup_d_ANONYMOUS_CONSENT_CHECK_UPDATED_VERSIONS: typeof ANONYMOUS_CONSENT_CHECK_UPDATED_VERSIONS;
type anonymousConsentsGroup_d_AnonymousConsentCheckUpdatedVersions = AnonymousConsentCheckUpdatedVersions;
declare const anonymousConsentsGroup_d_AnonymousConsentCheckUpdatedVersions: typeof AnonymousConsentCheckUpdatedVersions;
type anonymousConsentsGroup_d_AnonymousConsentsActions = AnonymousConsentsActions;
declare const anonymousConsentsGroup_d_GET_ALL_ANONYMOUS_CONSENTS: typeof GET_ALL_ANONYMOUS_CONSENTS;
declare const anonymousConsentsGroup_d_GET_ANONYMOUS_CONSENT: typeof GET_ANONYMOUS_CONSENT;
declare const anonymousConsentsGroup_d_GIVE_ANONYMOUS_CONSENT: typeof GIVE_ANONYMOUS_CONSENT;
type anonymousConsentsGroup_d_GetAllAnonymousConsents = GetAllAnonymousConsents;
declare const anonymousConsentsGroup_d_GetAllAnonymousConsents: typeof GetAllAnonymousConsents;
type anonymousConsentsGroup_d_GetAnonymousConsent = GetAnonymousConsent;
declare const anonymousConsentsGroup_d_GetAnonymousConsent: typeof GetAnonymousConsent;
type anonymousConsentsGroup_d_GiveAnonymousConsent = GiveAnonymousConsent;
declare const anonymousConsentsGroup_d_GiveAnonymousConsent: typeof GiveAnonymousConsent;
declare const anonymousConsentsGroup_d_LOAD_ANONYMOUS_CONSENT_TEMPLATES: typeof LOAD_ANONYMOUS_CONSENT_TEMPLATES;
declare const anonymousConsentsGroup_d_LOAD_ANONYMOUS_CONSENT_TEMPLATES_FAIL: typeof LOAD_ANONYMOUS_CONSENT_TEMPLATES_FAIL;
declare const anonymousConsentsGroup_d_LOAD_ANONYMOUS_CONSENT_TEMPLATES_SUCCESS: typeof LOAD_ANONYMOUS_CONSENT_TEMPLATES_SUCCESS;
type anonymousConsentsGroup_d_LoadAnonymousConsentTemplates = LoadAnonymousConsentTemplates;
declare const anonymousConsentsGroup_d_LoadAnonymousConsentTemplates: typeof LoadAnonymousConsentTemplates;
type anonymousConsentsGroup_d_LoadAnonymousConsentTemplatesFail = LoadAnonymousConsentTemplatesFail;
declare const anonymousConsentsGroup_d_LoadAnonymousConsentTemplatesFail: typeof LoadAnonymousConsentTemplatesFail;
type anonymousConsentsGroup_d_LoadAnonymousConsentTemplatesSuccess = LoadAnonymousConsentTemplatesSuccess;
declare const anonymousConsentsGroup_d_LoadAnonymousConsentTemplatesSuccess: typeof LoadAnonymousConsentTemplatesSuccess;
declare const anonymousConsentsGroup_d_RESET_LOAD_ANONYMOUS_CONSENT_TEMPLATES: typeof RESET_LOAD_ANONYMOUS_CONSENT_TEMPLATES;
type anonymousConsentsGroup_d_ResetLoadAnonymousConsentTemplates = ResetLoadAnonymousConsentTemplates;
declare const anonymousConsentsGroup_d_ResetLoadAnonymousConsentTemplates: typeof ResetLoadAnonymousConsentTemplates;
declare const anonymousConsentsGroup_d_SET_ANONYMOUS_CONSENTS: typeof SET_ANONYMOUS_CONSENTS;
type anonymousConsentsGroup_d_SetAnonymousConsents = SetAnonymousConsents;
declare const anonymousConsentsGroup_d_SetAnonymousConsents: typeof SetAnonymousConsents;
declare const anonymousConsentsGroup_d_TOGGLE_ANONYMOUS_CONSENTS_BANNER_DISMISSED: typeof TOGGLE_ANONYMOUS_CONSENTS_BANNER_DISMISSED;
declare const anonymousConsentsGroup_d_TOGGLE_ANONYMOUS_CONSENT_TEMPLATES_UPDATED: typeof TOGGLE_ANONYMOUS_CONSENT_TEMPLATES_UPDATED;
type anonymousConsentsGroup_d_ToggleAnonymousConsentTemplatesUpdated = ToggleAnonymousConsentTemplatesUpdated;
declare const anonymousConsentsGroup_d_ToggleAnonymousConsentTemplatesUpdated: typeof ToggleAnonymousConsentTemplatesUpdated;
type anonymousConsentsGroup_d_ToggleAnonymousConsentsBannerDissmissed = ToggleAnonymousConsentsBannerDissmissed;
declare const anonymousConsentsGroup_d_ToggleAnonymousConsentsBannerDissmissed: typeof ToggleAnonymousConsentsBannerDissmissed;
declare const anonymousConsentsGroup_d_WITHDRAW_ANONYMOUS_CONSENT: typeof WITHDRAW_ANONYMOUS_CONSENT;
type anonymousConsentsGroup_d_WithdrawAnonymousConsent = WithdrawAnonymousConsent;
declare const anonymousConsentsGroup_d_WithdrawAnonymousConsent: typeof WithdrawAnonymousConsent;
declare namespace anonymousConsentsGroup_d {
  export { anonymousConsentsGroup_d_ANONYMOUS_CONSENT_CHECK_UPDATED_VERSIONS as ANONYMOUS_CONSENT_CHECK_UPDATED_VERSIONS, anonymousConsentsGroup_d_AnonymousConsentCheckUpdatedVersions as AnonymousConsentCheckUpdatedVersions, anonymousConsentsGroup_d_GET_ALL_ANONYMOUS_CONSENTS as GET_ALL_ANONYMOUS_CONSENTS, anonymousConsentsGroup_d_GET_ANONYMOUS_CONSENT as GET_ANONYMOUS_CONSENT, anonymousConsentsGroup_d_GIVE_ANONYMOUS_CONSENT as GIVE_ANONYMOUS_CONSENT, anonymousConsentsGroup_d_GetAllAnonymousConsents as GetAllAnonymousConsents, anonymousConsentsGroup_d_GetAnonymousConsent as GetAnonymousConsent, anonymousConsentsGroup_d_GiveAnonymousConsent as GiveAnonymousConsent, anonymousConsentsGroup_d_LOAD_ANONYMOUS_CONSENT_TEMPLATES as LOAD_ANONYMOUS_CONSENT_TEMPLATES, anonymousConsentsGroup_d_LOAD_ANONYMOUS_CONSENT_TEMPLATES_FAIL as LOAD_ANONYMOUS_CONSENT_TEMPLATES_FAIL, anonymousConsentsGroup_d_LOAD_ANONYMOUS_CONSENT_TEMPLATES_SUCCESS as LOAD_ANONYMOUS_CONSENT_TEMPLATES_SUCCESS, anonymousConsentsGroup_d_LoadAnonymousConsentTemplates as LoadAnonymousConsentTemplates, anonymousConsentsGroup_d_LoadAnonymousConsentTemplatesFail as LoadAnonymousConsentTemplatesFail, anonymousConsentsGroup_d_LoadAnonymousConsentTemplatesSuccess as LoadAnonymousConsentTemplatesSuccess, anonymousConsentsGroup_d_RESET_LOAD_ANONYMOUS_CONSENT_TEMPLATES as RESET_LOAD_ANONYMOUS_CONSENT_TEMPLATES, anonymousConsentsGroup_d_ResetLoadAnonymousConsentTemplates as ResetLoadAnonymousConsentTemplates, anonymousConsentsGroup_d_SET_ANONYMOUS_CONSENTS as SET_ANONYMOUS_CONSENTS, anonymousConsentsGroup_d_SetAnonymousConsents as SetAnonymousConsents, anonymousConsentsGroup_d_TOGGLE_ANONYMOUS_CONSENTS_BANNER_DISMISSED as TOGGLE_ANONYMOUS_CONSENTS_BANNER_DISMISSED, anonymousConsentsGroup_d_TOGGLE_ANONYMOUS_CONSENT_TEMPLATES_UPDATED as TOGGLE_ANONYMOUS_CONSENT_TEMPLATES_UPDATED, anonymousConsentsGroup_d_ToggleAnonymousConsentTemplatesUpdated as ToggleAnonymousConsentTemplatesUpdated, anonymousConsentsGroup_d_ToggleAnonymousConsentsBannerDissmissed as ToggleAnonymousConsentsBannerDissmissed, anonymousConsentsGroup_d_WITHDRAW_ANONYMOUS_CONSENT as WITHDRAW_ANONYMOUS_CONSENT, anonymousConsentsGroup_d_WithdrawAnonymousConsent as WithdrawAnonymousConsent };
  export type { anonymousConsentsGroup_d_AnonymousConsentsActions as AnonymousConsentsActions };
}

declare const getAnonymousConsentTemplatesState: MemoizedSelector<StateWithAnonymousConsents, LoaderState<ConsentTemplate[]>>;
declare const getAnonymousConsentTemplatesValue: MemoizedSelector<StateWithAnonymousConsents, ConsentTemplate[]>;
declare const getAnonymousConsentTemplatesLoading: MemoizedSelector<StateWithAnonymousConsents, boolean>;
declare const getAnonymousConsentTemplatesSuccess: MemoizedSelector<StateWithAnonymousConsents, boolean>;
declare const getAnonymousConsentTemplatesError: MemoizedSelector<StateWithAnonymousConsents, boolean>;
declare const getAnonymousConsentTemplate: (templateCode: string) => MemoizedSelector<StateWithAnonymousConsents, ConsentTemplate | undefined>;

declare const getAnonymousConsentTemplatesUpdate: MemoizedSelector<StateWithAnonymousConsents, boolean>;
declare const getAnonymousConsentsBannerDismissed: MemoizedSelector<StateWithAnonymousConsents, boolean>;

declare const getAnonymousConsents: MemoizedSelector<StateWithAnonymousConsents, AnonymousConsent[]>;
declare const getAnonymousConsentByTemplateCode: (templateCode: string) => MemoizedSelector<StateWithAnonymousConsents, AnonymousConsent | undefined>;

declare const getAnonymousConsentState: MemoizedSelector<StateWithAnonymousConsents, AnonymousConsentsState>;

declare const anonymousConsentsGroup_selectors_d_getAnonymousConsentByTemplateCode: typeof getAnonymousConsentByTemplateCode;
declare const anonymousConsentsGroup_selectors_d_getAnonymousConsentState: typeof getAnonymousConsentState;
declare const anonymousConsentsGroup_selectors_d_getAnonymousConsentTemplate: typeof getAnonymousConsentTemplate;
declare const anonymousConsentsGroup_selectors_d_getAnonymousConsentTemplatesError: typeof getAnonymousConsentTemplatesError;
declare const anonymousConsentsGroup_selectors_d_getAnonymousConsentTemplatesLoading: typeof getAnonymousConsentTemplatesLoading;
declare const anonymousConsentsGroup_selectors_d_getAnonymousConsentTemplatesState: typeof getAnonymousConsentTemplatesState;
declare const anonymousConsentsGroup_selectors_d_getAnonymousConsentTemplatesSuccess: typeof getAnonymousConsentTemplatesSuccess;
declare const anonymousConsentsGroup_selectors_d_getAnonymousConsentTemplatesUpdate: typeof getAnonymousConsentTemplatesUpdate;
declare const anonymousConsentsGroup_selectors_d_getAnonymousConsentTemplatesValue: typeof getAnonymousConsentTemplatesValue;
declare const anonymousConsentsGroup_selectors_d_getAnonymousConsents: typeof getAnonymousConsents;
declare const anonymousConsentsGroup_selectors_d_getAnonymousConsentsBannerDismissed: typeof getAnonymousConsentsBannerDismissed;
declare namespace anonymousConsentsGroup_selectors_d {
  export {
    anonymousConsentsGroup_selectors_d_getAnonymousConsentByTemplateCode as getAnonymousConsentByTemplateCode,
    anonymousConsentsGroup_selectors_d_getAnonymousConsentState as getAnonymousConsentState,
    anonymousConsentsGroup_selectors_d_getAnonymousConsentTemplate as getAnonymousConsentTemplate,
    anonymousConsentsGroup_selectors_d_getAnonymousConsentTemplatesError as getAnonymousConsentTemplatesError,
    anonymousConsentsGroup_selectors_d_getAnonymousConsentTemplatesLoading as getAnonymousConsentTemplatesLoading,
    anonymousConsentsGroup_selectors_d_getAnonymousConsentTemplatesState as getAnonymousConsentTemplatesState,
    anonymousConsentsGroup_selectors_d_getAnonymousConsentTemplatesSuccess as getAnonymousConsentTemplatesSuccess,
    anonymousConsentsGroup_selectors_d_getAnonymousConsentTemplatesUpdate as getAnonymousConsentTemplatesUpdate,
    anonymousConsentsGroup_selectors_d_getAnonymousConsentTemplatesValue as getAnonymousConsentTemplatesValue,
    anonymousConsentsGroup_selectors_d_getAnonymousConsents as getAnonymousConsents,
    anonymousConsentsGroup_selectors_d_getAnonymousConsentsBannerDismissed as getAnonymousConsentsBannerDismissed,
  };
}

/**
 * Anonymous consents state synced to browser storage.
 */
type SyncedAnonymousConsentsState = Partial<AnonymousConsentsState>;
/**
 * Responsible for saving the anonymous consents data in browser storage.
 */
declare class AnonymousConsentsStatePersistenceService implements OnDestroy {
    protected statePersistenceService: StatePersistenceService;
    protected store: Store<StateWithAnonymousConsents>;
    protected anonymousConsentsService: AnonymousConsentsService;
    protected subscription: Subscription;
    constructor(statePersistenceService: StatePersistenceService, store: Store<StateWithAnonymousConsents>, anonymousConsentsService: AnonymousConsentsService);
    /**
     * Identifier used for storage key.
     */
    protected key: string;
    /**
     * Initializes the synchronization between state and browser storage.
     */
    initSync(): void;
    /**
     * Gets and transforms state from different sources into the form that should
     * be saved in storage.
     */
    protected getAuthState(): Observable<SyncedAnonymousConsentsState>;
    /**
     * Function called on each browser storage read.
     * Used to update state from browser -> state.
     */
    protected onRead(state: SyncedAnonymousConsentsState | undefined): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnonymousConsentsStatePersistenceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AnonymousConsentsStatePersistenceService>;
}

declare class AnonymousConsentsStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AnonymousConsentsStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AnonymousConsentsStoreModule, never, [typeof i1.CommonModule, typeof StateModule, typeof i2.StoreFeatureModule, typeof i4.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AnonymousConsentsStoreModule>;
}

declare class AnonymousConsentsModule {
    static forRoot(): ModuleWithProviders<AnonymousConsentsModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnonymousConsentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AnonymousConsentsModule, never, [typeof AnonymousConsentsStoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AnonymousConsentsModule>;
}

declare abstract class AnonymousConsentsConfig extends OccConfig {
    anonymousConsents?: {
        /**
         * Specify the consent template ID to be show on the registration page.
         */
        registerConsent?: string;
        /**
         * Show the legal description at the top of the anonymous consents dialog.
         */
        showLegalDescriptionInDialog?: boolean;
        /**
         * Specify the list of consent template IDs that are required and which can't be toggled off.
         */
        requiredConsents?: string[];
        /**
         * Consent management page configuration.
         */
        consentManagementPage?: {
            /**
             * Show all anonymous consents on the consent management page.
             */
            showAnonymousConsents?: boolean;
            /**
             * A list of consent template IDs that should be hidden on the consent management page.
             */
            hideConsents?: string[];
        };
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<AnonymousConsentsConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AnonymousConsentsConfig>;
}
declare module './spartacus-core' {
    interface Config extends AnonymousConsentsConfig {
    }
}

declare const defaultAnonymousConsentsConfig: AnonymousConsentsConfig;

declare class AnonymousConsentTemplatesConnector {
    protected adapter: AnonymousConsentTemplatesAdapter;
    constructor(adapter: AnonymousConsentTemplatesAdapter);
    loadAnonymousConsentTemplates(): Observable<ConsentTemplate[]>;
    loadAnonymousConsents(): Observable<AnonymousConsent[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnonymousConsentTemplatesConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AnonymousConsentTemplatesConnector>;
}

declare const ANONYMOUS_CONSENT_NORMALIZER: InjectionToken<Converter<string, AnonymousConsent[]>>;

declare class AnonymousConsentsInterceptor implements HttpInterceptor {
    private anonymousConsentsService;
    private authService;
    private occEndpoints;
    private config;
    constructor(anonymousConsentsService: AnonymousConsentsService, authService: AuthService, occEndpoints: OccEndpointsService, config: AnonymousConsentsConfig);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    private handleResponse;
    private handleRequest;
    private isOccUrl;
    private giveRequiredConsents;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnonymousConsentsInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AnonymousConsentsInterceptor>;
}

interface TranslationResourceKey {
    [key: string]: any;
}
interface TranslationResources {
    [lang: string]: {
        [chunkName: string]: TranslationResourceKey;
    };
}
interface TranslationChunksConfig {
    [chunk: string]: string[];
}

declare abstract class I18nConfig {
    i18n?: {
        /**
         * When there are missing translation resources for the active language, the fallback language will be used.
         */
        fallbackLang?: string | false;
        /**
         * Configuration for lazy loading of translation files.
         * For eager loading of translations please use config option `i18n.resources`
         */
        backend?: {
            /**
             * The path for loading JSON translations via HTTP requests.
             * The path should contain the following placeholders:
             * - `{{lng}}` for language
             * - `{{ns}}` for the name of chunk.
             *
             * Example:
             * ```ts
             * loadPath: 'assets/i18n-assets/{{lng}}/{{ns}}.json'
             * ```
             *
             * **NOTE**:
             * This option is NOT recommended for loading translations from local assets.
             * For this case, use the config option `i18n.backend.loader` instead,
             * which is more performant (especially in SSR).
             *
             * This option is recommended ONLY for loading translations resources
             * from an external server.
             */
            loadPath?: string;
            /**
             * Function that load translation resources asynchronously.
             *
             * Returns a Promise with translation resources for the given language and the chunk name.
             *
             * This function can use e.g. a dynamic import() to code-split and lazy load
             * the translation resources.
             *
             * @param lng language
             * @param ns  translation's chunk name (namespace)
             * @example
             * ```ts
             * loader: (language, chunkName) => import(`../../assets/i18n-assets/${language}/${chunkName}.json`)
             * ```
             */
            loader?: (language: string, chunkName: string) => Promise<TranslationResourceKey>;
        };
        /**
         * Reference to translation resources that are eagerly bundled with JS app.
         * For lazy loading of translations please use config option `i18n.backend` instead.
         */
        resources?: TranslationResources;
        /**
         * Logs i18n events (like loading translation resources) to the console. Don't use in production!
         */
        debug?: boolean;
        /**
         * Mapping that assigns keys' namespaces to specific chunks. The main purpose of chunks is to lazy load them.
         */
        chunks?: {
            [chunk: string]: string[];
        };
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<I18nConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<I18nConfig>;
}
declare module './spartacus-core' {
    interface Config extends I18nConfig {
    }
}

declare class I18nConfigInitializer implements ConfigInitializer {
    protected configInit: ConfigInitializerService;
    readonly scopes: string[];
    readonly configFactory: () => Promise<I18nConfig>;
    constructor(configInit: ConfigInitializerService);
    /**
     * Resolves the `fallbackLang` based on the default language from config `context.language` .
     */
    protected resolveConfig(): Observable<I18nConfig>;
    static ɵfac: i0.ɵɵFactoryDeclaration<I18nConfigInitializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<I18nConfigInitializer>;
}

declare abstract class TranslationService {
    /**
     * Translates given key with options.
     * It accepts also an array of keys. It allows for providing multiple variations of a key or multiple keys that may be used interchangeably as fallback.
     * In case the primary key is not available, the fallback keys will be attempted in the order they are provided.
     * The first key that can be resolved will be used for the translation.
     *
     * Note: When using lazy-loading of translation chunks, it will first load all the chunks for the corresponding keys before attempting to resolve the value.
     * This ensures that all the necessary data is available before the translation is performed.
     *
     * @param key translation key or array of keys
     * @param options values for interpolation in translation
     * @param whitespaceUntilLoaded if true, immediately emits a non-breaking space
     */
    translate: (key: string | string[], options?: any, whitespaceUntilLoaded?: boolean) => Observable<string>;
    /**
     * Loads chunks with translations
     *
     * @param chunkNames array of chunk names to be loaded
     */
    loadChunks: (chunkNames: string | string[]) => Promise<any>;
}

declare class TranslatePipe implements PipeTransform, OnDestroy {
    protected service: TranslationService;
    protected cd: ChangeDetectorRef;
    private lastKey;
    private lastOptions;
    private translatedValue;
    private sub;
    protected logger: LoggerService;
    constructor(service: TranslationService, cd: ChangeDetectorRef);
    transform(input: Translatable | string | string[], options?: TranslatableParams): string;
    private translate;
    private markForCheck;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<TranslatePipe, "cxTranslate", true>;
}

declare class CxDatePipe extends DatePipe implements PipeTransform {
    protected language: LanguageService;
    protected logger: LoggerService;
    constructor(language: LanguageService);
    transform(value: any, format?: string, timezone?: string): string | null;
    transform(value: null | undefined, format?: string, timezone?: string): null;
    private getLang;
    private getActiveLang;
    private reportMissingLocaleData;
    static ɵfac: i0.ɵɵFactoryDeclaration<CxDatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<CxDatePipe, "cxDate", true>;
}

declare class CxNumericPipe extends DecimalPipe implements PipeTransform {
    protected language: LanguageService;
    protected logger: LoggerService;
    constructor(language: LanguageService);
    transform(value: any | number | string, digitsInfo?: string): string | null;
    transform(value: null | undefined, digitsInfo?: string): null;
    protected getLang(): string;
    protected getActiveLang(): string;
    protected reportMissingLocaleData(lang: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CxNumericPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<CxNumericPipe, "cxNumeric", true>;
}

declare class I18nModule {
    static forRoot(): ModuleWithProviders<I18nModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<I18nModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<I18nModule, never, [typeof TranslatePipe, typeof CxDatePipe, typeof CxNumericPipe], [typeof TranslatePipe, typeof CxDatePipe, typeof CxNumericPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<I18nModule>;
}

declare class CmsStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CmsStoreModule, never, [typeof i1.CommonModule, typeof StateModule, typeof i2.StoreFeatureModule, typeof i4.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CmsStoreModule>;
}

declare class PageMetaModule {
    static forRoot(): ModuleWithProviders<PageMetaModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageMetaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PageMetaModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PageMetaModule>;
}

declare class CmsModule {
    static forRoot(): ModuleWithProviders<CmsModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CmsModule, never, [typeof CmsStoreModule, typeof PageMetaModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CmsModule>;
}

declare class ProcessStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProcessStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProcessStoreModule, never, [typeof StateModule, typeof i2.StoreFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProcessStoreModule>;
}

declare class ProcessModule {
    static forRoot(): ModuleWithProviders<ProcessModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProcessModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProcessModule, never, [typeof ProcessStoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProcessModule>;
}

/**
 * @deprecated Please use a different util to provide values of feature toggles:
 *             ```ts
 *             provideFeatureToggles({
 *               [string]: boolean
 *             })
 *             ```
 *             instead of
 *             ```ts
 *             provideConfig({
 *               features: {
 *                 [string]: boolean
 *               }
 *             })
 *             ```
 *             If you need to inject feature toggles, please inject `FeatureToggles` token instead of `FeaturesConfig`.
 */
declare abstract class FeaturesConfig {
    /**
     * @deprecated Please use a different util to provide values of feature toggles:
     *             ```ts
     *             provideFeatureToggles({
     *               [string]: boolean
     *             })
     *             ```
     *             instead of
     *             ```ts
     *             provideConfig({
     *               features: {
     *                 [string]: boolean
     *               }
     *             })
     *             ```
     */
    features?: {
        /**
         * Configure feature level.
         * Value corresponds to a specific release version number: '1.0', '1.1', etc.
         * Each subsequent level contains all of the features from previous one.
         *
         * @deprecated Please use named feature flags instead of feature level.
         *             Moreover, please use a different util to provide values of feature toggles:
         *             ```ts
         *             provideFeatureToggles({
         *               [string]: boolean
         *             })
         *             ```
         *             instead of
         *             ```ts
         *             provideConfig({
         *               features: {
         *                 [string]: boolean
         *               }
         *             })
         *             ```
         */
        level?: string;
        /**
         * @deprecated Please use a different util to provide values of feature toggles:
         *             ```ts
         *             provideFeatureToggles({
         *               [string]: boolean
         *             })
         *             ```
         *             instead of
         *             ```ts
         *             provideConfig({
         *               features: {
         *                 [string]: boolean
         *               }
         *             })
         *             ```
         */
        [_: string]: string | boolean | undefined;
        /**
         * Enables displaying consignment tracking info in the order details view
         *
         * It's is enabled by default since v1.2.
         */
        consignmentTracking?: boolean;
        /**
         * @deprecated - this feature will be moved into INJECTION_TOKEN in https://jira.tools.sap/browse/CXSPA-13592
         *
         * The 3.0 version introduced an unified configuration that emits new configuration
         * every time lazy loaded module is instantiated. To ease transition to this new
         * mechanism, the same changes are also published to global Config token under
         * the hood, which could cause issues in some implementations.
         *
         * This option allows to disable this mechanism, i.e.:
         *  - configuration won't change after app will be bootstrapped
         *  - if any service would like to take into an account configuration from
         *    lazy loaded modules, it will have to use ConfigurationService.unifiedConfig$
         *
         * It's disabled by default and recommended to keep it so.
         */
        disableConfigUpdates?: boolean;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<FeaturesConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FeaturesConfig>;
}
declare module './spartacus-core' {
    interface Config extends FeaturesConfig {
    }
}

/**
 * Properties for gradual adaptation to breaking changes in Spartacus via feature toggles.
 * Each toggle has its own lifespan defined in the official docs.
 * It should be provided in the root injector (in an eagerly loaded module).
 */
declare abstract class FeatureToggles {
    static ɵfac: i0.ɵɵFactoryDeclaration<FeatureToggles, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FeatureToggles>;
}
interface FeatureToggles extends FeatureTogglesInterface {
}
type FeatureToggleKey = keyof FeatureToggles;
type FeatureToggleExpression = FeatureToggleKey | `!${FeatureToggleKey}`;
/**
 * DefaultFeatureToggles token, used to build FeatureToggles. Built from DefaultFeatureTogglesChunk's
 */
declare const DefaultFeatureToggles: InjectionToken<FeatureToggles>;
/**
 * RootFeatureToggles token, used to build Global FeatureToggles. Built from FeatureTogglesChunks
 */
declare const RootFeatureToggles: InjectionToken<FeatureToggles>;
/**
 * FeatureTogglesChunk token, contributes to FeatureToggles.
 * Should not be used directly, use `provideFeatureToggles` or `provideFeatureTogglesFactory` instead.
 */
declare const FeatureTogglesChunk: InjectionToken<FeatureToggles[]>;
/**
 * DefaultFeatureTogglesChunk token, contributes to DefaultFeatureToggles.
 * Should not be used directly, use `provideDefaultFeatureToggles` or `provideDefaultFeatureTogglesFactory` instead.
 *
 * General rule is, that all FeatureToggles provided in libraries should be provided as `default`.
 */
declare const DefaultFeatureTogglesChunk: InjectionToken<FeatureToggles[]>;

type FeatureTogglesFactory = (...props: any[]) => FeatureToggles;
/**
 * Enables gradual adaptation to breaking changes in Spartacus via feature toggles.
 * Each toggle has its own lifespan defined in the official docs.
 * It should be provided in the root injector (in an eagerly loaded module).
 *
 * For using in a library, call `provideDefaultFeatureToggles() instead.
 *
 * @param toggles FeatureToggles object
 */
declare function provideFeatureToggles(toggles?: FeatureToggles): ValueProvider;
/**
 * Enables gradual adaptation to breaking changes in Spartacus via feature toggles.
 * Each toggle has its own lifespan defined in the official docs.
 * It should be provided in the root injector (in an eagerly loaded module).
 *
 * For using in a library, call `provideDefaultFeatureToggles() instead.
 *
 * @param featureTogglesFactory Factory Function that returns FeatureToggles object
 */
declare function provideFeatureTogglesFactory(featureTogglesFactory: FeatureTogglesFactory): FactoryProvider;
/**
 * It's a helper function to provide DefaultFeatureTogglesChunk token
 *
 * CAUTION: It should be provided only in the root injector, i.e. in eagerly loaded module.
 *
 * @param toggles FeatureToggles object
 */
declare function provideDefaultFeatureToggles(toggles?: FeatureToggles): ValueProvider;
/**
 * It's a helper function to provide DefaultFeatureTogglesChunk toggles with a factory function
 *
 * CAUTION: It should be provided only in the root injector, i.e. in eagerly loaded module.
 *
 * @param featureTogglesFactory Factory Function that returns FeatureToggles object
 */
declare function provideDefaultFeatureTogglesFactory(featureTogglesFactory: FeatureTogglesFactory): FactoryProvider;

/**
 * @deprecated - Use FeatureToggles instead
 */
declare class FeatureConfigService {
    protected config: FeaturesConfig;
    constructor(config: FeaturesConfig);
    /**
     * @deprecated - features level is no longer used
     */
    isLevel(version: string): boolean;
    isEnabled(feature: FeatureToggleExpression): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FeatureConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FeatureConfigService>;
}

/**
 * @deprecated  Unused directive. Please use named feature flags instead of feature level.
 */
declare class FeatureLevelDirective {
    protected templateRef: TemplateRef<any>;
    protected viewContainer: ViewContainerRef;
    protected featureConfig: FeatureConfigService;
    constructor(templateRef: TemplateRef<any>, viewContainer: ViewContainerRef, featureConfig: FeatureConfigService);
    private hasView;
    set cxFeatureLevel(level: string | number);
    static ɵfac: i0.ɵɵFactoryDeclaration<FeatureLevelDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FeatureLevelDirective, "[cxFeatureLevel]", never, { "cxFeatureLevel": { "alias": "cxFeatureLevel"; "required": false; }; }, {}, never, never, true, never>;
}

declare class FeatureDirective {
    protected templateRef: TemplateRef<any>;
    protected viewContainer: ViewContainerRef;
    protected featureConfig: FeatureConfigService;
    constructor(templateRef: TemplateRef<any>, viewContainer: ViewContainerRef, featureConfig: FeatureConfigService);
    private hasView;
    set cxFeature(feature: FeatureToggleExpression);
    static ɵfac: i0.ɵɵFactoryDeclaration<FeatureDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FeatureDirective, "[cxFeature]", never, { "cxFeature": { "alias": "cxFeature"; "required": false; }; }, {}, never, never, true, never>;
}

declare class FeaturesConfigModule {
    static forRoot(defaultLevel?: string): ModuleWithProviders<FeaturesConfigModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FeaturesConfigModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FeaturesConfigModule, never, [typeof FeatureLevelDirective, typeof FeatureDirective], [typeof FeatureLevelDirective, typeof FeatureDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FeaturesConfigModule>;
}

declare class JavaRegExpConverter {
    logger: LoggerService;
    /**
     * Pattern that extracts modifiers from the Java regexp.
     *
     * Java regexps MAY start with ONE or MANY modifiers like `(?MODIFIERS)PATTERN`. Examples:
     * - `(?i)` for Case Insensitive Mode: `(?i)PATTERN`
     * - `(?u)` for Unicode-Aware Case Folding; `(?u)PATTERN`
     * - or multiple combined:  `(?iu)PATTERN`
     * - (more modifiers in the official Java docs https://docs.oracle.com/javase/8/docs/api/java/util/regex/Pattern.html)
     *
     * This pattern extracts 3 parts from the input string, i.e. for `(?iu)PATTERN`:
     *    1. original modifiers syntax, i.e. `(?iu)` (or undefined if no modifiers present)
     *    2. extracted modifiers, i.e. `iu` (or undefined if no modifiers present)
     *    3. the rest of the regexp, i.e. `PATTERN`
     */
    private readonly EXTRACT_JAVA_REGEXP_MODIFIERS;
    /**
     * Converts RegExp from Java syntax to Javascript, by recognizing Java regexp modifiers
     * and converting them to the Javascript ones (i.e. case insensitive mode: `(?i)PATTERN` -> `/pattern/i`)
     *
     * **CAUTION!** Not all features and modifiers of Java regexps are valid in Javascript!
     * If unsupported feature or modifier is used, then `null` will be returned instead of Javascript RegExp.
     *
     * See differences between Java and Javascript regexps:
     * - https://stackoverflow.com/questions/8754444/convert-javascript-regular-expression-to-java-syntax
     * - https://en.wikipedia.org/wiki/Comparison_of_regular_expression_engines#Language_features
     */
    toJsRegExp(javaSyntax: string): RegExp | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<JavaRegExpConverter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<JavaRegExpConverter>;
}

declare class SiteContextConfigInitializer implements ConfigInitializer {
    protected baseSiteService: BaseSiteService;
    protected javaRegExpConverter: JavaRegExpConverter;
    protected winRef: WindowRef;
    readonly scopes: string[];
    readonly configFactory: () => Promise<SiteContextConfig>;
    protected federatedLoginService: FederatedLoginService;
    constructor(baseSiteService: BaseSiteService, javaRegExpConverter: JavaRegExpConverter, winRef: WindowRef);
    private get currentUrl();
    /**
     * Emits the site context config basing on the current base site data.
     *
     * Completes after emitting the value.
     */
    protected resolveConfig(): Observable<SiteContextConfig>;
    protected getConfig(source: BaseSite): SiteContextConfig;
    private isCurrentBaseSite;
    /**
     * Returns an array of url encoded site context parameters.
     *
     * It maps the string "storefront" (used in OCC) to the "baseSite" (used in Spartacus)
     */
    private getUrlParams;
    /**
     * Returns iso codes in a array, where the first element is the default iso code.
     */
    private getIsoCodes;
    /**
     * Moves to the start of the array the first element that satisfies the given predicate.
     *
     * @param array array to modify
     * @param predicate function called on elements
     */
    private moveToFirst;
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteContextConfigInitializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SiteContextConfigInitializer>;
}

declare class SiteContextStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteContextStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SiteContextStoreModule, never, [typeof i1.CommonModule, typeof i2.StoreFeatureModule, typeof i4.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SiteContextStoreModule>;
}

/**
 * Builds and registers the site context events
 */
declare class SiteContextEventBuilder {
    protected actionsSubject: ActionsSubject;
    protected eventService: EventService;
    constructor(actionsSubject: ActionsSubject, eventService: EventService);
    /**
     * Registers the site context events
     */
    protected register(): void;
    /**
     * Register the language set action
     */
    protected registerSetLanguage(): void;
    /**
     * Register the currency set action
     */
    protected registerSetCurrency(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteContextEventBuilder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SiteContextEventBuilder>;
}

declare class SiteContextEventModule {
    constructor(_siteContextEventBuilder: SiteContextEventBuilder);
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteContextEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SiteContextEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SiteContextEventModule>;
}

declare class SiteContextModule {
    static forRoot(): ModuleWithProviders<SiteContextModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteContextModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SiteContextModule, never, [typeof StateModule, typeof SiteContextStoreModule, typeof SiteContextEventModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SiteContextModule>;
}

declare class LazyLoadingModule {
    static forRoot(): ModuleWithProviders<LazyLoadingModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LazyLoadingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LazyLoadingModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LazyLoadingModule>;
}

declare class HttpTimeoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<HttpTimeoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HttpTimeoutModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HttpTimeoutModule>;
}

declare class HttpModule {
    static forRoot(): ModuleWithProviders<HttpModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<HttpModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HttpModule, never, [typeof HttpTimeoutModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HttpModule>;
}

declare class SiteThemeStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteThemeStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SiteThemeStoreModule, never, [typeof i1.CommonModule, typeof i2.StoreFeatureModule, typeof i4.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SiteThemeStoreModule>;
}

declare class SiteThemeModule {
    static forRoot(): ModuleWithProviders<SiteThemeModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteThemeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SiteThemeModule, never, [typeof StateModule, typeof SiteThemeStoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SiteThemeModule>;
}

declare class BaseCoreModule {
    static forRoot(): ModuleWithProviders<BaseCoreModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BaseCoreModule, never, [typeof ErrorHandlingModule, typeof StateModule, typeof ConfigModule, typeof ConfigInitializerModule, typeof ConfigValidatorModule, typeof I18nModule, typeof CmsModule, typeof GlobalMessageModule, typeof ProcessModule, typeof FeaturesConfigModule, typeof SiteContextModule, typeof MetaTagConfigModule, typeof BaseOccModule, typeof LazyLoadingModule, typeof HttpModule, typeof SiteThemeModule, typeof FederatedLoginModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BaseCoreModule>;
}

declare const POINT_OF_SERVICE_NORMALIZER: InjectionToken<Converter<any, PointOfService>>;

declare const PAYMENT_DETAILS_NORMALIZER: InjectionToken<Converter<any, PaymentDetails>>;

interface StandardCmsComponentConfig {
    CMSSiteContextComponent?: CmsComponentMapping;
    CMSLinkComponent?: CmsComponentMapping;
    SimpleResponsiveBannerComponent?: CmsComponentMapping;
    SimpleBannerComponent?: CmsComponentMapping;
    BannerComponent?: CmsComponentMapping;
    CMSParagraphComponent?: CmsComponentMapping;
    BreadcrumbComponent?: CmsComponentMapping;
    NavigationComponent?: CmsComponentMapping;
    FooterNavigationComponent?: CmsComponentMapping;
    CategoryNavigationComponent?: CmsComponentMapping;
    ProductAddToCartComponent?: CmsComponentMapping;
    MiniCartComponent?: CmsComponentMapping;
    ProductCarouselComponent?: CmsComponentMapping;
    SearchBoxComponent?: CmsComponentMapping;
    ProductReferencesComponent?: CmsComponentMapping;
    CMSTabParagraphComponent?: CmsComponentMapping;
    LoginComponent?: CmsComponentMapping;
}
interface JspIncludeCmsComponentConfig {
    AccountAddressBookComponent?: CmsComponentMapping;
    ForgotPasswordComponent?: CmsComponentMapping;
    ResetPasswordComponent?: CmsComponentMapping;
    ProductDetailsTabComponent?: CmsComponentMapping;
    ProductSpecsTabComponent?: CmsComponentMapping;
    ProductReviewsTabComponent?: CmsComponentMapping;
}
declare const JSP_INCLUDE_CMS_COMPONENT_TYPE = "JspIncludeComponent";
declare const CMS_FLEX_COMPONENT_TYPE = "CMSFlexComponent";
/**
 * Configuration of the CMS component's child routes
 */
interface CmsComponentChildRoutesConfig {
    /**
     * Route `data` property to apply on the parent (host) route of the CMS child routes.
     */
    parent?: Pick<Route, 'data'>;
    /**
     * Child routes defined by the existence of the CMS component on the page.
     */
    children?: Route[];
}
interface CmsComponentMapping<T = CmsComponent> {
    component?: any;
    /**
     * Configurable component providers for cms components.
     *
     * Component services are designed to be non-singleton services and are scoped
     * to the component injection tree. The advantage of these services is that they can
     * resolve services injected to the component injection tree. However, these services
     * cannot be extended with the native Angular DI system.
     *
     * The configurable component providers mitigate this downside, by allowing you to provide
     * component providers through services.
     */
    providers?: StaticProvider[];
    childRoutes?: Route[] | CmsComponentChildRoutesConfig;
    disableSSR?: boolean;
    i18nKeys?: string[];
    guards?: any[];
    /**
     * The component data can be statically configured. The data can be used for various reasons:
     * - Improve performance with an initial data that doesn't require API response
     * - Introduce UI properties that are not available on the API
     * - Build ghost design based on the initial data that is used prior to the backend data is loaded
     */
    data?: T;
    /**
     * DeferLoading can be specified globally, but also per component.
     * Some components require direct loading while it's not initially
     * in the viewport.
     */
    deferLoading?: DeferLoadingStrategy;
}
/** Strategy to control the loading strategy of DOM elements. */
declare enum DeferLoadingStrategy {
    /** Defers loading of DOM elements until element is near/in the users view port */
    DEFER = "DEFERRED-LOADING",
    /** Renders the DOM instantly without being concerned with the view port */
    INSTANT = "INSTANT-LOADING"
}
interface CMSComponentConfig extends StandardCmsComponentConfig, JspIncludeCmsComponentConfig {
    [componentType: string]: CmsComponentMapping | undefined;
}
interface FeatureModuleConfig {
    /**
     * Lazy resolved feature module
     */
    module?: () => Promise<any>;
    /**
     * Lazy resolved dependency modules or features referenced by name
     */
    dependencies?: ((() => Promise<any>) | string)[];
    /**
     * Cms components covered by this feature
     */
    cmsComponents?: string[];
}
declare abstract class CmsConfig extends OccConfig {
    featureModules?: {
        [featureName: string]: FeatureModuleConfig | string;
    };
    cmsComponents?: CMSComponentConfig;
    componentsLoading?: {
        pageSize?: number;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CmsConfig>;
}
declare module './spartacus-core' {
    interface Config extends CmsConfig {
    }
}

declare const defaultCmsModuleConfig: CmsConfig;

/**
 * The `CmsPageConfig` is used to build pages by configuration.
 * The interfaces are designed to have a clean configuration for
 * static CMS structure. Ordinary attributes that are not
 * required for configurable pages have been left out and
 * will not be serialized in the adapter logic.
 */
interface CmsPageConfig {
    /**
     * When the `ignoreBackend` is set to true, the CMS backend
     * will not be consumed. This saves network latency and is
     * useful for commodity commerce pages.
     * */
    ignoreBackend?: boolean;
    pageId?: string;
    type?: string;
    /**
     * The page title is typically used to display the page heading
     * as well as for the page title tag. The latter is used for browser
     * navigation as well as SEO and social share platforms.
     */
    title?: string;
    /**
     * the template is used to bind to the layout
     * configuration and css layout class
     */
    template?: string;
    /**
     * The page slots represent various sections on the page that
     * can contain components.
     */
    slots: {
        [key: string]: CmsPageSlotConfig;
    };
}
/**
 * The `CmsPageSlotsConfig` (plural) holds `CmsPageSlotConfig` objects.
 */
interface CmsPageSlotsConfig {
    [key: string]: CmsPageSlotConfig;
}
/**
 * The `CmsPageSlotConfig` is a simplified configuration model
 * that can be used to configure slots in static configuration,
 * rather than loading from a backend.
 */
interface CmsPageSlotConfig {
    componentIds?: string[];
    properties?: any;
}
/**
 * The `CmsStructureConfig` is used to build pages in Spartacus by configuration
 * instead of using a backend CMS system. The configuration can be used to build
 * complete pages or parts of a page. The `CmsStructureConfig` is optimized to
 * only require the necessary properties. Adapter logic is applied to serialize
 * the `CmsStructureConfig` into the required UI model.
 */
declare abstract class CmsStructureConfig extends CmsConfig {
    cmsStructure?: {
        components?: {
            [key: string]: ContentSlotComponentData | any;
        };
        pages?: CmsPageConfig[];
        slots?: CmsPageSlotsConfig;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsStructureConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CmsStructureConfig>;
}
declare module './spartacus-core' {
    interface Config extends CmsStructureConfig {
    }
}

/**
 * Service that provides access to CMS structure from a static
 * configuration or configuration file. This class uses static
 * configuration is designed in async fashion so that configurations
 * can be loaded from a file or stream.
 *
 * The intent of the `CmsStructureConfigService` however is to provide
 * fast loading pages and default cms structure for commodity commerce.
 */
declare abstract class CmsStructureConfigService {
    protected cmsDataConfig: CmsStructureConfig;
    constructor(cmsDataConfig: CmsStructureConfig);
    /**
     * Merge the cms structure to the pageStructure. The page structure
     * can either hold complete page structures or global structures that
     * might apply to all pages (such has header components).
     */
    mergePageStructure(pageId: string, pageStructure: CmsStructureModel): Observable<CmsStructureModel>;
    /**
     *
     * Returns boolean observable to indicate whether the page should not be
     * loaded from the backend. This is useful for pages which are comoditized
     * and follow best practice.
     *
     * By default, configurable pages are driven by static configuration,
     * in order to allow for fast loading pages (preventing network delays).
     */
    shouldIgnoreBackend(pageId: string): Observable<boolean>;
    /**
     * returns an Observable component data from the static configuration.
     */
    getComponentFromConfig(componentId: string): Observable<ContentSlotComponentData | any>;
    /**
     * returns an Observable components data from the static configuration.
     */
    getComponentsFromConfig(ids: string[]): Observable<(ContentSlotComponentData | any)[]>;
    /**
     * returns an observable with the `PageConfig`.
     */
    protected getPageFromConfig(pageId: string): Observable<CmsPageConfig | undefined>;
    /**
     * Merge page data from the configuration into the given structure, if any.
     * If the given page structure is empty, a page is created and the page slots are
     * are merged into the page.
     */
    protected mergePage(pageId: string, pageStructure: CmsStructureModel): Observable<CmsStructureModel>;
    /**
     * Adds any pre-configured slots for pages that do not use them.
     * If pages have a slot for the given position, the configuration
     * is ignored. Even if the slot does not have inner structure (such as
     * components), so that the cms structure is able to override the (static)
     * configuration.
     */
    protected mergeSlots(pageStructure: CmsStructureModel, slots?: CmsPageSlotsConfig): Observable<CmsStructureModel>;
    protected getComponentsByPosition(slots: CmsPageSlotsConfig, position: string): ContentSlotComponentData[];
    protected getComponentById(componentId: string): ContentSlotComponentData | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsStructureConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CmsStructureConfigService>;
}

declare class CmsPageConnector {
    protected cmsPageAdapter: CmsPageAdapter;
    protected cmsStructureConfigService: CmsStructureConfigService;
    constructor(cmsPageAdapter: CmsPageAdapter, cmsStructureConfigService: CmsStructureConfigService);
    /**
     * Returns an observable with the page structure. The page structure is
     * typically loaded from a backend, but can also be returned from static
     * configuration (see `CmsStructureConfigService`).
     */
    get(pageContext: PageContext): Observable<CmsStructureModel>;
    /**
     *
     * Merge default page structure to the given `CmsStructureModel`.
     * This is beneficial for a fast setup of the UI without necessary
     * fine-grained CMS setup.
     */
    private mergeDefaultPageStructure;
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsPageConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CmsPageConnector>;
}

declare const CMS_PAGE_NORMALIZER: InjectionToken<Converter<any, CmsStructureModel>>;

declare class CmsComponentConnector {
    protected cmsStructureConfigService: CmsStructureConfigService;
    protected cmsComponentAdapter: CmsComponentAdapter;
    protected config: CmsConfig;
    constructor(cmsStructureConfigService: CmsStructureConfigService, cmsComponentAdapter: CmsComponentAdapter, config: CmsConfig);
    get<T extends CmsComponent>(id: string, pageContext: PageContext): Observable<T>;
    getList(ids: string[], pageContext: PageContext): Observable<CmsComponent[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsComponentConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CmsComponentConnector>;
}

declare const CMS_COMPONENT_NORMALIZER: InjectionToken<Converter<any, CmsComponent>>;

declare abstract class ComponentDecorator {
    /**
     * Add attributes to CMS Component element dynamically
     * @param element: CMS component element
     * @param renderer
     * @param component: CMS component data
     */
    abstract decorate(element: Element, renderer: Renderer2, component?: ContentSlotComponentData): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComponentDecorator, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ComponentDecorator>;
}

declare abstract class SlotDecorator {
    /**
     * Add attributes to CMS Slot element dynamically
     * @param element: CMS slot element
     * @param renderer
     * @param slot: CMS slot data
     */
    abstract decorate(element: Element, renderer: Renderer2, slot?: ContentSlotData): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SlotDecorator, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SlotDecorator>;
}

interface NodeItem {
    [id_type: string]: CmsLinkComponent;
}

declare const CMS_FEATURE = "cms";
declare const NAVIGATION_DETAIL_ENTITY = "[Cms] Navigation Entity";
declare const COMPONENT_ENTITY = "[Cms] Component Entity";
interface StateWithCms {
    [CMS_FEATURE]: CmsState;
}
type ComponentsState = EntityState<ComponentsContext>;
interface ComponentsContext {
    component?: CmsComponent;
    /**
     * Page context stores an information for which context does the component exist.
     * For example, if `SiteLogoComponent` was successfully loaded for a product page with an ID of 1776948, then this object will contain:
     *
     * ```ts
     * ProductPage-1776948: {
     *  success: true,
     *  loading: false,
     *  error: false,
     *  // The `value` property indicates that the component exists for the given page context.
     *  value: true
     * }
     * ```
     *
     * If the same `SiteLogoComponent` component was tried to be loaded on homepage (page context id is `homepage`),
     * and it doesn't exist for some reason (maybe it has a restriction), then this object will contain:
     *
     * ```ts
     * ProductPage-1776948: {
     *  success: true,
     *  loading: false,
     *  error: false,
     *  // The `value` property indicates that the component exists for the given page context.
     *  value: true
     * },
     * ContentPage-homepage: {
     *  success: true,
     *  loading: false,
     *  error: false,
     *  // The `value` in this case is `false` indicating that the component was tried to be loaded, but it doesn't exist or has a restriction.
     *  value: false
     * }
     * ```
     *
     */
    pageContext: {
        [context: string]: LoaderState<boolean>;
    };
}
type IndexType = {
    content: EntityLoaderState<string>;
    product: EntityLoaderState<string>;
    category: EntityLoaderState<string>;
    catalog: EntityLoaderState<string>;
};
interface NavigationNodes {
    [nodeId: string]: NodeItem;
}
interface PageState {
    pageData: EntityState<Page>;
    index: IndexType;
}
interface CmsState {
    page: PageState;
    components: ComponentsState;
    navigation: EntityLoaderState<NodeItem>;
}

declare class CmsService {
    protected store: Store<StateWithCms>;
    protected routingService: RoutingService;
    private components;
    constructor(store: Store<StateWithCms>, routingService: RoutingService);
    /**
     * Get current CMS page data
     */
    getCurrentPage(): Observable<Page>;
    /**
     * Get CMS component data by uid
     *
     * This method can be safely and optimally used to load multiple components data at the same time.
     * Calling getComponentData multiple times for different components will always result in optimized
     * back-end request: all components requested at the same time (in one event loop) will be loaded in one network call.
     *
     * In case the component data is not present, the method will load it.
     * Otherwise, if the page context is not provided, the current page context from the router state will be used instead.
     *
     * @param uid CMS component uid
     * @param pageContext if provided, it will be used to lookup the component data.
     */
    getComponentData<T extends CmsComponent | null>(uid: string, pageContext?: PageContext): Observable<T>;
    private createComponentData;
    /**
     * Given the position, get the content slot data
     * @param position : content slot position
     */
    getContentSlot(position: string): Observable<ContentSlotData>;
    /**
     * Given navigation node uid, get items (with id and type) inside the navigation entries
     * @param navigationNodeUid : uid of the navigation node
     */
    getNavigationEntryItems(navigationNodeUid: string): Observable<NodeItem>;
    /**
     * Load navigation items data
     * @param rootUid : the uid of the root navigation node
     * @param itemList : list of items (with id and type)
     */
    loadNavigationItems(rootUid: string, itemList: {
        id: string | undefined;
        superType: string | undefined;
    }[]): void;
    /**
     * Refresh the content of the latest cms page
     */
    refreshLatestPage(): void;
    /**
     * Refresh the cms page content by page Id
     * @param pageId
     */
    refreshPageById(pageId: string): void;
    /**
     * Refresh cms component's content
     * @param uid component uid
     * @param pageContext an optional parameter that enables the caller to specify for which context the component should be refreshed.
     * If not specified, 'current' page context is used.
     */
    refreshComponent(uid: string, pageContext?: PageContext): void;
    /**
     * Given pageContext, return the CMS page data
     * @param pageContext
     */
    getPageState(pageContext: PageContext): Observable<Page>;
    /**
     * Given pageContext, return the CMS page data
     * @param pageContext
     */
    getPageComponentTypes(pageContext: PageContext): Observable<string[]>;
    /**
     * Given pageContext, return whether the CMS page data exists or not
     * @param pageContext
     */
    hasPage(pageContext: PageContext, forceReload?: boolean): Observable<boolean>;
    /**
     * Given pageContext, return the CMS page data
     **/
    getPage(pageContext: PageContext, forceReload?: boolean): Observable<Page | null>;
    getPageIndex(pageContext: PageContext): Observable<string>;
    setPageFailIndex(pageContext: PageContext, value: string): void;
    /**
     * Clear the cached component data.
     * This is useful when components need to be forcefully reloaded,
     * for example in SmartEdit context when child components need to be refreshed.
     *
     * @param uids Optional array of component UIDs to clear. If not provided, clears all cached components.
     */
    clearComponentState(uids?: string[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CmsService>;
}

declare abstract class PageMetaConfig {
    pageMeta?: PageMetaResolversConfig;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageMetaConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PageMetaConfig>;
}
declare module './spartacus-core' {
    interface Config extends PageMetaConfig {
    }
}
interface PageMetaResolversConfig {
    resolvers?: PageMetaResolverConfig[];
    /**
     * Specifies how the canonical url is created.
     */
    canonicalUrl?: CanonicalUrlOptions;
}
interface PageMetaResolverConfig {
    /**
     * PageMeta property
     */
    property: string;
    /**
     * The resolver method that must be provided on the resolver class.
     */
    method: string;
}
interface CanonicalUrlOptions {
    /**
     * Forces a trailing slash to avoid both https://www.myshop.com and https://www.myshop.com/.
     */
    forceTrailingSlash?: boolean;
    /**
     * Forces the use of `https://` in the canonical URL.
     */
    forceHttps?: boolean;
    /**
     * Forces the `www` subdomain, so that canonical URLs are always prefixed with `www.`.
     *
     * Please be aware that the logic will not detect whether your domain includes a subdomain.
     */
    forceWww?: boolean;
    /**
     * Removes query parameters from the URL to avoid page duplicates.
     *
     * This is useful in case page urls have various query parameters that are added by
     * integrations (i.e. generated links from social platform).
     *
     * The query parameter can either be removed completely, or an array of query parameter keys
     * can be provided.
     */
    removeQueryParams?: boolean | string[];
}

/**
 * Abstract class that can be used to resolve meta data for specific pages.
 * The `getScore` method is used to select the right resolver for a specific
 * page, based on a score. The score is calculated by the (non)matching page
 * type, page template, and uid.
 */
declare abstract class PageMetaResolver implements Applicable {
    /** The `PageType` is used to score the (non)matching page */
    pageType: PageType;
    /** The page template is used to score the (non)matching page template */
    pageTemplate: string;
    /** The page uid is used to score the (non)matching page ids */
    pageUid: string;
    /**
     * Returns the matching score for a resolver class, based on
     * the page type and page template.
     */
    getScore(page: Page): number;
    hasMatch(page: Page): boolean;
    getPriority(page: Page): number;
}

/**
 * Service that collects the page meta data by using injected page resolvers.
 */
declare class PageMetaService {
    protected cms: CmsService;
    protected unifiedInjector: UnifiedInjector;
    protected pageMetaConfig: PageMetaConfig;
    protected platformId: string;
    protected languageService: LanguageService;
    constructor(cms: CmsService, unifiedInjector: UnifiedInjector, pageMetaConfig: PageMetaConfig, platformId: string);
    protected resolvers$: Observable<PageMetaResolver[]>;
    protected meta$: Observable<PageMeta | null>;
    /**
     * Returns the observed page meta data for the current page.
     *
     * The data is resolved by various PageResolvers, which are configurable.
     */
    getMeta(): Observable<PageMeta | null>;
    /**
     * If a `PageResolver` has implemented a resolver interface, the resolved data
     * is merged into the `PageMeta` object.
     * @param metaResolver
     */
    protected resolve(metaResolver: PageMetaResolver): Observable<PageMeta>;
    /**
     * Returns an object with resolvers. The object properties represent the `PageMeta` property, i.e.:
     *
     * ```
     * {
     *   title: 'resolveTitle',
     *   robots: 'resolveRobots'
     * }
     * ```
     */
    protected getResolverMethods(): {
        [property: string]: string;
    };
    /**
     * Return the resolver with the best match, based on a score
     * generated by the resolver.
     *
     * Resolvers match by default on `PageType` and `page.template`.
     */
    protected getMetaResolver(page: Page): Observable<PageMetaResolver | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageMetaService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PageMetaService>;
}

/**
 * Resolves the page heading value which is used in the UI (typically
 * the `<H1>`). The page heading might differ from the page title,
 * which is used in the browser (history, tabs) and outside the storefront
 * by search crawlers (Google Search, Bing) and social crawlers (facebook,
 * pinterest).
 *
 * While there are multiple standard resolvers available, nothing stops you
 * from adding custom resolvers to the list of `PageMetaService.resolverMethods`.
 */
interface PageHeadingResolver {
    /**
     * Resolves the page heading.
     */
    resolveHeading(): Observable<string | undefined>;
}
/**
 * Resolves the page title which is first and foremost used for the page
 * title tag, but could also be used as a fallback for the page heading.
 */
interface PageTitleResolver {
    /**
     * Resolves the page title.
     */
    resolveTitle(): Observable<string | undefined>;
}
/**
 * Resolves the page description. The page description is typically used
 * in the Search Engine Result Page (SERP).
 */
interface PageDescriptionResolver {
    /**
     * Resolves the page description.
     */
    resolveDescription(): Observable<string | undefined>;
}
/**
 * Resolves breadcrumbs for the page, which are used in the
 * `BreadcrumbComponent` and Structural Data.
 */
interface PageBreadcrumbResolver {
    /**
     * Resolves the breadcrumbs for the page.
     */
    resolveBreadcrumbs(): Observable<BreadcrumbMeta[] | undefined>;
}
/**
 * Provides a method to resolve the the main image for the page.
 * This is typically used for social sharing (for example by using
 * the `og:image` metatag).
 */
interface PageImageResolver {
    /**
     * Resolves the main image for the page.
     */
    resolveImage(): Observable<string | undefined>;
}
/**
 * Resolves the robot information for the page. This is used by
 * search engines to understand whether the page and subsequential links
 * should be indexed.
 *
 */
interface PageRobotsResolver {
    /**
     * Resolves the robot meta data for the page.
     *
     * The robot meta data is used by search engines to indicate whether a page
     * should be indexed and whether links on the page should be followed for
     * further indexing.
     *
     * Robots meta tags are an alternative (or supplement) to the robots.txt as well
     * as the sitemaps.
     */
    resolveRobots(): Observable<PageRobotsMeta[] | undefined>;
}
interface CanonicalPageResolver {
    /**
     * Resolves the canonical url for the page.
     *
     * The canonical url is used by search engines to optimize the search index. Without
     * a canonical url, url variations for the same page might be considered duplicates
     * which have a negative impact on SEO.
     */
    resolveCanonicalUrl(): Observable<string | undefined>;
}

/**
 * Service to add links to the page meta data, such canonical URLs.
 */
declare class PageLinkService {
    protected pageMetaConfig: PageMetaConfig;
    protected winRef: WindowRef;
    constructor(pageMetaConfig: PageMetaConfig, winRef: WindowRef);
    private featureToggles;
    /**
     * Returns the canonical for the page.
     *
     * The canonical url is created by the help of the default `CanonicalUrlOptions` from
     * the pageMeta options. The options can be further adjusted by the options argument.
     */
    getCanonicalUrl(options?: CanonicalUrlOptions, url?: string): string;
    protected sanitizeUrl(rawUrl: string): string;
    protected buildCanonicalUrl(url: string, options: CanonicalUrlOptions): string;
    protected removeQueryParams(url: string, config: CanonicalUrlOptions): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageLinkService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PageLinkService>;
}

/**
 * Angular ActivatedRouteSnapshot extended with the custom configuration
 * of the page meta in the property `data.cxPageMeta`.
 */
interface ActivatedRouteSnapshotWithPageMeta extends ActivatedRouteSnapshot {
    routeConfig: (Route & {
        data?: Data & {
            cxPageMeta?: RoutePageMetaConfig;
        };
    }) | null;
}
/**
 * Configuration of the breadcrumb for the Route.
 */
interface RoutePageMetaConfig {
    breadcrumb?: string | RouteBreadcrumbConfig;
    /**
     * Optional resolver class implementing `RoutePageMetaResolver`.
     * The resolver instance will be implicitly inherited by all the
     * child routes of the route with defined resolver (unless some
     * child route defines its own resolver).
     */
    resolver?: Type<any>;
}
/**
 * Configuration of the breadcrumb for specific route
 */
interface RouteBreadcrumbConfig {
    /**
     * Raw text for the breadcrumb label.
     */
    raw?: string;
    /**
     * Translation key for the breadcrumb label.
     * */
    i18n?: string;
}
/**
 * Params for the breadcrumb resolver of a single activated route.
 */
interface RouteBreadcrumbResolverParams {
    url?: string;
    pageMetaConfig?: RoutePageMetaConfig;
    route?: ActivatedRouteSnapshot;
}
/**
 * Breadcrumb resolver interface for a single route
 */
interface RouteBreadcrumbResolver {
    /**
     * Turns the route definition (with its breadcrumb config) into the resolved breadcrumb.
     *
     * @param url precalculated absolute link based on the route snapshot and its ancestors in the routes tree
     * @param pageMetaConfig page meta config for the route, including the breadcrumb config
     * @param route the route snapshot
     */
    resolveBreadcrumbs(params: RouteBreadcrumbResolverParams): Observable<BreadcrumbMeta[]>;
}

interface RouteWithExtras {
    route: ActivatedRouteSnapshotWithPageMeta;
    resolver: any;
    url: string;
}
interface RoutingResolveBreadcrumbsOptions {
    /**
     * Includes the current route in the breadcrumbs.
     */
    includeCurrentRoute?: boolean;
}
/**
 * Resolves the page meta based on the Angular Activated Routes
 */
declare class RoutingPageMetaResolver {
    protected activatedRoutesService: ActivatedRoutesService;
    protected injector: Injector;
    constructor(activatedRoutesService: ActivatedRoutesService, injector: Injector);
    /**
     * Array of activated routes, excluding the special Angular `root` route.
     */
    protected readonly routes$: Observable<ActivatedRouteSnapshot[]>;
    /**
     * Array of activated routes together with precalculated extras:
     *
     * - route's page meta resolver
     * - route's absolute string URL
     *
     * In case when there is no page meta resolver configured for a specific route,
     * it inherits its parent's resolver.
     *
     * When there is no page meta resolver configured for the highest parent in the hierarchy,
     * it uses the `DefaultRoutePageMetaResolver`.
     */
    protected readonly routesWithExtras$: Observable<RouteWithExtras[]>;
    /**
     * Array of breadcrumbs defined for all the activated routes (from the root route to the leaf route).
     * It emits on every completed routing navigation.
     */
    resolveBreadcrumbs(options?: RoutingResolveBreadcrumbsOptions): Observable<BreadcrumbMeta[]>;
    /**
     * Returns the instance of the RoutePageMetaResolver configured for the given activated route.
     * Returns null in case there the resolver can't be injected or is undefined.
     *
     * @param route route to resolve
     */
    protected getResolver(route: ActivatedRouteSnapshotWithPageMeta): any;
    /**
     * Resolvers breadcrumb for a specific route
     */
    protected resolveRouteBreadcrumb({ route, resolver, url, }: RouteWithExtras): Observable<BreadcrumbMeta[]>;
    /**
     * By default in breadcrumbs list we don't want to show a link to the current page, so this function
     * trims the last breadcrumb (the breadcrumb of the current route).
     *
     * This function also handles special case when the current route has a configured empty path ('' route).
     * The '' routes are often a _technical_ routes to organize other routes, assign common guards for its children, etc.
     * It shouldn't happen that '' route has a defined breadcrumb config.
     *
     * In that case, we trim not only the last route ('' route), but also its parent route with non-empty path
     * (which likely defines the breadcrumb config).
     */
    private trimCurrentRoute;
    /**
     * Returns the URL path for the given activated route in a string format.
     * (ActivatedRouteSnapshot#url contains an array of `UrlSegment`s, not a string)
     */
    private getUrlPart;
    /**
     * Returns the breadcrumb config placed in the route's `data` configuration.
     */
    protected getPageMetaConfig(route: ActivatedRouteSnapshotWithPageMeta): RoutePageMetaConfig | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<RoutingPageMetaResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RoutingPageMetaResolver>;
}

declare class BasePageMetaResolver implements PageTitleResolver, PageDescriptionResolver, PageBreadcrumbResolver, PageRobotsResolver, CanonicalPageResolver {
    protected cmsService: CmsService;
    protected translation: TranslationService;
    protected routingPageMetaResolver: RoutingPageMetaResolver;
    protected router: Router;
    protected pageLinkService: PageLinkService;
    constructor(cmsService: CmsService, translation: TranslationService, routingPageMetaResolver: RoutingPageMetaResolver, router: Router, pageLinkService: PageLinkService);
    /**
     * Helper to provide access to the current CMS page
     */
    protected page$: Observable<Page>;
    protected title$: Observable<string | undefined>;
    protected description$: Observable<string | undefined>;
    protected robots$: Observable<PageRobotsMeta[]>;
    /**
     * Breadcrumb for the home page.
     */
    protected homeBreadcrumb$: Observable<BreadcrumbMeta[]>;
    /**
     * All the resolved breadcrumbs (including those from Angular child routes).
     */
    protected breadcrumb$: Observable<BreadcrumbMeta[]>;
    resolveTitle(): Observable<string | undefined>;
    resolveDescription(): Observable<string | undefined>;
    /**
     * Resolves a single breadcrumb item to the home page for each `ContentPage`.
     * The home page label is resolved from the translation service.
     */
    resolveBreadcrumbs(): Observable<BreadcrumbMeta[] | undefined>;
    resolveRobots(): Observable<PageRobotsMeta[]>;
    resolveCanonicalUrl(options?: CanonicalUrlOptions): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BasePageMetaResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BasePageMetaResolver>;
}

declare const defaultPageMetaConfig: PageMetaConfig;

/**
 * Resolves the page data for all Content Pages based on the `PageType.CONTENT_PAGE`.
 * More specific resolvers for content pages can be implemented by making them more
 * specific, for example by using the page template (see `CartPageMetaResolver`).
 *
 * The page title, description, breadcrumbs and robot information are resolved from the
 * content page data. The canonical URL is resolved from the URL.
 */
declare class ContentPageMetaResolver extends PageMetaResolver implements PageTitleResolver, PageDescriptionResolver, PageBreadcrumbResolver, PageRobotsResolver, CanonicalPageResolver {
    protected basePageMetaResolver: BasePageMetaResolver;
    constructor(basePageMetaResolver: BasePageMetaResolver);
    resolveTitle(): Observable<string | undefined>;
    resolveDescription(): Observable<string | undefined>;
    resolveBreadcrumbs(): Observable<BreadcrumbMeta[] | undefined>;
    resolveRobots(): Observable<PageRobotsMeta[]>;
    resolveCanonicalUrl(): Observable<string | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentPageMetaResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ContentPageMetaResolver>;
}

/**
 * Resolves the breadcrumb for the Angular ActivatedRouteSnapshot
 */
declare abstract class DefaultRoutePageMetaResolver implements RouteBreadcrumbResolver {
    protected translation: TranslationService;
    constructor(translation: TranslationService);
    /**
     * Resolves breadcrumb based on the given url and the breadcrumb config.
     *
     * - When breadcrumb config is empty, it returns an empty breadcrumb.
     * - When breadcrumb config is a string or object with `i18n` property,
     *    it translates it and use as a label of the returned breadcrumb.
     * - When breadcrumb config is an object with property `raw`, then
     *    it's used as a label of the returned breadcrumb.
     */
    resolveBreadcrumbs({ url, pageMetaConfig, }: RouteBreadcrumbResolverParams): Observable<BreadcrumbMeta[]>;
    /**
     * Translates the configured breadcrumb label
     */
    protected translateBreadcrumbLabel(breadcrumbConfig: string | RouteBreadcrumbConfig): Observable<string>;
    /**
     * Resolves dynamic data for the whole resolver.
     */
    protected getParams(): Observable<{
        [_: string]: any;
    } | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DefaultRoutePageMetaResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DefaultRoutePageMetaResolver>;
}

/**
 * Service that used to add dynamic attributes to CMS component
 * and slot elements.
 */
declare class DynamicAttributeService {
    protected unifiedInjector: UnifiedInjector;
    private componentDecorators$;
    private slotDecorators$;
    constructor(unifiedInjector: UnifiedInjector);
    /**
     * Add dynamic attributes to CMS component element
     * @param element: CMS component element
     * @param renderer
     * @param componentData: component data
     */
    addAttributesToComponent(element: Element, renderer: Renderer2, componentData?: ContentSlotComponentData): void;
    /**
     * Add dynamic attributes to CMS slot element
     * @param element: CMS slot element
     * @param renderer
     * @param slotData: slot data
     */
    addAttributesToSlot(element: Element, renderer: Renderer2, slotData?: ContentSlotData): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynamicAttributeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DynamicAttributeService>;
}

declare const LOAD_CMS_COMPONENT = "[Cms] Load Component";
declare const LOAD_CMS_COMPONENT_FAIL = "[Cms] Load Component Fail";
declare const LOAD_CMS_COMPONENT_SUCCESS = "[Cms] Load Component Success";
declare const CMS_GET_COMPONENT_FROM_PAGE = "[Cms] Get Component from Page";
declare const CLEAR_CMS_COMPONENT = "[Cms] Clear Component";
declare class LoadCmsComponent extends EntityLoadAction {
    payload: {
        uid: string;
        pageContext?: PageContext;
    };
    readonly type = "[Cms] Load Component";
    constructor(payload: {
        uid: string;
        pageContext?: PageContext;
    });
}
declare class LoadCmsComponentFail extends EntityFailAction implements ErrorAction {
    payload: {
        uid: string;
        error: any;
        pageContext: PageContext;
    };
    readonly type = "[Cms] Load Component Fail";
    constructor(payload: {
        uid: string;
        error: any;
        pageContext: PageContext;
    });
}
declare class LoadCmsComponentSuccess<T extends CmsComponent> extends EntitySuccessAction {
    payload: {
        component: T;
        uid?: string;
        pageContext: PageContext;
    };
    readonly type = "[Cms] Load Component Success";
    constructor(payload: {
        component: T;
        uid?: string;
        pageContext: PageContext;
    });
}
declare class CmsGetComponentFromPage<T extends CmsComponent> extends EntitySuccessAction {
    payload: {
        component: T;
        pageContext: PageContext;
    } | {
        component: T;
        pageContext: PageContext;
    }[];
    readonly type = "[Cms] Get Component from Page";
    constructor(payload: {
        component: T;
        pageContext: PageContext;
    } | {
        component: T;
        pageContext: PageContext;
    }[]);
}
declare class ClearCmsComponent extends EntityLoaderResetAction {
    payload: {
        uid: string;
    };
    readonly type = "[Cms] Clear Component";
    constructor(payload: {
        uid: string;
    });
}
type CmsComponentAction<T extends CmsComponent> = LoadCmsComponent | LoadCmsComponentFail | LoadCmsComponentSuccess<T> | CmsGetComponentFromPage<T> | ClearCmsComponent;

declare const LOAD_CMS_NAVIGATION_ITEMS = "[Cms] Load NavigationEntry items";
declare const LOAD_CMS_NAVIGATION_ITEMS_FAIL = "[Cms] Load NavigationEntry items Fail";
declare const LOAD_CMS_NAVIGATION_ITEMS_SUCCESS = "[Cms] Load NavigationEntry items Success";
declare class LoadCmsNavigationItems extends EntityLoadAction {
    payload: {
        nodeId: string;
        items: any[];
    };
    readonly type = "[Cms] Load NavigationEntry items";
    constructor(payload: {
        nodeId: string;
        items: any[];
    });
}
declare class LoadCmsNavigationItemsFail extends EntityFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Cms] Load NavigationEntry items Fail";
    constructor(nodeId: string, payload: any);
}
declare class LoadCmsNavigationItemsSuccess extends EntitySuccessAction {
    payload: {
        nodeId: string;
        components: any[];
    };
    readonly type = "[Cms] Load NavigationEntry items Success";
    constructor(payload: {
        nodeId: string;
        components: any[];
    });
}
type CmsNavigationEntryItemAction = LoadCmsNavigationItems | LoadCmsNavigationItemsFail | LoadCmsNavigationItemsSuccess;

declare const LOAD_CMS_PAGE_DATA = "[Cms] Load Page Data";
declare const LOAD_CMS_PAGE_DATA_FAIL = "[Cms] Load Page Data Fail";
declare const LOAD_CMS_PAGE_DATA_SUCCESS = "[Cms] Load Page Data Success";
declare const CMS_SET_PAGE_SUCCESS_INDEX = "[Cms] Set Page Success Index";
declare const CMS_SET_PAGE_FAIL_INDEX = "[Cms] Set Page Fail Index";
declare class LoadCmsPageData extends EntityLoadAction {
    payload: PageContext;
    readonly type = "[Cms] Load Page Data";
    constructor(payload: PageContext);
}
declare class LoadCmsPageDataFail extends EntityFailAction implements ErrorAction {
    readonly type = "[Cms] Load Page Data Fail";
    constructor(pageContext: PageContext, error: any);
}
declare class LoadCmsPageDataSuccess extends EntitySuccessAction {
    readonly type = "[Cms] Load Page Data Success";
    constructor(pageContext: PageContext, payload: Page);
}
declare class CmsSetPageSuccessIndex extends EntitySuccessAction {
    readonly type = "[Cms] Set Page Success Index";
    constructor(pageContext: PageContext, payload: Page);
}
declare class CmsSetPageFailIndex extends EntityFailAction implements ErrorAction {
    payload: string;
    readonly type = "[Cms] Set Page Fail Index";
    constructor(pageContext: PageContext, payload: string);
}
type CmsPageAction = LoadCmsPageData | LoadCmsPageDataFail | LoadCmsPageDataSuccess | CmsSetPageFailIndex;

declare const cmsGroup_actions_d_CLEAR_CMS_COMPONENT: typeof CLEAR_CMS_COMPONENT;
declare const cmsGroup_actions_d_CMS_GET_COMPONENT_FROM_PAGE: typeof CMS_GET_COMPONENT_FROM_PAGE;
declare const cmsGroup_actions_d_CMS_SET_PAGE_FAIL_INDEX: typeof CMS_SET_PAGE_FAIL_INDEX;
declare const cmsGroup_actions_d_CMS_SET_PAGE_SUCCESS_INDEX: typeof CMS_SET_PAGE_SUCCESS_INDEX;
type cmsGroup_actions_d_ClearCmsComponent = ClearCmsComponent;
declare const cmsGroup_actions_d_ClearCmsComponent: typeof ClearCmsComponent;
type cmsGroup_actions_d_CmsComponentAction<T extends CmsComponent> = CmsComponentAction<T>;
type cmsGroup_actions_d_CmsGetComponentFromPage<T extends CmsComponent> = CmsGetComponentFromPage<T>;
declare const cmsGroup_actions_d_CmsGetComponentFromPage: typeof CmsGetComponentFromPage;
type cmsGroup_actions_d_CmsNavigationEntryItemAction = CmsNavigationEntryItemAction;
type cmsGroup_actions_d_CmsPageAction = CmsPageAction;
type cmsGroup_actions_d_CmsSetPageFailIndex = CmsSetPageFailIndex;
declare const cmsGroup_actions_d_CmsSetPageFailIndex: typeof CmsSetPageFailIndex;
type cmsGroup_actions_d_CmsSetPageSuccessIndex = CmsSetPageSuccessIndex;
declare const cmsGroup_actions_d_CmsSetPageSuccessIndex: typeof CmsSetPageSuccessIndex;
declare const cmsGroup_actions_d_LOAD_CMS_COMPONENT: typeof LOAD_CMS_COMPONENT;
declare const cmsGroup_actions_d_LOAD_CMS_COMPONENT_FAIL: typeof LOAD_CMS_COMPONENT_FAIL;
declare const cmsGroup_actions_d_LOAD_CMS_COMPONENT_SUCCESS: typeof LOAD_CMS_COMPONENT_SUCCESS;
declare const cmsGroup_actions_d_LOAD_CMS_NAVIGATION_ITEMS: typeof LOAD_CMS_NAVIGATION_ITEMS;
declare const cmsGroup_actions_d_LOAD_CMS_NAVIGATION_ITEMS_FAIL: typeof LOAD_CMS_NAVIGATION_ITEMS_FAIL;
declare const cmsGroup_actions_d_LOAD_CMS_NAVIGATION_ITEMS_SUCCESS: typeof LOAD_CMS_NAVIGATION_ITEMS_SUCCESS;
declare const cmsGroup_actions_d_LOAD_CMS_PAGE_DATA: typeof LOAD_CMS_PAGE_DATA;
declare const cmsGroup_actions_d_LOAD_CMS_PAGE_DATA_FAIL: typeof LOAD_CMS_PAGE_DATA_FAIL;
declare const cmsGroup_actions_d_LOAD_CMS_PAGE_DATA_SUCCESS: typeof LOAD_CMS_PAGE_DATA_SUCCESS;
type cmsGroup_actions_d_LoadCmsComponent = LoadCmsComponent;
declare const cmsGroup_actions_d_LoadCmsComponent: typeof LoadCmsComponent;
type cmsGroup_actions_d_LoadCmsComponentFail = LoadCmsComponentFail;
declare const cmsGroup_actions_d_LoadCmsComponentFail: typeof LoadCmsComponentFail;
type cmsGroup_actions_d_LoadCmsComponentSuccess<T extends CmsComponent> = LoadCmsComponentSuccess<T>;
declare const cmsGroup_actions_d_LoadCmsComponentSuccess: typeof LoadCmsComponentSuccess;
type cmsGroup_actions_d_LoadCmsNavigationItems = LoadCmsNavigationItems;
declare const cmsGroup_actions_d_LoadCmsNavigationItems: typeof LoadCmsNavigationItems;
type cmsGroup_actions_d_LoadCmsNavigationItemsFail = LoadCmsNavigationItemsFail;
declare const cmsGroup_actions_d_LoadCmsNavigationItemsFail: typeof LoadCmsNavigationItemsFail;
type cmsGroup_actions_d_LoadCmsNavigationItemsSuccess = LoadCmsNavigationItemsSuccess;
declare const cmsGroup_actions_d_LoadCmsNavigationItemsSuccess: typeof LoadCmsNavigationItemsSuccess;
type cmsGroup_actions_d_LoadCmsPageData = LoadCmsPageData;
declare const cmsGroup_actions_d_LoadCmsPageData: typeof LoadCmsPageData;
type cmsGroup_actions_d_LoadCmsPageDataFail = LoadCmsPageDataFail;
declare const cmsGroup_actions_d_LoadCmsPageDataFail: typeof LoadCmsPageDataFail;
type cmsGroup_actions_d_LoadCmsPageDataSuccess = LoadCmsPageDataSuccess;
declare const cmsGroup_actions_d_LoadCmsPageDataSuccess: typeof LoadCmsPageDataSuccess;
declare namespace cmsGroup_actions_d {
  export { cmsGroup_actions_d_CLEAR_CMS_COMPONENT as CLEAR_CMS_COMPONENT, cmsGroup_actions_d_CMS_GET_COMPONENT_FROM_PAGE as CMS_GET_COMPONENT_FROM_PAGE, cmsGroup_actions_d_CMS_SET_PAGE_FAIL_INDEX as CMS_SET_PAGE_FAIL_INDEX, cmsGroup_actions_d_CMS_SET_PAGE_SUCCESS_INDEX as CMS_SET_PAGE_SUCCESS_INDEX, cmsGroup_actions_d_ClearCmsComponent as ClearCmsComponent, cmsGroup_actions_d_CmsGetComponentFromPage as CmsGetComponentFromPage, cmsGroup_actions_d_CmsSetPageFailIndex as CmsSetPageFailIndex, cmsGroup_actions_d_CmsSetPageSuccessIndex as CmsSetPageSuccessIndex, cmsGroup_actions_d_LOAD_CMS_COMPONENT as LOAD_CMS_COMPONENT, cmsGroup_actions_d_LOAD_CMS_COMPONENT_FAIL as LOAD_CMS_COMPONENT_FAIL, cmsGroup_actions_d_LOAD_CMS_COMPONENT_SUCCESS as LOAD_CMS_COMPONENT_SUCCESS, cmsGroup_actions_d_LOAD_CMS_NAVIGATION_ITEMS as LOAD_CMS_NAVIGATION_ITEMS, cmsGroup_actions_d_LOAD_CMS_NAVIGATION_ITEMS_FAIL as LOAD_CMS_NAVIGATION_ITEMS_FAIL, cmsGroup_actions_d_LOAD_CMS_NAVIGATION_ITEMS_SUCCESS as LOAD_CMS_NAVIGATION_ITEMS_SUCCESS, cmsGroup_actions_d_LOAD_CMS_PAGE_DATA as LOAD_CMS_PAGE_DATA, cmsGroup_actions_d_LOAD_CMS_PAGE_DATA_FAIL as LOAD_CMS_PAGE_DATA_FAIL, cmsGroup_actions_d_LOAD_CMS_PAGE_DATA_SUCCESS as LOAD_CMS_PAGE_DATA_SUCCESS, cmsGroup_actions_d_LoadCmsComponent as LoadCmsComponent, cmsGroup_actions_d_LoadCmsComponentFail as LoadCmsComponentFail, cmsGroup_actions_d_LoadCmsComponentSuccess as LoadCmsComponentSuccess, cmsGroup_actions_d_LoadCmsNavigationItems as LoadCmsNavigationItems, cmsGroup_actions_d_LoadCmsNavigationItemsFail as LoadCmsNavigationItemsFail, cmsGroup_actions_d_LoadCmsNavigationItemsSuccess as LoadCmsNavigationItemsSuccess, cmsGroup_actions_d_LoadCmsPageData as LoadCmsPageData, cmsGroup_actions_d_LoadCmsPageDataFail as LoadCmsPageDataFail, cmsGroup_actions_d_LoadCmsPageDataSuccess as LoadCmsPageDataSuccess };
  export type { cmsGroup_actions_d_CmsComponentAction as CmsComponentAction, cmsGroup_actions_d_CmsNavigationEntryItemAction as CmsNavigationEntryItemAction, cmsGroup_actions_d_CmsPageAction as CmsPageAction };
}

declare const getComponentsState: MemoizedSelector<StateWithCms, ComponentsState>;
declare const componentsContextSelectorFactory: (uid: string) => MemoizedSelector<StateWithCms, ComponentsContext | undefined>;
declare const componentsLoaderStateSelectorFactory: (uid: string, context: string) => MemoizedSelector<StateWithCms, LoaderState<boolean>>;
/**
 * This selector will return:
 *   - true: component for this context exists
 *   - false: component for this context doesn't exist
 *   - undefined: if the exists status for component is unknown
 *
 * @param uid
 * @param context
 */
declare const componentsContextExistsSelectorFactory: (uid: string, context: string) => MemoizedSelector<StateWithCms, boolean>;
declare const componentsDataSelectorFactory: (uid: string) => MemoizedSelector<StateWithCms, CmsComponent | undefined>;
/**
 * This selector will return:
 *   - CmsComponent instance: if we have component data for specified context
 *   - null: if there is no component data for specified context
 *   - undefined: if status of component data for specified context is unknown
 *
 * @param uid
 * @param context
 */
declare const componentsSelectorFactory: (uid: string, context: string) => MemoizedSelector<StateWithCms, CmsComponent | null | undefined>;

declare const getCmsState: MemoizedSelector<StateWithCms, CmsState>;

declare const getNavigationEntryItemState: MemoizedSelector<StateWithCms, EntityLoaderState<NodeItem>>;
declare const getSelectedNavigationEntryItemState: (nodeId: string) => MemoizedSelector<StateWithCms, LoaderState<NodeItem>>;
declare const getNavigationEntryItems: (nodeId: string) => MemoizedSelector<StateWithCms, NodeItem>;

declare const getPageState: MemoizedSelector<StateWithCms, PageState>;
declare const getPageStateIndex: MemoizedSelector<StateWithCms, IndexType>;
declare const getPageStateIndexEntityLoaderState: (pageContext: PageContext) => MemoizedSelector<StateWithCms, EntityLoaderState<string>>;
declare const getPageStateIndexLoaderState: (pageContext: PageContext) => MemoizedSelector<StateWithCms, LoaderState<string>>;
declare const getPageStateIndexValue: (pageContext: PageContext) => MemoizedSelector<StateWithCms, string>;
declare const getPageEntities: MemoizedSelector<StateWithCms, {
    [id: string]: Page;
}>;
declare const getPageData: (pageContext: PageContext) => MemoizedSelector<StateWithCms, Page>;
declare const getPageComponentTypes: (pageContext: PageContext) => MemoizedSelector<StateWithCms, string[]>;
declare const getCurrentSlotSelectorFactory: (pageContext: PageContext, position: string) => MemoizedSelector<StateWithCms, ContentSlotData | undefined>;

declare const cmsGroup_selectors_d_componentsContextExistsSelectorFactory: typeof componentsContextExistsSelectorFactory;
declare const cmsGroup_selectors_d_componentsContextSelectorFactory: typeof componentsContextSelectorFactory;
declare const cmsGroup_selectors_d_componentsDataSelectorFactory: typeof componentsDataSelectorFactory;
declare const cmsGroup_selectors_d_componentsLoaderStateSelectorFactory: typeof componentsLoaderStateSelectorFactory;
declare const cmsGroup_selectors_d_componentsSelectorFactory: typeof componentsSelectorFactory;
declare const cmsGroup_selectors_d_getCmsState: typeof getCmsState;
declare const cmsGroup_selectors_d_getComponentsState: typeof getComponentsState;
declare const cmsGroup_selectors_d_getCurrentSlotSelectorFactory: typeof getCurrentSlotSelectorFactory;
declare const cmsGroup_selectors_d_getNavigationEntryItemState: typeof getNavigationEntryItemState;
declare const cmsGroup_selectors_d_getNavigationEntryItems: typeof getNavigationEntryItems;
declare const cmsGroup_selectors_d_getPageComponentTypes: typeof getPageComponentTypes;
declare const cmsGroup_selectors_d_getPageData: typeof getPageData;
declare const cmsGroup_selectors_d_getPageEntities: typeof getPageEntities;
declare const cmsGroup_selectors_d_getPageState: typeof getPageState;
declare const cmsGroup_selectors_d_getPageStateIndex: typeof getPageStateIndex;
declare const cmsGroup_selectors_d_getPageStateIndexEntityLoaderState: typeof getPageStateIndexEntityLoaderState;
declare const cmsGroup_selectors_d_getPageStateIndexLoaderState: typeof getPageStateIndexLoaderState;
declare const cmsGroup_selectors_d_getPageStateIndexValue: typeof getPageStateIndexValue;
declare const cmsGroup_selectors_d_getSelectedNavigationEntryItemState: typeof getSelectedNavigationEntryItemState;
declare namespace cmsGroup_selectors_d {
  export {
    cmsGroup_selectors_d_componentsContextExistsSelectorFactory as componentsContextExistsSelectorFactory,
    cmsGroup_selectors_d_componentsContextSelectorFactory as componentsContextSelectorFactory,
    cmsGroup_selectors_d_componentsDataSelectorFactory as componentsDataSelectorFactory,
    cmsGroup_selectors_d_componentsLoaderStateSelectorFactory as componentsLoaderStateSelectorFactory,
    cmsGroup_selectors_d_componentsSelectorFactory as componentsSelectorFactory,
    cmsGroup_selectors_d_getCmsState as getCmsState,
    cmsGroup_selectors_d_getComponentsState as getComponentsState,
    cmsGroup_selectors_d_getCurrentSlotSelectorFactory as getCurrentSlotSelectorFactory,
    cmsGroup_selectors_d_getNavigationEntryItemState as getNavigationEntryItemState,
    cmsGroup_selectors_d_getNavigationEntryItems as getNavigationEntryItems,
    cmsGroup_selectors_d_getPageComponentTypes as getPageComponentTypes,
    cmsGroup_selectors_d_getPageData as getPageData,
    cmsGroup_selectors_d_getPageEntities as getPageEntities,
    cmsGroup_selectors_d_getPageState as getPageState,
    cmsGroup_selectors_d_getPageStateIndex as getPageStateIndex,
    cmsGroup_selectors_d_getPageStateIndexEntityLoaderState as getPageStateIndexEntityLoaderState,
    cmsGroup_selectors_d_getPageStateIndexLoaderState as getPageStateIndexLoaderState,
    cmsGroup_selectors_d_getPageStateIndexValue as getPageStateIndexValue,
    cmsGroup_selectors_d_getSelectedNavigationEntryItemState as getSelectedNavigationEntryItemState,
  };
}

declare const COST_CENTER_NORMALIZER: InjectionToken<Converter<any, CostCenter>>;
declare const COST_CENTERS_NORMALIZER: InjectionToken<Converter<any, EntitiesModel<CostCenter>>>;
declare const COST_CENTER_SERIALIZER: InjectionToken<Converter<CostCenter, any>>;

declare class CostCenterModule {
    static forRoot(): ModuleWithProviders<CostCenterModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CostCenterModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CostCenterModule>;
}

/**
 * Automatically adds/removes CSS classes to/from the root element of the application,
 * based on the explicitly registered usage of feature flags.
 *
 * The CSS classes are added only for flags that are currently used and enabled in the config.
 *
 * The CSS classes for flags that are enabled BUT NOT USED are NOT ADDED to the root element.
 */
declare class FeatureStylesService {
    private rendererFactory;
    private featureToggles;
    protected logger: LoggerService;
    /**
     * Prefix for feature's CSS classes that are added to the root element
     *
     * The same as the one used in the SCSS mixin `@include forFeature()`
     */
    protected readonly CSS_FEATURE_FLAG_PREFIX = "cxFeat_";
    /**
     * Angular Renderer util to add/remove CSS classes to/from the root element.
     */
    protected renderer: i0.Renderer2;
    /**
     * The root HTML element of the application to apply CSS classes to.
     *
     * It's set by the `init()` method.
     */
    protected rootElement: HTMLElement | undefined;
    /**
     * Tracks the number of usages of each feature flag.
     *
     * - when a counter becomes >0, the feature's CSS class will be added to the root element.
     * - when a counter becomes =0, the feature's CSS class will be removed from the root element.
     */
    protected usagesCounter: Map<string, number>;
    /**
     * Saves the root element of the application for later usage in this service.
     *
     * In edge cases, if some usages of feature flags were registered
     * before the `init()` method was called, this method immediately adds
     * CSS classes to the root element for the already registered features usages.
     */
    init(rootComponent: ComponentRef<any>): void;
    /**
     * Registers the usage of a given feature flag.
     *
     * - If the feature flag enabled, this method adds the feature's CSS class
     *    to the root element.
     * - If the feature flag is disabled, this method does nothing.
     *
     * Note: Please mind to call `unregisterUsage()` when the feature is not used anymore.
     *       Otherwise, the feature's CSS class will be added to the root element forever.
     */
    registerUsage(feature: FeatureToggleKey): void;
    /**
     * Unregisters the usage of a feature flag.
     *
     * If the feature flag is enabled, this method removes the feature's CSS class
     * from the root element (unless there are other registered usages of the same feature yet).
     */
    unregisterUsage(feature: FeatureToggleKey): void;
    /**
     * Returns whether the given feature flag is enabled.
     */
    protected isEnabled(feature: FeatureToggleKey): boolean;
    /**
     * Adds the feature's CSS class to the root element, if the flag is enabled.
     *
     * It does nothing if the feature flag is disabled
     * or if the root element is not yet available.
     */
    protected addClass(feature: FeatureToggleKey): void;
    /**
     * Removes the feature's CSS class from the root element, if the flag is enabled.
     *
     * It does nothing if the feature flag is disabled
     * or if the root element is not yet available.
     */
    protected removeClass(feature: FeatureToggleKey): void;
    /**
     * Returns a feature flag's CSS class name.
     *
     * The CSS class name consists of the prefix `cxFeat_`
     * and the feature flag name.
     */
    protected getCssClass(feature: FeatureToggleKey): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<FeatureStylesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FeatureStylesService>;
}

/**
 * @deprecated - features level is no longer used
 */
declare function isFeatureLevel(config: Config, level: string): boolean;
declare function isFeatureEnabled(config: Config, feature: FeatureToggleExpression | 'disableConfigUpdates'): boolean;

/**
 * Registers the usage of the feature flag's styles in the component. Must be called in the component's constructor.
 *
 * IMPORTANT: If not called in the constructor of your component, the feature styles MIGHT NOT be activated EVEN if the flag is enabled!
 *
 * You should call it in the constructor of EVERY component that uses feature flag's styles.
 * For instance, if the SCSS of your component you have:
 * ```scss
 * %cx-my-component {
 *   ...
 *     ...
 *       @include forFeature('myFeatureFlag') { ... }
 * }
 * ```
 * ... then you should also call `useFeatureStyles('myFeatureFlag')` in the constructor of this component.
 *
 * Under the hood, to activate the styles, a corresponding CSS class is added the root element of the application.
 *
 * Note: When your component is destroyed, the CSS class is removed from the root element
 * (unless there exist yet other components that declared using the same feature flag's styles).
 */
declare function useFeatureStyles(feature: FeatureToggleKey): void;

declare const defaultBackendHttpTimeoutConfig: OccConfig;

/**
 * Angular HttpContext to configure a timeout for a HTTP request.
 *
 * Allows for configuring different timeout time per platform (in server vs. in browser).
 *
 * When undefined, no timeout will be applied.
 */
declare const HTTP_TIMEOUT_CONFIG: HttpContextToken<HttpTimeoutConfig | undefined>;
/**
 * Configuration for timeout of HTTP requests
 */
interface HttpTimeoutConfig {
    /**
     * Timeout in milliseconds for backend requests made in a server.
     */
    server?: number;
    /**
     * Timeout in milliseconds for backend requests made in a browser.
     */
    browser?: number;
}
declare abstract class BackendHttpTimeoutConfig {
    timeout?: HttpTimeoutConfig;
}
declare module './spartacus-core' {
    interface BackendConfig extends BackendHttpTimeoutConfig {
    }
}

/**
 * It throws an error when a request takes longer than the specified time.
 */
declare class HttpTimeoutInterceptor implements HttpInterceptor {
    protected windowRef: WindowRef;
    protected config: OccConfig;
    protected logger: LoggerService;
    constructor(windowRef: WindowRef, config: OccConfig);
    /**
     * It throws an error when a request takes longer than the specified time.
     *
     * It starts counting time for timeout only after the request is sent.
     */
    intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>>;
    /**
     * Returns the configured timeout value for the given request.
     *
     * The timeout can be configured specifically for a certain request
     * via HttpContextToken `HTTP_TIMEOUT_CONFIG`. When it's not available,
     * the value is taken from the global config `config.backend.timeout`.
     *
     * Depending on the platform (browser or server), the configured timeout value can be different.
     */
    protected getTimeoutValue(request: HttpRequest<unknown>): number | undefined;
    /**
     * It converts an RxJs `TimeoutError` (caused by the `timeout()` operator),
     * to a manually crafted `HttpErrorResponse` object.
     *
     * If the error is not an RxJs `TimeoutError`, it just returns the original error.
     */
    protected convertTimeoutToHttpErrorResponse({ error, request, timeoutValue, }: {
        error: unknown;
        request: HttpRequest<unknown>;
        timeoutValue: number;
    }): unknown | HttpErrorResponse;
    protected buildError(request: HttpRequest<unknown>, timeoutValue: number): Error;
    static ɵfac: i0.ɵɵFactoryDeclaration<HttpTimeoutInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HttpTimeoutInterceptor>;
}

interface B64EncodingOptions {
    /**
     * Set to `true` for Base 64 Encoding with URL and Filename Safe Alphabet
     *
     * See https://datatracker.ietf.org/doc/html/rfc4648#section-5
     */
    urlSafe?: boolean;
}
declare function encodeBase64(value: string, options?: B64EncodingOptions): string;
declare function decodeBase64(b64String: string, options?: B64EncodingOptions): string;

declare abstract class Command<PARAMS = undefined, RESULT = unknown> {
    abstract execute(parameters: PARAMS): Observable<RESULT>;
}
declare enum CommandStrategy {
    Parallel = 0,
    Queue = 1,
    CancelPrevious = 2,
    ErrorPrevious = 3
}
declare class CommandService implements OnDestroy {
    protected subscriptions: Subscription;
    constructor();
    create<PARAMS = undefined, RESULT = unknown>(commandFactory: (command: PARAMS) => Observable<RESULT>, options?: {
        strategy?: CommandStrategy;
    }): Command<PARAMS, RESULT>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommandService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CommandService>;
}

type QueryNotifier = Observable<unknown> | Type<CxEvent>;
interface QueryState<T> {
    loading: boolean;
    error: false | Error;
    data: T | undefined;
}
interface Query<RESULT, PARAMS extends unknown[] = []> {
    get(...params: PARAMS): Observable<RESULT | undefined>;
    getState(...params: PARAMS): Observable<QueryState<RESULT>>;
}
declare class QueryService implements OnDestroy {
    protected eventService: EventService;
    protected subscriptions: Subscription;
    constructor(eventService: EventService);
    create<T>(loaderFactory: () => Observable<T>, options?: {
        /** Reloads the query, while preserving the `data` until the new data is loaded */
        reloadOn?: QueryNotifier[];
        /** Resets the query to the initial state */
        resetOn?: QueryNotifier[];
    }): Query<T>;
    protected getTriggersStream(triggers: QueryNotifier[]): Observable<unknown>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QueryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QueryService>;
}

/**
 * Creates an instance of the given class and fills its properties with the given data.
 *
 * @param type reference to the class
 * @param data object with properties to be copied to the class
 */
declare function createFrom<T extends object>(type: Type<T>, data: T): T;

/**
 * Angular uses the native encodeURIComponent function,
 * but then un-encoded some characters that are allowed
 * to be part of the query according to IETF RFC 3986.
 * So, to make these characters still encoded, this encoder only
 * uses the encodeURIComponent.
 */

declare class HttpParamsURIEncoder implements HttpParameterCodec {
    encodeKey(key: string): string;
    encodeValue(value: string): string;
    decodeKey(key: string): string;
    decodeValue(value: string): string;
}

/**
 * This function checks if the provided property name is invalid.
 * It prevents the use of dangerous object keys that can lead to prototype pollution attacks.
 *
 * Prototype pollution occurs when properties like '__proto__', 'constructor', or 'prototype'
 * are added to an object, potentially leading to security vulnerabilities by modifying object prototypes.
 *
 * @param {string} key - The object property name to validate.
 * @throws {Error} If the property name is potentially dangerous.
 */
declare function isKeyInvalid(key: string): void;

/**
 * Normalizes empty strings to `undefined` for use with nullish coalescing
 *
 * ```ts
 * const x = normalizeEmpty(statusText) ?? 'N/A';
 * ```
 */
declare function normalizeEmpty(str: string | undefined | null): string | undefined | null;

declare class ObjectComparisonUtils {
    static shallowEqualObjects(objA: object, objB: object): boolean;
    static deepEqualObjects(objA: object, objB: object): boolean;
    protected static compareObjectProperties(objA: object, objB: object): boolean;
    static countOfDeepEqualObjects(obj: any, arr: Array<any>): number;
    static indexOfFirstOccurrence(obj: any, arr: Array<any>): number | undefined;
}

declare enum OccHttpErrorType {
    NOT_FOUND_ERROR = "NotFoundError",
    CLASS_MISMATCH_ERROR = "ClassMismatchError"
}
declare enum OccHttpErrorReason {
    NOT_FOUND_ERROR = "notFound"
}

/**
 * A helper function for detecting JaloObjectNoLongerValidError errors
 */
declare function isJaloError(err: HttpErrorModel): boolean;
/**
 * A helper function for detecting server (500 and above) code errors
 */
declare function isServerError(err: HttpErrorModel): boolean;
/**
 * A helper function for detecting 401 code errors
 */
declare function isAuthorizationError(err: HttpErrorModel): boolean;
declare const DEFAULT_SERVER_ERROR_RETRIES_COUNT = 2;
declare const DEFAULT_AUTHORIZATION_ERROR_RETRIES_COUNT = 2;

declare const EMAIL_PATTERN: RegExp;
declare const PASSWORD_PATTERN: RegExp;
declare const MIN_ONE_UPPER_CASE_CHARACTER_PATTERN: RegExp;
declare const MIN_ONE_DIGIT_PATTERN: RegExp;
declare const MIN_ONE_SPECIAL_CHARACTER_PATTERN: RegExp;
declare const MIN_SIX_CHARACTERS_PATTERN: RegExp;
declare const MIN_EIGHT_CHARACTERS_PATTERN: RegExp;
declare const MAX_CHARACTERS_PATTERN: RegExp;
declare const CONSECUTIVE_CHARACTERS: RegExp;
declare const STRONG_PASSWORD_PATTERN: RegExp;
declare const SECURE_PASSWORD_PATTERN: RegExp;
declare const ENDS_WITH_LEGAL_CHARACTER_PATTERN: RegExp;

/**
 * Options for the back-off operator.
 */
interface BackOffOptions {
    /**
     * Function which evaluates if the given error should be handled exponentially.
     *
     * If it returns false, the error is re-thrown.
     * Otherwise, the operation is retried.
     */
    shouldRetry?: (err: HttpErrorModel | Error) => boolean;
    /** how many times to perform the back-off. Default value is 3 times. */
    maxTries?: number;
    /** delay in ms. Default value is 300ms. Assuming the maxTries is set to 3, it means the maximum time spent retrying will be: 1*1*300 + 2*2*300 + 3*3*300 = 4200ms (4.2s) */
    delay?: number;
}
/**
 *
 * An operator which performs exponential back-off on the source stream.
 *
 * Source: https://angular.io/guide/practical-observable-usage#exponential-backoff
 *
 * @param options such as defining `maxTries`, or `delay`
 * @returns either the original error (if the given `errFn` return `false`), or the
 */
declare function backOff<T>(options?: BackOffOptions): OperatorFunction<T, T>;

/**
 * Will grab last synchronously available value from the observable stream
 * at the time of the call.
 *
 * Should be used with caution, as it's not a legitimate way for getting value
 * from the observable. Observable composition or standard subscribe method
 * should be used for most of the cases.
 *
 * @param source
 */
declare function getLastValueSync<T>(source: Observable<T>): T | undefined;

type ReturnTypes<T extends Observable<any>[]> = {
    [P in keyof T]: T[P] extends Observable<infer R> ? R : never;
};
type Observables = [Observable<any>] | Observable<any>[];
/**
 * uniteLatest is an alternative to combineLatest. The first emission is
 * emitted synchronously (just like combineLatest) and all following emissions
 * are audited and emitted using asapScheduler.
 *
 * It effectively smooths out emissions when multiple sources will emit at the
 * same time: uniteLatest will have only one emission, where combine latest will
 * have more than one (one per source changed).
 *
 * @param sources
 */
declare function uniteLatest<R extends Observables>(sources: R): Observable<ReturnTypes<R>>;

/**
 *
 * Withdraw from the source observable when notifier emits a value
 *
 * Withdraw will result in resubscribing to the source observable
 * Operator is useful to kill ongoing emission transformation on notifier emission
 *
 * @param notifier
 */
declare function withdrawOn<T>(notifier: Observable<any>): OperatorFunction<T, T>;

/**
 * Wraps the given value into an observable.
 *
 * - If the value is an Observable, it returns the value as is.
 * - If the value is a Promise, it returns an Observable that emits the result of the Promise.
 * - If the value is neither an Observable nor a Promise, it returns an Observable
 *    that immediately emits the given value.
 */
declare function wrapIntoObservable<T>(value: T | Promise<T> | Observable<T>): Observable<T>;

declare enum ScriptPlacement {
    HEAD = "head",
    BODY = "body"
}
declare class ScriptLoader {
    protected document: any;
    protected platformId: Object;
    constructor(document: any, platformId: Object);
    /**
     * Embeds a javascript from an external URL.
     *
     * @param embedOptions
     * src: URL for the script to be loaded
     * params: additional parameters to be attached to the given URL
     * attributes: the attributes of HTML script tag (exclude src)
     * callback: a function to be invoked after the script has been loaded
     * errorCallback: function to be invoked after error during script loading
     * placement: HTML body or head where script will be placed
     * disableKeyRestriction: disable the custom attributes restriction which requires key to start with 'data-'
     */
    embedScript(embedOptions: {
        src: string;
        params?: Object;
        attributes?: Object;
        callback?: EventListener;
        errorCallback?: EventListener;
        placement?: ScriptPlacement;
        disableKeyRestriction?: boolean;
    }): void;
    /**
     * Indicates if the script is already added to the DOM.
     */
    hasScript(src?: string): boolean;
    /**
     * Parses the given object with parameters to a string "param1=value1&param2=value2"
     * @param params object containing parameters
     */
    private parseParams;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScriptLoader, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ScriptLoader>;
}

/**
 * The url of the server request when running SSR
 * */
declare const SERVER_REQUEST_URL: InjectionToken<string>;
/**
 * The url of the server request host when running SSR
 * */
declare const SERVER_REQUEST_ORIGIN: InjectionToken<string>;

declare class TestingTimeUtils {
    static fakeToLocaleTimeString(mockTime: string, callback: Function): any;
    static fakeDateTimezoneOffset(offset: number, callback: Function): any;
}

declare class TimeUtils {
    /**
     * Returns the local timezone in a format that can be appended to a date-like string.
     * @param invert (default: false): returns the opposite operator relative to the local timezone
     *
     * @example
     * When locale is set to a CEST timezone, `getLocalTimezoneOffset()` returns '+02:00'
     * and `getLocalTimezoneOffset(true)` returns '-02:00'
     */
    static getLocalTimezoneOffset(invert?: boolean): string;
    static convertDateToDatetime(date: string, endOfDay?: boolean): string;
    static convertDatetimeToDate(datetime: string): string;
}

/**
 * Safely normalizes HttpErrorResponse to HttpErrorModel or returns the original error.
 *
 * Can be used as a safe and generic way for embodying http errors into
 * NgRx Action payload, as it will strip potentially unserializable parts from
 * HttpErrorResponse instances and warn in debug mode if passed error is not
 * instance of HttpErrorModel or HttpErrorResponse (which usually happens when
 * logic in NgRx Effect is not sealed correctly)
 */
declare function tryNormalizeHttpError(error: HttpErrorResponse | HttpErrorModel | any, logger: LoggerService): HttpErrorModel | Error;

declare function isNotUndefined<T>(value: T | undefined): value is T;
declare function isNotNullable<T>(value: T): value is NonNullable<T>;

type RequiredPick<T extends object, K extends keyof T = keyof T> = Omit<T, K> & Required<Pick<T, K>>;

/**
 * Configures a specific i18next backend plugin, to allow for loading translations from external resources.
 */
declare abstract class I18nextBackendInitializer implements Applicable {
    /**
     * Configures an i18next backend plugin, to allow for loading translations from external resources.
     *
     * @returns Additional configuration to be used when initializing the i18next instance.
     */
    abstract initialize(): InitOptions;
    /**
     * Returns `true` if the backend is applicable.
     */
    hasMatch?(...params: any[]): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<I18nextBackendInitializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<I18nextBackendInitializer>;
}

declare const i18nextBackendProviders: Provider[];

/**
 * Configures an i18next backend plugin, to allow for loading translations from external resources.
 *
 * By default it configures and uses the `I18nextHttpBackendService`.
 *
 * It's an extension point to allow for providing potentially different i18next backend plugins.
 * See the list of available plugins: https://www.i18next.com/overview/plugins-and-utils#backends
 */
declare class I18nextBackendService {
    protected backendInitializers: I18nextBackendInitializer[] | null;
    constructor(backendInitializers: I18nextBackendInitializer[] | null);
    /**
     * Configures an i18next backend plugin, to allow for loading translations from external resources.
     *
     * @returns Additional configuration to be used when initializing the i18next instance.
     */
    initialize(): InitOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<I18nextBackendService, [{ optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<I18nextBackendService>;
}

type I18nextHttpBackendClient = HttpBackendOptions['request'];
/**
 * Function to be used by the `i18next-http-backend` plugin for loading translations via http.
 */
declare const I18NEXT_HTTP_BACKEND_CLIENT: InjectionToken<((options: i18next_http_backend.HttpBackendOptions, url: string, payload: {} | string, callback: i18next_http_backend.RequestCallback) => void) | undefined>;

/**
 * Configures an i18next HTTP backend plugin,
 * to allow for loading translations via HTTP.
 */
declare class I18nextHttpBackendInitializer implements I18nextBackendInitializer {
    protected i18next: i18n;
    protected i18nextHttpClient: I18nextHttpBackendClient;
    protected config: I18nConfig;
    protected windowRef: WindowRef;
    constructor(i18next: i18n, i18nextHttpClient: I18nextHttpBackendClient, config: I18nConfig, windowRef: WindowRef);
    /**
     * Tells whether this i18next backend is applicable, based on the configuration.
     */
    hasMatch(): boolean;
    /**
     * @override
     * Configures an i18next HTTP backend plugin,
     * to allow for loading translations via HTTP.
     */
    initialize(): InitOptions<HttpBackendOptions>;
    /**
     * Returns the configuration for the i18next-http-backend plugin.
     */
    protected getBackendConfig(): HttpBackendOptions;
    /**
     * Resolves the relative path to the absolute one in SSR, using the server request's origin.
     * It's needed, because Angular Universal doesn't support relative URLs in HttpClient. See Angular issues:
     * - https://github.com/angular/angular/issues/19224
     * - https://github.com/angular/universal/issues/858
     */
    protected getLoadPath(path: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<I18nextHttpBackendInitializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<I18nextHttpBackendInitializer>;
}

declare class I18nextResourcesToBackendInitializer implements I18nextBackendInitializer {
    protected config: I18nConfig;
    protected i18next: i18n;
    constructor(config: I18nConfig, i18next: i18n);
    hasMatch(): boolean;
    initialize(): InitOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<I18nextResourcesToBackendInitializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<I18nextResourcesToBackendInitializer>;
}

/**
 * Initializes the i18next instance.
 */
declare class I18nextInitializer implements OnDestroy {
    protected i18next: i18n;
    protected config: I18nConfig;
    protected languageService: LanguageService;
    protected i18nextBackendService: I18nextBackendService;
    loggerPlugin: node_modules_i18next.LoggerModule;
    constructor(i18next: i18n, config: I18nConfig, languageService: LanguageService, i18nextBackendService: I18nextBackendService);
    /**
     * Initializes the i18next instance.
     *
     * @returns Promise that resolves when the i18next instance is initialized.
     */
    initialize(): Promise<any>;
    /**
     * Returns the configuration for initializing an i18next instance.
     */
    protected getI18nextConfig(): InitOptions;
    /**
     * Populates the i18next instance with the given static translations.
     *
     * @param i18next i18next instance
     * @param resources translation resources
     */
    protected addTranslationResources(): void;
    protected subscription: Subscription;
    /**
     * Ensures that when the site context language changes,
     * the i18next instance is updated with the new language.
     */
    protected synchronizeLanguage(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<I18nextInitializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<I18nextInitializer>;
}

/**
 * The instance of i18next.
 *
 * Each SSR request gets its own instance of i18next.
 *
 * The reference to the static global instance of `i18next` (`import i18next from 'i18next`)
 * should not be used anywhere else, because otherwise it would be shared in between all SSR requests
 * and can cause concurrency issues.
 */
declare const I18NEXT_INSTANCE: InjectionToken<i18n>;

declare class TranslationChunkService {
    protected config: I18nConfig;
    protected duplicates: {
        [key: string]: string[];
    };
    protected chunks: {
        [key: string]: string;
    };
    protected logger: LoggerService;
    constructor(config: I18nConfig);
    protected readonly KEY_SEPARATOR = ".";
    getChunkNameForKey(key: string): string;
    private warnDuplicates;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslationChunkService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslationChunkService>;
}

declare class I18nextTranslationService implements TranslationService {
    protected config: I18nConfig;
    protected translationChunk: TranslationChunkService;
    protected i18next: i18n;
    private readonly NON_BREAKING_SPACE;
    protected readonly NAMESPACE_SEPARATOR = ":";
    protected logger: LoggerService;
    constructor(config: I18nConfig, translationChunk: TranslationChunkService, i18next: i18n);
    translate(key: string | string[], options?: any, whitespaceUntilLoaded?: boolean): Observable<string>;
    loadChunks(chunkNames: string | string[]): Promise<any>;
    /**
     * Returns a fallback value in case when the all given keys are missing
     */
    protected getFallbackValue(keyOrKeys: string | string[]): string;
    private reportMissingKey;
    private getNamespacedKey;
    static ɵfac: i0.ɵɵFactoryDeclaration<I18nextTranslationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<I18nextTranslationService>;
}

declare class MockTranslatePipe implements PipeTransform {
    transform(input: Translatable | string | string[], options?: object): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<MockTranslatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<MockTranslatePipe, "cxTranslate", true>;
}

declare class MockDatePipe extends DatePipe implements PipeTransform {
    transform(value: any, ...args: any[]): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<MockDatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<MockDatePipe, "cxDate", true>;
}

declare class I18nTestingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<I18nTestingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<I18nTestingModule, never, [typeof MockTranslatePipe, typeof MockDatePipe], [typeof MockTranslatePipe, typeof MockDatePipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<I18nTestingModule>;
}

declare class MockTranslationService implements TranslationService {
    translate(key: string | string[], options?: any, _whitespaceUntilLoaded?: boolean): Observable<string>;
    loadChunks(_chunks: string | string[]): Promise<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MockTranslationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MockTranslationService>;
}

/**
 * Will be thrown in case lazy loaded modules are loaded and instantiated.
 *
 * This event is thrown for cms driven lazy loaded feature modules amd it's
 * dependencies
 */
declare class ModuleInitializedEvent extends CxEvent {
    /**
     * Event's type
     */
    static readonly type = "ModuleInitializedEvent";
    /**
     * Name/identifier of the feature associated with this module.
     *
     * You can differentiate between feature and dependency modules, as the latter
     * won't have thus property set.
     */
    feature?: string;
    /**
     * Reference fpr lazy loaded module instance
     */
    moduleRef: NgModuleRef<any>;
}

/**
 * The MODULE_INITIALIZER is used as a multi provider that returns
 * a function that should be executed when the module is lazy loaded.
 * It is, in a way, an APP_INITIALIZER for lazy loaded modules.
 *
 * If the module is eagerly loaded, the MODULE_INITIALIZER functions
 * run when the app is initialized.  Therfore, if the module in which it is
 * defined is used in a eager loading configuration, MODULE_INITIALIZER
 * will fall back to work like APP_INITIALIZER.
 */
declare const MODULE_INITIALIZER: InjectionToken<(() => any)[]>;

declare class FeatureModulesService {
    protected cmsConfig: CmsConfig;
    protected lazyModules: LazyModulesService;
    private features;
    constructor(cmsConfig: CmsConfig, lazyModules: LazyModulesService);
    /**
     * Check if feature is configured properly by providing module the shell app
     *
     * @param featureName
     */
    isConfigured(featureName: string): boolean;
    /**
     * Resolve feature based on feature name, if feature was not yet resolved
     *
     * It will first resolve all module dependencies if defined
     */
    resolveFeature(featureName: string): Observable<NgModuleRef<any>>;
    /**
     * Resolve
     * @param featureName
     * @protected
     */
    protected getFeatureConfig(featureName: string): FeatureModuleConfig | undefined;
    /**
     * Will return target feature name, resolving optional feature to feature
     * string mapping
     *
     * @param featureName
     * @protected
     */
    protected resolveFeatureAlias(featureName: string): string;
    /**
     * Resolve dependency modules for the feature
     *
     * @param dependencies
     * @protected
     */
    protected resolveDependencies(dependencies?: any[]): Observable<NgModuleRef<any>[] | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FeatureModulesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FeatureModulesService>;
}

interface FacadeDescriptor<T extends object> {
    /**
     * Facade class
     */
    facade: AbstractType<StrictlyAllowedFacade<T>>;
    /**
     * Feature name that should be used to resolve facade
     */
    feature: string;
    /**
     * Methods of the facade that will be proxied from lazy loaded services.
     *
     * All methods should either return an Observable or void. Any return type that
     * is not an Observable will be ignored.
     */
    methods?: MethodKeys<T>[];
    /**
     * Properties of the facade that will be proxied from lazy loaded services.
     *
     * Only Observable properties are supported.
     */
    properties?: PropertyKeys<T>[];
    /**
     * Denotes that feature should have to be initialized with an async delay.
     * Required to make lazy NgRx store feature ready.
     */
    async?: boolean;
}
type MethodKeys<T extends object> = {
    [K in keyof T]: T[K] extends (...args: any[]) => AllowedReturn ? K : never;
}[keyof T];
type PropertyKeys<T extends object> = {
    [K in keyof T]: T[K] extends Observable<any> ? K : never;
}[keyof T];
type AllowedReturn = void | Observable<any>;
type AllowedKeys<T> = {
    [K in keyof T]: T[K] extends (...args: any[]) => AllowedReturn ? K : T[K] extends Observable<any> ? K : never;
}[keyof T];
type StrictlyAllowedFacade<T> = Pick<T, AllowedKeys<T>> extends T ? T : never;

/**
 * Service that can create proxy facade, which is a service that will expose
 * methods and properties from a facade implemented in the lazy loaded module.
 *
 * Returned proxy facade will lazy load the feature and facade implementation
 * at first method call or when first property observable will be subscribed.
 */
declare class FacadeFactoryService {
    protected featureModules: FeatureModulesService;
    protected injector: Injector;
    constructor(featureModules: FeatureModulesService, injector: Injector);
    protected getResolver<T>(feature: string, facadeClass: AbstractType<T>, async?: boolean): Observable<T>;
    /**
     * Calls a method on a facade
     *
     * Method should either return an observable or void. Any other return type
     * than observable is ignored.
     *
     * @param resolver$
     * @param method
     * @param args
     * @protected
     */
    protected call(resolver$: Observable<any>, method: string, args: unknown[]): Observable<unknown>;
    /**
     * Get the property value from the facade
     *
     * Property has to be an aobservable
     *
     * @param resolver$
     * @param property
     * @protected
     */
    protected get(resolver$: Observable<any>, property: string): Observable<unknown>;
    create<T extends object>({ facade, feature, methods, properties, async, }: FacadeDescriptor<T>): T;
    /**
     * isProxyFacadeInstance tests if the provided facade is labeled as a proxy instance.
     * Facade proxy instances contain an object key to label them as such.
     * @param facade The facade object to evaluate
     */
    isProxyFacadeInstance(facade: any): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FacadeFactoryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FacadeFactoryService>;
}

/**
 * Factory that will create proxy facade, which is a service that will expose
 * methods and properties from a facade implemented in the lazy loaded module.
 *
 * Returned proxy facade will lazy load the feature and facade implementation
 * at first method call or when first property observable will be subscribed.
 *
 * @param descriptor
 */
declare function facadeFactory<T extends object>(descriptor: FacadeDescriptor<T>): T;

declare const PROCESS_FEATURE = "process";
interface StateWithProcess<T> {
    [PROCESS_FEATURE]: EntityLoaderState<T>;
}

declare function getProcessStateFactory<T>(processId: string): MemoizedSelector<StateWithProcess<T>, LoaderState<T>>;
declare function getProcessLoadingFactory<T>(processId: string): MemoizedSelector<StateWithProcess<T>, boolean>;
declare function getProcessSuccessFactory<T>(processId: string): MemoizedSelector<StateWithProcess<T>, boolean>;
declare function getProcessErrorFactory<T>(processId: string): MemoizedSelector<StateWithProcess<T>, boolean>;

declare const process_selectors_d_getProcessErrorFactory: typeof getProcessErrorFactory;
declare const process_selectors_d_getProcessLoadingFactory: typeof getProcessLoadingFactory;
declare const process_selectors_d_getProcessStateFactory: typeof getProcessStateFactory;
declare const process_selectors_d_getProcessSuccessFactory: typeof getProcessSuccessFactory;
declare namespace process_selectors_d {
  export {
    process_selectors_d_getProcessErrorFactory as getProcessErrorFactory,
    process_selectors_d_getProcessLoadingFactory as getProcessLoadingFactory,
    process_selectors_d_getProcessStateFactory as getProcessStateFactory,
    process_selectors_d_getProcessSuccessFactory as getProcessSuccessFactory,
  };
}

declare class ProductConnector {
    protected adapter: ProductAdapter;
    constructor(adapter: ProductAdapter);
    get(productCode: string, scope?: string): Observable<Product>;
    getMany(products: ScopedProductData[]): ScopedProductData[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductConnector>;
}

declare const PRODUCT_NORMALIZER: InjectionToken<Converter<any, Product>>;

declare class ProductAvailabilityConnector {
    protected adapter: ProductAvailabilityAdapter;
    constructor(adapter: ProductAvailabilityAdapter);
    getRealTimeStock(productCode: string, unitSapCode: string): Observable<ProductAvailabilities>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductAvailabilityConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductAvailabilityConnector>;
}

declare const PRODUCT_REFERENCES_NORMALIZER: InjectionToken<Converter<any, ProductReference[]>>;

declare class ProductReferencesConnector {
    protected adapter: ProductReferencesAdapter;
    constructor(adapter: ProductReferencesAdapter);
    get(productCode: string, referenceType?: string, pageSize?: number): Observable<ProductReference[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductReferencesConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductReferencesConnector>;
}

declare class ProductReviewsConnector {
    protected adapter: ProductReviewsAdapter;
    constructor(adapter: ProductReviewsAdapter);
    get(productCode: string, maxCount?: number): Observable<Review[]>;
    add(productCode: string, review: any): Observable<Review>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductReviewsConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductReviewsConnector>;
}

declare const PRODUCT_REVIEW_NORMALIZER: InjectionToken<Converter<any, Review>>;
declare const PRODUCT_REVIEW_SERIALIZER: InjectionToken<Converter<Review, any>>;

declare class ProductSearchConnector {
    protected adapter: ProductSearchAdapter;
    constructor(adapter: ProductSearchAdapter);
    search(query: string, searchConfig?: SearchConfig, scope?: string): Observable<ProductSearchPage>;
    searchByCodes(codes: string[], scope?: string): Observable<{
        products: Product[];
    }>;
    searchByCategory(category: string, scope?: string): Observable<{
        products: Product[];
    }>;
    getSuggestions(term: string, pageSize?: number): Observable<Suggestion[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductSearchConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductSearchConnector>;
}

declare const PRODUCT_SEARCH_PAGE_NORMALIZER: InjectionToken<Converter<any, ProductSearchPage>>;
declare const PRODUCT_SUGGESTION_NORMALIZER: InjectionToken<Converter<any, Suggestion>>;

interface ScopedLoaderState<T> {
    [scope: string]: LoaderState<T>;
}
type EntityScopedLoaderState<T> = EntityState<ScopedLoaderState<T>>;

declare const PRODUCT_FEATURE = "product";
declare const PRODUCT_DETAIL_ENTITY = "[Product] Detail Entity";
declare const PRODUCT_SEARCH_RESULTS_BY_CODES_ENTITY = "[Product] Search Results By Codes Entity";
declare const PRODUCT_SEARCH_RESULTS_BY_CATEGORY_ENTITY = "[Product] Search Results By Category Entity";
interface StateWithProduct {
    [PRODUCT_FEATURE]: ProductsState;
}
interface ProductsState {
    details: EntityScopedLoaderState<Product>;
    search: ProductsSearchState;
    searchByCode: EntityScopedLoaderState<Product>;
    searchByCategory: EntityScopedLoaderState<Product[]>;
    reviews: ProductReviewsState;
    references: ProductReferencesState;
}
interface ProductsSearchState {
    results: ProductSearchPage;
    suggestions: Suggestion[];
    auxResults: ProductSearchPage;
}
interface ProductReviewsState {
    productCode: string;
    list: Review[];
}
interface ProductReferencesState {
    productCode: string;
    list: ProductReference[];
}

declare class ProductSearchService {
    protected store: Store<StateWithProduct>;
    constructor(store: Store<StateWithProduct>);
    search(query: string | undefined, searchConfig?: SearchConfig): void;
    getResults(): Observable<ProductSearchPage>;
    clearResults(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductSearchService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductSearchService>;
}

/**
 * Indicates that a user select or unselect a facet value
 */
declare class FacetChangedEvent extends CxEvent {
    /**
     * Event's type
     */
    static readonly type = "FacetChangedEvent";
    /**
     * Facet code
     */
    code?: string;
    /**
     * Facet name
     */
    name?: string;
    /**
     * Facet value code
     */
    valueCode?: string;
    /**
     * Facet value name
     */
    valueName?: string;
    /**
     * Indicate whether facet value is toggled on or off
     */
    selected?: boolean;
}

declare class ProductEventBuilder {
    protected eventService: EventService;
    protected productSearchService: ProductSearchService;
    constructor(eventService: EventService, productSearchService: ProductSearchService);
    protected register(): void;
    /**
     * To get the changed facet, we need to compare the product search results
     * got before and after toggling the facet value. These 2 product searches must
     * have the same search queries except one different solr filter term. That means
     * these 2 searches must have the same 'freeTextSearch'; and if they are category
     * searches, they must have the same root (in the same category or brand).
     */
    protected buildFacetChangedEvent(): Observable<FacetChangedEvent | undefined>;
    /**
     * The 2 product searches (before and after facet changed) must have the same
     * search queries; and if they are category searches, they also must have the
     * same root (in the same category or brand).
     */
    private compareSearchResults;
    /**
     * Get the toggled breadcrumb. The 2 breadcrumb lists got from the 2 search results
     * only can have one different solr filter term.
     */
    private getToggledBreadcrumb;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductEventBuilder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductEventBuilder>;
}

declare class ProductEventModule {
    constructor(_productEventBuilder: ProductEventBuilder);
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductEventModule>;
}

declare class ProductReferenceService {
    protected store: Store<StateWithProduct>;
    constructor(store: Store<StateWithProduct>);
    loadProductReferences(productCode: string, referenceType?: string, pageSize?: number): void;
    getProductReferences(productCode: string, referenceType: string): Observable<ProductReference[]>;
    cleanReferences(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductReferenceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductReferenceService>;
}

declare class ProductReviewService {
    protected store: Store<StateWithProduct>;
    constructor(store: Store<StateWithProduct>);
    getByProductCode(productCode: string): Observable<Review[]>;
    add(productCode: string, review: Review): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductReviewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductReviewService>;
}

declare class ProductSearchByCodeService {
    protected store: Store<any>;
    load({ code, scope }: {
        code: string;
        scope?: string;
    }): void;
    get({ code, scope, }: {
        code: string;
        scope?: string;
    }): Observable<Product | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductSearchByCodeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductSearchByCodeService>;
}

declare class ProductSearchByCategoryService {
    protected store: Store<any>;
    load({ categoryCode, scope, }: {
        categoryCode: string;
        scope?: string;
    }): void;
    get({ categoryCode, scope, }: {
        categoryCode: string;
        scope?: string;
    }): Observable<Product[] | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductSearchByCategoryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductSearchByCategoryService>;
}

declare class ProductLoadingService {
    protected store: Store<StateWithProduct>;
    protected loadingScopes: LoadingScopesService;
    protected actions$: Actions;
    protected platformId: any;
    protected eventService: EventService;
    protected products: {
        [code: string]: {
            [scope: string]: Observable<Product>;
        };
    };
    constructor(store: Store<StateWithProduct>, loadingScopes: LoadingScopesService, actions$: Actions, platformId: any, eventService: EventService);
    get(productCode: string, scopes: string[]): Observable<Product>;
    protected initProductScopes(productCode: string, scopes: string[]): void;
    protected getScopesIndex(scopes: string[]): string;
    /**
     * Creates observable for providing specified product data for the scope
     *
     * @param productCode
     * @param scope
     */
    protected getProductForScope(productCode: string, scope: string): Observable<Product>;
    /**
     * Returns reload triggers for product per scope
     *
     * @param productCode
     * @param scope
     */
    protected getProductReloadTriggers(productCode: string, scope: string): Observable<unknown>[];
    /**
     * Generic method that returns stream triggering reload by maxAge
     *
     * Could be refactored to separate service in future to use in other
     * max age reload implementations
     *
     * @param loadStart$ Stream that emits on load start
     * @param loadFinish$ Stream that emits on load finish
     * @param maxAge max age
     */
    private getMaxAgeTrigger;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductLoadingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductLoadingService>;
}

declare class ProductService {
    protected store: Store<StateWithProduct>;
    protected productLoading: ProductLoadingService;
    constructor(store: Store<StateWithProduct>, productLoading: ProductLoadingService);
    /**
     * Returns the product observable. The product will be loaded
     * whenever there's no value observed.
     *
     * The underlying product loader ensures that the product is
     * only loaded once, even in case of parallel observers.
     *
     * You should provide product data scope you are interested in to not load all
     * the data if not needed. You can provide more than one scope.
     *
     * @param productCode Product code to load
     * @param scopes Scope or scopes of the product data
     */
    get(productCode: string, scopes?: (ProductScope | string)[] | ProductScope | string): Observable<Product | undefined>;
    /**
     * Returns boolean observable for product's loading state
     */
    isLoading(productCode: string, scope?: ProductScope | string): Observable<boolean>;
    /**
     * Returns boolean observable for product's load success state
     */
    isSuccess(productCode: string, scope?: ProductScope | string): Observable<boolean>;
    /**
     * Returns boolean observable for product's load error state
     */
    hasError(productCode: string, scope?: ProductScope | string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductService>;
}

declare class SearchboxService extends ProductSearchService {
    private actionsSubject;
    /**
     * dispatch the search for the search box
     */
    search(query: string, searchConfig?: SearchConfig): void;
    /**
     * Performs search and returns an Observable that emits when the search is completed
     */
    searchWithCompletion(query: string, searchConfig?: SearchConfig): Observable<boolean>;
    getResults(): Observable<ProductSearchPage>;
    /**
     * clears the products and suggestions
     */
    clearResults(): void;
    getSuggestionResults(): Observable<Suggestion[]>;
    searchSuggestions(query: string, searchConfig?: SearchConfig): void;
    /**
     * Performs suggestions search and returns an Observable that emits when the operation is completed
     */
    searchSuggestionsWithCompletion(query: string, searchConfig?: SearchConfig): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchboxService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SearchboxService>;
}

/**
 * The `ProductAvailabilityService` is responsible for fetching the latest real-time stock
 * information for products. Unlike the stock information provided by the `ProductService`,
 * which might be cached, this service ensures that you receive fresh data directly
 * from the backend.
 */
declare class ProductAvailabilityService {
    protected connector: ProductAvailabilityConnector;
    protected command: CommandService;
    /**
     * Command to get real-time stock data for a product.
     */
    protected getRealTimeStockCommand: Command<{
        productCode: string;
        unitSapCode: string;
    }, ProductAvailabilities>;
    /**
     * Executes the command to fetch real-time stock data.
     *
     * @param productCode The product code for which to fetch stock data.
     * @param unitSapCode The SAP code associated with the product.
     * @returns An observable of `ProductAvailabilities`.
     */
    getRealTimeStock(productCode: string, unitSapCode: string): Observable<ProductAvailabilities>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductAvailabilityService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductAvailabilityService>;
}

declare class ProductStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductStoreModule, never, [typeof i1.CommonModule, typeof i2.StoreFeatureModule, typeof i4.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductStoreModule>;
}

declare class ProductModule {
    static forRoot(): ModuleWithProviders<ProductModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductModule, never, [typeof ProductStoreModule, typeof ProductEventModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductModule>;
}

/**
 * Resolves the page data for the Product Listing Page.
 *
 * The page title, and breadcrumbs are resolved in this implementation only.
 */
declare class CategoryPageMetaResolver extends PageMetaResolver implements PageTitleResolver, PageBreadcrumbResolver, PageRobotsResolver {
    protected productSearchService: ProductSearchService;
    protected cms: CmsService;
    protected translation: TranslationService;
    protected basePageMetaResolver: BasePageMetaResolver;
    protected searchPage$: Observable<ProductSearchPage | Page>;
    constructor(productSearchService: ProductSearchService, cms: CmsService, translation: TranslationService, basePageMetaResolver: BasePageMetaResolver);
    resolveTitle(): Observable<string>;
    resolveBreadcrumbs(): Observable<BreadcrumbMeta[]>;
    protected resolveBreadcrumbData(page: ProductSearchPage, label: string): BreadcrumbMeta[];
    protected hasProductListComponent(page: Page): boolean;
    resolveRobots(): Observable<PageRobotsMeta[]>;
    /**
     * Resolves the canonical url for the category listing page.
     *
     * The default options will be used to resolve the url, which means that
     * all query parameters are removed and https and www are added explicitly.
     */
    resolveCanonicalUrl(): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CategoryPageMetaResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CategoryPageMetaResolver>;
}

/**
 * Resolves the page data for the Product Detail Page
 * based on the `PageType.PRODUCT_PAGE`.
 *
 * The page title, heading, description, breadcrumbs and
 * first GALLERY image are resolved if available in the data.
 */
declare class ProductPageMetaResolver extends PageMetaResolver implements PageHeadingResolver, PageTitleResolver, PageDescriptionResolver, PageBreadcrumbResolver, PageImageResolver, PageRobotsResolver {
    protected routingService: RoutingService;
    protected productService: ProductService;
    protected translation: TranslationService;
    protected basePageMetaResolver: BasePageMetaResolver;
    protected pageLinkService: PageLinkService;
    constructor(routingService: RoutingService, productService: ProductService, translation: TranslationService, basePageMetaResolver: BasePageMetaResolver, pageLinkService: PageLinkService);
    protected product$: Observable<Product>;
    /**
     * Resolves the page heading for the Product Detail Page.
     * The page heading is used in the UI (`<h1>`), where as the page
     * title is used by the browser and crawlers.
     */
    resolveHeading(): Observable<string>;
    /**
     * Resolves the page title for the Product Detail Page. The page title
     * is resolved with the product name, the first category and the manufacturer.
     * The page title used by the browser (history, tabs) and crawlers.
     */
    resolveTitle(): Observable<string>;
    /**
     * Resolves the page description for the Product Detail Page. The description
     * is based on the `product.summary`.
     */
    resolveDescription(): Observable<string>;
    /**
     * Resolves breadcrumbs for the Product Detail Page. The breadcrumbs are driven by
     * a static home page crumb and a crumb for each category.
     */
    resolveBreadcrumbs(): Observable<BreadcrumbMeta[]>;
    /**
     * Resolves the main page image for the Product Detail Page. The product image
     * is based on the PRIMARY product image. The zoom format is used by default.
     */
    resolveImage(): Observable<string>;
    protected resolveFirstCategory(product: Product): string;
    protected resolveManufacturer(product: Product): string;
    resolveRobots(): Observable<PageRobotsMeta[]>;
    /**
     * Resolves the canonical url for the product page using the default canonical url
     * configuration.
     *
     * In case of a variant product, the baseProduct code is used to resolve the url. It's important
     * to know that this has a few limitations:
     * - We're not always able to get the super baseProduct, in case of multi-level variants.
     *   OCC only exposes the direct baseProduct, which might still not resolve in the correct
     *   canonical URL. This is business driven and subject to change in a customization.
     * - The url resolved for the variant doesn't contain any content other then the product code.
     *   This means that we do not provide any product data to resolve pretty URLs (for example
     *   the product title).
     */
    resolveCanonicalUrl(): Observable<string>;
    /**
     * Resolves the base product whenever the given product is a variant product.
     *
     * Since product variants can be multi-layered, we recursively try to find the base product
     * this might be too opinionated for your business though.
     */
    protected findBaseProduct(product: Product): Observable<Product>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductPageMetaResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductPageMetaResolver>;
}

/**
 * Resolves the page data for the Search Result Page based on the
 * `PageType.CATEGORY_PAGE` and the `SearchResultsListPageTemplate` template.
 *
 * Only the page title is resolved in the standard implementation.
 */
declare class SearchPageMetaResolver extends PageMetaResolver implements PageMetaResolver, PageTitleResolver, PageRobotsResolver {
    protected routingService: RoutingService;
    protected productSearchService: ProductSearchService;
    protected translation: TranslationService;
    protected basePageMetaResolver: BasePageMetaResolver;
    protected total$: Observable<number | undefined>;
    protected query$: Observable<string>;
    constructor(routingService: RoutingService, productSearchService: ProductSearchService, translation: TranslationService, basePageMetaResolver: BasePageMetaResolver);
    resolveTitle(): Observable<string>;
    resolveRobots(): Observable<PageRobotsMeta[]>;
    /**
     * Resolves the canonical page for the search page.
     *
     * The default options will be used to resolve the url, which means that
     * the all query parameters are removed and https and www are added explicitly.
     */
    resolveCanonicalUrl(): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchPageMetaResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SearchPageMetaResolver>;
}

declare class ProductCatalogService {
    /**
     * Returns whether product is present in commerce product catalog.
     *
     * @param product product to check
     * @return true if product is present in catalog, false otherwise
     */
    isProductInCatalog(product?: Product): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductCatalogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductCatalogService>;
}

declare const LOAD_PRODUCT_REFERENCES = "[Product] Load Product References Data";
declare const LOAD_PRODUCT_REFERENCES_FAIL = "[Product] Load Product References Data Fail";
declare const LOAD_PRODUCT_REFERENCES_SUCCESS = "[Product] Load Product References Data Success";
declare const CLEAN_PRODUCT_REFERENCES = "[Product] Clean Product References";
declare class LoadProductReferences implements Action {
    payload: {
        productCode: string;
        referenceType?: string;
        pageSize?: number;
    };
    readonly type = "[Product] Load Product References Data";
    constructor(payload: {
        productCode: string;
        referenceType?: string;
        pageSize?: number;
    });
}
declare class LoadProductReferencesFail implements ErrorAction {
    payload: any;
    readonly type = "[Product] Load Product References Data Fail";
    error: any;
    constructor(payload: any);
}
declare class LoadProductReferencesSuccess implements Action {
    payload: {
        productCode: string;
        list: ProductReference[];
    };
    readonly type = "[Product] Load Product References Data Success";
    constructor(payload: {
        productCode: string;
        list: ProductReference[];
    });
}
declare class CleanProductReferences implements Action {
    readonly type = "[Product] Clean Product References";
}
type ProductReferencesAction = LoadProductReferences | LoadProductReferencesFail | LoadProductReferencesSuccess | CleanProductReferences;

declare const LOAD_PRODUCT_REVIEWS = "[Product] Load Product Reviews Data";
declare const LOAD_PRODUCT_REVIEWS_FAIL = "[Product] Load Product Reviews Data Fail";
declare const LOAD_PRODUCT_REVIEWS_SUCCESS = "[Product] Load Product Reviews Data Success";
declare const POST_PRODUCT_REVIEW = "[Product] Post Product Review";
declare const POST_PRODUCT_REVIEW_FAIL = "[Product] Post Product Review Fail";
declare const POST_PRODUCT_REVIEW_SUCCESS = "[Product] Post Product Review Success";
declare class LoadProductReviews implements Action {
    payload: string;
    readonly type = "[Product] Load Product Reviews Data";
    constructor(payload: string);
}
declare class LoadProductReviewsFail implements ErrorAction {
    payload: any;
    readonly type = "[Product] Load Product Reviews Data Fail";
    error: any;
    constructor(payload: any);
}
declare class LoadProductReviewsSuccess implements Action {
    payload: {
        productCode: string;
        list: Review[];
    };
    readonly type = "[Product] Load Product Reviews Data Success";
    constructor(payload: {
        productCode: string;
        list: Review[];
    });
}
declare class PostProductReview implements Action {
    payload: {
        productCode: string;
        review: Review;
    };
    readonly type = "[Product] Post Product Review";
    constructor(payload: {
        productCode: string;
        review: Review;
    });
}
declare class PostProductReviewFail implements ErrorAction {
    payload: any;
    readonly type = "[Product] Post Product Review Fail";
    error: any;
    constructor(payload: any);
}
declare class PostProductReviewSuccess implements Action {
    payload: Review;
    readonly type = "[Product] Post Product Review Success";
    constructor(payload: Review);
}
type ProductReviewsAction = LoadProductReviews | LoadProductReviewsFail | LoadProductReviewsSuccess | PostProductReview | PostProductReviewFail | PostProductReviewSuccess;

declare const SEARCH_PRODUCTS = "[Product] Search Products";
declare const SEARCH_PRODUCTS_FAIL = "[Product] Search Products Fail";
declare const SEARCH_PRODUCTS_SUCCESS = "[Product] Search Products Success";
declare const GET_PRODUCT_SUGGESTIONS = "[Product] Get Product Suggestions";
declare const GET_PRODUCT_SUGGESTIONS_SUCCESS = "[Product] Get Product Suggestions Success";
declare const GET_PRODUCT_SUGGESTIONS_FAIL = "[Product] Get Product Suggestions Fail";
declare const CLEAR_PRODUCT_SEARCH_RESULT = "[Product] Clear Product Search Result";
declare class SearchProducts implements Action {
    payload: {
        queryText: string;
        searchConfig?: SearchConfig;
    };
    auxiliary?: boolean | undefined;
    readonly type = "[Product] Search Products";
    constructor(payload: {
        queryText: string;
        searchConfig?: SearchConfig;
    }, auxiliary?: boolean | undefined);
}
declare class SearchProductsFail implements ErrorAction {
    payload: any;
    auxiliary?: boolean | undefined;
    readonly type = "[Product] Search Products Fail";
    error: any;
    constructor(payload: any, auxiliary?: boolean | undefined);
}
declare class SearchProductsSuccess implements Action {
    payload: ProductSearchPage;
    auxiliary?: boolean | undefined;
    readonly type = "[Product] Search Products Success";
    constructor(payload: ProductSearchPage, auxiliary?: boolean | undefined);
}
declare class GetProductSuggestions implements Action {
    payload: {
        term: string;
        searchConfig?: SearchConfig;
    };
    readonly type = "[Product] Get Product Suggestions";
    constructor(payload: {
        term: string;
        searchConfig?: SearchConfig;
    });
}
declare class GetProductSuggestionsSuccess implements Action {
    payload: Suggestion[];
    readonly type = "[Product] Get Product Suggestions Success";
    constructor(payload: Suggestion[]);
}
declare class GetProductSuggestionsFail implements ErrorAction {
    payload: any;
    error: any;
    readonly type = "[Product] Get Product Suggestions Fail";
    constructor(payload: any);
}
declare class ClearProductSearchResult implements Action {
    payload: ClearSearch;
    readonly type = "[Product] Clear Product Search Result";
    constructor(payload?: ClearSearch);
}
type ProductSearchAction = SearchProducts | SearchProductsFail | SearchProductsSuccess | GetProductSuggestions | GetProductSuggestionsSuccess | GetProductSuggestionsFail | ClearProductSearchResult;

declare namespace EntityScopedLoaderActions {
    interface EntityScopedLoaderMeta extends EntityLoaderMeta {
        scope?: string;
    }
    interface EntityScopedLoaderAction extends Action {
        readonly payload?: any;
        readonly meta?: EntityScopedLoaderMeta;
    }
    function entityScopedLoadMeta(entityType: string, id: string | string[], scope?: string): EntityScopedLoaderMeta;
    function entityScopedFailMeta(entityType: string, id: string | string[], scope: string, error: any): EntityScopedLoaderMeta;
    function entityScopedSuccessMeta(entityType: string, id: string | string[], scope?: string): EntityScopedLoaderMeta;
    function entityScopedResetMeta(entityType: string, id?: string | string[], scope?: string): EntityScopedLoaderMeta;
    class EntityScopedLoadAction implements EntityScopedLoaderAction {
        type: string;
        readonly meta: EntityScopedLoaderMeta;
        constructor(entityType: string, id: string | string[], scope?: string);
    }
    class EntityScopedFailAction implements EntityScopedLoaderAction, ErrorAction {
        type: string;
        error: any;
        readonly meta: EntityScopedLoaderMeta;
        constructor(entityType: string, id: string | string[], scope: string, error: any);
    }
    class EntityScopedSuccessAction implements EntityScopedLoaderAction {
        payload?: any | undefined;
        type: string;
        readonly meta: EntityScopedLoaderMeta;
        constructor(entityType: string, id: string | string[], scope?: string, payload?: any | undefined);
    }
    class EntityScopedResetAction implements EntityScopedLoaderAction {
        type: string;
        readonly meta: EntityScopedLoaderMeta;
        constructor(entityType: string, id?: string | string[], scope?: string);
    }
}

declare const PRODUCT_SEARCH_LOAD_BY_CODE = "[Product] Product Search Load By Code";
declare const PRODUCT_SEARCH_LOAD_BY_CODE_SUCCESS = "[Product] Product Search Load By Code Success";
declare const PRODUCT_SEARCH_LOAD_BY_CODE_FAIL = "[Product] Product Search Load By Code Fail";
declare const CLEAR_PRODUCT_SEARCH_BY_CODE_STATE = "[Product] Clear Product Search By Code State";
declare class ProductSearchLoadByCode extends EntityScopedLoaderActions.EntityScopedLoadAction {
    payload: {
        code: string;
        scope: string;
    };
    readonly type = "[Product] Product Search Load By Code";
    constructor(payload: {
        code: string;
        scope: string;
    });
}
declare class ProductSearchLoadByCodeSuccess extends EntityScopedLoaderActions.EntityScopedSuccessAction {
    readonly type = "[Product] Product Search Load By Code Success";
    constructor(payload: {
        product: Product;
        code: string;
        scope: string;
    });
}
declare class ProductSearchLoadByCodeFail extends EntityScopedLoaderActions.EntityScopedFailAction implements ErrorAction {
    readonly type = "[Product] Product Search Load By Code Fail";
    constructor(payload: {
        code: string;
        scope: string;
        error: any;
    });
}
declare class ClearProductSearchByCodeState extends EntityRemoveAllAction {
    readonly type = "[Product] Clear Product Search By Code State";
    constructor();
}
type ProductSearchByCodeAction = ProductSearchLoadByCode | ProductSearchLoadByCodeSuccess | ProductSearchLoadByCodeFail | ClearProductSearchByCodeState;

declare const PRODUCT_SEARCH_LOAD_BY_CATEGORY = "[Product] Product Search Load By Category";
declare const PRODUCT_SEARCH_LOAD_BY_CATEGORY_SUCCESS = "[Product] Product Search Load By Category Success";
declare const PRODUCT_SEARCH_LOAD_BY_CATEGORY_FAIL = "[Product] Product Search Load By Category Fail";
declare class ProductSearchLoadByCategory extends EntityScopedLoaderActions.EntityScopedLoadAction {
    payload: {
        categoryCode: string;
        scope: string;
    };
    readonly type = "[Product] Product Search Load By Category";
    constructor(payload: {
        categoryCode: string;
        scope: string;
    });
}
declare class ProductSearchLoadByCategorySuccess extends EntityScopedLoaderActions.EntityScopedSuccessAction {
    readonly type = "[Product] Product Search Load By Category Success";
    constructor(payload: {
        products: Product[];
        categoryCode: string;
        scope: string;
    });
}
declare class ProductSearchLoadByCategoryFail extends EntityScopedLoaderActions.EntityScopedFailAction implements ErrorAction {
    readonly type = "[Product] Product Search Load By Category Fail";
    constructor(payload: {
        categoryCode: string;
        scope: string;
        error: any;
    });
}
type ProductSearchByCategoryAction = ProductSearchLoadByCategory | ProductSearchLoadByCategorySuccess | ProductSearchLoadByCategoryFail;

declare const LOAD_PRODUCT = "[Product] Load Product Data";
declare const LOAD_PRODUCT_FAIL = "[Product] Load Product Data Fail";
declare const LOAD_PRODUCT_SUCCESS = "[Product] Load Product Data Success";
declare const CLEAR_PRODUCT_PRICE = "[Product] Clear Product PRICE";
interface ProductMeta extends EntityLoaderMeta {
    scope?: string;
}
interface EntityScopedLoaderAction extends Action {
    readonly payload?: any;
    readonly meta?: ProductMeta;
}
declare class LoadProduct extends EntityScopedLoaderActions.EntityScopedLoadAction {
    payload: string;
    readonly type = "[Product] Load Product Data";
    constructor(payload: string, scope?: string);
}
declare class LoadProductFail extends EntityScopedLoaderActions.EntityScopedFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Product] Load Product Data Fail";
    constructor(productCode: string, payload: any, scope?: string);
}
declare class LoadProductSuccess extends EntityScopedLoaderActions.EntityScopedSuccessAction {
    payload: Product;
    readonly type = "[Product] Load Product Data Success";
    constructor(payload: Product, scope?: string);
}
declare class ClearProductPrice extends EntityScopedLoaderActions.EntityScopedResetAction {
    readonly type = "[Product] Clear Product PRICE";
    constructor();
}
type ProductAction = LoadProduct | LoadProductFail | LoadProductSuccess | ClearProductPrice;

declare const productGroup_actions_d_CLEAN_PRODUCT_REFERENCES: typeof CLEAN_PRODUCT_REFERENCES;
declare const productGroup_actions_d_CLEAR_PRODUCT_PRICE: typeof CLEAR_PRODUCT_PRICE;
declare const productGroup_actions_d_CLEAR_PRODUCT_SEARCH_BY_CODE_STATE: typeof CLEAR_PRODUCT_SEARCH_BY_CODE_STATE;
declare const productGroup_actions_d_CLEAR_PRODUCT_SEARCH_RESULT: typeof CLEAR_PRODUCT_SEARCH_RESULT;
type productGroup_actions_d_CleanProductReferences = CleanProductReferences;
declare const productGroup_actions_d_CleanProductReferences: typeof CleanProductReferences;
type productGroup_actions_d_ClearProductPrice = ClearProductPrice;
declare const productGroup_actions_d_ClearProductPrice: typeof ClearProductPrice;
type productGroup_actions_d_ClearProductSearchByCodeState = ClearProductSearchByCodeState;
declare const productGroup_actions_d_ClearProductSearchByCodeState: typeof ClearProductSearchByCodeState;
type productGroup_actions_d_ClearProductSearchResult = ClearProductSearchResult;
declare const productGroup_actions_d_ClearProductSearchResult: typeof ClearProductSearchResult;
type productGroup_actions_d_EntityScopedLoaderAction = EntityScopedLoaderAction;
declare const productGroup_actions_d_GET_PRODUCT_SUGGESTIONS: typeof GET_PRODUCT_SUGGESTIONS;
declare const productGroup_actions_d_GET_PRODUCT_SUGGESTIONS_FAIL: typeof GET_PRODUCT_SUGGESTIONS_FAIL;
declare const productGroup_actions_d_GET_PRODUCT_SUGGESTIONS_SUCCESS: typeof GET_PRODUCT_SUGGESTIONS_SUCCESS;
type productGroup_actions_d_GetProductSuggestions = GetProductSuggestions;
declare const productGroup_actions_d_GetProductSuggestions: typeof GetProductSuggestions;
type productGroup_actions_d_GetProductSuggestionsFail = GetProductSuggestionsFail;
declare const productGroup_actions_d_GetProductSuggestionsFail: typeof GetProductSuggestionsFail;
type productGroup_actions_d_GetProductSuggestionsSuccess = GetProductSuggestionsSuccess;
declare const productGroup_actions_d_GetProductSuggestionsSuccess: typeof GetProductSuggestionsSuccess;
declare const productGroup_actions_d_LOAD_PRODUCT: typeof LOAD_PRODUCT;
declare const productGroup_actions_d_LOAD_PRODUCT_FAIL: typeof LOAD_PRODUCT_FAIL;
declare const productGroup_actions_d_LOAD_PRODUCT_REFERENCES: typeof LOAD_PRODUCT_REFERENCES;
declare const productGroup_actions_d_LOAD_PRODUCT_REFERENCES_FAIL: typeof LOAD_PRODUCT_REFERENCES_FAIL;
declare const productGroup_actions_d_LOAD_PRODUCT_REFERENCES_SUCCESS: typeof LOAD_PRODUCT_REFERENCES_SUCCESS;
declare const productGroup_actions_d_LOAD_PRODUCT_REVIEWS: typeof LOAD_PRODUCT_REVIEWS;
declare const productGroup_actions_d_LOAD_PRODUCT_REVIEWS_FAIL: typeof LOAD_PRODUCT_REVIEWS_FAIL;
declare const productGroup_actions_d_LOAD_PRODUCT_REVIEWS_SUCCESS: typeof LOAD_PRODUCT_REVIEWS_SUCCESS;
declare const productGroup_actions_d_LOAD_PRODUCT_SUCCESS: typeof LOAD_PRODUCT_SUCCESS;
type productGroup_actions_d_LoadProduct = LoadProduct;
declare const productGroup_actions_d_LoadProduct: typeof LoadProduct;
type productGroup_actions_d_LoadProductFail = LoadProductFail;
declare const productGroup_actions_d_LoadProductFail: typeof LoadProductFail;
type productGroup_actions_d_LoadProductReferences = LoadProductReferences;
declare const productGroup_actions_d_LoadProductReferences: typeof LoadProductReferences;
type productGroup_actions_d_LoadProductReferencesFail = LoadProductReferencesFail;
declare const productGroup_actions_d_LoadProductReferencesFail: typeof LoadProductReferencesFail;
type productGroup_actions_d_LoadProductReferencesSuccess = LoadProductReferencesSuccess;
declare const productGroup_actions_d_LoadProductReferencesSuccess: typeof LoadProductReferencesSuccess;
type productGroup_actions_d_LoadProductReviews = LoadProductReviews;
declare const productGroup_actions_d_LoadProductReviews: typeof LoadProductReviews;
type productGroup_actions_d_LoadProductReviewsFail = LoadProductReviewsFail;
declare const productGroup_actions_d_LoadProductReviewsFail: typeof LoadProductReviewsFail;
type productGroup_actions_d_LoadProductReviewsSuccess = LoadProductReviewsSuccess;
declare const productGroup_actions_d_LoadProductReviewsSuccess: typeof LoadProductReviewsSuccess;
type productGroup_actions_d_LoadProductSuccess = LoadProductSuccess;
declare const productGroup_actions_d_LoadProductSuccess: typeof LoadProductSuccess;
declare const productGroup_actions_d_POST_PRODUCT_REVIEW: typeof POST_PRODUCT_REVIEW;
declare const productGroup_actions_d_POST_PRODUCT_REVIEW_FAIL: typeof POST_PRODUCT_REVIEW_FAIL;
declare const productGroup_actions_d_POST_PRODUCT_REVIEW_SUCCESS: typeof POST_PRODUCT_REVIEW_SUCCESS;
declare const productGroup_actions_d_PRODUCT_SEARCH_LOAD_BY_CATEGORY: typeof PRODUCT_SEARCH_LOAD_BY_CATEGORY;
declare const productGroup_actions_d_PRODUCT_SEARCH_LOAD_BY_CATEGORY_FAIL: typeof PRODUCT_SEARCH_LOAD_BY_CATEGORY_FAIL;
declare const productGroup_actions_d_PRODUCT_SEARCH_LOAD_BY_CATEGORY_SUCCESS: typeof PRODUCT_SEARCH_LOAD_BY_CATEGORY_SUCCESS;
declare const productGroup_actions_d_PRODUCT_SEARCH_LOAD_BY_CODE: typeof PRODUCT_SEARCH_LOAD_BY_CODE;
declare const productGroup_actions_d_PRODUCT_SEARCH_LOAD_BY_CODE_FAIL: typeof PRODUCT_SEARCH_LOAD_BY_CODE_FAIL;
declare const productGroup_actions_d_PRODUCT_SEARCH_LOAD_BY_CODE_SUCCESS: typeof PRODUCT_SEARCH_LOAD_BY_CODE_SUCCESS;
type productGroup_actions_d_PostProductReview = PostProductReview;
declare const productGroup_actions_d_PostProductReview: typeof PostProductReview;
type productGroup_actions_d_PostProductReviewFail = PostProductReviewFail;
declare const productGroup_actions_d_PostProductReviewFail: typeof PostProductReviewFail;
type productGroup_actions_d_PostProductReviewSuccess = PostProductReviewSuccess;
declare const productGroup_actions_d_PostProductReviewSuccess: typeof PostProductReviewSuccess;
type productGroup_actions_d_ProductAction = ProductAction;
type productGroup_actions_d_ProductMeta = ProductMeta;
type productGroup_actions_d_ProductReferencesAction = ProductReferencesAction;
type productGroup_actions_d_ProductReviewsAction = ProductReviewsAction;
type productGroup_actions_d_ProductSearchAction = ProductSearchAction;
type productGroup_actions_d_ProductSearchByCategoryAction = ProductSearchByCategoryAction;
type productGroup_actions_d_ProductSearchByCodeAction = ProductSearchByCodeAction;
type productGroup_actions_d_ProductSearchLoadByCategory = ProductSearchLoadByCategory;
declare const productGroup_actions_d_ProductSearchLoadByCategory: typeof ProductSearchLoadByCategory;
type productGroup_actions_d_ProductSearchLoadByCategoryFail = ProductSearchLoadByCategoryFail;
declare const productGroup_actions_d_ProductSearchLoadByCategoryFail: typeof ProductSearchLoadByCategoryFail;
type productGroup_actions_d_ProductSearchLoadByCategorySuccess = ProductSearchLoadByCategorySuccess;
declare const productGroup_actions_d_ProductSearchLoadByCategorySuccess: typeof ProductSearchLoadByCategorySuccess;
type productGroup_actions_d_ProductSearchLoadByCode = ProductSearchLoadByCode;
declare const productGroup_actions_d_ProductSearchLoadByCode: typeof ProductSearchLoadByCode;
type productGroup_actions_d_ProductSearchLoadByCodeFail = ProductSearchLoadByCodeFail;
declare const productGroup_actions_d_ProductSearchLoadByCodeFail: typeof ProductSearchLoadByCodeFail;
type productGroup_actions_d_ProductSearchLoadByCodeSuccess = ProductSearchLoadByCodeSuccess;
declare const productGroup_actions_d_ProductSearchLoadByCodeSuccess: typeof ProductSearchLoadByCodeSuccess;
declare const productGroup_actions_d_SEARCH_PRODUCTS: typeof SEARCH_PRODUCTS;
declare const productGroup_actions_d_SEARCH_PRODUCTS_FAIL: typeof SEARCH_PRODUCTS_FAIL;
declare const productGroup_actions_d_SEARCH_PRODUCTS_SUCCESS: typeof SEARCH_PRODUCTS_SUCCESS;
type productGroup_actions_d_SearchProducts = SearchProducts;
declare const productGroup_actions_d_SearchProducts: typeof SearchProducts;
type productGroup_actions_d_SearchProductsFail = SearchProductsFail;
declare const productGroup_actions_d_SearchProductsFail: typeof SearchProductsFail;
type productGroup_actions_d_SearchProductsSuccess = SearchProductsSuccess;
declare const productGroup_actions_d_SearchProductsSuccess: typeof SearchProductsSuccess;
declare namespace productGroup_actions_d {
  export { productGroup_actions_d_CLEAN_PRODUCT_REFERENCES as CLEAN_PRODUCT_REFERENCES, productGroup_actions_d_CLEAR_PRODUCT_PRICE as CLEAR_PRODUCT_PRICE, productGroup_actions_d_CLEAR_PRODUCT_SEARCH_BY_CODE_STATE as CLEAR_PRODUCT_SEARCH_BY_CODE_STATE, productGroup_actions_d_CLEAR_PRODUCT_SEARCH_RESULT as CLEAR_PRODUCT_SEARCH_RESULT, productGroup_actions_d_CleanProductReferences as CleanProductReferences, productGroup_actions_d_ClearProductPrice as ClearProductPrice, productGroup_actions_d_ClearProductSearchByCodeState as ClearProductSearchByCodeState, productGroup_actions_d_ClearProductSearchResult as ClearProductSearchResult, productGroup_actions_d_GET_PRODUCT_SUGGESTIONS as GET_PRODUCT_SUGGESTIONS, productGroup_actions_d_GET_PRODUCT_SUGGESTIONS_FAIL as GET_PRODUCT_SUGGESTIONS_FAIL, productGroup_actions_d_GET_PRODUCT_SUGGESTIONS_SUCCESS as GET_PRODUCT_SUGGESTIONS_SUCCESS, productGroup_actions_d_GetProductSuggestions as GetProductSuggestions, productGroup_actions_d_GetProductSuggestionsFail as GetProductSuggestionsFail, productGroup_actions_d_GetProductSuggestionsSuccess as GetProductSuggestionsSuccess, productGroup_actions_d_LOAD_PRODUCT as LOAD_PRODUCT, productGroup_actions_d_LOAD_PRODUCT_FAIL as LOAD_PRODUCT_FAIL, productGroup_actions_d_LOAD_PRODUCT_REFERENCES as LOAD_PRODUCT_REFERENCES, productGroup_actions_d_LOAD_PRODUCT_REFERENCES_FAIL as LOAD_PRODUCT_REFERENCES_FAIL, productGroup_actions_d_LOAD_PRODUCT_REFERENCES_SUCCESS as LOAD_PRODUCT_REFERENCES_SUCCESS, productGroup_actions_d_LOAD_PRODUCT_REVIEWS as LOAD_PRODUCT_REVIEWS, productGroup_actions_d_LOAD_PRODUCT_REVIEWS_FAIL as LOAD_PRODUCT_REVIEWS_FAIL, productGroup_actions_d_LOAD_PRODUCT_REVIEWS_SUCCESS as LOAD_PRODUCT_REVIEWS_SUCCESS, productGroup_actions_d_LOAD_PRODUCT_SUCCESS as LOAD_PRODUCT_SUCCESS, productGroup_actions_d_LoadProduct as LoadProduct, productGroup_actions_d_LoadProductFail as LoadProductFail, productGroup_actions_d_LoadProductReferences as LoadProductReferences, productGroup_actions_d_LoadProductReferencesFail as LoadProductReferencesFail, productGroup_actions_d_LoadProductReferencesSuccess as LoadProductReferencesSuccess, productGroup_actions_d_LoadProductReviews as LoadProductReviews, productGroup_actions_d_LoadProductReviewsFail as LoadProductReviewsFail, productGroup_actions_d_LoadProductReviewsSuccess as LoadProductReviewsSuccess, productGroup_actions_d_LoadProductSuccess as LoadProductSuccess, productGroup_actions_d_POST_PRODUCT_REVIEW as POST_PRODUCT_REVIEW, productGroup_actions_d_POST_PRODUCT_REVIEW_FAIL as POST_PRODUCT_REVIEW_FAIL, productGroup_actions_d_POST_PRODUCT_REVIEW_SUCCESS as POST_PRODUCT_REVIEW_SUCCESS, productGroup_actions_d_PRODUCT_SEARCH_LOAD_BY_CATEGORY as PRODUCT_SEARCH_LOAD_BY_CATEGORY, productGroup_actions_d_PRODUCT_SEARCH_LOAD_BY_CATEGORY_FAIL as PRODUCT_SEARCH_LOAD_BY_CATEGORY_FAIL, productGroup_actions_d_PRODUCT_SEARCH_LOAD_BY_CATEGORY_SUCCESS as PRODUCT_SEARCH_LOAD_BY_CATEGORY_SUCCESS, productGroup_actions_d_PRODUCT_SEARCH_LOAD_BY_CODE as PRODUCT_SEARCH_LOAD_BY_CODE, productGroup_actions_d_PRODUCT_SEARCH_LOAD_BY_CODE_FAIL as PRODUCT_SEARCH_LOAD_BY_CODE_FAIL, productGroup_actions_d_PRODUCT_SEARCH_LOAD_BY_CODE_SUCCESS as PRODUCT_SEARCH_LOAD_BY_CODE_SUCCESS, productGroup_actions_d_PostProductReview as PostProductReview, productGroup_actions_d_PostProductReviewFail as PostProductReviewFail, productGroup_actions_d_PostProductReviewSuccess as PostProductReviewSuccess, productGroup_actions_d_ProductSearchLoadByCategory as ProductSearchLoadByCategory, productGroup_actions_d_ProductSearchLoadByCategoryFail as ProductSearchLoadByCategoryFail, productGroup_actions_d_ProductSearchLoadByCategorySuccess as ProductSearchLoadByCategorySuccess, productGroup_actions_d_ProductSearchLoadByCode as ProductSearchLoadByCode, productGroup_actions_d_ProductSearchLoadByCodeFail as ProductSearchLoadByCodeFail, productGroup_actions_d_ProductSearchLoadByCodeSuccess as ProductSearchLoadByCodeSuccess, productGroup_actions_d_SEARCH_PRODUCTS as SEARCH_PRODUCTS, productGroup_actions_d_SEARCH_PRODUCTS_FAIL as SEARCH_PRODUCTS_FAIL, productGroup_actions_d_SEARCH_PRODUCTS_SUCCESS as SEARCH_PRODUCTS_SUCCESS, productGroup_actions_d_SearchProducts as SearchProducts, productGroup_actions_d_SearchProductsFail as SearchProductsFail, productGroup_actions_d_SearchProductsSuccess as SearchProductsSuccess };
  export type { productGroup_actions_d_EntityScopedLoaderAction as EntityScopedLoaderAction, productGroup_actions_d_ProductAction as ProductAction, productGroup_actions_d_ProductMeta as ProductMeta, productGroup_actions_d_ProductReferencesAction as ProductReferencesAction, productGroup_actions_d_ProductReviewsAction as ProductReviewsAction, productGroup_actions_d_ProductSearchAction as ProductSearchAction, productGroup_actions_d_ProductSearchByCategoryAction as ProductSearchByCategoryAction, productGroup_actions_d_ProductSearchByCodeAction as ProductSearchByCodeAction };
}

declare const getProductsState: MemoizedSelector<StateWithProduct, ProductsState>;

declare const getProductReferencesState: MemoizedSelector<StateWithProduct, ProductReferencesState>;
declare const getSelectedProductReferencesFactory: (productCode: string, referenceType: string) => MemoizedSelector<StateWithProduct, ProductReference[]>;

declare const getProductReviewsState: MemoizedSelector<StateWithProduct, ProductReviewsState>;
declare const getSelectedProductReviewsFactory: (productCode: string) => MemoizedSelector<StateWithProduct, Review[] | undefined>;

declare const getProductsSearchState: MemoizedSelector<StateWithProduct, ProductsSearchState>;
declare const getSearchResults: MemoizedSelector<StateWithProduct, ProductSearchPage>;
declare const getAuxSearchResults: MemoizedSelector<StateWithProduct, ProductSearchPage>;
declare const getProductSuggestions: MemoizedSelector<StateWithProduct, Suggestion[]>;

declare const getProductSearchByCodeState: MemoizedSelector<StateWithProduct, EntityScopedLoaderState<Product>>;
declare const getSelectedProductSearchByCodeStateFactory: (payload: {
    code: string;
    scope: string;
}) => MemoizedSelector<StateWithProduct, LoaderState<Product>>;

declare const getProductSearchByCategoryState: MemoizedSelector<StateWithProduct, EntityScopedLoaderState<Product[]>>;
declare const getSelectedProductSearchByCategoryStateFactory: (payload: {
    categoryCode: string;
    scope: string;
}) => MemoizedSelector<StateWithProduct, LoaderState<Product[]>>;

declare const getProductState: MemoizedSelector<StateWithProduct, EntityScopedLoaderState<Product>>;
declare const getSelectedProductStateFactory: (code: string, scope?: string) => MemoizedSelector<StateWithProduct, LoaderState<Product>>;
declare const getSelectedProductFactory: (code: string, scope?: string) => MemoizedSelector<StateWithProduct, Product>;
declare const getSelectedProductLoadingFactory: (code: string, scope?: string) => MemoizedSelector<StateWithProduct, boolean>;
declare const getSelectedProductSuccessFactory: (code: string, scope?: string) => MemoizedSelector<StateWithProduct, boolean>;
declare const getSelectedProductErrorFactory: (code: string, scope?: string) => MemoizedSelector<StateWithProduct, boolean>;
declare const getAllProductCodes: MemoizedSelector<StateWithProduct, string[]>;

declare const productGroup_selectors_d_getAllProductCodes: typeof getAllProductCodes;
declare const productGroup_selectors_d_getAuxSearchResults: typeof getAuxSearchResults;
declare const productGroup_selectors_d_getProductReferencesState: typeof getProductReferencesState;
declare const productGroup_selectors_d_getProductReviewsState: typeof getProductReviewsState;
declare const productGroup_selectors_d_getProductSearchByCategoryState: typeof getProductSearchByCategoryState;
declare const productGroup_selectors_d_getProductSearchByCodeState: typeof getProductSearchByCodeState;
declare const productGroup_selectors_d_getProductState: typeof getProductState;
declare const productGroup_selectors_d_getProductSuggestions: typeof getProductSuggestions;
declare const productGroup_selectors_d_getProductsSearchState: typeof getProductsSearchState;
declare const productGroup_selectors_d_getProductsState: typeof getProductsState;
declare const productGroup_selectors_d_getSearchResults: typeof getSearchResults;
declare const productGroup_selectors_d_getSelectedProductErrorFactory: typeof getSelectedProductErrorFactory;
declare const productGroup_selectors_d_getSelectedProductFactory: typeof getSelectedProductFactory;
declare const productGroup_selectors_d_getSelectedProductLoadingFactory: typeof getSelectedProductLoadingFactory;
declare const productGroup_selectors_d_getSelectedProductReferencesFactory: typeof getSelectedProductReferencesFactory;
declare const productGroup_selectors_d_getSelectedProductReviewsFactory: typeof getSelectedProductReviewsFactory;
declare const productGroup_selectors_d_getSelectedProductSearchByCategoryStateFactory: typeof getSelectedProductSearchByCategoryStateFactory;
declare const productGroup_selectors_d_getSelectedProductSearchByCodeStateFactory: typeof getSelectedProductSearchByCodeStateFactory;
declare const productGroup_selectors_d_getSelectedProductStateFactory: typeof getSelectedProductStateFactory;
declare const productGroup_selectors_d_getSelectedProductSuccessFactory: typeof getSelectedProductSuccessFactory;
declare namespace productGroup_selectors_d {
  export {
    productGroup_selectors_d_getAllProductCodes as getAllProductCodes,
    productGroup_selectors_d_getAuxSearchResults as getAuxSearchResults,
    productGroup_selectors_d_getProductReferencesState as getProductReferencesState,
    productGroup_selectors_d_getProductReviewsState as getProductReviewsState,
    productGroup_selectors_d_getProductSearchByCategoryState as getProductSearchByCategoryState,
    productGroup_selectors_d_getProductSearchByCodeState as getProductSearchByCodeState,
    productGroup_selectors_d_getProductState as getProductState,
    productGroup_selectors_d_getProductSuggestions as getProductSuggestions,
    productGroup_selectors_d_getProductsSearchState as getProductsSearchState,
    productGroup_selectors_d_getProductsState as getProductsState,
    productGroup_selectors_d_getSearchResults as getSearchResults,
    productGroup_selectors_d_getSelectedProductErrorFactory as getSelectedProductErrorFactory,
    productGroup_selectors_d_getSelectedProductFactory as getSelectedProductFactory,
    productGroup_selectors_d_getSelectedProductLoadingFactory as getSelectedProductLoadingFactory,
    productGroup_selectors_d_getSelectedProductReferencesFactory as getSelectedProductReferencesFactory,
    productGroup_selectors_d_getSelectedProductReviewsFactory as getSelectedProductReviewsFactory,
    productGroup_selectors_d_getSelectedProductSearchByCategoryStateFactory as getSelectedProductSearchByCategoryStateFactory,
    productGroup_selectors_d_getSelectedProductSearchByCodeStateFactory as getSelectedProductSearchByCodeStateFactory,
    productGroup_selectors_d_getSelectedProductStateFactory as getSelectedProductStateFactory,
    productGroup_selectors_d_getSelectedProductSuccessFactory as getSelectedProductSuccessFactory,
  };
}

/**
 * Helper function for safely getting context parameter config
 *
 * @param config
 * @param parameter
 */
declare function getContextParameterValues(config: SiteContextConfig, parameter: string): string[];
/**
 * Helper function for calculating default value for context parameter from config
 *
 * @param config
 * @param parameter
 */
declare function getContextParameterDefault(config: SiteContextConfig, parameter: string): string | undefined;

declare class SiteConnector {
    protected adapter: SiteAdapter;
    constructor(adapter: SiteAdapter);
    getLanguages(): Observable<Language[]>;
    getCurrencies(): Observable<Currency[]>;
    getCountries(type?: CountryType): Observable<Country[]>;
    getRegions(countryIsoCode: string): Observable<Region[]>;
    getCities(regionIsocode: string): Observable<City[]>;
    getDistricts(cityIsocode: string): Observable<CityDistrict[]>;
    getBaseSite(siteUid?: string): Observable<BaseSite | undefined>;
    getBaseSites(): Observable<BaseSite[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SiteConnector>;
}

declare const LANGUAGE_NORMALIZER: InjectionToken<Converter<any, Language>>;
declare const CURRENCY_NORMALIZER: InjectionToken<Converter<any, Currency>>;
declare const COUNTRY_NORMALIZER: InjectionToken<Converter<any, Country>>;
declare const REGION_NORMALIZER: InjectionToken<Converter<any, Region>>;
declare const CITY_NORMALIZER: InjectionToken<Converter<any, City>>;
declare const CITY_DISTRICT_NORMALIZER: InjectionToken<Converter<any, CityDistrict>>;
declare const BASE_SITE_NORMALIZER: InjectionToken<Converter<any, BaseSite>>;

/**
 * Indicates that the language has changed.
 */
declare class LanguageSetEvent extends CxEvent {
    /**
     * Event's type
     */
    static readonly type = "LanguageSetEvent";
    activeLanguage: string;
}
/**
 * Indicates that the Currency has changed.
 */
declare class CurrencySetEvent extends CxEvent {
    /**
     * Event's type
     */
    static readonly type = "CurrencySetEvent";
    activeCurrency: string;
}

declare const LANGUAGE_CONTEXT_ID = "language";
declare const CURRENCY_CONTEXT_ID = "currency";
declare const BASE_SITE_CONTEXT_ID = "baseSite";
declare const THEME_CONTEXT_ID = "theme";

declare const LOAD_BASE_SITE = "[Site-context] Load BaseSite";
declare const LOAD_BASE_SITE_FAIL = "[Site-context] Load BaseSite Fail";
declare const LOAD_BASE_SITE_SUCCESS = "[Site-context] Load BaseSite Success";
declare const LOAD_BASE_SITES = "[Site-context] Load BaseSites";
declare const LOAD_BASE_SITES_FAIL = "[Site-context] Load BaseSites Fail";
declare const LOAD_BASE_SITES_SUCCESS = "[Site-context] Load BaseSites Success";
declare const SET_ACTIVE_BASE_SITE = "[Site-context] Set Active BaseSite";
declare const BASE_SITE_CHANGE = "[Site-context] BaseSite Change";
declare class LoadBaseSite implements Action {
    readonly type = "[Site-context] Load BaseSite";
}
declare class LoadBaseSiteFail implements ErrorAction {
    payload: any;
    error: any;
    readonly type = "[Site-context] Load BaseSite Fail";
    constructor(payload: any);
}
declare class LoadBaseSiteSuccess implements Action {
    payload: BaseSite;
    readonly type = "[Site-context] Load BaseSite Success";
    constructor(payload: BaseSite);
}
declare class LoadBaseSites implements Action {
    readonly type = "[Site-context] Load BaseSites";
}
declare class LoadBaseSitesFail implements ErrorAction {
    payload: any;
    error: any;
    readonly type = "[Site-context] Load BaseSites Fail";
    constructor(payload: any);
}
declare class LoadBaseSitesSuccess implements Action {
    payload: BaseSite[];
    readonly type = "[Site-context] Load BaseSites Success";
    constructor(payload: BaseSite[]);
}
declare class SetActiveBaseSite implements Action {
    payload: string;
    readonly type = "[Site-context] Set Active BaseSite";
    constructor(payload: string);
}
declare class BaseSiteChange implements Action {
    readonly type = "[Site-context] BaseSite Change";
}
type BaseSiteAction = LoadBaseSite | LoadBaseSiteFail | LoadBaseSiteSuccess | LoadBaseSites | LoadBaseSitesFail | LoadBaseSitesSuccess | SetActiveBaseSite | BaseSiteChange;

declare const LOAD_CURRENCIES = "[Site-context] Load Currencies";
declare const LOAD_CURRENCIES_FAIL = "[Site-context] Load Currencies Fail";
declare const LOAD_CURRENCIES_SUCCESS = "[Site-context] Load Currencies Success";
declare const SET_ACTIVE_CURRENCY = "[Site-context] Set Active Currency";
declare const CURRENCY_CHANGE = "[Site-context] Currency Change";
declare class LoadCurrencies implements Action {
    readonly type = "[Site-context] Load Currencies";
}
declare class LoadCurrenciesFail implements ErrorAction {
    payload: any;
    error: any;
    readonly type = "[Site-context] Load Currencies Fail";
    constructor(payload: any);
}
declare class LoadCurrenciesSuccess implements Action {
    payload: Currency[];
    readonly type = "[Site-context] Load Currencies Success";
    constructor(payload: Currency[]);
}
declare class SetActiveCurrency implements Action {
    payload: string;
    readonly type = "[Site-context] Set Active Currency";
    constructor(payload: string);
}
declare class CurrencyChange implements Action {
    payload: {
        previous: string | null;
        current: string | null;
    };
    readonly type = "[Site-context] Currency Change";
    constructor(payload: {
        previous: string | null;
        current: string | null;
    });
}
type CurrenciesAction = LoadCurrencies | LoadCurrenciesFail | LoadCurrenciesSuccess | SetActiveCurrency | CurrencyChange;

declare const LOAD_LANGUAGES = "[Site-context] Load Languages";
declare const LOAD_LANGUAGES_FAIL = "[Site-context] Load Languages Fail";
declare const LOAD_LANGUAGES_SUCCESS = "[Site-context] Load Languages Success";
declare const SET_ACTIVE_LANGUAGE = "[Site-context] Set Active Language";
declare const LANGUAGE_CHANGE = "[Site-context] Language Change";
declare class LoadLanguages implements Action {
    readonly type = "[Site-context] Load Languages";
}
declare class LoadLanguagesFail implements ErrorAction {
    payload: any;
    error: any;
    readonly type = "[Site-context] Load Languages Fail";
    constructor(payload: any);
}
declare class LoadLanguagesSuccess implements Action {
    payload: Language[];
    readonly type = "[Site-context] Load Languages Success";
    constructor(payload: Language[]);
}
declare class SetActiveLanguage implements Action {
    payload: string;
    readonly type = "[Site-context] Set Active Language";
    constructor(payload: string);
}
declare class LanguageChange implements Action {
    payload: {
        previous: string | null;
        current: string | null;
    };
    readonly type = "[Site-context] Language Change";
    constructor(payload: {
        previous: string | null;
        current: string | null;
    });
}
type LanguagesAction = LoadLanguages | LoadLanguagesFail | LoadLanguagesSuccess | SetActiveLanguage | LanguageChange;

declare const siteContextGroup_actions_d_BASE_SITE_CHANGE: typeof BASE_SITE_CHANGE;
type siteContextGroup_actions_d_BaseSiteAction = BaseSiteAction;
type siteContextGroup_actions_d_BaseSiteChange = BaseSiteChange;
declare const siteContextGroup_actions_d_BaseSiteChange: typeof BaseSiteChange;
declare const siteContextGroup_actions_d_CURRENCY_CHANGE: typeof CURRENCY_CHANGE;
type siteContextGroup_actions_d_CurrenciesAction = CurrenciesAction;
type siteContextGroup_actions_d_CurrencyChange = CurrencyChange;
declare const siteContextGroup_actions_d_CurrencyChange: typeof CurrencyChange;
declare const siteContextGroup_actions_d_LANGUAGE_CHANGE: typeof LANGUAGE_CHANGE;
declare const siteContextGroup_actions_d_LOAD_BASE_SITE: typeof LOAD_BASE_SITE;
declare const siteContextGroup_actions_d_LOAD_BASE_SITES: typeof LOAD_BASE_SITES;
declare const siteContextGroup_actions_d_LOAD_BASE_SITES_FAIL: typeof LOAD_BASE_SITES_FAIL;
declare const siteContextGroup_actions_d_LOAD_BASE_SITES_SUCCESS: typeof LOAD_BASE_SITES_SUCCESS;
declare const siteContextGroup_actions_d_LOAD_BASE_SITE_FAIL: typeof LOAD_BASE_SITE_FAIL;
declare const siteContextGroup_actions_d_LOAD_BASE_SITE_SUCCESS: typeof LOAD_BASE_SITE_SUCCESS;
declare const siteContextGroup_actions_d_LOAD_CURRENCIES: typeof LOAD_CURRENCIES;
declare const siteContextGroup_actions_d_LOAD_CURRENCIES_FAIL: typeof LOAD_CURRENCIES_FAIL;
declare const siteContextGroup_actions_d_LOAD_CURRENCIES_SUCCESS: typeof LOAD_CURRENCIES_SUCCESS;
declare const siteContextGroup_actions_d_LOAD_LANGUAGES: typeof LOAD_LANGUAGES;
declare const siteContextGroup_actions_d_LOAD_LANGUAGES_FAIL: typeof LOAD_LANGUAGES_FAIL;
declare const siteContextGroup_actions_d_LOAD_LANGUAGES_SUCCESS: typeof LOAD_LANGUAGES_SUCCESS;
type siteContextGroup_actions_d_LanguageChange = LanguageChange;
declare const siteContextGroup_actions_d_LanguageChange: typeof LanguageChange;
type siteContextGroup_actions_d_LanguagesAction = LanguagesAction;
type siteContextGroup_actions_d_LoadBaseSite = LoadBaseSite;
declare const siteContextGroup_actions_d_LoadBaseSite: typeof LoadBaseSite;
type siteContextGroup_actions_d_LoadBaseSiteFail = LoadBaseSiteFail;
declare const siteContextGroup_actions_d_LoadBaseSiteFail: typeof LoadBaseSiteFail;
type siteContextGroup_actions_d_LoadBaseSiteSuccess = LoadBaseSiteSuccess;
declare const siteContextGroup_actions_d_LoadBaseSiteSuccess: typeof LoadBaseSiteSuccess;
type siteContextGroup_actions_d_LoadBaseSites = LoadBaseSites;
declare const siteContextGroup_actions_d_LoadBaseSites: typeof LoadBaseSites;
type siteContextGroup_actions_d_LoadBaseSitesFail = LoadBaseSitesFail;
declare const siteContextGroup_actions_d_LoadBaseSitesFail: typeof LoadBaseSitesFail;
type siteContextGroup_actions_d_LoadBaseSitesSuccess = LoadBaseSitesSuccess;
declare const siteContextGroup_actions_d_LoadBaseSitesSuccess: typeof LoadBaseSitesSuccess;
type siteContextGroup_actions_d_LoadCurrencies = LoadCurrencies;
declare const siteContextGroup_actions_d_LoadCurrencies: typeof LoadCurrencies;
type siteContextGroup_actions_d_LoadCurrenciesFail = LoadCurrenciesFail;
declare const siteContextGroup_actions_d_LoadCurrenciesFail: typeof LoadCurrenciesFail;
type siteContextGroup_actions_d_LoadCurrenciesSuccess = LoadCurrenciesSuccess;
declare const siteContextGroup_actions_d_LoadCurrenciesSuccess: typeof LoadCurrenciesSuccess;
type siteContextGroup_actions_d_LoadLanguages = LoadLanguages;
declare const siteContextGroup_actions_d_LoadLanguages: typeof LoadLanguages;
type siteContextGroup_actions_d_LoadLanguagesFail = LoadLanguagesFail;
declare const siteContextGroup_actions_d_LoadLanguagesFail: typeof LoadLanguagesFail;
type siteContextGroup_actions_d_LoadLanguagesSuccess = LoadLanguagesSuccess;
declare const siteContextGroup_actions_d_LoadLanguagesSuccess: typeof LoadLanguagesSuccess;
declare const siteContextGroup_actions_d_SET_ACTIVE_BASE_SITE: typeof SET_ACTIVE_BASE_SITE;
declare const siteContextGroup_actions_d_SET_ACTIVE_CURRENCY: typeof SET_ACTIVE_CURRENCY;
declare const siteContextGroup_actions_d_SET_ACTIVE_LANGUAGE: typeof SET_ACTIVE_LANGUAGE;
type siteContextGroup_actions_d_SetActiveBaseSite = SetActiveBaseSite;
declare const siteContextGroup_actions_d_SetActiveBaseSite: typeof SetActiveBaseSite;
type siteContextGroup_actions_d_SetActiveCurrency = SetActiveCurrency;
declare const siteContextGroup_actions_d_SetActiveCurrency: typeof SetActiveCurrency;
type siteContextGroup_actions_d_SetActiveLanguage = SetActiveLanguage;
declare const siteContextGroup_actions_d_SetActiveLanguage: typeof SetActiveLanguage;
declare namespace siteContextGroup_actions_d {
  export { siteContextGroup_actions_d_BASE_SITE_CHANGE as BASE_SITE_CHANGE, siteContextGroup_actions_d_BaseSiteChange as BaseSiteChange, siteContextGroup_actions_d_CURRENCY_CHANGE as CURRENCY_CHANGE, siteContextGroup_actions_d_CurrencyChange as CurrencyChange, siteContextGroup_actions_d_LANGUAGE_CHANGE as LANGUAGE_CHANGE, siteContextGroup_actions_d_LOAD_BASE_SITE as LOAD_BASE_SITE, siteContextGroup_actions_d_LOAD_BASE_SITES as LOAD_BASE_SITES, siteContextGroup_actions_d_LOAD_BASE_SITES_FAIL as LOAD_BASE_SITES_FAIL, siteContextGroup_actions_d_LOAD_BASE_SITES_SUCCESS as LOAD_BASE_SITES_SUCCESS, siteContextGroup_actions_d_LOAD_BASE_SITE_FAIL as LOAD_BASE_SITE_FAIL, siteContextGroup_actions_d_LOAD_BASE_SITE_SUCCESS as LOAD_BASE_SITE_SUCCESS, siteContextGroup_actions_d_LOAD_CURRENCIES as LOAD_CURRENCIES, siteContextGroup_actions_d_LOAD_CURRENCIES_FAIL as LOAD_CURRENCIES_FAIL, siteContextGroup_actions_d_LOAD_CURRENCIES_SUCCESS as LOAD_CURRENCIES_SUCCESS, siteContextGroup_actions_d_LOAD_LANGUAGES as LOAD_LANGUAGES, siteContextGroup_actions_d_LOAD_LANGUAGES_FAIL as LOAD_LANGUAGES_FAIL, siteContextGroup_actions_d_LOAD_LANGUAGES_SUCCESS as LOAD_LANGUAGES_SUCCESS, siteContextGroup_actions_d_LanguageChange as LanguageChange, siteContextGroup_actions_d_LoadBaseSite as LoadBaseSite, siteContextGroup_actions_d_LoadBaseSiteFail as LoadBaseSiteFail, siteContextGroup_actions_d_LoadBaseSiteSuccess as LoadBaseSiteSuccess, siteContextGroup_actions_d_LoadBaseSites as LoadBaseSites, siteContextGroup_actions_d_LoadBaseSitesFail as LoadBaseSitesFail, siteContextGroup_actions_d_LoadBaseSitesSuccess as LoadBaseSitesSuccess, siteContextGroup_actions_d_LoadCurrencies as LoadCurrencies, siteContextGroup_actions_d_LoadCurrenciesFail as LoadCurrenciesFail, siteContextGroup_actions_d_LoadCurrenciesSuccess as LoadCurrenciesSuccess, siteContextGroup_actions_d_LoadLanguages as LoadLanguages, siteContextGroup_actions_d_LoadLanguagesFail as LoadLanguagesFail, siteContextGroup_actions_d_LoadLanguagesSuccess as LoadLanguagesSuccess, siteContextGroup_actions_d_SET_ACTIVE_BASE_SITE as SET_ACTIVE_BASE_SITE, siteContextGroup_actions_d_SET_ACTIVE_CURRENCY as SET_ACTIVE_CURRENCY, siteContextGroup_actions_d_SET_ACTIVE_LANGUAGE as SET_ACTIVE_LANGUAGE, siteContextGroup_actions_d_SetActiveBaseSite as SetActiveBaseSite, siteContextGroup_actions_d_SetActiveCurrency as SetActiveCurrency, siteContextGroup_actions_d_SetActiveLanguage as SetActiveLanguage };
  export type { siteContextGroup_actions_d_BaseSiteAction as BaseSiteAction, siteContextGroup_actions_d_CurrenciesAction as CurrenciesAction, siteContextGroup_actions_d_LanguagesAction as LanguagesAction };
}

declare const getBaseSiteState: MemoizedSelector<StateWithSiteContext, BaseSiteState>;
declare const getActiveBaseSite: MemoizedSelector<StateWithSiteContext, string>;
declare const getBaseSiteData: MemoizedSelector<StateWithSiteContext, BaseSite>;
declare const getBaseSitesEntities: MemoizedSelector<StateWithSiteContext, BaseSiteEntities | null>;
declare const getAllBaseSites: MemoizedSelector<StateWithSiteContext, BaseSite[] | null>;

declare const getCurrenciesState: MemoizedSelector<StateWithSiteContext, CurrenciesState>;
declare const getCurrenciesEntities: MemoizedSelector<StateWithSiteContext, CurrencyEntities | null>;
declare const getActiveCurrency: MemoizedSelector<StateWithSiteContext, string | null>;
declare const getAllCurrencies: MemoizedSelector<StateWithSiteContext, Currency[] | null>;

declare const getLanguagesState: MemoizedSelector<StateWithSiteContext, LanguagesState>;
declare const getLanguagesEntities: MemoizedSelector<StateWithSiteContext, LanguagesEntities | null>;
declare const getActiveLanguage: MemoizedSelector<StateWithSiteContext, string | null>;
declare const getAllLanguages: MemoizedSelector<StateWithSiteContext, Language[] | null>;

declare const getSiteContextState: MemoizedSelector<StateWithSiteContext, SiteContextState>;

declare const siteContextGroup_selectors_d_getActiveBaseSite: typeof getActiveBaseSite;
declare const siteContextGroup_selectors_d_getActiveCurrency: typeof getActiveCurrency;
declare const siteContextGroup_selectors_d_getActiveLanguage: typeof getActiveLanguage;
declare const siteContextGroup_selectors_d_getAllBaseSites: typeof getAllBaseSites;
declare const siteContextGroup_selectors_d_getAllCurrencies: typeof getAllCurrencies;
declare const siteContextGroup_selectors_d_getAllLanguages: typeof getAllLanguages;
declare const siteContextGroup_selectors_d_getBaseSiteData: typeof getBaseSiteData;
declare const siteContextGroup_selectors_d_getBaseSiteState: typeof getBaseSiteState;
declare const siteContextGroup_selectors_d_getBaseSitesEntities: typeof getBaseSitesEntities;
declare const siteContextGroup_selectors_d_getCurrenciesEntities: typeof getCurrenciesEntities;
declare const siteContextGroup_selectors_d_getCurrenciesState: typeof getCurrenciesState;
declare const siteContextGroup_selectors_d_getLanguagesEntities: typeof getLanguagesEntities;
declare const siteContextGroup_selectors_d_getLanguagesState: typeof getLanguagesState;
declare const siteContextGroup_selectors_d_getSiteContextState: typeof getSiteContextState;
declare namespace siteContextGroup_selectors_d {
  export {
    siteContextGroup_selectors_d_getActiveBaseSite as getActiveBaseSite,
    siteContextGroup_selectors_d_getActiveCurrency as getActiveCurrency,
    siteContextGroup_selectors_d_getActiveLanguage as getActiveLanguage,
    siteContextGroup_selectors_d_getAllBaseSites as getAllBaseSites,
    siteContextGroup_selectors_d_getAllCurrencies as getAllCurrencies,
    siteContextGroup_selectors_d_getAllLanguages as getAllLanguages,
    siteContextGroup_selectors_d_getBaseSiteData as getBaseSiteData,
    siteContextGroup_selectors_d_getBaseSiteState as getBaseSiteState,
    siteContextGroup_selectors_d_getBaseSitesEntities as getBaseSitesEntities,
    siteContextGroup_selectors_d_getCurrenciesEntities as getCurrenciesEntities,
    siteContextGroup_selectors_d_getCurrenciesState as getCurrenciesState,
    siteContextGroup_selectors_d_getLanguagesEntities as getLanguagesEntities,
    siteContextGroup_selectors_d_getLanguagesState as getLanguagesState,
    siteContextGroup_selectors_d_getSiteContextState as getSiteContextState,
  };
}

declare abstract class SiteThemeConfig {
    siteTheme?: {
        optionalThemes?: Array<SiteTheme>;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteThemeConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SiteThemeConfig>;
}
declare module './spartacus-core' {
    interface Config extends SiteThemeConfig {
    }
}

declare const defaultSiteThemeConfig: SiteThemeConfig;

declare class SiteThemeService implements SiteContext<SiteTheme> {
    private featureToggles;
    protected store: Store<any>;
    protected config: Config;
    protected baseSiteService: BaseSiteService;
    /**
     * Fallback default theme ID to be used when `config.context.theme` is not defined.
     */
    protected readonly FALLBACK_DEFAULT_THEME_ID = "";
    getDefault(): SiteTheme;
    /**
     * Resolves the "Default" theme: static `config.context.theme` if set,
     * otherwise (when `applyBaseSiteThemeFromCms` is on) the active base
     * site's `theme`. Falls back to an empty string.
     */
    protected getDefaultClassName(): string;
    /**
     * Synchronously reads `theme` of the currently active base site.
     * Returns `undefined` when no base site has resolved yet.
     */
    protected readActiveBaseSiteTheme(): string | undefined;
    /**
     * List of possible themes.
     *
     * There are 2 types of themes: default and optional which are configured differently in Spartacus config.
     * This property combines both types of themes into a single list.
     *
     * 1. The default theme ID can be configured only via Spartacus config `config.context.theme`
     *    (note: its value can be defined statically or fetched dynamically from the CMS backend).
     * 2. The optional themes (their IDs and their i18n keys) can be configured
     *    only via Spartacus config `config.siteTheme.optionalThemes`
     *
     * CAUTION: This property should be accessed only when those configs are stable, e.g. `ConfigInitializer.getStable('context','siteTheme'))`
     */
    protected get themes(): SiteTheme[];
    getAll(): Observable<SiteTheme[]>;
    /**
     * Gets the className of the active theme.
     */
    getActive(): Observable<string>;
    /**
     * Sets the active theme className.
     */
    setActive(className: string): void;
    isInitialized(): boolean;
    protected isValid(className: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SiteThemeService>;
}

declare const SET_ACTIVE_SITE_THEME = "[Site-theme] Set Active Site Theme";
declare const SITE_THEME_CHANGE = "[Site-theme] Site Theme Change";
declare class SetActiveSiteTheme implements Action {
    payload: string;
    readonly type = "[Site-theme] Set Active Site Theme";
    constructor(payload: string);
}
declare class SiteThemeChange implements Action {
    payload: {
        previous: string | null;
        current: string | null;
    };
    readonly type = "[Site-theme] Site Theme Change";
    constructor(payload: {
        previous: string | null;
        current: string | null;
    });
}
type SiteThemesAction = SetActiveSiteTheme | SiteThemeChange;

declare const siteThemeGroup_actions_d_SET_ACTIVE_SITE_THEME: typeof SET_ACTIVE_SITE_THEME;
declare const siteThemeGroup_actions_d_SITE_THEME_CHANGE: typeof SITE_THEME_CHANGE;
type siteThemeGroup_actions_d_SetActiveSiteTheme = SetActiveSiteTheme;
declare const siteThemeGroup_actions_d_SetActiveSiteTheme: typeof SetActiveSiteTheme;
type siteThemeGroup_actions_d_SiteThemeChange = SiteThemeChange;
declare const siteThemeGroup_actions_d_SiteThemeChange: typeof SiteThemeChange;
type siteThemeGroup_actions_d_SiteThemesAction = SiteThemesAction;
declare namespace siteThemeGroup_actions_d {
  export { siteThemeGroup_actions_d_SET_ACTIVE_SITE_THEME as SET_ACTIVE_SITE_THEME, siteThemeGroup_actions_d_SITE_THEME_CHANGE as SITE_THEME_CHANGE, siteThemeGroup_actions_d_SetActiveSiteTheme as SetActiveSiteTheme, siteThemeGroup_actions_d_SiteThemeChange as SiteThemeChange };
  export type { siteThemeGroup_actions_d_SiteThemesAction as SiteThemesAction };
}

declare const SITE_THEME_FEATURE = "siteTheme";
interface StateWithSiteTheme {
    [SITE_THEME_FEATURE]: SiteThemeState;
}
interface SiteThemeState {
    themes: SiteThemesState;
}
interface SiteThemeEntities {
    [className: string]: SiteTheme;
}
interface SiteThemesState {
    activeSiteTheme: string | null;
}

declare const getSiteThemesState: MemoizedSelector<StateWithSiteTheme, SiteThemesState>;
declare const getActiveSiteTheme: MemoizedSelector<StateWithSiteTheme, string | null>;

declare const getSiteThemeState: MemoizedSelector<StateWithSiteTheme, SiteThemeState>;

declare const siteThemeGroup_selectors_d_getActiveSiteTheme: typeof getActiveSiteTheme;
declare const siteThemeGroup_selectors_d_getSiteThemeState: typeof getSiteThemeState;
declare const siteThemeGroup_selectors_d_getSiteThemesState: typeof getSiteThemesState;
declare namespace siteThemeGroup_selectors_d {
  export {
    siteThemeGroup_selectors_d_getActiveSiteTheme as getActiveSiteTheme,
    siteThemeGroup_selectors_d_getSiteThemeState as getSiteThemeState,
    siteThemeGroup_selectors_d_getSiteThemesState as getSiteThemesState,
  };
}

declare abstract class HierarchicalAddressConfig {
    hierarchicalAddress?: {
        /**
         * Country isocodes whose addresses use a hierarchical (multi-level)
         * format: country → region → city → district. For these countries the
         * address form shows chained dropdowns and skips OCC address verification.
         */
        countriesUsingHierarchicalAddressFormat?: string[];
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<HierarchicalAddressConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HierarchicalAddressConfig>;
}
declare module './spartacus-core' {
    interface Config extends HierarchicalAddressConfig {
    }
}

declare const defaultHierarchicalAddressConfig: HierarchicalAddressConfig;

declare class UserAddressConnector {
    protected adapter: UserAddressAdapter;
    constructor(adapter: UserAddressAdapter);
    getAll(userId: string): Observable<Address[]>;
    add(userId: string, address: Address): Observable<{}>;
    update(userId: string, addressId: string, address: Address): Observable<{}>;
    verify(userId: string, address: Address): Observable<AddressValidation>;
    delete(userId: string, addressId: string): Observable<{}>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAddressConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserAddressConnector>;
}

declare const ADDRESS_NORMALIZER: InjectionToken<Converter<any, Address>>;
declare const ADDRESS_LIST_NORMALIZER: InjectionToken<Converter<any, EntitiesModel<Address>>>;
declare const ADDRESS_SERIALIZER: InjectionToken<Converter<Address, any>>;
declare const ADDRESS_VALIDATION_NORMALIZER: InjectionToken<Converter<any, AddressValidation>>;

declare class UserConsentConnector {
    protected adapter: UserConsentAdapter;
    constructor(adapter: UserConsentAdapter);
    loadConsents(userId: string): Observable<ConsentTemplate[]>;
    giveConsent(userId: string, consentTemplateId: string, consentTemplateVersion: number): Observable<ConsentTemplate>;
    withdrawConsent(userId: string, consentCode: string, consentId?: string): Observable<{}>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserConsentConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserConsentConnector>;
}

declare const CONSENT_TEMPLATE_NORMALIZER: InjectionToken<Converter<any, ConsentTemplate>>;

declare abstract class UserCostCenterAdapter {
    /**
     * Returns the list of all active cost centers of the login user
     * @param userId
     */
    abstract loadActiveList(userId: string): Observable<EntitiesModel<CostCenter>>;
}

declare class UserCostCenterConnector {
    protected adapter: UserCostCenterAdapter;
    constructor(adapter: UserCostCenterAdapter);
    getActiveList(userId: string): Observable<EntitiesModel<CostCenter>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserCostCenterConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserCostCenterConnector>;
}

declare class CustomerCouponConnector {
    protected adapter: CustomerCouponAdapter;
    constructor(adapter: CustomerCouponAdapter);
    getCustomerCoupons(userId: string, pageSize: number, currentPage?: number, sort?: string): Observable<CustomerCouponSearchResult>;
    turnOnNotification(userId: string, couponCode: string): Observable<CustomerCouponNotification>;
    turnOffNotification(userId: string, couponCode: string): Observable<{}>;
    claimCustomerCoupon(userId: string, couponCode: string): Observable<CustomerCoupon2Customer>;
    disclaimCustomerCoupon(userId: string, couponCode: string): Observable<CustomerCoupon2Customer>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerCouponConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomerCouponConnector>;
}

declare const CUSTOMER_COUPON_SEARCH_RESULT_NORMALIZER: InjectionToken<Converter<any, CustomerCouponSearchResult>>;

declare const PRODUCT_INTERESTS_NORMALIZER: InjectionToken<Converter<any, ProductInterestSearchResult>>;

declare class UserInterestsConnector {
    protected adapter: UserInterestsAdapter;
    constructor(adapter: UserInterestsAdapter);
    getInterests(userId: string, pageSize?: number, currentPage?: number, sort?: string, productCode?: string, notificationType?: NotificationType): Observable<ProductInterestSearchResult>;
    removeInterest(userId: string, item: ProductInterestEntryRelation): Observable<any[]>;
    addInterest(userId: string, productCode: string, notificationType: NotificationType): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserInterestsConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserInterestsConnector>;
}

declare class UserPaymentConnector {
    protected adapter: UserPaymentAdapter;
    constructor(adapter: UserPaymentAdapter);
    getAll(userId: string): Observable<PaymentDetails[]>;
    delete(userId: string, paymentMethodID: string): Observable<{}>;
    setDefault(userId: string, paymentMethodID: string): Observable<{}>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserPaymentConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserPaymentConnector>;
}

declare class UserEventBuilder {
    protected stateEventService: StateEventService;
    constructor(stateEventService: StateEventService);
    /**
     * Registers user events
     */
    protected register(): void;
    /**
     * Register an address successfully updated event
     */
    protected updateUserAddressEvent(): void;
    protected addUserAddressEvent(): void;
    protected deleteUserAddressEvent(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserEventBuilder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserEventBuilder>;
}

declare class UserEventModule {
    constructor(_userEventBuilder: UserEventBuilder);
    static ɵfac: i0.ɵɵFactoryDeclaration<UserEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserEventModule>;
}

declare abstract class UserAddressEvent extends CxEvent {
    userId: string;
}
declare class UpdateUserAddressEvent extends UserAddressEvent {
    static readonly type = "UpdateUserAddressEvent";
    addressId: string;
    address: Address;
}
declare class DeleteUserAddressEvent extends UserAddressEvent {
    static readonly type = "DeleteUserAddressEvent";
    addressId: string;
}
declare class AddUserAddressEvent extends UserAddressEvent {
    static readonly type = "AddUserAddressEvent";
    address: Address;
}
declare class LoadUserAddressesEvent extends UserAddressEvent {
    static readonly type = "LoadUserAddressesEvent";
}
declare class LoadUserPaymentMethodsEvent extends UserAddressEvent {
    static readonly type = "LoadUserPaymentMethodsEvent";
}

declare const USER_FEATURE = "user";
declare const REGISTER_USER_PROCESS_ID = "registerUser";
declare const GIVE_CONSENT_PROCESS_ID = "giveConsent";
declare const WITHDRAW_CONSENT_PROCESS_ID = "withdrawConsent";
declare const UPDATE_NOTIFICATION_PREFERENCES_PROCESS_ID = "updateNotificationPreferences";
declare const ADD_PRODUCT_INTEREST_PROCESS_ID = "addProductInterests";
declare const REMOVE_PRODUCT_INTERESTS_PROCESS_ID = "removeProductInterests";
declare const USER_CONSENTS = "[User] User Consents";
declare const USER_PAYMENT_METHODS = "[User] User Payment Methods";
declare const USER_ADDRESSES = "[User] User Addresses";
declare const USER_COST_CENTERS = "[User] User Cost Centers";
declare const REGIONS = "[User] Regions";
declare const CITIES = "[User] Cities";
declare const DISTRICTS = "[User] Districts";
declare const CUSTOMER_COUPONS = "[User] Customer Coupons";
declare const SUBSCRIBE_CUSTOMER_COUPON_PROCESS_ID = "subscribeCustomerCoupon";
declare const UNSUBSCRIBE_CUSTOMER_COUPON_PROCESS_ID = "unsubscribeCustomerCoupon";
declare const CLAIM_CUSTOMER_COUPON_PROCESS_ID = "claimCustomerCoupon";
declare const DISCLAIM_CUSTOMER_COUPON_PROCESS_ID = "disclaimCustomerCoupon";
declare const NOTIFICATION_PREFERENCES = "[User] Notification Preferences";
declare const PRODUCT_INTERESTS = "[User] Product Interests";
interface StateWithUser {
    [USER_FEATURE]: UserState;
}
interface UserState {
    addresses: LoaderState<Address[]>;
    consents: LoaderState<ConsentTemplate[]>;
    billingCountries: BillingCountriesState;
    countries: DeliveryCountriesState;
    payments: LoaderState<PaymentDetails[]>;
    regions: LoaderState<RegionsState>;
    cities?: LoaderState<CitiesState>;
    districts?: LoaderState<DistrictsState>;
    customerCoupons: LoaderState<CustomerCouponSearchResult>;
    notificationPreferences: LoaderState<NotificationPreference[]>;
    productInterests: LoaderState<ProductInterestSearchResult>;
    costCenters: LoaderState<CostCenter[]>;
}
interface RegionsState {
    entities: Region[];
    country: string | null;
}
interface CitiesState {
    entities: City[];
    regionIsocode: string | null;
}
interface DistrictsState {
    entities: CityDistrict[];
    cityIsocode: string | null;
}
interface BillingCountryEntities {
    [key: string]: Country;
}
interface BillingCountriesState {
    entities: BillingCountryEntities;
}
interface DeliveryCountryEntities {
    [key: string]: Country;
}
interface DeliveryCountriesState {
    entities: DeliveryCountryEntities;
}

declare class UserConsentService {
    protected store: Store<StateWithUser | StateWithProcess<void>>;
    protected authService: AuthService;
    protected userIdService: UserIdService;
    constructor(store: Store<StateWithUser | StateWithProcess<void>>, authService: AuthService, userIdService: UserIdService);
    /**
     * Retrieves all consents.
     */
    loadConsents(): void;
    /**
     * Returns all consent templates. If `loadIfMissing` parameter is set to `true`, the method triggers the load if consent templates.
     * @param loadIfMissing is set to `true`, the method will load templates if those are not already present. The default value is `false`.
     */
    getConsents(loadIfMissing?: boolean): Observable<ConsentTemplate[]>;
    /**
     * Returns the consents loading flag
     */
    getConsentsResultLoading(): Observable<boolean>;
    /**
     * Returns the consents success flag
     */
    getConsentsResultSuccess(): Observable<boolean>;
    /**
     * Returns the consents error flag
     */
    getConsentsResultError(): Observable<boolean>;
    /**
     * Resets the processing state for consent retrieval
     */
    resetConsentsProcessState(): void;
    /**
     * Returns the registered consent for the given template ID.
     *
     * As a side-effect, the method will call `getConsents(true)` to load the templates if those are not present.
     *
     * @param templateId a template ID by which to filter the registered templates.
     */
    getConsent(templateId: string): Observable<Consent | undefined>;
    /**
     * Returns `true` if the consent is truthy and if `consentWithdrawnDate` doesn't exist.
     * Otherwise, `false` is returned.
     *
     * @param consent to check
     */
    isConsentGiven(consent: Consent): boolean;
    /**
     * Returns `true` if the consent is either falsy or if `consentWithdrawnDate` is present.
     * Otherwise, `false` is returned.
     *
     * @param consent to check
     */
    isConsentWithdrawn(consent: Consent | undefined): boolean;
    /**
     * Give consent for specified consent template ID and version.
     * @param consentTemplateId a template ID for which to give a consent
     * @param consentTemplateVersion a template version for which to give a consent
     */
    giveConsent(consentTemplateId: string, consentTemplateVersion: number): void;
    /**
     * Returns the give consent process loading flag
     */
    getGiveConsentResultLoading(): Observable<boolean>;
    /**
     * Returns the give consent process success flag
     */
    getGiveConsentResultSuccess(): Observable<boolean>;
    /**
     * Returns the give consent process error flag
     */
    getGiveConsentResultError(): Observable<boolean>;
    /**
     * Resents the give consent process flags
     */
    resetGiveConsentProcessState(): void;
    /**
     * Withdraw consent for the given `consentCode`
     * @param consentCode for which to withdraw the consent
     */
    withdrawConsent(consentCode: string, consentId?: string): void;
    /**
     * Returns the withdraw consent process loading flag
     */
    getWithdrawConsentResultLoading(): Observable<boolean>;
    /**
     * Returns the withdraw consent process success flag
     */
    getWithdrawConsentResultSuccess(): Observable<boolean>;
    /**
     * Returns the withdraw consent process error flag
     */
    getWithdrawConsentResultError(): Observable<boolean>;
    /**
     * Resets the process flags for withdraw consent
     */
    resetWithdrawConsentProcessState(): void;
    /**
     * Filters the provided `templateList`' templates by hiding the template IDs specified in `hideTemplateIds`.
     * If the `hideTemplateIds` is empty, the provided `templateList` is returned.
     *
     * @param templateList a list of consent templates to filter
     * @param hideTemplateIds template IDs to hide
     */
    filterConsentTemplates(templateList: ConsentTemplate[], hideTemplateIds?: string[]): ConsentTemplate[];
    static ɵfac: i0.ɵɵFactoryDeclaration<UserConsentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserConsentService>;
}

/**
 * Unified facade for both anonymous and registered user consents.
 */
declare class ConsentService {
    protected anonymousConsentsService: AnonymousConsentsService;
    protected userConsentService: UserConsentService;
    constructor(anonymousConsentsService: AnonymousConsentsService, userConsentService: UserConsentService);
    /**
     * Returns either anonymous consent or registered consent as they are emitted.
     * @param templateCode for which to return either anonymous or registered consent.
     */
    getConsent(templateCode: string): Observable<AnonymousConsent | Consent | undefined>;
    /**
     * Checks if the `templateId`'s template has a given consent.
     * The method returns `false` if the consent doesn't exist or if it's withdrawn. Otherwise, `true` is returned.
     *
     * @param templateId of a template which's consent should be checked
     */
    checkConsentGivenByTemplateId(templateId: string): Observable<boolean>;
    /**
     * Checks if the `templateId`'s template has a withdrawn consent.
     * The method returns `true` if the consent doesn't exist or if it's withdrawn. Otherwise, `false` is returned.
     *
     * @param templateId of a template which's consent should be checked
     */
    checkConsentWithdrawnByTemplateId(templateId: string): Observable<boolean>;
    /**
     *
     * Checks the provided `consent`'s type and delegates to an appropriate method - `anonymousConsentsService.isConsentGiven(consent)` or `this.userConsentService.isConsentGiven`
     *
     * @param consent a consent to check
     */
    isConsentGiven(consent: AnonymousConsent | Consent): boolean;
    /**
     *
     * Checks the provided `consent`'s type and delegates to an appropriate method - `anonymousConsentsService.isConsentWithdrawn(consent)` or `this.userConsentService.isConsentWithdrawn`
     *
     * @param consent a consent to check
     */
    isConsentWithdrawn(consent: AnonymousConsent | Consent): boolean;
    /**
     * Returns `true` if the provided consent is of type `AnonymousConsent`. Otherwise, `false` is returned.
     */
    isAnonymousConsentType(consent: AnonymousConsent | Consent): consent is AnonymousConsent;
    /**
     * Returns `true` if the provided consent is of type `Consent`. Otherwise, `false` is returned.
     */
    isConsentType(consent: AnonymousConsent | Consent): consent is Consent;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConsentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConsentService>;
}

declare class CustomerCouponService {
    protected store: Store<StateWithUser | StateWithProcess<void>>;
    protected userIdService: UserIdService;
    constructor(store: Store<StateWithUser | StateWithProcess<void>>, userIdService: UserIdService);
    /**
     * Retrieves customer's coupons
     * @param pageSize page size
     * @param currentPage current page
     * @param sort sort
     */
    loadCustomerCoupons(pageSize: number, currentPage?: number, sort?: string): void;
    /**
     * Returns customer coupon search result
     * @param pageSize page size
     */
    getCustomerCoupons(pageSize: number): Observable<CustomerCouponSearchResult>;
    /**
     * Returns a loaded flag for customer coupons
     */
    getCustomerCouponsLoaded(): Observable<boolean>;
    /**
     * Returns a loading flag for customer coupons
     */
    getCustomerCouponsLoading(): Observable<boolean>;
    /**
     * Subscribe a CustomerCoupon Notification
     * @param couponCode a customer coupon code
     */
    subscribeCustomerCoupon(couponCode: string): void;
    /**
     * Returns the subscribe customer coupon notification process loading flag
     */
    getSubscribeCustomerCouponResultLoading(): Observable<boolean>;
    /**
     * Returns the subscribe customer coupon notification process success flag
     */
    getSubscribeCustomerCouponResultSuccess(): Observable<boolean>;
    /**
     * Returns the subscribe customer coupon notification process error flag
     */
    getSubscribeCustomerCouponResultError(): Observable<boolean>;
    /**
     * Unsubscribe a CustomerCoupon Notification
     * @param couponCode a customer coupon code
     */
    unsubscribeCustomerCoupon(couponCode: string): void;
    /**
     * Returns the unsubscribe customer coupon notification process loading flag
     */
    getUnsubscribeCustomerCouponResultLoading(): Observable<boolean>;
    /**
     * Returns the unsubscribe customer coupon notification process success flag
     */
    getUnsubscribeCustomerCouponResultSuccess(): Observable<boolean>;
    /**
     * Returns the unsubscribe customer coupon notification process error flag
     */
    getUnsubscribeCustomerCouponResultError(): Observable<boolean>;
    /**
     * Claim a CustomerCoupon
     * @param couponCode a customer coupon code
     */
    claimCustomerCoupon(couponCode: string): void;
    /**
     * Disclaim a CustomerCoupon
     * @param couponCode a customer coupon code
     */
    disclaimCustomerCoupon(couponCode: string): void;
    /**
     * Resets the processing state for customer coupon
     */
    resetDisclaimCustomerCoupon(): void;
    /**
     * Returns the claim customer coupon notification process success flag
     */
    getClaimCustomerCouponResultSuccess(): Observable<boolean>;
    /**
     * Returns the claim customer coupon notification process loading flag
     */
    getClaimCustomerCouponResultLoading(): Observable<boolean>;
    /**
     * Returns the disclaim customer coupon notification process success flag
     */
    getDisclaimCustomerCouponResultSuccess(): Observable<boolean>;
    /**
     * Returns the claim customer coupon notification process error flag
     */
    getClaimCustomerCouponResultError(): Observable<boolean>;
    /**
     * Returns the disclaim customer coupon notification process error flag
     */
    getDisclaimCustomerCouponResultError(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerCouponService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomerCouponService>;
}

declare class UserAddressService {
    protected store: Store<StateWithUser>;
    protected userIdService: UserIdService;
    protected userAddressConnector: UserAddressConnector;
    protected command: CommandService;
    constructor(store: Store<StateWithUser>, userIdService: UserIdService, userAddressConnector: UserAddressConnector, command: CommandService);
    /**
     * Retrieves user's addresses
     */
    loadAddresses(): void;
    /**
     * Adds user address
     * @param address a user address
     */
    addUserAddress(address: Address): void;
    /**
     * Sets user address as default
     * @param addressId a user address ID
     */
    setAddressAsDefault(addressId: string): void;
    /**
     * Updates existing user address
     * @param addressId a user address ID
     * @param address a user address
     */
    updateUserAddress(addressId: string, address: Address): void;
    /**
     * Deletes existing user address
     * @param addressId a user address ID
     */
    deleteUserAddress(addressId: string): void;
    /**
     * Returns the default address
     */
    getDefaultAddress(): Observable<Address | undefined>;
    /**
     * Returns addresses
     */
    getAddresses(): Observable<Address[]>;
    /**
     * Returns a loading flag for addresses
     */
    getAddressesLoading(): Observable<boolean>;
    getAddressesLoadedSuccess(): Observable<boolean>;
    getAddressesError(): Observable<boolean>;
    /**
     * Retrieves delivery countries
     */
    loadDeliveryCountries(): void;
    /**
     * Returns all delivery countries
     */
    getDeliveryCountries(): Observable<Country[]>;
    /**
     * Returns a country based on the provided `isocode`
     * @param isocode an isocode for a country
     */
    getCountry(isocode: string): Observable<Country | null>;
    /**
     * Retrieves regions for specified country by `countryIsoCode`
     * @param countryIsoCode
     */
    loadRegions(countryIsoCode: string): void;
    /**
     * Clear regions in store - useful when changing country
     */
    clearRegions(): void;
    /**
     * Returns all regions
     */
    getRegions(countryIsoCode: string): Observable<Region[]>;
    /**
     * Returns cities for the given region
     * @param regionIsocode a region ISO code
     */
    getCities(regionIsocode: string): Observable<City[]>;
    /**
     * Retrieves cities for the given region
     * @param regionIsocode a region ISO code
     */
    loadCities(regionIsocode: string): void;
    /**
     * Clears cities in store
     */
    clearCities(): void;
    /**
     * Returns districts for the given city
     * @param cityIsocode a city ISO code
     */
    getDistricts(cityIsocode: string): Observable<CityDistrict[]>;
    /**
     * Retrieves districts for the given city
     * @param cityIsocode a city ISO code
     */
    loadDistricts(cityIsocode: string): void;
    /**
     * Clears districts in store
     */
    clearDistricts(): void;
    /**
     * Verifies the address
     * @param address : the address to be verified
     */
    verifyAddress(address: Address): Observable<AddressValidation>;
    protected userAddressVerificationCommand: Command<{
        address: Address;
    }, AddressValidation>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAddressService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserAddressService>;
}

declare class UserCostCenterService {
    protected store: Store<StateWithUser>;
    protected userIdService: UserIdService;
    constructor(store: Store<StateWithUser>, userIdService: UserIdService);
    /**
     * Load all visible active cost centers for the currently login user
     */
    loadActiveCostCenters(): void;
    private getCostCentersState;
    /**
     * Get all visible active cost centers
     */
    getActiveCostCenters(): Observable<CostCenter[]>;
    /**
     * Get the addresses of the cost center's unit based on cost center id
     * @param costCenterId cost center id
     */
    getCostCenterAddresses(costCenterId: string): Observable<Address[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserCostCenterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserCostCenterService>;
}

declare class UserInterestsService {
    protected store: Store<StateWithUser | StateWithProcess<void>>;
    protected userIdService: UserIdService;
    constructor(store: Store<StateWithUser | StateWithProcess<void>>, userIdService: UserIdService);
    /**
     * Retrieves an product interest list
     * @param pageSize page size
     * @param currentPage current page
     * @param sort sort
     */
    loadProductInterests(pageSize?: number, currentPage?: number, sort?: string, productCode?: string, notificationType?: NotificationType): void;
    /**
     * Returns product interests
     */
    getProductInterests(): Observable<ProductInterestSearchResult>;
    /**
     * Returns product interests
     * @param pageSize the page size
     */
    getAndLoadProductInterests(pageSize?: number): Observable<ProductInterestSearchResult>;
    /**
     * Returns a loading flag for product interests
     */
    getProdutInterestsLoading(): Observable<boolean>;
    /**
     * Removes a ProductInterestRelation
     * @param item product interest relation item
     * @param singleDelete flag to delete only one interest
     */
    removeProdutInterest(item: ProductInterestEntryRelation, singleDelete?: boolean): void;
    /**
     * Returns a loading flag for removing product interests.
     */
    getRemoveProdutInterestLoading(): Observable<boolean>;
    /**
     * Returns a success flag for removing a product interests.
     */
    getRemoveProdutInterestSuccess(): Observable<boolean>;
    /**
     * Add a new product interest.
     *
     * @param productCode the product code
     * @param notificationType the notification type
     */
    addProductInterest(productCode: string, notificationType: NotificationType): void;
    /**
     * Returns a success flag for adding a product interest.
     */
    getAddProductInterestSuccess(): Observable<boolean>;
    /**
     * Returns a error flag for adding a product interest.
     */
    getAddProductInterestError(): Observable<boolean>;
    /**
     * Reset product interest adding state.
     */
    resetAddInterestState(): void;
    /**
     * Reset product interest removing state.
     */
    resetRemoveInterestState(): void;
    /**
     * Clears product interests
     */
    clearProductInterests(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserInterestsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserInterestsService>;
}

declare class UserNotificationPreferenceService {
    protected store: Store<StateWithUser | StateWithProcess<void>>;
    protected userIdService: UserIdService;
    constructor(store: Store<StateWithUser | StateWithProcess<void>>, userIdService: UserIdService);
    /**
     * Returns all notification preferences.
     */
    getPreferences(): Observable<NotificationPreference[]>;
    /**
     * Returns all enabled notification preferences.
     */
    getEnabledPreferences(): Observable<NotificationPreference[]>;
    /**
     * Loads all notification preferences.
     */
    loadPreferences(): void;
    /**
     * Clear all notification preferences.
     */
    clearPreferences(): void;
    /**
     * Returns a loading flag for notification preferences.
     */
    getPreferencesLoading(): Observable<boolean>;
    /**
     * Updating notification preferences.
     * @param preferences a preference list
     */
    updatePreferences(preferences: NotificationPreference[]): void;
    /**
     * Returns a loading flag for updating preferences.
     */
    getUpdatePreferencesResultLoading(): Observable<boolean>;
    /**
     * Resets the update notification preferences process state. The state needs to be
     * reset after the process concludes, regardless if it's a success or an error.
     */
    resetNotificationPreferences(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserNotificationPreferenceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserNotificationPreferenceService>;
}

declare class UserPaymentService {
    protected store: Store<StateWithUser>;
    protected userIdService: UserIdService;
    constructor(store: Store<StateWithUser>, userIdService: UserIdService);
    /**
     * Loads all user's payment methods.
     */
    loadPaymentMethods(): void;
    /**
     * Returns all user's payment methods
     */
    getPaymentMethods(): Observable<PaymentDetails[]>;
    /**
     * Returns a loading flag for payment methods
     */
    getPaymentMethodsLoading(): Observable<boolean>;
    getPaymentMethodsLoadedSuccess(): Observable<boolean>;
    /**
     * Sets the payment as a default one
     * @param paymentMethodId a payment method ID
     */
    setPaymentMethodAsDefault(paymentMethodId: string): void;
    /**
     * Deletes the payment method
     *
     * @param paymentMethodId a payment method ID
     */
    deletePaymentMethod(paymentMethodId: string): void;
    /**
     * Returns all billing countries
     */
    getAllBillingCountries(): Observable<Country[]>;
    /**
     * Retrieves billing countries
     */
    loadBillingCountries(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserPaymentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserPaymentService>;
}

declare const LOAD_BILLING_COUNTRIES = "[User] Load Billing Countries";
declare const LOAD_BILLING_COUNTRIES_FAIL = "[User] Load Billing Countries Fail";
declare const LOAD_BILLING_COUNTRIES_SUCCESS = "[User] Load Billing Countries Success";
declare class LoadBillingCountries implements Action {
    readonly type = "[User] Load Billing Countries";
    constructor();
}
declare class LoadBillingCountriesFail implements ErrorAction {
    payload: any;
    readonly type = "[User] Load Billing Countries Fail";
    error: any;
    constructor(payload: any);
}
declare class LoadBillingCountriesSuccess implements Action {
    payload: any;
    readonly type = "[User] Load Billing Countries Success";
    constructor(payload: any);
}
type BillingCountriesAction = LoadBillingCountries | LoadBillingCountriesFail | LoadBillingCountriesSuccess;

declare const LOAD_CITIES = "[User] Load Cities";
declare const LOAD_CITIES_SUCCESS = "[User] Load Cities Success";
declare const LOAD_CITIES_FAIL = "[User] Load Cities Fail";
declare const CLEAR_CITIES = "[User] Clear Cities";
declare class LoadCities extends LoaderLoadAction {
    payload: string;
    readonly type = "[User] Load Cities";
    constructor(payload: string);
}
declare class LoadCitiesFail extends LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Load Cities Fail";
    constructor(payload: any);
}
declare class LoadCitiesSuccess extends LoaderSuccessAction {
    payload: {
        entities: City[];
        regionIsocode: string;
    };
    readonly type = "[User] Load Cities Success";
    constructor(payload: {
        entities: City[];
        regionIsocode: string;
    });
}
declare class ClearCities implements Action {
    readonly type = "[User] Clear Cities";
}
type CitiesAction = LoadCities | LoadCitiesFail | LoadCitiesSuccess | ClearCities;

declare const LOAD_CUSTOMER_COUPONS = "[User] Load Customer Coupons";
declare const LOAD_CUSTOMER_COUPONS_FAIL = "[User] Load Customer Coupons Fail";
declare const LOAD_CUSTOMER_COUPONS_SUCCESS = "[User] Load Customer Coupons Success";
declare const RESET_LOAD_CUSTOMER_COUPONS = "[User] Reset Load Customer Coupons";
declare const SUBSCRIBE_CUSTOMER_COUPON = "[User] Subscribe Customer Notification Coupon";
declare const SUBSCRIBE_CUSTOMER_COUPON_FAIL = "[User] Subscribe Customer Coupon Notification Fail";
declare const SUBSCRIBE_CUSTOMER_COUPON_SUCCESS = "[User] Subscribe Customer Coupon Notification Success";
declare const RESET_SUBSCRIBE_CUSTOMER_COUPON_PROCESS = "[User] Reset Subscribe Customer Coupon Process";
declare const UNSUBSCRIBE_CUSTOMER_COUPON = "[User] Unsubscribe Customer Notification Coupon";
declare const UNSUBSCRIBE_CUSTOMER_COUPON_FAIL = "[User] Unsubscribe Customer Coupon Notification Fail";
declare const UNSUBSCRIBE_CUSTOMER_COUPON_SUCCESS = "[User] Unsubscribe Customer Coupon Notification Success";
declare const RESET_UNSUBSCRIBE_CUSTOMER_COUPON_PROCESS = "[User] Reset Unsubscribe Customer Coupon Process";
declare const CLAIM_CUSTOMER_COUPON = "[User] Claim Customer";
declare const CLAIM_CUSTOMER_COUPON_FAIL = "[User] Claim Customer Fail";
declare const CLAIM_CUSTOMER_COUPON_SUCCESS = "[User] Claim Customer Success";
declare const DISCLAIM_CUSTOMER_COUPON = "[User] Disclaim Customer";
declare const DISCLAIM_CUSTOMER_COUPON_FAIL = "[User] Disclaim Customer Fail";
declare const DISCLAIM_CUSTOMER_COUPON_SUCCESS = "[User] Disclaim Customer Success";
declare const RESET_DISCLAIM_CUSTOMER_COUPON = "[User] Reset Disclaim Customer";
declare class LoadCustomerCoupons extends LoaderLoadAction {
    payload: {
        userId: string;
        pageSize: number;
        currentPage?: number;
        sort?: string;
    };
    readonly type = "[User] Load Customer Coupons";
    constructor(payload: {
        userId: string;
        pageSize: number;
        currentPage?: number;
        sort?: string;
    });
}
declare class LoadCustomerCouponsFail extends LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Load Customer Coupons Fail";
    constructor(payload: any);
}
declare class LoadCustomerCouponsSuccess extends LoaderSuccessAction {
    payload: CustomerCouponSearchResult;
    readonly type = "[User] Load Customer Coupons Success";
    constructor(payload: CustomerCouponSearchResult);
}
declare class ResetLoadCustomerCoupons extends LoaderResetAction {
    readonly type = "[User] Reset Load Customer Coupons";
    constructor();
}
declare class SubscribeCustomerCoupon extends EntityLoadAction {
    payload: {
        userId: string;
        couponCode: string;
    };
    readonly type = "[User] Subscribe Customer Notification Coupon";
    constructor(payload: {
        userId: string;
        couponCode: string;
    });
}
declare class SubscribeCustomerCouponFail extends EntityFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Subscribe Customer Coupon Notification Fail";
    constructor(payload: any);
}
declare class SubscribeCustomerCouponSuccess extends EntitySuccessAction {
    payload: CustomerCouponNotification;
    readonly type = "[User] Subscribe Customer Coupon Notification Success";
    constructor(payload: CustomerCouponNotification);
}
declare class ResetSubscribeCustomerCouponProcess extends EntityLoaderResetAction {
    readonly type = "[User] Reset Subscribe Customer Coupon Process";
    constructor();
}
declare class UnsubscribeCustomerCoupon extends EntityLoadAction {
    payload: {
        userId: string;
        couponCode: string;
    };
    readonly type = "[User] Unsubscribe Customer Notification Coupon";
    constructor(payload: {
        userId: string;
        couponCode: string;
    });
}
declare class UnsubscribeCustomerCouponFail extends EntityFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Unsubscribe Customer Coupon Notification Fail";
    constructor(payload: any);
}
declare class UnsubscribeCustomerCouponSuccess extends EntitySuccessAction {
    payload: any;
    readonly type = "[User] Unsubscribe Customer Coupon Notification Success";
    constructor(payload: any);
}
declare class ResetUnsubscribeCustomerCouponProcess extends EntityLoaderResetAction {
    readonly type = "[User] Reset Unsubscribe Customer Coupon Process";
    constructor();
}
declare class ClaimCustomerCoupon extends EntityLoadAction {
    payload: {
        userId: string;
        couponCode: string;
    };
    readonly type = "[User] Claim Customer";
    constructor(payload: {
        userId: string;
        couponCode: string;
    });
}
declare class DisclaimCustomerCoupon extends EntityLoadAction {
    payload: {
        userId: string;
        couponCode: string;
    };
    readonly type = "[User] Disclaim Customer";
    constructor(payload: {
        userId: string;
        couponCode: string;
    });
}
declare class ResetDisclaimCustomerCoupon extends EntityLoaderResetAction {
    readonly type = "[User] Reset Disclaim Customer";
    constructor();
}
declare class DisclaimCustomerCouponFail extends EntityFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Disclaim Customer Fail";
    constructor(payload: any);
}
declare class DisclaimCustomerCouponSuccess extends EntitySuccessAction {
    payload: CustomerCoupon2Customer;
    readonly type = "[User] Disclaim Customer Success";
    constructor(payload: CustomerCoupon2Customer);
}
declare class ClaimCustomerCouponFail extends EntityFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Claim Customer Fail";
    constructor(payload: any);
}
declare class ClaimCustomerCouponSuccess extends EntitySuccessAction {
    payload: CustomerCoupon2Customer;
    readonly type = "[User] Claim Customer Success";
    constructor(payload: CustomerCoupon2Customer);
}
type CustomerCouponAction = LoadCustomerCoupons | LoadCustomerCouponsFail | LoadCustomerCouponsSuccess | ResetLoadCustomerCoupons | SubscribeCustomerCoupon | SubscribeCustomerCouponFail | SubscribeCustomerCouponSuccess | ResetSubscribeCustomerCouponProcess | UnsubscribeCustomerCoupon | UnsubscribeCustomerCouponFail | UnsubscribeCustomerCouponSuccess | ResetUnsubscribeCustomerCouponProcess | ClaimCustomerCoupon | ClaimCustomerCouponFail | ClaimCustomerCouponSuccess | DisclaimCustomerCoupon | DisclaimCustomerCouponFail | DisclaimCustomerCouponSuccess | ResetDisclaimCustomerCoupon;

declare const LOAD_DELIVERY_COUNTRIES = "[User] Load Delivery Countries";
declare const LOAD_DELIVERY_COUNTRIES_FAIL = "[User] Load Delivery Countries Fail";
declare const LOAD_DELIVERY_COUNTRIES_SUCCESS = "[User] Load Delivery Countries Success";
declare class LoadDeliveryCountries implements Action {
    readonly type = "[User] Load Delivery Countries";
    constructor();
}
declare class LoadDeliveryCountriesFail implements ErrorAction {
    payload: any;
    error: any;
    readonly type = "[User] Load Delivery Countries Fail";
    constructor(payload: any);
}
declare class LoadDeliveryCountriesSuccess implements Action {
    payload: Country[];
    readonly type = "[User] Load Delivery Countries Success";
    constructor(payload: Country[]);
}
type DeliveryCountriesAction = LoadDeliveryCountries | LoadDeliveryCountriesFail | LoadDeliveryCountriesSuccess;

declare const LOAD_DISTRICTS = "[User] Load Districts";
declare const LOAD_DISTRICTS_SUCCESS = "[User] Load Districts Success";
declare const LOAD_DISTRICTS_FAIL = "[User] Load Districts Fail";
declare const CLEAR_DISTRICTS = "[User] Clear Districts";
declare class LoadDistricts extends LoaderLoadAction {
    payload: string;
    readonly type = "[User] Load Districts";
    constructor(payload: string);
}
declare class LoadDistrictsFail extends LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Load Districts Fail";
    constructor(payload: any);
}
declare class LoadDistrictsSuccess extends LoaderSuccessAction {
    payload: {
        entities: CityDistrict[];
        cityIsocode: string;
    };
    readonly type = "[User] Load Districts Success";
    constructor(payload: {
        entities: CityDistrict[];
        cityIsocode: string;
    });
}
declare class ClearDistricts implements Action {
    readonly type = "[User] Clear Districts";
}
type DistrictsAction = LoadDistricts | LoadDistrictsFail | LoadDistrictsSuccess | ClearDistricts;

declare const LOAD_NOTIFICATION_PREFERENCES = "[User] Load Notification Preferences";
declare const LOAD_NOTIFICATION_PREFERENCES_FAIL = "[User] Load Notification Preferences Fail";
declare const LOAD_NOTIFICATION_PREFERENCES_SUCCESS = "[User] Load Notification Preferences Success";
declare const UPDATE_NOTIFICATION_PREFERENCES = "[User] Update Notification Preferences";
declare const UPDATE_NOTIFICATION_PREFERENCES_FAIL = "[User] Update Notification Preferences Fail";
declare const UPDATE_NOTIFICATION_PREFERENCES_SUCCESS = "[User] Update Notification Preferences Success";
declare const RESET_NOTIFICATION_PREFERENCES = "[User] Reset Notification Preferences";
declare const CLEAR_NOTIFICATION_PREFERENCES = "[User] Clear Notification Preferences";
declare class LoadNotificationPreferences extends LoaderLoadAction {
    payload: string;
    readonly type = "[User] Load Notification Preferences";
    constructor(payload: string);
}
declare class LoadNotificationPreferencesFail extends LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Load Notification Preferences Fail";
    constructor(payload: any);
}
declare class LoadNotificationPreferencesSuccess extends LoaderSuccessAction {
    payload: NotificationPreference[];
    readonly type = "[User] Load Notification Preferences Success";
    constructor(payload: NotificationPreference[]);
}
declare class UpdateNotificationPreferences extends EntityLoadAction {
    payload: {
        userId: string;
        preferences: NotificationPreference[];
    };
    readonly type = "[User] Update Notification Preferences";
    constructor(payload: {
        userId: string;
        preferences: NotificationPreference[];
    });
}
declare class UpdateNotificationPreferencesFail extends EntityFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Update Notification Preferences Fail";
    constructor(payload: any);
}
declare class UpdateNotificationPreferencesSuccess extends EntitySuccessAction {
    payload: NotificationPreference[];
    readonly type = "[User] Update Notification Preferences Success";
    constructor(payload: NotificationPreference[]);
}
declare class ResetNotificationPreferences extends EntityLoaderResetAction {
    readonly type = "[User] Reset Notification Preferences";
    constructor();
}
declare class ClearNotificationPreferences extends LoaderResetAction {
    readonly type = "[User] Clear Notification Preferences";
    constructor();
}
type NotificationPreferenceAction = LoadNotificationPreferences | LoadNotificationPreferencesFail | LoadNotificationPreferencesSuccess | UpdateNotificationPreferences | UpdateNotificationPreferencesFail | UpdateNotificationPreferencesSuccess | ResetNotificationPreferences | ClearNotificationPreferences;

declare const LOAD_USER_PAYMENT_METHODS = "[User] Load User Payment Methods";
declare const LOAD_USER_PAYMENT_METHODS_FAIL = "[User] Load User Payment Methods Fail";
declare const LOAD_USER_PAYMENT_METHODS_SUCCESS = "[User] Load User Payment Methods Success";
declare const SET_DEFAULT_USER_PAYMENT_METHOD = "[User] Set Default User Payment Method";
declare const SET_DEFAULT_USER_PAYMENT_METHOD_FAIL = "[User] Set Default User Payment Method Fail";
declare const SET_DEFAULT_USER_PAYMENT_METHOD_SUCCESS = "[User] Set Default User Payment Method Success";
declare const DELETE_USER_PAYMENT_METHOD = "[User] Delete User Payment Method";
declare const DELETE_USER_PAYMENT_METHOD_FAIL = "[User] Delete User Payment Method Fail";
declare const DELETE_USER_PAYMENT_METHOD_SUCCESS = "[User] Delete User  Payment Method Success";
declare class LoadUserPaymentMethods extends LoaderLoadAction {
    payload: string;
    readonly type = "[User] Load User Payment Methods";
    constructor(payload: string);
}
declare class LoadUserPaymentMethodsFail extends LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Load User Payment Methods Fail";
    constructor(payload: any);
}
declare class LoadUserPaymentMethodsSuccess extends LoaderSuccessAction {
    payload: PaymentDetails[];
    readonly type = "[User] Load User Payment Methods Success";
    constructor(payload: PaymentDetails[]);
}
declare class SetDefaultUserPaymentMethod extends LoaderLoadAction {
    payload: any;
    readonly type = "[User] Set Default User Payment Method";
    constructor(payload: any);
}
declare class SetDefaultUserPaymentMethodFail extends LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Set Default User Payment Method Fail";
    constructor(payload: any);
}
declare class SetDefaultUserPaymentMethodSuccess extends LoaderSuccessAction {
    payload: any;
    readonly type = "[User] Set Default User Payment Method Success";
    constructor(payload: any);
}
declare class DeleteUserPaymentMethod extends LoaderLoadAction {
    payload: any;
    readonly type = "[User] Delete User Payment Method";
    constructor(payload: any);
}
declare class DeleteUserPaymentMethodFail extends LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Delete User Payment Method Fail";
    constructor(payload: any);
}
declare class DeleteUserPaymentMethodSuccess extends LoaderSuccessAction {
    payload: any;
    readonly type = "[User] Delete User  Payment Method Success";
    constructor(payload: any);
}
type UserPaymentMethodsAction = LoadUserPaymentMethods | LoadUserPaymentMethodsFail | LoadUserPaymentMethodsSuccess | SetDefaultUserPaymentMethod | SetDefaultUserPaymentMethodFail | SetDefaultUserPaymentMethodSuccess | DeleteUserPaymentMethod | DeleteUserPaymentMethodFail | DeleteUserPaymentMethodSuccess;

declare const LOAD_PRODUCT_INTERESTS = "Load Product Interests";
declare const LOAD_PRODUCT_INTERESTS_FAIL = "Load Product Interests Fail";
declare const LOAD_PRODUCT_INTERESTS_SUCCESS = "Load Product Interests Success";
declare const REMOVE_PRODUCT_INTEREST = "Remove Product Interest";
declare const REMOVE_PRODUCT_INTEREST_SUCCESS = "Remove Product Interest Success";
declare const REMOVE_PRODUCT_INTEREST_FAIL = "Remove Product Interest Fail";
declare const ADD_PRODUCT_INTEREST = "Add Product Interest";
declare const ADD_PRODUCT_INTEREST_FAIL = "Add Product Interest Fail";
declare const ADD_PRODUCT_INTEREST_SUCCESS = "Add Product Interest Success";
declare const ADD_PRODUCT_INTEREST_RESET = "Add Product Interest Reset";
declare const REMOVE_PRODUCT_INTEREST_RESET = "Remove Product Interest Reset";
declare const CLEAR_PRODUCT_INTERESTS = "Clear Product Interests";
declare class LoadProductInterests extends LoaderLoadAction {
    payload: {
        userId: string;
        pageSize?: number;
        currentPage?: number;
        sort?: string;
        productCode?: string;
        notificationType?: NotificationType;
    };
    readonly type = "Load Product Interests";
    constructor(payload: {
        userId: string;
        pageSize?: number;
        currentPage?: number;
        sort?: string;
        productCode?: string;
        notificationType?: NotificationType;
    });
}
declare class LoadProductInterestsFail extends LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "Load Product Interests Fail";
    constructor(payload: any);
}
declare class LoadProductInterestsSuccess extends LoaderSuccessAction {
    payload: ProductInterestSearchResult;
    readonly type = "Load Product Interests Success";
    constructor(payload: ProductInterestSearchResult);
}
declare class RemoveProductInterest extends EntityLoadAction {
    payload: {
        userId: string;
        item: ProductInterestEntryRelation;
        singleDelete?: boolean;
    };
    readonly type = "Remove Product Interest";
    constructor(payload: {
        userId: string;
        item: ProductInterestEntryRelation;
        singleDelete?: boolean;
    });
}
declare class RemoveProductInterestSuccess extends EntitySuccessAction {
    payload: any;
    readonly type = "Remove Product Interest Success";
    constructor(payload: any);
}
declare class RemoveProductInterestFail extends EntityFailAction implements ErrorAction {
    payload: any;
    readonly type = "Remove Product Interest Fail";
    constructor(payload: any);
}
declare class AddProductInterest extends EntityLoadAction {
    payload: {
        userId: string;
        productCode: string;
        notificationType: NotificationType;
    };
    readonly type = "Add Product Interest";
    constructor(payload: {
        userId: string;
        productCode: string;
        notificationType: NotificationType;
    });
}
declare class AddProductInterestSuccess extends EntitySuccessAction {
    payload: any;
    readonly type = "Add Product Interest Success";
    constructor(payload: any);
}
declare class AddProductInterestFail extends EntityFailAction implements ErrorAction {
    payload: any;
    readonly type = "Add Product Interest Fail";
    constructor(payload: any);
}
declare class ResetAddInterestState extends EntityLoaderResetAction {
    readonly type = "Add Product Interest Reset";
    constructor();
}
declare class ResetRemoveInterestState extends EntityLoaderResetAction {
    readonly type = "Remove Product Interest Reset";
    constructor();
}
declare class ClearProductInterests extends LoaderResetAction {
    readonly type = "Clear Product Interests";
    constructor();
}
type ProductInterestsAction = LoadProductInterests | LoadProductInterestsFail | LoadProductInterestsSuccess | RemoveProductInterest | RemoveProductInterestSuccess | RemoveProductInterestFail | AddProductInterest | AddProductInterestFail | AddProductInterestSuccess | ResetAddInterestState | ResetRemoveInterestState | ClearProductInterests;

declare const LOAD_REGIONS = "[User] Load Regions";
declare const LOAD_REGIONS_SUCCESS = "[User] Load Regions Success";
declare const LOAD_REGIONS_FAIL = "[User] Load Regions Fail";
declare const CLEAR_REGIONS = "[User] Clear Regions";
declare class LoadRegions extends LoaderLoadAction {
    payload: string;
    readonly type = "[User] Load Regions";
    constructor(payload: string);
}
declare class LoadRegionsFail extends LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Load Regions Fail";
    constructor(payload: any);
}
declare class LoadRegionsSuccess extends LoaderSuccessAction {
    payload: {
        entities: Region[];
        country: string;
    };
    readonly type = "[User] Load Regions Success";
    constructor(payload: {
        entities: Region[];
        country: string;
    });
}
declare class ClearRegions implements Action {
    readonly type = "[User] Clear Regions";
    constructor();
}
type RegionsAction = LoadRegions | LoadRegionsFail | LoadRegionsSuccess | ClearRegions;

declare const LOAD_USER_ADDRESSES = "[User] Load User Addresses";
declare const LOAD_USER_ADDRESSES_FAIL = "[User] Load User Addresses Fail";
declare const LOAD_USER_ADDRESSES_SUCCESS = "[User] Load User Addresses Success";
declare const ADD_USER_ADDRESS = "[User] Add User Address";
declare const ADD_USER_ADDRESS_FAIL = "[User] Add User Address Fail";
declare const ADD_USER_ADDRESS_SUCCESS = "[User] Add User Address Success";
declare const UPDATE_USER_ADDRESS = "[User] Update User Address";
declare const UPDATE_USER_ADDRESS_FAIL = "[User] Update User Address Fail";
declare const UPDATE_USER_ADDRESS_SUCCESS = "[User] Update User Address Success";
declare const DELETE_USER_ADDRESS = "[User] Delete User Address";
declare const DELETE_USER_ADDRESS_FAIL = "[User] Delete User Address Fail";
declare const DELETE_USER_ADDRESS_SUCCESS = "[User] Delete User Address Success";
declare class LoadUserAddresses extends LoaderLoadAction {
    payload: string;
    readonly type = "[User] Load User Addresses";
    constructor(payload: string);
}
declare class LoadUserAddressesFail extends LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Load User Addresses Fail";
    constructor(payload: any);
}
declare class LoadUserAddressesSuccess extends LoaderSuccessAction {
    payload: Address[];
    readonly type = "[User] Load User Addresses Success";
    constructor(payload: Address[]);
}
declare class AddUserAddress extends LoaderLoadAction {
    payload: {
        userId: string;
        address: Address;
    };
    readonly type = "[User] Add User Address";
    constructor(payload: {
        userId: string;
        address: Address;
    });
}
declare class AddUserAddressFail extends LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Add User Address Fail";
    constructor(payload: any);
}
declare class AddUserAddressSuccess extends LoaderSuccessAction {
    payload: any;
    readonly type = "[User] Add User Address Success";
    constructor(payload: any);
}
declare class UpdateUserAddress extends LoaderLoadAction {
    payload: {
        userId: string;
        addressId: string;
        address: Address;
    };
    readonly type = "[User] Update User Address";
    constructor(payload: {
        userId: string;
        addressId: string;
        address: Address;
    });
}
declare class UpdateUserAddressFail extends LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Update User Address Fail";
    constructor(payload: any);
}
declare class UpdateUserAddressSuccess extends LoaderSuccessAction {
    payload: any;
    readonly type = "[User] Update User Address Success";
    constructor(payload: any);
}
declare class DeleteUserAddress extends LoaderLoadAction {
    payload: any;
    readonly type = "[User] Delete User Address";
    constructor(payload: any);
}
declare class DeleteUserAddressFail extends LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Delete User Address Fail";
    constructor(payload: any);
}
declare class DeleteUserAddressSuccess extends LoaderSuccessAction {
    payload: any;
    readonly type = "[User] Delete User Address Success";
    constructor(payload: any);
}
type UserAddressesAction = LoadUserAddresses | LoadUserAddressesFail | LoadUserAddressesSuccess | AddUserAddress | AddUserAddressFail | AddUserAddressSuccess | UpdateUserAddress | UpdateUserAddressFail | UpdateUserAddressSuccess | DeleteUserAddress | DeleteUserAddressFail | DeleteUserAddressSuccess;

declare const LOAD_USER_CONSENTS = "[User] Load User Consents";
declare const LOAD_USER_CONSENTS_SUCCESS = "[User] Load User Consents Success";
declare const LOAD_USER_CONSENTS_FAIL = "[User] Load User Consents Fail";
declare const RESET_LOAD_USER_CONSENTS = "[User] Reset Load User Consents";
declare const GIVE_USER_CONSENT = "[User] Give User Consent";
declare const GIVE_USER_CONSENT_FAIL = "[User] Give User Consent Fail";
declare const GIVE_USER_CONSENT_SUCCESS = "[User] Give User Consent Success";
declare const RESET_GIVE_USER_CONSENT_PROCESS = "[User] Reset Give User Consent Process";
declare const TRANSFER_ANONYMOUS_CONSENT = "[User] Transfer Anonymous Consent";
declare const WITHDRAW_USER_CONSENT = "[User] Withdraw User Consent";
declare const WITHDRAW_USER_CONSENT_FAIL = "[User] Withdraw User Consent Fail";
declare const WITHDRAW_USER_CONSENT_SUCCESS = "[User] Withdraw User Consent Success";
declare const RESET_WITHDRAW_USER_CONSENT_PROCESS = "[User] Reset Withdraw User Consent Process";
declare class LoadUserConsents extends LoaderLoadAction {
    payload: string;
    readonly type = "[User] Load User Consents";
    constructor(payload: string);
}
declare class LoadUserConsentsFail extends LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Load User Consents Fail";
    constructor(payload: any);
}
declare class LoadUserConsentsSuccess extends LoaderSuccessAction {
    payload: ConsentTemplate[];
    readonly type = "[User] Load User Consents Success";
    constructor(payload: ConsentTemplate[]);
}
declare class ResetLoadUserConsents extends LoaderResetAction {
    readonly type = "[User] Reset Load User Consents";
    constructor();
}
declare class GiveUserConsent extends EntityLoadAction {
    payload: {
        userId: string;
        consentTemplateId: string | undefined;
        consentTemplateVersion: number | undefined;
    };
    readonly type = "[User] Give User Consent";
    constructor(payload: {
        userId: string;
        consentTemplateId: string | undefined;
        consentTemplateVersion: number | undefined;
    });
}
declare class GiveUserConsentFail extends EntityFailAction implements ErrorAction {
    readonly type = "[User] Give User Consent Fail";
    constructor(payload: any);
}
declare class GiveUserConsentSuccess extends EntitySuccessAction {
    consentTemplate: ConsentTemplate;
    readonly type = "[User] Give User Consent Success";
    constructor(consentTemplate: ConsentTemplate);
}
declare class ResetGiveUserConsentProcess extends EntityLoaderResetAction {
    readonly type = "[User] Reset Give User Consent Process";
    constructor();
}
declare class TransferAnonymousConsent {
    payload: {
        userId: string;
        consentTemplateId: string | undefined;
        consentTemplateVersion: number | undefined;
    };
    readonly type = "[User] Transfer Anonymous Consent";
    constructor(payload: {
        userId: string;
        consentTemplateId: string | undefined;
        consentTemplateVersion: number | undefined;
    });
}
declare class WithdrawUserConsent extends EntityLoadAction {
    payload: {
        userId: string;
        consentCode: string;
        consentId?: string;
    };
    readonly type = "[User] Withdraw User Consent";
    constructor(payload: {
        userId: string;
        consentCode: string;
        consentId?: string;
    });
}
declare class WithdrawUserConsentFail extends EntityFailAction implements ErrorAction {
    readonly type = "[User] Withdraw User Consent Fail";
    constructor(payload: any);
}
declare class WithdrawUserConsentSuccess extends EntitySuccessAction {
    readonly type = "[User] Withdraw User Consent Success";
    constructor();
}
declare class ResetWithdrawUserConsentProcess extends EntityLoaderResetAction {
    readonly type = "[User] Reset Withdraw User Consent Process";
    constructor();
}
type UserConsentsAction = LoadUserConsents | LoadUserConsentsFail | LoadUserConsentsSuccess | ResetLoadUserConsents | GiveUserConsent | GiveUserConsentFail | GiveUserConsentSuccess | ResetGiveUserConsentProcess | WithdrawUserConsent | WithdrawUserConsentFail | WithdrawUserConsentSuccess | ResetWithdrawUserConsentProcess;

declare const LOAD_ACTIVE_COST_CENTERS = "[User] Load Active CostCenters";
declare const LOAD_ACTIVE_COST_CENTERS_FAIL = "[User] Load Active CostCenters Fail";
declare const LOAD_ACTIVE_COST_CENTERS_SUCCESS = "[User] Load Active CostCenters Success";
declare class LoadActiveCostCenters extends LoaderLoadAction {
    payload: string;
    readonly type = "[User] Load Active CostCenters";
    constructor(payload: string);
}
declare class LoadActiveCostCentersFail extends LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[User] Load Active CostCenters Fail";
    constructor(payload: any);
}
declare class LoadActiveCostCentersSuccess extends LoaderSuccessAction {
    payload: CostCenter[];
    readonly type = "[User] Load Active CostCenters Success";
    constructor(payload: CostCenter[]);
}
type UserCostCenterAction = LoadActiveCostCenters | LoadActiveCostCentersFail | LoadActiveCostCentersSuccess;

declare const CLEAR_USER_MISCS_DATA = "[User] Clear User Misc Data";
declare class ClearUserMiscsData implements Action {
    readonly type = "[User] Clear User Misc Data";
}

declare const REGISTER_USER_SUCCESS = "[User] Register User Success";
declare class RegisterUserSuccess extends EntitySuccessAction {
    readonly type = "[User] Register User Success";
    constructor();
}
type UserRegisterOrRemoveAction = RegisterUserSuccess;

declare const userGroup_actions_d_ADD_PRODUCT_INTEREST: typeof ADD_PRODUCT_INTEREST;
declare const userGroup_actions_d_ADD_PRODUCT_INTEREST_FAIL: typeof ADD_PRODUCT_INTEREST_FAIL;
declare const userGroup_actions_d_ADD_PRODUCT_INTEREST_RESET: typeof ADD_PRODUCT_INTEREST_RESET;
declare const userGroup_actions_d_ADD_PRODUCT_INTEREST_SUCCESS: typeof ADD_PRODUCT_INTEREST_SUCCESS;
declare const userGroup_actions_d_ADD_USER_ADDRESS: typeof ADD_USER_ADDRESS;
declare const userGroup_actions_d_ADD_USER_ADDRESS_FAIL: typeof ADD_USER_ADDRESS_FAIL;
declare const userGroup_actions_d_ADD_USER_ADDRESS_SUCCESS: typeof ADD_USER_ADDRESS_SUCCESS;
type userGroup_actions_d_AddProductInterest = AddProductInterest;
declare const userGroup_actions_d_AddProductInterest: typeof AddProductInterest;
type userGroup_actions_d_AddProductInterestFail = AddProductInterestFail;
declare const userGroup_actions_d_AddProductInterestFail: typeof AddProductInterestFail;
type userGroup_actions_d_AddProductInterestSuccess = AddProductInterestSuccess;
declare const userGroup_actions_d_AddProductInterestSuccess: typeof AddProductInterestSuccess;
type userGroup_actions_d_AddUserAddress = AddUserAddress;
declare const userGroup_actions_d_AddUserAddress: typeof AddUserAddress;
type userGroup_actions_d_AddUserAddressFail = AddUserAddressFail;
declare const userGroup_actions_d_AddUserAddressFail: typeof AddUserAddressFail;
type userGroup_actions_d_AddUserAddressSuccess = AddUserAddressSuccess;
declare const userGroup_actions_d_AddUserAddressSuccess: typeof AddUserAddressSuccess;
type userGroup_actions_d_BillingCountriesAction = BillingCountriesAction;
declare const userGroup_actions_d_CLAIM_CUSTOMER_COUPON: typeof CLAIM_CUSTOMER_COUPON;
declare const userGroup_actions_d_CLAIM_CUSTOMER_COUPON_FAIL: typeof CLAIM_CUSTOMER_COUPON_FAIL;
declare const userGroup_actions_d_CLAIM_CUSTOMER_COUPON_SUCCESS: typeof CLAIM_CUSTOMER_COUPON_SUCCESS;
declare const userGroup_actions_d_CLEAR_CITIES: typeof CLEAR_CITIES;
declare const userGroup_actions_d_CLEAR_DISTRICTS: typeof CLEAR_DISTRICTS;
declare const userGroup_actions_d_CLEAR_NOTIFICATION_PREFERENCES: typeof CLEAR_NOTIFICATION_PREFERENCES;
declare const userGroup_actions_d_CLEAR_PRODUCT_INTERESTS: typeof CLEAR_PRODUCT_INTERESTS;
declare const userGroup_actions_d_CLEAR_REGIONS: typeof CLEAR_REGIONS;
declare const userGroup_actions_d_CLEAR_USER_MISCS_DATA: typeof CLEAR_USER_MISCS_DATA;
type userGroup_actions_d_CitiesAction = CitiesAction;
type userGroup_actions_d_ClaimCustomerCoupon = ClaimCustomerCoupon;
declare const userGroup_actions_d_ClaimCustomerCoupon: typeof ClaimCustomerCoupon;
type userGroup_actions_d_ClaimCustomerCouponFail = ClaimCustomerCouponFail;
declare const userGroup_actions_d_ClaimCustomerCouponFail: typeof ClaimCustomerCouponFail;
type userGroup_actions_d_ClaimCustomerCouponSuccess = ClaimCustomerCouponSuccess;
declare const userGroup_actions_d_ClaimCustomerCouponSuccess: typeof ClaimCustomerCouponSuccess;
type userGroup_actions_d_ClearCities = ClearCities;
declare const userGroup_actions_d_ClearCities: typeof ClearCities;
type userGroup_actions_d_ClearDistricts = ClearDistricts;
declare const userGroup_actions_d_ClearDistricts: typeof ClearDistricts;
type userGroup_actions_d_ClearNotificationPreferences = ClearNotificationPreferences;
declare const userGroup_actions_d_ClearNotificationPreferences: typeof ClearNotificationPreferences;
type userGroup_actions_d_ClearProductInterests = ClearProductInterests;
declare const userGroup_actions_d_ClearProductInterests: typeof ClearProductInterests;
type userGroup_actions_d_ClearRegions = ClearRegions;
declare const userGroup_actions_d_ClearRegions: typeof ClearRegions;
type userGroup_actions_d_ClearUserMiscsData = ClearUserMiscsData;
declare const userGroup_actions_d_ClearUserMiscsData: typeof ClearUserMiscsData;
type userGroup_actions_d_CustomerCouponAction = CustomerCouponAction;
declare const userGroup_actions_d_DELETE_USER_ADDRESS: typeof DELETE_USER_ADDRESS;
declare const userGroup_actions_d_DELETE_USER_ADDRESS_FAIL: typeof DELETE_USER_ADDRESS_FAIL;
declare const userGroup_actions_d_DELETE_USER_ADDRESS_SUCCESS: typeof DELETE_USER_ADDRESS_SUCCESS;
declare const userGroup_actions_d_DELETE_USER_PAYMENT_METHOD: typeof DELETE_USER_PAYMENT_METHOD;
declare const userGroup_actions_d_DELETE_USER_PAYMENT_METHOD_FAIL: typeof DELETE_USER_PAYMENT_METHOD_FAIL;
declare const userGroup_actions_d_DELETE_USER_PAYMENT_METHOD_SUCCESS: typeof DELETE_USER_PAYMENT_METHOD_SUCCESS;
declare const userGroup_actions_d_DISCLAIM_CUSTOMER_COUPON: typeof DISCLAIM_CUSTOMER_COUPON;
declare const userGroup_actions_d_DISCLAIM_CUSTOMER_COUPON_FAIL: typeof DISCLAIM_CUSTOMER_COUPON_FAIL;
declare const userGroup_actions_d_DISCLAIM_CUSTOMER_COUPON_SUCCESS: typeof DISCLAIM_CUSTOMER_COUPON_SUCCESS;
type userGroup_actions_d_DeleteUserAddress = DeleteUserAddress;
declare const userGroup_actions_d_DeleteUserAddress: typeof DeleteUserAddress;
type userGroup_actions_d_DeleteUserAddressFail = DeleteUserAddressFail;
declare const userGroup_actions_d_DeleteUserAddressFail: typeof DeleteUserAddressFail;
type userGroup_actions_d_DeleteUserAddressSuccess = DeleteUserAddressSuccess;
declare const userGroup_actions_d_DeleteUserAddressSuccess: typeof DeleteUserAddressSuccess;
type userGroup_actions_d_DeleteUserPaymentMethod = DeleteUserPaymentMethod;
declare const userGroup_actions_d_DeleteUserPaymentMethod: typeof DeleteUserPaymentMethod;
type userGroup_actions_d_DeleteUserPaymentMethodFail = DeleteUserPaymentMethodFail;
declare const userGroup_actions_d_DeleteUserPaymentMethodFail: typeof DeleteUserPaymentMethodFail;
type userGroup_actions_d_DeleteUserPaymentMethodSuccess = DeleteUserPaymentMethodSuccess;
declare const userGroup_actions_d_DeleteUserPaymentMethodSuccess: typeof DeleteUserPaymentMethodSuccess;
type userGroup_actions_d_DeliveryCountriesAction = DeliveryCountriesAction;
type userGroup_actions_d_DisclaimCustomerCoupon = DisclaimCustomerCoupon;
declare const userGroup_actions_d_DisclaimCustomerCoupon: typeof DisclaimCustomerCoupon;
type userGroup_actions_d_DisclaimCustomerCouponFail = DisclaimCustomerCouponFail;
declare const userGroup_actions_d_DisclaimCustomerCouponFail: typeof DisclaimCustomerCouponFail;
type userGroup_actions_d_DisclaimCustomerCouponSuccess = DisclaimCustomerCouponSuccess;
declare const userGroup_actions_d_DisclaimCustomerCouponSuccess: typeof DisclaimCustomerCouponSuccess;
type userGroup_actions_d_DistrictsAction = DistrictsAction;
declare const userGroup_actions_d_GIVE_USER_CONSENT: typeof GIVE_USER_CONSENT;
declare const userGroup_actions_d_GIVE_USER_CONSENT_FAIL: typeof GIVE_USER_CONSENT_FAIL;
declare const userGroup_actions_d_GIVE_USER_CONSENT_SUCCESS: typeof GIVE_USER_CONSENT_SUCCESS;
type userGroup_actions_d_GiveUserConsent = GiveUserConsent;
declare const userGroup_actions_d_GiveUserConsent: typeof GiveUserConsent;
type userGroup_actions_d_GiveUserConsentFail = GiveUserConsentFail;
declare const userGroup_actions_d_GiveUserConsentFail: typeof GiveUserConsentFail;
type userGroup_actions_d_GiveUserConsentSuccess = GiveUserConsentSuccess;
declare const userGroup_actions_d_GiveUserConsentSuccess: typeof GiveUserConsentSuccess;
declare const userGroup_actions_d_LOAD_ACTIVE_COST_CENTERS: typeof LOAD_ACTIVE_COST_CENTERS;
declare const userGroup_actions_d_LOAD_ACTIVE_COST_CENTERS_FAIL: typeof LOAD_ACTIVE_COST_CENTERS_FAIL;
declare const userGroup_actions_d_LOAD_ACTIVE_COST_CENTERS_SUCCESS: typeof LOAD_ACTIVE_COST_CENTERS_SUCCESS;
declare const userGroup_actions_d_LOAD_BILLING_COUNTRIES: typeof LOAD_BILLING_COUNTRIES;
declare const userGroup_actions_d_LOAD_BILLING_COUNTRIES_FAIL: typeof LOAD_BILLING_COUNTRIES_FAIL;
declare const userGroup_actions_d_LOAD_BILLING_COUNTRIES_SUCCESS: typeof LOAD_BILLING_COUNTRIES_SUCCESS;
declare const userGroup_actions_d_LOAD_CITIES: typeof LOAD_CITIES;
declare const userGroup_actions_d_LOAD_CITIES_FAIL: typeof LOAD_CITIES_FAIL;
declare const userGroup_actions_d_LOAD_CITIES_SUCCESS: typeof LOAD_CITIES_SUCCESS;
declare const userGroup_actions_d_LOAD_CUSTOMER_COUPONS: typeof LOAD_CUSTOMER_COUPONS;
declare const userGroup_actions_d_LOAD_CUSTOMER_COUPONS_FAIL: typeof LOAD_CUSTOMER_COUPONS_FAIL;
declare const userGroup_actions_d_LOAD_CUSTOMER_COUPONS_SUCCESS: typeof LOAD_CUSTOMER_COUPONS_SUCCESS;
declare const userGroup_actions_d_LOAD_DELIVERY_COUNTRIES: typeof LOAD_DELIVERY_COUNTRIES;
declare const userGroup_actions_d_LOAD_DELIVERY_COUNTRIES_FAIL: typeof LOAD_DELIVERY_COUNTRIES_FAIL;
declare const userGroup_actions_d_LOAD_DELIVERY_COUNTRIES_SUCCESS: typeof LOAD_DELIVERY_COUNTRIES_SUCCESS;
declare const userGroup_actions_d_LOAD_DISTRICTS: typeof LOAD_DISTRICTS;
declare const userGroup_actions_d_LOAD_DISTRICTS_FAIL: typeof LOAD_DISTRICTS_FAIL;
declare const userGroup_actions_d_LOAD_DISTRICTS_SUCCESS: typeof LOAD_DISTRICTS_SUCCESS;
declare const userGroup_actions_d_LOAD_NOTIFICATION_PREFERENCES: typeof LOAD_NOTIFICATION_PREFERENCES;
declare const userGroup_actions_d_LOAD_NOTIFICATION_PREFERENCES_FAIL: typeof LOAD_NOTIFICATION_PREFERENCES_FAIL;
declare const userGroup_actions_d_LOAD_NOTIFICATION_PREFERENCES_SUCCESS: typeof LOAD_NOTIFICATION_PREFERENCES_SUCCESS;
declare const userGroup_actions_d_LOAD_PRODUCT_INTERESTS: typeof LOAD_PRODUCT_INTERESTS;
declare const userGroup_actions_d_LOAD_PRODUCT_INTERESTS_FAIL: typeof LOAD_PRODUCT_INTERESTS_FAIL;
declare const userGroup_actions_d_LOAD_PRODUCT_INTERESTS_SUCCESS: typeof LOAD_PRODUCT_INTERESTS_SUCCESS;
declare const userGroup_actions_d_LOAD_REGIONS: typeof LOAD_REGIONS;
declare const userGroup_actions_d_LOAD_REGIONS_FAIL: typeof LOAD_REGIONS_FAIL;
declare const userGroup_actions_d_LOAD_REGIONS_SUCCESS: typeof LOAD_REGIONS_SUCCESS;
declare const userGroup_actions_d_LOAD_USER_ADDRESSES: typeof LOAD_USER_ADDRESSES;
declare const userGroup_actions_d_LOAD_USER_ADDRESSES_FAIL: typeof LOAD_USER_ADDRESSES_FAIL;
declare const userGroup_actions_d_LOAD_USER_ADDRESSES_SUCCESS: typeof LOAD_USER_ADDRESSES_SUCCESS;
declare const userGroup_actions_d_LOAD_USER_CONSENTS: typeof LOAD_USER_CONSENTS;
declare const userGroup_actions_d_LOAD_USER_CONSENTS_FAIL: typeof LOAD_USER_CONSENTS_FAIL;
declare const userGroup_actions_d_LOAD_USER_CONSENTS_SUCCESS: typeof LOAD_USER_CONSENTS_SUCCESS;
declare const userGroup_actions_d_LOAD_USER_PAYMENT_METHODS: typeof LOAD_USER_PAYMENT_METHODS;
declare const userGroup_actions_d_LOAD_USER_PAYMENT_METHODS_FAIL: typeof LOAD_USER_PAYMENT_METHODS_FAIL;
declare const userGroup_actions_d_LOAD_USER_PAYMENT_METHODS_SUCCESS: typeof LOAD_USER_PAYMENT_METHODS_SUCCESS;
type userGroup_actions_d_LoadActiveCostCenters = LoadActiveCostCenters;
declare const userGroup_actions_d_LoadActiveCostCenters: typeof LoadActiveCostCenters;
type userGroup_actions_d_LoadActiveCostCentersFail = LoadActiveCostCentersFail;
declare const userGroup_actions_d_LoadActiveCostCentersFail: typeof LoadActiveCostCentersFail;
type userGroup_actions_d_LoadActiveCostCentersSuccess = LoadActiveCostCentersSuccess;
declare const userGroup_actions_d_LoadActiveCostCentersSuccess: typeof LoadActiveCostCentersSuccess;
type userGroup_actions_d_LoadBillingCountries = LoadBillingCountries;
declare const userGroup_actions_d_LoadBillingCountries: typeof LoadBillingCountries;
type userGroup_actions_d_LoadBillingCountriesFail = LoadBillingCountriesFail;
declare const userGroup_actions_d_LoadBillingCountriesFail: typeof LoadBillingCountriesFail;
type userGroup_actions_d_LoadBillingCountriesSuccess = LoadBillingCountriesSuccess;
declare const userGroup_actions_d_LoadBillingCountriesSuccess: typeof LoadBillingCountriesSuccess;
type userGroup_actions_d_LoadCities = LoadCities;
declare const userGroup_actions_d_LoadCities: typeof LoadCities;
type userGroup_actions_d_LoadCitiesFail = LoadCitiesFail;
declare const userGroup_actions_d_LoadCitiesFail: typeof LoadCitiesFail;
type userGroup_actions_d_LoadCitiesSuccess = LoadCitiesSuccess;
declare const userGroup_actions_d_LoadCitiesSuccess: typeof LoadCitiesSuccess;
type userGroup_actions_d_LoadCustomerCoupons = LoadCustomerCoupons;
declare const userGroup_actions_d_LoadCustomerCoupons: typeof LoadCustomerCoupons;
type userGroup_actions_d_LoadCustomerCouponsFail = LoadCustomerCouponsFail;
declare const userGroup_actions_d_LoadCustomerCouponsFail: typeof LoadCustomerCouponsFail;
type userGroup_actions_d_LoadCustomerCouponsSuccess = LoadCustomerCouponsSuccess;
declare const userGroup_actions_d_LoadCustomerCouponsSuccess: typeof LoadCustomerCouponsSuccess;
type userGroup_actions_d_LoadDeliveryCountries = LoadDeliveryCountries;
declare const userGroup_actions_d_LoadDeliveryCountries: typeof LoadDeliveryCountries;
type userGroup_actions_d_LoadDeliveryCountriesFail = LoadDeliveryCountriesFail;
declare const userGroup_actions_d_LoadDeliveryCountriesFail: typeof LoadDeliveryCountriesFail;
type userGroup_actions_d_LoadDeliveryCountriesSuccess = LoadDeliveryCountriesSuccess;
declare const userGroup_actions_d_LoadDeliveryCountriesSuccess: typeof LoadDeliveryCountriesSuccess;
type userGroup_actions_d_LoadDistricts = LoadDistricts;
declare const userGroup_actions_d_LoadDistricts: typeof LoadDistricts;
type userGroup_actions_d_LoadDistrictsFail = LoadDistrictsFail;
declare const userGroup_actions_d_LoadDistrictsFail: typeof LoadDistrictsFail;
type userGroup_actions_d_LoadDistrictsSuccess = LoadDistrictsSuccess;
declare const userGroup_actions_d_LoadDistrictsSuccess: typeof LoadDistrictsSuccess;
type userGroup_actions_d_LoadNotificationPreferences = LoadNotificationPreferences;
declare const userGroup_actions_d_LoadNotificationPreferences: typeof LoadNotificationPreferences;
type userGroup_actions_d_LoadNotificationPreferencesFail = LoadNotificationPreferencesFail;
declare const userGroup_actions_d_LoadNotificationPreferencesFail: typeof LoadNotificationPreferencesFail;
type userGroup_actions_d_LoadNotificationPreferencesSuccess = LoadNotificationPreferencesSuccess;
declare const userGroup_actions_d_LoadNotificationPreferencesSuccess: typeof LoadNotificationPreferencesSuccess;
type userGroup_actions_d_LoadProductInterests = LoadProductInterests;
declare const userGroup_actions_d_LoadProductInterests: typeof LoadProductInterests;
type userGroup_actions_d_LoadProductInterestsFail = LoadProductInterestsFail;
declare const userGroup_actions_d_LoadProductInterestsFail: typeof LoadProductInterestsFail;
type userGroup_actions_d_LoadProductInterestsSuccess = LoadProductInterestsSuccess;
declare const userGroup_actions_d_LoadProductInterestsSuccess: typeof LoadProductInterestsSuccess;
type userGroup_actions_d_LoadRegions = LoadRegions;
declare const userGroup_actions_d_LoadRegions: typeof LoadRegions;
type userGroup_actions_d_LoadRegionsFail = LoadRegionsFail;
declare const userGroup_actions_d_LoadRegionsFail: typeof LoadRegionsFail;
type userGroup_actions_d_LoadRegionsSuccess = LoadRegionsSuccess;
declare const userGroup_actions_d_LoadRegionsSuccess: typeof LoadRegionsSuccess;
type userGroup_actions_d_LoadUserAddresses = LoadUserAddresses;
declare const userGroup_actions_d_LoadUserAddresses: typeof LoadUserAddresses;
type userGroup_actions_d_LoadUserAddressesFail = LoadUserAddressesFail;
declare const userGroup_actions_d_LoadUserAddressesFail: typeof LoadUserAddressesFail;
type userGroup_actions_d_LoadUserAddressesSuccess = LoadUserAddressesSuccess;
declare const userGroup_actions_d_LoadUserAddressesSuccess: typeof LoadUserAddressesSuccess;
type userGroup_actions_d_LoadUserConsents = LoadUserConsents;
declare const userGroup_actions_d_LoadUserConsents: typeof LoadUserConsents;
type userGroup_actions_d_LoadUserConsentsFail = LoadUserConsentsFail;
declare const userGroup_actions_d_LoadUserConsentsFail: typeof LoadUserConsentsFail;
type userGroup_actions_d_LoadUserConsentsSuccess = LoadUserConsentsSuccess;
declare const userGroup_actions_d_LoadUserConsentsSuccess: typeof LoadUserConsentsSuccess;
type userGroup_actions_d_LoadUserPaymentMethods = LoadUserPaymentMethods;
declare const userGroup_actions_d_LoadUserPaymentMethods: typeof LoadUserPaymentMethods;
type userGroup_actions_d_LoadUserPaymentMethodsFail = LoadUserPaymentMethodsFail;
declare const userGroup_actions_d_LoadUserPaymentMethodsFail: typeof LoadUserPaymentMethodsFail;
type userGroup_actions_d_LoadUserPaymentMethodsSuccess = LoadUserPaymentMethodsSuccess;
declare const userGroup_actions_d_LoadUserPaymentMethodsSuccess: typeof LoadUserPaymentMethodsSuccess;
type userGroup_actions_d_NotificationPreferenceAction = NotificationPreferenceAction;
type userGroup_actions_d_ProductInterestsAction = ProductInterestsAction;
declare const userGroup_actions_d_REGISTER_USER_SUCCESS: typeof REGISTER_USER_SUCCESS;
declare const userGroup_actions_d_REMOVE_PRODUCT_INTEREST: typeof REMOVE_PRODUCT_INTEREST;
declare const userGroup_actions_d_REMOVE_PRODUCT_INTEREST_FAIL: typeof REMOVE_PRODUCT_INTEREST_FAIL;
declare const userGroup_actions_d_REMOVE_PRODUCT_INTEREST_RESET: typeof REMOVE_PRODUCT_INTEREST_RESET;
declare const userGroup_actions_d_REMOVE_PRODUCT_INTEREST_SUCCESS: typeof REMOVE_PRODUCT_INTEREST_SUCCESS;
declare const userGroup_actions_d_RESET_DISCLAIM_CUSTOMER_COUPON: typeof RESET_DISCLAIM_CUSTOMER_COUPON;
declare const userGroup_actions_d_RESET_GIVE_USER_CONSENT_PROCESS: typeof RESET_GIVE_USER_CONSENT_PROCESS;
declare const userGroup_actions_d_RESET_LOAD_CUSTOMER_COUPONS: typeof RESET_LOAD_CUSTOMER_COUPONS;
declare const userGroup_actions_d_RESET_LOAD_USER_CONSENTS: typeof RESET_LOAD_USER_CONSENTS;
declare const userGroup_actions_d_RESET_NOTIFICATION_PREFERENCES: typeof RESET_NOTIFICATION_PREFERENCES;
declare const userGroup_actions_d_RESET_SUBSCRIBE_CUSTOMER_COUPON_PROCESS: typeof RESET_SUBSCRIBE_CUSTOMER_COUPON_PROCESS;
declare const userGroup_actions_d_RESET_UNSUBSCRIBE_CUSTOMER_COUPON_PROCESS: typeof RESET_UNSUBSCRIBE_CUSTOMER_COUPON_PROCESS;
declare const userGroup_actions_d_RESET_WITHDRAW_USER_CONSENT_PROCESS: typeof RESET_WITHDRAW_USER_CONSENT_PROCESS;
type userGroup_actions_d_RegionsAction = RegionsAction;
type userGroup_actions_d_RegisterUserSuccess = RegisterUserSuccess;
declare const userGroup_actions_d_RegisterUserSuccess: typeof RegisterUserSuccess;
type userGroup_actions_d_RemoveProductInterest = RemoveProductInterest;
declare const userGroup_actions_d_RemoveProductInterest: typeof RemoveProductInterest;
type userGroup_actions_d_RemoveProductInterestFail = RemoveProductInterestFail;
declare const userGroup_actions_d_RemoveProductInterestFail: typeof RemoveProductInterestFail;
type userGroup_actions_d_RemoveProductInterestSuccess = RemoveProductInterestSuccess;
declare const userGroup_actions_d_RemoveProductInterestSuccess: typeof RemoveProductInterestSuccess;
type userGroup_actions_d_ResetAddInterestState = ResetAddInterestState;
declare const userGroup_actions_d_ResetAddInterestState: typeof ResetAddInterestState;
type userGroup_actions_d_ResetDisclaimCustomerCoupon = ResetDisclaimCustomerCoupon;
declare const userGroup_actions_d_ResetDisclaimCustomerCoupon: typeof ResetDisclaimCustomerCoupon;
type userGroup_actions_d_ResetGiveUserConsentProcess = ResetGiveUserConsentProcess;
declare const userGroup_actions_d_ResetGiveUserConsentProcess: typeof ResetGiveUserConsentProcess;
type userGroup_actions_d_ResetLoadCustomerCoupons = ResetLoadCustomerCoupons;
declare const userGroup_actions_d_ResetLoadCustomerCoupons: typeof ResetLoadCustomerCoupons;
type userGroup_actions_d_ResetLoadUserConsents = ResetLoadUserConsents;
declare const userGroup_actions_d_ResetLoadUserConsents: typeof ResetLoadUserConsents;
type userGroup_actions_d_ResetNotificationPreferences = ResetNotificationPreferences;
declare const userGroup_actions_d_ResetNotificationPreferences: typeof ResetNotificationPreferences;
type userGroup_actions_d_ResetRemoveInterestState = ResetRemoveInterestState;
declare const userGroup_actions_d_ResetRemoveInterestState: typeof ResetRemoveInterestState;
type userGroup_actions_d_ResetSubscribeCustomerCouponProcess = ResetSubscribeCustomerCouponProcess;
declare const userGroup_actions_d_ResetSubscribeCustomerCouponProcess: typeof ResetSubscribeCustomerCouponProcess;
type userGroup_actions_d_ResetUnsubscribeCustomerCouponProcess = ResetUnsubscribeCustomerCouponProcess;
declare const userGroup_actions_d_ResetUnsubscribeCustomerCouponProcess: typeof ResetUnsubscribeCustomerCouponProcess;
type userGroup_actions_d_ResetWithdrawUserConsentProcess = ResetWithdrawUserConsentProcess;
declare const userGroup_actions_d_ResetWithdrawUserConsentProcess: typeof ResetWithdrawUserConsentProcess;
declare const userGroup_actions_d_SET_DEFAULT_USER_PAYMENT_METHOD: typeof SET_DEFAULT_USER_PAYMENT_METHOD;
declare const userGroup_actions_d_SET_DEFAULT_USER_PAYMENT_METHOD_FAIL: typeof SET_DEFAULT_USER_PAYMENT_METHOD_FAIL;
declare const userGroup_actions_d_SET_DEFAULT_USER_PAYMENT_METHOD_SUCCESS: typeof SET_DEFAULT_USER_PAYMENT_METHOD_SUCCESS;
declare const userGroup_actions_d_SUBSCRIBE_CUSTOMER_COUPON: typeof SUBSCRIBE_CUSTOMER_COUPON;
declare const userGroup_actions_d_SUBSCRIBE_CUSTOMER_COUPON_FAIL: typeof SUBSCRIBE_CUSTOMER_COUPON_FAIL;
declare const userGroup_actions_d_SUBSCRIBE_CUSTOMER_COUPON_SUCCESS: typeof SUBSCRIBE_CUSTOMER_COUPON_SUCCESS;
type userGroup_actions_d_SetDefaultUserPaymentMethod = SetDefaultUserPaymentMethod;
declare const userGroup_actions_d_SetDefaultUserPaymentMethod: typeof SetDefaultUserPaymentMethod;
type userGroup_actions_d_SetDefaultUserPaymentMethodFail = SetDefaultUserPaymentMethodFail;
declare const userGroup_actions_d_SetDefaultUserPaymentMethodFail: typeof SetDefaultUserPaymentMethodFail;
type userGroup_actions_d_SetDefaultUserPaymentMethodSuccess = SetDefaultUserPaymentMethodSuccess;
declare const userGroup_actions_d_SetDefaultUserPaymentMethodSuccess: typeof SetDefaultUserPaymentMethodSuccess;
type userGroup_actions_d_SubscribeCustomerCoupon = SubscribeCustomerCoupon;
declare const userGroup_actions_d_SubscribeCustomerCoupon: typeof SubscribeCustomerCoupon;
type userGroup_actions_d_SubscribeCustomerCouponFail = SubscribeCustomerCouponFail;
declare const userGroup_actions_d_SubscribeCustomerCouponFail: typeof SubscribeCustomerCouponFail;
type userGroup_actions_d_SubscribeCustomerCouponSuccess = SubscribeCustomerCouponSuccess;
declare const userGroup_actions_d_SubscribeCustomerCouponSuccess: typeof SubscribeCustomerCouponSuccess;
declare const userGroup_actions_d_TRANSFER_ANONYMOUS_CONSENT: typeof TRANSFER_ANONYMOUS_CONSENT;
type userGroup_actions_d_TransferAnonymousConsent = TransferAnonymousConsent;
declare const userGroup_actions_d_TransferAnonymousConsent: typeof TransferAnonymousConsent;
declare const userGroup_actions_d_UNSUBSCRIBE_CUSTOMER_COUPON: typeof UNSUBSCRIBE_CUSTOMER_COUPON;
declare const userGroup_actions_d_UNSUBSCRIBE_CUSTOMER_COUPON_FAIL: typeof UNSUBSCRIBE_CUSTOMER_COUPON_FAIL;
declare const userGroup_actions_d_UNSUBSCRIBE_CUSTOMER_COUPON_SUCCESS: typeof UNSUBSCRIBE_CUSTOMER_COUPON_SUCCESS;
declare const userGroup_actions_d_UPDATE_NOTIFICATION_PREFERENCES: typeof UPDATE_NOTIFICATION_PREFERENCES;
declare const userGroup_actions_d_UPDATE_NOTIFICATION_PREFERENCES_FAIL: typeof UPDATE_NOTIFICATION_PREFERENCES_FAIL;
declare const userGroup_actions_d_UPDATE_NOTIFICATION_PREFERENCES_SUCCESS: typeof UPDATE_NOTIFICATION_PREFERENCES_SUCCESS;
declare const userGroup_actions_d_UPDATE_USER_ADDRESS: typeof UPDATE_USER_ADDRESS;
declare const userGroup_actions_d_UPDATE_USER_ADDRESS_FAIL: typeof UPDATE_USER_ADDRESS_FAIL;
declare const userGroup_actions_d_UPDATE_USER_ADDRESS_SUCCESS: typeof UPDATE_USER_ADDRESS_SUCCESS;
type userGroup_actions_d_UnsubscribeCustomerCoupon = UnsubscribeCustomerCoupon;
declare const userGroup_actions_d_UnsubscribeCustomerCoupon: typeof UnsubscribeCustomerCoupon;
type userGroup_actions_d_UnsubscribeCustomerCouponFail = UnsubscribeCustomerCouponFail;
declare const userGroup_actions_d_UnsubscribeCustomerCouponFail: typeof UnsubscribeCustomerCouponFail;
type userGroup_actions_d_UnsubscribeCustomerCouponSuccess = UnsubscribeCustomerCouponSuccess;
declare const userGroup_actions_d_UnsubscribeCustomerCouponSuccess: typeof UnsubscribeCustomerCouponSuccess;
type userGroup_actions_d_UpdateNotificationPreferences = UpdateNotificationPreferences;
declare const userGroup_actions_d_UpdateNotificationPreferences: typeof UpdateNotificationPreferences;
type userGroup_actions_d_UpdateNotificationPreferencesFail = UpdateNotificationPreferencesFail;
declare const userGroup_actions_d_UpdateNotificationPreferencesFail: typeof UpdateNotificationPreferencesFail;
type userGroup_actions_d_UpdateNotificationPreferencesSuccess = UpdateNotificationPreferencesSuccess;
declare const userGroup_actions_d_UpdateNotificationPreferencesSuccess: typeof UpdateNotificationPreferencesSuccess;
type userGroup_actions_d_UpdateUserAddress = UpdateUserAddress;
declare const userGroup_actions_d_UpdateUserAddress: typeof UpdateUserAddress;
type userGroup_actions_d_UpdateUserAddressFail = UpdateUserAddressFail;
declare const userGroup_actions_d_UpdateUserAddressFail: typeof UpdateUserAddressFail;
type userGroup_actions_d_UpdateUserAddressSuccess = UpdateUserAddressSuccess;
declare const userGroup_actions_d_UpdateUserAddressSuccess: typeof UpdateUserAddressSuccess;
type userGroup_actions_d_UserAddressesAction = UserAddressesAction;
type userGroup_actions_d_UserConsentsAction = UserConsentsAction;
type userGroup_actions_d_UserCostCenterAction = UserCostCenterAction;
type userGroup_actions_d_UserPaymentMethodsAction = UserPaymentMethodsAction;
type userGroup_actions_d_UserRegisterOrRemoveAction = UserRegisterOrRemoveAction;
declare const userGroup_actions_d_WITHDRAW_USER_CONSENT: typeof WITHDRAW_USER_CONSENT;
declare const userGroup_actions_d_WITHDRAW_USER_CONSENT_FAIL: typeof WITHDRAW_USER_CONSENT_FAIL;
declare const userGroup_actions_d_WITHDRAW_USER_CONSENT_SUCCESS: typeof WITHDRAW_USER_CONSENT_SUCCESS;
type userGroup_actions_d_WithdrawUserConsent = WithdrawUserConsent;
declare const userGroup_actions_d_WithdrawUserConsent: typeof WithdrawUserConsent;
type userGroup_actions_d_WithdrawUserConsentFail = WithdrawUserConsentFail;
declare const userGroup_actions_d_WithdrawUserConsentFail: typeof WithdrawUserConsentFail;
type userGroup_actions_d_WithdrawUserConsentSuccess = WithdrawUserConsentSuccess;
declare const userGroup_actions_d_WithdrawUserConsentSuccess: typeof WithdrawUserConsentSuccess;
declare namespace userGroup_actions_d {
  export { userGroup_actions_d_ADD_PRODUCT_INTEREST as ADD_PRODUCT_INTEREST, userGroup_actions_d_ADD_PRODUCT_INTEREST_FAIL as ADD_PRODUCT_INTEREST_FAIL, userGroup_actions_d_ADD_PRODUCT_INTEREST_RESET as ADD_PRODUCT_INTEREST_RESET, userGroup_actions_d_ADD_PRODUCT_INTEREST_SUCCESS as ADD_PRODUCT_INTEREST_SUCCESS, userGroup_actions_d_ADD_USER_ADDRESS as ADD_USER_ADDRESS, userGroup_actions_d_ADD_USER_ADDRESS_FAIL as ADD_USER_ADDRESS_FAIL, userGroup_actions_d_ADD_USER_ADDRESS_SUCCESS as ADD_USER_ADDRESS_SUCCESS, userGroup_actions_d_AddProductInterest as AddProductInterest, userGroup_actions_d_AddProductInterestFail as AddProductInterestFail, userGroup_actions_d_AddProductInterestSuccess as AddProductInterestSuccess, userGroup_actions_d_AddUserAddress as AddUserAddress, userGroup_actions_d_AddUserAddressFail as AddUserAddressFail, userGroup_actions_d_AddUserAddressSuccess as AddUserAddressSuccess, userGroup_actions_d_CLAIM_CUSTOMER_COUPON as CLAIM_CUSTOMER_COUPON, userGroup_actions_d_CLAIM_CUSTOMER_COUPON_FAIL as CLAIM_CUSTOMER_COUPON_FAIL, userGroup_actions_d_CLAIM_CUSTOMER_COUPON_SUCCESS as CLAIM_CUSTOMER_COUPON_SUCCESS, userGroup_actions_d_CLEAR_CITIES as CLEAR_CITIES, userGroup_actions_d_CLEAR_DISTRICTS as CLEAR_DISTRICTS, userGroup_actions_d_CLEAR_NOTIFICATION_PREFERENCES as CLEAR_NOTIFICATION_PREFERENCES, userGroup_actions_d_CLEAR_PRODUCT_INTERESTS as CLEAR_PRODUCT_INTERESTS, userGroup_actions_d_CLEAR_REGIONS as CLEAR_REGIONS, userGroup_actions_d_CLEAR_USER_MISCS_DATA as CLEAR_USER_MISCS_DATA, userGroup_actions_d_ClaimCustomerCoupon as ClaimCustomerCoupon, userGroup_actions_d_ClaimCustomerCouponFail as ClaimCustomerCouponFail, userGroup_actions_d_ClaimCustomerCouponSuccess as ClaimCustomerCouponSuccess, userGroup_actions_d_ClearCities as ClearCities, userGroup_actions_d_ClearDistricts as ClearDistricts, userGroup_actions_d_ClearNotificationPreferences as ClearNotificationPreferences, userGroup_actions_d_ClearProductInterests as ClearProductInterests, userGroup_actions_d_ClearRegions as ClearRegions, userGroup_actions_d_ClearUserMiscsData as ClearUserMiscsData, userGroup_actions_d_DELETE_USER_ADDRESS as DELETE_USER_ADDRESS, userGroup_actions_d_DELETE_USER_ADDRESS_FAIL as DELETE_USER_ADDRESS_FAIL, userGroup_actions_d_DELETE_USER_ADDRESS_SUCCESS as DELETE_USER_ADDRESS_SUCCESS, userGroup_actions_d_DELETE_USER_PAYMENT_METHOD as DELETE_USER_PAYMENT_METHOD, userGroup_actions_d_DELETE_USER_PAYMENT_METHOD_FAIL as DELETE_USER_PAYMENT_METHOD_FAIL, userGroup_actions_d_DELETE_USER_PAYMENT_METHOD_SUCCESS as DELETE_USER_PAYMENT_METHOD_SUCCESS, userGroup_actions_d_DISCLAIM_CUSTOMER_COUPON as DISCLAIM_CUSTOMER_COUPON, userGroup_actions_d_DISCLAIM_CUSTOMER_COUPON_FAIL as DISCLAIM_CUSTOMER_COUPON_FAIL, userGroup_actions_d_DISCLAIM_CUSTOMER_COUPON_SUCCESS as DISCLAIM_CUSTOMER_COUPON_SUCCESS, userGroup_actions_d_DeleteUserAddress as DeleteUserAddress, userGroup_actions_d_DeleteUserAddressFail as DeleteUserAddressFail, userGroup_actions_d_DeleteUserAddressSuccess as DeleteUserAddressSuccess, userGroup_actions_d_DeleteUserPaymentMethod as DeleteUserPaymentMethod, userGroup_actions_d_DeleteUserPaymentMethodFail as DeleteUserPaymentMethodFail, userGroup_actions_d_DeleteUserPaymentMethodSuccess as DeleteUserPaymentMethodSuccess, userGroup_actions_d_DisclaimCustomerCoupon as DisclaimCustomerCoupon, userGroup_actions_d_DisclaimCustomerCouponFail as DisclaimCustomerCouponFail, userGroup_actions_d_DisclaimCustomerCouponSuccess as DisclaimCustomerCouponSuccess, userGroup_actions_d_GIVE_USER_CONSENT as GIVE_USER_CONSENT, userGroup_actions_d_GIVE_USER_CONSENT_FAIL as GIVE_USER_CONSENT_FAIL, userGroup_actions_d_GIVE_USER_CONSENT_SUCCESS as GIVE_USER_CONSENT_SUCCESS, userGroup_actions_d_GiveUserConsent as GiveUserConsent, userGroup_actions_d_GiveUserConsentFail as GiveUserConsentFail, userGroup_actions_d_GiveUserConsentSuccess as GiveUserConsentSuccess, userGroup_actions_d_LOAD_ACTIVE_COST_CENTERS as LOAD_ACTIVE_COST_CENTERS, userGroup_actions_d_LOAD_ACTIVE_COST_CENTERS_FAIL as LOAD_ACTIVE_COST_CENTERS_FAIL, userGroup_actions_d_LOAD_ACTIVE_COST_CENTERS_SUCCESS as LOAD_ACTIVE_COST_CENTERS_SUCCESS, userGroup_actions_d_LOAD_BILLING_COUNTRIES as LOAD_BILLING_COUNTRIES, userGroup_actions_d_LOAD_BILLING_COUNTRIES_FAIL as LOAD_BILLING_COUNTRIES_FAIL, userGroup_actions_d_LOAD_BILLING_COUNTRIES_SUCCESS as LOAD_BILLING_COUNTRIES_SUCCESS, userGroup_actions_d_LOAD_CITIES as LOAD_CITIES, userGroup_actions_d_LOAD_CITIES_FAIL as LOAD_CITIES_FAIL, userGroup_actions_d_LOAD_CITIES_SUCCESS as LOAD_CITIES_SUCCESS, userGroup_actions_d_LOAD_CUSTOMER_COUPONS as LOAD_CUSTOMER_COUPONS, userGroup_actions_d_LOAD_CUSTOMER_COUPONS_FAIL as LOAD_CUSTOMER_COUPONS_FAIL, userGroup_actions_d_LOAD_CUSTOMER_COUPONS_SUCCESS as LOAD_CUSTOMER_COUPONS_SUCCESS, userGroup_actions_d_LOAD_DELIVERY_COUNTRIES as LOAD_DELIVERY_COUNTRIES, userGroup_actions_d_LOAD_DELIVERY_COUNTRIES_FAIL as LOAD_DELIVERY_COUNTRIES_FAIL, userGroup_actions_d_LOAD_DELIVERY_COUNTRIES_SUCCESS as LOAD_DELIVERY_COUNTRIES_SUCCESS, userGroup_actions_d_LOAD_DISTRICTS as LOAD_DISTRICTS, userGroup_actions_d_LOAD_DISTRICTS_FAIL as LOAD_DISTRICTS_FAIL, userGroup_actions_d_LOAD_DISTRICTS_SUCCESS as LOAD_DISTRICTS_SUCCESS, userGroup_actions_d_LOAD_NOTIFICATION_PREFERENCES as LOAD_NOTIFICATION_PREFERENCES, userGroup_actions_d_LOAD_NOTIFICATION_PREFERENCES_FAIL as LOAD_NOTIFICATION_PREFERENCES_FAIL, userGroup_actions_d_LOAD_NOTIFICATION_PREFERENCES_SUCCESS as LOAD_NOTIFICATION_PREFERENCES_SUCCESS, userGroup_actions_d_LOAD_PRODUCT_INTERESTS as LOAD_PRODUCT_INTERESTS, userGroup_actions_d_LOAD_PRODUCT_INTERESTS_FAIL as LOAD_PRODUCT_INTERESTS_FAIL, userGroup_actions_d_LOAD_PRODUCT_INTERESTS_SUCCESS as LOAD_PRODUCT_INTERESTS_SUCCESS, userGroup_actions_d_LOAD_REGIONS as LOAD_REGIONS, userGroup_actions_d_LOAD_REGIONS_FAIL as LOAD_REGIONS_FAIL, userGroup_actions_d_LOAD_REGIONS_SUCCESS as LOAD_REGIONS_SUCCESS, userGroup_actions_d_LOAD_USER_ADDRESSES as LOAD_USER_ADDRESSES, userGroup_actions_d_LOAD_USER_ADDRESSES_FAIL as LOAD_USER_ADDRESSES_FAIL, userGroup_actions_d_LOAD_USER_ADDRESSES_SUCCESS as LOAD_USER_ADDRESSES_SUCCESS, userGroup_actions_d_LOAD_USER_CONSENTS as LOAD_USER_CONSENTS, userGroup_actions_d_LOAD_USER_CONSENTS_FAIL as LOAD_USER_CONSENTS_FAIL, userGroup_actions_d_LOAD_USER_CONSENTS_SUCCESS as LOAD_USER_CONSENTS_SUCCESS, userGroup_actions_d_LOAD_USER_PAYMENT_METHODS as LOAD_USER_PAYMENT_METHODS, userGroup_actions_d_LOAD_USER_PAYMENT_METHODS_FAIL as LOAD_USER_PAYMENT_METHODS_FAIL, userGroup_actions_d_LOAD_USER_PAYMENT_METHODS_SUCCESS as LOAD_USER_PAYMENT_METHODS_SUCCESS, userGroup_actions_d_LoadActiveCostCenters as LoadActiveCostCenters, userGroup_actions_d_LoadActiveCostCentersFail as LoadActiveCostCentersFail, userGroup_actions_d_LoadActiveCostCentersSuccess as LoadActiveCostCentersSuccess, userGroup_actions_d_LoadBillingCountries as LoadBillingCountries, userGroup_actions_d_LoadBillingCountriesFail as LoadBillingCountriesFail, userGroup_actions_d_LoadBillingCountriesSuccess as LoadBillingCountriesSuccess, userGroup_actions_d_LoadCities as LoadCities, userGroup_actions_d_LoadCitiesFail as LoadCitiesFail, userGroup_actions_d_LoadCitiesSuccess as LoadCitiesSuccess, userGroup_actions_d_LoadCustomerCoupons as LoadCustomerCoupons, userGroup_actions_d_LoadCustomerCouponsFail as LoadCustomerCouponsFail, userGroup_actions_d_LoadCustomerCouponsSuccess as LoadCustomerCouponsSuccess, userGroup_actions_d_LoadDeliveryCountries as LoadDeliveryCountries, userGroup_actions_d_LoadDeliveryCountriesFail as LoadDeliveryCountriesFail, userGroup_actions_d_LoadDeliveryCountriesSuccess as LoadDeliveryCountriesSuccess, userGroup_actions_d_LoadDistricts as LoadDistricts, userGroup_actions_d_LoadDistrictsFail as LoadDistrictsFail, userGroup_actions_d_LoadDistrictsSuccess as LoadDistrictsSuccess, userGroup_actions_d_LoadNotificationPreferences as LoadNotificationPreferences, userGroup_actions_d_LoadNotificationPreferencesFail as LoadNotificationPreferencesFail, userGroup_actions_d_LoadNotificationPreferencesSuccess as LoadNotificationPreferencesSuccess, userGroup_actions_d_LoadProductInterests as LoadProductInterests, userGroup_actions_d_LoadProductInterestsFail as LoadProductInterestsFail, userGroup_actions_d_LoadProductInterestsSuccess as LoadProductInterestsSuccess, userGroup_actions_d_LoadRegions as LoadRegions, userGroup_actions_d_LoadRegionsFail as LoadRegionsFail, userGroup_actions_d_LoadRegionsSuccess as LoadRegionsSuccess, userGroup_actions_d_LoadUserAddresses as LoadUserAddresses, userGroup_actions_d_LoadUserAddressesFail as LoadUserAddressesFail, userGroup_actions_d_LoadUserAddressesSuccess as LoadUserAddressesSuccess, userGroup_actions_d_LoadUserConsents as LoadUserConsents, userGroup_actions_d_LoadUserConsentsFail as LoadUserConsentsFail, userGroup_actions_d_LoadUserConsentsSuccess as LoadUserConsentsSuccess, userGroup_actions_d_LoadUserPaymentMethods as LoadUserPaymentMethods, userGroup_actions_d_LoadUserPaymentMethodsFail as LoadUserPaymentMethodsFail, userGroup_actions_d_LoadUserPaymentMethodsSuccess as LoadUserPaymentMethodsSuccess, userGroup_actions_d_REGISTER_USER_SUCCESS as REGISTER_USER_SUCCESS, userGroup_actions_d_REMOVE_PRODUCT_INTEREST as REMOVE_PRODUCT_INTEREST, userGroup_actions_d_REMOVE_PRODUCT_INTEREST_FAIL as REMOVE_PRODUCT_INTEREST_FAIL, userGroup_actions_d_REMOVE_PRODUCT_INTEREST_RESET as REMOVE_PRODUCT_INTEREST_RESET, userGroup_actions_d_REMOVE_PRODUCT_INTEREST_SUCCESS as REMOVE_PRODUCT_INTEREST_SUCCESS, userGroup_actions_d_RESET_DISCLAIM_CUSTOMER_COUPON as RESET_DISCLAIM_CUSTOMER_COUPON, userGroup_actions_d_RESET_GIVE_USER_CONSENT_PROCESS as RESET_GIVE_USER_CONSENT_PROCESS, userGroup_actions_d_RESET_LOAD_CUSTOMER_COUPONS as RESET_LOAD_CUSTOMER_COUPONS, userGroup_actions_d_RESET_LOAD_USER_CONSENTS as RESET_LOAD_USER_CONSENTS, userGroup_actions_d_RESET_NOTIFICATION_PREFERENCES as RESET_NOTIFICATION_PREFERENCES, userGroup_actions_d_RESET_SUBSCRIBE_CUSTOMER_COUPON_PROCESS as RESET_SUBSCRIBE_CUSTOMER_COUPON_PROCESS, userGroup_actions_d_RESET_UNSUBSCRIBE_CUSTOMER_COUPON_PROCESS as RESET_UNSUBSCRIBE_CUSTOMER_COUPON_PROCESS, userGroup_actions_d_RESET_WITHDRAW_USER_CONSENT_PROCESS as RESET_WITHDRAW_USER_CONSENT_PROCESS, userGroup_actions_d_RegisterUserSuccess as RegisterUserSuccess, userGroup_actions_d_RemoveProductInterest as RemoveProductInterest, userGroup_actions_d_RemoveProductInterestFail as RemoveProductInterestFail, userGroup_actions_d_RemoveProductInterestSuccess as RemoveProductInterestSuccess, userGroup_actions_d_ResetAddInterestState as ResetAddInterestState, userGroup_actions_d_ResetDisclaimCustomerCoupon as ResetDisclaimCustomerCoupon, userGroup_actions_d_ResetGiveUserConsentProcess as ResetGiveUserConsentProcess, userGroup_actions_d_ResetLoadCustomerCoupons as ResetLoadCustomerCoupons, userGroup_actions_d_ResetLoadUserConsents as ResetLoadUserConsents, userGroup_actions_d_ResetNotificationPreferences as ResetNotificationPreferences, userGroup_actions_d_ResetRemoveInterestState as ResetRemoveInterestState, userGroup_actions_d_ResetSubscribeCustomerCouponProcess as ResetSubscribeCustomerCouponProcess, userGroup_actions_d_ResetUnsubscribeCustomerCouponProcess as ResetUnsubscribeCustomerCouponProcess, userGroup_actions_d_ResetWithdrawUserConsentProcess as ResetWithdrawUserConsentProcess, userGroup_actions_d_SET_DEFAULT_USER_PAYMENT_METHOD as SET_DEFAULT_USER_PAYMENT_METHOD, userGroup_actions_d_SET_DEFAULT_USER_PAYMENT_METHOD_FAIL as SET_DEFAULT_USER_PAYMENT_METHOD_FAIL, userGroup_actions_d_SET_DEFAULT_USER_PAYMENT_METHOD_SUCCESS as SET_DEFAULT_USER_PAYMENT_METHOD_SUCCESS, userGroup_actions_d_SUBSCRIBE_CUSTOMER_COUPON as SUBSCRIBE_CUSTOMER_COUPON, userGroup_actions_d_SUBSCRIBE_CUSTOMER_COUPON_FAIL as SUBSCRIBE_CUSTOMER_COUPON_FAIL, userGroup_actions_d_SUBSCRIBE_CUSTOMER_COUPON_SUCCESS as SUBSCRIBE_CUSTOMER_COUPON_SUCCESS, userGroup_actions_d_SetDefaultUserPaymentMethod as SetDefaultUserPaymentMethod, userGroup_actions_d_SetDefaultUserPaymentMethodFail as SetDefaultUserPaymentMethodFail, userGroup_actions_d_SetDefaultUserPaymentMethodSuccess as SetDefaultUserPaymentMethodSuccess, userGroup_actions_d_SubscribeCustomerCoupon as SubscribeCustomerCoupon, userGroup_actions_d_SubscribeCustomerCouponFail as SubscribeCustomerCouponFail, userGroup_actions_d_SubscribeCustomerCouponSuccess as SubscribeCustomerCouponSuccess, userGroup_actions_d_TRANSFER_ANONYMOUS_CONSENT as TRANSFER_ANONYMOUS_CONSENT, userGroup_actions_d_TransferAnonymousConsent as TransferAnonymousConsent, userGroup_actions_d_UNSUBSCRIBE_CUSTOMER_COUPON as UNSUBSCRIBE_CUSTOMER_COUPON, userGroup_actions_d_UNSUBSCRIBE_CUSTOMER_COUPON_FAIL as UNSUBSCRIBE_CUSTOMER_COUPON_FAIL, userGroup_actions_d_UNSUBSCRIBE_CUSTOMER_COUPON_SUCCESS as UNSUBSCRIBE_CUSTOMER_COUPON_SUCCESS, userGroup_actions_d_UPDATE_NOTIFICATION_PREFERENCES as UPDATE_NOTIFICATION_PREFERENCES, userGroup_actions_d_UPDATE_NOTIFICATION_PREFERENCES_FAIL as UPDATE_NOTIFICATION_PREFERENCES_FAIL, userGroup_actions_d_UPDATE_NOTIFICATION_PREFERENCES_SUCCESS as UPDATE_NOTIFICATION_PREFERENCES_SUCCESS, userGroup_actions_d_UPDATE_USER_ADDRESS as UPDATE_USER_ADDRESS, userGroup_actions_d_UPDATE_USER_ADDRESS_FAIL as UPDATE_USER_ADDRESS_FAIL, userGroup_actions_d_UPDATE_USER_ADDRESS_SUCCESS as UPDATE_USER_ADDRESS_SUCCESS, userGroup_actions_d_UnsubscribeCustomerCoupon as UnsubscribeCustomerCoupon, userGroup_actions_d_UnsubscribeCustomerCouponFail as UnsubscribeCustomerCouponFail, userGroup_actions_d_UnsubscribeCustomerCouponSuccess as UnsubscribeCustomerCouponSuccess, userGroup_actions_d_UpdateNotificationPreferences as UpdateNotificationPreferences, userGroup_actions_d_UpdateNotificationPreferencesFail as UpdateNotificationPreferencesFail, userGroup_actions_d_UpdateNotificationPreferencesSuccess as UpdateNotificationPreferencesSuccess, userGroup_actions_d_UpdateUserAddress as UpdateUserAddress, userGroup_actions_d_UpdateUserAddressFail as UpdateUserAddressFail, userGroup_actions_d_UpdateUserAddressSuccess as UpdateUserAddressSuccess, userGroup_actions_d_WITHDRAW_USER_CONSENT as WITHDRAW_USER_CONSENT, userGroup_actions_d_WITHDRAW_USER_CONSENT_FAIL as WITHDRAW_USER_CONSENT_FAIL, userGroup_actions_d_WITHDRAW_USER_CONSENT_SUCCESS as WITHDRAW_USER_CONSENT_SUCCESS, userGroup_actions_d_WithdrawUserConsent as WithdrawUserConsent, userGroup_actions_d_WithdrawUserConsentFail as WithdrawUserConsentFail, userGroup_actions_d_WithdrawUserConsentSuccess as WithdrawUserConsentSuccess };
  export type { userGroup_actions_d_BillingCountriesAction as BillingCountriesAction, userGroup_actions_d_CitiesAction as CitiesAction, userGroup_actions_d_CustomerCouponAction as CustomerCouponAction, userGroup_actions_d_DeliveryCountriesAction as DeliveryCountriesAction, userGroup_actions_d_DistrictsAction as DistrictsAction, userGroup_actions_d_NotificationPreferenceAction as NotificationPreferenceAction, userGroup_actions_d_ProductInterestsAction as ProductInterestsAction, userGroup_actions_d_RegionsAction as RegionsAction, userGroup_actions_d_UserAddressesAction as UserAddressesAction, userGroup_actions_d_UserConsentsAction as UserConsentsAction, userGroup_actions_d_UserCostCenterAction as UserCostCenterAction, userGroup_actions_d_UserPaymentMethodsAction as UserPaymentMethodsAction, userGroup_actions_d_UserRegisterOrRemoveAction as UserRegisterOrRemoveAction };
}

declare const getBillingCountriesState: MemoizedSelector<StateWithUser, BillingCountriesState>;
declare const getBillingCountriesEntites: MemoizedSelector<StateWithUser, BillingCountryEntities>;
declare const getAllBillingCountries: MemoizedSelector<StateWithUser, Country[]>;

declare const getCitiesLoaderState: MemoizedSelector<StateWithUser, LoaderState<CitiesState>>;
declare const getCitiesDataAndLoading: MemoizedSelector<StateWithUser, {
    loaded: boolean;
    loading: boolean;
    cities: City[];
    regionIsocode: string | null;
}>;

declare const getCustomerCouponsState: MemoizedSelector<StateWithUser, LoaderState<CustomerCouponSearchResult>>;
declare const getCustomerCouponsLoaded: MemoizedSelector<StateWithUser, boolean>;
declare const getCustomerCouponsLoading: MemoizedSelector<StateWithUser, boolean>;
declare const getCustomerCoupons: MemoizedSelector<StateWithUser, CustomerCouponSearchResult>;

declare const getDeliveryCountriesState: MemoizedSelector<StateWithUser, DeliveryCountriesState>;
declare const getDeliveryCountriesEntites: MemoizedSelector<StateWithUser, DeliveryCountryEntities>;
declare const getAllDeliveryCountries: MemoizedSelector<StateWithUser, Country[]>;
declare const countrySelectorFactory: (isocode: string) => MemoizedSelector<StateWithUser, Country | null>;

declare const getDistrictsLoaderState: MemoizedSelector<StateWithUser, LoaderState<DistrictsState>>;
declare const getDistrictsDataAndLoading: MemoizedSelector<StateWithUser, {
    loaded: boolean;
    loading: boolean;
    districts: CityDistrict[];
    cityIsocode: string | null;
}>;

declare const getUserState: MemoizedSelector<StateWithUser, UserState>;

declare const getPreferencesLoaderState: MemoizedSelector<StateWithUser, LoaderState<NotificationPreference[]>>;
declare const getPreferences: MemoizedSelector<StateWithUser, NotificationPreference[]>;
declare const getEnabledPreferences: MemoizedSelector<StateWithUser, NotificationPreference[]>;
declare const getPreferencesLoading: MemoizedSelector<StateWithUser, boolean>;

declare const getPaymentMethodsState: MemoizedSelector<StateWithUser, LoaderState<PaymentDetails[]>>;
declare const getPaymentMethods: MemoizedSelector<StateWithUser, PaymentDetails[]>;
declare const getPaymentMethodsLoading: MemoizedSelector<StateWithUser, boolean>;
declare const getPaymentMethodsLoadedSuccess: MemoizedSelector<StateWithUser, boolean>;

declare const getInterestsState: MemoizedSelector<StateWithUser, LoaderState<ProductInterestSearchResult>>;
declare const getInterests: MemoizedSelector<StateWithUser, ProductInterestSearchResult>;
declare const getInterestsLoading: MemoizedSelector<StateWithUser, boolean>;

declare const getRegionsLoaderState: MemoizedSelector<StateWithUser, LoaderState<RegionsState>>;
declare const getAllRegions: MemoizedSelector<StateWithUser, Region[]>;
declare const getRegionsDataAndLoading: MemoizedSelector<StateWithUser, {
    loaded: boolean;
    loading: boolean;
    regions: Region[];
    country: string | null;
}>;
declare const getRegionsCountry: MemoizedSelector<StateWithUser, string | null>;
declare const getRegionsLoading: MemoizedSelector<StateWithUser, boolean>;
declare const getRegionsLoaded: MemoizedSelector<StateWithUser, boolean>;

declare const getAddressesLoaderState: MemoizedSelector<StateWithUser, LoaderState<Address[]>>;
declare const getAddresses: MemoizedSelector<StateWithUser, Address[]>;
declare const getAddressesLoading: MemoizedSelector<StateWithUser, boolean>;
declare const getAddressesLoadedSuccess: MemoizedSelector<StateWithUser, boolean>;

declare const getConsentsState: MemoizedSelector<StateWithUser, LoaderState<ConsentTemplate[]>>;
declare const getConsentsValue: MemoizedSelector<StateWithUser, ConsentTemplate[]>;
declare const getConsentByTemplateId: (templateId: string) => MemoizedSelector<StateWithUser, ConsentTemplate | undefined>;
declare const getConsentsLoading: MemoizedSelector<StateWithUser, boolean>;
declare const getConsentsSuccess: MemoizedSelector<StateWithUser, boolean>;
declare const getConsentsError: MemoizedSelector<StateWithUser, boolean>;

declare const getCostCentersState: MemoizedSelector<StateWithUser, LoaderState<CostCenter[]>>;
declare const getCostCenters: MemoizedSelector<StateWithUser, CostCenter[]>;

declare const usersGroup_selectors_d_countrySelectorFactory: typeof countrySelectorFactory;
declare const usersGroup_selectors_d_getAddresses: typeof getAddresses;
declare const usersGroup_selectors_d_getAddressesLoadedSuccess: typeof getAddressesLoadedSuccess;
declare const usersGroup_selectors_d_getAddressesLoaderState: typeof getAddressesLoaderState;
declare const usersGroup_selectors_d_getAddressesLoading: typeof getAddressesLoading;
declare const usersGroup_selectors_d_getAllBillingCountries: typeof getAllBillingCountries;
declare const usersGroup_selectors_d_getAllDeliveryCountries: typeof getAllDeliveryCountries;
declare const usersGroup_selectors_d_getAllRegions: typeof getAllRegions;
declare const usersGroup_selectors_d_getBillingCountriesEntites: typeof getBillingCountriesEntites;
declare const usersGroup_selectors_d_getBillingCountriesState: typeof getBillingCountriesState;
declare const usersGroup_selectors_d_getCitiesDataAndLoading: typeof getCitiesDataAndLoading;
declare const usersGroup_selectors_d_getCitiesLoaderState: typeof getCitiesLoaderState;
declare const usersGroup_selectors_d_getConsentByTemplateId: typeof getConsentByTemplateId;
declare const usersGroup_selectors_d_getConsentsError: typeof getConsentsError;
declare const usersGroup_selectors_d_getConsentsLoading: typeof getConsentsLoading;
declare const usersGroup_selectors_d_getConsentsState: typeof getConsentsState;
declare const usersGroup_selectors_d_getConsentsSuccess: typeof getConsentsSuccess;
declare const usersGroup_selectors_d_getConsentsValue: typeof getConsentsValue;
declare const usersGroup_selectors_d_getCostCenters: typeof getCostCenters;
declare const usersGroup_selectors_d_getCostCentersState: typeof getCostCentersState;
declare const usersGroup_selectors_d_getCustomerCoupons: typeof getCustomerCoupons;
declare const usersGroup_selectors_d_getCustomerCouponsLoaded: typeof getCustomerCouponsLoaded;
declare const usersGroup_selectors_d_getCustomerCouponsLoading: typeof getCustomerCouponsLoading;
declare const usersGroup_selectors_d_getCustomerCouponsState: typeof getCustomerCouponsState;
declare const usersGroup_selectors_d_getDeliveryCountriesEntites: typeof getDeliveryCountriesEntites;
declare const usersGroup_selectors_d_getDeliveryCountriesState: typeof getDeliveryCountriesState;
declare const usersGroup_selectors_d_getDistrictsDataAndLoading: typeof getDistrictsDataAndLoading;
declare const usersGroup_selectors_d_getDistrictsLoaderState: typeof getDistrictsLoaderState;
declare const usersGroup_selectors_d_getEnabledPreferences: typeof getEnabledPreferences;
declare const usersGroup_selectors_d_getInterests: typeof getInterests;
declare const usersGroup_selectors_d_getInterestsLoading: typeof getInterestsLoading;
declare const usersGroup_selectors_d_getInterestsState: typeof getInterestsState;
declare const usersGroup_selectors_d_getPaymentMethods: typeof getPaymentMethods;
declare const usersGroup_selectors_d_getPaymentMethodsLoadedSuccess: typeof getPaymentMethodsLoadedSuccess;
declare const usersGroup_selectors_d_getPaymentMethodsLoading: typeof getPaymentMethodsLoading;
declare const usersGroup_selectors_d_getPaymentMethodsState: typeof getPaymentMethodsState;
declare const usersGroup_selectors_d_getPreferences: typeof getPreferences;
declare const usersGroup_selectors_d_getPreferencesLoaderState: typeof getPreferencesLoaderState;
declare const usersGroup_selectors_d_getPreferencesLoading: typeof getPreferencesLoading;
declare const usersGroup_selectors_d_getRegionsCountry: typeof getRegionsCountry;
declare const usersGroup_selectors_d_getRegionsDataAndLoading: typeof getRegionsDataAndLoading;
declare const usersGroup_selectors_d_getRegionsLoaded: typeof getRegionsLoaded;
declare const usersGroup_selectors_d_getRegionsLoaderState: typeof getRegionsLoaderState;
declare const usersGroup_selectors_d_getRegionsLoading: typeof getRegionsLoading;
declare const usersGroup_selectors_d_getUserState: typeof getUserState;
declare namespace usersGroup_selectors_d {
  export {
    usersGroup_selectors_d_countrySelectorFactory as countrySelectorFactory,
    usersGroup_selectors_d_getAddresses as getAddresses,
    usersGroup_selectors_d_getAddressesLoadedSuccess as getAddressesLoadedSuccess,
    usersGroup_selectors_d_getAddressesLoaderState as getAddressesLoaderState,
    usersGroup_selectors_d_getAddressesLoading as getAddressesLoading,
    usersGroup_selectors_d_getAllBillingCountries as getAllBillingCountries,
    usersGroup_selectors_d_getAllDeliveryCountries as getAllDeliveryCountries,
    usersGroup_selectors_d_getAllRegions as getAllRegions,
    usersGroup_selectors_d_getBillingCountriesEntites as getBillingCountriesEntites,
    usersGroup_selectors_d_getBillingCountriesState as getBillingCountriesState,
    usersGroup_selectors_d_getCitiesDataAndLoading as getCitiesDataAndLoading,
    usersGroup_selectors_d_getCitiesLoaderState as getCitiesLoaderState,
    usersGroup_selectors_d_getConsentByTemplateId as getConsentByTemplateId,
    usersGroup_selectors_d_getConsentsError as getConsentsError,
    usersGroup_selectors_d_getConsentsLoading as getConsentsLoading,
    usersGroup_selectors_d_getConsentsState as getConsentsState,
    usersGroup_selectors_d_getConsentsSuccess as getConsentsSuccess,
    usersGroup_selectors_d_getConsentsValue as getConsentsValue,
    usersGroup_selectors_d_getCostCenters as getCostCenters,
    usersGroup_selectors_d_getCostCentersState as getCostCentersState,
    usersGroup_selectors_d_getCustomerCoupons as getCustomerCoupons,
    usersGroup_selectors_d_getCustomerCouponsLoaded as getCustomerCouponsLoaded,
    usersGroup_selectors_d_getCustomerCouponsLoading as getCustomerCouponsLoading,
    usersGroup_selectors_d_getCustomerCouponsState as getCustomerCouponsState,
    usersGroup_selectors_d_getDeliveryCountriesEntites as getDeliveryCountriesEntites,
    usersGroup_selectors_d_getDeliveryCountriesState as getDeliveryCountriesState,
    usersGroup_selectors_d_getDistrictsDataAndLoading as getDistrictsDataAndLoading,
    usersGroup_selectors_d_getDistrictsLoaderState as getDistrictsLoaderState,
    usersGroup_selectors_d_getEnabledPreferences as getEnabledPreferences,
    usersGroup_selectors_d_getInterests as getInterests,
    usersGroup_selectors_d_getInterestsLoading as getInterestsLoading,
    usersGroup_selectors_d_getInterestsState as getInterestsState,
    usersGroup_selectors_d_getPaymentMethods as getPaymentMethods,
    usersGroup_selectors_d_getPaymentMethodsLoadedSuccess as getPaymentMethodsLoadedSuccess,
    usersGroup_selectors_d_getPaymentMethodsLoading as getPaymentMethodsLoading,
    usersGroup_selectors_d_getPaymentMethodsState as getPaymentMethodsState,
    usersGroup_selectors_d_getPreferences as getPreferences,
    usersGroup_selectors_d_getPreferencesLoaderState as getPreferencesLoaderState,
    usersGroup_selectors_d_getPreferencesLoading as getPreferencesLoading,
    usersGroup_selectors_d_getRegionsCountry as getRegionsCountry,
    usersGroup_selectors_d_getRegionsDataAndLoading as getRegionsDataAndLoading,
    usersGroup_selectors_d_getRegionsLoaded as getRegionsLoaded,
    usersGroup_selectors_d_getRegionsLoaderState as getRegionsLoaderState,
    usersGroup_selectors_d_getRegionsLoading as getRegionsLoading,
    usersGroup_selectors_d_getUserState as getUserState,
  };
}

declare abstract class UserProfileFacadeTransitionalToken {
    abstract getTitles(): Observable<Title[]>;
}

declare class UserStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserStoreModule, never, [typeof i1.CommonModule, typeof StateModule, typeof i2.StoreFeatureModule, typeof i4.EffectsFeatureModule, typeof _angular_router.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserStoreModule>;
}

declare class UserModule {
    static forRoot(): ModuleWithProviders<UserModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserModule, never, [typeof UserStoreModule, typeof UserEventModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserModule>;
}

export { ADDRESS_LIST_NORMALIZER, ADDRESS_NORMALIZER, ADDRESS_SERIALIZER, ADDRESS_VALIDATION_NORMALIZER, ADD_PRODUCT_INTEREST_PROCESS_ID, ANONYMOUS_CONSENTS, ANONYMOUS_CONSENTS_HEADER, ANONYMOUS_CONSENTS_STORE_FEATURE, ANONYMOUS_CONSENT_NORMALIZER, ANONYMOUS_CONSENT_STATUS, AbstractBrowserTabNotificationService, ActivatedRoutesService, AddUserAddressEvent, AnonymousConsentNormalizer, AnonymousConsentTemplatesAdapter, AnonymousConsentTemplatesConnector, anonymousConsentsGroup_d as AnonymousConsentsActions, AnonymousConsentsConfig, AnonymousConsentsInterceptor, AnonymousConsentsModule, anonymousConsentsGroup_selectors_d as AnonymousConsentsSelectors, AnonymousConsentsService, AnonymousConsentsStatePersistenceService, authGroup_actions_d as AuthActions, AuthConfig, AuthConfigInitializer, AuthConfigService, AuthFlowRoutesService, AuthGuard, AuthHttpHeaderService, AuthInterceptor, AuthModule, AuthMultisiteIsolationService, AuthNotificationService, AuthNotificationType, AuthRedirectService, AuthRedirectStorageService, AuthService, AuthStatePersistenceService, AuthStorageService, B2BUserRight, B2BUserRole, BASE_SITE_CONTEXT_ID, BASE_SITE_NORMALIZER, BackendHttpTimeoutConfig, BadGatewayHandler, BadRequestHandler, BaseCoreModule, BaseOccModule, BasePageMetaResolver, BaseSiteInitializer, BaseSiteNormalizer, BaseSiteService, CITIES, CITY_DISTRICT_NORMALIZER, CITY_NORMALIZER, CLAIM_CUSTOMER_COUPON_PROCESS_ID, CLIENT_AUTH_FEATURE, CLIENT_TOKEN_DATA, CMS_COMPONENT_NORMALIZER, CMS_FEATURE, CMS_FLEX_COMPONENT_TYPE, CMS_PAGE_NORMALIZER, COMPONENT_ENTITY, CONFIG_INITIALIZER, CONSECUTIVE_CHARACTERS, CONSENT_TEMPLATE_NORMALIZER, COST_CENTERS_NORMALIZER, COST_CENTER_NORMALIZER, COST_CENTER_SERIALIZER, COUNTRY_NORMALIZER, CURRENCY_CONTEXT_ID, CURRENCY_NORMALIZER, CUSTOMER_COUPONS, CUSTOMER_COUPON_SEARCH_RESULT_NORMALIZER, CategoryPageMetaResolver, clientTokenGroup_actions_d as ClientAuthActions, ClientAuthModule, clientTokenGroup_selectors_d as ClientAuthSelectors, ClientAuthenticationTokenService, ClientErrorHandlingService, ClientTokenInterceptor, ClientTokenService, cmsGroup_actions_d as CmsActions, CmsBannerCarouselEffect, CmsComponentAdapter, CmsComponentConnector, CmsConfig, CmsModule, CmsOccModule, CmsPageAdapter, CmsPageConnector, CmsPageNotFoundOutboundHttpError, cmsGroup_selectors_d as CmsSelectors, CmsService, CmsStructureConfig, CmsStructureConfigService, Command, CommandService, CommandStrategy, ComponentDecorator, Config, ConfigChunk, ConfigInitializerModule, ConfigInitializerService, ConfigModule, ConfigValidatorModule, ConfigValidatorToken, ConfigurableRoutesService, ConfigurationService, ConflictHandler, ConsentService, ContainerBackgroundOptions, ContainerSizeOptions, ContentPageMetaResolver, ContextServiceMap, ConverterService, CostCenterModule, CostCenterOccModule, CountryType, CrossSiteRequestForgeryService, CsrfStateService, CurrencyInitializer, CurrencyService, CurrencySetEvent, CurrencyStatePersistenceService, CustomLoginGuard, CustomerCouponAdapter, CustomerCouponConnector, CustomerCouponService, CxDatePipe, CxErrorHandler, CxEvent, CxNumericPipe, DEFAULT_AUTHORIZATION_ERROR_RETRIES_COUNT, DEFAULT_AUTH_HTTP_HEADER_SERVICE, DEFAULT_SCOPE, DEFAULT_SERVER_ERROR_RETRIES_COUNT, DEFAULT_URL_MATCHER, DELEGATED_AUTH_HTTP_HEADER_SERVICE, DISCLAIM_CUSTOMER_COUPON_PROCESS_ID, DISTRICTS, DefaultConfig, DefaultConfigChunk, DefaultFeatureToggles, DefaultFeatureTogglesChunk, DefaultRoutePageMetaResolver, DeferLoadingStrategy, DeleteUserAddressEvent, DynamicAttributeService, EMAIL_PATTERN, ENDS_WITH_LEGAL_CHARACTER_PATTERN, EXPIRED_REFRESH_TOKEN_HANDLERS, EffectsErrorHandlerModule, ErrorActionService, ErrorHandlingModule, EventService, ExternalRoutesConfig, ExternalRoutesGuard, ExternalRoutesModule, ExternalRoutesService, FEDERATED_LOGIN_STATE_KEY, FacadeFactoryService, FacetChangedEvent, FeatureConfigService, FeatureDirective, FeatureLevelDirective, FeatureModulesService, FeatureStylesService, FeatureToggles, FeatureTogglesChunk, FeaturesConfig, FeaturesConfigModule, FederatedLoginConfig, FederatedLoginContextSerializerService, FederatedLoginContextStorageService, FederatedLoginGuard, FederatedLoginModule, FederatedLoginService, ForbiddenHandler, GIVE_CONSENT_PROCESS_ID, GLOBAL_MESSAGE_FEATURE, GatewayTimeoutHandler, GlobService, globalMessageGroup_actions_d as GlobalMessageActions, GlobalMessageConfig, GlobalMessageModule, globalMessageGroup_selectors_d as GlobalMessageSelectors, GlobalMessageService, GlobalMessageType, HOME_PAGE_CONTEXT, HTTP_TIMEOUT_CONFIG, HierarchicalAddressConfig, HttpErrorHandler, HttpErrorHandlerInterceptor, HttpErrorHandlerModule, HttpErrorModel, HttpModule, HttpParamsURIEncoder, HttpResponseStatus, HttpTimeoutInterceptor, HttpTimeoutModule, I18NEXT_HTTP_BACKEND_CLIENT, I18NEXT_INSTANCE, I18nConfig, I18nConfigInitializer, I18nModule, I18nTestingModule, I18nextBackendInitializer, I18nextBackendService, I18nextHttpBackendInitializer, I18nextInitializer, I18nextResourcesToBackendInitializer, I18nextTranslationService, ImageType, InterceptorUtil, InternalServerErrorHandler, JSP_INCLUDE_CMS_COMPONENT_TYPE, JavaRegExpConverter, LANGUAGE_CONTEXT_ID, LANGUAGE_NORMALIZER, LOCATION_INITIALIZED_MULTI, LanguageInitializer, LanguageService, LanguageSetEvent, LanguageStatePersistenceService, LazyModulesService, LegacyOccCmsComponentAdapter, LoadUserAddressesEvent, LoadUserPaymentMethodsEvent, LoadingScopesService, LoggerService, LoggingErrorHandler, LoginEvent, LogoutEvent, MAX_CHARACTERS_PATTERN, MEDIA_BASE_URL_META_TAG_NAME, MEDIA_BASE_URL_META_TAG_PLACEHOLDER, MIN_EIGHT_CHARACTERS_PATTERN, MIN_ONE_DIGIT_PATTERN, MIN_ONE_SPECIAL_CHARACTER_PATTERN, MIN_ONE_UPPER_CASE_CHARACTER_PATTERN, MIN_SIX_CHARACTERS_PATTERN, MODULE_INITIALIZER, MULTI_ERROR_HANDLER, MetaTagConfigModule, MockDatePipe, MockTranslatePipe, MockTranslationService, ModuleInitializedEvent, NAVIGATION_DETAIL_ENTITY, NOTIFICATION_PREFERENCES, NotAuthGuard, NotFoundHandler, NotificationType, OAUTH_REDIRECT_FLOW_KEY, OAuthFlow, OAuthLibWrapperService, OCC_BASE_URL_META_TAG_NAME, OCC_BASE_URL_META_TAG_PLACEHOLDER, OCC_CART_ID_CURRENT, OCC_HTTP_TOKEN, occUserIds_d as OCC_USER_IDS, OCC_USER_ID_ANONYMOUS, OCC_USER_ID_CONSTANTS, OCC_USER_ID_CURRENT, OCC_USER_ID_GUEST, ObjectComparisonUtils, Occ, OccAnonymousConsentTemplatesAdapter, OccCmsComponentAdapter, OccCmsPageAdapter, OccCmsPageNormalizer, OccConfig, OccCostCenterListNormalizer, OccCostCenterNormalizer, OccCostCenterSerializer, OccCustomerCouponAdapter, OccEndpointsService, OccFieldsService, OccHttpErrorReason, OccHttpErrorType, OccProductAdapter, OccProductAvailabilityAdapter, OccProductReferencesAdapter, OccProductReferencesListNormalizer, OccProductReviewsAdapter, OccProductSearchAdapter, OccProductSearchPageNormalizer, OccRequestsOptimizerService, OccSiteAdapter, OccUserAddressAdapter, OccUserConsentAdapter, OccUserInterestsAdapter, OccUserInterestsNormalizer, OccUserNotificationPreferenceAdapter, OccUserPaymentAdapter, OutboundHttpError, PASSWORD_PATTERN, PAYMENT_DETAILS_NORMALIZER, POINT_OF_SERVICE_NORMALIZER, PROCESS_FEATURE, PRODUCT_DETAIL_ENTITY, PRODUCT_FEATURE, PRODUCT_INTERESTS, PRODUCT_INTERESTS_NORMALIZER, PRODUCT_NORMALIZER, PRODUCT_REFERENCES_NORMALIZER, PRODUCT_REVIEW_NORMALIZER, PRODUCT_REVIEW_SERIALIZER, PRODUCT_SEARCH_PAGE_NORMALIZER, PRODUCT_SEARCH_RESULTS_BY_CATEGORY_ENTITY, PRODUCT_SEARCH_RESULTS_BY_CODES_ENTITY, PRODUCT_SUGGESTION_NORMALIZER, PageContext, PageLinkService, PageMetaConfig, PageMetaModule, PageMetaResolver, PageMetaService, PageRobotsMeta, PageType, PriceType, Priority, ProcessModule, process_selectors_d as ProcessSelectors, productGroup_actions_d as ProductActions, ProductAdapter, ProductAvailabilityAdapter, ProductAvailabilityConnector, ProductAvailabilityService, ProductCatalogService, ProductConnector, ProductEventBuilder, ProductEventModule, ProductImageNormalizer, ProductLoadingService, ProductModule, ProductNameNormalizer, ProductOccModule, ProductPageMetaResolver, ProductReferenceNormalizer, ProductReferenceService, ProductReferencesAdapter, ProductReferencesConnector, ProductReviewService, ProductReviewsAdapter, ProductReviewsConnector, ProductScope, ProductSearchAdapter, ProductSearchByCategoryService, ProductSearchByCodeService, ProductSearchConnector, ProductSearchService, productGroup_selectors_d as ProductSelectors, ProductService, ProductTypes, ProductURLPipe, ProtectedRoutesGuard, ProtectedRoutesService, QueryService, REGIONS, REGION_NORMALIZER, REGISTER_USER_PROCESS_ID, REMOVE_PRODUCT_INTERESTS_PROCESS_ID, ROUTING_FEATURE, RootConfig, RootFeatureToggles, RouteLoadStrategy, routingGroup_actions_d as RoutingActions, RoutingConfig, RoutingConfigService, RoutingModule, RoutingPageMetaResolver, RoutingParamsService, routingGroup_selectors_d as RoutingSelector, RoutingService, SECURE_PASSWORD_PATTERN, SERVER_REQUEST_ORIGIN, SERVER_REQUEST_URL, SITE_CONTEXT_FEATURE, SITE_THEME_FEATURE, SMART_EDIT_CONTEXT, STRONG_PASSWORD_PATTERN, SUBSCRIBE_CUSTOMER_COUPON_PROCESS_ID, ScriptLoader, ScriptPlacement, ScrollBehavior, SearchPageMetaResolver, SearchboxService, SecurePortalConfigInitializer, SemanticPathService, SiteAdapter, SiteConnector, siteContextGroup_actions_d as SiteContextActions, SiteContextConfig, SiteContextConfigInitializer, SiteContextEventBuilder, SiteContextEventModule, SiteContextInterceptor, SiteContextModule, SiteContextOccModule, SiteContextParamsService, siteContextGroup_selectors_d as SiteContextSelectors, SiteContextUrlSerializer, siteThemeGroup_actions_d as SiteThemeActions, SiteThemeConfig, SiteThemeModule, siteThemeGroup_selectors_d as SiteThemeSelectors, SiteThemeService, SlotDecorator, StateConfig, StateEventService, StateModule, StatePersistenceService, StateTransferType, utilsGroup_d as StateUtils, StorageSyncType, StringTemplate, TEST_CONFIG, TEST_CONFIG_COOKIE_NAME, THEME_CONTEXT_ID, TestConfigModule, TestingTimeUtils, TimeUtils, TokenRevocationInterceptor, TranslatePipe, TranslationChunkService, TranslationService, UNSUBSCRIBE_CUSTOMER_COUPON_PROCESS_ID, UPDATE_NOTIFICATION_PREFERENCES_PROCESS_ID, USER_ADDRESSES, USER_CONSENTS, USER_COST_CENTERS, USER_FEATURE, USER_PAYMENT_METHODS, USE_AUTHORIZATION_CODE_FLOW_BY_DEFAULT, USE_CAPTCHA_TOKEN, USE_CLIENT_TOKEN, USE_CUSTOMER_SUPPORT_AGENT_TOKEN, UnifiedInjector, UnknownErrorHandler, UpdateUserAddressEvent, UrlMatcherService, UrlModule, UrlParsingService, UrlPipe, userGroup_actions_d as UserActions, UserAddressAdapter, UserAddressConnector, UserAddressEvent, UserAddressService, UserAuthEventBuilder, UserAuthEventModule, UserAuthModule, UserConsentAdapter, UserConsentConnector, UserConsentService, UserCostCenterAdapter, UserCostCenterConnector, UserCostCenterService, UserEventBuilder, UserEventModule, UserIdService, UserInterestsAdapter, UserInterestsConnector, UserInterestsService, UserModule, UserNotificationPreferenceService, UserOccModule, UserPaymentAdapter, UserPaymentConnector, UserPaymentService, UserProfileFacadeTransitionalToken, usersGroup_selectors_d as UsersSelectors, VariantQualifier, VariantType, WITHDRAW_CONSENT_PROCESS_ID, WindowRef, WithCredentialsInterceptor, authNotificationServiceChannelId, backOff, configInitializerFactory, configValidatorFactory, contextServiceMapProvider, createFrom, decodeBase64, deepMerge, defaultAnonymousConsentsConfig, defaultBackendHttpTimeoutConfig, defaultCmsModuleConfig, defaultHierarchicalAddressConfig, defaultOccConfig, defaultPageMetaConfig, defaultSiteThemeConfig, encodeBase64, errorHandlers, extractFields, facadeFactory, federatedLoginProviders, getContextParameterDefault, getContextParameterValues, getLastValueSync, httpErrorInterceptors, i18nextBackendProviders, initConfigurableRoutes, initSecurePortalConfig, isAuthorizationError, isFeatureEnabled, isFeatureLevel, isJaloError, isKeyInvalid, isNotNullable, isNotUndefined, isObject, isServerError, isTabNotificationWrapperEvent, isTranslatable, locationInitializedFactory, mediaServerConfigFromMetaTagFactory, mergeFields, normalizeEmpty, occConfigValidator, occServerConfigFromMetaTagFactory, optimizeFields, parseFields, provideConfig, provideConfigFactory, provideConfigFromMetaTags, provideConfigInitializer, provideConfigInitializerFactory, provideConfigValidator, provideDefaultConfig, provideDefaultConfigFactory, provideDefaultFeatureToggles, provideDefaultFeatureTogglesFactory, provideFeatureToggles, provideFeatureTogglesFactory, provideLocationInitializer, provideLocationInitializerFactory, resolveApplicable, serviceMapFactory, stringifyFields, tryNormalizeHttpError, uniteLatest, urlPathJoin, useFeatureStyles, validateConfig, withdrawOn, wrapIntoObservable };
export type { ActionToEventMapping, ActivatedRouteSnapshotWithPageMeta, ActivatedRouterStateSnapshot, Address, AddressValidation, AnonymousConsent, AnonymousConsentsState, Applicable, AuthLibConfig, AuthToken, B2BApprovalProcess, B2BUnit, B2BUser, BackOffOptions, BackendConfig, BaseOccUrlProperties, BaseOption, BaseSite, BaseSiteEntities, BaseSiteState, BaseStore, BillingCountriesState, BillingCountryEntities, Breadcrumb, BreadcrumbMeta, CMSComponentConfig, CMSTabParagraphContainer, CSRFResponse, CanonicalPageResolver, CanonicalUrlOptions, CaptchaConfig, CardType, Category, CitiesState, City, CityDistrict, Classification, ClearSearch, ClientAuthState, ClientToken, CmsActivatedRouteSnapshot, CmsAddToCartComponent, CmsBannerCarouselComponent, CmsBannerComponent, CmsBannerComponentMedia, CmsBreadcrumbsComponent, CmsComponent, CmsComponentChildRoutesConfig, CmsComponentMapping, CmsComponentWithChildren, CmsLinkComponent, CmsMiniCartComponent, CmsNavigationComponent, CmsNavigationEntry, CmsNavigationNode, CmsOrderDetailItemsComponent, CmsOrderDetailOverviewComponent, CmsPDFDocumentComponent, CmsPageConfig, CmsPageSlotConfig, CmsPageSlotsConfig, CmsPageTitleComponent, CmsParagraphComponent, CmsPickupItemDetails, CmsProductCarouselComponent, CmsProductFacetNavigationComponent, CmsProductReferencesComponent, CmsResponsiveBannerComponentMedia, CmsRoute, CmsRouteData, CmsScrollToTopComponent, CmsSearchBoxComponent, CmsSiteContextSelectorComponent, CmsState, CmsStructureModel, CmsVideoComponent, ComponentsContext, ComponentsState, ConfigFactory, ConfigInitializer, ConfigValidator, Consent, ConsentTemplate, ContentSlotComponentData, ContentSlotData, Converter, CostCenter, Country, CurrenciesState, Currency, CurrencyEntities, CustomerCoupon, CustomerCoupon2Customer, CustomerCouponNotification, CustomerCouponSearchResult, DeliveryCountriesState, DeliveryCountryEntities, DistrictsState, DynamicAttributes, EntitiesModel, ErrorAction, ErrorModel, ExpiredRefreshTokenHandler, FacadeDescriptor, Facet, FacetValue, Feature, FeatureModuleConfig, FeatureToggleExpression, FeatureToggleKey, FeatureTogglesFactory, FeatureUnit, FeatureValue, FederatedLoginContext, FutureStock, GeoPoint, GlobalMessage, GlobalMessageEntities, GlobalMessageState, GlobalMessageTypeConfig, HttpTimeoutConfig, I18nextHttpBackendClient, Image, ImageGroup, Images, IndexType, JspIncludeCmsComponentConfig, Language, LanguagesEntities, LanguagesState, ListModel, LocationInitializer, LocationInitializerFactory, MultiErrorHandler, NavigationNodes, NodeItem, NotificationPreference, NotificationPreferenceList, OAuthTryLoginResult, OccCmsPageRequest, OccEndpoint, OccEndpoints, OccFieldsModel, OccHttpContext, OccOptimimalUrlGroups, OpeningSchedule, OrderApprovalPermissionType, Page, PageBreadcrumbResolver, PageDescriptionResolver, PageHeadingResolver, PageImageResolver, PageMeta, PageMetaResolverConfig, PageMetaResolversConfig, PageRobotsResolver, PageState, PageTitleResolver, PaginationModel, ParamsMapping, PaymentDetails, PointOfService, PointOfServiceStock, Price, PriceRange, Principal, Product, ProductAvailabilities, ProductInterestEntry, ProductInterestEntryRelation, ProductInterestSearchResult, ProductOccEndpoint, ProductReference, ProductReferences, ProductReferencesState, ProductReviewsState, ProductSearchPage, ProductsSearchState, ProductsState, Promotion, PromotionRestriction, Query, QueryNotifier, QueryState, Region, RegionsState, RequiredPick, Review, RouteBreadcrumbConfig, RouteBreadcrumbResolver, RouteBreadcrumbResolverParams, RouteConfig, RoutePageMetaConfig, RouterState, RoutesConfig, RoutingConfigDefinition, RoutingResolveBreadcrumbsOptions, SapUnit, ScopedData, ScopedDataWithUrl, ScopedProductData, SearchConfig, SearchQuery, SearchState, SiteContext, SiteContextState, SiteContextUrlParams, SiteTheme, SiteThemeEntities, SiteThemeState, SiteThemesState, SortModel, SpecialOpeningDay, SpellingSuggestion, StandardCmsComponentConfig, State, StateWithAnonymousConsents, StateWithClientAuth, StateWithCms, StateWithGlobalMessage, StateWithProcess, StateWithProduct, StateWithSiteContext, StateWithSiteTheme, StateWithUser, Stock, StoreFinderStockSearchPage, Suggestion, SyncedAnonymousConsentsState, SyncedAuthState, TabNotificationWrapper, TestConfig, TestConfigModuleOptions, Time, Title, Translatable, TranslatableParams, TranslationChunksConfig, TranslationResourceKey, TranslationResources, UrlCommand, UrlCommandRoute, UrlCommands, UrlMatcherFactory, UrlTreeWithSiteContext, User, UserState, VariantCategory, VariantMatrixElement, VariantOption, VariantOptionQualifier, VariantValueCategory, WeekdayOpeningDay };
