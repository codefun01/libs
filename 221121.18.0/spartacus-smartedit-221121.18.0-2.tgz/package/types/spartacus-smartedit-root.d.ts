import * as i0 from '@angular/core';
import { Location } from '@angular/common';
import { ScriptLoader, FeatureModulesService, WindowRef, RoutingService } from '@spartacus/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

declare abstract class SmartEditConfig {
    smartEdit?: {
        storefrontPreviewRoute?: string;
        allowOrigin?: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<SmartEditConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SmartEditConfig>;
}
declare module '@spartacus/core' {
    interface Config extends SmartEditConfig {
    }
}

declare const SMART_EDIT_FEATURE = "smartEdit";

/**
 * The SmartEditLauncherService is used to check whether Spartacus is launched inside Smart Edit;
 * it also gets cmsTicketId sent from Smart Edit.
 */
declare class SmartEditLauncherService {
    protected config: SmartEditConfig;
    protected location: Location;
    protected scriptLoader: ScriptLoader;
    protected readonly featureModulesService: FeatureModulesService;
    protected readonly windowRef: WindowRef;
    private _cmsTicketId;
    private static readonly STORAGE_KEY_CMS_TICKET_ID;
    get cmsTicketId(): string | undefined;
    constructor(config: SmartEditConfig, location: Location, scriptLoader: ScriptLoader);
    /**
     * load webApplicationInjector.js first when Spartacus launched inside SmartEdit
     */
    load(): void;
    /**
     * Indicates whether Spartacus is launched in SmartEdit
     */
    isLaunchedInSmartEdit(): boolean;
    private isInitialSmartEditPage;
    private isFullPageRedirectInSmartEdit;
    private persistCmsTicketId;
    private restoreCmsTicketId;
    static ɵfac: i0.ɵɵFactoryDeclaration<SmartEditLauncherService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SmartEditLauncherService>;
}

declare function smartEditFactory(smartEditLauncherService: SmartEditLauncherService): () => void;
declare class SmartEditRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SmartEditRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SmartEditRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SmartEditRootModule>;
}

declare class CmsTicketInterceptor implements HttpInterceptor {
    protected service: SmartEditLauncherService;
    routingService: RoutingService;
    constructor(service: SmartEditLauncherService);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    protected setRequestForProductListPage(request: HttpRequest<any>, next: HttpHandler, cmsTicketId: string): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsTicketInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CmsTicketInterceptor>;
}

export { CmsTicketInterceptor, SMART_EDIT_FEATURE, SmartEditConfig, SmartEditLauncherService, SmartEditRootModule, smartEditFactory };
