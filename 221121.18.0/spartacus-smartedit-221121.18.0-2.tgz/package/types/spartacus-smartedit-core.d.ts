import * as i0 from '@angular/core';
import { NgZone, RendererFactory2, Renderer2 } from '@angular/core';
import { CmsService, RoutingService, BaseSiteService, WindowRef, Page } from '@spartacus/core';
import { SmartEditConfig } from '@spartacus/smartedit/root';

declare class SmartEditService {
    protected cmsService: CmsService;
    protected routingService: RoutingService;
    protected baseSiteService: BaseSiteService;
    protected zone: NgZone;
    protected winRef: WindowRef;
    protected rendererFactory: RendererFactory2;
    protected config: SmartEditConfig;
    private isPreviewPage;
    private _currentPageId;
    private defaultPreviewProductCode;
    private defaultPreviewCategoryCode;
    constructor(cmsService: CmsService, routingService: RoutingService, baseSiteService: BaseSiteService, zone: NgZone, winRef: WindowRef, rendererFactory: RendererFactory2, config: SmartEditConfig);
    processCmsPage(): void;
    /**
     * add CSS classes in a body tag
     */
    protected addPageContract(cmsPage: Page): void;
    /**
     * go to the default preview page
     */
    protected goToPreviewPage(cmsPage: Page): void;
    /**
     * re-render CMS components and slots
     */
    protected renderComponent(componentId: string, componentType?: string, parentId?: string): boolean;
    protected reprocessPage(): void;
    /**
     * add smartedit HTML markup contract
     */
    addSmartEditContract(element: Element, renderer: Renderer2, properties: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SmartEditService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SmartEditService>;
}

declare class SmartEditCoreModule {
    private smartEditService;
    constructor(smartEditService: SmartEditService);
    static ɵfac: i0.ɵɵFactoryDeclaration<SmartEditCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SmartEditCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SmartEditCoreModule>;
}

export { SmartEditCoreModule, SmartEditService };
