import * as i0 from '@angular/core';
import { Injectable, inject, APP_INITIALIZER, NgModule } from '@angular/core';
import * as i3 from '@spartacus/core';
import { Config, FeatureModulesService, WindowRef, RoutingService, provideDefaultConfig } from '@spartacus/core';
import * as i2 from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { take, switchMap } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SmartEditConfig {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SmartEditConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SmartEditConfig, providedIn: 'root', useExisting: Config }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SmartEditConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useExisting: Config,
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const SMART_EDIT_FEATURE = 'smartEdit';

/**
 * The SmartEditLauncherService is used to check whether Spartacus is launched inside Smart Edit;
 * it also gets cmsTicketId sent from Smart Edit.
 */
class SmartEditLauncherService {
    static { this.STORAGE_KEY_CMS_TICKET_ID = 'smartedit.cmsTicketId'; }
    get cmsTicketId() {
        return this._cmsTicketId;
    }
    constructor(config, location, scriptLoader) {
        this.config = config;
        this.location = location;
        this.scriptLoader = scriptLoader;
        this.featureModulesService = inject(FeatureModulesService);
        this.windowRef = inject(WindowRef);
    }
    /**
     * load webApplicationInjector.js first when Spartacus launched inside SmartEdit
     */
    load() {
        if (this.isLaunchedInSmartEdit()) {
            this.featureModulesService.resolveFeature(SMART_EDIT_FEATURE).subscribe();
            this.scriptLoader?.embedScript({
                src: 'assets/webApplicationInjector.js',
                params: undefined,
                attributes: {
                    id: 'text/smartedit-injector',
                    'data-smartedit-allow-origin': this.config.smartEdit?.allowOrigin,
                },
            });
        }
    }
    /**
     * Indicates whether Spartacus is launched in SmartEdit
     */
    isLaunchedInSmartEdit() {
        const [path, params] = this.location.path().split('?');
        const cmsToken = params
            ?.split('&')
            .find((param) => param.startsWith('cmsTicketId='));
        const cmsTicketId = cmsToken?.split('=')[1];
        return (this.isInitialSmartEditPage(path, cmsTicketId) ||
            this.isFullPageRedirectInSmartEdit());
    }
    isInitialSmartEditPage(path, cmsTicketId) {
        // When both the SmartEdit cmsTicketId and the storefrontPreviewRoute values are found in the URL, store the cmsTicketId in sessionStorage.
        // so it survives full-page navigation (e.g. CDC OIDC redirect flow).
        if (path.split('/').pop() === this.config.smartEdit?.storefrontPreviewRoute &&
            !!cmsTicketId) {
            this.persistCmsTicketId(cmsTicketId);
            this._cmsTicketId = cmsTicketId;
            return true;
        }
        return false;
    }
    isFullPageRedirectInSmartEdit() {
        // Fall back to sessionStorage for scenarios where a full-page redirect
        // drops the cmsTicketId and other SmartEdit context from the URL.
        this._cmsTicketId = this.restoreCmsTicketId();
        return !!this._cmsTicketId;
    }
    persistCmsTicketId(cmsTicketId) {
        // bypass sessionStorage when not in browser context (e.g. SSR) to avoid "SecurityError: Access to storage is denied" error
        if (!this.windowRef.isBrowser()) {
            return;
        }
        sessionStorage.setItem(SmartEditLauncherService.STORAGE_KEY_CMS_TICKET_ID, cmsTicketId);
    }
    restoreCmsTicketId() {
        // bypass sessionStorage when not in browser context (e.g. SSR) to avoid "SecurityError: Access to storage is denied" error
        if (!this.windowRef.isBrowser()) {
            return undefined;
        }
        const stored = sessionStorage.getItem(SmartEditLauncherService.STORAGE_KEY_CMS_TICKET_ID);
        return stored ?? undefined;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SmartEditLauncherService, deps: [{ token: SmartEditConfig }, { token: i2.Location }, { token: i3.ScriptLoader }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SmartEditLauncherService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SmartEditLauncherService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: SmartEditConfig }, { type: i2.Location }, { type: i3.ScriptLoader }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultSmartEditConfig = {
    smartEdit: {
        storefrontPreviewRoute: 'cx-preview',
        allowOrigin: 'localhost:9002',
    },
};

class CmsTicketInterceptor {
    constructor(service) {
        this.service = service;
        this.routingService = inject(RoutingService);
    }
    intercept(request, next) {
        const cmsTicketId = this.service.cmsTicketId;
        if (!cmsTicketId) {
            return next.handle(request);
        }
        if (request.url.includes('/productList')) {
            return this.setRequestForProductListPage(request, next, cmsTicketId);
        }
        if (request.url.includes('/cms/') || request.url.includes('/products/')) {
            request = request.clone({
                setParams: {
                    cmsTicketId,
                },
            });
        }
        return next.handle(request);
    }
    setRequestForProductListPage(request, next, cmsTicketId) {
        return this.routingService.getPageContext().pipe(take(1), switchMap((pageContext) => {
            request = request.clone(!!pageContext.id
                ? {
                    setParams: {
                        cmsTicketId,
                        categoryCode: pageContext.id,
                    },
                }
                : {
                    setParams: {
                        cmsTicketId,
                    },
                });
            return next.handle(request);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CmsTicketInterceptor, deps: [{ token: SmartEditLauncherService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CmsTicketInterceptor, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CmsTicketInterceptor, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: SmartEditLauncherService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const interceptors = [
    {
        provide: HTTP_INTERCEPTORS,
        useExisting: CmsTicketInterceptor,
        multi: true,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
function smartEditFactory(smartEditLauncherService) {
    const isReady = () => {
        smartEditLauncherService.load();
    };
    return isReady;
}
class SmartEditRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SmartEditRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: SmartEditRootModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SmartEditRootModule, providers: [
            ...interceptors,
            provideDefaultConfig(defaultSmartEditConfig),
            {
                provide: APP_INITIALIZER,
                useFactory: smartEditFactory,
                deps: [SmartEditLauncherService],
                multi: true,
            },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SmartEditRootModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        ...interceptors,
                        provideDefaultConfig(defaultSmartEditConfig),
                        {
                            provide: APP_INITIALIZER,
                            useFactory: smartEditFactory,
                            deps: [SmartEditLauncherService],
                            multi: true,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CmsTicketInterceptor, SMART_EDIT_FEATURE, SmartEditConfig, SmartEditLauncherService, SmartEditRootModule, smartEditFactory };
//# sourceMappingURL=spartacus-smartedit-root.mjs.map
