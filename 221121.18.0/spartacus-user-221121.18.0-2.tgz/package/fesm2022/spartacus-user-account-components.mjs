import * as i0 from '@angular/core';
import { inject, Injectable, HostBinding, ViewChild, ChangeDetectionStrategy, Component, NgModule, Optional, ChangeDetectorRef } from '@angular/core';
import * as i1$2 from '@angular/router';
import { Router, ActivatedRoute, RouterLink, RouterModule } from '@angular/router';
import * as i1 from '@spartacus/core';
import { FeatureToggles, WindowRef, SemanticPathService, AuthConfigService, CsrfStateService, FederatedLoginService, AuthMultisiteIsolationService, GlobalMessageType, OAUTH_REDIRECT_FLOW_KEY, FeatureDirective, UrlPipe, TranslatePipe, UrlModule, I18nModule, FeaturesConfigModule, provideDefaultConfig, AuthService, GlobalMessageService, NotAuthGuard, CustomLoginGuard, RoutingService, AuthGuard } from '@spartacus/core';
import * as i1$3 from '@spartacus/storefront';
import { IS_GUEST_USER_CHECKOUT_KEY, CustomFormValidators, SpinnerComponent, FormRequiredLegendComponent, FormRequiredAsterisksComponent, FormErrorsComponent, PasswordVisibilityToggleDirective, FormErrorsModule, SpinnerModule, PasswordVisibilityToggleModule, PageSlotModule, BtnLikeLinkModule, PageSlotComponent, DomChangeDirective, DomChangeModule, FocusDirective, IconComponent, LAUNCH_CALLER, DIALOG_TYPE, LaunchDialogService, KeyboardFocusModule, IconModule } from '@spartacus/storefront';
import { of, BehaviorSubject, combineLatest, EMPTY, from, tap as tap$1 } from 'rxjs';
import * as i1$1 from '@angular/forms';
import { UntypedFormGroup, UntypedFormControl, Validators, FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { tap, take, catchError, withLatestFrom, switchMap } from 'rxjs/operators';
import { NgIf, AsyncPipe, CommonModule, NgClass } from '@angular/common';
import * as i2 from '@spartacus/user/account/root';
import { VerificationTokenFacade, VERIFICATION_TOKEN_DIALOG_ACTION } from '@spartacus/user/account/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class LoginAsGuestGuard {
    constructor() {
        this.featureToggles = inject(FeatureToggles);
        this.windowRef = inject(WindowRef);
        this.router = inject(Router);
        this.semanticPathService = inject(SemanticPathService);
    }
    getPath() {
        return this.semanticPathService.get('loginForm');
    }
    canActivate() {
        if (this.featureToggles.authorizationCodeFlowByDefault &&
            this.windowRef.localStorage?.getItem(IS_GUEST_USER_CHECKOUT_KEY) ===
                'true') {
            this.windowRef.localStorage.removeItem(IS_GUEST_USER_CHECKOUT_KEY);
            return of(this.router.createUrlTree([this.getPath()], {
                queryParams: { forced: true },
            }));
        }
        return of(true);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginAsGuestGuard, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginAsGuestGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginAsGuestGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ONE_TIME_PASSWORD_LOGIN_PURPOSE = 'LOGIN';
const OTP_LOGIN_STATE_STORAGE_KEY = 'cx_otp_login_state';
const LOGIN_ERROR_KEY = 'cx_login_error';
const SESSION_EXPIRED_ERROR = 'session_expired';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class LoginFormComponentService {
    get csrf() {
        return this.csrfStateService.get();
    }
    constructor(auth, globalMessage, winRef) {
        this.auth = auth;
        this.globalMessage = globalMessage;
        this.winRef = winRef;
        this.authConfigService = inject(AuthConfigService);
        this.featureToggles = inject(FeatureToggles);
        this.csrfStateService = inject(CsrfStateService);
        this.router = inject(Router);
        this.activatedRoute = inject(ActivatedRoute);
        this.federatedLoginService = inject(FederatedLoginService);
        this.authMultisiteIsolationService = inject(AuthMultisiteIsolationService);
        this.customFormValidErrors = [
            'bad_credentials',
            'account_disabled',
        ];
        this.busy$ = new BehaviorSubject(false);
        this.isUpdating$ = this.busy$.pipe(tap((state) => {
            const userId = this.winRef.nativeWindow?.history?.state?.['newUid'];
            if (userId) {
                this.form.patchValue({ userId });
            }
            state === true ? this.form.disable() : this.form.enable();
        }));
        this.showResetPassword = !this.federatedLoginService.isLoginDomain;
        this.form = new UntypedFormGroup({
            userId: new UntypedFormControl('', [
                Validators.required,
                CustomFormValidators.emailValidator,
            ]),
            password: new UntypedFormControl('', Validators.required),
        });
        if (this.featureToggles.authorizationCodeFlowByDefault) {
            this.initCustomLogin();
        }
    }
    login(nativeForm) {
        if (!this.form.valid) {
            this.form.markAllAsTouched();
            return;
        }
        if (this.featureToggles.authorizationCodeFlowByDefault && nativeForm) {
            if (this.featureToggles.authorizationCodeFlowByDefaultCsrfTokenRefresh) {
                // CXSPA-13213: refresh the CSRF token immediately before the
                // native form submit. The auth server rotates per-request, so a
                // stale page-load token would 403. A 403 on this GET also
                // signals that the auth-server session no longer holds a
                // pending PKCE authorization request — handled in catchError
                // below by redirecting to /login?error=session_expired so the
                // existing handleCustomLoginError() pipeline shows the friendly
                // message.
                combineLatest([
                    this.auth.refreshCsrfToken(),
                    this.featureToggles.siteIsolationForCustomLoginPage
                        ? this.getUserId()
                        : of(undefined),
                ])
                    .pipe(take(1), tap(([csrfToken, userId]) => {
                    this.csrfStateService.set(csrfToken);
                    this.form.get('csrf')?.setValue(csrfToken.token);
                    this.setOauthRedirectFlowFlag();
                    // Submit BEFORE flipping busy$ to true. busy$=true triggers
                    // form.disable(), which sets disabled=true on every bound input,
                    // and the browser excludes disabled inputs from native form
                    // submissions — resulting in an empty POST body and a 403.
                    if (this.featureToggles.siteIsolationForCustomLoginPage) {
                        this.submitWithUsernameOverride(nativeForm, userId);
                    }
                    else {
                        nativeForm.submit();
                    }
                    this.busy$.next(true);
                }), catchError(() => {
                    this.busy$.next(false);
                    this.clearOauthRedirectFlowFlag();
                    // Use a hard browser navigation (window.location.href) instead
                    // of router.navigate(['/login'], { queryParams: ... }). The
                    // router-based in-app navigation reuses the current
                    // LoginFormComponent and — by Angular's default route-reuse
                    // strategy — does NOT re-run CustomLoginGuard.canActivate(),
                    // which is the only place that fetches a fresh CSRF token
                    // (authService.getCsrfToken()) and binds it to a fresh
                    // auth-server session. Without that re-run, the next Sign In
                    // click reuses the dead JSESSIONID and 403s again.
                    // A real page load (which is what the user would do manually
                    // by refreshing) re-bootstraps Angular and re-runs the guard,
                    // producing a healthy CSRF token + session. window.location.href
                    // is the smallest change that replicates that behavior on the
                    // recovery path.
                    //
                    // Why sessionStorage instead of `?error=session_expired` on
                    // the URL: CustomLoginGuard re-runs on the hard redirect and
                    // can itself navigate (e.g. its own catchError calls
                    // createRoute('login'), which strips query params via UrlTree).
                    // A query param is therefore not guaranteed to survive the
                    // re-bootstrap. sessionStorage survives any number of
                    // intermediate redirects within the same browsing context
                    // and is read once + cleared by handleCustomLoginError().
                    if (this.winRef.isBrowser()) {
                        this.winRef.sessionStorage?.setItem(LOGIN_ERROR_KEY, SESSION_EXPIRED_ERROR);
                        const nativeWindow = this.winRef.nativeWindow;
                        if (nativeWindow) {
                            nativeWindow.location.href = '/login';
                        }
                        else {
                            // Defensive fallback: WindowRef.isBrowser() returned true
                            // but nativeWindow is undefined. This shouldn't happen at
                            // runtime (the two are gated by the same check inside
                            // WindowRef), but the type allows it. Without a redirect,
                            // sessionStorage drain on the next page-load won't fire
                            // (no page load happens), so surface the message inline
                            // so the user is not silently stuck on a dead form.
                            this.globalMessage.add({ key: this.resolveLoginErrorKey(SESSION_EXPIRED_ERROR) }, GlobalMessageType.MSG_TYPE_ERROR);
                        }
                    }
                    return EMPTY;
                }))
                    .subscribe();
            }
            else if (this.featureToggles.siteIsolationForCustomLoginPage) {
                this.getUserId()
                    .pipe(take(1))
                    .subscribe((userId) => {
                    this.setOauthRedirectFlowFlag();
                    this.submitWithUsernameOverride(nativeForm, userId);
                    this.busy$.next(true);
                });
            }
            else {
                this.setOauthRedirectFlowFlag();
                nativeForm.submit();
                this.busy$.next(true);
            }
        }
        else {
            this.busy$.next(true);
            from(this.auth.loginWithCredentials(
            // TODO: consider dropping toLowerCase as this should not be part of the UI,
            // as it's too opinionated and doesn't work with other AUTH services
            this.form.value.userId.toLowerCase(), this.form.value.password))
                .pipe(withLatestFrom(this.auth.isUserLoggedIn()), tap(([_, isLoggedIn]) => this.onSuccess(isLoggedIn)))
                .subscribe();
        }
    }
    handleCustomLoginError() {
        if (!this.featureToggles.authorizationCodeFlowByDefault) {
            return;
        }
        // First, drain any error stashed in sessionStorage by the catchError
        // hard-redirect path (see login()). sessionStorage survives the
        // re-bootstrap that the hard redirect causes, where a query param
        // would be lost to CustomLoginGuard's own internal redirects.
        if (this.winRef.isBrowser()) {
            const stashed = this.winRef.sessionStorage?.getItem(LOGIN_ERROR_KEY);
            if (stashed) {
                this.winRef.sessionStorage?.removeItem(LOGIN_ERROR_KEY);
                this.clearOauthRedirectFlowFlag();
                this.globalMessage.add({ key: this.resolveLoginErrorKey(stashed) }, GlobalMessageType.MSG_TYPE_ERROR);
            }
        }
        // Then handle errors arriving via query param (e.g. bad_credentials
        // round-trip from the auth server). Subscribe to queryParams (not
        // snapshot) so this also fires on in-place navigations that don't
        // re-construct LoginFormComponent.
        this.activatedRoute.queryParams.subscribe((params) => {
            const error = params['error'];
            if (error) {
                this.clearOauthRedirectFlowFlag();
                this.globalMessage.add({ key: this.resolveLoginErrorKey(error) }, GlobalMessageType.MSG_TYPE_ERROR);
                this.router.navigate([], {
                    queryParams: { error: null },
                });
            }
        });
    }
    resolveLoginErrorKey(error) {
        if (error === SESSION_EXPIRED_ERROR) {
            return 'httpHandlers.sessionExpired';
        }
        return this.customFormValidErrors.includes(error)
            ? `customLoginPage.badRequest.${error}`
            : 'customLoginPage.badRequest.unknown_error';
    }
    onSuccess(isLoggedIn) {
        if (isLoggedIn) {
            // We want to remove error messages on successful login (primary the bad
            // username/password combination)
            this.globalMessage.remove(GlobalMessageType.MSG_TYPE_ERROR);
            this.form.reset();
        }
        this.busy$.next(false);
    }
    initCustomLogin() {
        this.method = 'POST';
        this.action = this.authConfigService?.getCustomLoginFormEndpoint();
        this.form.addControl('csrf', new FormControl('', Validators.required));
        this.form.get('csrf')?.setValue(this.csrf?.token);
    }
    setOauthRedirectFlowFlag() {
        if (this.winRef.isBrowser()) {
            this.winRef.localStorage?.setItem(OAUTH_REDIRECT_FLOW_KEY, 'true');
        }
    }
    clearOauthRedirectFlowFlag() {
        if (this.winRef.isBrowser()) {
            this.winRef.localStorage?.removeItem(OAUTH_REDIRECT_FLOW_KEY);
        }
    }
    getUserId() {
        return this.authMultisiteIsolationService.decorateUserId(this.form.get('userId')?.value);
    }
    /**
     * Submits the native form after overriding the value of username input
     * for the duration of the submit only. The DOM value is written, the
     * form is submitted (which snapshots form data synchronously), and the
     * original value is restored on the next microtask — before the browser
     * has a chance to paint. This is used to POST the decorated userId
     * without the decorated value becoming visible in the input.
     */
    submitWithUsernameOverride(nativeForm, username) {
        const input = nativeForm.elements.namedItem('username');
        if (!(input instanceof HTMLInputElement) || !username) {
            nativeForm.submit();
            return;
        }
        const original = input.value;
        input.value = username;
        nativeForm.submit();
        // Restore synchronously — form.submit() snapshots the form data
        // before returning, so restoring immediately does not affect the POST
        // body but reverts the DOM before any repaint.
        input.value = original;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginFormComponentService, deps: [{ token: i1.AuthService }, { token: i1.GlobalMessageService }, { token: i1.WindowRef }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginFormComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginFormComponentService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.AuthService }, { type: i1.GlobalMessageService }, { type: i1.WindowRef }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class LoginFormComponent {
    constructor(service) {
        this.service = service;
        this.style = true;
        this.form = this.service.form;
        this.isUpdating$ = this.service.isUpdating$;
        this.csrf = this.service.csrf;
        this.action = this.service.action;
        this.method = this.service.method;
        this.showResetPassword = this.service.showResetPassword;
        this.service.handleCustomLoginError();
    }
    onSubmit() {
        this.service.login(this.loginForm?.nativeElement);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginFormComponent, deps: [{ token: LoginFormComponentService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: LoginFormComponent, isStandalone: true, selector: "cx-login-form", host: { attributes: { "ngSkipHydration": "true" }, properties: { "class.user-form": "this.style" } }, viewQueries: [{ propertyName: "loginForm", first: true, predicate: ["loginForm"], descendants: true }], ngImport: i0, template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"></cx-spinner>\n\n<form\n  (ngSubmit)=\"onSubmit()\"\n  [formGroup]=\"form\"\n  [attr.method]=\"method\"\n  [attr.action]=\"action\"\n  #loginForm\n>\n  <cx-form-required-legend />\n  <label>\n    <span class=\"label-content\">\n      {{ 'loginForm.emailAddress.label' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      type=\"email\"\n      class=\"form-control\"\n      placeholder=\"{{ 'loginForm.emailAddress.placeholder' | cxTranslate }}\"\n      [attr.aria-label]=\"'loginForm.emailAddress.label' | cxTranslate\"\n      formControlName=\"userId\"\n      name=\"username\"\n      [attr.aria-invalid]=\"\n        form.get('userId')?.touched && form.get('userId')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'userIdError'\"\n    />\n\n    <cx-form-errors\n      id=\"userIdError\"\n      [translationParams]=\"{\n        label: 'loginForm.emailAddress.label' | cxTranslate,\n      }\"\n      [control]=\"form.get('userId')\"\n    ></cx-form-errors>\n  </label>\n\n  <label>\n    <span class=\"label-content\">\n      {{ 'loginForm.password.label' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      type=\"password\"\n      class=\"form-control\"\n      placeholder=\"{{ 'loginForm.password.placeholder' | cxTranslate }}\"\n      formControlName=\"password\"\n      name=\"password\"\n      [attr.aria-label]=\"'loginForm.password.placeholder' | cxTranslate\"\n      [attr.aria-invalid]=\"\n        form.get('password')?.touched && form.get('password')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'passwordError'\"\n      cxPasswordVisibilitySwitch\n    />\n\n    <cx-form-errors\n      id=\"passwordError\"\n      [translationParams]=\"{\n        label: 'loginForm.password.label' | cxTranslate,\n      }\"\n      [control]=\"form.get('password')\"\n    ></cx-form-errors>\n  </label>\n\n  <ng-container *cxFeature=\"'authorizationCodeFlowByDefault'\">\n    <input\n      *ngIf=\"csrf\"\n      formControlName=\"csrf\"\n      type=\"hidden\"\n      [name]=\"csrf.parameterName\"\n    />\n  </ng-container>\n\n  <a\n    *ngIf=\"showResetPassword\"\n    [routerLink]=\"{ cxRoute: 'forgotPassword' } | cxUrl\"\n    class=\"btn-link\"\n  >\n    {{ 'loginForm.forgotPassword' | cxTranslate }}\n  </a>\n\n  <button\n    type=\"submit\"\n    class=\"btn btn-block btn-primary\"\n    [disabled]=\"form.disabled\"\n  >\n    {{ 'loginForm.signIn' | cxTranslate }}\n  </button>\n</form>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: PasswordVisibilityToggleDirective, selector: "[cxPasswordVisibilitySwitch][type=\"password\"]" }, { kind: "directive", type: FeatureDirective, selector: "[cxFeature]", inputs: ["cxFeature"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-login-form', changeDetection: ChangeDetectionStrategy.OnPush, host: { ngSkipHydration: 'true' }, imports: [
                        NgIf,
                        SpinnerComponent,
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredLegendComponent,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        PasswordVisibilityToggleDirective,
                        FeatureDirective,
                        RouterLink,
                        AsyncPipe,
                        UrlPipe,
                        TranslatePipe,
                    ], template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"></cx-spinner>\n\n<form\n  (ngSubmit)=\"onSubmit()\"\n  [formGroup]=\"form\"\n  [attr.method]=\"method\"\n  [attr.action]=\"action\"\n  #loginForm\n>\n  <cx-form-required-legend />\n  <label>\n    <span class=\"label-content\">\n      {{ 'loginForm.emailAddress.label' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      type=\"email\"\n      class=\"form-control\"\n      placeholder=\"{{ 'loginForm.emailAddress.placeholder' | cxTranslate }}\"\n      [attr.aria-label]=\"'loginForm.emailAddress.label' | cxTranslate\"\n      formControlName=\"userId\"\n      name=\"username\"\n      [attr.aria-invalid]=\"\n        form.get('userId')?.touched && form.get('userId')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'userIdError'\"\n    />\n\n    <cx-form-errors\n      id=\"userIdError\"\n      [translationParams]=\"{\n        label: 'loginForm.emailAddress.label' | cxTranslate,\n      }\"\n      [control]=\"form.get('userId')\"\n    ></cx-form-errors>\n  </label>\n\n  <label>\n    <span class=\"label-content\">\n      {{ 'loginForm.password.label' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      type=\"password\"\n      class=\"form-control\"\n      placeholder=\"{{ 'loginForm.password.placeholder' | cxTranslate }}\"\n      formControlName=\"password\"\n      name=\"password\"\n      [attr.aria-label]=\"'loginForm.password.placeholder' | cxTranslate\"\n      [attr.aria-invalid]=\"\n        form.get('password')?.touched && form.get('password')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'passwordError'\"\n      cxPasswordVisibilitySwitch\n    />\n\n    <cx-form-errors\n      id=\"passwordError\"\n      [translationParams]=\"{\n        label: 'loginForm.password.label' | cxTranslate,\n      }\"\n      [control]=\"form.get('password')\"\n    ></cx-form-errors>\n  </label>\n\n  <ng-container *cxFeature=\"'authorizationCodeFlowByDefault'\">\n    <input\n      *ngIf=\"csrf\"\n      formControlName=\"csrf\"\n      type=\"hidden\"\n      [name]=\"csrf.parameterName\"\n    />\n  </ng-container>\n\n  <a\n    *ngIf=\"showResetPassword\"\n    [routerLink]=\"{ cxRoute: 'forgotPassword' } | cxUrl\"\n    class=\"btn-link\"\n  >\n    {{ 'loginForm.forgotPassword' | cxTranslate }}\n  </a>\n\n  <button\n    type=\"submit\"\n    class=\"btn btn-block btn-primary\"\n    [disabled]=\"form.disabled\"\n  >\n    {{ 'loginForm.signIn' | cxTranslate }}\n  </button>\n</form>\n" }]
        }], ctorParameters: () => [{ type: LoginFormComponentService }], propDecorators: { loginForm: [{
                type: ViewChild,
                args: ['loginForm']
            }], style: [{
                type: HostBinding,
                args: ['class.user-form']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class LoginFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: LoginFormModule, imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            FormErrorsModule,
            SpinnerModule,
            PasswordVisibilityToggleModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            LoginFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginFormModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    ReturningCustomerLoginComponent: {
                        component: LoginFormComponent,
                        guards: [NotAuthGuard, CustomLoginGuard],
                        providers: [
                            {
                                provide: LoginFormComponentService,
                                useClass: LoginFormComponentService,
                                deps: [AuthService, GlobalMessageService, WindowRef],
                            },
                        ],
                    },
                },
            }),
        ], imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            FormErrorsModule,
            SpinnerModule,
            PasswordVisibilityToggleModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            LoginFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        FormErrorsModule,
                        SpinnerModule,
                        PasswordVisibilityToggleModule,
                        FeaturesConfigModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        LoginFormComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                ReturningCustomerLoginComponent: {
                                    component: LoginFormComponent,
                                    guards: [NotAuthGuard, CustomLoginGuard],
                                    providers: [
                                        {
                                            provide: LoginFormComponentService,
                                            useClass: LoginFormComponentService,
                                            deps: [AuthService, GlobalMessageService, WindowRef],
                                        },
                                    ],
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class LoginRegisterComponent {
    constructor(activatedRoute) {
        this.activatedRoute = activatedRoute;
        this.loginAsGuest = false;
        this.routingService = inject(RoutingService, {
            optional: true,
        });
    }
    ngOnInit() {
        this.loginAsGuest = this.activatedRoute.snapshot.queryParams['forced'];
    }
    navigateTo(cxRoute) {
        this.routingService?.go({ cxRoute });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginRegisterComponent, deps: [{ token: i1$2.ActivatedRoute }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: LoginRegisterComponent, isStandalone: true, selector: "cx-login-register", ngImport: i0, template: "<div class=\"register\">\n  <p class=\"cx-section-title\" id=\"register-section-label\">\n    {{ 'loginForm.dontHaveAccount' | cxTranslate }}\n  </p>\n\n  <button\n    (click)=\"navigateTo(loginAsGuest ? 'checkoutLogin' : 'register')\"\n    class=\"btn btn-block btn-secondary\"\n    [ngClass]=\"loginAsGuest ? 'btn-guest' : 'btn-register'\"\n    aria-describedby=\"register-section-label\"\n  >\n    {{\n      (loginAsGuest ? 'loginForm.guestCheckout' : 'loginForm.register')\n        | cxTranslate\n    }}\n  </button>\n</div>\n", dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginRegisterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-login-register', imports: [NgClass, TranslatePipe], template: "<div class=\"register\">\n  <p class=\"cx-section-title\" id=\"register-section-label\">\n    {{ 'loginForm.dontHaveAccount' | cxTranslate }}\n  </p>\n\n  <button\n    (click)=\"navigateTo(loginAsGuest ? 'checkoutLogin' : 'register')\"\n    class=\"btn btn-block btn-secondary\"\n    [ngClass]=\"loginAsGuest ? 'btn-guest' : 'btn-register'\"\n    aria-describedby=\"register-section-label\"\n  >\n    {{\n      (loginAsGuest ? 'loginForm.guestCheckout' : 'loginForm.register')\n        | cxTranslate\n    }}\n  </button>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1$2.ActivatedRoute }], propDecorators: { routingService: [{
                type: Optional
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class LoginRegisterB2BComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginRegisterB2BComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: LoginRegisterB2BComponent, isStandalone: true, selector: "cx-login-register-b2b", ngImport: i0, template: "<cx-login-register *cxFeature=\"'a11yB2BRegisterComponent'\"></cx-login-register>\n", dependencies: [{ kind: "component", type: LoginRegisterComponent, selector: "cx-login-register" }, { kind: "directive", type: FeatureDirective, selector: "[cxFeature]", inputs: ["cxFeature"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginRegisterB2BComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-login-register-b2b', imports: [LoginRegisterComponent, FeatureDirective], template: "<cx-login-register *cxFeature=\"'a11yB2BRegisterComponent'\"></cx-login-register>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class LoginRegisterModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginRegisterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: LoginRegisterModule, imports: [CommonModule,
            RouterModule,
            UrlModule,
            PageSlotModule,
            I18nModule,
            BtnLikeLinkModule,
            LoginRegisterComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginRegisterModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    ReturningCustomerRegisterComponent: {
                        component: LoginRegisterComponent,
                        guards: [NotAuthGuard, LoginAsGuestGuard],
                    },
                },
            }),
            provideDefaultConfig({
                cmsComponents: {
                    ReturningOrganizationUserRegisterComponent: {
                        component: LoginRegisterB2BComponent,
                        guards: [NotAuthGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            RouterModule,
            UrlModule,
            PageSlotModule,
            I18nModule,
            BtnLikeLinkModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginRegisterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        UrlModule,
                        PageSlotModule,
                        I18nModule,
                        BtnLikeLinkModule,
                        LoginRegisterComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                ReturningCustomerRegisterComponent: {
                                    component: LoginRegisterComponent,
                                    guards: [NotAuthGuard, LoginAsGuestGuard],
                                },
                            },
                        }),
                        provideDefaultConfig({
                            cmsComponents: {
                                ReturningOrganizationUserRegisterComponent: {
                                    component: LoginRegisterB2BComponent,
                                    guards: [NotAuthGuard],
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class LoginComponent {
    constructor(auth, userAccount, translation) {
        this.auth = auth;
        this.userAccount = userAccount;
        this.translation = translation;
    }
    ngOnInit() {
        this.user$ = this.auth.isUserLoggedIn().pipe(switchMap((isUserLoggedIn) => {
            if (isUserLoggedIn) {
                return this.userAccount.get();
            }
            else {
                return of(undefined);
            }
        }));
        this.greeting$ = this.user$.pipe(switchMap((user) => this.translation.translate(`miniLogin.userGreeting`, {
            name: user?.name,
        })));
        this.usingASMClient$ = this.auth.isUsingASMClient();
    }
    onRootNavBtnAdded($event, greeting) {
        $event.target.setAttribute('aria-label', greeting);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginComponent, deps: [{ token: i1.AuthService }, { token: i2.UserAccountFacade }, { token: i1.TranslationService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: LoginComponent, isStandalone: true, selector: "cx-login", ngImport: i0, template: "<ng-container *ngIf=\"user$ | async as user; else login\">\n  <ng-container *ngIf=\"greeting$ | async as greeting\">\n    <div class=\"cx-login-greet\">\n      {{ greeting$ | async }}\n    </div>\n    <cx-page-slot\n      (cxDomChange)=\"onRootNavBtnAdded($event, greeting)\"\n      cxDomChangeTargetSelector=\"nav ul li:first-child button\"\n      id=\"account-nav\"\n      position=\"HeaderLinks\"\n    ></cx-page-slot>\n  </ng-container>\n</ng-container>\n\n<ng-template #login>\n  <ng-container *ngIf=\"!(usingASMClient$ | async)\">\n    <a role=\"link\" [routerLink]=\"{ cxRoute: 'login' } | cxUrl\">{{\n      'miniLogin.signInRegister' | cxTranslate\n    }}</a>\n  </ng-container>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: PageSlotComponent, selector: "cx-page-slot,[cx-page-slot]", inputs: ["position", "class", "isPageFold", "hasComponents"] }, { kind: "directive", type: DomChangeDirective, selector: "[cxDomChange]", inputs: ["cxDomChangeTargetSelector"], outputs: ["cxDomChange"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-login', imports: [
                        NgIf,
                        PageSlotComponent,
                        DomChangeDirective,
                        RouterLink,
                        AsyncPipe,
                        UrlPipe,
                        TranslatePipe,
                    ], template: "<ng-container *ngIf=\"user$ | async as user; else login\">\n  <ng-container *ngIf=\"greeting$ | async as greeting\">\n    <div class=\"cx-login-greet\">\n      {{ greeting$ | async }}\n    </div>\n    <cx-page-slot\n      (cxDomChange)=\"onRootNavBtnAdded($event, greeting)\"\n      cxDomChangeTargetSelector=\"nav ul li:first-child button\"\n      id=\"account-nav\"\n      position=\"HeaderLinks\"\n    ></cx-page-slot>\n  </ng-container>\n</ng-container>\n\n<ng-template #login>\n  <ng-container *ngIf=\"!(usingASMClient$ | async)\">\n    <a role=\"link\" [routerLink]=\"{ cxRoute: 'login' } | cxUrl\">{{\n      'miniLogin.signInRegister' | cxTranslate\n    }}</a>\n  </ng-container>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1.AuthService }, { type: i2.UserAccountFacade }, { type: i1.TranslationService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class LoginModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: LoginModule, imports: [CommonModule,
            RouterModule,
            UrlModule,
            PageSlotModule,
            I18nModule,
            DomChangeModule,
            LoginComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    LoginComponent: {
                        component: LoginComponent,
                    },
                },
            }),
        ], imports: [CommonModule,
            RouterModule,
            UrlModule,
            PageSlotModule,
            I18nModule,
            DomChangeModule,
            LoginComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: LoginModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        UrlModule,
                        PageSlotModule,
                        I18nModule,
                        DomChangeModule,
                        LoginComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                LoginComponent: {
                                    component: LoginComponent,
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class MyAccountV2UserComponent extends LoginComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MyAccountV2UserComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: MyAccountV2UserComponent, isStandalone: true, selector: "cx-my-account-v2-user", usesInheritance: true, ngImport: i0, template: "<div class=\"cx-my-account-v2-user\">\n  <ng-container *ngIf=\"user$ | async as user\">\n    <div class=\"cx-name\">{{ user.title }}{{ user.name }}</div>\n    <a\n      class=\"cx-sign-out\"\n      [routerLink]=\"\n        {\n          cxRoute: 'logout',\n        } | cxUrl\n      \"\n      >{{ 'myAccountV2User.signOut' | cxTranslate }}\n    </a>\n  </ng-container>\n</div>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MyAccountV2UserComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-my-account-v2-user', imports: [NgIf, RouterLink, AsyncPipe, UrlPipe, TranslatePipe], template: "<div class=\"cx-my-account-v2-user\">\n  <ng-container *ngIf=\"user$ | async as user\">\n    <div class=\"cx-name\">{{ user.title }}{{ user.name }}</div>\n    <a\n      class=\"cx-sign-out\"\n      [routerLink]=\"\n        {\n          cxRoute: 'logout',\n        } | cxUrl\n      \"\n      >{{ 'myAccountV2User.signOut' | cxTranslate }}\n    </a>\n  </ng-container>\n</div>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class MyAccountV2UserModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MyAccountV2UserModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: MyAccountV2UserModule, imports: [CommonModule,
            RouterModule,
            UrlModule,
            I18nModule,
            MyAccountV2UserComponent], exports: [MyAccountV2UserComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MyAccountV2UserModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    MyAccountViewUserComponent: {
                        component: MyAccountV2UserComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            RouterModule,
            UrlModule,
            I18nModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MyAccountV2UserModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                MyAccountViewUserComponent: {
                                    component: MyAccountV2UserComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                    ],
                    exports: [MyAccountV2UserComponent],
                    imports: [
                        CommonModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        MyAccountV2UserComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OneTimePasswordLoginFormComponent {
    constructor() {
        this.routingService = inject(RoutingService);
        this.verificationTokenFacade = inject(VerificationTokenFacade);
        this.winRef = inject(WindowRef);
        this.busy$ = new BehaviorSubject(false);
        this.isUpdating$ = this.busy$.pipe(tap$1((state) => {
            const userId = this.winRef.nativeWindow?.history?.state?.['newUid'];
            if (userId) {
                this.form.patchValue({ userId });
            }
            state === true ? this.form.disable() : this.form.enable();
        }));
        this.form = new UntypedFormGroup({
            userId: new UntypedFormControl('', [
                Validators.required,
                CustomFormValidators.emailValidator,
            ]),
            password: new UntypedFormControl('', Validators.required),
        });
        this.style = true;
    }
    ngOnInit() {
        const sessionState = this.getStoredLoginState();
        if (sessionState) {
            this.form.patchValue({
                userId: sessionState.loginId,
            });
        }
        this.clearStoredLoginState();
    }
    getStoredLoginState() {
        const stored = this.winRef.sessionStorage?.getItem(OTP_LOGIN_STATE_STORAGE_KEY);
        if (!stored) {
            return null;
        }
        try {
            return JSON.parse(stored);
        }
        catch {
            return null;
        }
    }
    clearStoredLoginState() {
        this.winRef.sessionStorage?.removeItem(OTP_LOGIN_STATE_STORAGE_KEY);
    }
    onSubmit() {
        if (!this.form.valid) {
            this.form.markAllAsTouched();
            return;
        }
        this.busy$.next(true);
        const verificationTokenCreation = this.collectDataFromLoginForm();
        this.verificationTokenFacade
            .createVerificationToken(verificationTokenCreation)
            .subscribe({
            next: (result) => this.goToVerificationTokenForm(result, verificationTokenCreation),
            error: (error) => {
                this.routingService.go({
                    cxRoute: 'verifyToken',
                }, {
                    state: {
                        loginId: verificationTokenCreation.loginId,
                        password: verificationTokenCreation.password,
                        errorStatus: error.status,
                    },
                });
                this.busy$.next(false);
            },
            complete: () => this.onCreateVerificationTokenComplete(),
        });
    }
    goToVerificationTokenForm(verificationToken, verificationTokenCreation) {
        this.routingService.go({
            cxRoute: 'verifyToken',
        }, {
            state: {
                loginId: verificationTokenCreation.loginId,
                password: verificationTokenCreation.password,
                tokenId: verificationToken.tokenId,
                expiresIn: verificationToken.expiresIn,
            },
        });
    }
    onCreateVerificationTokenComplete() {
        this.form.reset();
        this.busy$.next(false);
    }
    collectDataFromLoginForm() {
        return {
            // TODO: consider dropping toLowerCase as this should not be part of the UI,
            // as it's too opinionated and doesn't work with other AUTH services
            loginId: this.form.value.userId.toLowerCase(),
            password: this.form.value.password,
            purpose: ONE_TIME_PASSWORD_LOGIN_PURPOSE,
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OneTimePasswordLoginFormComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OneTimePasswordLoginFormComponent, isStandalone: true, selector: "cx-otp-login-form", host: { attributes: { "ngSkipHydration": "true" }, properties: { "class.user-form": "this.style" } }, ngImport: i0, template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"></cx-spinner>\n\n<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n  <cx-form-required-legend />\n  <label>\n    <span class=\"label-content\">\n      {{ 'loginForm.emailAddress.label' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      type=\"email\"\n      class=\"form-control\"\n      formControlName=\"userId\"\n      placeholder=\"{{ 'loginForm.emailAddress.placeholder' | cxTranslate }}\"\n      [attr.aria-invalid]=\"\n        form.get('userId')?.touched && form.get('userId')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'userIdError'\"\n    />\n    <cx-form-errors\n      id=\"userIdError\"\n      [control]=\"form.get('userId')\"\n    ></cx-form-errors>\n  </label>\n\n  <label>\n    <span class=\"label-content\">\n      {{ 'loginForm.password.label' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      type=\"password\"\n      class=\"form-control\"\n      placeholder=\"{{ 'loginForm.password.placeholder' | cxTranslate }}\"\n      formControlName=\"password\"\n      [attr.aria-label]=\"'loginForm.password.placeholder' | cxTranslate\"\n      [attr.aria-invalid]=\"\n        form.get('password')?.touched && form.get('password')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'passwordError'\"\n      cxPasswordVisibilitySwitch\n    />\n    <cx-form-errors\n      id=\"passwordError\"\n      [control]=\"form.get('password')\"\n    ></cx-form-errors>\n  </label>\n\n  <a [routerLink]=\"{ cxRoute: 'forgotPassword' } | cxUrl\" class=\"btn-link\">\n    {{ 'loginForm.forgotPassword' | cxTranslate }}\n  </a>\n\n  <button\n    type=\"submit\"\n    class=\"btn btn-block btn-primary\"\n    [disabled]=\"form.disabled\"\n  >\n    {{ 'loginForm.signIn' | cxTranslate }}\n  </button>\n</form>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: PasswordVisibilityToggleDirective, selector: "[cxPasswordVisibilitySwitch][type=\"password\"]" }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OneTimePasswordLoginFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-otp-login-form', changeDetection: ChangeDetectionStrategy.OnPush, host: { ngSkipHydration: 'true' }, imports: [
                        NgIf,
                        SpinnerComponent,
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredLegendComponent,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        PasswordVisibilityToggleDirective,
                        RouterLink,
                        AsyncPipe,
                        UrlPipe,
                        TranslatePipe,
                    ], template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"></cx-spinner>\n\n<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n  <cx-form-required-legend />\n  <label>\n    <span class=\"label-content\">\n      {{ 'loginForm.emailAddress.label' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      type=\"email\"\n      class=\"form-control\"\n      formControlName=\"userId\"\n      placeholder=\"{{ 'loginForm.emailAddress.placeholder' | cxTranslate }}\"\n      [attr.aria-invalid]=\"\n        form.get('userId')?.touched && form.get('userId')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'userIdError'\"\n    />\n    <cx-form-errors\n      id=\"userIdError\"\n      [control]=\"form.get('userId')\"\n    ></cx-form-errors>\n  </label>\n\n  <label>\n    <span class=\"label-content\">\n      {{ 'loginForm.password.label' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      type=\"password\"\n      class=\"form-control\"\n      placeholder=\"{{ 'loginForm.password.placeholder' | cxTranslate }}\"\n      formControlName=\"password\"\n      [attr.aria-label]=\"'loginForm.password.placeholder' | cxTranslate\"\n      [attr.aria-invalid]=\"\n        form.get('password')?.touched && form.get('password')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'passwordError'\"\n      cxPasswordVisibilitySwitch\n    />\n    <cx-form-errors\n      id=\"passwordError\"\n      [control]=\"form.get('password')\"\n    ></cx-form-errors>\n  </label>\n\n  <a [routerLink]=\"{ cxRoute: 'forgotPassword' } | cxUrl\" class=\"btn-link\">\n    {{ 'loginForm.forgotPassword' | cxTranslate }}\n  </a>\n\n  <button\n    type=\"submit\"\n    class=\"btn btn-block btn-primary\"\n    [disabled]=\"form.disabled\"\n  >\n    {{ 'loginForm.signIn' | cxTranslate }}\n  </button>\n</form>\n" }]
        }], propDecorators: { style: [{
                type: HostBinding,
                args: ['class.user-form']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OneTimePasswordLoginFormModeule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OneTimePasswordLoginFormModeule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OneTimePasswordLoginFormModeule, imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            FormErrorsModule,
            SpinnerModule,
            PasswordVisibilityToggleModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            OneTimePasswordLoginFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OneTimePasswordLoginFormModeule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    ReturningCustomerOTPLoginComponent: {
                        component: OneTimePasswordLoginFormComponent,
                        guards: [NotAuthGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            FormErrorsModule,
            SpinnerModule,
            PasswordVisibilityToggleModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            OneTimePasswordLoginFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OneTimePasswordLoginFormModeule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        FormErrorsModule,
                        SpinnerModule,
                        PasswordVisibilityToggleModule,
                        FeaturesConfigModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        OneTimePasswordLoginFormComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                ReturningCustomerOTPLoginComponent: {
                                    component: OneTimePasswordLoginFormComponent,
                                    guards: [NotAuthGuard],
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class VerificationTokenDialogComponent {
    constructor(launchDialogService) {
        this.launchDialogService = launchDialogService;
        this.VERIFICATION_TOKEN_DIALOG_ACTION = VERIFICATION_TOKEN_DIALOG_ACTION;
        this.focusConfig = {
            trap: true,
            block: true,
            autofocus: true,
            focusOnEscape: true,
        };
    }
    closeModal(reason) {
        this.launchDialogService.closeDialog(reason);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: VerificationTokenDialogComponent, deps: [{ token: i1$3.LaunchDialogService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: VerificationTokenDialogComponent, isStandalone: true, selector: "cx-verification-token-dialog", ngImport: i0, template: "<div\n  class=\"cx-verification-token-dialog cx-modal-container cx-asm-dialog\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"closeModal(VERIFICATION_TOKEN_DIALOG_ACTION.OK)\"\n  aria-labelledby=\"verification-token-dialog-title\"\n>\n  <div class=\"cx-modal-content\">\n    <!-- Modal Header -->\n    <div class=\"cx-dialog-header modal-header\">\n      <div>\n        <span class=\"info-icon\">\n          <cx-icon type=\"INFO\"></cx-icon>\n        </span>\n        <h3 id=\"verification-token-dialog-title\" class=\"title modal-title\">\n          {{ 'verificationTokenDialog.title' | cxTranslate }}\n        </h3>\n      </div>\n    </div>\n    <hr class=\"spliter\" />\n\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\">\n      <div class=\"cx-dialog-row\">\n        <div class=\"cx-dialog-item\">\n          {{ 'verificationTokenDialog.noReceiveCode' | cxTranslate }}\n        </div>\n        <div class=\"cx-dialog-item\">\n          {{ 'verificationTokenDialog.contentLine1' | cxTranslate }}\n        </div>\n        <div class=\"cx-dialog-item\">\n          {{ 'verificationTokenDialog.contentLine2' | cxTranslate }}\n        </div>\n        <div class=\"cx-dialog-item\">\n          {{ 'verificationTokenDialog.contentLine3' | cxTranslate }}\n        </div>\n      </div>\n    </div>\n\n    <!-- Modal Footer -->\n    <div class=\"cx-dialog-footer modal-footer\">\n      <button\n        (click)=\"closeModal(VERIFICATION_TOKEN_DIALOG_ACTION.OK)\"\n        [attr.aria-label]=\"'verificationTokenDialog.ok' | cxTranslate\"\n        class=\"btn btn-primary\"\n        type=\"button\"\n      >\n        {{ 'verificationTokenDialog.close' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: VerificationTokenDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-verification-token-dialog', imports: [FocusDirective, IconComponent, TranslatePipe], template: "<div\n  class=\"cx-verification-token-dialog cx-modal-container cx-asm-dialog\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"closeModal(VERIFICATION_TOKEN_DIALOG_ACTION.OK)\"\n  aria-labelledby=\"verification-token-dialog-title\"\n>\n  <div class=\"cx-modal-content\">\n    <!-- Modal Header -->\n    <div class=\"cx-dialog-header modal-header\">\n      <div>\n        <span class=\"info-icon\">\n          <cx-icon type=\"INFO\"></cx-icon>\n        </span>\n        <h3 id=\"verification-token-dialog-title\" class=\"title modal-title\">\n          {{ 'verificationTokenDialog.title' | cxTranslate }}\n        </h3>\n      </div>\n    </div>\n    <hr class=\"spliter\" />\n\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\">\n      <div class=\"cx-dialog-row\">\n        <div class=\"cx-dialog-item\">\n          {{ 'verificationTokenDialog.noReceiveCode' | cxTranslate }}\n        </div>\n        <div class=\"cx-dialog-item\">\n          {{ 'verificationTokenDialog.contentLine1' | cxTranslate }}\n        </div>\n        <div class=\"cx-dialog-item\">\n          {{ 'verificationTokenDialog.contentLine2' | cxTranslate }}\n        </div>\n        <div class=\"cx-dialog-item\">\n          {{ 'verificationTokenDialog.contentLine3' | cxTranslate }}\n        </div>\n      </div>\n    </div>\n\n    <!-- Modal Footer -->\n    <div class=\"cx-dialog-footer modal-footer\">\n      <button\n        (click)=\"closeModal(VERIFICATION_TOKEN_DIALOG_ACTION.OK)\"\n        [attr.aria-label]=\"'verificationTokenDialog.ok' | cxTranslate\"\n        class=\"btn btn-primary\"\n        type=\"button\"\n      >\n        {{ 'verificationTokenDialog.close' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1$3.LaunchDialogService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultVerificationTokenLayoutConfig = {
    launch: {
        [LAUNCH_CALLER.ACCOUNT_VERIFICATION_TOKEN]: {
            inlineRoot: true,
            component: VerificationTokenDialogComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const globalMsgShowTime = 10000;
class VerificationTokenFormComponentService {
    get csrf() {
        return this.csrfStateService.get();
    }
    constructor() {
        this.authConfigService = inject(AuthConfigService);
        this.featureToggles = inject(FeatureToggles);
        this.auth = inject(AuthService);
        this.csrfStateService = inject(CsrfStateService);
        this.winRef = inject(WindowRef);
        this.globalMessage = inject(GlobalMessageService);
        this.verificationTokenFacade = inject(VerificationTokenFacade);
        this.busy$ = new BehaviorSubject(false);
        this.isUpdating$ = this.busy$.pipe(tap((state) => {
            state === true ? this.form.disable() : this.form.enable();
        }));
        this.form = new UntypedFormGroup({
            tokenId: new UntypedFormControl('', [Validators.required]),
            tokenCode: new UntypedFormControl('', [Validators.required]),
        });
        if (this.featureToggles.authorizationCodeFlowByDefault) {
            this.initCustomLogin();
        }
    }
    login(nativeForm) {
        if (!this.form.valid) {
            this.form.markAllAsTouched();
            return;
        }
        if (this.featureToggles.authorizationCodeFlowByDefault && nativeForm) {
            this.winRef.localStorage?.setItem(OAUTH_REDIRECT_FLOW_KEY, 'true');
            nativeForm.submit();
            this.busy$.next(true);
        }
        else {
            this.busy$.next(true);
            from(this.auth.otpLoginWithCredentials(this.form.value.tokenId, this.form.value.tokenCode))
                .pipe(withLatestFrom(this.auth.isUserLoggedIn()), tap(([_, isLoggedIn]) => this.onSuccess(isLoggedIn)))
                .subscribe();
        }
    }
    displayMessage(key, params) {
        this.globalMessage.add({
            key: key,
            params,
        }, GlobalMessageType.MSG_TYPE_CONFIRMATION, globalMsgShowTime);
    }
    createVerificationToken(loginId, password, purpose) {
        return this.verificationTokenFacade.createVerificationToken({
            loginId,
            password,
            purpose,
        });
    }
    onSuccess(isLoggedIn) {
        if (isLoggedIn) {
            // We want to remove error messages on successful login (primary the bad
            // username/password combination)
            this.globalMessage.remove(GlobalMessageType.MSG_TYPE_ERROR);
            this.form.reset();
        }
        this.busy$.next(false);
    }
    initCustomLogin() {
        this.method = 'POST';
        this.action = this.authConfigService?.getCustomLoginFormEndpoint();
        this.form.addControl('csrf', new FormControl('', Validators.required));
        this.form.get('csrf')?.setValue(this.csrf?.token);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: VerificationTokenFormComponentService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: VerificationTokenFormComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: VerificationTokenFormComponentService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class VerificationTokenFormComponent {
    constructor() {
        this.featureToggles = inject(FeatureToggles);
        this.service = inject(VerificationTokenFormComponentService);
        this.launchDialogService = inject(LaunchDialogService);
        this.cdr = inject(ChangeDetectorRef);
        this.routingService = inject(RoutingService);
        this.winRef = inject(WindowRef);
        this.waitTime = 60;
        this.form = this.service.form;
        this.isUpdating$ = this.service.isUpdating$;
        this.style = true;
        this.isResendDisabled = true;
        this.waitTimeForRateLimit = 300;
        this.csrf = this.service.csrf;
        this.action = this.service.action;
        this.method = this.service.method;
    }
    ngOnInit() {
        if (history.state) {
            this.tokenId = history.state['tokenId'];
            this.password = history.state['password'];
            this.target = history.state['loginId'];
            this.errorStatus = history.state['errorStatus'];
            history.pushState({
                tokenId: '',
                password: '',
                loginId: '',
                errorStatus: '',
            }, 'verifyToken');
            if (this.errorStatus === 400) {
                this.upToRateLimit = true;
                this.tokenId = 'invalidTokenId';
                this.startRateLimitWaitTimeInterval();
            }
            else if (!this.target || !this.password || !this.tokenId) {
                this.service.displayMessage('verificationTokenForm.needInputCredentials', {});
                this.routingService.go(this.featureToggles.authorizationCodeFlowByDefault
                    ? { cxRoute: 'login' }
                    : ['/login']);
            }
            else {
                this.startWaitTimeInterval();
                this.service.displayMessage('verificationTokenForm.createVerificationToken', { target: this.target });
            }
        }
    }
    onSubmit() {
        this.service.login(this.verificationTokenForm?.nativeElement);
    }
    resendOTP() {
        this.isResendDisabled = true;
        this.resendLink.nativeElement.tabIndex = -1;
        this.resendLink.nativeElement.blur();
        this.waitTime = 60;
        this.startWaitTimeInterval();
        this.service
            .createVerificationToken(this.target, this.password, ONE_TIME_PASSWORD_LOGIN_PURPOSE)
            .subscribe({
            next: (result) => (this.tokenId = result.tokenId),
            complete: () => this.service.displayMessage('verificationTokenForm.createVerificationToken', { target: this.target }),
        });
    }
    startWaitTimeInterval() {
        const interval = setInterval(() => {
            this.waitTime--;
            this.cdr.detectChanges();
            if (this.waitTime <= 0) {
                clearInterval(interval);
                this.isResendDisabled = false;
                this.resendLink.nativeElement.tabIndex = 0;
                this.cdr.detectChanges();
            }
        }, 1000);
    }
    openInfoDailog() {
        this.launchDialogService.openDialogAndSubscribe(LAUNCH_CALLER.ACCOUNT_VERIFICATION_TOKEN, this.element);
    }
    onOpenInfoDailogKeyDown(event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.openInfoDailog();
        }
    }
    startRateLimitWaitTimeInterval() {
        const interval = setInterval(() => {
            this.waitTimeForRateLimit--;
            this.cdr.detectChanges();
            if (this.waitTimeForRateLimit <= 0) {
                clearInterval(interval);
                this.upToRateLimit = false;
                this.isResendDisabled = false;
                this.cdr.detectChanges();
            }
        }, 1000);
    }
    goBack() {
        this.winRef.sessionStorage?.setItem(OTP_LOGIN_STATE_STORAGE_KEY, JSON.stringify({ loginId: this.target }));
        this.routingService.go({ cxRoute: 'login' });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: VerificationTokenFormComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: VerificationTokenFormComponent, isStandalone: true, selector: "cx-verification-token-form", host: { properties: { "class.user-form": "this.style" } }, viewQueries: [{ propertyName: "element", first: true, predicate: ["noReceiveCodeLink"], descendants: true }, { propertyName: "resendLink", first: true, predicate: ["resendLink"], descendants: true }, { propertyName: "verificationTokenForm", first: true, predicate: ["verificationTokenForm"], descendants: true }], ngImport: i0, template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"></cx-spinner>\n\n<form\n  (ngSubmit)=\"onSubmit()\"\n  [formGroup]=\"form\"\n  [attr.method]=\"method\"\n  [attr.action]=\"action\"\n  #verificationTokenForm\n>\n  <cx-form-required-legend />\n  <label>\n    <span class=\"label-content\">\n      {{ 'verificationTokenForm.verificationCode.label' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      class=\"form-control\"\n      formControlName=\"tokenCode\"\n      name=\"password\"\n      [placeholder]=\"\n        'verificationTokenForm.verificationCode.placeholder' | cxTranslate\n      \"\n      aria-describedby=\"tokenInputHint\"\n    />\n    <cx-form-errors [control]=\"form.get('tokenCode')\"></cx-form-errors>\n    <div class=\"rate-limit-error-display\" *ngIf=\"upToRateLimit\">\n      {{\n        'register.rateLimitForRegistrationMessage'\n          | cxTranslate: { seconds: waitTimeForRateLimit }\n      }}\n    </div>\n  </label>\n  <span id=\"tokenInputHint\" class=\"cx-visually-hidden\">\n    {{ 'verificationTokenForm.tokenInputHint' | cxTranslate }}\n  </span>\n\n  <input\n    type=\"hidden\"\n    formControlName=\"tokenId\"\n    name=\"username\"\n    [(ngModel)]=\"tokenId\"\n  />\n\n  <ng-container *cxFeature=\"'authorizationCodeFlowByDefault'\">\n    <input\n      *ngIf=\"csrf\"\n      formControlName=\"csrf\"\n      type=\"hidden\"\n      [name]=\"csrf.parameterName\"\n    />\n  </ng-container>\n\n  <div *ngIf=\"!upToRateLimit\" class=\"resend-link-text\">\n    <div class=\"left-text\">\n      <span role=\"timer\" aria-live=\"polite\" aria-atomic=\"true\">\n        <a\n          role=\"button\"\n          tabindex=\"-1\"\n          #resendLink\n          (keydown.enter)=\"resendOTP()\"\n          (keydown.space)=\"resendOTP()\"\n          (click)=\"resendOTP()\"\n          class=\"btn-link\"\n          [ngClass]=\"{ 'disabled-link': isResendDisabled }\"\n        >\n          {{ 'verificationTokenForm.resend' | cxTranslate }}\n        </a>\n        <ng-container *ngIf=\"isResendDisabled\">\n          {{\n            'verificationTokenForm.sendRateLime'\n              | cxTranslate: { waitTime: waitTime }\n          }}\n        </ng-container>\n      </span>\n    </div>\n    <div class=\"right-text\">\n      <a\n        role=\"button\"\n        tabindex=\"0\"\n        #noReceiveCodeLink\n        (keydown)=\"onOpenInfoDailogKeyDown($event)\"\n        (click)=\"openInfoDailog()\"\n        class=\"btn-link\"\n      >\n        {{ 'verificationTokenForm.noReceiveCode' | cxTranslate }}\n      </a>\n    </div>\n  </div>\n\n  <div class=\"verify-container\">\n    <button\n      type=\"submit\"\n      class=\"btn btn-block btn-primary\"\n      [disabled]=\"form.disabled\"\n    >\n      {{ 'verificationTokenForm.verify' | cxTranslate }}\n    </button>\n    <button\n      type=\"button\"\n      (click)=\"goBack()\"\n      class=\"btn btn-block btn-secondary btn-register\"\n    >\n      {{ 'verificationTokenForm.back' | cxTranslate }}\n    </button>\n  </div>\n</form>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: FeatureDirective, selector: "[cxFeature]", inputs: ["cxFeature"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: VerificationTokenFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-verification-token-form', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        SpinnerComponent,
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredLegendComponent,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        FeatureDirective,
                        NgClass,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"></cx-spinner>\n\n<form\n  (ngSubmit)=\"onSubmit()\"\n  [formGroup]=\"form\"\n  [attr.method]=\"method\"\n  [attr.action]=\"action\"\n  #verificationTokenForm\n>\n  <cx-form-required-legend />\n  <label>\n    <span class=\"label-content\">\n      {{ 'verificationTokenForm.verificationCode.label' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      class=\"form-control\"\n      formControlName=\"tokenCode\"\n      name=\"password\"\n      [placeholder]=\"\n        'verificationTokenForm.verificationCode.placeholder' | cxTranslate\n      \"\n      aria-describedby=\"tokenInputHint\"\n    />\n    <cx-form-errors [control]=\"form.get('tokenCode')\"></cx-form-errors>\n    <div class=\"rate-limit-error-display\" *ngIf=\"upToRateLimit\">\n      {{\n        'register.rateLimitForRegistrationMessage'\n          | cxTranslate: { seconds: waitTimeForRateLimit }\n      }}\n    </div>\n  </label>\n  <span id=\"tokenInputHint\" class=\"cx-visually-hidden\">\n    {{ 'verificationTokenForm.tokenInputHint' | cxTranslate }}\n  </span>\n\n  <input\n    type=\"hidden\"\n    formControlName=\"tokenId\"\n    name=\"username\"\n    [(ngModel)]=\"tokenId\"\n  />\n\n  <ng-container *cxFeature=\"'authorizationCodeFlowByDefault'\">\n    <input\n      *ngIf=\"csrf\"\n      formControlName=\"csrf\"\n      type=\"hidden\"\n      [name]=\"csrf.parameterName\"\n    />\n  </ng-container>\n\n  <div *ngIf=\"!upToRateLimit\" class=\"resend-link-text\">\n    <div class=\"left-text\">\n      <span role=\"timer\" aria-live=\"polite\" aria-atomic=\"true\">\n        <a\n          role=\"button\"\n          tabindex=\"-1\"\n          #resendLink\n          (keydown.enter)=\"resendOTP()\"\n          (keydown.space)=\"resendOTP()\"\n          (click)=\"resendOTP()\"\n          class=\"btn-link\"\n          [ngClass]=\"{ 'disabled-link': isResendDisabled }\"\n        >\n          {{ 'verificationTokenForm.resend' | cxTranslate }}\n        </a>\n        <ng-container *ngIf=\"isResendDisabled\">\n          {{\n            'verificationTokenForm.sendRateLime'\n              | cxTranslate: { waitTime: waitTime }\n          }}\n        </ng-container>\n      </span>\n    </div>\n    <div class=\"right-text\">\n      <a\n        role=\"button\"\n        tabindex=\"0\"\n        #noReceiveCodeLink\n        (keydown)=\"onOpenInfoDailogKeyDown($event)\"\n        (click)=\"openInfoDailog()\"\n        class=\"btn-link\"\n      >\n        {{ 'verificationTokenForm.noReceiveCode' | cxTranslate }}\n      </a>\n    </div>\n  </div>\n\n  <div class=\"verify-container\">\n    <button\n      type=\"submit\"\n      class=\"btn btn-block btn-primary\"\n      [disabled]=\"form.disabled\"\n    >\n      {{ 'verificationTokenForm.verify' | cxTranslate }}\n    </button>\n    <button\n      type=\"button\"\n      (click)=\"goBack()\"\n      class=\"btn btn-block btn-secondary btn-register\"\n    >\n      {{ 'verificationTokenForm.back' | cxTranslate }}\n    </button>\n  </div>\n</form>\n" }]
        }], ctorParameters: () => [], propDecorators: { style: [{
                type: HostBinding,
                args: ['class.user-form']
            }], element: [{
                type: ViewChild,
                args: ['noReceiveCodeLink']
            }], resendLink: [{
                type: ViewChild,
                args: ['resendLink']
            }], verificationTokenForm: [{
                type: ViewChild,
                args: ['verificationTokenForm']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class VerificationTokenFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: VerificationTokenFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: VerificationTokenFormModule, imports: [CommonModule,
            FormsModule,
            KeyboardFocusModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            IconModule,
            I18nModule,
            FormErrorsModule,
            SpinnerModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            VerificationTokenFormComponent,
            VerificationTokenDialogComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: VerificationTokenFormModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    VerifyOTPTokenComponent: {
                        component: VerificationTokenFormComponent,
                        guards: [NotAuthGuard, CustomLoginGuard],
                        providers: [
                            {
                                provide: VerificationTokenFormComponentService,
                                useClass: VerificationTokenFormComponentService,
                                deps: [
                                    AuthService,
                                    GlobalMessageService,
                                    VerificationTokenFacade,
                                    WindowRef,
                                ],
                            },
                        ],
                    },
                },
            }),
            provideDefaultConfig(defaultVerificationTokenLayoutConfig),
        ], imports: [CommonModule,
            FormsModule,
            KeyboardFocusModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            IconModule,
            I18nModule,
            FormErrorsModule,
            SpinnerModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            VerificationTokenFormComponent,
            VerificationTokenDialogComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: VerificationTokenFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        FormsModule,
                        KeyboardFocusModule,
                        ReactiveFormsModule,
                        RouterModule,
                        UrlModule,
                        IconModule,
                        I18nModule,
                        FormErrorsModule,
                        SpinnerModule,
                        FeaturesConfigModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        VerificationTokenFormComponent,
                        VerificationTokenDialogComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                VerifyOTPTokenComponent: {
                                    component: VerificationTokenFormComponent,
                                    guards: [NotAuthGuard, CustomLoginGuard],
                                    providers: [
                                        {
                                            provide: VerificationTokenFormComponentService,
                                            useClass: VerificationTokenFormComponentService,
                                            deps: [
                                                AuthService,
                                                GlobalMessageService,
                                                VerificationTokenFacade,
                                                WindowRef,
                                            ],
                                        },
                                    ],
                                },
                            },
                        }),
                        provideDefaultConfig(defaultVerificationTokenLayoutConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAccountComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: UserAccountComponentsModule, imports: [LoginModule,
            LoginFormModule,
            VerificationTokenFormModule,
            LoginRegisterModule,
            MyAccountV2UserModule,
            OneTimePasswordLoginFormModeule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountComponentsModule, imports: [LoginModule,
            LoginFormModule,
            VerificationTokenFormModule,
            LoginRegisterModule,
            MyAccountV2UserModule,
            OneTimePasswordLoginFormModeule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        LoginModule,
                        LoginFormModule,
                        VerificationTokenFormModule,
                        LoginRegisterModule,
                        MyAccountV2UserModule,
                        OneTimePasswordLoginFormModeule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { LoginAsGuestGuard, LoginComponent, LoginFormComponent, LoginFormComponentService, LoginFormModule, LoginModule, LoginRegisterB2BComponent, LoginRegisterComponent, LoginRegisterModule, MyAccountV2UserComponent, MyAccountV2UserModule, OneTimePasswordLoginFormComponent, OneTimePasswordLoginFormModeule, UserAccountComponentsModule, VerificationTokenFormComponent, VerificationTokenFormComponentService, VerificationTokenFormModule };
//# sourceMappingURL=spartacus-user-account-components.mjs.map
