import { NgIf, AsyncPipe, CommonModule, NgFor, NgTemplateOutlet, NgClass } from '@angular/common';
import * as i0 from '@angular/core';
import { HostListener, ChangeDetectionStrategy, Component, inject, Optional, ViewChild, NgModule, Injectable, InjectionToken, ChangeDetectorRef, EventEmitter, Output, Input } from '@angular/core';
import { RouterModule, RouterLink } from '@angular/router';
import * as i2 from '@spartacus/core';
import { GlobalMessageType, TranslatePipe, RoutingService, UrlModule, I18nModule, provideDefaultConfig, AuthGuard, OAuthFlow, FeaturesConfigModule, AuthConfigService, GlobalMessageService, NotAuthGuard, FeatureToggles, useFeatureStyles, UrlPipe, HttpErrorModel, PageMetaService, FeatureDirective, AuthService, AuthRedirectService, provideDefaultConfigFactory, LanguageService, HierarchicalAddressConfig, UserAddressService, AnonymousConsentsService, AnonymousConsentsConfig, ClientAuthenticationTokenService } from '@spartacus/core';
import * as i3 from '@spartacus/storefront';
import { ICON_TYPE, FocusDirective, IconComponent, SpinnerComponent, DIALOG_TYPE, LAUNCH_CALLER, IconModule, SpinnerModule, KeyboardFocusModule, BtnLikeLinkModule, CustomFormValidators, FormRequiredLegendComponent, FormRequiredAsterisksComponent, FormErrorsComponent, FormErrorsModule, sortTitles, NgSelectA11yDirective, PasswordVisibilityToggleDirective, CaptchaComponent, CaptchaModule, NgSelectA11yModule, PasswordVisibilityToggleModule, getPageTitle, BtnLikeLinkDirective, MessageComponent, MessageComponentModule, TruncationTooltipDirective, getAddressNumbers, CardComponent, CardModule, PageSlotModule, LaunchDialogService } from '@spartacus/storefront';
import { BehaviorSubject, Subscription, combineLatest, Subject, of, map as map$1, filter as filter$1 } from 'rxjs';
import { first, take, tap, map, filter, switchMap, skip, pairwise, withLatestFrom } from 'rxjs/operators';
import * as i1 from '@spartacus/user/profile/root';
import { UserPasswordFacade, UserRegisterFacade, UserProfileFacade, UserEmailFacade } from '@spartacus/user/profile/root';
import * as i2$1 from '@angular/forms';
import { UntypedFormGroup, UntypedFormControl, Validators, FormsModule, ReactiveFormsModule, UntypedFormBuilder } from '@angular/forms';
import { NgSelectComponent, NgSelectModule, NgOptionComponent } from '@ng-select/ng-select';
import { VerificationTokenFacade } from '@spartacus/user/account/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CloseAccountModalComponent {
    handleClick(event) {
        if (event.target.tagName === this.el.nativeElement.tagName) {
            this.dismissModal('Cross click');
        }
    }
    constructor(authService, globalMessageService, routingService, translationService, userProfile, launchDialogService, el) {
        this.authService = authService;
        this.globalMessageService = globalMessageService;
        this.routingService = routingService;
        this.translationService = translationService;
        this.userProfile = userProfile;
        this.launchDialogService = launchDialogService;
        this.el = el;
        this.iconTypes = ICON_TYPE;
        this.focusConfig = {
            trap: true,
            block: true,
            autofocus: 'button',
            focusOnEscape: true,
        };
        this.loading$ = new BehaviorSubject(false);
    }
    get isLoading$() {
        return this.loading$.asObservable();
    }
    ngOnInit() {
        this.isLoggedIn$ = this.authService.isUserLoggedIn();
    }
    onSuccess() {
        this.dismissModal('Success');
        this.translationService
            .translate('closeAccount.accountClosedSuccessfully')
            .pipe(first())
            .subscribe((text) => {
            this.globalMessageService.add(text, GlobalMessageType.MSG_TYPE_CONFIRMATION);
        });
        this.authService.coreLogout().then(() => {
            this.routingService.go({ cxRoute: 'home' });
        });
    }
    onError() {
        this.dismissModal('Error');
        this.translationService
            .translate('closeAccount.accountClosedFailure')
            .pipe(first())
            .subscribe((text) => {
            this.globalMessageService.add(text, GlobalMessageType.MSG_TYPE_ERROR);
        });
    }
    dismissModal(reason) {
        this.launchDialogService.closeDialog(reason);
    }
    closeAccount() {
        this.loading$.next(true);
        this.userProfile.close().subscribe({
            next: () => {
                this.onSuccess();
                this.loading$.next(false);
            },
            error: () => {
                this.onError();
                this.loading$.next(false);
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CloseAccountModalComponent, deps: [{ token: i2.AuthService }, { token: i2.GlobalMessageService }, { token: i2.RoutingService }, { token: i2.TranslationService }, { token: i1.UserProfileFacade }, { token: i3.LaunchDialogService }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CloseAccountModalComponent, isStandalone: true, selector: "cx-close-account-modal", host: { listeners: { "click": "handleClick($event)" } }, ngImport: i0, template: "<ng-container *ngIf=\"isLoggedIn$ | async\">\n  <div\n    class=\"modal-dialog modal-dialog-centered cx-close-account-modal\"\n    [cxFocus]=\"focusConfig\"\n    (esc)=\"dismissModal('Escape click')\"\n  >\n    <div class=\"modal-content cx-close-account-modal-container\">\n      <div class=\"cx-close-account-modal-header cx-modal-header\">\n        <h3 class=\"cx-close-account-modal-title\">\n          {{ 'closeAccount.confirmAccountClosure' | cxTranslate }}\n        </h3>\n        <button\n          type=\"button\"\n          class=\"close\"\n          title=\"{{ 'common.close' | cxTranslate }}\"\n          [attr.aria-label]=\"'common.close' | cxTranslate\"\n          (click)=\"dismissModal('Cross click')\"\n        >\n          <span aria-hidden=\"true\">\n            <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n          </span>\n        </button>\n      </div>\n\n      <div *ngIf=\"isLoading$ | async; else loaded\">\n        <div class=\"cx-spinner\">\n          <cx-spinner> </cx-spinner>\n        </div>\n      </div>\n\n      <ng-template #loaded>\n        <div class=\"modal-body\">\n          <p class=\"cx-confirmation\">\n            {{ 'closeAccount.confirmAccountClosureMessage' | cxTranslate }}\n          </p>\n        </div>\n        <div class=\"cx-close-account-modal-footer cx-modal-footer\">\n          <button class=\"btn btn-primary\" (click)=\"closeAccount()\">\n            {{ 'closeAccount.closeMyAccount' | cxTranslate }}\n          </button>\n          <button\n            (click)=\"dismissModal('Cancel')\"\n            class=\"btn btn-block btn-secondary\"\n          >\n            {{ 'common.cancel' | cxTranslate }}\n          </button>\n        </div>\n      </ng-template>\n    </div>\n  </div>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CloseAccountModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-close-account-modal', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        FocusDirective,
                        IconComponent,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<ng-container *ngIf=\"isLoggedIn$ | async\">\n  <div\n    class=\"modal-dialog modal-dialog-centered cx-close-account-modal\"\n    [cxFocus]=\"focusConfig\"\n    (esc)=\"dismissModal('Escape click')\"\n  >\n    <div class=\"modal-content cx-close-account-modal-container\">\n      <div class=\"cx-close-account-modal-header cx-modal-header\">\n        <h3 class=\"cx-close-account-modal-title\">\n          {{ 'closeAccount.confirmAccountClosure' | cxTranslate }}\n        </h3>\n        <button\n          type=\"button\"\n          class=\"close\"\n          title=\"{{ 'common.close' | cxTranslate }}\"\n          [attr.aria-label]=\"'common.close' | cxTranslate\"\n          (click)=\"dismissModal('Cross click')\"\n        >\n          <span aria-hidden=\"true\">\n            <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n          </span>\n        </button>\n      </div>\n\n      <div *ngIf=\"isLoading$ | async; else loaded\">\n        <div class=\"cx-spinner\">\n          <cx-spinner> </cx-spinner>\n        </div>\n      </div>\n\n      <ng-template #loaded>\n        <div class=\"modal-body\">\n          <p class=\"cx-confirmation\">\n            {{ 'closeAccount.confirmAccountClosureMessage' | cxTranslate }}\n          </p>\n        </div>\n        <div class=\"cx-close-account-modal-footer cx-modal-footer\">\n          <button class=\"btn btn-primary\" (click)=\"closeAccount()\">\n            {{ 'closeAccount.closeMyAccount' | cxTranslate }}\n          </button>\n          <button\n            (click)=\"dismissModal('Cancel')\"\n            class=\"btn btn-block btn-secondary\"\n          >\n            {{ 'common.cancel' | cxTranslate }}\n          </button>\n        </div>\n      </ng-template>\n    </div>\n  </div>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: i2.AuthService }, { type: i2.GlobalMessageService }, { type: i2.RoutingService }, { type: i2.TranslationService }, { type: i1.UserProfileFacade }, { type: i3.LaunchDialogService }, { type: i0.ElementRef }], propDecorators: { handleClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultCloseDialogModalLayoutConfig = {
    launch: {
        CLOSE_ACCOUNT: {
            inline: true,
            component: CloseAccountModalComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CloseAccountComponent {
    constructor(launchDialogService, vcr) {
        this.launchDialogService = launchDialogService;
        this.vcr = vcr;
        this.routingService = inject(RoutingService, {
            optional: true,
        });
    }
    openModal() {
        const dialog = this.launchDialogService.openDialog(LAUNCH_CALLER.CLOSE_ACCOUNT, this.element, this.vcr);
        dialog?.pipe(take(1)).subscribe();
    }
    navigateTo(cxRoute) {
        this.routingService?.go({ cxRoute });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CloseAccountComponent, deps: [{ token: i3.LaunchDialogService }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CloseAccountComponent, isStandalone: true, selector: "cx-close-account", viewQueries: [{ propertyName: "element", first: true, predicate: ["element"], descendants: true }], ngImport: i0, template: "<div class=\"col-lg-8 col-md-9\">\n  <div class=\"row cx-btn-group\">\n    <div class=\"col-sm-6\">\n      <button class=\"btn btn-block btn-secondary\" (click)=\"navigateTo('home')\">\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n    </div>\n    <div class=\"col-sm-6\">\n      <button #element class=\"btn btn-block btn-primary\" (click)=\"openModal()\">\n        {{ 'closeAccount.closeMyAccount' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n", dependencies: [{ kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CloseAccountComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-close-account', changeDetection: ChangeDetectionStrategy.OnPush, imports: [TranslatePipe], template: "<div class=\"col-lg-8 col-md-9\">\n  <div class=\"row cx-btn-group\">\n    <div class=\"col-sm-6\">\n      <button class=\"btn btn-block btn-secondary\" (click)=\"navigateTo('home')\">\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n    </div>\n    <div class=\"col-sm-6\">\n      <button #element class=\"btn btn-block btn-primary\" (click)=\"openModal()\">\n        {{ 'closeAccount.closeMyAccount' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i3.LaunchDialogService }, { type: i0.ViewContainerRef }], propDecorators: { element: [{
                type: ViewChild,
                args: ['element']
            }], routingService: [{
                type: Optional
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CloseAccountModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CloseAccountModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CloseAccountModule, imports: [CommonModule,
            RouterModule,
            UrlModule,
            I18nModule,
            IconModule,
            SpinnerModule,
            KeyboardFocusModule,
            BtnLikeLinkModule,
            CloseAccountComponent,
            CloseAccountModalComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CloseAccountModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    CloseAccountComponent: {
                        component: CloseAccountComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
            provideDefaultConfig(defaultCloseDialogModalLayoutConfig),
        ], imports: [CommonModule,
            RouterModule,
            UrlModule,
            I18nModule,
            IconModule,
            SpinnerModule,
            KeyboardFocusModule,
            BtnLikeLinkModule,
            CloseAccountModalComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CloseAccountModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        IconModule,
                        SpinnerModule,
                        KeyboardFocusModule,
                        BtnLikeLinkModule,
                        CloseAccountComponent,
                        CloseAccountModalComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                CloseAccountComponent: {
                                    component: CloseAccountComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                        provideDefaultConfig(defaultCloseDialogModalLayoutConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ForgotPasswordComponentService {
    constructor(userPasswordService, routingService, authConfigService, globalMessage) {
        this.userPasswordService = userPasswordService;
        this.routingService = routingService;
        this.authConfigService = authConfigService;
        this.globalMessage = globalMessage;
        this.busy$ = new BehaviorSubject(false);
        this.isUpdating$ = this.busy$.pipe(tap((state) => (state === true ? this.form.disable() : this.form.enable())));
        this.form = new UntypedFormGroup({
            userEmail: new UntypedFormControl('', [
                Validators.required,
                CustomFormValidators.emailValidator,
            ]),
        });
    }
    /**
     * Sends an email to the user to reset the password.
     *
     * When the `ResourceOwnerPasswordFlow` is used, the user is routed
     * to the login page.
     */
    requestEmail() {
        if (!this.form.valid) {
            this.form.markAllAsTouched();
            return;
        }
        this.busy$.next(true);
        this.userPasswordService
            .requestForgotPasswordEmail(this.form.value.userEmail)
            .subscribe({
            next: () => this.onSuccess(),
            error: (error) => this.onError(error),
        });
    }
    onSuccess() {
        this.globalMessage.add({ key: 'forgottenPassword.passwordResetEmailSent' }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
        this.busy$.next(false);
        this.form.reset();
        this.redirect();
    }
    onError(_error) {
        this.busy$.next(false);
    }
    /**
     * Redirects the user back to the login page.
     *
     * This only happens in case of the `ResourceOwnerPasswordFlow` OAuth flow.
     */
    redirect() {
        if (this.authConfigService.getOAuthFlow() ===
            OAuthFlow.ResourceOwnerPasswordFlow) {
            this.routingService.go({ cxRoute: 'login' });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ForgotPasswordComponentService, deps: [{ token: i1.UserPasswordFacade }, { token: i2.RoutingService }, { token: i2.AuthConfigService }, { token: i2.GlobalMessageService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ForgotPasswordComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ForgotPasswordComponentService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.UserPasswordFacade }, { type: i2.RoutingService }, { type: i2.AuthConfigService }, { type: i2.GlobalMessageService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ForgotPasswordComponent {
    constructor(service) {
        this.service = service;
        this.routingService = inject(RoutingService, {
            optional: true,
        });
        this.form = this.service.form;
        this.isUpdating$ = this.service.isUpdating$;
    }
    onSubmit() {
        this.service.requestEmail();
    }
    navigateTo(cxRoute) {
        this.routingService?.go({ cxRoute });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ForgotPasswordComponent, deps: [{ token: ForgotPasswordComponentService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: ForgotPasswordComponent, isStandalone: true, selector: "cx-forgot-password", ngImport: i0, template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"> </cx-spinner>\n<cx-form-required-legend />\n<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n  <label>\n    <span class=\"label-content\"\n      >{{ 'forgottenPassword.emailAddress.label' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      type=\"email\"\n      class=\"form-control\"\n      placeholder=\"{{\n        'forgottenPassword.emailAddress.placeholder' | cxTranslate\n      }}\"\n      formControlName=\"userEmail\"\n      [attr.aria-invalid]=\"\n        form.get('userEmail')?.touched && form.get('userEmail')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'userEmailError'\"\n    />\n\n    <cx-form-errors\n      id=\"userEmailError\"\n      [translationParams]=\"{\n        label: 'forgottenPassword.emailAddress.label' | cxTranslate,\n      }\"\n      [control]=\"form.get('userEmail')\"\n    ></cx-form-errors>\n  </label>\n\n  <button class=\"btn btn-block btn-secondary\" (click)=\"navigateTo('login')\">\n    {{ 'common.cancel' | cxTranslate }}\n  </button>\n  <button class=\"btn btn-block btn-primary\" [disabled]=\"form.disabled\">\n    {{ 'common.submit' | cxTranslate }}\n  </button>\n</form>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ForgotPasswordComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-forgot-password', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        SpinnerComponent,
                        FormRequiredLegendComponent,
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"> </cx-spinner>\n<cx-form-required-legend />\n<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n  <label>\n    <span class=\"label-content\"\n      >{{ 'forgottenPassword.emailAddress.label' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      type=\"email\"\n      class=\"form-control\"\n      placeholder=\"{{\n        'forgottenPassword.emailAddress.placeholder' | cxTranslate\n      }}\"\n      formControlName=\"userEmail\"\n      [attr.aria-invalid]=\"\n        form.get('userEmail')?.touched && form.get('userEmail')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'userEmailError'\"\n    />\n\n    <cx-form-errors\n      id=\"userEmailError\"\n      [translationParams]=\"{\n        label: 'forgottenPassword.emailAddress.label' | cxTranslate,\n      }\"\n      [control]=\"form.get('userEmail')\"\n    ></cx-form-errors>\n  </label>\n\n  <button class=\"btn btn-block btn-secondary\" (click)=\"navigateTo('login')\">\n    {{ 'common.cancel' | cxTranslate }}\n  </button>\n  <button class=\"btn btn-block btn-primary\" [disabled]=\"form.disabled\">\n    {{ 'common.submit' | cxTranslate }}\n  </button>\n</form>\n" }]
        }], ctorParameters: () => [{ type: ForgotPasswordComponentService }], propDecorators: { routingService: [{
                type: Optional
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ForgotPasswordModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ForgotPasswordModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: ForgotPasswordModule, imports: [CommonModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            FormErrorsModule,
            SpinnerModule,
            FeaturesConfigModule,
            BtnLikeLinkModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            ForgotPasswordComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ForgotPasswordModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    ForgotPasswordComponent: {
                        component: ForgotPasswordComponent,
                        guards: [NotAuthGuard],
                        providers: [
                            {
                                provide: ForgotPasswordComponentService,
                                useClass: ForgotPasswordComponentService,
                                deps: [
                                    UserPasswordFacade,
                                    RoutingService,
                                    AuthConfigService,
                                    GlobalMessageService,
                                ],
                            },
                        ],
                    },
                },
            }),
        ], imports: [CommonModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            FormErrorsModule,
            SpinnerModule,
            FeaturesConfigModule,
            BtnLikeLinkModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            ForgotPasswordComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ForgotPasswordModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        FormErrorsModule,
                        SpinnerModule,
                        FeaturesConfigModule,
                        BtnLikeLinkModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        ForgotPasswordComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                ForgotPasswordComponent: {
                                    component: ForgotPasswordComponent,
                                    guards: [NotAuthGuard],
                                    providers: [
                                        {
                                            provide: ForgotPasswordComponentService,
                                            useClass: ForgotPasswordComponentService,
                                            deps: [
                                                UserPasswordFacade,
                                                RoutingService,
                                                AuthConfigService,
                                                GlobalMessageService,
                                            ],
                                        },
                                    ],
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class RegisterComponentService {
    constructor(userRegisterFacade, globalMessageService, fb) {
        this.userRegisterFacade = userRegisterFacade;
        this.globalMessageService = globalMessageService;
        this.fb = fb;
    }
    /**
     * Register a new user.
     *
     * @param user as UserSignUp
     */
    register(user) {
        return this.userRegisterFacade.register(user);
    }
    /**
     * Returns titles that can be used for the user profiles.
     */
    getTitles() {
        return this.userRegisterFacade.getTitles();
    }
    /**
     * Show the message after successful registration.
     */
    postRegisterMessage() {
        this.globalMessageService.add({ key: 'register.postRegisterSuccessMessage' }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
    }
    /**
     * Get if any additional consents needs to be provided during registration
     * In core feature, no additional consents are necessary during registration.
     * In integration scenarios, eg: cdc, this method will be overridden to return
     * necessary cdc consents
     */
    getAdditionalConsents() {
        return [];
    }
    /**
     * Generate form control if any additional consents that needs to be provided during registration
     * In core feature, no additional consents are necessary during registration.
     * In integration scenarios, eg: cdc, this method will be overridden to return
     * form controls for necessary cdc consents
     */
    generateAdditionalConsentsFormControl() {
        return this.fb?.array([]) ?? undefined;
    }
    collectDataFromRegisterForm(formData) {
        const { firstName, lastName, email, password, titleCode } = formData;
        return {
            firstName,
            lastName,
            password,
            titleCode,
            uid: email.toLowerCase(),
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegisterComponentService, deps: [{ token: i1.UserRegisterFacade }, { token: i2.GlobalMessageService }, { token: i2$1.UntypedFormBuilder }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegisterComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegisterComponentService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.UserRegisterFacade }, { type: i2.GlobalMessageService }, { type: i2$1.UntypedFormBuilder }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class RegisterComponent {
    get additionalConsents() {
        return this.registerForm?.get('additionalConsents');
    }
    updateAdditionalConsents(event, index) {
        const { checked } = event.target;
        this.registerForm.value.additionalConsents[index].isConsentGranted =
            checked;
    }
    constructor(globalMessageService, fb, router, anonymousConsentsService, anonymousConsentsConfig, authConfigService, registerComponentService) {
        this.globalMessageService = globalMessageService;
        this.fb = fb;
        this.router = router;
        this.anonymousConsentsService = anonymousConsentsService;
        this.anonymousConsentsConfig = anonymousConsentsConfig;
        this.authConfigService = authConfigService;
        this.registerComponentService = registerComponentService;
        // CXSPA-10916: Remove service with toggle
        this.featureToggles = inject(FeatureToggles);
        this.passwordValidators = this.featureToggles
            .useEnhancedSecurePasswordValidators
            ? [
                ...CustomFormValidators.securePasswordValidators,
                CustomFormValidators.mustEndWithLegalCharacter,
            ]
            : CustomFormValidators.securePasswordValidators;
        this.isLoading$ = new BehaviorSubject(false);
        this.subscription = new Subscription();
        this.registerForm = this.fb.group({
            titleCode: [null],
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            email: ['', [Validators.required, CustomFormValidators.emailValidator]],
            password: ['', [Validators.required, ...this.passwordValidators]],
            passwordconf: ['', Validators.required],
            newsletter: new UntypedFormControl({
                value: false,
                disabled: this.isConsentRequired(),
            }),
            additionalConsents: this.registerComponentService.generateAdditionalConsentsFormControl?.() ??
                this.fb.array([]),
            termsandconditions: [false, Validators.requiredTrue],
            captcha: [false, Validators.requiredTrue],
        }, {
            validators: CustomFormValidators.passwordsMustMatch('password', 'passwordconf'),
        });
        useFeatureStyles('a11yRegistrationTermsAsteriskMargin');
    }
    ngOnInit() {
        this.titles$ = this.registerComponentService.getTitles().pipe(map((titles) => {
            return titles.sort(sortTitles);
        }));
        // TODO: Workaround: allow server for decide is titleCode mandatory (if yes, provide personalized message)
        this.subscription.add(this.globalMessageService
            .get()
            .pipe(filter((messages) => !!Object.keys(messages).length))
            .subscribe((globalMessageEntities) => {
            const messages = globalMessageEntities &&
                globalMessageEntities[GlobalMessageType.MSG_TYPE_ERROR];
            if (messages?.some((message) => message.raw === 'This field is required.')) {
                this.globalMessageService.remove(GlobalMessageType.MSG_TYPE_ERROR);
                this.globalMessageService.add({ key: 'register.titleRequired' }, GlobalMessageType.MSG_TYPE_ERROR);
            }
        }));
        const registerConsent = this.anonymousConsentsConfig?.anonymousConsents?.registerConsent ?? '';
        this.anonymousConsent$ = combineLatest([
            this.anonymousConsentsService.getConsent(registerConsent),
            this.anonymousConsentsService.getTemplate(registerConsent),
        ]).pipe(map(([consent, template]) => {
            return {
                consent,
                template: template?.description ? template.description : '',
            };
        }));
        this.additionalRegistrationConsents =
            this.registerComponentService?.getAdditionalConsents() || [];
        this.subscription.add(
        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
        this.registerForm.get('newsletter').valueChanges.subscribe(() => {
            this.toggleAnonymousConsent();
        }));
    }
    submitForm() {
        if (this.registerForm.valid) {
            this.registerUser();
        }
        else {
            this.registerForm.markAllAsTouched();
        }
    }
    registerUser() {
        this.isLoading$.next(true);
        this.registerComponentService
            .register(this.collectDataFromRegisterForm(this.registerForm.value))
            .subscribe({
            next: () => this.onRegisterUserSuccess(),
            complete: () => this.isLoading$.next(this.authConfigService.getOAuthFlow() ===
                OAuthFlow.AuthorizationCode),
            error: () => this.isLoading$.next(false),
        });
    }
    titleSelected(title) {
        this.registerForm['controls'].titleCode.setValue(title.code);
    }
    collectDataFromRegisterForm(formData) {
        return this.registerComponentService.collectDataFromRegisterForm(formData);
    }
    isConsentGiven(consent) {
        return this.anonymousConsentsService.isConsentGiven(consent);
    }
    isConsentRequired() {
        const requiredConsents = this.anonymousConsentsConfig?.anonymousConsents?.requiredConsents;
        const registerConsent = this.anonymousConsentsConfig?.anonymousConsents?.registerConsent;
        if (requiredConsents && registerConsent) {
            return requiredConsents.includes(registerConsent);
        }
        return false;
    }
    onRegisterUserSuccess() {
        if (this.featureToggles.authorizationCodeFlowByDefault) {
            this.router.go({ cxRoute: 'login' });
        }
        else if (this.authConfigService.getOAuthFlow() ===
            OAuthFlow.ResourceOwnerPasswordFlow) {
            this.router.go('login');
        }
        this.registerComponentService.postRegisterMessage();
    }
    toggleAnonymousConsent() {
        const registerConsent = this.anonymousConsentsConfig?.anonymousConsents?.registerConsent;
        if (registerConsent) {
            if (this.registerForm.get('newsletter')?.value) {
                this.anonymousConsentsService.giveConsent(registerConsent);
            }
            else {
                this.anonymousConsentsService.withdrawConsent(registerConsent);
            }
        }
    }
    /**
     * Triggered via CaptchaComponent when a user confirms captcha
     */
    captchaConfirmed() {
        this.registerForm.get('captcha')?.setValue(true);
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegisterComponent, deps: [{ token: i2.GlobalMessageService }, { token: i2$1.UntypedFormBuilder }, { token: i2.RoutingService }, { token: i2.AnonymousConsentsService }, { token: i2.AnonymousConsentsConfig }, { token: i2.AuthConfigService }, { token: RegisterComponentService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: RegisterComponent, isStandalone: true, selector: "cx-register", host: { attributes: { "ngSkipHydration": "true" } }, ngImport: i0, template: "<section\n  class=\"cx-page-section container\"\n  *ngIf=\"!(isLoading$ | async); else loading\"\n>\n  <div class=\"row justify-content-center\">\n    <div class=\"col-md-6\">\n      <div class=\"cx-section\">\n        <cx-form-required-legend />\n        <form (ngSubmit)=\"submitForm()\" [formGroup]=\"registerForm\">\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\">{{\n                'register.titleOptional' | cxTranslate\n              }}</span>\n              <ng-select\n                [clearable]=\"false\"\n                [items]=\"(titles$ | async) ?? []\"\n                [placeholder]=\"'register.selectTitle' | cxTranslate\"\n                [searchable]=\"false\"\n                bindLabel=\"name\"\n                bindValue=\"code\"\n                formControlName=\"titleCode\"\n                id=\"title-select\"\n                ariaLabelDropdown=\"{{\n                  'common.ngSelectDropdownOptionsList' | cxTranslate\n                }}\"\n                [cxNgSelectA11y]=\"{}\"\n              >\n              </ng-select>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\"\n                >{{ 'register.firstName.label' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <input\n                required=\"true\"\n                class=\"form-control\"\n                type=\"text\"\n                name=\"firstname\"\n                placeholder=\"{{\n                  'register.firstName.placeholder' | cxTranslate\n                }}\"\n                formControlName=\"firstName\"\n                [attr.aria-invalid]=\"\n                  registerForm.get('firstName')?.touched &&\n                  registerForm.get('firstName')?.invalid\n                \"\n                [attr.aria-errormessage]=\"'firstNameError'\"\n              />\n\n              <cx-form-errors\n                id=\"firstNameError\"\n                [translationParams]=\"{\n                  label: 'register.firstName.label' | cxTranslate,\n                }\"\n                [control]=\"registerForm.get('firstName')\"\n              ></cx-form-errors>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\"\n                >{{ 'register.lastName.label' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <input\n                required=\"true\"\n                class=\"form-control\"\n                type=\"text\"\n                name=\"lastname\"\n                placeholder=\"{{\n                  'register.lastName.placeholder' | cxTranslate\n                }}\"\n                formControlName=\"lastName\"\n                [attr.aria-invalid]=\"\n                  registerForm.get('lastName')?.touched &&\n                  registerForm.get('lastName')?.invalid\n                \"\n                [attr.aria-errormessage]=\"'lastNameError'\"\n              />\n\n              <cx-form-errors\n                id=\"lastNameError\"\n                [translationParams]=\"{\n                  label: 'register.lastName.label' | cxTranslate,\n                }\"\n                [control]=\"registerForm.get('lastName')\"\n              ></cx-form-errors>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\"\n                >{{ 'register.emailAddress.label' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <input\n                required=\"true\"\n                class=\"form-control\"\n                type=\"email\"\n                name=\"email\"\n                placeholder=\"{{\n                  'register.emailAddress.placeholder' | cxTranslate\n                }}\"\n                formControlName=\"email\"\n                [attr.aria-invalid]=\"\n                  registerForm.get('email')?.touched &&\n                  registerForm.get('email')?.invalid\n                \"\n                [attr.aria-errormessage]=\"'emailError'\"\n              />\n\n              <cx-form-errors\n                id=\"emailError\"\n                [translationParams]=\"{\n                  label: 'register.emailAddress.label' | cxTranslate,\n                }\"\n                [control]=\"registerForm.get('email')\"\n              ></cx-form-errors>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\"\n                >{{ 'register.password.label' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <input\n                required=\"true\"\n                class=\"form-control\"\n                type=\"password\"\n                name=\"password\"\n                placeholder=\"{{\n                  'register.password.placeholder' | cxTranslate\n                }}\"\n                formControlName=\"password\"\n                [attr.aria-label]=\"\n                  'register.password.placeholder' | cxTranslate\n                \"\n                aria-describedby=\"password-input-hint\"\n                cxPasswordVisibilitySwitch\n              />\n              <p class=\"input-hint\" id=\"password-input-hint\">\n                {{ 'register.passwordMinRequirements' | cxTranslate }}\n              </p>\n\n              <cx-form-errors\n                [translationParams]=\"{\n                  label: 'register.password.label' | cxTranslate,\n                }\"\n                [control]=\"registerForm.get('password')\"\n              ></cx-form-errors>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\"\n                >{{ 'register.confirmPassword.label' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <input\n                required=\"true\"\n                class=\"form-control\"\n                type=\"password\"\n                name=\"confirmpassword\"\n                placeholder=\"{{\n                  'register.confirmPassword.placeholder' | cxTranslate\n                }}\"\n                formControlName=\"passwordconf\"\n                [attr.aria-label]=\"\n                  'register.confirmPassword.placeholder' | cxTranslate\n                \"\n                [attr.aria-invalid]=\"\n                  registerForm.get('passwordconf')?.touched &&\n                  registerForm.get('passwordconf')?.invalid\n                \"\n                [attr.aria-errormessage]=\"'passwordconfError'\"\n                cxPasswordVisibilitySwitch\n              />\n\n              <cx-form-errors\n                id=\"passwordconfError\"\n                [translationParams]=\"{\n                  label: 'register.confirmPassword.label' | cxTranslate,\n                }\"\n                [control]=\"registerForm.get('passwordconf')\"\n              ></cx-form-errors>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <div class=\"form-check\">\n              <ng-container\n                *ngIf=\"anonymousConsent$ | async as anonymousConsent\"\n              >\n                <label *ngIf=\"anonymousConsent.template\">\n                  <input\n                    type=\"checkbox\"\n                    name=\"newsletter\"\n                    class=\"form-check-input\"\n                    formControlName=\"newsletter\"\n                    [checked]=\"isConsentGiven(anonymousConsent.consent)\"\n                  />\n                  <span class=\"form-check-label\">\n                    {{ anonymousConsent.template }}\n                  </span>\n                </label>\n              </ng-container>\n            </div>\n          </div>\n\n          <div\n            formArrayName=\"additionalConsents\"\n            class=\"form-group\"\n            *ngIf=\"additionalRegistrationConsents as consents\"\n          >\n            <div\n              class=\"form-check\"\n              *ngFor=\"let control of additionalConsents.controls; let i = index\"\n              [formGroupName]=\"i\"\n            >\n              <div *ngIf=\"consents[i]?.template?.id as id\">\n                <label>\n                  <input\n                    type=\"checkbox\"\n                    [required]=\"consents[i].required\"\n                    [name]=\"id\"\n                    (change)=\"updateAdditionalConsents($any($event), i)\"\n                    formControlName=\"isConsentGranted\"\n                  />\n                  <span class=\"form-check-label\">\n                    {{ consents[i].template.description }}\n                    <ng-container *ngIf=\"consents[i].required\">\n                      <cx-form-required-asterisks />\n                    </ng-container>\n                  </span>\n                  <cx-form-errors\n                    [control]=\"control.get('isConsentGranted')\"\n                  ></cx-form-errors>\n                </label>\n              </div>\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <div class=\"form-check\">\n              <label>\n                <input\n                  required=\"true\"\n                  type=\"checkbox\"\n                  name=\"termsandconditions\"\n                  formControlName=\"termsandconditions\"\n                  [attr.aria-invalid]=\"\n                    registerForm.get('termsandconditions')?.touched &&\n                    registerForm.get('termsandconditions')?.invalid\n                  \"\n                  [attr.aria-errormessage]=\"'termsandconditionsError'\"\n                />\n                <span class=\"form-check-label\">\n                  <span id=\"confirm-read-label\">\n                    {{ 'register.confirmThatRead' | cxTranslate }}\n                  </span>\n                  <a\n                    [routerLink]=\"{ cxRoute: 'termsAndConditions' } | cxUrl\"\n                    target=\"_blank\"\n                    rel=\"noopener noreferrer\"\n                    aria-describedby=\"confirm-read-label\"\n                  >\n                    {{ 'register.termsAndConditions' | cxTranslate }}\n                  </a>\n                  <cx-form-required-asterisks />\n                </span>\n\n                <cx-form-errors\n                  id=\"termsandconditionsError\"\n                  [translationParams]=\"{\n                    label: 'register.termsAndConditions' | cxTranslate,\n                  }\"\n                  [control]=\"registerForm.get('termsandconditions')\"\n                ></cx-form-errors>\n              </label>\n            </div>\n          </div>\n          <cx-captcha (confirmed)=\"captchaConfirmed()\"></cx-captcha>\n          <cx-form-errors\n            [control]=\"registerForm.get('captcha')\"\n          ></cx-form-errors>\n          <button type=\"submit\" class=\"btn btn-block btn-primary\">\n            {{ 'register.register' | cxTranslate }}\n          </button>\n          <a\n            class=\"cx-login-link btn-link\"\n            [routerLink]=\"{ cxRoute: 'login' } | cxUrl\"\n            >{{ 'register.signIn' | cxTranslate }}</a\n          >\n        </form>\n      </div>\n    </div>\n  </div>\n</section>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\"><cx-spinner></cx-spinner></div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i2$1.CheckboxRequiredValidator, selector: "input[type=checkbox][required][formControlName],input[type=checkbox][required][formControl],input[type=checkbox][required][ngModel]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: i2$1.FormGroupName, selector: "[formGroupName]", inputs: ["formGroupName"] }, { kind: "directive", type: i2$1.FormArrayName, selector: "[formArrayName]", inputs: ["formArrayName"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "directive", type: NgSelectA11yDirective, selector: "[cxNgSelectA11y]", inputs: ["cxNgSelectA11y"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: PasswordVisibilityToggleDirective, selector: "[cxPasswordVisibilitySwitch][type=\"password\"]" }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: CaptchaComponent, selector: "cx-captcha", outputs: ["confirmed"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegisterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-register', host: { ngSkipHydration: 'true' }, imports: [
                        NgIf,
                        FormRequiredLegendComponent,
                        FormsModule,
                        ReactiveFormsModule,
                        NgSelectComponent,
                        NgSelectA11yDirective,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        PasswordVisibilityToggleDirective,
                        NgFor,
                        RouterLink,
                        CaptchaComponent,
                        SpinnerComponent,
                        AsyncPipe,
                        UrlPipe,
                        TranslatePipe,
                    ], template: "<section\n  class=\"cx-page-section container\"\n  *ngIf=\"!(isLoading$ | async); else loading\"\n>\n  <div class=\"row justify-content-center\">\n    <div class=\"col-md-6\">\n      <div class=\"cx-section\">\n        <cx-form-required-legend />\n        <form (ngSubmit)=\"submitForm()\" [formGroup]=\"registerForm\">\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\">{{\n                'register.titleOptional' | cxTranslate\n              }}</span>\n              <ng-select\n                [clearable]=\"false\"\n                [items]=\"(titles$ | async) ?? []\"\n                [placeholder]=\"'register.selectTitle' | cxTranslate\"\n                [searchable]=\"false\"\n                bindLabel=\"name\"\n                bindValue=\"code\"\n                formControlName=\"titleCode\"\n                id=\"title-select\"\n                ariaLabelDropdown=\"{{\n                  'common.ngSelectDropdownOptionsList' | cxTranslate\n                }}\"\n                [cxNgSelectA11y]=\"{}\"\n              >\n              </ng-select>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\"\n                >{{ 'register.firstName.label' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <input\n                required=\"true\"\n                class=\"form-control\"\n                type=\"text\"\n                name=\"firstname\"\n                placeholder=\"{{\n                  'register.firstName.placeholder' | cxTranslate\n                }}\"\n                formControlName=\"firstName\"\n                [attr.aria-invalid]=\"\n                  registerForm.get('firstName')?.touched &&\n                  registerForm.get('firstName')?.invalid\n                \"\n                [attr.aria-errormessage]=\"'firstNameError'\"\n              />\n\n              <cx-form-errors\n                id=\"firstNameError\"\n                [translationParams]=\"{\n                  label: 'register.firstName.label' | cxTranslate,\n                }\"\n                [control]=\"registerForm.get('firstName')\"\n              ></cx-form-errors>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\"\n                >{{ 'register.lastName.label' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <input\n                required=\"true\"\n                class=\"form-control\"\n                type=\"text\"\n                name=\"lastname\"\n                placeholder=\"{{\n                  'register.lastName.placeholder' | cxTranslate\n                }}\"\n                formControlName=\"lastName\"\n                [attr.aria-invalid]=\"\n                  registerForm.get('lastName')?.touched &&\n                  registerForm.get('lastName')?.invalid\n                \"\n                [attr.aria-errormessage]=\"'lastNameError'\"\n              />\n\n              <cx-form-errors\n                id=\"lastNameError\"\n                [translationParams]=\"{\n                  label: 'register.lastName.label' | cxTranslate,\n                }\"\n                [control]=\"registerForm.get('lastName')\"\n              ></cx-form-errors>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\"\n                >{{ 'register.emailAddress.label' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <input\n                required=\"true\"\n                class=\"form-control\"\n                type=\"email\"\n                name=\"email\"\n                placeholder=\"{{\n                  'register.emailAddress.placeholder' | cxTranslate\n                }}\"\n                formControlName=\"email\"\n                [attr.aria-invalid]=\"\n                  registerForm.get('email')?.touched &&\n                  registerForm.get('email')?.invalid\n                \"\n                [attr.aria-errormessage]=\"'emailError'\"\n              />\n\n              <cx-form-errors\n                id=\"emailError\"\n                [translationParams]=\"{\n                  label: 'register.emailAddress.label' | cxTranslate,\n                }\"\n                [control]=\"registerForm.get('email')\"\n              ></cx-form-errors>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\"\n                >{{ 'register.password.label' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <input\n                required=\"true\"\n                class=\"form-control\"\n                type=\"password\"\n                name=\"password\"\n                placeholder=\"{{\n                  'register.password.placeholder' | cxTranslate\n                }}\"\n                formControlName=\"password\"\n                [attr.aria-label]=\"\n                  'register.password.placeholder' | cxTranslate\n                \"\n                aria-describedby=\"password-input-hint\"\n                cxPasswordVisibilitySwitch\n              />\n              <p class=\"input-hint\" id=\"password-input-hint\">\n                {{ 'register.passwordMinRequirements' | cxTranslate }}\n              </p>\n\n              <cx-form-errors\n                [translationParams]=\"{\n                  label: 'register.password.label' | cxTranslate,\n                }\"\n                [control]=\"registerForm.get('password')\"\n              ></cx-form-errors>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\"\n                >{{ 'register.confirmPassword.label' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <input\n                required=\"true\"\n                class=\"form-control\"\n                type=\"password\"\n                name=\"confirmpassword\"\n                placeholder=\"{{\n                  'register.confirmPassword.placeholder' | cxTranslate\n                }}\"\n                formControlName=\"passwordconf\"\n                [attr.aria-label]=\"\n                  'register.confirmPassword.placeholder' | cxTranslate\n                \"\n                [attr.aria-invalid]=\"\n                  registerForm.get('passwordconf')?.touched &&\n                  registerForm.get('passwordconf')?.invalid\n                \"\n                [attr.aria-errormessage]=\"'passwordconfError'\"\n                cxPasswordVisibilitySwitch\n              />\n\n              <cx-form-errors\n                id=\"passwordconfError\"\n                [translationParams]=\"{\n                  label: 'register.confirmPassword.label' | cxTranslate,\n                }\"\n                [control]=\"registerForm.get('passwordconf')\"\n              ></cx-form-errors>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <div class=\"form-check\">\n              <ng-container\n                *ngIf=\"anonymousConsent$ | async as anonymousConsent\"\n              >\n                <label *ngIf=\"anonymousConsent.template\">\n                  <input\n                    type=\"checkbox\"\n                    name=\"newsletter\"\n                    class=\"form-check-input\"\n                    formControlName=\"newsletter\"\n                    [checked]=\"isConsentGiven(anonymousConsent.consent)\"\n                  />\n                  <span class=\"form-check-label\">\n                    {{ anonymousConsent.template }}\n                  </span>\n                </label>\n              </ng-container>\n            </div>\n          </div>\n\n          <div\n            formArrayName=\"additionalConsents\"\n            class=\"form-group\"\n            *ngIf=\"additionalRegistrationConsents as consents\"\n          >\n            <div\n              class=\"form-check\"\n              *ngFor=\"let control of additionalConsents.controls; let i = index\"\n              [formGroupName]=\"i\"\n            >\n              <div *ngIf=\"consents[i]?.template?.id as id\">\n                <label>\n                  <input\n                    type=\"checkbox\"\n                    [required]=\"consents[i].required\"\n                    [name]=\"id\"\n                    (change)=\"updateAdditionalConsents($any($event), i)\"\n                    formControlName=\"isConsentGranted\"\n                  />\n                  <span class=\"form-check-label\">\n                    {{ consents[i].template.description }}\n                    <ng-container *ngIf=\"consents[i].required\">\n                      <cx-form-required-asterisks />\n                    </ng-container>\n                  </span>\n                  <cx-form-errors\n                    [control]=\"control.get('isConsentGranted')\"\n                  ></cx-form-errors>\n                </label>\n              </div>\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <div class=\"form-check\">\n              <label>\n                <input\n                  required=\"true\"\n                  type=\"checkbox\"\n                  name=\"termsandconditions\"\n                  formControlName=\"termsandconditions\"\n                  [attr.aria-invalid]=\"\n                    registerForm.get('termsandconditions')?.touched &&\n                    registerForm.get('termsandconditions')?.invalid\n                  \"\n                  [attr.aria-errormessage]=\"'termsandconditionsError'\"\n                />\n                <span class=\"form-check-label\">\n                  <span id=\"confirm-read-label\">\n                    {{ 'register.confirmThatRead' | cxTranslate }}\n                  </span>\n                  <a\n                    [routerLink]=\"{ cxRoute: 'termsAndConditions' } | cxUrl\"\n                    target=\"_blank\"\n                    rel=\"noopener noreferrer\"\n                    aria-describedby=\"confirm-read-label\"\n                  >\n                    {{ 'register.termsAndConditions' | cxTranslate }}\n                  </a>\n                  <cx-form-required-asterisks />\n                </span>\n\n                <cx-form-errors\n                  id=\"termsandconditionsError\"\n                  [translationParams]=\"{\n                    label: 'register.termsAndConditions' | cxTranslate,\n                  }\"\n                  [control]=\"registerForm.get('termsandconditions')\"\n                ></cx-form-errors>\n              </label>\n            </div>\n          </div>\n          <cx-captcha (confirmed)=\"captchaConfirmed()\"></cx-captcha>\n          <cx-form-errors\n            [control]=\"registerForm.get('captcha')\"\n          ></cx-form-errors>\n          <button type=\"submit\" class=\"btn btn-block btn-primary\">\n            {{ 'register.register' | cxTranslate }}\n          </button>\n          <a\n            class=\"cx-login-link btn-link\"\n            [routerLink]=\"{ cxRoute: 'login' } | cxUrl\"\n            >{{ 'register.signIn' | cxTranslate }}</a\n          >\n        </form>\n      </div>\n    </div>\n  </div>\n</section>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\"><cx-spinner></cx-spinner></div>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i2.GlobalMessageService }, { type: i2$1.UntypedFormBuilder }, { type: i2.RoutingService }, { type: i2.AnonymousConsentsService }, { type: i2.AnonymousConsentsConfig }, { type: i2.AuthConfigService }, { type: RegisterComponentService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class RegisterComponentModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegisterComponentModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: RegisterComponentModule, imports: [CaptchaModule,
            CommonModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            SpinnerModule,
            FormErrorsModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            NgSelectA11yModule,
            NgSelectModule,
            PasswordVisibilityToggleModule,
            FeaturesConfigModule,
            RegisterComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegisterComponentModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    RegisterCustomerComponent: {
                        component: RegisterComponent,
                        guards: [NotAuthGuard],
                        providers: [
                            {
                                provide: RegisterComponentService,
                                useClass: RegisterComponentService,
                                deps: [
                                    UserRegisterFacade,
                                    GlobalMessageService,
                                    UntypedFormBuilder,
                                ],
                            },
                        ],
                    },
                },
            }),
        ], imports: [CaptchaModule,
            CommonModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            SpinnerModule,
            FormErrorsModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            NgSelectA11yModule,
            NgSelectModule,
            PasswordVisibilityToggleModule,
            FeaturesConfigModule,
            RegisterComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegisterComponentModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CaptchaModule,
                        CommonModule,
                        ReactiveFormsModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        SpinnerModule,
                        FormErrorsModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        NgSelectA11yModule,
                        NgSelectModule,
                        PasswordVisibilityToggleModule,
                        FeaturesConfigModule,
                        RegisterComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                RegisterCustomerComponent: {
                                    component: RegisterComponent,
                                    guards: [NotAuthGuard],
                                    providers: [
                                        {
                                            provide: RegisterComponentService,
                                            useClass: RegisterComponentService,
                                            deps: [
                                                UserRegisterFacade,
                                                GlobalMessageService,
                                                UntypedFormBuilder,
                                            ],
                                        },
                                    ],
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ResetPasswordComponentService {
    constructor(userPasswordService, routingService, globalMessage) {
        this.userPasswordService = userPasswordService;
        this.routingService = routingService;
        this.globalMessage = globalMessage;
        // TODO: Delete FeatureToggles injection
        // When: upon removing feature toogle: useEnhancedSecurePasswordValidators and not used anywhere else
        this.featureToggles = inject(FeatureToggles);
        this.passwordValidators = this.featureToggles
            .useEnhancedSecurePasswordValidators
            ? [
                ...CustomFormValidators.securePasswordValidators,
                CustomFormValidators.mustEndWithLegalCharacter,
            ]
            : CustomFormValidators.securePasswordValidators;
        this.busy$ = new BehaviorSubject(false);
        this.isUpdating$ = this.busy$.pipe(tap((state) => (state === true ? this.form.disable() : this.form.enable())));
        this.resetToken$ = this.routingService
            .getRouterState()
            .pipe(map((routerState) => routerState.state.queryParams['token']));
        this.form = new UntypedFormGroup({
            password: new UntypedFormControl('', [
                Validators.required,
                ...this.passwordValidators,
            ]),
            passwordConfirm: new UntypedFormControl('', Validators.required),
        }, {
            validators: CustomFormValidators.passwordsMustMatch('password', 'passwordConfirm'),
        });
    }
    /**
     * Resets the password by the given token.
     *
     * The token has been provided during the request password flow.
     * The token is not validated on the client.
     */
    resetPassword(token) {
        if (!this.form.valid) {
            this.form.markAllAsTouched();
            return;
        }
        this.busy$.next(true);
        const password = this.form.get('password').value;
        this.userPasswordService.reset(token, password).subscribe({
            next: () => this.onSuccess(),
            error: (error) => this.onError(error),
        });
    }
    onSuccess() {
        this.globalMessage.add({ key: 'forgottenPassword.passwordResetSuccess' }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
        this.busy$.next(false);
        this.form.reset();
        this.redirect();
    }
    onError(error) {
        this.busy$.next(false);
        if (error instanceof HttpErrorModel) {
            (error.details ?? []).forEach((err) => {
                if (err.message) {
                    this.globalMessage.add({ raw: err.message }, GlobalMessageType.MSG_TYPE_ERROR);
                }
            });
        }
    }
    /**
     * Redirects the user to the login page.
     */
    redirect() {
        this.routingService.go({ cxRoute: 'login' });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ResetPasswordComponentService, deps: [{ token: i1.UserPasswordFacade }, { token: i2.RoutingService }, { token: i2.GlobalMessageService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ResetPasswordComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ResetPasswordComponentService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.UserPasswordFacade }, { type: i2.RoutingService }, { type: i2.GlobalMessageService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ResetPasswordComponent {
    constructor(service) {
        this.service = service;
        this.form = this.service.form;
        this.isUpdating$ = this.service.isUpdating$;
        this.token$ = this.service.resetToken$;
    }
    onSubmit(token) {
        this.service.resetPassword(token);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ResetPasswordComponent, deps: [{ token: ResetPasswordComponentService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: ResetPasswordComponent, isStandalone: true, selector: "cx-reset-password", host: { attributes: { "ngSkipHydration": "true" }, classAttribute: "user-form" }, ngImport: i0, template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"> </cx-spinner>\n\n<form\n  *ngIf=\"token$ | async as token\"\n  (ngSubmit)=\"onSubmit(token)\"\n  [formGroup]=\"form\"\n>\n  <cx-form-required-legend />\n  <label>\n    <span class=\"label-content\"\n      >{{ 'register.newPassword' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      class=\"form-control\"\n      type=\"password\"\n      placeholder=\"{{ 'register.password.placeholder' | cxTranslate }}\"\n      formControlName=\"password\"\n      [attr.aria-label]=\"'register.password.placeholder' | cxTranslate\"\n      [attr.aria-invalid]=\"\n        form.get('password')?.touched && form.get('password')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'passwordError'\"\n      cxPasswordVisibilitySwitch\n    />\n\n    <cx-form-errors\n      id=\"passwordError\"\n      [translationParams]=\"{\n        label: 'register.newPassword' | cxTranslate,\n      }\"\n      [control]=\"form.get('password')\"\n    ></cx-form-errors>\n  </label>\n\n  <label>\n    <span class=\"label-content\"\n      >{{ 'register.passwordMinRequirements' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      class=\"form-control\"\n      type=\"password\"\n      placeholder=\"{{ 'register.confirmPassword.placeholder' | cxTranslate }}\"\n      formControlName=\"passwordConfirm\"\n      [attr.aria-label]=\"'register.confirmPassword.placeholder' | cxTranslate\"\n      [attr.aria-invalid]=\"\n        form.get('passwordConfirm')?.touched &&\n        form.get('passwordConfirm')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'passwordConfirmError'\"\n      cxPasswordVisibilitySwitch\n    />\n\n    <cx-form-errors\n      id=\"passwordConfirmError\"\n      [translationParams]=\"{\n        label: 'register.passwordMinRequirements' | cxTranslate,\n      }\"\n      [control]=\"form.get('passwordConfirm')\"\n    ></cx-form-errors>\n  </label>\n\n  <button class=\"btn btn-block btn-primary\" [disabled]=\"form.disabled\">\n    {{ 'register.resetPassword' | cxTranslate }}\n  </button>\n</form>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "directive", type: PasswordVisibilityToggleDirective, selector: "[cxPasswordVisibilitySwitch][type=\"password\"]" }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ResetPasswordComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-reset-password', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'user-form', ngSkipHydration: 'true' }, imports: [
                        NgIf,
                        SpinnerComponent,
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredLegendComponent,
                        FormRequiredAsterisksComponent,
                        PasswordVisibilityToggleDirective,
                        FormErrorsComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"> </cx-spinner>\n\n<form\n  *ngIf=\"token$ | async as token\"\n  (ngSubmit)=\"onSubmit(token)\"\n  [formGroup]=\"form\"\n>\n  <cx-form-required-legend />\n  <label>\n    <span class=\"label-content\"\n      >{{ 'register.newPassword' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      class=\"form-control\"\n      type=\"password\"\n      placeholder=\"{{ 'register.password.placeholder' | cxTranslate }}\"\n      formControlName=\"password\"\n      [attr.aria-label]=\"'register.password.placeholder' | cxTranslate\"\n      [attr.aria-invalid]=\"\n        form.get('password')?.touched && form.get('password')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'passwordError'\"\n      cxPasswordVisibilitySwitch\n    />\n\n    <cx-form-errors\n      id=\"passwordError\"\n      [translationParams]=\"{\n        label: 'register.newPassword' | cxTranslate,\n      }\"\n      [control]=\"form.get('password')\"\n    ></cx-form-errors>\n  </label>\n\n  <label>\n    <span class=\"label-content\"\n      >{{ 'register.passwordMinRequirements' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      class=\"form-control\"\n      type=\"password\"\n      placeholder=\"{{ 'register.confirmPassword.placeholder' | cxTranslate }}\"\n      formControlName=\"passwordConfirm\"\n      [attr.aria-label]=\"'register.confirmPassword.placeholder' | cxTranslate\"\n      [attr.aria-invalid]=\"\n        form.get('passwordConfirm')?.touched &&\n        form.get('passwordConfirm')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'passwordConfirmError'\"\n      cxPasswordVisibilitySwitch\n    />\n\n    <cx-form-errors\n      id=\"passwordConfirmError\"\n      [translationParams]=\"{\n        label: 'register.passwordMinRequirements' | cxTranslate,\n      }\"\n      [control]=\"form.get('passwordConfirm')\"\n    ></cx-form-errors>\n  </label>\n\n  <button class=\"btn btn-block btn-primary\" [disabled]=\"form.disabled\">\n    {{ 'register.resetPassword' | cxTranslate }}\n  </button>\n</form>\n" }]
        }], ctorParameters: () => [{ type: ResetPasswordComponentService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ResetPasswordModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ResetPasswordModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: ResetPasswordModule, imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            RouterModule,
            I18nModule,
            FormErrorsModule,
            SpinnerModule,
            PasswordVisibilityToggleModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            ResetPasswordComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ResetPasswordModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    ResetPasswordComponent: {
                        component: ResetPasswordComponent,
                        guards: [NotAuthGuard],
                        providers: [
                            {
                                provide: ResetPasswordComponentService,
                                useClass: ResetPasswordComponentService,
                                deps: [UserPasswordFacade, RoutingService, GlobalMessageService],
                            },
                        ],
                    },
                },
            }),
        ], imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            RouterModule,
            I18nModule,
            FormErrorsModule,
            SpinnerModule,
            PasswordVisibilityToggleModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            ResetPasswordComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ResetPasswordModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        RouterModule,
                        I18nModule,
                        FormErrorsModule,
                        SpinnerModule,
                        PasswordVisibilityToggleModule,
                        FeaturesConfigModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        ResetPasswordComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                ResetPasswordComponent: {
                                    component: ResetPasswordComponent,
                                    guards: [NotAuthGuard],
                                    providers: [
                                        {
                                            provide: ResetPasswordComponentService,
                                            useClass: ResetPasswordComponentService,
                                            deps: [UserPasswordFacade, RoutingService, GlobalMessageService],
                                        },
                                    ],
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UpdateEmailComponentService {
    constructor(userEmail, routingService, globalMessageService, authService, authRedirectService) {
        this.userEmail = userEmail;
        this.routingService = routingService;
        this.globalMessageService = globalMessageService;
        this.authService = authService;
        this.authRedirectService = authRedirectService;
        this.busy$ = new BehaviorSubject(false);
        this.updateSucceed$ = new Subject();
        this.isUpdating$ = this.busy$.pipe(tap((state) => (state === true ? this.form.disable() : this.form.enable())));
        this.form = new UntypedFormGroup({
            email: new UntypedFormControl('', [
                Validators.required,
                CustomFormValidators.emailValidator,
            ]),
            confirmEmail: new UntypedFormControl('', [Validators.required]),
            password: new UntypedFormControl('', [Validators.required]),
        }, {
            validators: CustomFormValidators.emailsMustMatch('email', 'confirmEmail'),
        });
    }
    save() {
        if (!this.form.valid) {
            this.form.markAllAsTouched();
            return;
        }
        this.busy$.next(true);
        const newEmail = this.form.get('confirmEmail')?.value;
        const password = this.form.get('password')?.value;
        this.userEmail.update(password, newEmail).subscribe({
            next: () => this.onSuccess(newEmail),
            error: (error) => this.onError(error),
        });
    }
    /**
     * Handles successful updating of the user email.
     */
    onSuccess(newUid) {
        this.globalMessageService.add({
            key: 'updateEmailForm.emailUpdateSuccess',
            params: { newUid },
        }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
        this.busy$.next(false);
        this.form.reset();
        this.updateSucceed$.next(true);
        // sets the redirect url after login
        this.authRedirectService.setRedirectUrl(this.routingService.getUrl({ cxRoute: 'home' }));
        // TODO(#9638): Use logout route when it will support passing redirect url
        this.authService.coreLogout().then(() => {
            this.routingService.go({ cxRoute: 'login' }, {
                state: {
                    newUid,
                },
            });
        });
    }
    onError(_error) {
        this.busy$.next(false);
        this.updateSucceed$.next(false);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdateEmailComponentService, deps: [{ token: i1.UserEmailFacade }, { token: i2.RoutingService }, { token: i2.GlobalMessageService }, { token: i2.AuthService }, { token: i2.AuthRedirectService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdateEmailComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdateEmailComponentService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.UserEmailFacade }, { type: i2.RoutingService }, { type: i2.GlobalMessageService }, { type: i2.AuthService }, { type: i2.AuthRedirectService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UpdateEmailComponent {
    constructor(service) {
        this.service = service;
        this.pageMetaService = inject(PageMetaService);
        this.form = this.service.form;
        this.isUpdating$ = this.service.isUpdating$;
        this.pageTitle$ = getPageTitle(this.pageMetaService);
    }
    onSubmit() {
        this.service.save();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdateEmailComponent, deps: [{ token: UpdateEmailComponentService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: UpdateEmailComponent, isStandalone: true, selector: "cx-update-email", host: { attributes: { "ngSkipHydration": "true" }, classAttribute: "user-form" }, ngImport: i0, template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"> </cx-spinner>\n<cx-form-required-legend />\n<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n  <fieldset>\n    <legend\n      *cxFeature=\"'a11yFormFieldSectionLegend'\"\n      class=\"cx-visually-hidden\"\n    >\n      {{ pageTitle$ | async }}\n    </legend>\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updateEmailForm.newEmailAddress.label' | cxTranslate }}\n\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"email\"\n        name=\"email\"\n        formControlName=\"email\"\n        placeholder=\"{{\n          'updateEmailForm.newEmailAddress.placeholder' | cxTranslate\n        }}\"\n        [attr.aria-invalid]=\"\n          form.get('email')?.touched && form.get('email')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'emailError'\"\n        class=\"form-control\"\n      />\n\n      <cx-form-errors\n        id=\"emailError\"\n        [translationParams]=\"{\n          label: 'updateEmailForm.newEmailAddress.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('email')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updateEmailForm.confirmNewEmailAddress.label' | cxTranslate }}\n\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"email\"\n        name=\"confirmEmail\"\n        formControlName=\"confirmEmail\"\n        placeholder=\"{{\n          'updateEmailForm.confirmNewEmailAddress.placeholder' | cxTranslate\n        }}\"\n        [attr.aria-invalid]=\"\n          form.get('confirmEmail')?.touched && form.get('confirmEmail')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'confirmEmailError'\"\n        class=\"form-control\"\n      />\n\n      <cx-form-errors\n        id=\"confirmEmailError\"\n        [translationParams]=\"{\n          label: 'updateEmailForm.confirmNewEmailAddress.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('confirmEmail')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updateEmailForm.password.label' | cxTranslate }}\n\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"password\"\n        name=\"password\"\n        formControlName=\"password\"\n        placeholder=\"{{ 'updateEmailForm.password.placeholder' | cxTranslate }}\"\n        class=\"form-control\"\n        autocomplete=\"new-password\"\n        [attr.aria-label]=\"'updateEmailForm.password.placeholder' | cxTranslate\"\n        [attr.aria-describedby]=\"'passwordError'\"\n        cxPasswordVisibilitySwitch\n      />\n\n      <cx-form-errors\n        id=\"passwordError\"\n        [translationParams]=\"{\n          label: 'updateEmailForm.password.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('password')\"\n      ></cx-form-errors>\n    </label>\n\n    <a\n      class=\"btn btn-block btn-secondary\"\n      [routerLink]=\"{ cxRoute: 'home' } | cxUrl\"\n      cxBtnLikeLink\n    >\n      {{ 'common.cancel' | cxTranslate }}\n    </a>\n\n    <button class=\"btn btn-block btn-primary\" [disabled]=\"form.disabled\">\n      {{ 'common.save' | cxTranslate }}\n    </button>\n  </fieldset>\n</form>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: PasswordVisibilityToggleDirective, selector: "[cxPasswordVisibilitySwitch][type=\"password\"]" }, { kind: "directive", type: BtnLikeLinkDirective, selector: "a[cxBtnLikeLink].btn" }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: FeatureDirective, selector: "[cxFeature]", inputs: ["cxFeature"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdateEmailComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-update-email', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'user-form', ngSkipHydration: 'true' }, imports: [
                        NgIf,
                        SpinnerComponent,
                        FormRequiredLegendComponent,
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        PasswordVisibilityToggleDirective,
                        BtnLikeLinkDirective,
                        RouterLink,
                        AsyncPipe,
                        UrlPipe,
                        TranslatePipe,
                        FeatureDirective,
                    ], template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"> </cx-spinner>\n<cx-form-required-legend />\n<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n  <fieldset>\n    <legend\n      *cxFeature=\"'a11yFormFieldSectionLegend'\"\n      class=\"cx-visually-hidden\"\n    >\n      {{ pageTitle$ | async }}\n    </legend>\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updateEmailForm.newEmailAddress.label' | cxTranslate }}\n\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"email\"\n        name=\"email\"\n        formControlName=\"email\"\n        placeholder=\"{{\n          'updateEmailForm.newEmailAddress.placeholder' | cxTranslate\n        }}\"\n        [attr.aria-invalid]=\"\n          form.get('email')?.touched && form.get('email')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'emailError'\"\n        class=\"form-control\"\n      />\n\n      <cx-form-errors\n        id=\"emailError\"\n        [translationParams]=\"{\n          label: 'updateEmailForm.newEmailAddress.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('email')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updateEmailForm.confirmNewEmailAddress.label' | cxTranslate }}\n\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"email\"\n        name=\"confirmEmail\"\n        formControlName=\"confirmEmail\"\n        placeholder=\"{{\n          'updateEmailForm.confirmNewEmailAddress.placeholder' | cxTranslate\n        }}\"\n        [attr.aria-invalid]=\"\n          form.get('confirmEmail')?.touched && form.get('confirmEmail')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'confirmEmailError'\"\n        class=\"form-control\"\n      />\n\n      <cx-form-errors\n        id=\"confirmEmailError\"\n        [translationParams]=\"{\n          label: 'updateEmailForm.confirmNewEmailAddress.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('confirmEmail')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updateEmailForm.password.label' | cxTranslate }}\n\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"password\"\n        name=\"password\"\n        formControlName=\"password\"\n        placeholder=\"{{ 'updateEmailForm.password.placeholder' | cxTranslate }}\"\n        class=\"form-control\"\n        autocomplete=\"new-password\"\n        [attr.aria-label]=\"'updateEmailForm.password.placeholder' | cxTranslate\"\n        [attr.aria-describedby]=\"'passwordError'\"\n        cxPasswordVisibilitySwitch\n      />\n\n      <cx-form-errors\n        id=\"passwordError\"\n        [translationParams]=\"{\n          label: 'updateEmailForm.password.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('password')\"\n      ></cx-form-errors>\n    </label>\n\n    <a\n      class=\"btn btn-block btn-secondary\"\n      [routerLink]=\"{ cxRoute: 'home' } | cxUrl\"\n      cxBtnLikeLink\n    >\n      {{ 'common.cancel' | cxTranslate }}\n    </a>\n\n    <button class=\"btn btn-block btn-primary\" [disabled]=\"form.disabled\">\n      {{ 'common.save' | cxTranslate }}\n    </button>\n  </fieldset>\n</form>\n" }]
        }], ctorParameters: () => [{ type: UpdateEmailComponentService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class MyAccountV2EmailComponent {
    constructor() {
        this.emailComponentService = inject(UpdateEmailComponentService);
        this.userProfile = inject(UserProfileFacade);
        this.pageMetaService = inject(PageMetaService);
        this.form = this.emailComponentService.form;
        this.isUpdating$ = this.emailComponentService.isUpdating$;
        this.pageTitle$ = getPageTitle(this.pageMetaService);
        this.user$ = this.userProfile
            .get()
            .pipe(filter((user) => Boolean(user)));
        this.globalMessageType = GlobalMessageType;
    }
    ngOnInit() {
        this.isEditing = false;
    }
    onSubmit() {
        this.emailComponentService.save();
        this.emailComponentService.updateSucceed$.subscribe((res) => {
            this.isEditing = !res;
        });
    }
    onEdit() {
        this.isEditing = true;
        this.showingAlert = true;
        this.form.reset();
    }
    cancelEdit() {
        this.isEditing = false;
    }
    closeDialogConfirmationAlert() {
        this.showingAlert = false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MyAccountV2EmailComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: MyAccountV2EmailComponent, isStandalone: true, selector: "cx-my-account-v2-email", host: { attributes: { "ngSkipHydration": "true" } }, ngImport: i0, template: "<cx-spinner\n  class=\"overlay\"\n  *ngIf=\"(isUpdating$ | async) || !(user$ | async); $\"\n>\n</cx-spinner>\n<div>\n  <div class=\"flex-line\">\n    <span class=\"headertext\">{{\n      'myAccountV2Email.myEmailAddress' | cxTranslate\n    }}</span>\n    <button class=\"editButton\" *ngIf=\"!isEditing\" (click)=\"onEdit()\">\n      {{ 'common.edit' | cxTranslate }}\n    </button>\n  </div>\n  <div>\n    <div *ngIf=\"!isEditing\">\n      <div class=\"flex-line\">\n        <label class=\"text-head\">\n          {{ 'myAccountV2Email.email' | cxTranslate }}\n        </label>\n        <label class=\"value\">\n          {{ (user$ | async)?.uid }}\n        </label>\n      </div>\n    </div>\n  </div>\n  <cx-message\n    *ngIf=\"isEditing && showingAlert\"\n    [text]=\"'myAccountV2Email.reloginIndicator' | cxTranslate\"\n    [type]=\"globalMessageType.MSG_TYPE_INFO\"\n    (closeMessage)=\"closeDialogConfirmationAlert()\"\n  ></cx-message>\n  <div *ngIf=\"isEditing\" class=\"email-editing-area\">\n    <form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n      <fieldset>\n        <legend *cxFeature=\"'a11yFormFieldSectionLegend'\" class=\"headertext\">\n          {{ 'myAccountV2Email.myEmailAddress' | cxTranslate }}\n        </legend>\n        <label>\n          <span class=\"text-head\">{{\n            'myAccountV2Email.emailAddress' | cxTranslate\n          }}</span>\n          <input\n            type=\"text\"\n            class=\"form-control\"\n            [value]=\"(user$ | async)?.uid\"\n            readonly\n          />\n        </label>\n\n        <label>\n          <span class=\"text-head\">{{\n            'myAccountV2Email.newEmailAddress' | cxTranslate\n          }}</span>\n          <input\n            required=\"true\"\n            type=\"email\"\n            name=\"email\"\n            formControlName=\"email\"\n            placeholder=\"{{\n              'myAccountV2Email.emailPlaceHolder' | cxTranslate\n            }}\"\n            class=\"form-control\"\n            [attr.aria-invalid]=\"\n              form.get('email')?.touched && form.get('email')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'emailError'\"\n          />\n\n          <cx-form-errors\n            id=\"emailError\"\n            [translationParams]=\"{\n              label: 'updateEmailForm.newEmailAddress.label' | cxTranslate,\n            }\"\n            [control]=\"form.get('email')\"\n          ></cx-form-errors>\n        </label>\n\n        <label>\n          <span class=\"text-head\">{{\n            'myAccountV2Email.confirmNewEmailAddress' | cxTranslate\n          }}</span>\n          <input\n            required=\"true\"\n            type=\"email\"\n            name=\"confirmEmail\"\n            formControlName=\"confirmEmail\"\n            placeholder=\"{{\n              'myAccountV2Email.emailPlaceHolder' | cxTranslate\n            }}\"\n            class=\"form-control\"\n            [attr.aria-invalid]=\"\n              form.get('confirmEmail')?.touched &&\n              form.get('confirmEmail')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'confirmEmailError'\"\n          />\n\n          <cx-form-errors\n            id=\"confirmEmailError\"\n            [translationParams]=\"{\n              label:\n                'updateEmailForm.confirmNewEmailAddress.label' | cxTranslate,\n            }\"\n            [control]=\"form.get('confirmEmail')\"\n          ></cx-form-errors>\n        </label>\n\n        <label>\n          <span class=\"label-content, text-head\">{{\n            'myAccountV2Email.password' | cxTranslate\n          }}</span>\n          <input\n            required=\"true\"\n            type=\"password\"\n            name=\"password\"\n            formControlName=\"password\"\n            placeholder=\"{{\n              'myAccountV2Email.passwordPlaceHolder' | cxTranslate\n            }}\"\n            class=\"form-control\"\n            autocomplete=\"new-password\"\n            [attr.aria-label]=\"\n              'myAccountV2Email.passwordPlaceHolder' | cxTranslate\n            \"\n            [attr.aria-invalid]=\"\n              form.get('password')?.touched && form.get('password')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'passwordError'\"\n            cxPasswordVisibilitySwitch\n          />\n\n          <cx-form-errors\n            id=\"passwordError\"\n            [translationParams]=\"{\n              label: 'updateEmailForm.password.label' | cxTranslate,\n            }\"\n            [control]=\"form.get('password')\"\n          ></cx-form-errors>\n        </label>\n\n        <div class=\"btn-group\">\n          <button class=\"btn button-cancel button\" (click)=\"cancelEdit()\">\n            {{ 'common.cancel' | cxTranslate }}\n          </button>\n          <button\n            class=\"btn btn-primary button\"\n            (click)=\"onSubmit()\"\n            [disabled]=\"form.disabled\"\n          >\n            {{ 'common.save' | cxTranslate }}\n          </button>\n        </div>\n      </fieldset>\n    </form>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "component", type: MessageComponent, selector: "cx-message", inputs: ["text", "actionButtonText", "actionButtonMessage", "accordionText", "showBody", "isVisibleCloseButton", "type"], outputs: ["closeMessage", "buttonAction"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: PasswordVisibilityToggleDirective, selector: "[cxPasswordVisibilitySwitch][type=\"password\"]" }, { kind: "directive", type: FeatureDirective, selector: "[cxFeature]", inputs: ["cxFeature"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MyAccountV2EmailComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-my-account-v2-email', changeDetection: ChangeDetectionStrategy.OnPush, host: { ngSkipHydration: 'true' }, imports: [
                        NgIf,
                        SpinnerComponent,
                        MessageComponent,
                        FormsModule,
                        ReactiveFormsModule,
                        FormErrorsComponent,
                        PasswordVisibilityToggleDirective,
                        AsyncPipe,
                        TranslatePipe,
                        FeatureDirective,
                    ], template: "<cx-spinner\n  class=\"overlay\"\n  *ngIf=\"(isUpdating$ | async) || !(user$ | async); $\"\n>\n</cx-spinner>\n<div>\n  <div class=\"flex-line\">\n    <span class=\"headertext\">{{\n      'myAccountV2Email.myEmailAddress' | cxTranslate\n    }}</span>\n    <button class=\"editButton\" *ngIf=\"!isEditing\" (click)=\"onEdit()\">\n      {{ 'common.edit' | cxTranslate }}\n    </button>\n  </div>\n  <div>\n    <div *ngIf=\"!isEditing\">\n      <div class=\"flex-line\">\n        <label class=\"text-head\">\n          {{ 'myAccountV2Email.email' | cxTranslate }}\n        </label>\n        <label class=\"value\">\n          {{ (user$ | async)?.uid }}\n        </label>\n      </div>\n    </div>\n  </div>\n  <cx-message\n    *ngIf=\"isEditing && showingAlert\"\n    [text]=\"'myAccountV2Email.reloginIndicator' | cxTranslate\"\n    [type]=\"globalMessageType.MSG_TYPE_INFO\"\n    (closeMessage)=\"closeDialogConfirmationAlert()\"\n  ></cx-message>\n  <div *ngIf=\"isEditing\" class=\"email-editing-area\">\n    <form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n      <fieldset>\n        <legend *cxFeature=\"'a11yFormFieldSectionLegend'\" class=\"headertext\">\n          {{ 'myAccountV2Email.myEmailAddress' | cxTranslate }}\n        </legend>\n        <label>\n          <span class=\"text-head\">{{\n            'myAccountV2Email.emailAddress' | cxTranslate\n          }}</span>\n          <input\n            type=\"text\"\n            class=\"form-control\"\n            [value]=\"(user$ | async)?.uid\"\n            readonly\n          />\n        </label>\n\n        <label>\n          <span class=\"text-head\">{{\n            'myAccountV2Email.newEmailAddress' | cxTranslate\n          }}</span>\n          <input\n            required=\"true\"\n            type=\"email\"\n            name=\"email\"\n            formControlName=\"email\"\n            placeholder=\"{{\n              'myAccountV2Email.emailPlaceHolder' | cxTranslate\n            }}\"\n            class=\"form-control\"\n            [attr.aria-invalid]=\"\n              form.get('email')?.touched && form.get('email')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'emailError'\"\n          />\n\n          <cx-form-errors\n            id=\"emailError\"\n            [translationParams]=\"{\n              label: 'updateEmailForm.newEmailAddress.label' | cxTranslate,\n            }\"\n            [control]=\"form.get('email')\"\n          ></cx-form-errors>\n        </label>\n\n        <label>\n          <span class=\"text-head\">{{\n            'myAccountV2Email.confirmNewEmailAddress' | cxTranslate\n          }}</span>\n          <input\n            required=\"true\"\n            type=\"email\"\n            name=\"confirmEmail\"\n            formControlName=\"confirmEmail\"\n            placeholder=\"{{\n              'myAccountV2Email.emailPlaceHolder' | cxTranslate\n            }}\"\n            class=\"form-control\"\n            [attr.aria-invalid]=\"\n              form.get('confirmEmail')?.touched &&\n              form.get('confirmEmail')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'confirmEmailError'\"\n          />\n\n          <cx-form-errors\n            id=\"confirmEmailError\"\n            [translationParams]=\"{\n              label:\n                'updateEmailForm.confirmNewEmailAddress.label' | cxTranslate,\n            }\"\n            [control]=\"form.get('confirmEmail')\"\n          ></cx-form-errors>\n        </label>\n\n        <label>\n          <span class=\"label-content, text-head\">{{\n            'myAccountV2Email.password' | cxTranslate\n          }}</span>\n          <input\n            required=\"true\"\n            type=\"password\"\n            name=\"password\"\n            formControlName=\"password\"\n            placeholder=\"{{\n              'myAccountV2Email.passwordPlaceHolder' | cxTranslate\n            }}\"\n            class=\"form-control\"\n            autocomplete=\"new-password\"\n            [attr.aria-label]=\"\n              'myAccountV2Email.passwordPlaceHolder' | cxTranslate\n            \"\n            [attr.aria-invalid]=\"\n              form.get('password')?.touched && form.get('password')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'passwordError'\"\n            cxPasswordVisibilitySwitch\n          />\n\n          <cx-form-errors\n            id=\"passwordError\"\n            [translationParams]=\"{\n              label: 'updateEmailForm.password.label' | cxTranslate,\n            }\"\n            [control]=\"form.get('password')\"\n          ></cx-form-errors>\n        </label>\n\n        <div class=\"btn-group\">\n          <button class=\"btn button-cancel button\" (click)=\"cancelEdit()\">\n            {{ 'common.cancel' | cxTranslate }}\n          </button>\n          <button\n            class=\"btn btn-primary button\"\n            (click)=\"onSubmit()\"\n            [disabled]=\"form.disabled\"\n          >\n            {{ 'common.save' | cxTranslate }}\n          </button>\n        </div>\n      </fieldset>\n    </form>\n  </div>\n</div>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const USE_MY_ACCOUNT_V2_EMAIL = new InjectionToken('feature flag to enable enhanced UI for email related pages under My-Account', { providedIn: 'root', factory: () => false });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const myAccountV2EmailMapping = {
    cmsComponents: {
        UpdateEmailComponent: {
            component: MyAccountV2EmailComponent,
        },
    },
};
class UpdateEmailModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdateEmailModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: UpdateEmailModule, imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            SpinnerModule,
            UrlModule,
            RouterModule,
            I18nModule,
            FormErrorsModule,
            PasswordVisibilityToggleModule,
            FeaturesConfigModule,
            MessageComponentModule,
            BtnLikeLinkModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            UpdateEmailComponent,
            MyAccountV2EmailComponent], exports: [UpdateEmailComponent, MyAccountV2EmailComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdateEmailModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    UpdateEmailComponent: {
                        component: UpdateEmailComponent,
                        guards: [AuthGuard],
                        providers: [
                            {
                                provide: UpdateEmailComponentService,
                                useClass: UpdateEmailComponentService,
                                deps: [
                                    UserEmailFacade,
                                    RoutingService,
                                    GlobalMessageService,
                                    AuthService,
                                    AuthRedirectService,
                                ],
                            },
                        ],
                    },
                },
            }),
            provideDefaultConfigFactory(() => inject(USE_MY_ACCOUNT_V2_EMAIL) ? myAccountV2EmailMapping : {}),
        ], imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            SpinnerModule,
            UrlModule,
            RouterModule,
            I18nModule,
            FormErrorsModule,
            PasswordVisibilityToggleModule,
            FeaturesConfigModule,
            MessageComponentModule,
            BtnLikeLinkModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            UpdateEmailComponent,
            MyAccountV2EmailComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdateEmailModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        SpinnerModule,
                        UrlModule,
                        RouterModule,
                        I18nModule,
                        FormErrorsModule,
                        PasswordVisibilityToggleModule,
                        FeaturesConfigModule,
                        MessageComponentModule,
                        BtnLikeLinkModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        UpdateEmailComponent,
                        MyAccountV2EmailComponent,
                    ],
                    exports: [UpdateEmailComponent, MyAccountV2EmailComponent],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                UpdateEmailComponent: {
                                    component: UpdateEmailComponent,
                                    guards: [AuthGuard],
                                    providers: [
                                        {
                                            provide: UpdateEmailComponentService,
                                            useClass: UpdateEmailComponentService,
                                            deps: [
                                                UserEmailFacade,
                                                RoutingService,
                                                GlobalMessageService,
                                                AuthService,
                                                AuthRedirectService,
                                            ],
                                        },
                                    ],
                                },
                            },
                        }),
                        provideDefaultConfigFactory(() => inject(USE_MY_ACCOUNT_V2_EMAIL) ? myAccountV2EmailMapping : {}),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const USE_MY_ACCOUNT_V2_PASSWORD = new InjectionToken('feature flag to enable enhanced UI for Update Password related pages under My-Account', { providedIn: 'root', factory: () => false });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UpdatePasswordComponentService {
    constructor(userPasswordService, routingService, globalMessageService, authRedirectService, authService) {
        this.userPasswordService = userPasswordService;
        this.routingService = routingService;
        this.globalMessageService = globalMessageService;
        this.authRedirectService = authRedirectService;
        this.authService = authService;
        // TODO: Delete FeatureToggles injection
        // When: upon removing feature toogle: useEnhancedSecurePasswordValidators and service is not used anywhere else
        this.featureToggles = inject(FeatureToggles);
        this.passwordValidators = this.featureToggles
            .useEnhancedSecurePasswordValidators
            ? [
                ...CustomFormValidators.securePasswordValidators,
                CustomFormValidators.mustEndWithLegalCharacter,
            ]
            : CustomFormValidators.securePasswordValidators;
        this.busy$ = new BehaviorSubject(false);
        this.usingV2 = inject(USE_MY_ACCOUNT_V2_PASSWORD);
        this.isUpdating$ = this.busy$.pipe(tap((state) => (state === true ? this.form.disable() : this.form.enable())));
        this.form = new UntypedFormGroup({
            oldPassword: new UntypedFormControl('', Validators.required),
            newPassword: new UntypedFormControl('', [
                Validators.required,
                ...this.passwordValidators,
            ]),
            newPasswordConfirm: new UntypedFormControl('', Validators.required),
        }, {
            validators: this.getPasswordValidators(),
        });
    }
    /**
     * Updates the password for the user.
     */
    updatePassword() {
        if (!this.form.valid) {
            this.form.markAllAsTouched();
            return;
        }
        this.busy$.next(true);
        const oldPassword = this.form.get('oldPassword')?.value;
        const newPassword = this.form.get('newPassword')?.value;
        this.userPasswordService.update(oldPassword, newPassword).subscribe({
            next: () => this.onSuccess(),
            error: (error) => this.onError(error),
        });
    }
    onSuccess() {
        this.globalMessageService.add({
            key: this.usingV2
                ? 'myAccountV2PasswordForm.passwordUpdateSuccess'
                : 'updatePasswordForm.passwordUpdateSuccess',
        }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
        this.busy$.next(false);
        this.form.reset();
        // sets the redirect url after login
        this.authRedirectService?.setRedirectUrl(this.routingService.getUrl({ cxRoute: 'home' }));
        // TODO(#9638): Use logout route when it will support passing redirect url
        this.authService?.coreLogout().then(() => {
            this.routingService.go({ cxRoute: 'login' });
        });
    }
    onError(_error) {
        if (_error instanceof HttpErrorModel &&
            _error.details?.[0].type === 'AccessDeniedError') {
            this.globalMessageService.add({
                key: this.usingV2
                    ? 'myAccountV2PasswordForm.accessDeniedError'
                    : 'updatePasswordForm.accessDeniedError',
            }, GlobalMessageType.MSG_TYPE_ERROR);
        }
        this.busy$.next(false);
        this.form.reset();
    }
    getPasswordValidators() {
        return [
            CustomFormValidators.passwordsMustMatch('newPassword', 'newPasswordConfirm'),
            CustomFormValidators.passwordsCannotMatch('oldPassword', 'newPassword'),
        ];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdatePasswordComponentService, deps: [{ token: i1.UserPasswordFacade }, { token: i2.RoutingService }, { token: i2.GlobalMessageService }, { token: i2.AuthRedirectService }, { token: i2.AuthService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdatePasswordComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdatePasswordComponentService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.UserPasswordFacade }, { type: i2.RoutingService }, { type: i2.GlobalMessageService }, { type: i2.AuthRedirectService }, { type: i2.AuthService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UpdatePasswordComponent {
    constructor(service) {
        this.service = service;
        this.routingService = inject(RoutingService, {
            optional: true,
        });
        this.pageMetaService = inject(PageMetaService);
        this.form = this.service.form;
        this.isUpdating$ = this.service.isUpdating$;
        this.pageTitle$ = getPageTitle(this.pageMetaService);
    }
    onSubmit() {
        this.service.updatePassword();
    }
    navigateTo(cxRoute) {
        this.routingService?.go({ cxRoute });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdatePasswordComponent, deps: [{ token: UpdatePasswordComponentService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: UpdatePasswordComponent, isStandalone: true, selector: "cx-update-password", host: { attributes: { "ngSkipHydration": "true" }, classAttribute: "user-form" }, ngImport: i0, template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"> </cx-spinner>\n<cx-form-required-legend />\n<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n  <fieldset>\n    <legend\n      *cxFeature=\"'a11yFormFieldSectionLegend'\"\n      class=\"cx-visually-hidden\"\n    >\n      {{ pageTitle$ | async }}\n    </legend>\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updatePasswordForm.oldPassword.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"password\"\n        name=\"oldPassword\"\n        placeholder=\"{{\n          'updatePasswordForm.oldPassword.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"oldPassword\"\n        [attr.aria-label]=\"\n          'updatePasswordForm.oldPassword.placeholder' | cxTranslate\n        \"\n        [attr.aria-invalid]=\"\n          form.get('oldPassword')?.touched && form.get('oldPassword')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'oldPasswordError'\"\n        cxPasswordVisibilitySwitch\n      />\n\n      <cx-form-errors\n        id=\"oldPasswordError\"\n        [translationParams]=\"{\n          label: 'updatePasswordForm.oldPassword.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('oldPassword')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updatePasswordForm.newPassword.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"password\"\n        name=\"newPassword\"\n        placeholder=\"{{\n          'updatePasswordForm.newPassword.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"newPassword\"\n        [attr.aria-label]=\"\n          'updatePasswordForm.newPassword.placeholder' | cxTranslate\n        \"\n        [attr.aria-invalid]=\"\n          form.get('newPassword')?.touched && form.get('newPassword')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'newPasswordError'\"\n        cxPasswordVisibilitySwitch\n      />\n\n      <cx-form-errors\n        id=\"newPasswordError\"\n        [translationParams]=\"{\n          label: 'updatePasswordForm.newPassword.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('newPassword')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updatePasswordForm.confirmPassword.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"password\"\n        name=\"newPasswordConfirm\"\n        placeholder=\"{{\n          'updatePasswordForm.confirmPassword.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"newPasswordConfirm\"\n        [attr.aria-label]=\"\n          'updatePasswordForm.confirmPassword.placeholder' | cxTranslate\n        \"\n        [attr.aria-invalid]=\"\n          form.get('newPasswordConfirm')?.touched &&\n          form.get('newPasswordConfirm')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'newPasswordConfirmError'\"\n        cxPasswordVisibilitySwitch\n      />\n\n      <cx-form-errors\n        id=\"newPasswordConfirmError\"\n        [translationParams]=\"{\n          label: 'updatePasswordForm.confirmPassword.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('newPasswordConfirm')\"\n      ></cx-form-errors>\n    </label>\n\n    <button class=\"btn btn-block btn-secondary\" (click)=\"navigateTo('home')\">\n      {{ 'common.cancel' | cxTranslate }}\n    </button>\n    <button class=\"btn btn-block btn-primary\" [disabled]=\"form.disabled\">\n      {{ 'common.save' | cxTranslate }}\n    </button>\n  </fieldset>\n</form>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "directive", type: PasswordVisibilityToggleDirective, selector: "[cxPasswordVisibilitySwitch][type=\"password\"]" }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: FeatureDirective, selector: "[cxFeature]", inputs: ["cxFeature"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdatePasswordComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-update-password', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'user-form', ngSkipHydration: 'true' }, imports: [
                        NgIf,
                        SpinnerComponent,
                        FormRequiredLegendComponent,
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredAsterisksComponent,
                        PasswordVisibilityToggleDirective,
                        FormErrorsComponent,
                        AsyncPipe,
                        TranslatePipe,
                        FeatureDirective,
                    ], template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"> </cx-spinner>\n<cx-form-required-legend />\n<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n  <fieldset>\n    <legend\n      *cxFeature=\"'a11yFormFieldSectionLegend'\"\n      class=\"cx-visually-hidden\"\n    >\n      {{ pageTitle$ | async }}\n    </legend>\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updatePasswordForm.oldPassword.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"password\"\n        name=\"oldPassword\"\n        placeholder=\"{{\n          'updatePasswordForm.oldPassword.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"oldPassword\"\n        [attr.aria-label]=\"\n          'updatePasswordForm.oldPassword.placeholder' | cxTranslate\n        \"\n        [attr.aria-invalid]=\"\n          form.get('oldPassword')?.touched && form.get('oldPassword')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'oldPasswordError'\"\n        cxPasswordVisibilitySwitch\n      />\n\n      <cx-form-errors\n        id=\"oldPasswordError\"\n        [translationParams]=\"{\n          label: 'updatePasswordForm.oldPassword.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('oldPassword')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updatePasswordForm.newPassword.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"password\"\n        name=\"newPassword\"\n        placeholder=\"{{\n          'updatePasswordForm.newPassword.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"newPassword\"\n        [attr.aria-label]=\"\n          'updatePasswordForm.newPassword.placeholder' | cxTranslate\n        \"\n        [attr.aria-invalid]=\"\n          form.get('newPassword')?.touched && form.get('newPassword')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'newPasswordError'\"\n        cxPasswordVisibilitySwitch\n      />\n\n      <cx-form-errors\n        id=\"newPasswordError\"\n        [translationParams]=\"{\n          label: 'updatePasswordForm.newPassword.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('newPassword')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updatePasswordForm.confirmPassword.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"password\"\n        name=\"newPasswordConfirm\"\n        placeholder=\"{{\n          'updatePasswordForm.confirmPassword.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"newPasswordConfirm\"\n        [attr.aria-label]=\"\n          'updatePasswordForm.confirmPassword.placeholder' | cxTranslate\n        \"\n        [attr.aria-invalid]=\"\n          form.get('newPasswordConfirm')?.touched &&\n          form.get('newPasswordConfirm')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'newPasswordConfirmError'\"\n        cxPasswordVisibilitySwitch\n      />\n\n      <cx-form-errors\n        id=\"newPasswordConfirmError\"\n        [translationParams]=\"{\n          label: 'updatePasswordForm.confirmPassword.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('newPasswordConfirm')\"\n      ></cx-form-errors>\n    </label>\n\n    <button class=\"btn btn-block btn-secondary\" (click)=\"navigateTo('home')\">\n      {{ 'common.cancel' | cxTranslate }}\n    </button>\n    <button class=\"btn btn-block btn-primary\" [disabled]=\"form.disabled\">\n      {{ 'common.save' | cxTranslate }}\n    </button>\n  </fieldset>\n</form>\n" }]
        }], ctorParameters: () => [{ type: UpdatePasswordComponentService }], propDecorators: { routingService: [{
                type: Optional
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class MyAccountV2PasswordComponent {
    constructor() {
        this.service = inject(UpdatePasswordComponentService);
        this.pageMetaService = inject(PageMetaService);
        this.showingAlert = true;
        this.globalMessageType = GlobalMessageType;
        this.form = this.service.form;
        this.isUpdating$ = this.service.isUpdating$;
        this.pageTitle$ = getPageTitle(this.pageMetaService);
    }
    onSubmit() {
        this.service.updatePassword();
    }
    onCancel() {
        this.oldPassword = '';
        this.newPassword = '';
        this.newPasswordConfirm = '';
    }
    closeDialogConfirmationAlert() {
        this.showingAlert = false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MyAccountV2PasswordComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: MyAccountV2PasswordComponent, isStandalone: true, selector: "cx-my-account-v2-password", host: { attributes: { "ngSkipHydration": "true" } }, ngImport: i0, template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"> </cx-spinner>\n\n<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n  <fieldset>\n    <legend\n      *cxFeature=\"'a11yFormFieldSectionLegend'\"\n      class=\"myaccount-password-header\"\n    >\n      {{ 'myAccountV2PasswordForm.newPasswordTitle' | cxTranslate }}\n    </legend>\n\n    <cx-message\n      *ngIf=\"showingAlert\"\n      [text]=\"'myAccountV2PasswordForm.reloginIndicator' | cxTranslate\"\n      [type]=\"globalMessageType.MSG_TYPE_INFO\"\n      (closeMessage)=\"closeDialogConfirmationAlert()\"\n    >\n    </cx-message>\n\n    <label class=\"myaccount-label-padding\">\n      <span class=\"label-content myaccount-password-label\">{{\n        'myAccountV2PasswordForm.oldPassword.label' | cxTranslate\n      }}</span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        [(ngModel)]=\"oldPassword\"\n        type=\"password\"\n        name=\"oldPassword\"\n        placeholder=\"{{\n          'myAccountV2PasswordForm.oldPassword.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"oldPassword\"\n        [attr.aria-label]=\"\n          'myAccountV2PasswordForm.oldPassword.placeholder' | cxTranslate\n        \"\n        [attr.aria-invalid]=\"\n          form.get('oldPassword')?.touched && form.get('oldPassword')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'oldPasswordError'\"\n        cxPasswordVisibilitySwitch\n      />\n\n      <cx-form-errors\n        id=\"oldPasswordError\"\n        [translationParams]=\"{\n          label: 'updatePasswordForm.oldPassword.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('oldPassword')\"\n      ></cx-form-errors>\n    </label>\n\n    <label class=\"myaccount-label-padding\">\n      <span class=\"label-content myaccount-password-label\">{{\n        'myAccountV2PasswordForm.newPassword.label' | cxTranslate\n      }}</span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        [(ngModel)]=\"newPassword\"\n        type=\"password\"\n        name=\"newPassword\"\n        placeholder=\"{{\n          'myAccountV2PasswordForm.newPassword.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"newPassword\"\n        [attr.aria-label]=\"\n          'myAccountV2PasswordForm.newPassword.placeholder' | cxTranslate\n        \"\n        [attr.aria-invalid]=\"\n          form.get('newPassword')?.touched && form.get('newPassword')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'newPasswordError'\"\n        cxPasswordVisibilitySwitch\n      />\n\n      <cx-form-errors\n        id=\"newPasswordError\"\n        [translationParams]=\"{\n          label: 'updatePasswordForm.newPassword.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('newPassword')\"\n      ></cx-form-errors>\n    </label>\n\n    <label class=\"myaccount-label-padding\">\n      <span class=\"label-content myaccount-password-label\">{{\n        'myAccountV2PasswordForm.confirmPassword.label' | cxTranslate\n      }}</span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        [(ngModel)]=\"newPasswordConfirm\"\n        type=\"password\"\n        name=\"newPasswordConfirm\"\n        placeholder=\"{{\n          'myAccountV2PasswordForm.confirmPassword.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"newPasswordConfirm\"\n        [attr.aria-label]=\"\n          'myAccountV2PasswordForm.confirmPassword.placeholder' | cxTranslate\n        \"\n        [attr.aria-invalid]=\"\n          form.get('newPasswordConfirm')?.touched &&\n          form.get('newPasswordConfirm')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'newPasswordConfirmError'\"\n        cxPasswordVisibilitySwitch\n      />\n\n      <cx-form-errors\n        id=\"newPasswordConfirmError\"\n        [translationParams]=\"{\n          label: 'updatePasswordForm.confirmPassword.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('newPasswordConfirm')\"\n      ></cx-form-errors>\n    </label>\n\n    <div class=\"password-btn-group\">\n      <button\n        class=\"btn myaccount-password-button myaccount-password-button-cancel\"\n        (click)=\"onCancel()\"\n      >\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n      <button\n        class=\"btn btn-primary myaccount-password-button\"\n        [disabled]=\"form.disabled\"\n      >\n        {{ 'common.save' | cxTranslate }}\n      </button>\n    </div>\n  </fieldset>\n</form>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: MessageComponent, selector: "cx-message", inputs: ["text", "actionButtonText", "actionButtonMessage", "accordionText", "showBody", "isVisibleCloseButton", "type"], outputs: ["closeMessage", "buttonAction"] }, { kind: "directive", type: PasswordVisibilityToggleDirective, selector: "[cxPasswordVisibilitySwitch][type=\"password\"]" }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: FeatureDirective, selector: "[cxFeature]", inputs: ["cxFeature"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MyAccountV2PasswordComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-my-account-v2-password', changeDetection: ChangeDetectionStrategy.OnPush, host: { ngSkipHydration: 'true' }, imports: [
                        NgIf,
                        SpinnerComponent,
                        FormsModule,
                        ReactiveFormsModule,
                        MessageComponent,
                        PasswordVisibilityToggleDirective,
                        FormErrorsComponent,
                        AsyncPipe,
                        TranslatePipe,
                        FeatureDirective,
                    ], template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"> </cx-spinner>\n\n<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n  <fieldset>\n    <legend\n      *cxFeature=\"'a11yFormFieldSectionLegend'\"\n      class=\"myaccount-password-header\"\n    >\n      {{ 'myAccountV2PasswordForm.newPasswordTitle' | cxTranslate }}\n    </legend>\n\n    <cx-message\n      *ngIf=\"showingAlert\"\n      [text]=\"'myAccountV2PasswordForm.reloginIndicator' | cxTranslate\"\n      [type]=\"globalMessageType.MSG_TYPE_INFO\"\n      (closeMessage)=\"closeDialogConfirmationAlert()\"\n    >\n    </cx-message>\n\n    <label class=\"myaccount-label-padding\">\n      <span class=\"label-content myaccount-password-label\">{{\n        'myAccountV2PasswordForm.oldPassword.label' | cxTranslate\n      }}</span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        [(ngModel)]=\"oldPassword\"\n        type=\"password\"\n        name=\"oldPassword\"\n        placeholder=\"{{\n          'myAccountV2PasswordForm.oldPassword.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"oldPassword\"\n        [attr.aria-label]=\"\n          'myAccountV2PasswordForm.oldPassword.placeholder' | cxTranslate\n        \"\n        [attr.aria-invalid]=\"\n          form.get('oldPassword')?.touched && form.get('oldPassword')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'oldPasswordError'\"\n        cxPasswordVisibilitySwitch\n      />\n\n      <cx-form-errors\n        id=\"oldPasswordError\"\n        [translationParams]=\"{\n          label: 'updatePasswordForm.oldPassword.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('oldPassword')\"\n      ></cx-form-errors>\n    </label>\n\n    <label class=\"myaccount-label-padding\">\n      <span class=\"label-content myaccount-password-label\">{{\n        'myAccountV2PasswordForm.newPassword.label' | cxTranslate\n      }}</span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        [(ngModel)]=\"newPassword\"\n        type=\"password\"\n        name=\"newPassword\"\n        placeholder=\"{{\n          'myAccountV2PasswordForm.newPassword.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"newPassword\"\n        [attr.aria-label]=\"\n          'myAccountV2PasswordForm.newPassword.placeholder' | cxTranslate\n        \"\n        [attr.aria-invalid]=\"\n          form.get('newPassword')?.touched && form.get('newPassword')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'newPasswordError'\"\n        cxPasswordVisibilitySwitch\n      />\n\n      <cx-form-errors\n        id=\"newPasswordError\"\n        [translationParams]=\"{\n          label: 'updatePasswordForm.newPassword.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('newPassword')\"\n      ></cx-form-errors>\n    </label>\n\n    <label class=\"myaccount-label-padding\">\n      <span class=\"label-content myaccount-password-label\">{{\n        'myAccountV2PasswordForm.confirmPassword.label' | cxTranslate\n      }}</span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        [(ngModel)]=\"newPasswordConfirm\"\n        type=\"password\"\n        name=\"newPasswordConfirm\"\n        placeholder=\"{{\n          'myAccountV2PasswordForm.confirmPassword.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"newPasswordConfirm\"\n        [attr.aria-label]=\"\n          'myAccountV2PasswordForm.confirmPassword.placeholder' | cxTranslate\n        \"\n        [attr.aria-invalid]=\"\n          form.get('newPasswordConfirm')?.touched &&\n          form.get('newPasswordConfirm')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'newPasswordConfirmError'\"\n        cxPasswordVisibilitySwitch\n      />\n\n      <cx-form-errors\n        id=\"newPasswordConfirmError\"\n        [translationParams]=\"{\n          label: 'updatePasswordForm.confirmPassword.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('newPasswordConfirm')\"\n      ></cx-form-errors>\n    </label>\n\n    <div class=\"password-btn-group\">\n      <button\n        class=\"btn myaccount-password-button myaccount-password-button-cancel\"\n        (click)=\"onCancel()\"\n      >\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n      <button\n        class=\"btn btn-primary myaccount-password-button\"\n        [disabled]=\"form.disabled\"\n      >\n        {{ 'common.save' | cxTranslate }}\n      </button>\n    </div>\n  </fieldset>\n</form>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const myAccountV2PasswordMapping = {
    cmsComponents: {
        UpdatePasswordComponent: {
            component: MyAccountV2PasswordComponent,
        },
    },
};
class UpdatePasswordModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdatePasswordModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: UpdatePasswordModule, imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            SpinnerModule,
            I18nModule,
            FormErrorsModule,
            UrlModule,
            RouterModule,
            PasswordVisibilityToggleModule,
            FeaturesConfigModule,
            MessageComponentModule,
            BtnLikeLinkModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            UpdatePasswordComponent,
            MyAccountV2PasswordComponent], exports: [UpdatePasswordComponent, MyAccountV2PasswordComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdatePasswordModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    UpdatePasswordComponent: {
                        component: UpdatePasswordComponent,
                        guards: [AuthGuard],
                        providers: [
                            {
                                provide: UpdatePasswordComponentService,
                                useClass: UpdatePasswordComponentService,
                                deps: [
                                    UserPasswordFacade,
                                    RoutingService,
                                    GlobalMessageService,
                                    AuthRedirectService,
                                    AuthService,
                                ],
                            },
                        ],
                    },
                },
            }),
            provideDefaultConfigFactory(() => inject(USE_MY_ACCOUNT_V2_PASSWORD) ? myAccountV2PasswordMapping : {}),
        ], imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            SpinnerModule,
            I18nModule,
            FormErrorsModule,
            UrlModule,
            RouterModule,
            PasswordVisibilityToggleModule,
            FeaturesConfigModule,
            MessageComponentModule,
            BtnLikeLinkModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            UpdatePasswordComponent,
            MyAccountV2PasswordComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdatePasswordModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        SpinnerModule,
                        I18nModule,
                        FormErrorsModule,
                        UrlModule,
                        RouterModule,
                        PasswordVisibilityToggleModule,
                        FeaturesConfigModule,
                        MessageComponentModule,
                        BtnLikeLinkModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        UpdatePasswordComponent,
                        MyAccountV2PasswordComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                UpdatePasswordComponent: {
                                    component: UpdatePasswordComponent,
                                    guards: [AuthGuard],
                                    providers: [
                                        {
                                            provide: UpdatePasswordComponentService,
                                            useClass: UpdatePasswordComponentService,
                                            deps: [
                                                UserPasswordFacade,
                                                RoutingService,
                                                GlobalMessageService,
                                                AuthRedirectService,
                                                AuthService,
                                            ],
                                        },
                                    ],
                                },
                            },
                        }),
                        provideDefaultConfigFactory(() => inject(USE_MY_ACCOUNT_V2_PASSWORD) ? myAccountV2PasswordMapping : {}),
                    ],
                    exports: [UpdatePasswordComponent, MyAccountV2PasswordComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UpdateProfileComponentService {
    constructor(userProfile, globalMessageService) {
        this.userProfile = userProfile;
        this.globalMessageService = globalMessageService;
        this.user$ = this.userProfile
            .get()
            .pipe(filter((user) => Boolean(user)));
        this.busy$ = new BehaviorSubject(false);
        this.updateSucceed$ = new Subject();
        this.isUpdating$ = this.user$.pipe(tap((user) => this.form.patchValue(user)), switchMap((_user) => this.busy$), tap((state) => (state === true ? this.form.disable() : this.form.enable())));
        this.titles$ = this.userProfile.getTitles();
        this.form = new UntypedFormGroup({
            customerId: new UntypedFormControl(''),
            titleCode: new UntypedFormControl(''),
            firstName: new UntypedFormControl('', Validators.required),
            lastName: new UntypedFormControl('', Validators.required),
        });
    }
    /**
     * Updates the user's details and handles the UI.
     */
    updateProfile() {
        if (!this.form.valid) {
            this.form.markAllAsTouched();
            return;
        }
        this.busy$.next(true);
        this.userProfile.update(this.form.value).subscribe({
            next: () => this.onSuccess(),
            error: (error) => this.onError(error),
        });
    }
    onSuccess() {
        this.globalMessageService.add({
            key: 'updateProfileForm.profileUpdateSuccess',
        }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
        this.busy$.next(false);
        this.form.reset();
        this.updateSucceed$.next(true);
    }
    onError(_error) {
        this.busy$.next(false);
        this.updateSucceed$.next(false);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdateProfileComponentService, deps: [{ token: i1.UserProfileFacade }, { token: i2.GlobalMessageService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdateProfileComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdateProfileComponentService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.UserProfileFacade }, { type: i2.GlobalMessageService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UpdateProfileComponent {
    constructor(service) {
        this.service = service;
        this.routingService = inject(RoutingService, {
            optional: true,
        });
        this.pageMetaService = inject(PageMetaService);
        this.form = this.service.form;
        this.isUpdating$ = this.service.isUpdating$;
        this.titles$ = this.service.titles$;
        this.pageTitle$ = getPageTitle(this.pageMetaService);
    }
    onSubmit() {
        this.service.updateProfile();
    }
    navigateTo(cxRoute) {
        this.routingService?.go({ cxRoute });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdateProfileComponent, deps: [{ token: UpdateProfileComponentService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: UpdateProfileComponent, isStandalone: true, selector: "cx-update-profile", host: { classAttribute: "user-form" }, ngImport: i0, template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"> </cx-spinner>\n<cx-form-required-legend />\n<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n  <fieldset>\n    <legend\n      *cxFeature=\"'a11yFormFieldSectionLegend'\"\n      class=\"cx-visually-hidden\"\n    >\n      {{ pageTitle$ | async }}\n    </legend>\n    <label>\n      <span class=\"label-content\">{{\n        'updateProfileForm.title' | cxTranslate\n      }}</span>\n      <ng-select\n        [clearable]=\"false\"\n        [searchable]=\"false\"\n        formControlName=\"titleCode\"\n        id=\"title-select\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n        [cxNgSelectA11y]=\"{\n          ariaLabel: 'updateProfileForm.title' | cxTranslate,\n        }\"\n      >\n        <ng-option *ngFor=\"let title of titles$ | async\" [value]=\"title.code\">{{\n          title.name\n        }}</ng-option>\n      </ng-select>\n    </label>\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updateProfileForm.firstName.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"text\"\n        class=\"form-control\"\n        name=\"firstName\"\n        placeholder=\"{{\n          'updateProfileForm.firstName.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"firstName\"\n        [attr.aria-invalid]=\"\n          form.get('firstName')?.touched && form.get('firstName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'firstNameError'\"\n      />\n\n      <cx-form-errors\n        id=\"firstNameError\"\n        [translationParams]=\"{\n          label: 'updateProfileForm.firstName.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('firstName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updateProfileForm.lastName.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"text\"\n        class=\"form-control\"\n        name=\"lastName\"\n        placeholder=\"{{\n          'updateProfileForm.lastName.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"lastName\"\n        [attr.aria-invalid]=\"\n          form.get('lastName')?.touched && form.get('lastName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'lastNameError'\"\n      />\n\n      <cx-form-errors\n        id=\"lastNameError\"\n        [translationParams]=\"{\n          label: 'updateProfileForm.lastName.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('lastName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updateProfileForm.customerId' | cxTranslate }}\n        <cx-form-required-asterisks *cxFeature=\"'showRequiredAsterisks'\" />\n      </span>\n      <input\n        required=\"true\"\n        type=\"text\"\n        class=\"form-control\"\n        name=\"customerId\"\n        formControlName=\"customerId\"\n        cxTruncationTooltip\n        [attr.aria-invalid]=\"\n          form.get('customerId')?.touched && form.get('customerId')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'customerIdError'\"\n        readonly\n      />\n\n      <cx-form-errors\n        id=\"customerIdError\"\n        [translationParams]=\"{\n          label: 'updateProfileForm.customerId' | cxTranslate,\n        }\"\n        [control]=\"form.get('customerId')\"\n      ></cx-form-errors>\n    </label>\n\n    <button\n      type=\"button\"\n      class=\"btn btn-block btn-secondary\"\n      (click)=\"navigateTo('home')\"\n    >\n      {{ 'common.cancel' | cxTranslate }}\n    </button>\n    <button class=\"btn btn-block btn-primary\" [disabled]=\"form.disabled\">\n      {{ 'common.save' | cxTranslate }}\n    </button>\n  </fieldset>\n</form>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "directive", type: NgSelectA11yDirective, selector: "[cxNgSelectA11y]", inputs: ["cxNgSelectA11y"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: NgOptionComponent, selector: "ng-option", inputs: ["value", "disabled"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: FeatureDirective, selector: "[cxFeature]", inputs: ["cxFeature"] }, { kind: "directive", type: TruncationTooltipDirective, selector: "[cxTruncationTooltip]" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdateProfileComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-update-profile', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'user-form' }, imports: [
                        NgIf,
                        SpinnerComponent,
                        FormRequiredLegendComponent,
                        FormsModule,
                        ReactiveFormsModule,
                        NgSelectComponent,
                        NgSelectA11yDirective,
                        NgFor,
                        NgOptionComponent,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        AsyncPipe,
                        TranslatePipe,
                        FeatureDirective,
                        TruncationTooltipDirective,
                    ], template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"> </cx-spinner>\n<cx-form-required-legend />\n<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n  <fieldset>\n    <legend\n      *cxFeature=\"'a11yFormFieldSectionLegend'\"\n      class=\"cx-visually-hidden\"\n    >\n      {{ pageTitle$ | async }}\n    </legend>\n    <label>\n      <span class=\"label-content\">{{\n        'updateProfileForm.title' | cxTranslate\n      }}</span>\n      <ng-select\n        [clearable]=\"false\"\n        [searchable]=\"false\"\n        formControlName=\"titleCode\"\n        id=\"title-select\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n        [cxNgSelectA11y]=\"{\n          ariaLabel: 'updateProfileForm.title' | cxTranslate,\n        }\"\n      >\n        <ng-option *ngFor=\"let title of titles$ | async\" [value]=\"title.code\">{{\n          title.name\n        }}</ng-option>\n      </ng-select>\n    </label>\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updateProfileForm.firstName.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"text\"\n        class=\"form-control\"\n        name=\"firstName\"\n        placeholder=\"{{\n          'updateProfileForm.firstName.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"firstName\"\n        [attr.aria-invalid]=\"\n          form.get('firstName')?.touched && form.get('firstName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'firstNameError'\"\n      />\n\n      <cx-form-errors\n        id=\"firstNameError\"\n        [translationParams]=\"{\n          label: 'updateProfileForm.firstName.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('firstName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updateProfileForm.lastName.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"text\"\n        class=\"form-control\"\n        name=\"lastName\"\n        placeholder=\"{{\n          'updateProfileForm.lastName.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"lastName\"\n        [attr.aria-invalid]=\"\n          form.get('lastName')?.touched && form.get('lastName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'lastNameError'\"\n      />\n\n      <cx-form-errors\n        id=\"lastNameError\"\n        [translationParams]=\"{\n          label: 'updateProfileForm.lastName.label' | cxTranslate,\n        }\"\n        [control]=\"form.get('lastName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\"\n        >{{ 'updateProfileForm.customerId' | cxTranslate }}\n        <cx-form-required-asterisks *cxFeature=\"'showRequiredAsterisks'\" />\n      </span>\n      <input\n        required=\"true\"\n        type=\"text\"\n        class=\"form-control\"\n        name=\"customerId\"\n        formControlName=\"customerId\"\n        cxTruncationTooltip\n        [attr.aria-invalid]=\"\n          form.get('customerId')?.touched && form.get('customerId')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'customerIdError'\"\n        readonly\n      />\n\n      <cx-form-errors\n        id=\"customerIdError\"\n        [translationParams]=\"{\n          label: 'updateProfileForm.customerId' | cxTranslate,\n        }\"\n        [control]=\"form.get('customerId')\"\n      ></cx-form-errors>\n    </label>\n\n    <button\n      type=\"button\"\n      class=\"btn btn-block btn-secondary\"\n      (click)=\"navigateTo('home')\"\n    >\n      {{ 'common.cancel' | cxTranslate }}\n    </button>\n    <button class=\"btn btn-block btn-primary\" [disabled]=\"form.disabled\">\n      {{ 'common.save' | cxTranslate }}\n    </button>\n  </fieldset>\n</form>\n" }]
        }], ctorParameters: () => [{ type: UpdateProfileComponentService }], propDecorators: { routingService: [{
                type: Optional
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class MyAccountV2ProfileComponent {
    constructor() {
        this.service = inject(UpdateProfileComponentService);
        this.pageMetaService = inject(PageMetaService);
        this.form = this.service.form;
        this.isUpdating$ = this.service.isUpdating$;
        this.titles$ = this.service.titles$;
        this.user$ = this.service.user$;
        this.pageTitle$ = getPageTitle(this.pageMetaService);
    }
    ngOnInit() {
        this.isEditing = false;
    }
    onSubmit() {
        this.service.updateProfile();
        this.service.updateSucceed$.subscribe((res) => {
            this.isEditing = !res;
        });
    }
    cancelEdit() {
        this.isEditing = false;
        this.form.setValue(this.originalEditValue);
    }
    onEdit() {
        this.isEditing = true;
        this.originalEditValue = this.form.value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MyAccountV2ProfileComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: MyAccountV2ProfileComponent, isStandalone: true, selector: "cx-my-account-v2-profile", ngImport: i0, template: "<cx-spinner class=\"overlay\" *ngIf=\"(isUpdating$ | async) || !(user$ | async)\">\n</cx-spinner>\n<div>\n  <div>\n    <div class=\"flex-line\">\n      <span class=\"headertext\">{{\n        'myAccountV2UserProfile.myInformation' | cxTranslate\n      }}</span>\n      <button class=\"editButton\" *ngIf=\"!isEditing\" (click)=\"onEdit()\">\n        {{ 'common.edit' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n  <div *ngIf=\"!isEditing\">\n    <div class=\"flex-line\">\n      <label class=\"text-head\">\n        {{ 'myAccountV2UserProfile.title' | cxTranslate }}\n      </label>\n      <label class=\"value\">\n        {{ (user$ | async)?.title }}\n      </label>\n    </div>\n    <div class=\"flex-line\">\n      <label class=\"text-head\">\n        {{ 'myAccountV2UserProfile.name' | cxTranslate }}\n      </label>\n      <label class=\"value\">\n        {{ (user$ | async)?.firstName }} {{ (user$ | async)?.lastName }}\n      </label>\n    </div>\n    <div class=\"flex-line\">\n      <label class=\"text-head\">\n        {{ 'myAccountV2UserProfile.customerId' | cxTranslate }}\n      </label>\n      <label class=\"value\">\n        {{ (user$ | async)?.customerId }}\n      </label>\n    </div>\n  </div>\n  <div *ngIf=\"isEditing\" class=\"myaccount-editing-area\">\n    <form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n      <fieldset>\n        <legend *cxFeature=\"'a11yFormFieldSectionLegend'\" class=\"headertext\">\n          {{ 'myAccountV2UserProfile.myInformation' | cxTranslate }}\n        </legend>\n        <label>\n          <span class=\"label-content, text-head\">{{\n            'myAccountV2UserProfile.title' | cxTranslate\n          }}</span>\n          <ng-select\n            [clearable]=\"false\"\n            [searchable]=\"false\"\n            formControlName=\"titleCode\"\n            id=\"title-select\"\n            ariaLabelDropdown=\"{{\n              'common.ngSelectDropdownOptionsList' | cxTranslate\n            }}\"\n            [cxNgSelectA11y]=\"{\n              ariaLabel: 'myAccountV2UserProfile.title' | cxTranslate,\n            }\"\n          >\n            <ng-option\n              *ngFor=\"let title of titles$ | async\"\n              [value]=\"title.code\"\n              >{{ title.name }}</ng-option\n            >\n          </ng-select>\n        </label>\n        <label>\n          <span class=\"label-content, text-head\">{{\n            'myAccountV2UserProfile.firstName' | cxTranslate\n          }}</span>\n          <input\n            required=\"true\"\n            type=\"text\"\n            class=\"form-control\"\n            name=\"firstName\"\n            formControlName=\"firstName\"\n            [attr.aria-invalid]=\"\n              form.get('firstName')?.touched && form.get('firstName')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'firstNameError'\"\n          />\n          <cx-form-errors\n            id=\"firstNameError\"\n            [translationParams]=\"{\n              label: 'updateProfileForm.firstName.label' | cxTranslate,\n            }\"\n            [control]=\"form.get('firstName')\"\n          ></cx-form-errors>\n        </label>\n\n        <label>\n          <span class=\"label-content, text-head\">{{\n            'myAccountV2UserProfile.lastName' | cxTranslate\n          }}</span>\n          <input\n            required=\"true\"\n            type=\"text\"\n            class=\"form-control\"\n            name=\"lastName\"\n            formControlName=\"lastName\"\n            [attr.aria-invalid]=\"\n              form.get('lastName')?.touched && form.get('lastName')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'lastNameError'\"\n          />\n          <cx-form-errors\n            id=\"lastNameError\"\n            [translationParams]=\"{\n              label: 'updateProfileForm.lastName.label' | cxTranslate,\n            }\"\n            [control]=\"form.get('lastName')\"\n          ></cx-form-errors>\n        </label>\n\n        <label>\n          <span class=\"label-content, text-head\">{{\n            'myAccountV2UserProfile.customerId' | cxTranslate\n          }}</span>\n          <input\n            required=\"true\"\n            type=\"text\"\n            class=\"form-control\"\n            name=\"customerId\"\n            formControlName=\"customerId\"\n            cxTruncationTooltip\n            [attr.aria-invalid]=\"\n              form.get('customerId')?.touched && form.get('customerId')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'customerIdError'\"\n            readonly\n          />\n          <cx-form-errors\n            id=\"customerIdError\"\n            [translationParams]=\"{\n              label: 'updateProfileForm.customerId' | cxTranslate,\n            }\"\n            [control]=\"form.get('customerId')\"\n          ></cx-form-errors>\n        </label>\n      </fieldset>\n    </form>\n\n    <div class=\"btn-group\">\n      <button class=\"btn button-cancel button\" (click)=\"cancelEdit()\">\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n      <button\n        class=\"btn btn-primary button\"\n        (click)=\"onSubmit()\"\n        [disabled]=\"form.disabled\"\n      >\n        {{ 'common.save' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "directive", type: NgSelectA11yDirective, selector: "[cxNgSelectA11y]", inputs: ["cxNgSelectA11y"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: NgOptionComponent, selector: "ng-option", inputs: ["value", "disabled"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: TruncationTooltipDirective, selector: "[cxTruncationTooltip]" }, { kind: "directive", type: FeatureDirective, selector: "[cxFeature]", inputs: ["cxFeature"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MyAccountV2ProfileComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-my-account-v2-profile', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        SpinnerComponent,
                        FormsModule,
                        ReactiveFormsModule,
                        NgSelectComponent,
                        NgSelectA11yDirective,
                        NgFor,
                        NgOptionComponent,
                        FormErrorsComponent,
                        AsyncPipe,
                        TranslatePipe,
                        TruncationTooltipDirective,
                        FeatureDirective,
                    ], template: "<cx-spinner class=\"overlay\" *ngIf=\"(isUpdating$ | async) || !(user$ | async)\">\n</cx-spinner>\n<div>\n  <div>\n    <div class=\"flex-line\">\n      <span class=\"headertext\">{{\n        'myAccountV2UserProfile.myInformation' | cxTranslate\n      }}</span>\n      <button class=\"editButton\" *ngIf=\"!isEditing\" (click)=\"onEdit()\">\n        {{ 'common.edit' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n  <div *ngIf=\"!isEditing\">\n    <div class=\"flex-line\">\n      <label class=\"text-head\">\n        {{ 'myAccountV2UserProfile.title' | cxTranslate }}\n      </label>\n      <label class=\"value\">\n        {{ (user$ | async)?.title }}\n      </label>\n    </div>\n    <div class=\"flex-line\">\n      <label class=\"text-head\">\n        {{ 'myAccountV2UserProfile.name' | cxTranslate }}\n      </label>\n      <label class=\"value\">\n        {{ (user$ | async)?.firstName }} {{ (user$ | async)?.lastName }}\n      </label>\n    </div>\n    <div class=\"flex-line\">\n      <label class=\"text-head\">\n        {{ 'myAccountV2UserProfile.customerId' | cxTranslate }}\n      </label>\n      <label class=\"value\">\n        {{ (user$ | async)?.customerId }}\n      </label>\n    </div>\n  </div>\n  <div *ngIf=\"isEditing\" class=\"myaccount-editing-area\">\n    <form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n      <fieldset>\n        <legend *cxFeature=\"'a11yFormFieldSectionLegend'\" class=\"headertext\">\n          {{ 'myAccountV2UserProfile.myInformation' | cxTranslate }}\n        </legend>\n        <label>\n          <span class=\"label-content, text-head\">{{\n            'myAccountV2UserProfile.title' | cxTranslate\n          }}</span>\n          <ng-select\n            [clearable]=\"false\"\n            [searchable]=\"false\"\n            formControlName=\"titleCode\"\n            id=\"title-select\"\n            ariaLabelDropdown=\"{{\n              'common.ngSelectDropdownOptionsList' | cxTranslate\n            }}\"\n            [cxNgSelectA11y]=\"{\n              ariaLabel: 'myAccountV2UserProfile.title' | cxTranslate,\n            }\"\n          >\n            <ng-option\n              *ngFor=\"let title of titles$ | async\"\n              [value]=\"title.code\"\n              >{{ title.name }}</ng-option\n            >\n          </ng-select>\n        </label>\n        <label>\n          <span class=\"label-content, text-head\">{{\n            'myAccountV2UserProfile.firstName' | cxTranslate\n          }}</span>\n          <input\n            required=\"true\"\n            type=\"text\"\n            class=\"form-control\"\n            name=\"firstName\"\n            formControlName=\"firstName\"\n            [attr.aria-invalid]=\"\n              form.get('firstName')?.touched && form.get('firstName')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'firstNameError'\"\n          />\n          <cx-form-errors\n            id=\"firstNameError\"\n            [translationParams]=\"{\n              label: 'updateProfileForm.firstName.label' | cxTranslate,\n            }\"\n            [control]=\"form.get('firstName')\"\n          ></cx-form-errors>\n        </label>\n\n        <label>\n          <span class=\"label-content, text-head\">{{\n            'myAccountV2UserProfile.lastName' | cxTranslate\n          }}</span>\n          <input\n            required=\"true\"\n            type=\"text\"\n            class=\"form-control\"\n            name=\"lastName\"\n            formControlName=\"lastName\"\n            [attr.aria-invalid]=\"\n              form.get('lastName')?.touched && form.get('lastName')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'lastNameError'\"\n          />\n          <cx-form-errors\n            id=\"lastNameError\"\n            [translationParams]=\"{\n              label: 'updateProfileForm.lastName.label' | cxTranslate,\n            }\"\n            [control]=\"form.get('lastName')\"\n          ></cx-form-errors>\n        </label>\n\n        <label>\n          <span class=\"label-content, text-head\">{{\n            'myAccountV2UserProfile.customerId' | cxTranslate\n          }}</span>\n          <input\n            required=\"true\"\n            type=\"text\"\n            class=\"form-control\"\n            name=\"customerId\"\n            formControlName=\"customerId\"\n            cxTruncationTooltip\n            [attr.aria-invalid]=\"\n              form.get('customerId')?.touched && form.get('customerId')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'customerIdError'\"\n            readonly\n          />\n          <cx-form-errors\n            id=\"customerIdError\"\n            [translationParams]=\"{\n              label: 'updateProfileForm.customerId' | cxTranslate,\n            }\"\n            [control]=\"form.get('customerId')\"\n          ></cx-form-errors>\n        </label>\n      </fieldset>\n    </form>\n\n    <div class=\"btn-group\">\n      <button class=\"btn button-cancel button\" (click)=\"cancelEdit()\">\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n      <button\n        class=\"btn btn-primary button\"\n        (click)=\"onSubmit()\"\n        [disabled]=\"form.disabled\"\n      >\n        {{ 'common.save' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const USE_MY_ACCOUNT_V2_PROFILE = new InjectionToken('feature flag to enable enhanced UI for profile related pages under My-Account', { providedIn: 'root', factory: () => false });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const myAccountV2ProfileMapping = {
    cmsComponents: {
        UpdateProfileComponent: {
            component: MyAccountV2ProfileComponent,
        },
    },
};
class UpdateProfileModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdateProfileModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: UpdateProfileModule, imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            SpinnerModule,
            I18nModule,
            FormErrorsModule,
            RouterModule,
            UrlModule,
            NgSelectModule,
            NgSelectA11yModule,
            FeaturesConfigModule,
            BtnLikeLinkModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            UpdateProfileComponent,
            MyAccountV2ProfileComponent], exports: [UpdateProfileComponent, MyAccountV2ProfileComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdateProfileModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    UpdateProfileComponent: {
                        component: UpdateProfileComponent,
                        guards: [AuthGuard],
                        providers: [
                            {
                                provide: UpdateProfileComponentService,
                                useClass: UpdateProfileComponentService,
                                deps: [UserProfileFacade, GlobalMessageService],
                            },
                        ],
                    },
                },
            }),
            provideDefaultConfigFactory(() => inject(USE_MY_ACCOUNT_V2_PROFILE) ? myAccountV2ProfileMapping : {}),
        ], imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            SpinnerModule,
            I18nModule,
            FormErrorsModule,
            RouterModule,
            UrlModule,
            NgSelectModule,
            NgSelectA11yModule,
            FeaturesConfigModule,
            BtnLikeLinkModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            UpdateProfileComponent,
            MyAccountV2ProfileComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UpdateProfileModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        SpinnerModule,
                        I18nModule,
                        FormErrorsModule,
                        RouterModule,
                        UrlModule,
                        NgSelectModule,
                        NgSelectA11yModule,
                        FeaturesConfigModule,
                        BtnLikeLinkModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        UpdateProfileComponent,
                        MyAccountV2ProfileComponent,
                    ],
                    exports: [UpdateProfileComponent, MyAccountV2ProfileComponent],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                UpdateProfileComponent: {
                                    component: UpdateProfileComponent,
                                    guards: [AuthGuard],
                                    providers: [
                                        {
                                            provide: UpdateProfileComponentService,
                                            useClass: UpdateProfileComponentService,
                                            deps: [UserProfileFacade, GlobalMessageService],
                                        },
                                    ],
                                },
                            },
                        }),
                        provideDefaultConfigFactory(() => inject(USE_MY_ACCOUNT_V2_PROFILE) ? myAccountV2ProfileMapping : {}),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AddressFormComponent {
    constructor(fb, userAddressService, globalMessageService, translation, launchDialogService, userProfileFacade) {
        this.fb = fb;
        this.userAddressService = userAddressService;
        this.globalMessageService = globalMessageService;
        this.translation = translation;
        this.launchDialogService = launchDialogService;
        this.userProfileFacade = userProfileFacade;
        this.languageService = inject(LanguageService);
        this.cdr = inject(ChangeDetectorRef);
        this.featureToggles = inject(FeatureToggles);
        this.hierarchicalAddressConfig = inject(HierarchicalAddressConfig);
        this.selectedCountry$ = new BehaviorSubject('');
        this.selectedRegion$ = new BehaviorSubject('');
        this.selectedCity$ = new BehaviorSubject('');
        this.isHierarchicalAddressFormat = false;
        this.cities = [];
        this.districts = [];
        this.setAsDefaultField = true;
        this.showCancelBtn = true;
        this.submitAddress = new EventEmitter();
        this.backToAddress = new EventEmitter();
        this.subscription = new Subscription();
        this.addressForm = this.fb.group({
            country: this.fb.group({
                isocode: [null, Validators.required],
            }),
            titleCode: [''],
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            line1: ['', Validators.required],
            line2: [''],
            town: ['', Validators.required],
            region: this.fb.group({
                isocode: [null, Validators.required],
            }),
            district: [null],
            postalCode: ['', Validators.required],
            phone: '',
            cellphone: '',
            defaultAddress: [false],
        });
    }
    ngOnInit() {
        // Fetching countries if no data stream was provided
        this.countries$ =
            this.countries ||
                this.userAddressService.getDeliveryCountries().pipe(tap((countries) => {
                    if (Object.keys(countries).length === 0) {
                        this.userAddressService.loadDeliveryCountries();
                    }
                }));
        // Fetching titles
        this.titles$ = this.getTitles();
        // Fetching regions
        this.regions$ = this.selectedCountry$.pipe(switchMap((country) => this.userAddressService.getRegions(country)), tap((regions) => {
            const regionControl = this.addressForm.get('region.isocode');
            if (regions && regions.length > 0) {
                regionControl?.enable();
            }
            else {
                regionControl?.disable();
            }
        }));
        if (this.addressData && Object.keys(this.addressData).length !== 0) {
            if (this.featureToggles.enableHierarchicalAddressFormat) {
                this.countrySelected(this.addressData.country);
                this.addressForm.patchValue(this.addressData);
            }
            else {
                this.addressForm.patchValue(this.addressData);
                this.countrySelected(this.addressData.country);
            }
            if (this.addressData.region) {
                this.regionSelected(this.addressData.region);
            }
        }
        this.addresses$ = this.userAddressService.getAddresses();
        if (this.featureToggles.enableHierarchicalAddressFormat) {
            this.initCitiesSubscription();
            this.initDistrictsSubscription();
            this.initLanguageSubscription();
        }
    }
    initCitiesSubscription() {
        this.subscription.add(this.selectedRegion$
            .pipe(switchMap((regionIsocode) => {
            if (!this.isHierarchicalAddressFormat || !regionIsocode) {
                return of([]);
            }
            return this.userAddressService.getCities(regionIsocode);
        }))
            .subscribe((cities) => {
            this.cities = cities;
            const townControl = this.addressForm.get('town');
            if (this.isHierarchicalAddressFormat && !this.selectedRegion$.value) {
                townControl?.disable();
            }
            else {
                townControl?.enable();
            }
            if (this.addressData?.city?.isocode &&
                !this.selectedCity$.value &&
                this.selectedRegion$.value === this.addressData.region?.isocode) {
                this.selectedCity$.next(this.addressData.city.isocode);
                this.addressForm
                    .get('town')
                    ?.setValue(this.addressData.city.isocode);
            }
            this.cdr.markForCheck();
        }));
    }
    initDistrictsSubscription() {
        this.subscription.add(this.selectedCity$
            .pipe(switchMap((cityIsocode) => {
            if (!this.isHierarchicalAddressFormat) {
                return of([]);
            }
            return this.userAddressService.getDistricts(cityIsocode);
        }))
            .subscribe((districts) => {
            this.districts = districts;
            if (this.addressData?.cityDistrict?.isocode &&
                this.selectedCity$.value === this.addressData.city?.isocode) {
                this.addressForm
                    .get('district')
                    ?.setValue(this.addressData.cityDistrict.isocode);
            }
            this.cdr.markForCheck();
        }));
    }
    initLanguageSubscription() {
        this.subscription.add(this.languageService
            .getActive()
            .pipe(skip(1))
            .subscribe(() => {
            if (this.isHierarchicalAddressFormat) {
                this.userAddressService.clearRegions();
                if (this.selectedRegion$.value) {
                    this.userAddressService.clearCities();
                }
                if (this.selectedCity$.value) {
                    this.userAddressService.clearDistricts();
                }
            }
        }));
    }
    getTitles() {
        return combineLatest([
            this.translation.translate('addressForm.defaultTitle'),
            this.userProfileFacade.getTitles(),
        ]).pipe(map(([noneTitleText, titles]) => {
            const noneTitle = { code: '', name: noneTitleText };
            titles.sort(sortTitles);
            return [noneTitle, ...titles];
        }));
    }
    handleAddressVerificationResults(results) {
        if (results.decision === 'ACCEPT') {
            this.submitAddress.emit(this.addressForm.value);
        }
        else if (results.decision === 'REJECT') {
            // TODO: Workaround: allow server for decide is titleCode mandatory (if yes, provide personalized message)
            if (results.errors?.errors.some((error) => error.subject === 'titleCode')) {
                this.globalMessageService.add({ key: 'addressForm.titleRequired' }, GlobalMessageType.MSG_TYPE_ERROR);
            }
            else {
                this.globalMessageService.add({ key: 'addressForm.invalidAddress' }, GlobalMessageType.MSG_TYPE_ERROR);
            }
        }
        else if (results.decision === 'REVIEW') {
            this.openSuggestedAddress(results);
        }
    }
    countrySelected(country) {
        this.addressForm.get('country')?.get('isocode')?.setValue(country?.isocode);
        this.selectedCountry$.next(country?.isocode ?? '');
        if (!this.featureToggles.enableHierarchicalAddressFormat) {
            return;
        }
        this.isHierarchicalAddressFormat = (this.hierarchicalAddressConfig.hierarchicalAddress
            ?.countriesUsingHierarchicalAddressFormat ?? []).includes(country?.isocode ?? '');
        const cellphoneControl = this.addressForm.get('cellphone');
        const districtControl = this.addressForm.get('district');
        const townControl = this.addressForm.get('town');
        this.addressForm.get('region')?.get('isocode')?.reset();
        townControl?.reset();
        districtControl?.reset();
        this.selectedRegion$.next('');
        this.selectedCity$.next('');
        if (this.isHierarchicalAddressFormat) {
            cellphoneControl?.setValidators([Validators.required]);
            districtControl?.setValidators([Validators.required]);
        }
        else {
            cellphoneControl?.clearValidators();
            districtControl?.clearValidators();
            townControl?.enable();
            districtControl?.enable();
        }
        cellphoneControl?.updateValueAndValidity();
        districtControl?.updateValueAndValidity();
    }
    regionSelected(region) {
        this.addressForm.get('region')?.get('isocode')?.setValue(region.isocode);
        if (this.featureToggles.enableHierarchicalAddressFormat &&
            this.isHierarchicalAddressFormat) {
            this.selectedRegion$.next(region.isocode ?? '');
            this.addressForm.get('town')?.reset();
            this.selectedCity$.next('');
            this.addressForm.get('district')?.reset();
        }
    }
    citySelected(city) {
        if (city?.isocode) {
            this.selectedCity$.next(city.isocode);
            this.addressForm.get('district')?.reset();
        }
    }
    toggleDefaultAddress() {
        this.addressForm['controls'].defaultAddress.setValue(this.addressForm.value.defaultAddress);
    }
    back() {
        this.backToAddress.emit();
    }
    verifyAddress() {
        if (this.addressForm.valid) {
            const regionControl = this.addressForm.get('region');
            const isocode = regionControl?.value?.isocode;
            if (isocode) {
                this.regions$.pipe(take(1)).subscribe((regions) => {
                    if (regions.length) {
                        const selectedRegion = regions.find((region) => region.isocode === isocode);
                        regionControl?.patchValue({
                            isocodeShort: selectedRegion?.isocodeShort,
                        });
                    }
                    else {
                        regionControl?.reset();
                    }
                });
            }
            if (this.addressForm.dirty) {
                if (this.featureToggles.enableHierarchicalAddressFormat &&
                    this.isHierarchicalAddressFormat) {
                    this.submitAddress.emit(this.addressForm.value);
                }
                else {
                    this.subscription.add(this.userAddressService
                        .verifyAddress(this.addressForm.value)
                        .subscribe((value) => {
                        this.handleAddressVerificationResults(value);
                    }));
                }
            }
            else {
                // address form value not changed
                // ignore duplicate address
                this.submitAddress.emit(undefined);
            }
        }
        else {
            this.addressForm.markAllAsTouched();
            this.globalMessageService.add({ key: 'formErrors.globalMessage' }, GlobalMessageType.MSG_TYPE_ASSISTIVE);
        }
    }
    openSuggestedAddress(results) {
        this.launchDialogService.openDialogAndSubscribe(LAUNCH_CALLER.SUGGESTED_ADDRESSES, this.element, {
            enteredAddress: this.addressForm.value,
            suggestedAddresses: results.suggestedAddresses,
        });
        this.subscription.add(this.launchDialogService.dialogClose
            .pipe(filter((result) => Boolean(result)))
            .subscribe((result) => {
            if (typeof result === 'object') {
                const address = {
                    ...result,
                    titleCode: this.addressForm.value.titleCode,
                    phone: this.addressForm.value.phone,
                    selected: true,
                };
                this.submitAddress.emit(address);
            }
        }));
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddressFormComponent, deps: [{ token: i2$1.UntypedFormBuilder }, { token: i2.UserAddressService }, { token: i2.GlobalMessageService }, { token: i2.TranslationService }, { token: i3.LaunchDialogService }, { token: i1.UserProfileFacade }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: AddressFormComponent, isStandalone: true, selector: "cx-address-form", inputs: { addressData: "addressData", actionBtnLabel: "actionBtnLabel", cancelBtnLabel: "cancelBtnLabel", setAsDefaultField: "setAsDefaultField", showTitleCode: "showTitleCode", showCancelBtn: "showCancelBtn", countries: "countries" }, outputs: { submitAddress: "submitAddress", backToAddress: "backToAddress" }, viewQueries: [{ propertyName: "element", first: true, predicate: ["submit"], descendants: true }], ngImport: i0, template: "<cx-form-required-legend />\n<form (ngSubmit)=\"verifyAddress()\" [formGroup]=\"addressForm\">\n  <ng-container *cxFeature=\"'a11yAddressFormInitialFocus'\">\n    <div [cxFocus]=\"{ autofocus: true }\">\n      <ng-container *ngTemplateOutlet=\"formBody\" />\n    </div>\n  </ng-container>\n  <ng-container *cxFeature=\"'!a11yAddressFormInitialFocus'\">\n    <ng-container *ngTemplateOutlet=\"formBody\" />\n  </ng-container>\n\n  <ng-template #formBody>\n    <div class=\"form-group\" formGroupName=\"country\">\n      <ng-container *ngIf=\"countries$ | async as countries\">\n        <div *ngIf=\"countries.length !== 0\">\n          <label>\n            <span class=\"label-content required\"\n              >{{ 'addressForm.country' | cxTranslate }}\n              <cx-form-required-asterisks />\n            </span>\n            <ng-select\n              [inputAttrs]=\"{ required: 'true' }\"\n              class=\"country-select\"\n              id=\"country-select\"\n              formControlName=\"isocode\"\n              [searchable]=\"true\"\n              [clearable]=\"false\"\n              [items]=\"countries\"\n              bindLabel=\"name\"\n              bindValue=\"isocode\"\n              placeholder=\"{{ 'addressForm.selectOne' | cxTranslate }}\"\n              (change)=\"countrySelected($event)\"\n              ariaLabelDropdown=\"{{\n                'common.ngSelectDropdownOptionsList' | cxTranslate\n              }}\"\n              [cxNgSelectA11y]=\"{}\"\n            />\n            <cx-form-errors\n              [translationParams]=\"{\n                label: 'addressForm.country' | cxTranslate,\n              }\"\n              [control]=\"addressForm.get('country.isocode')\"\n            />\n          </label>\n        </div>\n      </ng-container>\n    </div>\n    <div class=\"form-group\" *ngIf=\"showTitleCode\">\n      <ng-container *ngIf=\"titles$ | async as titles\">\n        <div *ngIf=\"titles.length !== 0\">\n          <label>\n            <span class=\"label-content required\">{{\n              'addressForm.titleOptional' | cxTranslate\n            }}</span>\n            <ng-select\n              id=\"title-select\"\n              formControlName=\"titleCode\"\n              [searchable]=\"true\"\n              [clearable]=\"false\"\n              [items]=\"titles\"\n              bindLabel=\"name\"\n              bindValue=\"code\"\n              [placeholder]=\"'addressForm.title' | cxTranslate\"\n              ariaLabelDropdown=\"{{\n                'common.ngSelectDropdownOptionsList' | cxTranslate\n              }}\"\n              [cxNgSelectA11y]=\"{\n                ariaLabel: 'addressForm.titleOptional' | cxTranslate,\n              }\"\n            />\n          </label>\n        </div>\n      </ng-container>\n    </div>\n    <div class=\"form-group\">\n      <label>\n        <span class=\"label-content required\"\n          >{{ 'addressForm.firstName.label' | cxTranslate }}\n          <cx-form-required-asterisks />\n        </span>\n        <input\n          required=\"true\"\n          class=\"form-control\"\n          type=\"text\"\n          placeholder=\"{{ 'addressForm.firstName.placeholder' | cxTranslate }}\"\n          formControlName=\"firstName\"\n          [attr.aria-invalid]=\"\n            addressForm.get('firstName')?.touched &&\n            addressForm.get('firstName')?.invalid\n          \"\n          [attr.aria-errormessage]=\"'firstNameError'\"\n        />\n        <cx-form-errors\n          id=\"firstNameError\"\n          [translationParams]=\"{\n            label: 'addressForm.firstName.label' | cxTranslate,\n          }\"\n          [control]=\"addressForm.get('firstName')\"\n        />\n      </label>\n    </div>\n    <div class=\"form-group\">\n      <label>\n        <span class=\"label-content required\"\n          >{{ 'addressForm.lastName.label' | cxTranslate }}\n          <cx-form-required-asterisks />\n        </span>\n        <input\n          required=\"true\"\n          type=\"text\"\n          class=\"form-control\"\n          placeholder=\"{{ 'addressForm.lastName.placeholder' | cxTranslate }}\"\n          formControlName=\"lastName\"\n          [attr.aria-invalid]=\"\n            addressForm.get('lastName')?.touched &&\n            addressForm.get('lastName')?.invalid\n          \"\n          [attr.aria-errormessage]=\"'lastNameError'\"\n        />\n        <cx-form-errors\n          id=\"lastNameError\"\n          [translationParams]=\"{\n            label: 'addressForm.lastName.label' | cxTranslate,\n          }\"\n          [control]=\"addressForm.get('lastName')\"\n        />\n      </label>\n    </div>\n    <div class=\"form-group\">\n      <label>\n        <span class=\"label-content required\"\n          >{{ 'addressForm.address1' | cxTranslate }}\n          <cx-form-required-asterisks />\n        </span>\n        <input\n          required=\"true\"\n          type=\"text\"\n          class=\"form-control\"\n          placeholder=\"{{ 'addressForm.streetAddress' | cxTranslate }}\"\n          formControlName=\"line1\"\n          [attr.aria-invalid]=\"\n            addressForm.get('line1')?.touched &&\n            addressForm.get('line1')?.invalid\n          \"\n          [attr.aria-errormessage]=\"'line1Error'\"\n        />\n        <cx-form-errors\n          id=\"line1Error\"\n          [translationParams]=\"{\n            label: 'addressForm.address1' | cxTranslate,\n          }\"\n          [control]=\"addressForm.get('line1')\"\n        />\n      </label>\n    </div>\n    <div class=\"form-group\">\n      <label>\n        <span class=\"label-content\">{{\n          'addressForm.address2' | cxTranslate\n        }}</span>\n        <input\n          type=\"text\"\n          class=\"form-control\"\n          placeholder=\"{{ 'addressForm.aptSuite' | cxTranslate }}\"\n          formControlName=\"line2\"\n        />\n      </label>\n    </div>\n    <div class=\"row\">\n      <ng-container *cxFeature=\"'enableHierarchicalAddressFormat'\">\n        <ng-container *ngIf=\"isHierarchicalAddressFormat\">\n          <ng-container\n            *ngIf=\"regions$ | async as regions\"\n            formGroupName=\"region\"\n          >\n            <ng-container *ngIf=\"regions.length !== 0\">\n              <div class=\"form-group col-md-6\">\n                <label>\n                  <span class=\"label-content required\"\n                    >{{ 'addressForm.province' | cxTranslate }}\n                    <cx-form-required-asterisks />\n                  </span>\n                  <ng-select\n                    [inputAttrs]=\"{ required: 'true' }\"\n                    class=\"region-select\"\n                    formControlName=\"isocode\"\n                    [searchable]=\"true\"\n                    [clearable]=\"false\"\n                    [items]=\"regions\"\n                    bindLabel=\"{{ regions[0].name ? 'name' : 'isocode' }}\"\n                    bindValue=\"{{ regions[0].name ? 'isocode' : 'region' }}\"\n                    placeholder=\"{{ 'addressForm.selectOne' | cxTranslate }}\"\n                    (change)=\"regionSelected($event)\"\n                    id=\"region-select\"\n                    ariaLabelDropdown=\"{{\n                      'common.ngSelectDropdownOptionsList' | cxTranslate\n                    }}\"\n                    [cxNgSelectA11y]=\"{\n                      ariaLabel: 'addressForm.province' | cxTranslate,\n                    }\"\n                  />\n                  <cx-form-errors\n                    [translationParams]=\"{\n                      label: 'addressForm.province' | cxTranslate,\n                    }\"\n                    [control]=\"addressForm.get('region.isocode')\"\n                  />\n                </label>\n              </div>\n            </ng-container>\n          </ng-container>\n        </ng-container>\n      </ng-container>\n      <div class=\"form-group col-sm-6\">\n        <label>\n          <span class=\"label-content required\"\n            >{{ 'addressForm.city.label' | cxTranslate }}\n\n            <cx-form-required-asterisks />\n          </span>\n          <ng-container *cxFeature=\"'enableHierarchicalAddressFormat'\">\n            <ng-select\n              *ngIf=\"isHierarchicalAddressFormat; else cityTextInput\"\n              class=\"city-select\"\n              id=\"city-select\"\n              formControlName=\"town\"\n              [searchable]=\"true\"\n              [clearable]=\"false\"\n              [items]=\"cities\"\n              bindLabel=\"name\"\n              bindValue=\"isocode\"\n              placeholder=\"{{\n                selectedRegion$.value\n                  ? ('addressForm.selectOne' | cxTranslate)\n                  : ('addressForm.selectProvinceFirst' | cxTranslate)\n              }}\"\n              (change)=\"citySelected($event)\"\n              [cxNgSelectA11y]=\"{\n                ariaLabel: 'addressForm.city.label' | cxTranslate,\n              }\"\n            />\n          </ng-container>\n          <ng-container *cxFeature=\"'!enableHierarchicalAddressFormat'\">\n            <ng-container *ngTemplateOutlet=\"cityTextInput\" />\n          </ng-container>\n          <ng-template #cityTextInput>\n            <input\n              required=\"true\"\n              type=\"text\"\n              class=\"form-control\"\n              placeholder=\"{{ 'addressForm.city.placeholder' | cxTranslate }}\"\n              formControlName=\"town\"\n              [attr.aria-invalid]=\"\n                addressForm.get('town')?.touched &&\n                addressForm.get('town')?.invalid\n              \"\n              [attr.aria-errormessage]=\"'townError'\"\n            />\n          </ng-template>\n          <cx-form-errors\n            id=\"townError\"\n            [translationParams]=\"{\n              label: 'addressForm.city.label' | cxTranslate,\n            }\"\n            [control]=\"addressForm.get('town')\"\n          />\n        </label>\n      </div>\n      <ng-container *cxFeature=\"'enableHierarchicalAddressFormat'\">\n        <div class=\"form-group col-md-6\" *ngIf=\"isHierarchicalAddressFormat\">\n          <label>\n            <span class=\"label-content required\"\n              >{{ 'addressForm.district' | cxTranslate }}\n              <cx-form-required-asterisks />\n            </span>\n            <ng-select\n              class=\"district-select\"\n              id=\"district-select\"\n              formControlName=\"district\"\n              [searchable]=\"true\"\n              [clearable]=\"false\"\n              [items]=\"districts\"\n              bindLabel=\"name\"\n              bindValue=\"isocode\"\n              placeholder=\"{{\n                selectedCity$.value\n                  ? ('addressForm.selectOne' | cxTranslate)\n                  : ('addressForm.selectCityFirst' | cxTranslate)\n              }}\"\n              [cxNgSelectA11y]=\"{\n                ariaLabel: 'addressForm.district' | cxTranslate,\n              }\"\n            />\n            <cx-form-errors\n              [translationParams]=\"{\n                label: 'addressForm.district' | cxTranslate,\n              }\"\n              [control]=\"addressForm.get('district')\"\n            />\n          </label>\n        </div>\n      </ng-container>\n      <div class=\"form-group col-sm-6\">\n        <label>\n          <span class=\"label-content required\"\n            >{{ 'addressForm.zipCode.label' | cxTranslate }}\n\n            <cx-form-required-asterisks />\n          </span>\n          <input\n            required=\"true\"\n            type=\"text\"\n            class=\"form-control\"\n            placeholder=\"{{ 'addressForm.zipCode.placeholder' | cxTranslate }}\"\n            formControlName=\"postalCode\"\n            [attr.aria-invalid]=\"\n              addressForm.get('postalCode')?.touched &&\n              addressForm.get('postalCode')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'postalCodeError'\"\n          />\n          <cx-form-errors\n            id=\"postalCodeError\"\n            [translationParams]=\"{\n              label: 'addressForm.zipCode.label' | cxTranslate,\n            }\"\n            [control]=\"addressForm.get('postalCode')\"\n          />\n        </label>\n      </div>\n      <ng-container\n        *ngIf=\"!isHierarchicalAddressFormat && (regions$ | async) as regions\"\n        formGroupName=\"region\"\n      >\n        <ng-container *ngIf=\"regions.length !== 0\">\n          <div class=\"form-group col-md-6\">\n            <label>\n              <span class=\"label-content required\"\n                >{{ 'addressForm.state' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <ng-select\n                [inputAttrs]=\"{ required: 'true' }\"\n                class=\"region-select\"\n                formControlName=\"isocode\"\n                [searchable]=\"true\"\n                [clearable]=\"false\"\n                [items]=\"regions\"\n                bindLabel=\"{{ regions[0].name ? 'name' : 'isocode' }}\"\n                bindValue=\"{{ regions[0].name ? 'isocode' : 'region' }}\"\n                placeholder=\"{{ 'addressForm.selectOne' | cxTranslate }}\"\n                id=\"region-select\"\n                ariaLabelDropdown=\"{{\n                  'common.ngSelectDropdownOptionsList' | cxTranslate\n                }}\"\n                [cxNgSelectA11y]=\"{\n                  ariaLabel: 'addressForm.state' | cxTranslate,\n                }\"\n              />\n              <cx-form-errors [control]=\"addressForm.get('region.isocode')\" />\n            </label>\n          </div>\n        </ng-container>\n      </ng-container>\n    </div>\n\n    <div class=\"row\">\n      <div class=\"form-group col-md-6\">\n        <label>\n          <span class=\"label-content\">{{\n            'addressForm.phoneNumber.label' | cxTranslate\n          }}</span>\n          <input\n            type=\"tel\"\n            class=\"form-control\"\n            placeholder=\"{{\n              'addressForm.phoneNumber.placeholder' | cxTranslate\n            }}\"\n            formControlName=\"phone\"\n          />\n        </label>\n      </div>\n      <ng-container *cxFeature=\"'enableHierarchicalAddressFormat'\">\n        <div class=\"form-group col-md-6\">\n          <label>\n            <span\n              class=\"label-content\"\n              [class.required]=\"isHierarchicalAddressFormat\"\n              >{{\n                (isHierarchicalAddressFormat\n                  ? 'addressForm.cellphone.requiredLabel'\n                  : 'addressForm.cellphone.label'\n                ) | cxTranslate\n              }}\n              <cx-form-required-asterisks *ngIf=\"isHierarchicalAddressFormat\" />\n            </span>\n            <input\n              type=\"tel\"\n              class=\"form-control\"\n              placeholder=\"{{\n                'addressForm.cellphone.placeholder' | cxTranslate\n              }}\"\n              formControlName=\"cellphone\"\n            />\n            <cx-form-errors\n              *ngIf=\"isHierarchicalAddressFormat\"\n              [translationParams]=\"{\n                label: 'addressForm.cellphone.requiredLabel' | cxTranslate,\n              }\"\n              [control]=\"addressForm.get('cellphone')\"\n            />\n          </label>\n        </div>\n      </ng-container>\n      <ng-container *cxFeature=\"'!enableHierarchicalAddressFormat'\">\n        <div class=\"form-group col-md-6\">\n          <label>\n            <span class=\"label-content\">{{\n              'addressForm.cellphone.label' | cxTranslate\n            }}</span>\n            <input\n              type=\"tel\"\n              class=\"form-control\"\n              placeholder=\"{{\n                'addressForm.cellphone.placeholder' | cxTranslate\n              }}\"\n              formControlName=\"cellphone\"\n            />\n          </label>\n        </div>\n      </ng-container>\n    </div>\n\n    <div\n      class=\"form-group\"\n      *ngIf=\"(addresses$ | async)?.length && setAsDefaultField\"\n    >\n      <div class=\"form-check\">\n        <label>\n          <input\n            type=\"checkbox\"\n            class=\"form-check-input\"\n            formControlName=\"defaultAddress\"\n            (change)=\"toggleDefaultAddress()\"\n          />\n          <span class=\"form-check-label\">{{\n            'addressForm.setAsDefault' | cxTranslate\n          }}</span>\n        </label>\n      </div>\n    </div>\n    <div class=\"cx-address-form-btns\">\n      <div class=\"row\">\n        <div class=\"col-md-13 col-lg-6\" *ngIf=\"showCancelBtn\">\n          <button class=\"btn btn-block btn-secondary\" (click)=\"back()\">\n            {{ cancelBtnLabel || ('addressForm.chooseAddress' | cxTranslate) }}\n          </button>\n        </div>\n        <div class=\"col-md-13 col-lg-6\">\n          <button #submit class=\"btn btn-block btn-primary\" type=\"submit\">\n            {{ actionBtnLabel || ('common.continue' | cxTranslate) }}\n          </button>\n        </div>\n      </div>\n    </div>\n  </ng-template>\n</form>\n", dependencies: [{ kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: i2$1.FormGroupName, selector: "[formGroupName]", inputs: ["formGroupName"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "directive", type: NgSelectA11yDirective, selector: "[cxNgSelectA11y]", inputs: ["cxNgSelectA11y"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: FeatureDirective, selector: "[cxFeature]", inputs: ["cxFeature"] }, { kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddressFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-address-form', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        FormRequiredLegendComponent,
                        FormsModule,
                        ReactiveFormsModule,
                        NgIf,
                        NgTemplateOutlet,
                        FormRequiredAsterisksComponent,
                        NgSelectComponent,
                        NgSelectA11yDirective,
                        FormErrorsComponent,
                        AsyncPipe,
                        FeatureDirective,
                        FocusDirective,
                        TranslatePipe,
                    ], template: "<cx-form-required-legend />\n<form (ngSubmit)=\"verifyAddress()\" [formGroup]=\"addressForm\">\n  <ng-container *cxFeature=\"'a11yAddressFormInitialFocus'\">\n    <div [cxFocus]=\"{ autofocus: true }\">\n      <ng-container *ngTemplateOutlet=\"formBody\" />\n    </div>\n  </ng-container>\n  <ng-container *cxFeature=\"'!a11yAddressFormInitialFocus'\">\n    <ng-container *ngTemplateOutlet=\"formBody\" />\n  </ng-container>\n\n  <ng-template #formBody>\n    <div class=\"form-group\" formGroupName=\"country\">\n      <ng-container *ngIf=\"countries$ | async as countries\">\n        <div *ngIf=\"countries.length !== 0\">\n          <label>\n            <span class=\"label-content required\"\n              >{{ 'addressForm.country' | cxTranslate }}\n              <cx-form-required-asterisks />\n            </span>\n            <ng-select\n              [inputAttrs]=\"{ required: 'true' }\"\n              class=\"country-select\"\n              id=\"country-select\"\n              formControlName=\"isocode\"\n              [searchable]=\"true\"\n              [clearable]=\"false\"\n              [items]=\"countries\"\n              bindLabel=\"name\"\n              bindValue=\"isocode\"\n              placeholder=\"{{ 'addressForm.selectOne' | cxTranslate }}\"\n              (change)=\"countrySelected($event)\"\n              ariaLabelDropdown=\"{{\n                'common.ngSelectDropdownOptionsList' | cxTranslate\n              }}\"\n              [cxNgSelectA11y]=\"{}\"\n            />\n            <cx-form-errors\n              [translationParams]=\"{\n                label: 'addressForm.country' | cxTranslate,\n              }\"\n              [control]=\"addressForm.get('country.isocode')\"\n            />\n          </label>\n        </div>\n      </ng-container>\n    </div>\n    <div class=\"form-group\" *ngIf=\"showTitleCode\">\n      <ng-container *ngIf=\"titles$ | async as titles\">\n        <div *ngIf=\"titles.length !== 0\">\n          <label>\n            <span class=\"label-content required\">{{\n              'addressForm.titleOptional' | cxTranslate\n            }}</span>\n            <ng-select\n              id=\"title-select\"\n              formControlName=\"titleCode\"\n              [searchable]=\"true\"\n              [clearable]=\"false\"\n              [items]=\"titles\"\n              bindLabel=\"name\"\n              bindValue=\"code\"\n              [placeholder]=\"'addressForm.title' | cxTranslate\"\n              ariaLabelDropdown=\"{{\n                'common.ngSelectDropdownOptionsList' | cxTranslate\n              }}\"\n              [cxNgSelectA11y]=\"{\n                ariaLabel: 'addressForm.titleOptional' | cxTranslate,\n              }\"\n            />\n          </label>\n        </div>\n      </ng-container>\n    </div>\n    <div class=\"form-group\">\n      <label>\n        <span class=\"label-content required\"\n          >{{ 'addressForm.firstName.label' | cxTranslate }}\n          <cx-form-required-asterisks />\n        </span>\n        <input\n          required=\"true\"\n          class=\"form-control\"\n          type=\"text\"\n          placeholder=\"{{ 'addressForm.firstName.placeholder' | cxTranslate }}\"\n          formControlName=\"firstName\"\n          [attr.aria-invalid]=\"\n            addressForm.get('firstName')?.touched &&\n            addressForm.get('firstName')?.invalid\n          \"\n          [attr.aria-errormessage]=\"'firstNameError'\"\n        />\n        <cx-form-errors\n          id=\"firstNameError\"\n          [translationParams]=\"{\n            label: 'addressForm.firstName.label' | cxTranslate,\n          }\"\n          [control]=\"addressForm.get('firstName')\"\n        />\n      </label>\n    </div>\n    <div class=\"form-group\">\n      <label>\n        <span class=\"label-content required\"\n          >{{ 'addressForm.lastName.label' | cxTranslate }}\n          <cx-form-required-asterisks />\n        </span>\n        <input\n          required=\"true\"\n          type=\"text\"\n          class=\"form-control\"\n          placeholder=\"{{ 'addressForm.lastName.placeholder' | cxTranslate }}\"\n          formControlName=\"lastName\"\n          [attr.aria-invalid]=\"\n            addressForm.get('lastName')?.touched &&\n            addressForm.get('lastName')?.invalid\n          \"\n          [attr.aria-errormessage]=\"'lastNameError'\"\n        />\n        <cx-form-errors\n          id=\"lastNameError\"\n          [translationParams]=\"{\n            label: 'addressForm.lastName.label' | cxTranslate,\n          }\"\n          [control]=\"addressForm.get('lastName')\"\n        />\n      </label>\n    </div>\n    <div class=\"form-group\">\n      <label>\n        <span class=\"label-content required\"\n          >{{ 'addressForm.address1' | cxTranslate }}\n          <cx-form-required-asterisks />\n        </span>\n        <input\n          required=\"true\"\n          type=\"text\"\n          class=\"form-control\"\n          placeholder=\"{{ 'addressForm.streetAddress' | cxTranslate }}\"\n          formControlName=\"line1\"\n          [attr.aria-invalid]=\"\n            addressForm.get('line1')?.touched &&\n            addressForm.get('line1')?.invalid\n          \"\n          [attr.aria-errormessage]=\"'line1Error'\"\n        />\n        <cx-form-errors\n          id=\"line1Error\"\n          [translationParams]=\"{\n            label: 'addressForm.address1' | cxTranslate,\n          }\"\n          [control]=\"addressForm.get('line1')\"\n        />\n      </label>\n    </div>\n    <div class=\"form-group\">\n      <label>\n        <span class=\"label-content\">{{\n          'addressForm.address2' | cxTranslate\n        }}</span>\n        <input\n          type=\"text\"\n          class=\"form-control\"\n          placeholder=\"{{ 'addressForm.aptSuite' | cxTranslate }}\"\n          formControlName=\"line2\"\n        />\n      </label>\n    </div>\n    <div class=\"row\">\n      <ng-container *cxFeature=\"'enableHierarchicalAddressFormat'\">\n        <ng-container *ngIf=\"isHierarchicalAddressFormat\">\n          <ng-container\n            *ngIf=\"regions$ | async as regions\"\n            formGroupName=\"region\"\n          >\n            <ng-container *ngIf=\"regions.length !== 0\">\n              <div class=\"form-group col-md-6\">\n                <label>\n                  <span class=\"label-content required\"\n                    >{{ 'addressForm.province' | cxTranslate }}\n                    <cx-form-required-asterisks />\n                  </span>\n                  <ng-select\n                    [inputAttrs]=\"{ required: 'true' }\"\n                    class=\"region-select\"\n                    formControlName=\"isocode\"\n                    [searchable]=\"true\"\n                    [clearable]=\"false\"\n                    [items]=\"regions\"\n                    bindLabel=\"{{ regions[0].name ? 'name' : 'isocode' }}\"\n                    bindValue=\"{{ regions[0].name ? 'isocode' : 'region' }}\"\n                    placeholder=\"{{ 'addressForm.selectOne' | cxTranslate }}\"\n                    (change)=\"regionSelected($event)\"\n                    id=\"region-select\"\n                    ariaLabelDropdown=\"{{\n                      'common.ngSelectDropdownOptionsList' | cxTranslate\n                    }}\"\n                    [cxNgSelectA11y]=\"{\n                      ariaLabel: 'addressForm.province' | cxTranslate,\n                    }\"\n                  />\n                  <cx-form-errors\n                    [translationParams]=\"{\n                      label: 'addressForm.province' | cxTranslate,\n                    }\"\n                    [control]=\"addressForm.get('region.isocode')\"\n                  />\n                </label>\n              </div>\n            </ng-container>\n          </ng-container>\n        </ng-container>\n      </ng-container>\n      <div class=\"form-group col-sm-6\">\n        <label>\n          <span class=\"label-content required\"\n            >{{ 'addressForm.city.label' | cxTranslate }}\n\n            <cx-form-required-asterisks />\n          </span>\n          <ng-container *cxFeature=\"'enableHierarchicalAddressFormat'\">\n            <ng-select\n              *ngIf=\"isHierarchicalAddressFormat; else cityTextInput\"\n              class=\"city-select\"\n              id=\"city-select\"\n              formControlName=\"town\"\n              [searchable]=\"true\"\n              [clearable]=\"false\"\n              [items]=\"cities\"\n              bindLabel=\"name\"\n              bindValue=\"isocode\"\n              placeholder=\"{{\n                selectedRegion$.value\n                  ? ('addressForm.selectOne' | cxTranslate)\n                  : ('addressForm.selectProvinceFirst' | cxTranslate)\n              }}\"\n              (change)=\"citySelected($event)\"\n              [cxNgSelectA11y]=\"{\n                ariaLabel: 'addressForm.city.label' | cxTranslate,\n              }\"\n            />\n          </ng-container>\n          <ng-container *cxFeature=\"'!enableHierarchicalAddressFormat'\">\n            <ng-container *ngTemplateOutlet=\"cityTextInput\" />\n          </ng-container>\n          <ng-template #cityTextInput>\n            <input\n              required=\"true\"\n              type=\"text\"\n              class=\"form-control\"\n              placeholder=\"{{ 'addressForm.city.placeholder' | cxTranslate }}\"\n              formControlName=\"town\"\n              [attr.aria-invalid]=\"\n                addressForm.get('town')?.touched &&\n                addressForm.get('town')?.invalid\n              \"\n              [attr.aria-errormessage]=\"'townError'\"\n            />\n          </ng-template>\n          <cx-form-errors\n            id=\"townError\"\n            [translationParams]=\"{\n              label: 'addressForm.city.label' | cxTranslate,\n            }\"\n            [control]=\"addressForm.get('town')\"\n          />\n        </label>\n      </div>\n      <ng-container *cxFeature=\"'enableHierarchicalAddressFormat'\">\n        <div class=\"form-group col-md-6\" *ngIf=\"isHierarchicalAddressFormat\">\n          <label>\n            <span class=\"label-content required\"\n              >{{ 'addressForm.district' | cxTranslate }}\n              <cx-form-required-asterisks />\n            </span>\n            <ng-select\n              class=\"district-select\"\n              id=\"district-select\"\n              formControlName=\"district\"\n              [searchable]=\"true\"\n              [clearable]=\"false\"\n              [items]=\"districts\"\n              bindLabel=\"name\"\n              bindValue=\"isocode\"\n              placeholder=\"{{\n                selectedCity$.value\n                  ? ('addressForm.selectOne' | cxTranslate)\n                  : ('addressForm.selectCityFirst' | cxTranslate)\n              }}\"\n              [cxNgSelectA11y]=\"{\n                ariaLabel: 'addressForm.district' | cxTranslate,\n              }\"\n            />\n            <cx-form-errors\n              [translationParams]=\"{\n                label: 'addressForm.district' | cxTranslate,\n              }\"\n              [control]=\"addressForm.get('district')\"\n            />\n          </label>\n        </div>\n      </ng-container>\n      <div class=\"form-group col-sm-6\">\n        <label>\n          <span class=\"label-content required\"\n            >{{ 'addressForm.zipCode.label' | cxTranslate }}\n\n            <cx-form-required-asterisks />\n          </span>\n          <input\n            required=\"true\"\n            type=\"text\"\n            class=\"form-control\"\n            placeholder=\"{{ 'addressForm.zipCode.placeholder' | cxTranslate }}\"\n            formControlName=\"postalCode\"\n            [attr.aria-invalid]=\"\n              addressForm.get('postalCode')?.touched &&\n              addressForm.get('postalCode')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'postalCodeError'\"\n          />\n          <cx-form-errors\n            id=\"postalCodeError\"\n            [translationParams]=\"{\n              label: 'addressForm.zipCode.label' | cxTranslate,\n            }\"\n            [control]=\"addressForm.get('postalCode')\"\n          />\n        </label>\n      </div>\n      <ng-container\n        *ngIf=\"!isHierarchicalAddressFormat && (regions$ | async) as regions\"\n        formGroupName=\"region\"\n      >\n        <ng-container *ngIf=\"regions.length !== 0\">\n          <div class=\"form-group col-md-6\">\n            <label>\n              <span class=\"label-content required\"\n                >{{ 'addressForm.state' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <ng-select\n                [inputAttrs]=\"{ required: 'true' }\"\n                class=\"region-select\"\n                formControlName=\"isocode\"\n                [searchable]=\"true\"\n                [clearable]=\"false\"\n                [items]=\"regions\"\n                bindLabel=\"{{ regions[0].name ? 'name' : 'isocode' }}\"\n                bindValue=\"{{ regions[0].name ? 'isocode' : 'region' }}\"\n                placeholder=\"{{ 'addressForm.selectOne' | cxTranslate }}\"\n                id=\"region-select\"\n                ariaLabelDropdown=\"{{\n                  'common.ngSelectDropdownOptionsList' | cxTranslate\n                }}\"\n                [cxNgSelectA11y]=\"{\n                  ariaLabel: 'addressForm.state' | cxTranslate,\n                }\"\n              />\n              <cx-form-errors [control]=\"addressForm.get('region.isocode')\" />\n            </label>\n          </div>\n        </ng-container>\n      </ng-container>\n    </div>\n\n    <div class=\"row\">\n      <div class=\"form-group col-md-6\">\n        <label>\n          <span class=\"label-content\">{{\n            'addressForm.phoneNumber.label' | cxTranslate\n          }}</span>\n          <input\n            type=\"tel\"\n            class=\"form-control\"\n            placeholder=\"{{\n              'addressForm.phoneNumber.placeholder' | cxTranslate\n            }}\"\n            formControlName=\"phone\"\n          />\n        </label>\n      </div>\n      <ng-container *cxFeature=\"'enableHierarchicalAddressFormat'\">\n        <div class=\"form-group col-md-6\">\n          <label>\n            <span\n              class=\"label-content\"\n              [class.required]=\"isHierarchicalAddressFormat\"\n              >{{\n                (isHierarchicalAddressFormat\n                  ? 'addressForm.cellphone.requiredLabel'\n                  : 'addressForm.cellphone.label'\n                ) | cxTranslate\n              }}\n              <cx-form-required-asterisks *ngIf=\"isHierarchicalAddressFormat\" />\n            </span>\n            <input\n              type=\"tel\"\n              class=\"form-control\"\n              placeholder=\"{{\n                'addressForm.cellphone.placeholder' | cxTranslate\n              }}\"\n              formControlName=\"cellphone\"\n            />\n            <cx-form-errors\n              *ngIf=\"isHierarchicalAddressFormat\"\n              [translationParams]=\"{\n                label: 'addressForm.cellphone.requiredLabel' | cxTranslate,\n              }\"\n              [control]=\"addressForm.get('cellphone')\"\n            />\n          </label>\n        </div>\n      </ng-container>\n      <ng-container *cxFeature=\"'!enableHierarchicalAddressFormat'\">\n        <div class=\"form-group col-md-6\">\n          <label>\n            <span class=\"label-content\">{{\n              'addressForm.cellphone.label' | cxTranslate\n            }}</span>\n            <input\n              type=\"tel\"\n              class=\"form-control\"\n              placeholder=\"{{\n                'addressForm.cellphone.placeholder' | cxTranslate\n              }}\"\n              formControlName=\"cellphone\"\n            />\n          </label>\n        </div>\n      </ng-container>\n    </div>\n\n    <div\n      class=\"form-group\"\n      *ngIf=\"(addresses$ | async)?.length && setAsDefaultField\"\n    >\n      <div class=\"form-check\">\n        <label>\n          <input\n            type=\"checkbox\"\n            class=\"form-check-input\"\n            formControlName=\"defaultAddress\"\n            (change)=\"toggleDefaultAddress()\"\n          />\n          <span class=\"form-check-label\">{{\n            'addressForm.setAsDefault' | cxTranslate\n          }}</span>\n        </label>\n      </div>\n    </div>\n    <div class=\"cx-address-form-btns\">\n      <div class=\"row\">\n        <div class=\"col-md-13 col-lg-6\" *ngIf=\"showCancelBtn\">\n          <button class=\"btn btn-block btn-secondary\" (click)=\"back()\">\n            {{ cancelBtnLabel || ('addressForm.chooseAddress' | cxTranslate) }}\n          </button>\n        </div>\n        <div class=\"col-md-13 col-lg-6\">\n          <button #submit class=\"btn btn-block btn-primary\" type=\"submit\">\n            {{ actionBtnLabel || ('common.continue' | cxTranslate) }}\n          </button>\n        </div>\n      </div>\n    </div>\n  </ng-template>\n</form>\n" }]
        }], ctorParameters: () => [{ type: i2$1.UntypedFormBuilder }, { type: i2.UserAddressService }, { type: i2.GlobalMessageService }, { type: i2.TranslationService }, { type: i3.LaunchDialogService }, { type: i1.UserProfileFacade }], propDecorators: { addressData: [{
                type: Input
            }], actionBtnLabel: [{
                type: Input
            }], cancelBtnLabel: [{
                type: Input
            }], setAsDefaultField: [{
                type: Input
            }], showTitleCode: [{
                type: Input
            }], showCancelBtn: [{
                type: Input
            }], countries: [{
                type: Input
            }], submitAddress: [{
                type: Output
            }], backToAddress: [{
                type: Output
            }], element: [{
                type: ViewChild,
                args: ['submit']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AddressBookComponentService {
    constructor(userAddressService) {
        this.userAddressService = userAddressService;
    }
    getAddresses() {
        return this.userAddressService.getAddresses();
    }
    getAddressesStateLoading() {
        return this.userAddressService.getAddressesLoading();
    }
    getAddressesError() {
        return this.userAddressService.getAddressesError();
    }
    loadAddresses() {
        this.userAddressService.loadAddresses();
    }
    addUserAddress(address) {
        this.userAddressService.addUserAddress(address);
    }
    updateUserAddress(addressId, address) {
        this.userAddressService.updateUserAddress(addressId, address);
    }
    setAddressAsDefault(addressId) {
        this.userAddressService.setAddressAsDefault(addressId);
    }
    deleteUserAddress(addressId) {
        this.userAddressService.deleteUserAddress(addressId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddressBookComponentService, deps: [{ token: i2.UserAddressService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddressBookComponentService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddressBookComponentService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i2.UserAddressService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AddressBookComponent {
    constructor(service, translation, globalMessageService) {
        this.service = service;
        this.translation = translation;
        this.globalMessageService = globalMessageService;
        this.showAddAddressForm = false;
        this.showEditAddressForm = false;
        this.subscription = new Subscription();
        this.languageService = inject(LanguageService);
        this.featureToggles = inject(FeatureToggles);
        this.hierarchicalAddressConfig = inject(HierarchicalAddressConfig);
    }
    ngOnInit() {
        this.addresses$ = this.service.getAddresses();
        this.addressesStateLoading$ = this.service.getAddressesStateLoading();
        this.service.loadAddresses();
        if (this.featureToggles.enableHierarchicalAddressFormat) {
            this.subscription.add(this.languageService
                .getActive()
                .pipe(skip(1))
                .subscribe(() => this.service.loadAddresses()));
        }
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    addAddressButtonHandle() {
        this.showEditAddressForm = false;
        this.showAddAddressForm = true;
    }
    editAddressButtonHandle(address) {
        this.showAddAddressForm = false;
        this.showEditAddressForm = true;
        this.currentAddress = address;
    }
    addAddressSubmit(address) {
        if (!this.featureToggles.enableHierarchicalAddressFormat) {
            this.showAddAddressForm = false;
            this.service.addUserAddress(address);
            return;
        }
        if (!address) {
            this.showAddAddressForm = false;
            return;
        }
        this.service.addUserAddress(address);
        this.subscription.add(this.service
            .getAddressesStateLoading()
            .pipe(pairwise(), filter(([prev, curr]) => prev === true && curr === false), take(1), withLatestFrom(this.service.getAddressesError()))
            .subscribe(([_, hasError]) => {
            if (!hasError) {
                this.showAddAddressForm = false;
            }
        }));
    }
    addAddressCancel() {
        this.showAddAddressForm = false;
    }
    editAddressSubmit(address) {
        if (!this.featureToggles.enableHierarchicalAddressFormat) {
            this.showEditAddressForm = false;
            if (address && this.currentAddress['id']) {
                this.service.updateUserAddress(this.currentAddress['id'], address);
            }
            return;
        }
        if (!address) {
            this.showEditAddressForm = false;
            return;
        }
        if (this.currentAddress['id']) {
            this.service.updateUserAddress(this.currentAddress['id'], address);
            this.subscription.add(this.service
                .getAddressesStateLoading()
                .pipe(pairwise(), filter(([prev, curr]) => prev === true && curr === false), take(1), withLatestFrom(this.service.getAddressesError()))
                .subscribe(([_, hasError]) => {
                if (!hasError) {
                    this.showEditAddressForm = false;
                }
            }));
        }
    }
    editAddressCancel() {
        this.showEditAddressForm = false;
    }
    getCardContent(address) {
        return combineLatest([
            this.translation.translate('addressCard.default'),
            this.translation.translate('addressCard.setAsDefault'),
            this.translation.translate('common.delete'),
            this.translation.translate('common.edit'),
            this.translation.translate('addressBook.areYouSureToDeleteAddress'),
            this.translation.translate('addressCard.phoneNumber'),
            this.translation.translate('addressCard.mobileNumber'),
        ]).pipe(map(([defaultText, setAsDefaultText, textDelete, textEdit, textVerifyDeleteMsg, textPhone, textMobile,]) => {
            const actions = [];
            if (!address.defaultAddress) {
                actions.push({ name: setAsDefaultText, event: 'default' });
            }
            actions.push({ name: textEdit, event: 'edit' });
            actions.push({ name: textDelete, event: 'delete' });
            const numbers = getAddressNumbers(address, textPhone, textMobile);
            let text;
            if (this.featureToggles.enableHierarchicalAddressFormat) {
                const locationLine = this.buildLocationLine(address);
                const districtName = this.isHierarchicalAddressFormat(address)
                    ? address.cityDistrict?.name || address.district || ''
                    : '';
                text = [
                    address.line1,
                    address.line2,
                    locationLine,
                    districtName,
                    address.postalCode,
                    numbers,
                ].filter(Boolean);
            }
            else {
                let region = '';
                if (address.region && address.region.isocode) {
                    region = address.region.isocode + ', ';
                }
                text = [
                    address.line1,
                    address.line2,
                    address.town + ', ' + region + address.country?.isocode,
                    address.postalCode,
                    numbers,
                ];
            }
            return {
                role: 'application',
                textBold: address.firstName + ' ' + address.lastName,
                text,
                actions: actions,
                header: address.defaultAddress ? `✓ ${defaultText}` : '',
                deleteMsg: textVerifyDeleteMsg,
                label: address.defaultAddress
                    ? 'addressBook.defaultDeliveryAddress'
                    : 'addressBook.additionalDeliveryAddress',
            };
        }));
    }
    buildLocationLine(address) {
        if (this.isHierarchicalAddressFormat(address)) {
            const hierarchicalRegion = address.region?.name || address.region?.isocode || '';
            const townName = address.city?.name || address.town || '';
            const countryName = address.country?.name || address.country?.isocode || '';
            return [townName, hierarchicalRegion, countryName]
                .filter(Boolean)
                .join(', ');
        }
        let region = '';
        if (address.region && address.region.isocode) {
            region = address.region.isocode + ', ';
        }
        return address.town + ', ' + region + address.country?.isocode;
    }
    isHierarchicalAddressFormat(address) {
        return (this.hierarchicalAddressConfig.hierarchicalAddress
            ?.countriesUsingHierarchicalAddressFormat ?? []).includes(address.country?.isocode ?? '');
    }
    setAddressAsDefault(address) {
        this.service.setAddressAsDefault(address.id ?? '');
        this.globalMessageService.add({
            key: 'addressMessages.setAsDefaultSuccessfully',
            params: { streetAddress: address.line1 },
        }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
    }
    deleteAddress(addressId) {
        this.service.deleteUserAddress(addressId);
    }
    setEdit(addressId) {
        if (this.editCard !== addressId) {
            this.editCard = addressId;
        }
        else {
            this.deleteAddress(addressId);
        }
    }
    cancelCard() {
        this.editCard = null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddressBookComponent, deps: [{ token: AddressBookComponentService }, { token: i2.TranslationService }, { token: i2.GlobalMessageService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: AddressBookComponent, isStandalone: true, selector: "cx-address-book", ngImport: i0, template: "<div class=\"cx-section\">\n  <ng-container\n    *ngIf=\"\n      (addresses$ | async)?.length &&\n      !(showAddAddressForm || showEditAddressForm)\n    \"\n  >\n    <div class=\"row\">\n      <div class=\"col-md-6\">\n        <button\n          class=\"btn btn-block btn-secondary\"\n          (click)=\"addAddressButtonHandle()\"\n        >\n          {{ 'addressBook.addNewAddress' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n\n    <div\n      class=\"row cx-address-deck\"\n      *ngIf=\"!(addressesStateLoading$ | async); else loading\"\n    >\n      <div\n        *ngFor=\"let address of addresses$ | async; let i = index\"\n        class=\"col-md-6 cx-address-card\"\n      >\n        <cx-card\n          [index]=\"i\"\n          [border]=\"true\"\n          [fitToContainer]=\"true\"\n          [content]=\"getCardContent(address) | async\"\n          (editCard)=\"editAddressButtonHandle(address)\"\n          (setDefaultCard)=\"setAddressAsDefault(address)\"\n          (deleteCard)=\"setEdit(address.id ?? '')\"\n          [editMode]=\"address.id === editCard\"\n          (cancelCard)=\"cancelCard()\"\n        ></cx-card>\n      </div>\n    </div>\n  </ng-container>\n\n  <ng-container\n    *ngIf=\"\n      (!(addresses$ | async)?.length || showAddAddressForm) &&\n      !showEditAddressForm\n    \"\n  >\n    <section>\n      <h2 class=\"cx-section-msg\">\n        {{ 'addressBook.addNewDeliveryAddress' | cxTranslate }}\n      </h2>\n      <cx-address-form\n        class=\"cx-form\"\n        [showTitleCode]=\"true\"\n        [showCancelBtn]=\"!((addresses$ | async)?.length === 0)\"\n        actionBtnLabel=\"{{ 'addressBook.addAddress' | cxTranslate }}\"\n        cancelBtnLabel=\"{{ 'addressBook.backToAddressList' | cxTranslate }}\"\n        [setAsDefaultField]=\"!((addresses$ | async)?.length === 0)\"\n        (submitAddress)=\"addAddressSubmit($event)\"\n        (backToAddress)=\"addAddressCancel()\"\n        (cancelCard)=\"cancelCard()\"\n      ></cx-address-form>\n    </section>\n  </ng-container>\n\n  <ng-container *ngIf=\"showEditAddressForm\">\n    <section>\n      <h2 class=\"cx-section-msg\">\n        {{ 'addressBook.editDeliveryAddress' | cxTranslate }}\n      </h2>\n      <cx-address-form\n        [showTitleCode]=\"true\"\n        actionBtnLabel=\"{{ 'addressBook.updateAddress' | cxTranslate }}\"\n        cancelBtnLabel=\"{{ 'addressBook.backToAddressList' | cxTranslate }}\"\n        [addressData]=\"currentAddress\"\n        (submitAddress)=\"editAddressSubmit($event)\"\n        (backToAddress)=\"editAddressCancel()\"\n      ></cx-address-form>\n    </section>\n  </ng-container>\n</div>\n\n<ng-template #loading>\n  <div class=\"col-md-12 cx-address-spinner\">\n    <cx-spinner></cx-spinner>\n  </div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: CardComponent, selector: "cx-card", inputs: ["border", "editMode", "isDefault", "content", "fitToContainer", "truncateText", "truncateParagraphText", "charactersLimit", "index", "role"], outputs: ["deleteCard", "setDefaultCard", "sendCard", "editCard", "cancelCard"] }, { kind: "component", type: AddressFormComponent, selector: "cx-address-form", inputs: ["addressData", "actionBtnLabel", "cancelBtnLabel", "setAsDefaultField", "showTitleCode", "showCancelBtn", "countries"], outputs: ["submitAddress", "backToAddress"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddressBookComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-address-book', imports: [
                        NgIf,
                        NgFor,
                        CardComponent,
                        AddressFormComponent,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<div class=\"cx-section\">\n  <ng-container\n    *ngIf=\"\n      (addresses$ | async)?.length &&\n      !(showAddAddressForm || showEditAddressForm)\n    \"\n  >\n    <div class=\"row\">\n      <div class=\"col-md-6\">\n        <button\n          class=\"btn btn-block btn-secondary\"\n          (click)=\"addAddressButtonHandle()\"\n        >\n          {{ 'addressBook.addNewAddress' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n\n    <div\n      class=\"row cx-address-deck\"\n      *ngIf=\"!(addressesStateLoading$ | async); else loading\"\n    >\n      <div\n        *ngFor=\"let address of addresses$ | async; let i = index\"\n        class=\"col-md-6 cx-address-card\"\n      >\n        <cx-card\n          [index]=\"i\"\n          [border]=\"true\"\n          [fitToContainer]=\"true\"\n          [content]=\"getCardContent(address) | async\"\n          (editCard)=\"editAddressButtonHandle(address)\"\n          (setDefaultCard)=\"setAddressAsDefault(address)\"\n          (deleteCard)=\"setEdit(address.id ?? '')\"\n          [editMode]=\"address.id === editCard\"\n          (cancelCard)=\"cancelCard()\"\n        ></cx-card>\n      </div>\n    </div>\n  </ng-container>\n\n  <ng-container\n    *ngIf=\"\n      (!(addresses$ | async)?.length || showAddAddressForm) &&\n      !showEditAddressForm\n    \"\n  >\n    <section>\n      <h2 class=\"cx-section-msg\">\n        {{ 'addressBook.addNewDeliveryAddress' | cxTranslate }}\n      </h2>\n      <cx-address-form\n        class=\"cx-form\"\n        [showTitleCode]=\"true\"\n        [showCancelBtn]=\"!((addresses$ | async)?.length === 0)\"\n        actionBtnLabel=\"{{ 'addressBook.addAddress' | cxTranslate }}\"\n        cancelBtnLabel=\"{{ 'addressBook.backToAddressList' | cxTranslate }}\"\n        [setAsDefaultField]=\"!((addresses$ | async)?.length === 0)\"\n        (submitAddress)=\"addAddressSubmit($event)\"\n        (backToAddress)=\"addAddressCancel()\"\n        (cancelCard)=\"cancelCard()\"\n      ></cx-address-form>\n    </section>\n  </ng-container>\n\n  <ng-container *ngIf=\"showEditAddressForm\">\n    <section>\n      <h2 class=\"cx-section-msg\">\n        {{ 'addressBook.editDeliveryAddress' | cxTranslate }}\n      </h2>\n      <cx-address-form\n        [showTitleCode]=\"true\"\n        actionBtnLabel=\"{{ 'addressBook.updateAddress' | cxTranslate }}\"\n        cancelBtnLabel=\"{{ 'addressBook.backToAddressList' | cxTranslate }}\"\n        [addressData]=\"currentAddress\"\n        (submitAddress)=\"editAddressSubmit($event)\"\n        (backToAddress)=\"editAddressCancel()\"\n      ></cx-address-form>\n    </section>\n  </ng-container>\n</div>\n\n<ng-template #loading>\n  <div class=\"col-md-12 cx-address-spinner\">\n    <cx-spinner></cx-spinner>\n  </div>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: AddressBookComponentService }, { type: i2.TranslationService }, { type: i2.GlobalMessageService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SuggestedAddressDialogComponent {
    handleClick(event) {
        if (event.target.tagName === this.el.nativeElement.tagName) {
            this.closeModal('Cross click');
        }
    }
    constructor(launchDialogService, el) {
        this.launchDialogService = launchDialogService;
        this.el = el;
        this.iconTypes = ICON_TYPE;
        this.focusConfig = {
            trap: true,
            block: true,
            autofocus: 'button',
            focusOnEscape: true,
        };
        this.data$ = this.launchDialogService.data$;
    }
    ngOnInit() {
        this.data$.pipe(take(1)).subscribe((data) => this.setSelectedAddress(data));
    }
    closeModal(reason) {
        this.launchDialogService.closeDialog(reason);
    }
    setSelectedAddress(data) {
        this.selectedAddress = data.suggestedAddresses?.length
            ? data.suggestedAddresses[0]
            : data.enteredAddress;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SuggestedAddressDialogComponent, deps: [{ token: i3.LaunchDialogService }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: SuggestedAddressDialogComponent, isStandalone: true, selector: "cx-suggested-addresses-dialog", host: { listeners: { "click": "handleClick($event)" } }, ngImport: i0, template: "<div\n  class=\"modal-dialog modal-dialog-centered modal-lg cx-suggested-addresses-dialog\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"closeModal('Escape clicked')\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <div\n    *ngIf=\"data$ | async as data\"\n    class=\"modal-content cx-suggested-addresses-container\"\n  >\n    <div class=\"cx-suggested-addresses-header cx-modal-header\">\n      <h3 id=\"dialogTitle\" class=\"cx-suggested-addresses-title\">\n        {{ 'addressSuggestion.verifyYourAddress' | cxTranslate }}\n      </h3>\n      <button\n        type=\"button\"\n        class=\"close\"\n        title=\"{{ 'common.close' | cxTranslate }}\"\n        [attr.aria-label]=\"'common.close' | cxTranslate\"\n        (click)=\"closeModal('Cross click')\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n        </span>\n      </button>\n    </div>\n    <div class=\"modal-body\" ngForm>\n      <div class=\"cx-dialog-info\">\n        <p>\n          {{ 'addressSuggestion.ensureAccuracySuggestChange' | cxTranslate }}\n          {{ 'addressSuggestion.chooseAddressToUse' | cxTranslate }}\n        </p>\n      </div>\n\n      <div class=\"cx-dialog-options\">\n        <div\n          class=\"form-check\"\n          *ngFor=\"\n            let suggestedAddress of data.suggestedAddresses;\n            let i = index\n          \"\n        >\n          <input\n            class=\"form-check-input\"\n            type=\"radio\"\n            name=\"selectedAddress\"\n            [(ngModel)]=\"selectedAddress\"\n            [value]=\"suggestedAddress\"\n            [id]=\"'suggested-addresses--suggested-' + i\"\n          />\n          <label\n            class=\"form-check-label cx-dialog-label\"\n            [for]=\"'suggested-addresses--suggested-' + i\"\n          >\n            {{ 'addressSuggestion.suggestedAddress' | cxTranslate }}\n            {{ data.suggestedAddresses.length > 1 ? i + 1 : null }}\n          </label>\n          <div class=\"cx-dialog-suggested\">\n            <div class=\"cx-card-container\">\n              <div class=\"cx-card-label\">{{ suggestedAddress?.firstName }}</div>\n              <div class=\"cx-card-label\">{{ suggestedAddress?.lastName }}</div>\n              <div class=\"cx-card-label\">{{ suggestedAddress?.line1 }}</div>\n              <div class=\"cx-card-label\">\n                <span>{{ suggestedAddress?.line2 }}</span>\n              </div>\n              <div class=\"cx-card-label\">{{ suggestedAddress?.town }}</div>\n              <div class=\"cx-card-label\">\n                {{ suggestedAddress?.region?.isocode }}\n              </div>\n              <div class=\"cx-card-label\">\n                {{ suggestedAddress?.postalCode }}\n              </div>\n            </div>\n          </div>\n        </div>\n        <div class=\"form-check\">\n          <input\n            class=\"form-check-input\"\n            type=\"radio\"\n            name=\"selectedAddress\"\n            [(ngModel)]=\"selectedAddress\"\n            [value]=\"data.enteredAddress\"\n            id=\"suggested-addresses--entered\"\n          />\n          <label\n            class=\"form-check-label cx-dialog-label\"\n            for=\"suggested-addresses--entered\"\n          >\n            {{ 'addressSuggestion.enteredAddress' | cxTranslate }}\n          </label>\n          <div class=\"cx-dialog-entered\">\n            <div class=\"cx-card-container\">\n              <div class=\"cx-card-label\">\n                {{ data.enteredAddress?.firstName }}\n                {{ data.enteredAddress?.lastName }}\n              </div>\n              <div class=\"cx-card-label\">{{ data.enteredAddress?.line1 }}</div>\n              <div class=\"cx-card-label\">\n                <span>{{ data.enteredAddress?.line2 }}</span>\n              </div>\n              <div class=\"cx-card-label\">\n                {{ data.enteredAddress?.town }}\n                {{ data.enteredAddress?.region?.isocode }}\n              </div>\n              <div class=\"cx-card-label\">\n                {{ data.enteredAddress?.postalCode }}\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n    <div class=\"cx-suggested-addresses-footer cx-modal-footer\">\n      <div class=\"row\">\n        <div class=\"cx-dialog-actions col-sm-12 col-md-12 col-lg-6 offset-lg-6\">\n          <button\n            class=\"btn btn-secondary cx-dialog-buttons\"\n            (click)=\"closeModal('Edit address')\"\n          >\n            {{ 'addressSuggestion.editAddress' | cxTranslate }}\n          </button>\n          <button\n            cxAutoFocus\n            class=\"btn btn-primary cx-dialog-buttons\"\n            (click)=\"closeModal(selectedAddress)\"\n          >\n            {{ 'addressSuggestion.saveAddress' | cxTranslate }}\n          </button>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.RadioControlValueAccessor, selector: "input[type=radio][formControlName],input[type=radio][formControl],input[type=radio][ngModel]", inputs: ["name", "formControlName", "value"] }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i2$1.NgForm, selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SuggestedAddressDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-suggested-addresses-dialog', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        FocusDirective,
                        NgIf,
                        IconComponent,
                        FormsModule,
                        NgFor,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<div\n  class=\"modal-dialog modal-dialog-centered modal-lg cx-suggested-addresses-dialog\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"closeModal('Escape clicked')\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <div\n    *ngIf=\"data$ | async as data\"\n    class=\"modal-content cx-suggested-addresses-container\"\n  >\n    <div class=\"cx-suggested-addresses-header cx-modal-header\">\n      <h3 id=\"dialogTitle\" class=\"cx-suggested-addresses-title\">\n        {{ 'addressSuggestion.verifyYourAddress' | cxTranslate }}\n      </h3>\n      <button\n        type=\"button\"\n        class=\"close\"\n        title=\"{{ 'common.close' | cxTranslate }}\"\n        [attr.aria-label]=\"'common.close' | cxTranslate\"\n        (click)=\"closeModal('Cross click')\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n        </span>\n      </button>\n    </div>\n    <div class=\"modal-body\" ngForm>\n      <div class=\"cx-dialog-info\">\n        <p>\n          {{ 'addressSuggestion.ensureAccuracySuggestChange' | cxTranslate }}\n          {{ 'addressSuggestion.chooseAddressToUse' | cxTranslate }}\n        </p>\n      </div>\n\n      <div class=\"cx-dialog-options\">\n        <div\n          class=\"form-check\"\n          *ngFor=\"\n            let suggestedAddress of data.suggestedAddresses;\n            let i = index\n          \"\n        >\n          <input\n            class=\"form-check-input\"\n            type=\"radio\"\n            name=\"selectedAddress\"\n            [(ngModel)]=\"selectedAddress\"\n            [value]=\"suggestedAddress\"\n            [id]=\"'suggested-addresses--suggested-' + i\"\n          />\n          <label\n            class=\"form-check-label cx-dialog-label\"\n            [for]=\"'suggested-addresses--suggested-' + i\"\n          >\n            {{ 'addressSuggestion.suggestedAddress' | cxTranslate }}\n            {{ data.suggestedAddresses.length > 1 ? i + 1 : null }}\n          </label>\n          <div class=\"cx-dialog-suggested\">\n            <div class=\"cx-card-container\">\n              <div class=\"cx-card-label\">{{ suggestedAddress?.firstName }}</div>\n              <div class=\"cx-card-label\">{{ suggestedAddress?.lastName }}</div>\n              <div class=\"cx-card-label\">{{ suggestedAddress?.line1 }}</div>\n              <div class=\"cx-card-label\">\n                <span>{{ suggestedAddress?.line2 }}</span>\n              </div>\n              <div class=\"cx-card-label\">{{ suggestedAddress?.town }}</div>\n              <div class=\"cx-card-label\">\n                {{ suggestedAddress?.region?.isocode }}\n              </div>\n              <div class=\"cx-card-label\">\n                {{ suggestedAddress?.postalCode }}\n              </div>\n            </div>\n          </div>\n        </div>\n        <div class=\"form-check\">\n          <input\n            class=\"form-check-input\"\n            type=\"radio\"\n            name=\"selectedAddress\"\n            [(ngModel)]=\"selectedAddress\"\n            [value]=\"data.enteredAddress\"\n            id=\"suggested-addresses--entered\"\n          />\n          <label\n            class=\"form-check-label cx-dialog-label\"\n            for=\"suggested-addresses--entered\"\n          >\n            {{ 'addressSuggestion.enteredAddress' | cxTranslate }}\n          </label>\n          <div class=\"cx-dialog-entered\">\n            <div class=\"cx-card-container\">\n              <div class=\"cx-card-label\">\n                {{ data.enteredAddress?.firstName }}\n                {{ data.enteredAddress?.lastName }}\n              </div>\n              <div class=\"cx-card-label\">{{ data.enteredAddress?.line1 }}</div>\n              <div class=\"cx-card-label\">\n                <span>{{ data.enteredAddress?.line2 }}</span>\n              </div>\n              <div class=\"cx-card-label\">\n                {{ data.enteredAddress?.town }}\n                {{ data.enteredAddress?.region?.isocode }}\n              </div>\n              <div class=\"cx-card-label\">\n                {{ data.enteredAddress?.postalCode }}\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n    <div class=\"cx-suggested-addresses-footer cx-modal-footer\">\n      <div class=\"row\">\n        <div class=\"cx-dialog-actions col-sm-12 col-md-12 col-lg-6 offset-lg-6\">\n          <button\n            class=\"btn btn-secondary cx-dialog-buttons\"\n            (click)=\"closeModal('Edit address')\"\n          >\n            {{ 'addressSuggestion.editAddress' | cxTranslate }}\n          </button>\n          <button\n            cxAutoFocus\n            class=\"btn btn-primary cx-dialog-buttons\"\n            (click)=\"closeModal(selectedAddress)\"\n          >\n            {{ 'addressSuggestion.saveAddress' | cxTranslate }}\n          </button>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i3.LaunchDialogService }, { type: i0.ElementRef }], propDecorators: { handleClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AddressFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddressFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: AddressFormModule, imports: [NgSelectA11yModule,
            CommonModule,
            ReactiveFormsModule,
            FormsModule,
            RouterModule,
            NgSelectModule,
            IconModule,
            I18nModule,
            FormErrorsModule,
            KeyboardFocusModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            AddressFormComponent,
            SuggestedAddressDialogComponent], exports: [AddressFormComponent, SuggestedAddressDialogComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddressFormModule, imports: [NgSelectA11yModule,
            CommonModule,
            ReactiveFormsModule,
            FormsModule,
            RouterModule,
            NgSelectModule,
            IconModule,
            I18nModule,
            FormErrorsModule,
            KeyboardFocusModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            AddressFormComponent,
            SuggestedAddressDialogComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddressFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        NgSelectA11yModule,
                        CommonModule,
                        ReactiveFormsModule,
                        FormsModule,
                        RouterModule,
                        NgSelectModule,
                        IconModule,
                        I18nModule,
                        FormErrorsModule,
                        KeyboardFocusModule,
                        FeaturesConfigModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        AddressFormComponent,
                        SuggestedAddressDialogComponent,
                    ],
                    exports: [AddressFormComponent, SuggestedAddressDialogComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultSuggestedAddressesDialogLayoutConfig = {
    launch: {
        SUGGESTED_ADDRESSES: {
            inlineRoot: true,
            component: SuggestedAddressDialogComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AddressBookModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddressBookModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: AddressBookModule, imports: [CommonModule,
            CardModule,
            AddressFormModule,
            SpinnerModule,
            I18nModule,
            FeaturesConfigModule,
            AddressBookComponent], exports: [AddressBookComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddressBookModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    AccountAddressBookComponent: {
                        component: AddressBookComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
            provideDefaultConfig(defaultSuggestedAddressesDialogLayoutConfig),
            UserAddressService,
        ], imports: [CommonModule,
            CardModule,
            AddressFormModule,
            SpinnerModule,
            I18nModule,
            FeaturesConfigModule,
            AddressBookComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddressBookModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        CardModule,
                        AddressFormModule,
                        SpinnerModule,
                        I18nModule,
                        FeaturesConfigModule,
                        AddressBookComponent,
                    ],
                    exports: [AddressBookComponent],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                AccountAddressBookComponent: {
                                    component: AddressBookComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                        provideDefaultConfig(defaultSuggestedAddressesDialogLayoutConfig),
                        UserAddressService,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ONE_TIME_PASSWORD_REGISTRATION_PURPOSE = 'REGISTRATION';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OneTimePasswordRegisterComponent {
    constructor() {
        this.globalMessageService = inject(GlobalMessageService);
        this.fb = inject(UntypedFormBuilder);
        this.router = inject(RoutingService);
        this.anonymousConsentsService = inject(AnonymousConsentsService);
        this.anonymousConsentsConfig = inject(AnonymousConsentsConfig);
        this.clientAuthenticationTokenService = inject(ClientAuthenticationTokenService);
        this.registerComponentService = inject(RegisterComponentService);
        this.routingService = inject(RoutingService);
        this.registrationVerificationTokenFacade = inject(VerificationTokenFacade);
        this.isLoading$ = new BehaviorSubject(false);
        this.subscription = new Subscription();
        this.registerForm = this.fb.group({
            titleCode: [null],
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            email: ['', [Validators.required, CustomFormValidators.emailValidator]],
            newsletter: new UntypedFormControl({
                value: false,
                disabled: this.isConsentRequired(),
            }),
            additionalConsents: this.registerComponentService.generateAdditionalConsentsFormControl?.() ??
                this.fb.array([]),
            termsandconditions: [false, Validators.requiredTrue],
            captcha: [false, Validators.requiredTrue],
        });
        useFeatureStyles('a11yRegistrationTermsAsteriskMargin');
    }
    get additionalConsents() {
        return this.registerForm?.get('additionalConsents');
    }
    updateAdditionalConsents(event, index) {
        const { checked } = event.target;
        this.registerForm.value.additionalConsents[index] = checked;
    }
    ngOnInit() {
        this.titles$ = this.registerComponentService.getTitles().pipe(map$1((titles) => {
            return titles.sort(sortTitles);
        }));
        const state = history.state;
        if (state?.['email']) {
            this.registerForm.patchValue({
                titleCode: state['titleCode'] ?? null,
                firstName: state['firstName'] ?? '',
                lastName: state['lastName'] ?? '',
                email: state['email'] ?? '',
            });
            history.replaceState({ titleCode: '', firstName: '', lastName: '', email: '' }, '');
        }
        // TODO: Workaround: allow server for decide is titleCode mandatory (if yes, provide personalized message)
        this.subscription.add(this.globalMessageService
            .get()
            .pipe(filter$1((messages) => !!Object.keys(messages).length))
            .subscribe((globalMessageEntities) => {
            const messages = globalMessageEntities &&
                globalMessageEntities[GlobalMessageType.MSG_TYPE_ERROR];
            if (messages &&
                messages.some((message) => message.raw === 'This field is required.')) {
                this.globalMessageService.remove(GlobalMessageType.MSG_TYPE_ERROR);
                this.globalMessageService.add({ key: 'register.titleRequired' }, GlobalMessageType.MSG_TYPE_ERROR);
            }
        }));
        const registerConsent = this.anonymousConsentsConfig?.anonymousConsents?.registerConsent ?? '';
        this.anonymousConsent$ = combineLatest([
            this.anonymousConsentsService.getConsent(registerConsent),
            this.anonymousConsentsService.getTemplate(registerConsent),
        ]).pipe(map$1(([consent, template]) => {
            return {
                consent,
                template: template?.description ? template.description : '',
            };
        }));
        this.additionalRegistrationConsents =
            this.registerComponentService?.getAdditionalConsents() || [];
        this.subscription.add(
        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
        this.registerForm.get('newsletter')?.valueChanges.subscribe(() => {
            this.toggleAnonymousConsent();
        }));
    }
    submitForm() {
        if (this.registerForm.valid) {
            this.sendRegistrationVerificationToken();
        }
        else {
            this.registerForm.markAllAsTouched();
        }
    }
    sendRegistrationVerificationToken() {
        this.isLoading$.next(true);
        this.clientAuthenticationTokenService.loadClientAuthenticationToken();
        const registrationVerificationTokenCreation = this.collectDataFromRegisterForm();
        this.registrationVerificationTokenFacade
            .createVerificationToken(registrationVerificationTokenCreation)
            .subscribe({
            next: (result) => this.goToVerificationTokenForm(result),
            error: (error) => {
                this.routingService.go({
                    cxRoute: 'verifyTokenForRegistration',
                }, {
                    state: {
                        errorStatus: error.status,
                        titleCode: this.registerForm.value.titleCode,
                        firstName: this.registerForm.value.firstName,
                        lastName: this.registerForm.value.lastName,
                        loginId: this.registerForm.value.email.toLowerCase(),
                    },
                });
                this.isLoading$.next(false);
            },
            complete: () => this.onCreateRegistrationVerificationTokenComplete(),
        });
    }
    onCreateRegistrationVerificationTokenComplete() {
        this.isLoading$.next(false);
    }
    collectDataFromRegisterForm() {
        return {
            loginId: this.registerForm.value.email.toLowerCase(),
            purpose: ONE_TIME_PASSWORD_REGISTRATION_PURPOSE,
        };
    }
    goToVerificationTokenForm(registrationVerificationToken) {
        this.routingService.go({
            cxRoute: 'verifyTokenForRegistration',
        }, {
            state: {
                loginId: this.registerForm.value.email.toLowerCase(),
                tokenId: registrationVerificationToken.tokenId,
                expiresIn: registrationVerificationToken.expiresIn,
                titleCode: this.registerForm.value.titleCode,
                firstName: this.registerForm.value.firstName,
                lastName: this.registerForm.value.lastName,
            },
        });
    }
    isConsentGiven(consent) {
        return this.anonymousConsentsService.isConsentGiven(consent);
    }
    isConsentRequired() {
        const requiredConsents = this.anonymousConsentsConfig?.anonymousConsents?.requiredConsents;
        const registerConsent = this.anonymousConsentsConfig?.anonymousConsents?.registerConsent;
        if (requiredConsents && registerConsent) {
            return requiredConsents.includes(registerConsent);
        }
        return false;
    }
    toggleAnonymousConsent() {
        const registerConsent = this.anonymousConsentsConfig?.anonymousConsents?.registerConsent;
        if (registerConsent) {
            if (this.registerForm.get('newsletter')?.value) {
                this.anonymousConsentsService.giveConsent(registerConsent);
            }
            else {
                this.anonymousConsentsService.withdrawConsent(registerConsent);
            }
        }
    }
    /**
     * Triggered via CaptchaComponent when a user confirms captcha
     */
    captchaConfirmed() {
        this.registerForm.get('captcha')?.setValue(true);
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OneTimePasswordRegisterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OneTimePasswordRegisterComponent, isStandalone: true, selector: "cx-otp-register-form", ngImport: i0, template: "<section\n  class=\"cx-page-section container\"\n  *ngIf=\"!(isLoading$ | async); else loading\"\n>\n  <div class=\"row justify-content-center\">\n    <div class=\"col-md-6\">\n      <div class=\"cx-section\">\n        <form (ngSubmit)=\"submitForm()\" [formGroup]=\"registerForm\">\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\">{{\n                'register.title' | cxTranslate\n              }}</span>\n              <ng-select\n                [clearable]=\"false\"\n                [items]=\"(titles$ | async) ?? []\"\n                [placeholder]=\"'register.selectTitle' | cxTranslate\"\n                [searchable]=\"false\"\n                bindLabel=\"name\"\n                bindValue=\"code\"\n                formControlName=\"titleCode\"\n                id=\"title-select\"\n                ariaLabelDropdown=\"{{\n                  'common.ngSelectDropdownOptionsList' | cxTranslate\n                }}\"\n                [cxNgSelectA11y]=\"{}\"\n              >\n              </ng-select>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\"\n                >{{ 'register.firstName.label' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <input\n                required=\"true\"\n                class=\"form-control\"\n                type=\"text\"\n                name=\"firstname\"\n                placeholder=\"{{\n                  'register.firstName.placeholder' | cxTranslate\n                }}\"\n                formControlName=\"firstName\"\n              />\n\n              <cx-form-errors\n                [translationParams]=\"{\n                  label: 'register.firstName.label' | cxTranslate,\n                }\"\n                [control]=\"registerForm.get('firstName')\"\n              ></cx-form-errors>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\"\n                >{{ 'register.lastName.label' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <input\n                required=\"true\"\n                class=\"form-control\"\n                type=\"text\"\n                name=\"lastname\"\n                placeholder=\"{{\n                  'register.lastName.placeholder' | cxTranslate\n                }}\"\n                formControlName=\"lastName\"\n              />\n\n              <cx-form-errors\n                [translationParams]=\"{\n                  label: 'register.lastName.label' | cxTranslate,\n                }\"\n                [control]=\"registerForm.get('lastName')\"\n              ></cx-form-errors>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\"\n                >{{ 'register.emailAddress.label' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <input\n                required=\"true\"\n                class=\"form-control\"\n                type=\"email\"\n                name=\"email\"\n                placeholder=\"{{\n                  'register.emailAddress.placeholder' | cxTranslate\n                }}\"\n                formControlName=\"email\"\n              />\n\n              <cx-form-errors\n                [translationParams]=\"{\n                  label: 'register.emailAddress.label' | cxTranslate,\n                }\"\n                [control]=\"registerForm.get('email')\"\n              ></cx-form-errors>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <div class=\"form-check\">\n              <label *ngIf=\"anonymousConsent$ | async as anonymousConsent\">\n                <input\n                  type=\"checkbox\"\n                  name=\"newsletter\"\n                  class=\"form-check-input\"\n                  formControlName=\"newsletter\"\n                  [checked]=\"isConsentGiven(anonymousConsent.consent)\"\n                />\n                <span class=\"form-check-label\">\n                  {{ anonymousConsent.template }}\n                </span>\n              </label>\n            </div>\n          </div>\n\n          <div\n            formArrayName=\"additionalConsents\"\n            class=\"form-group\"\n            *ngIf=\"additionalRegistrationConsents as consents\"\n          >\n            <div\n              class=\"form-check\"\n              *ngFor=\"let control of additionalConsents.controls; let i = index\"\n            >\n              <div *ngIf=\"consents[i]?.template?.id as id\">\n                <label>\n                  <input\n                    type=\"checkbox\"\n                    [required]=\"consents[i].required\"\n                    [name]=\"id\"\n                    (change)=\"updateAdditionalConsents($any($event), i)\"\n                    [formControlName]=\"i\"\n                  />\n                  <span class=\"form-check-label\">\n                    {{ consents[i].template.description }}\n                  </span>\n                  <cx-form-errors [control]=\"control\"></cx-form-errors>\n                </label>\n              </div>\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <div class=\"form-check\">\n              <label>\n                <input\n                  required=\"true\"\n                  type=\"checkbox\"\n                  name=\"termsandconditions\"\n                  formControlName=\"termsandconditions\"\n                />\n                <span class=\"form-check-label\">\n                  {{ 'register.confirmThatRead' | cxTranslate }}\n                  <a\n                    [routerLink]=\"{ cxRoute: 'termsAndConditions' } | cxUrl\"\n                    target=\"_blank\"\n                    rel=\"noopener noreferrer\"\n                  >\n                    {{ 'register.termsAndConditions' | cxTranslate }}\n                  </a>\n                  <cx-form-required-asterisks />\n                </span>\n\n                <cx-form-errors\n                  [translationParams]=\"{\n                    label: 'register.termsAndConditions' | cxTranslate,\n                  }\"\n                  [control]=\"registerForm.get('termsandconditions')\"\n                ></cx-form-errors>\n              </label>\n            </div>\n          </div>\n          <cx-captcha (confirmed)=\"captchaConfirmed()\"></cx-captcha>\n          <cx-form-errors\n            [control]=\"registerForm.get('captcha')\"\n          ></cx-form-errors>\n          <button type=\"submit\" class=\"btn btn-block btn-primary\">\n            {{ 'register.furtherRegistration' | cxTranslate }}\n          </button>\n          <a\n            class=\"cx-login-link btn-link\"\n            [routerLink]=\"{ cxRoute: 'login' } | cxUrl\"\n            >{{ 'register.signIn' | cxTranslate }}</a\n          >\n        </form>\n      </div>\n    </div>\n  </div>\n</section>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\"><cx-spinner></cx-spinner></div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i2$1.CheckboxRequiredValidator, selector: "input[type=checkbox][required][formControlName],input[type=checkbox][required][formControl],input[type=checkbox][required][ngModel]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: i2$1.FormArrayName, selector: "[formArrayName]", inputs: ["formArrayName"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "directive", type: NgSelectA11yDirective, selector: "[cxNgSelectA11y]", inputs: ["cxNgSelectA11y"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: CaptchaComponent, selector: "cx-captcha", outputs: ["confirmed"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OneTimePasswordRegisterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-otp-register-form', imports: [
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        NgSelectComponent,
                        NgSelectA11yDirective,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        NgFor,
                        RouterLink,
                        CaptchaComponent,
                        SpinnerComponent,
                        AsyncPipe,
                        UrlPipe,
                        TranslatePipe,
                    ], template: "<section\n  class=\"cx-page-section container\"\n  *ngIf=\"!(isLoading$ | async); else loading\"\n>\n  <div class=\"row justify-content-center\">\n    <div class=\"col-md-6\">\n      <div class=\"cx-section\">\n        <form (ngSubmit)=\"submitForm()\" [formGroup]=\"registerForm\">\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\">{{\n                'register.title' | cxTranslate\n              }}</span>\n              <ng-select\n                [clearable]=\"false\"\n                [items]=\"(titles$ | async) ?? []\"\n                [placeholder]=\"'register.selectTitle' | cxTranslate\"\n                [searchable]=\"false\"\n                bindLabel=\"name\"\n                bindValue=\"code\"\n                formControlName=\"titleCode\"\n                id=\"title-select\"\n                ariaLabelDropdown=\"{{\n                  'common.ngSelectDropdownOptionsList' | cxTranslate\n                }}\"\n                [cxNgSelectA11y]=\"{}\"\n              >\n              </ng-select>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\"\n                >{{ 'register.firstName.label' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <input\n                required=\"true\"\n                class=\"form-control\"\n                type=\"text\"\n                name=\"firstname\"\n                placeholder=\"{{\n                  'register.firstName.placeholder' | cxTranslate\n                }}\"\n                formControlName=\"firstName\"\n              />\n\n              <cx-form-errors\n                [translationParams]=\"{\n                  label: 'register.firstName.label' | cxTranslate,\n                }\"\n                [control]=\"registerForm.get('firstName')\"\n              ></cx-form-errors>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\"\n                >{{ 'register.lastName.label' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <input\n                required=\"true\"\n                class=\"form-control\"\n                type=\"text\"\n                name=\"lastname\"\n                placeholder=\"{{\n                  'register.lastName.placeholder' | cxTranslate\n                }}\"\n                formControlName=\"lastName\"\n              />\n\n              <cx-form-errors\n                [translationParams]=\"{\n                  label: 'register.lastName.label' | cxTranslate,\n                }\"\n                [control]=\"registerForm.get('lastName')\"\n              ></cx-form-errors>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              <span class=\"label-content\"\n                >{{ 'register.emailAddress.label' | cxTranslate }}\n                <cx-form-required-asterisks />\n              </span>\n              <input\n                required=\"true\"\n                class=\"form-control\"\n                type=\"email\"\n                name=\"email\"\n                placeholder=\"{{\n                  'register.emailAddress.placeholder' | cxTranslate\n                }}\"\n                formControlName=\"email\"\n              />\n\n              <cx-form-errors\n                [translationParams]=\"{\n                  label: 'register.emailAddress.label' | cxTranslate,\n                }\"\n                [control]=\"registerForm.get('email')\"\n              ></cx-form-errors>\n            </label>\n          </div>\n\n          <div class=\"form-group\">\n            <div class=\"form-check\">\n              <label *ngIf=\"anonymousConsent$ | async as anonymousConsent\">\n                <input\n                  type=\"checkbox\"\n                  name=\"newsletter\"\n                  class=\"form-check-input\"\n                  formControlName=\"newsletter\"\n                  [checked]=\"isConsentGiven(anonymousConsent.consent)\"\n                />\n                <span class=\"form-check-label\">\n                  {{ anonymousConsent.template }}\n                </span>\n              </label>\n            </div>\n          </div>\n\n          <div\n            formArrayName=\"additionalConsents\"\n            class=\"form-group\"\n            *ngIf=\"additionalRegistrationConsents as consents\"\n          >\n            <div\n              class=\"form-check\"\n              *ngFor=\"let control of additionalConsents.controls; let i = index\"\n            >\n              <div *ngIf=\"consents[i]?.template?.id as id\">\n                <label>\n                  <input\n                    type=\"checkbox\"\n                    [required]=\"consents[i].required\"\n                    [name]=\"id\"\n                    (change)=\"updateAdditionalConsents($any($event), i)\"\n                    [formControlName]=\"i\"\n                  />\n                  <span class=\"form-check-label\">\n                    {{ consents[i].template.description }}\n                  </span>\n                  <cx-form-errors [control]=\"control\"></cx-form-errors>\n                </label>\n              </div>\n            </div>\n          </div>\n\n          <div class=\"form-group\">\n            <div class=\"form-check\">\n              <label>\n                <input\n                  required=\"true\"\n                  type=\"checkbox\"\n                  name=\"termsandconditions\"\n                  formControlName=\"termsandconditions\"\n                />\n                <span class=\"form-check-label\">\n                  {{ 'register.confirmThatRead' | cxTranslate }}\n                  <a\n                    [routerLink]=\"{ cxRoute: 'termsAndConditions' } | cxUrl\"\n                    target=\"_blank\"\n                    rel=\"noopener noreferrer\"\n                  >\n                    {{ 'register.termsAndConditions' | cxTranslate }}\n                  </a>\n                  <cx-form-required-asterisks />\n                </span>\n\n                <cx-form-errors\n                  [translationParams]=\"{\n                    label: 'register.termsAndConditions' | cxTranslate,\n                  }\"\n                  [control]=\"registerForm.get('termsandconditions')\"\n                ></cx-form-errors>\n              </label>\n            </div>\n          </div>\n          <cx-captcha (confirmed)=\"captchaConfirmed()\"></cx-captcha>\n          <cx-form-errors\n            [control]=\"registerForm.get('captcha')\"\n          ></cx-form-errors>\n          <button type=\"submit\" class=\"btn btn-block btn-primary\">\n            {{ 'register.furtherRegistration' | cxTranslate }}\n          </button>\n          <a\n            class=\"cx-login-link btn-link\"\n            [routerLink]=\"{ cxRoute: 'login' } | cxUrl\"\n            >{{ 'register.signIn' | cxTranslate }}</a\n          >\n        </form>\n      </div>\n    </div>\n  </div>\n</section>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\"><cx-spinner></cx-spinner></div>\n</ng-template>\n" }]
        }], ctorParameters: () => [] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OneTimePasswordRegisterModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OneTimePasswordRegisterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OneTimePasswordRegisterModule, imports: [CommonModule,
            RouterModule,
            UrlModule,
            PageSlotModule,
            I18nModule,
            FeaturesConfigModule,
            BtnLikeLinkModule,
            ReactiveFormsModule,
            NgSelectModule,
            NgSelectA11yModule,
            CaptchaModule,
            SpinnerModule,
            FormErrorsModule,
            FormRequiredAsterisksComponent,
            OneTimePasswordRegisterComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OneTimePasswordRegisterModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    RegisterCustomerWithOTPComponent: {
                        component: OneTimePasswordRegisterComponent,
                        guards: [NotAuthGuard],
                        providers: [
                            {
                                provide: RegisterComponentService,
                                useClass: RegisterComponentService,
                                deps: [UserRegisterFacade, UntypedFormBuilder],
                            },
                        ],
                    },
                },
            }),
        ], imports: [CommonModule,
            RouterModule,
            UrlModule,
            PageSlotModule,
            I18nModule,
            FeaturesConfigModule,
            BtnLikeLinkModule,
            ReactiveFormsModule,
            NgSelectModule,
            NgSelectA11yModule,
            CaptchaModule,
            SpinnerModule,
            FormErrorsModule,
            FormRequiredAsterisksComponent,
            OneTimePasswordRegisterComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OneTimePasswordRegisterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        UrlModule,
                        PageSlotModule,
                        I18nModule,
                        FeaturesConfigModule,
                        BtnLikeLinkModule,
                        ReactiveFormsModule,
                        NgSelectModule,
                        NgSelectA11yModule,
                        CaptchaModule,
                        SpinnerModule,
                        FormErrorsModule,
                        FormRequiredAsterisksComponent,
                        OneTimePasswordRegisterComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                RegisterCustomerWithOTPComponent: {
                                    component: OneTimePasswordRegisterComponent,
                                    guards: [NotAuthGuard],
                                    providers: [
                                        {
                                            provide: RegisterComponentService,
                                            useClass: RegisterComponentService,
                                            deps: [UserRegisterFacade, UntypedFormBuilder],
                                        },
                                    ],
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const globalMsgShowTime = 10000;
class RegistrationVerificationTokenFormComponentService {
    constructor() {
        this.globalMessageService = inject(GlobalMessageService);
        this.userRegisterFacade = inject(UserRegisterFacade);
    }
    displayMessage(key, params) {
        this.globalMessageService.add({
            key: key,
            params,
        }, GlobalMessageType.MSG_TYPE_CONFIRMATION, globalMsgShowTime);
    }
    register(user) {
        return this.userRegisterFacade.register(user);
    }
    postRegisterMessage() {
        this.displayMessage('register.postRegisterSuccessMessage', globalMsgShowTime);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegistrationVerificationTokenFormComponentService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegistrationVerificationTokenFormComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegistrationVerificationTokenFormComponentService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class RegistrationVerificationTokenFormComponent {
    constructor() {
        this.fb = inject(UntypedFormBuilder);
        this.router = inject(RoutingService);
        this.authConfigService = inject(AuthConfigService);
        this.registrationVerificationTokenFacade = inject(VerificationTokenFacade);
        this.service = inject(RegistrationVerificationTokenFormComponentService);
        this.globalMessage = inject(GlobalMessageService);
        this.launchDialogService = inject(LaunchDialogService);
        this.featureToggles = inject(FeatureToggles);
        this.passwordValidators = this.getPasswordValidators();
        this.cdr = inject(ChangeDetectorRef);
        this.waitTime = 60;
        this.waitTimeForRateLimit = 300;
        this.registerForm = this.fb.group({
            password: ['', [Validators.required, ...this.passwordValidators]],
            passwordconf: ['', Validators.required],
            tokenCode: ['', Validators.required],
            titleCode: [''],
            firstName: [''],
            lastName: [''],
            email: [''],
            tokenId: [''],
        }, {
            validators: CustomFormValidators.passwordsMustMatch('password', 'passwordconf'),
        });
        this.isLoading$ = new BehaviorSubject(false);
        this.isResendDisabled = true;
    }
    getPasswordValidators() {
        return this.featureToggles.useEnhancedSecurePasswordValidators
            ? [
                ...CustomFormValidators.securePasswordValidators,
                CustomFormValidators.mustEndWithLegalCharacter,
            ]
            : CustomFormValidators.securePasswordValidators;
    }
    ngOnInit() {
        if (history.state) {
            this.tokenId = history.state['tokenId'];
            this.target = history.state['loginId'];
            this.titleCode = history.state['titleCode'];
            this.firstName = history.state['firstName'];
            this.lastName = history.state['lastName'];
            this.errorStatus = history.state['errorStatus'];
            history.pushState({
                tokenId: '',
                loginId: '',
                titleCode: '',
                firstName: '',
                lastName: '',
                errorStatus: '',
            }, 'verifyTokenForRegistration');
        }
        if (this.errorStatus === 400) {
            this.upToRateLimit = true;
            this.tokenId = 'invalidTokenId';
            this.startRateLimitWaitTimeInterval();
        }
        else if (!this.target ||
            !this.tokenId ||
            !this.firstName ||
            !this.lastName) {
            this.router.go(this.featureToggles.authorizationCodeFlowByDefault
                ? { cxRoute: 'register' }
                : ['/login/register']);
        }
        else {
            this.startWaitTimeInterval();
            this.service.displayMessage('verificationTokenForm.createVerificationToken', { target: this.target });
        }
    }
    onSubmit() {
        if (this.registerForm.valid) {
            this.registerUserWithVerificationToken();
        }
        else {
            this.registerForm.markAllAsTouched();
        }
    }
    registerUserWithVerificationToken() {
        this.isLoading$.next(true);
        this.registerForm.setValue({
            titleCode: this.titleCode,
            firstName: this.firstName,
            lastName: this.lastName,
            email: this.target,
            tokenId: this.tokenId,
            password: this.registerForm.value.password,
            tokenCode: this.registerForm.value.tokenCode,
            passwordconf: this.registerForm.value.passwordconf,
        });
        this.service
            .register(this.collectDataFromRegisterForm(this.registerForm.value))
            .subscribe({
            next: () => this.onRegisterUserSuccess(),
            complete: () => this.isLoading$.next(false),
            error: (error) => {
                if (error.status === 400) {
                    this.registerForm
                        .get('tokenCode')
                        ?.setErrors({ invalidTokenCodeError: error.message });
                    this.globalMessage.remove(GlobalMessageType.MSG_TYPE_ERROR);
                }
                this.isLoading$.next(false);
            },
        });
    }
    collectDataFromRegisterForm(formData) {
        const { email, firstName, lastName, password, titleCode, tokenId: verificationTokenId, tokenCode: verificationTokenCode, } = formData;
        return {
            uid: email.toLowerCase(),
            firstName,
            lastName,
            password,
            titleCode,
            verificationTokenId,
            verificationTokenCode,
        };
    }
    onRegisterUserSuccess() {
        if (this.authConfigService.getOAuthFlow() ===
            OAuthFlow.ResourceOwnerPasswordFlow) {
            this.router.go('login');
        }
        if (this.featureToggles.authorizationCodeFlowByDefault) {
            this.router.go({ cxRoute: 'login' });
        }
        this.service.postRegisterMessage();
    }
    resendOTP() {
        this.isResendDisabled = true;
        this.resendLink.nativeElement.tabIndex = -1;
        this.waitTime = 60;
        this.startWaitTimeInterval();
        this.createRegistrationVerificationToken(this.target, ONE_TIME_PASSWORD_REGISTRATION_PURPOSE).subscribe({
            next: (result) => (this.tokenId = result.tokenId),
            complete: () => this.service.displayMessage('verificationTokenForm.createVerificationToken', { target: this.target }),
        });
    }
    createRegistrationVerificationToken(loginId, purpose) {
        return this.registrationVerificationTokenFacade.createVerificationToken({
            loginId,
            purpose,
        });
    }
    startWaitTimeInterval() {
        const interval = setInterval(() => {
            this.waitTime--;
            this.cdr.detectChanges();
            if (this.waitTime <= 0) {
                clearInterval(interval);
                this.isResendDisabled = false;
                this.resendLink.nativeElement.tabIndex = 0;
                this.cdr.detectChanges();
            }
        }, 1000);
    }
    startRateLimitWaitTimeInterval() {
        const interval = setInterval(() => {
            this.waitTimeForRateLimit--;
            this.cdr.detectChanges();
            if (this.waitTimeForRateLimit <= 0) {
                clearInterval(interval);
                this.upToRateLimit = false;
                this.isResendDisabled = false;
                this.cdr.detectChanges();
            }
        }, 1000);
    }
    openInfoDailog() {
        this.launchDialogService.openDialogAndSubscribe(LAUNCH_CALLER.ACCOUNT_VERIFICATION_TOKEN, this.element);
    }
    onOpenInfoDailogKeyDown(event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.openInfoDailog();
        }
    }
    goBack() {
        this.router.go({ cxRoute: 'register' }, {
            state: {
                titleCode: this.titleCode,
                firstName: this.firstName,
                lastName: this.lastName,
                email: this.target,
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegistrationVerificationTokenFormComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: RegistrationVerificationTokenFormComponent, isStandalone: true, selector: "cx-registration-verification-token-form", host: { attributes: { "ngSkipHydration": "true" } }, viewQueries: [{ propertyName: "element", first: true, predicate: ["noReceiveCodeLink"], descendants: true }, { propertyName: "resendLink", first: true, predicate: ["resendLink"], descendants: true }], ngImport: i0, template: "<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"registerForm\">\n  <label>\n    <span class=\"label-content\">\n      {{ 'verificationTokenForm.verificationCode.label' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      class=\"form-control\"\n      formControlName=\"tokenCode\"\n      placeholder=\"{{\n        'verificationTokenForm.verificationCode.placeholder' | cxTranslate\n      }}\"\n    />\n    <cx-form-errors [control]=\"registerForm.get('tokenCode')\"></cx-form-errors>\n    <div class=\"rate-limit-error-display\" *ngIf=\"upToRateLimit\">\n      {{\n        'register.rateLimitForRegistrationMessage'\n          | cxTranslate: { seconds: waitTimeForRateLimit }\n      }}\n    </div>\n  </label>\n\n  <input type=\"hidden\" formControlName=\"tokenId\" [(ngModel)]=\"tokenId\" />\n\n  <div *ngIf=\"!upToRateLimit\" class=\"resend-link-text\">\n    <div class=\"left-text\">\n      <span role=\"timer\" aria-live=\"polite\" aria-atomic=\"true\">\n        <a\n          role=\"button\"\n          tabindex=\"-1\"\n          #resendLink\n          (keydown.enter)=\"resendOTP()\"\n          (keydown.space)=\"resendOTP()\"\n          (click)=\"resendOTP()\"\n          class=\"btn-link\"\n          [ngClass]=\"{ 'disabled-link': isResendDisabled }\"\n        >\n          {{ 'verificationTokenForm.resend' | cxTranslate }}\n        </a>\n        <ng-container *ngIf=\"isResendDisabled\">\n          {{\n            'verificationTokenForm.sendRateLime'\n              | cxTranslate: { waitTime: waitTime }\n          }}\n        </ng-container>\n      </span>\n    </div>\n    <div class=\"right-text\">\n      <a\n        role=\"button\"\n        tabindex=\"0\"\n        #noReceiveCodeLink\n        (keydown)=\"onOpenInfoDailogKeyDown($event)\"\n        (click)=\"openInfoDailog()\"\n        class=\"btn-link\"\n      >\n        {{ 'verificationTokenForm.noReceiveCode' | cxTranslate }}\n      </a>\n    </div>\n  </div>\n\n  <div class=\"form-group\">\n    <label>\n      <span class=\"label-content\"\n        >{{ 'register.password.label' | cxTranslate }}\n        <cx-form-required-asterisks\n      /></span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"password\"\n        name=\"password\"\n        placeholder=\"{{ 'register.password.placeholder' | cxTranslate }}\"\n        formControlName=\"password\"\n        [attr.aria-label]=\"'register.password.placeholder' | cxTranslate\"\n        aria-describedby=\"password-input-hint\"\n        cxPasswordVisibilitySwitch\n      />\n      <p class=\"input-hint\" id=\"password-input-hint\">\n        {{ 'register.passwordMinRequirements' | cxTranslate }}\n      </p>\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'register.password.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('password')\"\n      ></cx-form-errors>\n    </label>\n  </div>\n\n  <div class=\"form-group\">\n    <label>\n      <span class=\"label-content\"\n        >{{ 'register.confirmPassword.label' | cxTranslate }}\n        <cx-form-required-asterisks\n      /></span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"password\"\n        name=\"confirmpassword\"\n        placeholder=\"{{ 'register.confirmPassword.placeholder' | cxTranslate }}\"\n        formControlName=\"passwordconf\"\n        [attr.aria-label]=\"'register.confirmPassword.placeholder' | cxTranslate\"\n        cxPasswordVisibilitySwitch\n      />\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'register.confirmPassword.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('passwordconf')\"\n      ></cx-form-errors>\n    </label>\n  </div>\n\n  <div class=\"verify-container\">\n    <button\n      type=\"submit\"\n      class=\"btn btn-block btn-primary\"\n      [disabled]=\"registerForm.disabled\"\n    >\n      {{ 'register.register' | cxTranslate }}\n    </button>\n    <button\n      type=\"button\"\n      (click)=\"goBack()\"\n      class=\"btn btn-block btn-secondary btn-register\"\n    >\n      {{ 'verificationTokenForm.back' | cxTranslate }}\n    </button>\n  </div>\n</form>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\"><cx-spinner></cx-spinner></div>\n</ng-template>\n", dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i2$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegistrationVerificationTokenFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-registration-verification-token-form', changeDetection: ChangeDetectionStrategy.OnPush, host: { ngSkipHydration: 'true' }, imports: [
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        NgIf,
                        NgClass,
                        SpinnerComponent,
                        TranslatePipe,
                    ], template: "<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"registerForm\">\n  <label>\n    <span class=\"label-content\">\n      {{ 'verificationTokenForm.verificationCode.label' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      class=\"form-control\"\n      formControlName=\"tokenCode\"\n      placeholder=\"{{\n        'verificationTokenForm.verificationCode.placeholder' | cxTranslate\n      }}\"\n    />\n    <cx-form-errors [control]=\"registerForm.get('tokenCode')\"></cx-form-errors>\n    <div class=\"rate-limit-error-display\" *ngIf=\"upToRateLimit\">\n      {{\n        'register.rateLimitForRegistrationMessage'\n          | cxTranslate: { seconds: waitTimeForRateLimit }\n      }}\n    </div>\n  </label>\n\n  <input type=\"hidden\" formControlName=\"tokenId\" [(ngModel)]=\"tokenId\" />\n\n  <div *ngIf=\"!upToRateLimit\" class=\"resend-link-text\">\n    <div class=\"left-text\">\n      <span role=\"timer\" aria-live=\"polite\" aria-atomic=\"true\">\n        <a\n          role=\"button\"\n          tabindex=\"-1\"\n          #resendLink\n          (keydown.enter)=\"resendOTP()\"\n          (keydown.space)=\"resendOTP()\"\n          (click)=\"resendOTP()\"\n          class=\"btn-link\"\n          [ngClass]=\"{ 'disabled-link': isResendDisabled }\"\n        >\n          {{ 'verificationTokenForm.resend' | cxTranslate }}\n        </a>\n        <ng-container *ngIf=\"isResendDisabled\">\n          {{\n            'verificationTokenForm.sendRateLime'\n              | cxTranslate: { waitTime: waitTime }\n          }}\n        </ng-container>\n      </span>\n    </div>\n    <div class=\"right-text\">\n      <a\n        role=\"button\"\n        tabindex=\"0\"\n        #noReceiveCodeLink\n        (keydown)=\"onOpenInfoDailogKeyDown($event)\"\n        (click)=\"openInfoDailog()\"\n        class=\"btn-link\"\n      >\n        {{ 'verificationTokenForm.noReceiveCode' | cxTranslate }}\n      </a>\n    </div>\n  </div>\n\n  <div class=\"form-group\">\n    <label>\n      <span class=\"label-content\"\n        >{{ 'register.password.label' | cxTranslate }}\n        <cx-form-required-asterisks\n      /></span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"password\"\n        name=\"password\"\n        placeholder=\"{{ 'register.password.placeholder' | cxTranslate }}\"\n        formControlName=\"password\"\n        [attr.aria-label]=\"'register.password.placeholder' | cxTranslate\"\n        aria-describedby=\"password-input-hint\"\n        cxPasswordVisibilitySwitch\n      />\n      <p class=\"input-hint\" id=\"password-input-hint\">\n        {{ 'register.passwordMinRequirements' | cxTranslate }}\n      </p>\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'register.password.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('password')\"\n      ></cx-form-errors>\n    </label>\n  </div>\n\n  <div class=\"form-group\">\n    <label>\n      <span class=\"label-content\"\n        >{{ 'register.confirmPassword.label' | cxTranslate }}\n        <cx-form-required-asterisks\n      /></span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"password\"\n        name=\"confirmpassword\"\n        placeholder=\"{{ 'register.confirmPassword.placeholder' | cxTranslate }}\"\n        formControlName=\"passwordconf\"\n        [attr.aria-label]=\"'register.confirmPassword.placeholder' | cxTranslate\"\n        cxPasswordVisibilitySwitch\n      />\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'register.confirmPassword.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('passwordconf')\"\n      ></cx-form-errors>\n    </label>\n  </div>\n\n  <div class=\"verify-container\">\n    <button\n      type=\"submit\"\n      class=\"btn btn-block btn-primary\"\n      [disabled]=\"registerForm.disabled\"\n    >\n      {{ 'register.register' | cxTranslate }}\n    </button>\n    <button\n      type=\"button\"\n      (click)=\"goBack()\"\n      class=\"btn btn-block btn-secondary btn-register\"\n    >\n      {{ 'verificationTokenForm.back' | cxTranslate }}\n    </button>\n  </div>\n</form>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\"><cx-spinner></cx-spinner></div>\n</ng-template>\n" }]
        }], propDecorators: { element: [{
                type: ViewChild,
                args: ['noReceiveCodeLink']
            }], resendLink: [{
                type: ViewChild,
                args: ['resendLink']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class RegistrationVerificationTokenFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegistrationVerificationTokenFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: RegistrationVerificationTokenFormModule, imports: [CommonModule,
            FormsModule,
            KeyboardFocusModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            IconModule,
            I18nModule,
            FormErrorsModule,
            SpinnerModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            RegistrationVerificationTokenFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegistrationVerificationTokenFormModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    VerifyOTPForRegistrationComponent: {
                        component: RegistrationVerificationTokenFormComponent,
                        guards: [NotAuthGuard],
                        providers: [
                            {
                                provide: RegistrationVerificationTokenFormComponentService,
                                useClass: RegistrationVerificationTokenFormComponentService,
                                deps: [GlobalMessageService, UserRegisterFacade],
                            },
                        ],
                    },
                },
            }),
        ], imports: [CommonModule,
            FormsModule,
            KeyboardFocusModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            IconModule,
            I18nModule,
            FormErrorsModule,
            SpinnerModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            RegistrationVerificationTokenFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegistrationVerificationTokenFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        FormsModule,
                        KeyboardFocusModule,
                        ReactiveFormsModule,
                        RouterModule,
                        UrlModule,
                        IconModule,
                        I18nModule,
                        FormErrorsModule,
                        SpinnerModule,
                        FeaturesConfigModule,
                        FormRequiredAsterisksComponent,
                        RegistrationVerificationTokenFormComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                VerifyOTPForRegistrationComponent: {
                                    component: RegistrationVerificationTokenFormComponent,
                                    guards: [NotAuthGuard],
                                    providers: [
                                        {
                                            provide: RegistrationVerificationTokenFormComponentService,
                                            useClass: RegistrationVerificationTokenFormComponentService,
                                            deps: [GlobalMessageService, UserRegisterFacade],
                                        },
                                    ],
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserProfileComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserProfileComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: UserProfileComponentsModule, imports: [RegisterComponentModule,
            UpdateProfileModule,
            UpdateEmailModule,
            UpdatePasswordModule,
            ForgotPasswordModule,
            ResetPasswordModule,
            CloseAccountModule,
            AddressBookModule,
            OneTimePasswordRegisterModule,
            RegistrationVerificationTokenFormModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserProfileComponentsModule, imports: [RegisterComponentModule,
            UpdateProfileModule,
            UpdateEmailModule,
            UpdatePasswordModule,
            ForgotPasswordModule,
            ResetPasswordModule,
            CloseAccountModule,
            AddressBookModule,
            OneTimePasswordRegisterModule,
            RegistrationVerificationTokenFormModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserProfileComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        RegisterComponentModule,
                        UpdateProfileModule,
                        UpdateEmailModule,
                        UpdatePasswordModule,
                        ForgotPasswordModule,
                        ResetPasswordModule,
                        CloseAccountModule,
                        AddressBookModule,
                        OneTimePasswordRegisterModule,
                        RegistrationVerificationTokenFormModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AddressBookComponent, AddressBookComponentService, AddressBookModule, AddressFormComponent, AddressFormModule, CloseAccountComponent, CloseAccountModalComponent, CloseAccountModule, ForgotPasswordComponent, ForgotPasswordComponentService, ForgotPasswordModule, MyAccountV2EmailComponent, MyAccountV2PasswordComponent, MyAccountV2ProfileComponent, OneTimePasswordRegisterComponent, OneTimePasswordRegisterModule, RegisterComponent, RegisterComponentModule, RegisterComponentService, RegistrationVerificationTokenFormComponent, RegistrationVerificationTokenFormComponentService, RegistrationVerificationTokenFormModule, ResetPasswordComponent, ResetPasswordComponentService, ResetPasswordModule, SuggestedAddressDialogComponent, USE_MY_ACCOUNT_V2_EMAIL, USE_MY_ACCOUNT_V2_PASSWORD, USE_MY_ACCOUNT_V2_PROFILE, UpdateEmailComponent, UpdateEmailComponentService, UpdateEmailModule, UpdatePasswordComponent, UpdatePasswordComponentService, UpdatePasswordModule, UpdateProfileComponent, UpdateProfileComponentService, UpdateProfileModule, UserProfileComponentsModule };
//# sourceMappingURL=spartacus-user-profile-components.mjs.map
