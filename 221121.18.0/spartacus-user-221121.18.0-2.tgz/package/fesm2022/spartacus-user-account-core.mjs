import * as i0 from '@angular/core';
import { InjectionToken, Injectable, inject, NgModule } from '@angular/core';
import * as i2 from '@spartacus/core';
import { LoginEvent, LogoutEvent, CommandService } from '@spartacus/core';
import { UserAccountChangedEvent, UserAccountFacade, VerificationTokenFacade } from '@spartacus/user/account/root';
import { switchMap } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const USER_ACCOUNT_NORMALIZER = new InjectionToken('UserAccountNormalizer');
const USER_ACCOUNT_SERIALIZER = new InjectionToken('UserAccountSerializer');
const VERIFICATION_TOKEN_NORMALIZER = new InjectionToken('VerificationTokenNormalizer');
const LOGIN_FORM_SERIALIZER = new InjectionToken('LoginFormSerializer');

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAccountAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAccountConnector {
    constructor(adapter) {
        this.adapter = adapter;
    }
    get(userId) {
        return this.adapter.load(userId);
    }
    createVerificationToken(verificationTokenCreation) {
        return this.adapter.createVerificationToken(verificationTokenCreation);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountConnector, deps: [{ token: UserAccountAdapter }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountConnector, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: UserAccountAdapter }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAccountService {
    constructor(userAccountConnector, userIdService, query) {
        this.userAccountConnector = userAccountConnector;
        this.userIdService = userIdService;
        this.query = query;
        this.userQuery = this.query.create(() => this.userIdService
            .takeUserId(true)
            .pipe(switchMap((userId) => this.userAccountConnector.get(userId))), {
            reloadOn: [UserAccountChangedEvent],
            resetOn: [LoginEvent, LogoutEvent],
        });
    }
    /**
     * Returns the user according the userId
     * no use query for userId can change every time
     */
    getById(userId) {
        return this.userAccountConnector.get(userId);
    }
    /**
     * Returns the current user.
     */
    get() {
        return this.userQuery.get();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountService, deps: [{ token: UserAccountConnector }, { token: i2.UserIdService }, { token: i2.QueryService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: UserAccountConnector }, { type: i2.UserIdService }, { type: i2.QueryService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class VerificationTokenService {
    constructor() {
        this.connector = inject(UserAccountConnector);
        this.command = inject(CommandService);
        this.createVerificationTokenCommand = this.command.create(({ verificationTokenCreation }) => this.connector.createVerificationToken(verificationTokenCreation));
    }
    /**
     * create verification token
     */
    createVerificationToken(verificationTokenCreation) {
        return this.createVerificationTokenCommand.execute({
            verificationTokenCreation,
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: VerificationTokenService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: VerificationTokenService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: VerificationTokenService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const facadeProviders = [
    UserAccountService,
    {
        provide: UserAccountFacade,
        useExisting: UserAccountService,
    },
    VerificationTokenService,
    {
        provide: VerificationTokenFacade,
        useExisting: VerificationTokenService,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAccountCoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: UserAccountCoreModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountCoreModule, providers: [UserAccountConnector, ...facadeProviders] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [UserAccountConnector, ...facadeProviders],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { LOGIN_FORM_SERIALIZER, USER_ACCOUNT_NORMALIZER, USER_ACCOUNT_SERIALIZER, UserAccountAdapter, UserAccountConnector, UserAccountCoreModule, UserAccountService, VERIFICATION_TOKEN_NORMALIZER, VerificationTokenService };
//# sourceMappingURL=spartacus-user-account-core.mjs.map
