import * as i1 from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import * as i2 from '@spartacus/core';
import { LoggerService, tryNormalizeHttpError, InterceptorUtil, USE_CLIENT_TOKEN, provideDefaultConfig } from '@spartacus/core';
import { USER_ACCOUNT_NORMALIZER, LOGIN_FORM_SERIALIZER, VERIFICATION_TOKEN_NORMALIZER, UserAccountAdapter } from '@spartacus/user/account/core';
import { catchError } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOccUserAccountConfig = {
    backend: {
        occ: {
            endpoints: {
                user: 'users/${userId}',
                createVerificationToken: 'users/anonymous/verificationToken',
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const CONTENT_TYPE_JSON_HEADER = { 'Content-Type': 'application/json' };
class OccUserAccountAdapter {
    constructor(http, occEndpoints, converter) {
        this.http = http;
        this.occEndpoints = occEndpoints;
        this.converter = converter;
        this.logger = inject(LoggerService);
    }
    load(userId) {
        const url = this.occEndpoints.buildUrl('user', { urlParams: { userId } });
        return this.http.get(url).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), this.converter.pipeable(USER_ACCOUNT_NORMALIZER));
    }
    createVerificationToken(verificationTokenCreation) {
        const url = this.occEndpoints.buildUrl('createVerificationToken');
        const headers = InterceptorUtil.createHeader(USE_CLIENT_TOKEN, true, new HttpHeaders({
            ...CONTENT_TYPE_JSON_HEADER,
        }));
        verificationTokenCreation = this.converter.convert(verificationTokenCreation, LOGIN_FORM_SERIALIZER);
        return this.http
            .post(url, verificationTokenCreation, { headers })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), this.converter.pipeable(VERIFICATION_TOKEN_NORMALIZER));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccUserAccountAdapter, deps: [{ token: i1.HttpClient }, { token: i2.OccEndpointsService }, { token: i2.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccUserAccountAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccUserAccountAdapter, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: i2.OccEndpointsService }, { type: i2.ConverterService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAccountOccModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountOccModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: UserAccountOccModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountOccModule, providers: [
            provideDefaultConfig(defaultOccUserAccountConfig),
            { provide: UserAccountAdapter, useClass: OccUserAccountAdapter },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountOccModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        provideDefaultConfig(defaultOccUserAccountConfig),
                        { provide: UserAccountAdapter, useClass: OccUserAccountAdapter },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OccUserAccountAdapter, UserAccountOccModule, defaultOccUserAccountConfig };
//# sourceMappingURL=spartacus-user-account-occ.mjs.map
