import { OccConfig, OccEndpoint, OccEndpointsService, ConverterService, LoggerService } from '@spartacus/core';
import { HttpClient } from '@angular/common/http';
import { UserAccountAdapter } from '@spartacus/user/account/core';
import { User, VerificationTokenCreation, VerificationToken } from '@spartacus/user/account/root';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';

declare const defaultOccUserAccountConfig: OccConfig;

interface UserAccountOccEndpoints {
    /**
     * Get user account details
     */
    user?: string | OccEndpoint;
    /**
     * Create one time password for user login
     */
    createVerificationToken?: string | OccEndpoint;
}
declare module '@spartacus/core' {
    interface OccEndpoints extends UserAccountOccEndpoints {
    }
}

declare class OccUserAccountAdapter implements UserAccountAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    load(userId: string): Observable<User>;
    createVerificationToken(verificationTokenCreation: VerificationTokenCreation): Observable<VerificationToken>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccUserAccountAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccUserAccountAdapter>;
}

declare class UserAccountOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAccountOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserAccountOccModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserAccountOccModule>;
}

export { OccUserAccountAdapter, UserAccountOccModule, defaultOccUserAccountConfig };
export type { UserAccountOccEndpoints };
