import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    userAccount: {
        loginForm: {
            forgotPassword: string;
            signIn: string;
            register: string;
            dontHaveAccount: string;
            guestCheckout: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            wrongEmailFormat: string;
        };
        verificationTokenForm: {
            createVerificationToken: string;
            needInputCredentials: string;
            sendRateLime: string;
            resend: string;
            verificationCode: {
                label: string;
                placeholder: string;
            };
            noReceiveCode: string;
            verify: string;
            registerVerify: string;
            back: string;
            tokenInputHint: string;
        };
        verificationTokenDialog: {
            title: string;
            noReceiveCode: string;
            contentLine1: string;
            contentLine2: string;
            contentLine3: string;
            close: string;
        };
        miniLogin: {
            userGreeting: string;
            signInRegister: string;
        };
        myAccountV2User: {
            signOut: string;
        };
    };
};

declare const de: {
    userAccount: {
        loginForm: {
            forgotPassword: string;
            signIn: string;
            register: string;
            dontHaveAccount: string;
            guestCheckout: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            wrongEmailFormat: string;
        };
        verificationTokenForm: {
            createVerificationToken: string;
            needInputCredentials: string;
            sendRateLime: string;
            resend: string;
            verificationCode: {
                label: string;
                placeholder: string;
            };
            noReceiveCode: string;
            verify: string;
            registerVerify: string;
            back: string;
            tokenInputHint: string;
        };
        verificationTokenDialog: {
            title: string;
            noReceiveCode: string;
            contentLine1: string;
            contentLine2: string;
            contentLine3: string;
            close: string;
        };
        miniLogin: {
            userGreeting: string;
            signInRegister: string;
        };
        myAccountV2User: {
            signOut: string;
        };
    };
};

declare const en: {
    userAccount: {
        loginForm: {
            forgotPassword: string;
            signIn: string;
            register: string;
            dontHaveAccount: string;
            guestCheckout: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            wrongEmailFormat: string;
        };
        verificationTokenForm: {
            createVerificationToken: string;
            needInputCredentials: string;
            sendRateLime: string;
            resend: string;
            verificationCode: {
                label: string;
                placeholder: string;
            };
            noReceiveCode: string;
            verify: string;
            registerVerify: string;
            back: string;
            tokenInputHint: string;
        };
        verificationTokenDialog: {
            title: string;
            noReceiveCode: string;
            contentLine1: string;
            contentLine2: string;
            contentLine3: string;
            close: string;
        };
        miniLogin: {
            userGreeting: string;
            signInRegister: string;
        };
        myAccountV2User: {
            signOut: string;
        };
    };
};

declare const es: {
    userAccount: {
        loginForm: {
            forgotPassword: string;
            signIn: string;
            register: string;
            dontHaveAccount: string;
            guestCheckout: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            wrongEmailFormat: string;
        };
        verificationTokenForm: {
            createVerificationToken: string;
            needInputCredentials: string;
            sendRateLime: string;
            resend: string;
            verificationCode: {
                label: string;
                placeholder: string;
            };
            noReceiveCode: string;
            verify: string;
            registerVerify: string;
            back: string;
            tokenInputHint: string;
        };
        verificationTokenDialog: {
            title: string;
            noReceiveCode: string;
            contentLine1: string;
            contentLine2: string;
            contentLine3: string;
            close: string;
        };
        miniLogin: {
            userGreeting: string;
            signInRegister: string;
        };
        myAccountV2User: {
            signOut: string;
        };
    };
};

declare const es_CO: {
    userAccount: {
        loginForm: {
            forgotPassword: string;
            signIn: string;
            register: string;
            dontHaveAccount: string;
            guestCheckout: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            wrongEmailFormat: string;
        };
        verificationTokenForm: {
            createVerificationToken: string;
            needInputCredentials: string;
            sendRateLime: string;
            resend: string;
            verificationCode: {
                label: string;
                placeholder: string;
            };
            noReceiveCode: string;
            verify: string;
            registerVerify: string;
            back: string;
            tokenInputHint: string;
        };
        verificationTokenDialog: {
            title: string;
            noReceiveCode: string;
            contentLine1: string;
            contentLine2: string;
            contentLine3: string;
            close: string;
        };
        miniLogin: {
            userGreeting: string;
            signInRegister: string;
        };
        myAccountV2User: {
            signOut: string;
        };
    };
};

declare const fr: {
    userAccount: {
        loginForm: {
            forgotPassword: string;
            signIn: string;
            register: string;
            dontHaveAccount: string;
            guestCheckout: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            wrongEmailFormat: string;
        };
        verificationTokenForm: {
            createVerificationToken: string;
            needInputCredentials: string;
            sendRateLime: string;
            resend: string;
            verificationCode: {
                label: string;
                placeholder: string;
            };
            noReceiveCode: string;
            verify: string;
            registerVerify: string;
            back: string;
            tokenInputHint: string;
        };
        verificationTokenDialog: {
            title: string;
            noReceiveCode: string;
            contentLine1: string;
            contentLine2: string;
            contentLine3: string;
            close: string;
        };
        miniLogin: {
            userGreeting: string;
            signInRegister: string;
        };
        myAccountV2User: {
            signOut: string;
        };
    };
};

declare const hi: {
    userAccount: {
        loginForm: {
            forgotPassword: string;
            signIn: string;
            register: string;
            dontHaveAccount: string;
            guestCheckout: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            wrongEmailFormat: string;
        };
        verificationTokenForm: {
            createVerificationToken: string;
            needInputCredentials: string;
            sendRateLime: string;
            resend: string;
            verificationCode: {
                label: string;
                placeholder: string;
            };
            noReceiveCode: string;
            verify: string;
            registerVerify: string;
            back: string;
            tokenInputHint: string;
        };
        verificationTokenDialog: {
            title: string;
            noReceiveCode: string;
            contentLine1: string;
            contentLine2: string;
            contentLine3: string;
            close: string;
        };
        miniLogin: {
            userGreeting: string;
            signInRegister: string;
        };
        myAccountV2User: {
            signOut: string;
        };
    };
};

declare const hu: {
    userAccount: {
        loginForm: {
            forgotPassword: string;
            signIn: string;
            register: string;
            dontHaveAccount: string;
            guestCheckout: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            wrongEmailFormat: string;
        };
        verificationTokenForm: {
            createVerificationToken: string;
            needInputCredentials: string;
            sendRateLime: string;
            resend: string;
            verificationCode: {
                label: string;
                placeholder: string;
            };
            noReceiveCode: string;
            verify: string;
            registerVerify: string;
            back: string;
            tokenInputHint: string;
        };
        verificationTokenDialog: {
            title: string;
            noReceiveCode: string;
            contentLine1: string;
            contentLine2: string;
            contentLine3: string;
            close: string;
        };
        miniLogin: {
            userGreeting: string;
            signInRegister: string;
        };
        myAccountV2User: {
            signOut: string;
        };
    };
};

declare const id: {
    userAccount: {
        loginForm: {
            forgotPassword: string;
            signIn: string;
            register: string;
            dontHaveAccount: string;
            guestCheckout: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            wrongEmailFormat: string;
        };
        verificationTokenForm: {
            createVerificationToken: string;
            needInputCredentials: string;
            sendRateLime: string;
            resend: string;
            verificationCode: {
                label: string;
                placeholder: string;
            };
            noReceiveCode: string;
            verify: string;
            registerVerify: string;
            back: string;
            tokenInputHint: string;
        };
        verificationTokenDialog: {
            title: string;
            noReceiveCode: string;
            contentLine1: string;
            contentLine2: string;
            contentLine3: string;
            close: string;
        };
        miniLogin: {
            userGreeting: string;
            signInRegister: string;
        };
        myAccountV2User: {
            signOut: string;
        };
    };
};

declare const it: {
    userAccount: {
        loginForm: {
            forgotPassword: string;
            signIn: string;
            register: string;
            dontHaveAccount: string;
            guestCheckout: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            wrongEmailFormat: string;
        };
        verificationTokenForm: {
            createVerificationToken: string;
            needInputCredentials: string;
            sendRateLime: string;
            resend: string;
            verificationCode: {
                label: string;
                placeholder: string;
            };
            noReceiveCode: string;
            verify: string;
            registerVerify: string;
            back: string;
            tokenInputHint: string;
        };
        verificationTokenDialog: {
            title: string;
            noReceiveCode: string;
            contentLine1: string;
            contentLine2: string;
            contentLine3: string;
            close: string;
        };
        miniLogin: {
            userGreeting: string;
            signInRegister: string;
        };
        myAccountV2User: {
            signOut: string;
        };
    };
};

declare const ja: {
    userAccount: {
        loginForm: {
            forgotPassword: string;
            signIn: string;
            register: string;
            dontHaveAccount: string;
            guestCheckout: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            wrongEmailFormat: string;
        };
        verificationTokenForm: {
            createVerificationToken: string;
            needInputCredentials: string;
            sendRateLime: string;
            resend: string;
            verificationCode: {
                label: string;
                placeholder: string;
            };
            noReceiveCode: string;
            verify: string;
            registerVerify: string;
            back: string;
            tokenInputHint: string;
        };
        verificationTokenDialog: {
            title: string;
            noReceiveCode: string;
            contentLine1: string;
            contentLine2: string;
            contentLine3: string;
            close: string;
        };
        miniLogin: {
            userGreeting: string;
            signInRegister: string;
        };
        myAccountV2User: {
            signOut: string;
        };
    };
};

declare const ko: {
    userAccount: {
        loginForm: {
            forgotPassword: string;
            signIn: string;
            register: string;
            dontHaveAccount: string;
            guestCheckout: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            wrongEmailFormat: string;
        };
        verificationTokenForm: {
            createVerificationToken: string;
            needInputCredentials: string;
            sendRateLime: string;
            resend: string;
            verificationCode: {
                label: string;
                placeholder: string;
            };
            noReceiveCode: string;
            verify: string;
            registerVerify: string;
            back: string;
            tokenInputHint: string;
        };
        verificationTokenDialog: {
            title: string;
            noReceiveCode: string;
            contentLine1: string;
            contentLine2: string;
            contentLine3: string;
            close: string;
        };
        miniLogin: {
            userGreeting: string;
            signInRegister: string;
        };
        myAccountV2User: {
            signOut: string;
        };
    };
};

declare const pl: {
    userAccount: {
        loginForm: {
            forgotPassword: string;
            signIn: string;
            register: string;
            dontHaveAccount: string;
            guestCheckout: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            wrongEmailFormat: string;
        };
        verificationTokenForm: {
            createVerificationToken: string;
            needInputCredentials: string;
            sendRateLime: string;
            resend: string;
            verificationCode: {
                label: string;
                placeholder: string;
            };
            noReceiveCode: string;
            verify: string;
            registerVerify: string;
            back: string;
            tokenInputHint: string;
        };
        verificationTokenDialog: {
            title: string;
            noReceiveCode: string;
            contentLine1: string;
            contentLine2: string;
            contentLine3: string;
            close: string;
        };
        miniLogin: {
            userGreeting: string;
            signInRegister: string;
        };
        myAccountV2User: {
            signOut: string;
        };
    };
};

declare const pt: {
    userAccount: {
        loginForm: {
            forgotPassword: string;
            signIn: string;
            register: string;
            dontHaveAccount: string;
            guestCheckout: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            wrongEmailFormat: string;
        };
        verificationTokenForm: {
            createVerificationToken: string;
            needInputCredentials: string;
            sendRateLime: string;
            resend: string;
            verificationCode: {
                label: string;
                placeholder: string;
            };
            noReceiveCode: string;
            verify: string;
            registerVerify: string;
            back: string;
            tokenInputHint: string;
        };
        verificationTokenDialog: {
            title: string;
            noReceiveCode: string;
            contentLine1: string;
            contentLine2: string;
            contentLine3: string;
            close: string;
        };
        miniLogin: {
            userGreeting: string;
            signInRegister: string;
        };
        myAccountV2User: {
            signOut: string;
        };
    };
};

declare const ru: {
    userAccount: {
        loginForm: {
            forgotPassword: string;
            signIn: string;
            register: string;
            dontHaveAccount: string;
            guestCheckout: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            wrongEmailFormat: string;
        };
        verificationTokenForm: {
            createVerificationToken: string;
            needInputCredentials: string;
            sendRateLime: string;
            resend: string;
            verificationCode: {
                label: string;
                placeholder: string;
            };
            noReceiveCode: string;
            verify: string;
            registerVerify: string;
            back: string;
            tokenInputHint: string;
        };
        verificationTokenDialog: {
            title: string;
            noReceiveCode: string;
            contentLine1: string;
            contentLine2: string;
            contentLine3: string;
            close: string;
        };
        miniLogin: {
            userGreeting: string;
            signInRegister: string;
        };
        myAccountV2User: {
            signOut: string;
        };
    };
};

declare const zh: {
    userAccount: {
        loginForm: {
            forgotPassword: string;
            signIn: string;
            register: string;
            dontHaveAccount: string;
            guestCheckout: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            wrongEmailFormat: string;
        };
        verificationTokenForm: {
            createVerificationToken: string;
            needInputCredentials: string;
            sendRateLime: string;
            resend: string;
            verificationCode: {
                label: string;
                placeholder: string;
            };
            noReceiveCode: string;
            verify: string;
            registerVerify: string;
            back: string;
            tokenInputHint: string;
        };
        verificationTokenDialog: {
            title: string;
            noReceiveCode: string;
            contentLine1: string;
            contentLine2: string;
            contentLine3: string;
            close: string;
        };
        miniLogin: {
            userGreeting: string;
            signInRegister: string;
        };
        myAccountV2User: {
            signOut: string;
        };
    };
};

declare const zh_TW: {
    userAccount: {
        loginForm: {
            forgotPassword: string;
            signIn: string;
            register: string;
            dontHaveAccount: string;
            guestCheckout: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            wrongEmailFormat: string;
        };
        verificationTokenForm: {
            createVerificationToken: string;
            needInputCredentials: string;
            sendRateLime: string;
            resend: string;
            verificationCode: {
                label: string;
                placeholder: string;
            };
            noReceiveCode: string;
            verify: string;
            registerVerify: string;
            back: string;
            tokenInputHint: string;
        };
        verificationTokenDialog: {
            title: string;
            noReceiveCode: string;
            contentLine1: string;
            contentLine2: string;
            contentLine3: string;
            close: string;
        };
        miniLogin: {
            userGreeting: string;
            signInRegister: string;
        };
        myAccountV2User: {
            signOut: string;
        };
    };
};

declare const userAccountTranslationChunksConfig: TranslationChunksConfig;

export { userAccountTranslationChunksConfig, cs as userAccountTranslationsCs, de as userAccountTranslationsDe, en as userAccountTranslationsEn, es as userAccountTranslationsEs, es_CO as userAccountTranslationsEs_CO, fr as userAccountTranslationsFr, hi as userAccountTranslationsHi, hu as userAccountTranslationsHu, id as userAccountTranslationsId, it as userAccountTranslationsIt, ja as userAccountTranslationsJa, ko as userAccountTranslationsKo, pl as userAccountTranslationsPl, pt as userAccountTranslationsPt, ru as userAccountTranslationsRu, zh as userAccountTranslationsZh, zh_TW as userAccountTranslationsZh_TW };
