import * as i0 from '@angular/core';
import * as i1 from '@spartacus/user/profile/core';
import * as i2 from '@spartacus/user/profile/occ';
import * as i3 from '@spartacus/user/profile/components';
import * as i4 from '@spartacus/storefront';

declare class UserProfileModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserProfileModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserProfileModule, never, [typeof i1.UserProfileCoreModule, typeof i2.UserProfileOccModule, typeof i3.UserProfileComponentsModule, typeof i4.CaptchaModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserProfileModule>;
}

export { UserProfileModule };
