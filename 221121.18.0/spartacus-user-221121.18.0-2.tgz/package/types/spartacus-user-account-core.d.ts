import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import { Converter, UserIdService, QueryService, Query, CommandService, Command } from '@spartacus/core';
import { VerificationTokenCreation, User, VerificationToken, UserAccountFacade, VerificationTokenFacade } from '@spartacus/user/account/root';
import { Observable } from 'rxjs';

declare const USER_ACCOUNT_NORMALIZER: InjectionToken<Converter<any, User>>;
declare const USER_ACCOUNT_SERIALIZER: InjectionToken<Converter<User, any>>;
declare const VERIFICATION_TOKEN_NORMALIZER: InjectionToken<Converter<any, VerificationToken>>;
declare const LOGIN_FORM_SERIALIZER: InjectionToken<Converter<VerificationTokenCreation, any>>;

declare abstract class UserAccountAdapter {
    abstract load(userId: string): Observable<User>;
    abstract createVerificationToken(verificationTokenCreation: VerificationTokenCreation): Observable<VerificationToken>;
}

declare class UserAccountConnector {
    protected adapter: UserAccountAdapter;
    constructor(adapter: UserAccountAdapter);
    get(userId: string): Observable<User>;
    createVerificationToken(verificationTokenCreation: VerificationTokenCreation): Observable<VerificationToken>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAccountConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserAccountConnector>;
}

declare class UserAccountService implements UserAccountFacade {
    protected userAccountConnector: UserAccountConnector;
    protected userIdService: UserIdService;
    protected query: QueryService;
    protected userQuery: Query<User>;
    constructor(userAccountConnector: UserAccountConnector, userIdService: UserIdService, query: QueryService);
    /**
     * Returns the user according the userId
     * no use query for userId can change every time
     */
    getById(userId: string): Observable<User | undefined>;
    /**
     * Returns the current user.
     */
    get(): Observable<User | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAccountService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserAccountService>;
}

declare class VerificationTokenService implements VerificationTokenFacade {
    protected connector: UserAccountConnector;
    protected command: CommandService;
    protected createVerificationTokenCommand: Command<{
        verificationTokenCreation: VerificationTokenCreation;
    }, VerificationToken>;
    /**
     * create verification token
     */
    createVerificationToken(verificationTokenCreation: VerificationTokenCreation): Observable<VerificationToken>;
    static ɵfac: i0.ɵɵFactoryDeclaration<VerificationTokenService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VerificationTokenService>;
}

declare class UserAccountCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAccountCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserAccountCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserAccountCoreModule>;
}

export { LOGIN_FORM_SERIALIZER, USER_ACCOUNT_NORMALIZER, USER_ACCOUNT_SERIALIZER, UserAccountAdapter, UserAccountConnector, UserAccountCoreModule, UserAccountService, VERIFICATION_TOKEN_NORMALIZER, VerificationTokenService };
