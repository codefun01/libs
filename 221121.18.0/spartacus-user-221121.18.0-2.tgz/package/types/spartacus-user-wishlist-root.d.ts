import { Product } from '@spartacus/core';

interface WishlistEntry {
    id: string;
    productCode?: string;
    addedAt?: string;
    product?: Product;
}
interface Wishlist {
    id?: string;
    entries?: WishlistEntry[];
}

export type { Wishlist, WishlistEntry };
