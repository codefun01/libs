import { Observable } from 'rxjs';
import { Wishlist, WishlistEntry } from '@spartacus/user/wishlist/root';
import * as i0 from '@angular/core';

declare abstract class UserWishlistAdapter {
    abstract getWishlist(userId: string): Observable<Wishlist>;
    abstract addEntry(userId: string, wishlistId: string, productCode: string): Observable<WishlistEntry>;
    abstract removeEntry(userId: string, wishlistId: string, entryId: string): Observable<void>;
}

declare class UserWishlistConnector {
    protected adapter: UserWishlistAdapter;
    getWishlist(userId: string): Observable<Wishlist>;
    addEntry(userId: string, wishlistId: string, productCode: string): Observable<WishlistEntry>;
    removeEntry(userId: string, wishlistId: string, entryId: string): Observable<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserWishlistConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserWishlistConnector>;
}

export { UserWishlistAdapter, UserWishlistConnector };
