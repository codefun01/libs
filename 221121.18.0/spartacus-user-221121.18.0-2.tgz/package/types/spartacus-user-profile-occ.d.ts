import { OccConfig, OccEndpoint, OccEndpointsService, ConverterService, LoggerService } from '@spartacus/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import * as i0 from '@angular/core';
import { Injector } from '@angular/core';
import { CaptchaApiConfig } from '@spartacus/storefront';
import { User } from '@spartacus/user/account/root';
import { UserProfileAdapter } from '@spartacus/user/profile/core';
import { UserSignUp, Title } from '@spartacus/user/profile/root';
import { Observable } from 'rxjs';

declare const defaultOccUserProfileConfig: OccConfig;

interface UserProfileOccEndpoints {
    /**
     * Titles used for user's personal info.
     */
    titles?: string | OccEndpoint;
    /**
     * Register a new user.
     */
    userRegister?: string | OccEndpoint;
    /**
     * Request an email to reset the password
     */
    userForgotPassword?: string | OccEndpoint;
    /**
     * Request an email to reset the password
     */
    userRestoreToken?: string | OccEndpoint;
    /**
     * Reset the password once the email is received.
     */
    userResetPassword?: string | OccEndpoint;
    /**
     * Update the user id with which the user authenticates.
     */
    userUpdateLoginId?: string | OccEndpoint;
    /**
     * Update the user's password
     */
    userUpdatePassword?: string | OccEndpoint;
    /**
     * Update the user's profile
     */
    userUpdateProfile?: string | OccEndpoint;
    /**
     * Close user account
     */
    userCloseAccount?: string | OccEndpoint;
}
declare module '@spartacus/core' {
    interface OccEndpoints extends UserProfileOccEndpoints {
    }
}

declare class OccUserProfileAdapter implements UserProfileAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    protected captchaConfig: CaptchaApiConfig | null;
    protected injector: Injector | null;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    update(userId: string, user: User): Observable<unknown>;
    register(user: UserSignUp): Observable<User>;
    registerGuest(guid: string, password: string): Observable<User>;
    requestForgotPasswordEmail(userEmailAddress: string): Observable<unknown>;
    resetPassword(token: string, newPassword: string): Observable<unknown>;
    updateEmail(userId: string, currentPassword: string, newUserId: string): Observable<unknown>;
    updatePassword(userId: string, oldPassword: string, newPassword: string): Observable<unknown>;
    close(userId: string): Observable<unknown>;
    loadTitles(): Observable<Title[]>;
    protected appendCaptchaToken(currentHeaders: HttpHeaders): HttpHeaders;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccUserProfileAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccUserProfileAdapter>;
}

declare class UserProfileOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserProfileOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserProfileOccModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserProfileOccModule>;
}

export { OccUserProfileAdapter, UserProfileOccModule, defaultOccUserProfileConfig };
export type { UserProfileOccEndpoints };
