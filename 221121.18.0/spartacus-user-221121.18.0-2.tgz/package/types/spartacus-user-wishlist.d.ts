import { Observable } from 'rxjs';
import { Wishlist as Wishlist$1, WishlistEntry as WishlistEntry$1 } from '@spartacus/user/wishlist/root';
import * as i0 from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { OccEndpointsService, LoggerService, OccConfig, Product } from '@spartacus/core';
import { UserWishlistAdapter as UserWishlistAdapter$1 } from '@spartacus/user/wishlist/core';

declare abstract class UserWishlistAdapter {
    abstract getWishlist(userId: string): Observable<Wishlist$1>;
    abstract addEntry(userId: string, wishlistId: string, productCode: string): Observable<WishlistEntry$1>;
    abstract removeEntry(userId: string, wishlistId: string, entryId: string): Observable<void>;
}

declare class UserWishlistConnector {
    protected adapter: UserWishlistAdapter;
    getWishlist(userId: string): Observable<Wishlist$1>;
    addEntry(userId: string, wishlistId: string, productCode: string): Observable<WishlistEntry$1>;
    removeEntry(userId: string, wishlistId: string, entryId: string): Observable<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserWishlistConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserWishlistConnector>;
}

declare class OccUserWishlistAdapter implements UserWishlistAdapter$1 {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected logger: LoggerService;
    getWishlist(userId: string): Observable<Wishlist$1>;
    addEntry(userId: string, wishlistId: string, productCode: string): Observable<WishlistEntry$1>;
    removeEntry(userId: string, wishlistId: string, entryId: string): Observable<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccUserWishlistAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccUserWishlistAdapter>;
}

declare const defaultOccUserWishlistConfig: OccConfig;

interface WishlistEntry {
    id: string;
    productCode?: string;
    addedAt?: string;
    product?: Product;
}
interface Wishlist {
    id?: string;
    entries?: WishlistEntry[];
}

export { OccUserWishlistAdapter, UserWishlistAdapter, UserWishlistConnector, defaultOccUserWishlistConfig };
export type { Wishlist, WishlistEntry };
