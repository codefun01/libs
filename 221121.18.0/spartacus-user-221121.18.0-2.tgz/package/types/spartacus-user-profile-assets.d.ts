import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    address: {
        addressForm: {
            title: string;
            titleOptional: string;
            defaultTitle: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            address1: string;
            address2: string;
            country: string;
            city: {
                label: string;
                placeholder: string;
            };
            state: string;
            zipCode: {
                label: string;
                placeholder: string;
            };
            phoneNumber: {
                label: string;
                placeholder: string;
            };
            cellphone: {
                label: string;
                placeholder: string;
            };
            saveAsDefault: string;
            chooseAddress: string;
            streetAddress: string;
            aptSuite: string;
            selectOne: string;
            setAsDefault: string;
            titleRequired: string;
            userAddressAddSuccess: string;
            userAddressUpdateSuccess: string;
            userAddressDeleteSuccess: string;
            invalidAddress: string;
        };
        addressBook: {
            addNewDeliveryAddress: string;
            editDeliveryAddress: string;
            areYouSureToDeleteAddress: string;
            addNewAddress: string;
            addAddress: string;
            updateAddress: string;
            backToAddressList: string;
            defaultDeliveryAddress: string;
            additionalDeliveryAddress: string;
        };
        addressCard: {
            default: string;
            selected: string;
            selectedAddress: string;
            setAsDefault: string;
            shipTo: string;
            billTo: string;
            phoneNumber: string;
            mobileNumber: string;
        };
        addressSuggestion: {
            verifyYourAddress: string;
            ensureAccuracySuggestChange: string;
            chooseAddressToUse: string;
            suggestedAddress: string;
            enteredAddress: string;
            editAddress: string;
            saveAddress: string;
        };
        addressMessages: {
            setAsDefaultSuccessfully: string;
        };
    };
    myAccountV2Email: {
        myAccountV2Email: {
            myEmailAddress: string;
            email: string;
            emailAddress: string;
            newEmailAddress: string;
            confirmNewEmailAddress: string;
            emailPlaceHolder: string;
            passwordPlaceHolder: string;
            password: string;
            reloginIndicator: string;
        };
    };
    myAccountV2Password: {
        myAccountV2PasswordForm: {
            oldPassword: {
                label: string;
                placeholder: string;
            };
            oldPasswordIsRequired: string;
            newPassword: {
                label: string;
                placeholder: string;
            };
            passwordMinRequirements: string;
            confirmPassword: {
                label: string;
                placeholder: string;
            };
            reloginIndicator: string;
            bothPasswordMustMatch: string;
            passwordUpdateSuccess: string;
            accessDeniedError: string;
            newPasswordTitle: string;
        };
    };
    myAccountV2UserProfile: {
        myAccountV2UserProfile: {
            myEmailAddress: string;
            myInformation: string;
            name: string;
            customerId: string;
            title: string;
            firstName: string;
            lastName: string;
        };
    };
    userProfile: {
        updateEmailForm: {
            newEmailAddress: {
                label: string;
                placeholder: string;
            };
            confirmNewEmailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            bothEmailMustMatch: string;
            password: {
                label: string;
                placeholder: string;
            };
            pleaseInputPassword: string;
            emailUpdateSuccess: string;
        };
        register: {
            confirmPassword: {
                action: string;
                label: string;
                placeholder: string;
            };
            managementInMyAccount: string;
            termsAndConditions: string;
            signIn: string;
            register: string;
            furtherRegistration: string;
            confirmNewPassword: string;
            resetPassword: string;
            createAccount: string;
            title: string;
            titleOptional: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            newPassword: string;
            emailMarketing: string;
            confirmThatRead: string;
            selectTitle: string;
            passwordMinRequirements: string;
            passwordStrengthRequirements: string;
            bothPasswordMustMatch: string;
            titleRequired: string;
            postRegisterMessage: string;
            postRegisterSuccessMessage: string;
            rateLimitForRegistrationMessage: string;
            verificationTokenForm: {
                createVerificationToken: string;
                sendRateLime: string;
                resend: string;
                verificationCode: {
                    label: string;
                    placeholder: string;
                };
                back: string;
            };
        };
        forgottenPassword: {
            resetPassword: string;
            enterEmailAddressAssociatedWithYourAccount: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            passwordResetEmailSent: string;
            passwordResetSuccess: string;
        };
    };
};

declare const de: {
    address: {
        addressForm: {
            title: string;
            titleOptional: string;
            defaultTitle: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            address1: string;
            address2: string;
            country: string;
            city: {
                label: string;
                placeholder: string;
            };
            state: string;
            zipCode: {
                label: string;
                placeholder: string;
            };
            phoneNumber: {
                label: string;
                placeholder: string;
            };
            cellphone: {
                label: string;
                placeholder: string;
            };
            saveAsDefault: string;
            chooseAddress: string;
            streetAddress: string;
            aptSuite: string;
            selectOne: string;
            setAsDefault: string;
            titleRequired: string;
            userAddressAddSuccess: string;
            userAddressUpdateSuccess: string;
            userAddressDeleteSuccess: string;
            invalidAddress: string;
        };
        addressBook: {
            addNewDeliveryAddress: string;
            editDeliveryAddress: string;
            areYouSureToDeleteAddress: string;
            addNewAddress: string;
            addAddress: string;
            updateAddress: string;
            backToAddressList: string;
            defaultDeliveryAddress: string;
            additionalDeliveryAddress: string;
        };
        addressCard: {
            default: string;
            selected: string;
            selectedAddress: string;
            setAsDefault: string;
            shipTo: string;
            billTo: string;
            phoneNumber: string;
            mobileNumber: string;
        };
        addressSuggestion: {
            verifyYourAddress: string;
            ensureAccuracySuggestChange: string;
            chooseAddressToUse: string;
            suggestedAddress: string;
            enteredAddress: string;
            editAddress: string;
            saveAddress: string;
        };
        addressMessages: {
            setAsDefaultSuccessfully: string;
        };
    };
    myAccountV2Email: {
        myAccountV2Email: {
            myEmailAddress: string;
            email: string;
            emailAddress: string;
            newEmailAddress: string;
            confirmNewEmailAddress: string;
            emailPlaceHolder: string;
            passwordPlaceHolder: string;
            password: string;
            reloginIndicator: string;
        };
    };
    myAccountV2Password: {
        myAccountV2PasswordForm: {
            oldPassword: {
                label: string;
                placeholder: string;
            };
            oldPasswordIsRequired: string;
            newPassword: {
                label: string;
                placeholder: string;
            };
            passwordMinRequirements: string;
            confirmPassword: {
                label: string;
                placeholder: string;
            };
            reloginIndicator: string;
            bothPasswordMustMatch: string;
            passwordUpdateSuccess: string;
            accessDeniedError: string;
            newPasswordTitle: string;
        };
    };
    myAccountV2UserProfile: {
        myAccountV2UserProfile: {
            myEmailAddress: string;
            myInformation: string;
            name: string;
            customerId: string;
            title: string;
            firstName: string;
            lastName: string;
        };
    };
    userProfile: {
        updateEmailForm: {
            newEmailAddress: {
                label: string;
                placeholder: string;
            };
            confirmNewEmailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            bothEmailMustMatch: string;
            password: {
                label: string;
                placeholder: string;
            };
            pleaseInputPassword: string;
            emailUpdateSuccess: string;
        };
        register: {
            confirmPassword: {
                action: string;
                label: string;
                placeholder: string;
            };
            managementInMyAccount: string;
            termsAndConditions: string;
            signIn: string;
            register: string;
            furtherRegistration: string;
            confirmNewPassword: string;
            resetPassword: string;
            createAccount: string;
            title: string;
            titleOptional: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            newPassword: string;
            emailMarketing: string;
            confirmThatRead: string;
            selectTitle: string;
            passwordMinRequirements: string;
            passwordStrengthRequirements: string;
            bothPasswordMustMatch: string;
            titleRequired: string;
            postRegisterMessage: string;
            postRegisterSuccessMessage: string;
            rateLimitForRegistrationMessage: string;
            verificationTokenForm: {
                createVerificationToken: string;
                sendRateLime: string;
                resend: string;
                verificationCode: {
                    label: string;
                    placeholder: string;
                };
                back: string;
            };
        };
        forgottenPassword: {
            resetPassword: string;
            enterEmailAddressAssociatedWithYourAccount: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            passwordResetEmailSent: string;
            passwordResetSuccess: string;
        };
    };
};

declare const en: {
    address: {
        addressForm: {
            title: string;
            titleOptional: string;
            defaultTitle: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            address1: string;
            address2: string;
            country: string;
            city: {
                label: string;
                placeholder: string;
            };
            state: string;
            province: string;
            district: string;
            zipCode: {
                label: string;
                placeholder: string;
            };
            phoneNumber: {
                label: string;
                placeholder: string;
            };
            cellphone: {
                label: string;
                placeholder: string;
                requiredLabel: string;
            };
            saveAsDefault: string;
            chooseAddress: string;
            streetAddress: string;
            aptSuite: string;
            selectOne: string;
            selectProvinceFirst: string;
            selectCityFirst: string;
            setAsDefault: string;
            titleRequired: string;
            userAddressAddSuccess: string;
            userAddressUpdateSuccess: string;
            userAddressDeleteSuccess: string;
            invalidAddress: string;
        };
        addressBook: {
            addNewDeliveryAddress: string;
            editDeliveryAddress: string;
            areYouSureToDeleteAddress: string;
            addNewAddress: string;
            addAddress: string;
            updateAddress: string;
            backToAddressList: string;
            defaultDeliveryAddress: string;
            additionalDeliveryAddress: string;
        };
        addressCard: {
            default: string;
            selected: string;
            selectedAddress: string;
            setAsDefault: string;
            shipTo: string;
            billTo: string;
            phoneNumber: string;
            mobileNumber: string;
        };
        addressSuggestion: {
            verifyYourAddress: string;
            ensureAccuracySuggestChange: string;
            chooseAddressToUse: string;
            suggestedAddress: string;
            enteredAddress: string;
            editAddress: string;
            saveAddress: string;
        };
        addressMessages: {
            setAsDefaultSuccessfully: string;
        };
    };
    myAccountV2Email: {
        myAccountV2Email: {
            myEmailAddress: string;
            email: string;
            emailAddress: string;
            newEmailAddress: string;
            confirmNewEmailAddress: string;
            emailPlaceHolder: string;
            passwordPlaceHolder: string;
            password: string;
            reloginIndicator: string;
        };
    };
    myAccountV2Password: {
        myAccountV2PasswordForm: {
            oldPassword: {
                label: string;
                placeholder: string;
            };
            oldPasswordIsRequired: string;
            newPassword: {
                label: string;
                placeholder: string;
            };
            passwordMinRequirements: string;
            confirmPassword: {
                label: string;
                placeholder: string;
            };
            reloginIndicator: string;
            bothPasswordMustMatch: string;
            passwordUpdateSuccess: string;
            accessDeniedError: string;
            newPasswordTitle: string;
        };
    };
    myAccountV2UserProfile: {
        myAccountV2UserProfile: {
            myEmailAddress: string;
            myInformation: string;
            name: string;
            customerId: string;
            title: string;
            firstName: string;
            lastName: string;
        };
    };
    userProfile: {
        updateEmailForm: {
            newEmailAddress: {
                label: string;
                placeholder: string;
            };
            confirmNewEmailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            bothEmailMustMatch: string;
            password: {
                label: string;
                placeholder: string;
            };
            pleaseInputPassword: string;
            emailUpdateSuccess: string;
        };
        register: {
            confirmPassword: {
                action: string;
                label: string;
                placeholder: string;
            };
            managementInMyAccount: string;
            termsAndConditions: string;
            signIn: string;
            register: string;
            furtherRegistration: string;
            confirmNewPassword: string;
            resetPassword: string;
            createAccount: string;
            title: string;
            titleOptional: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            newPassword: string;
            emailMarketing: string;
            confirmThatRead: string;
            selectTitle: string;
            passwordMinRequirements: string;
            passwordStrengthRequirements: string;
            bothPasswordMustMatch: string;
            titleRequired: string;
            postRegisterMessage: string;
            postRegisterSuccessMessage: string;
            rateLimitForRegistrationMessage: string;
            verificationTokenForm: {
                createVerificationToken: string;
                sendRateLime: string;
                resend: string;
                verificationCode: {
                    label: string;
                    placeholder: string;
                };
                back: string;
            };
        };
        forgottenPassword: {
            resetPassword: string;
            enterEmailAddressAssociatedWithYourAccount: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            passwordResetEmailSent: string;
            passwordResetSuccess: string;
        };
    };
};

declare const es: {
    address: {
        addressForm: {
            title: string;
            titleOptional: string;
            defaultTitle: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            address1: string;
            address2: string;
            country: string;
            city: {
                label: string;
                placeholder: string;
            };
            state: string;
            zipCode: {
                label: string;
                placeholder: string;
            };
            phoneNumber: {
                label: string;
                placeholder: string;
            };
            cellphone: {
                label: string;
                placeholder: string;
            };
            saveAsDefault: string;
            chooseAddress: string;
            streetAddress: string;
            aptSuite: string;
            selectOne: string;
            setAsDefault: string;
            titleRequired: string;
            userAddressAddSuccess: string;
            userAddressUpdateSuccess: string;
            userAddressDeleteSuccess: string;
            invalidAddress: string;
        };
        addressBook: {
            addNewDeliveryAddress: string;
            editDeliveryAddress: string;
            areYouSureToDeleteAddress: string;
            addNewAddress: string;
            addAddress: string;
            updateAddress: string;
            backToAddressList: string;
            defaultDeliveryAddress: string;
            additionalDeliveryAddress: string;
        };
        addressCard: {
            default: string;
            selected: string;
            selectedAddress: string;
            setAsDefault: string;
            shipTo: string;
            billTo: string;
            phoneNumber: string;
            mobileNumber: string;
        };
        addressSuggestion: {
            verifyYourAddress: string;
            ensureAccuracySuggestChange: string;
            chooseAddressToUse: string;
            suggestedAddress: string;
            enteredAddress: string;
            editAddress: string;
            saveAddress: string;
        };
        addressMessages: {
            setAsDefaultSuccessfully: string;
        };
    };
    myAccountV2Email: {
        myAccountV2Email: {
            myEmailAddress: string;
            email: string;
            emailAddress: string;
            newEmailAddress: string;
            confirmNewEmailAddress: string;
            emailPlaceHolder: string;
            passwordPlaceHolder: string;
            password: string;
            reloginIndicator: string;
        };
    };
    myAccountV2Password: {
        myAccountV2PasswordForm: {
            oldPassword: {
                label: string;
                placeholder: string;
            };
            oldPasswordIsRequired: string;
            newPassword: {
                label: string;
                placeholder: string;
            };
            passwordMinRequirements: string;
            confirmPassword: {
                label: string;
                placeholder: string;
            };
            reloginIndicator: string;
            bothPasswordMustMatch: string;
            passwordUpdateSuccess: string;
            accessDeniedError: string;
            newPasswordTitle: string;
        };
    };
    myAccountV2UserProfile: {
        myAccountV2UserProfile: {
            myEmailAddress: string;
            myInformation: string;
            name: string;
            customerId: string;
            title: string;
            firstName: string;
            lastName: string;
        };
    };
    userProfile: {
        updateEmailForm: {
            newEmailAddress: {
                label: string;
                placeholder: string;
            };
            confirmNewEmailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            bothEmailMustMatch: string;
            password: {
                label: string;
                placeholder: string;
            };
            pleaseInputPassword: string;
            emailUpdateSuccess: string;
        };
        register: {
            confirmPassword: {
                action: string;
                label: string;
                placeholder: string;
            };
            managementInMyAccount: string;
            termsAndConditions: string;
            signIn: string;
            register: string;
            furtherRegistration: string;
            confirmNewPassword: string;
            resetPassword: string;
            createAccount: string;
            title: string;
            titleOptional: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            newPassword: string;
            emailMarketing: string;
            confirmThatRead: string;
            selectTitle: string;
            passwordMinRequirements: string;
            passwordStrengthRequirements: string;
            bothPasswordMustMatch: string;
            titleRequired: string;
            postRegisterMessage: string;
            postRegisterSuccessMessage: string;
            rateLimitForRegistrationMessage: string;
            verificationTokenForm: {
                createVerificationToken: string;
                sendRateLime: string;
                resend: string;
                verificationCode: {
                    label: string;
                    placeholder: string;
                };
                back: string;
            };
        };
        forgottenPassword: {
            resetPassword: string;
            enterEmailAddressAssociatedWithYourAccount: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            passwordResetEmailSent: string;
            passwordResetSuccess: string;
        };
    };
};

declare const es_CO: {
    address: {
        addressForm: {
            title: string;
            titleOptional: string;
            defaultTitle: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            address1: string;
            address2: string;
            country: string;
            city: {
                label: string;
                placeholder: string;
            };
            state: string;
            zipCode: {
                label: string;
                placeholder: string;
            };
            phoneNumber: {
                label: string;
                placeholder: string;
            };
            cellphone: {
                label: string;
                placeholder: string;
            };
            saveAsDefault: string;
            chooseAddress: string;
            streetAddress: string;
            aptSuite: string;
            selectOne: string;
            setAsDefault: string;
            titleRequired: string;
            userAddressAddSuccess: string;
            userAddressUpdateSuccess: string;
            userAddressDeleteSuccess: string;
            invalidAddress: string;
        };
        addressBook: {
            addNewDeliveryAddress: string;
            editDeliveryAddress: string;
            areYouSureToDeleteAddress: string;
            addNewAddress: string;
            addAddress: string;
            updateAddress: string;
            backToAddressList: string;
            defaultDeliveryAddress: string;
            additionalDeliveryAddress: string;
        };
        addressCard: {
            default: string;
            selected: string;
            selectedAddress: string;
            setAsDefault: string;
            shipTo: string;
            billTo: string;
            phoneNumber: string;
            mobileNumber: string;
        };
        addressSuggestion: {
            verifyYourAddress: string;
            ensureAccuracySuggestChange: string;
            chooseAddressToUse: string;
            suggestedAddress: string;
            enteredAddress: string;
            editAddress: string;
            saveAddress: string;
        };
        addressMessages: {
            setAsDefaultSuccessfully: string;
        };
    };
    myAccountV2Email: {
        myAccountV2Email: {
            myEmailAddress: string;
            email: string;
            emailAddress: string;
            newEmailAddress: string;
            confirmNewEmailAddress: string;
            emailPlaceHolder: string;
            passwordPlaceHolder: string;
            password: string;
            reloginIndicator: string;
        };
    };
    myAccountV2Password: {
        myAccountV2PasswordForm: {
            oldPassword: {
                label: string;
                placeholder: string;
            };
            oldPasswordIsRequired: string;
            newPassword: {
                label: string;
                placeholder: string;
            };
            passwordMinRequirements: string;
            confirmPassword: {
                label: string;
                placeholder: string;
            };
            reloginIndicator: string;
            bothPasswordMustMatch: string;
            passwordUpdateSuccess: string;
            accessDeniedError: string;
            newPasswordTitle: string;
        };
    };
    myAccountV2UserProfile: {
        myAccountV2UserProfile: {
            myEmailAddress: string;
            myInformation: string;
            name: string;
            customerId: string;
            title: string;
            firstName: string;
            lastName: string;
        };
    };
    userProfile: {
        updateEmailForm: {
            newEmailAddress: {
                label: string;
                placeholder: string;
            };
            confirmNewEmailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            bothEmailMustMatch: string;
            password: {
                label: string;
                placeholder: string;
            };
            pleaseInputPassword: string;
            emailUpdateSuccess: string;
        };
        register: {
            confirmPassword: {
                action: string;
                label: string;
                placeholder: string;
            };
            managementInMyAccount: string;
            termsAndConditions: string;
            signIn: string;
            register: string;
            furtherRegistration: string;
            confirmNewPassword: string;
            resetPassword: string;
            createAccount: string;
            title: string;
            titleOptional: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            newPassword: string;
            emailMarketing: string;
            confirmThatRead: string;
            selectTitle: string;
            passwordMinRequirements: string;
            passwordStrengthRequirements: string;
            bothPasswordMustMatch: string;
            titleRequired: string;
            postRegisterMessage: string;
            postRegisterSuccessMessage: string;
            rateLimitForRegistrationMessage: string;
            verificationTokenForm: {
                createVerificationToken: string;
                sendRateLime: string;
                resend: string;
                verificationCode: {
                    label: string;
                    placeholder: string;
                };
                back: string;
            };
        };
        forgottenPassword: {
            resetPassword: string;
            enterEmailAddressAssociatedWithYourAccount: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            passwordResetEmailSent: string;
            passwordResetSuccess: string;
        };
    };
};

declare const fr: {
    address: {
        addressForm: {
            title: string;
            titleOptional: string;
            defaultTitle: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            address1: string;
            address2: string;
            country: string;
            city: {
                label: string;
                placeholder: string;
            };
            state: string;
            zipCode: {
                label: string;
                placeholder: string;
            };
            phoneNumber: {
                label: string;
                placeholder: string;
            };
            cellphone: {
                label: string;
                placeholder: string;
            };
            saveAsDefault: string;
            chooseAddress: string;
            streetAddress: string;
            aptSuite: string;
            selectOne: string;
            setAsDefault: string;
            titleRequired: string;
            userAddressAddSuccess: string;
            userAddressUpdateSuccess: string;
            userAddressDeleteSuccess: string;
            invalidAddress: string;
        };
        addressBook: {
            addNewDeliveryAddress: string;
            editDeliveryAddress: string;
            areYouSureToDeleteAddress: string;
            addNewAddress: string;
            addAddress: string;
            updateAddress: string;
            backToAddressList: string;
            defaultDeliveryAddress: string;
            additionalDeliveryAddress: string;
        };
        addressCard: {
            default: string;
            selected: string;
            selectedAddress: string;
            setAsDefault: string;
            shipTo: string;
            billTo: string;
            phoneNumber: string;
            mobileNumber: string;
        };
        addressSuggestion: {
            verifyYourAddress: string;
            ensureAccuracySuggestChange: string;
            chooseAddressToUse: string;
            suggestedAddress: string;
            enteredAddress: string;
            editAddress: string;
            saveAddress: string;
        };
        addressMessages: {
            setAsDefaultSuccessfully: string;
        };
    };
    myAccountV2Email: {
        myAccountV2Email: {
            myEmailAddress: string;
            email: string;
            emailAddress: string;
            newEmailAddress: string;
            confirmNewEmailAddress: string;
            emailPlaceHolder: string;
            passwordPlaceHolder: string;
            password: string;
            reloginIndicator: string;
        };
    };
    myAccountV2Password: {
        myAccountV2PasswordForm: {
            oldPassword: {
                label: string;
                placeholder: string;
            };
            oldPasswordIsRequired: string;
            newPassword: {
                label: string;
                placeholder: string;
            };
            passwordMinRequirements: string;
            confirmPassword: {
                label: string;
                placeholder: string;
            };
            reloginIndicator: string;
            bothPasswordMustMatch: string;
            passwordUpdateSuccess: string;
            accessDeniedError: string;
            newPasswordTitle: string;
        };
    };
    myAccountV2UserProfile: {
        myAccountV2UserProfile: {
            myEmailAddress: string;
            myInformation: string;
            name: string;
            customerId: string;
            title: string;
            firstName: string;
            lastName: string;
        };
    };
    userProfile: {
        updateEmailForm: {
            newEmailAddress: {
                label: string;
                placeholder: string;
            };
            confirmNewEmailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            bothEmailMustMatch: string;
            password: {
                label: string;
                placeholder: string;
            };
            pleaseInputPassword: string;
            emailUpdateSuccess: string;
        };
        register: {
            confirmPassword: {
                action: string;
                label: string;
                placeholder: string;
            };
            managementInMyAccount: string;
            termsAndConditions: string;
            signIn: string;
            register: string;
            furtherRegistration: string;
            confirmNewPassword: string;
            resetPassword: string;
            createAccount: string;
            title: string;
            titleOptional: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            newPassword: string;
            emailMarketing: string;
            confirmThatRead: string;
            selectTitle: string;
            passwordMinRequirements: string;
            passwordStrengthRequirements: string;
            bothPasswordMustMatch: string;
            titleRequired: string;
            postRegisterMessage: string;
            postRegisterSuccessMessage: string;
            rateLimitForRegistrationMessage: string;
            verificationTokenForm: {
                createVerificationToken: string;
                sendRateLime: string;
                resend: string;
                verificationCode: {
                    label: string;
                    placeholder: string;
                };
                back: string;
            };
        };
        forgottenPassword: {
            resetPassword: string;
            enterEmailAddressAssociatedWithYourAccount: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            passwordResetEmailSent: string;
            passwordResetSuccess: string;
        };
    };
};

declare const hi: {
    address: {
        addressForm: {
            title: string;
            titleOptional: string;
            defaultTitle: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            address1: string;
            address2: string;
            country: string;
            city: {
                label: string;
                placeholder: string;
            };
            state: string;
            zipCode: {
                label: string;
                placeholder: string;
            };
            phoneNumber: {
                label: string;
                placeholder: string;
            };
            cellphone: {
                label: string;
                placeholder: string;
            };
            saveAsDefault: string;
            chooseAddress: string;
            streetAddress: string;
            aptSuite: string;
            selectOne: string;
            setAsDefault: string;
            titleRequired: string;
            userAddressAddSuccess: string;
            userAddressUpdateSuccess: string;
            userAddressDeleteSuccess: string;
            invalidAddress: string;
        };
        addressBook: {
            addNewDeliveryAddress: string;
            editDeliveryAddress: string;
            areYouSureToDeleteAddress: string;
            addNewAddress: string;
            addAddress: string;
            updateAddress: string;
            backToAddressList: string;
            defaultDeliveryAddress: string;
            additionalDeliveryAddress: string;
        };
        addressCard: {
            default: string;
            selected: string;
            selectedAddress: string;
            setAsDefault: string;
            shipTo: string;
            billTo: string;
            phoneNumber: string;
            mobileNumber: string;
        };
        addressSuggestion: {
            verifyYourAddress: string;
            ensureAccuracySuggestChange: string;
            chooseAddressToUse: string;
            suggestedAddress: string;
            enteredAddress: string;
            editAddress: string;
            saveAddress: string;
        };
        addressMessages: {
            setAsDefaultSuccessfully: string;
        };
    };
    myAccountV2Email: {
        myAccountV2Email: {
            myEmailAddress: string;
            email: string;
            emailAddress: string;
            newEmailAddress: string;
            confirmNewEmailAddress: string;
            emailPlaceHolder: string;
            passwordPlaceHolder: string;
            password: string;
            reloginIndicator: string;
        };
    };
    myAccountV2Password: {
        myAccountV2PasswordForm: {
            oldPassword: {
                label: string;
                placeholder: string;
            };
            oldPasswordIsRequired: string;
            newPassword: {
                label: string;
                placeholder: string;
            };
            passwordMinRequirements: string;
            confirmPassword: {
                label: string;
                placeholder: string;
            };
            reloginIndicator: string;
            bothPasswordMustMatch: string;
            passwordUpdateSuccess: string;
            accessDeniedError: string;
            newPasswordTitle: string;
        };
    };
    myAccountV2UserProfile: {
        myAccountV2UserProfile: {
            myEmailAddress: string;
            myInformation: string;
            name: string;
            customerId: string;
            title: string;
            firstName: string;
            lastName: string;
        };
    };
    userProfile: {
        updateEmailForm: {
            newEmailAddress: {
                label: string;
                placeholder: string;
            };
            confirmNewEmailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            bothEmailMustMatch: string;
            password: {
                label: string;
                placeholder: string;
            };
            pleaseInputPassword: string;
            emailUpdateSuccess: string;
        };
        register: {
            confirmPassword: {
                action: string;
                label: string;
                placeholder: string;
            };
            managementInMyAccount: string;
            termsAndConditions: string;
            signIn: string;
            register: string;
            furtherRegistration: string;
            confirmNewPassword: string;
            resetPassword: string;
            createAccount: string;
            title: string;
            titleOptional: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            newPassword: string;
            emailMarketing: string;
            confirmThatRead: string;
            selectTitle: string;
            passwordMinRequirements: string;
            passwordStrengthRequirements: string;
            bothPasswordMustMatch: string;
            titleRequired: string;
            postRegisterMessage: string;
            postRegisterSuccessMessage: string;
            rateLimitForRegistrationMessage: string;
            verificationTokenForm: {
                createVerificationToken: string;
                sendRateLime: string;
                resend: string;
                verificationCode: {
                    label: string;
                    placeholder: string;
                };
                back: string;
            };
        };
        forgottenPassword: {
            resetPassword: string;
            enterEmailAddressAssociatedWithYourAccount: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            passwordResetEmailSent: string;
            passwordResetSuccess: string;
        };
    };
};

declare const hu: {
    address: {
        addressForm: {
            title: string;
            titleOptional: string;
            defaultTitle: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            address1: string;
            address2: string;
            country: string;
            city: {
                label: string;
                placeholder: string;
            };
            state: string;
            zipCode: {
                label: string;
                placeholder: string;
            };
            phoneNumber: {
                label: string;
                placeholder: string;
            };
            cellphone: {
                label: string;
                placeholder: string;
            };
            saveAsDefault: string;
            chooseAddress: string;
            streetAddress: string;
            aptSuite: string;
            selectOne: string;
            setAsDefault: string;
            titleRequired: string;
            userAddressAddSuccess: string;
            userAddressUpdateSuccess: string;
            userAddressDeleteSuccess: string;
            invalidAddress: string;
        };
        addressBook: {
            addNewDeliveryAddress: string;
            editDeliveryAddress: string;
            areYouSureToDeleteAddress: string;
            addNewAddress: string;
            addAddress: string;
            updateAddress: string;
            backToAddressList: string;
            defaultDeliveryAddress: string;
            additionalDeliveryAddress: string;
        };
        addressCard: {
            default: string;
            selected: string;
            selectedAddress: string;
            setAsDefault: string;
            shipTo: string;
            billTo: string;
            phoneNumber: string;
            mobileNumber: string;
        };
        addressSuggestion: {
            verifyYourAddress: string;
            ensureAccuracySuggestChange: string;
            chooseAddressToUse: string;
            suggestedAddress: string;
            enteredAddress: string;
            editAddress: string;
            saveAddress: string;
        };
        addressMessages: {
            setAsDefaultSuccessfully: string;
        };
    };
    myAccountV2Email: {
        myAccountV2Email: {
            myEmailAddress: string;
            email: string;
            emailAddress: string;
            newEmailAddress: string;
            confirmNewEmailAddress: string;
            emailPlaceHolder: string;
            passwordPlaceHolder: string;
            password: string;
            reloginIndicator: string;
        };
    };
    myAccountV2Password: {
        myAccountV2PasswordForm: {
            oldPassword: {
                label: string;
                placeholder: string;
            };
            oldPasswordIsRequired: string;
            newPassword: {
                label: string;
                placeholder: string;
            };
            passwordMinRequirements: string;
            confirmPassword: {
                label: string;
                placeholder: string;
            };
            reloginIndicator: string;
            bothPasswordMustMatch: string;
            passwordUpdateSuccess: string;
            accessDeniedError: string;
            newPasswordTitle: string;
        };
    };
    myAccountV2UserProfile: {
        myAccountV2UserProfile: {
            myEmailAddress: string;
            myInformation: string;
            name: string;
            customerId: string;
            title: string;
            firstName: string;
            lastName: string;
        };
    };
    userProfile: {
        updateEmailForm: {
            newEmailAddress: {
                label: string;
                placeholder: string;
            };
            confirmNewEmailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            bothEmailMustMatch: string;
            password: {
                label: string;
                placeholder: string;
            };
            pleaseInputPassword: string;
            emailUpdateSuccess: string;
        };
        register: {
            confirmPassword: {
                action: string;
                label: string;
                placeholder: string;
            };
            managementInMyAccount: string;
            termsAndConditions: string;
            signIn: string;
            register: string;
            furtherRegistration: string;
            confirmNewPassword: string;
            resetPassword: string;
            createAccount: string;
            title: string;
            titleOptional: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            newPassword: string;
            emailMarketing: string;
            confirmThatRead: string;
            selectTitle: string;
            passwordMinRequirements: string;
            passwordStrengthRequirements: string;
            bothPasswordMustMatch: string;
            titleRequired: string;
            postRegisterMessage: string;
            postRegisterSuccessMessage: string;
            rateLimitForRegistrationMessage: string;
            verificationTokenForm: {
                createVerificationToken: string;
                sendRateLime: string;
                resend: string;
                verificationCode: {
                    label: string;
                    placeholder: string;
                };
                back: string;
            };
        };
        forgottenPassword: {
            resetPassword: string;
            enterEmailAddressAssociatedWithYourAccount: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            passwordResetEmailSent: string;
            passwordResetSuccess: string;
        };
    };
};

declare const id: {
    address: {
        addressForm: {
            title: string;
            titleOptional: string;
            defaultTitle: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            address1: string;
            address2: string;
            country: string;
            city: {
                label: string;
                placeholder: string;
            };
            state: string;
            zipCode: {
                label: string;
                placeholder: string;
            };
            phoneNumber: {
                label: string;
                placeholder: string;
            };
            cellphone: {
                label: string;
                placeholder: string;
            };
            saveAsDefault: string;
            chooseAddress: string;
            streetAddress: string;
            aptSuite: string;
            selectOne: string;
            setAsDefault: string;
            titleRequired: string;
            userAddressAddSuccess: string;
            userAddressUpdateSuccess: string;
            userAddressDeleteSuccess: string;
            invalidAddress: string;
        };
        addressBook: {
            addNewDeliveryAddress: string;
            editDeliveryAddress: string;
            areYouSureToDeleteAddress: string;
            addNewAddress: string;
            addAddress: string;
            updateAddress: string;
            backToAddressList: string;
            defaultDeliveryAddress: string;
            additionalDeliveryAddress: string;
        };
        addressCard: {
            default: string;
            selected: string;
            selectedAddress: string;
            setAsDefault: string;
            shipTo: string;
            billTo: string;
            phoneNumber: string;
            mobileNumber: string;
        };
        addressSuggestion: {
            verifyYourAddress: string;
            ensureAccuracySuggestChange: string;
            chooseAddressToUse: string;
            suggestedAddress: string;
            enteredAddress: string;
            editAddress: string;
            saveAddress: string;
        };
        addressMessages: {
            setAsDefaultSuccessfully: string;
        };
    };
    myAccountV2Email: {
        myAccountV2Email: {
            myEmailAddress: string;
            email: string;
            emailAddress: string;
            newEmailAddress: string;
            confirmNewEmailAddress: string;
            emailPlaceHolder: string;
            passwordPlaceHolder: string;
            password: string;
            reloginIndicator: string;
        };
    };
    myAccountV2Password: {
        myAccountV2PasswordForm: {
            oldPassword: {
                label: string;
                placeholder: string;
            };
            oldPasswordIsRequired: string;
            newPassword: {
                label: string;
                placeholder: string;
            };
            passwordMinRequirements: string;
            confirmPassword: {
                label: string;
                placeholder: string;
            };
            reloginIndicator: string;
            bothPasswordMustMatch: string;
            passwordUpdateSuccess: string;
            accessDeniedError: string;
            newPasswordTitle: string;
        };
    };
    myAccountV2UserProfile: {
        myAccountV2UserProfile: {
            myEmailAddress: string;
            myInformation: string;
            name: string;
            customerId: string;
            title: string;
            firstName: string;
            lastName: string;
        };
    };
    userProfile: {
        updateEmailForm: {
            newEmailAddress: {
                label: string;
                placeholder: string;
            };
            confirmNewEmailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            bothEmailMustMatch: string;
            password: {
                label: string;
                placeholder: string;
            };
            pleaseInputPassword: string;
            emailUpdateSuccess: string;
        };
        register: {
            confirmPassword: {
                action: string;
                label: string;
                placeholder: string;
            };
            managementInMyAccount: string;
            termsAndConditions: string;
            signIn: string;
            register: string;
            furtherRegistration: string;
            confirmNewPassword: string;
            resetPassword: string;
            createAccount: string;
            title: string;
            titleOptional: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            newPassword: string;
            emailMarketing: string;
            confirmThatRead: string;
            selectTitle: string;
            passwordMinRequirements: string;
            passwordStrengthRequirements: string;
            bothPasswordMustMatch: string;
            titleRequired: string;
            postRegisterMessage: string;
            postRegisterSuccessMessage: string;
            rateLimitForRegistrationMessage: string;
            verificationTokenForm: {
                createVerificationToken: string;
                sendRateLime: string;
                resend: string;
                verificationCode: {
                    label: string;
                    placeholder: string;
                };
                back: string;
            };
        };
        forgottenPassword: {
            resetPassword: string;
            enterEmailAddressAssociatedWithYourAccount: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            passwordResetEmailSent: string;
            passwordResetSuccess: string;
        };
    };
};

declare const it: {
    address: {
        addressForm: {
            title: string;
            titleOptional: string;
            defaultTitle: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            address1: string;
            address2: string;
            country: string;
            city: {
                label: string;
                placeholder: string;
            };
            state: string;
            zipCode: {
                label: string;
                placeholder: string;
            };
            phoneNumber: {
                label: string;
                placeholder: string;
            };
            cellphone: {
                label: string;
                placeholder: string;
            };
            saveAsDefault: string;
            chooseAddress: string;
            streetAddress: string;
            aptSuite: string;
            selectOne: string;
            setAsDefault: string;
            titleRequired: string;
            userAddressAddSuccess: string;
            userAddressUpdateSuccess: string;
            userAddressDeleteSuccess: string;
            invalidAddress: string;
        };
        addressBook: {
            addNewDeliveryAddress: string;
            editDeliveryAddress: string;
            areYouSureToDeleteAddress: string;
            addNewAddress: string;
            addAddress: string;
            updateAddress: string;
            backToAddressList: string;
            defaultDeliveryAddress: string;
            additionalDeliveryAddress: string;
        };
        addressCard: {
            default: string;
            selected: string;
            selectedAddress: string;
            setAsDefault: string;
            shipTo: string;
            billTo: string;
            phoneNumber: string;
            mobileNumber: string;
        };
        addressSuggestion: {
            verifyYourAddress: string;
            ensureAccuracySuggestChange: string;
            chooseAddressToUse: string;
            suggestedAddress: string;
            enteredAddress: string;
            editAddress: string;
            saveAddress: string;
        };
        addressMessages: {
            setAsDefaultSuccessfully: string;
        };
    };
    myAccountV2Email: {
        myAccountV2Email: {
            myEmailAddress: string;
            email: string;
            emailAddress: string;
            newEmailAddress: string;
            confirmNewEmailAddress: string;
            emailPlaceHolder: string;
            passwordPlaceHolder: string;
            password: string;
            reloginIndicator: string;
        };
    };
    myAccountV2Password: {
        myAccountV2PasswordForm: {
            oldPassword: {
                label: string;
                placeholder: string;
            };
            oldPasswordIsRequired: string;
            newPassword: {
                label: string;
                placeholder: string;
            };
            passwordMinRequirements: string;
            confirmPassword: {
                label: string;
                placeholder: string;
            };
            reloginIndicator: string;
            bothPasswordMustMatch: string;
            passwordUpdateSuccess: string;
            accessDeniedError: string;
            newPasswordTitle: string;
        };
    };
    myAccountV2UserProfile: {
        myAccountV2UserProfile: {
            myEmailAddress: string;
            myInformation: string;
            name: string;
            customerId: string;
            title: string;
            firstName: string;
            lastName: string;
        };
    };
    userProfile: {
        updateEmailForm: {
            newEmailAddress: {
                label: string;
                placeholder: string;
            };
            confirmNewEmailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            bothEmailMustMatch: string;
            password: {
                label: string;
                placeholder: string;
            };
            pleaseInputPassword: string;
            emailUpdateSuccess: string;
        };
        register: {
            confirmPassword: {
                action: string;
                label: string;
                placeholder: string;
            };
            managementInMyAccount: string;
            termsAndConditions: string;
            signIn: string;
            register: string;
            furtherRegistration: string;
            confirmNewPassword: string;
            resetPassword: string;
            createAccount: string;
            title: string;
            titleOptional: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            newPassword: string;
            emailMarketing: string;
            confirmThatRead: string;
            selectTitle: string;
            passwordMinRequirements: string;
            passwordStrengthRequirements: string;
            bothPasswordMustMatch: string;
            titleRequired: string;
            postRegisterMessage: string;
            postRegisterSuccessMessage: string;
            rateLimitForRegistrationMessage: string;
            verificationTokenForm: {
                createVerificationToken: string;
                sendRateLime: string;
                resend: string;
                verificationCode: {
                    label: string;
                    placeholder: string;
                };
                back: string;
            };
        };
        forgottenPassword: {
            resetPassword: string;
            enterEmailAddressAssociatedWithYourAccount: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            passwordResetEmailSent: string;
            passwordResetSuccess: string;
        };
    };
};

declare const ja: {
    address: {
        addressForm: {
            title: string;
            titleOptional: string;
            defaultTitle: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            address1: string;
            address2: string;
            country: string;
            city: {
                label: string;
                placeholder: string;
            };
            state: string;
            zipCode: {
                label: string;
                placeholder: string;
            };
            phoneNumber: {
                label: string;
                placeholder: string;
            };
            cellphone: {
                label: string;
                placeholder: string;
            };
            saveAsDefault: string;
            chooseAddress: string;
            streetAddress: string;
            aptSuite: string;
            selectOne: string;
            setAsDefault: string;
            titleRequired: string;
            userAddressAddSuccess: string;
            userAddressUpdateSuccess: string;
            userAddressDeleteSuccess: string;
            invalidAddress: string;
        };
        addressBook: {
            addNewDeliveryAddress: string;
            editDeliveryAddress: string;
            areYouSureToDeleteAddress: string;
            addNewAddress: string;
            addAddress: string;
            updateAddress: string;
            backToAddressList: string;
            defaultDeliveryAddress: string;
            additionalDeliveryAddress: string;
        };
        addressCard: {
            default: string;
            selected: string;
            selectedAddress: string;
            setAsDefault: string;
            shipTo: string;
            billTo: string;
            phoneNumber: string;
            mobileNumber: string;
        };
        addressSuggestion: {
            verifyYourAddress: string;
            ensureAccuracySuggestChange: string;
            chooseAddressToUse: string;
            suggestedAddress: string;
            enteredAddress: string;
            editAddress: string;
            saveAddress: string;
        };
        addressMessages: {
            setAsDefaultSuccessfully: string;
        };
    };
    myAccountV2Email: {
        myAccountV2Email: {
            myEmailAddress: string;
            email: string;
            emailAddress: string;
            newEmailAddress: string;
            confirmNewEmailAddress: string;
            emailPlaceHolder: string;
            passwordPlaceHolder: string;
            password: string;
            reloginIndicator: string;
        };
    };
    myAccountV2Password: {
        myAccountV2PasswordForm: {
            oldPassword: {
                label: string;
                placeholder: string;
            };
            oldPasswordIsRequired: string;
            newPassword: {
                label: string;
                placeholder: string;
            };
            passwordMinRequirements: string;
            confirmPassword: {
                label: string;
                placeholder: string;
            };
            reloginIndicator: string;
            bothPasswordMustMatch: string;
            passwordUpdateSuccess: string;
            accessDeniedError: string;
            newPasswordTitle: string;
        };
    };
    myAccountV2UserProfile: {
        myAccountV2UserProfile: {
            myEmailAddress: string;
            myInformation: string;
            name: string;
            customerId: string;
            title: string;
            firstName: string;
            lastName: string;
        };
    };
    userProfile: {
        updateEmailForm: {
            newEmailAddress: {
                label: string;
                placeholder: string;
            };
            confirmNewEmailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            bothEmailMustMatch: string;
            password: {
                label: string;
                placeholder: string;
            };
            pleaseInputPassword: string;
            emailUpdateSuccess: string;
        };
        register: {
            confirmPassword: {
                action: string;
                label: string;
                placeholder: string;
            };
            managementInMyAccount: string;
            termsAndConditions: string;
            signIn: string;
            register: string;
            furtherRegistration: string;
            confirmNewPassword: string;
            resetPassword: string;
            createAccount: string;
            title: string;
            titleOptional: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            newPassword: string;
            emailMarketing: string;
            confirmThatRead: string;
            selectTitle: string;
            passwordMinRequirements: string;
            passwordStrengthRequirements: string;
            bothPasswordMustMatch: string;
            titleRequired: string;
            postRegisterMessage: string;
            postRegisterSuccessMessage: string;
            rateLimitForRegistrationMessage: string;
            verificationTokenForm: {
                createVerificationToken: string;
                sendRateLime: string;
                resend: string;
                verificationCode: {
                    label: string;
                    placeholder: string;
                };
                back: string;
            };
        };
        forgottenPassword: {
            resetPassword: string;
            enterEmailAddressAssociatedWithYourAccount: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            passwordResetEmailSent: string;
            passwordResetSuccess: string;
        };
    };
};

declare const ko: {
    address: {
        addressForm: {
            title: string;
            titleOptional: string;
            defaultTitle: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            address1: string;
            address2: string;
            country: string;
            city: {
                label: string;
                placeholder: string;
            };
            state: string;
            zipCode: {
                label: string;
                placeholder: string;
            };
            phoneNumber: {
                label: string;
                placeholder: string;
            };
            cellphone: {
                label: string;
                placeholder: string;
            };
            saveAsDefault: string;
            chooseAddress: string;
            streetAddress: string;
            aptSuite: string;
            selectOne: string;
            setAsDefault: string;
            titleRequired: string;
            userAddressAddSuccess: string;
            userAddressUpdateSuccess: string;
            userAddressDeleteSuccess: string;
            invalidAddress: string;
        };
        addressBook: {
            addNewDeliveryAddress: string;
            editDeliveryAddress: string;
            areYouSureToDeleteAddress: string;
            addNewAddress: string;
            addAddress: string;
            updateAddress: string;
            backToAddressList: string;
            defaultDeliveryAddress: string;
            additionalDeliveryAddress: string;
        };
        addressCard: {
            default: string;
            selected: string;
            selectedAddress: string;
            setAsDefault: string;
            shipTo: string;
            billTo: string;
            phoneNumber: string;
            mobileNumber: string;
        };
        addressSuggestion: {
            verifyYourAddress: string;
            ensureAccuracySuggestChange: string;
            chooseAddressToUse: string;
            suggestedAddress: string;
            enteredAddress: string;
            editAddress: string;
            saveAddress: string;
        };
        addressMessages: {
            setAsDefaultSuccessfully: string;
        };
    };
    myAccountV2Email: {
        myAccountV2Email: {
            myEmailAddress: string;
            email: string;
            emailAddress: string;
            newEmailAddress: string;
            confirmNewEmailAddress: string;
            emailPlaceHolder: string;
            passwordPlaceHolder: string;
            password: string;
            reloginIndicator: string;
        };
    };
    myAccountV2Password: {
        myAccountV2PasswordForm: {
            oldPassword: {
                label: string;
                placeholder: string;
            };
            oldPasswordIsRequired: string;
            newPassword: {
                label: string;
                placeholder: string;
            };
            passwordMinRequirements: string;
            confirmPassword: {
                label: string;
                placeholder: string;
            };
            reloginIndicator: string;
            bothPasswordMustMatch: string;
            passwordUpdateSuccess: string;
            accessDeniedError: string;
            newPasswordTitle: string;
        };
    };
    myAccountV2UserProfile: {
        myAccountV2UserProfile: {
            myEmailAddress: string;
            myInformation: string;
            name: string;
            customerId: string;
            title: string;
            firstName: string;
            lastName: string;
        };
    };
    userProfile: {
        updateEmailForm: {
            newEmailAddress: {
                label: string;
                placeholder: string;
            };
            confirmNewEmailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            bothEmailMustMatch: string;
            password: {
                label: string;
                placeholder: string;
            };
            pleaseInputPassword: string;
            emailUpdateSuccess: string;
        };
        register: {
            confirmPassword: {
                action: string;
                label: string;
                placeholder: string;
            };
            managementInMyAccount: string;
            termsAndConditions: string;
            signIn: string;
            register: string;
            furtherRegistration: string;
            confirmNewPassword: string;
            resetPassword: string;
            createAccount: string;
            title: string;
            titleOptional: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            newPassword: string;
            emailMarketing: string;
            confirmThatRead: string;
            selectTitle: string;
            passwordMinRequirements: string;
            passwordStrengthRequirements: string;
            bothPasswordMustMatch: string;
            titleRequired: string;
            postRegisterMessage: string;
            postRegisterSuccessMessage: string;
            rateLimitForRegistrationMessage: string;
            verificationTokenForm: {
                createVerificationToken: string;
                sendRateLime: string;
                resend: string;
                verificationCode: {
                    label: string;
                    placeholder: string;
                };
                back: string;
            };
        };
        forgottenPassword: {
            resetPassword: string;
            enterEmailAddressAssociatedWithYourAccount: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            passwordResetEmailSent: string;
            passwordResetSuccess: string;
        };
    };
};

declare const pl: {
    address: {
        addressForm: {
            title: string;
            titleOptional: string;
            defaultTitle: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            address1: string;
            address2: string;
            country: string;
            city: {
                label: string;
                placeholder: string;
            };
            state: string;
            zipCode: {
                label: string;
                placeholder: string;
            };
            phoneNumber: {
                label: string;
                placeholder: string;
            };
            cellphone: {
                label: string;
                placeholder: string;
            };
            saveAsDefault: string;
            chooseAddress: string;
            streetAddress: string;
            aptSuite: string;
            selectOne: string;
            setAsDefault: string;
            titleRequired: string;
            userAddressAddSuccess: string;
            userAddressUpdateSuccess: string;
            userAddressDeleteSuccess: string;
            invalidAddress: string;
        };
        addressBook: {
            addNewDeliveryAddress: string;
            editDeliveryAddress: string;
            areYouSureToDeleteAddress: string;
            addNewAddress: string;
            addAddress: string;
            updateAddress: string;
            backToAddressList: string;
            defaultDeliveryAddress: string;
            additionalDeliveryAddress: string;
        };
        addressCard: {
            default: string;
            selected: string;
            selectedAddress: string;
            setAsDefault: string;
            shipTo: string;
            billTo: string;
            phoneNumber: string;
            mobileNumber: string;
        };
        addressSuggestion: {
            verifyYourAddress: string;
            ensureAccuracySuggestChange: string;
            chooseAddressToUse: string;
            suggestedAddress: string;
            enteredAddress: string;
            editAddress: string;
            saveAddress: string;
        };
        addressMessages: {
            setAsDefaultSuccessfully: string;
        };
    };
    myAccountV2Email: {
        myAccountV2Email: {
            myEmailAddress: string;
            email: string;
            emailAddress: string;
            newEmailAddress: string;
            confirmNewEmailAddress: string;
            emailPlaceHolder: string;
            passwordPlaceHolder: string;
            password: string;
            reloginIndicator: string;
        };
    };
    myAccountV2Password: {
        myAccountV2PasswordForm: {
            oldPassword: {
                label: string;
                placeholder: string;
            };
            oldPasswordIsRequired: string;
            newPassword: {
                label: string;
                placeholder: string;
            };
            passwordMinRequirements: string;
            confirmPassword: {
                label: string;
                placeholder: string;
            };
            reloginIndicator: string;
            bothPasswordMustMatch: string;
            passwordUpdateSuccess: string;
            accessDeniedError: string;
            newPasswordTitle: string;
        };
    };
    myAccountV2UserProfile: {
        myAccountV2UserProfile: {
            myEmailAddress: string;
            myInformation: string;
            name: string;
            customerId: string;
            title: string;
            firstName: string;
            lastName: string;
        };
    };
    userProfile: {
        updateEmailForm: {
            newEmailAddress: {
                label: string;
                placeholder: string;
            };
            confirmNewEmailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            bothEmailMustMatch: string;
            password: {
                label: string;
                placeholder: string;
            };
            pleaseInputPassword: string;
            emailUpdateSuccess: string;
        };
        register: {
            confirmPassword: {
                action: string;
                label: string;
                placeholder: string;
            };
            managementInMyAccount: string;
            termsAndConditions: string;
            signIn: string;
            register: string;
            furtherRegistration: string;
            confirmNewPassword: string;
            resetPassword: string;
            createAccount: string;
            title: string;
            titleOptional: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            newPassword: string;
            emailMarketing: string;
            confirmThatRead: string;
            selectTitle: string;
            passwordMinRequirements: string;
            passwordStrengthRequirements: string;
            bothPasswordMustMatch: string;
            titleRequired: string;
            postRegisterMessage: string;
            postRegisterSuccessMessage: string;
            rateLimitForRegistrationMessage: string;
            verificationTokenForm: {
                createVerificationToken: string;
                sendRateLime: string;
                resend: string;
                verificationCode: {
                    label: string;
                    placeholder: string;
                };
                back: string;
            };
        };
        forgottenPassword: {
            resetPassword: string;
            enterEmailAddressAssociatedWithYourAccount: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            passwordResetEmailSent: string;
            passwordResetSuccess: string;
        };
    };
};

declare const pt: {
    address: {
        addressForm: {
            title: string;
            titleOptional: string;
            defaultTitle: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            address1: string;
            address2: string;
            country: string;
            city: {
                label: string;
                placeholder: string;
            };
            state: string;
            zipCode: {
                label: string;
                placeholder: string;
            };
            phoneNumber: {
                label: string;
                placeholder: string;
            };
            cellphone: {
                label: string;
                placeholder: string;
            };
            saveAsDefault: string;
            chooseAddress: string;
            streetAddress: string;
            aptSuite: string;
            selectOne: string;
            setAsDefault: string;
            titleRequired: string;
            userAddressAddSuccess: string;
            userAddressUpdateSuccess: string;
            userAddressDeleteSuccess: string;
            invalidAddress: string;
        };
        addressBook: {
            addNewDeliveryAddress: string;
            editDeliveryAddress: string;
            areYouSureToDeleteAddress: string;
            addNewAddress: string;
            addAddress: string;
            updateAddress: string;
            backToAddressList: string;
            defaultDeliveryAddress: string;
            additionalDeliveryAddress: string;
        };
        addressCard: {
            default: string;
            selected: string;
            selectedAddress: string;
            setAsDefault: string;
            shipTo: string;
            billTo: string;
            phoneNumber: string;
            mobileNumber: string;
        };
        addressSuggestion: {
            verifyYourAddress: string;
            ensureAccuracySuggestChange: string;
            chooseAddressToUse: string;
            suggestedAddress: string;
            enteredAddress: string;
            editAddress: string;
            saveAddress: string;
        };
        addressMessages: {
            setAsDefaultSuccessfully: string;
        };
    };
    myAccountV2Email: {
        myAccountV2Email: {
            myEmailAddress: string;
            email: string;
            emailAddress: string;
            newEmailAddress: string;
            confirmNewEmailAddress: string;
            emailPlaceHolder: string;
            passwordPlaceHolder: string;
            password: string;
            reloginIndicator: string;
        };
    };
    myAccountV2Password: {
        myAccountV2PasswordForm: {
            oldPassword: {
                label: string;
                placeholder: string;
            };
            oldPasswordIsRequired: string;
            newPassword: {
                label: string;
                placeholder: string;
            };
            passwordMinRequirements: string;
            confirmPassword: {
                label: string;
                placeholder: string;
            };
            reloginIndicator: string;
            bothPasswordMustMatch: string;
            passwordUpdateSuccess: string;
            accessDeniedError: string;
            newPasswordTitle: string;
        };
    };
    myAccountV2UserProfile: {
        myAccountV2UserProfile: {
            myEmailAddress: string;
            myInformation: string;
            name: string;
            customerId: string;
            title: string;
            firstName: string;
            lastName: string;
        };
    };
    userProfile: {
        updateEmailForm: {
            newEmailAddress: {
                label: string;
                placeholder: string;
            };
            confirmNewEmailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            bothEmailMustMatch: string;
            password: {
                label: string;
                placeholder: string;
            };
            pleaseInputPassword: string;
            emailUpdateSuccess: string;
        };
        register: {
            confirmPassword: {
                action: string;
                label: string;
                placeholder: string;
            };
            managementInMyAccount: string;
            termsAndConditions: string;
            signIn: string;
            register: string;
            furtherRegistration: string;
            confirmNewPassword: string;
            resetPassword: string;
            createAccount: string;
            title: string;
            titleOptional: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            newPassword: string;
            emailMarketing: string;
            confirmThatRead: string;
            selectTitle: string;
            passwordMinRequirements: string;
            passwordStrengthRequirements: string;
            bothPasswordMustMatch: string;
            titleRequired: string;
            postRegisterMessage: string;
            postRegisterSuccessMessage: string;
            rateLimitForRegistrationMessage: string;
            verificationTokenForm: {
                createVerificationToken: string;
                sendRateLime: string;
                resend: string;
                verificationCode: {
                    label: string;
                    placeholder: string;
                };
                back: string;
            };
        };
        forgottenPassword: {
            resetPassword: string;
            enterEmailAddressAssociatedWithYourAccount: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            passwordResetEmailSent: string;
            passwordResetSuccess: string;
        };
    };
};

declare const ru: {
    address: {
        addressForm: {
            title: string;
            titleOptional: string;
            defaultTitle: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            address1: string;
            address2: string;
            country: string;
            city: {
                label: string;
                placeholder: string;
            };
            state: string;
            zipCode: {
                label: string;
                placeholder: string;
            };
            phoneNumber: {
                label: string;
                placeholder: string;
            };
            cellphone: {
                label: string;
                placeholder: string;
            };
            saveAsDefault: string;
            chooseAddress: string;
            streetAddress: string;
            aptSuite: string;
            selectOne: string;
            setAsDefault: string;
            titleRequired: string;
            userAddressAddSuccess: string;
            userAddressUpdateSuccess: string;
            userAddressDeleteSuccess: string;
            invalidAddress: string;
        };
        addressBook: {
            addNewDeliveryAddress: string;
            editDeliveryAddress: string;
            areYouSureToDeleteAddress: string;
            addNewAddress: string;
            addAddress: string;
            updateAddress: string;
            backToAddressList: string;
            defaultDeliveryAddress: string;
            additionalDeliveryAddress: string;
        };
        addressCard: {
            default: string;
            selected: string;
            selectedAddress: string;
            setAsDefault: string;
            shipTo: string;
            billTo: string;
            phoneNumber: string;
            mobileNumber: string;
        };
        addressSuggestion: {
            verifyYourAddress: string;
            ensureAccuracySuggestChange: string;
            chooseAddressToUse: string;
            suggestedAddress: string;
            enteredAddress: string;
            editAddress: string;
            saveAddress: string;
        };
        addressMessages: {
            setAsDefaultSuccessfully: string;
        };
    };
    myAccountV2Email: {
        myAccountV2Email: {
            myEmailAddress: string;
            email: string;
            emailAddress: string;
            newEmailAddress: string;
            confirmNewEmailAddress: string;
            emailPlaceHolder: string;
            passwordPlaceHolder: string;
            password: string;
            reloginIndicator: string;
        };
    };
    myAccountV2Password: {
        myAccountV2PasswordForm: {
            oldPassword: {
                label: string;
                placeholder: string;
            };
            oldPasswordIsRequired: string;
            newPassword: {
                label: string;
                placeholder: string;
            };
            passwordMinRequirements: string;
            confirmPassword: {
                label: string;
                placeholder: string;
            };
            reloginIndicator: string;
            bothPasswordMustMatch: string;
            passwordUpdateSuccess: string;
            accessDeniedError: string;
            newPasswordTitle: string;
        };
    };
    myAccountV2UserProfile: {
        myAccountV2UserProfile: {
            myEmailAddress: string;
            myInformation: string;
            name: string;
            customerId: string;
            title: string;
            firstName: string;
            lastName: string;
        };
    };
    userProfile: {
        updateEmailForm: {
            newEmailAddress: {
                label: string;
                placeholder: string;
            };
            confirmNewEmailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            bothEmailMustMatch: string;
            password: {
                label: string;
                placeholder: string;
            };
            pleaseInputPassword: string;
            emailUpdateSuccess: string;
        };
        register: {
            confirmPassword: {
                action: string;
                label: string;
                placeholder: string;
            };
            managementInMyAccount: string;
            termsAndConditions: string;
            signIn: string;
            register: string;
            furtherRegistration: string;
            confirmNewPassword: string;
            resetPassword: string;
            createAccount: string;
            title: string;
            titleOptional: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            newPassword: string;
            emailMarketing: string;
            confirmThatRead: string;
            selectTitle: string;
            passwordMinRequirements: string;
            passwordStrengthRequirements: string;
            bothPasswordMustMatch: string;
            titleRequired: string;
            postRegisterMessage: string;
            postRegisterSuccessMessage: string;
            rateLimitForRegistrationMessage: string;
            verificationTokenForm: {
                createVerificationToken: string;
                sendRateLime: string;
                resend: string;
                verificationCode: {
                    label: string;
                    placeholder: string;
                };
                back: string;
            };
        };
        forgottenPassword: {
            resetPassword: string;
            enterEmailAddressAssociatedWithYourAccount: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            passwordResetEmailSent: string;
            passwordResetSuccess: string;
        };
    };
};

declare const zh: {
    address: {
        addressForm: {
            title: string;
            titleOptional: string;
            defaultTitle: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            address1: string;
            address2: string;
            country: string;
            city: {
                label: string;
                placeholder: string;
            };
            state: string;
            zipCode: {
                label: string;
                placeholder: string;
            };
            phoneNumber: {
                label: string;
                placeholder: string;
            };
            cellphone: {
                label: string;
                placeholder: string;
            };
            saveAsDefault: string;
            chooseAddress: string;
            streetAddress: string;
            aptSuite: string;
            selectOne: string;
            setAsDefault: string;
            titleRequired: string;
            userAddressAddSuccess: string;
            userAddressUpdateSuccess: string;
            userAddressDeleteSuccess: string;
            invalidAddress: string;
        };
        addressBook: {
            addNewDeliveryAddress: string;
            editDeliveryAddress: string;
            areYouSureToDeleteAddress: string;
            addNewAddress: string;
            addAddress: string;
            updateAddress: string;
            backToAddressList: string;
            defaultDeliveryAddress: string;
            additionalDeliveryAddress: string;
        };
        addressCard: {
            default: string;
            selected: string;
            selectedAddress: string;
            setAsDefault: string;
            shipTo: string;
            billTo: string;
            phoneNumber: string;
            mobileNumber: string;
        };
        addressSuggestion: {
            verifyYourAddress: string;
            ensureAccuracySuggestChange: string;
            chooseAddressToUse: string;
            suggestedAddress: string;
            enteredAddress: string;
            editAddress: string;
            saveAddress: string;
        };
        addressMessages: {
            setAsDefaultSuccessfully: string;
        };
    };
    myAccountV2Email: {
        myAccountV2Email: {
            myEmailAddress: string;
            email: string;
            emailAddress: string;
            newEmailAddress: string;
            confirmNewEmailAddress: string;
            emailPlaceHolder: string;
            passwordPlaceHolder: string;
            password: string;
            reloginIndicator: string;
        };
    };
    myAccountV2Password: {
        myAccountV2PasswordForm: {
            oldPassword: {
                label: string;
                placeholder: string;
            };
            oldPasswordIsRequired: string;
            newPassword: {
                label: string;
                placeholder: string;
            };
            passwordMinRequirements: string;
            confirmPassword: {
                label: string;
                placeholder: string;
            };
            reloginIndicator: string;
            bothPasswordMustMatch: string;
            passwordUpdateSuccess: string;
            accessDeniedError: string;
            newPasswordTitle: string;
        };
    };
    myAccountV2UserProfile: {
        myAccountV2UserProfile: {
            myEmailAddress: string;
            myInformation: string;
            name: string;
            customerId: string;
            title: string;
            firstName: string;
            lastName: string;
        };
    };
    userProfile: {
        updateEmailForm: {
            newEmailAddress: {
                label: string;
                placeholder: string;
            };
            confirmNewEmailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            bothEmailMustMatch: string;
            password: {
                label: string;
                placeholder: string;
            };
            pleaseInputPassword: string;
            emailUpdateSuccess: string;
        };
        register: {
            confirmPassword: {
                action: string;
                label: string;
                placeholder: string;
            };
            managementInMyAccount: string;
            termsAndConditions: string;
            signIn: string;
            register: string;
            furtherRegistration: string;
            confirmNewPassword: string;
            resetPassword: string;
            createAccount: string;
            title: string;
            titleOptional: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            newPassword: string;
            emailMarketing: string;
            confirmThatRead: string;
            selectTitle: string;
            passwordMinRequirements: string;
            passwordStrengthRequirements: string;
            bothPasswordMustMatch: string;
            titleRequired: string;
            postRegisterMessage: string;
            postRegisterSuccessMessage: string;
            rateLimitForRegistrationMessage: string;
            verificationTokenForm: {
                createVerificationToken: string;
                sendRateLime: string;
                resend: string;
                verificationCode: {
                    label: string;
                    placeholder: string;
                };
                back: string;
            };
        };
        forgottenPassword: {
            resetPassword: string;
            enterEmailAddressAssociatedWithYourAccount: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            passwordResetEmailSent: string;
            passwordResetSuccess: string;
        };
    };
};

declare const zh_TW: {
    address: {
        addressForm: {
            title: string;
            titleOptional: string;
            defaultTitle: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            address1: string;
            address2: string;
            country: string;
            city: {
                label: string;
                placeholder: string;
            };
            state: string;
            zipCode: {
                label: string;
                placeholder: string;
            };
            phoneNumber: {
                label: string;
                placeholder: string;
            };
            cellphone: {
                label: string;
                placeholder: string;
            };
            saveAsDefault: string;
            chooseAddress: string;
            streetAddress: string;
            aptSuite: string;
            selectOne: string;
            setAsDefault: string;
            titleRequired: string;
            userAddressAddSuccess: string;
            userAddressUpdateSuccess: string;
            userAddressDeleteSuccess: string;
            invalidAddress: string;
        };
        addressBook: {
            addNewDeliveryAddress: string;
            editDeliveryAddress: string;
            areYouSureToDeleteAddress: string;
            addNewAddress: string;
            addAddress: string;
            updateAddress: string;
            backToAddressList: string;
            defaultDeliveryAddress: string;
            additionalDeliveryAddress: string;
        };
        addressCard: {
            default: string;
            selected: string;
            selectedAddress: string;
            setAsDefault: string;
            shipTo: string;
            billTo: string;
            phoneNumber: string;
            mobileNumber: string;
        };
        addressSuggestion: {
            verifyYourAddress: string;
            ensureAccuracySuggestChange: string;
            chooseAddressToUse: string;
            suggestedAddress: string;
            enteredAddress: string;
            editAddress: string;
            saveAddress: string;
        };
        addressMessages: {
            setAsDefaultSuccessfully: string;
        };
    };
    myAccountV2Email: {
        myAccountV2Email: {
            myEmailAddress: string;
            email: string;
            emailAddress: string;
            newEmailAddress: string;
            confirmNewEmailAddress: string;
            emailPlaceHolder: string;
            passwordPlaceHolder: string;
            password: string;
            reloginIndicator: string;
        };
    };
    myAccountV2Password: {
        myAccountV2PasswordForm: {
            oldPassword: {
                label: string;
                placeholder: string;
            };
            oldPasswordIsRequired: string;
            newPassword: {
                label: string;
                placeholder: string;
            };
            passwordMinRequirements: string;
            confirmPassword: {
                label: string;
                placeholder: string;
            };
            reloginIndicator: string;
            bothPasswordMustMatch: string;
            passwordUpdateSuccess: string;
            accessDeniedError: string;
            newPasswordTitle: string;
        };
    };
    myAccountV2UserProfile: {
        myAccountV2UserProfile: {
            myEmailAddress: string;
            myInformation: string;
            name: string;
            customerId: string;
            title: string;
            firstName: string;
            lastName: string;
        };
    };
    userProfile: {
        updateEmailForm: {
            newEmailAddress: {
                label: string;
                placeholder: string;
            };
            confirmNewEmailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            bothEmailMustMatch: string;
            password: {
                label: string;
                placeholder: string;
            };
            pleaseInputPassword: string;
            emailUpdateSuccess: string;
        };
        register: {
            confirmPassword: {
                action: string;
                label: string;
                placeholder: string;
            };
            managementInMyAccount: string;
            termsAndConditions: string;
            signIn: string;
            register: string;
            furtherRegistration: string;
            confirmNewPassword: string;
            resetPassword: string;
            createAccount: string;
            title: string;
            titleOptional: string;
            firstName: {
                label: string;
                placeholder: string;
            };
            lastName: {
                label: string;
                placeholder: string;
            };
            emailAddress: {
                label: string;
                placeholder: string;
            };
            password: {
                label: string;
                placeholder: string;
            };
            newPassword: string;
            emailMarketing: string;
            confirmThatRead: string;
            selectTitle: string;
            passwordMinRequirements: string;
            passwordStrengthRequirements: string;
            bothPasswordMustMatch: string;
            titleRequired: string;
            postRegisterMessage: string;
            postRegisterSuccessMessage: string;
            rateLimitForRegistrationMessage: string;
            verificationTokenForm: {
                createVerificationToken: string;
                sendRateLime: string;
                resend: string;
                verificationCode: {
                    label: string;
                    placeholder: string;
                };
                back: string;
            };
        };
        forgottenPassword: {
            resetPassword: string;
            enterEmailAddressAssociatedWithYourAccount: string;
            emailAddress: {
                label: string;
                placeholder: string;
            };
            enterValidEmail: string;
            passwordResetEmailSent: string;
            passwordResetSuccess: string;
        };
    };
};

declare const userProfileTranslationChunksConfig: TranslationChunksConfig;

export { userProfileTranslationChunksConfig, cs as userProfileTranslationsCs, de as userProfileTranslationsDe, en as userProfileTranslationsEn, es as userProfileTranslationsEs, es_CO as userProfileTranslationsEs_CO, fr as userProfileTranslationsFr, hi as userProfileTranslationsHi, hu as userProfileTranslationsHu, id as userProfileTranslationsId, it as userProfileTranslationsIt, ja as userProfileTranslationsJa, ko as userProfileTranslationsKo, pl as userProfileTranslationsPl, pt as userProfileTranslationsPt, ru as userProfileTranslationsRu, zh as userProfileTranslationsZh, zh_TW as userProfileTranslationsZh_TW };
