import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import { Converter, UserIdService, CommandService, Command, AuthService, EventService, QueryService, Query, RoutingService } from '@spartacus/core';
import { User, UserAccountFacade } from '@spartacus/user/account/root';
import { Title, UserSignUp, UserEmailFacade, UserPasswordFacade, UserProfileFacade, UserRegisterFacade } from '@spartacus/user/profile/root';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';

declare const USER_PROFILE_NORMALIZER: InjectionToken<Converter<User, any>>;
declare const USER_PROFILE_SERIALIZER: InjectionToken<Converter<User, any>>;
declare const USER_SERIALIZER: InjectionToken<Converter<User, any>>;
declare const USER_SIGN_UP_SERIALIZER: InjectionToken<Converter<UserSignUp, any>>;
declare const TITLE_NORMALIZER: InjectionToken<Converter<any, Title>>;

declare abstract class UserProfileAdapter {
    abstract update(username: string, user: User): Observable<unknown>;
    abstract register(user: UserSignUp): Observable<User>;
    abstract registerGuest(guid: string, password: string): Observable<User>;
    abstract requestForgotPasswordEmail(userEmailAddress: string): Observable<unknown>;
    abstract resetPassword(token: string, newPassword: string): Observable<unknown>;
    abstract updateEmail(userId: string, currentPassword: string, newUserId: string): Observable<unknown>;
    abstract updatePassword(userId: string, oldPassword: string, newPassword: string): Observable<unknown>;
    abstract close(userId: string): Observable<unknown>;
    abstract loadTitles(): Observable<Title[]>;
}

declare class UserProfileConnector {
    protected userProfileAdapter: UserProfileAdapter;
    constructor(userProfileAdapter: UserProfileAdapter);
    update(username: string, user: User): Observable<unknown>;
    register(user: UserSignUp): Observable<User>;
    registerGuest(guid: string, password: string): Observable<User>;
    requestForgotPasswordEmail(userEmailAddress: string): Observable<unknown>;
    resetPassword(token: string, newPassword: string): Observable<unknown>;
    updateEmail(userId: string, currentPassword: string, newUserId: string): Observable<unknown>;
    updatePassword(userId: string, oldPassword: string, newPassword: string): Observable<unknown>;
    remove(userId: string): Observable<unknown>;
    getTitles(): Observable<Title[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserProfileConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserProfileConnector>;
}

declare class UserEmailService implements UserEmailFacade {
    protected userIdService: UserIdService;
    protected userProfileConnector: UserProfileConnector;
    protected command: CommandService;
    constructor(userIdService: UserIdService, userProfileConnector: UserProfileConnector, command: CommandService);
    protected updateCommand: Command<{
        password: string;
        newUid: string;
    }>;
    /**
     * Updates the user's email.
     *
     * @param password to users password to confirm the users
     * @param newUid the new proposed email address.
     */
    update(password: string, newUid: string): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserEmailService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserEmailService>;
}

declare class UserPasswordService implements UserPasswordFacade {
    protected userProfileConnector: UserProfileConnector;
    protected userIdService: UserIdService;
    protected command: CommandService;
    protected updateCommand: Command<{
        oldPassword: string;
        newPassword: string;
    }>;
    protected resetCommand: Command<{
        token: string;
        password: string;
    }>;
    protected requestForgotPasswordEmailCommand: Command<{
        email: string;
    }>;
    constructor(userProfileConnector: UserProfileConnector, userIdService: UserIdService, command: CommandService);
    /**
     * Updates the password for the user
     *
     * The method returns an observable with `LoaderState` information, including the
     * actual user data.
     *
     * @param oldPassword the current password that will be changed
     * @param newPassword the new password
     */
    update(oldPassword: string, newPassword: string): Observable<unknown>;
    /**
     * Reset new password. Part of the forgot password flow.
     *
     * @param token
     * @param password
     */
    reset(token: string, password: string): Observable<unknown>;
    requestForgotPasswordEmail(email: string): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserPasswordService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserPasswordService>;
}

declare class UserProfileService implements UserProfileFacade {
    protected userAccountService: UserAccountFacade;
    protected authService: AuthService;
    protected userProfileConnector: UserProfileConnector;
    protected eventService: EventService;
    protected userIdService: UserIdService;
    protected query: QueryService;
    protected command: CommandService;
    protected updateCommand: Command<{
        details: User;
    }>;
    protected closeCommand: Command;
    protected titleQuery: Query<Title[]>;
    constructor(userAccountService: UserAccountFacade, authService: AuthService, userProfileConnector: UserProfileConnector, eventService: EventService, userIdService: UserIdService, query: QueryService, command: CommandService);
    get(): Observable<User | undefined>;
    /**
     * Updates the user's details.
     *
     * @param details User details to be updated.
     */
    update(details: User): Observable<unknown>;
    /**
     * Closes the user account.
     */
    close(): Observable<unknown>;
    /**
     * Returns titles that can be used for the user profiles.
     */
    getTitles(): Observable<Title[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserProfileService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserProfileService>;
}

declare class UserRegisterService implements UserRegisterFacade {
    protected userProfile: UserProfileService;
    protected userConnector: UserProfileConnector;
    protected authService: AuthService;
    protected command: CommandService;
    protected store: Store;
    private featureToggles;
    protected routingService: RoutingService;
    protected registerCommand: Command<{
        user: UserSignUp;
    }, User>;
    protected registerGuestCommand: Command<{
        guid: string;
        password: string;
    }, User>;
    constructor(userProfile: UserProfileService, userConnector: UserProfileConnector, authService: AuthService, command: CommandService, store: Store);
    /**
     * Register a new user.
     *
     * @param submitFormData as UserRegisterFormData
     */
    register(user: UserSignUp): Observable<User>;
    /**
     * Register a new user from guest.
     *
     * @param guid
     * @param password
     */
    registerGuest(guid: string, password: string): Observable<User>;
    /**
     * Returns titles that can be used for the user profiles.
     */
    getTitles(): Observable<Title[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserRegisterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserRegisterService>;
}

declare class UserProfileCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserProfileCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserProfileCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserProfileCoreModule>;
}

export { TITLE_NORMALIZER, USER_PROFILE_NORMALIZER, USER_PROFILE_SERIALIZER, USER_SERIALIZER, USER_SIGN_UP_SERIALIZER, UserEmailService, UserPasswordService, UserProfileAdapter, UserProfileConnector, UserProfileCoreModule, UserProfileService, UserRegisterService };
