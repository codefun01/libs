import { HttpClient } from '@angular/common/http';
import { OccEndpointsService, LoggerService, OccConfig } from '@spartacus/core';
import { Wishlist, WishlistEntry } from '@spartacus/user/wishlist/root';
import { UserWishlistAdapter } from '@spartacus/user/wishlist/core';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';

declare class OccUserWishlistAdapter implements UserWishlistAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected logger: LoggerService;
    getWishlist(userId: string): Observable<Wishlist>;
    addEntry(userId: string, wishlistId: string, productCode: string): Observable<WishlistEntry>;
    removeEntry(userId: string, wishlistId: string, entryId: string): Observable<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccUserWishlistAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccUserWishlistAdapter>;
}

declare const defaultOccUserWishlistConfig: OccConfig;

export { OccUserWishlistAdapter, defaultOccUserWishlistConfig };
