import { EventService, GlobalMessageService, CmsConfig, CxEvent } from '@spartacus/core';
import * as i0 from '@angular/core';
import { OnDestroy } from '@angular/core';
import { Subscription, Observable } from 'rxjs';

/**
 * User account event listener.
 */
declare class UserAccountEventListener implements OnDestroy {
    protected eventService: EventService;
    protected globalMessageService: GlobalMessageService;
    protected subscriptions: Subscription;
    constructor(eventService: EventService, globalMessageService: GlobalMessageService);
    /**
     * Registers events for the auth events.
     */
    protected onAuth(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAccountEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserAccountEventListener>;
}

declare class UserAccountEventModule {
    constructor(_userAccountEventListener: UserAccountEventListener);
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAccountEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserAccountEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserAccountEventModule>;
}

declare function defaultUserAccountComponentsConfig(): CmsConfig;
declare class UserAccountRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAccountRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserAccountRootModule, never, [typeof UserAccountEventModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserAccountRootModule>;
}

interface User {
    displayUid?: string;
    firstName?: string;
    lastName?: string;
    name?: string;
    uid?: string;
    customerId?: string;
    title?: string;
}

declare abstract class UserAccountFacade {
    abstract get(): Observable<User | undefined>;
    abstract getById(userId: string): Observable<User | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAccountFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserAccountFacade>;
}

declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        ACCOUNT_VERIFICATION_TOKEN = "ACCOUNT_VERIFICATION_TOKEN"
    }
}

interface VerificationTokenCreation {
    purpose: string;
    loginId: string;
    password?: string;
}
interface VerificationToken {
    expiresIn: string;
    tokenId: string;
}
declare enum VERIFICATION_TOKEN_DIALOG_ACTION {
    OK = "OK"
}

declare abstract class VerificationTokenFacade {
    abstract createVerificationToken(verificationTokenCreation: VerificationTokenCreation): Observable<VerificationToken>;
    static ɵfac: i0.ɵɵFactoryDeclaration<VerificationTokenFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VerificationTokenFacade>;
}

declare abstract class UserAccountEvent extends CxEvent {
    user: User;
}
declare class UserAccountChangedEvent extends UserAccountEvent {
    static readonly type = "UserAccountChangedEvent";
}

declare const USER_ACCOUNT_FEATURE = "userAccount";
declare const USER_ACCOUNT_CORE_FEATURE = "userAccountCore";

export { USER_ACCOUNT_CORE_FEATURE, USER_ACCOUNT_FEATURE, UserAccountChangedEvent, UserAccountEvent, UserAccountEventListener, UserAccountEventModule, UserAccountFacade, UserAccountRootModule, VERIFICATION_TOKEN_DIALOG_ACTION, VerificationTokenFacade, defaultUserAccountComponentsConfig };
export type { User, VerificationToken, VerificationTokenCreation };
