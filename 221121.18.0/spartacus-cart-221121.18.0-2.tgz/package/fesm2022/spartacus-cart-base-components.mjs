import * as i0 from '@angular/core';
import { Injectable, inject, Input, Directive, NgModule, ChangeDetectionStrategy, Component, HostListener, ComponentRef, ViewChild, Optional } from '@angular/core';
import { ReplaySubject, Subscription, race, of, combineLatest, merge } from 'rxjs';
import * as i1$1 from '@spartacus/cart/base/root';
import { AbstractOrderType, CartUiEventAddToCart, CartAddEntryFailEvent, CartAddEntrySuccessEvent, PromotionLocation, CartOutlets, CartItemContext, CartItemQuantityService, CartConfig, DeleteCartSuccessEvent, DeleteCartFailEvent, CartValidationStatusCode, OrderEntriesSource, ActiveCartOrderEntriesContextToken } from '@spartacus/cart/base/root';
import * as i1 from '@spartacus/storefront';
import { LAUNCH_CALLER, ICON_TYPE, IconComponent, OutletDirective, MediaComponent, ItemCounterComponent, PromotionsComponent, AtMessageDirective, FocusDirective, SpinnerComponent, IconModule, ItemCounterModule, OutletModule, FormErrorsModule, FormRequiredLegendComponent, AtMessageModule, MediaModule, PromotionsModule, provideOutlet, DIALOG_TYPE, SpinnerModule, KeyboardFocusModule, BtnLikeLinkModule, ProgressButtonComponent, ProgressButtonModule, PAGE_LAYOUT_HANDLER } from '@spartacus/storefront';
import { take, map, filter, switchMap, startWith, tap, shareReplay, withLatestFrom } from 'rxjs/operators';
import * as i2 from '@spartacus/core';
import { TranslatePipe, UrlPipe, FeatureDirective, ProductAvailabilityService, ProductCatalogService, ProductScope, isNotNullable, ProductTypes, I18nModule, FeaturesConfigModule, provideDefaultConfig, UrlModule, FeatureToggles, useFeatureStyles, GlobalMessageType } from '@spartacus/core';
import { NgIf, AsyncPipe, NgClass, NgFor, NgTemplateOutlet, CommonModule } from '@angular/common';
import * as i2$1 from '@angular/forms';
import { UntypedFormGroup, UntypedFormControl, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import * as i1$2 from '@angular/router';
import { RouterLink, RouterModule, NavigationEnd, NavigationCancel } from '@angular/router';
import { NgSelectModule } from '@ng-select/ng-select';
import * as i3 from '@spartacus/cart/base/core';
import { isEmpty } from '@spartacus/cart/base/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Context source for AbstractOrderContext. Default values represent the context
 * of an active cart
 *
 * AbstractOrderContext should be injected in child components.
 */
class AbstractOrderContextSource {
    constructor() {
        this.key$ = new ReplaySubject(1);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AbstractOrderContextSource, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AbstractOrderContextSource }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AbstractOrderContextSource, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Context for transporting information about an abstract order (active cart, saved cart, order, quote).
 */
class AbstractOrderContext {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AbstractOrderContext, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AbstractOrderContext }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AbstractOrderContext, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AbstractOrderContextDirective {
    constructor() {
        this.abstractOrderContextSource = inject(AbstractOrderContextSource);
    }
    ngOnChanges(changes) {
        const contextChanges = changes.cxAbstractOrderContext;
        if (contextChanges) {
            let abstractOrderKey;
            const type = contextChanges.currentValue.type;
            if (type === AbstractOrderType.CART) {
                abstractOrderKey = { type };
            }
            else {
                const id = contextChanges.currentValue.id;
                if (id) {
                    abstractOrderKey = { type, id };
                }
                else {
                    throw new Error('id required for order, quote or saved cart');
                }
            }
            this.abstractOrderContextSource.key$.next(abstractOrderKey);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AbstractOrderContextDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.23", type: AbstractOrderContextDirective, isStandalone: true, selector: "[cxAbstractOrderContext]", inputs: { cxAbstractOrderContext: "cxAbstractOrderContext" }, providers: [
            AbstractOrderContextSource,
            { provide: AbstractOrderContext, useExisting: AbstractOrderContextSource },
        ], usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AbstractOrderContextDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[cxAbstractOrderContext]',
                    providers: [
                        AbstractOrderContextSource,
                        { provide: AbstractOrderContext, useExisting: AbstractOrderContextSource },
                    ],
                }]
        }], propDecorators: { cxAbstractOrderContext: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AbstractOrderContextModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AbstractOrderContextModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: AbstractOrderContextModule, imports: [AbstractOrderContextDirective], exports: [AbstractOrderContextDirective] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AbstractOrderContextModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AbstractOrderContextModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [AbstractOrderContextDirective],
                    exports: [AbstractOrderContextDirective],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AddedToCartDialogEventListener {
    constructor(eventService, launchDialogService) {
        this.eventService = eventService;
        this.launchDialogService = launchDialogService;
        this.subscription = new Subscription();
        this.onAddToCart();
    }
    onAddToCart() {
        this.subscription.add(this.eventService.get(CartUiEventAddToCart).subscribe((event) => {
            this.openModal(event);
        }));
        this.subscription.add(this.eventService.get(CartAddEntryFailEvent).subscribe((event) => {
            this.closeModal(event);
        }));
    }
    /**
     * Opens modal based on CartUiEventAddToCart.
     * @param event Signals that a product has been added to the cart.
     */
    openModal(event) {
        const addToCartData = {
            productCode: event.productCode,
            quantity: event.quantity,
            numberOfEntriesBeforeAdd: event.numberOfEntriesBeforeAdd,
            pickupStoreName: event.pickupStoreName,
            addingEntryResult$: this.createCompletionObservable(),
        };
        const dialog = this.launchDialogService.openDialog(LAUNCH_CALLER.ADDED_TO_CART, event?.triggerElementRef, undefined, addToCartData);
        if (dialog) {
            dialog.pipe(take(1)).subscribe();
        }
    }
    createCompletionObservable() {
        // We subscribe early to result events using ReplaySubject(1)
        // to ensure no missed emissions even if the modal subscribes late.
        const addingEntryResult$ = new ReplaySubject(1);
        race([
            this.eventService.get(CartAddEntrySuccessEvent),
            this.eventService.get(CartAddEntryFailEvent),
        ]).subscribe((completionEvent) => addingEntryResult$.next(completionEvent));
        return addingEntryResult$;
    }
    closeModal(reason) {
        this.launchDialogService.closeDialog(reason);
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddedToCartDialogEventListener, deps: [{ token: i2.EventService }, { token: i1.LaunchDialogService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddedToCartDialogEventListener, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddedToCartDialogEventListener, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i2.EventService }, { type: i1.LaunchDialogService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartItemValidationWarningComponent {
    constructor(cartValidationFacade) {
        this.cartValidationFacade = cartValidationFacade;
        this.iconTypes = ICON_TYPE;
        this.isVisible = true;
        this.cartModification$ = this.cartValidationFacade
            .getValidationResults()
            .pipe(map((modificationList) => modificationList.find((modification) => modification.entry?.product?.code === this.code)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartItemValidationWarningComponent, deps: [{ token: i1$1.CartValidationFacade }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CartItemValidationWarningComponent, isStandalone: true, selector: "cx-cart-item-validation-warning", inputs: { code: "code" }, ngImport: i0, template: "<ng-container *ngIf=\"cartModification$ | async as cartModification\">\n  <div class=\"alert alert-info\" *ngIf=\"isVisible\">\n    <span class=\"alert-icon\">\n      <cx-icon [type]=\"iconTypes.INFO\"></cx-icon>\n    </span>\n    <span>\n      {{\n        'validation.' + cartModification.statusCode\n          | cxTranslate\n            : {\n                quantity: cartModification.quantityAdded,\n              }\n      }}\n    </span>\n\n    <button\n      class=\"close\"\n      type=\"button\"\n      title=\"{{ 'common.close' | cxTranslate }}\"\n      (click)=\"isVisible = !isVisible\"\n    >\n      <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n    </button>\n  </div>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartItemValidationWarningComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-cart-item-validation-warning', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, IconComponent, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"cartModification$ | async as cartModification\">\n  <div class=\"alert alert-info\" *ngIf=\"isVisible\">\n    <span class=\"alert-icon\">\n      <cx-icon [type]=\"iconTypes.INFO\"></cx-icon>\n    </span>\n    <span>\n      {{\n        'validation.' + cartModification.statusCode\n          | cxTranslate\n            : {\n                quantity: cartModification.quantityAdded,\n              }\n      }}\n    </span>\n\n    <button\n      class=\"close\"\n      type=\"button\"\n      title=\"{{ 'common.close' | cxTranslate }}\"\n      (click)=\"isVisible = !isVisible\"\n    >\n      <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n    </button>\n  </div>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: i1$1.CartValidationFacade }], propDecorators: { code: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Context source for `CartItemComponent`.
 *
 * `CartItemContext` should be injected instead in child components.
 */
class CartItemContextSource {
    constructor() {
        this.compact$ = new ReplaySubject(1);
        this.readonly$ = new ReplaySubject(1);
        this.item$ = new ReplaySubject(1);
        this.quantityControl$ = new ReplaySubject(1);
        this.location$ = new ReplaySubject(1);
        this.options$ = new ReplaySubject(1);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartItemContextSource, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartItemContextSource }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartItemContextSource, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartItemComponent {
    constructor(cartItemContextSource) {
        this.cartItemContextSource = cartItemContextSource;
        this.compact = false;
        this.readonly = false;
        this.promotionLocation = PromotionLocation.ActiveCart;
        // TODO: evaluate whether this is generic enough
        this.options = {
            isSaveForLater: false,
            optionalBtn: null,
            displayAddToCart: false,
        };
        this.iconTypes = ICON_TYPE;
        this.CartOutlets = CartOutlets;
    }
    ngOnChanges(changes) {
        if (changes?.compact) {
            this.cartItemContextSource.compact$.next(this.compact);
        }
        if (changes?.readonly) {
            this.cartItemContextSource.readonly$.next(this.readonly);
        }
        if (changes?.item) {
            this.cartItemContextSource.item$.next(this.item);
        }
        if (changes?.quantityControl) {
            this.cartItemContextSource.quantityControl$.next(this.quantityControl);
        }
        if (changes?.promotionLocation) {
            this.cartItemContextSource.location$.next(this.promotionLocation);
        }
        if (changes?.options) {
            this.cartItemContextSource.options$.next(this.options);
        }
    }
    isProductOutOfStock(product) {
        // TODO Move stocklevelstatuses across the app to an enum
        return (product &&
            product.stock &&
            product.stock.stockLevelStatus === 'outOfStock');
    }
    removeItem() {
        this.quantityControl.setValue(0);
        this.quantityControl.markAsDirty();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartItemComponent, deps: [{ token: CartItemContextSource }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CartItemComponent, isStandalone: true, selector: "cx-cart-item", inputs: { compact: "compact", item: "item", readonly: "readonly", quantityControl: "quantityControl", promotionLocation: "promotionLocation", options: "options" }, providers: [
            CartItemContextSource,
            { provide: CartItemContext, useExisting: CartItemContextSource },
        ], usesOnChanges: true, ngImport: i0, template: "<!-- Item Start Outlet -->\n<ng-template [cxOutlet]=\"CartOutlets.ITEM\">\n  <ng-template [cxOutlet]=\"CartOutlets.ITEM_CONFIGURATOR_ISSUES\"></ng-template>\n  <cx-cart-item-validation-warning\n    [code]=\"item.product?.code\"\n  ></cx-cart-item-validation-warning>\n  <div [ngClass]=\"compact ? 'cx-compact row' : 'row'\">\n    <!-- Item Image -->\n    <div class=\"col-2 cx-image-container\">\n      <a\n        [routerLink]=\"{ cxRoute: 'product', params: item.product } | cxUrl\"\n        tabindex=\"0\"\n      >\n        <cx-media\n          [container]=\"item.product?.images?.PRIMARY\"\n          format=\"cartIcon\"\n        ></cx-media>\n      </a>\n    </div>\n    <!-- Item Information -->\n    <div class=\"cx-info col-10\">\n      <div class=\"cx-info-container row\">\n        <!-- Item Description -->\n        <div [ngClass]=\"compact ? '' : ' col-md-3 col-lg-3 col-xl-5'\">\n          <div *ngIf=\"item.product?.name\" class=\"cx-name\">\n            <a\n              class=\"cx-link\"\n              [routerLink]=\"\n                { cxRoute: 'product', params: item.product } | cxUrl\n              \"\n              ><h3>{{ item.product?.name }}</h3></a\n            >\n          </div>\n          <div *ngIf=\"item.product?.code\" class=\"cx-code\">\n            {{ 'cartItems.id' | cxTranslate }} {{ item.product?.code }}\n          </div>\n\n          <!-- Item Details Outlet -->\n          <ng-template [cxOutlet]=\"CartOutlets.ITEM_DETAILS\"> </ng-template>\n\n          <!-- Variants -->\n          <ng-container *ngIf=\"item.product?.baseOptions?.length\">\n            <div\n              *ngFor=\"\n                let variant of item.product?.baseOptions[0]?.selected\n                  ?.variantOptionQualifiers\n              \"\n              class=\"cx-property\"\n            >\n              <div class=\"cx-label\" *ngIf=\"variant.name && variant.value\">\n                {{ variant.name }}: {{ variant.value }}\n              </div>\n            </div>\n          </ng-container>\n        </div>\n        <!-- Subscription Item Charges -->\n        <div\n          class=\"cx-price\"\n          [ngClass]=\"compact ? '' : ' col-md-3 col-lg-3 col-xl-2'\"\n        >\n          <ng-template\n            [cxOutlet]=\"CartOutlets.SUBSCRIPTION_PRICE_BODY\"\n            [cxOutletContext]=\"{\n              item: item,\n              parent: 'minicart',\n            }\"\n          >\n          </ng-template>\n        </div>\n        <!-- Item Price -->\n        <div\n          *ngIf=\"item.basePrice\"\n          class=\"cx-price\"\n          [ngClass]=\"compact ? '' : ' col-md-3 col-lg-3 col-xl-2'\"\n        >\n          <div\n            class=\"cx-label\"\n            [ngClass]=\"compact ? '' : ' d-block d-md-none d-lg-none d-xl-none'\"\n          >\n            {{ 'cartItems.itemPrice' | cxTranslate }}\n          </div>\n          <div *ngIf=\"item.basePrice\" class=\"cx-value\">\n            {{ item.basePrice?.formattedValue }}\n          </div>\n        </div>\n        <!-- Item Quantity -->\n        <div class=\"cx-quantity\" [ngClass]=\"compact ? '' : ' col-3'\">\n          <div\n            class=\"cx-label\"\n            [ngClass]=\"compact ? '' : ' d-block d-md-none d-lg-none d-xl-none'\"\n            placement=\"left\"\n            title=\"{{ 'cartItems.quantityTitle' | cxTranslate }}\"\n          >\n            {{ 'cartItems.quantityFull' | cxTranslate }}\n          </div>\n          <div class=\"cx-value\" [class.readonly-value]=\"readonly\">\n            <cx-item-counter\n              [control]=\"quantityControl\"\n              [readonly]=\"\n                !item.updateable || readonly || options.isSaveForLater\n              \"\n              [max]=\"item.product?.stock?.stockLevel\"\n              [allowZero]=\"true\"\n            >\n            </cx-item-counter>\n          </div>\n        </div>\n        <!-- Total -->\n        <ng-container *ngIf=\"options.isSaveForLater; else total\">\n          <div\n            class=\"cx-total\"\n            [ngClass]=\"compact ? '' : ' col-md-3 col-lg-3 col-xl-2'\"\n          >\n            <div\n              class=\"cx-label\"\n              [ngClass]=\"\n                compact ? '' : ' d-block d-md-none d-lg-none d-xl-none'\n              \"\n            >\n              {{ 'saveForLaterItems.stock' | cxTranslate }}\n            </div>\n            <div\n              *ngIf=\"item.product?.stock.stockLevel >= 0; else forceInstock\"\n              class=\"cx-value\"\n            >\n              {{ item.product?.stock?.stockLevel }}\n            </div>\n            <ng-template #forceInstock>\n              <div class=\"cx-value\">\n                {{ 'saveForLaterItems.forceInStock' | cxTranslate }}\n              </div>\n            </ng-template>\n          </div>\n        </ng-container>\n      </div>\n      <!-- Availability -->\n      <div\n        *ngIf=\"isProductOutOfStock(item.product)\"\n        class=\"cx-availability col-12\"\n      >\n        {{ 'addToCart.outOfStock' | cxTranslate }}\n      </div>\n\n      <!-- Item Bundle Details Outlet -->\n      <ng-template [cxOutlet]=\"CartOutlets.ITEM_BUNDLE_DETAILS\"> </ng-template>\n\n      <!-- Promotion -->\n\n      <cx-promotions [promotions]=\"item.promotions\"></cx-promotions>\n\n      <!-- Actions -->\n      <div\n        *ngIf=\"(!readonly || options.isSaveForLater) && item.updateable\"\n        class=\"cx-actions col-12\"\n      >\n        <ng-container *ngIf=\"!isProductOutOfStock(item.product)\">\n          <ng-container\n            *ngTemplateOutlet=\"\n              options.optionalBtn;\n              context: {\n                $implicit: { loading: quantityControl.disabled, item: item },\n              }\n            \"\n          ></ng-container>\n        </ng-container>\n\n        <div class=\"col-md-3 cx-remove-btn\">\n          <button\n            (click)=\"removeItem()\"\n            [cxAtMessage]=\"'cartItems.itemRemoved' | cxTranslate\"\n            [disabled]=\"quantityControl.disabled\"\n            attr.aria-label=\"{{ 'addToCart.removeFromCart' | cxTranslate }}\"\n            class=\"btn btn-tertiary\"\n          >\n            {{ 'common.remove' | cxTranslate }}\n          </button>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <ng-template #total>\n    <div\n      *ngIf=\"item.totalPrice\"\n      class=\"cx-total\"\n      [ngClass]=\"compact ? '' : ' col-md-3 col-xl-2'\"\n    >\n      <div\n        class=\"cx-label\"\n        [ngClass]=\"compact ? '' : ' d-block d-md-none d-lg-none d-xl-none'\"\n      >\n        {{ 'cartItems.total' | cxTranslate }}\n      </div>\n      <div class=\"cx-value\">{{ item.totalPrice.formattedValue }}</div>\n    </div>\n  </ng-template>\n</ng-template>\n", dependencies: [{ kind: "directive", type: OutletDirective, selector: "[cxOutlet]", inputs: ["cxOutlet", "cxOutletContext", "cxOutletDefer", "cxComponentRef"], outputs: ["loaded", "cxComponentRefChange"] }, { kind: "component", type: CartItemValidationWarningComponent, selector: "cx-cart-item-validation-warning", inputs: ["code"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: MediaComponent, selector: "cx-media", inputs: ["container", "format", "alt", "role", "loading", "fetchPriority", "elementType", "sizesForImgElement"], outputs: ["loaded"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: ItemCounterComponent, selector: "cx-item-counter", inputs: ["control", "min", "max", "step", "allowZero", "ariaDescribedById", "readonly"] }, { kind: "component", type: PromotionsComponent, selector: "cx-promotions", inputs: ["promotions"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: AtMessageDirective, selector: "[cxAtMessage]", inputs: ["cxAtMessage"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-cart-item', providers: [
                        CartItemContextSource,
                        { provide: CartItemContext, useExisting: CartItemContextSource },
                    ], imports: [
                        OutletDirective,
                        CartItemValidationWarningComponent,
                        NgClass,
                        RouterLink,
                        MediaComponent,
                        NgIf,
                        NgFor,
                        ItemCounterComponent,
                        PromotionsComponent,
                        NgTemplateOutlet,
                        AtMessageDirective,
                        TranslatePipe,
                        UrlPipe,
                    ], template: "<!-- Item Start Outlet -->\n<ng-template [cxOutlet]=\"CartOutlets.ITEM\">\n  <ng-template [cxOutlet]=\"CartOutlets.ITEM_CONFIGURATOR_ISSUES\"></ng-template>\n  <cx-cart-item-validation-warning\n    [code]=\"item.product?.code\"\n  ></cx-cart-item-validation-warning>\n  <div [ngClass]=\"compact ? 'cx-compact row' : 'row'\">\n    <!-- Item Image -->\n    <div class=\"col-2 cx-image-container\">\n      <a\n        [routerLink]=\"{ cxRoute: 'product', params: item.product } | cxUrl\"\n        tabindex=\"0\"\n      >\n        <cx-media\n          [container]=\"item.product?.images?.PRIMARY\"\n          format=\"cartIcon\"\n        ></cx-media>\n      </a>\n    </div>\n    <!-- Item Information -->\n    <div class=\"cx-info col-10\">\n      <div class=\"cx-info-container row\">\n        <!-- Item Description -->\n        <div [ngClass]=\"compact ? '' : ' col-md-3 col-lg-3 col-xl-5'\">\n          <div *ngIf=\"item.product?.name\" class=\"cx-name\">\n            <a\n              class=\"cx-link\"\n              [routerLink]=\"\n                { cxRoute: 'product', params: item.product } | cxUrl\n              \"\n              ><h3>{{ item.product?.name }}</h3></a\n            >\n          </div>\n          <div *ngIf=\"item.product?.code\" class=\"cx-code\">\n            {{ 'cartItems.id' | cxTranslate }} {{ item.product?.code }}\n          </div>\n\n          <!-- Item Details Outlet -->\n          <ng-template [cxOutlet]=\"CartOutlets.ITEM_DETAILS\"> </ng-template>\n\n          <!-- Variants -->\n          <ng-container *ngIf=\"item.product?.baseOptions?.length\">\n            <div\n              *ngFor=\"\n                let variant of item.product?.baseOptions[0]?.selected\n                  ?.variantOptionQualifiers\n              \"\n              class=\"cx-property\"\n            >\n              <div class=\"cx-label\" *ngIf=\"variant.name && variant.value\">\n                {{ variant.name }}: {{ variant.value }}\n              </div>\n            </div>\n          </ng-container>\n        </div>\n        <!-- Subscription Item Charges -->\n        <div\n          class=\"cx-price\"\n          [ngClass]=\"compact ? '' : ' col-md-3 col-lg-3 col-xl-2'\"\n        >\n          <ng-template\n            [cxOutlet]=\"CartOutlets.SUBSCRIPTION_PRICE_BODY\"\n            [cxOutletContext]=\"{\n              item: item,\n              parent: 'minicart',\n            }\"\n          >\n          </ng-template>\n        </div>\n        <!-- Item Price -->\n        <div\n          *ngIf=\"item.basePrice\"\n          class=\"cx-price\"\n          [ngClass]=\"compact ? '' : ' col-md-3 col-lg-3 col-xl-2'\"\n        >\n          <div\n            class=\"cx-label\"\n            [ngClass]=\"compact ? '' : ' d-block d-md-none d-lg-none d-xl-none'\"\n          >\n            {{ 'cartItems.itemPrice' | cxTranslate }}\n          </div>\n          <div *ngIf=\"item.basePrice\" class=\"cx-value\">\n            {{ item.basePrice?.formattedValue }}\n          </div>\n        </div>\n        <!-- Item Quantity -->\n        <div class=\"cx-quantity\" [ngClass]=\"compact ? '' : ' col-3'\">\n          <div\n            class=\"cx-label\"\n            [ngClass]=\"compact ? '' : ' d-block d-md-none d-lg-none d-xl-none'\"\n            placement=\"left\"\n            title=\"{{ 'cartItems.quantityTitle' | cxTranslate }}\"\n          >\n            {{ 'cartItems.quantityFull' | cxTranslate }}\n          </div>\n          <div class=\"cx-value\" [class.readonly-value]=\"readonly\">\n            <cx-item-counter\n              [control]=\"quantityControl\"\n              [readonly]=\"\n                !item.updateable || readonly || options.isSaveForLater\n              \"\n              [max]=\"item.product?.stock?.stockLevel\"\n              [allowZero]=\"true\"\n            >\n            </cx-item-counter>\n          </div>\n        </div>\n        <!-- Total -->\n        <ng-container *ngIf=\"options.isSaveForLater; else total\">\n          <div\n            class=\"cx-total\"\n            [ngClass]=\"compact ? '' : ' col-md-3 col-lg-3 col-xl-2'\"\n          >\n            <div\n              class=\"cx-label\"\n              [ngClass]=\"\n                compact ? '' : ' d-block d-md-none d-lg-none d-xl-none'\n              \"\n            >\n              {{ 'saveForLaterItems.stock' | cxTranslate }}\n            </div>\n            <div\n              *ngIf=\"item.product?.stock.stockLevel >= 0; else forceInstock\"\n              class=\"cx-value\"\n            >\n              {{ item.product?.stock?.stockLevel }}\n            </div>\n            <ng-template #forceInstock>\n              <div class=\"cx-value\">\n                {{ 'saveForLaterItems.forceInStock' | cxTranslate }}\n              </div>\n            </ng-template>\n          </div>\n        </ng-container>\n      </div>\n      <!-- Availability -->\n      <div\n        *ngIf=\"isProductOutOfStock(item.product)\"\n        class=\"cx-availability col-12\"\n      >\n        {{ 'addToCart.outOfStock' | cxTranslate }}\n      </div>\n\n      <!-- Item Bundle Details Outlet -->\n      <ng-template [cxOutlet]=\"CartOutlets.ITEM_BUNDLE_DETAILS\"> </ng-template>\n\n      <!-- Promotion -->\n\n      <cx-promotions [promotions]=\"item.promotions\"></cx-promotions>\n\n      <!-- Actions -->\n      <div\n        *ngIf=\"(!readonly || options.isSaveForLater) && item.updateable\"\n        class=\"cx-actions col-12\"\n      >\n        <ng-container *ngIf=\"!isProductOutOfStock(item.product)\">\n          <ng-container\n            *ngTemplateOutlet=\"\n              options.optionalBtn;\n              context: {\n                $implicit: { loading: quantityControl.disabled, item: item },\n              }\n            \"\n          ></ng-container>\n        </ng-container>\n\n        <div class=\"col-md-3 cx-remove-btn\">\n          <button\n            (click)=\"removeItem()\"\n            [cxAtMessage]=\"'cartItems.itemRemoved' | cxTranslate\"\n            [disabled]=\"quantityControl.disabled\"\n            attr.aria-label=\"{{ 'addToCart.removeFromCart' | cxTranslate }}\"\n            class=\"btn btn-tertiary\"\n          >\n            {{ 'common.remove' | cxTranslate }}\n          </button>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <ng-template #total>\n    <div\n      *ngIf=\"item.totalPrice\"\n      class=\"cx-total\"\n      [ngClass]=\"compact ? '' : ' col-md-3 col-xl-2'\"\n    >\n      <div\n        class=\"cx-label\"\n        [ngClass]=\"compact ? '' : ' d-block d-md-none d-lg-none d-xl-none'\"\n      >\n        {{ 'cartItems.total' | cxTranslate }}\n      </div>\n      <div class=\"cx-value\">{{ item.totalPrice.formattedValue }}</div>\n    </div>\n  </ng-template>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: CartItemContextSource }], propDecorators: { compact: [{
                type: Input
            }], item: [{
                type: Input
            }], readonly: [{
                type: Input
            }], quantityControl: [{
                type: Input
            }], promotionLocation: [{
                type: Input
            }], options: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AddedToCartDialogComponent {
    handleClick(event) {
        if (event.target.tagName === this.el.nativeElement.tagName) {
            this.dismissModal('Cross click');
        }
    }
    constructor(activeCartFacade, launchDialogService, routingService, el) {
        this.activeCartFacade = activeCartFacade;
        this.launchDialogService = launchDialogService;
        this.routingService = routingService;
        this.el = el;
        this.iconTypes = ICON_TYPE;
        this.cart$ = this.activeCartFacade.getActive();
        this.loaded$ = this.activeCartFacade.isStable();
        this.promotionLocation = PromotionLocation.ActiveCart;
        this.quantity = 0;
        this.form = new UntypedFormGroup({});
        this.focusConfig = {
            trap: true,
            block: true,
            autofocus: 'button',
            focusOnEscape: true,
        };
        this.subscription = new Subscription();
    }
    ngOnInit() {
        this.subscription.add(this.launchDialogService.data$.subscribe((dialogData) => {
            this.init(dialogData.productCode, dialogData.quantity, dialogData.numberOfEntriesBeforeAdd, dialogData.pickupStoreName, dialogData.addingEntryResult$);
        }));
        this.subscription.add(this.routingService
            .getRouterState()
            .pipe(filter((state) => !!state.nextState))
            .subscribe(() => this.dismissModal('dismiss')));
    }
    /**
     * Returns an observable formControl with the quantity of the cartEntry,
     * but also updates the entry in case of a changed value.
     * The quantity can be set to zero in order to remove the entry.
     */
    getQuantityControl() {
        if (!this.quantityControl$) {
            this.quantityControl$ = this.entry$.pipe(filter((e) => !!e), map((entry) => this.getQuantityFormControl(entry)), switchMap(() => this.form.valueChanges.pipe(
            // eslint-disable-next-line import/no-deprecated
            startWith(null), tap((valueChange) => {
                if (valueChange) {
                    this.activeCartFacade.updateEntry(valueChange.entryNumber, valueChange.quantity);
                    if (valueChange.quantity === 0) {
                        this.dismissModal('Removed');
                    }
                }
                else {
                    this.form.markAsPristine();
                }
            }))), map(() => this.form.get('quantity')), shareReplay({ bufferSize: 1, refCount: true }));
        }
        return this.quantityControl$;
    }
    init(productCode, quantity, numberOfEntriesBeforeAdd, pickupStoreName, addingEntryResult$) {
        // Display last entry for new product code. This always corresponds to
        // our new item, independently of whether merging occured or not
        const productCode$ = addingEntryResult$
            ? // get the product code from the backend response, because it might be different
                // from the requested product code. That can e.g. happen for certain kinds of product variants
                addingEntryResult$.pipe(filter((event) => event instanceof CartAddEntrySuccessEvent), map((event) => {
                    const productCodeFromEntry = event
                        .entry?.product?.code;
                    return productCodeFromEntry
                        ? productCodeFromEntry
                        : event.productCode;
                }))
            : of(productCode);
        this.entry$ = productCode$.pipe(switchMap((code) => this.activeCartFacade.getLastEntry(code)));
        this.quantity = quantity;
        this.pickupStoreName = pickupStoreName;
        this.addedEntryWasMerged$ = this.getAddedEntryWasMerged(numberOfEntriesBeforeAdd);
    }
    /**
     * Determines if the added entry was merged with an existing one.
     *
     * @param numberOfEntriesBeforeAdd Number of entries in cart before addToCart has been performed
     * @returns Has entry been merged?
     */
    getAddedEntryWasMerged(numberOfEntriesBeforeAdd) {
        return this.loaded$.pipe(filter((loaded) => loaded), switchMap(() => this.activeCartFacade.getEntries()), map((entries) => entries.length === numberOfEntriesBeforeAdd));
    }
    /**
     * Adds quantity and entryNumber form controls to the FormGroup.
     * Returns quantity form control.
     */
    getQuantityFormControl(entry) {
        if (!this.form.get('quantity')) {
            const quantity = new UntypedFormControl(entry?.quantity, {
                updateOn: 'blur',
            });
            this.form.addControl('quantity', quantity);
            const entryNumber = new UntypedFormControl(entry?.entryNumber);
            this.form.addControl('entryNumber', entryNumber);
        }
        else {
            // set the real quantity added to cart
            this.form.get('quantity')?.setValue(entry?.quantity);
        }
        return this.form.get('quantity');
    }
    dismissModal(reason) {
        this.launchDialogService.closeDialog(reason);
    }
    onAction(action) {
        const actionDetails = {
            viewCart: {
                reason: 'View Cart click',
                cxRoute: 'cart',
            },
            checkout: {
                reason: 'Proceed To Checkout click',
                cxRoute: 'checkout',
            },
        };
        const { reason, cxRoute } = actionDetails[action];
        this.routingService.go({ cxRoute });
        this.dismissModal(reason);
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddedToCartDialogComponent, deps: [{ token: i1$1.ActiveCartFacade }, { token: i1.LaunchDialogService }, { token: i2.RoutingService }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: AddedToCartDialogComponent, isStandalone: true, selector: "cx-added-to-cart-dialog", host: { listeners: { "click": "handleClick($event)" } }, ngImport: i0, template: "<div\n  class=\"cx-modal-container\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"dismissModal('Escape pressed')\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <div class=\"cx-modal-content\">\n    <!-- Modal Header -->\n    <div\n      aria-live=\"polite\"\n      aria-atomic=\"true\"\n      class=\"cx-dialog-header modal-header\"\n    >\n      <ng-container *cxFeature=\"'!a11yAddedToCartDialogHeading'\">\n        <div id=\"dialogTitle\" class=\"cx-dialog-title modal-title\" role=\"none\">\n          {{ 'addToCart.itemAddedToYourCart' | cxTranslate }}\n        </div>\n      </ng-container>\n      <ng-container *cxFeature=\"'a11yAddedToCartDialogHeading'\">\n        <h2 id=\"dialogTitle\" class=\"cx-dialog-title modal-title\">\n          {{ 'addToCart.itemAddedToYourCart' | cxTranslate }}\n        </h2>\n      </ng-container>\n\n      <button\n        type=\"button\"\n        class=\"close\"\n        title=\"{{ 'common.close' | cxTranslate }}\"\n        attr.aria-label=\"{{ 'addToCart.closeModal' | cxTranslate }}\"\n        (click)=\"dismissModal('Cross click')\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n        </span>\n      </button>\n    </div>\n\n    <!-- Modal Body -->\n    <ng-container *ngIf=\"loaded$ | async; else loading\">\n      <div class=\"cx-dialog-body modal-body\" *ngIf=\"entry$ | async as entry\">\n        <div class=\"cx-dialog-row\">\n          <div class=\"cx-dialog-item col-sm-12 col-md-6\">\n            <cx-cart-item\n              [item]=\"entry\"\n              [compact]=\"true\"\n              [quantityControl]=\"getQuantityControl() | async\"\n              [promotionLocation]=\"promotionLocation\"\n            ></cx-cart-item>\n            <div class=\"cx-dialog-pickup-store\" *ngIf=\"pickupStoreName\">\n              {{ 'pickupOptionDialog.modalHeader' | cxTranslate }}:\n              <span class=\"cx-dialog-pickup-store-name\">{{\n                pickupStoreName\n              }}</span>\n            </div>\n          </div>\n          <!-- Separator -->\n          <div\n            class=\"cx-dialog-separator col-sm-12 d-xs-block d-sm-block d-md-none\"\n          ></div>\n          <!-- Total container -->\n          <div\n            class=\"cx-dialog-actions col-sm-12 col-md-6\"\n            *ngIf=\"cart$ | async as cart\"\n          >\n            <div class=\"cx-dialog-total\">\n              <div>\n                {{\n                  'cartItems.cartTotal'\n                    | cxTranslate: { count: cart.totalUnitCount }\n                }}\n              </div>\n\n              <div>{{ cart.subTotal?.formattedValue }}</div>\n            </div>\n\n            <!-- Promotions -->\n            <div class=\"cx-dialog-promotions\">\n              <cx-promotions\n                [promotions]=\"\n                  (cart.appliedOrderPromotions || []).concat(\n                    cart.potentialOrderPromotions || []\n                  )\n                \"\n              ></cx-promotions>\n            </div>\n\n            <!-- Actions -->\n            <div class=\"cx-dialog-buttons\">\n              <button\n                [class.disabled]=\"form.dirty\"\n                (click)=\"onAction('viewCart')\"\n                class=\"btn btn-primary\"\n                autofocus\n              >\n                {{ 'addToCart.viewCart' | cxTranslate }}\n              </button>\n              <button\n                [class.disabled]=\"form.dirty\"\n                (click)=\"onAction('checkout')\"\n                class=\"btn btn-secondary\"\n              >\n                {{ 'addToCart.proceedToCheckout' | cxTranslate }}\n              </button>\n            </div>\n          </div>\n        </div>\n      </div>\n    </ng-container>\n  </div>\n\n  <!-- Modal Body -->\n  <ng-template #loading>\n    <div class=\"cx-dialog-body modal-body\">\n      <div class=\"cx-dialog-row\">\n        <div class=\"col-sm-12\">\n          <cx-spinner aria-hidden=\"true\"></cx-spinner>\n        </div>\n      </div>\n    </div>\n  </ng-template>\n</div>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CartItemComponent, selector: "cx-cart-item", inputs: ["compact", "item", "readonly", "quantityControl", "promotionLocation", "options"] }, { kind: "component", type: PromotionsComponent, selector: "cx-promotions", inputs: ["promotions"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "directive", type: FeatureDirective, selector: "[cxFeature]", inputs: ["cxFeature"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddedToCartDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-added-to-cart-dialog', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        FocusDirective,
                        IconComponent,
                        NgIf,
                        CartItemComponent,
                        PromotionsComponent,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                        FeatureDirective,
                    ], template: "<div\n  class=\"cx-modal-container\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"dismissModal('Escape pressed')\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <div class=\"cx-modal-content\">\n    <!-- Modal Header -->\n    <div\n      aria-live=\"polite\"\n      aria-atomic=\"true\"\n      class=\"cx-dialog-header modal-header\"\n    >\n      <ng-container *cxFeature=\"'!a11yAddedToCartDialogHeading'\">\n        <div id=\"dialogTitle\" class=\"cx-dialog-title modal-title\" role=\"none\">\n          {{ 'addToCart.itemAddedToYourCart' | cxTranslate }}\n        </div>\n      </ng-container>\n      <ng-container *cxFeature=\"'a11yAddedToCartDialogHeading'\">\n        <h2 id=\"dialogTitle\" class=\"cx-dialog-title modal-title\">\n          {{ 'addToCart.itemAddedToYourCart' | cxTranslate }}\n        </h2>\n      </ng-container>\n\n      <button\n        type=\"button\"\n        class=\"close\"\n        title=\"{{ 'common.close' | cxTranslate }}\"\n        attr.aria-label=\"{{ 'addToCart.closeModal' | cxTranslate }}\"\n        (click)=\"dismissModal('Cross click')\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n        </span>\n      </button>\n    </div>\n\n    <!-- Modal Body -->\n    <ng-container *ngIf=\"loaded$ | async; else loading\">\n      <div class=\"cx-dialog-body modal-body\" *ngIf=\"entry$ | async as entry\">\n        <div class=\"cx-dialog-row\">\n          <div class=\"cx-dialog-item col-sm-12 col-md-6\">\n            <cx-cart-item\n              [item]=\"entry\"\n              [compact]=\"true\"\n              [quantityControl]=\"getQuantityControl() | async\"\n              [promotionLocation]=\"promotionLocation\"\n            ></cx-cart-item>\n            <div class=\"cx-dialog-pickup-store\" *ngIf=\"pickupStoreName\">\n              {{ 'pickupOptionDialog.modalHeader' | cxTranslate }}:\n              <span class=\"cx-dialog-pickup-store-name\">{{\n                pickupStoreName\n              }}</span>\n            </div>\n          </div>\n          <!-- Separator -->\n          <div\n            class=\"cx-dialog-separator col-sm-12 d-xs-block d-sm-block d-md-none\"\n          ></div>\n          <!-- Total container -->\n          <div\n            class=\"cx-dialog-actions col-sm-12 col-md-6\"\n            *ngIf=\"cart$ | async as cart\"\n          >\n            <div class=\"cx-dialog-total\">\n              <div>\n                {{\n                  'cartItems.cartTotal'\n                    | cxTranslate: { count: cart.totalUnitCount }\n                }}\n              </div>\n\n              <div>{{ cart.subTotal?.formattedValue }}</div>\n            </div>\n\n            <!-- Promotions -->\n            <div class=\"cx-dialog-promotions\">\n              <cx-promotions\n                [promotions]=\"\n                  (cart.appliedOrderPromotions || []).concat(\n                    cart.potentialOrderPromotions || []\n                  )\n                \"\n              ></cx-promotions>\n            </div>\n\n            <!-- Actions -->\n            <div class=\"cx-dialog-buttons\">\n              <button\n                [class.disabled]=\"form.dirty\"\n                (click)=\"onAction('viewCart')\"\n                class=\"btn btn-primary\"\n                autofocus\n              >\n                {{ 'addToCart.viewCart' | cxTranslate }}\n              </button>\n              <button\n                [class.disabled]=\"form.dirty\"\n                (click)=\"onAction('checkout')\"\n                class=\"btn btn-secondary\"\n              >\n                {{ 'addToCart.proceedToCheckout' | cxTranslate }}\n              </button>\n            </div>\n          </div>\n        </div>\n      </div>\n    </ng-container>\n  </div>\n\n  <!-- Modal Body -->\n  <ng-template #loading>\n    <div class=\"cx-dialog-body modal-body\">\n      <div class=\"cx-dialog-row\">\n        <div class=\"col-sm-12\">\n          <cx-spinner aria-hidden=\"true\"></cx-spinner>\n        </div>\n      </div>\n    </div>\n  </ng-template>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1$1.ActiveCartFacade }, { type: i1.LaunchDialogService }, { type: i2.RoutingService }, { type: i0.ElementRef }], propDecorators: { handleClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AddToCartComponent {
    /**
     * We disable the dialog launch on quantity input,
     * as it causes an unexpected change of context.
     * The expectation is only for the quantity to get updated in the Qty field.
     */
    handleKeyboardEvent(event) {
        const eventTarget = event.target;
        const isQuantityInput = eventTarget.ariaLabel === 'Quantity' && eventTarget.tagName === 'INPUT';
        if (event.key === 'Enter' && isQuantityInput) {
            event.preventDefault();
        }
    }
    constructor(currentProductService, cd, activeCartService, component, eventService, productListItemContext) {
        this.currentProductService = currentProductService;
        this.cd = cd;
        this.activeCartService = activeCartService;
        this.component = component;
        this.eventService = eventService;
        this.productListItemContext = productListItemContext;
        this.showQuantity = true;
        this.disabled = false;
        this.hasStock = false;
        this.inventoryThreshold = false;
        this.showInventory$ = this.component?.data$.pipe(map((data) => data.inventoryDisplay));
        this.unavailable = false;
        this.quantity = 1;
        this.subscription = new Subscription();
        this.addToCartForm = new UntypedFormGroup({
            quantity: new UntypedFormControl(1, { updateOn: 'blur' }),
        });
        this.CartOutlets = CartOutlets;
        this.iconTypes = ICON_TYPE;
        this.productAvailabilityService = inject(ProductAvailabilityService);
        this.productCatalogService = inject(ProductCatalogService);
        this.cartItemQuantityService = inject(CartItemQuantityService);
        this.realTimeStockEnabled = !!inject(CartConfig).cart?.showRealTimeStockInPDP?.enabled;
    }
    ngOnInit() {
        this.subscribeToQuantityChanges();
        if (this.product) {
            this.productCode = this.product.code ?? '';
            this.setStockInfo(this.product);
            this.unavailable = !this.productCatalogService.isProductInCatalog(this.product);
        }
        else if (this.productCode) {
            // force hasStock and quantity for the time being, as we do not have more info:
            this.quantity = 1;
            this.hasStock = true;
            this.cd.markForCheck();
        }
        else {
            let product$;
            if (this.productListItemContext) {
                product$ = this.productListItemContext.product$;
            }
            else if (this.realTimeStockEnabled) {
                product$ = this.currentProductService.getProduct([
                    ProductScope.UNIT,
                    ProductScope.DETAILS,
                ]);
            }
            else {
                product$ = this.currentProductService.getProduct();
            }
            this.subscription.add(product$.pipe(filter(isNotNullable)).subscribe((product) => {
                this.productCode = product.code ?? '';
                this.product = product;
                this.setStockInfo(product);
                this.unavailable =
                    !this.productCatalogService.isProductInCatalog(product);
            }));
        }
    }
    subscribeToQuantityChanges() {
        this.subscription.add(this.addToCartForm
            .get('quantity')
            ?.valueChanges.pipe(startWith(this.addToCartForm.get('quantity')?.value))
            .subscribe((quantity) => this.cartItemQuantityService.setQuantity(quantity ?? 1)));
    }
    setStockInfo(product) {
        this.quantity = 1;
        this.addToCartForm.controls['quantity'].setValue(1);
        this.inventoryThreshold = product.stock?.isValueRounded ?? false;
        if (this.productListItemContext) {
            this.showQuantity = false;
        }
        if (this.realTimeStockEnabled && product.sapUnit?.sapCode) {
            this.productAvailabilityService
                .getRealTimeStock(this.productCode, product.sapUnit?.sapCode)
                .pipe(take(1))
                .subscribe(({ quantity, status }) => {
                this.maxQuantity = Number(quantity);
                this.hasStock = Boolean(status && status !== 'OUT_OF_STOCK');
                this.cd.markForCheck();
            });
        }
        else {
            this.hasStock = Boolean(product.stock?.stockLevelStatus !== 'outOfStock');
            if (this.hasStock && product.stock?.stockLevel) {
                this.maxQuantity = product.stock.stockLevel;
            }
            this.cd.markForCheck();
        }
    }
    /**
     * In specific scenarios, we need to omit displaying the stock level or append a plus to the value.
     * When backoffice forces a product to be in stock, omit showing the stock level.
     * When product stock level is limited by a threshold value, append '+' at the end.
     * When out of stock, display no numerical value.
     */
    getInventory() {
        if (this.hasStock &&
            this.product.productTypes !== ProductTypes.SUBSCRIPTION) {
            const quantityDisplay = this.maxQuantity
                ? this.maxQuantity.toString()
                : '';
            return this.inventoryThreshold ? quantityDisplay + '+' : quantityDisplay;
        }
        else {
            return '';
        }
    }
    updateCount(value) {
        this.quantity = value;
    }
    addToCart() {
        let quantity = 0;
        if (this.savedCart) {
            quantity = this.getQuantityFromSavedCart(this.productCode);
        }
        else {
            quantity = this.addToCartForm.get('quantity')?.value;
        }
        if (!this.productCode || quantity <= 0) {
            return;
        }
        if (this.pickupOptionCompRef instanceof ComponentRef) {
            this.pickupOptionCompRef.instance.intendedPickupLocation$
                .pipe(take(1))
                .subscribe((intendedPickupLocation) => {
                this.pickupStore =
                    intendedPickupLocation?.pickupOption === 'pickup'
                        ? intendedPickupLocation.name
                        : undefined;
            });
        }
        this.activeCartService
            .getEntries()
            .pipe(take(1))
            .subscribe((cartEntries) => {
            this.activeCartService.addEntry(this.productCode, quantity, this.pickupStore);
            // A CartUiEventAddToCart is dispatched.  This event is intended for the UI
            // responsible to provide feedback about what was added to the cart, like
            // the added to cart dialog.
            //
            // Because we call activeCartService.getEntries() before, we can be sure the
            // cart library is loaded already and that the event listener exists.
            this.eventService.dispatch(this.createCartUiEventAddToCart(this.productCode, quantity, cartEntries.length, this.pickupStore));
        });
    }
    createCartUiEventAddToCart(productCode, quantity, numberOfEntriesBeforeAdd, storeName) {
        const newEvent = new CartUiEventAddToCart();
        newEvent.productCode = productCode;
        newEvent.quantity = quantity;
        newEvent.numberOfEntriesBeforeAdd = numberOfEntriesBeforeAdd;
        newEvent.pickupStoreName = storeName;
        newEvent.triggerElementRef = this.addToCartDialogTriggerEl;
        return newEvent;
    }
    onPickupOptionsCompLoaded() {
        if (this.pickupOptionCompRef instanceof ComponentRef) {
            this.subscription.add(this.pickupOptionCompRef.instance.intendedPickupChange.subscribe((intendedPickupLocation) => {
                this.disabled =
                    intendedPickupLocation?.pickupOption === 'pickup' &&
                        !intendedPickupLocation.displayName;
            }));
        }
    }
    getQuantityFromSavedCart(productCode) {
        return (this.savedCart?.entries?.find((e) => e?.product?.code === productCode)
            ?.quantity ?? 0);
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddToCartComponent, deps: [{ token: i1.CurrentProductService }, { token: i0.ChangeDetectorRef }, { token: i1$1.ActiveCartFacade }, { token: i1.CmsComponentData }, { token: i2.EventService }, { token: i1.ProductListItemContext, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: AddToCartComponent, isStandalone: true, selector: "cx-add-to-cart", inputs: { productCode: "productCode", showQuantity: "showQuantity", options: "options", pickupStore: "pickupStore", savedCart: "savedCart", product: "product" }, host: { listeners: { "document:keydown": "handleKeyboardEvent($event)" } }, viewQueries: [{ propertyName: "addToCartDialogTriggerEl", first: true, predicate: ["addToCartDialogTriggerEl"], descendants: true }], ngImport: i0, template: "<form *ngIf=\"productCode\" [formGroup]=\"addToCartForm\" (submit)=\"addToCart()\">\n  <div class=\"quantity\" *ngIf=\"showQuantity\">\n    <label>{{ 'addToCart.quantityFull' | cxTranslate }}</label>\n    <div class=\"cx-counter-stock\">\n      <cx-item-counter\n        *ngIf=\"hasStock\"\n        [max]=\"maxQuantity\"\n        [control]=\"addToCartForm.get('quantity')\"\n        [ariaDescribedById]=\"'add-to-card-stock-info'\"\n      ></cx-item-counter>\n\n      <span class=\"info\" id=\"add-to-card-stock-info\">\n        <span *ngIf=\"showInventory$ | async\">{{ getInventory() }}</span>\n        {{\n          hasStock\n            ? ('addToCart.inStock' | cxTranslate)\n            : ('addToCart.outOfStock' | cxTranslate)\n        }}</span\n      >\n    </div>\n  </div>\n\n  <ng-container *ngIf=\"hasStock\">\n    <ng-template\n      [cxOutlet]=\"CartOutlets.ADD_TO_CART_PICKUP_OPTION\"\n      [(cxComponentRef)]=\"pickupOptionCompRef\"\n      (cxComponentRefChange)=\"onPickupOptionsCompLoaded()\"\n    ></ng-template>\n  </ng-container>\n\n  <button\n    #addToCartDialogTriggerEl\n    *ngIf=\"hasStock\"\n    [ngClass]=\"\n      options?.displayAddToCart\n        ? 'btn btn-tertiary'\n        : 'btn btn-primary btn-block'\n    \"\n    type=\"submit\"\n    [disabled]=\"\n      disabled || quantity <= 0 || quantity > maxQuantity || unavailable\n    \"\n    [attr.aria-label]=\"\n      product?.name\n        ? ('addToCart.addToCart' | cxTranslate) + ', ' + product?.name\n        : ('addToCart.addToCart' | cxTranslate)\n    \"\n  >\n    <span\n      *ngIf=\"\n        options?.addToCartString === ('addToCart.buyItAgain' | cxTranslate) &&\n        !unavailable\n      \"\n      class=\"repeat-icon\"\n      ><cx-icon [type]=\"iconTypes.REPEAT\"></cx-icon\n    ></span>\n    <span\n      [ngClass]=\"\n        options?.addToCartString === ('addToCart.buyItAgain' | cxTranslate)\n          ? 'buyItAgainLink'\n          : ''\n      \"\n    >\n      {{\n        unavailable\n          ? ('addToCart.unavailable' | cxTranslate)\n          : (options?.addToCartString ?? ('addToCart.addToCart' | cxTranslate))\n      }}\n    </span>\n  </button>\n</form>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: ItemCounterComponent, selector: "cx-item-counter", inputs: ["control", "min", "max", "step", "allowZero", "ariaDescribedById", "readonly"] }, { kind: "directive", type: OutletDirective, selector: "[cxOutlet]", inputs: ["cxOutlet", "cxOutletContext", "cxOutletDefer", "cxComponentRef"], outputs: ["loaded", "cxComponentRefChange"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddToCartComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-add-to-cart', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        ItemCounterComponent,
                        OutletDirective,
                        NgClass,
                        IconComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<form *ngIf=\"productCode\" [formGroup]=\"addToCartForm\" (submit)=\"addToCart()\">\n  <div class=\"quantity\" *ngIf=\"showQuantity\">\n    <label>{{ 'addToCart.quantityFull' | cxTranslate }}</label>\n    <div class=\"cx-counter-stock\">\n      <cx-item-counter\n        *ngIf=\"hasStock\"\n        [max]=\"maxQuantity\"\n        [control]=\"addToCartForm.get('quantity')\"\n        [ariaDescribedById]=\"'add-to-card-stock-info'\"\n      ></cx-item-counter>\n\n      <span class=\"info\" id=\"add-to-card-stock-info\">\n        <span *ngIf=\"showInventory$ | async\">{{ getInventory() }}</span>\n        {{\n          hasStock\n            ? ('addToCart.inStock' | cxTranslate)\n            : ('addToCart.outOfStock' | cxTranslate)\n        }}</span\n      >\n    </div>\n  </div>\n\n  <ng-container *ngIf=\"hasStock\">\n    <ng-template\n      [cxOutlet]=\"CartOutlets.ADD_TO_CART_PICKUP_OPTION\"\n      [(cxComponentRef)]=\"pickupOptionCompRef\"\n      (cxComponentRefChange)=\"onPickupOptionsCompLoaded()\"\n    ></ng-template>\n  </ng-container>\n\n  <button\n    #addToCartDialogTriggerEl\n    *ngIf=\"hasStock\"\n    [ngClass]=\"\n      options?.displayAddToCart\n        ? 'btn btn-tertiary'\n        : 'btn btn-primary btn-block'\n    \"\n    type=\"submit\"\n    [disabled]=\"\n      disabled || quantity <= 0 || quantity > maxQuantity || unavailable\n    \"\n    [attr.aria-label]=\"\n      product?.name\n        ? ('addToCart.addToCart' | cxTranslate) + ', ' + product?.name\n        : ('addToCart.addToCart' | cxTranslate)\n    \"\n  >\n    <span\n      *ngIf=\"\n        options?.addToCartString === ('addToCart.buyItAgain' | cxTranslate) &&\n        !unavailable\n      \"\n      class=\"repeat-icon\"\n      ><cx-icon [type]=\"iconTypes.REPEAT\"></cx-icon\n    ></span>\n    <span\n      [ngClass]=\"\n        options?.addToCartString === ('addToCart.buyItAgain' | cxTranslate)\n          ? 'buyItAgainLink'\n          : ''\n      \"\n    >\n      {{\n        unavailable\n          ? ('addToCart.unavailable' | cxTranslate)\n          : (options?.addToCartString ?? ('addToCart.addToCart' | cxTranslate))\n      }}\n    </span>\n  </button>\n</form>\n" }]
        }], ctorParameters: () => [{ type: i1.CurrentProductService }, { type: i0.ChangeDetectorRef }, { type: i1$1.ActiveCartFacade }, { type: i1.CmsComponentData }, { type: i2.EventService }, { type: i1.ProductListItemContext, decorators: [{
                    type: Optional
                }] }], propDecorators: { productCode: [{
                type: Input
            }], showQuantity: [{
                type: Input
            }], options: [{
                type: Input
            }], pickupStore: [{
                type: Input
            }], savedCart: [{
                type: Input
            }], product: [{
                type: Input
            }], addToCartDialogTriggerEl: [{
                type: ViewChild,
                args: ['addToCartDialogTriggerEl']
            }], handleKeyboardEvent: [{
                type: HostListener,
                args: ['document:keydown', ['$event']]
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AddToCartModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddToCartModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: AddToCartModule, imports: [CommonModule,
            ReactiveFormsModule,
            I18nModule,
            IconModule,
            ItemCounterModule,
            OutletModule,
            FeaturesConfigModule,
            AddToCartComponent], exports: [AddToCartComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddToCartModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    ProductAddToCartComponent: {
                        component: AddToCartComponent,
                        data: {
                            inventoryDisplay: false,
                        },
                    },
                },
            }),
        ], imports: [CommonModule,
            ReactiveFormsModule,
            I18nModule,
            IconModule,
            ItemCounterModule,
            OutletModule,
            FeaturesConfigModule,
            AddToCartComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddToCartModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        I18nModule,
                        IconModule,
                        ItemCounterModule,
                        OutletModule,
                        FeaturesConfigModule,
                        AddToCartComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                ProductAddToCartComponent: {
                                    component: AddToCartComponent,
                                    data: {
                                        inventoryDisplay: false,
                                    },
                                },
                            },
                        }),
                    ],
                    exports: [AddToCartComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AppliedCouponsComponent {
    constructor(cartVoucherService) {
        this.cartVoucherService = cartVoucherService;
        this.cartIsLoading = false;
        this.isReadOnly = false;
        this.iconTypes = ICON_TYPE;
    }
    get sortedVouchers() {
        this.vouchers = this.vouchers || [];
        return this.vouchers.slice().sort((a, b) => {
            return a.code && b.code ? a.code.localeCompare(b.code) : 0;
        });
    }
    removeVoucher(voucherId) {
        this.cartVoucherService.removeVoucher(voucherId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AppliedCouponsComponent, deps: [{ token: i1$1.CartVoucherFacade }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: AppliedCouponsComponent, isStandalone: true, selector: "cx-applied-coupons", inputs: { vouchers: "vouchers", cartIsLoading: "cartIsLoading", isReadOnly: "isReadOnly" }, ngImport: i0, template: "<div *ngIf=\"isReadOnly; else editableCoupons\">\n  <div *ngIf=\"sortedVouchers.length > 0\">\n    <div class=\"cx-applied-coupon-title\">\n      {{ 'voucher.vouchersApplied' | cxTranslate }}\n    </div>\n  </div>\n  <ng-container>\n    <div\n      *ngFor=\"let voucher of sortedVouchers\"\n      class=\"coupon-summary cx-coupon-card textonly\"\n    >\n      <span class=\"cx-applied-coupon-code\">{{ voucher.voucherCode }}</span>\n    </div>\n  </ng-container>\n</div>\n\n<ng-template #editableCoupons>\n  <div class=\"row\">\n    <ng-container>\n      <div\n        *ngFor=\"let voucher of sortedVouchers\"\n        class=\"col-sm-12 col-md-6 col-lg-12 cx-coupon-card-grid\"\n      >\n        <div class=\"cx-coupon-apply cx-coupon-card cx-coupon-list-wrap\">\n          <span class=\"cx-cart-coupon-code\">{{ voucher.voucherCode }}</span>\n          <button\n            type=\"button\"\n            class=\"close\"\n            title=\"{{ 'common.close' | cxTranslate }}\"\n            [attr.aria-label]=\"'common.close' | cxTranslate\"\n            (click)=\"removeVoucher(voucher.voucherCode)\"\n            [disabled]=\"cartIsLoading\"\n            [class.disabled]=\"cartIsLoading\"\n          >\n            <span aria-hidden=\"true\">\n              <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n            </span>\n          </button>\n        </div>\n      </div>\n    </ng-container>\n  </div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AppliedCouponsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-applied-coupons', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, NgFor, IconComponent, TranslatePipe], template: "<div *ngIf=\"isReadOnly; else editableCoupons\">\n  <div *ngIf=\"sortedVouchers.length > 0\">\n    <div class=\"cx-applied-coupon-title\">\n      {{ 'voucher.vouchersApplied' | cxTranslate }}\n    </div>\n  </div>\n  <ng-container>\n    <div\n      *ngFor=\"let voucher of sortedVouchers\"\n      class=\"coupon-summary cx-coupon-card textonly\"\n    >\n      <span class=\"cx-applied-coupon-code\">{{ voucher.voucherCode }}</span>\n    </div>\n  </ng-container>\n</div>\n\n<ng-template #editableCoupons>\n  <div class=\"row\">\n    <ng-container>\n      <div\n        *ngFor=\"let voucher of sortedVouchers\"\n        class=\"col-sm-12 col-md-6 col-lg-12 cx-coupon-card-grid\"\n      >\n        <div class=\"cx-coupon-apply cx-coupon-card cx-coupon-list-wrap\">\n          <span class=\"cx-cart-coupon-code\">{{ voucher.voucherCode }}</span>\n          <button\n            type=\"button\"\n            class=\"close\"\n            title=\"{{ 'common.close' | cxTranslate }}\"\n            [attr.aria-label]=\"'common.close' | cxTranslate\"\n            (click)=\"removeVoucher(voucher.voucherCode)\"\n            [disabled]=\"cartIsLoading\"\n            [class.disabled]=\"cartIsLoading\"\n          >\n            <span aria-hidden=\"true\">\n              <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n            </span>\n          </button>\n        </div>\n      </div>\n    </ng-container>\n  </div>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1$1.CartVoucherFacade }], propDecorators: { vouchers: [{
                type: Input
            }], cartIsLoading: [{
                type: Input
            }], isReadOnly: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartCouponComponent {
    constructor(cartVoucherService, formBuilder, customerCouponService, activeCartService) {
        this.cartVoucherService = cartVoucherService;
        this.formBuilder = formBuilder;
        this.customerCouponService = customerCouponService;
        this.activeCartService = activeCartService;
        this.MAX_CUSTOMER_COUPON_PAGE = 100;
        this.ignoreCloseEvent = false;
        this.subscription = new Subscription();
        this.couponBoxIsActive = false;
    }
    ngOnInit() {
        if (this.customerCouponService) {
            this.customerCouponService.loadCustomerCoupons(this.MAX_CUSTOMER_COUPON_PAGE);
        }
        this.cart$ = combineLatest([
            this.activeCartService.getActive(),
            this.activeCartService.getActiveCartId(),
            this.customerCouponService.getCustomerCoupons(this.MAX_CUSTOMER_COUPON_PAGE),
        ]).pipe(tap(([cart, activeCardId, customerCoupons]) => {
            this.cartId = activeCardId;
            this.getApplicableCustomerCoupons(cart, customerCoupons.coupons ?? []);
        }), map(([cart]) => cart));
        this.cartIsLoading$ = this.activeCartService
            .isStable()
            .pipe(map((loaded) => !loaded));
        this.cartVoucherService.resetAddVoucherProcessingState();
        this.couponForm = this.formBuilder.group({
            couponCode: ['', [Validators.required]],
        });
        // TODO(#7241): Replace process subscriptions with event listeners and drop process for ADD_VOUCHER
        this.subscription.add(this.cartVoucherService
            .getAddVoucherResultSuccess()
            .subscribe((success) => {
            this.onSuccess(success);
        }));
        // TODO(#7241): Replace process subscriptions with event listeners and drop process for ADD_VOUCHER
        this.subscription.add(this.cartVoucherService.getAddVoucherResultError().subscribe((error) => {
            this.onError(error);
        }));
    }
    onError(error) {
        if (error) {
            this.customerCouponService.loadCustomerCoupons(this.MAX_CUSTOMER_COUPON_PAGE);
            this.cartVoucherService.resetAddVoucherProcessingState();
        }
    }
    onSuccess(success) {
        if (success) {
            this.couponForm.reset();
            this.cartVoucherService.resetAddVoucherProcessingState();
        }
    }
    getApplicableCustomerCoupons(cart, coupons) {
        this.applicableCoupons = coupons || [];
        if (cart.appliedVouchers) {
            cart.appliedVouchers.forEach((appliedVoucher) => {
                this.applicableCoupons = this.applicableCoupons.filter((coupon) => coupon.couponId !== appliedVoucher.code);
            });
        }
    }
    applyVoucher() {
        if (this.couponForm.valid) {
            this.cartVoucherService.addVoucher(this.couponForm.value.couponCode, this.cartId);
        }
        else {
            this.couponForm.markAllAsTouched();
        }
    }
    applyCustomerCoupon(couponId) {
        this.cartVoucherService.addVoucher(couponId, this.cartId);
        this.couponBoxIsActive = false;
    }
    close(event) {
        if (!this.ignoreCloseEvent) {
            this.couponBoxIsActive = false;
            if (event && event.target) {
                event.target.blur();
            }
        }
        this.ignoreCloseEvent = false;
    }
    disableClose() {
        this.ignoreCloseEvent = true;
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
        this.cartVoucherService.resetAddVoucherProcessingState();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartCouponComponent, deps: [{ token: i1$1.CartVoucherFacade }, { token: i2$1.UntypedFormBuilder }, { token: i2.CustomerCouponService }, { token: i1$1.ActiveCartFacade }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CartCouponComponent, isStandalone: true, selector: "cx-cart-coupon", ngImport: i0, template: "<ng-container *ngIf=\"cart$ | async as cart\">\n  <div class=\"form-group\">\n    <form (ngSubmit)=\"applyVoucher()\" [formGroup]=\"couponForm\">\n      <label id=\"card-coupon-input-label\" class=\"cx-cart-coupon-title\">\n        {{ 'voucher.addCoupon' | cxTranslate }}\n      </label>\n\n      <div class=\"cx-cart-coupon-container\">\n        <input\n          [attr.aria-labelledby]=\"'card-coupon-input-label'\"\n          type=\"text\"\n          class=\"form-control input-coupon-code\"\n          formControlName=\"couponCode\"\n          placeholder=\"{{ 'voucher.placeholder' | cxTranslate }}\"\n        />\n        <button\n          class=\"btn btn-block btn-secondary apply-coupon-button\"\n          type=\"submit\"\n          [disabled]=\"\n            (cartIsLoading$ | async) || !couponForm?.get('couponCode')?.value\n          \"\n          [class.disabled]=\"cartIsLoading$ | async\"\n        >\n          {{ 'voucher.apply' | cxTranslate }}\n        </button>\n      </div>\n    </form>\n  </div>\n\n  <cx-applied-coupons\n    [vouchers]=\"cart.appliedVouchers\"\n    [cartIsLoading]=\"cartIsLoading$ | async\"\n    [isReadOnly]=\"false\"\n  >\n  </cx-applied-coupons>\n\n  <ng-container *ngIf=\"applicableCoupons && applicableCoupons.length > 0\">\n    <div class=\"cx-available-coupon\">\n      <div class=\"title cx-cart-coupon-title\">\n        {{ 'voucher.availableCoupons' | cxTranslate }}\n      </div>\n      <div class=\"message\">\n        {{ 'voucher.availableCouponsLabel' | cxTranslate }}\n      </div>\n      <div class=\"scroll\">\n        <div class=\"coupons card\" *ngFor=\"let coupon of applicableCoupons\">\n          <button\n            (click)=\"applyCustomerCoupon(coupon.couponId)\"\n            class=\"coupon-id link\"\n            [disabled]=\"cartIsLoading$ | async\"\n            [class.disabled]=\"cartIsLoading$ | async\"\n          >\n            {{ coupon.couponId }}\n          </button>\n        </div>\n      </div>\n    </div>\n  </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i2$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i2$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i2$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: AppliedCouponsComponent, selector: "cx-applied-coupons", inputs: ["vouchers", "cartIsLoading", "isReadOnly"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartCouponComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-cart-coupon', imports: [
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        AppliedCouponsComponent,
                        NgFor,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<ng-container *ngIf=\"cart$ | async as cart\">\n  <div class=\"form-group\">\n    <form (ngSubmit)=\"applyVoucher()\" [formGroup]=\"couponForm\">\n      <label id=\"card-coupon-input-label\" class=\"cx-cart-coupon-title\">\n        {{ 'voucher.addCoupon' | cxTranslate }}\n      </label>\n\n      <div class=\"cx-cart-coupon-container\">\n        <input\n          [attr.aria-labelledby]=\"'card-coupon-input-label'\"\n          type=\"text\"\n          class=\"form-control input-coupon-code\"\n          formControlName=\"couponCode\"\n          placeholder=\"{{ 'voucher.placeholder' | cxTranslate }}\"\n        />\n        <button\n          class=\"btn btn-block btn-secondary apply-coupon-button\"\n          type=\"submit\"\n          [disabled]=\"\n            (cartIsLoading$ | async) || !couponForm?.get('couponCode')?.value\n          \"\n          [class.disabled]=\"cartIsLoading$ | async\"\n        >\n          {{ 'voucher.apply' | cxTranslate }}\n        </button>\n      </div>\n    </form>\n  </div>\n\n  <cx-applied-coupons\n    [vouchers]=\"cart.appliedVouchers\"\n    [cartIsLoading]=\"cartIsLoading$ | async\"\n    [isReadOnly]=\"false\"\n  >\n  </cx-applied-coupons>\n\n  <ng-container *ngIf=\"applicableCoupons && applicableCoupons.length > 0\">\n    <div class=\"cx-available-coupon\">\n      <div class=\"title cx-cart-coupon-title\">\n        {{ 'voucher.availableCoupons' | cxTranslate }}\n      </div>\n      <div class=\"message\">\n        {{ 'voucher.availableCouponsLabel' | cxTranslate }}\n      </div>\n      <div class=\"scroll\">\n        <div class=\"coupons card\" *ngFor=\"let coupon of applicableCoupons\">\n          <button\n            (click)=\"applyCustomerCoupon(coupon.couponId)\"\n            class=\"coupon-id link\"\n            [disabled]=\"cartIsLoading$ | async\"\n            [class.disabled]=\"cartIsLoading$ | async\"\n          >\n            {{ coupon.couponId }}\n          </button>\n        </div>\n      </div>\n    </div>\n  </ng-container>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: i1$1.CartVoucherFacade }, { type: i2$1.UntypedFormBuilder }, { type: i2.CustomerCouponService }, { type: i1$1.ActiveCartFacade }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartCouponModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartCouponModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CartCouponModule, imports: [CommonModule,
            NgSelectModule,
            FormsModule,
            ReactiveFormsModule,
            I18nModule,
            IconModule,
            FormErrorsModule,
            FeaturesConfigModule,
            FormRequiredLegendComponent,
            CartCouponComponent,
            AppliedCouponsComponent], exports: [CartCouponComponent, AppliedCouponsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartCouponModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    CartApplyCouponComponent: {
                        component: CartCouponComponent,
                    },
                },
            }),
        ], imports: [CommonModule,
            NgSelectModule,
            FormsModule,
            ReactiveFormsModule,
            I18nModule,
            IconModule,
            FormErrorsModule,
            FeaturesConfigModule,
            FormRequiredLegendComponent,
            CartCouponComponent,
            AppliedCouponsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartCouponModule, decorators: [{
            type: NgModule,
            args: [{
                    exports: [CartCouponComponent, AppliedCouponsComponent],
                    imports: [
                        CommonModule,
                        NgSelectModule,
                        FormsModule,
                        ReactiveFormsModule,
                        I18nModule,
                        IconModule,
                        FormErrorsModule,
                        FeaturesConfigModule,
                        FormRequiredLegendComponent,
                        CartCouponComponent,
                        AppliedCouponsComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                CartApplyCouponComponent: {
                                    component: CartCouponComponent,
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartItemValidationWarningModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartItemValidationWarningModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CartItemValidationWarningModule, imports: [CommonModule,
            RouterModule,
            I18nModule,
            UrlModule,
            IconModule,
            CartItemValidationWarningComponent], exports: [CartItemValidationWarningComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartItemValidationWarningModule, imports: [CommonModule,
            RouterModule,
            I18nModule,
            UrlModule,
            IconModule,
            CartItemValidationWarningComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartItemValidationWarningModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        I18nModule,
                        UrlModule,
                        IconModule,
                        CartItemValidationWarningComponent,
                    ],
                    exports: [CartItemValidationWarningComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartItemListComponentService {
    showBasePriceWithDiscount() {
        return true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartItemListComponentService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartItemListComponentService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartItemListComponentService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartItemListRowComponent extends CartItemComponent {
    constructor(cartItemContextSource) {
        super(cartItemContextSource);
        this.componentService = inject(CartItemListComponentService);
        this.isFlagQuote = this.componentService.showBasePriceWithDiscount();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartItemListRowComponent, deps: [{ token: CartItemContextSource }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CartItemListRowComponent, isStandalone: true, selector: "[cx-cart-item-list-row], cx-cart-item-list-row", inputs: { items: "items" }, providers: [
            CartItemContextSource,
            { provide: CartItemContext, useExisting: CartItemContextSource },
        ], usesInheritance: true, ngImport: i0, template: "<!-- Item Start Outlet -->\n<ng-template [cxOutlet]=\"CartOutlets.LIST_ITEM\">\n  <td role=\"cell\">\n    <ng-template\n      [cxOutlet]=\"CartOutlets.ITEM_CONFIGURATOR_ISSUES\"\n    ></ng-template>\n    <cx-cart-item-validation-warning\n      [code]=\"item.product?.code\"\n    ></cx-cart-item-validation-warning>\n    <div class=\"cx-table-item-container\">\n      <!-- Item Image -->\n      <a\n        *ngIf=\"!options.disableItemLink\"\n        [routerLink]=\"{ cxRoute: 'product', params: item.product } | cxUrl\"\n        tabindex=\"0\"\n      >\n        <cx-media\n          [container]=\"item.product?.images?.PRIMARY\"\n          format=\"cartIcon\"\n        ></cx-media>\n      </a>\n      <cx-media\n        *ngIf=\"options.disableItemLink\"\n        [container]=\"item.product?.images?.PRIMARY\"\n        format=\"cartIcon\"\n      ></cx-media>\n      <div class=\"cx-info\">\n        <div *ngIf=\"item.product?.name\" class=\"cx-name\">\n          <a\n            *ngIf=\"!options.disableItemLink\"\n            class=\"cx-link\"\n            [routerLink]=\"{ cxRoute: 'product', params: item.product } | cxUrl\"\n            >{{ item.product?.name }}</a\n          >\n          <span *ngIf=\"options.disableItemLink\">{{ item.product?.name }}</span>\n        </div>\n        <div *ngIf=\"item.product?.code\" class=\"cx-code\">\n          {{ 'cartItems.id' | cxTranslate }} {{ item.product?.code }}\n        </div>\n        <!-- Item Price -->\n        <ng-container *ngIf=\"isFlagQuote\">\n          <div *ngIf=\"item.basePrice\" class=\"cx-price\">\n            <div *ngIf=\"item.basePrice\" class=\"cx-value\">\n              {{ item.basePrice?.formattedValue }}\n            </div>\n          </div></ng-container\n        >\n        <ng-template\n          [cxOutlet]=\"CartOutlets.CPQ_QUOTE\"\n          [cxOutletContext]=\"{\n            items: item,\n          }\"\n        ></ng-template>\n      </div>\n    </div>\n    <div class=\"cx-cart-addons\">\n      <!-- Item Details Outlet -->\n      <ng-template [cxOutlet]=\"CartOutlets.ITEM_DETAILS\"> </ng-template>\n\n      <!-- Item Bundle Details Outlet -->\n      <ng-template [cxOutlet]=\"CartOutlets.ITEM_BUNDLE_DETAILS\"> </ng-template>\n\n      <!-- Promotion -->\n      <cx-promotions [promotions]=\"item.promotions\"></cx-promotions>\n\n      <!-- Item Delivery Details Outlet -->\n      <ng-template\n        *ngIf=\"!readonly\"\n        [cxOutlet]=\"CartOutlets.ITEM_DELIVERY_DETAILS\"\n        [cxOutletContext]=\"{ item, cartType: options.cartType }\"\n      ></ng-template>\n    </div>\n\n    <!-- Variants -->\n    <ng-container *ngIf=\"item.product?.baseOptions?.length\">\n      <div\n        *ngFor=\"\n          let variant of item.product?.baseOptions[0]?.selected\n            ?.variantOptionQualifiers\n        \"\n        class=\"cx-property\"\n      >\n        <!-- cx-mobile-header -->\n        <div class=\"cx-label\" *ngIf=\"variant.name && variant.value\">\n          {{ variant.name }}: {{ variant.value }}\n        </div>\n      </div>\n    </ng-container>\n  </td>\n  <!-- Mobile Item Price -->\n  <td role=\"cell\" *ngIf=\"item.basePrice\" class=\"cx-price cx-mobile-only\">\n    <div class=\"cx-mobile-header\">\n      {{ 'cartItems.itemPrice' | cxTranslate }}\n    </div>\n    <div *ngIf=\"item.basePrice\" class=\"cx-value\">\n      {{ item.basePrice?.formattedValue }}\n    </div>\n  </td>\n\n  <!-- Subscription Charges -->\n  <ng-template\n    [cxOutlet]=\"CartOutlets.SUBSCRIPTION_PRICE_BODY\"\n    [cxOutletContext]=\"{\n      items,\n      item,\n      parent: 'cart',\n    }\"\n  >\n  </ng-template>\n\n  <!-- item price with discount -->\n  <ng-template\n    [cxOutlet]=\"CartOutlets.CPQ_QUOTE_MODULE\"\n    [cxOutletContext]=\"{\n      items: item,\n    }\"\n  ></ng-template>\n\n  <!-- Item Quantity -->\n  <td role=\"cell\" class=\"cx-quantity\">\n    <div\n      class=\"cx-mobile-header\"\n      placement=\"left\"\n      title=\"{{ 'cartItems.quantityTitle' | cxTranslate }}\"\n    >\n      {{ 'cartItems.quantityFull' | cxTranslate }}\n    </div>\n    <div class=\"cx-value\" [class.readonly-value]=\"readonly\">\n      <cx-item-counter\n        [control]=\"quantityControl\"\n        [readonly]=\"!item.updateable || readonly || options.isSaveForLater\"\n        [max]=\"item.product?.stock?.stockLevel\"\n        [allowZero]=\"true\"\n      >\n      </cx-item-counter>\n    </div>\n  </td>\n  <!-- Total -->\n  <ng-container *ngIf=\"options.isSaveForLater; else total\">\n    <td role=\"cell\" class=\"cx-total\">\n      <div class=\"cx-mobile-header\">\n        {{ 'saveForLaterItems.stock' | cxTranslate }}\n      </div>\n      <div\n        *ngIf=\"item.product?.stock?.stockLevel >= 0; else forceInstock\"\n        class=\"cx-value\"\n      >\n        {{ item.product?.stock.stockLevel }}\n      </div>\n      <ng-template #forceInstock>\n        <div class=\"cx-value\">\n          {{ 'saveForLaterItems.forceInStock' | cxTranslate }}\n        </div>\n      </ng-template>\n    </td>\n  </ng-container>\n\n  <td\n    role=\"cell\"\n    *ngIf=\"\n      (!readonly || options.isSaveForLater || options.displayAddToCart) &&\n      item.updateable\n    \"\n    class=\"cx-actions\"\n  >\n    <ng-container *ngIf=\"!isProductOutOfStock(item.product)\">\n      <ng-container\n        *ngTemplateOutlet=\"\n          options.optionalBtn;\n          context: {\n            $implicit: {\n              loading: quantityControl.disabled,\n              item: this.item,\n              options: this.options,\n            },\n          }\n        \"\n      ></ng-container>\n    </ng-container>\n\n    <!-- Availability -->\n    <span\n      role=\"cell\"\n      *ngIf=\"isProductOutOfStock(item.product)\"\n      class=\"cx-availability\"\n    >\n      {{ 'addToCart.outOfStock' | cxTranslate }}\n    </span>\n\n    <button\n      *ngIf=\"!readonly\"\n      (click)=\"removeItem()\"\n      [cxAtMessage]=\"'cartItems.itemRemoved' | cxTranslate\"\n      [disabled]=\"quantityControl.disabled\"\n      attr.aria-label=\"{{ 'addToCart.removeFromCart' | cxTranslate }}\"\n      class=\"btn btn-tertiary cx-remove-btn\"\n    >\n      {{ 'common.remove' | cxTranslate }}\n    </button>\n  </td>\n</ng-template>\n<ng-template #total>\n  <td role=\"cell\" *ngIf=\"item.totalPrice\" class=\"cx-total\">\n    <div class=\"cx-mobile-header\">\n      {{ 'cartItems.total' | cxTranslate }}\n    </div>\n    <div class=\"cx-value\">{{ item.totalPrice.formattedValue }}</div>\n  </td>\n</ng-template>\n", dependencies: [{ kind: "directive", type: OutletDirective, selector: "[cxOutlet]", inputs: ["cxOutlet", "cxOutletContext", "cxOutletDefer", "cxComponentRef"], outputs: ["loaded", "cxComponentRefChange"] }, { kind: "component", type: CartItemValidationWarningComponent, selector: "cx-cart-item-validation-warning", inputs: ["code"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: MediaComponent, selector: "cx-media", inputs: ["container", "format", "alt", "role", "loading", "fetchPriority", "elementType", "sizesForImgElement"], outputs: ["loaded"] }, { kind: "component", type: PromotionsComponent, selector: "cx-promotions", inputs: ["promotions"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: ItemCounterComponent, selector: "cx-item-counter", inputs: ["control", "min", "max", "step", "allowZero", "ariaDescribedById", "readonly"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: AtMessageDirective, selector: "[cxAtMessage]", inputs: ["cxAtMessage"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartItemListRowComponent, decorators: [{
            type: Component,
            args: [{ selector: '[cx-cart-item-list-row], cx-cart-item-list-row', providers: [
                        CartItemContextSource,
                        { provide: CartItemContext, useExisting: CartItemContextSource },
                    ], imports: [
                        OutletDirective,
                        CartItemValidationWarningComponent,
                        NgIf,
                        RouterLink,
                        MediaComponent,
                        PromotionsComponent,
                        NgFor,
                        ItemCounterComponent,
                        NgTemplateOutlet,
                        AtMessageDirective,
                        TranslatePipe,
                        UrlPipe,
                    ], template: "<!-- Item Start Outlet -->\n<ng-template [cxOutlet]=\"CartOutlets.LIST_ITEM\">\n  <td role=\"cell\">\n    <ng-template\n      [cxOutlet]=\"CartOutlets.ITEM_CONFIGURATOR_ISSUES\"\n    ></ng-template>\n    <cx-cart-item-validation-warning\n      [code]=\"item.product?.code\"\n    ></cx-cart-item-validation-warning>\n    <div class=\"cx-table-item-container\">\n      <!-- Item Image -->\n      <a\n        *ngIf=\"!options.disableItemLink\"\n        [routerLink]=\"{ cxRoute: 'product', params: item.product } | cxUrl\"\n        tabindex=\"0\"\n      >\n        <cx-media\n          [container]=\"item.product?.images?.PRIMARY\"\n          format=\"cartIcon\"\n        ></cx-media>\n      </a>\n      <cx-media\n        *ngIf=\"options.disableItemLink\"\n        [container]=\"item.product?.images?.PRIMARY\"\n        format=\"cartIcon\"\n      ></cx-media>\n      <div class=\"cx-info\">\n        <div *ngIf=\"item.product?.name\" class=\"cx-name\">\n          <a\n            *ngIf=\"!options.disableItemLink\"\n            class=\"cx-link\"\n            [routerLink]=\"{ cxRoute: 'product', params: item.product } | cxUrl\"\n            >{{ item.product?.name }}</a\n          >\n          <span *ngIf=\"options.disableItemLink\">{{ item.product?.name }}</span>\n        </div>\n        <div *ngIf=\"item.product?.code\" class=\"cx-code\">\n          {{ 'cartItems.id' | cxTranslate }} {{ item.product?.code }}\n        </div>\n        <!-- Item Price -->\n        <ng-container *ngIf=\"isFlagQuote\">\n          <div *ngIf=\"item.basePrice\" class=\"cx-price\">\n            <div *ngIf=\"item.basePrice\" class=\"cx-value\">\n              {{ item.basePrice?.formattedValue }}\n            </div>\n          </div></ng-container\n        >\n        <ng-template\n          [cxOutlet]=\"CartOutlets.CPQ_QUOTE\"\n          [cxOutletContext]=\"{\n            items: item,\n          }\"\n        ></ng-template>\n      </div>\n    </div>\n    <div class=\"cx-cart-addons\">\n      <!-- Item Details Outlet -->\n      <ng-template [cxOutlet]=\"CartOutlets.ITEM_DETAILS\"> </ng-template>\n\n      <!-- Item Bundle Details Outlet -->\n      <ng-template [cxOutlet]=\"CartOutlets.ITEM_BUNDLE_DETAILS\"> </ng-template>\n\n      <!-- Promotion -->\n      <cx-promotions [promotions]=\"item.promotions\"></cx-promotions>\n\n      <!-- Item Delivery Details Outlet -->\n      <ng-template\n        *ngIf=\"!readonly\"\n        [cxOutlet]=\"CartOutlets.ITEM_DELIVERY_DETAILS\"\n        [cxOutletContext]=\"{ item, cartType: options.cartType }\"\n      ></ng-template>\n    </div>\n\n    <!-- Variants -->\n    <ng-container *ngIf=\"item.product?.baseOptions?.length\">\n      <div\n        *ngFor=\"\n          let variant of item.product?.baseOptions[0]?.selected\n            ?.variantOptionQualifiers\n        \"\n        class=\"cx-property\"\n      >\n        <!-- cx-mobile-header -->\n        <div class=\"cx-label\" *ngIf=\"variant.name && variant.value\">\n          {{ variant.name }}: {{ variant.value }}\n        </div>\n      </div>\n    </ng-container>\n  </td>\n  <!-- Mobile Item Price -->\n  <td role=\"cell\" *ngIf=\"item.basePrice\" class=\"cx-price cx-mobile-only\">\n    <div class=\"cx-mobile-header\">\n      {{ 'cartItems.itemPrice' | cxTranslate }}\n    </div>\n    <div *ngIf=\"item.basePrice\" class=\"cx-value\">\n      {{ item.basePrice?.formattedValue }}\n    </div>\n  </td>\n\n  <!-- Subscription Charges -->\n  <ng-template\n    [cxOutlet]=\"CartOutlets.SUBSCRIPTION_PRICE_BODY\"\n    [cxOutletContext]=\"{\n      items,\n      item,\n      parent: 'cart',\n    }\"\n  >\n  </ng-template>\n\n  <!-- item price with discount -->\n  <ng-template\n    [cxOutlet]=\"CartOutlets.CPQ_QUOTE_MODULE\"\n    [cxOutletContext]=\"{\n      items: item,\n    }\"\n  ></ng-template>\n\n  <!-- Item Quantity -->\n  <td role=\"cell\" class=\"cx-quantity\">\n    <div\n      class=\"cx-mobile-header\"\n      placement=\"left\"\n      title=\"{{ 'cartItems.quantityTitle' | cxTranslate }}\"\n    >\n      {{ 'cartItems.quantityFull' | cxTranslate }}\n    </div>\n    <div class=\"cx-value\" [class.readonly-value]=\"readonly\">\n      <cx-item-counter\n        [control]=\"quantityControl\"\n        [readonly]=\"!item.updateable || readonly || options.isSaveForLater\"\n        [max]=\"item.product?.stock?.stockLevel\"\n        [allowZero]=\"true\"\n      >\n      </cx-item-counter>\n    </div>\n  </td>\n  <!-- Total -->\n  <ng-container *ngIf=\"options.isSaveForLater; else total\">\n    <td role=\"cell\" class=\"cx-total\">\n      <div class=\"cx-mobile-header\">\n        {{ 'saveForLaterItems.stock' | cxTranslate }}\n      </div>\n      <div\n        *ngIf=\"item.product?.stock?.stockLevel >= 0; else forceInstock\"\n        class=\"cx-value\"\n      >\n        {{ item.product?.stock.stockLevel }}\n      </div>\n      <ng-template #forceInstock>\n        <div class=\"cx-value\">\n          {{ 'saveForLaterItems.forceInStock' | cxTranslate }}\n        </div>\n      </ng-template>\n    </td>\n  </ng-container>\n\n  <td\n    role=\"cell\"\n    *ngIf=\"\n      (!readonly || options.isSaveForLater || options.displayAddToCart) &&\n      item.updateable\n    \"\n    class=\"cx-actions\"\n  >\n    <ng-container *ngIf=\"!isProductOutOfStock(item.product)\">\n      <ng-container\n        *ngTemplateOutlet=\"\n          options.optionalBtn;\n          context: {\n            $implicit: {\n              loading: quantityControl.disabled,\n              item: this.item,\n              options: this.options,\n            },\n          }\n        \"\n      ></ng-container>\n    </ng-container>\n\n    <!-- Availability -->\n    <span\n      role=\"cell\"\n      *ngIf=\"isProductOutOfStock(item.product)\"\n      class=\"cx-availability\"\n    >\n      {{ 'addToCart.outOfStock' | cxTranslate }}\n    </span>\n\n    <button\n      *ngIf=\"!readonly\"\n      (click)=\"removeItem()\"\n      [cxAtMessage]=\"'cartItems.itemRemoved' | cxTranslate\"\n      [disabled]=\"quantityControl.disabled\"\n      attr.aria-label=\"{{ 'addToCart.removeFromCart' | cxTranslate }}\"\n      class=\"btn btn-tertiary cx-remove-btn\"\n    >\n      {{ 'common.remove' | cxTranslate }}\n    </button>\n  </td>\n</ng-template>\n<ng-template #total>\n  <td role=\"cell\" *ngIf=\"item.totalPrice\" class=\"cx-total\">\n    <div class=\"cx-mobile-header\">\n      {{ 'cartItems.total' | cxTranslate }}\n    </div>\n    <div class=\"cx-value\">{{ item.totalPrice.formattedValue }}</div>\n  </td>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: CartItemContextSource }], propDecorators: { items: [{
                type: Optional
            }, {
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartItemListComponent {
    set items(items) {
        this._setItems(items);
    }
    get items() {
        return this._items;
    }
    set cartIsLoading(value) {
        this.setLoading = value; // CXSPA-13739: Replace with underlying logic
    }
    /** @deprecated Use `cartIsLoading` */
    // CXSPA-13739: Move logic to `cartIsLoading` when removing
    set setLoading(value) {
        if (!this.readonly) {
            // Whenever the cart is loading, we disable the complete form
            // to avoid any user interaction with the cart.
            value
                ? this.form.disable({ emitEvent: false })
                : this.form.enable({ emitEvent: false });
            this.cd.markForCheck();
        }
    }
    constructor(activeCartService, selectiveCartService, userIdService, multiCartService, cd, outlet) {
        this.activeCartService = activeCartService;
        this.selectiveCartService = selectiveCartService;
        this.userIdService = userIdService;
        this.multiCartService = multiCartService;
        this.cd = cd;
        this.outlet = outlet;
        this.productCatalogService = inject(ProductCatalogService);
        this.subscription = new Subscription();
        this.readonly = false;
        this.hasHeader = true;
        this.options = {
            isSaveForLater: false,
            optionalBtn: null,
            displayAddToCart: false,
        };
        this._items = [];
        this.form = new UntypedFormGroup({});
        this.promotionLocation = PromotionLocation.ActiveCart;
        this.CartOutlets = CartOutlets;
        this.featureToggles = inject(FeatureToggles);
        useFeatureStyles('a11yCartItemListHideEmptyOutlets');
    }
    ngOnInit() {
        this.subscription.add(this.getInputsFromContext());
        this.subscription.add(this.userIdService
            ?.getUserId()
            .subscribe((userId) => (this.userId = userId)));
    }
    _setItems(items, options) {
        this.resolveItems(items, options);
        this.createForm();
    }
    getInputsFromContext() {
        return this.outlet?.context$.subscribe((context) => {
            let contextRequiresRerender = false;
            if (context.readonly !== undefined) {
                contextRequiresRerender = this.readonly !== context.readonly;
                this.readonly = context.readonly;
            }
            if (context.hasHeader !== undefined) {
                this.hasHeader = context.hasHeader;
            }
            if (context.options !== undefined) {
                this.options = context.options;
            }
            if (context.cartId !== undefined) {
                this.cartId = context.cartId;
            }
            if (context.promotionLocation !== undefined) {
                this.promotionLocation = context.promotionLocation;
            }
            if (context.cartIsLoading !== undefined) {
                this.cartIsLoading = context.cartIsLoading;
            }
            this.updateItemsOnContextChange(context, contextRequiresRerender);
        });
    }
    updateItemsOnContextChange(context, contextRequiresRerender) {
        const preventRedundantRecreationEnabled = this.featureToggles.a11yPreventCartItemsFormRedundantRecreation;
        if (context.items !== undefined &&
            (!preventRedundantRecreationEnabled ||
                contextRequiresRerender ||
                this.isItemsChanged(context.items))) {
            this.cd.markForCheck();
            this._setItems(context.items, {
                forceRerender: contextRequiresRerender,
            });
        }
    }
    isItemsChanged(newItems) {
        return JSON.stringify(this.items) !== JSON.stringify(newItems);
    }
    /**
     * Resolves items passed to component input and updates 'items' field
     */
    resolveItems(items, options) {
        if (!items) {
            this._items = [];
            return;
        }
        // The items we're getting from the input do not have a consistent model.
        // In case of a `consignmentEntry`, we need to normalize the data from the orderEntry.
        if (items.every((item) => item.hasOwnProperty('orderEntry'))) {
            this.normalizeConsignmentEntries(items);
        }
        else {
            this.rerenderChangedItems(items, options);
        }
    }
    normalizeConsignmentEntries(items) {
        this._items = items.map((consignmentEntry) => {
            const entry = Object.assign({}, consignmentEntry.orderEntry);
            entry.quantity = consignmentEntry.quantity;
            return entry;
        });
    }
    /**
     * We'd like to avoid the unnecessary re-renders of unchanged cart items after the data reload.
     * OCC cart entries don't have any unique identifier that we could use in Angular `trackBy`.
     * So we update each array element to the new object only when it's any different to the previous one.
     */
    rerenderChangedItems(items, options) {
        let offset = 0;
        for (let i = 0; i - offset < Math.max(items.length, this._items.length); i++) {
            const index = i - offset;
            if (options?.forceRerender ||
                JSON.stringify(this._items?.[index]) !== JSON.stringify(items[index])) {
                if (this._items[index]) {
                    this.form?.removeControl(this.getControlName(this._items[index]));
                }
                if (!items[index]) {
                    this._items.splice(index, 1);
                    offset++;
                }
                else {
                    this._items[index] = items[index];
                }
            }
        }
    }
    /**
     * Creates form models for list items
     */
    createForm() {
        this._items.forEach((item) => {
            const controlName = this.getControlName(item);
            const control = this.form.get(controlName);
            if (control) {
                if (control.get('quantity')?.value !== item.quantity) {
                    control.patchValue({ quantity: item.quantity }, { emitEvent: false });
                }
            }
            else {
                const group = new UntypedFormGroup({
                    entryNumber: new UntypedFormControl(item.entryNumber),
                    quantity: new UntypedFormControl(item.quantity, { updateOn: 'blur' }),
                });
                this.form.addControl(controlName, group);
            }
            // If we disable form group before adding, disabled status will reset
            // Which forces us to disable control after including to form object
            if (!item.updateable || this.readonly) {
                this.form.controls[controlName].disable();
            }
        });
    }
    getControlName(item) {
        return item.entryNumber?.toString() || '';
    }
    removeEntry(item) {
        if (this.options.isSaveForLater) {
            this.selectiveCartService.removeEntry(item);
        }
        else if (this.cartId && this.userId) {
            this.multiCartService.removeEntry(this.userId, this.cartId, item.entryNumber);
        }
        else {
            this.activeCartService.removeEntry(item);
        }
        delete this.form.controls[this.getControlName(item)];
    }
    getControl(item) {
        return this.form.get(this.getControlName(item))?.valueChanges.pipe(
        // eslint-disable-next-line import/no-deprecated
        startWith(null), tap((value) => {
            if (item.updateable && value && !this.readonly) {
                if (this.options.isSaveForLater) {
                    this.selectiveCartService.updateEntry(value.entryNumber, value.quantity);
                }
                else if (this.cartId && this.userId) {
                    this.multiCartService.updateEntry(this.userId, this.cartId, value.entryNumber, value.quantity);
                }
                else {
                    this.activeCartService.updateEntry(value.entryNumber, value.quantity);
                }
            }
        }), map(() => this.form.get(this.getControlName(item))));
    }
    getOptions(item) {
        if (!this.productCatalogService.isProductInCatalog(item.product)) {
            return { ...this.options, disableItemLink: true };
        }
        return this.options;
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartItemListComponent, deps: [{ token: i1$1.ActiveCartFacade }, { token: i1$1.SelectiveCartFacade }, { token: i2.UserIdService }, { token: i1$1.MultiCartFacade }, { token: i0.ChangeDetectorRef }, { token: i1.OutletContextData, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CartItemListComponent, isStandalone: true, selector: "cx-cart-item-list", inputs: { readonly: "readonly", hasHeader: "hasHeader", options: "options", cartId: "cartId", items: "items", promotionLocation: "promotionLocation", cartIsLoading: "cartIsLoading" }, ngImport: i0, template: "<table role=\"table\">\n  <caption class=\"cx-visually-hidden\">\n    {{\n      'cartItems.caption' | cxTranslate\n    }}\n  </caption>\n  <thead *ngIf=\"hasHeader\">\n    <tr role=\"row\" class=\"cx-item-list-header\">\n      <th role=\"columnheader\" scope=\"col\" class=\"cx-item-list-desc\">\n        {{ 'cartItems.item' | cxTranslate }}\n      </th>\n\n      <ng-template\n        [cxOutlet]=\"CartOutlets.SUBSCRIPTION_PRICE_HEADING\"\n        [cxOutletContext]=\"{\n          items,\n          parent: 'cart',\n        }\"\n      ></ng-template>\n\n      <ng-template\n        [cxOutlet]=\"CartOutlets.CPQ_QUOTE_HEADING\"\n        [cxOutletContext]=\"items\"\n      ></ng-template>\n      <th role=\"columnheader\" scope=\"col\" class=\"cx-item-list-qty\">\n        {{ 'cartItems.quantityFull' | cxTranslate }}\n      </th>\n      <ng-container *ngIf=\"options.isSaveForLater; else totalHeader\">\n        <th role=\"columnheader\" scope=\"col\" class=\"cx-item-list-total\">\n          {{ 'saveForLaterItems.stock' | cxTranslate }}\n        </th>\n      </ng-container>\n      <ng-container\n        *ngIf=\"!readonly || options.isSaveForLater || options.displayAddToCart\"\n      >\n        <th role=\"columnheader\" scope=\"col\" class=\"cx-item-list-actions\">\n          {{ 'cartItems.actions' | cxTranslate }}\n        </th>\n      </ng-container>\n    </tr>\n  </thead>\n  <tbody class=\"cx-item-list-items\">\n    <ng-container *ngFor=\"let item of items; let i = index\">\n      <ng-container\n        *ngIf=\"getControl(item) | async as control\"\n        [class.is-changed]=\"control.get('quantity').disabled\"\n      >\n        <tr\n          cx-cart-item-list-row\n          role=\"row\"\n          class=\"cx-item-list-row\"\n          [items]=\"items\"\n          [item]=\"item\"\n          [quantityControl]=\"control.get('quantity')\"\n          [readonly]=\"readonly\"\n          [promotionLocation]=\"promotionLocation\"\n          [options]=\"getOptions(item)\"\n          [attr.aria-rowindex]=\"i + 1\"\n        ></tr>\n      </ng-container>\n    </ng-container>\n  </tbody>\n</table>\n\n<ng-template #totalHeader>\n  <th role=\"columnheader\" scope=\"col\" class=\"cx-item-list-total\">\n    {{ 'cartItems.total' | cxTranslate }}\n  </th>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: OutletDirective, selector: "[cxOutlet]", inputs: ["cxOutlet", "cxOutletContext", "cxOutletDefer", "cxComponentRef"], outputs: ["loaded", "cxComponentRefChange"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: CartItemListRowComponent, selector: "[cx-cart-item-list-row], cx-cart-item-list-row", inputs: ["items"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartItemListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-cart-item-list', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        OutletDirective,
                        NgFor,
                        CartItemListRowComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<table role=\"table\">\n  <caption class=\"cx-visually-hidden\">\n    {{\n      'cartItems.caption' | cxTranslate\n    }}\n  </caption>\n  <thead *ngIf=\"hasHeader\">\n    <tr role=\"row\" class=\"cx-item-list-header\">\n      <th role=\"columnheader\" scope=\"col\" class=\"cx-item-list-desc\">\n        {{ 'cartItems.item' | cxTranslate }}\n      </th>\n\n      <ng-template\n        [cxOutlet]=\"CartOutlets.SUBSCRIPTION_PRICE_HEADING\"\n        [cxOutletContext]=\"{\n          items,\n          parent: 'cart',\n        }\"\n      ></ng-template>\n\n      <ng-template\n        [cxOutlet]=\"CartOutlets.CPQ_QUOTE_HEADING\"\n        [cxOutletContext]=\"items\"\n      ></ng-template>\n      <th role=\"columnheader\" scope=\"col\" class=\"cx-item-list-qty\">\n        {{ 'cartItems.quantityFull' | cxTranslate }}\n      </th>\n      <ng-container *ngIf=\"options.isSaveForLater; else totalHeader\">\n        <th role=\"columnheader\" scope=\"col\" class=\"cx-item-list-total\">\n          {{ 'saveForLaterItems.stock' | cxTranslate }}\n        </th>\n      </ng-container>\n      <ng-container\n        *ngIf=\"!readonly || options.isSaveForLater || options.displayAddToCart\"\n      >\n        <th role=\"columnheader\" scope=\"col\" class=\"cx-item-list-actions\">\n          {{ 'cartItems.actions' | cxTranslate }}\n        </th>\n      </ng-container>\n    </tr>\n  </thead>\n  <tbody class=\"cx-item-list-items\">\n    <ng-container *ngFor=\"let item of items; let i = index\">\n      <ng-container\n        *ngIf=\"getControl(item) | async as control\"\n        [class.is-changed]=\"control.get('quantity').disabled\"\n      >\n        <tr\n          cx-cart-item-list-row\n          role=\"row\"\n          class=\"cx-item-list-row\"\n          [items]=\"items\"\n          [item]=\"item\"\n          [quantityControl]=\"control.get('quantity')\"\n          [readonly]=\"readonly\"\n          [promotionLocation]=\"promotionLocation\"\n          [options]=\"getOptions(item)\"\n          [attr.aria-rowindex]=\"i + 1\"\n        ></tr>\n      </ng-container>\n    </ng-container>\n  </tbody>\n</table>\n\n<ng-template #totalHeader>\n  <th role=\"columnheader\" scope=\"col\" class=\"cx-item-list-total\">\n    {{ 'cartItems.total' | cxTranslate }}\n  </th>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1$1.ActiveCartFacade }, { type: i1$1.SelectiveCartFacade }, { type: i2.UserIdService }, { type: i1$1.MultiCartFacade }, { type: i0.ChangeDetectorRef }, { type: i1.OutletContextData, decorators: [{
                    type: Optional
                }] }], propDecorators: { readonly: [{
                type: Input
            }], hasHeader: [{
                type: Input
            }], options: [{
                type: Input
            }], cartId: [{
                type: Input
            }], items: [{
                type: Input
            }], promotionLocation: [{
                type: Input
            }], cartIsLoading: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OrderSummaryComponent {
    constructor(outlet) {
        this.outlet = outlet;
        this.subscription = new Subscription();
    }
    ngOnInit() {
        if (this.outlet?.context$) {
            this.subscription.add(this.outlet.context$.subscribe((context) => (this.cart = context)));
        }
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderSummaryComponent, deps: [{ token: i1.OutletContextData, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OrderSummaryComponent, isStandalone: true, selector: "cx-order-summary", inputs: { cart: "cart" }, ngImport: i0, template: "<h3 class=\"cx-summary-heading\">\n  {{ 'orderCost.orderSummary' | cxTranslate }}\n</h3>\n\n<div class=\"cx-summary-partials\" *ngIf=\"cart\">\n  <div class=\"cx-summary-row\">\n    <div class=\"col-6 cx-summary-label\">\n      {{ 'orderCost.subtotal' | cxTranslate }}\n    </div>\n    <div class=\"col-6 cx-summary-amount\">\n      {{ cart.subTotal?.formattedValue }}\n    </div>\n  </div>\n  <div class=\"cx-summary-row\">\n    <div class=\"col-6 cx-summary-label\">\n      {{\n        (cart.deliveryCost?.formattedValue\n          ? 'orderCost.shipping'\n          : 'orderCost.estimatedShipping'\n        ) | cxTranslate\n      }}\n    </div>\n    <div class=\"col-6 cx-summary-amount\">\n      {{\n        cart.deliveryCost?.formattedValue\n          ? cart.deliveryCost?.formattedValue\n          : ('orderCost.toBeDetermined' | cxTranslate)\n      }}\n    </div>\n  </div>\n  <div class=\"cx-summary-row\" *ngIf=\"cart.net; else cartWithoutNet\">\n    <div class=\"col-6 cx-summary-label\">\n      {{ 'orderCost.salesTax' | cxTranslate }}\n    </div>\n    <div class=\"col-6 cx-summary-amount\">\n      {{ cart.totalTax?.formattedValue }}\n    </div>\n  </div>\n  <div class=\"cx-summary-row cx-summary-total\">\n    <div class=\"col-6 cx-summary-label\">\n      {{ 'orderCost.total' | cxTranslate }}\n    </div>\n    <div class=\"col-6 cx-summary-amount\">\n      {{ cart.totalPriceWithTax?.formattedValue }}\n    </div>\n  </div>\n  <div class=\"cx-summary-row\" *ngIf=\"cart.totalDiscounts?.value > 0\">\n    {{ 'orderCost.discount' | cxTranslate }}\n    {{ cart.totalDiscounts?.formattedValue }}\n  </div>\n  <ng-template #cartWithoutNet>\n    <div class=\"cx-summary-row\">\n      {{\n        cart.totalPriceWithTax?.value !== cart.totalPrice?.value\n          ? ('orderCost.grossTax' | cxTranslate)\n          : ('orderCost.grossIncludeTax' | cxTranslate)\n      }}\n      {{ cart.totalTax?.formattedValue }}.\n    </div>\n  </ng-template>\n</div>\n\n<cx-applied-coupons\n  [vouchers]=\"cart.appliedVouchers\"\n  [isReadOnly]=\"true\"\n></cx-applied-coupons>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: AppliedCouponsComponent, selector: "cx-applied-coupons", inputs: ["vouchers", "cartIsLoading", "isReadOnly"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderSummaryComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-order-summary', imports: [NgIf, AppliedCouponsComponent, TranslatePipe], template: "<h3 class=\"cx-summary-heading\">\n  {{ 'orderCost.orderSummary' | cxTranslate }}\n</h3>\n\n<div class=\"cx-summary-partials\" *ngIf=\"cart\">\n  <div class=\"cx-summary-row\">\n    <div class=\"col-6 cx-summary-label\">\n      {{ 'orderCost.subtotal' | cxTranslate }}\n    </div>\n    <div class=\"col-6 cx-summary-amount\">\n      {{ cart.subTotal?.formattedValue }}\n    </div>\n  </div>\n  <div class=\"cx-summary-row\">\n    <div class=\"col-6 cx-summary-label\">\n      {{\n        (cart.deliveryCost?.formattedValue\n          ? 'orderCost.shipping'\n          : 'orderCost.estimatedShipping'\n        ) | cxTranslate\n      }}\n    </div>\n    <div class=\"col-6 cx-summary-amount\">\n      {{\n        cart.deliveryCost?.formattedValue\n          ? cart.deliveryCost?.formattedValue\n          : ('orderCost.toBeDetermined' | cxTranslate)\n      }}\n    </div>\n  </div>\n  <div class=\"cx-summary-row\" *ngIf=\"cart.net; else cartWithoutNet\">\n    <div class=\"col-6 cx-summary-label\">\n      {{ 'orderCost.salesTax' | cxTranslate }}\n    </div>\n    <div class=\"col-6 cx-summary-amount\">\n      {{ cart.totalTax?.formattedValue }}\n    </div>\n  </div>\n  <div class=\"cx-summary-row cx-summary-total\">\n    <div class=\"col-6 cx-summary-label\">\n      {{ 'orderCost.total' | cxTranslate }}\n    </div>\n    <div class=\"col-6 cx-summary-amount\">\n      {{ cart.totalPriceWithTax?.formattedValue }}\n    </div>\n  </div>\n  <div class=\"cx-summary-row\" *ngIf=\"cart.totalDiscounts?.value > 0\">\n    {{ 'orderCost.discount' | cxTranslate }}\n    {{ cart.totalDiscounts?.formattedValue }}\n  </div>\n  <ng-template #cartWithoutNet>\n    <div class=\"cx-summary-row\">\n      {{\n        cart.totalPriceWithTax?.value !== cart.totalPrice?.value\n          ? ('orderCost.grossTax' | cxTranslate)\n          : ('orderCost.grossIncludeTax' | cxTranslate)\n      }}\n      {{ cart.totalTax?.formattedValue }}.\n    </div>\n  </ng-template>\n</div>\n\n<cx-applied-coupons\n  [vouchers]=\"cart.appliedVouchers\"\n  [isReadOnly]=\"true\"\n></cx-applied-coupons>\n" }]
        }], ctorParameters: () => [{ type: i1.OutletContextData, decorators: [{
                    type: Optional
                }] }], propDecorators: { cart: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartSharedModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartSharedModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CartSharedModule, imports: [AtMessageModule,
            CartCouponModule,
            CartItemValidationWarningModule,
            CommonModule,
            I18nModule,
            IconModule,
            ItemCounterModule,
            MediaModule,
            OutletModule,
            PromotionsModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            AddToCartModule,
            FeaturesConfigModule,
            CartItemComponent,
            OrderSummaryComponent,
            CartItemListComponent,
            CartItemListRowComponent], exports: [CartItemComponent,
            CartItemListRowComponent,
            CartItemListComponent,
            OrderSummaryComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartSharedModule, providers: [
            provideOutlet({
                id: CartOutlets.ORDER_SUMMARY,
                component: OrderSummaryComponent,
            }),
            provideOutlet({
                id: CartOutlets.CART_ITEM_LIST,
                component: CartItemListComponent,
            }),
        ], imports: [AtMessageModule,
            CartCouponModule,
            CartItemValidationWarningModule,
            CommonModule,
            I18nModule,
            IconModule,
            ItemCounterModule,
            MediaModule,
            OutletModule,
            PromotionsModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            AddToCartModule,
            FeaturesConfigModule,
            CartItemComponent,
            OrderSummaryComponent,
            CartItemListComponent,
            CartItemListRowComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartSharedModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        AtMessageModule,
                        CartCouponModule,
                        CartItemValidationWarningModule,
                        CommonModule,
                        I18nModule,
                        IconModule,
                        ItemCounterModule,
                        MediaModule,
                        OutletModule,
                        PromotionsModule,
                        ReactiveFormsModule,
                        RouterModule,
                        UrlModule,
                        AddToCartModule,
                        FeaturesConfigModule,
                        CartItemComponent,
                        OrderSummaryComponent,
                        CartItemListComponent,
                        CartItemListRowComponent,
                    ],
                    providers: [
                        provideOutlet({
                            id: CartOutlets.ORDER_SUMMARY,
                            component: OrderSummaryComponent,
                        }),
                        provideOutlet({
                            id: CartOutlets.CART_ITEM_LIST,
                            component: CartItemListComponent,
                        }),
                    ],
                    exports: [
                        CartItemComponent,
                        CartItemListRowComponent,
                        CartItemListComponent,
                        OrderSummaryComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultAddedToCartLayoutConfig = {
    launch: {
        ADDED_TO_CART: {
            inlineRoot: true,
            component: AddedToCartDialogComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AddedToCartDialogModule {
    constructor(_addToCartDialogEventListener) {
        // Intentional empty constructor
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddedToCartDialogModule, deps: [{ token: AddedToCartDialogEventListener }], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: AddedToCartDialogModule, imports: [CommonModule,
            ReactiveFormsModule,
            CartSharedModule,
            RouterModule,
            SpinnerModule,
            PromotionsModule,
            UrlModule,
            IconModule,
            I18nModule,
            ItemCounterModule,
            KeyboardFocusModule,
            FeaturesConfigModule,
            BtnLikeLinkModule,
            AddedToCartDialogComponent], exports: [AddedToCartDialogComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddedToCartDialogModule, providers: [provideDefaultConfig(defaultAddedToCartLayoutConfig)], imports: [CommonModule,
            ReactiveFormsModule,
            CartSharedModule,
            RouterModule,
            SpinnerModule,
            PromotionsModule,
            UrlModule,
            IconModule,
            I18nModule,
            ItemCounterModule,
            KeyboardFocusModule,
            FeaturesConfigModule,
            BtnLikeLinkModule,
            AddedToCartDialogComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddedToCartDialogModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        CartSharedModule,
                        RouterModule,
                        SpinnerModule,
                        PromotionsModule,
                        UrlModule,
                        IconModule,
                        I18nModule,
                        ItemCounterModule,
                        KeyboardFocusModule,
                        FeaturesConfigModule,
                        BtnLikeLinkModule,
                        AddedToCartDialogComponent,
                    ],
                    providers: [provideDefaultConfig(defaultAddedToCartLayoutConfig)],
                    exports: [AddedToCartDialogComponent],
                }]
        }], ctorParameters: () => [{ type: AddedToCartDialogEventListener }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ClearCartDialogComponentService {
    constructor(launchDialogService, globalMessageService, activeCartFacade, multiCartFacade, userIdService, eventService) {
        this.launchDialogService = launchDialogService;
        this.globalMessageService = globalMessageService;
        this.activeCartFacade = activeCartFacade;
        this.multiCartFacade = multiCartFacade;
        this.userIdService = userIdService;
        this.eventService = eventService;
    }
    /**
     * Clear the cart by deleting the active cart.
     */
    deleteActiveCart() {
        this.activeCartFacade
            .getActiveCartId()
            .pipe(withLatestFrom(this.userIdService.getUserId()), take(1), tap(([cartId, userId]) => {
            this.multiCartFacade.deleteCart(cartId, userId);
        }), switchMap(() => merge(this.eventService.get(DeleteCartSuccessEvent).pipe(map(() => true)), this.eventService.get(DeleteCartFailEvent).pipe(map(() => false))).pipe(take(1))), tap(() => this.closeDialog('Close dialog after cart cleared')))
            .subscribe((success) => {
            this.displayGlobalMessage(success);
        });
    }
    /**
     * Close clear cart modal dialog
     *
     * @param reason to close dialog
     */
    closeDialog(reason) {
        this.launchDialogService.closeDialog(reason);
    }
    /**
     * Display global message after clearing cart.
     * By default, only message displayed is of type `Success`. A negative scenario
     * related to cart has been handled in the occ layer already.
     *
     * @param success result of clear cart action
     */
    displayGlobalMessage(success) {
        if (success) {
            this.globalMessageService.add({ key: 'clearCart.cartClearedSuccessfully' }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ClearCartDialogComponentService, deps: [{ token: i1.LaunchDialogService }, { token: i2.GlobalMessageService }, { token: i1$1.ActiveCartFacade }, { token: i1$1.MultiCartFacade }, { token: i2.UserIdService }, { token: i2.EventService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ClearCartDialogComponentService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ClearCartDialogComponentService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.LaunchDialogService }, { type: i2.GlobalMessageService }, { type: i1$1.ActiveCartFacade }, { type: i1$1.MultiCartFacade }, { type: i2.UserIdService }, { type: i2.EventService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ClearCartDialogComponent {
    handleClick(event) {
        // Close on click outside the dialog window
        if (event.target.tagName === this.el.nativeElement.tagName) {
            this.close('Cross click');
        }
    }
    constructor(el, clearCartDialogComponentService) {
        this.el = el;
        this.clearCartDialogComponentService = clearCartDialogComponentService;
        this.focusConfig = {
            trap: true,
            block: true,
            autofocus: 'button.btn-primary',
            focusOnEscape: true,
        };
        this.isClearing = false;
        this.iconTypes = ICON_TYPE;
    }
    clearCart() {
        this.isClearing = true;
        this.clearCartDialogComponentService.deleteActiveCart();
    }
    close(reason) {
        this.clearCartDialogComponentService.closeDialog(reason);
    }
    ngOnDestroy() {
        this.close('close dialog on component destroy');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ClearCartDialogComponent, deps: [{ token: i0.ElementRef }, { token: ClearCartDialogComponentService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: ClearCartDialogComponent, isStandalone: true, selector: "cx-clear-cart-dialog", host: { listeners: { "click": "handleClick($event)" } }, ngImport: i0, template: "<div\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"close('Escape clicked')\"\n  class=\"modal-dialog modal-dialog-centered cx-clear-cart-dialog\"\n  role=\"dialog\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <div class=\"modal-content cx-clear-cart-container\">\n    <ng-container *ngIf=\"!isClearing; else loading\">\n      <!-- Modal Header -->\n      <div class=\"modal-header cx-clear-cart-header\">\n        <h3 id=\"dialogTitle\" class=\"cx-clear-cart-title modal-title\">\n          {{ 'clearCart.clearCart' | cxTranslate }}\n        </h3>\n\n        <button\n          (click)=\"close('Close Clear Cart Dialog')\"\n          [attr.aria-label]=\"'common.close' | cxTranslate\"\n          class=\"close\"\n          type=\"button\"\n          title=\"{{ 'common.close' | cxTranslate }}\"\n        >\n          <span aria-hidden=\"true\">\n            <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n          </span>\n        </button>\n      </div>\n\n      <!-- Modal Body -->\n      <div class=\"modal-body cx-clear-cart-body\">\n        <div class=\"clear-cart-msg\">\n          {{ 'clearCart.allItemsWillBeRemoved' | cxTranslate }}\n        </div>\n        <div class=\"clear-cart-warning\" role=\"alert\">\n          {{ 'clearCart.areYouSureToClearCart' | cxTranslate }}\n        </div>\n        <div>\n          <div class=\"cx-clear-cart-footer\">\n            <button\n              (click)=\"close('Cancel Clear Cart')\"\n              class=\"btn btn-secondary\"\n              type=\"button\"\n            >\n              {{ 'common.cancel' | cxTranslate }}\n            </button>\n            <button (click)=\"clearCart()\" class=\"btn btn-primary\" type=\"button\">\n              {{ 'clearCart.clearCart' | cxTranslate }}\n            </button>\n          </div>\n        </div>\n      </div>\n    </ng-container>\n  </div>\n</div>\n\n<ng-template #loading>\n  <div class=\"modal-header cx-clear-cart-header\">\n    <h2 class=\"cx-clear-cart-title modal-title\">\n      {{ 'clearCart.clearingCart' | cxTranslate }}\n    </h2>\n  </div>\n  <div class=\"cx-spinner\">\n    <cx-spinner></cx-spinner>\n  </div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ClearCartDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-clear-cart-dialog', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        FocusDirective,
                        NgIf,
                        IconComponent,
                        SpinnerComponent,
                        TranslatePipe,
                    ], template: "<div\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"close('Escape clicked')\"\n  class=\"modal-dialog modal-dialog-centered cx-clear-cart-dialog\"\n  role=\"dialog\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <div class=\"modal-content cx-clear-cart-container\">\n    <ng-container *ngIf=\"!isClearing; else loading\">\n      <!-- Modal Header -->\n      <div class=\"modal-header cx-clear-cart-header\">\n        <h3 id=\"dialogTitle\" class=\"cx-clear-cart-title modal-title\">\n          {{ 'clearCart.clearCart' | cxTranslate }}\n        </h3>\n\n        <button\n          (click)=\"close('Close Clear Cart Dialog')\"\n          [attr.aria-label]=\"'common.close' | cxTranslate\"\n          class=\"close\"\n          type=\"button\"\n          title=\"{{ 'common.close' | cxTranslate }}\"\n        >\n          <span aria-hidden=\"true\">\n            <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n          </span>\n        </button>\n      </div>\n\n      <!-- Modal Body -->\n      <div class=\"modal-body cx-clear-cart-body\">\n        <div class=\"clear-cart-msg\">\n          {{ 'clearCart.allItemsWillBeRemoved' | cxTranslate }}\n        </div>\n        <div class=\"clear-cart-warning\" role=\"alert\">\n          {{ 'clearCart.areYouSureToClearCart' | cxTranslate }}\n        </div>\n        <div>\n          <div class=\"cx-clear-cart-footer\">\n            <button\n              (click)=\"close('Cancel Clear Cart')\"\n              class=\"btn btn-secondary\"\n              type=\"button\"\n            >\n              {{ 'common.cancel' | cxTranslate }}\n            </button>\n            <button (click)=\"clearCart()\" class=\"btn btn-primary\" type=\"button\">\n              {{ 'clearCart.clearCart' | cxTranslate }}\n            </button>\n          </div>\n        </div>\n      </div>\n    </ng-container>\n  </div>\n</div>\n\n<ng-template #loading>\n  <div class=\"modal-header cx-clear-cart-header\">\n    <h2 class=\"cx-clear-cart-title modal-title\">\n      {{ 'clearCart.clearingCart' | cxTranslate }}\n    </h2>\n  </div>\n  <div class=\"cx-spinner\">\n    <cx-spinner></cx-spinner>\n  </div>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: ClearCartDialogComponentService }], propDecorators: { handleClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ClearCartDialogModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ClearCartDialogModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: ClearCartDialogModule, imports: [CommonModule,
            SpinnerModule,
            I18nModule,
            IconModule,
            KeyboardFocusModule,
            FeaturesConfigModule,
            ClearCartDialogComponent], exports: [ClearCartDialogComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ClearCartDialogModule, imports: [CommonModule,
            SpinnerModule,
            I18nModule,
            IconModule,
            KeyboardFocusModule,
            FeaturesConfigModule,
            ClearCartDialogComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ClearCartDialogModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        SpinnerModule,
                        I18nModule,
                        IconModule,
                        KeyboardFocusModule,
                        FeaturesConfigModule,
                        ClearCartDialogComponent,
                    ],
                    exports: [ClearCartDialogComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultClearCartLayoutConfig = {
    launch: {
        CLEAR_CART: {
            inline: true,
            component: ClearCartDialogComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ClearCartComponent {
    constructor(activeCartFacade, vcr, launchDialogService) {
        this.activeCartFacade = activeCartFacade;
        this.vcr = vcr;
        this.launchDialogService = launchDialogService;
        this.cart$ = this.activeCartFacade.getActive();
        this.subscription = new Subscription();
    }
    openDialog(event) {
        const dialog = this.launchDialogService.openDialog(LAUNCH_CALLER.CLEAR_CART, this.element, this.vcr);
        if (dialog) {
            this.subscription.add(dialog.pipe(take(1)).subscribe());
        }
        event.stopPropagation();
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ClearCartComponent, deps: [{ token: i1$1.ActiveCartFacade }, { token: i0.ViewContainerRef }, { token: i1.LaunchDialogService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: ClearCartComponent, isStandalone: true, selector: "cx-clear-cart", viewQueries: [{ propertyName: "element", first: true, predicate: ["element"], descendants: true }], ngImport: i0, template: "<ng-container *ngIf=\"cart$ | async as cart\">\n  <div *ngIf=\"cart.totalItems > 0\" class=\"clear-cart-wrapper\">\n    <button\n      #element\n      (click)=\"openDialog($event)\"\n      class=\"btn btn-tertiary clear-cart-btn\"\n      type=\"button\"\n    >\n      {{ 'clearCart.clearCart' | cxTranslate }}\n    </button>\n  </div>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ClearCartComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-clear-cart', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"cart$ | async as cart\">\n  <div *ngIf=\"cart.totalItems > 0\" class=\"clear-cart-wrapper\">\n    <button\n      #element\n      (click)=\"openDialog($event)\"\n      class=\"btn btn-tertiary clear-cart-btn\"\n      type=\"button\"\n    >\n      {{ 'clearCart.clearCart' | cxTranslate }}\n    </button>\n  </div>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: i1$1.ActiveCartFacade }, { type: i0.ViewContainerRef }, { type: i1.LaunchDialogService }], propDecorators: { element: [{
                type: ViewChild,
                args: ['element']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ClearCartModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ClearCartModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: ClearCartModule, imports: [CommonModule,
            I18nModule,
            ClearCartDialogModule,
            ClearCartComponent], exports: [ClearCartComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ClearCartModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    ClearCartComponent: {
                        component: ClearCartComponent,
                    },
                },
            }),
            provideDefaultConfig(defaultClearCartLayoutConfig),
        ], imports: [CommonModule,
            I18nModule,
            ClearCartDialogModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ClearCartModule, decorators: [{
            type: NgModule,
            args: [{
                    exports: [ClearCartComponent],
                    imports: [
                        CommonModule,
                        I18nModule,
                        ClearCartDialogModule,
                        ClearCartComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                ClearCartComponent: {
                                    component: ClearCartComponent,
                                },
                            },
                        }),
                        provideDefaultConfig(defaultClearCartLayoutConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartValidationWarningsComponent {
    constructor(cartValidationFacade) {
        this.cartValidationFacade = cartValidationFacade;
        this.iconTypes = ICON_TYPE;
        this.visibleWarnings = {};
        this.cartModifications$ = this.cartValidationFacade.getValidationResults().pipe(map((modificationList) => {
            const result = modificationList.filter((modification) => modification.statusCode === CartValidationStatusCode.NO_STOCK);
            result.forEach((modification) => {
                if (modification.entry?.product?.code) {
                    this.visibleWarnings[modification.entry.product.code] = true;
                }
            });
            return result;
        }));
    }
    removeMessage(cartModification) {
        if (cartModification.entry?.product?.code) {
            this.visibleWarnings[cartModification.entry.product.code] = false;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartValidationWarningsComponent, deps: [{ token: i1$1.CartValidationFacade }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CartValidationWarningsComponent, isStandalone: true, selector: "cx-cart-validation-warnings", ngImport: i0, template: "<ng-container *ngFor=\"let cartModification of cartModifications$ | async\">\n  <div\n    class=\"alert alert-danger\"\n    *ngIf=\"visibleWarnings[cartModification.entry.product.code]\"\n  >\n    <span class=\"alert-icon\">\n      <cx-icon [type]=\"iconTypes.ERROR\"></cx-icon>\n    </span>\n    <span>\n      <a\n        [routerLink]=\"\n          { cxRoute: 'product', params: cartModification.entry.product } | cxUrl\n        \"\n      >\n        {{ cartModification.entry.product.name }}\n      </a>\n      {{ 'validation.productOutOfStock' | cxTranslate }}\n    </span>\n\n    <button\n      class=\"close\"\n      type=\"button\"\n      title=\"{{ 'common.close' | cxTranslate }}\"\n      [attr.aria-label]=\"'common.close' | cxTranslate\"\n      (click)=\"removeMessage(cartModification)\"\n    >\n      <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n    </button>\n  </div>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartValidationWarningsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-cart-validation-warnings', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgFor,
                        NgIf,
                        IconComponent,
                        RouterLink,
                        AsyncPipe,
                        TranslatePipe,
                        UrlPipe,
                    ], template: "<ng-container *ngFor=\"let cartModification of cartModifications$ | async\">\n  <div\n    class=\"alert alert-danger\"\n    *ngIf=\"visibleWarnings[cartModification.entry.product.code]\"\n  >\n    <span class=\"alert-icon\">\n      <cx-icon [type]=\"iconTypes.ERROR\"></cx-icon>\n    </span>\n    <span>\n      <a\n        [routerLink]=\"\n          { cxRoute: 'product', params: cartModification.entry.product } | cxUrl\n        \"\n      >\n        {{ cartModification.entry.product.name }}\n      </a>\n      {{ 'validation.productOutOfStock' | cxTranslate }}\n    </span>\n\n    <button\n      class=\"close\"\n      type=\"button\"\n      title=\"{{ 'common.close' | cxTranslate }}\"\n      [attr.aria-label]=\"'common.close' | cxTranslate\"\n      (click)=\"removeMessage(cartModification)\"\n    >\n      <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n    </button>\n  </div>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: i1$1.CartValidationFacade }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartValidationWarningsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartValidationWarningsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CartValidationWarningsModule, imports: [CommonModule,
            RouterModule,
            I18nModule,
            UrlModule,
            IconModule,
            CartValidationWarningsComponent], exports: [CartValidationWarningsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartValidationWarningsModule, imports: [CommonModule,
            RouterModule,
            I18nModule,
            UrlModule,
            IconModule,
            CartValidationWarningsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartValidationWarningsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        I18nModule,
                        UrlModule,
                        IconModule,
                        CartValidationWarningsComponent,
                    ],
                    exports: [CartValidationWarningsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartDetailsComponent {
    constructor(activeCartService, selectiveCartService, authService, routingService, cartConfig) {
        this.activeCartService = activeCartService;
        this.selectiveCartService = selectiveCartService;
        this.authService = authService;
        this.routingService = routingService;
        this.cartConfig = cartConfig;
        this.loggedIn = false;
        this.promotionLocation = PromotionLocation.ActiveCart;
    }
    ngOnInit() {
        this.cart$ = this.activeCartService.getActive();
        this.entries$ = this.activeCartService
            .getEntries()
            .pipe(filter((entries) => entries.length > 0));
        this.selectiveCartEnabled = this.cartConfig.isSelectiveCartEnabled();
        this.cartLoaded$ = combineLatest([
            this.activeCartService.isStable(),
            this.selectiveCartEnabled
                ? this.selectiveCartService.isStable()
                : of(false),
            this.authService.isUserLoggedIn(),
        ]).pipe(tap(([, , loggedIn]) => (this.loggedIn = loggedIn)), map(([cartLoaded, sflLoaded, loggedIn]) => loggedIn && this.selectiveCartEnabled
            ? cartLoaded && sflLoaded
            : cartLoaded));
    }
    saveForLater(item) {
        if (this.loggedIn) {
            this.activeCartService.removeEntry(item);
            this.selectiveCartService.addEntry(item.product?.code ?? '', item.quantity ?? 0);
        }
        else {
            this.routingService.go({ cxRoute: 'login' });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartDetailsComponent, deps: [{ token: i1$1.ActiveCartFacade }, { token: i1$1.SelectiveCartFacade }, { token: i2.AuthService }, { token: i2.RoutingService }, { token: i3.CartConfigService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CartDetailsComponent, isStandalone: true, selector: "cx-cart-details", ngImport: i0, template: "<ng-container *ngIf=\"cart$ | async as cart\">\n  <ng-container *ngIf=\"entries$ | async as entries\">\n    <div *ngIf=\"cart.totalItems > 0\" class=\"cart-details-wrapper\">\n      <cx-cart-validation-warnings></cx-cart-validation-warnings>\n\n      <h2 class=\"cx-total\">\n        {{ 'cartDetails.cartName' | cxTranslate: { code: cart.code } }}\n      </h2>\n\n      <cx-promotions\n        [promotions]=\"\n          (cart.appliedOrderPromotions || []).concat(\n            cart.potentialOrderPromotions || []\n          )\n        \"\n      ></cx-promotions>\n\n      <cx-cart-item-list\n        [items]=\"entries\"\n        [cartIsLoading]=\"!(cartLoaded$ | async)\"\n        [promotionLocation]=\"promotionLocation\"\n        [options]=\"{\n          isSaveForLater: false,\n          optionalBtn: saveForLaterBtn,\n        }\"\n      ></cx-cart-item-list>\n    </div>\n  </ng-container>\n</ng-container>\n\n<ng-template let-ctx #saveForLaterBtn>\n  <button\n    *ngIf=\"selectiveCartEnabled\"\n    class=\"btn btn-tertiary cx-sfl-btn\"\n    [disabled]=\"ctx.loading\"\n    (click)=\"saveForLater(ctx.item)\"\n    type=\"button\"\n  >\n    {{ 'saveForLaterItems.saveForLater' | cxTranslate }}\n  </button>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CartValidationWarningsComponent, selector: "cx-cart-validation-warnings" }, { kind: "component", type: PromotionsComponent, selector: "cx-promotions", inputs: ["promotions"] }, { kind: "component", type: CartItemListComponent, selector: "cx-cart-item-list", inputs: ["readonly", "hasHeader", "options", "cartId", "items", "promotionLocation", "cartIsLoading"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-cart-details', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        CartValidationWarningsComponent,
                        PromotionsComponent,
                        CartItemListComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<ng-container *ngIf=\"cart$ | async as cart\">\n  <ng-container *ngIf=\"entries$ | async as entries\">\n    <div *ngIf=\"cart.totalItems > 0\" class=\"cart-details-wrapper\">\n      <cx-cart-validation-warnings></cx-cart-validation-warnings>\n\n      <h2 class=\"cx-total\">\n        {{ 'cartDetails.cartName' | cxTranslate: { code: cart.code } }}\n      </h2>\n\n      <cx-promotions\n        [promotions]=\"\n          (cart.appliedOrderPromotions || []).concat(\n            cart.potentialOrderPromotions || []\n          )\n        \"\n      ></cx-promotions>\n\n      <cx-cart-item-list\n        [items]=\"entries\"\n        [cartIsLoading]=\"!(cartLoaded$ | async)\"\n        [promotionLocation]=\"promotionLocation\"\n        [options]=\"{\n          isSaveForLater: false,\n          optionalBtn: saveForLaterBtn,\n        }\"\n      ></cx-cart-item-list>\n    </div>\n  </ng-container>\n</ng-container>\n\n<ng-template let-ctx #saveForLaterBtn>\n  <button\n    *ngIf=\"selectiveCartEnabled\"\n    class=\"btn btn-tertiary cx-sfl-btn\"\n    [disabled]=\"ctx.loading\"\n    (click)=\"saveForLater(ctx.item)\"\n    type=\"button\"\n  >\n    {{ 'saveForLaterItems.saveForLater' | cxTranslate }}\n  </button>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1$1.ActiveCartFacade }, { type: i1$1.SelectiveCartFacade }, { type: i2.AuthService }, { type: i2.RoutingService }, { type: i3.CartConfigService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartDetailsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartDetailsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CartDetailsModule, imports: [CartSharedModule,
            CommonModule,
            CartCouponModule,
            RouterModule,
            UrlModule,
            PromotionsModule,
            I18nModule,
            CartValidationWarningsModule,
            CartDetailsComponent], exports: [CartDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartDetailsModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    CartComponent: {
                        component: CartDetailsComponent,
                    },
                },
            }),
        ], imports: [CartSharedModule,
            CommonModule,
            CartCouponModule,
            RouterModule,
            UrlModule,
            PromotionsModule,
            I18nModule,
            CartValidationWarningsModule,
            CartDetailsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartDetailsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CartSharedModule,
                        CommonModule,
                        CartCouponModule,
                        RouterModule,
                        UrlModule,
                        PromotionsModule,
                        I18nModule,
                        CartValidationWarningsModule,
                        CartDetailsComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                CartComponent: {
                                    component: CartDetailsComponent,
                                },
                            },
                        }),
                    ],
                    exports: [CartDetailsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartPageLayoutHandler {
    constructor(activeCartService, selectiveCartService, cartConfig) {
        this.activeCartService = activeCartService;
        this.selectiveCartService = selectiveCartService;
        this.cartConfig = cartConfig;
    }
    handle(slots$, pageTemplate, section) {
        if (pageTemplate === 'CartPageTemplate' && !section) {
            return combineLatest([
                slots$,
                this.activeCartService.getActive(),
                this.getSelectiveCart(),
                this.activeCartService.getLoading(),
            ]).pipe(map(([slots, cart, selectiveCart, loadingCart]) => {
                const exclude = (arr, args) => arr.filter((item) => args.every((arg) => arg !== item));
                return isEmpty(cart) && loadingCart
                    ? exclude(slots, [
                        'TopContent',
                        'CenterRightContentSlot',
                        'EmptyCartMiddleContent',
                    ])
                    : cart.totalItems
                        ? exclude(slots, ['EmptyCartMiddleContent'])
                        : selectiveCart?.totalItems
                            ? exclude(slots, [
                                'EmptyCartMiddleContent',
                                'CenterRightContentSlot',
                            ])
                            : exclude(slots, ['TopContent', 'CenterRightContentSlot']);
            }));
        }
        return slots$;
    }
    getSelectiveCart() {
        return this.cartConfig.isSelectiveCartEnabled()
            ? this.selectiveCartService.getCart().pipe(startWith(null))
            : of({});
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartPageLayoutHandler, deps: [{ token: i1$1.ActiveCartFacade }, { token: i1$1.SelectiveCartFacade }, { token: i3.CartConfigService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartPageLayoutHandler, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartPageLayoutHandler, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.ActiveCartFacade }, { type: i1$1.SelectiveCartFacade }, { type: i3.CartConfigService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartProceedToCheckoutComponent {
    constructor(router, cd) {
        this.router = router;
        this.cd = cd;
        this.cartValidationInProgress = false;
        this.subscription = new Subscription();
    }
    ngOnInit() {
        this.subscription.add(this.router.events.subscribe((event) => {
            if (event instanceof NavigationEnd ||
                event instanceof NavigationCancel) {
                this.cartValidationInProgress = false;
                this.cd?.markForCheck();
            }
        }));
    }
    disableButtonWhileNavigation() {
        this.cartValidationInProgress = true;
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartProceedToCheckoutComponent, deps: [{ token: i1$2.Router }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CartProceedToCheckoutComponent, isStandalone: true, selector: "cx-cart-proceed-to-checkout", ngImport: i0, template: "<cx-progress-button\n  (clickEvent)=\"disableButtonWhileNavigation()\"\n  [class]=\"'btn btn-primary btn-block'\"\n  [disabled]=\"cartValidationInProgress\"\n  [loading]=\"cartValidationInProgress\"\n  [routerLink]=\"{ cxRoute: 'checkout' } | cxUrl\"\n  tabindex=\"-1\"\n>\n  {{\n    (cartValidationInProgress\n      ? 'validation.inProgress'\n      : 'cartDetails.proceedToCheckout'\n    ) | cxTranslate\n  }}\n</cx-progress-button>\n", dependencies: [{ kind: "component", type: ProgressButtonComponent, selector: "cx-progress-button", inputs: ["ariaLabel", "class", "disabled", "loading"], outputs: ["clickEvent"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartProceedToCheckoutComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-cart-proceed-to-checkout', changeDetection: ChangeDetectionStrategy.OnPush, imports: [ProgressButtonComponent, RouterLink, TranslatePipe, UrlPipe], template: "<cx-progress-button\n  (clickEvent)=\"disableButtonWhileNavigation()\"\n  [class]=\"'btn btn-primary btn-block'\"\n  [disabled]=\"cartValidationInProgress\"\n  [loading]=\"cartValidationInProgress\"\n  [routerLink]=\"{ cxRoute: 'checkout' } | cxUrl\"\n  tabindex=\"-1\"\n>\n  {{\n    (cartValidationInProgress\n      ? 'validation.inProgress'\n      : 'cartDetails.proceedToCheckout'\n    ) | cxTranslate\n  }}\n</cx-progress-button>\n" }]
        }], ctorParameters: () => [{ type: i1$2.Router }, { type: i0.ChangeDetectorRef }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartProceedToCheckoutModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartProceedToCheckoutModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CartProceedToCheckoutModule, imports: [CommonModule,
            ProgressButtonModule,
            RouterModule,
            I18nModule,
            UrlModule,
            CartProceedToCheckoutComponent], exports: [CartProceedToCheckoutComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartProceedToCheckoutModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    CartProceedToCheckoutComponent: {
                        component: CartProceedToCheckoutComponent,
                    },
                },
            }),
        ], imports: [CommonModule,
            ProgressButtonModule,
            RouterModule,
            I18nModule,
            UrlModule,
            CartProceedToCheckoutComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartProceedToCheckoutModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        ProgressButtonModule,
                        RouterModule,
                        I18nModule,
                        UrlModule,
                        CartProceedToCheckoutComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                CartProceedToCheckoutComponent: {
                                    component: CartProceedToCheckoutComponent,
                                },
                            },
                        }),
                    ],
                    exports: [CartProceedToCheckoutComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartTotalsComponent {
    constructor(activeCartService) {
        this.activeCartService = activeCartService;
    }
    ngOnInit() {
        this.cart$ = this.activeCartService.getActive();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartTotalsComponent, deps: [{ token: i1$1.ActiveCartFacade }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CartTotalsComponent, isStandalone: true, selector: "cx-cart-totals", ngImport: i0, template: "<ng-container *ngIf=\"cart$ | async as cart\">\n  <cx-order-summary [cart]=\"cart\"></cx-order-summary>\n</ng-container>\n", dependencies: [{ kind: "component", type: OrderSummaryComponent, selector: "cx-order-summary", inputs: ["cart"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartTotalsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-cart-totals', changeDetection: ChangeDetectionStrategy.OnPush, imports: [OrderSummaryComponent, AsyncPipe, NgIf], template: "<ng-container *ngIf=\"cart$ | async as cart\">\n  <cx-order-summary [cart]=\"cart\"></cx-order-summary>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: i1$1.ActiveCartFacade }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartTotalsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartTotalsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CartTotalsModule, imports: [CommonModule, CartSharedModule, CartTotalsComponent], exports: [CartTotalsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartTotalsModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    CartTotalsComponent: {
                        component: CartTotalsComponent,
                    },
                },
            }),
        ], imports: [CommonModule, CartSharedModule, CartTotalsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartTotalsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, CartSharedModule, CartTotalsComponent],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                CartTotalsComponent: {
                                    component: CartTotalsComponent,
                                },
                            },
                        }),
                    ],
                    exports: [CartTotalsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ActiveCartOrderEntriesContext {
    constructor(importInfoService, activeCartFacade) {
        this.importInfoService = importInfoService;
        this.activeCartFacade = activeCartFacade;
        this.type = OrderEntriesSource.ACTIVE_CART;
    }
    addEntries(products) {
        return this.add(products).pipe(switchMap((cartId) => this.importInfoService.getResults(cartId)), take(products.length));
    }
    getEntries() {
        return this.activeCartFacade.getEntries();
    }
    add(products) {
        this.activeCartFacade.addEntries(this.mapProductsToOrderEntries(products));
        return this.activeCartFacade.getActiveCartId();
    }
    mapProductsToOrderEntries(products) {
        return products.map((product) => ({
            product: { code: product.productCode },
            quantity: product.quantity,
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ActiveCartOrderEntriesContext, deps: [{ token: i3.ProductImportInfoService }, { token: i1$1.ActiveCartFacade }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ActiveCartOrderEntriesContext, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ActiveCartOrderEntriesContext, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i3.ProductImportInfoService }, { type: i1$1.ActiveCartFacade }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SaveForLaterComponent {
    constructor(cmsService, cartService, selectiveCartService) {
        this.cmsService = cmsService;
        this.cartService = cartService;
        this.selectiveCartService = selectiveCartService;
        this.CartLocation = PromotionLocation;
    }
    ngOnInit() {
        this.isCartEmpty$ = this.cartService
            .getActive()
            .pipe(map((cart) => !(cart && cart.totalItems && cart.totalItems > 0)));
        this.saveForLater$ = this.selectiveCartService.getCart();
        this.entries$ = this.selectiveCartService
            .getEntries()
            .pipe(filter((entries) => entries.length > 0));
        this.cartLoaded$ = combineLatest([
            this.cartService.isStable(),
            this.selectiveCartService.isStable(),
        ]).pipe(map(([cartLoaded, sflLoaded]) => cartLoaded && sflLoaded));
        this.data$ = this.cmsService.getComponentData('EmptyCartParagraphComponent');
    }
    moveToCart(item) {
        this.selectiveCartService.removeEntry(item);
        this.cartService.addEntry(item.product?.code ?? '', item.quantity ?? 0);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SaveForLaterComponent, deps: [{ token: i2.CmsService }, { token: i1$1.ActiveCartFacade }, { token: i1$1.SelectiveCartFacade }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: SaveForLaterComponent, isStandalone: true, selector: "cx-save-for-later", ngImport: i0, template: "<ng-container *ngIf=\"isCartEmpty$ | async\">\n  <p\n    *ngIf=\"data$ | async as data\"\n    [innerHTML]=\"data.content\"\n    class=\"cx-empty-cart-info\"\n  ></p>\n</ng-container>\n\n<ng-container *ngIf=\"saveForLater$ | async as saveForLater\">\n  <ng-container *ngIf=\"entries$ | async as entries\">\n    <div *ngIf=\"saveForLater.totalItems > 0\" class=\"cart-details-wrapper\">\n      <div class=\"cx-total\">\n        {{\n          'saveForLaterItems.itemTotal'\n            | cxTranslate: { count: saveForLater.totalItems }\n        }}\n      </div>\n      <cx-cart-item-list\n        [items]=\"entries\"\n        [readonly]=\"false\"\n        [cartIsLoading]=\"!(cartLoaded$ | async)\"\n        [promotionLocation]=\"CartLocation.SaveForLater\"\n        [options]=\"{\n          isSaveForLater: true,\n          optionalBtn: moveToCartBtn,\n        }\"\n      ></cx-cart-item-list>\n    </div>\n  </ng-container>\n</ng-container>\n\n<ng-template let-ctx #moveToCartBtn>\n  <button\n    class=\"btn btn-tertiary cx-sfl-btn\"\n    [disabled]=\"ctx.loading\"\n    (click)=\"moveToCart(ctx.item)\"\n    type=\"button\"\n  >\n    {{ 'saveForLaterItems.moveToCart' | cxTranslate }}\n  </button>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CartItemListComponent, selector: "cx-cart-item-list", inputs: ["readonly", "hasHeader", "options", "cartId", "items", "promotionLocation", "cartIsLoading"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SaveForLaterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-save-for-later', imports: [NgIf, CartItemListComponent, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"isCartEmpty$ | async\">\n  <p\n    *ngIf=\"data$ | async as data\"\n    [innerHTML]=\"data.content\"\n    class=\"cx-empty-cart-info\"\n  ></p>\n</ng-container>\n\n<ng-container *ngIf=\"saveForLater$ | async as saveForLater\">\n  <ng-container *ngIf=\"entries$ | async as entries\">\n    <div *ngIf=\"saveForLater.totalItems > 0\" class=\"cart-details-wrapper\">\n      <div class=\"cx-total\">\n        {{\n          'saveForLaterItems.itemTotal'\n            | cxTranslate: { count: saveForLater.totalItems }\n        }}\n      </div>\n      <cx-cart-item-list\n        [items]=\"entries\"\n        [readonly]=\"false\"\n        [cartIsLoading]=\"!(cartLoaded$ | async)\"\n        [promotionLocation]=\"CartLocation.SaveForLater\"\n        [options]=\"{\n          isSaveForLater: true,\n          optionalBtn: moveToCartBtn,\n        }\"\n      ></cx-cart-item-list>\n    </div>\n  </ng-container>\n</ng-container>\n\n<ng-template let-ctx #moveToCartBtn>\n  <button\n    class=\"btn btn-tertiary cx-sfl-btn\"\n    [disabled]=\"ctx.loading\"\n    (click)=\"moveToCart(ctx.item)\"\n    type=\"button\"\n  >\n    {{ 'saveForLaterItems.moveToCart' | cxTranslate }}\n  </button>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i2.CmsService }, { type: i1$1.ActiveCartFacade }, { type: i1$1.SelectiveCartFacade }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SaveForLaterModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SaveForLaterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: SaveForLaterModule, imports: [CommonModule, I18nModule, CartSharedModule, SaveForLaterComponent], exports: [SaveForLaterComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SaveForLaterModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    SaveForLaterComponent: {
                        component: SaveForLaterComponent,
                    },
                },
            }),
        ], imports: [CommonModule, I18nModule, CartSharedModule, SaveForLaterComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SaveForLaterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, I18nModule, CartSharedModule, SaveForLaterComponent],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                SaveForLaterComponent: {
                                    component: SaveForLaterComponent,
                                },
                            },
                        }),
                    ],
                    exports: [SaveForLaterComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartBaseComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartBaseComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CartBaseComponentsModule, imports: [CommonModule,
            CartDetailsModule,
            CartProceedToCheckoutModule,
            CartTotalsModule,
            CartSharedModule,
            SaveForLaterModule,
            ClearCartModule, i1.OutletModule], exports: [CartDetailsModule,
            CartProceedToCheckoutModule,
            CartTotalsModule,
            CartSharedModule,
            ClearCartModule,
            AddedToCartDialogModule,
            SaveForLaterModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartBaseComponentsModule, providers: [
            {
                provide: PAGE_LAYOUT_HANDLER,
                useExisting: CartPageLayoutHandler,
                multi: true,
            },
            {
                provide: ActiveCartOrderEntriesContextToken,
                useExisting: ActiveCartOrderEntriesContext,
            },
        ], imports: [CommonModule,
            CartDetailsModule,
            CartProceedToCheckoutModule,
            CartTotalsModule,
            CartSharedModule,
            SaveForLaterModule,
            ClearCartModule,
            OutletModule.forChild(), CartDetailsModule,
            CartProceedToCheckoutModule,
            CartTotalsModule,
            CartSharedModule,
            ClearCartModule,
            AddedToCartDialogModule,
            SaveForLaterModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartBaseComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        CartDetailsModule,
                        CartProceedToCheckoutModule,
                        CartTotalsModule,
                        CartSharedModule,
                        SaveForLaterModule,
                        ClearCartModule,
                        OutletModule.forChild(),
                    ],
                    exports: [
                        CartDetailsModule,
                        CartProceedToCheckoutModule,
                        CartTotalsModule,
                        CartSharedModule,
                        ClearCartModule,
                        AddedToCartDialogModule,
                        SaveForLaterModule,
                    ],
                    providers: [
                        {
                            provide: PAGE_LAYOUT_HANDLER,
                            useExisting: CartPageLayoutHandler,
                            multi: true,
                        },
                        {
                            provide: ActiveCartOrderEntriesContextToken,
                            useExisting: ActiveCartOrderEntriesContext,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartValidationComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartValidationComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CartValidationComponentsModule, imports: [CartValidationWarningsModule, CartItemValidationWarningModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartValidationComponentsModule, imports: [CartValidationWarningsModule, CartItemValidationWarningModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartValidationComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CartValidationWarningsModule, CartItemValidationWarningModule],
                    providers: [],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AbstractOrderContext, AbstractOrderContextDirective, AbstractOrderContextModule, AbstractOrderContextSource, ActiveCartOrderEntriesContext, AddedToCartDialogComponent, AddedToCartDialogEventListener, AddedToCartDialogModule, AppliedCouponsComponent, CartBaseComponentsModule, CartCouponComponent, CartCouponModule, CartDetailsComponent, CartDetailsModule, CartItemComponent, CartItemContextSource, CartItemListComponent, CartItemListComponentService, CartItemListRowComponent, CartPageLayoutHandler, CartProceedToCheckoutComponent, CartProceedToCheckoutModule, CartSharedModule, CartTotalsComponent, CartTotalsModule, CartValidationComponentsModule, CartValidationWarningsComponent, CartValidationWarningsModule, ClearCartComponent, ClearCartDialogComponent, ClearCartDialogComponentService, ClearCartDialogModule, ClearCartModule, OrderSummaryComponent, SaveForLaterComponent, SaveForLaterModule, defaultClearCartLayoutConfig };
//# sourceMappingURL=spartacus-cart-base-components.mjs.map
