import * as i0 from '@angular/core';
import { NgModule, inject, Injectable } from '@angular/core';
import { WishListComponentsModule } from '@spartacus/cart/wish-list/components';
import { WishListCoreModule } from '@spartacus/cart/wish-list/core';
import { WishListFacade } from '@spartacus/cart/wish-list/root';
import { UserIdService, ProductSearchConnector, OCC_USER_ID_ANONYMOUS, provideDefaultConfig } from '@spartacus/core';
import { UserWishlistConnector, UserWishlistAdapter } from '@spartacus/user/wishlist/core';
import { OccUserWishlistAdapter, defaultOccUserWishlistConfig } from '@spartacus/user/wishlist/occ';
import { BehaviorSubject, combineLatest, of } from 'rxjs';
import { filter, switchMap, catchError, shareReplay, map, take, mergeMap } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class WishListModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: WishListModule, imports: [WishListComponentsModule, WishListCoreModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListModule, imports: [WishListComponentsModule, WishListCoreModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [WishListComponentsModule, WishListCoreModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class WishListV2Service {
    constructor() {
        this.userIdService = inject(UserIdService);
        this.connector = inject(UserWishlistConnector);
        this.productSearchConnector = inject(ProductSearchConnector);
        this.refresh$ = new BehaviorSubject(undefined);
    }
    get wishlistV2$() {
        this._wishlistV2$ ??= combineLatest([
            this.userIdService.getUserId(),
            this.refresh$,
        ]).pipe(filter(([userId]) => userId !== OCC_USER_ID_ANONYMOUS), switchMap(([userId]) => this.connector
            .getWishlist(userId)
            .pipe(catchError(() => of({ entries: [] })))), switchMap((wishlist) => this.enrichWithProducts(wishlist)), shareReplay({ bufferSize: 1, refCount: false }));
        return this._wishlistV2$;
    }
    enrichWithProducts(wishlist) {
        const entries = wishlist.entries ?? [];
        if (entries.length === 0) {
            return of(wishlist);
        }
        const codes = entries
            .map((e) => e.productCode ?? '')
            .filter((code) => !!code);
        return this.productSearchConnector.searchByCodes(codes).pipe(map(({ products }) => {
            const productMap = new Map(products.map((p) => [p.code, p]));
            return {
                ...wishlist,
                entries: entries.map((entry) => ({
                    ...entry,
                    product: productMap.get(entry.productCode ?? '') ??
                        { code: entry.productCode },
                })),
            };
        }), catchError(() => of(wishlist)));
    }
    // no-op: the backend creates the default wishlist automatically on first entry
    createWishList(_userId, _name, _description) { }
    // no-op: data is loaded lazily via getWishList()
    loadWishList(_userId, _customerId) { }
    getWishList() {
        return this.wishlistV2$.pipe(map((wl) => this.mapWishlistToCart(wl)));
    }
    addEntry(productCode) {
        combineLatest([this.userIdService.getUserId(), this.wishlistV2$])
            .pipe(take(1), map(([userId, wl]) => ({ userId, wishlistId: wl.id ?? 'default' })), mergeMap(({ userId, wishlistId }) => this.connector.addEntry(userId, wishlistId, productCode)))
            .subscribe(() => this.refresh$.next());
    }
    removeEntry(entry) {
        const entryId = entry.wishlistEntryId;
        combineLatest([this.userIdService.getUserId(), this.wishlistV2$])
            .pipe(take(1), map(([userId, wl]) => ({ userId, wishlistId: wl.id ?? 'default' })), mergeMap(({ userId, wishlistId }) => this.connector.removeEntry(userId, wishlistId, entryId)))
            .subscribe(() => this.refresh$.next());
    }
    getWishListLoading() {
        return of(false);
    }
    mapWishlistToCart(wl) {
        return {
            code: wl.id,
            entries: (wl.entries ?? []).map((e, idx) => ({
                entryNumber: idx,
                wishlistEntryId: e.id,
                product: e.product ?? { code: e.productCode },
                basePrice: e.product?.price,
                updateable: true,
                quantity: 1,
            })),
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListV2Service, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListV2Service }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListV2Service, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Optional NgModule that switches the Wish List feature to use the new dedicated
 * Wishlist OCC API (`/wishlists`) instead of the SavedCart-based API.
 *
 * Import this module in your application when the `wishlistV2` API is available
 * on the backend. It overrides `WishListFacade` with `WishListV2Service` and
 * registers the required connector and OCC adapter.
 *
 * When this module is NOT imported, the standard V1 SavedCart-based Wish List
 * implementation remains active and no V2 code is bundled.
 *
 * @example
 * // app.module.ts
 * imports: [WishListModule, WishListV2Module]
 */
class WishListV2Module {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListV2Module, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: WishListV2Module }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListV2Module, providers: [
            WishListV2Service,
            {
                provide: WishListFacade,
                useExisting: WishListV2Service,
            },
            UserWishlistConnector,
            {
                provide: UserWishlistAdapter,
                useClass: OccUserWishlistAdapter,
            },
            provideDefaultConfig(defaultOccUserWishlistConfig),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListV2Module, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        WishListV2Service,
                        {
                            provide: WishListFacade,
                            useExisting: WishListV2Service,
                        },
                        UserWishlistConnector,
                        {
                            provide: UserWishlistAdapter,
                            useClass: OccUserWishlistAdapter,
                        },
                        provideDefaultConfig(defaultOccUserWishlistConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class WishListWithV2Module {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListWithV2Module, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: WishListWithV2Module, imports: [WishListModule, WishListV2Module] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListWithV2Module, imports: [WishListModule, WishListV2Module] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListWithV2Module, decorators: [{
            type: NgModule,
            args: [{
                    imports: [WishListModule, WishListV2Module],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { WishListModule, WishListV2Module, WishListWithV2Module };
//# sourceMappingURL=spartacus-cart-wish-list.mjs.map
