import { NgIf, NgClass, AsyncPipe, CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { inject, ComponentRef, HostListener, ViewChild, Input, Optional, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import * as i4 from '@angular/forms';
import { UntypedFormGroup, UntypedFormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i2 from '@spartacus/cart/base/root';
import { CartOutlets, CartItemQuantityService, CartConfig, CartUiEventAddToCart } from '@spartacus/cart/base/root';
import * as i3 from '@spartacus/core';
import { ProductAvailabilityService, ProductCatalogService, ProductScope, isNotNullable, ProductTypes, TranslatePipe, I18nModule, FeaturesConfigModule, provideDefaultConfig } from '@spartacus/core';
import * as i1 from '@spartacus/storefront';
import { ICON_TYPE, ItemCounterComponent, OutletDirective, IconComponent, IconModule, ItemCounterModule, OutletModule } from '@spartacus/storefront';
import { Subscription } from 'rxjs';
import { map, filter, startWith, take } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AddToCartComponent {
    /**
     * We disable the dialog launch on quantity input,
     * as it causes an unexpected change of context.
     * The expectation is only for the quantity to get updated in the Qty field.
     */
    handleKeyboardEvent(event) {
        const eventTarget = event.target;
        const isQuantityInput = eventTarget.ariaLabel === 'Quantity' && eventTarget.tagName === 'INPUT';
        if (event.key === 'Enter' && isQuantityInput) {
            event.preventDefault();
        }
    }
    constructor(currentProductService, cd, activeCartService, component, eventService, productListItemContext) {
        this.currentProductService = currentProductService;
        this.cd = cd;
        this.activeCartService = activeCartService;
        this.component = component;
        this.eventService = eventService;
        this.productListItemContext = productListItemContext;
        this.showQuantity = true;
        this.disabled = false;
        this.hasStock = false;
        this.inventoryThreshold = false;
        this.showInventory$ = this.component?.data$.pipe(map((data) => data.inventoryDisplay));
        this.unavailable = false;
        this.quantity = 1;
        this.subscription = new Subscription();
        this.addToCartForm = new UntypedFormGroup({
            quantity: new UntypedFormControl(1, { updateOn: 'blur' }),
        });
        this.CartOutlets = CartOutlets;
        this.iconTypes = ICON_TYPE;
        this.productAvailabilityService = inject(ProductAvailabilityService);
        this.productCatalogService = inject(ProductCatalogService);
        this.cartItemQuantityService = inject(CartItemQuantityService);
        this.realTimeStockEnabled = !!inject(CartConfig).cart?.showRealTimeStockInPDP?.enabled;
    }
    ngOnInit() {
        this.subscribeToQuantityChanges();
        if (this.product) {
            this.productCode = this.product.code ?? '';
            this.setStockInfo(this.product);
            this.unavailable = !this.productCatalogService.isProductInCatalog(this.product);
        }
        else if (this.productCode) {
            // force hasStock and quantity for the time being, as we do not have more info:
            this.quantity = 1;
            this.hasStock = true;
            this.cd.markForCheck();
        }
        else {
            let product$;
            if (this.productListItemContext) {
                product$ = this.productListItemContext.product$;
            }
            else if (this.realTimeStockEnabled) {
                product$ = this.currentProductService.getProduct([
                    ProductScope.UNIT,
                    ProductScope.DETAILS,
                ]);
            }
            else {
                product$ = this.currentProductService.getProduct();
            }
            this.subscription.add(product$.pipe(filter(isNotNullable)).subscribe((product) => {
                this.productCode = product.code ?? '';
                this.product = product;
                this.setStockInfo(product);
                this.unavailable =
                    !this.productCatalogService.isProductInCatalog(product);
            }));
        }
    }
    subscribeToQuantityChanges() {
        this.subscription.add(this.addToCartForm
            .get('quantity')
            ?.valueChanges.pipe(startWith(this.addToCartForm.get('quantity')?.value))
            .subscribe((quantity) => this.cartItemQuantityService.setQuantity(quantity ?? 1)));
    }
    setStockInfo(product) {
        this.quantity = 1;
        this.addToCartForm.controls['quantity'].setValue(1);
        this.inventoryThreshold = product.stock?.isValueRounded ?? false;
        if (this.productListItemContext) {
            this.showQuantity = false;
        }
        if (this.realTimeStockEnabled && product.sapUnit?.sapCode) {
            this.productAvailabilityService
                .getRealTimeStock(this.productCode, product.sapUnit?.sapCode)
                .pipe(take(1))
                .subscribe(({ quantity, status }) => {
                this.maxQuantity = Number(quantity);
                this.hasStock = Boolean(status && status !== 'OUT_OF_STOCK');
                this.cd.markForCheck();
            });
        }
        else {
            this.hasStock = Boolean(product.stock?.stockLevelStatus !== 'outOfStock');
            if (this.hasStock && product.stock?.stockLevel) {
                this.maxQuantity = product.stock.stockLevel;
            }
            this.cd.markForCheck();
        }
    }
    /**
     * In specific scenarios, we need to omit displaying the stock level or append a plus to the value.
     * When backoffice forces a product to be in stock, omit showing the stock level.
     * When product stock level is limited by a threshold value, append '+' at the end.
     * When out of stock, display no numerical value.
     */
    getInventory() {
        if (this.hasStock &&
            this.product.productTypes !== ProductTypes.SUBSCRIPTION) {
            const quantityDisplay = this.maxQuantity
                ? this.maxQuantity.toString()
                : '';
            return this.inventoryThreshold ? quantityDisplay + '+' : quantityDisplay;
        }
        else {
            return '';
        }
    }
    updateCount(value) {
        this.quantity = value;
    }
    addToCart() {
        let quantity = 0;
        if (this.savedCart) {
            quantity = this.getQuantityFromSavedCart(this.productCode);
        }
        else {
            quantity = this.addToCartForm.get('quantity')?.value;
        }
        if (!this.productCode || quantity <= 0) {
            return;
        }
        if (this.pickupOptionCompRef instanceof ComponentRef) {
            this.pickupOptionCompRef.instance.intendedPickupLocation$
                .pipe(take(1))
                .subscribe((intendedPickupLocation) => {
                this.pickupStore =
                    intendedPickupLocation?.pickupOption === 'pickup'
                        ? intendedPickupLocation.name
                        : undefined;
            });
        }
        this.activeCartService
            .getEntries()
            .pipe(take(1))
            .subscribe((cartEntries) => {
            this.activeCartService.addEntry(this.productCode, quantity, this.pickupStore);
            // A CartUiEventAddToCart is dispatched.  This event is intended for the UI
            // responsible to provide feedback about what was added to the cart, like
            // the added to cart dialog.
            //
            // Because we call activeCartService.getEntries() before, we can be sure the
            // cart library is loaded already and that the event listener exists.
            this.eventService.dispatch(this.createCartUiEventAddToCart(this.productCode, quantity, cartEntries.length, this.pickupStore));
        });
    }
    createCartUiEventAddToCart(productCode, quantity, numberOfEntriesBeforeAdd, storeName) {
        const newEvent = new CartUiEventAddToCart();
        newEvent.productCode = productCode;
        newEvent.quantity = quantity;
        newEvent.numberOfEntriesBeforeAdd = numberOfEntriesBeforeAdd;
        newEvent.pickupStoreName = storeName;
        newEvent.triggerElementRef = this.addToCartDialogTriggerEl;
        return newEvent;
    }
    onPickupOptionsCompLoaded() {
        if (this.pickupOptionCompRef instanceof ComponentRef) {
            this.subscription.add(this.pickupOptionCompRef.instance.intendedPickupChange.subscribe((intendedPickupLocation) => {
                this.disabled =
                    intendedPickupLocation?.pickupOption === 'pickup' &&
                        !intendedPickupLocation.displayName;
            }));
        }
    }
    getQuantityFromSavedCart(productCode) {
        return (this.savedCart?.entries?.find((e) => e?.product?.code === productCode)
            ?.quantity ?? 0);
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddToCartComponent, deps: [{ token: i1.CurrentProductService }, { token: i0.ChangeDetectorRef }, { token: i2.ActiveCartFacade }, { token: i1.CmsComponentData }, { token: i3.EventService }, { token: i1.ProductListItemContext, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: AddToCartComponent, isStandalone: true, selector: "cx-add-to-cart", inputs: { productCode: "productCode", showQuantity: "showQuantity", options: "options", pickupStore: "pickupStore", savedCart: "savedCart", product: "product" }, host: { listeners: { "document:keydown": "handleKeyboardEvent($event)" } }, viewQueries: [{ propertyName: "addToCartDialogTriggerEl", first: true, predicate: ["addToCartDialogTriggerEl"], descendants: true }], ngImport: i0, template: "<form *ngIf=\"productCode\" [formGroup]=\"addToCartForm\" (submit)=\"addToCart()\">\n  <div class=\"quantity\" *ngIf=\"showQuantity\">\n    <label>{{ 'addToCart.quantityFull' | cxTranslate }}</label>\n    <div class=\"cx-counter-stock\">\n      <cx-item-counter\n        *ngIf=\"hasStock\"\n        [max]=\"maxQuantity\"\n        [control]=\"addToCartForm.get('quantity')\"\n        [ariaDescribedById]=\"'add-to-card-stock-info'\"\n      ></cx-item-counter>\n\n      <span class=\"info\" id=\"add-to-card-stock-info\">\n        <span *ngIf=\"showInventory$ | async\">{{ getInventory() }}</span>\n        {{\n          hasStock\n            ? ('addToCart.inStock' | cxTranslate)\n            : ('addToCart.outOfStock' | cxTranslate)\n        }}</span\n      >\n    </div>\n  </div>\n\n  <ng-container *ngIf=\"hasStock\">\n    <ng-template\n      [cxOutlet]=\"CartOutlets.ADD_TO_CART_PICKUP_OPTION\"\n      [(cxComponentRef)]=\"pickupOptionCompRef\"\n      (cxComponentRefChange)=\"onPickupOptionsCompLoaded()\"\n    ></ng-template>\n  </ng-container>\n\n  <button\n    #addToCartDialogTriggerEl\n    *ngIf=\"hasStock\"\n    [ngClass]=\"\n      options?.displayAddToCart\n        ? 'btn btn-tertiary'\n        : 'btn btn-primary btn-block'\n    \"\n    type=\"submit\"\n    [disabled]=\"\n      disabled || quantity <= 0 || quantity > maxQuantity || unavailable\n    \"\n    [attr.aria-label]=\"\n      product?.name\n        ? ('addToCart.addToCart' | cxTranslate) + ', ' + product?.name\n        : ('addToCart.addToCart' | cxTranslate)\n    \"\n  >\n    <span\n      *ngIf=\"\n        options?.addToCartString === ('addToCart.buyItAgain' | cxTranslate) &&\n        !unavailable\n      \"\n      class=\"repeat-icon\"\n      ><cx-icon [type]=\"iconTypes.REPEAT\"></cx-icon\n    ></span>\n    <span\n      [ngClass]=\"\n        options?.addToCartString === ('addToCart.buyItAgain' | cxTranslate)\n          ? 'buyItAgainLink'\n          : ''\n      \"\n    >\n      {{\n        unavailable\n          ? ('addToCart.unavailable' | cxTranslate)\n          : (options?.addToCartString ?? ('addToCart.addToCart' | cxTranslate))\n      }}\n    </span>\n  </button>\n</form>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i4.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i4.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: ItemCounterComponent, selector: "cx-item-counter", inputs: ["control", "min", "max", "step", "allowZero", "ariaDescribedById", "readonly"] }, { kind: "directive", type: OutletDirective, selector: "[cxOutlet]", inputs: ["cxOutlet", "cxOutletContext", "cxOutletDefer", "cxComponentRef"], outputs: ["loaded", "cxComponentRefChange"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddToCartComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-add-to-cart', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        ItemCounterComponent,
                        OutletDirective,
                        NgClass,
                        IconComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<form *ngIf=\"productCode\" [formGroup]=\"addToCartForm\" (submit)=\"addToCart()\">\n  <div class=\"quantity\" *ngIf=\"showQuantity\">\n    <label>{{ 'addToCart.quantityFull' | cxTranslate }}</label>\n    <div class=\"cx-counter-stock\">\n      <cx-item-counter\n        *ngIf=\"hasStock\"\n        [max]=\"maxQuantity\"\n        [control]=\"addToCartForm.get('quantity')\"\n        [ariaDescribedById]=\"'add-to-card-stock-info'\"\n      ></cx-item-counter>\n\n      <span class=\"info\" id=\"add-to-card-stock-info\">\n        <span *ngIf=\"showInventory$ | async\">{{ getInventory() }}</span>\n        {{\n          hasStock\n            ? ('addToCart.inStock' | cxTranslate)\n            : ('addToCart.outOfStock' | cxTranslate)\n        }}</span\n      >\n    </div>\n  </div>\n\n  <ng-container *ngIf=\"hasStock\">\n    <ng-template\n      [cxOutlet]=\"CartOutlets.ADD_TO_CART_PICKUP_OPTION\"\n      [(cxComponentRef)]=\"pickupOptionCompRef\"\n      (cxComponentRefChange)=\"onPickupOptionsCompLoaded()\"\n    ></ng-template>\n  </ng-container>\n\n  <button\n    #addToCartDialogTriggerEl\n    *ngIf=\"hasStock\"\n    [ngClass]=\"\n      options?.displayAddToCart\n        ? 'btn btn-tertiary'\n        : 'btn btn-primary btn-block'\n    \"\n    type=\"submit\"\n    [disabled]=\"\n      disabled || quantity <= 0 || quantity > maxQuantity || unavailable\n    \"\n    [attr.aria-label]=\"\n      product?.name\n        ? ('addToCart.addToCart' | cxTranslate) + ', ' + product?.name\n        : ('addToCart.addToCart' | cxTranslate)\n    \"\n  >\n    <span\n      *ngIf=\"\n        options?.addToCartString === ('addToCart.buyItAgain' | cxTranslate) &&\n        !unavailable\n      \"\n      class=\"repeat-icon\"\n      ><cx-icon [type]=\"iconTypes.REPEAT\"></cx-icon\n    ></span>\n    <span\n      [ngClass]=\"\n        options?.addToCartString === ('addToCart.buyItAgain' | cxTranslate)\n          ? 'buyItAgainLink'\n          : ''\n      \"\n    >\n      {{\n        unavailable\n          ? ('addToCart.unavailable' | cxTranslate)\n          : (options?.addToCartString ?? ('addToCart.addToCart' | cxTranslate))\n      }}\n    </span>\n  </button>\n</form>\n" }]
        }], ctorParameters: () => [{ type: i1.CurrentProductService }, { type: i0.ChangeDetectorRef }, { type: i2.ActiveCartFacade }, { type: i1.CmsComponentData }, { type: i3.EventService }, { type: i1.ProductListItemContext, decorators: [{
                    type: Optional
                }] }], propDecorators: { productCode: [{
                type: Input
            }], showQuantity: [{
                type: Input
            }], options: [{
                type: Input
            }], pickupStore: [{
                type: Input
            }], savedCart: [{
                type: Input
            }], product: [{
                type: Input
            }], addToCartDialogTriggerEl: [{
                type: ViewChild,
                args: ['addToCartDialogTriggerEl']
            }], handleKeyboardEvent: [{
                type: HostListener,
                args: ['document:keydown', ['$event']]
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AddToCartModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddToCartModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: AddToCartModule, imports: [CommonModule,
            ReactiveFormsModule,
            I18nModule,
            IconModule,
            ItemCounterModule,
            OutletModule,
            FeaturesConfigModule,
            AddToCartComponent], exports: [AddToCartComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddToCartModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    ProductAddToCartComponent: {
                        component: AddToCartComponent,
                        data: {
                            inventoryDisplay: false,
                        },
                    },
                },
            }),
        ], imports: [CommonModule,
            ReactiveFormsModule,
            I18nModule,
            IconModule,
            ItemCounterModule,
            OutletModule,
            FeaturesConfigModule,
            AddToCartComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AddToCartModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        I18nModule,
                        IconModule,
                        ItemCounterModule,
                        OutletModule,
                        FeaturesConfigModule,
                        AddToCartComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                ProductAddToCartComponent: {
                                    component: AddToCartComponent,
                                    data: {
                                        inventoryDisplay: false,
                                    },
                                },
                            },
                        }),
                    ],
                    exports: [AddToCartComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AddToCartComponent, AddToCartModule };
//# sourceMappingURL=spartacus-cart-base-components-add-to-cart.mjs.map
