import * as i0 from '@angular/core';
import { Injectable, inject, NgModule } from '@angular/core';
import * as i3 from '@spartacus/cart/base/root';
import { CartType } from '@spartacus/cart/base/root';
import * as i4 from '@spartacus/core';
import { StateUtils, OCC_USER_ID_ANONYMOUS, UserIdService, ProductSearchConnector, LoggerService, tryNormalizeHttpError, SiteContextActions, isNotUndefined } from '@spartacus/core';
import { combineLatest, BehaviorSubject, of, from, EMPTY } from 'rxjs';
import { distinctUntilChanged, tap, filter, switchMap, map, withLatestFrom, take, catchError, shareReplay, mergeMap, concatMap } from 'rxjs/operators';
import * as i2$1 from '@spartacus/cart/base/core';
import { MULTI_CART_DATA, getCartIdByUserId, CartActions, MultiCartSelectors } from '@spartacus/cart/base/core';
import * as i1 from '@ngrx/store';
import { select } from '@ngrx/store';
import * as i2 from '@spartacus/user/account/root';
import { UserWishlistConnector } from '@spartacus/user/wishlist/core';
import { WishListFacade } from '@spartacus/cart/wish-list/root';
import * as i1$1 from '@ngrx/effects';
import { createEffect, ofType, EffectsModule } from '@ngrx/effects';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const CREATE_WISH_LIST = '[Wish List] Create Wish List';
const CREATE_WISH_LIST_FAIL = '[Wish List] Create Wish List Fail';
const CREATE_WISH_LIST_SUCCESS = '[Wish List] Create Wish List Success';
const LOAD_WISH_LIST = '[Wish List] Load Wish List';
const LOAD_WISH_LIST_SUCCESS = '[Wish List] Load Wish List Success';
const LOAD_WISH_LIST_FAIL = '[Wish List] Load Wish List Fail';
class CreateWishList {
    constructor(payload) {
        this.payload = payload;
        this.type = CREATE_WISH_LIST;
    }
}
class CreateWishListSuccess extends StateUtils.EntitySuccessAction {
    constructor(payload) {
        super(MULTI_CART_DATA, payload.cartId);
        this.payload = payload;
        this.type = CREATE_WISH_LIST_SUCCESS;
    }
}
class CreateWishListFail extends StateUtils.EntityFailAction {
    constructor(payload) {
        super(MULTI_CART_DATA, payload.cartId, payload.error);
        this.payload = payload;
        this.type = CREATE_WISH_LIST_FAIL;
    }
}
/**
 * When we try load wishlist for the first time we don't know cart id.
 * Instead we create temporary cartId from wishlist name to keep track of loading/error state.
 */
class LoadWishList extends StateUtils.EntityLoadAction {
    constructor(payload) {
        super(MULTI_CART_DATA, payload.cartId);
        this.payload = payload;
        this.type = LOAD_WISH_LIST;
    }
}
class LoadWishListSuccess extends StateUtils.EntitySuccessAction {
    constructor(payload) {
        super(MULTI_CART_DATA, payload.cartId);
        this.payload = payload;
        this.type = LOAD_WISH_LIST_SUCCESS;
    }
}
class LoadWishListFail extends StateUtils.EntityFailAction {
    constructor(payload) {
        super(MULTI_CART_DATA, payload.cartId, payload.error);
        this.payload = payload;
        this.type = LOAD_WISH_LIST_FAIL;
    }
}

var wishList_action = /*#__PURE__*/Object.freeze({
    __proto__: null,
    CREATE_WISH_LIST: CREATE_WISH_LIST,
    CREATE_WISH_LIST_FAIL: CREATE_WISH_LIST_FAIL,
    CREATE_WISH_LIST_SUCCESS: CREATE_WISH_LIST_SUCCESS,
    CreateWishList: CreateWishList,
    CreateWishListFail: CreateWishListFail,
    CreateWishListSuccess: CreateWishListSuccess,
    LOAD_WISH_LIST: LOAD_WISH_LIST,
    LOAD_WISH_LIST_FAIL: LOAD_WISH_LIST_FAIL,
    LOAD_WISH_LIST_SUCCESS: LOAD_WISH_LIST_SUCCESS,
    LoadWishList: LoadWishList,
    LoadWishListFail: LoadWishListFail,
    LoadWishListSuccess: LoadWishListSuccess
});

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Compute wishlist cart name for customer.
 */
function getWishlistName(customerId) {
    return `wishlist${customerId}`;
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class WishListService {
    constructor(store, userAccountFacade, multiCartFacade, userIdService) {
        this.store = store;
        this.userAccountFacade = userAccountFacade;
        this.multiCartFacade = multiCartFacade;
        this.userIdService = userIdService;
    }
    createWishList(userId, name, description) {
        this.store.dispatch(new CreateWishList({ userId, name, description }));
    }
    getWishList() {
        return combineLatest([
            this.getWishListId(),
            this.userAccountFacade.get(),
            this.userIdService.getUserId(),
        ]).pipe(distinctUntilChanged(), tap(([wishListId, user, userId]) => {
            if (!wishListId &&
                userId !== OCC_USER_ID_ANONYMOUS &&
                user?.customerId) {
                this.loadWishList(userId, user.customerId);
            }
        }), filter(([wishListId]) => Boolean(wishListId)), switchMap(([wishListId]) => this.multiCartFacade.getCart(wishListId)));
    }
    loadWishList(userId, customerId) {
        this.store.dispatch(new LoadWishList({
            userId,
            cartId: getWishlistName(customerId),
        }));
    }
    addEntry(productCode) {
        this.getWishListIdWithUserId().subscribe(([wishListId, userId]) => this.multiCartFacade.addEntry(userId, wishListId, productCode, 1));
    }
    removeEntry(entry) {
        this.getWishListIdWithUserId().subscribe(([wishListId, userId]) => this.multiCartFacade.removeEntry(userId, wishListId, entry.entryNumber));
    }
    getWishListLoading() {
        return this.getWishListId().pipe(switchMap((wishListId) => this.multiCartFacade.isStable(wishListId).pipe(map((stable) => !stable))));
    }
    getWishListId() {
        return this.multiCartFacade.getCartIdByType(CartType.WISH_LIST);
    }
    getWishListIdWithUserId() {
        return this.getWishListId().pipe(distinctUntilChanged(), withLatestFrom(this.userIdService.getUserId(), this.userAccountFacade.get()), tap(([wishListId, userId, user]) => {
            if (!wishListId && user?.customerId) {
                this.loadWishList(userId, user.customerId);
            }
        }), filter(([wishListId]) => Boolean(wishListId)), map(([wishListId, userId]) => [wishListId, userId]), take(1));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListService, deps: [{ token: i1.Store }, { token: i2.UserAccountFacade }, { token: i3.MultiCartFacade }, { token: i4.UserIdService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.Store }, { type: i2.UserAccountFacade }, { type: i3.MultiCartFacade }, { type: i4.UserIdService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class WishListV2Service {
    constructor() {
        this.userIdService = inject(UserIdService);
        this.connector = inject(UserWishlistConnector);
        this.productSearchConnector = inject(ProductSearchConnector);
        this.refresh$ = new BehaviorSubject(undefined);
    }
    get wishlistV2$() {
        this._wishlistV2$ ??= combineLatest([
            this.userIdService.getUserId(),
            this.refresh$,
        ]).pipe(filter(([userId]) => userId !== OCC_USER_ID_ANONYMOUS), switchMap(([userId]) => this.connector
            .getWishlist(userId)
            .pipe(catchError(() => of({ entries: [] })))), switchMap((wishlist) => this.enrichWithProducts(wishlist)), shareReplay({ bufferSize: 1, refCount: false }));
        return this._wishlistV2$;
    }
    enrichWithProducts(wishlist) {
        const entries = wishlist.entries ?? [];
        if (entries.length === 0) {
            return of(wishlist);
        }
        const codes = entries
            .map((e) => e.productCode ?? '')
            .filter((code) => !!code);
        return this.productSearchConnector.searchByCodes(codes).pipe(map(({ products }) => {
            const productMap = new Map(products.map((p) => [p.code, p]));
            return {
                ...wishlist,
                entries: entries.map((entry) => ({
                    ...entry,
                    product: productMap.get(entry.productCode ?? '') ??
                        { code: entry.productCode },
                })),
            };
        }), catchError(() => of(wishlist)));
    }
    // no-op: the backend creates the default wishlist automatically on first entry
    createWishList(_userId, _name, _description) { }
    // no-op: data is loaded lazily via getWishList()
    loadWishList(_userId, _customerId) { }
    getWishList() {
        return this.wishlistV2$.pipe(map((wl) => this.mapWishlistToCart(wl)));
    }
    addEntry(productCode) {
        combineLatest([this.userIdService.getUserId(), this.wishlistV2$])
            .pipe(take(1), map(([userId, wl]) => ({ userId, wishlistId: wl.id ?? 'default' })), mergeMap(({ userId, wishlistId }) => this.connector.addEntry(userId, wishlistId, productCode)))
            .subscribe(() => this.refresh$.next());
    }
    removeEntry(entry) {
        const entryId = entry.wishlistEntryId;
        combineLatest([this.userIdService.getUserId(), this.wishlistV2$])
            .pipe(take(1), map(([userId, wl]) => ({ userId, wishlistId: wl.id ?? 'default' })), mergeMap(({ userId, wishlistId }) => this.connector.removeEntry(userId, wishlistId, entryId)))
            .subscribe(() => this.refresh$.next());
    }
    getWishListLoading() {
        return of(false);
    }
    mapWishlistToCart(wl) {
        return {
            code: wl.id,
            entries: (wl.entries ?? []).map((e, idx) => ({
                entryNumber: idx,
                wishlistEntryId: e.id,
                product: e.product ?? { code: e.productCode },
                basePrice: e.product?.price,
                updateable: true,
                quantity: 1,
            })),
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListV2Service, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListV2Service }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListV2Service, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const facadeProviders = [
    WishListService,
    {
        provide: WishListFacade,
        useExisting: WishListService,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class WishListEffects {
    constructor(actions$, cartConnector, userIdService, store) {
        this.actions$ = actions$;
        this.cartConnector = cartConnector;
        this.userIdService = userIdService;
        this.store = store;
        this.logger = inject(LoggerService);
        this.createWishList$ = createEffect(() => this.actions$.pipe(ofType(CREATE_WISH_LIST), map((action) => action.payload), switchMap((payload) => {
            return this.cartConnector.create(payload.userId).pipe(switchMap((cart) => {
                return this.cartConnector
                    .save(payload.userId, cart.code ?? '', payload.name, payload.description)
                    .pipe(switchMap((savedCart) => [
                    new CreateWishListSuccess({
                        cart: savedCart,
                        cartId: getCartIdByUserId(savedCart, payload.userId),
                    }),
                ]), catchError((error) => from([
                    new CreateWishListFail({
                        cartId: cart.code ?? '',
                        error: tryNormalizeHttpError(error, this.logger),
                    }),
                ])));
            }));
        })));
        this.loadWishList$ = createEffect(() => this.actions$.pipe(ofType(LOAD_WISH_LIST), map((action) => action.payload), concatMap((payload) => {
            const { userId, cartId } = payload;
            return this.cartConnector.loadAll(userId).pipe(switchMap((carts) => {
                const wishListName = cartId;
                const wishList = carts.find((cart) => cart.name === wishListName);
                const actions = [];
                actions.push(wishList
                    ? new LoadWishListSuccess({
                        cart: wishList,
                        cartId: getCartIdByUserId(wishList, userId),
                    })
                    : new CreateWishList({
                        userId,
                        name: wishListName,
                    }));
                // remove temp wishlist, which id is whishlist name
                actions.push(new CartActions.RemoveCart({ cartId: wishListName }));
                return actions;
            }), catchError((error) => from([
                new LoadWishListFail({
                    cartId: cartId,
                    error: tryNormalizeHttpError(error, this.logger),
                }),
            ])));
        })));
        this.resetWishList$ = createEffect(() => this.actions$.pipe(ofType(SiteContextActions.LANGUAGE_CHANGE, SiteContextActions.CURRENCY_CHANGE), withLatestFrom(this.userIdService.getUserId(), this.store.pipe(filter((store) => !!store.cart), select(MultiCartSelectors.getCartIdByTypeFactory(CartType.WISH_LIST)))), switchMap(([, userId, wishListId]) => {
            if (wishListId) {
                return this.cartConnector.load(userId, wishListId).pipe(switchMap((wishList) => [
                    new LoadWishListSuccess({
                        cart: wishList ?? {},
                        cartId: getCartIdByUserId(wishList, userId),
                    }),
                ]), catchError((error) => from([
                    new LoadWishListFail({
                        cartId: wishListId,
                        error: tryNormalizeHttpError(error, this.logger),
                    }),
                ])));
            }
            return EMPTY;
        })));
        this.setWishListId$ = createEffect(() => this.actions$.pipe(ofType(CREATE_WISH_LIST_SUCCESS, LOAD_WISH_LIST_SUCCESS), map((action) => {
            switch (action.type) {
                case CREATE_WISH_LIST_SUCCESS:
                case LOAD_WISH_LIST_SUCCESS: {
                    return new CartActions.SetCartTypeIndex({
                        cartType: CartType.WISH_LIST,
                        cartId: action.meta
                            .entityId,
                    });
                }
            }
        }), filter(isNotUndefined)));
        this.setWishListData$ = createEffect(() => this.actions$.pipe(ofType(CREATE_WISH_LIST_SUCCESS, LOAD_WISH_LIST_SUCCESS), map((action) => {
            switch (action.type) {
                case CREATE_WISH_LIST_SUCCESS:
                case LOAD_WISH_LIST_SUCCESS: {
                    return new CartActions.SetCartData({
                        cart: action.payload.cart,
                        cartId: action.payload.cartId,
                    });
                }
            }
        }), filter(isNotUndefined)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListEffects, deps: [{ token: i1$1.Actions }, { token: i2$1.CartConnector }, { token: i4.UserIdService }, { token: i1.Store }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListEffects }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListEffects, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1$1.Actions }, { type: i2$1.CartConnector }, { type: i4.UserIdService }, { type: i1.Store }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const effects = [WishListEffects];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class WishListStoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListStoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: WishListStoreModule, imports: [i1$1.EffectsFeatureModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListStoreModule, imports: [EffectsModule.forFeature(effects)] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListStoreModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [EffectsModule.forFeature(effects)],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class WishListCoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: WishListCoreModule, imports: [WishListStoreModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListCoreModule, providers: [...facadeProviders], imports: [WishListStoreModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: WishListCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [WishListStoreModule],
                    providers: [...facadeProviders],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { wishList_action as WishListActions, WishListCoreModule, WishListService, WishListV2Service, getWishlistName };
//# sourceMappingURL=spartacus-cart-wish-list-core.mjs.map
