import * as i0 from '@angular/core';

declare const CART_IMPORT_EXPORT_FEATURE = "cartImportExport";

declare class ImportExportRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ImportExportRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ImportExportRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ImportExportRootModule>;
}

export { CART_IMPORT_EXPORT_FEATURE, ImportExportRootModule };
