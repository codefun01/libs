import * as i0 from '@angular/core';
import { ElementRef } from '@angular/core';
import { OrderEntry } from '@spartacus/cart/base/root';
import { WishListFacade } from '@spartacus/cart/wish-list/root';
import * as i2 from '@spartacus/core';
import { AuthService, Product } from '@spartacus/core';
import * as i3 from '@spartacus/storefront';
import { CurrentProductService, ICON_TYPE } from '@spartacus/storefront';
import { Observable } from 'rxjs';
import * as i1 from '@angular/common';
import * as i4 from '@angular/router';

declare class AddToWishListComponent {
    protected wishListFacade: WishListFacade;
    protected currentProductService: CurrentProductService;
    protected authService: AuthService;
    product$: Observable<Product>;
    wishListEntries$: Observable<OrderEntry[]>;
    loading$: Observable<boolean>;
    addToWishlistButton: ElementRef;
    removeFromWishlistButton: ElementRef;
    userLoggedIn$: Observable<boolean>;
    hasStock: boolean;
    iconTypes: typeof ICON_TYPE;
    constructor(wishListFacade: WishListFacade, currentProductService: CurrentProductService, authService: AuthService);
    add(product: Product): void;
    remove(entry: OrderEntry): void;
    getProductInWishList(product: Product, entries: OrderEntry[]): OrderEntry | undefined;
    protected setStockInfo(product: Product): void;
    protected getWishListEntries(): Observable<OrderEntry[]>;
    /**
     * When disabling the button, the focus gets lost unexpecedly.
     * This method makes sure that it is restored after.
     */
    protected restoreFocus(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddToWishListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddToWishListComponent, "cx-add-to-wishlist", never, {}, {}, never, never, true, never>;
}

declare class AddToWishListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AddToWishListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AddToWishListModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof i4.RouterModule, typeof i2.UrlModule, typeof i3.AtMessageModule, typeof i2.FeaturesConfigModule, typeof i3.BtnLikeLinkModule, typeof AddToWishListComponent], [typeof AddToWishListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AddToWishListModule>;
}

export { AddToWishListComponent, AddToWishListModule };
