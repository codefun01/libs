import { Cart, MultiCartFacade } from '@spartacus/cart/base/root';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import { ActionsSubject, Store } from '@ngrx/store';
import { EventService, StateEventService, ActionToEventMapping, StateWithProcess, UserIdService, StateUtils, ErrorAction } from '@spartacus/core';
import * as i1 from '@ngrx/effects';
import { StateWithMultiCart } from '@spartacus/cart/base/core';
import { SavedCartFacade } from '@spartacus/cart/saved-cart/root';
import { UserAccountFacade } from '@spartacus/user/account/root';

declare abstract class SavedCartAdapter {
    /**
     *
     * Abstract method used to load a single saved cart
     */
    abstract load(userId: String, cartId: String): Observable<Cart>;
    /**
     *
     * Abstract method used to load a list of saved carts
     */
    abstract loadList(userId: string): Observable<Cart[]>;
    /**
     *
     * Abstract method used to restore a saved cart to an active cart
     */
    abstract restoreSavedCart(userId: string, cartId: string): Observable<Cart>;
    /**
     *
     * Abstract method used to clone a saved cart
     */
    abstract cloneSavedCart(userId: string, cartId: string, saveCartName?: string): Observable<Cart>;
}

declare class SavedCartConnector {
    protected adapter: SavedCartAdapter;
    constructor(adapter: SavedCartAdapter);
    get(userId: string, cartId: string): Observable<Cart>;
    getList(userId: string): Observable<Cart[]>;
    restoreSavedCart(userId: string, cartId: string): Observable<Cart>;
    cloneSavedCart(userId: string, cartId: string, saveCartName?: string): Observable<Cart>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SavedCartConnector>;
}

declare class SavedCartEventBuilder {
    protected actionsSubject: ActionsSubject;
    protected eventService: EventService;
    protected stateEventService: StateEventService;
    protected multiCartService: MultiCartFacade;
    constructor(actionsSubject: ActionsSubject, eventService: EventService, stateEventService: StateEventService, multiCartService: MultiCartFacade);
    /**
     * Registers events for the saved cart
     */
    protected register(): void;
    /**
     * Registers restore saved cart events
     */
    protected registerRestoreSavedCartEvents(): void;
    /**
     * Registers save cart events
     */
    protected registerSaveCartEvents(): void;
    /**
     * Registers edit saved cart events
     */
    protected registerEditSavedCartEvents(): void;
    /**
     * Registers clone saved cart events
     */
    protected registerCloneSavedCartEvents(): void;
    /**
     * Builds the restore save cart events from the action and cart
     *
     * @param mapping mapping declaration from `action` string type to `event` class type
     * @param saveTime should the saveTime attribute be added to the event
     * @returns
     */
    protected buildRestoreSavedCartEvents<T>(mapping: ActionToEventMapping<T>): () => void;
    /**
     * Builds save cart event by adding the saveTime from the cart
     *
     * @param mapping mapping declaration from `action` string type to `event` class type
     * @returns events register function
     */
    protected buildSaveCartSuccessEvent<T>(mapping: ActionToEventMapping<T>): () => void;
    /**
     * Returns a stream of actions only of a given type(s)
     *
     * @param actionType type(s) of actions
     */
    protected getAction(actionType: string | string[]): Observable<{
        type: string;
        payload?: any;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartEventBuilder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SavedCartEventBuilder>;
}

declare class SavedCartEventsModule {
    constructor(_savedCartEventBuilder: SavedCartEventBuilder);
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartEventsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SavedCartEventsModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SavedCartEventsModule>;
}

declare class SavedCartStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SavedCartStoreModule, never, [typeof i1.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SavedCartStoreModule>;
}

declare class SavedCartCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SavedCartCoreModule, never, [typeof SavedCartStoreModule, typeof SavedCartEventsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SavedCartCoreModule>;
}

declare class SavedCartService implements SavedCartFacade {
    protected store: Store<StateWithMultiCart | StateWithProcess<void>>;
    protected userIdService: UserIdService;
    protected userAccountFacade: UserAccountFacade;
    protected multiCartService: MultiCartFacade;
    protected eventService: EventService;
    constructor(store: Store<StateWithMultiCart | StateWithProcess<void>>, userIdService: UserIdService, userAccountFacade: UserAccountFacade, multiCartService: MultiCartFacade, eventService: EventService);
    /**
     * Loads a single saved cart
     */
    loadSavedCart(cartId: string): void;
    /**
     * Gets a single saved cart
     * it won't emit if the delete saved cart event gets triggered to avoid race condition between actions
     *
     * @param cartId
     * @returns observable with cart
     */
    get(cartId: string): Observable<Cart | undefined>;
    /**
     * Gets the selected cart state
     *
     * @param cartId
     * @returns observable of selected cart with loader state
     */
    getSavedCart(cartId: string): Observable<StateUtils.ProcessesLoaderState<Cart | undefined>>;
    /**
     * Returns true when there are no operations on that in progress and it is not currently loading
     *
     * @param cartId
     */
    isStable(cartId: string): Observable<boolean>;
    /**
     * Loads a list of saved carts
     */
    loadSavedCarts(): void;
    /**
     * Gets a list of saved carts
     *
     * @returns observable with list of saved carts
     */
    getList(): Observable<Cart[]>;
    /**
     * Gets a list of saved carts from all carts in the state
     * by filtering through the carts that are not wishlist and not saved cart
     *
     * @returns observable with list of saved carts
     */
    getSavedCartList(): Observable<Cart[]>;
    /**
     * Gets the loading flag of getting a list of saved carts
     *
     * @returns observable with boolean of the loading state
     */
    getSavedCartListProcessLoading(): Observable<boolean>;
    /**
     * Gets the loading state of getting a list of saved carts
     *
     * @returns observable with boolean of the loader state
     */
    getSavedCartListProcess(): Observable<StateUtils.LoaderState<any>>;
    /**
     * Clears the process state of performing a saved cart
     */
    clearSavedCarts(): void;
    /**
     * Triggers a restore saved cart
     *
     * @param cartId
     */
    restoreSavedCart(cartId: string): void;
    /**
     * Gets the loading state of restoring saved cart
     *
     * @returns observable with boolean of the loading state
     */
    getRestoreSavedCartProcessLoading(): Observable<boolean>;
    /**
     * Gets the success state of restoring saved cart
     *
     * @returns observable with boolean of the success state
     */
    getRestoreSavedCartProcessSuccess(): Observable<boolean>;
    /**
     * Gets the error state of restoring saved cart
     *
     * @returns observable with boolean of the error state
     */
    getRestoreSavedCartProcessError(): Observable<boolean>;
    /**
     * Clears the process state of performing a restore saved cart
     */
    clearRestoreSavedCart(): void;
    /**
     * Triggers delete saved cart
     * @param cartId
     */
    deleteSavedCart(cartId: string): void;
    /**
     * Triggers a saved cart
     *
     */
    saveCart({ cartId, saveCartName, saveCartDescription, }: {
        cartId: string;
        saveCartName?: string;
        saveCartDescription?: string;
    }): void;
    /**
     * Gets the loading state of saving a cart
     *
     * @returns observable with boolean of the loading state
     */
    getSaveCartProcessLoading(): Observable<boolean>;
    /**
     * Gets the success state of saving a cart
     *
     * @returns observable with boolean of the success state
     */
    getSaveCartProcessSuccess(): Observable<boolean>;
    /**
     * Gets the error state of saving a cart
     *
     * @returns observable with boolean of the error state
     */
    getSaveCartProcessError(): Observable<boolean>;
    /**
     * Clears the process state of performing a save cart
     */
    clearSaveCart(): void;
    /**
     * Triggers an edit saved cart
     *
     */
    editSavedCart({ cartId, saveCartName, saveCartDescription, }: {
        cartId: string;
        saveCartName?: string;
        saveCartDescription?: string;
    }): void;
    /**
     * Triggers a clone saved cart
     *
     * @param cartId
     */
    cloneSavedCart(cartId: string, saveCartName?: string): void;
    /**
     * Gets the loading state of cloning a saved cart
     *
     * @returns observable with boolean of the loading state
     */
    getCloneSavedCartProcessLoading(): Observable<boolean>;
    /**
     * Gets the success state of cloning a saved cart
     *
     * @returns observable with boolean of the success state
     */
    getCloneSavedCartProcessSuccess(): Observable<boolean>;
    /**
     * Gets the error state of cloning a saved cart
     *
     * @returns observable with boolean of the error state
     */
    getCloneSavedCartProcessError(): Observable<boolean>;
    /**
     * Clears the process state of cloning a saved cart
     */
    clearCloneSavedCart(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SavedCartService>;
}

declare const LOAD_SAVED_CART = "[Saved Cart] Load Saved Cart";
declare const LOAD_SAVED_CART_SUCCESS = "[Saved Cart] Load Saved Cart Success";
declare const LOAD_SAVED_CART_FAIL = "[Saved Cart] Load Saved Cart Fail";
declare const LOAD_SAVED_CARTS = "[Saved Cart] Load Saved Carts";
declare const LOAD_SAVED_CARTS_SUCCESS = "[Saved Cart] Load Saved Carts Success";
declare const LOAD_SAVED_CARTS_FAIL = "[Saved Cart] Load Saved Carts Fail";
declare const CLEAR_SAVED_CARTS = "[Saved Cart] Clear Saved Carts";
declare const RESTORE_SAVED_CART = "[Saved Cart] Restore Saved Cart";
declare const RESTORE_SAVED_CART_SUCCESS = "[Saved Cart] Restore Saved Cart Success";
declare const RESTORE_SAVED_CART_FAIL = "[Saved Cart] Restore Saved Cart Fail";
declare const CLEAR_RESTORE_SAVED_CART = "[Saved Cart] Clear Restore Saved Cart";
declare const SAVE_CART = "[Saved Cart] Save Cart";
declare const SAVE_CART_SUCCESS = "[Saved Cart] Save Cart Success";
declare const SAVE_CART_FAIL = "[Saved Cart] Save Cart Fail";
declare const CLEAR_SAVE_CART = "[Saved Cart] Clear Save Cart";
declare const EDIT_SAVED_CART = "[Saved Cart] Edit Saved Cart";
declare const EDIT_SAVED_CART_SUCCESS = "[Saved Cart] Edit Saved Cart Success";
declare const EDIT_SAVED_CART_FAIL = "[Saved Cart] Edit Saved Cart Fail";
declare const CLONE_SAVED_CART = "[Saved Cart] Clone Saved Cart";
declare const CLONE_SAVED_CART_SUCCESS = "[Saved Cart] Clone Saved Cart Success";
declare const CLONE_SAVED_CART_FAIL = "[Saved Cart] Clone Saved Cart Fail";
declare const CLEAR_CLONE_SAVED_CART = "[Saved Cart] Clear Clone Saved Cart";
declare class LoadSavedCart extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        cartId: string;
    };
    readonly type = "[Saved Cart] Load Saved Cart";
    constructor(payload: {
        userId: string;
        cartId: string;
    });
}
declare class LoadSavedCartSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        userId: string;
        cartId: string;
    };
    readonly type = "[Saved Cart] Load Saved Cart Success";
    constructor(payload: {
        userId: string;
        cartId: string;
    });
}
declare class LoadSavedCartFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userId: string;
        cartId: string;
        error: any;
    };
    readonly type = "[Saved Cart] Load Saved Cart Fail";
    constructor(payload: {
        userId: string;
        cartId: string;
        error: any;
    });
}
declare class LoadSavedCarts extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
    };
    readonly type = "[Saved Cart] Load Saved Carts";
    constructor(payload: {
        userId: string;
    });
}
declare class LoadSavedCartsSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        userId: string;
    };
    readonly type = "[Saved Cart] Load Saved Carts Success";
    constructor(payload: {
        userId: string;
    });
}
declare class LoadSavedCartsFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userId: string;
        error: any;
    };
    readonly type = "[Saved Cart] Load Saved Carts Fail";
    constructor(payload: {
        userId: string;
        error: any;
    });
}
declare class ClearSavedCarts extends StateUtils.EntityLoaderResetAction {
    readonly type = "[Saved Cart] Clear Saved Carts";
    constructor();
}
declare class RestoreSavedCart extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        cartId: string;
    };
    readonly type = "[Saved Cart] Restore Saved Cart";
    constructor(payload: {
        userId: string;
        cartId: string;
    });
}
declare class RestoreSavedCartSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        userId: string;
        cartId: string;
    };
    readonly type = "[Saved Cart] Restore Saved Cart Success";
    constructor(payload: {
        userId: string;
        cartId: string;
    });
}
declare class RestoreSavedCartFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userId: string;
        cartId: string;
        error: any;
    };
    readonly type = "[Saved Cart] Restore Saved Cart Fail";
    constructor(payload: {
        userId: string;
        cartId: string;
        error: any;
    });
}
declare class ClearRestoreSavedCart extends StateUtils.EntityLoaderResetAction {
    readonly type = "[Saved Cart] Clear Restore Saved Cart";
    constructor();
}
declare class SaveCart extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
        saveCartDescription?: string;
    };
    readonly type = "[Saved Cart] Save Cart";
    constructor(payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
        saveCartDescription?: string;
    });
}
declare class SaveCartSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
        saveCartDescription?: string;
    };
    readonly type = "[Saved Cart] Save Cart Success";
    constructor(payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
        saveCartDescription?: string;
    });
}
declare class SaveCartFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
        saveCartDescription?: string;
        error: any;
    };
    readonly type = "[Saved Cart] Save Cart Fail";
    constructor(payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
        saveCartDescription?: string;
        error: any;
    });
}
declare class ClearSaveCart extends StateUtils.EntityLoaderResetAction {
    readonly type = "[Saved Cart] Clear Save Cart";
    constructor();
}
declare class EditSavedCart extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
        saveCartDescription?: string;
    };
    readonly type = "[Saved Cart] Edit Saved Cart";
    constructor(payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
        saveCartDescription?: string;
    });
}
declare class EditSavedCartSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
        saveCartDescription?: string;
    };
    readonly type = "[Saved Cart] Edit Saved Cart Success";
    constructor(payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
        saveCartDescription?: string;
    });
}
declare class EditSavedCartFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
        saveCartDescription?: string;
        error: any;
    };
    readonly type = "[Saved Cart] Edit Saved Cart Fail";
    constructor(payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
        saveCartDescription?: string;
        error: any;
    });
}
declare class CloneSavedCart extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
    };
    readonly type = "[Saved Cart] Clone Saved Cart";
    constructor(payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
    });
}
declare class CloneSavedCartSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
    };
    readonly type = "[Saved Cart] Clone Saved Cart Success";
    constructor(payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
    });
}
declare class CloneSavedCartFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
        error: any;
    };
    readonly type = "[Saved Cart] Clone Saved Cart Fail";
    constructor(payload: {
        userId: string;
        cartId: string;
        saveCartName?: string;
        error: any;
    });
}
declare class ClearCloneSavedCart extends StateUtils.EntityLoaderResetAction {
    readonly type = "[Saved Cart] Clear Clone Saved Cart";
    constructor();
}
type SavedCartActions = LoadSavedCart | LoadSavedCartSuccess | LoadSavedCartFail | LoadSavedCarts | LoadSavedCartsSuccess | LoadSavedCartsFail | ClearSavedCarts | RestoreSavedCart | RestoreSavedCartSuccess | RestoreSavedCartFail | ClearRestoreSavedCart | SaveCart | SaveCartSuccess | SaveCartFail | ClearSaveCart | EditSavedCart | EditSavedCartSuccess | EditSavedCartFail | CloneSavedCart | CloneSavedCartSuccess | CloneSavedCartFail | ClearCloneSavedCart;

declare const savedCart_action_d_CLEAR_CLONE_SAVED_CART: typeof CLEAR_CLONE_SAVED_CART;
declare const savedCart_action_d_CLEAR_RESTORE_SAVED_CART: typeof CLEAR_RESTORE_SAVED_CART;
declare const savedCart_action_d_CLEAR_SAVED_CARTS: typeof CLEAR_SAVED_CARTS;
declare const savedCart_action_d_CLEAR_SAVE_CART: typeof CLEAR_SAVE_CART;
declare const savedCart_action_d_CLONE_SAVED_CART: typeof CLONE_SAVED_CART;
declare const savedCart_action_d_CLONE_SAVED_CART_FAIL: typeof CLONE_SAVED_CART_FAIL;
declare const savedCart_action_d_CLONE_SAVED_CART_SUCCESS: typeof CLONE_SAVED_CART_SUCCESS;
type savedCart_action_d_ClearCloneSavedCart = ClearCloneSavedCart;
declare const savedCart_action_d_ClearCloneSavedCart: typeof ClearCloneSavedCart;
type savedCart_action_d_ClearRestoreSavedCart = ClearRestoreSavedCart;
declare const savedCart_action_d_ClearRestoreSavedCart: typeof ClearRestoreSavedCart;
type savedCart_action_d_ClearSaveCart = ClearSaveCart;
declare const savedCart_action_d_ClearSaveCart: typeof ClearSaveCart;
type savedCart_action_d_ClearSavedCarts = ClearSavedCarts;
declare const savedCart_action_d_ClearSavedCarts: typeof ClearSavedCarts;
type savedCart_action_d_CloneSavedCart = CloneSavedCart;
declare const savedCart_action_d_CloneSavedCart: typeof CloneSavedCart;
type savedCart_action_d_CloneSavedCartFail = CloneSavedCartFail;
declare const savedCart_action_d_CloneSavedCartFail: typeof CloneSavedCartFail;
type savedCart_action_d_CloneSavedCartSuccess = CloneSavedCartSuccess;
declare const savedCart_action_d_CloneSavedCartSuccess: typeof CloneSavedCartSuccess;
declare const savedCart_action_d_EDIT_SAVED_CART: typeof EDIT_SAVED_CART;
declare const savedCart_action_d_EDIT_SAVED_CART_FAIL: typeof EDIT_SAVED_CART_FAIL;
declare const savedCart_action_d_EDIT_SAVED_CART_SUCCESS: typeof EDIT_SAVED_CART_SUCCESS;
type savedCart_action_d_EditSavedCart = EditSavedCart;
declare const savedCart_action_d_EditSavedCart: typeof EditSavedCart;
type savedCart_action_d_EditSavedCartFail = EditSavedCartFail;
declare const savedCart_action_d_EditSavedCartFail: typeof EditSavedCartFail;
type savedCart_action_d_EditSavedCartSuccess = EditSavedCartSuccess;
declare const savedCart_action_d_EditSavedCartSuccess: typeof EditSavedCartSuccess;
declare const savedCart_action_d_LOAD_SAVED_CART: typeof LOAD_SAVED_CART;
declare const savedCart_action_d_LOAD_SAVED_CARTS: typeof LOAD_SAVED_CARTS;
declare const savedCart_action_d_LOAD_SAVED_CARTS_FAIL: typeof LOAD_SAVED_CARTS_FAIL;
declare const savedCart_action_d_LOAD_SAVED_CARTS_SUCCESS: typeof LOAD_SAVED_CARTS_SUCCESS;
declare const savedCart_action_d_LOAD_SAVED_CART_FAIL: typeof LOAD_SAVED_CART_FAIL;
declare const savedCart_action_d_LOAD_SAVED_CART_SUCCESS: typeof LOAD_SAVED_CART_SUCCESS;
type savedCart_action_d_LoadSavedCart = LoadSavedCart;
declare const savedCart_action_d_LoadSavedCart: typeof LoadSavedCart;
type savedCart_action_d_LoadSavedCartFail = LoadSavedCartFail;
declare const savedCart_action_d_LoadSavedCartFail: typeof LoadSavedCartFail;
type savedCart_action_d_LoadSavedCartSuccess = LoadSavedCartSuccess;
declare const savedCart_action_d_LoadSavedCartSuccess: typeof LoadSavedCartSuccess;
type savedCart_action_d_LoadSavedCarts = LoadSavedCarts;
declare const savedCart_action_d_LoadSavedCarts: typeof LoadSavedCarts;
type savedCart_action_d_LoadSavedCartsFail = LoadSavedCartsFail;
declare const savedCart_action_d_LoadSavedCartsFail: typeof LoadSavedCartsFail;
type savedCart_action_d_LoadSavedCartsSuccess = LoadSavedCartsSuccess;
declare const savedCart_action_d_LoadSavedCartsSuccess: typeof LoadSavedCartsSuccess;
declare const savedCart_action_d_RESTORE_SAVED_CART: typeof RESTORE_SAVED_CART;
declare const savedCart_action_d_RESTORE_SAVED_CART_FAIL: typeof RESTORE_SAVED_CART_FAIL;
declare const savedCart_action_d_RESTORE_SAVED_CART_SUCCESS: typeof RESTORE_SAVED_CART_SUCCESS;
type savedCart_action_d_RestoreSavedCart = RestoreSavedCart;
declare const savedCart_action_d_RestoreSavedCart: typeof RestoreSavedCart;
type savedCart_action_d_RestoreSavedCartFail = RestoreSavedCartFail;
declare const savedCart_action_d_RestoreSavedCartFail: typeof RestoreSavedCartFail;
type savedCart_action_d_RestoreSavedCartSuccess = RestoreSavedCartSuccess;
declare const savedCart_action_d_RestoreSavedCartSuccess: typeof RestoreSavedCartSuccess;
declare const savedCart_action_d_SAVE_CART: typeof SAVE_CART;
declare const savedCart_action_d_SAVE_CART_FAIL: typeof SAVE_CART_FAIL;
declare const savedCart_action_d_SAVE_CART_SUCCESS: typeof SAVE_CART_SUCCESS;
type savedCart_action_d_SaveCart = SaveCart;
declare const savedCart_action_d_SaveCart: typeof SaveCart;
type savedCart_action_d_SaveCartFail = SaveCartFail;
declare const savedCart_action_d_SaveCartFail: typeof SaveCartFail;
type savedCart_action_d_SaveCartSuccess = SaveCartSuccess;
declare const savedCart_action_d_SaveCartSuccess: typeof SaveCartSuccess;
type savedCart_action_d_SavedCartActions = SavedCartActions;
declare namespace savedCart_action_d {
  export { savedCart_action_d_CLEAR_CLONE_SAVED_CART as CLEAR_CLONE_SAVED_CART, savedCart_action_d_CLEAR_RESTORE_SAVED_CART as CLEAR_RESTORE_SAVED_CART, savedCart_action_d_CLEAR_SAVED_CARTS as CLEAR_SAVED_CARTS, savedCart_action_d_CLEAR_SAVE_CART as CLEAR_SAVE_CART, savedCart_action_d_CLONE_SAVED_CART as CLONE_SAVED_CART, savedCart_action_d_CLONE_SAVED_CART_FAIL as CLONE_SAVED_CART_FAIL, savedCart_action_d_CLONE_SAVED_CART_SUCCESS as CLONE_SAVED_CART_SUCCESS, savedCart_action_d_ClearCloneSavedCart as ClearCloneSavedCart, savedCart_action_d_ClearRestoreSavedCart as ClearRestoreSavedCart, savedCart_action_d_ClearSaveCart as ClearSaveCart, savedCart_action_d_ClearSavedCarts as ClearSavedCarts, savedCart_action_d_CloneSavedCart as CloneSavedCart, savedCart_action_d_CloneSavedCartFail as CloneSavedCartFail, savedCart_action_d_CloneSavedCartSuccess as CloneSavedCartSuccess, savedCart_action_d_EDIT_SAVED_CART as EDIT_SAVED_CART, savedCart_action_d_EDIT_SAVED_CART_FAIL as EDIT_SAVED_CART_FAIL, savedCart_action_d_EDIT_SAVED_CART_SUCCESS as EDIT_SAVED_CART_SUCCESS, savedCart_action_d_EditSavedCart as EditSavedCart, savedCart_action_d_EditSavedCartFail as EditSavedCartFail, savedCart_action_d_EditSavedCartSuccess as EditSavedCartSuccess, savedCart_action_d_LOAD_SAVED_CART as LOAD_SAVED_CART, savedCart_action_d_LOAD_SAVED_CARTS as LOAD_SAVED_CARTS, savedCart_action_d_LOAD_SAVED_CARTS_FAIL as LOAD_SAVED_CARTS_FAIL, savedCart_action_d_LOAD_SAVED_CARTS_SUCCESS as LOAD_SAVED_CARTS_SUCCESS, savedCart_action_d_LOAD_SAVED_CART_FAIL as LOAD_SAVED_CART_FAIL, savedCart_action_d_LOAD_SAVED_CART_SUCCESS as LOAD_SAVED_CART_SUCCESS, savedCart_action_d_LoadSavedCart as LoadSavedCart, savedCart_action_d_LoadSavedCartFail as LoadSavedCartFail, savedCart_action_d_LoadSavedCartSuccess as LoadSavedCartSuccess, savedCart_action_d_LoadSavedCarts as LoadSavedCarts, savedCart_action_d_LoadSavedCartsFail as LoadSavedCartsFail, savedCart_action_d_LoadSavedCartsSuccess as LoadSavedCartsSuccess, savedCart_action_d_RESTORE_SAVED_CART as RESTORE_SAVED_CART, savedCart_action_d_RESTORE_SAVED_CART_FAIL as RESTORE_SAVED_CART_FAIL, savedCart_action_d_RESTORE_SAVED_CART_SUCCESS as RESTORE_SAVED_CART_SUCCESS, savedCart_action_d_RestoreSavedCart as RestoreSavedCart, savedCart_action_d_RestoreSavedCartFail as RestoreSavedCartFail, savedCart_action_d_RestoreSavedCartSuccess as RestoreSavedCartSuccess, savedCart_action_d_SAVE_CART as SAVE_CART, savedCart_action_d_SAVE_CART_FAIL as SAVE_CART_FAIL, savedCart_action_d_SAVE_CART_SUCCESS as SAVE_CART_SUCCESS, savedCart_action_d_SaveCart as SaveCart, savedCart_action_d_SaveCartFail as SaveCartFail, savedCart_action_d_SaveCartSuccess as SaveCartSuccess };
  export type { savedCart_action_d_SavedCartActions as SavedCartActions };
}

declare const SAVED_CART_LIST_PROCESS_ID = "saved-cart-list";
declare const SAVED_CART_RESTORE_CART_PROCESS_ID = "saved-cart-restore-cart";
declare const SAVED_CART_SAVE_CART_PROCESS_ID = "saved-cart-save-cart";
declare const SAVED_CART_CLONE_CART_PROCESS_ID = "saved-cart-clone-cart";

export { SAVED_CART_CLONE_CART_PROCESS_ID, SAVED_CART_LIST_PROCESS_ID, SAVED_CART_RESTORE_CART_PROCESS_ID, SAVED_CART_SAVE_CART_PROCESS_ID, savedCart_action_d as SavedCartActions, SavedCartAdapter, SavedCartConnector, SavedCartCoreModule, SavedCartEventBuilder, SavedCartEventsModule, SavedCartService };
