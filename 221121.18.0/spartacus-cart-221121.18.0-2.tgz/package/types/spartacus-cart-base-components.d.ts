import * as _spartacus_cart_base_root from '@spartacus/cart/base/root';
import { AbstractOrderKey, AbstractOrderType, CartUiEventAddToCart, CartAddEntryFailEvent, CartAddEntrySuccessEvent, ActiveCartFacade, OrderEntry, Cart, PromotionLocation, CartVoucherFacade, Voucher, CartValidationFacade, CartItemComponentOptions, CartOutlets, CartItemQuantityService, CartItemContext, SelectiveCartFacade, MultiCartFacade, CartModification, AddOrderEntriesContext, GetOrderEntriesContext, OrderEntriesSource, ProductData, ProductImportInfo } from '@spartacus/cart/base/root';
import * as rxjs from 'rxjs';
import { Observable, ReplaySubject, Subscription } from 'rxjs';
import * as i0 from '@angular/core';
import { OnChanges, SimpleChanges, OnDestroy, OnInit, ElementRef, ChangeDetectorRef, ViewContainerRef } from '@angular/core';
import * as i3$1 from '@spartacus/core';
import { EventService, RoutingService, CustomerCouponService, CustomerCoupon, CmsAddToCartComponent, Product, ProductCatalogService, UserIdService, AuthService, CmsService, CmsParagraphComponent, GlobalMessageService } from '@spartacus/core';
import * as i5 from '@spartacus/storefront';
import { LaunchDialogService, ICON_TYPE, FocusConfig, CurrentProductService, CmsComponentData, ProductListItemContext, OutletContextData, PageLayoutHandler, LayoutConfig } from '@spartacus/storefront';
import * as i3 from '@angular/forms';
import { UntypedFormGroup, UntypedFormControl, UntypedFormBuilder } from '@angular/forms';
import * as i1 from '@angular/common';
import * as i2 from '@ng-select/ng-select';
import * as i2$1 from '@angular/router';
import { Router } from '@angular/router';
import { CartConfigService, ProductImportInfoService } from '@spartacus/cart/base/core';

/**
 * Context for transporting information about an abstract order (active cart, saved cart, order, quote).
 */
declare abstract class AbstractOrderContext {
    readonly key$: Observable<AbstractOrderKey>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbstractOrderContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AbstractOrderContext>;
}

/**
 * Context source for AbstractOrderContext. Default values represent the context
 * of an active cart
 *
 * AbstractOrderContext should be injected in child components.
 */
declare class AbstractOrderContextSource implements AbstractOrderContext {
    readonly key$: ReplaySubject<AbstractOrderKey>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbstractOrderContextSource, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AbstractOrderContextSource>;
}

/**
 * Consumers cannot always guarentee at design time that id is present
 * -> we provide this 'relaxed' version of {@link AbstractOrderKey} and
 * check at runtime if id is present for the document types that require it.
 */
interface AbstractOrderKeyInput {
    type: AbstractOrderType;
    id?: string;
}
declare class AbstractOrderContextDirective implements OnChanges {
    cxAbstractOrderContext: AbstractOrderKeyInput;
    protected abstractOrderContextSource: AbstractOrderContextSource;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbstractOrderContextDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AbstractOrderContextDirective, "[cxAbstractOrderContext]", never, { "cxAbstractOrderContext": { "alias": "cxAbstractOrderContext"; "required": false; }; }, {}, never, never, true, never>;
}

declare class AbstractOrderContextModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AbstractOrderContextModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AbstractOrderContextModule, never, [typeof AbstractOrderContextDirective], [typeof AbstractOrderContextDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AbstractOrderContextModule>;
}

declare class AddedToCartDialogEventListener implements OnDestroy {
    protected eventService: EventService;
    protected launchDialogService: LaunchDialogService;
    protected subscription: Subscription;
    constructor(eventService: EventService, launchDialogService: LaunchDialogService);
    protected onAddToCart(): void;
    /**
     * Opens modal based on CartUiEventAddToCart.
     * @param event Signals that a product has been added to the cart.
     */
    protected openModal(event: CartUiEventAddToCart): void;
    protected createCompletionObservable(): Observable<CartAddEntryFailEvent | CartAddEntrySuccessEvent>;
    protected closeModal(reason?: any): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddedToCartDialogEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AddedToCartDialogEventListener>;
}

interface AddedToCartDialogComponentData {
    productCode: string;
    quantity: number;
    numberOfEntriesBeforeAdd: number;
    pickupStoreName?: string;
    /**
     * Observable emitting the result of adding an item to cart. It emits either
     * {@link CartAddEntrySuccessEvent} or {@link CartAddEntryFailEvent)
     */
    addingEntryResult$?: Observable<CartAddEntrySuccessEvent | CartAddEntryFailEvent>;
}
declare class AddedToCartDialogComponent implements OnInit, OnDestroy {
    protected activeCartFacade: ActiveCartFacade;
    protected launchDialogService: LaunchDialogService;
    protected routingService: RoutingService;
    protected el: ElementRef;
    iconTypes: typeof ICON_TYPE;
    entry$: Observable<OrderEntry | undefined>;
    cart$: Observable<Cart>;
    loaded$: Observable<boolean>;
    addedEntryWasMerged$: Observable<boolean>;
    promotionLocation: PromotionLocation;
    quantity: number;
    pickupStoreName: string | undefined;
    form: UntypedFormGroup;
    focusConfig: FocusConfig;
    handleClick(event: UIEvent): void;
    protected quantityControl$: Observable<UntypedFormControl>;
    protected subscription: Subscription;
    constructor(activeCartFacade: ActiveCartFacade, launchDialogService: LaunchDialogService, routingService: RoutingService, el: ElementRef);
    ngOnInit(): void;
    /**
     * Returns an observable formControl with the quantity of the cartEntry,
     * but also updates the entry in case of a changed value.
     * The quantity can be set to zero in order to remove the entry.
     */
    getQuantityControl(): Observable<UntypedFormControl>;
    init(productCode: string, quantity: number, numberOfEntriesBeforeAdd: number, pickupStoreName?: string, addingEntryResult$?: Observable<CartAddEntrySuccessEvent | CartAddEntryFailEvent>): void;
    /**
     * Determines if the added entry was merged with an existing one.
     *
     * @param numberOfEntriesBeforeAdd Number of entries in cart before addToCart has been performed
     * @returns Has entry been merged?
     */
    protected getAddedEntryWasMerged(numberOfEntriesBeforeAdd: number): Observable<boolean>;
    /**
     * Adds quantity and entryNumber form controls to the FormGroup.
     * Returns quantity form control.
     */
    protected getQuantityFormControl(entry?: OrderEntry): UntypedFormControl;
    dismissModal(reason?: any): void;
    onAction(action: 'viewCart' | 'checkout'): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddedToCartDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddedToCartDialogComponent, "cx-added-to-cart-dialog", never, {}, {}, never, never, true, never>;
}

declare class CartCouponComponent implements OnInit, OnDestroy {
    protected cartVoucherService: CartVoucherFacade;
    protected formBuilder: UntypedFormBuilder;
    protected customerCouponService: CustomerCouponService;
    protected activeCartService: ActiveCartFacade;
    MAX_CUSTOMER_COUPON_PAGE: number;
    couponForm: UntypedFormGroup;
    cartIsLoading$: Observable<boolean>;
    cart$: Observable<Cart>;
    cartId: string;
    applicableCoupons: CustomerCoupon[];
    protected ignoreCloseEvent: boolean;
    protected subscription: Subscription;
    couponBoxIsActive: boolean;
    constructor(cartVoucherService: CartVoucherFacade, formBuilder: UntypedFormBuilder, customerCouponService: CustomerCouponService, activeCartService: ActiveCartFacade);
    ngOnInit(): void;
    protected onError(error: boolean): void;
    onSuccess(success: boolean): void;
    protected getApplicableCustomerCoupons(cart: Cart, coupons: CustomerCoupon[]): void;
    applyVoucher(): void;
    applyCustomerCoupon(couponId: string): void;
    close(event: UIEvent): void;
    disableClose(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartCouponComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CartCouponComponent, "cx-cart-coupon", never, {}, {}, never, never, true, never>;
}

declare class AppliedCouponsComponent {
    protected cartVoucherService: CartVoucherFacade;
    vouchers: Voucher[];
    cartIsLoading: boolean;
    isReadOnly: boolean;
    iconTypes: typeof ICON_TYPE;
    constructor(cartVoucherService: CartVoucherFacade);
    get sortedVouchers(): Voucher[];
    removeVoucher(voucherId: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AppliedCouponsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AppliedCouponsComponent, "cx-applied-coupons", never, { "vouchers": { "alias": "vouchers"; "required": false; }; "cartIsLoading": { "alias": "cartIsLoading"; "required": false; }; "isReadOnly": { "alias": "isReadOnly"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CartCouponModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CartCouponModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartCouponModule, never, [typeof i1.CommonModule, typeof i2.NgSelectModule, typeof i3.FormsModule, typeof i3.ReactiveFormsModule, typeof i3$1.I18nModule, typeof i5.IconModule, typeof i5.FormErrorsModule, typeof i3$1.FeaturesConfigModule, typeof i5.FormRequiredLegendComponent, typeof CartCouponComponent, typeof AppliedCouponsComponent], [typeof CartCouponComponent, typeof AppliedCouponsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartCouponModule>;
}

declare class CartItemValidationWarningComponent {
    protected cartValidationFacade: CartValidationFacade;
    code: string;
    iconTypes: typeof ICON_TYPE;
    isVisible: boolean;
    cartModification$: rxjs.Observable<_spartacus_cart_base_root.CartModification | undefined>;
    constructor(cartValidationFacade: CartValidationFacade);
    static ɵfac: i0.ɵɵFactoryDeclaration<CartItemValidationWarningComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CartItemValidationWarningComponent, "cx-cart-item-validation-warning", never, { "code": { "alias": "code"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CartItemValidationWarningModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CartItemValidationWarningModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartItemValidationWarningModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof i3$1.I18nModule, typeof i3$1.UrlModule, typeof i5.IconModule, typeof CartItemValidationWarningComponent], [typeof CartItemValidationWarningComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartItemValidationWarningModule>;
}

declare class AddToCartComponent implements OnInit, OnDestroy {
    protected currentProductService: CurrentProductService;
    protected cd: ChangeDetectorRef;
    protected activeCartService: ActiveCartFacade;
    protected component: CmsComponentData<CmsAddToCartComponent>;
    protected eventService: EventService;
    protected productListItemContext?: ProductListItemContext | undefined;
    productCode: string;
    showQuantity: boolean;
    options: CartItemComponentOptions;
    pickupStore: string | undefined;
    savedCart: Cart | undefined;
    /**
     * As long as we do not support #5026, we require product input, as we need
     *  a reference to the product model to fetch the stock data.
     */
    product: Product;
    /**
     * Element responsible for opening the modal. The reference is used to refocus the modal after it closes.
     */
    addToCartDialogTriggerEl: ElementRef;
    maxQuantity: number;
    disabled: boolean;
    hasStock: boolean;
    inventoryThreshold: boolean;
    showInventory$: Observable<boolean | undefined> | undefined;
    unavailable: boolean;
    quantity: number;
    subscription: Subscription;
    addToCartForm: UntypedFormGroup;
    readonly CartOutlets: typeof CartOutlets;
    pickupOptionCompRef: any;
    iconTypes: typeof ICON_TYPE;
    private productAvailabilityService;
    protected productCatalogService: ProductCatalogService;
    protected cartItemQuantityService: CartItemQuantityService;
    protected realTimeStockEnabled: boolean;
    /**
     * We disable the dialog launch on quantity input,
     * as it causes an unexpected change of context.
     * The expectation is only for the quantity to get updated in the Qty field.
     */
    handleKeyboardEvent(event: KeyboardEvent): void;
    constructor(currentProductService: CurrentProductService, cd: ChangeDetectorRef, activeCartService: ActiveCartFacade, component: CmsComponentData<CmsAddToCartComponent>, eventService: EventService, productListItemContext?: ProductListItemContext | undefined);
    ngOnInit(): void;
    protected subscribeToQuantityChanges(): void;
    protected setStockInfo(product: Product): void;
    /**
     * In specific scenarios, we need to omit displaying the stock level or append a plus to the value.
     * When backoffice forces a product to be in stock, omit showing the stock level.
     * When product stock level is limited by a threshold value, append '+' at the end.
     * When out of stock, display no numerical value.
     */
    getInventory(): string;
    updateCount(value: number): void;
    addToCart(): void;
    protected createCartUiEventAddToCart(productCode: string, quantity: number, numberOfEntriesBeforeAdd: number, storeName?: string): CartUiEventAddToCart;
    onPickupOptionsCompLoaded(): void;
    protected getQuantityFromSavedCart(productCode: string): number;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddToCartComponent, [null, null, null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddToCartComponent, "cx-add-to-cart", never, { "productCode": { "alias": "productCode"; "required": false; }; "showQuantity": { "alias": "showQuantity"; "required": false; }; "options": { "alias": "options"; "required": false; }; "pickupStore": { "alias": "pickupStore"; "required": false; }; "savedCart": { "alias": "savedCart"; "required": false; }; "product": { "alias": "product"; "required": false; }; }, {}, never, never, true, never>;
}

declare class AddToCartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AddToCartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AddToCartModule, never, [typeof i1.CommonModule, typeof i3.ReactiveFormsModule, typeof i3$1.I18nModule, typeof i5.IconModule, typeof i5.ItemCounterModule, typeof i5.OutletModule, typeof i3$1.FeaturesConfigModule, typeof AddToCartComponent], [typeof AddToCartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AddToCartModule>;
}

/**
 * Context source for `CartItemComponent`.
 *
 * `CartItemContext` should be injected instead in child components.
 */
declare class CartItemContextSource implements CartItemContext {
    readonly compact$: ReplaySubject<boolean>;
    readonly readonly$: ReplaySubject<boolean>;
    readonly item$: ReplaySubject<OrderEntry>;
    readonly quantityControl$: ReplaySubject<UntypedFormControl>;
    readonly location$: ReplaySubject<PromotionLocation>;
    readonly options$: ReplaySubject<CartItemComponentOptions>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartItemContextSource, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartItemContextSource>;
}

declare class CartItemComponent implements OnChanges {
    protected cartItemContextSource: CartItemContextSource;
    compact: boolean;
    item: OrderEntry;
    readonly: boolean;
    quantityControl: UntypedFormControl;
    promotionLocation: PromotionLocation;
    options: CartItemComponentOptions;
    iconTypes: typeof ICON_TYPE;
    readonly CartOutlets: typeof CartOutlets;
    constructor(cartItemContextSource: CartItemContextSource);
    ngOnChanges(changes?: SimpleChanges): void;
    isProductOutOfStock(product: any): boolean;
    removeItem(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CartItemComponent, "cx-cart-item", never, { "compact": { "alias": "compact"; "required": false; }; "item": { "alias": "item"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "quantityControl": { "alias": "quantityControl"; "required": false; }; "promotionLocation": { "alias": "promotionLocation"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OrderSummaryComponent implements OnInit, OnDestroy {
    protected outlet?: OutletContextData<any> | undefined;
    cart: Cart;
    protected subscription: Subscription;
    constructor(outlet?: OutletContextData<any> | undefined);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderSummaryComponent, [{ optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderSummaryComponent, "cx-order-summary", never, { "cart": { "alias": "cart"; "required": false; }; }, {}, never, never, true, never>;
}

interface ItemListContext {
    readonly?: boolean;
    hasHeader?: boolean;
    options?: CartItemComponentOptions;
    cartId?: string;
    items?: OrderEntry[];
    promotionLocation?: PromotionLocation;
    cartIsLoading?: boolean;
}
declare class CartItemListComponent implements OnInit, OnDestroy {
    protected activeCartService: ActiveCartFacade;
    protected selectiveCartService: SelectiveCartFacade;
    protected userIdService: UserIdService;
    protected multiCartService: MultiCartFacade;
    protected cd: ChangeDetectorRef;
    protected outlet?: OutletContextData<ItemListContext> | undefined;
    protected productCatalogService: ProductCatalogService;
    protected subscription: Subscription;
    protected userId: string;
    readonly: boolean;
    hasHeader: boolean;
    options: CartItemComponentOptions;
    cartId: string;
    protected _items: OrderEntry[];
    form: UntypedFormGroup;
    set items(items: OrderEntry[]);
    get items(): OrderEntry[];
    promotionLocation: PromotionLocation;
    set cartIsLoading(value: boolean);
    /** @deprecated Use `cartIsLoading` */
    set setLoading(value: boolean);
    readonly CartOutlets: typeof CartOutlets;
    private featureToggles;
    constructor(activeCartService: ActiveCartFacade, selectiveCartService: SelectiveCartFacade, userIdService: UserIdService, multiCartService: MultiCartFacade, cd: ChangeDetectorRef, outlet?: OutletContextData<ItemListContext> | undefined);
    ngOnInit(): void;
    protected _setItems(items: OrderEntry[], options?: {
        forceRerender?: boolean;
    }): void;
    protected getInputsFromContext(): Subscription | undefined;
    protected updateItemsOnContextChange(context: ItemListContext, contextRequiresRerender: boolean): void;
    protected isItemsChanged(newItems: OrderEntry[]): boolean;
    /**
     * Resolves items passed to component input and updates 'items' field
     */
    protected resolveItems(items: OrderEntry[], options?: {
        forceRerender?: boolean;
    }): void;
    protected normalizeConsignmentEntries(items: OrderEntry[]): void;
    /**
     * We'd like to avoid the unnecessary re-renders of unchanged cart items after the data reload.
     * OCC cart entries don't have any unique identifier that we could use in Angular `trackBy`.
     * So we update each array element to the new object only when it's any different to the previous one.
     */
    protected rerenderChangedItems(items: OrderEntry[], options?: {
        forceRerender?: boolean;
    }): void;
    /**
     * Creates form models for list items
     */
    protected createForm(): void;
    protected getControlName(item: OrderEntry): string;
    removeEntry(item: OrderEntry): void;
    getControl(item: OrderEntry): Observable<UntypedFormGroup> | undefined;
    getOptions(item: OrderEntry): CartItemComponentOptions;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartItemListComponent, [null, null, null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CartItemListComponent, "cx-cart-item-list", never, { "readonly": { "alias": "readonly"; "required": false; }; "hasHeader": { "alias": "hasHeader"; "required": false; }; "options": { "alias": "options"; "required": false; }; "cartId": { "alias": "cartId"; "required": false; }; "items": { "alias": "items"; "required": false; }; "promotionLocation": { "alias": "promotionLocation"; "required": false; }; "cartIsLoading": { "alias": "cartIsLoading"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CartItemListComponentService {
    showBasePriceWithDiscount(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartItemListComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartItemListComponentService>;
}

declare class CartItemListRowComponent extends CartItemComponent {
    items: OrderEntry[];
    protected componentService: CartItemListComponentService;
    isFlagQuote: boolean;
    constructor(cartItemContextSource: CartItemContextSource);
    static ɵfac: i0.ɵɵFactoryDeclaration<CartItemListRowComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CartItemListRowComponent, "[cx-cart-item-list-row], cx-cart-item-list-row", never, { "items": { "alias": "items"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CartSharedModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CartSharedModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartSharedModule, never, [typeof i5.AtMessageModule, typeof CartCouponModule, typeof CartItemValidationWarningModule, typeof i1.CommonModule, typeof i3$1.I18nModule, typeof i5.IconModule, typeof i5.ItemCounterModule, typeof i5.MediaModule, typeof i5.OutletModule, typeof i5.PromotionsModule, typeof i3.ReactiveFormsModule, typeof i2$1.RouterModule, typeof i3$1.UrlModule, typeof AddToCartModule, typeof i3$1.FeaturesConfigModule, typeof CartItemComponent, typeof OrderSummaryComponent, typeof CartItemListComponent, typeof CartItemListRowComponent], [typeof CartItemComponent, typeof CartItemListRowComponent, typeof CartItemListComponent, typeof OrderSummaryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartSharedModule>;
}

declare class AddedToCartDialogModule {
    constructor(_addToCartDialogEventListener: AddedToCartDialogEventListener);
    static ɵfac: i0.ɵɵFactoryDeclaration<AddedToCartDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AddedToCartDialogModule, never, [typeof i1.CommonModule, typeof i3.ReactiveFormsModule, typeof CartSharedModule, typeof i2$1.RouterModule, typeof i5.SpinnerModule, typeof i5.PromotionsModule, typeof i3$1.UrlModule, typeof i5.IconModule, typeof i3$1.I18nModule, typeof i5.ItemCounterModule, typeof i5.KeyboardFocusModule, typeof i3$1.FeaturesConfigModule, typeof i5.BtnLikeLinkModule, typeof AddedToCartDialogComponent], [typeof AddedToCartDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AddedToCartDialogModule>;
}

declare class CartValidationWarningsComponent {
    protected cartValidationFacade: CartValidationFacade;
    iconTypes: typeof ICON_TYPE;
    visibleWarnings: Record<string, boolean>;
    cartModifications$: rxjs.Observable<CartModification[]>;
    constructor(cartValidationFacade: CartValidationFacade);
    removeMessage(cartModification: CartModification): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartValidationWarningsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CartValidationWarningsComponent, "cx-cart-validation-warnings", never, {}, {}, never, never, true, never>;
}

declare class CartValidationWarningsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CartValidationWarningsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartValidationWarningsModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof i3$1.I18nModule, typeof i3$1.UrlModule, typeof i5.IconModule, typeof CartValidationWarningsComponent], [typeof CartValidationWarningsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartValidationWarningsModule>;
}

declare class CartDetailsComponent implements OnInit {
    protected activeCartService: ActiveCartFacade;
    protected selectiveCartService: SelectiveCartFacade;
    protected authService: AuthService;
    protected routingService: RoutingService;
    protected cartConfig: CartConfigService;
    cart$: Observable<Cart>;
    entries$: Observable<OrderEntry[]>;
    cartLoaded$: Observable<boolean>;
    loggedIn: boolean;
    promotionLocation: PromotionLocation;
    selectiveCartEnabled: boolean;
    constructor(activeCartService: ActiveCartFacade, selectiveCartService: SelectiveCartFacade, authService: AuthService, routingService: RoutingService, cartConfig: CartConfigService);
    ngOnInit(): void;
    saveForLater(item: OrderEntry): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CartDetailsComponent, "cx-cart-details", never, {}, {}, never, never, true, never>;
}

declare class CartDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CartDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartDetailsModule, never, [typeof CartSharedModule, typeof i1.CommonModule, typeof CartCouponModule, typeof i2$1.RouterModule, typeof i3$1.UrlModule, typeof i5.PromotionsModule, typeof i3$1.I18nModule, typeof CartValidationWarningsModule, typeof CartDetailsComponent], [typeof CartDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartDetailsModule>;
}

declare class CartProceedToCheckoutComponent implements OnInit, OnDestroy {
    protected router: Router;
    protected cd?: ChangeDetectorRef | undefined;
    cartValidationInProgress: boolean;
    protected subscription: Subscription;
    constructor(router: Router, cd?: ChangeDetectorRef | undefined);
    ngOnInit(): void;
    disableButtonWhileNavigation(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartProceedToCheckoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CartProceedToCheckoutComponent, "cx-cart-proceed-to-checkout", never, {}, {}, never, never, true, never>;
}

declare class CartProceedToCheckoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CartProceedToCheckoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartProceedToCheckoutModule, never, [typeof i1.CommonModule, typeof i5.ProgressButtonModule, typeof i2$1.RouterModule, typeof i3$1.I18nModule, typeof i3$1.UrlModule, typeof CartProceedToCheckoutComponent], [typeof CartProceedToCheckoutComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartProceedToCheckoutModule>;
}

declare class CartTotalsComponent implements OnInit {
    protected activeCartService: ActiveCartFacade;
    cart$: Observable<Cart>;
    constructor(activeCartService: ActiveCartFacade);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartTotalsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CartTotalsComponent, "cx-cart-totals", never, {}, {}, never, never, true, never>;
}

declare class CartTotalsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CartTotalsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartTotalsModule, never, [typeof i1.CommonModule, typeof CartSharedModule, typeof CartTotalsComponent], [typeof CartTotalsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartTotalsModule>;
}

declare class SaveForLaterComponent implements OnInit {
    protected cmsService: CmsService;
    protected cartService: ActiveCartFacade;
    protected selectiveCartService: SelectiveCartFacade;
    saveForLater$: Observable<Cart>;
    cart$: Observable<Cart>;
    entries$: Observable<OrderEntry[]>;
    cartLoaded$: Observable<boolean>;
    data$: Observable<CmsParagraphComponent>;
    isCartEmpty$: Observable<boolean>;
    CartLocation: typeof PromotionLocation;
    constructor(cmsService: CmsService, cartService: ActiveCartFacade, selectiveCartService: SelectiveCartFacade);
    ngOnInit(): void;
    moveToCart(item: OrderEntry): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SaveForLaterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SaveForLaterComponent, "cx-save-for-later", never, {}, {}, never, never, true, never>;
}

declare class SaveForLaterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SaveForLaterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SaveForLaterModule, never, [typeof i1.CommonModule, typeof i3$1.I18nModule, typeof CartSharedModule, typeof SaveForLaterComponent], [typeof SaveForLaterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SaveForLaterModule>;
}

declare class ClearCartDialogComponentService {
    protected launchDialogService: LaunchDialogService;
    protected globalMessageService: GlobalMessageService;
    protected activeCartFacade: ActiveCartFacade;
    protected multiCartFacade: MultiCartFacade;
    protected userIdService: UserIdService;
    protected eventService: EventService;
    constructor(launchDialogService: LaunchDialogService, globalMessageService: GlobalMessageService, activeCartFacade: ActiveCartFacade, multiCartFacade: MultiCartFacade, userIdService: UserIdService, eventService: EventService);
    /**
     * Clear the cart by deleting the active cart.
     */
    deleteActiveCart(): void;
    /**
     * Close clear cart modal dialog
     *
     * @param reason to close dialog
     */
    closeDialog(reason: string): void;
    /**
     * Display global message after clearing cart.
     * By default, only message displayed is of type `Success`. A negative scenario
     * related to cart has been handled in the occ layer already.
     *
     * @param success result of clear cart action
     */
    protected displayGlobalMessage(success: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClearCartDialogComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ClearCartDialogComponentService>;
}

declare class ClearCartDialogComponent implements OnDestroy {
    protected el: ElementRef;
    protected clearCartDialogComponentService: ClearCartDialogComponentService;
    focusConfig: FocusConfig;
    isClearing: boolean;
    iconTypes: typeof ICON_TYPE;
    handleClick(event: UIEvent): void;
    constructor(el: ElementRef, clearCartDialogComponentService: ClearCartDialogComponentService);
    clearCart(): void;
    close(reason: string): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClearCartDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClearCartDialogComponent, "cx-clear-cart-dialog", never, {}, {}, never, never, true, never>;
}

declare class ClearCartDialogModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ClearCartDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ClearCartDialogModule, never, [typeof i1.CommonModule, typeof i5.SpinnerModule, typeof i3$1.I18nModule, typeof i5.IconModule, typeof i5.KeyboardFocusModule, typeof i3$1.FeaturesConfigModule, typeof ClearCartDialogComponent], [typeof ClearCartDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ClearCartDialogModule>;
}

declare class ClearCartComponent implements OnDestroy {
    protected activeCartFacade: ActiveCartFacade;
    protected vcr: ViewContainerRef;
    protected launchDialogService: LaunchDialogService;
    cart$: Observable<Cart>;
    protected subscription: Subscription;
    element: ElementRef;
    constructor(activeCartFacade: ActiveCartFacade, vcr: ViewContainerRef, launchDialogService: LaunchDialogService);
    openDialog(event: Event): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClearCartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClearCartComponent, "cx-clear-cart", never, {}, {}, never, never, true, never>;
}

declare class ClearCartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ClearCartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ClearCartModule, never, [typeof i1.CommonModule, typeof i3$1.I18nModule, typeof ClearCartDialogModule, typeof ClearCartComponent], [typeof ClearCartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ClearCartModule>;
}

declare class CartBaseComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CartBaseComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartBaseComponentsModule, never, [typeof i1.CommonModule, typeof CartDetailsModule, typeof CartProceedToCheckoutModule, typeof CartTotalsModule, typeof CartSharedModule, typeof SaveForLaterModule, typeof ClearCartModule, typeof i5.OutletModule], [typeof CartDetailsModule, typeof CartProceedToCheckoutModule, typeof CartTotalsModule, typeof CartSharedModule, typeof ClearCartModule, typeof AddedToCartDialogModule, typeof SaveForLaterModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartBaseComponentsModule>;
}

declare class CartPageLayoutHandler implements PageLayoutHandler {
    protected activeCartService: ActiveCartFacade;
    protected selectiveCartService: SelectiveCartFacade;
    protected cartConfig: CartConfigService;
    constructor(activeCartService: ActiveCartFacade, selectiveCartService: SelectiveCartFacade, cartConfig: CartConfigService);
    handle(slots$: Observable<string[]>, pageTemplate?: string, section?: string): Observable<string[]>;
    protected getSelectiveCart(): Observable<Cart | null>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartPageLayoutHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartPageLayoutHandler>;
}

declare const defaultClearCartLayoutConfig: LayoutConfig;

declare class ActiveCartOrderEntriesContext implements AddOrderEntriesContext, GetOrderEntriesContext {
    protected importInfoService: ProductImportInfoService;
    protected activeCartFacade: ActiveCartFacade;
    readonly type = OrderEntriesSource.ACTIVE_CART;
    constructor(importInfoService: ProductImportInfoService, activeCartFacade: ActiveCartFacade);
    addEntries(products: ProductData[]): Observable<ProductImportInfo>;
    getEntries(): Observable<OrderEntry[]>;
    protected add(products: ProductData[]): Observable<string>;
    protected mapProductsToOrderEntries(products: ProductData[]): OrderEntry[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ActiveCartOrderEntriesContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ActiveCartOrderEntriesContext>;
}

declare class CartValidationComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CartValidationComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartValidationComponentsModule, never, [typeof CartValidationWarningsModule, typeof CartItemValidationWarningModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartValidationComponentsModule>;
}

export { AbstractOrderContext, AbstractOrderContextDirective, AbstractOrderContextModule, AbstractOrderContextSource, ActiveCartOrderEntriesContext, AddedToCartDialogComponent, AddedToCartDialogEventListener, AddedToCartDialogModule, AppliedCouponsComponent, CartBaseComponentsModule, CartCouponComponent, CartCouponModule, CartDetailsComponent, CartDetailsModule, CartItemComponent, CartItemContextSource, CartItemListComponent, CartItemListComponentService, CartItemListRowComponent, CartPageLayoutHandler, CartProceedToCheckoutComponent, CartProceedToCheckoutModule, CartSharedModule, CartTotalsComponent, CartTotalsModule, CartValidationComponentsModule, CartValidationWarningsComponent, CartValidationWarningsModule, ClearCartComponent, ClearCartDialogComponent, ClearCartDialogComponentService, ClearCartDialogModule, ClearCartModule, OrderSummaryComponent, SaveForLaterComponent, SaveForLaterModule, defaultClearCartLayoutConfig };
export type { AbstractOrderKeyInput, AddedToCartDialogComponentData };
