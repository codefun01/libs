import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import { OrderEntry, ProductData } from '@spartacus/cart/base/root';
import { HttpErrorModel, Product, RoutingConfig } from '@spartacus/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import * as i1 from '@angular/router';

declare abstract class QuickOrderConfig {
    quickOrder?: {
        searchForm?: {
            displayProductImages: boolean;
            maxProducts: number;
            minCharactersBeforeRequest: number;
        };
        list?: {
            hardDeleteTimeout: number;
        };
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<QuickOrderConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuickOrderConfig>;
}
declare module '@spartacus/core' {
    interface Config extends QuickOrderConfig {
    }
}

declare const defaultQuickOrderConfig: QuickOrderConfig;

type QuickOrderAddEntryEvent = {
    productCode: string;
    entry?: OrderEntry;
    quantityAdded?: number;
    quantity: number;
    error?: HttpErrorModel;
};

declare function quickOrderFacadeFactory(): QuickOrderFacade;
declare abstract class QuickOrderFacade {
    /**
     * Get entries
     */
    abstract getEntries(): BehaviorSubject<OrderEntry[]>;
    /**
     * Search products using query
     */
    abstract searchProducts(query: string, maxProducts?: number): Observable<Product[]>;
    /**
     * Clear a list of added entries
     */
    abstract clearList(): void;
    /**
     * Get information about the possibility to add the next product
     */
    abstract canAdd(code?: string, productsData?: ProductData[]): Observable<boolean>;
    /**
     * Set quick order list limit property
     */
    abstract setListLimit(limit: number): void;
    /**
     * Load a list of entries
     */
    abstract loadEntries(entries: OrderEntry[]): void;
    /**
     * Load a list of entries
     */
    abstract updateEntryQuantity(entryIndex: number, quantity: number): void;
    /**
     * Delete single entry from the list
     */
    abstract softDeleteEntry(index: number): void;
    /**
     * Add product to the quick order list
     */
    abstract addProduct(product: Product, quantity?: number): void;
    /**
     * Return product added subject
     */
    abstract getProductAdded(): Subject<string>;
    /**
     * Set product added subject
     */
    abstract setProductAdded(productCode: string): void;
    /**
     * Adding to cart all products from the list
     */
    abstract addToCart(): Observable<[OrderEntry[], QuickOrderAddEntryEvent[]]>;
    /**
     * Return soft deleted entries
     */
    abstract getSoftDeletedEntries(): Observable<Record<string, OrderEntry>>;
    /**
     * Restore soft deleted entry
     */
    abstract restoreSoftDeletedEntry(productCode: string): void;
    /**
     * Clear deleted entry from the list
     */
    abstract hardDeleteEntry(productCode: string): void;
    /**
     * Clear all deleted entries and timeout subscriptions
     */
    abstract clearDeletedEntries(): void;
    /**
     *  Return non purchasable product error
     */
    abstract getNonPurchasableProductError(): Observable<Product | null>;
    /**
     * Set error that selected product is not purchasable
     */
    abstract setNonPurchasableProductError(product: Product): void;
    /**
     * Clear not purchasable product error
     */
    abstract clearNonPurchasableProductError(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuickOrderFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuickOrderFacade>;
}

declare const CART_QUICK_ORDER_FEATURE = "cartQuickOrder";
declare const CART_QUICK_ORDER_CORE_FEATURE = "cartQuickOrderCore";

declare function defaultQuickOrderComponentsConfig(): {
    featureModules: {
        cartQuickOrder: {
            cmsComponents: string[];
        };
        cartQuickOrderCore: string;
    };
};
declare const defaultQuickOrderRoutingConfig: RoutingConfig;
declare class QuickOrderRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuickOrderRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuickOrderRootModule, never, [typeof i1.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuickOrderRootModule>;
}

declare const QuickOrderOrderEntriesContextToken: InjectionToken<unknown>;

export { CART_QUICK_ORDER_CORE_FEATURE, CART_QUICK_ORDER_FEATURE, QuickOrderConfig, QuickOrderFacade, QuickOrderOrderEntriesContextToken, QuickOrderRootModule, defaultQuickOrderComponentsConfig, defaultQuickOrderConfig, defaultQuickOrderRoutingConfig, quickOrderFacadeFactory };
export type { QuickOrderAddEntryEvent };
