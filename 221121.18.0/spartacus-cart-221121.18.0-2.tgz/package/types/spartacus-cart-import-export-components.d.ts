import { OrderEntry, OrderEntriesContext, ProductImportSummary, AddOrderEntriesContext, ProductData, ProductImportInfo, OrderEntriesSource } from '@spartacus/cart/base/root';
import * as i3 from '@spartacus/storefront';
import { ExportCsvFileService, ContextService, LaunchDialogService, ICON_TYPE, FocusConfig, ImportCsvFileService, FilesFormValidators } from '@spartacus/storefront';
import { Observable, Subscription, BehaviorSubject, Subject } from 'rxjs';
import { ImportExportConfig, ExportConfig, ExportColumn, CartNameGeneration } from '@spartacus/cart/import-export/core';
import * as i4 from '@spartacus/core';
import { GlobalMessageService, TranslationService, GlobalMessageType, CxDatePipe } from '@spartacus/core';
import * as i0 from '@angular/core';
import { ElementRef, OnInit, EventEmitter } from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@angular/router';
import * as i2$1 from '@angular/forms';
import { UntypedFormGroup, AbstractControl } from '@angular/forms';

declare class ExportOrderEntriesToCsvService {
    protected exportCsvFileService: ExportCsvFileService;
    protected importExportConfig: ImportExportConfig;
    protected globalMessageService: GlobalMessageService;
    protected translationService: TranslationService;
    constructor(exportCsvFileService: ExportCsvFileService, importExportConfig: ImportExportConfig, globalMessageService: GlobalMessageService, translationService: TranslationService);
    protected get exportConfig(): ExportConfig | undefined;
    protected get separator(): string | undefined;
    protected columns: ExportColumn[];
    downloadCsv(entries: OrderEntry[]): void;
    protected resolveValue(combinedKeys: string, entry: OrderEntry): string;
    protected resolveValues(entries: OrderEntry[]): string[][];
    protected getTranslatedColumnHeaders(): Observable<string[]>;
    protected displayExportMessage(): void;
    protected limitValues(data: string[][]): string[][];
    protected getResolvedEntries(entries: OrderEntry[]): Observable<string[][]>;
    protected download(entries: string[][]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExportOrderEntriesToCsvService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ExportOrderEntriesToCsvService>;
}

declare class ExportOrderEntriesComponent {
    protected exportEntriesService: ExportOrderEntriesToCsvService;
    protected contextService: ContextService;
    styles: string;
    constructor(exportEntriesService: ExportOrderEntriesToCsvService, contextService: ContextService);
    protected orderEntriesContext$: Observable<OrderEntriesContext | undefined>;
    entries$: Observable<OrderEntry[] | undefined>;
    exportCsv(entries: OrderEntry[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExportOrderEntriesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExportOrderEntriesComponent, "cx-export-order-entries", never, {}, {}, never, never, true, never>;
}

declare class ExportOrderEntriesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ExportOrderEntriesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ExportOrderEntriesModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i4.I18nModule, typeof i4.UrlModule, typeof i4.ConfigModule, typeof ExportOrderEntriesComponent], [typeof ExportOrderEntriesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ExportOrderEntriesModule>;
}

declare class ImportOrderEntriesComponent {
    protected launchDialogService: LaunchDialogService;
    protected contextService: ContextService;
    protected subscription: Subscription;
    element: ElementRef;
    constructor(launchDialogService: LaunchDialogService, contextService: ContextService);
    orderEntriesContext$: Observable<OrderEntriesContext | undefined>;
    openDialog(orderEntriesContext: OrderEntriesContext): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImportOrderEntriesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImportOrderEntriesComponent, "cx-import-order-entries", never, {}, {}, never, never, true, never>;
}

declare class ImportEntriesDialogComponent {
    protected launchDialogService: LaunchDialogService;
    iconTypes: typeof ICON_TYPE;
    focusConfig: FocusConfig;
    formState: boolean;
    summary$: BehaviorSubject<ProductImportSummary>;
    context$: Observable<AddOrderEntriesContext>;
    constructor(launchDialogService: LaunchDialogService);
    isNewCartForm(context: AddOrderEntriesContext): boolean;
    close(reason: string): void;
    importProducts(context: AddOrderEntriesContext, { products, savedCartInfo, }: {
        products: ProductData[];
        savedCartInfo?: {
            name: string;
            description: string;
        };
    }): void;
    protected populateSummary(action: ProductImportInfo): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImportEntriesDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImportEntriesDialogComponent, "cx-import-entries-dialog", never, {}, {}, never, never, true, never>;
}

declare class ImportProductsFromCsvService {
    constructor();
    csvDataToProduct(csvData: string[][]): ProductData[];
    isDataParsableToProducts(data: string[][]): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImportProductsFromCsvService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ImportProductsFromCsvService>;
}

declare class ImportEntriesFormComponent implements OnInit {
    protected launchDialogService: LaunchDialogService;
    protected importToCartService: ImportProductsFromCsvService;
    protected importCsvService: ImportCsvFileService;
    protected filesFormValidators: FilesFormValidators;
    protected importExportConfig: ImportExportConfig;
    form: UntypedFormGroup;
    loadedFile: string[][] | null;
    formSubmitSubject$: Subject<unknown>;
    globalMessageType: typeof GlobalMessageType;
    submitEvent: EventEmitter<{
        products: ProductData[];
    }>;
    type: OrderEntriesSource;
    constructor(launchDialogService: LaunchDialogService, importToCartService: ImportProductsFromCsvService, importCsvService: ImportCsvFileService, filesFormValidators: FilesFormValidators, importExportConfig: ImportExportConfig);
    ngOnInit(): void;
    close(reason: string): void;
    save(): void;
    protected buildForm(): UntypedFormGroup;
    get allowedTypes(): string[] | undefined;
    protected get maxSize(): number | undefined;
    protected get maxEntries(): number | undefined;
    protected get separator(): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImportEntriesFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImportEntriesFormComponent, "cx-import-entries-form", never, { "type": { "alias": "type"; "required": false; }; }, { "submitEvent": "submitEvent"; }, never, never, true, never>;
}

declare class ImportToNewSavedCartFormComponent extends ImportEntriesFormComponent {
    protected launchDialogService: LaunchDialogService;
    protected importToCartService: ImportProductsFromCsvService;
    protected importCsvService: ImportCsvFileService;
    protected filesFormValidators: FilesFormValidators;
    protected importExportConfig: ImportExportConfig;
    protected datePipe: CxDatePipe;
    descriptionMaxLength: number;
    nameMaxLength: number;
    submitEvent: EventEmitter<{
        products: ProductData[];
        savedCartInfo?: {
            name: string;
            description: string;
        };
    }>;
    get descriptionsCharacterLeft(): number;
    constructor(launchDialogService: LaunchDialogService, importToCartService: ImportProductsFromCsvService, importCsvService: ImportCsvFileService, filesFormValidators: FilesFormValidators, importExportConfig: ImportExportConfig, datePipe: CxDatePipe);
    save(): void;
    protected buildForm(): UntypedFormGroup;
    updateCartName(): void;
    protected setFieldValueByFileName(nameField: AbstractControl): void;
    protected setFieldValueByDatetime(nameField: AbstractControl): void;
    protected get cartNameGeneration(): CartNameGeneration | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImportToNewSavedCartFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImportToNewSavedCartFormComponent, "cx-import-to-new-saved-cart-form", never, {}, { "submitEvent": "submitEvent"; }, never, never, true, never>;
}

declare class ImportEntriesSummaryComponent {
    iconTypes: typeof ICON_TYPE;
    orderEntriesSource: typeof OrderEntriesSource;
    warningDetailsOpened: boolean;
    errorDetailsOpened: boolean;
    type: string;
    summary: ProductImportSummary;
    closeEvent: EventEmitter<string>;
    close(reason: string): void;
    toggleWarningList(): void;
    toggleErrorList(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImportEntriesSummaryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImportEntriesSummaryComponent, "cx-import-entries-summary", never, { "type": { "alias": "type"; "required": false; }; "summary": { "alias": "summary"; "required": false; }; }, { "closeEvent": "closeEvent"; }, never, never, true, never>;
}

declare class ImportOrderEntriesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ImportOrderEntriesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ImportOrderEntriesModule, never, [typeof i1.CommonModule, typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof i3.FormErrorsModule, typeof i3.FormRequiredAsterisksComponent, typeof i3.FormRequiredLegendComponent, typeof i3.IconModule, typeof i3.KeyboardFocusModule, typeof i3.FileUploadModule, typeof i4.I18nModule, typeof i3.MessageComponentModule, typeof i4.FeaturesConfigModule, typeof i4.ConfigModule, typeof i4.FeaturesConfigModule, typeof ImportOrderEntriesComponent, typeof ImportEntriesDialogComponent, typeof ImportEntriesFormComponent, typeof ImportEntriesSummaryComponent, typeof ImportToNewSavedCartFormComponent], [typeof ImportOrderEntriesComponent, typeof ImportEntriesDialogComponent, typeof ImportEntriesFormComponent, typeof ImportEntriesSummaryComponent, typeof ImportToNewSavedCartFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ImportOrderEntriesModule>;
}

declare class ImportExportOrderEntriesComponent {
    protected contextService: ContextService;
    constructor(contextService: ContextService);
    protected context$: Observable<OrderEntriesContext | undefined>;
    shouldDisplayImport$: Observable<boolean>;
    shouldDisplayExport$: Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImportExportOrderEntriesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImportExportOrderEntriesComponent, "cx-import-export-order-entries", never, {}, {}, never, never, true, never>;
}

declare class ImportExportOrderEntriesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ImportExportOrderEntriesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ImportExportOrderEntriesModule, never, [typeof i3.PageComponentModule, typeof i4.ConfigModule, typeof i4.I18nModule, typeof i4.UrlModule, typeof ImportOrderEntriesModule, typeof ExportOrderEntriesModule, typeof i1.CommonModule, typeof ImportExportOrderEntriesComponent], [typeof ImportExportOrderEntriesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ImportExportOrderEntriesModule>;
}

export { ExportOrderEntriesComponent, ExportOrderEntriesModule, ExportOrderEntriesToCsvService, ImportEntriesDialogComponent, ImportEntriesFormComponent, ImportEntriesSummaryComponent, ImportExportOrderEntriesComponent, ImportExportOrderEntriesModule, ImportOrderEntriesComponent, ImportOrderEntriesModule, ImportProductsFromCsvService, ImportToNewSavedCartFormComponent };
