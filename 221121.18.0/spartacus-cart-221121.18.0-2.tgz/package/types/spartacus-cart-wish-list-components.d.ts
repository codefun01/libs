import * as i0 from '@angular/core';
import { OnChanges, EventEmitter, SimpleChanges } from '@angular/core';
import * as i1 from '@spartacus/storefront';
import { ProductListItemContextSource } from '@spartacus/storefront';
import * as i2 from '@angular/common';
import * as i3 from '@spartacus/core';
import * as i4 from '@angular/router';
import { Cart, OrderEntry } from '@spartacus/cart/base/root';
import { WishListFacade } from '@spartacus/cart/wish-list/root';
import { Observable } from 'rxjs';

declare class WishListComponent {
    protected wishListFacade: WishListFacade;
    wishList$: Observable<Cart>;
    loading$: Observable<boolean>;
    constructor(wishListFacade: WishListFacade);
    removeEntry(item: OrderEntry): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WishListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WishListComponent, "cx-wish-list", never, {}, {}, never, never, true, never>;
}

declare class WishListItemComponent implements OnChanges {
    protected productListItemContextSource: ProductListItemContextSource;
    isLoading: boolean;
    cartEntry: OrderEntry;
    remove: EventEmitter<OrderEntry>;
    constructor(productListItemContextSource: ProductListItemContextSource);
    ngOnChanges(changes?: SimpleChanges): void;
    removeEntry(item: OrderEntry): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WishListItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WishListItemComponent, "[cx-wish-list-item], cx-wish-list-item", never, { "isLoading": { "alias": "isLoading"; "required": false; }; "cartEntry": { "alias": "cartEntry"; "required": false; }; }, { "remove": "remove"; }, never, never, true, never>;
}

declare class WishListComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<WishListComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<WishListComponentsModule, never, [typeof i1.AtMessageModule, typeof i2.CommonModule, typeof i3.I18nModule, typeof i1.ItemCounterModule, typeof i1.MediaModule, typeof i1.PageComponentModule, typeof i4.RouterModule, typeof i1.StarRatingModule, typeof i3.UrlModule, typeof i3.FeaturesConfigModule, typeof WishListComponent, typeof WishListItemComponent], [typeof WishListComponent, typeof WishListItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<WishListComponentsModule>;
}

export { WishListComponent, WishListComponentsModule, WishListItemComponent };
