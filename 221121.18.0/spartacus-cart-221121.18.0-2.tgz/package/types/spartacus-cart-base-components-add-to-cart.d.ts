import * as i0 from '@angular/core';
import { OnInit, OnDestroy, ChangeDetectorRef, ElementRef } from '@angular/core';
import * as i2 from '@angular/forms';
import { UntypedFormGroup } from '@angular/forms';
import { ActiveCartFacade, CartItemComponentOptions, Cart, CartOutlets, CartItemQuantityService, CartUiEventAddToCart } from '@spartacus/cart/base/root';
import * as i3 from '@spartacus/core';
import { CmsAddToCartComponent, EventService, Product, ProductCatalogService } from '@spartacus/core';
import * as i4 from '@spartacus/storefront';
import { CurrentProductService, CmsComponentData, ProductListItemContext, ICON_TYPE } from '@spartacus/storefront';
import { Observable, Subscription } from 'rxjs';
import * as i1 from '@angular/common';

declare class AddToCartComponent implements OnInit, OnDestroy {
    protected currentProductService: CurrentProductService;
    protected cd: ChangeDetectorRef;
    protected activeCartService: ActiveCartFacade;
    protected component: CmsComponentData<CmsAddToCartComponent>;
    protected eventService: EventService;
    protected productListItemContext?: ProductListItemContext | undefined;
    productCode: string;
    showQuantity: boolean;
    options: CartItemComponentOptions;
    pickupStore: string | undefined;
    savedCart: Cart | undefined;
    /**
     * As long as we do not support #5026, we require product input, as we need
     *  a reference to the product model to fetch the stock data.
     */
    product: Product;
    /**
     * Element responsible for opening the modal. The reference is used to refocus the modal after it closes.
     */
    addToCartDialogTriggerEl: ElementRef;
    maxQuantity: number;
    disabled: boolean;
    hasStock: boolean;
    inventoryThreshold: boolean;
    showInventory$: Observable<boolean | undefined> | undefined;
    unavailable: boolean;
    quantity: number;
    subscription: Subscription;
    addToCartForm: UntypedFormGroup;
    readonly CartOutlets: typeof CartOutlets;
    pickupOptionCompRef: any;
    iconTypes: typeof ICON_TYPE;
    private productAvailabilityService;
    protected productCatalogService: ProductCatalogService;
    protected cartItemQuantityService: CartItemQuantityService;
    protected realTimeStockEnabled: boolean;
    /**
     * We disable the dialog launch on quantity input,
     * as it causes an unexpected change of context.
     * The expectation is only for the quantity to get updated in the Qty field.
     */
    handleKeyboardEvent(event: KeyboardEvent): void;
    constructor(currentProductService: CurrentProductService, cd: ChangeDetectorRef, activeCartService: ActiveCartFacade, component: CmsComponentData<CmsAddToCartComponent>, eventService: EventService, productListItemContext?: ProductListItemContext | undefined);
    ngOnInit(): void;
    protected subscribeToQuantityChanges(): void;
    protected setStockInfo(product: Product): void;
    /**
     * In specific scenarios, we need to omit displaying the stock level or append a plus to the value.
     * When backoffice forces a product to be in stock, omit showing the stock level.
     * When product stock level is limited by a threshold value, append '+' at the end.
     * When out of stock, display no numerical value.
     */
    getInventory(): string;
    updateCount(value: number): void;
    addToCart(): void;
    protected createCartUiEventAddToCart(productCode: string, quantity: number, numberOfEntriesBeforeAdd: number, storeName?: string): CartUiEventAddToCart;
    onPickupOptionsCompLoaded(): void;
    protected getQuantityFromSavedCart(productCode: string): number;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddToCartComponent, [null, null, null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddToCartComponent, "cx-add-to-cart", never, { "productCode": { "alias": "productCode"; "required": false; }; "showQuantity": { "alias": "showQuantity"; "required": false; }; "options": { "alias": "options"; "required": false; }; "pickupStore": { "alias": "pickupStore"; "required": false; }; "savedCart": { "alias": "savedCart"; "required": false; }; "product": { "alias": "product"; "required": false; }; }, {}, never, never, true, never>;
}

declare class AddToCartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AddToCartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AddToCartModule, never, [typeof i1.CommonModule, typeof i2.ReactiveFormsModule, typeof i3.I18nModule, typeof i4.IconModule, typeof i4.ItemCounterModule, typeof i4.OutletModule, typeof i3.FeaturesConfigModule, typeof AddToCartComponent], [typeof AddToCartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AddToCartModule>;
}

export { AddToCartComponent, AddToCartModule };
