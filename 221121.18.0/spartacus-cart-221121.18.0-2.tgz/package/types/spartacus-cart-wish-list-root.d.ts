import { Cart, OrderEntry } from '@spartacus/cart/base/root';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';

declare abstract class WishListFacade {
    abstract createWishList(userId: string, name?: string, description?: string): void;
    abstract getWishList(): Observable<Cart>;
    abstract loadWishList(userId: string, customerId: string): void;
    abstract addEntry(productCode: string): void;
    abstract removeEntry(entry: OrderEntry): void;
    abstract getWishListLoading(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<WishListFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WishListFacade>;
}

declare const CART_WISH_LIST_FEATURE = "cartWishList";
declare const CART_WISH_LIST_CORE_FEATURE = "cartWishListCore";
declare const ADD_TO_WISHLIST_FEATURE = "addToWishList";

declare function defaultCartWishListComponentsConfig(): {
    featureModules: {
        cartWishList: {
            cmsComponents: string[];
            dependencies: string[];
        };
        addToWishList: {
            cmsComponents: string[];
        };
        cartWishListCore: string;
    };
};
declare class WishListRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<WishListRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<WishListRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<WishListRootModule>;
}

export { ADD_TO_WISHLIST_FEATURE, CART_WISH_LIST_CORE_FEATURE, CART_WISH_LIST_FEATURE, WishListFacade, WishListRootModule, defaultCartWishListComponentsConfig };
