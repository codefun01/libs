import * as i0 from '@angular/core';
import { OnInit, OnDestroy, ViewContainerRef, ElementRef } from '@angular/core';
import { ActiveCartFacade, Cart, CartOutlets, CartType, PromotionLocation, AddOrderEntriesContext, GetOrderEntriesContext, MultiCartFacade, OrderEntriesSource, ProductData, ProductImportInfo, OrderEntry } from '@spartacus/cart/base/root';
import * as i2 from '@spartacus/core';
import { AuthService, RoutingService, EventService, GlobalMessageService, TranslationService, UserIdService } from '@spartacus/core';
import * as i4 from '@spartacus/storefront';
import { LaunchDialogService, ICON_TYPE, Card, SiteContextComponentService, FocusConfig, LayoutConfig } from '@spartacus/storefront';
import { Subscription, Observable } from 'rxjs';
import * as i1 from '@angular/common';
import * as i3 from '@angular/router';
import { SavedCartFacade, SavedCartFormType } from '@spartacus/cart/saved-cart/root';
import * as i5 from '@spartacus/cart/base/components/add-to-cart';
import { ProductImportInfoService } from '@spartacus/cart/base/core';
import * as i2$1 from '@angular/forms';
import { UntypedFormGroup } from '@angular/forms';

declare class AddToSavedCartComponent implements OnInit, OnDestroy {
    protected activeCartFacade: ActiveCartFacade;
    protected authService: AuthService;
    protected routingService: RoutingService;
    protected vcr: ViewContainerRef;
    protected launchDialogService: LaunchDialogService;
    protected subscription: Subscription;
    protected loggedIn: boolean;
    element: ElementRef;
    cart$: Observable<Cart>;
    /**
     * Whether to show the "Save cart for later" button. Contingent on whether there are actual entries to save.
     */
    disableSaveCartForLater$: Observable<boolean>;
    constructor(activeCartFacade: ActiveCartFacade, authService: AuthService, routingService: RoutingService, vcr: ViewContainerRef, launchDialogService: LaunchDialogService);
    ngOnInit(): void;
    saveCart(cart: Cart): void;
    openDialog(cart: Cart): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddToSavedCartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddToSavedCartComponent, "cx-add-to-saved-cart", never, {}, {}, never, never, true, never>;
}

declare class AddToSavedCartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AddToSavedCartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AddToSavedCartModule, never, [typeof i1.CommonModule, typeof i3.RouterModule, typeof i2.I18nModule, typeof i2.UrlModule, typeof i2.FeaturesConfigModule, typeof AddToSavedCartComponent], [typeof AddToSavedCartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AddToSavedCartModule>;
}

declare class SavedCartDetailsService {
    protected routingService: RoutingService;
    protected savedCartService: SavedCartFacade;
    protected savedCartId$: Observable<any>;
    protected savedCart$: Observable<Cart | undefined>;
    constructor(routingService: RoutingService, savedCartService: SavedCartFacade);
    getSavedCartId(): Observable<string>;
    getCartDetails(): Observable<Cart | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartDetailsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SavedCartDetailsService>;
}

declare class SavedCartDetailsActionComponent implements OnDestroy {
    protected savedCartDetailsService: SavedCartDetailsService;
    protected vcr: ViewContainerRef;
    protected launchDialogService: LaunchDialogService;
    private subscription;
    savedCartFormType: typeof SavedCartFormType;
    element: ElementRef;
    savedCart$: Observable<Cart | undefined>;
    constructor(savedCartDetailsService: SavedCartDetailsService, vcr: ViewContainerRef, launchDialogService: LaunchDialogService);
    openDialog(cart: Cart, type: SavedCartFormType): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartDetailsActionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SavedCartDetailsActionComponent, "cx-saved-cart-details-action", never, {}, {}, never, never, true, never>;
}

declare class SavedCartDetailsItemsComponent implements OnInit, OnDestroy {
    protected savedCartDetailsService: SavedCartDetailsService;
    protected savedCartService: SavedCartFacade;
    protected eventSercvice: EventService;
    protected globalMessageService: GlobalMessageService;
    protected routingService: RoutingService;
    protected translation: TranslationService;
    private subscription;
    readonly CartOutlets: typeof CartOutlets;
    readonly CartType: typeof CartType;
    CartLocation: typeof PromotionLocation;
    buyItAgainTranslation$: Observable<string>;
    cartLoaded$: Observable<boolean>;
    savedCart$: Observable<Cart | undefined>;
    constructor(savedCartDetailsService: SavedCartDetailsService, savedCartService: SavedCartFacade, eventSercvice: EventService, globalMessageService: GlobalMessageService, routingService: RoutingService, translation: TranslationService);
    ngOnInit(): void;
    onDeleteComplete(success: boolean): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartDetailsItemsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SavedCartDetailsItemsComponent, "cx-saved-cart-details-items", never, {}, {}, never, never, true, never>;
}

declare class SavedCartDetailsOverviewComponent implements OnDestroy {
    protected savedCartDetailsService: SavedCartDetailsService;
    protected translation: TranslationService;
    protected vcr: ViewContainerRef;
    protected launchDialogService: LaunchDialogService;
    private subscription;
    element: ElementRef;
    iconTypes: typeof ICON_TYPE;
    savedCart$: Observable<Cart | undefined>;
    constructor(savedCartDetailsService: SavedCartDetailsService, translation: TranslationService, vcr: ViewContainerRef, launchDialogService: LaunchDialogService);
    getCartName(cartName: string): Observable<Card>;
    getCartDescription(cartDescription: string): Observable<Card>;
    getCartId(cartId: string): Observable<Card>;
    getDateSaved(saveTime: string | null): Observable<Card>;
    getCartItems(totalItems: number): Observable<Card>;
    getCartQuantity(totalUnitCount: number): Observable<Card>;
    getCartTotal(totalPriceWithTax: string): Observable<Card>;
    openDialog(cart: Cart): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartDetailsOverviewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SavedCartDetailsOverviewComponent, "cx-saved-cart-details-overview", never, {}, {}, never, never, true, never>;
}

declare class SavedCartDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SavedCartDetailsModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i2.UrlModule, typeof i3.RouterModule, typeof i4.CardModule, typeof i4.MediaModule, typeof i4.IconModule, typeof i4.SpinnerModule, typeof i4.OutletModule, typeof i5.AddToCartModule, typeof i2.ConfigModule, typeof i2.FeaturesConfigModule, typeof SavedCartDetailsOverviewComponent, typeof SavedCartDetailsActionComponent, typeof SavedCartDetailsItemsComponent], [typeof SavedCartDetailsOverviewComponent, typeof SavedCartDetailsActionComponent, typeof SavedCartDetailsItemsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SavedCartDetailsModule>;
}

declare class SavedCartListComponent implements OnInit, OnDestroy {
    protected routing: RoutingService;
    protected savedCartService: SavedCartFacade;
    protected vcr: ViewContainerRef;
    protected launchDialogService: LaunchDialogService;
    private subscription;
    protected readonly siteContextService: SiteContextComponentService | null;
    restoreButton: ElementRef;
    isLoading$: Observable<boolean>;
    savedCarts$: Observable<Cart[]>;
    constructor(routing: RoutingService, savedCartService: SavedCartFacade, vcr: ViewContainerRef, launchDialogService: LaunchDialogService);
    ngOnInit(): void;
    goToSavedCartDetails(cart: Cart): void;
    openDialog(event: Event, cart: Cart): void;
    protected observeAndReloadSavedCartOnContextChange(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SavedCartListComponent, "cx-saved-cart-list", never, {}, {}, never, never, true, never>;
}

declare class SavedCartListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SavedCartListModule, never, [typeof i1.CommonModule, typeof i2.UrlModule, typeof i3.RouterModule, typeof i4.ListNavigationModule, typeof i2.I18nModule, typeof i4.SpinnerModule, typeof i2.FeaturesConfigModule, typeof SavedCartListComponent], [typeof SavedCartListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SavedCartListModule>;
}

declare class SavedCartOrderEntriesContext implements AddOrderEntriesContext, GetOrderEntriesContext {
    protected importInfoService: ProductImportInfoService;
    protected userIdService: UserIdService;
    protected multiCartService: MultiCartFacade;
    protected savedCartService: SavedCartFacade;
    protected routingService: RoutingService;
    readonly type = OrderEntriesSource.SAVED_CART;
    constructor(importInfoService: ProductImportInfoService, userIdService: UserIdService, multiCartService: MultiCartFacade, savedCartService: SavedCartFacade, routingService: RoutingService);
    protected savedCartId$: Observable<any>;
    addEntries(products: ProductData[]): Observable<ProductImportInfo>;
    getEntries(): Observable<OrderEntry[]>;
    protected add(products: ProductData[]): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartOrderEntriesContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SavedCartOrderEntriesContext>;
}

declare class NewSavedCartOrderEntriesContext implements AddOrderEntriesContext {
    protected importInfoService: ProductImportInfoService;
    protected userIdService: UserIdService;
    protected multiCartService: MultiCartFacade;
    protected savedCartService: SavedCartFacade;
    readonly type = OrderEntriesSource.NEW_SAVED_CART;
    constructor(importInfoService: ProductImportInfoService, userIdService: UserIdService, multiCartService: MultiCartFacade, savedCartService: SavedCartFacade);
    addEntries(products: ProductData[], savedCartInfo?: {
        name: string;
        description: string;
    }): Observable<ProductImportInfo>;
    protected add(products: ProductData[], savedCartInfo?: {
        name: string;
        description: string;
    }): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<NewSavedCartOrderEntriesContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NewSavedCartOrderEntriesContext>;
}

interface SavedCartFormDialogOptions {
    cart: Cart;
    layoutOption?: string;
}
declare class SavedCartFormDialogComponent implements OnInit, OnDestroy {
    protected launchDialogService: LaunchDialogService;
    protected el: ElementRef;
    protected savedCartService: SavedCartFacade;
    protected eventService: EventService;
    protected routingService: RoutingService;
    protected globalMessageService: GlobalMessageService;
    private subscription;
    savedCartFormType: typeof SavedCartFormType;
    form: UntypedFormGroup;
    iconTypes: typeof ICON_TYPE;
    cart: Cart;
    layoutOption: string | undefined;
    descriptionMaxLength: number;
    nameMaxLength: number;
    isCloneSavedCart: boolean;
    focusConfig: FocusConfig;
    isLoading$: Observable<boolean>;
    isDisableDeleteButton$: Observable<boolean>;
    isDisableRestoreButton$: Observable<boolean>;
    get descriptionsCharacterLeft(): number;
    handleClick(event: UIEvent): void;
    constructor(launchDialogService: LaunchDialogService, el: ElementRef, savedCartService: SavedCartFacade, eventService: EventService, routingService: RoutingService, globalMessageService: GlobalMessageService);
    ngOnInit(): void;
    saveOrEditCart(cartId: string): void;
    deleteCart(cartId: string): void;
    restoreSavedCart(cartId: string): void;
    close(reason: string): void;
    onComplete(success: boolean): void;
    toggleIsCloneSavedCart(): boolean;
    protected build(cart?: Cart): void;
    protected patchData(item?: any): void;
    private resetSavedCartStates;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartFormDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SavedCartFormDialogComponent, "cx-saved-cart-form-dialog", never, {}, {}, never, never, true, never>;
}

declare class SavedCartFormDialogModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartFormDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SavedCartFormDialogModule, never, [typeof i1.CommonModule, typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof i4.FormErrorsModule, typeof i2.I18nModule, typeof i4.IconModule, typeof i4.KeyboardFocusModule, typeof i2.FeaturesConfigModule, typeof i4.FormRequiredAsterisksComponent, typeof i4.FormRequiredLegendComponent, typeof SavedCartFormDialogComponent], [typeof SavedCartFormDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SavedCartFormDialogModule>;
}

declare class SavedCartComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SavedCartComponentsModule, never, [typeof i3.RouterModule, typeof AddToSavedCartModule, typeof SavedCartFormDialogModule, typeof SavedCartListModule, typeof SavedCartDetailsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SavedCartComponentsModule>;
}

declare const defaultSavedCartFormLayoutConfig: LayoutConfig;

export { AddToSavedCartComponent, AddToSavedCartModule, NewSavedCartOrderEntriesContext, SavedCartComponentsModule, SavedCartDetailsActionComponent, SavedCartDetailsItemsComponent, SavedCartDetailsModule, SavedCartDetailsOverviewComponent, SavedCartDetailsService, SavedCartFormDialogComponent, SavedCartFormDialogModule, SavedCartListComponent, SavedCartListModule, SavedCartOrderEntriesContext, defaultSavedCartFormLayoutConfig };
export type { SavedCartFormDialogOptions };
