import * as i0 from '@angular/core';
import * as i1 from '@spartacus/cart/wish-list/components';
import * as i2 from '@spartacus/cart/wish-list/core';

declare class WishListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<WishListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<WishListModule, never, [typeof i1.WishListComponentsModule, typeof i2.WishListCoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<WishListModule>;
}

/**
 * Optional NgModule that switches the Wish List feature to use the new dedicated
 * Wishlist OCC API (`/wishlists`) instead of the SavedCart-based API.
 *
 * Import this module in your application when the `wishlistV2` API is available
 * on the backend. It overrides `WishListFacade` with `WishListV2Service` and
 * registers the required connector and OCC adapter.
 *
 * When this module is NOT imported, the standard V1 SavedCart-based Wish List
 * implementation remains active and no V2 code is bundled.
 *
 * @example
 * // app.module.ts
 * imports: [WishListModule, WishListV2Module]
 */
declare class WishListV2Module {
    static ɵfac: i0.ɵɵFactoryDeclaration<WishListV2Module, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<WishListV2Module, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<WishListV2Module>;
}

declare class WishListWithV2Module {
    static ɵfac: i0.ɵɵFactoryDeclaration<WishListWithV2Module, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<WishListWithV2Module, never, [typeof WishListModule, typeof WishListV2Module], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<WishListWithV2Module>;
}

export { WishListModule, WishListV2Module, WishListWithV2Module };
