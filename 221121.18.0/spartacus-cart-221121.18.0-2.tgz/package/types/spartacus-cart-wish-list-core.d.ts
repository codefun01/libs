import { Store, Action } from '@ngrx/store';
import { StateWithMultiCart } from '@spartacus/cart/base/core';
import { MultiCartFacade, Cart, OrderEntry } from '@spartacus/cart/base/root';
import { WishListFacade } from '@spartacus/cart/wish-list/root';
import { UserIdService, StateUtils, ErrorAction } from '@spartacus/core';
import { UserAccountFacade } from '@spartacus/user/account/root';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import * as i1 from '@ngrx/effects';

declare class WishListService implements WishListFacade {
    protected store: Store<StateWithMultiCart>;
    protected userAccountFacade: UserAccountFacade;
    protected multiCartFacade: MultiCartFacade;
    protected userIdService: UserIdService;
    constructor(store: Store<StateWithMultiCart>, userAccountFacade: UserAccountFacade, multiCartFacade: MultiCartFacade, userIdService: UserIdService);
    createWishList(userId: string, name?: string, description?: string): void;
    getWishList(): Observable<Cart>;
    loadWishList(userId: string, customerId: string): void;
    addEntry(productCode: string): void;
    removeEntry(entry: OrderEntry): void;
    getWishListLoading(): Observable<boolean>;
    protected getWishListId(): Observable<string>;
    private getWishListIdWithUserId;
    static ɵfac: i0.ɵɵFactoryDeclaration<WishListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WishListService>;
}

declare class WishListV2Service implements WishListFacade {
    private userIdService;
    private connector;
    private productSearchConnector;
    private refresh$;
    private _wishlistV2$;
    private get wishlistV2$();
    private enrichWithProducts;
    createWishList(_userId: string, _name?: string, _description?: string): void;
    loadWishList(_userId: string, _customerId: string): void;
    getWishList(): Observable<Cart>;
    addEntry(productCode: string): void;
    removeEntry(entry: OrderEntry): void;
    getWishListLoading(): Observable<boolean>;
    private mapWishlistToCart;
    static ɵfac: i0.ɵɵFactoryDeclaration<WishListV2Service, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WishListV2Service>;
}

declare const CREATE_WISH_LIST = "[Wish List] Create Wish List";
declare const CREATE_WISH_LIST_FAIL = "[Wish List] Create Wish List Fail";
declare const CREATE_WISH_LIST_SUCCESS = "[Wish List] Create Wish List Success";
declare const LOAD_WISH_LIST = "[Wish List] Load Wish List";
declare const LOAD_WISH_LIST_SUCCESS = "[Wish List] Load Wish List Success";
declare const LOAD_WISH_LIST_FAIL = "[Wish List] Load Wish List Fail";
declare class CreateWishList implements Action {
    payload: {
        userId: string;
        name?: string;
        description?: string;
    };
    readonly type = "[Wish List] Create Wish List";
    constructor(payload: {
        userId: string;
        name?: string;
        description?: string;
    });
}
declare class CreateWishListSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        cart: Cart;
        cartId: string;
    };
    readonly type = "[Wish List] Create Wish List Success";
    constructor(payload: {
        cart: Cart;
        cartId: string;
    });
}
declare class CreateWishListFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        cartId: string;
        error: any;
    };
    readonly type = "[Wish List] Create Wish List Fail";
    constructor(payload: {
        cartId: string;
        error: any;
    });
}
interface LoadWishListPayload {
    userId: string;
    /**
     * This is tempCartId which is exact the wishlist name computed from customerId
     */
    cartId: string;
}
/**
 * When we try load wishlist for the first time we don't know cart id.
 * Instead we create temporary cartId from wishlist name to keep track of loading/error state.
 */
declare class LoadWishList extends StateUtils.EntityLoadAction {
    payload: LoadWishListPayload;
    readonly type = "[Wish List] Load Wish List";
    constructor(payload: LoadWishListPayload);
}
declare class LoadWishListSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        cart: Cart;
        cartId: string;
    };
    readonly type = "[Wish List] Load Wish List Success";
    constructor(payload: {
        cart: Cart;
        cartId: string;
    });
}
interface LoadWishListFailPayload {
    /**
     * Cart id used as a store entity key. This could point either to some
     * temporary cart used to track loading/error state or to normal wish list entity.
     */
    cartId: string;
    error: any;
}
declare class LoadWishListFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: LoadWishListFailPayload;
    readonly type = "[Wish List] Load Wish List Fail";
    constructor(payload: LoadWishListFailPayload);
}
type WishListActions = CreateWishList | CreateWishListSuccess | CreateWishListFail | LoadWishList | LoadWishListSuccess | LoadWishListFail;

declare const wishList_action_d_CREATE_WISH_LIST: typeof CREATE_WISH_LIST;
declare const wishList_action_d_CREATE_WISH_LIST_FAIL: typeof CREATE_WISH_LIST_FAIL;
declare const wishList_action_d_CREATE_WISH_LIST_SUCCESS: typeof CREATE_WISH_LIST_SUCCESS;
type wishList_action_d_CreateWishList = CreateWishList;
declare const wishList_action_d_CreateWishList: typeof CreateWishList;
type wishList_action_d_CreateWishListFail = CreateWishListFail;
declare const wishList_action_d_CreateWishListFail: typeof CreateWishListFail;
type wishList_action_d_CreateWishListSuccess = CreateWishListSuccess;
declare const wishList_action_d_CreateWishListSuccess: typeof CreateWishListSuccess;
declare const wishList_action_d_LOAD_WISH_LIST: typeof LOAD_WISH_LIST;
declare const wishList_action_d_LOAD_WISH_LIST_FAIL: typeof LOAD_WISH_LIST_FAIL;
declare const wishList_action_d_LOAD_WISH_LIST_SUCCESS: typeof LOAD_WISH_LIST_SUCCESS;
type wishList_action_d_LoadWishList = LoadWishList;
declare const wishList_action_d_LoadWishList: typeof LoadWishList;
type wishList_action_d_LoadWishListFail = LoadWishListFail;
declare const wishList_action_d_LoadWishListFail: typeof LoadWishListFail;
type wishList_action_d_LoadWishListSuccess = LoadWishListSuccess;
declare const wishList_action_d_LoadWishListSuccess: typeof LoadWishListSuccess;
type wishList_action_d_WishListActions = WishListActions;
declare namespace wishList_action_d {
  export { wishList_action_d_CREATE_WISH_LIST as CREATE_WISH_LIST, wishList_action_d_CREATE_WISH_LIST_FAIL as CREATE_WISH_LIST_FAIL, wishList_action_d_CREATE_WISH_LIST_SUCCESS as CREATE_WISH_LIST_SUCCESS, wishList_action_d_CreateWishList as CreateWishList, wishList_action_d_CreateWishListFail as CreateWishListFail, wishList_action_d_CreateWishListSuccess as CreateWishListSuccess, wishList_action_d_LOAD_WISH_LIST as LOAD_WISH_LIST, wishList_action_d_LOAD_WISH_LIST_FAIL as LOAD_WISH_LIST_FAIL, wishList_action_d_LOAD_WISH_LIST_SUCCESS as LOAD_WISH_LIST_SUCCESS, wishList_action_d_LoadWishList as LoadWishList, wishList_action_d_LoadWishListFail as LoadWishListFail, wishList_action_d_LoadWishListSuccess as LoadWishListSuccess };
  export type { wishList_action_d_WishListActions as WishListActions };
}

/**
 * Compute wishlist cart name for customer.
 */
declare function getWishlistName(customerId: string): string;

declare class WishListStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<WishListStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<WishListStoreModule, never, [typeof i1.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<WishListStoreModule>;
}

declare class WishListCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<WishListCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<WishListCoreModule, never, [typeof WishListStoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<WishListCoreModule>;
}

export { wishList_action_d as WishListActions, WishListCoreModule, WishListService, WishListV2Service, getWishlistName };
