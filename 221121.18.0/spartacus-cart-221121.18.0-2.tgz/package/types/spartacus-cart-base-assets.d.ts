import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    cart: {
        cartDetails: {
            id: string;
            proceedToCheckout: string;
            cartName: string;
        };
        cartItems: {
            id: string;
            description: string;
            item: string;
            itemPrice: string;
            quantity: string;
            quantityFull: string;
            quantityTitle: string;
            total: string;
            actions: string;
            cartTotal: string;
            cartTotal_other: string;
            itemRemoved: string;
            caption: string;
        };
        orderCost: {
            orderSummary: string;
            subtotal: string;
            shipping: string;
            estimatedShipping: string;
            discount: string;
            salesTax: string;
            grossTax: string;
            grossIncludeTax: string;
            total: string;
            toBeDetermined: string;
        };
        voucher: {
            coupon: string;
            coupon_other: string;
            couponLabel: string;
            addCoupon: string;
            apply: string;
            placeholder: string;
            applyVoucherSuccess: string;
            removeVoucherSuccess: string;
            anchorLabel: string;
            vouchersApplied: string;
            availableCoupons: string;
            availableCouponsLabel: string;
        };
        saveForLaterItems: {
            itemTotal: string;
            itemTotal_other: string;
            cartTitle: string;
            saveForLater: string;
            moveToCart: string;
            stock: string;
            forceInStock: string;
        };
        clearCart: {
            clearCart: string;
            clearingCart: string;
            cartClearedSuccessfully: string;
            areYouSureToClearCart: string;
            allItemsWillBeRemoved: string;
        };
        validation: {
            cartEntriesChangeDuringCheckout: string;
            cartEntryRemoved: string;
            productOutOfStock: string;
            lowStock: string;
            reviewConfiguration: string;
            configurationError: string;
            pricingError: string;
            unresolvableIssues: string;
            inProgress: string;
        };
    };
};

declare const de: {
    cart: {
        cartDetails: {
            id: string;
            proceedToCheckout: string;
            cartName: string;
        };
        cartItems: {
            id: string;
            description: string;
            item: string;
            itemPrice: string;
            quantity: string;
            quantityFull: string;
            quantityTitle: string;
            total: string;
            actions: string;
            cartTotal: string;
            cartTotal_other: string;
            itemRemoved: string;
            caption: string;
        };
        orderCost: {
            orderSummary: string;
            subtotal: string;
            shipping: string;
            estimatedShipping: string;
            discount: string;
            salesTax: string;
            grossTax: string;
            grossIncludeTax: string;
            total: string;
            toBeDetermined: string;
        };
        voucher: {
            coupon: string;
            coupon_other: string;
            couponLabel: string;
            addCoupon: string;
            apply: string;
            placeholder: string;
            applyVoucherSuccess: string;
            removeVoucherSuccess: string;
            anchorLabel: string;
            vouchersApplied: string;
            availableCoupons: string;
            availableCouponsLabel: string;
        };
        saveForLaterItems: {
            itemTotal: string;
            itemTotal_other: string;
            cartTitle: string;
            saveForLater: string;
            moveToCart: string;
            stock: string;
            forceInStock: string;
        };
        clearCart: {
            clearCart: string;
            clearingCart: string;
            cartClearedSuccessfully: string;
            areYouSureToClearCart: string;
            allItemsWillBeRemoved: string;
        };
        validation: {
            cartEntriesChangeDuringCheckout: string;
            cartEntryRemoved: string;
            productOutOfStock: string;
            lowStock: string;
            reviewConfiguration: string;
            configurationError: string;
            pricingError: string;
            unresolvableIssues: string;
            inProgress: string;
        };
    };
};

declare const en: {
    cart: {
        cartDetails: {
            id: string;
            proceedToCheckout: string;
            cartName: string;
        };
        cartItems: {
            id: string;
            description: string;
            item: string;
            itemPrice: string;
            quantity: string;
            quantityFull: string;
            quantityTitle: string;
            total: string;
            dueNow: string;
            actions: string;
            cartTotal: string;
            cartTotal_other: string;
            itemRemoved: string;
            caption: string;
        };
        orderCost: {
            orderSummary: string;
            subtotal: string;
            shipping: string;
            estimatedShipping: string;
            discount: string;
            salesTax: string;
            grossTax: string;
            grossIncludeTax: string;
            total: string;
            toBeDetermined: string;
        };
        voucher: {
            coupon: string;
            coupon_other: string;
            couponLabel: string;
            addCoupon: string;
            apply: string;
            placeholder: string;
            applyVoucherSuccess: string;
            removeVoucherSuccess: string;
            anchorLabel: string;
            vouchersApplied: string;
            availableCoupons: string;
            availableCouponsLabel: string;
        };
        saveForLaterItems: {
            itemTotal: string;
            itemTotal_other: string;
            cartTitle: string;
            saveForLater: string;
            moveToCart: string;
            stock: string;
            forceInStock: string;
        };
        clearCart: {
            clearCart: string;
            clearingCart: string;
            cartClearedSuccessfully: string;
            areYouSureToClearCart: string;
            allItemsWillBeRemoved: string;
        };
        validation: {
            cartEntriesChangeDuringCheckout: string;
            cartEntryRemoved: string;
            productOutOfStock: string;
            lowStock: string;
            reviewConfiguration: string;
            configurationError: string;
            pricingError: string;
            unresolvableIssues: string;
            inProgress: string;
        };
    };
};

declare const es: {
    cart: {
        cartDetails: {
            id: string;
            proceedToCheckout: string;
            cartName: string;
        };
        cartItems: {
            id: string;
            description: string;
            item: string;
            itemPrice: string;
            quantity: string;
            quantityFull: string;
            quantityTitle: string;
            total: string;
            actions: string;
            cartTotal: string;
            cartTotal_other: string;
            itemRemoved: string;
            caption: string;
        };
        orderCost: {
            orderSummary: string;
            subtotal: string;
            shipping: string;
            estimatedShipping: string;
            discount: string;
            salesTax: string;
            grossTax: string;
            grossIncludeTax: string;
            total: string;
            toBeDetermined: string;
        };
        voucher: {
            coupon: string;
            coupon_other: string;
            couponLabel: string;
            addCoupon: string;
            apply: string;
            placeholder: string;
            applyVoucherSuccess: string;
            removeVoucherSuccess: string;
            anchorLabel: string;
            vouchersApplied: string;
            availableCoupons: string;
            availableCouponsLabel: string;
        };
        saveForLaterItems: {
            itemTotal: string;
            itemTotal_other: string;
            cartTitle: string;
            saveForLater: string;
            moveToCart: string;
            stock: string;
            forceInStock: string;
        };
        clearCart: {
            clearCart: string;
            clearingCart: string;
            cartClearedSuccessfully: string;
            areYouSureToClearCart: string;
            allItemsWillBeRemoved: string;
        };
        validation: {
            cartEntriesChangeDuringCheckout: string;
            cartEntryRemoved: string;
            productOutOfStock: string;
            lowStock: string;
            reviewConfiguration: string;
            configurationError: string;
            pricingError: string;
            unresolvableIssues: string;
            inProgress: string;
        };
    };
};

declare const es_CO: {
    cart: {
        cartDetails: {
            id: string;
            proceedToCheckout: string;
            cartName: string;
        };
        cartItems: {
            id: string;
            description: string;
            item: string;
            itemPrice: string;
            quantity: string;
            quantityFull: string;
            quantityTitle: string;
            total: string;
            actions: string;
            cartTotal: string;
            cartTotal_other: string;
            itemRemoved: string;
            caption: string;
        };
        orderCost: {
            orderSummary: string;
            subtotal: string;
            shipping: string;
            estimatedShipping: string;
            discount: string;
            salesTax: string;
            grossTax: string;
            grossIncludeTax: string;
            total: string;
            toBeDetermined: string;
        };
        voucher: {
            coupon: string;
            coupon_other: string;
            couponLabel: string;
            addCoupon: string;
            apply: string;
            placeholder: string;
            applyVoucherSuccess: string;
            removeVoucherSuccess: string;
            anchorLabel: string;
            vouchersApplied: string;
            availableCoupons: string;
            availableCouponsLabel: string;
        };
        saveForLaterItems: {
            itemTotal: string;
            itemTotal_other: string;
            cartTitle: string;
            saveForLater: string;
            moveToCart: string;
            stock: string;
            forceInStock: string;
        };
        clearCart: {
            clearCart: string;
            clearingCart: string;
            cartClearedSuccessfully: string;
            areYouSureToClearCart: string;
            allItemsWillBeRemoved: string;
        };
        validation: {
            cartEntriesChangeDuringCheckout: string;
            cartEntryRemoved: string;
            productOutOfStock: string;
            lowStock: string;
            reviewConfiguration: string;
            configurationError: string;
            pricingError: string;
            unresolvableIssues: string;
            inProgress: string;
        };
    };
};

declare const fr: {
    cart: {
        cartDetails: {
            id: string;
            proceedToCheckout: string;
            cartName: string;
        };
        cartItems: {
            id: string;
            description: string;
            item: string;
            itemPrice: string;
            quantity: string;
            quantityFull: string;
            quantityTitle: string;
            total: string;
            actions: string;
            cartTotal: string;
            cartTotal_other: string;
            itemRemoved: string;
            caption: string;
        };
        orderCost: {
            orderSummary: string;
            subtotal: string;
            shipping: string;
            estimatedShipping: string;
            discount: string;
            salesTax: string;
            grossTax: string;
            grossIncludeTax: string;
            total: string;
            toBeDetermined: string;
        };
        voucher: {
            coupon: string;
            coupon_other: string;
            couponLabel: string;
            addCoupon: string;
            apply: string;
            placeholder: string;
            applyVoucherSuccess: string;
            removeVoucherSuccess: string;
            anchorLabel: string;
            vouchersApplied: string;
            availableCoupons: string;
            availableCouponsLabel: string;
        };
        saveForLaterItems: {
            itemTotal: string;
            itemTotal_other: string;
            cartTitle: string;
            saveForLater: string;
            moveToCart: string;
            stock: string;
            forceInStock: string;
        };
        clearCart: {
            clearCart: string;
            clearingCart: string;
            cartClearedSuccessfully: string;
            areYouSureToClearCart: string;
            allItemsWillBeRemoved: string;
        };
        validation: {
            cartEntriesChangeDuringCheckout: string;
            cartEntryRemoved: string;
            productOutOfStock: string;
            lowStock: string;
            reviewConfiguration: string;
            configurationError: string;
            pricingError: string;
            unresolvableIssues: string;
            inProgress: string;
        };
    };
};

declare const hi: {
    cart: {
        cartDetails: {
            id: string;
            proceedToCheckout: string;
            cartName: string;
        };
        cartItems: {
            id: string;
            description: string;
            item: string;
            itemPrice: string;
            quantity: string;
            quantityFull: string;
            quantityTitle: string;
            total: string;
            actions: string;
            cartTotal: string;
            cartTotal_other: string;
            itemRemoved: string;
            caption: string;
        };
        orderCost: {
            orderSummary: string;
            subtotal: string;
            shipping: string;
            estimatedShipping: string;
            discount: string;
            salesTax: string;
            grossTax: string;
            grossIncludeTax: string;
            total: string;
            toBeDetermined: string;
        };
        voucher: {
            coupon: string;
            coupon_other: string;
            couponLabel: string;
            addCoupon: string;
            apply: string;
            placeholder: string;
            applyVoucherSuccess: string;
            removeVoucherSuccess: string;
            anchorLabel: string;
            vouchersApplied: string;
            availableCoupons: string;
            availableCouponsLabel: string;
        };
        saveForLaterItems: {
            itemTotal: string;
            itemTotal_other: string;
            cartTitle: string;
            saveForLater: string;
            moveToCart: string;
            stock: string;
            forceInStock: string;
        };
        clearCart: {
            clearCart: string;
            clearingCart: string;
            cartClearedSuccessfully: string;
            areYouSureToClearCart: string;
            allItemsWillBeRemoved: string;
        };
        validation: {
            cartEntriesChangeDuringCheckout: string;
            cartEntryRemoved: string;
            productOutOfStock: string;
            lowStock: string;
            reviewConfiguration: string;
            configurationError: string;
            pricingError: string;
            unresolvableIssues: string;
            inProgress: string;
        };
    };
};

declare const hu: {
    cart: {
        cartDetails: {
            id: string;
            proceedToCheckout: string;
            cartName: string;
        };
        cartItems: {
            id: string;
            description: string;
            item: string;
            itemPrice: string;
            quantity: string;
            quantityFull: string;
            quantityTitle: string;
            total: string;
            actions: string;
            cartTotal: string;
            cartTotal_other: string;
            itemRemoved: string;
            caption: string;
        };
        orderCost: {
            orderSummary: string;
            subtotal: string;
            shipping: string;
            estimatedShipping: string;
            discount: string;
            salesTax: string;
            grossTax: string;
            grossIncludeTax: string;
            total: string;
            toBeDetermined: string;
        };
        voucher: {
            coupon: string;
            coupon_other: string;
            couponLabel: string;
            addCoupon: string;
            apply: string;
            placeholder: string;
            applyVoucherSuccess: string;
            removeVoucherSuccess: string;
            anchorLabel: string;
            vouchersApplied: string;
            availableCoupons: string;
            availableCouponsLabel: string;
        };
        saveForLaterItems: {
            itemTotal: string;
            itemTotal_other: string;
            cartTitle: string;
            saveForLater: string;
            moveToCart: string;
            stock: string;
            forceInStock: string;
        };
        clearCart: {
            clearCart: string;
            clearingCart: string;
            cartClearedSuccessfully: string;
            areYouSureToClearCart: string;
            allItemsWillBeRemoved: string;
        };
        validation: {
            cartEntriesChangeDuringCheckout: string;
            cartEntryRemoved: string;
            productOutOfStock: string;
            lowStock: string;
            reviewConfiguration: string;
            configurationError: string;
            pricingError: string;
            unresolvableIssues: string;
            inProgress: string;
        };
    };
};

declare const id: {
    cart: {
        cartDetails: {
            id: string;
            proceedToCheckout: string;
            cartName: string;
        };
        cartItems: {
            id: string;
            description: string;
            item: string;
            itemPrice: string;
            quantity: string;
            quantityFull: string;
            quantityTitle: string;
            total: string;
            actions: string;
            cartTotal: string;
            cartTotal_other: string;
            itemRemoved: string;
            caption: string;
        };
        orderCost: {
            orderSummary: string;
            subtotal: string;
            shipping: string;
            estimatedShipping: string;
            discount: string;
            salesTax: string;
            grossTax: string;
            grossIncludeTax: string;
            total: string;
            toBeDetermined: string;
        };
        voucher: {
            coupon: string;
            coupon_other: string;
            couponLabel: string;
            addCoupon: string;
            apply: string;
            placeholder: string;
            applyVoucherSuccess: string;
            removeVoucherSuccess: string;
            anchorLabel: string;
            vouchersApplied: string;
            availableCoupons: string;
            availableCouponsLabel: string;
        };
        saveForLaterItems: {
            itemTotal: string;
            itemTotal_other: string;
            cartTitle: string;
            saveForLater: string;
            moveToCart: string;
            stock: string;
            forceInStock: string;
        };
        clearCart: {
            clearCart: string;
            clearingCart: string;
            cartClearedSuccessfully: string;
            areYouSureToClearCart: string;
            allItemsWillBeRemoved: string;
        };
        validation: {
            cartEntriesChangeDuringCheckout: string;
            cartEntryRemoved: string;
            productOutOfStock: string;
            lowStock: string;
            reviewConfiguration: string;
            configurationError: string;
            pricingError: string;
            unresolvableIssues: string;
            inProgress: string;
        };
    };
};

declare const it: {
    cart: {
        cartDetails: {
            id: string;
            proceedToCheckout: string;
            cartName: string;
        };
        cartItems: {
            id: string;
            description: string;
            item: string;
            itemPrice: string;
            quantity: string;
            quantityFull: string;
            quantityTitle: string;
            total: string;
            actions: string;
            cartTotal: string;
            cartTotal_other: string;
            itemRemoved: string;
            caption: string;
        };
        orderCost: {
            orderSummary: string;
            subtotal: string;
            shipping: string;
            estimatedShipping: string;
            discount: string;
            salesTax: string;
            grossTax: string;
            grossIncludeTax: string;
            total: string;
            toBeDetermined: string;
        };
        voucher: {
            coupon: string;
            coupon_other: string;
            couponLabel: string;
            addCoupon: string;
            apply: string;
            placeholder: string;
            applyVoucherSuccess: string;
            removeVoucherSuccess: string;
            anchorLabel: string;
            vouchersApplied: string;
            availableCoupons: string;
            availableCouponsLabel: string;
        };
        saveForLaterItems: {
            itemTotal: string;
            itemTotal_other: string;
            cartTitle: string;
            saveForLater: string;
            moveToCart: string;
            stock: string;
            forceInStock: string;
        };
        clearCart: {
            clearCart: string;
            clearingCart: string;
            cartClearedSuccessfully: string;
            areYouSureToClearCart: string;
            allItemsWillBeRemoved: string;
        };
        validation: {
            cartEntriesChangeDuringCheckout: string;
            cartEntryRemoved: string;
            productOutOfStock: string;
            lowStock: string;
            reviewConfiguration: string;
            configurationError: string;
            pricingError: string;
            unresolvableIssues: string;
            inProgress: string;
        };
    };
};

declare const ja: {
    cart: {
        cartDetails: {
            id: string;
            proceedToCheckout: string;
            cartName: string;
        };
        cartItems: {
            id: string;
            description: string;
            item: string;
            itemPrice: string;
            quantity: string;
            quantityFull: string;
            quantityTitle: string;
            total: string;
            actions: string;
            cartTotal: string;
            cartTotal_other: string;
            itemRemoved: string;
            caption: string;
        };
        orderCost: {
            orderSummary: string;
            subtotal: string;
            shipping: string;
            estimatedShipping: string;
            discount: string;
            salesTax: string;
            grossTax: string;
            grossIncludeTax: string;
            total: string;
            toBeDetermined: string;
        };
        voucher: {
            coupon: string;
            coupon_other: string;
            couponLabel: string;
            addCoupon: string;
            apply: string;
            placeholder: string;
            applyVoucherSuccess: string;
            removeVoucherSuccess: string;
            anchorLabel: string;
            vouchersApplied: string;
            availableCoupons: string;
            availableCouponsLabel: string;
        };
        saveForLaterItems: {
            itemTotal: string;
            itemTotal_other: string;
            cartTitle: string;
            saveForLater: string;
            moveToCart: string;
            stock: string;
            forceInStock: string;
        };
        clearCart: {
            clearCart: string;
            clearingCart: string;
            cartClearedSuccessfully: string;
            areYouSureToClearCart: string;
            allItemsWillBeRemoved: string;
        };
        validation: {
            cartEntriesChangeDuringCheckout: string;
            cartEntryRemoved: string;
            productOutOfStock: string;
            lowStock: string;
            reviewConfiguration: string;
            configurationError: string;
            pricingError: string;
            unresolvableIssues: string;
            inProgress: string;
        };
    };
};

declare const ko: {
    cart: {
        cartDetails: {
            id: string;
            proceedToCheckout: string;
            cartName: string;
        };
        cartItems: {
            id: string;
            description: string;
            item: string;
            itemPrice: string;
            quantity: string;
            quantityFull: string;
            quantityTitle: string;
            total: string;
            actions: string;
            cartTotal: string;
            cartTotal_other: string;
            itemRemoved: string;
            caption: string;
        };
        orderCost: {
            orderSummary: string;
            subtotal: string;
            shipping: string;
            estimatedShipping: string;
            discount: string;
            salesTax: string;
            grossTax: string;
            grossIncludeTax: string;
            total: string;
            toBeDetermined: string;
        };
        voucher: {
            coupon: string;
            coupon_other: string;
            couponLabel: string;
            addCoupon: string;
            apply: string;
            placeholder: string;
            applyVoucherSuccess: string;
            removeVoucherSuccess: string;
            anchorLabel: string;
            vouchersApplied: string;
            availableCoupons: string;
            availableCouponsLabel: string;
        };
        saveForLaterItems: {
            itemTotal: string;
            itemTotal_other: string;
            cartTitle: string;
            saveForLater: string;
            moveToCart: string;
            stock: string;
            forceInStock: string;
        };
        clearCart: {
            clearCart: string;
            clearingCart: string;
            cartClearedSuccessfully: string;
            areYouSureToClearCart: string;
            allItemsWillBeRemoved: string;
        };
        validation: {
            cartEntriesChangeDuringCheckout: string;
            cartEntryRemoved: string;
            productOutOfStock: string;
            lowStock: string;
            reviewConfiguration: string;
            configurationError: string;
            pricingError: string;
            unresolvableIssues: string;
            inProgress: string;
        };
    };
};

declare const pl: {
    cart: {
        cartDetails: {
            id: string;
            proceedToCheckout: string;
            cartName: string;
        };
        cartItems: {
            id: string;
            description: string;
            item: string;
            itemPrice: string;
            quantity: string;
            quantityFull: string;
            quantityTitle: string;
            total: string;
            actions: string;
            cartTotal: string;
            cartTotal_other: string;
            itemRemoved: string;
            caption: string;
        };
        orderCost: {
            orderSummary: string;
            subtotal: string;
            shipping: string;
            estimatedShipping: string;
            discount: string;
            salesTax: string;
            grossTax: string;
            grossIncludeTax: string;
            total: string;
            toBeDetermined: string;
        };
        voucher: {
            coupon: string;
            coupon_other: string;
            couponLabel: string;
            addCoupon: string;
            apply: string;
            placeholder: string;
            applyVoucherSuccess: string;
            removeVoucherSuccess: string;
            anchorLabel: string;
            vouchersApplied: string;
            availableCoupons: string;
            availableCouponsLabel: string;
        };
        saveForLaterItems: {
            itemTotal: string;
            itemTotal_other: string;
            cartTitle: string;
            saveForLater: string;
            moveToCart: string;
            stock: string;
            forceInStock: string;
        };
        clearCart: {
            clearCart: string;
            clearingCart: string;
            cartClearedSuccessfully: string;
            areYouSureToClearCart: string;
            allItemsWillBeRemoved: string;
        };
        validation: {
            cartEntriesChangeDuringCheckout: string;
            cartEntryRemoved: string;
            productOutOfStock: string;
            lowStock: string;
            reviewConfiguration: string;
            configurationError: string;
            pricingError: string;
            unresolvableIssues: string;
            inProgress: string;
        };
    };
};

declare const pt: {
    cart: {
        cartDetails: {
            id: string;
            proceedToCheckout: string;
            cartName: string;
        };
        cartItems: {
            id: string;
            description: string;
            item: string;
            itemPrice: string;
            quantity: string;
            quantityFull: string;
            quantityTitle: string;
            total: string;
            actions: string;
            cartTotal: string;
            cartTotal_other: string;
            itemRemoved: string;
            caption: string;
        };
        orderCost: {
            orderSummary: string;
            subtotal: string;
            shipping: string;
            estimatedShipping: string;
            discount: string;
            salesTax: string;
            grossTax: string;
            grossIncludeTax: string;
            total: string;
            toBeDetermined: string;
        };
        voucher: {
            coupon: string;
            coupon_other: string;
            couponLabel: string;
            addCoupon: string;
            apply: string;
            placeholder: string;
            applyVoucherSuccess: string;
            removeVoucherSuccess: string;
            anchorLabel: string;
            vouchersApplied: string;
            availableCoupons: string;
            availableCouponsLabel: string;
        };
        saveForLaterItems: {
            itemTotal: string;
            itemTotal_other: string;
            cartTitle: string;
            saveForLater: string;
            moveToCart: string;
            stock: string;
            forceInStock: string;
        };
        clearCart: {
            clearCart: string;
            clearingCart: string;
            cartClearedSuccessfully: string;
            areYouSureToClearCart: string;
            allItemsWillBeRemoved: string;
        };
        validation: {
            cartEntriesChangeDuringCheckout: string;
            cartEntryRemoved: string;
            productOutOfStock: string;
            lowStock: string;
            reviewConfiguration: string;
            configurationError: string;
            pricingError: string;
            unresolvableIssues: string;
            inProgress: string;
        };
    };
};

declare const ru: {
    cart: {
        cartDetails: {
            id: string;
            proceedToCheckout: string;
            cartName: string;
        };
        cartItems: {
            id: string;
            description: string;
            item: string;
            itemPrice: string;
            quantity: string;
            quantityFull: string;
            quantityTitle: string;
            total: string;
            actions: string;
            cartTotal: string;
            cartTotal_other: string;
            itemRemoved: string;
            caption: string;
        };
        orderCost: {
            orderSummary: string;
            subtotal: string;
            shipping: string;
            estimatedShipping: string;
            discount: string;
            salesTax: string;
            grossTax: string;
            grossIncludeTax: string;
            total: string;
            toBeDetermined: string;
        };
        voucher: {
            coupon: string;
            coupon_other: string;
            couponLabel: string;
            addCoupon: string;
            apply: string;
            placeholder: string;
            applyVoucherSuccess: string;
            removeVoucherSuccess: string;
            anchorLabel: string;
            vouchersApplied: string;
            availableCoupons: string;
            availableCouponsLabel: string;
        };
        saveForLaterItems: {
            itemTotal: string;
            itemTotal_other: string;
            cartTitle: string;
            saveForLater: string;
            moveToCart: string;
            stock: string;
            forceInStock: string;
        };
        clearCart: {
            clearCart: string;
            clearingCart: string;
            cartClearedSuccessfully: string;
            areYouSureToClearCart: string;
            allItemsWillBeRemoved: string;
        };
        validation: {
            cartEntriesChangeDuringCheckout: string;
            cartEntryRemoved: string;
            productOutOfStock: string;
            lowStock: string;
            reviewConfiguration: string;
            configurationError: string;
            pricingError: string;
            unresolvableIssues: string;
            inProgress: string;
        };
    };
};

declare const zh: {
    cart: {
        cartDetails: {
            id: string;
            proceedToCheckout: string;
            cartName: string;
        };
        cartItems: {
            id: string;
            description: string;
            item: string;
            itemPrice: string;
            quantity: string;
            quantityFull: string;
            quantityTitle: string;
            total: string;
            actions: string;
            cartTotal: string;
            cartTotal_other: string;
            itemRemoved: string;
            caption: string;
        };
        orderCost: {
            orderSummary: string;
            subtotal: string;
            shipping: string;
            estimatedShipping: string;
            discount: string;
            salesTax: string;
            grossTax: string;
            grossIncludeTax: string;
            total: string;
            toBeDetermined: string;
        };
        voucher: {
            coupon: string;
            coupon_other: string;
            couponLabel: string;
            addCoupon: string;
            apply: string;
            placeholder: string;
            applyVoucherSuccess: string;
            removeVoucherSuccess: string;
            anchorLabel: string;
            vouchersApplied: string;
            availableCoupons: string;
            availableCouponsLabel: string;
        };
        saveForLaterItems: {
            itemTotal: string;
            itemTotal_other: string;
            cartTitle: string;
            saveForLater: string;
            moveToCart: string;
            stock: string;
            forceInStock: string;
        };
        clearCart: {
            clearCart: string;
            clearingCart: string;
            cartClearedSuccessfully: string;
            areYouSureToClearCart: string;
            allItemsWillBeRemoved: string;
        };
        validation: {
            cartEntriesChangeDuringCheckout: string;
            cartEntryRemoved: string;
            productOutOfStock: string;
            lowStock: string;
            reviewConfiguration: string;
            configurationError: string;
            pricingError: string;
            unresolvableIssues: string;
            inProgress: string;
        };
    };
};

declare const zh_TW: {
    cart: {
        cartDetails: {
            id: string;
            proceedToCheckout: string;
            cartName: string;
        };
        cartItems: {
            id: string;
            description: string;
            item: string;
            itemPrice: string;
            quantity: string;
            quantityFull: string;
            quantityTitle: string;
            total: string;
            actions: string;
            cartTotal: string;
            cartTotal_other: string;
            itemRemoved: string;
            caption: string;
        };
        orderCost: {
            orderSummary: string;
            subtotal: string;
            shipping: string;
            estimatedShipping: string;
            discount: string;
            salesTax: string;
            grossTax: string;
            grossIncludeTax: string;
            total: string;
            toBeDetermined: string;
        };
        voucher: {
            coupon: string;
            coupon_other: string;
            couponLabel: string;
            addCoupon: string;
            apply: string;
            placeholder: string;
            applyVoucherSuccess: string;
            removeVoucherSuccess: string;
            anchorLabel: string;
            vouchersApplied: string;
            availableCoupons: string;
            availableCouponsLabel: string;
        };
        saveForLaterItems: {
            itemTotal: string;
            itemTotal_other: string;
            cartTitle: string;
            saveForLater: string;
            moveToCart: string;
            stock: string;
            forceInStock: string;
        };
        clearCart: {
            clearCart: string;
            clearingCart: string;
            cartClearedSuccessfully: string;
            areYouSureToClearCart: string;
            allItemsWillBeRemoved: string;
        };
        validation: {
            cartEntriesChangeDuringCheckout: string;
            cartEntryRemoved: string;
            productOutOfStock: string;
            lowStock: string;
            reviewConfiguration: string;
            configurationError: string;
            pricingError: string;
            unresolvableIssues: string;
            inProgress: string;
        };
    };
};

declare const cartBaseTranslationChunksConfig: TranslationChunksConfig;

export { cartBaseTranslationChunksConfig, cs as cartBaseTranslationsCs, de as cartBaseTranslationsDe, en as cartBaseTranslationsEn, es as cartBaseTranslationsEs, es_CO as cartBaseTranslationsEs_CO, fr as cartBaseTranslationsFr, hi as cartBaseTranslationsHi, hu as cartBaseTranslationsHu, id as cartBaseTranslationsId, it as cartBaseTranslationsIt, ja as cartBaseTranslationsJa, ko as cartBaseTranslationsKo, pl as cartBaseTranslationsPl, pt as cartBaseTranslationsPt, ru as cartBaseTranslationsRu, zh as cartBaseTranslationsZh, zh_TW as cartBaseTranslationsZh_TW };
