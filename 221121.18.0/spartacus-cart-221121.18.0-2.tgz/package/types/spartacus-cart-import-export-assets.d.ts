import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    importExport: {
        exportEntries: {
            exportToCsv: string;
            exportMessage: string;
            columnNames: {
                code: string;
                quantity: string;
                name: string;
                price: string;
            };
            exportProductToCsv: string;
        };
        importEntries: {
            importProducts: string;
        };
        importEntriesDialog: {
            importProducts: string;
            importProductsSubtitle: string;
            importProductsNewSavedCartSubtitle: string;
            importProductFileDetails: string;
            selectFile: string;
            selectedSuccessfully: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            upload: string;
            close: string;
            summary: {
                info: string;
                loadedToCart: string;
                loaded: string;
                loading: string;
                successes: string;
                warning: string;
                warning_other: string;
                error: string;
                error_other: string;
                messages: {
                    unknownIdentifier: string;
                    lowStock: string;
                    noStock: string;
                    unknownError: string;
                    limitExceeded: string;
                };
                show: string;
                hide: string;
            };
        };
    };
};

declare const de: {
    importExport: {
        exportEntries: {
            exportToCsv: string;
            exportMessage: string;
            columnNames: {
                code: string;
                quantity: string;
                name: string;
                price: string;
            };
            exportProductToCsv: string;
        };
        importEntries: {
            importProducts: string;
        };
        importEntriesDialog: {
            importProducts: string;
            importProductsSubtitle: string;
            importProductsNewSavedCartSubtitle: string;
            importProductFileDetails: string;
            selectFile: string;
            selectedSuccessfully: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            upload: string;
            close: string;
            summary: {
                info: string;
                loadedToCart: string;
                loaded: string;
                loading: string;
                successes: string;
                warning: string;
                warning_other: string;
                error: string;
                error_other: string;
                messages: {
                    unknownIdentifier: string;
                    lowStock: string;
                    noStock: string;
                    unknownError: string;
                    limitExceeded: string;
                };
                show: string;
                hide: string;
            };
        };
    };
};

declare const en: {
    importExport: {
        exportEntries: {
            exportToCsv: string;
            exportMessage: string;
            columnNames: {
                code: string;
                quantity: string;
                name: string;
                price: string;
            };
            exportProductToCsv: string;
        };
        importEntries: {
            importProducts: string;
        };
        importEntriesDialog: {
            importProducts: string;
            importProductsSubtitle: string;
            importProductsNewSavedCartSubtitle: string;
            importProductFileDetails: string;
            selectFile: string;
            selectedSuccessfully: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            upload: string;
            close: string;
            summary: {
                info: string;
                loadedToCart: string;
                loaded: string;
                loading: string;
                successes: string;
                warning: string;
                warning_other: string;
                error: string;
                error_other: string;
                messages: {
                    unknownIdentifier: string;
                    lowStock: string;
                    noStock: string;
                    unknownError: string;
                    limitExceeded: string;
                };
                show: string;
                hide: string;
            };
        };
    };
};

declare const es: {
    importExport: {
        exportEntries: {
            exportToCsv: string;
            exportMessage: string;
            columnNames: {
                code: string;
                quantity: string;
                name: string;
                price: string;
            };
            exportProductToCsv: string;
        };
        importEntries: {
            importProducts: string;
        };
        importEntriesDialog: {
            importProducts: string;
            importProductsSubtitle: string;
            importProductsNewSavedCartSubtitle: string;
            importProductFileDetails: string;
            selectFile: string;
            selectedSuccessfully: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            upload: string;
            close: string;
            summary: {
                info: string;
                loadedToCart: string;
                loaded: string;
                loading: string;
                successes: string;
                warning: string;
                warning_other: string;
                error: string;
                error_other: string;
                messages: {
                    unknownIdentifier: string;
                    lowStock: string;
                    noStock: string;
                    unknownError: string;
                    limitExceeded: string;
                };
                show: string;
                hide: string;
            };
        };
    };
};

declare const es_CO: {
    importExport: {
        exportEntries: {
            exportToCsv: string;
            exportMessage: string;
            columnNames: {
                code: string;
                quantity: string;
                name: string;
                price: string;
            };
            exportProductToCsv: string;
        };
        importEntries: {
            importProducts: string;
        };
        importEntriesDialog: {
            importProducts: string;
            importProductsSubtitle: string;
            importProductsNewSavedCartSubtitle: string;
            importProductFileDetails: string;
            selectFile: string;
            selectedSuccessfully: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            upload: string;
            close: string;
            summary: {
                info: string;
                loadedToCart: string;
                loaded: string;
                loading: string;
                successes: string;
                warning: string;
                warning_other: string;
                error: string;
                error_other: string;
                messages: {
                    unknownIdentifier: string;
                    lowStock: string;
                    noStock: string;
                    unknownError: string;
                    limitExceeded: string;
                };
                show: string;
                hide: string;
            };
        };
    };
};

declare const fr: {
    importExport: {
        exportEntries: {
            exportToCsv: string;
            exportMessage: string;
            columnNames: {
                code: string;
                quantity: string;
                name: string;
                price: string;
            };
            exportProductToCsv: string;
        };
        importEntries: {
            importProducts: string;
        };
        importEntriesDialog: {
            importProducts: string;
            importProductsSubtitle: string;
            importProductsNewSavedCartSubtitle: string;
            importProductFileDetails: string;
            selectFile: string;
            selectedSuccessfully: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            upload: string;
            close: string;
            summary: {
                info: string;
                loadedToCart: string;
                loaded: string;
                loading: string;
                successes: string;
                warning: string;
                warning_other: string;
                error: string;
                error_other: string;
                messages: {
                    unknownIdentifier: string;
                    lowStock: string;
                    noStock: string;
                    unknownError: string;
                    limitExceeded: string;
                };
                show: string;
                hide: string;
            };
        };
    };
};

declare const hi: {
    importExport: {
        exportEntries: {
            exportToCsv: string;
            exportMessage: string;
            columnNames: {
                code: string;
                quantity: string;
                name: string;
                price: string;
            };
            exportProductToCsv: string;
        };
        importEntries: {
            importProducts: string;
        };
        importEntriesDialog: {
            importProducts: string;
            importProductsSubtitle: string;
            importProductsNewSavedCartSubtitle: string;
            importProductFileDetails: string;
            selectFile: string;
            selectedSuccessfully: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            upload: string;
            close: string;
            summary: {
                info: string;
                loadedToCart: string;
                loaded: string;
                loading: string;
                successes: string;
                warning: string;
                warning_other: string;
                error: string;
                error_other: string;
                messages: {
                    unknownIdentifier: string;
                    lowStock: string;
                    noStock: string;
                    unknownError: string;
                    limitExceeded: string;
                };
                show: string;
                hide: string;
            };
        };
    };
};

declare const hu: {
    importExport: {
        exportEntries: {
            exportToCsv: string;
            exportMessage: string;
            columnNames: {
                code: string;
                quantity: string;
                name: string;
                price: string;
            };
            exportProductToCsv: string;
        };
        importEntries: {
            importProducts: string;
        };
        importEntriesDialog: {
            importProducts: string;
            importProductsSubtitle: string;
            importProductsNewSavedCartSubtitle: string;
            importProductFileDetails: string;
            selectFile: string;
            selectedSuccessfully: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            upload: string;
            close: string;
            summary: {
                info: string;
                loadedToCart: string;
                loaded: string;
                loading: string;
                successes: string;
                warning: string;
                warning_other: string;
                error: string;
                error_other: string;
                messages: {
                    unknownIdentifier: string;
                    lowStock: string;
                    noStock: string;
                    unknownError: string;
                    limitExceeded: string;
                };
                show: string;
                hide: string;
            };
        };
    };
};

declare const id: {
    importExport: {
        exportEntries: {
            exportToCsv: string;
            exportMessage: string;
            columnNames: {
                code: string;
                quantity: string;
                name: string;
                price: string;
            };
            exportProductToCsv: string;
        };
        importEntries: {
            importProducts: string;
        };
        importEntriesDialog: {
            importProducts: string;
            importProductsSubtitle: string;
            importProductsNewSavedCartSubtitle: string;
            importProductFileDetails: string;
            selectFile: string;
            selectedSuccessfully: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            upload: string;
            close: string;
            summary: {
                info: string;
                loadedToCart: string;
                loaded: string;
                loading: string;
                successes: string;
                warning: string;
                warning_other: string;
                error: string;
                error_other: string;
                messages: {
                    unknownIdentifier: string;
                    lowStock: string;
                    noStock: string;
                    unknownError: string;
                    limitExceeded: string;
                };
                show: string;
                hide: string;
            };
        };
    };
};

declare const it: {
    importExport: {
        exportEntries: {
            exportToCsv: string;
            exportMessage: string;
            columnNames: {
                code: string;
                quantity: string;
                name: string;
                price: string;
            };
            exportProductToCsv: string;
        };
        importEntries: {
            importProducts: string;
        };
        importEntriesDialog: {
            importProducts: string;
            importProductsSubtitle: string;
            importProductsNewSavedCartSubtitle: string;
            importProductFileDetails: string;
            selectFile: string;
            selectedSuccessfully: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            upload: string;
            close: string;
            summary: {
                info: string;
                loadedToCart: string;
                loaded: string;
                loading: string;
                successes: string;
                warning: string;
                warning_other: string;
                error: string;
                error_other: string;
                messages: {
                    unknownIdentifier: string;
                    lowStock: string;
                    noStock: string;
                    unknownError: string;
                    limitExceeded: string;
                };
                show: string;
                hide: string;
            };
        };
    };
};

declare const ja: {
    importExport: {
        exportEntries: {
            exportToCsv: string;
            exportMessage: string;
            columnNames: {
                code: string;
                quantity: string;
                name: string;
                price: string;
            };
            exportProductToCsv: string;
        };
        importEntries: {
            importProducts: string;
        };
        importEntriesDialog: {
            importProducts: string;
            importProductsSubtitle: string;
            importProductsNewSavedCartSubtitle: string;
            importProductFileDetails: string;
            selectFile: string;
            selectedSuccessfully: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            upload: string;
            close: string;
            summary: {
                info: string;
                loadedToCart: string;
                loaded: string;
                loading: string;
                successes: string;
                warning: string;
                warning_other: string;
                error: string;
                error_other: string;
                messages: {
                    unknownIdentifier: string;
                    lowStock: string;
                    noStock: string;
                    unknownError: string;
                    limitExceeded: string;
                };
                show: string;
                hide: string;
            };
        };
    };
};

declare const ko: {
    importExport: {
        exportEntries: {
            exportToCsv: string;
            exportMessage: string;
            columnNames: {
                code: string;
                quantity: string;
                name: string;
                price: string;
            };
            exportProductToCsv: string;
        };
        importEntries: {
            importProducts: string;
        };
        importEntriesDialog: {
            importProducts: string;
            importProductsSubtitle: string;
            importProductsNewSavedCartSubtitle: string;
            importProductFileDetails: string;
            selectFile: string;
            selectedSuccessfully: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            upload: string;
            close: string;
            summary: {
                info: string;
                loadedToCart: string;
                loaded: string;
                loading: string;
                successes: string;
                warning: string;
                warning_other: string;
                error: string;
                error_other: string;
                messages: {
                    unknownIdentifier: string;
                    lowStock: string;
                    noStock: string;
                    unknownError: string;
                    limitExceeded: string;
                };
                show: string;
                hide: string;
            };
        };
    };
};

declare const pl: {
    importExport: {
        exportEntries: {
            exportToCsv: string;
            exportMessage: string;
            columnNames: {
                code: string;
                quantity: string;
                name: string;
                price: string;
            };
            exportProductToCsv: string;
        };
        importEntries: {
            importProducts: string;
        };
        importEntriesDialog: {
            importProducts: string;
            importProductsSubtitle: string;
            importProductsNewSavedCartSubtitle: string;
            importProductFileDetails: string;
            selectFile: string;
            selectedSuccessfully: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            upload: string;
            close: string;
            summary: {
                info: string;
                loadedToCart: string;
                loaded: string;
                loading: string;
                successes: string;
                warning: string;
                warning_other: string;
                error: string;
                error_other: string;
                messages: {
                    unknownIdentifier: string;
                    lowStock: string;
                    noStock: string;
                    unknownError: string;
                    limitExceeded: string;
                };
                show: string;
                hide: string;
            };
        };
    };
};

declare const pt: {
    importExport: {
        exportEntries: {
            exportToCsv: string;
            exportMessage: string;
            columnNames: {
                code: string;
                quantity: string;
                name: string;
                price: string;
            };
            exportProductToCsv: string;
        };
        importEntries: {
            importProducts: string;
        };
        importEntriesDialog: {
            importProducts: string;
            importProductsSubtitle: string;
            importProductsNewSavedCartSubtitle: string;
            importProductFileDetails: string;
            selectFile: string;
            selectedSuccessfully: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            upload: string;
            close: string;
            summary: {
                info: string;
                loadedToCart: string;
                loaded: string;
                loading: string;
                successes: string;
                warning: string;
                warning_other: string;
                error: string;
                error_other: string;
                messages: {
                    unknownIdentifier: string;
                    lowStock: string;
                    noStock: string;
                    unknownError: string;
                    limitExceeded: string;
                };
                show: string;
                hide: string;
            };
        };
    };
};

declare const ru: {
    importExport: {
        exportEntries: {
            exportToCsv: string;
            exportMessage: string;
            columnNames: {
                code: string;
                quantity: string;
                name: string;
                price: string;
            };
            exportProductToCsv: string;
        };
        importEntries: {
            importProducts: string;
        };
        importEntriesDialog: {
            importProducts: string;
            importProductsSubtitle: string;
            importProductsNewSavedCartSubtitle: string;
            importProductFileDetails: string;
            selectFile: string;
            selectedSuccessfully: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            upload: string;
            close: string;
            summary: {
                info: string;
                loadedToCart: string;
                loaded: string;
                loading: string;
                successes: string;
                warning: string;
                warning_other: string;
                error: string;
                error_other: string;
                messages: {
                    unknownIdentifier: string;
                    lowStock: string;
                    noStock: string;
                    unknownError: string;
                    limitExceeded: string;
                };
                show: string;
                hide: string;
            };
        };
    };
};

declare const zh: {
    importExport: {
        exportEntries: {
            exportToCsv: string;
            exportMessage: string;
            columnNames: {
                code: string;
                quantity: string;
                name: string;
                price: string;
            };
            exportProductToCsv: string;
        };
        importEntries: {
            importProducts: string;
        };
        importEntriesDialog: {
            importProducts: string;
            importProductsSubtitle: string;
            importProductsNewSavedCartSubtitle: string;
            importProductFileDetails: string;
            selectFile: string;
            selectedSuccessfully: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            upload: string;
            close: string;
            summary: {
                info: string;
                loadedToCart: string;
                loaded: string;
                loading: string;
                successes: string;
                warning: string;
                warning_other: string;
                error: string;
                error_other: string;
                messages: {
                    unknownIdentifier: string;
                    lowStock: string;
                    noStock: string;
                    unknownError: string;
                    limitExceeded: string;
                };
                show: string;
                hide: string;
            };
        };
    };
};

declare const zh_TW: {
    importExport: {
        exportEntries: {
            exportToCsv: string;
            exportMessage: string;
            columnNames: {
                code: string;
                quantity: string;
                name: string;
                price: string;
            };
            exportProductToCsv: string;
        };
        importEntries: {
            importProducts: string;
        };
        importEntriesDialog: {
            importProducts: string;
            importProductsSubtitle: string;
            importProductsNewSavedCartSubtitle: string;
            importProductFileDetails: string;
            selectFile: string;
            selectedSuccessfully: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            upload: string;
            close: string;
            summary: {
                info: string;
                loadedToCart: string;
                loaded: string;
                loading: string;
                successes: string;
                warning: string;
                warning_other: string;
                error: string;
                error_other: string;
                messages: {
                    unknownIdentifier: string;
                    lowStock: string;
                    noStock: string;
                    unknownError: string;
                    limitExceeded: string;
                };
                show: string;
                hide: string;
            };
        };
    };
};

declare const importExportTranslationChunksConfig: TranslationChunksConfig;

export { importExportTranslationChunksConfig, cs as importExportTranslationsCs, de as importExportTranslationsDe, en as importExportTranslationsEn, es as importExportTranslationsEs, es_CO as importExportTranslationsEs_CO, fr as importExportTranslationsFr, hi as importExportTranslationsHi, hu as importExportTranslationsHu, id as importExportTranslationsId, it as importExportTranslationsIt, ja as importExportTranslationsJa, ko as importExportTranslationsKo, pl as importExportTranslationsPl, pt as importExportTranslationsPt, ru as importExportTranslationsRu, zh as importExportTranslationsZh, zh_TW as importExportTranslationsZh_TW };
