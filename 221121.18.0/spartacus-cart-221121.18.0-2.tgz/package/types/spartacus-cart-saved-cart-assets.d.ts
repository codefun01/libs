import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    savedCart: {
        savedCartDetails: {
            cartName: string;
            cartDescription: string;
            cartId: string;
            dateSaved: string;
            items: string;
            quantity: string;
            total: string;
            editSavedCart: string;
            deleteSavedCart: string;
            addSelectedItems: string;
            emptyCartItems: string;
        };
        savedCartList: {
            savedCarts: string;
            cartName: string;
            cartId: string;
            dateSaved: string;
            cartDescription: string;
            quantity: string;
            quantityFull: string;
            total: string;
            actions: string;
            makeCartActive: string;
            notFound: string;
            swapCartNoActiveCart: string;
            swapCartWithActiveCart: string;
        };
        savedCartCartPage: {
            messages: {
                cartSaved: string;
            };
        };
        savedCartDialog: {
            saveForLater: string;
            itemsSavedForLater: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            save: string;
            restore: string;
            followingCartDelete: string;
            followingCartRestore: string;
            delete: string;
            deleteCartSuccess: string;
            editCartSuccess: string;
            editSavedCart: string;
            deleteSavedCart: string;
            restoreSavedCart: string;
            name: string;
            id: string;
            description: string;
            quantity: string;
            quantityFull: string;
            total: string;
            keepCopySavedCart: string;
            defaultCloneCartName: string;
            nameOfCloneCart: string;
        };
        addToSavedCart: {
            savedCarts: string;
            saveCartForLater: string;
        };
    };
};

declare const de: {
    savedCart: {
        savedCartDetails: {
            cartName: string;
            cartDescription: string;
            cartId: string;
            dateSaved: string;
            items: string;
            quantity: string;
            total: string;
            editSavedCart: string;
            deleteSavedCart: string;
            addSelectedItems: string;
            emptyCartItems: string;
        };
        savedCartList: {
            savedCarts: string;
            cartName: string;
            cartId: string;
            dateSaved: string;
            cartDescription: string;
            quantity: string;
            quantityFull: string;
            total: string;
            actions: string;
            makeCartActive: string;
            notFound: string;
            swapCartNoActiveCart: string;
            swapCartWithActiveCart: string;
        };
        savedCartCartPage: {
            messages: {
                cartSaved: string;
            };
        };
        savedCartDialog: {
            saveForLater: string;
            itemsSavedForLater: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            save: string;
            restore: string;
            followingCartDelete: string;
            followingCartRestore: string;
            delete: string;
            deleteCartSuccess: string;
            editCartSuccess: string;
            editSavedCart: string;
            deleteSavedCart: string;
            restoreSavedCart: string;
            name: string;
            id: string;
            description: string;
            quantity: string;
            quantityFull: string;
            total: string;
            keepCopySavedCart: string;
            defaultCloneCartName: string;
            nameOfCloneCart: string;
        };
        addToSavedCart: {
            savedCarts: string;
            saveCartForLater: string;
        };
    };
};

declare const en: {
    savedCart: {
        savedCartDetails: {
            cartName: string;
            cartDescription: string;
            cartId: string;
            dateSaved: string;
            items: string;
            quantity: string;
            total: string;
            editSavedCart: string;
            deleteSavedCart: string;
            addSelectedItems: string;
            emptyCartItems: string;
        };
        savedCartList: {
            savedCarts: string;
            cartName: string;
            cartId: string;
            dateSaved: string;
            cartDescription: string;
            quantity: string;
            quantityFull: string;
            total: string;
            actions: string;
            makeCartActive: string;
            notFound: string;
            swapCartNoActiveCart: string;
            swapCartWithActiveCart: string;
        };
        savedCartCartPage: {
            messages: {
                cartSaved: string;
            };
        };
        savedCartDialog: {
            saveForLater: string;
            itemsSavedForLater: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            save: string;
            restore: string;
            followingCartDelete: string;
            followingCartRestore: string;
            delete: string;
            deleteCartSuccess: string;
            editCartSuccess: string;
            editSavedCart: string;
            deleteSavedCart: string;
            restoreSavedCart: string;
            name: string;
            id: string;
            description: string;
            quantity: string;
            quantityFull: string;
            total: string;
            keepCopySavedCart: string;
            defaultCloneCartName: string;
            nameOfCloneCart: string;
        };
        addToSavedCart: {
            savedCarts: string;
            saveCartForLater: string;
        };
    };
};

declare const es: {
    savedCart: {
        savedCartDetails: {
            cartName: string;
            cartDescription: string;
            cartId: string;
            dateSaved: string;
            items: string;
            quantity: string;
            total: string;
            editSavedCart: string;
            deleteSavedCart: string;
            addSelectedItems: string;
            emptyCartItems: string;
        };
        savedCartList: {
            savedCarts: string;
            cartName: string;
            cartId: string;
            dateSaved: string;
            cartDescription: string;
            quantity: string;
            quantityFull: string;
            total: string;
            actions: string;
            makeCartActive: string;
            notFound: string;
            swapCartNoActiveCart: string;
            swapCartWithActiveCart: string;
        };
        savedCartCartPage: {
            messages: {
                cartSaved: string;
            };
        };
        savedCartDialog: {
            saveForLater: string;
            itemsSavedForLater: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            save: string;
            restore: string;
            followingCartDelete: string;
            followingCartRestore: string;
            delete: string;
            deleteCartSuccess: string;
            editCartSuccess: string;
            editSavedCart: string;
            deleteSavedCart: string;
            restoreSavedCart: string;
            name: string;
            id: string;
            description: string;
            quantity: string;
            quantityFull: string;
            total: string;
            keepCopySavedCart: string;
            defaultCloneCartName: string;
            nameOfCloneCart: string;
        };
        addToSavedCart: {
            savedCarts: string;
            saveCartForLater: string;
        };
    };
};

declare const es_CO: {
    savedCart: {
        savedCartDetails: {
            cartName: string;
            cartDescription: string;
            cartId: string;
            dateSaved: string;
            items: string;
            quantity: string;
            total: string;
            editSavedCart: string;
            deleteSavedCart: string;
            addSelectedItems: string;
            emptyCartItems: string;
        };
        savedCartList: {
            savedCarts: string;
            cartName: string;
            cartId: string;
            dateSaved: string;
            cartDescription: string;
            quantity: string;
            quantityFull: string;
            total: string;
            actions: string;
            makeCartActive: string;
            notFound: string;
            swapCartNoActiveCart: string;
            swapCartWithActiveCart: string;
        };
        savedCartCartPage: {
            messages: {
                cartSaved: string;
            };
        };
        savedCartDialog: {
            saveForLater: string;
            itemsSavedForLater: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            save: string;
            restore: string;
            followingCartDelete: string;
            followingCartRestore: string;
            delete: string;
            deleteCartSuccess: string;
            editCartSuccess: string;
            editSavedCart: string;
            deleteSavedCart: string;
            restoreSavedCart: string;
            name: string;
            id: string;
            description: string;
            quantity: string;
            quantityFull: string;
            total: string;
            keepCopySavedCart: string;
            defaultCloneCartName: string;
            nameOfCloneCart: string;
        };
        addToSavedCart: {
            savedCarts: string;
            saveCartForLater: string;
        };
    };
};

declare const fr: {
    savedCart: {
        savedCartDetails: {
            cartName: string;
            cartDescription: string;
            cartId: string;
            dateSaved: string;
            items: string;
            quantity: string;
            total: string;
            editSavedCart: string;
            deleteSavedCart: string;
            addSelectedItems: string;
            emptyCartItems: string;
        };
        savedCartList: {
            savedCarts: string;
            cartName: string;
            cartId: string;
            dateSaved: string;
            cartDescription: string;
            quantity: string;
            quantityFull: string;
            total: string;
            actions: string;
            makeCartActive: string;
            notFound: string;
            swapCartNoActiveCart: string;
            swapCartWithActiveCart: string;
        };
        savedCartCartPage: {
            messages: {
                cartSaved: string;
            };
        };
        savedCartDialog: {
            saveForLater: string;
            itemsSavedForLater: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            save: string;
            restore: string;
            followingCartDelete: string;
            followingCartRestore: string;
            delete: string;
            deleteCartSuccess: string;
            editCartSuccess: string;
            editSavedCart: string;
            deleteSavedCart: string;
            restoreSavedCart: string;
            name: string;
            id: string;
            description: string;
            quantity: string;
            quantityFull: string;
            total: string;
            keepCopySavedCart: string;
            defaultCloneCartName: string;
            nameOfCloneCart: string;
        };
        addToSavedCart: {
            savedCarts: string;
            saveCartForLater: string;
        };
    };
};

declare const hi: {
    savedCart: {
        savedCartDetails: {
            cartName: string;
            cartDescription: string;
            cartId: string;
            dateSaved: string;
            items: string;
            quantity: string;
            total: string;
            editSavedCart: string;
            deleteSavedCart: string;
            addSelectedItems: string;
            emptyCartItems: string;
        };
        savedCartList: {
            savedCarts: string;
            cartName: string;
            cartId: string;
            dateSaved: string;
            cartDescription: string;
            quantity: string;
            quantityFull: string;
            total: string;
            actions: string;
            makeCartActive: string;
            notFound: string;
            swapCartNoActiveCart: string;
            swapCartWithActiveCart: string;
        };
        savedCartCartPage: {
            messages: {
                cartSaved: string;
            };
        };
        savedCartDialog: {
            saveForLater: string;
            itemsSavedForLater: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            save: string;
            restore: string;
            followingCartDelete: string;
            followingCartRestore: string;
            delete: string;
            deleteCartSuccess: string;
            editCartSuccess: string;
            editSavedCart: string;
            deleteSavedCart: string;
            restoreSavedCart: string;
            name: string;
            id: string;
            description: string;
            quantity: string;
            quantityFull: string;
            total: string;
            keepCopySavedCart: string;
            defaultCloneCartName: string;
            nameOfCloneCart: string;
        };
        addToSavedCart: {
            savedCarts: string;
            saveCartForLater: string;
        };
    };
};

declare const hu: {
    savedCart: {
        savedCartDetails: {
            cartName: string;
            cartDescription: string;
            cartId: string;
            dateSaved: string;
            items: string;
            quantity: string;
            total: string;
            editSavedCart: string;
            deleteSavedCart: string;
            addSelectedItems: string;
            emptyCartItems: string;
        };
        savedCartList: {
            savedCarts: string;
            cartName: string;
            cartId: string;
            dateSaved: string;
            cartDescription: string;
            quantity: string;
            quantityFull: string;
            total: string;
            actions: string;
            makeCartActive: string;
            notFound: string;
            swapCartNoActiveCart: string;
            swapCartWithActiveCart: string;
        };
        savedCartCartPage: {
            messages: {
                cartSaved: string;
            };
        };
        savedCartDialog: {
            saveForLater: string;
            itemsSavedForLater: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            save: string;
            restore: string;
            followingCartDelete: string;
            followingCartRestore: string;
            delete: string;
            deleteCartSuccess: string;
            editCartSuccess: string;
            editSavedCart: string;
            deleteSavedCart: string;
            restoreSavedCart: string;
            name: string;
            id: string;
            description: string;
            quantity: string;
            quantityFull: string;
            total: string;
            keepCopySavedCart: string;
            defaultCloneCartName: string;
            nameOfCloneCart: string;
        };
        addToSavedCart: {
            savedCarts: string;
            saveCartForLater: string;
        };
    };
};

declare const id: {
    savedCart: {
        savedCartDetails: {
            cartName: string;
            cartDescription: string;
            cartId: string;
            dateSaved: string;
            items: string;
            quantity: string;
            total: string;
            editSavedCart: string;
            deleteSavedCart: string;
            addSelectedItems: string;
            emptyCartItems: string;
        };
        savedCartList: {
            savedCarts: string;
            cartName: string;
            cartId: string;
            dateSaved: string;
            cartDescription: string;
            quantity: string;
            quantityFull: string;
            total: string;
            actions: string;
            makeCartActive: string;
            notFound: string;
            swapCartNoActiveCart: string;
            swapCartWithActiveCart: string;
        };
        savedCartCartPage: {
            messages: {
                cartSaved: string;
            };
        };
        savedCartDialog: {
            saveForLater: string;
            itemsSavedForLater: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            save: string;
            restore: string;
            followingCartDelete: string;
            followingCartRestore: string;
            delete: string;
            deleteCartSuccess: string;
            editCartSuccess: string;
            editSavedCart: string;
            deleteSavedCart: string;
            restoreSavedCart: string;
            name: string;
            id: string;
            description: string;
            quantity: string;
            quantityFull: string;
            total: string;
            keepCopySavedCart: string;
            defaultCloneCartName: string;
            nameOfCloneCart: string;
        };
        addToSavedCart: {
            savedCarts: string;
            saveCartForLater: string;
        };
    };
};

declare const it: {
    savedCart: {
        savedCartDetails: {
            cartName: string;
            cartDescription: string;
            cartId: string;
            dateSaved: string;
            items: string;
            quantity: string;
            total: string;
            editSavedCart: string;
            deleteSavedCart: string;
            addSelectedItems: string;
            emptyCartItems: string;
        };
        savedCartList: {
            savedCarts: string;
            cartName: string;
            cartId: string;
            dateSaved: string;
            cartDescription: string;
            quantity: string;
            quantityFull: string;
            total: string;
            actions: string;
            makeCartActive: string;
            notFound: string;
            swapCartNoActiveCart: string;
            swapCartWithActiveCart: string;
        };
        savedCartCartPage: {
            messages: {
                cartSaved: string;
            };
        };
        savedCartDialog: {
            saveForLater: string;
            itemsSavedForLater: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            save: string;
            restore: string;
            followingCartDelete: string;
            followingCartRestore: string;
            delete: string;
            deleteCartSuccess: string;
            editCartSuccess: string;
            editSavedCart: string;
            deleteSavedCart: string;
            restoreSavedCart: string;
            name: string;
            id: string;
            description: string;
            quantity: string;
            quantityFull: string;
            total: string;
            keepCopySavedCart: string;
            defaultCloneCartName: string;
            nameOfCloneCart: string;
        };
        addToSavedCart: {
            savedCarts: string;
            saveCartForLater: string;
        };
    };
};

declare const ja: {
    savedCart: {
        savedCartDetails: {
            cartName: string;
            cartDescription: string;
            cartId: string;
            dateSaved: string;
            items: string;
            quantity: string;
            total: string;
            editSavedCart: string;
            deleteSavedCart: string;
            addSelectedItems: string;
            emptyCartItems: string;
        };
        savedCartList: {
            savedCarts: string;
            cartName: string;
            cartId: string;
            dateSaved: string;
            cartDescription: string;
            quantity: string;
            quantityFull: string;
            total: string;
            actions: string;
            makeCartActive: string;
            notFound: string;
            swapCartNoActiveCart: string;
            swapCartWithActiveCart: string;
        };
        savedCartCartPage: {
            messages: {
                cartSaved: string;
            };
        };
        savedCartDialog: {
            saveForLater: string;
            itemsSavedForLater: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            save: string;
            restore: string;
            followingCartDelete: string;
            followingCartRestore: string;
            delete: string;
            deleteCartSuccess: string;
            editCartSuccess: string;
            editSavedCart: string;
            deleteSavedCart: string;
            restoreSavedCart: string;
            name: string;
            id: string;
            description: string;
            quantity: string;
            quantityFull: string;
            total: string;
            keepCopySavedCart: string;
            defaultCloneCartName: string;
            nameOfCloneCart: string;
        };
        addToSavedCart: {
            savedCarts: string;
            saveCartForLater: string;
        };
    };
};

declare const ko: {
    savedCart: {
        savedCartDetails: {
            cartName: string;
            cartDescription: string;
            cartId: string;
            dateSaved: string;
            items: string;
            quantity: string;
            total: string;
            editSavedCart: string;
            deleteSavedCart: string;
            addSelectedItems: string;
            emptyCartItems: string;
        };
        savedCartList: {
            savedCarts: string;
            cartName: string;
            cartId: string;
            dateSaved: string;
            cartDescription: string;
            quantity: string;
            quantityFull: string;
            total: string;
            actions: string;
            makeCartActive: string;
            notFound: string;
            swapCartNoActiveCart: string;
            swapCartWithActiveCart: string;
        };
        savedCartCartPage: {
            messages: {
                cartSaved: string;
            };
        };
        savedCartDialog: {
            saveForLater: string;
            itemsSavedForLater: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            save: string;
            restore: string;
            followingCartDelete: string;
            followingCartRestore: string;
            delete: string;
            deleteCartSuccess: string;
            editCartSuccess: string;
            editSavedCart: string;
            deleteSavedCart: string;
            restoreSavedCart: string;
            name: string;
            id: string;
            description: string;
            quantity: string;
            quantityFull: string;
            total: string;
            keepCopySavedCart: string;
            defaultCloneCartName: string;
            nameOfCloneCart: string;
        };
        addToSavedCart: {
            savedCarts: string;
            saveCartForLater: string;
        };
    };
};

declare const pl: {
    savedCart: {
        savedCartDetails: {
            cartName: string;
            cartDescription: string;
            cartId: string;
            dateSaved: string;
            items: string;
            quantity: string;
            total: string;
            editSavedCart: string;
            deleteSavedCart: string;
            addSelectedItems: string;
            emptyCartItems: string;
        };
        savedCartList: {
            savedCarts: string;
            cartName: string;
            cartId: string;
            dateSaved: string;
            cartDescription: string;
            quantity: string;
            quantityFull: string;
            total: string;
            actions: string;
            makeCartActive: string;
            notFound: string;
            swapCartNoActiveCart: string;
            swapCartWithActiveCart: string;
        };
        savedCartCartPage: {
            messages: {
                cartSaved: string;
            };
        };
        savedCartDialog: {
            saveForLater: string;
            itemsSavedForLater: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            save: string;
            restore: string;
            followingCartDelete: string;
            followingCartRestore: string;
            delete: string;
            deleteCartSuccess: string;
            editCartSuccess: string;
            editSavedCart: string;
            deleteSavedCart: string;
            restoreSavedCart: string;
            name: string;
            id: string;
            description: string;
            quantity: string;
            quantityFull: string;
            total: string;
            keepCopySavedCart: string;
            defaultCloneCartName: string;
            nameOfCloneCart: string;
        };
        addToSavedCart: {
            savedCarts: string;
            saveCartForLater: string;
        };
    };
};

declare const pt: {
    savedCart: {
        savedCartDetails: {
            cartName: string;
            cartDescription: string;
            cartId: string;
            dateSaved: string;
            items: string;
            quantity: string;
            total: string;
            editSavedCart: string;
            deleteSavedCart: string;
            addSelectedItems: string;
            emptyCartItems: string;
        };
        savedCartList: {
            savedCarts: string;
            cartName: string;
            cartId: string;
            dateSaved: string;
            cartDescription: string;
            quantity: string;
            quantityFull: string;
            total: string;
            actions: string;
            makeCartActive: string;
            notFound: string;
            swapCartNoActiveCart: string;
            swapCartWithActiveCart: string;
        };
        savedCartCartPage: {
            messages: {
                cartSaved: string;
            };
        };
        savedCartDialog: {
            saveForLater: string;
            itemsSavedForLater: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            save: string;
            restore: string;
            followingCartDelete: string;
            followingCartRestore: string;
            delete: string;
            deleteCartSuccess: string;
            editCartSuccess: string;
            editSavedCart: string;
            deleteSavedCart: string;
            restoreSavedCart: string;
            name: string;
            id: string;
            description: string;
            quantity: string;
            quantityFull: string;
            total: string;
            keepCopySavedCart: string;
            defaultCloneCartName: string;
            nameOfCloneCart: string;
        };
        addToSavedCart: {
            savedCarts: string;
            saveCartForLater: string;
        };
    };
};

declare const ru: {
    savedCart: {
        savedCartDetails: {
            cartName: string;
            cartDescription: string;
            cartId: string;
            dateSaved: string;
            items: string;
            quantity: string;
            total: string;
            editSavedCart: string;
            deleteSavedCart: string;
            addSelectedItems: string;
            emptyCartItems: string;
        };
        savedCartList: {
            savedCarts: string;
            cartName: string;
            cartId: string;
            dateSaved: string;
            cartDescription: string;
            quantity: string;
            quantityFull: string;
            total: string;
            actions: string;
            makeCartActive: string;
            notFound: string;
            swapCartNoActiveCart: string;
            swapCartWithActiveCart: string;
        };
        savedCartCartPage: {
            messages: {
                cartSaved: string;
            };
        };
        savedCartDialog: {
            saveForLater: string;
            itemsSavedForLater: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            save: string;
            restore: string;
            followingCartDelete: string;
            followingCartRestore: string;
            delete: string;
            deleteCartSuccess: string;
            editCartSuccess: string;
            editSavedCart: string;
            deleteSavedCart: string;
            restoreSavedCart: string;
            name: string;
            id: string;
            description: string;
            quantity: string;
            quantityFull: string;
            total: string;
            keepCopySavedCart: string;
            defaultCloneCartName: string;
            nameOfCloneCart: string;
        };
        addToSavedCart: {
            savedCarts: string;
            saveCartForLater: string;
        };
    };
};

declare const zh: {
    savedCart: {
        savedCartDetails: {
            cartName: string;
            cartDescription: string;
            cartId: string;
            dateSaved: string;
            items: string;
            quantity: string;
            total: string;
            editSavedCart: string;
            deleteSavedCart: string;
            addSelectedItems: string;
            emptyCartItems: string;
        };
        savedCartList: {
            savedCarts: string;
            cartName: string;
            cartId: string;
            dateSaved: string;
            cartDescription: string;
            quantity: string;
            quantityFull: string;
            total: string;
            actions: string;
            makeCartActive: string;
            notFound: string;
            swapCartNoActiveCart: string;
            swapCartWithActiveCart: string;
        };
        savedCartCartPage: {
            messages: {
                cartSaved: string;
            };
        };
        savedCartDialog: {
            saveForLater: string;
            itemsSavedForLater: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            save: string;
            restore: string;
            followingCartDelete: string;
            followingCartRestore: string;
            delete: string;
            deleteCartSuccess: string;
            editCartSuccess: string;
            editSavedCart: string;
            deleteSavedCart: string;
            restoreSavedCart: string;
            name: string;
            id: string;
            description: string;
            quantity: string;
            quantityFull: string;
            total: string;
            keepCopySavedCart: string;
            defaultCloneCartName: string;
            nameOfCloneCart: string;
        };
        addToSavedCart: {
            savedCarts: string;
            saveCartForLater: string;
        };
    };
};

declare const zh_TW: {
    savedCart: {
        savedCartDetails: {
            cartName: string;
            cartDescription: string;
            cartId: string;
            dateSaved: string;
            items: string;
            quantity: string;
            total: string;
            editSavedCart: string;
            deleteSavedCart: string;
            addSelectedItems: string;
            emptyCartItems: string;
        };
        savedCartList: {
            savedCarts: string;
            cartName: string;
            cartId: string;
            dateSaved: string;
            cartDescription: string;
            quantity: string;
            quantityFull: string;
            total: string;
            actions: string;
            makeCartActive: string;
            notFound: string;
            swapCartNoActiveCart: string;
            swapCartWithActiveCart: string;
        };
        savedCartCartPage: {
            messages: {
                cartSaved: string;
            };
        };
        savedCartDialog: {
            saveForLater: string;
            itemsSavedForLater: string;
            savedCartName: string;
            savedCartDescription: string;
            optional: string;
            charactersLeft: string;
            cancel: string;
            save: string;
            restore: string;
            followingCartDelete: string;
            followingCartRestore: string;
            delete: string;
            deleteCartSuccess: string;
            editCartSuccess: string;
            editSavedCart: string;
            deleteSavedCart: string;
            restoreSavedCart: string;
            name: string;
            id: string;
            description: string;
            quantity: string;
            quantityFull: string;
            total: string;
            keepCopySavedCart: string;
            defaultCloneCartName: string;
            nameOfCloneCart: string;
        };
        addToSavedCart: {
            savedCarts: string;
            saveCartForLater: string;
        };
    };
};

declare const savedCartTranslationChunksConfig: TranslationChunksConfig;

export { savedCartTranslationChunksConfig, cs as savedCartTranslationsCs, de as savedCartTranslationsDe, en as savedCartTranslationsEn, es as savedCartTranslationsEs, es_CO as savedCartTranslationsEs_CO, fr as savedCartTranslationsFr, hi as savedCartTranslationsHi, hu as savedCartTranslationsHu, id as savedCartTranslationsId, it as savedCartTranslationsIt, ja as savedCartTranslationsJa, ko as savedCartTranslationsKo, pl as savedCartTranslationsPl, pt as savedCartTranslationsPt, ru as savedCartTranslationsRu, zh as savedCartTranslationsZh, zh_TW as savedCartTranslationsZh_TW };
