import { Translatable } from '@spartacus/core';
import { ExportFileOptions } from '@spartacus/storefront';
import { OrderEntriesSource } from '@spartacus/cart/base/root';
import * as i0 from '@angular/core';
import { ModuleWithProviders } from '@angular/core';

interface ExportColumn {
    /**
     * `Translatable` object used to translate column heading to the language currently set in a storefront.
     * If `key` value was provided it also requires to have a representation in trasnlation file.
     */
    name: Translatable;
    /**
     * Dot notation string which refers to specified `OrderEntry` attribute.
     */
    value: string;
}
interface ExportConfig {
    /**
     * Specifies which columns besides code and quantity can be exported to CSV file.
     */
    additionalColumns?: ExportColumn[];
    /**
     * Flag used to determine if message informing about download starting proccess
     * should be visible to user.
     */
    messageEnabled?: boolean;
    /**
     * Property dedicated to delay download starting process.
     */
    downloadDelay?: number;
    /**
     * Metadata for exported file.
     */
    fileOptions: ExportFileOptions;
    /**
     * Determines entries limit in exported CSV file.
     */
    maxEntries?: number;
}

/**
 * Indicates from which source the new saved cart name
 * should be taken.
 */
declare enum CartNameSource {
    FILE_NAME = "fileName",
    DATE_TIME = "dateTime"
}
/**
 * Specifies cart name generation details.
 */
interface CartNameGeneration {
    /**
     *  If `source` is set as `DATE_TIME`, it means that by default
     *  new saved cart name will be set as current date according to `fromDateOptions` property.
     */
    source?: CartNameSource;
    fromDateOptions?: {
        /**
         * Adds text before the import date.
         */
        prefix?: string;
        /**
         * Adds text after the import date.
         */
        suffix?: string;
        /**
         * Transforms current date according to specified format.
         */
        mask?: string;
    };
}
/**
 * Allows to specify file validation attributes.
 */
interface FileValidity {
    /**
     * Maximum imported file size in megabytes.
     */
    maxSize?: number;
    /**
     * Maximum number for imported entries per place specified as key from `OrderEntriesSource`.
     */
    maxEntries?: {
        [key in OrderEntriesSource]?: number;
    };
    /**
     * String array with file types/extensions allowed for import.
     */
    allowedTypes?: string[];
}
/**
 * Interface for import config.
 */
interface ImportConfig {
    fileValidity?: FileValidity;
    cartNameGeneration?: CartNameGeneration;
}

declare abstract class ImportExportConfig {
    cartImportExport?: {
        file: {
            separator: string;
        };
        import?: ImportConfig;
        export: ExportConfig;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<ImportExportConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ImportExportConfig>;
}
declare module '@spartacus/core' {
    interface Config extends ImportExportConfig {
    }
}

declare const defaultImportExportConfig: ImportExportConfig;

declare class ImportExportCoreModule {
    static forRoot(): ModuleWithProviders<ImportExportCoreModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImportExportCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ImportExportCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ImportExportCoreModule>;
}

declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        IMPORT_TO_CART = "IMPORT_TO_CART"
    }
}

export { CartNameSource, ImportExportConfig, ImportExportCoreModule, defaultImportExportConfig };
export type { CartNameGeneration, ExportColumn, ExportConfig, FileValidity, ImportConfig };
