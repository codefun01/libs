import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    wishlist: {
        wishlist: {
            empty: string;
            itemRemoved: string;
            caption: string;
        };
    };
};

declare const de: {
    wishlist: {
        wishlist: {
            empty: string;
            itemRemoved: string;
            caption: string;
        };
    };
};

declare const en: {
    wishlist: {
        wishlist: {
            empty: string;
            itemRemoved: string;
            caption: string;
        };
    };
};

declare const es: {
    wishlist: {
        wishlist: {
            empty: string;
            itemRemoved: string;
            caption: string;
        };
    };
};

declare const es_CO: {
    wishlist: {
        wishlist: {
            empty: string;
            itemRemoved: string;
            caption: string;
        };
    };
};

declare const fr: {
    wishlist: {
        wishlist: {
            empty: string;
            itemRemoved: string;
            caption: string;
        };
    };
};

declare const hi: {
    wishlist: {
        wishlist: {
            empty: string;
            itemRemoved: string;
            caption: string;
        };
    };
};

declare const hu: {
    wishlist: {
        wishlist: {
            empty: string;
            itemRemoved: string;
            caption: string;
        };
    };
};

declare const id: {
    wishlist: {
        wishlist: {
            empty: string;
            itemRemoved: string;
            caption: string;
        };
    };
};

declare const it: {
    wishlist: {
        wishlist: {
            empty: string;
            itemRemoved: string;
            caption: string;
        };
    };
};

declare const ja: {
    wishlist: {
        wishlist: {
            empty: string;
            itemRemoved: string;
            caption: string;
        };
    };
};

declare const ko: {
    wishlist: {
        wishlist: {
            empty: string;
            itemRemoved: string;
            caption: string;
        };
    };
};

declare const pl: {
    wishlist: {
        wishlist: {
            empty: string;
            itemRemoved: string;
            caption: string;
        };
    };
};

declare const pt: {
    wishlist: {
        wishlist: {
            empty: string;
            itemRemoved: string;
            caption: string;
        };
    };
};

declare const ru: {
    wishlist: {
        wishlist: {
            empty: string;
            itemRemoved: string;
            caption: string;
        };
    };
};

declare const zh: {
    wishlist: {
        wishlist: {
            empty: string;
            itemRemoved: string;
            caption: string;
        };
    };
};

declare const zh_TW: {
    wishlist: {
        wishlist: {
            empty: string;
            itemRemoved: string;
            caption: string;
        };
    };
};

declare const wishListTranslationChunksConfig: TranslationChunksConfig;

export { wishListTranslationChunksConfig, cs as wishListTranslationsCs, de as wishListTranslationsDe, en as wishListTranslationsEn, es as wishListTranslationsEs, es_CO as wishListTranslationsEs_CO, fr as wishListTranslationsFr, hi as wishListTranslationsHi, hu as wishListTranslationsHu, id as wishListTranslationsId, it as wishListTranslationsIt, ja as wishListTranslationsJa, ko as wishListTranslationsKo, pl as wishListTranslationsPl, pt as wishListTranslationsPt, ru as wishListTranslationsRu, zh as wishListTranslationsZh, zh_TW as wishListTranslationsZh_TW };
