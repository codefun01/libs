import { HttpClient } from '@angular/common/http';
import { Cart } from '@spartacus/cart/base/root';
import { SavedCartAdapter } from '@spartacus/cart/saved-cart/core';
import { OccEndpointsService, ConverterService, OccEndpoint } from '@spartacus/core';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare class OccSavedCartAdapter implements SavedCartAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    load(userId: string, cartId: string): Observable<Cart>;
    loadList(userId: string): Observable<Cart[]>;
    restoreSavedCart(userId: string, cartId: string): Observable<Cart>;
    cloneSavedCart(userId: string, cartId: string, saveCartName: string): Observable<Cart>;
    protected getSavedCartEndpoint(userId: string, cartId: string): string;
    protected getSavedCartListEndpoint(userId: string): string;
    protected getRestoreSavedCartEndpoint(userId: string, cartId: string): string;
    protected getCloneSavedCartEndpoint(userId: string, cartId: string, saveCartName: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccSavedCartAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccSavedCartAdapter>;
}

declare module '@spartacus/core' {
    interface OccEndpoints {
        /**
         * Endpoint to load saved carts
         *
         * * @member {string}
         */
        savedCarts?: string | OccEndpoint;
        /**
         * Endpoint to save a cart
         *
         * * @member {string}
         */
        saveCart?: string | OccEndpoint;
        /**
         * Endpoint to get specific saved cart
         *
         * * @member {string}
         */
        savedCart?: string | OccEndpoint;
        /**
         * Endpoint to make a saved cart active
         *
         * * @member {string}
         */
        restoreSavedCart?: string | OccEndpoint;
        /**
         * Endpoint to clone a saved cart
         *
         * * @member {string}
         */
        cloneSavedCart?: string | OccEndpoint;
    }
}

declare class SavedCartOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SavedCartOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SavedCartOccModule>;
}

export { OccSavedCartAdapter, SavedCartOccModule };
