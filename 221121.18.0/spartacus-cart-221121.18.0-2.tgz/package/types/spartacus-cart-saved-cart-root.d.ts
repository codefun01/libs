import { CartEvent, Cart } from '@spartacus/cart/base/root';
import { StateUtils, CmsConfig } from '@spartacus/core';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import * as i1 from '@angular/router';

/**
 * Base saved cart event. Most cart events should have these properties.
 */
declare abstract class SavedCartEvent extends CartEvent {
}
declare class SaveCartEvent extends SavedCartEvent {
    /**
     * Event's type
     */
    static readonly type = "SaveCartEvent";
    saveCartName?: string;
    saveCartDescription?: string;
}
declare class SaveCartSuccessEvent extends SavedCartEvent {
    /**
     * Event's type
     */
    static readonly type = "SaveCartSuccessEvent";
    saveCartName?: string;
    saveCartDescription?: string;
    saveTime: string;
}
declare class SaveCartFailEvent extends SavedCartEvent {
    /**
     * Event's type
     */
    static readonly type = "SaveCartEvent";
    saveCartName?: string;
    saveCartDescription?: string;
}
declare class RestoreSavedCartEvent extends SavedCartEvent {
    /**
     * Event's type
     */
    static readonly type = "RestoreSavedCartEvent";
    saveCartName?: string;
    saveCartDescription?: string;
    saveTime: string;
}
declare class RestoreSavedCartSuccessEvent extends SavedCartEvent {
    /**
     * Event's type
     */
    static readonly type = "RestoreSavedCartSuccessEvent";
    saveCartName?: string;
    saveCartDescription?: string;
}
declare class RestoreSavedCartFailEvent extends SavedCartEvent {
    /**
     * Event's type
     */
    static readonly type = "RestoreSavedCartFailEvent";
    saveCartName?: string;
    saveCartDescription?: string;
    saveTime: string;
}
declare class EditSavedCartEvent extends SavedCartEvent {
    /**
     * Event's type
     */
    static readonly type = "EditSavedCartEvent";
    saveCartName?: string;
    saveCartDescription?: string;
}
declare class EditSavedCartSuccessEvent extends SavedCartEvent {
    /**
     * Event's type
     */
    static readonly type = "EditSavedCartSuccessEvent";
    saveCartName?: string;
    saveCartDescription?: string;
    saveTime: string;
}
declare class EditSavedCartFailEvent extends SavedCartEvent {
    /**
     * Event's type
     */
    static readonly type = "EditSavedCartFailEvent";
    saveCartName?: string;
    saveCartDescription?: string;
}
declare class CloneSavedCartEvent extends SavedCartEvent {
    /**
     * Event's type
     */
    static readonly type = "CloneSavedCartEvent";
    saveCartName?: string;
    saveCartDescription?: string;
    saveTime: string;
}
declare class CloneSavedCartSuccessEvent extends SavedCartEvent {
    /**
     * Event's type
     */
    static readonly type = "CloneSavedCartSuccessEvent";
    saveCartName?: string;
    saveCartDescription?: string;
}
declare class CloneSavedCartFailEvent extends SavedCartEvent {
    /**
     * Event's type
     */
    static readonly type = "CloneSavedCartFailEvent";
    saveCartName?: string;
    saveCartDescription?: string;
    saveTime: string;
}

declare abstract class SavedCartFacade {
    /**
     * Loads a single saved cart
     */
    abstract loadSavedCart(cartId: string): void;
    /**
     * Gets a single saved cart
     * it won't emit if the delete saved cart event gets triggered to avoid race condition between actions
     *
     * @param cartId
     * @returns observable with cart
     */
    abstract get(cartId: string): Observable<Cart | undefined>;
    /**
     * Gets the selected cart state
     *
     * @param cartId
     * @returns observable of selected cart with loader state
     */
    abstract getSavedCart(cartId: string): Observable<StateUtils.ProcessesLoaderState<Cart | undefined>>;
    /**
     * Returns true when there are no operations on that in progress and it is not currently loading
     *
     * @param cartId
     */
    abstract isStable(cartId: string): Observable<boolean>;
    /**
     * Loads a list of saved carts
     */
    abstract loadSavedCarts(): void;
    /**
     * Gets a list of saved carts
     *
     * @returns observable with list of saved carts
     */
    abstract getList(): Observable<Cart[]>;
    /**
     * Gets a list of saved carts from all carts in the state
     * by filtering through the carts that are not wishlist and not saved cart
     *
     * @returns observable with list of saved carts
     */
    abstract getSavedCartList(): Observable<Cart[]>;
    /**
     * Gets the loading flag of getting a list of saved carts
     *
     * @returns observable with boolean of the loading state
     */
    abstract getSavedCartListProcessLoading(): Observable<boolean>;
    /**
     * Gets the loading state of getting a list of saved carts
     *
     * @returns observable with boolean of the loader state
     */
    abstract getSavedCartListProcess(): Observable<StateUtils.LoaderState<any>>;
    /**
     * Clears the process state of performing a saved cart
     */
    abstract clearSavedCarts(): void;
    /**
     * Triggers a restore saved cart
     *
     * @param cartId
     */
    abstract restoreSavedCart(cartId: string): void;
    /**
     * Gets the loading state of restoring saved cart
     *
     * @returns observable with boolean of the loading state
     */
    abstract getRestoreSavedCartProcessLoading(): Observable<boolean>;
    /**
     * Gets the success state of restoring saved cart
     *
     * @returns observable with boolean of the success state
     */
    abstract getRestoreSavedCartProcessSuccess(): Observable<boolean>;
    /**
     * Gets the error state of restoring saved cart
     *
     * @returns observable with boolean of the error state
     */
    abstract getRestoreSavedCartProcessError(): Observable<boolean>;
    /**
     * Clears the process state of performing a restore saved cart
     */
    abstract clearRestoreSavedCart(): void;
    /**
     * Triggers delete saved cart
     * @param cartId
     */
    abstract deleteSavedCart(cartId: string): void;
    /**
     * Triggers a saved cart
     *
     */
    abstract saveCart({ cartId, saveCartName, saveCartDescription, }: {
        cartId: string;
        saveCartName?: string;
        saveCartDescription?: string;
    }): void;
    /**
     * Gets the loading state of saving a cart
     *
     * @returns observable with boolean of the loading state
     */
    abstract getSaveCartProcessLoading(): Observable<boolean>;
    /**
     * Gets the success state of saving a cart
     *
     * @returns observable with boolean of the success state
     */
    abstract getSaveCartProcessSuccess(): Observable<boolean>;
    /**
     * Gets the error state of saving a cart
     *
     * @returns observable with boolean of the error state
     */
    abstract getSaveCartProcessError(): Observable<boolean>;
    /**
     * Clears the process state of performing a save cart
     */
    abstract clearSaveCart(): void;
    /**
     * Triggers an edit saved cart
     *
     */
    abstract editSavedCart({ cartId, saveCartName, saveCartDescription, }: {
        cartId: string;
        saveCartName?: string;
        saveCartDescription?: string;
    }): void;
    /**
     * Triggers a clone saved cart
     *
     * @param cartId
     */
    abstract cloneSavedCart(cartId: string, saveCartName?: string): void;
    /**
     * Gets the loading state of cloning a saved cart
     *
     * @returns observable with boolean of the loading state
     */
    abstract getCloneSavedCartProcessLoading(): Observable<boolean>;
    /**
     * Gets the success state of cloning a saved cart
     *
     * @returns observable with boolean of the success state
     */
    abstract getCloneSavedCartProcessSuccess(): Observable<boolean>;
    /**
     * Gets the error state of cloning a saved cart
     *
     * @returns observable with boolean of the error state
     */
    abstract getCloneSavedCartProcessError(): Observable<boolean>;
    /**
     * Clears the process state cloning a saved cart
     */
    abstract clearCloneSavedCart(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SavedCartFacade>;
}

declare const CART_SAVED_CART_FEATURE = "cartSavedCart";
declare const CART_SAVED_CART_CORE_FEATURE = "cartSavedCartCore";

declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        SAVED_CART = "SAVED_CART"
    }
}

declare enum SavedCartFormType {
    EDIT = "edit",
    DELETE = "delete",
    SAVE = "save",
    RESTORE = "restore"
}

declare function defaultCartSavedCartComponentsConfig(): CmsConfig;
declare class SavedCartRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SavedCartRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SavedCartRootModule, never, [typeof i1.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SavedCartRootModule>;
}

declare const SavedCartOrderEntriesContextToken: InjectionToken<unknown>;
declare const NewSavedCartOrderEntriesContextToken: InjectionToken<unknown>;

export { CART_SAVED_CART_CORE_FEATURE, CART_SAVED_CART_FEATURE, CloneSavedCartEvent, CloneSavedCartFailEvent, CloneSavedCartSuccessEvent, EditSavedCartEvent, EditSavedCartFailEvent, EditSavedCartSuccessEvent, NewSavedCartOrderEntriesContextToken, RestoreSavedCartEvent, RestoreSavedCartFailEvent, RestoreSavedCartSuccessEvent, SaveCartEvent, SaveCartFailEvent, SaveCartSuccessEvent, SavedCartEvent, SavedCartFacade, SavedCartFormType, SavedCartOrderEntriesContextToken, SavedCartRootModule, defaultCartSavedCartComponentsConfig };
