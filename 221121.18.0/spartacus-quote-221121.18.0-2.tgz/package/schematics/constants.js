"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.QUOTE_TRANSLATION_CHUNKS_CONFIG = exports.QUOTE_TRANSLATIONS = exports.SPARTACUS_QUOTE_ASSETS = exports.SPARTACUS_QUOTE_ROOT = exports.QUOTE_SCSS_FILE_NAME = exports.QUOTE_MODULE_NAME = exports.QUOTE_FOLDER_NAME = void 0;
const schematics_1 = require("@spartacus/schematics");
exports.QUOTE_FOLDER_NAME = 'quote';
exports.QUOTE_MODULE_NAME = 'quote';
exports.QUOTE_SCSS_FILE_NAME = 'quote.scss';
exports.SPARTACUS_QUOTE_ROOT = `${schematics_1.SPARTACUS_QUOTE}/root`;
exports.SPARTACUS_QUOTE_ASSETS = `${schematics_1.SPARTACUS_QUOTE}/assets`;
exports.QUOTE_TRANSLATIONS = 'quoteTranslations';
exports.QUOTE_TRANSLATION_CHUNKS_CONFIG = 'quoteTranslationChunksConfig';
//# sourceMappingURL=constants.js.map