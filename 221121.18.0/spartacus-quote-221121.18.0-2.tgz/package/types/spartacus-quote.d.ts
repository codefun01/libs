import * as i0 from '@angular/core';
import * as i1 from '@spartacus/quote/components';
import * as i2 from '@spartacus/quote/core';
import * as i3 from '@spartacus/quote/occ';

declare class QuoteModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteModule, never, [typeof i1.QuoteComponentsModule, typeof i2.QuoteCoreModule, typeof i3.QuoteOccModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteModule>;
}

export { QuoteModule };
