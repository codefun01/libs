import { HttpClient } from '@angular/common/http';
import { OccEndpointsService, ConverterService, LoggerService, PaginationModel, OccEndpoint } from '@spartacus/core';
import { OrderConfig } from '@spartacus/order/root';
import { QuoteAdapter } from '@spartacus/quote/core';
import { QuoteList, QuoteStarter, Quote, QuoteMetadata, QuoteActionType, QuoteComment, QuoteDiscount } from '@spartacus/quote/root';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare class OccQuoteAdapter implements QuoteAdapter {
    protected httpClient: HttpClient;
    protected occEndpointsService: OccEndpointsService;
    protected converterService: ConverterService;
    protected loggerService: LoggerService;
    private occFieldsService;
    protected orderConfig: OrderConfig;
    getQuotes(userId: string, pagination: PaginationModel): Observable<QuoteList>;
    protected getQuotesEndpoint(userId: string, params?: PaginationModel): string;
    createQuote(userId: string, quoteStarter: QuoteStarter): Observable<Quote>;
    protected getCreateQuoteEndpoint(userId: string): string;
    getQuote(userId: string, quoteCode: string): Observable<Quote>;
    protected getQuoteEndpoint(userId: string, quoteCode: string): string;
    editQuote(userId: string, quoteCode: string, quoteMetadata: QuoteMetadata): Observable<unknown>;
    protected getEditQuoteEndpoint(userId: string, quoteCode: string): string;
    performQuoteAction(userId: string, quoteCode: string, quoteAction: QuoteActionType): Observable<unknown>;
    protected getPerformQuoteActionEndpoint(userId: string, quoteCode: string): string;
    addComment(userId: string, quoteCode: string, quoteComment: QuoteComment): Observable<unknown>;
    protected getAddCommentEndpoint(userId: string, quoteCode: string): string;
    addDiscount(userId: string, quoteCode: string, quoteDiscount: QuoteDiscount): Observable<unknown>;
    protected getAddDiscountEndpoint(userId: string, quoteCode: string): string;
    addQuoteEntryComment(userId: string, quoteCode: string, entryNumber: string, comment: QuoteComment): Observable<unknown>;
    protected getAddQuoteEntryCommentEndpoint(userId: string, quoteCode: string, entryNumber: string): string;
    downloadAttachment(userId: string, quoteCode: string, attachmentId: string): Observable<Blob>;
    protected getDownloadAttachmentEndpoint(userId: string, quoteCode: string, attachmentId: string): string;
    protected withErrorHandling<T>(quoteObservable: Observable<T>): Observable<T>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccQuoteAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccQuoteAdapter>;
}

declare class QuoteOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteOccModule>;
}

interface QuoteOccEndpoints {
    /**
     * Get all quotes for user.
     */
    getQuotes?: string | OccEndpoint;
    /**
     * Request a quote.
     */
    createQuote?: string | OccEndpoint;
    /**
     * Get Order Code associated with the Quote. The Order Code is present if the quote was used to place an order.
     */
    getOrderCode?: string | OccEndpoint;
    /**
     * Get a specific quote.
     */
    getQuote?: string | OccEndpoint;
    /**
     * Edit the quote.
     */
    editQuote?: string | OccEndpoint;
    /**
     * Perform workflow actions with the quote.
     */
    performQuoteAction?: string | OccEndpoint;
    /**
     * Add a comment to a quote.
     */
    addComment?: string | OccEndpoint;
    /**
     * Apply a discount to an existing quote.
     */
    addDiscount?: string | OccEndpoint;
    /**
     * Add a comment to a line item of a quote.
     */
    addQuoteEntryComment?: string | OccEndpoint;
    /**
     * Downloads the proposal document associated with a quote.
     */
    downloadAttachment?: string | OccEndpoint;
}
declare module '@spartacus/core' {
    interface OccEndpoints extends QuoteOccEndpoints {
    }
}

export { OccQuoteAdapter, QuoteOccModule };
export type { QuoteOccEndpoints };
