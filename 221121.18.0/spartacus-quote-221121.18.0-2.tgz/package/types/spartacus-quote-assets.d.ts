import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    quote: {
        quote: {
            confirmDialog: {
                name: string;
                description: string;
                validity: string;
                option: {
                    yes: string;
                    no: string;
                };
                buyer: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                buyer_offer: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    checkout: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                    };
                };
                expired: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                seller: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                        successMessage: string;
                    };
                };
                sellerapprover: {
                    approve: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    reject: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                cancelled: {
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                all: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
            };
            comments: {
                regionTitle: string;
                title: string;
                invalidComment: string;
                allProducts: string;
            };
            commons: {
                requestQuote: string;
                cart: string;
                minRequestInitiationNote: string;
                savedActiveCart: string;
            };
            header: {
                buyerEdit: {
                    a11y: {
                        cancel: string;
                        save: string;
                    };
                };
                overview: {
                    regionTitle: string;
                    id: string;
                    status: string;
                    information: string;
                    name: string;
                    description: string;
                    charactersLeft: string;
                    priceAndExpiry: string;
                    estimatedTotal: string;
                    total: string;
                    expirationTime: string;
                    a11y: {
                        edit: string;
                    };
                    createdAndUpdated: string;
                    createdDate: string;
                    lastUpdatedDate: string;
                };
            };
            httpHandlers: {
                cartValidationIssue: string;
                quoteCartIssue: string;
                absoluteDiscountIssue: string;
                expirationDateIssue: string;
                threshold: {
                    underThresholdError: string;
                };
                expired: string;
                downloadPDFError: string;
            };
            items: {
                regionTitle: string;
            };
            links: {
                newCart: string;
                quotes: string;
                download: string;
                order: string;
                a11y: {
                    newCart: string;
                    quotes: string;
                    download: string;
                    order: string;
                };
            };
            list: {
                regionTitle: string;
                title: string;
                name: string;
                updated: string;
                sortBy: string;
                sortQuotes: string;
                empty: string;
                quoteId: string;
                status: string;
                clickableRow: string;
            };
            states: {
                BUYER_DRAFT: string;
                BUYER_SUBMITTED: string;
                BUYER_ACCEPTED: string;
                BUYER_APPROVED: string;
                BUYER_REJECTED: string;
                BUYER_OFFER: string;
                BUYER_ORDERED: string;
                SELLER_DRAFT: string;
                SELLER_REQUEST: string;
                SELLER_SUBMITTED: string;
                SELLERAPPROVER_DRAFT: string;
                SELLERAPPROVER_PENDING: string;
                SELLERAPPROVER_APPROVED: string;
                SELLERAPPROVER_REJECTED: string;
                CREATED: string;
                CANCELLED: string;
                EXPIRED: string;
            };
            summary: {
                regionTitle: string;
                actions: {
                    APPROVE: string;
                    CANCEL: string;
                    CHECKOUT: string;
                    EDIT: string;
                    REJECT: string;
                    REQUOTE: string;
                    SAVE: string;
                    SUBMIT: string;
                    VIEW: string;
                };
                prices: {
                    title: string;
                    subtotal: string;
                    productDiscount: string;
                    orderDiscount: string;
                    quoteDiscount: string;
                    total: string;
                    hint: string;
                };
                sellerEdit: {
                    discount: string;
                    apply: string;
                    expiryDate: string;
                    discountValidationText: string;
                    a11y: {
                        apply: string;
                        discount: string;
                        expiryDate: string;
                    };
                };
            };
        };
    };
};

declare const de: {
    quote: {
        quote: {
            confirmDialog: {
                name: string;
                description: string;
                validity: string;
                option: {
                    yes: string;
                    no: string;
                };
                buyer: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                buyer_offer: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    checkout: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                    };
                };
                expired: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                seller: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                        successMessage: string;
                    };
                };
                sellerapprover: {
                    approve: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    reject: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                cancelled: {
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                all: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
            };
            comments: {
                regionTitle: string;
                title: string;
                invalidComment: string;
                allProducts: string;
            };
            commons: {
                requestQuote: string;
                cart: string;
                minRequestInitiationNote: string;
                savedActiveCart: string;
            };
            header: {
                buyerEdit: {
                    a11y: {
                        cancel: string;
                        save: string;
                    };
                };
                overview: {
                    regionTitle: string;
                    id: string;
                    status: string;
                    information: string;
                    name: string;
                    description: string;
                    charactersLeft: string;
                    priceAndExpiry: string;
                    estimatedTotal: string;
                    total: string;
                    expirationTime: string;
                    a11y: {
                        edit: string;
                    };
                    createdAndUpdated: string;
                    createdDate: string;
                    lastUpdatedDate: string;
                };
            };
            httpHandlers: {
                cartValidationIssue: string;
                quoteCartIssue: string;
                absoluteDiscountIssue: string;
                expirationDateIssue: string;
                threshold: {
                    underThresholdError: string;
                };
                expired: string;
                downloadPDFError: string;
            };
            items: {
                regionTitle: string;
            };
            links: {
                newCart: string;
                quotes: string;
                download: string;
                order: string;
                a11y: {
                    newCart: string;
                    quotes: string;
                    download: string;
                    order: string;
                };
            };
            list: {
                regionTitle: string;
                title: string;
                name: string;
                updated: string;
                sortBy: string;
                sortQuotes: string;
                empty: string;
                quoteId: string;
                status: string;
                clickableRow: string;
            };
            states: {
                BUYER_DRAFT: string;
                BUYER_SUBMITTED: string;
                BUYER_ACCEPTED: string;
                BUYER_APPROVED: string;
                BUYER_REJECTED: string;
                BUYER_OFFER: string;
                BUYER_ORDERED: string;
                SELLER_DRAFT: string;
                SELLER_REQUEST: string;
                SELLER_SUBMITTED: string;
                SELLERAPPROVER_DRAFT: string;
                SELLERAPPROVER_PENDING: string;
                SELLERAPPROVER_APPROVED: string;
                SELLERAPPROVER_REJECTED: string;
                CREATED: string;
                CANCELLED: string;
                EXPIRED: string;
            };
            summary: {
                regionTitle: string;
                actions: {
                    APPROVE: string;
                    CANCEL: string;
                    CHECKOUT: string;
                    EDIT: string;
                    REJECT: string;
                    REQUOTE: string;
                    SAVE: string;
                    SUBMIT: string;
                    VIEW: string;
                };
                prices: {
                    title: string;
                    subtotal: string;
                    productDiscount: string;
                    orderDiscount: string;
                    quoteDiscount: string;
                    total: string;
                    hint: string;
                };
                sellerEdit: {
                    discount: string;
                    apply: string;
                    expiryDate: string;
                    discountValidationText: string;
                    a11y: {
                        apply: string;
                        discount: string;
                        expiryDate: string;
                    };
                };
            };
        };
    };
};

declare const en: {
    quote: {
        quote: {
            confirmDialog: {
                name: string;
                description: string;
                validity: string;
                option: {
                    yes: string;
                    no: string;
                };
                buyer: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                buyer_offer: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    checkout: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                    };
                };
                expired: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                seller: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                        successMessage: string;
                    };
                };
                sellerapprover: {
                    approve: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    reject: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                cancelled: {
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                all: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
            };
            comments: {
                regionTitle: string;
                title: string;
                invalidComment: string;
                allProducts: string;
            };
            commons: {
                requestQuote: string;
                cart: string;
                minRequestInitiationNote: string;
                savedActiveCart: string;
            };
            header: {
                buyerEdit: {
                    a11y: {
                        cancel: string;
                        save: string;
                    };
                };
                overview: {
                    regionTitle: string;
                    id: string;
                    status: string;
                    information: string;
                    name: string;
                    description: string;
                    purchaseOrderNumber: string;
                    optional: string;
                    charactersLeft: string;
                    priceAndExpiry: string;
                    estimatedTotal: string;
                    total: string;
                    expirationTime: string;
                    a11y: {
                        edit: string;
                    };
                    createdAndUpdated: string;
                    createdDate: string;
                    lastUpdatedDate: string;
                };
            };
            httpHandlers: {
                cartValidationIssue: string;
                quoteCartIssue: string;
                absoluteDiscountIssue: string;
                expirationDateIssue: string;
                threshold: {
                    underThresholdError: string;
                };
                expired: string;
                downloadPDFError: string;
            };
            items: {
                regionTitle: string;
            };
            links: {
                newCart: string;
                quotes: string;
                download: string;
                order: string;
                a11y: {
                    newCart: string;
                    quotes: string;
                    download: string;
                    order: string;
                };
            };
            list: {
                regionTitle: string;
                title: string;
                name: string;
                updated: string;
                sortBy: string;
                sortQuotes: string;
                empty: string;
                quoteId: string;
                status: string;
                clickableRow: string;
            };
            states: {
                BUYER_DRAFT: string;
                BUYER_SUBMITTED: string;
                BUYER_ACCEPTED: string;
                BUYER_APPROVED: string;
                BUYER_REJECTED: string;
                BUYER_OFFER: string;
                BUYER_ORDERED: string;
                SELLER_DRAFT: string;
                SELLER_REQUEST: string;
                SELLER_SUBMITTED: string;
                SELLERAPPROVER_DRAFT: string;
                SELLERAPPROVER_PENDING: string;
                SELLERAPPROVER_APPROVED: string;
                SELLERAPPROVER_REJECTED: string;
                CREATED: string;
                CANCELLED: string;
                EXPIRED: string;
            };
            summary: {
                regionTitle: string;
                actions: {
                    APPROVE: string;
                    CANCEL: string;
                    CHECKOUT: string;
                    EDIT: string;
                    REJECT: string;
                    REQUOTE: string;
                    SAVE: string;
                    SUBMIT: string;
                    VIEW: string;
                };
                prices: {
                    title: string;
                    subtotal: string;
                    productDiscount: string;
                    orderDiscount: string;
                    quoteDiscount: string;
                    total: string;
                    hint: string;
                };
                sellerEdit: {
                    discount: string;
                    apply: string;
                    expiryDate: string;
                    discountValidationText: string;
                    a11y: {
                        apply: string;
                        discount: string;
                        expiryDate: string;
                    };
                };
            };
        };
    };
};

declare const es: {
    quote: {
        quote: {
            confirmDialog: {
                name: string;
                description: string;
                validity: string;
                option: {
                    yes: string;
                    no: string;
                };
                buyer: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                buyer_offer: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    checkout: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                    };
                };
                expired: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                seller: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                        successMessage: string;
                    };
                };
                sellerapprover: {
                    approve: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    reject: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                cancelled: {
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                all: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
            };
            comments: {
                regionTitle: string;
                title: string;
                invalidComment: string;
                allProducts: string;
            };
            commons: {
                requestQuote: string;
                cart: string;
                minRequestInitiationNote: string;
                savedActiveCart: string;
            };
            header: {
                buyerEdit: {
                    a11y: {
                        cancel: string;
                        save: string;
                    };
                };
                overview: {
                    regionTitle: string;
                    id: string;
                    status: string;
                    information: string;
                    name: string;
                    description: string;
                    charactersLeft: string;
                    priceAndExpiry: string;
                    estimatedTotal: string;
                    total: string;
                    expirationTime: string;
                    a11y: {
                        edit: string;
                    };
                    createdAndUpdated: string;
                    createdDate: string;
                    lastUpdatedDate: string;
                };
            };
            httpHandlers: {
                cartValidationIssue: string;
                quoteCartIssue: string;
                absoluteDiscountIssue: string;
                expirationDateIssue: string;
                threshold: {
                    underThresholdError: string;
                };
                expired: string;
                downloadPDFError: string;
            };
            items: {
                regionTitle: string;
            };
            links: {
                newCart: string;
                quotes: string;
                download: string;
                order: string;
                a11y: {
                    newCart: string;
                    quotes: string;
                    download: string;
                    order: string;
                };
            };
            list: {
                regionTitle: string;
                title: string;
                name: string;
                updated: string;
                sortBy: string;
                sortQuotes: string;
                empty: string;
                quoteId: string;
                status: string;
                clickableRow: string;
            };
            states: {
                BUYER_DRAFT: string;
                BUYER_SUBMITTED: string;
                BUYER_ACCEPTED: string;
                BUYER_APPROVED: string;
                BUYER_REJECTED: string;
                BUYER_OFFER: string;
                BUYER_ORDERED: string;
                SELLER_DRAFT: string;
                SELLER_REQUEST: string;
                SELLER_SUBMITTED: string;
                SELLERAPPROVER_DRAFT: string;
                SELLERAPPROVER_PENDING: string;
                SELLERAPPROVER_APPROVED: string;
                SELLERAPPROVER_REJECTED: string;
                CREATED: string;
                CANCELLED: string;
                EXPIRED: string;
            };
            summary: {
                regionTitle: string;
                actions: {
                    APPROVE: string;
                    CANCEL: string;
                    CHECKOUT: string;
                    EDIT: string;
                    REJECT: string;
                    REQUOTE: string;
                    SAVE: string;
                    SUBMIT: string;
                    VIEW: string;
                };
                prices: {
                    title: string;
                    subtotal: string;
                    productDiscount: string;
                    orderDiscount: string;
                    quoteDiscount: string;
                    total: string;
                    hint: string;
                };
                sellerEdit: {
                    discount: string;
                    apply: string;
                    expiryDate: string;
                    discountValidationText: string;
                    a11y: {
                        apply: string;
                        discount: string;
                        expiryDate: string;
                    };
                };
            };
        };
    };
};

declare const es_CO: {
    quote: {
        quote: {
            confirmDialog: {
                name: string;
                description: string;
                validity: string;
                option: {
                    yes: string;
                    no: string;
                };
                buyer: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                buyer_offer: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    checkout: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                    };
                };
                expired: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                seller: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                        successMessage: string;
                    };
                };
                sellerapprover: {
                    approve: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    reject: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                cancelled: {
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                all: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
            };
            comments: {
                regionTitle: string;
                title: string;
                invalidComment: string;
                allProducts: string;
            };
            commons: {
                requestQuote: string;
                cart: string;
                minRequestInitiationNote: string;
                savedActiveCart: string;
            };
            header: {
                buyerEdit: {
                    a11y: {
                        cancel: string;
                        save: string;
                    };
                };
                overview: {
                    regionTitle: string;
                    id: string;
                    status: string;
                    information: string;
                    name: string;
                    description: string;
                    charactersLeft: string;
                    priceAndExpiry: string;
                    estimatedTotal: string;
                    total: string;
                    expirationTime: string;
                    a11y: {
                        edit: string;
                    };
                    createdAndUpdated: string;
                    createdDate: string;
                    lastUpdatedDate: string;
                };
            };
            httpHandlers: {
                cartValidationIssue: string;
                quoteCartIssue: string;
                absoluteDiscountIssue: string;
                expirationDateIssue: string;
                threshold: {
                    underThresholdError: string;
                };
                expired: string;
                downloadPDFError: string;
            };
            items: {
                regionTitle: string;
            };
            links: {
                newCart: string;
                quotes: string;
                download: string;
                order: string;
                a11y: {
                    newCart: string;
                    quotes: string;
                    download: string;
                    order: string;
                };
            };
            list: {
                regionTitle: string;
                title: string;
                name: string;
                updated: string;
                sortBy: string;
                sortQuotes: string;
                empty: string;
                quoteId: string;
                status: string;
                clickableRow: string;
            };
            states: {
                BUYER_DRAFT: string;
                BUYER_SUBMITTED: string;
                BUYER_ACCEPTED: string;
                BUYER_APPROVED: string;
                BUYER_REJECTED: string;
                BUYER_OFFER: string;
                BUYER_ORDERED: string;
                SELLER_DRAFT: string;
                SELLER_REQUEST: string;
                SELLER_SUBMITTED: string;
                SELLERAPPROVER_DRAFT: string;
                SELLERAPPROVER_PENDING: string;
                SELLERAPPROVER_APPROVED: string;
                SELLERAPPROVER_REJECTED: string;
                CREATED: string;
                CANCELLED: string;
                EXPIRED: string;
            };
            summary: {
                regionTitle: string;
                actions: {
                    APPROVE: string;
                    CANCEL: string;
                    CHECKOUT: string;
                    EDIT: string;
                    REJECT: string;
                    REQUOTE: string;
                    SAVE: string;
                    SUBMIT: string;
                    VIEW: string;
                };
                prices: {
                    title: string;
                    subtotal: string;
                    productDiscount: string;
                    orderDiscount: string;
                    quoteDiscount: string;
                    total: string;
                    hint: string;
                };
                sellerEdit: {
                    discount: string;
                    apply: string;
                    expiryDate: string;
                    discountValidationText: string;
                    a11y: {
                        apply: string;
                        discount: string;
                        expiryDate: string;
                    };
                };
            };
        };
    };
};

declare const fr: {
    quote: {
        quote: {
            confirmDialog: {
                name: string;
                description: string;
                validity: string;
                option: {
                    yes: string;
                    no: string;
                };
                buyer: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                buyer_offer: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    checkout: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                    };
                };
                expired: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                seller: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                        successMessage: string;
                    };
                };
                sellerapprover: {
                    approve: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    reject: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                cancelled: {
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                all: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
            };
            comments: {
                regionTitle: string;
                title: string;
                invalidComment: string;
                allProducts: string;
            };
            commons: {
                requestQuote: string;
                cart: string;
                minRequestInitiationNote: string;
                savedActiveCart: string;
            };
            header: {
                buyerEdit: {
                    a11y: {
                        cancel: string;
                        save: string;
                    };
                };
                overview: {
                    regionTitle: string;
                    id: string;
                    status: string;
                    information: string;
                    name: string;
                    description: string;
                    charactersLeft: string;
                    priceAndExpiry: string;
                    estimatedTotal: string;
                    total: string;
                    expirationTime: string;
                    a11y: {
                        edit: string;
                    };
                    createdAndUpdated: string;
                    createdDate: string;
                    lastUpdatedDate: string;
                };
            };
            httpHandlers: {
                cartValidationIssue: string;
                quoteCartIssue: string;
                absoluteDiscountIssue: string;
                expirationDateIssue: string;
                threshold: {
                    underThresholdError: string;
                };
                expired: string;
                downloadPDFError: string;
            };
            items: {
                regionTitle: string;
            };
            links: {
                newCart: string;
                quotes: string;
                download: string;
                order: string;
                a11y: {
                    newCart: string;
                    quotes: string;
                    download: string;
                    order: string;
                };
            };
            list: {
                regionTitle: string;
                title: string;
                name: string;
                updated: string;
                sortBy: string;
                sortQuotes: string;
                empty: string;
                quoteId: string;
                status: string;
                clickableRow: string;
            };
            states: {
                BUYER_DRAFT: string;
                BUYER_SUBMITTED: string;
                BUYER_ACCEPTED: string;
                BUYER_APPROVED: string;
                BUYER_REJECTED: string;
                BUYER_OFFER: string;
                BUYER_ORDERED: string;
                SELLER_DRAFT: string;
                SELLER_REQUEST: string;
                SELLER_SUBMITTED: string;
                SELLERAPPROVER_DRAFT: string;
                SELLERAPPROVER_PENDING: string;
                SELLERAPPROVER_APPROVED: string;
                SELLERAPPROVER_REJECTED: string;
                CREATED: string;
                CANCELLED: string;
                EXPIRED: string;
            };
            summary: {
                regionTitle: string;
                actions: {
                    APPROVE: string;
                    CANCEL: string;
                    CHECKOUT: string;
                    EDIT: string;
                    REJECT: string;
                    REQUOTE: string;
                    SAVE: string;
                    SUBMIT: string;
                    VIEW: string;
                };
                prices: {
                    title: string;
                    subtotal: string;
                    productDiscount: string;
                    orderDiscount: string;
                    quoteDiscount: string;
                    total: string;
                    hint: string;
                };
                sellerEdit: {
                    discount: string;
                    apply: string;
                    expiryDate: string;
                    discountValidationText: string;
                    a11y: {
                        apply: string;
                        discount: string;
                        expiryDate: string;
                    };
                };
            };
        };
    };
};

declare const hi: {
    quote: {
        quote: {
            confirmDialog: {
                name: string;
                description: string;
                validity: string;
                option: {
                    yes: string;
                    no: string;
                };
                buyer: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                buyer_offer: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    checkout: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                    };
                };
                expired: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                seller: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                        successMessage: string;
                    };
                };
                sellerapprover: {
                    approve: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    reject: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                cancelled: {
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                all: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
            };
            comments: {
                regionTitle: string;
                title: string;
                invalidComment: string;
                allProducts: string;
            };
            commons: {
                requestQuote: string;
                cart: string;
                minRequestInitiationNote: string;
                savedActiveCart: string;
            };
            header: {
                buyerEdit: {
                    a11y: {
                        cancel: string;
                        save: string;
                    };
                };
                overview: {
                    regionTitle: string;
                    id: string;
                    status: string;
                    information: string;
                    name: string;
                    description: string;
                    charactersLeft: string;
                    priceAndExpiry: string;
                    estimatedTotal: string;
                    total: string;
                    expirationTime: string;
                    a11y: {
                        edit: string;
                    };
                    createdAndUpdated: string;
                    createdDate: string;
                    lastUpdatedDate: string;
                };
            };
            httpHandlers: {
                cartValidationIssue: string;
                quoteCartIssue: string;
                absoluteDiscountIssue: string;
                expirationDateIssue: string;
                threshold: {
                    underThresholdError: string;
                };
                expired: string;
                downloadPDFError: string;
            };
            items: {
                regionTitle: string;
            };
            links: {
                newCart: string;
                quotes: string;
                download: string;
                order: string;
                a11y: {
                    newCart: string;
                    quotes: string;
                    download: string;
                    order: string;
                };
            };
            list: {
                regionTitle: string;
                title: string;
                name: string;
                updated: string;
                sortBy: string;
                sortQuotes: string;
                empty: string;
                quoteId: string;
                status: string;
                clickableRow: string;
            };
            states: {
                BUYER_DRAFT: string;
                BUYER_SUBMITTED: string;
                BUYER_ACCEPTED: string;
                BUYER_APPROVED: string;
                BUYER_REJECTED: string;
                BUYER_OFFER: string;
                BUYER_ORDERED: string;
                SELLER_DRAFT: string;
                SELLER_REQUEST: string;
                SELLER_SUBMITTED: string;
                SELLERAPPROVER_DRAFT: string;
                SELLERAPPROVER_PENDING: string;
                SELLERAPPROVER_APPROVED: string;
                SELLERAPPROVER_REJECTED: string;
                CREATED: string;
                CANCELLED: string;
                EXPIRED: string;
            };
            summary: {
                regionTitle: string;
                actions: {
                    APPROVE: string;
                    CANCEL: string;
                    CHECKOUT: string;
                    EDIT: string;
                    REJECT: string;
                    REQUOTE: string;
                    SAVE: string;
                    SUBMIT: string;
                    VIEW: string;
                };
                prices: {
                    title: string;
                    subtotal: string;
                    productDiscount: string;
                    orderDiscount: string;
                    quoteDiscount: string;
                    total: string;
                    hint: string;
                };
                sellerEdit: {
                    discount: string;
                    apply: string;
                    expiryDate: string;
                    discountValidationText: string;
                    a11y: {
                        apply: string;
                        discount: string;
                        expiryDate: string;
                    };
                };
            };
        };
    };
};

declare const hu: {
    quote: {
        quote: {
            confirmDialog: {
                name: string;
                description: string;
                validity: string;
                option: {
                    yes: string;
                    no: string;
                };
                buyer: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                buyer_offer: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    checkout: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                    };
                };
                expired: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                seller: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                        successMessage: string;
                    };
                };
                sellerapprover: {
                    approve: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    reject: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                cancelled: {
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                all: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
            };
            comments: {
                regionTitle: string;
                title: string;
                invalidComment: string;
                allProducts: string;
            };
            commons: {
                requestQuote: string;
                cart: string;
                minRequestInitiationNote: string;
                savedActiveCart: string;
            };
            header: {
                buyerEdit: {
                    a11y: {
                        cancel: string;
                        save: string;
                    };
                };
                overview: {
                    regionTitle: string;
                    id: string;
                    status: string;
                    information: string;
                    name: string;
                    description: string;
                    charactersLeft: string;
                    priceAndExpiry: string;
                    estimatedTotal: string;
                    total: string;
                    expirationTime: string;
                    a11y: {
                        edit: string;
                    };
                    createdAndUpdated: string;
                    createdDate: string;
                    lastUpdatedDate: string;
                };
            };
            httpHandlers: {
                cartValidationIssue: string;
                quoteCartIssue: string;
                absoluteDiscountIssue: string;
                expirationDateIssue: string;
                threshold: {
                    underThresholdError: string;
                };
                expired: string;
                downloadPDFError: string;
            };
            items: {
                regionTitle: string;
            };
            links: {
                newCart: string;
                quotes: string;
                download: string;
                order: string;
                a11y: {
                    newCart: string;
                    quotes: string;
                    download: string;
                    order: string;
                };
            };
            list: {
                regionTitle: string;
                title: string;
                name: string;
                updated: string;
                sortBy: string;
                sortQuotes: string;
                empty: string;
                quoteId: string;
                status: string;
                clickableRow: string;
            };
            states: {
                BUYER_DRAFT: string;
                BUYER_SUBMITTED: string;
                BUYER_ACCEPTED: string;
                BUYER_APPROVED: string;
                BUYER_REJECTED: string;
                BUYER_OFFER: string;
                BUYER_ORDERED: string;
                SELLER_DRAFT: string;
                SELLER_REQUEST: string;
                SELLER_SUBMITTED: string;
                SELLERAPPROVER_DRAFT: string;
                SELLERAPPROVER_PENDING: string;
                SELLERAPPROVER_APPROVED: string;
                SELLERAPPROVER_REJECTED: string;
                CREATED: string;
                CANCELLED: string;
                EXPIRED: string;
            };
            summary: {
                regionTitle: string;
                actions: {
                    APPROVE: string;
                    CANCEL: string;
                    CHECKOUT: string;
                    EDIT: string;
                    REJECT: string;
                    REQUOTE: string;
                    SAVE: string;
                    SUBMIT: string;
                    VIEW: string;
                };
                prices: {
                    title: string;
                    subtotal: string;
                    productDiscount: string;
                    orderDiscount: string;
                    quoteDiscount: string;
                    total: string;
                    hint: string;
                };
                sellerEdit: {
                    discount: string;
                    apply: string;
                    expiryDate: string;
                    discountValidationText: string;
                    a11y: {
                        apply: string;
                        discount: string;
                        expiryDate: string;
                    };
                };
            };
        };
    };
};

declare const id: {
    quote: {
        quote: {
            confirmDialog: {
                name: string;
                description: string;
                validity: string;
                option: {
                    yes: string;
                    no: string;
                };
                buyer: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                buyer_offer: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    checkout: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                    };
                };
                expired: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                seller: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                        successMessage: string;
                    };
                };
                sellerapprover: {
                    approve: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    reject: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                cancelled: {
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                all: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
            };
            comments: {
                regionTitle: string;
                title: string;
                invalidComment: string;
                allProducts: string;
            };
            commons: {
                requestQuote: string;
                cart: string;
                minRequestInitiationNote: string;
                savedActiveCart: string;
            };
            header: {
                buyerEdit: {
                    a11y: {
                        cancel: string;
                        save: string;
                    };
                };
                overview: {
                    regionTitle: string;
                    id: string;
                    status: string;
                    information: string;
                    name: string;
                    description: string;
                    charactersLeft: string;
                    priceAndExpiry: string;
                    estimatedTotal: string;
                    total: string;
                    expirationTime: string;
                    a11y: {
                        edit: string;
                    };
                    createdAndUpdated: string;
                    createdDate: string;
                    lastUpdatedDate: string;
                };
            };
            httpHandlers: {
                cartValidationIssue: string;
                quoteCartIssue: string;
                absoluteDiscountIssue: string;
                expirationDateIssue: string;
                threshold: {
                    underThresholdError: string;
                };
                expired: string;
                downloadPDFError: string;
            };
            items: {
                regionTitle: string;
            };
            links: {
                newCart: string;
                quotes: string;
                download: string;
                order: string;
                a11y: {
                    newCart: string;
                    quotes: string;
                    download: string;
                    order: string;
                };
            };
            list: {
                regionTitle: string;
                title: string;
                name: string;
                updated: string;
                sortBy: string;
                sortQuotes: string;
                empty: string;
                quoteId: string;
                status: string;
                clickableRow: string;
            };
            states: {
                BUYER_DRAFT: string;
                BUYER_SUBMITTED: string;
                BUYER_ACCEPTED: string;
                BUYER_APPROVED: string;
                BUYER_REJECTED: string;
                BUYER_OFFER: string;
                BUYER_ORDERED: string;
                SELLER_DRAFT: string;
                SELLER_REQUEST: string;
                SELLER_SUBMITTED: string;
                SELLERAPPROVER_DRAFT: string;
                SELLERAPPROVER_PENDING: string;
                SELLERAPPROVER_APPROVED: string;
                SELLERAPPROVER_REJECTED: string;
                CREATED: string;
                CANCELLED: string;
                EXPIRED: string;
            };
            summary: {
                regionTitle: string;
                actions: {
                    APPROVE: string;
                    CANCEL: string;
                    CHECKOUT: string;
                    EDIT: string;
                    REJECT: string;
                    REQUOTE: string;
                    SAVE: string;
                    SUBMIT: string;
                    VIEW: string;
                };
                prices: {
                    title: string;
                    subtotal: string;
                    productDiscount: string;
                    orderDiscount: string;
                    quoteDiscount: string;
                    total: string;
                    hint: string;
                };
                sellerEdit: {
                    discount: string;
                    apply: string;
                    expiryDate: string;
                    discountValidationText: string;
                    a11y: {
                        apply: string;
                        discount: string;
                        expiryDate: string;
                    };
                };
            };
        };
    };
};

declare const it: {
    quote: {
        quote: {
            confirmDialog: {
                name: string;
                description: string;
                validity: string;
                option: {
                    yes: string;
                    no: string;
                };
                buyer: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                buyer_offer: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    checkout: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                    };
                };
                expired: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                seller: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                        successMessage: string;
                    };
                };
                sellerapprover: {
                    approve: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    reject: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                cancelled: {
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                all: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
            };
            comments: {
                regionTitle: string;
                title: string;
                invalidComment: string;
                allProducts: string;
            };
            commons: {
                requestQuote: string;
                cart: string;
                minRequestInitiationNote: string;
                savedActiveCart: string;
            };
            header: {
                buyerEdit: {
                    a11y: {
                        cancel: string;
                        save: string;
                    };
                };
                overview: {
                    regionTitle: string;
                    id: string;
                    status: string;
                    information: string;
                    name: string;
                    description: string;
                    charactersLeft: string;
                    priceAndExpiry: string;
                    estimatedTotal: string;
                    total: string;
                    expirationTime: string;
                    a11y: {
                        edit: string;
                    };
                    createdAndUpdated: string;
                    createdDate: string;
                    lastUpdatedDate: string;
                };
            };
            httpHandlers: {
                cartValidationIssue: string;
                quoteCartIssue: string;
                absoluteDiscountIssue: string;
                expirationDateIssue: string;
                threshold: {
                    underThresholdError: string;
                };
                expired: string;
                downloadPDFError: string;
            };
            items: {
                regionTitle: string;
            };
            links: {
                newCart: string;
                quotes: string;
                download: string;
                order: string;
                a11y: {
                    newCart: string;
                    quotes: string;
                    download: string;
                    order: string;
                };
            };
            list: {
                regionTitle: string;
                title: string;
                name: string;
                updated: string;
                sortBy: string;
                sortQuotes: string;
                empty: string;
                quoteId: string;
                status: string;
                clickableRow: string;
            };
            states: {
                BUYER_DRAFT: string;
                BUYER_SUBMITTED: string;
                BUYER_ACCEPTED: string;
                BUYER_APPROVED: string;
                BUYER_REJECTED: string;
                BUYER_OFFER: string;
                BUYER_ORDERED: string;
                SELLER_DRAFT: string;
                SELLER_REQUEST: string;
                SELLER_SUBMITTED: string;
                SELLERAPPROVER_DRAFT: string;
                SELLERAPPROVER_PENDING: string;
                SELLERAPPROVER_APPROVED: string;
                SELLERAPPROVER_REJECTED: string;
                CREATED: string;
                CANCELLED: string;
                EXPIRED: string;
            };
            summary: {
                regionTitle: string;
                actions: {
                    APPROVE: string;
                    CANCEL: string;
                    CHECKOUT: string;
                    EDIT: string;
                    REJECT: string;
                    REQUOTE: string;
                    SAVE: string;
                    SUBMIT: string;
                    VIEW: string;
                };
                prices: {
                    title: string;
                    subtotal: string;
                    productDiscount: string;
                    orderDiscount: string;
                    quoteDiscount: string;
                    total: string;
                    hint: string;
                };
                sellerEdit: {
                    discount: string;
                    apply: string;
                    expiryDate: string;
                    discountValidationText: string;
                    a11y: {
                        apply: string;
                        discount: string;
                        expiryDate: string;
                    };
                };
            };
        };
    };
};

declare const ja: {
    quote: {
        quote: {
            confirmDialog: {
                name: string;
                description: string;
                validity: string;
                option: {
                    yes: string;
                    no: string;
                };
                buyer: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                buyer_offer: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    checkout: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                    };
                };
                expired: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                seller: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                        successMessage: string;
                    };
                };
                sellerapprover: {
                    approve: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    reject: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                cancelled: {
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                all: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
            };
            comments: {
                regionTitle: string;
                title: string;
                invalidComment: string;
                allProducts: string;
            };
            commons: {
                requestQuote: string;
                cart: string;
                minRequestInitiationNote: string;
                savedActiveCart: string;
            };
            header: {
                buyerEdit: {
                    a11y: {
                        cancel: string;
                        save: string;
                    };
                };
                overview: {
                    regionTitle: string;
                    id: string;
                    status: string;
                    information: string;
                    name: string;
                    description: string;
                    charactersLeft: string;
                    priceAndExpiry: string;
                    estimatedTotal: string;
                    total: string;
                    expirationTime: string;
                    a11y: {
                        edit: string;
                    };
                    createdAndUpdated: string;
                    createdDate: string;
                    lastUpdatedDate: string;
                };
            };
            httpHandlers: {
                cartValidationIssue: string;
                quoteCartIssue: string;
                absoluteDiscountIssue: string;
                expirationDateIssue: string;
                threshold: {
                    underThresholdError: string;
                };
                expired: string;
                downloadPDFError: string;
            };
            items: {
                regionTitle: string;
            };
            links: {
                newCart: string;
                quotes: string;
                download: string;
                order: string;
                a11y: {
                    newCart: string;
                    quotes: string;
                    download: string;
                    order: string;
                };
            };
            list: {
                regionTitle: string;
                title: string;
                name: string;
                updated: string;
                sortBy: string;
                sortQuotes: string;
                empty: string;
                quoteId: string;
                status: string;
                clickableRow: string;
            };
            states: {
                BUYER_DRAFT: string;
                BUYER_SUBMITTED: string;
                BUYER_ACCEPTED: string;
                BUYER_APPROVED: string;
                BUYER_REJECTED: string;
                BUYER_OFFER: string;
                BUYER_ORDERED: string;
                SELLER_DRAFT: string;
                SELLER_REQUEST: string;
                SELLER_SUBMITTED: string;
                SELLERAPPROVER_DRAFT: string;
                SELLERAPPROVER_PENDING: string;
                SELLERAPPROVER_APPROVED: string;
                SELLERAPPROVER_REJECTED: string;
                CREATED: string;
                CANCELLED: string;
                EXPIRED: string;
            };
            summary: {
                regionTitle: string;
                actions: {
                    APPROVE: string;
                    CANCEL: string;
                    CHECKOUT: string;
                    EDIT: string;
                    REJECT: string;
                    REQUOTE: string;
                    SAVE: string;
                    SUBMIT: string;
                    VIEW: string;
                };
                prices: {
                    title: string;
                    subtotal: string;
                    productDiscount: string;
                    orderDiscount: string;
                    quoteDiscount: string;
                    total: string;
                    hint: string;
                };
                sellerEdit: {
                    discount: string;
                    apply: string;
                    expiryDate: string;
                    discountValidationText: string;
                    a11y: {
                        apply: string;
                        discount: string;
                        expiryDate: string;
                    };
                };
            };
        };
    };
};

declare const ko: {
    quote: {
        quote: {
            confirmDialog: {
                name: string;
                description: string;
                validity: string;
                option: {
                    yes: string;
                    no: string;
                };
                buyer: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                buyer_offer: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    checkout: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                    };
                };
                expired: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                seller: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                        successMessage: string;
                    };
                };
                sellerapprover: {
                    approve: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    reject: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                cancelled: {
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                all: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
            };
            comments: {
                regionTitle: string;
                title: string;
                invalidComment: string;
                allProducts: string;
            };
            commons: {
                requestQuote: string;
                cart: string;
                minRequestInitiationNote: string;
                savedActiveCart: string;
            };
            header: {
                buyerEdit: {
                    a11y: {
                        cancel: string;
                        save: string;
                    };
                };
                overview: {
                    regionTitle: string;
                    id: string;
                    status: string;
                    information: string;
                    name: string;
                    description: string;
                    charactersLeft: string;
                    priceAndExpiry: string;
                    estimatedTotal: string;
                    total: string;
                    expirationTime: string;
                    a11y: {
                        edit: string;
                    };
                    createdAndUpdated: string;
                    createdDate: string;
                    lastUpdatedDate: string;
                };
            };
            httpHandlers: {
                cartValidationIssue: string;
                quoteCartIssue: string;
                absoluteDiscountIssue: string;
                expirationDateIssue: string;
                threshold: {
                    underThresholdError: string;
                };
                expired: string;
                downloadPDFError: string;
            };
            items: {
                regionTitle: string;
            };
            links: {
                newCart: string;
                quotes: string;
                download: string;
                order: string;
                a11y: {
                    newCart: string;
                    quotes: string;
                    download: string;
                    order: string;
                };
            };
            list: {
                regionTitle: string;
                title: string;
                name: string;
                updated: string;
                sortBy: string;
                sortQuotes: string;
                empty: string;
                quoteId: string;
                status: string;
                clickableRow: string;
            };
            states: {
                BUYER_DRAFT: string;
                BUYER_SUBMITTED: string;
                BUYER_ACCEPTED: string;
                BUYER_APPROVED: string;
                BUYER_REJECTED: string;
                BUYER_OFFER: string;
                BUYER_ORDERED: string;
                SELLER_DRAFT: string;
                SELLER_REQUEST: string;
                SELLER_SUBMITTED: string;
                SELLERAPPROVER_DRAFT: string;
                SELLERAPPROVER_PENDING: string;
                SELLERAPPROVER_APPROVED: string;
                SELLERAPPROVER_REJECTED: string;
                CREATED: string;
                CANCELLED: string;
                EXPIRED: string;
            };
            summary: {
                regionTitle: string;
                actions: {
                    APPROVE: string;
                    CANCEL: string;
                    CHECKOUT: string;
                    EDIT: string;
                    REJECT: string;
                    REQUOTE: string;
                    SAVE: string;
                    SUBMIT: string;
                    VIEW: string;
                };
                prices: {
                    title: string;
                    subtotal: string;
                    productDiscount: string;
                    orderDiscount: string;
                    quoteDiscount: string;
                    total: string;
                    hint: string;
                };
                sellerEdit: {
                    discount: string;
                    apply: string;
                    expiryDate: string;
                    discountValidationText: string;
                    a11y: {
                        apply: string;
                        discount: string;
                        expiryDate: string;
                    };
                };
            };
        };
    };
};

declare const pl: {
    quote: {
        quote: {
            confirmDialog: {
                name: string;
                description: string;
                validity: string;
                option: {
                    yes: string;
                    no: string;
                };
                buyer: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                buyer_offer: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    checkout: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                    };
                };
                expired: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                seller: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                        successMessage: string;
                    };
                };
                sellerapprover: {
                    approve: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    reject: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                cancelled: {
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                all: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
            };
            comments: {
                regionTitle: string;
                title: string;
                invalidComment: string;
                allProducts: string;
            };
            commons: {
                requestQuote: string;
                cart: string;
                minRequestInitiationNote: string;
                savedActiveCart: string;
            };
            header: {
                buyerEdit: {
                    a11y: {
                        cancel: string;
                        save: string;
                    };
                };
                overview: {
                    regionTitle: string;
                    id: string;
                    status: string;
                    information: string;
                    name: string;
                    description: string;
                    charactersLeft: string;
                    priceAndExpiry: string;
                    estimatedTotal: string;
                    total: string;
                    expirationTime: string;
                    a11y: {
                        edit: string;
                    };
                    createdAndUpdated: string;
                    createdDate: string;
                    lastUpdatedDate: string;
                };
            };
            httpHandlers: {
                cartValidationIssue: string;
                quoteCartIssue: string;
                absoluteDiscountIssue: string;
                expirationDateIssue: string;
                threshold: {
                    underThresholdError: string;
                };
                expired: string;
                downloadPDFError: string;
            };
            items: {
                regionTitle: string;
            };
            links: {
                newCart: string;
                quotes: string;
                download: string;
                order: string;
                a11y: {
                    newCart: string;
                    quotes: string;
                    download: string;
                    order: string;
                };
            };
            list: {
                regionTitle: string;
                title: string;
                name: string;
                updated: string;
                sortBy: string;
                sortQuotes: string;
                empty: string;
                quoteId: string;
                status: string;
                clickableRow: string;
            };
            states: {
                BUYER_DRAFT: string;
                BUYER_SUBMITTED: string;
                BUYER_ACCEPTED: string;
                BUYER_APPROVED: string;
                BUYER_REJECTED: string;
                BUYER_OFFER: string;
                BUYER_ORDERED: string;
                SELLER_DRAFT: string;
                SELLER_REQUEST: string;
                SELLER_SUBMITTED: string;
                SELLERAPPROVER_DRAFT: string;
                SELLERAPPROVER_PENDING: string;
                SELLERAPPROVER_APPROVED: string;
                SELLERAPPROVER_REJECTED: string;
                CREATED: string;
                CANCELLED: string;
                EXPIRED: string;
            };
            summary: {
                regionTitle: string;
                actions: {
                    APPROVE: string;
                    CANCEL: string;
                    CHECKOUT: string;
                    EDIT: string;
                    REJECT: string;
                    REQUOTE: string;
                    SAVE: string;
                    SUBMIT: string;
                    VIEW: string;
                };
                prices: {
                    title: string;
                    subtotal: string;
                    productDiscount: string;
                    orderDiscount: string;
                    quoteDiscount: string;
                    total: string;
                    hint: string;
                };
                sellerEdit: {
                    discount: string;
                    apply: string;
                    expiryDate: string;
                    discountValidationText: string;
                    a11y: {
                        apply: string;
                        discount: string;
                        expiryDate: string;
                    };
                };
            };
        };
    };
};

declare const pt: {
    quote: {
        quote: {
            confirmDialog: {
                name: string;
                description: string;
                validity: string;
                option: {
                    yes: string;
                    no: string;
                };
                buyer: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                buyer_offer: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    checkout: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                    };
                };
                expired: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                seller: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                        successMessage: string;
                    };
                };
                sellerapprover: {
                    approve: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    reject: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                cancelled: {
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                all: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
            };
            comments: {
                regionTitle: string;
                title: string;
                invalidComment: string;
                allProducts: string;
            };
            commons: {
                requestQuote: string;
                cart: string;
                minRequestInitiationNote: string;
                savedActiveCart: string;
            };
            header: {
                buyerEdit: {
                    a11y: {
                        cancel: string;
                        save: string;
                    };
                };
                overview: {
                    regionTitle: string;
                    id: string;
                    status: string;
                    information: string;
                    name: string;
                    description: string;
                    charactersLeft: string;
                    priceAndExpiry: string;
                    estimatedTotal: string;
                    total: string;
                    expirationTime: string;
                    a11y: {
                        edit: string;
                    };
                    createdAndUpdated: string;
                    createdDate: string;
                    lastUpdatedDate: string;
                };
            };
            httpHandlers: {
                cartValidationIssue: string;
                quoteCartIssue: string;
                absoluteDiscountIssue: string;
                expirationDateIssue: string;
                threshold: {
                    underThresholdError: string;
                };
                expired: string;
                downloadPDFError: string;
            };
            items: {
                regionTitle: string;
            };
            links: {
                newCart: string;
                quotes: string;
                download: string;
                order: string;
                a11y: {
                    newCart: string;
                    quotes: string;
                    download: string;
                    order: string;
                };
            };
            list: {
                regionTitle: string;
                title: string;
                name: string;
                updated: string;
                sortBy: string;
                sortQuotes: string;
                empty: string;
                quoteId: string;
                status: string;
                clickableRow: string;
            };
            states: {
                BUYER_DRAFT: string;
                BUYER_SUBMITTED: string;
                BUYER_ACCEPTED: string;
                BUYER_APPROVED: string;
                BUYER_REJECTED: string;
                BUYER_OFFER: string;
                BUYER_ORDERED: string;
                SELLER_DRAFT: string;
                SELLER_REQUEST: string;
                SELLER_SUBMITTED: string;
                SELLERAPPROVER_DRAFT: string;
                SELLERAPPROVER_PENDING: string;
                SELLERAPPROVER_APPROVED: string;
                SELLERAPPROVER_REJECTED: string;
                CREATED: string;
                CANCELLED: string;
                EXPIRED: string;
            };
            summary: {
                regionTitle: string;
                actions: {
                    APPROVE: string;
                    CANCEL: string;
                    CHECKOUT: string;
                    EDIT: string;
                    REJECT: string;
                    REQUOTE: string;
                    SAVE: string;
                    SUBMIT: string;
                    VIEW: string;
                };
                prices: {
                    title: string;
                    subtotal: string;
                    productDiscount: string;
                    orderDiscount: string;
                    quoteDiscount: string;
                    total: string;
                    hint: string;
                };
                sellerEdit: {
                    discount: string;
                    apply: string;
                    expiryDate: string;
                    discountValidationText: string;
                    a11y: {
                        apply: string;
                        discount: string;
                        expiryDate: string;
                    };
                };
            };
        };
    };
};

declare const ru: {
    quote: {
        quote: {
            confirmDialog: {
                name: string;
                description: string;
                validity: string;
                option: {
                    yes: string;
                    no: string;
                };
                buyer: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                buyer_offer: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    checkout: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                    };
                };
                expired: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                seller: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                        successMessage: string;
                    };
                };
                sellerapprover: {
                    approve: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    reject: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                cancelled: {
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                all: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
            };
            comments: {
                regionTitle: string;
                title: string;
                invalidComment: string;
                allProducts: string;
            };
            commons: {
                requestQuote: string;
                cart: string;
                minRequestInitiationNote: string;
                savedActiveCart: string;
            };
            header: {
                buyerEdit: {
                    a11y: {
                        cancel: string;
                        save: string;
                    };
                };
                overview: {
                    regionTitle: string;
                    id: string;
                    status: string;
                    information: string;
                    name: string;
                    description: string;
                    charactersLeft: string;
                    priceAndExpiry: string;
                    estimatedTotal: string;
                    total: string;
                    expirationTime: string;
                    a11y: {
                        edit: string;
                    };
                    createdAndUpdated: string;
                    createdDate: string;
                    lastUpdatedDate: string;
                };
            };
            httpHandlers: {
                cartValidationIssue: string;
                quoteCartIssue: string;
                absoluteDiscountIssue: string;
                expirationDateIssue: string;
                threshold: {
                    underThresholdError: string;
                };
                expired: string;
                downloadPDFError: string;
            };
            items: {
                regionTitle: string;
            };
            links: {
                newCart: string;
                quotes: string;
                download: string;
                order: string;
                a11y: {
                    newCart: string;
                    quotes: string;
                    download: string;
                    order: string;
                };
            };
            list: {
                regionTitle: string;
                title: string;
                name: string;
                updated: string;
                sortBy: string;
                sortQuotes: string;
                empty: string;
                quoteId: string;
                status: string;
                clickableRow: string;
            };
            states: {
                BUYER_DRAFT: string;
                BUYER_SUBMITTED: string;
                BUYER_ACCEPTED: string;
                BUYER_APPROVED: string;
                BUYER_REJECTED: string;
                BUYER_OFFER: string;
                BUYER_ORDERED: string;
                SELLER_DRAFT: string;
                SELLER_REQUEST: string;
                SELLER_SUBMITTED: string;
                SELLERAPPROVER_DRAFT: string;
                SELLERAPPROVER_PENDING: string;
                SELLERAPPROVER_APPROVED: string;
                SELLERAPPROVER_REJECTED: string;
                CREATED: string;
                CANCELLED: string;
                EXPIRED: string;
            };
            summary: {
                regionTitle: string;
                actions: {
                    APPROVE: string;
                    CANCEL: string;
                    CHECKOUT: string;
                    EDIT: string;
                    REJECT: string;
                    REQUOTE: string;
                    SAVE: string;
                    SUBMIT: string;
                    VIEW: string;
                };
                prices: {
                    title: string;
                    subtotal: string;
                    productDiscount: string;
                    orderDiscount: string;
                    quoteDiscount: string;
                    total: string;
                    hint: string;
                };
                sellerEdit: {
                    discount: string;
                    apply: string;
                    expiryDate: string;
                    discountValidationText: string;
                    a11y: {
                        apply: string;
                        discount: string;
                        expiryDate: string;
                    };
                };
            };
        };
    };
};

declare const zh: {
    quote: {
        quote: {
            confirmDialog: {
                name: string;
                description: string;
                validity: string;
                option: {
                    yes: string;
                    no: string;
                };
                buyer: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                buyer_offer: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    checkout: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                    };
                };
                expired: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                seller: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                        successMessage: string;
                    };
                };
                sellerapprover: {
                    approve: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    reject: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                cancelled: {
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                all: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
            };
            comments: {
                regionTitle: string;
                title: string;
                invalidComment: string;
                allProducts: string;
            };
            commons: {
                requestQuote: string;
                cart: string;
                minRequestInitiationNote: string;
                savedActiveCart: string;
            };
            header: {
                buyerEdit: {
                    a11y: {
                        cancel: string;
                        save: string;
                    };
                };
                overview: {
                    regionTitle: string;
                    id: string;
                    status: string;
                    information: string;
                    name: string;
                    description: string;
                    charactersLeft: string;
                    priceAndExpiry: string;
                    estimatedTotal: string;
                    total: string;
                    expirationTime: string;
                    a11y: {
                        edit: string;
                    };
                    createdAndUpdated: string;
                    createdDate: string;
                    lastUpdatedDate: string;
                };
            };
            httpHandlers: {
                cartValidationIssue: string;
                quoteCartIssue: string;
                absoluteDiscountIssue: string;
                expirationDateIssue: string;
                threshold: {
                    underThresholdError: string;
                };
                expired: string;
                downloadPDFError: string;
            };
            items: {
                regionTitle: string;
            };
            links: {
                newCart: string;
                quotes: string;
                download: string;
                order: string;
                a11y: {
                    newCart: string;
                    quotes: string;
                    download: string;
                    order: string;
                };
            };
            list: {
                regionTitle: string;
                title: string;
                name: string;
                updated: string;
                sortBy: string;
                sortQuotes: string;
                empty: string;
                quoteId: string;
                status: string;
                clickableRow: string;
            };
            states: {
                BUYER_DRAFT: string;
                BUYER_SUBMITTED: string;
                BUYER_ACCEPTED: string;
                BUYER_APPROVED: string;
                BUYER_REJECTED: string;
                BUYER_OFFER: string;
                BUYER_ORDERED: string;
                SELLER_DRAFT: string;
                SELLER_REQUEST: string;
                SELLER_SUBMITTED: string;
                SELLERAPPROVER_DRAFT: string;
                SELLERAPPROVER_PENDING: string;
                SELLERAPPROVER_APPROVED: string;
                SELLERAPPROVER_REJECTED: string;
                CREATED: string;
                CANCELLED: string;
                EXPIRED: string;
            };
            summary: {
                regionTitle: string;
                actions: {
                    APPROVE: string;
                    CANCEL: string;
                    CHECKOUT: string;
                    EDIT: string;
                    REJECT: string;
                    REQUOTE: string;
                    SAVE: string;
                    SUBMIT: string;
                    VIEW: string;
                };
                prices: {
                    title: string;
                    subtotal: string;
                    productDiscount: string;
                    orderDiscount: string;
                    quoteDiscount: string;
                    total: string;
                    hint: string;
                };
                sellerEdit: {
                    discount: string;
                    apply: string;
                    expiryDate: string;
                    discountValidationText: string;
                    a11y: {
                        apply: string;
                        discount: string;
                        expiryDate: string;
                    };
                };
            };
        };
    };
};

declare const zh_TW: {
    quote: {
        quote: {
            confirmDialog: {
                name: string;
                description: string;
                validity: string;
                option: {
                    yes: string;
                    no: string;
                };
                buyer: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                buyer_offer: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    cancel: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    checkout: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                    };
                };
                expired: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                seller: {
                    submit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                        successMessage: string;
                    };
                };
                sellerapprover: {
                    approve: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                    reject: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        successMessage: string;
                    };
                };
                cancelled: {
                    requote: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
                all: {
                    edit: {
                        a11y: {
                            close: string;
                        };
                        title: string;
                        confirmNote: string;
                        warningNote: string;
                    };
                };
            };
            comments: {
                regionTitle: string;
                title: string;
                invalidComment: string;
                allProducts: string;
            };
            commons: {
                requestQuote: string;
                cart: string;
                minRequestInitiationNote: string;
                savedActiveCart: string;
            };
            header: {
                buyerEdit: {
                    a11y: {
                        cancel: string;
                        save: string;
                    };
                };
                overview: {
                    regionTitle: string;
                    id: string;
                    status: string;
                    information: string;
                    name: string;
                    description: string;
                    charactersLeft: string;
                    priceAndExpiry: string;
                    estimatedTotal: string;
                    total: string;
                    expirationTime: string;
                    a11y: {
                        edit: string;
                    };
                    createdAndUpdated: string;
                    createdDate: string;
                    lastUpdatedDate: string;
                };
            };
            httpHandlers: {
                cartValidationIssue: string;
                quoteCartIssue: string;
                absoluteDiscountIssue: string;
                expirationDateIssue: string;
                threshold: {
                    underThresholdError: string;
                };
                expired: string;
                downloadPDFError: string;
            };
            items: {
                regionTitle: string;
            };
            links: {
                newCart: string;
                quotes: string;
                download: string;
                order: string;
                a11y: {
                    newCart: string;
                    quotes: string;
                    download: string;
                    order: string;
                };
            };
            list: {
                regionTitle: string;
                title: string;
                name: string;
                updated: string;
                sortBy: string;
                sortQuotes: string;
                empty: string;
                quoteId: string;
                status: string;
                clickableRow: string;
            };
            states: {
                BUYER_DRAFT: string;
                BUYER_SUBMITTED: string;
                BUYER_ACCEPTED: string;
                BUYER_APPROVED: string;
                BUYER_REJECTED: string;
                BUYER_OFFER: string;
                BUYER_ORDERED: string;
                SELLER_DRAFT: string;
                SELLER_REQUEST: string;
                SELLER_SUBMITTED: string;
                SELLERAPPROVER_DRAFT: string;
                SELLERAPPROVER_PENDING: string;
                SELLERAPPROVER_APPROVED: string;
                SELLERAPPROVER_REJECTED: string;
                CREATED: string;
                CANCELLED: string;
                EXPIRED: string;
            };
            summary: {
                regionTitle: string;
                actions: {
                    APPROVE: string;
                    CANCEL: string;
                    CHECKOUT: string;
                    EDIT: string;
                    REJECT: string;
                    REQUOTE: string;
                    SAVE: string;
                    SUBMIT: string;
                    VIEW: string;
                };
                prices: {
                    title: string;
                    subtotal: string;
                    productDiscount: string;
                    orderDiscount: string;
                    quoteDiscount: string;
                    total: string;
                    hint: string;
                };
                sellerEdit: {
                    discount: string;
                    apply: string;
                    expiryDate: string;
                    discountValidationText: string;
                    a11y: {
                        apply: string;
                        discount: string;
                        expiryDate: string;
                    };
                };
            };
        };
    };
};

declare const quoteTranslationChunksConfig: TranslationChunksConfig;

export { quoteTranslationChunksConfig, cs as quoteTranslationsCs, de as quoteTranslationsDe, en as quoteTranslationsEn, es as quoteTranslationsEs, es_CO as quoteTranslationsEs_CO, fr as quoteTranslationsFr, hi as quoteTranslationsHi, hu as quoteTranslationsHu, id as quoteTranslationsId, it as quoteTranslationsIt, ja as quoteTranslationsJa, ko as quoteTranslationsKo, pl as quoteTranslationsPl, pt as quoteTranslationsPt, ru as quoteTranslationsRu, zh as quoteTranslationsZh, zh_TW as quoteTranslationsZh_TW };
