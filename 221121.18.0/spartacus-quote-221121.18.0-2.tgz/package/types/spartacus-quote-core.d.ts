import { QuoteActionType, QuoteActionsByState, QuoteList, QuoteStarter, Quote, QuoteMetadata, QuoteComment, QuoteDiscount, OccQuote, QuoteFacade, QuotesStateParams } from '@spartacus/quote/root';
import * as i0 from '@angular/core';
import { InjectionToken, OnDestroy } from '@angular/core';
import { PaginationModel, Converter, EventService, CxEvent, UserIdService, RoutingService, WindowRef, AuthService, QueryService, CommandService, GlobalMessageService, Command, HttpErrorModel, Query, QueryState } from '@spartacus/core';
import { Observable, Subscription, BehaviorSubject } from 'rxjs';
import { ActiveCartFacade, MultiCartFacade, Cart } from '@spartacus/cart/base/root';
import { SavedCartFacade } from '@spartacus/cart/saved-cart/root';
import { ViewConfig } from '@spartacus/storefront';

interface QuoteActionsConfig {
    /** Actions that should be presented in template as primary */
    primaryActions?: QuoteActionType[];
    /** Order of action rendering based on quote state */
    actionsOrderByState?: Partial<QuoteActionsByState>;
}
declare abstract class QuoteCoreConfig {
    /**
     * Commerce quotes config
     */
    quote?: {
        actions?: QuoteActionsConfig;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteCoreConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuoteCoreConfig>;
}
declare module '@spartacus/core' {
    interface Config extends QuoteCoreConfig {
    }
}

declare abstract class QuoteAdapter {
    /**
     * Fetches a list of quotes.
     *
     * @param userId - Quote user
     * @param pagination - Pagination options
     * @returns Observable emitting a quote list
     */
    abstract getQuotes(userId: string, pagination: PaginationModel): Observable<QuoteList>;
    /**
     * Creates a quote.
     *
     * @param userId - Quote user
     * @param quoteStarter - Attributes needed to create a quote
     * @returns Observable emitting a quote
     */
    abstract createQuote(userId: string, quoteStarter: QuoteStarter): Observable<Quote>;
    /**
     * Fetches a quote specified by its ID (aka code).
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code
     * @returns Observable emitting a quote
     */
    abstract getQuote(userId: string, quoteCode: string): Observable<Quote>;
    /**
     * Edits a quote in its main header aspects (name, description and expiry date).
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code, identifies a quote uniquely for a given user role
     * @param quoteMetadata - Attributes that are going to be changed
     * @returns Observable emitting unknown
     */
    abstract editQuote(userId: string, quoteCode: string, quoteMetadata: QuoteMetadata): Observable<unknown>;
    /**
     * Triggers an action on a quote identified by its code.
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code, identifies a quote uniquely for a given user role
     * @param quoteAction - Quote action
     * @returns Observable emitting unknown
     */
    abstract performQuoteAction(userId: string, quoteCode: string, quoteAction: QuoteActionType): Observable<unknown>;
    /**
     * Adds a header comment to a quote.
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code
     * @param quoteComment - Quote comment
     * @returns Observable emitting unknown
     */
    abstract addComment(userId: string, quoteCode: string, quoteComment: QuoteComment): Observable<unknown>;
    /**
     * Adds a discount to a quote. A previous discount will be overwritten.
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code
     * @param discount - Quote discount
     * @returns Observable emitting unknown
     */
    abstract addDiscount(userId: string, quoteCode: string, discount: QuoteDiscount): Observable<unknown>;
    /**
     * Adds an entry comment to a quote.
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code
     * @param entryNumber - Quote entry number
     * @param comment - Quote comment
     * @returns Observable emitting unknown
     */
    abstract addQuoteEntryComment(userId: string, quoteCode: string, entryNumber: string, comment: QuoteComment): Observable<unknown>;
    /**
     * Downloads the proposal document associated with a quote.
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code
     * @param attachmentId - Attachment ID
     * @returns Observable emitting a Blob response
     */
    abstract downloadAttachment(userId: string, quoteCode: string, attachmentId: string): Observable<Blob>;
}

declare class QuoteConnector {
    protected quoteAdapter: QuoteAdapter;
    /**
     * Fetches a list of quotes according to the pagination provided.
     *
     * @param userId - Quote user
     * @param pagination - Pagination attributes
     * @returns Observable emitting a quote list
     */
    getQuotes(userId: string, pagination: PaginationModel): Observable<QuoteList>;
    /**
     * Creates a quote.
     *
     * @param userId - Quote user
     * @param quoteStarter - Attributes needed to create a quote
     * @returns Observable emitting a quote
     */
    createQuote(userId: string, quoteStarter: QuoteStarter): Observable<Quote>;
    /**
     * Fetches a quote specified by its ID (aka code).
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code
     * @returns Observable emitting a quote
     */
    getQuote(userId: string, quoteCode: string): Observable<Quote>;
    /**
     * Edits a quote in its main header aspects (name, description and expiry date).
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code, identifies a quote uniquely for a given user role
     * @param quoteMetadata - Attributes that are going to be changed
     * @returns Observable emitting unknown
     */
    editQuote(userId: string, quoteCode: string, quoteMetadata: QuoteMetadata): Observable<unknown>;
    /**
     * Triggers an action on a quote identified by its code.
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code, identifies a quote for a given user role
     * @param quoteAction - Quote action
     * @returns Observable emitting unknown
     */
    performQuoteAction(userId: string, quoteCode: string, quoteAction: QuoteActionType): Observable<unknown>;
    /**
     * Adds a header comment to a quote.
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code
     * @param quoteComment - Quote comment
     * @returns Observable emitting unknown
     */
    addComment(userId: string, quoteCode: string, quoteComment: QuoteComment): Observable<unknown>;
    /**
     * Adds a discount to a quote. A previous discount will be overwritten.
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code
     * @param discount - Quote discount
     * @returns Observable emitting unknown
     */
    addDiscount(userId: string, quoteCode: string, discount: QuoteDiscount): Observable<unknown>;
    /**
     * Adds an entry comment to a quote.
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code
     * @param entryNumber - Quote entry number
     * @param comment - Quote comment
     * @returns Observable emitting unknown
     */
    addQuoteEntryComment(userId: string, quoteCode: string, entryNumber: string, comment: QuoteComment): Observable<unknown>;
    /**
     * Downloads the proposal document associated with a quote.
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code
     * @param attachmentId - Attachment ID
     * @returns Observable emitting a Blob response
     */
    downloadAttachment(userId: string, quoteCode: string, attachmentId: string): Observable<Blob>;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuoteConnector>;
}

declare const QUOTE_NORMALIZER: InjectionToken<Converter<OccQuote, Quote>>;
declare const QUOTE_LIST_NORMALIZER: InjectionToken<Converter<any, QuoteList>>;
declare const QUOTE_STARTER_SERIALIZER: InjectionToken<Converter<any, QuoteStarter>>;
declare const QUOTE_METADATA_SERIALIZER: InjectionToken<Converter<any, QuoteMetadata>>;
declare const QUOTE_ACTION_SERIALIZER: InjectionToken<Converter<any, QuoteActionType>>;
declare const QUOTE_COMMENT_SERIALIZER: InjectionToken<Converter<any, QuoteComment>>;
declare const QUOTE_DISCOUNT_SERIALIZER: InjectionToken<Converter<any, QuoteDiscount>>;

declare class QuoteCartEventListener implements OnDestroy {
    protected eventService: EventService;
    protected subscription: Subscription;
    constructor();
    protected listenToCartEvents(): void;
    protected triggerQuoteReload(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteCartEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuoteCartEventListener>;
}

declare class QuoteDetailsReloadQueryEvent extends CxEvent {
    /**
     * Event's type
     */
    static readonly type = "QuoteDetailsReloadQueryEvent";
}

declare class QuoteCartService {
    protected activeCartFacade: ActiveCartFacade;
    private checkoutAllowed;
    private checkoutAllowedAsObservable;
    constructor();
    /**
     * Returns a quote ID.
     *
     * @returns Observable emitting string or unknown
     */
    getQuoteId(): Observable<string | undefined>;
    /**
     * Verifies if a quote cart is active.
     *
     * @returns Observable emitting boolean
     */
    isQuoteCartActive(): Observable<boolean>;
    /**
     * Defines whether the checkout is allowed.
     *
     * @param checkoutAllowed - is checkout allowed
     */
    setCheckoutAllowed(checkoutAllowed: boolean): void;
    /**
     * Verifies if the checkout is allowed.
     *
     * @returns Observable emitting boolean
     */
    isCheckoutAllowed(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteCartService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuoteCartService>;
}

declare class CartUtilsService {
    protected userIdService: UserIdService;
    protected multiCartFacade: MultiCartFacade;
    protected routingService: RoutingService;
    protected quoteCartService: QuoteCartService;
    protected createNewCart(): Observable<Cart>;
    /**
     * Creates a new cart and navigates according to the 'cart' route.
     */
    goToNewCart(): void;
    /**
     * Handles a cart depending whether the quote is editable or not and navigates according to the 'quotes' route.
     *
     * @param isEditable - Is a quote editable?
     */
    handleCartAndGoToQuoteList(isEditable: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartUtilsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartUtilsService>;
}

declare class QuoteStorefrontUtilsService {
    protected windowRef: WindowRef;
    /**
     * Retrieves HTML element based on querySelector when running in browser.
     *
     * @param querySelector - query selector
     * @returns - if the HTML element has been found in the HTML tree then it will be returned, otherwise undefined.
     */
    getElement(querySelector: string): HTMLElement | undefined;
    /**
     * Change styling of a HTML element.
     *
     * @param querySelector - query selector
     * @param property - CSS property
     * @param value - CSS value
     */
    changeStyling(querySelector: string, property: string, value: string): void;
    protected isInViewport(element: HTMLElement | undefined): boolean;
    /**
     * Retrieves the height of the HTML element.
     *
     * @param querySelector - query selector
     * @returns - if the HTML element is in viewport then its height will be returned, otherwise zero
     */
    getHeight(querySelector: string): number;
    /**
     * Retrieves the value of DOMRect object by its property name.
     *
     * @param querySelector - query selector
     * @param property - name of the searched property
     * @returns - if the object has a searched property then the value of the property will be returned, otherwise undefined.
     */
    getDomRectValue(querySelector: string, property: string): number | undefined;
    /**
     * Retrieves the height of the window.
     *
     * @returns - if the height of the window is known, then it will be returned, otherwise zero.
     */
    getWindowHeight(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteStorefrontUtilsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuoteStorefrontUtilsService>;
}

declare class QuoteService implements QuoteFacade {
    protected userIdService: UserIdService;
    protected authService: AuthService;
    protected quoteConnector: QuoteConnector;
    protected eventService: EventService;
    protected queryService: QueryService;
    protected viewConfig: ViewConfig;
    protected commandService: CommandService;
    protected activeCartFacade: ActiveCartFacade;
    protected routingService: RoutingService;
    protected multiCartFacade: MultiCartFacade;
    protected quoteCartService: QuoteCartService;
    protected cartUtilsService: CartUtilsService;
    protected globalMessageService: GlobalMessageService;
    protected quoteStorefrontUtilsService: QuoteStorefrontUtilsService;
    protected savedCartFacade: SavedCartFacade;
    /**
     * Indicator whether an action is currently performing.
     */
    protected isActionPerforming$: BehaviorSubject<boolean>;
    protected createQuoteCommand: Command<{
        quoteMetadata: QuoteMetadata;
    }, Quote>;
    protected editQuoteCommand: Command<{
        quoteCode: string;
        quoteMetadata: QuoteMetadata;
    }>;
    protected addQuoteCommentCommand: Command<{
        quoteCode: string;
        quoteComment: QuoteComment;
        entryNumber?: string;
    }>;
    protected addDiscountCommand: Command<{
        quoteCode: string;
        quoteDiscount: QuoteDiscount;
    }>;
    protected performQuoteActionCommand: Command<{
        quote: Quote;
        quoteAction: QuoteActionType;
    }>;
    protected handleError(error: HttpErrorModel): Observable<unknown>;
    /**
     * Loads the quote cart and waits until load is done. Afterwards triggers specific actions depending on the
     * action we perform
     * @param userId - Current user
     * @param cartId - Quote cart ID
     * @param actionType - The action we are currently processing
     */
    protected loadQuoteCartAndProceed(userId: string, cartId: string, quoteId: string, actionType: QuoteActionType): void;
    protected triggerReloadAndCompleteAction(): void;
    protected requoteCommand: Command<{
        quoteStarter: QuoteStarter;
    }, Quote>;
    protected quoteDetailsState$: Query<Quote, unknown[]>;
    protected getQuotesStateQuery: ({ currentPage$, sort$, }: QuotesStateParams) => Query<QuoteList, []>;
    protected setFocusForCreateOrEditAction(action: QuoteActionType): void;
    protected saveActiveCart(): void;
    addDiscount(quoteCode: string, discount: QuoteDiscount): void;
    createQuote(quoteMetadata: QuoteMetadata): Observable<Quote>;
    editQuote(quoteCode: string, quoteMetadata: QuoteMetadata): void;
    addQuoteComment(quoteCode: string, quoteComment: QuoteComment, entryNumber?: string): Observable<unknown>;
    performQuoteAction(quote: Quote, quoteAction: QuoteActionType): Observable<unknown>;
    requote(quoteCode: string): Observable<Quote>;
    getQuotesState(params: QuotesStateParams): Observable<QueryState<QuoteList | undefined>>;
    getQuoteDetailsQueryState(): Observable<QueryState<Quote | undefined>>;
    getQuoteDetails(): Observable<Quote>;
    downloadAttachment(quoteCode: string, attachmentId: string): Observable<Blob>;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuoteService>;
}

declare class QuoteCoreModule {
    constructor(_quoteAddedToCartEventListener: QuoteCartEventListener);
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteCoreModule>;
}

export { CartUtilsService, QUOTE_ACTION_SERIALIZER, QUOTE_COMMENT_SERIALIZER, QUOTE_DISCOUNT_SERIALIZER, QUOTE_LIST_NORMALIZER, QUOTE_METADATA_SERIALIZER, QUOTE_NORMALIZER, QUOTE_STARTER_SERIALIZER, QuoteAdapter, QuoteCartEventListener, QuoteCartService, QuoteConnector, QuoteCoreConfig, QuoteCoreModule, QuoteDetailsReloadQueryEvent, QuoteService, QuoteStorefrontUtilsService };
export type { QuoteActionsConfig };
