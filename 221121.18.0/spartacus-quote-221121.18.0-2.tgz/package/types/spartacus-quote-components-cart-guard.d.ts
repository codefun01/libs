import * as i0 from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/core';
import { RoutingService, SemanticPathService, RouterState } from '@spartacus/core';
import { CanActivate, Router, GuardResult } from '@angular/router';
import { QuoteCartService } from '@spartacus/quote/core';
import { Observable } from 'rxjs';

/**
 * This component is used as a marker. In case it is present in the CMS composition of a page,
 * this page can be navigated to only if the {@link QuoteCartGuard}, which is attached
 * to this component, allows it. If not, the navigation will be re-directed to the quote
 * details page of the quote that is attached to the current cart.
 */
declare class QuoteCartGuardComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteCartGuardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuoteCartGuardComponent, "ng-component", never, {}, {}, never, never, true, never>;
}

declare class QuoteCartGuardComponentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteCartGuardComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteCartGuardComponentModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof QuoteCartGuardComponent], [typeof QuoteCartGuardComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteCartGuardComponentModule>;
}

/**
 * Ensures that the navigation will be re-directed to the quote
 * details page of the quote that is attached to the current cart in case:
 * (1) The current cart is linked to an editable quote
 * (2) The quote status doesn't allow the navigation to checkout
 */
declare class QuoteCartGuard implements CanActivate {
    protected routingService: RoutingService;
    protected quoteCartService: QuoteCartService;
    protected router: Router;
    protected semanticPathService: SemanticPathService;
    canActivate(): Observable<GuardResult>;
    /**
     * Verifies if the current navigation is an allowed checkout navigation.
     *
     * @param routerState - Used to assess if a checkout navigation is attempted
     * @param isCheckoutAllowed - Is checkout allowed although this guard is active? Only happens for quotes in state BUYER_OFFER
     * that can be ordered
     * @returns true if a checkout navigation is attempted and allowed because of the current quote state
     */
    protected checkAllowedCheckoutNavigation(routerState: RouterState, isCheckoutAllowed: boolean): boolean | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteCartGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuoteCartGuard>;
}

export { QuoteCartGuard, QuoteCartGuardComponent, QuoteCartGuardComponentModule };
