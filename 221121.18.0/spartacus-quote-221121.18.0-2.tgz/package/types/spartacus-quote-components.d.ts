import { ActiveCartFacade, MultiCartFacade, OrderEntry, AbstractOrderType, Cart, CartOutlets } from '@spartacus/cart/base/root';
import * as i2 from '@spartacus/core';
import { UserIdService, EventService, TranslationService, CxDatePipe, GlobalMessageService, SortModel, QueryState, PaginationModel, Price, LanguageService, GlobalMessageType } from '@spartacus/core';
import * as _spartacus_quote_root from '@spartacus/quote/root';
import { QuoteState, QuoteRoleType, QuoteActionType, QuoteFacade, Quote, QuoteComment, QuoteMetadata, QuoteAttachment, QuoteList, QuoteAction } from '@spartacus/quote/root';
import * as i3 from '@spartacus/storefront';
import { MessagingComponent, ICON_TYPE, MessageEvent, MessagingConfigs, MessageEventBoundItem, LaunchDialogService, FocusConfig, Card, FileDownloadService, IntersectionService } from '@spartacus/storefront';
import * as rxjs from 'rxjs';
import { ReplaySubject, Observable, BehaviorSubject, Subscription, Subject } from 'rxjs';
import * as i0 from '@angular/core';
import { OnInit, EventEmitter, OnDestroy, ElementRef, AfterViewInit, ViewContainerRef } from '@angular/core';
import * as i1 from '@angular/common';
import { QuoteCoreConfig, CartUtilsService, QuoteStorefrontUtilsService } from '@spartacus/quote/core';
import * as i4 from '@angular/forms';
import { FormGroup, ValidatorFn } from '@angular/forms';
import * as i5 from '@angular/router';
import * as i4$1 from '@spartacus/cart/base/components';
import { OrderConfig } from '@spartacus/order/root';

interface QuoteUIConfigFragment {
    maxCharsForComments?: number;
    truncateCardTileContentAfterNumChars?: number;
    confirmActionDialogMapping?: ConfirmActionDialogMappingConfig;
    maximumDecimalsForPercentageDiscount?: number;
    updateDebounceTime?: {
        expiryDate?: number;
    };
}
type ConfirmActionDialogConfig = {
    i18nKeyPrefix: string;
    showWarningNote: boolean;
    showExpirationDate: boolean;
    showSuccessMessage: boolean;
    showOnlyWhenCartIsNotEmpty: boolean;
};
/**
 * When a quote action is triggered and a valid configuration for this action is given,
 * a confirmation dialog will be shown instead. The dialog is customized by the given configuration.
 *
 * Note: If you provide a state/action as well as a role/action mapping that both match,
 * then always the more specific state/action mapping will be used.
 */
type ConfirmActionDialogMappingConfig = {
    [stateKey in QuoteState | QuoteRoleType]?: {
        [actionKey in QuoteActionType]?: ConfirmActionDialogConfig;
    };
};
declare abstract class QuoteUIConfig {
    quote?: QuoteUIConfigFragment;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteUIConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuoteUIConfig>;
}
declare module '@spartacus/core' {
    interface Config extends QuoteUIConfig {
    }
}

interface QuoteItemsData {
    entries: OrderEntry[] | undefined;
    readOnly: boolean;
    abstractOrderType: AbstractOrderType;
    abstractOrderId?: string;
}
type EditState = {
    readOnly: boolean;
};
type QuoteOrCartWithEditState = Observable<[Quote, EditState, AbstractOrderType]> | Observable<[Cart, EditState, AbstractOrderType]>;
declare class QuoteItemsComponentService {
    protected quoteFacade: QuoteFacade;
    protected userIdService: UserIdService;
    protected activeCartFacade: ActiveCartFacade;
    protected multiCartFacade: MultiCartFacade;
    protected _quoteEntriesExpanded$: ReplaySubject<boolean>;
    constructor();
    /**
     * Signals that the quote entry section is expanded.
     *
     * @param expanded Quote entry section expanded?
     */
    setQuoteEntriesExpanded(expanded: boolean): void;
    /**
     * Emits expanded state of the quote entries section.
     *
     * @returns Observable of boolean values telling if the quote entry section is expanded
     */
    getQuoteEntriesExpanded(): Observable<boolean>;
    /**
     * Retrieves observable of current quote entries (which can be read from a quote,
     * a saved cart or an active cart, depending on the quote state and its edit status).
     *
     * @returns Observable of quote items data. The return structure also contains information
     * about the type of the hosting document (quote, saved cart or active cart) and its edit status.
     */
    retrieveQuoteEntries(): Observable<QuoteItemsData>;
    protected prepareActiveCart(): QuoteOrCartWithEditState;
    protected prepareSavedCart(quoteCartId: string): QuoteOrCartWithEditState;
    protected prepareQuote(quote: Quote): QuoteOrCartWithEditState;
    protected loadQuoteCartIfNeeded(quote: Quote, userId: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteItemsComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuoteItemsComponentService>;
}

declare class QuoteCommentsComponent {
    protected quoteFacade: QuoteFacade;
    protected quoteItemsComponentService: QuoteItemsComponentService;
    protected eventService: EventService;
    protected translationService: TranslationService;
    protected quoteUIConfig: QuoteUIConfig;
    protected document: Document;
    commentsComponent: MessagingComponent;
    expandComments: boolean;
    iconTypes: typeof ICON_TYPE;
    quoteDetails$: Observable<Quote>;
    messageEvents$: Observable<Array<MessageEvent>>;
    messagingConfigs: MessagingConfigs;
    /**
     * Creates a quote comment based on the provided message event.
     * In case it contains an itemId the comment will be associated with this item, otherwise a header comment is created.
     *
     * @param event - message event
     * @param code - quote code
     */
    onSend(event: {
        message: string;
        itemId?: string;
    }, code: string): void;
    /**
     * Ensures that the quote item list is expanded, before scrolling to the corresponding item.
     *
     * @param event - click event containing the target item
     */
    onItemClicked(event: {
        item: MessageEventBoundItem;
    }): void;
    /**
     * Checks whether the comment section shall be shown at all.
     * In case the quote is in readonly mode and no comments are present, comment section is hidden, as there is nothing to display.
     * In case the quote is editable the comment section is always shown, as you could at least add comments from it.
     *
     * @param quote - quote
     * @returns true, only is the comment section shall be shown
     */
    showComments(quote: Quote): boolean;
    protected prepareMessagingConfigs(): MessagingConfigs;
    protected prepareItemList(): Observable<MessageEventBoundItem[]>;
    protected convertToItem(entry: OrderEntry): MessageEventBoundItem;
    protected prepareMessageEvents(): Observable<MessageEvent[]>;
    protected mapCommentToMessageEvent(comment: QuoteComment, entry?: OrderEntry): MessageEvent;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteCommentsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuoteCommentsComponent, "cx-quote-comments", never, {}, {}, never, never, true, never>;
}

declare class QuoteCommentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteCommentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteCommentsModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof i3.ChatMessagingModule, typeof QuoteCommentsComponent], [typeof QuoteCommentsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteCommentsModule>;
}

interface ConfirmationContext {
    quote: Quote;
    title: string;
    confirmNote: string;
    warningNote?: string;
    validity?: string;
    successMessage?: string;
    a11y: {
        close: string;
    };
}

declare class QuoteConfirmDialogComponent implements OnInit {
    protected launchDialogService: LaunchDialogService;
    protected quoteCoreConfig: QuoteCoreConfig;
    protected translationService: TranslationService;
    protected cxDatePipe: CxDatePipe;
    iconTypes: typeof ICON_TYPE;
    focusConfig: FocusConfig;
    confirmationContext$: Observable<ConfirmationContext>;
    constructor();
    ngOnInit(): void;
    /**
     * Closes a modal with a certain reason.
     *
     * @param reason - Reason
     */
    dismissModal(reason?: any): void;
    protected isNotEmpty(value: string): boolean;
    /**
     * Retrieves an accessibility text for the confirmation modal.
     *
     * @param context - confirmation context
     */
    getA11yModalText(context: ConfirmationContext): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteConfirmDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuoteConfirmDialogComponent, "cx-quote-confirm-dialog", never, {}, {}, never, never, true, never>;
}

declare class QuoteConfirmDialogModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteConfirmDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteConfirmDialogModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i2.UrlModule, typeof i3.IconModule, typeof i4.FormsModule, typeof i4.ReactiveFormsModule, typeof i3.FormErrorsModule, typeof i5.RouterModule, typeof i3.KeyboardFocusModule, typeof i3.SpinnerModule, typeof i2.FeaturesConfigModule, typeof QuoteConfirmDialogComponent], [typeof QuoteConfirmDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteConfirmDialogModule>;
}

interface SaveEvent {
    name?: string;
    description?: string;
    purchaseOrderNumber?: string;
}
interface EditCard {
    name: string;
    description: string;
    purchaseOrderNumber?: string;
    charactersLimit?: number;
}
declare class QuoteHeaderBuyerEditComponent implements OnInit {
    iconTypes: typeof ICON_TYPE;
    editForm: FormGroup;
    saveCard: EventEmitter<SaveEvent>;
    cancelCard: EventEmitter<any>;
    content: EditCard;
    private featureToggles;
    enablePurchaseOrderNumber: boolean | undefined;
    /**
     * Cancels the view of the edit card tile.
     */
    cancel(): void;
    /**
     * Saves the edited card tile by throwing the save event
     * with the edit mode set to 'false' and the edited data.
     */
    save(): void;
    protected getCharactersLeft(formControlName: string, charactersLimit: number): number;
    protected defineFormControl(formControlName: string, value: string): void;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteHeaderBuyerEditComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuoteHeaderBuyerEditComponent, "cx-quote-header-buyer-edit", never, { "content": { "alias": "content"; "required": false; }; }, { "saveCard": "saveCard"; "cancelCard": "cancelCard"; }, never, never, true, never>;
}

declare class QuoteHeaderBuyerEditModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteHeaderBuyerEditModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteHeaderBuyerEditModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof i3.KeyboardFocusModule, typeof i4.ReactiveFormsModule, typeof QuoteHeaderBuyerEditComponent], [typeof QuoteHeaderBuyerEditComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteHeaderBuyerEditModule>;
}

declare class QuoteHeaderOverviewComponent {
    protected quoteFacade: QuoteFacade;
    protected eventService: EventService;
    protected translationService: TranslationService;
    protected quoteUIConfig: QuoteUIConfig;
    private featureToggles;
    protected static NO_DATA: string;
    protected static CHARACTERS_LIMIT: number;
    protected static DEFAULT_CARD_TILE_MAX_CHARS: number;
    quoteDetails$: Observable<Quote>;
    iconTypes: typeof ICON_TYPE;
    editMode: boolean;
    enablePurchaseOrderNumber: boolean | undefined;
    protected defineQuoteMetaData(event: SaveEvent): QuoteMetadata;
    /**
     * Verifies whether the quote is editable and is viewed from a user acting as buyer.
     *
     * @param quote - quote
     * @returns if the quote is editable and its state is 'QuoteState.BUYER_DRAFT' or 'QuoteState.BUYER_OFFER', otherwise returns 'false'.
     */
    isQuoteEditableForBuyer(quote: Quote): boolean;
    /**
     * Cancels the view of the edit card tile
     * by setting the edit mode to 'false'.
     */
    cancel(): void;
    /**
     * Saves the edited card tile.
     *
     * @param quote - Quote
     * @param event - edit event
     */
    save(quote: Quote, event: SaveEvent): void;
    /**
     * Toggles the edit mode.
     */
    toggleEditMode(): void;
    /**
     * Retrieves the card content that represents the quote information with its name and description.
     *
     * @param name - Quote name
     * @param description - Quote description
     * @returns Observable emitting a card content
     */
    getQuoteInformation(name?: string, description?: string, purchaseOrderNumber?: string): Observable<Card>;
    /**
     * Retrieves the edit card content that represents the edit quote information with its name and description.
     *
     * @param name - Quote name
     * @param description - Quote description
     * @returns Observable emitting an edit card content
     */
    getEditQuoteInformation(name: string, description: string, purchaseOrderNumber?: string): EditCard;
    /**
     * Retrieves the card content that represents the estimated total and expiry date information.
     *
     * @param quote - Quote
     * @param expiryDate -  Expiry date
     * @returns Observable emitting a card content
     */
    getEstimatedTotalAndExpiryDate(quote: Quote, expiryDate?: string | null): Observable<Card>;
    /**
     * Retrieves the card content that represents the created and last updated dates.
     *
     * @param createdDate - Created date
     * @param lastUpdatedDate - Last updated date
     * @returns Observable emitting a card content
     */
    getCreatedAndUpdatedDates(createdDate?: string | null, lastUpdatedDate?: string | null): Observable<Card>;
    /**
     * Retrieves a characters limit for a card tile.
     * If the card tile contains more characters, they will be truncated.
     *
     * @returns characters limit for a card tile
     */
    getCharactersLimitForCardTile(): number;
    /**
     * Returns total price as formatted string.
     *
     * @param quote - Quote
     * @returns Total price formatted format, null if that is not available
     * @protected
     */
    protected getTotalPrice(quote: Quote): string | null;
    /**
     * Returns total price description.
     *
     * @param quote - Quote
     * @returns 'Total' price if quote is in final state, 'Estimated total' otherwise
     * @protected
     */
    protected getTotalPriceDescription(quote: Quote): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteHeaderOverviewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuoteHeaderOverviewComponent, "cx-quote-header-overview", never, {}, {}, never, never, true, never>;
}

declare class QuoteHeaderOverviewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteHeaderOverviewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteHeaderOverviewModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof i3.CardModule, typeof QuoteHeaderBuyerEditModule, typeof i3.KeyboardFocusModule, typeof QuoteHeaderOverviewComponent], [typeof QuoteHeaderOverviewComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteHeaderOverviewModule>;
}

/**
 * Renders quote items. These items are either taken from the actual quote,
 * or from the attached quote cart.
 * Specifically if the quote is editable, changes to the entries will be
 * done by changing the attached quote cart's entries.
 *
 * Note that the component makes use of outlet CART_ITEM_LIST in order to
 * render the quote entries. The default implementation of this outlet is
 * in feature lib 'cartBase'. This lib is always loaded, because
 * quoteFacade.getQuoteDetails() always triggers activeCartFacade for checking
 * on the quote/cart link.
 */
declare class QuoteItemsComponent {
    protected quoteItemsComponentService: QuoteItemsComponentService;
    quoteItemsData$: Observable<QuoteItemsData>;
    showCart$: Observable<boolean>;
    iconTypes: typeof ICON_TYPE;
    readonly cartOutlets: typeof CartOutlets;
    readonly abstractOrderType: typeof AbstractOrderType;
    /**
     * Handler to toggle expanded state of quote entries section.
     *
     * @param showCart - current expanded state, will be inverted
     */
    onToggleShowOrHideCart(showCart: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteItemsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuoteItemsComponent, "cx-quote-items", never, {}, {}, never, never, true, never>;
}

declare class QuoteItemsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteItemsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteItemsModule, never, [typeof i1.CommonModule, typeof i3.OutletModule, typeof i3.IconModule, typeof i2.I18nModule, typeof i4$1.AbstractOrderContextModule, typeof QuoteItemsComponent], [typeof QuoteItemsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteItemsModule>;
}

declare class QuoteLinksComponent implements OnInit {
    protected quoteFacade: QuoteFacade;
    protected cartUtilsService: CartUtilsService;
    protected eventService: EventService;
    protected fileDownloadService: FileDownloadService;
    protected globalMessageService: GlobalMessageService;
    protected orderConfig: OrderConfig;
    quoteDetails$: Observable<Quote>;
    ngOnInit(): void;
    /**
     * Creates a new cart and navigates according to the 'cart' route.
     */
    goToNewCart(): void;
    /**
     * Click handler for download button.
     *
     * @param quoteCode - The quote ID (aka code)
     * @param attachments - Array of attachments belonging to the quote. It is expected to contain only 1 entry.
     */
    onDownloadAttachment(quoteCode: string, attachments: QuoteAttachment[]): void;
    /**
     * Determines if there is any document attached with the quote.
     *
     * @param attachments - an array of attachments to the quote
     * @returns - if the document is present, returns 'true', otherwise 'false'.
     */
    hasAttachment(attachments: QuoteAttachment[]): boolean;
    /**
     * Determines if the feature for showing the download button is enabled.
     *
     * @returns - if the feature is enabled, returns 'true', otherwise 'false'.
     * @deprecated  This method is obsolete since 2211.41
     */
    isShowDownloadProposalButtonFeatureEnabled(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteLinksComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuoteLinksComponent, "cx-quote-links", never, {}, {}, never, never, true, never>;
}

declare class QuoteLinksModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteLinksModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteLinksModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i5.RouterModule, typeof i2.UrlModule, typeof i2.FeaturesConfigModule, typeof QuoteLinksComponent], [typeof QuoteLinksComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteLinksModule>;
}

declare class QuoteListComponentService {
    protected quoteFacade: QuoteFacade;
    protected translationService: TranslationService;
    readonly defaultSortOption = "byCode";
    protected sort: BehaviorSubject<string>;
    protected currentPage: BehaviorSubject<number>;
    sortOptions: SortModel[];
    quotesState$: Observable<QueryState<QuoteList | undefined>>;
    sortLabels$: Observable<{
        [key: string]: string;
    }>;
    /**
     * Sets sorting for quote list.
     *
     * @param sort - Code of desired sort option that will be applied to the quote list
     */
    setSorting(sort: string): void;
    /**
     * Sets current page.
     *
     * @param page - number of page that will be applied to the quote list
     */
    setPage(page: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteListComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuoteListComponentService>;
}

declare class QuoteListComponent implements OnInit {
    protected quoteListComponentService: QuoteListComponentService;
    protected translationService: TranslationService;
    protected cxDatePipe: CxDatePipe;
    sorts: i2.SortModel[];
    sortLabels$: rxjs.Observable<{
        [key: string]: string;
    }>;
    quotesState$: rxjs.Observable<i2.QueryState<_spartacus_quote_root.QuoteList | undefined>>;
    dateFormat: string;
    iconTypes: typeof ICON_TYPE;
    ngOnInit(): void;
    /**
     * Changes current sorting.
     *
     * @param sortCode - Identifies sort option that should be applied
     */
    changeSorting(sortCode: string): void;
    /**
     * Changes current page.
     *
     * @param page - Desired page number
     */
    changePage(page: number): void;
    /**
     * Retrieves the class name for the quote state. This class name is composed
     * using 'quote-' as prefix and the last part of the status name in lower case
     * (like e.g. draft for SELLER_DRAFT).
     *
     * @param state - quote state
     * @returns class name corresponding to quote state.
     */
    getQuoteStateClass(state: QuoteState): string;
    protected isPaginationEnabled(pagination: PaginationModel): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuoteListComponent, "cx-quote-list", never, {}, {}, never, never, true, never>;
}

declare class QuoteListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteListModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof i2.UrlModule, typeof i5.RouterModule, typeof i3.ListNavigationModule, typeof QuoteListComponent], [typeof QuoteListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteListModule>;
}

declare class QuoteSummaryPricesComponent {
    protected quoteFacade: QuoteFacade;
    quoteDetails$: rxjs.Observable<_spartacus_quote_root.Quote>;
    /**
     * Checks whether the price has a non-zero value.
     *
     * @param price - Price to check
     * @returns true, only if the price has a non zero value
     */
    hasNonZeroPriceValue(price?: Price): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteSummaryPricesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuoteSummaryPricesComponent, "cx-quote-summary-prices", never, {}, {}, never, never, true, never>;
}

declare class QuoteSummaryPricesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteSummaryPricesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteSummaryPricesModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof QuoteSummaryPricesComponent], [typeof QuoteSummaryPricesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteSummaryPricesModule>;
}

type LocalizationElements = {
    locale: string;
    formatter: Intl.NumberFormat;
    percentageSign: string;
};
/**
 * Provides validation and formatting of numeric input.
 */
declare class QuoteSummarySellerEditComponentService {
    protected languageService: LanguageService;
    protected quoteUIConfig: QuoteUIConfig;
    private readonly maximumDecimalsForPercentageDiscountDefault;
    /**
     * Parses a discount value to numeric format.
     *
     * @param input - Discount as string, can include unit symbol, decimal and grouping separators
     * @returns Observable of discount as number
     */
    parseDiscountValue(input: string | undefined | null): Observable<number>;
    /**
     * Retrieves formatter according to current locale and unit.
     *
     * @returns Observable of formatters
     */
    getFormatter(): Observable<Intl.NumberFormat>;
    /**
     * Retrieves localization elements according to current locale and unit.
     *
     * @returns Observables of localization elements
     */
    getLocalizationElements(): Observable<LocalizationElements>;
    /**
     * Retrieves number format validator according to inputs.
     *
     * @param locale - Current locale
     * @param unit - Unit
     * @returns Formatter that can be attached to a form control
     */
    getNumberFormatValidator(locale: string, unit: string): ValidatorFn;
    /**
     * Adds current time and time zone to a date. Result is a timestamp string that can be handed over to OCC.
     *
     * @param date - Date as string
     * @returns Timestamp as string
     */
    addTimeToDate(date: string): string;
    /**
     * Removes time portion from timestamp.
     *
     * @param timestamp - Timestamp as string
     * @returns Date portion of timestamp
     */
    removeTimeFromDate(timestamp?: string): string | undefined;
    /**
     * Verifies if quote state belongs to seller and can be edited.
     *
     * @param quote - Quote
     * @returns Is it for seller?
     */
    isEditable(quote: Quote): boolean;
    protected checkAndReportMissingPercentageSign(locale: string, formatter: Intl.NumberFormat, percentageSign?: string): LocalizationElements;
    protected parseInput(input: string, locale: string): number;
    protected parseInputForSeparators(input: string, groupingSeparator: string, decimalSeparator: string): number;
    protected getValidationErrorsNumericFormat(input: string, locale: string, unit: string): {
        [key: string]: any;
    } | null;
    protected createValidationError(isError: boolean): {
        [key: string]: any;
    } | null;
    /**
     * Returns maximum number of decimal places for the percentage discount.
     * The value is read from the configuration, refer to attribute quote/maximumDecimalsForPercentageDiscount.
     * In case this configuration is not present, default value is 8.
     *
     * @returns Maximum number of decimal places for percentage discount
     * @protected
     */
    protected retrieveMaxNumberOfDecimalPlaces(): number;
    protected performValidationForPercentageValue(input: string, groupingSeparator: string, decimalSeparator: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteSummarySellerEditComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuoteSummarySellerEditComponentService>;
}

declare class QuoteSummarySellerEditComponent implements OnInit, OnDestroy {
    protected quoteFacade: QuoteFacade;
    protected quoteHeaderSellerEditComponentService: QuoteSummarySellerEditComponentService;
    protected quoteUIConfig: QuoteUIConfig;
    quoteDetailsForSeller$: Observable<Quote>;
    element: ElementRef;
    form: FormGroup;
    iconType: typeof ICON_TYPE;
    discountPlaceholder: string;
    protected subscription: Subscription;
    protected dateUpdates: Subject<{
        quoteCode: string;
        date: string;
    }>;
    discountUpdatePerforming$: BehaviorSubject<boolean>;
    protected fillFormAttributes(localizationElements: LocalizationElements, quote: Quote): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    /**
     * Should the validation message be displayed?
     *
     * @returns True in case discount control has errors
     */
    mustDisplayValidationMessage(): boolean;
    /**
     * Parses current discount from control and sends absolute discount to the facade layer.
     *
     * @param quoteCode - Quote code
     */
    onApply(quoteCode: string): void;
    /**
     * Prepares date for facade layer and sends it.
     *
     * @param quoteCode - Quote code
     */
    onSetDate(quoteCode: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteSummarySellerEditComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuoteSummarySellerEditComponent, "cx-quote-summary-seller-edit", never, {}, {}, never, never, true, never>;
}

declare class QuoteSummarySellerEditModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteSummarySellerEditModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteSummarySellerEditModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i4.FormsModule, typeof i4.ReactiveFormsModule, typeof i3.IconModule, typeof i3.DatePickerModule, typeof QuoteSummarySellerEditComponent], [typeof QuoteSummarySellerEditComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteSummarySellerEditModule>;
}

declare class QuoteSummaryActionsComponent implements AfterViewInit, OnInit, OnDestroy {
    protected quoteFacade: QuoteFacade;
    protected launchDialogService: LaunchDialogService;
    protected viewContainerRef: ViewContainerRef;
    protected globalMessageService: GlobalMessageService;
    protected quoteUIConfig: QuoteUIConfig;
    protected activeCartFacade: ActiveCartFacade;
    protected quoteStorefrontUtilsService: QuoteStorefrontUtilsService;
    protected intersectionService: IntersectionService;
    quoteDetails$: Observable<Quote>;
    cartDetails$: Observable<Cart>;
    element: ElementRef;
    QuoteActionType: typeof QuoteActionType;
    protected subscription: Subscription;
    isFixedPosition: boolean;
    protected readonly CX_SECTION_SELECTOR = "cx-quote-summary-actions section";
    protected readonly HEADER_SLOT_SELECTOR = ".BottomHeaderSlot";
    /**
     * Height of a CSS box model of section for action buttons
     * See _quote-summary-actions.scss
     */
    protected readonly ACTION_BUTTONS_HEIGHT = 226;
    protected readonly AMOUNT_OF_ACTION_BUTTONS = 2;
    protected readonly BOTTOM = "bottom";
    handleResize(): void;
    handleScroll(): void;
    ngAfterViewInit(): void;
    ngOnInit(): void;
    /**
     * Retrieves the actual height of the action buttons.
     *
     * @returns - Height of the action buttons.
     * @protected
     */
    protected getActionButtonsHeight(): number;
    /**
     * Adjusts `bottom` property.
     *
     * In case we deal with a desktop device, then the bottom property will be removed.
     *
     * In case we deal with a mobile device.
     * There are 2 cases when the bottom property will be changed accordingly.
     * Firstly, the bottom property will be changed to the value that is less than zero,
     * when the height of the action buttons is greater than the spare viewport height.
     * Secondly, the bottom property will be changed to zero,
     * when the mentioned condition is not met.
     *
     * @protected
     */
    protected adjustBottomProperty(): void;
    /**
     * Defines the class name for the section that controls the styling to be displayed on mobile.
     *
     * @protected
     */
    protected defineClassForSection(): void;
    protected adjustStyling(): void;
    /**
     * Checks whether the given action must be disabled on the UI based on the details of the quote.
     * For example the SUBMIT action is disabled when the quote threshold is not exceeded.
     *
     * @param type - type of the quote action
     * @param quote - quote
     * @returns true, only of the action shall be disabled
     */
    mustDisableAction(type: string, quote: Quote): boolean;
    protected isThresholdReached(quote: Quote): boolean;
    /**
     * Generic click handler for quote action buttons.
     *
     * @param action - the action to be triggered
     * @param quote - quote
     * @param cart - cart
     */
    onClick(action: QuoteActionType, quote: Quote, cart: Cart): void;
    protected performAction(action: QuoteActionType, quote: Quote): void;
    protected launchConfirmationDialog(context: ConfirmationContext): void;
    protected handleConfirmationDialogClose(action: QuoteActionType, context: ConfirmationContext): void;
    protected getMessageType(action: QuoteActionType): GlobalMessageType;
    protected requote(quoteId: string): void;
    /**
     * Verifies whether there are any action buttons.
     *
     * @param allowedActions - currently displayed actions
     * @returns - if there are any action buttons, returns 'true', otherwise 'false'.
     */
    areButtonsRendered(allowedActions: QuoteAction[]): boolean;
    /**
     * Returns the style class to be used for the button, so whether its a primary, secondary or tertiary button.
     *
     * @param allowedActions - currently displayed actions
     * @param action - action associated with this button
     * @returns 'btn-primary' | 'btn-secondary' | 'btn-tertiary'
     */
    getButtonStyle(allowedActions: QuoteAction[], action: QuoteAction): string;
    ngOnDestroy(): void;
    protected isConfirmationDialogRequired(action: QuoteActionType, state: QuoteState, cartIsEmptyOrQuoteCart: boolean): boolean;
    protected prepareConfirmationContext(action: QuoteActionType, quote: Quote): ConfirmationContext;
    protected getConfirmDialogConfig(action: QuoteActionType, state: QuoteState): ConfirmActionDialogConfig;
    protected stateToRoleTypeForDialogConfig(state: QuoteState): QuoteRoleType;
    getFilteredActions(allowedActions: QuoteAction[]): QuoteAction[];
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteSummaryActionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuoteSummaryActionsComponent, "cx-quote-summary-actions", never, {}, {}, never, never, true, never>;
}

declare class QuoteSummaryActionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteSummaryActionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteSummaryActionsModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof QuoteSummaryActionsComponent], [typeof QuoteSummaryActionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteSummaryActionsModule>;
}

declare class QuoteSummaryComponent {
    protected quoteFacade: QuoteFacade;
    quoteDetails$: rxjs.Observable<_spartacus_quote_root.Quote>;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteSummaryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuoteSummaryComponent, "cx-quote-summary", never, {}, {}, never, never, true, never>;
}

declare class QuoteSummaryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteSummaryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteSummaryModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof QuoteSummaryPricesModule, typeof QuoteSummarySellerEditModule, typeof QuoteSummaryActionsModule, typeof QuoteSummaryComponent], [typeof QuoteSummaryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteSummaryModule>;
}

declare class QuoteComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteComponentsModule, never, [typeof i1.CommonModule, typeof i3.ListNavigationModule, typeof QuoteConfirmDialogModule, typeof QuoteLinksModule, typeof QuoteCommentsModule, typeof QuoteHeaderBuyerEditModule, typeof QuoteHeaderOverviewModule, typeof QuoteItemsModule, typeof QuoteListModule, typeof QuoteSummaryModule, typeof QuoteSummaryActionsModule, typeof QuoteSummaryPricesModule, typeof QuoteSummarySellerEditModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteComponentsModule>;
}

export { QuoteCommentsComponent, QuoteCommentsModule, QuoteComponentsModule, QuoteConfirmDialogComponent, QuoteConfirmDialogModule, QuoteHeaderBuyerEditComponent, QuoteHeaderBuyerEditModule, QuoteHeaderOverviewComponent, QuoteHeaderOverviewModule, QuoteItemsComponent, QuoteItemsComponentService, QuoteItemsModule, QuoteLinksComponent, QuoteLinksModule, QuoteListComponent, QuoteListComponentService, QuoteListModule, QuoteSummaryActionsComponent, QuoteSummaryActionsModule, QuoteSummaryComponent, QuoteSummaryModule, QuoteSummaryPricesComponent, QuoteSummaryPricesModule, QuoteSummarySellerEditComponent, QuoteSummarySellerEditComponentService, QuoteSummarySellerEditModule, QuoteUIConfig };
export type { ConfirmActionDialogConfig, ConfirmActionDialogMappingConfig, ConfirmationContext, EditCard, LocalizationElements, QuoteItemsData, QuoteUIConfigFragment, SaveEvent };
