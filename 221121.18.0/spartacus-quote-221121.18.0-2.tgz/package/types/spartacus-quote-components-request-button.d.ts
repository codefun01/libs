import * as i0 from '@angular/core';
import { OnDestroy } from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/core';
import { RoutingService, AuthService } from '@spartacus/core';
import * as rxjs from 'rxjs';
import { Subscription } from 'rxjs';
import { QuoteFacade } from '@spartacus/quote/root';

declare class QuoteRequestButtonComponent implements OnDestroy {
    protected quoteFacade: QuoteFacade;
    protected routingService: RoutingService;
    protected authService: AuthService;
    protected subscription: Subscription;
    /**
     * Quote handling requires a logged-in user. We cannot enforce that via an authGuard here
     * because otheriwise the entire cart page would need an authenticated user. So we check on
     * the view and don't render the button if the user is not logged in.
     */
    isLoggedIn$: rxjs.Observable<boolean>;
    /**
     * Creates a new quote and triggers the navigation according to route 'quoteDetails',
     * in order to land on the quote details page.
     */
    goToQuoteDetails(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteRequestButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuoteRequestButtonComponent, "cx-quote-request-button", never, {}, {}, never, never, true, never>;
}

declare class QuoteRequestButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteRequestButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteRequestButtonModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof QuoteRequestButtonComponent], [typeof QuoteRequestButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteRequestButtonModule>;
}

export { QuoteRequestButtonComponent, QuoteRequestButtonModule };
