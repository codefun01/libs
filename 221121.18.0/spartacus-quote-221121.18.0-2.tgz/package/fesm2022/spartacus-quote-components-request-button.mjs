import { NgIf, AsyncPipe, CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { inject, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { RoutingService, AuthService, TranslatePipe, I18nModule, provideDefaultConfig } from '@spartacus/core';
import { QuoteFacade } from '@spartacus/quote/root';
import { Subscription } from 'rxjs';
import { tap } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteRequestButtonComponent {
    constructor() {
        this.quoteFacade = inject(QuoteFacade);
        this.routingService = inject(RoutingService);
        this.authService = inject(AuthService);
        this.subscription = new Subscription();
        /**
         * Quote handling requires a logged-in user. We cannot enforce that via an authGuard here
         * because otheriwise the entire cart page would need an authenticated user. So we check on
         * the view and don't render the button if the user is not logged in.
         */
        this.isLoggedIn$ = this.authService.isUserLoggedIn();
    }
    /**
     * Creates a new quote and triggers the navigation according to route 'quoteDetails',
     * in order to land on the quote details page.
     */
    goToQuoteDetails() {
        this.subscription.add(this.quoteFacade
            .createQuote({})
            .pipe(tap((quote) => {
            this.routingService.go({
                cxRoute: 'quoteDetails',
                params: { quoteId: quote.code },
            });
        }))
            .subscribe());
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteRequestButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: QuoteRequestButtonComponent, isStandalone: true, selector: "cx-quote-request-button", ngImport: i0, template: "<button\n  *ngIf=\"isLoggedIn$ | async\"\n  #element\n  (click)=\"goToQuoteDetails()\"\n  type=\"button\"\n  class=\"btn btn-block btn-secondary\"\n>\n  {{ 'quote.commons.requestQuote' | cxTranslate }}\n</button>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteRequestButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-quote-request-button', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, AsyncPipe, TranslatePipe], template: "<button\n  *ngIf=\"isLoggedIn$ | async\"\n  #element\n  (click)=\"goToQuoteDetails()\"\n  type=\"button\"\n  class=\"btn btn-block btn-secondary\"\n>\n  {{ 'quote.commons.requestQuote' | cxTranslate }}\n</button>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteRequestButtonModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteRequestButtonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QuoteRequestButtonModule, imports: [CommonModule, I18nModule, QuoteRequestButtonComponent], exports: [QuoteRequestButtonComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteRequestButtonModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    QuoteRequestComponent: {
                        component: QuoteRequestButtonComponent,
                    },
                },
            }),
        ], imports: [CommonModule, I18nModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteRequestButtonModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, I18nModule, QuoteRequestButtonComponent],
                    exports: [QuoteRequestButtonComponent],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                QuoteRequestComponent: {
                                    component: QuoteRequestButtonComponent,
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { QuoteRequestButtonComponent, QuoteRequestButtonModule };
//# sourceMappingURL=spartacus-quote-components-request-button.mjs.map
