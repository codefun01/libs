import * as i0 from '@angular/core';
import { Injectable, inject, InjectionToken, NgModule } from '@angular/core';
import { Config, CxEvent, EventService, UserIdService, RoutingService, WindowRef, AuthService, QueryService, CommandService, GlobalMessageService, CommandStrategy, LoginEvent, GlobalMessageType, provideDefaultConfig } from '@spartacus/core';
import { CartAddEntrySuccessEvent, CartUpdateEntrySuccessEvent, CartRemoveEntrySuccessEvent, ActiveCartFacade, MultiCartFacade } from '@spartacus/cart/base/root';
import { Subscription, ReplaySubject, BehaviorSubject, combineLatest, zip, of, EMPTY, throwError } from 'rxjs';
import { SavedCartFacade } from '@spartacus/cart/saved-cart/root';
import { QuoteActionType, QuoteFacade } from '@spartacus/quote/root';
import { ViewConfig } from '@spartacus/storefront';
import { map, switchMap, take, concatMap, tap, catchError, filter, withLatestFrom, mergeMap } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteCoreConfig {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCoreConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCoreConfig, providedIn: 'root', useExisting: Config }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCoreConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useExisting: Config,
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteConnector {
    constructor() {
        this.quoteAdapter = inject(QuoteAdapter);
    }
    /**
     * Fetches a list of quotes according to the pagination provided.
     *
     * @param userId - Quote user
     * @param pagination - Pagination attributes
     * @returns Observable emitting a quote list
     */
    getQuotes(userId, pagination) {
        return this.quoteAdapter.getQuotes(userId, pagination);
    }
    /**
     * Creates a quote.
     *
     * @param userId - Quote user
     * @param quoteStarter - Attributes needed to create a quote
     * @returns Observable emitting a quote
     */
    createQuote(userId, quoteStarter) {
        return this.quoteAdapter.createQuote(userId, quoteStarter);
    }
    /**
     * Fetches a quote specified by its ID (aka code).
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code
     * @returns Observable emitting a quote
     */
    getQuote(userId, quoteCode) {
        return this.quoteAdapter.getQuote(userId, quoteCode);
    }
    /**
     * Edits a quote in its main header aspects (name, description and expiry date).
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code, identifies a quote uniquely for a given user role
     * @param quoteMetadata - Attributes that are going to be changed
     * @returns Observable emitting unknown
     */
    editQuote(userId, quoteCode, quoteMetadata) {
        return this.quoteAdapter.editQuote(userId, quoteCode, quoteMetadata);
    }
    /**
     * Triggers an action on a quote identified by its code.
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code, identifies a quote for a given user role
     * @param quoteAction - Quote action
     * @returns Observable emitting unknown
     */
    performQuoteAction(userId, quoteCode, quoteAction) {
        return this.quoteAdapter.performQuoteAction(userId, quoteCode, quoteAction);
    }
    /**
     * Adds a header comment to a quote.
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code
     * @param quoteComment - Quote comment
     * @returns Observable emitting unknown
     */
    addComment(userId, quoteCode, quoteComment) {
        return this.quoteAdapter.addComment(userId, quoteCode, quoteComment);
    }
    /**
     * Adds a discount to a quote. A previous discount will be overwritten.
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code
     * @param discount - Quote discount
     * @returns Observable emitting unknown
     */
    addDiscount(userId, quoteCode, discount) {
        return this.quoteAdapter.addDiscount(userId, quoteCode, discount);
    }
    /**
     * Adds an entry comment to a quote.
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code
     * @param entryNumber - Quote entry number
     * @param comment - Quote comment
     * @returns Observable emitting unknown
     */
    addQuoteEntryComment(userId, quoteCode, entryNumber, comment) {
        return this.quoteAdapter.addQuoteEntryComment(userId, quoteCode, entryNumber, comment);
    }
    /**
     * Downloads the proposal document associated with a quote.
     *
     * @param userId - Quote user
     * @param quoteCode - Quote code
     * @param attachmentId - Attachment ID
     * @returns Observable emitting a Blob response
     */
    downloadAttachment(userId, quoteCode, attachmentId) {
        return this.quoteAdapter.downloadAttachment(userId, quoteCode, attachmentId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const QUOTE_NORMALIZER = new InjectionToken('QuoteNormalizer');
const QUOTE_LIST_NORMALIZER = new InjectionToken('QuoteListNormalizer');
const QUOTE_STARTER_SERIALIZER = new InjectionToken('QuoteStarterSerializer');
const QUOTE_METADATA_SERIALIZER = new InjectionToken('QuoteMetadataSerializer');
const QUOTE_ACTION_SERIALIZER = new InjectionToken('QuoteActionSerializer');
const QUOTE_COMMENT_SERIALIZER = new InjectionToken('QuoteCommentSerializer');
const QUOTE_DISCOUNT_SERIALIZER = new InjectionToken('QuoteDiscountSerializer');

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteDetailsReloadQueryEvent extends CxEvent {
    /**
     * Event's type
     */
    static { this.type = 'QuoteDetailsReloadQueryEvent'; }
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteCartEventListener {
    constructor() {
        this.eventService = inject(EventService);
        this.subscription = new Subscription();
        this.listenToCartEvents();
    }
    listenToCartEvents() {
        this.subscription.add(this.eventService.get(CartAddEntrySuccessEvent).subscribe(() => {
            this.triggerQuoteReload();
        }));
        this.subscription.add(this.eventService.get(CartUpdateEntrySuccessEvent).subscribe(() => {
            this.triggerQuoteReload();
        }));
        this.subscription.add(this.eventService.get(CartRemoveEntrySuccessEvent).subscribe(() => {
            this.triggerQuoteReload();
        }));
    }
    triggerQuoteReload() {
        this.eventService.dispatch({}, QuoteDetailsReloadQueryEvent);
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCartEventListener, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCartEventListener, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCartEventListener, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteCartService {
    constructor() {
        this.activeCartFacade = inject(ActiveCartFacade);
        this.checkoutAllowed = new ReplaySubject(1);
        this.checkoutAllowedAsObservable = this.checkoutAllowed.asObservable();
        this.checkoutAllowed.next(false);
    }
    /**
     * Returns a quote ID.
     *
     * @returns Observable emitting string or unknown
     */
    getQuoteId() {
        return this.activeCartFacade
            .getActive()
            .pipe(map((cart) => cart.quoteCode));
    }
    /**
     * Verifies if a quote cart is active.
     *
     * @returns Observable emitting boolean
     */
    isQuoteCartActive() {
        return this.activeCartFacade
            .getActive()
            .pipe(map((cart) => cart.quoteCode !== undefined));
    }
    /**
     * Defines whether the checkout is allowed.
     *
     * @param checkoutAllowed - is checkout allowed
     */
    setCheckoutAllowed(checkoutAllowed) {
        this.checkoutAllowed.next(checkoutAllowed);
    }
    /**
     * Verifies if the checkout is allowed.
     *
     * @returns Observable emitting boolean
     */
    isCheckoutAllowed() {
        return this.checkoutAllowedAsObservable;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCartService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCartService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCartService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartUtilsService {
    constructor() {
        this.userIdService = inject(UserIdService);
        this.multiCartFacade = inject(MultiCartFacade);
        this.routingService = inject(RoutingService);
        this.quoteCartService = inject(QuoteCartService);
    }
    createNewCart() {
        return this.userIdService.takeUserId().pipe(switchMap((userId) => this.multiCartFacade.createCart({
            userId,
            oldCartId: undefined,
            toMergeCartGuid: undefined,
            extraData: { active: true },
        })));
    }
    /**
     * Creates a new cart and navigates according to the 'cart' route.
     */
    goToNewCart() {
        this.createNewCart()
            .pipe(take(1))
            .subscribe(() => {
            this.routingService.go({ cxRoute: 'cart' });
        });
    }
    /**
     * Handles a cart depending whether the quote is editable or not and navigates according to the 'quotes' route.
     *
     * @param isEditable - Is a quote editable?
     */
    handleCartAndGoToQuoteList(isEditable) {
        if (isEditable) {
            this.createNewCart()
                .pipe(take(1))
                .subscribe(() => {
                this.routingService.go({ cxRoute: 'quotes' });
            });
        }
        else {
            this.routingService.go({ cxRoute: 'quotes' });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartUtilsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartUtilsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CartUtilsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteStorefrontUtilsService {
    constructor() {
        this.windowRef = inject(WindowRef);
    }
    /**
     * Retrieves HTML element based on querySelector when running in browser.
     *
     * @param querySelector - query selector
     * @returns - if the HTML element has been found in the HTML tree then it will be returned, otherwise undefined.
     */
    getElement(querySelector) {
        if (this.windowRef.isBrowser()) {
            return this.windowRef.document.querySelector(querySelector);
        }
    }
    /**
     * Change styling of a HTML element.
     *
     * @param querySelector - query selector
     * @param property - CSS property
     * @param value - CSS value
     */
    changeStyling(querySelector, property, value) {
        const element = this.getElement(querySelector);
        if (element) {
            element.style.setProperty(property, value);
        }
    }
    isInViewport(element) {
        if (element) {
            const bounding = element.getBoundingClientRect();
            const height = element.offsetHeight;
            const width = element.offsetWidth;
            return (bounding.top >= -height &&
                bounding.left >= -width &&
                bounding.right <=
                    (this.windowRef.nativeWindow?.innerWidth || element.clientWidth) +
                        width &&
                bounding.bottom <=
                    (this.windowRef.nativeWindow?.innerHeight || element.clientHeight) +
                        height);
        }
        return false;
    }
    /**
     * Retrieves the height of the HTML element.
     *
     * @param querySelector - query selector
     * @returns - if the HTML element is in viewport then its height will be returned, otherwise zero
     */
    getHeight(querySelector) {
        const element = this.getElement(querySelector);
        const isElementInViewport = this.isInViewport(element);
        if (isElementInViewport && element?.offsetHeight) {
            return element?.offsetHeight;
        }
        return 0;
    }
    /**
     * Retrieves the value of DOMRect object by its property name.
     *
     * @param querySelector - query selector
     * @param property - name of the searched property
     * @returns - if the object has a searched property then the value of the property will be returned, otherwise undefined.
     */
    getDomRectValue(querySelector, property) {
        const element = this.getElement(querySelector);
        if (element) {
            const domRectObj = element.getBoundingClientRect().toJSON();
            const properties = Object.getOwnPropertyNames(domRectObj);
            if (properties.length >= 1 && properties.indexOf(property) >= 0) {
                const value = domRectObj[property];
                if (typeof value === 'number') {
                    return Math.round(value);
                }
            }
        }
        return undefined;
    }
    /**
     * Retrieves the height of the window.
     *
     * @returns - if the height of the window is known, then it will be returned, otherwise zero.
     */
    getWindowHeight() {
        if (this.windowRef.isBrowser()) {
            return this.windowRef.nativeWindow
                ? this.windowRef.nativeWindow.innerHeight
                : 0;
        }
        return 0;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteStorefrontUtilsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteStorefrontUtilsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteStorefrontUtilsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteService {
    constructor() {
        this.userIdService = inject(UserIdService);
        this.authService = inject(AuthService);
        this.quoteConnector = inject(QuoteConnector);
        this.eventService = inject(EventService);
        this.queryService = inject(QueryService);
        this.viewConfig = inject(ViewConfig);
        this.commandService = inject(CommandService);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.routingService = inject(RoutingService);
        this.multiCartFacade = inject(MultiCartFacade);
        this.quoteCartService = inject(QuoteCartService);
        this.cartUtilsService = inject(CartUtilsService);
        this.globalMessageService = inject(GlobalMessageService);
        this.quoteStorefrontUtilsService = inject(QuoteStorefrontUtilsService);
        this.savedCartFacade = inject(SavedCartFacade);
        /**
         * Indicator whether an action is currently performing.
         */
        this.isActionPerforming$ = new BehaviorSubject(false);
        this.createQuoteCommand = this.commandService.create((payload) => combineLatest([
            this.userIdService.takeUserId(),
            this.activeCartFacade.takeActiveCartId(),
        ]).pipe(take(1), switchMap(([userId, cartId]) => zip(of(userId), this.quoteConnector.createQuote(userId, { cartId }))), concatMap(([userId, quote]) => zip(combineLatest([
            this.quoteConnector.editQuote(userId, quote.code, payload.quoteMetadata),
        ]), of(userId), of(quote))), tap(([_, userId, quote]) => {
            this.multiCartFacade.loadCart({
                userId,
                cartId: quote.cartId,
                extraData: {
                    active: true,
                },
            });
            this.eventService.dispatch({}, QuoteDetailsReloadQueryEvent);
        }), tap(() => this.setFocusForCreateOrEditAction(QuoteActionType.CREATE)), map(([_, _userId, quote]) => quote)), {
            strategy: CommandStrategy.CancelPrevious,
        });
        this.editQuoteCommand = this.commandService.create((payload) => this.userIdService.takeUserId().pipe(take(1), switchMap((userId) => this.quoteConnector.editQuote(userId, payload.quoteCode, payload.quoteMetadata)), tap(() => {
            this.eventService.dispatch({}, QuoteDetailsReloadQueryEvent);
        })), {
            strategy: CommandStrategy.CancelPrevious,
        });
        this.addQuoteCommentCommand = this.commandService.create((payload) => this.userIdService.takeUserId().pipe(take(1), switchMap((userId) => {
            if (payload.entryNumber) {
                return this.quoteConnector.addQuoteEntryComment(userId, payload.quoteCode, payload.entryNumber, payload.quoteComment);
            }
            else {
                return this.quoteConnector.addComment(userId, payload.quoteCode, payload.quoteComment);
            }
        })), {
            strategy: CommandStrategy.CancelPrevious,
        });
        this.addDiscountCommand = this.commandService.create((payload) => this.userIdService.takeUserId().pipe(take(1), switchMap((userId) => {
            return this.quoteConnector.addDiscount(userId, payload.quoteCode, payload.quoteDiscount);
        }), tap(() => {
            this.eventService.dispatch({}, QuoteDetailsReloadQueryEvent);
        }), catchError((error) => {
            this.triggerReloadAndCompleteAction();
            return this.handleError(error);
        })), {
            strategy: CommandStrategy.CancelPrevious,
        });
        this.performQuoteActionCommand = this.commandService.create((payload) => {
            this.isActionPerforming$.next(true);
            return this.userIdService.takeUserId().pipe(take(1), switchMap((userId) => zip(this.quoteConnector.performQuoteAction(userId, payload.quote.code, payload.quoteAction), of(userId))), tap(([_result, userId]) => {
                if (payload.quoteAction === QuoteActionType.SUBMIT ||
                    payload.quoteAction === QuoteActionType.CANCEL) {
                    this.cartUtilsService.handleCartAndGoToQuoteList(payload.quote.isEditable);
                    this.isActionPerforming$.next(false);
                }
                if (payload.quoteAction === QuoteActionType.REJECT ||
                    payload.quoteAction === QuoteActionType.APPROVE) {
                    this.routingService.go({ cxRoute: 'quotes' });
                }
                if (payload.quoteAction === QuoteActionType.EDIT ||
                    payload.quoteAction === QuoteActionType.CHECKOUT) {
                    this.saveActiveCart();
                    //no cartId present: ensure that we re-fetch quote cart id from quote
                    const cartId = payload.quote.cartId;
                    if (!cartId) {
                        this.quoteConnector
                            .getQuote(userId, payload.quote.code)
                            .pipe(filter((quote) => quote.cartId !== undefined), take(1))
                            .subscribe((quote) => {
                            this.loadQuoteCartAndProceed(userId, quote.cartId, quote.code, payload.quoteAction);
                        });
                    }
                    else {
                        this.loadQuoteCartAndProceed(userId, cartId, payload.quote.code, payload.quoteAction);
                    }
                }
                else {
                    this.isActionPerforming$.next(false);
                }
            }), tap(() => this.setFocusForCreateOrEditAction(payload.quoteAction)), catchError((error) => {
                this.triggerReloadAndCompleteAction();
                return this.handleError(error);
            }));
        }, {
            strategy: CommandStrategy.CancelPrevious,
        });
        this.requoteCommand = this.commandService.create((payload) => {
            this.isActionPerforming$.next(true);
            return this.userIdService.takeUserId().pipe(take(1), switchMap((userId) => this.quoteConnector.createQuote(userId, payload.quoteStarter).pipe(tap((quote) => {
                this.saveActiveCart();
                this.loadQuoteCartAndProceed(userId, quote.cartId, quote.code, QuoteActionType.REQUOTE);
            }))));
        }, {
            strategy: CommandStrategy.CancelPrevious,
        });
        this.quoteDetailsState$ = this.queryService.create(() => 
        //we need to ensure that the active cart has been loaded, in order to determine if the
        //quote is connected to a quote cart (and then directly ready for edit)
        this.activeCartFacade.getActive().pipe(take(1), switchMap(() => combineLatest([
            this.routingService.getRouterState(),
            this.authService.isUserLoggedIn(),
        ]).pipe(
        //we don't need to cover the intermediate router states where a future route is already known.
        //only changes to the URL are relevant. Otherwise we get unneeded hits when e.g. navigating back from quotes.
        //In addition we check is the user is logged in as otherwise we would get (failing) calls after logout
        filter(([routerState, isLoggedIn]) => routerState.nextState === undefined && isLoggedIn), withLatestFrom(this.userIdService.takeUserId()), switchMap(([[routerState, _isLoggedIn], userId]) => {
            return this.quoteConnector.getQuote(userId, routerState.state.params.quoteId);
        })))), {
            reloadOn: [QuoteDetailsReloadQueryEvent, LoginEvent],
        });
        this.getQuotesStateQuery = ({ currentPage$, sort$, }) => this.queryService.create(() => combineLatest([
            this.userIdService.takeUserId(),
            currentPage$,
            sort$,
        ]).pipe(switchMap(([userId, currentPage, sort]) => this.quoteConnector.getQuotes(userId, {
            currentPage,
            sort,
            pageSize: this.viewConfig.view?.defaultPageSize,
        })), tap(() => {
            this.eventService.dispatch({}, QuoteDetailsReloadQueryEvent);
        })), {
            reloadOn: [], // Changes to currentPage$/sort$ are now handled reactively within the factory itself, so reloadOn is no longer needed.
            resetOn: [LoginEvent],
        });
    }
    handleError(error) {
        if (error.details?.[0]?.type === 'CommerceQuoteExpirationTimeError') {
            this.globalMessageService.add({ key: 'quote.httpHandlers.expired' }, GlobalMessageType.MSG_TYPE_ERROR);
            return EMPTY;
        }
        return throwError(error);
    }
    /**
     * Loads the quote cart and waits until load is done. Afterwards triggers specific actions depending on the
     * action we perform
     * @param userId - Current user
     * @param cartId - Quote cart ID
     * @param actionType - The action we are currently processing
     */
    loadQuoteCartAndProceed(userId, cartId, quoteId, actionType) {
        this.multiCartFacade.loadCart({
            userId: userId,
            cartId: cartId,
            extraData: {
                active: true,
            },
        });
        this.activeCartFacade
            .getActive()
            .pipe(filter((cart) => cart.code === cartId), take(1))
            .subscribe(() => {
            this.triggerReloadAndCompleteAction();
            if (actionType === QuoteActionType.CHECKOUT) {
                this.quoteCartService.setCheckoutAllowed(true);
                this.routingService.go({ cxRoute: 'checkout' });
            }
            else if (actionType === QuoteActionType.REQUOTE) {
                this.routingService.go({
                    cxRoute: 'quoteDetails',
                    params: { quoteId: quoteId },
                });
            }
        });
    }
    triggerReloadAndCompleteAction() {
        this.isActionPerforming$.next(false);
        this.eventService.dispatch({}, QuoteDetailsReloadQueryEvent);
    }
    setFocusForCreateOrEditAction(action) {
        if (action === QuoteActionType.EDIT || action === QuoteActionType.CREATE) {
            const storefrontElement = this.quoteStorefrontUtilsService.getElement('cx-storefront');
            if (storefrontElement) {
                storefrontElement.focus();
            }
        }
    }
    saveActiveCart() {
        this.activeCartFacade
            .getActive()
            .pipe(take(1))
            .subscribe((activeCart) => {
            if ((activeCart?.entries ?? []).length > 0 &&
                !activeCart.quoteCode &&
                activeCart.code) {
                this.savedCartFacade.editSavedCart({
                    cartId: activeCart.code,
                    saveCartName: '',
                    saveCartDescription: '',
                });
                this.globalMessageService.add({
                    key: 'quote.commons.savedActiveCart',
                    params: {
                        code: activeCart.code,
                    },
                }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
            }
        });
    }
    addDiscount(quoteCode, discount) {
        this.addDiscountCommand.execute({
            quoteCode,
            quoteDiscount: discount,
        });
    }
    createQuote(quoteMetadata) {
        return this.createQuoteCommand.execute({
            quoteMetadata,
        });
    }
    editQuote(quoteCode, quoteMetadata) {
        this.editQuoteCommand.execute({ quoteCode, quoteMetadata });
    }
    addQuoteComment(quoteCode, quoteComment, entryNumber) {
        return this.addQuoteCommentCommand.execute({
            quoteCode,
            quoteComment,
            entryNumber,
        });
    }
    performQuoteAction(quote, quoteAction) {
        return this.performQuoteActionCommand.execute({ quote, quoteAction });
    }
    requote(quoteCode) {
        return this.requoteCommand.execute({ quoteStarter: { quoteCode } });
    }
    getQuotesState(params) {
        return this.getQuotesStateQuery(params).getState();
    }
    getQuoteDetailsQueryState() {
        return combineLatest([
            this.isActionPerforming$,
            this.quoteDetailsState$.getState(),
        ]).pipe(map(([isLoading, state]) => ({
            ...state,
            loading: state.loading || isLoading,
        })));
    }
    getQuoteDetails() {
        return this.getQuoteDetailsQueryState().pipe(filter((state) => !state.loading), filter((state) => state.data !== undefined), map((state) => state.data), map((quote) => quote));
    }
    downloadAttachment(quoteCode, attachmentId) {
        return this.userIdService.takeUserId().pipe(mergeMap((userId) => {
            return this.quoteConnector.downloadAttachment(userId, quoteCode, attachmentId);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultQuoteCoreConfig = {
    quote: {
        actions: {
            primaryActions: [
                QuoteActionType.APPROVE,
                QuoteActionType.CHECKOUT,
                QuoteActionType.SUBMIT,
                QuoteActionType.REQUOTE,
            ],
            actionsOrderByState: {
                BUYER_DRAFT: [
                    QuoteActionType.SUBMIT,
                    QuoteActionType.EDIT,
                    QuoteActionType.CANCEL,
                ],
                BUYER_OFFER: [
                    QuoteActionType.CHECKOUT,
                    QuoteActionType.EDIT,
                    QuoteActionType.CANCEL,
                ],
                CANCELLED: [QuoteActionType.REQUOTE],
                EXPIRED: [QuoteActionType.REQUOTE, QuoteActionType.CANCEL],
                SELLER_REQUEST: [QuoteActionType.SUBMIT, QuoteActionType.EDIT],
                SELLER_DRAFT: [QuoteActionType.SUBMIT, QuoteActionType.EDIT],
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const facadeProviders = [
    QuoteService,
    {
        provide: QuoteFacade,
        useExisting: QuoteService,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteCoreModule {
    constructor(_quoteAddedToCartEventListener) {
        // Intentional empty constructor
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCoreModule, deps: [{ token: QuoteCartEventListener }], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QuoteCoreModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCoreModule, providers: [
            ...facadeProviders,
            QuoteConnector,
            provideDefaultConfig(defaultQuoteCoreConfig),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        ...facadeProviders,
                        QuoteConnector,
                        provideDefaultConfig(defaultQuoteCoreConfig),
                    ],
                }]
        }], ctorParameters: () => [{ type: QuoteCartEventListener }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CartUtilsService, QUOTE_ACTION_SERIALIZER, QUOTE_COMMENT_SERIALIZER, QUOTE_DISCOUNT_SERIALIZER, QUOTE_LIST_NORMALIZER, QUOTE_METADATA_SERIALIZER, QUOTE_NORMALIZER, QUOTE_STARTER_SERIALIZER, QuoteAdapter, QuoteCartEventListener, QuoteCartService, QuoteConnector, QuoteCoreConfig, QuoteCoreModule, QuoteDetailsReloadQueryEvent, QuoteService, QuoteStorefrontUtilsService };
//# sourceMappingURL=spartacus-quote-core.mjs.map
