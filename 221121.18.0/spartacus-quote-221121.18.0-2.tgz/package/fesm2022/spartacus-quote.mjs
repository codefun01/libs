import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { QuoteCoreModule } from '@spartacus/quote/core';
import { QuoteComponentsModule } from '@spartacus/quote/components';
import { QuoteOccModule } from '@spartacus/quote/occ';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QuoteModule, imports: [QuoteComponentsModule, QuoteCoreModule, QuoteOccModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteModule, imports: [QuoteComponentsModule, QuoteCoreModule, QuoteOccModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [QuoteComponentsModule, QuoteCoreModule, QuoteOccModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Triple-slash reference directive to include global type augmentations.
 * This ensures that Angular's compiler loads the type declarations
 * during the build process, enabling proper type checking for @HostListener decorators
 * with platform event syntax (e.g., 'keydown.Escape', 'keydown.ArrowUp').
 * for more about triple-slash directives, see: https://www.typescriptlang.org/docs/handbook/triple-slash-directives.html
 */
/// <reference path="../../types.d.ts" />
/*
 * Public API Surface of quote
 */

/**
 * Generated bundle index. Do not edit.
 */

export { QuoteModule };
//# sourceMappingURL=spartacus-quote.mjs.map
