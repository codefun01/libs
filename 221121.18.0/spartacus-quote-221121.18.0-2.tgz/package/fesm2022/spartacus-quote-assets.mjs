var quote$w = {
	confirmDialog: {
		name: "Název:",
		description: "Popis:",
		validity: "Tato nabídka platí do {{ expirationTime }}",
		option: {
			yes: "Ano",
			no: "Ne"
		},
		buyer: {
			submit: {
				a11y: {
					close: "Zavřít modální okno odeslání nabídky"
				},
				title: "Odeslat žádost o nabídku {{ code }}?",
				confirmNote: "Chcete tuto žádost o nabídku opravdu odeslat?",
				successMessage: "Žádost o nabídku byla úspěšně odeslána"
			},
			cancel: {
				a11y: {
					close: "Zavřít modální okno zrušení nabídky"
				},
				title: "Zrušit žádost o nabídku {{ code }}?",
				confirmNote: "Opravdu chcete zrušit tuto žádost o nabídku?",
				successMessage: "Žádost o nabídku byla zrušena"
			}
		},
		buyer_offer: {
			edit: {
				a11y: {
					close: "Zavřít modální okno úpravy nabídky"
				},
				title: "Potvrdit úpravu nabídky {{ code }}?",
				confirmNote: "Chcete tuto schválenou nabídku opravdu upravit?",
				warningNote: "Tato nabídka byla schválena, její úprava zabrání přechodu k pokladně, dokud nebudou schváleny nové úpravy."
			},
			cancel: {
				a11y: {
					close: "Zavřít modální okno zrušení nabídky"
				},
				title: "Zrušit nabídku {{ code }}?",
				confirmNote: "Chcete tuto nabídku opravdu zrušit?",
				successMessage: "Nabídka byla zrušena"
			},
			checkout: {
				a11y: {
					close: "Zavřít modální okno kontroly a potvrzení nabídky"
				},
				title: "Zkontrolovat a potvrdit nabídku {{ code }}?",
				confirmNote: "Opravdu chcete přijmout a potvrdit tuto nabídku?"
			}
		},
		expired: {
			edit: {
				a11y: {
					close: "Zavřít modální okno úpravy nabídky"
				},
				title: "Potvrdit úpravu nabídky {{ code }}?",
				confirmNote: "Chcete tuto nabídku s ukončenou platností opravdu upravit?",
				warningNote: "Platnost této nabídky skončila. Úprava této nabídky zabrání přechodu k pokladně, dokud nebudou schváleny nové úpravy."
			},
			requote: {
				a11y: {
					close: "Zavřít modální okno opakování nabídky"
				},
				title: "Znovu vytvořit žádost o nabídku {{ code }}?",
				confirmNote: "Opravdu chcete znovu vytvořit tuto žádost o nabídku?",
				warningNote: "Platnost této nabídky skončila. Jejím opětovným vytvořením vytvoříte novou žádost o nabídku se stejným obsahem, který lze upravit a odeslat ke schválení."
			}
		},
		seller: {
			submit: {
				a11y: {
					close: "Zavřít modální okno odeslání nabídky"
				},
				title: "Odeslat nabídku {{ code }}?",
				confirmNote: "Chcete tuto nabídku opravdu odeslat?",
				warningNote: "V závislosti na celkové hodnotě nabídky může být vyžadováno dodatečné schválení, než bude nákupčí moci nabídku zkontrolovat a potvrdit.",
				successMessage: "Nabídka byla úspěšně odeslána"
			}
		},
		sellerapprover: {
			approve: {
				a11y: {
					close: "Zavřít modální okno schválení nabídky"
				},
				title: "Schválit nabídku {{ code }}?",
				confirmNote: "Chcete tuto nabídku opravdu schválit?",
				successMessage: "Nabídka byla úspěšně schválena"
			},
			reject: {
				a11y: {
					close: "Zavřít modální okno zamítnutí nabídky"
				},
				title: "Zamítnout nabídku {{ code }}?",
				confirmNote: "Chcete tuto nabídku opravdu zamítnout?",
				successMessage: "Nabídka byla zamítnuta"
			}
		},
		cancelled: {
			requote: {
				a11y: {
					close: "Zavřít modální okno opakování nabídky"
				},
				title: "Znovu vytvořit žádost o nabídku {{ code }}?",
				confirmNote: "Opravdu chcete znovu vytvořit tuto žádost o nabídku?",
				warningNote: "Váš aktuální košík bude změněn na uložený košík."
			}
		},
		all: {
			edit: {
				a11y: {
					close: "Zavřít modální okno úpravy nabídky"
				},
				title: "Upravit nabídku {{ code }}?",
				confirmNote: "Chcete tuto nabídku opravdu upravit?",
				warningNote: "Váš aktuální košík bude změněn na uložený košík."
			}
		}
	},
	comments: {
		regionTitle: "Pole kontakt/komentář",
		title: "Kontakt",
		invalidComment: "Neplatný vstup – zadejte znovu…",
		allProducts: "Všechny produkty"
	},
	commons: {
		requestQuote: "Požádat o nabídku",
		cart: "Košík",
		minRequestInitiationNote: "Pro odeslání nabídky je vyžadován minimální mezisoučet ${{minValue}}. ",
		savedActiveCart: "Váš aktuální košík byl změněn na uložený košík {{ code }}"
	},
	header: {
		buyerEdit: {
			a11y: {
				cancel: "Zrušit úpravu informací hlavičky nabídky",
				save: "Uložit informace hlavičky nabídky"
			}
		},
		overview: {
			regionTitle: "Shrnutí detailů nabídky",
			id: "ID nabídky",
			status: "Status",
			information: "Informace o nabídce",
			name: "Název",
			description: "Popis",
			charactersLeft: "zbývá znaků: {{count}}",
			priceAndExpiry: "Cena a konec platnosti",
			estimatedTotal: "Odhadovaný celkový součet",
			total: "Celkem",
			expirationTime: "Datum konce platnosti",
			a11y: {
				edit: "Upravit informace hlavičky nabídky"
			},
			createdAndUpdated: "Vytvořeno a aktualizováno",
			createdDate: "Vytvořeno",
			lastUpdatedDate: "Poslední aktualizace"
		}
	},
	httpHandlers: {
		cartValidationIssue: "Vyskytl se problém s vašimi položkami. Zkontrolujte svůj košík.",
		quoteCartIssue: "Položky v košíku nelze měnit. Přejděte k pokladně.",
		absoluteDiscountIssue: "Vyberte slevu, která nepřesahuje celkovou hodnotu.",
		expirationDateIssue: "Vyberte datum konce platnosti, které je v budoucnosti.",
		threshold: {
			underThresholdError: "Celková cena požadované nabídky nedosahuje na minimální prahovou hodnotu."
		},
		expired: "Platnost nabídky vypršela. Je třeba znovu odeslat žádost o nabídku, abyste obdrželi novou nabídku dodavatele.",
		downloadPDFError: "Něco se pokazilo. Nelze získat dokument návrhu v PDF."
	},
	items: {
		regionTitle: "Položky v košíku"
	},
	links: {
		newCart: "Nový košík",
		quotes: "Nabídky",
		download: "Stáhnout dokument návrhu",
		order: "Detail objednávky",
		a11y: {
			newCart: "Vytvořit nový prázdný košík a přejít k němu.",
			quotes: "Přejít k seznamu výsledků vyhledávání nabídek.",
			download: "Zahájit stahování návrhu nabídky.",
			order: "Přejít na objednávku spojenou s touto nabídkou"
		}
	},
	list: {
		regionTitle: "Souhrn seznamu nabídky",
		title: "Seznam nabídky",
		name: "Název",
		updated: "Aktualizováno",
		sortBy: "Řadit podle",
		sortQuotes: "Řadit nabídky",
		empty: "Pro tento účet nemáme žádné záznamy nabídek.",
		quoteId: "ID nabídky",
		status: "Status",
		clickableRow: "Kliknutím na řádek zobrazíte detaily nabídky."
	},
	states: {
		BUYER_DRAFT: "Koncept",
		BUYER_SUBMITTED: "Odesláno",
		BUYER_ACCEPTED: "Přijato",
		BUYER_APPROVED: "Schváleno",
		BUYER_REJECTED: "Zamítnuto",
		BUYER_OFFER: "Nabídka dodavatele",
		BUYER_ORDERED: "Objednáno",
		SELLER_DRAFT: "Koncept",
		SELLER_REQUEST: "Vyžádáno",
		SELLER_SUBMITTED: "Odesláno",
		SELLERAPPROVER_DRAFT: "Koncept",
		SELLERAPPROVER_PENDING: "Čeká na schválení",
		SELLERAPPROVER_APPROVED: "Schváleno",
		SELLERAPPROVER_REJECTED: "Zamítnuto",
		CREATED: "Vytvořeno",
		CANCELLED: "Zrušeno",
		EXPIRED: "Skončila platnost"
	},
	summary: {
		regionTitle: "Souhrn objednávky",
		actions: {
			APPROVE: "Schválit nabídku",
			CANCEL: "Zrušit nabídku",
			CHECKOUT: "Přijmout a k pokladně",
			EDIT: "Upravit nabídku",
			REJECT: "Zamítnout nabídku",
			REQUOTE: "Požádat o novou nabídku",
			SAVE: "Uložit nabídku",
			SUBMIT: "Odeslat nabídku",
			VIEW: "Zobrazit nabídku"
		},
		prices: {
			title: "Souhrn objednávky",
			subtotal: "Mezisoučet",
			productDiscount: "Sleva položky",
			orderDiscount: "Sleva na objednávku",
			quoteDiscount: "Sleva z nabídky",
			total: "Celkem",
			hint: "V celkovém součtu nejsou zahrnuty žádné daně."
		},
		sellerEdit: {
			discount: "Sleva",
			apply: "Použít",
			expiryDate: "Datum konce platnosti",
			discountValidationText: "Zadejte platnou slevu v procentech",
			a11y: {
				apply: "Zadanou hodnotu slevy aplikujete na tuto nabídku kliknutím.",
				discount: "Zadejte slevu v procentech, která se má použít na tuto nabídku.",
				expiryDate: "Zadejte datum konce platnosti této nabídky."
			}
		}
	}
};
var quote$x = {
	quote: quote$w
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const cs = {
    quote: quote$x,
};

var quote$u = {
	confirmDialog: {
		name: "Name:",
		description: "Beschreibung:",
		validity: "Das Angebot ist gültig bis {{ expirationTime }}",
		option: {
			yes: "Ja",
			no: "Nein"
		},
		buyer: {
			submit: {
				a11y: {
					close: "Modalen Dialog zum Senden des Angebots schließen"
				},
				title: "Angebotsanforderung {{ code }} senden?",
				confirmNote: "Möchten Sie diese Angebotsanforderung wirklich senden?",
				successMessage: "Angebotsanforderung erfolgreich gesendet"
			},
			cancel: {
				a11y: {
					close: "Modalen Dialog zum Stornieren des Angebots schließen"
				},
				title: "Angebotsanforderung {{ code }} stornieren?",
				confirmNote: "Möchten Sie diese Angebotsanforderung wirklich stornieren?",
				successMessage: "Angebotsanforderung storniert"
			}
		},
		buyer_offer: {
			edit: {
				a11y: {
					close: "Modalen Dialog zum Bearbeiten des Angebots schließen"
				},
				title: "Bearbeitung von Angebot {{ code }} bestätigen?",
				confirmNote: "Möchten Sie dieses genehmigte Angebot wirklich bearbeiten?",
				warningNote: "Dieses Angebot wurde genehmigt. Wenn dieses Angebot bearbeitet wird, ist die Bezahlung erst nach Genehmigung der neuen Änderungen möglich."
			},
			cancel: {
				a11y: {
					close: "Modalen Dialog zum Stornieren des Angebots schließen"
				},
				title: "Angebot {{ code }} stornieren?",
				confirmNote: "Möchten Sie dieses Angebot wirklich stornieren?",
				successMessage: "Angebot storniert"
			},
			checkout: {
				a11y: {
					close: "Modalen Dialog zum Bezahlen des Angebots schließen"
				},
				title: "Angebot {{ code }} bezahlen?",
				confirmNote: "Möchten Sie dieses Angebot wirklich akzeptieren und bezahlen?"
			}
		},
		expired: {
			edit: {
				a11y: {
					close: "Modalen Dialog zum Bearbeiten des Angebots schließen"
				},
				title: "Bearbeitung von Angebot {{ code }} bestätigen?",
				confirmNote: "Möchten Sie dieses abgelaufene Angebot wirklich bearbeiten?",
				warningNote: "Dieses Angebot ist abgelaufen. Wenn das Angebot bearbeitet wird, ist die Bezahlung erst nach Genehmigung der neuen Änderungen möglich."
			},
			requote: {
				a11y: {
					close: "Modalen Dialog zum Neuerstellen des Angebots schließen"
				},
				title: "Angebotsanforderung {{ code }} erneut erstellen?",
				confirmNote: "Möchten Sie diese Angebotsanforderung wirklich erneut erstellen?",
				warningNote: "Dieses Angebot ist abgelaufen. Durch eine Neuerstellung wird eine neue Angebotsanforderung mit denselben Inhalten erstellt, die bearbeitet und dann zur Genehmigung abgesendet werden kann."
			}
		},
		seller: {
			submit: {
				a11y: {
					close: "Modalen Dialog zum Senden des Angebots schließen"
				},
				title: "Angebot {{ code }} senden?",
				confirmNote: "Möchten Sie dieses Angebot wirklich senden?",
				warningNote: "Abhängig vom Gesamtwert des Angebots ist möglicherweise eine zusätzliche Genehmigung erforderlich, bevor der Käufer dieses Angebot bezahlen kann.",
				successMessage: "Angebot erfolgreich gesendet"
			}
		},
		sellerapprover: {
			approve: {
				a11y: {
					close: "Modalen Dialog zum Genehmigen des Angebots schließen"
				},
				title: "Angebot {{ code }} genehmigen?",
				confirmNote: "Möchten Sie dieses Angebot wirklich genehmigen?",
				successMessage: "Angebot erfolgreich genehmigt"
			},
			reject: {
				a11y: {
					close: "Modalen Dialog zum Ablehnen des Angebots schließen"
				},
				title: "Angebot {{ code }} ablehnen?",
				confirmNote: "Möchten Sie dieses Angebot wirklich ablehnen?",
				successMessage: "Angebot abgelehnt"
			}
		},
		cancelled: {
			requote: {
				a11y: {
					close: "Modalen Dialog zum Neuerstellen des Angebots schließen"
				},
				title: "Angebotsanforderung {{ code }} erneut erstellen?",
				confirmNote: "Möchten Sie diese Angebotsanforderung wirklich erneut erstellen?",
				warningNote: "Ihr aktueller Warenkorb wird in einen gespeicherten Warenkorb umgewandelt."
			}
		},
		all: {
			edit: {
				a11y: {
					close: "Modalen Dialog zum Bearbeiten des Angebots schließen"
				},
				title: "Angebot {{ code }} bearbeiten?",
				confirmNote: "Möchten Sie dieses Angebot wirklich bearbeiten?",
				warningNote: "Ihr aktueller Warenkorb wird in einen gespeicherten Warenkorb umgewandelt."
			}
		}
	},
	comments: {
		regionTitle: "Kontakt/Kommentarfeld",
		title: "Kontakt",
		invalidComment: "Ungültige Eingabe, versuchen Sie es noch einmal...",
		allProducts: "Alle Produkte"
	},
	commons: {
		requestQuote: "Angebot anfordern",
		cart: "Warenkorb",
		minRequestInitiationNote: "Mindestens eine Zwischensumme von {{minValue}} $ ist zum Senden eines Angebots erforderlich ",
		savedActiveCart: "Ihr aktiver Warenkorb wurde in den gespeicherten Warenkorb {{ code }} umgewandelt"
	},
	header: {
		buyerEdit: {
			a11y: {
				cancel: "Bearbeitung der Angebotskopfinformationen abbrechen",
				save: "Angebotskopfinformationen speichern"
			}
		},
		overview: {
			regionTitle: "Zusammenfassung der Angebotsdetails",
			id: "Angebots-ID",
			status: "Status",
			information: "Angebotsinformationen",
			name: "Name",
			description: "Beschreibung",
			charactersLeft: "Zeichen übrig: {{count}}",
			priceAndExpiry: "Preis und Ablauf",
			estimatedTotal: "Geschätzte Summe",
			total: "Gesamtsumme",
			expirationTime: "Ablaufdatum",
			a11y: {
				edit: "Angebotskopfinformationen bearbeiten"
			},
			createdAndUpdated: "Erstellt und aktualisiert",
			createdDate: "Erstellt",
			lastUpdatedDate: "Zuletzt aktualisiert"
		}
	},
	httpHandlers: {
		cartValidationIssue: "In Zusammenhang mit Ihren Einträgen sind Probleme aufgetreten. Überprüfen Sie Ihren Warenkorb.",
		quoteCartIssue: "Keine Änderungen den Warenkorbeinträgen möglich. Gehen Sie zur Kasse",
		absoluteDiscountIssue: "Wählen Sie einen Rabatt aus, der den Gesamtwert nicht überschreitet",
		expirationDateIssue: "Wählen Sie ein Ablaufdatum in der Zukunft aus",
		threshold: {
			underThresholdError: "Gesamtpreis des angeforderten Angebots entspricht nicht dem Schwellenwert für das Minimum"
		},
		expired: "Dieses Angebot ist abgelaufen. Sie müssen Ihre Angebotsanforderung erneut senden, um ein weiteres Anbieterangebot zu erhalten.",
		downloadPDFError: "Es ist ein Fehler aufgetreten. Die PDF-Datei für den Vorschlagsbeleg kann nicht abgerufen werden."
	},
	items: {
		regionTitle: "Warenkorbpositionen"
	},
	links: {
		newCart: "Neuer Warenkorb",
		quotes: "Angebote",
		download: "Vorschlag herunterladen",
		order: "Bestelldetails",
		a11y: {
			newCart: "Erstellen Sie einen neuen leeren Warenkorb, und wechseln Sie zu ihm.",
			quotes: "Navigieren Sie zur Ergebnisliste für die Angebotssuche.",
			download: "Herunterladen eines Angebotsvorschlags starten",
			order: "Zur Bestellung navigieren, die zu diesem Angebot gehört"
		}
	},
	list: {
		regionTitle: "Angebotslistenzusammenfassung",
		title: "Angebotsliste",
		name: "Name",
		updated: "Aktualisiert",
		sortBy: "Sortieren nach",
		sortQuotes: "Angebote sortieren",
		empty: "Für dieses Konto gibt es keine Angebotsdatensätze.",
		quoteId: "Angebots-ID",
		status: "Status",
		clickableRow: "Für weitere Angebotsdetails auf die Zeile klicken"
	},
	states: {
		BUYER_DRAFT: "Entwurf",
		BUYER_SUBMITTED: "Gesendet",
		BUYER_ACCEPTED: "Akzeptiert",
		BUYER_APPROVED: "Genehmigt",
		BUYER_REJECTED: "Abgelehnt",
		BUYER_OFFER: "Anbieterangebot",
		BUYER_ORDERED: "Bestellt",
		SELLER_DRAFT: "Entwurf",
		SELLER_REQUEST: "Angefordert",
		SELLER_SUBMITTED: "Gesendet",
		SELLERAPPROVER_DRAFT: "Entwurf",
		SELLERAPPROVER_PENDING: "Genehmigung ausstehend",
		SELLERAPPROVER_APPROVED: "Genehmigt",
		SELLERAPPROVER_REJECTED: "Abgelehnt",
		CREATED: "Erstellt",
		CANCELLED: "Storniert",
		EXPIRED: "Abgelaufen"
	},
	summary: {
		regionTitle: "Bestellungszusammenfassung",
		actions: {
			APPROVE: "Angebot genehmigen",
			CANCEL: "Angebot stornieren",
			CHECKOUT: "Akzeptieren und bezahlen",
			EDIT: "Angebot bearbeiten",
			REJECT: "Angebot ablehnen",
			REQUOTE: "Neues Angebot anfordern",
			SAVE: "Angebot speichern",
			SUBMIT: "Angebot senden",
			VIEW: "Angebot anzeigen"
		},
		prices: {
			title: "Bestellungszusammenfassung",
			subtotal: "Zwischensumme",
			productDiscount: "Positionsrabatt",
			orderDiscount: "Bestellungsrabatt",
			quoteDiscount: "Angebotsrabatt",
			total: "Gesamtsumme",
			hint: "Die Gesamtsumme enthält keine Steuern"
		},
		sellerEdit: {
			discount: "Rabatt",
			apply: "Anwenden",
			expiryDate: "Ablaufdatum",
			discountValidationText: "Geben Sie einen gültigen prozentualen Rabatt ein",
			a11y: {
				apply: "Klicken, um den eingegebenen Rabattwert auf dieses Angebot anzuwenden",
				discount: "Geben Sie einen prozentualen Rabattwert ein, der auf dieses Angebot angewendet werden soll",
				expiryDate: "Geben Sie ein Ablaufdatum für dieses Angebot ein"
			}
		}
	}
};
var quote$v = {
	quote: quote$u
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const de = {
    quote: quote$v,
};

var quote$s = {
	confirmDialog: {
		name: "Name:",
		description: "Description:",
		validity: "This quote is valid until {{ expirationTime }}",
		option: {
			yes: "Yes",
			no: "No"
		},
		buyer: {
			submit: {
				a11y: {
					close: "Close submit quote modal"
				},
				title: "Submit Quote Request {{ code }}?",
				confirmNote: "Are you sure you want to submit this quote request?",
				successMessage: "Quote request submitted successfully"
			},
			cancel: {
				a11y: {
					close: "Close cancel quote modal"
				},
				title: "Cancel Quote Request {{ code }}?",
				confirmNote: "Are you sure you want to cancel this quote request?",
				successMessage: "Quote request cancelled"
			}
		},
		buyer_offer: {
			edit: {
				a11y: {
					close: "Close edit quote modal"
				},
				title: "Confirm Edit Quote {{ code }}?",
				confirmNote: "Are you sure you want to edit this approved quote?",
				warningNote: "This Quote has been Approved. Editing this Quote will prevent Checkout until new edits are approved."
			},
			cancel: {
				a11y: {
					close: "Close cancel quote modal"
				},
				title: "Cancel Quote {{ code }}?",
				confirmNote: "Are you sure you want to cancel this quote?",
				successMessage: "Quote cancelled"
			},
			checkout: {
				a11y: {
					close: "Close checkout quote modal"
				},
				title: "Checkout Quote {{ code }}?",
				confirmNote: "Are you sure you want to accept and checkout this quote?"
			}
		},
		expired: {
			edit: {
				a11y: {
					close: "Close edit quote modal"
				},
				title: "Confirm Edit Quote {{ code }}?",
				confirmNote: "Are you sure you want to edit this expired quote?",
				warningNote: "This Quote is expired. Editing this quote will prevent checkout until new edits are approved."
			},
			requote: {
				a11y: {
					close: "Close requote modal"
				},
				title: "Recreate Quote Request {{ code }}?",
				confirmNote: "Are you sure you want to recreate this quote request?",
				warningNote: "This Quote is expired. Re-quoting it will create a new quote request with same contents, which can be edited and submitted for approval afterwards."
			}
		},
		seller: {
			submit: {
				a11y: {
					close: "Close submit quote modal"
				},
				title: "Submit Quote {{ code }}?",
				confirmNote: "Are you sure you want to submit this quote?",
				warningNote: "Depending on the total value of the quote, an additional approval might be required before the buyer can check out this quote.",
				successMessage: "Quote submitted successfully"
			}
		},
		sellerapprover: {
			approve: {
				a11y: {
					close: "Close approve quote modal"
				},
				title: "Approve Quote {{ code }}?",
				confirmNote: "Are you sure you want to approve this quote?",
				successMessage: "Quote approved successfully"
			},
			reject: {
				a11y: {
					close: "Close reject quote modal"
				},
				title: "Reject Quote {{ code }}?",
				confirmNote: "Are you sure you want to reject this quote?",
				successMessage: "Quote rejected"
			}
		},
		cancelled: {
			requote: {
				a11y: {
					close: "Close requote modal"
				},
				title: "Recreate Quote Request {{ code }}?",
				confirmNote: "Are you sure you want to recreate this quote request?",
				warningNote: "Your current cart will be converted to a saved cart."
			}
		},
		all: {
			edit: {
				a11y: {
					close: "Close edit quote modal"
				},
				title: "Edit Quote {{ code }}?",
				confirmNote: "Are you sure you want to edit this quote?",
				warningNote: "Your current cart will be converted to a saved cart."
			}
		}
	},
	comments: {
		regionTitle: "Contact/Comment Box",
		title: "Contact",
		invalidComment: "Invalid Input - Please type again...",
		allProducts: "All Products"
	},
	commons: {
		requestQuote: "Request Quote",
		cart: "Cart",
		minRequestInitiationNote: "Minimum ${{minValue}} subtotal is required to submit a quote ",
		savedActiveCart: "Your active cart was converted to saved cart {{ code }}"
	},
	header: {
		buyerEdit: {
			a11y: {
				cancel: "Cancel editing quote header information",
				save: "Save quote header information"
			}
		},
		overview: {
			regionTitle: "Quote details summary",
			id: "Quote ID",
			status: "Status",
			information: "Quote Information",
			name: "Name",
			description: "Description",
			purchaseOrderNumber: "Purchase order number",
			optional: "optional",
			charactersLeft: "characters left: {{count}}",
			priceAndExpiry: "Price & Expiry",
			estimatedTotal: "Estimated Total",
			total: "Total",
			expirationTime: "Expiry Date",
			a11y: {
				edit: "Edit quote header information"
			},
			createdAndUpdated: "Created & Updated",
			createdDate: "Created",
			lastUpdatedDate: "Last Updated"
		}
	},
	httpHandlers: {
		cartValidationIssue: "There are problems with your entries. Please review your cart.",
		quoteCartIssue: "Not possible to do changes to cart entries. Proceed to checkout",
		absoluteDiscountIssue: "Choose a discount that does not exceed the total value",
		expirationDateIssue: "Choose an expiration date in the future",
		threshold: {
			underThresholdError: "Total price of requested quote does not meet the minimum threshold"
		},
		expired: "This quote has expired. You must resubmit your quote request to receive another vendor quote.",
		downloadPDFError: "Something went wrong. Unable to obtain the proposal document PDF."
	},
	items: {
		regionTitle: "Cart items"
	},
	links: {
		newCart: "New Cart",
		quotes: "Quotes",
		download: "Download Proposal",
		order: "Order Detail",
		a11y: {
			newCart: "Create new empty cart and navigate to it.",
			quotes: "Navigate to quote search result list.",
			download: "Start downloading a quote proposal",
			order: "Navigate to order associated with this quote"
		}
	},
	list: {
		regionTitle: "Quote list summary",
		title: "Quote List",
		name: "Name",
		updated: "Updated",
		sortBy: "Sort by",
		sortQuotes: "Sort Quotes",
		empty: "We have no quote records for this account.",
		quoteId: "Quote ID",
		status: "Status",
		clickableRow: "Click on the row for more quote details"
	},
	states: {
		BUYER_DRAFT: "Draft",
		BUYER_SUBMITTED: "Submitted",
		BUYER_ACCEPTED: "Accepted",
		BUYER_APPROVED: "Approved",
		BUYER_REJECTED: "Rejected",
		BUYER_OFFER: "Vendor Quote",
		BUYER_ORDERED: "Ordered",
		SELLER_DRAFT: "Draft",
		SELLER_REQUEST: "Requested",
		SELLER_SUBMITTED: "Submitted",
		SELLERAPPROVER_DRAFT: "Draft",
		SELLERAPPROVER_PENDING: "Pending Approval",
		SELLERAPPROVER_APPROVED: "Approved",
		SELLERAPPROVER_REJECTED: "Rejected",
		CREATED: "Created",
		CANCELLED: "Cancelled",
		EXPIRED: "Expired"
	},
	summary: {
		regionTitle: "Order Summary",
		actions: {
			APPROVE: "Approve Quote",
			CANCEL: "Cancel Quote",
			CHECKOUT: "Accept and Checkout",
			EDIT: "Edit Quote",
			REJECT: "Reject Quote",
			REQUOTE: "Request new Quote",
			SAVE: "Save Quote",
			SUBMIT: "Submit Quote",
			VIEW: "View Quote"
		},
		prices: {
			title: "Order Summary",
			subtotal: "Subtotal",
			productDiscount: "Item Discount",
			orderDiscount: "Order Discount",
			quoteDiscount: "Quote Discount",
			total: "Total",
			hint: "No taxes are included in the total"
		},
		sellerEdit: {
			discount: "Discount",
			apply: "Apply",
			expiryDate: "Expiry Date",
			discountValidationText: "Enter a valid percentage discount",
			a11y: {
				apply: "Click to apply the entered discount value to this quote",
				discount: "Enter a percentage discount value to be applied to this quote",
				expiryDate: "Enter an expiry date for this quote"
			}
		}
	}
};
var quote$t = {
	quote: quote$s
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const en = {
    quote: quote$t,
};

var quote$q = {
	confirmDialog: {
		name: "Nombre:",
		description: "Descripción:",
		validity: "Esta oferta es válida hasta {{ expirationTime }}",
		option: {
			yes: "Sí",
			no: "No"
		},
		buyer: {
			submit: {
				a11y: {
					close: "Cerrar el modo de envío de oferta"
				},
				title: "¿Desea enviar la solicitud de oferta {{ code }}?",
				confirmNote: "¿Confirma que desea enviar esta solicitud de oferta?",
				successMessage: "Solicitud de oferta enviada correctamente"
			},
			cancel: {
				a11y: {
					close: "Cerrar modo de cancelación de oferta"
				},
				title: "¿Desea cancelar la solicitud de oferta {{ code }}?",
				confirmNote: "¿Confirma que desea cancelar esta solicitud de oferta?",
				successMessage: "Solicitud de oferta cancelada"
			}
		},
		buyer_offer: {
			edit: {
				a11y: {
					close: "Cerrar el modo de edición de ofertas"
				},
				title: "¿Confirma la edición de oferta {{ code }}?",
				confirmNote: "¿Confirma que desea editar esta oferta aprobada?",
				warningNote: "Esta oferta ya se aprobó. Si la edita, no podrá realizar el pago hasta que se aprueben las nuevas modificaciones."
			},
			cancel: {
				a11y: {
					close: "Cerrar modo de cancelación de oferta"
				},
				title: "¿Cancelar oferta {{ code }}?",
				confirmNote: "¿Confirma que desea cancelar esta oferta?",
				successMessage: "Oferta cancelada"
			},
			checkout: {
				a11y: {
					close: "Cerrar el modo de pago de oferta"
				},
				title: "¿Finalizar la compra de la oferta{{ code }}?",
				confirmNote: "¿Confirma que desea aceptar y pagar esta oferta?"
			}
		},
		expired: {
			edit: {
				a11y: {
					close: "Cerrar el modo de edición de ofertas"
				},
				title: "¿Confirma la edición de la oferta {{ code }}?",
				confirmNote: "¿Confirma que desea editar esta oferta vencida?",
				warningNote: "Esta oferta ha caducado. Si la edita, no podrá realizar el pago hasta que se aprueben las nuevas modificaciones."
			},
			requote: {
				a11y: {
					close: "Cerrar modo para volver a crear oferta"
				},
				title: "¿Recrear solicitud de oferta {{ code }}?",
				confirmNote: "¿Confirma que desea recrear esta solicitud de oferta?",
				warningNote: "Esta oferta ha caducado. Si la vuelve a crear, se generará una nueva solicitud de oferta con el mismo contenido, que se puede editar y enviar para su aprobación posterior."
			}
		},
		seller: {
			submit: {
				a11y: {
					close: "Cerrar el modo de envío de oferta"
				},
				title: "¿Enviar oferta {{ code }}?",
				confirmNote: "¿Confirma que desea enviar esta oferta?",
				warningNote: "Dependiendo del valor total de la oferta, podría requerirse una aprobación adicional antes de que el comprador pueda consultar esta oferta.",
				successMessage: "Oferta enviada correctamente"
			}
		},
		sellerapprover: {
			approve: {
				a11y: {
					close: "Cerrar modo de aprobación de oferta"
				},
				title: "¿Aprobar oferta {{ code }}?",
				confirmNote: "¿Confirma que desea aprobar esta oferta?",
				successMessage: "Oferta aprobada correctamente"
			},
			reject: {
				a11y: {
					close: "Cerrar modo de oferta rechazada"
				},
				title: "¿Rechazar oferta {{ code }}?",
				confirmNote: "¿Confirma que desea rechazar esta oferta?",
				successMessage: "Oferta rechazada"
			}
		},
		cancelled: {
			requote: {
				a11y: {
					close: "Cerrar modo para volver a crear oferta"
				},
				title: "¿Recrear solicitud de oferta {{ code }}?",
				confirmNote: "¿Confirma que desea recrear esta solicitud de oferta?",
				warningNote: "Su cesta actual se convertirá en una cesta guardada."
			}
		},
		all: {
			edit: {
				a11y: {
					close: "Cerrar el modo de edición de ofertas"
				},
				title: "¿Editar oferta {{ code }}?",
				confirmNote: "¿Confirma que desea editar esta oferta?",
				warningNote: "Su cesta actual se convertirá en una cesta guardada."
			}
		}
	},
	comments: {
		regionTitle: "Contacto/Cuadro de comentarios",
		title: "Contacto",
		invalidComment: "Entrada no válida. Escriba nuevamente...",
		allProducts: "Todos los productos"
	},
	commons: {
		requestQuote: "Solicitar oferta",
		cart: "Cesta",
		minRequestInitiationNote: "Se requiere un subtotal mínimo de ${{minValue}} para enviar una oferta ",
		savedActiveCart: "Su cesta activa se convirtió en cesta guardada {{ code }}"
	},
	header: {
		buyerEdit: {
			a11y: {
				cancel: "Cancelar la edición de la información del encabezado de oferta",
				save: "Guardar la información del encabezado de oferta"
			}
		},
		overview: {
			regionTitle: "Resumen de detalles de la oferta",
			id: "ID de oferta",
			status: "Estado",
			information: "Información de la oferta",
			name: "Nombre",
			description: "Descripción",
			charactersLeft: "caracteres restantes: {{count}}",
			priceAndExpiry: "Precio y caducidad",
			estimatedTotal: "Total estimado",
			total: "Total",
			expirationTime: "Fecha de caducidad",
			a11y: {
				edit: "Editar información de encabezado de oferta"
			},
			createdAndUpdated: "Creado y actualizado",
			createdDate: "Creado",
			lastUpdatedDate: "Última actualización"
		}
	},
	httpHandlers: {
		cartValidationIssue: "Hay problemas con sus entradas. Revise su cesta.",
		quoteCartIssue: "No es posible realizar cambios en las entradas de la cesta. Proceda al pago",
		absoluteDiscountIssue: "Elija un descuento que no exceda el valor total",
		expirationDateIssue: "Elija una fecha de vencimiento futura",
		threshold: {
			underThresholdError: "El precio total de la oferta solicitada no alcanza el umbral mínimo"
		},
		expired: "Esta oferta ha caducado. Debe volver a enviar su solicitud de oferta para recibir la oferta de otro proveedor.",
		downloadPDFError: "Algo salió mal. No se pudo obtener el documento de propuesta en formato PDF."
	},
	items: {
		regionTitle: "Elementos de la cesta"
	},
	links: {
		newCart: "Nueva cesta",
		quotes: "Ofertas",
		download: "Descargar propuesta",
		order: "Detalles del pedido",
		a11y: {
			newCart: "Crear una cesta nueva vacía e ir hasta ella.",
			quotes: "Ir a la lista de resultados de búsqueda de ofertas.",
			download: "Comenzar a descargar la propuesta de oferta",
			order: "Navegar a pedido asociado a esta oferta"
		}
	},
	list: {
		regionTitle: "Resumen de lista de ofertas",
		title: "Lista de ofertas",
		name: "Nombre",
		updated: "Actualizado",
		sortBy: "Ordenar por",
		sortQuotes: "Ordenar ofertas",
		empty: "No tenemos registro de ofertas para esta cuenta.",
		quoteId: "ID de oferta",
		status: "Estado",
		clickableRow: "Haga clic en la fila para obtener más información de las ofertas"
	},
	states: {
		BUYER_DRAFT: "Borrador",
		BUYER_SUBMITTED: "Enviada",
		BUYER_ACCEPTED: "Aceptada",
		BUYER_APPROVED: "Aprobada",
		BUYER_REJECTED: "Rechazada",
		BUYER_OFFER: "Oferta de proveedor",
		BUYER_ORDERED: "Pedida",
		SELLER_DRAFT: "Borrador",
		SELLER_REQUEST: "Solicitada",
		SELLER_SUBMITTED: "Enviada",
		SELLERAPPROVER_DRAFT: "Borrador",
		SELLERAPPROVER_PENDING: "Aprobación pendiente",
		SELLERAPPROVER_APPROVED: "Aprobada",
		SELLERAPPROVER_REJECTED: "Rechazada",
		CREATED: "Creada",
		CANCELLED: "Cancelada",
		EXPIRED: "Caducada"
	},
	summary: {
		regionTitle: "Resumen del pedido",
		actions: {
			APPROVE: "Aprobar oferta",
			CANCEL: "Cancelar oferta",
			CHECKOUT: "Aceptar y finalizar compra",
			EDIT: "Editar oferta",
			REJECT: "Rechazar oferta",
			REQUOTE: "Solicitar oferta nueva",
			SAVE: "Grabar oferta",
			SUBMIT: "Enviar oferta",
			VIEW: "Ver oferta"
		},
		prices: {
			title: "Resumen del pedido",
			subtotal: "Subtotal",
			productDiscount: "Descuento del elemento",
			orderDiscount: "Descuento del pedido",
			quoteDiscount: "Descuentos de la oferta",
			total: "Total",
			hint: "No se incluyen impuestos en el total"
		},
		sellerEdit: {
			discount: "Descuento",
			apply: "Aplicar",
			expiryDate: "Fecha de caducidad",
			discountValidationText: "Ingresar un descuento de porcentaje válido",
			a11y: {
				apply: "Haga clic para aplicar el valor de descuento ingresado a esta oferta",
				discount: "Ingrese un valor de descuento porcentual que se aplicará a esta oferta",
				expiryDate: "Ingrese una fecha de vencimiento para esta oferta"
			}
		}
	}
};
var quote$r = {
	quote: quote$q
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const es = {
    quote: quote$r,
};

var quote$o = {
	confirmDialog: {
		name: "Nombre:",
		description: "Descripción:",
		validity: "Esta oferta es válida hasta el {{ expirationTime }}",
		option: {
			yes: "Sí",
			no: "No"
		},
		buyer: {
			submit: {
				a11y: {
					close: "Cerrar el modo de envío de oferta"
				},
				title: "¿Desea enviar la solicitud de oferta {{ code }}?",
				confirmNote: "¿Confirma que desea enviar esta solicitud de oferta?",
				successMessage: "Solicitud de oferta enviada correctamente"
			},
			cancel: {
				a11y: {
					close: "Cerrar modo de cancelación de oferta"
				},
				title: "¿Desea cancelar la solicitud de oferta {{ code }}?",
				confirmNote: "¿Confirma que desea cancelar esta solicitud de oferta?",
				successMessage: "Solicitud de oferta cancelada"
			}
		},
		buyer_offer: {
			edit: {
				a11y: {
					close: "Cerrar el modo de edición de ofertas"
				},
				title: "¿Confirma la edición de oferta {{ code }}?",
				confirmNote: "¿Confirma que desea editar esta oferta aprobada?",
				warningNote: "Esta oferta ya se aprobó. Si la edita, no podrá realizar el pago hasta que se aprueben las nuevas modificaciones."
			},
			cancel: {
				a11y: {
					close: "Cerrar modo de cancelación de oferta"
				},
				title: "¿Cancelar oferta {{ code }}?",
				confirmNote: "¿Confirma que desea cancelar esta oferta?",
				successMessage: "Oferta cancelada"
			},
			checkout: {
				a11y: {
					close: "Cerrar el modo de pago de oferta"
				},
				title: "¿Finalizar la compra de la oferta{{ code }}?",
				confirmNote: "¿Confirma que desea aceptar y pagar esta oferta?"
			}
		},
		expired: {
			edit: {
				a11y: {
					close: "Cerrar el modo de edición de oferta"
				},
				title: "¿Confirma la edición de oferta {{ code }}?",
				confirmNote: "¿Confirma que desea editar esta oferta vencida?",
				warningNote: "Esta oferta caducó. Si la edita, no podrá realizar el pago hasta que se aprueben las nuevas modificaciones."
			},
			requote: {
				a11y: {
					close: "Cerrar modo para volver a crear oferta"
				},
				title: "¿Recrear solicitud de oferta{{ code }}?",
				confirmNote: "¿Confirma que desea recrear esta solicitud de oferta?",
				warningNote: "Esta oferta caducó. Si la vuelve a crear, se generará una nueva solicitud de oferta con el mismo contenido, que se puede editar y enviar para su aprobación posterior."
			}
		},
		seller: {
			submit: {
				a11y: {
					close: "Cerrar el modo de envío de oferta"
				},
				title: "¿Enviar oferta {{ code }}?",
				confirmNote: "¿Confirma que desea enviar esta oferta?",
				warningNote: "Dependiendo del valor total de la oferta, podría requerirse una aprobación adicional antes de que el comprador pueda consultar esta oferta.",
				successMessage: "Oferta enviada correctamente"
			}
		},
		sellerapprover: {
			approve: {
				a11y: {
					close: "Cerrar modo de aprobación de oferta"
				},
				title: "¿Aprobar oferta {{ code }}?",
				confirmNote: "¿Confirma que desea aprobar esta oferta?",
				successMessage: "Oferta aprobada correctamente"
			},
			reject: {
				a11y: {
					close: "Cerrar modo de oferta rechazada"
				},
				title: "¿Rechazar oferta {{ code }}?",
				confirmNote: "¿Confirma que desea rechazar esta oferta?",
				successMessage: "Oferta rechazada"
			}
		},
		cancelled: {
			requote: {
				a11y: {
					close: "Cerrar modo de volver a crear oferta "
				},
				title: "¿Recrear solicitud de oferta{{ code }}?",
				confirmNote: "¿Confirma que desea recrear esta solicitud de oferta?",
				warningNote: "Su carro actual se convertirá en un carro guardado."
			}
		},
		all: {
			edit: {
				a11y: {
					close: "Cerrar el modo de edición de ofertas"
				},
				title: "¿Editar oferta {{ code }}?",
				confirmNote: "¿Confirma que desea editar esta oferta?",
				warningNote: "Su carro actual se convertirá en un carro guardado."
			}
		}
	},
	comments: {
		regionTitle: "Contacto/Cuadro de comentarios",
		title: "Contacto",
		invalidComment: "Entrada no válida. Escriba nuevamente...",
		allProducts: "Todos los productos"
	},
	commons: {
		requestQuote: "Solicitar oferta",
		cart: "Cesta",
		minRequestInitiationNote: "Se requiere un subtotal mínimo de ${{minValue}} para enviar una oferta ",
		savedActiveCart: "Su carro activo se convirtió en carro guardado {{ code }}"
	},
	header: {
		buyerEdit: {
			a11y: {
				cancel: "Cancelar la edición de la información del encabezado de oferta",
				save: "Guardar la información del encabezado de oferta"
			}
		},
		overview: {
			regionTitle: "Resumen de detalles de la oferta",
			id: "ID de oferta",
			status: "Estado",
			information: "Información de la oferta",
			name: "Nombre",
			description: "Descripción",
			charactersLeft: "caracteres restantes: {{count}}",
			priceAndExpiry: "Precio y caducidad",
			estimatedTotal: "Total estimado",
			total: "Total",
			expirationTime: "Fecha de caducidad",
			a11y: {
				edit: "Editar información de encabezado de oferta"
			},
			createdAndUpdated: "Creado y actualizado",
			createdDate: "Creado",
			lastUpdatedDate: "Última actualización"
		}
	},
	httpHandlers: {
		cartValidationIssue: "Hay problemas con sus entradas. Revise su carro.",
		quoteCartIssue: "No es posible realizar cambios en las entradas del carro. Proceda al pago",
		absoluteDiscountIssue: "Elija un descuento que no exceda el valor total",
		expirationDateIssue: "Elija una fecha de vencimiento futura",
		threshold: {
			underThresholdError: "El precio total de la oferta solicitada no alcanza el umbral mínimo"
		},
		expired: "Esta oferta caducó. Debe volver a enviar su solicitud de oferta para recibir la oferta de otro proveedor.",
		downloadPDFError: "Algo salió mal. No se pudo obtener el documento de propuesta en formato PDF."
	},
	items: {
		regionTitle: "Artículos del carro"
	},
	links: {
		newCart: "Nuevo carro",
		quotes: "Ofertas",
		download: "Descargar propuesta",
		order: "Detalles del pedido",
		a11y: {
			newCart: "Crear nuevo carro vacío e ir hasta él.",
			quotes: "Ir a la lista de resultados de búsqueda de ofertas.",
			download: "Comenzar a descargar la propuesta de oferta",
			order: "Navegar a pedido asociado a esta oferta"
		}
	},
	list: {
		regionTitle: "Resumen de lista de ofertas",
		title: "Lista de ofertas",
		name: "Nombre",
		updated: "Actualizados",
		sortBy: "Clasificar por",
		sortQuotes: "Clasificar ofertas",
		empty: "No tenemos registro de ofertas para esta cuenta.",
		quoteId: "ID de oferta",
		status: "Estado",
		clickableRow: "Haga clic en la fila para obtener más información de las ofertas"
	},
	states: {
		BUYER_DRAFT: "Borrador",
		BUYER_SUBMITTED: "Enviada",
		BUYER_ACCEPTED: "Aceptada",
		BUYER_APPROVED: "Aprobada",
		BUYER_REJECTED: "Rechazada",
		BUYER_OFFER: "Oferta de proveedor",
		BUYER_ORDERED: "Solicitada",
		SELLER_DRAFT: "Borrador",
		SELLER_REQUEST: "Solicitada",
		SELLER_SUBMITTED: "Enviada",
		SELLERAPPROVER_DRAFT: "Borrador",
		SELLERAPPROVER_PENDING: "Aprobación pendiente",
		SELLERAPPROVER_APPROVED: "Aprobada",
		SELLERAPPROVER_REJECTED: "Rechazada",
		CREATED: "Creada",
		CANCELLED: "Cancelada",
		EXPIRED: "Caducada"
	},
	summary: {
		regionTitle: "Resumen de la orden",
		actions: {
			APPROVE: "Aprobar oferta",
			CANCEL: "Cancelar oferta",
			CHECKOUT: "Aceptar y finalizar compra",
			EDIT: "Editar oferta",
			REJECT: "Rechazar oferta",
			REQUOTE: "Solicitar oferta nueva",
			SAVE: "Guardar oferta",
			SUBMIT: "Enviar oferta",
			VIEW: "Ver oferta"
		},
		prices: {
			title: "Resumen de oferta",
			subtotal: "Subtotal",
			productDiscount: "Descuento del artículo",
			orderDiscount: "Descuento del pedido",
			quoteDiscount: "Descuento de la oferta",
			total: "Total",
			hint: "No se incluyen impuestos en el total"
		},
		sellerEdit: {
			discount: "Descuento",
			apply: "Aplicar",
			expiryDate: "Fecha de caducidad",
			discountValidationText: "Ingresar un descuento de porcentaje válido",
			a11y: {
				apply: "Haga clic para aplicar el valor de descuento ingresado a esta oferta",
				discount: "Ingrese un valor de descuento porcentual que se aplicará a esta oferta",
				expiryDate: "Ingrese una fecha de vencimiento para esta oferta"
			}
		}
	}
};
var quote$p = {
	quote: quote$o
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const es_CO = {
    quote: quote$p,
};

var quote$m = {
	confirmDialog: {
		name: "Nom :",
		description: "Description :",
		validity: "Ce devis est valable jusqu'au {{ expirationTime }}",
		option: {
			yes: "Oui",
			no: "Non"
		},
		buyer: {
			submit: {
				a11y: {
					close: "Fermer la boîte de dialogue modale d'envoi du devis"
				},
				title: "Envoyer la demande de devis {{ code }} ?",
				confirmNote: "Voulez-vous vraiment envoyer cette demande de devis ?",
				successMessage: "La demande de devis a été envoyée avec succès."
			},
			cancel: {
				a11y: {
					close: "Fermer la boîte de dialogue modale d'annulation du devis"
				},
				title: "Annuler la demande de devis {{ code }} ?",
				confirmNote: "Voulez-vous vraiment annuler cette demande de devis ?",
				successMessage: "Demande de devis annulée"
			}
		},
		buyer_offer: {
			edit: {
				a11y: {
					close: "Fermer la boîte de dialogue modale de modification du devis"
				},
				title: "Confirmer la modification du devis {{ code }} ?",
				confirmNote: "Voulez-vous vraiment modifier ce devis approuvé ?",
				warningNote: "Ce devis a été approuvé. La modification de ce devis empêchera sa validation tant que les modifications n'auront pas été approuvées."
			},
			cancel: {
				a11y: {
					close: "Fermer la boîte de dialogue modale d'annulation du devis"
				},
				title: "Annuler le devis {{ code }} ?",
				confirmNote: "Voulez-vous vraiment annuler ce devis ?",
				successMessage: "Devis annulé"
			},
			checkout: {
				a11y: {
					close: "Fermer la boîte de dialogue modale de validation du devis"
				},
				title: "Valider le devis {{ code }} ?",
				confirmNote: "Voulez-vous vraiment accepter et valider ce devis ?"
			}
		},
		expired: {
			edit: {
				a11y: {
					close: "Fermer la boîte de dialogue modale de modification du devis"
				},
				title: "Confirmer la modification du devis {{ code }} ?",
				confirmNote: "Voulez-vous vraiment modifier ce devis expiré ?",
				warningNote: "Ce devis a expiré. La modification de ce devis empêchera sa validation tant que les modifications n'auront pas été approuvées."
			},
			requote: {
				a11y: {
					close: "Fermer la boîte de dialogue modale de recréation du devis"
				},
				title: "Recréer la demande de devis{{ code }} ?",
				confirmNote: "Voulez-vous vraiment recréer cette demande de devis ?",
				warningNote: "Ce devis a expiré. Le fait de le recréer générera une nouvelle demande de devis avec le même contenu, qui pourra être modifiée et soumise à approbation par la suite."
			}
		},
		seller: {
			submit: {
				a11y: {
					close: "Fermer la boîte de dialogue modale d'envoi du devis"
				},
				title: "Envoyer le devis {{ code }} ?",
				confirmNote: "Voulez-vous vraiment envoyer ce devis ?",
				warningNote: "Selon la valeur totale du devis, une approbation supplémentaire peut être nécessaire avant que l'acheteur puisse valider ce devis.",
				successMessage: "Devis envoyé avec succès"
			}
		},
		sellerapprover: {
			approve: {
				a11y: {
					close: "Fermer la boîte de dialogue modale d'approbation du devis"
				},
				title: "Approuver le devis {{ code }} ?",
				confirmNote: "Voulez-vous vraiment approuver ce devis ?",
				successMessage: "Devis approuvé avec succès"
			},
			reject: {
				a11y: {
					close: "Fermer la boîte de dialogue modale de refus du devis"
				},
				title: "Refuser le devis {{ code }} ?",
				confirmNote: "Voulez-vous vraiment refuser ce devis ?",
				successMessage: "Devis refusé"
			}
		},
		cancelled: {
			requote: {
				a11y: {
					close: "Fermer la boîte de dialogue modale de recréation de devis"
				},
				title: "Recréer la demande de devis{{ code }} ?",
				confirmNote: "Voulez-vous vraiment recréer cette demande de devis ?",
				warningNote: "Votre panier actuel sera converti en panier sauvegardé."
			}
		},
		all: {
			edit: {
				a11y: {
					close: "Fermer la boîte de dialogue modale de modification du devis"
				},
				title: "Modifier le devis {{ code }} ?",
				confirmNote: "Voulez-vous vraiment modifier ce devis ?",
				warningNote: "Votre panier actuel sera converti en panier sauvegardé."
			}
		}
	},
	comments: {
		regionTitle: "Cadre pour contact/commentaire",
		title: "Contact",
		invalidComment: "Saisie non valide - Veuillez ressaisir du texte...",
		allProducts: "Tous les produits"
	},
	commons: {
		requestQuote: "Demander un devis",
		cart: "Panier",
		minRequestInitiationNote: "Un sous-total minimum de ${{minValue}} est requis pour envoyer un devis. ",
		savedActiveCart: "Votre panier actif a été converti en panier sauvegardé {{ code }}."
	},
	header: {
		buyerEdit: {
			a11y: {
				cancel: "Informations d'en-tête pour l'annulation de la modification du devis",
				save: "Informations d'en-tête pour la sauvegarde du devis"
			}
		},
		overview: {
			regionTitle: "Synthèse des détails du devis",
			id: "ID du devis",
			status: "Statut",
			information: "Informations sur le devis",
			name: "Nom",
			description: "Description",
			charactersLeft: "Caractères restants : {{count}}",
			priceAndExpiry: "Prix et expiration",
			estimatedTotal: "Total estimé",
			total: "Total",
			expirationTime: "Date d'expiration",
			a11y: {
				edit: "Informations d'en-tête pour la modification du devis"
			},
			createdAndUpdated: "Créé et mis à jour",
			createdDate: "Créé",
			lastUpdatedDate: "Dernière mise à jour"
		}
	},
	httpHandlers: {
		cartValidationIssue: "Vos entrées comportent des erreurs. Veuillez vérifier votre panier.",
		quoteCartIssue: "Impossible de modifier les entrées du panier. Veuillez passer à la validation.",
		absoluteDiscountIssue: "Sélectionnez une remise qui ne dépasse pas la valeur totale.",
		expirationDateIssue: "Sélectionnez une date d'expiration dans le futur.",
		threshold: {
			underThresholdError: "Le prix total du devis demandé n'atteint pas le seuil minimum."
		},
		expired: "Ce devis a expiré. Vous devez renvoyer votre demande de devis pour recevoir un autre devis du fournisseur.",
		downloadPDFError: "Une erreur s'est produite. Impossible d'obtenir le document PDF de la proposition."
	},
	items: {
		regionTitle: "Articles du panier"
	},
	links: {
		newCart: "Nouveau panier",
		quotes: "Devis",
		download: "Télécharger la proposition",
		order: "Détails de la commande",
		a11y: {
			newCart: "Créez un nouveau panier vide et naviguez vers celui-ci.",
			quotes: "Naviguez vers la liste des résultats de la recherche de devis.",
			download: "Commencer par télécharger une proposition de devis.",
			order: "Naviguer vers la commande associée à ce devis"
		}
	},
	list: {
		regionTitle: "Synthèse de la liste des devis",
		title: "Liste des devis",
		name: "Nom",
		updated: "Mis à jour",
		sortBy: "Trier par",
		sortQuotes: "Trier les devis",
		empty: "Nous n'avons pas de devis pour ce compte.",
		quoteId: "ID du devis",
		status: "Statut",
		clickableRow: "Cliquez sur la ligne pour plus de détails concernant le devis."
	},
	states: {
		BUYER_DRAFT: "Version préliminaire",
		BUYER_SUBMITTED: "Envoyé",
		BUYER_ACCEPTED: "Accepté",
		BUYER_APPROVED: "Approuvé",
		BUYER_REJECTED: "Refusé",
		BUYER_OFFER: "Devis du fournisseur",
		BUYER_ORDERED: "Commandé",
		SELLER_DRAFT: "Version préliminaire",
		SELLER_REQUEST: "Demandé",
		SELLER_SUBMITTED: "Envoyé",
		SELLERAPPROVER_DRAFT: "Version préliminaire",
		SELLERAPPROVER_PENDING: "En attente d'approbation",
		SELLERAPPROVER_APPROVED: "Approuvé",
		SELLERAPPROVER_REJECTED: "Refusé",
		CREATED: "Créé",
		CANCELLED: "Annulé",
		EXPIRED: "Expiré"
	},
	summary: {
		regionTitle: "Synthèse de la commande",
		actions: {
			APPROVE: "Approuver le devis",
			CANCEL: "Annuler le devis",
			CHECKOUT: "Accepter et valider",
			EDIT: "Modifier le devis",
			REJECT: "Refuser le devis",
			REQUOTE: "Demander un nouveau devis",
			SAVE: "Sauvegarder le devis",
			SUBMIT: "Envoyer le devis",
			VIEW: "Afficher le devis"
		},
		prices: {
			title: "Synthèse de la commande",
			subtotal: "Sous-total",
			productDiscount: "Remise sur l'article",
			orderDiscount: "Remise sur commande",
			quoteDiscount: "Remise sur devis",
			total: "Total",
			hint: "Aucune taxe n'est incluse dans le montant total"
		},
		sellerEdit: {
			discount: "Remise",
			apply: "Appliquer",
			expiryDate: "Date d'expiration",
			discountValidationText: "Saisissez un pourcentage de remise valide.",
			a11y: {
				apply: "Cliquez pour appliquer à ce devis la valeur de remise saisie .",
				discount: "Saisissez une valeur de remise en pourcentage à appliquer à ce devis.",
				expiryDate: "Saisissez une date d'expiration pour ce devis."
			}
		}
	}
};
var quote$n = {
	quote: quote$m
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const fr = {
    quote: quote$n,
};

var quote$k = {
	confirmDialog: {
		name: "नामः",
		description: "विवरणः",
		validity: "यह उद्धरण {{ expirationTime }} तक मान्य है",
		option: {
			yes: "हां",
			no: "नहीं"
		},
		buyer: {
			submit: {
				a11y: {
					close: "सबमिट कोट मॉडल बंद करें"
				},
				title: "उद्धरण अनुरोध {{ code }} सबमिट करें?",
				confirmNote: "क्या आप वाकई यह उद्धरण सबमिट करना चाहते हैं?",
				successMessage: "कोट अनुरोध सफलतापूर्वक सबमिट किया गया"
			},
			cancel: {
				a11y: {
					close: "उद्धरण मॉडल रद्द करना बंद करें"
				},
				title: "कोट अनुरोध {{ code }} रद्द करें?",
				confirmNote: "क्या आप वाकई इस उद्धरण को रद्द करना चाहते हैं?",
				successMessage: "उद्धरण अनुरोध रद्द किया गया"
			}
		},
		buyer_offer: {
			edit: {
				a11y: {
					close: "उद्धरण संपादित करें मॉडल बंद करें"
				},
				title: "उद्धरण {{ code }} के संपादन की पुष्टि करें?",
				confirmNote: "क्या आप वाकई इस स्वीकृत उद्धरण को संपादित करना चाहते हैं?",
				warningNote: "यह उद्धरण स्वीकृत कर दिया गया है. इस उद्धरण को संपादित करने से नए संपादन स्वीकृत होने तक चेकआउट रोका जाएगा."
			},
			cancel: {
				a11y: {
					close: "उद्धरण मॉडल रद्द करना बंद करें"
				},
				title: "उद्धरण {{ code }} रद्द करें?",
				confirmNote: "क्या आप वाकई इस उद्धरण को रद्द करना चाहते हैं?",
				successMessage: "उद्धरण रद्द किया गया"
			},
			checkout: {
				a11y: {
					close: "चेकआउट उद्धरण मॉडल बंद करें"
				},
				title: "उद्धरण {{ code }} चेकआउट करें?",
				confirmNote: "क्या आप वाकई इस उद्धरण को स्वीकृत कर चेकआउट करना चाहते हैं?"
			}
		},
		expired: {
			edit: {
				a11y: {
					close: "उद्धरण संपादन मॉडल बंद करें"
				},
				title: "उद्धरण {{ code }} के संपादन की पुष्टि करें?",
				confirmNote: "क्या आप वाकई इस समाप्त उद्धरण को संपादित करना चाहते हैं?",
				warningNote: "यह उद्धरण समाप्त हुआ. इस उद्धरण को संपादित करने से नए संपादन स्वीकृत होने तक चेकआउट रोका जाएगा."
			},
			requote: {
				a11y: {
					close: "पुनः उद्धरण मॉडल बंद करें"
				},
				title: "उद्धरण अनुरोध {{ code }} पुनः बनाएं?",
				confirmNote: "क्या आप वाकई यह उद्धरण अनुरोध पुनः बनाना चाहते हैं?",
				warningNote: "यह उद्धरण समाप्त हुआ. इसे पुनः उद्धरित करने से समान सामग्री से नया उद्धरण अनुरोध बनेगा जिसे बाद में अनुमोदन के लिए संपादित और सबमिट किया जा सकता है."
			}
		},
		seller: {
			submit: {
				a11y: {
					close: "सबमिट उद्धरण मॉडल बंद करें"
				},
				title: "उद्धरण {{ code }} सबमिट करें?",
				confirmNote: "क्या आप वाकई यह उद्धरण सबमिट करना चाहते हैं?",
				warningNote: "उद्धरण के कुल मान पर आधारित, क्रेता के इस उद्धरण से चेक आउट करने से पहले अतिरिक्त अनुमोदन की आवश्यकता हो सकती है.",
				successMessage: "उद्धरण सफलतापूर्वक सबमिट किया गया"
			}
		},
		sellerapprover: {
			approve: {
				a11y: {
					close: "अनुमोदन उद्धरण मॉडल बंद करें"
				},
				title: "उद्धरण {{ code }} अनुमोदित करें?",
				confirmNote: "क्या आप वाकई इस उद्धरण का अनुमोदन करना चाहते हैं?",
				successMessage: "उद्धरण सफलतापूर्वक अनुमोदित किया गया"
			},
			reject: {
				a11y: {
					close: "अस्वीकृत उद्धरण मॉडल बंद करें"
				},
				title: "उद्धरण {{ code }} अस्वीकृत करें?",
				confirmNote: "क्या आप वाकई यह उद्धरण अस्वीकृत करना चाहते हैं?",
				successMessage: "उद्धरण अस्वीकृत किया गया"
			}
		},
		cancelled: {
			requote: {
				a11y: {
					close: "पुनः उद्धरण मॉडल बंद करें"
				},
				title: "उद्धरण अनुरोध {{ code }} पुनः बनाएं?",
				confirmNote: "क्या आप वाकई यह उद्धरण अनुरोध पुनः बनाना चाहते हैं?",
				warningNote: "आपकी वर्तमान कार्ट सहेजी गई कार्ट में परिर्तित हो जाएगी."
			}
		},
		all: {
			edit: {
				a11y: {
					close: "उद्धरण संपादन मॉडल बंद करें"
				},
				title: "उद्धरण {{ code }} संपादित करें?",
				confirmNote: "क्या आप वाकई इस उद्धरण को संपादित करना चाहते हैं?",
				warningNote: "आपकी वर्तमान कार्ट सहेजी गई कार्ट में परिर्तित हो जाएगी."
			}
		}
	},
	comments: {
		regionTitle: "संपर्क/टिप्पणी बॉक्स",
		title: "संपर्क करें",
		invalidComment: "अमान्य इनपुट - कृपया फिर से टाइप करें...",
		allProducts: "सभी उत्पाद"
	},
	commons: {
		requestQuote: "उद्धरण के लिए अनुरोध करें",
		cart: "कार्ट",
		minRequestInitiationNote: "उद्धरण सबमिट करने के लिए न्यूनतम {{minValue}} उप-योग आवश्यक ",
		savedActiveCart: "आपकी सक्रिय कार्ट सहेजी गई कार्ट {{ code }} में रूपांतरित हो गई"
	},
	header: {
		buyerEdit: {
			a11y: {
				cancel: "उद्धरण शीर्षलेख जानकारी संपादन रद्द करें",
				save: "उद्धरण शीर्षलेख जानकारी सहेजें"
			}
		},
		overview: {
			regionTitle: "उद्धरण विवरण सारांश",
			id: "उद्धरण ID",
			status: "स्थिति",
			information: "उद्धरण जानकारी",
			name: "नाम",
			description: "वर्णन",
			charactersLeft: "वर्ण बचे हैंः  {{count}}",
			priceAndExpiry: "मूल्य और समाप्ति",
			estimatedTotal: "अनुमानित कुल योग",
			total: "कुल",
			expirationTime: "समाप्ति दिनांक",
			a11y: {
				edit: "उद्धरण शीर्षलेख जानकारी संपादित करें"
			},
			createdAndUpdated: "बनाया गया और अपडेट किया गया",
			createdDate: "बनाया गया",
			lastUpdatedDate: "अंतिम अपडेट किया गया"
		}
	},
	httpHandlers: {
		cartValidationIssue: "आपकी प्रविष्टियों में समस्याएं हैं. कृपया अपनी कार्ट की समीक्षा करें.",
		quoteCartIssue: "कार्ट प्रविष्टियों में परिवर्तन करना संभव नहीं. चेकआउट के लिए आगे बढ़ें",
		absoluteDiscountIssue: "कोई छूट चुनें जो कुल मान से बड़ा न हो",
		expirationDateIssue: "भविष्य में कोई समाप्ति दिनांक चुनें",
		threshold: {
			underThresholdError: "अनुरोधित उद्धरण का कुल मूल्य न्यूनतम थ्रेशोल्ड के समान नहीं है."
		},
		expired: "यह उद्धरण समाप्त हुआ. अन्य विक्रेता उद्धरण प्राप्त करने के लिए आपको अपना उद्धरण अनुरोध फिर से सबमिट करना चाहिए.",
		downloadPDFError: "कुछ गलत हुआ है. प्रस्ताव दस्तावेज़ PDF प्राप्त करने में असमर्थ."
	},
	items: {
		regionTitle: "कार्ट आइटम"
	},
	links: {
		newCart: "नया कार्ट",
		quotes: "उद्धरण ",
		download: "प्रस्ताव डाउनलोड करें",
		order: "ऑर्डर विवरण",
		a11y: {
			newCart: "नया रिक्त कार्ट बनाएं और इसे नेविगेट करें",
			quotes: "उद्धरण खोज परिणाम सूची पर नेविगेट करें.",
			download: "उद्धरण प्रस्ता डाउनलोड करना प्रारंभ करें",
			order: "इस कोट से संबंधित ऑर्डर पर नेविगेट करें"
		}
	},
	list: {
		regionTitle: "उद्धरण सूची सारांश",
		title: "उद्धरण सूची",
		name: "नाम",
		updated: "अपडेट किया गया",
		sortBy: "इसके द्वारा क्रमित",
		sortQuotes: "उद्धरण क्रमित करें",
		empty: "इस खाते के लिए हमारे पास कोई उद्धरण रिकॉर्ड नहीं हैं.",
		quoteId: "उद्धरण ID",
		status: "स्थिति",
		clickableRow: "अधिक उद्धरण विवरण के लिए इस पंक्ति पर क्लिक करें"
	},
	states: {
		BUYER_DRAFT: "ड्राफ़्ट",
		BUYER_SUBMITTED: "सबमिट किया",
		BUYER_ACCEPTED: "स्वीकृत",
		BUYER_APPROVED: "अनुमोदित",
		BUYER_REJECTED: "अस्वीकृत",
		BUYER_OFFER: "विक्रेता का उद्धरण",
		BUYER_ORDERED: "ऑर्डर किया गया",
		SELLER_DRAFT: "ड्राफ़्ट",
		SELLER_REQUEST: "अनुरोधित",
		SELLER_SUBMITTED: "सबमिट किया",
		SELLERAPPROVER_DRAFT: "ड्राफ़्ट",
		SELLERAPPROVER_PENDING: "लंबित अनुमोदन",
		SELLERAPPROVER_APPROVED: "अनुमोदित",
		SELLERAPPROVER_REJECTED: "अस्वीकृत",
		CREATED: "बनाया गया",
		CANCELLED: "रद्द किया गया",
		EXPIRED: "समाप्त हुआ"
	},
	summary: {
		regionTitle: "ऑर्डर सारांश",
		actions: {
			APPROVE: "उद्धरण का अनुमोदन करें",
			CANCEL: "उद्धरण रद्द करें ",
			CHECKOUT: "स्वीकार करें और चेक आउट करें",
			EDIT: "उद्धरण संपादित करें",
			REJECT: "अस्वीकृत उद्धरण ",
			REQUOTE: "नया उद्धरण अनुरोध",
			SAVE: "उद्धरण सहेजें",
			SUBMIT: "उद्धरण सबमिट करें",
			VIEW: "उद्धरण देखें"
		},
		prices: {
			title: "ऑर्डर सारांश",
			subtotal: "उप योग",
			productDiscount: "आइटम छूट",
			orderDiscount: "ऑर्डर पर छूट",
			quoteDiscount: "उद्धरण पर छूट",
			total: "कुल",
			hint: "कुल में कोई कर शामिल नहीं है"
		},
		sellerEdit: {
			discount: "छूट",
			apply: "लागू करें",
			expiryDate: "समाप्ति दिनांक",
			discountValidationText: "मान्य प्रतिशत छूट दर्ज करें",
			a11y: {
				apply: "इस उद्धरण के लिए दर्ज किए गए मान लागू करने के लिए क्लिक करें",
				discount: "इस उद्धरण पर लागू किए जाने वाले मान की प्रतिशत छूट दर्ज करें",
				expiryDate: "इस उद्धरण के लिए समाप्ति दिनांक दर्ज करें"
			}
		}
	}
};
var quote$l = {
	quote: quote$k
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const hi = {
    quote: quote$l,
};

var quote$i = {
	confirmDialog: {
		name: "Név:",
		description: "Leírás:",
		validity: "Az ajánlat a következő dátumig érvényes: {{ expirationTime }}",
		option: {
			yes: "Igen",
			no: "Nem"
		},
		buyer: {
			submit: {
				a11y: {
					close: "Ajánlat elküldése előugró ablak bezárása"
				},
				title: "Elküldi a következő ajánlatkérést: {{ code }}?",
				confirmNote: "Biztosan szeretné elküldeni ezt az ajánlatkérést?",
				successMessage: "Ajánlatkérés elküldése sikeres"
			},
			cancel: {
				a11y: {
					close: "Ajánlat törlése előugró ablak bezárása"
				},
				title: "Törli a következő ajánlatkérést: {{ code }}?",
				confirmNote: "Biztosan szeretné törölni ezt az ajánlatkérést?",
				successMessage: "Ajánlatkérés törölve"
			}
		},
		buyer_offer: {
			edit: {
				a11y: {
					close: "Ajánlat szerkesztése előugró ablak bezárása"
				},
				title: "Megerősíti a következő ajánlat szerkesztését: {{ code }}?",
				confirmNote: "Biztosan szeretné szerkeszteni ezt a jóváhagyott ajánlatot?",
				warningNote: "Ezt az ajánlatot már jóváhagyták. Az ajánlat szerkesztése megakadályozza a fizetést, amíg jóvá nem hagyják az új módosításokat."
			},
			cancel: {
				a11y: {
					close: "Ajánlat törlése előugró ablak bezárása"
				},
				title: "Törli a következő ajánlatot: {{ code }}?",
				confirmNote: "Biztosan szeretné törölni ezt az ajánlatot?",
				successMessage: "Ajánlat törölve"
			},
			checkout: {
				a11y: {
					close: "Ajánlat fizetése előugró ablak bezárása"
				},
				title: "Fizeti a következő ajánlatot: {{ code }}?",
				confirmNote: "Biztosan szeretné elfogadni és fizetni ezt az ajánlatot?"
			}
		},
		expired: {
			edit: {
				a11y: {
					close: "Ajánlat szerkesztése előugró ablak bezárása"
				},
				title: "Megerősíti a következő ajánlat szerkesztését: {{ code }}?",
				confirmNote: "Biztosan szeretné szerkeszteni ezt a lejárt ajánlatot?",
				warningNote: "Ez az ajánlat lejárt. Az ajánlat szerkesztése megakadályozza a fizetést, amíg jóvá nem hagyják az új módosításokat."
			},
			requote: {
				a11y: {
					close: "Ajánlat újraszámítása előugró ablak bezárása"
				},
				title: "Újra létrehozza a következő ajánlatkérést: {{ code }}?",
				confirmNote: "Biztosan szeretné újra létrehozni ezt az ajánlatkérést?",
				warningNote: "Ez az ajánlat lejárt. Az ajánlat újraszámítása egy új ajánlatkérést hoz létre ugyanazzal a tartalommal, amelyet később szerkeszthet és elküldhet."
			}
		},
		seller: {
			submit: {
				a11y: {
					close: "Ajánlat elküldése előugró ablak bezárása"
				},
				title: "Elküldi a következő ajánlatot: {{ code }}?",
				confirmNote: "Biztosan szeretné elküldeni ezt az ajánlatot?",
				warningNote: "Az ajánlat teljes értékétől függően előfordulhat, hogy további jóváhagyásra van szükség, mielőtt a beszerző kifizethetné ezt az ajánlatot.",
				successMessage: "Ajánlat elküldése sikeres"
			}
		},
		sellerapprover: {
			approve: {
				a11y: {
					close: "Ajánlat jóváhagyása előugró ablak bezárása"
				},
				title: "Jóváhagyja a következő ajánlatot: {{ code }}?",
				confirmNote: "Biztosan szeretné jóváhagyni ezt az ajánlatot?",
				successMessage: "Ajánlat jóváhagyása sikeres"
			},
			reject: {
				a11y: {
					close: "Ajánlat elutasítása előugró ablak bezárása"
				},
				title: "Elutasítja a következő ajánlatot: {{ code }}?",
				confirmNote: "Biztosan szeretné elutasítani ezt az ajánlatot?",
				successMessage: "Ajánlat elutasítva"
			}
		},
		cancelled: {
			requote: {
				a11y: {
					close: "Ajánlat újraszámítása előugró ablak bezárása"
				},
				title: "Újra létrehozza a következő ajánlatkérést: {{ code }}?",
				confirmNote: "Biztosan szeretné újra létrehozni ezt az ajánlatkérést?",
				warningNote: "A rendszer mentett kosárrá alakítja az aktuális kosarát."
			}
		},
		all: {
			edit: {
				a11y: {
					close: "Ajánlat szerkesztése előugró ablak bezárása"
				},
				title: "Szerkeszti a következő ajánlatot: {{ code }}?",
				confirmNote: "Biztosan szeretné szerkeszteni ezt az ajánlatot?",
				warningNote: "A rendszer mentett kosárrá alakítja az aktuális kosarát."
			}
		}
	},
	comments: {
		regionTitle: "Kapcsolat/Megjegyzés mező",
		title: "Kapcsolat",
		invalidComment: "Érvénytelen bevitel – Gépelje be újra…",
		allProducts: "Összes termék"
	},
	commons: {
		requestQuote: "Ajánlat kérése",
		cart: "Kosár",
		minRequestInitiationNote: "Legalább {{minValue}} USD részösszegre van szükség egy ajánlat elküldéséhez ",
		savedActiveCart: "A rendszer mentett kosárrá alakította az aktív kosarát ({{ code }})"
	},
	header: {
		buyerEdit: {
			a11y: {
				cancel: "Ajánlat fejlécadatai szerkesztésének megszakítása",
				save: "Ajánlat fejlécadatainak mentése"
			}
		},
		overview: {
			regionTitle: "Ajánlat részleteinek összegzése",
			id: "Ajánlatazonosító",
			status: "Státus",
			information: "Ajánlat adatai",
			name: "Név",
			description: "Leírás",
			charactersLeft: "hátralévő karakterek: {{count}}",
			priceAndExpiry: "Ár és lejárat",
			estimatedTotal: "Becsült végösszeg",
			total: "Végösszeg",
			expirationTime: "Lejárati dátum",
			a11y: {
				edit: "Ajánlat fejlécadatainak szerkesztése"
			},
			createdAndUpdated: "Létrehozva és aktualizálva",
			createdDate: "Létrehozva",
			lastUpdatedDate: "Legutóbbi aktualizálás"
		}
	},
	httpHandlers: {
		cartValidationIssue: "Hibák találhatók a bejegyzéseiben. Ellenőrizze a kosarát.",
		quoteCartIssue: "Nem lehetséges módosítani a kosár bejegyzéseit; lépjen a fizetéshez",
		absoluteDiscountIssue: "Olyan engedményt válasszon, amely nem haladja meg az összértéket",
		expirationDateIssue: "Jövőbeli lejárati dátumot válasszon",
		threshold: {
			underThresholdError: "A kért ajánlat teljes ára nem éri el a minimális küszöbértéket"
		},
		expired: "Ez az ajánlat lejárt. Újra el kell küldenie az ajánlatkérést, ha másik szállítói ajánlatot szeretne kérni.",
		downloadPDFError: "Hiba történt. Nem sikerült lekérni a javaslatdokumentum PDF-jét."
	},
	items: {
		regionTitle: "Kosárban lévő tételek"
	},
	links: {
		newCart: "Új kosár",
		quotes: "Ajánlatok",
		download: "Javaslat letöltése",
		order: "Rendelés részletei",
		a11y: {
			newCart: "Hozzon létre egy új üres kosarat, és nyissa meg.",
			quotes: "Lépjen az ajánlatkeresés találatainak listájára.",
			download: "Az ajánlatjavaslat letöltésének megkezdése",
			order: "Navigálás az ajánlathoz társított rendeléshez"
		}
	},
	list: {
		regionTitle: "Ajánlatlista összegzése",
		title: "Ajánlatlista",
		name: "Név",
		updated: "Aktualizálva",
		sortBy: "Rendezés alapja",
		sortQuotes: "Ajánlatok rendezése",
		empty: "Nem rendelkezünk ajánlati rekordokkal ehhez a fiókhoz.",
		quoteId: "Ajánlatazonosító",
		status: "Státus",
		clickableRow: "Az ajánlat további részleteihez kattintson a sorra"
	},
	states: {
		BUYER_DRAFT: "Piszkozat",
		BUYER_SUBMITTED: "Elküldve",
		BUYER_ACCEPTED: "Elfogadva",
		BUYER_APPROVED: "Jóváhagyva",
		BUYER_REJECTED: "Elutasítva",
		BUYER_OFFER: "Szállítói ajánlat",
		BUYER_ORDERED: "Megrendelve",
		SELLER_DRAFT: "Piszkozat",
		SELLER_REQUEST: "Igényelve",
		SELLER_SUBMITTED: "Elküldve",
		SELLERAPPROVER_DRAFT: "Piszkozat",
		SELLERAPPROVER_PENDING: "Jóváhagyásra vár",
		SELLERAPPROVER_APPROVED: "Jóváhagyva",
		SELLERAPPROVER_REJECTED: "Elutasítva",
		CREATED: "Létrehozva",
		CANCELLED: "Törölve",
		EXPIRED: "Lejárt"
	},
	summary: {
		regionTitle: "Rendelés összefoglalása",
		actions: {
			APPROVE: "Ajánlat jóváhagyása",
			CANCEL: "Ajánlat törlése",
			CHECKOUT: "Elfogadás és fizetés",
			EDIT: "Ajánlat szerkesztése",
			REJECT: "Ajánlat elutasítása",
			REQUOTE: "Új ajánlat kérése",
			SAVE: "Ajánlat mentése",
			SUBMIT: "Ajánlat elküldése",
			VIEW: "Ajánlat megtekintése"
		},
		prices: {
			title: "Rendelés összefoglalása",
			subtotal: "Részösszeg",
			productDiscount: "Tétel engedménye",
			orderDiscount: "Rendelés engedménye",
			quoteDiscount: "Ajánlat engedménye",
			total: "Összesen",
			hint: "A végösszeg nem tartalmazza az adókat"
		},
		sellerEdit: {
			discount: "Engedmény",
			apply: "Alkalmaz",
			expiryDate: "Lejárati dátum",
			discountValidationText: "Érvényes százalékos engedményt adjon meg",
			a11y: {
				apply: "Kattintással alkalmazhatja a megadott engedményértéket az ajánlatra",
				discount: "Adja meg az ajánlatra alkalmazni kívánt százalékos engedményértéket",
				expiryDate: "Adja meg az ajánlat lejárati dátumát"
			}
		}
	}
};
var quote$j = {
	quote: quote$i
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const hu = {
    quote: quote$j,
};

var quote$g = {
	confirmDialog: {
		name: "Nama:",
		description: "Deskripsi:",
		validity: "Penawaran ini valid hingga {{ expirationTime }}",
		option: {
			yes: "Ya",
			no: "Tidak"
		},
		buyer: {
			submit: {
				a11y: {
					close: "Tutup modal untuk mengajukan penawaran"
				},
				title: "Ajukan Permintaan Penawaran {{ code }}?",
				confirmNote: "Apakah Anda yakin ingin mengajukan permintaan penawaran ini?",
				successMessage: "Permintaan penawaran berhasil diajukan"
			},
			cancel: {
				a11y: {
					close: "Tutup modal untuk membatalkan penawaran"
				},
				title: "Batalkan Permintaan Penawaran {{ code }}?",
				confirmNote: "Apakah Anda yakin ingin membatalkan permintaan penawaran ini?",
				successMessage: "Permintaan penawaran dibatalkan"
			}
		},
		buyer_offer: {
			edit: {
				a11y: {
					close: "Tutup modal untuk mengedit penawaran"
				},
				title: "Konfirmasi Edit Penawaran {{ code }}?",
				confirmNote: "Apakah Anda yakin ingin mengedit penawaran yang disetujui ini?",
				warningNote: "Penawaran ini telah Disetujui. Jika Anda mengedit Penawaran ini, proses pembayaran akan tertunda hingga editan baru disetujui."
			},
			cancel: {
				a11y: {
					close: "Tutup modal untuk membatalkan penawaran"
				},
				title: "Batalkan Penawaran {{ code }}?",
				confirmNote: "Apakah Anda yakin ingin membatalkan penawaran ini?",
				successMessage: "Penawaran dibatalkan"
			},
			checkout: {
				a11y: {
					close: "Tutup modal untuk melakukan pembayaran penawaran"
				},
				title: "Lakukan Pembayaran untuk Penawaran {{ code }}?",
				confirmNote: "Apakah Anda yakin ingin menerima dan melakukan pembayaran untuk penawaran ini?"
			}
		},
		expired: {
			edit: {
				a11y: {
					close: "Tutup modal untuk mengedit penawaran"
				},
				title: "Konfirmasi Edit Penawaran {{ code }}?",
				confirmNote: "Apakah Anda yakin ingin mengedit penawaran yang telah berakhir ini?",
				warningNote: "Penawaran ini telah berakhir. Jika Anda mengedit penawaran ini, proses pembayaran akan tertunda hingga editan yang baru disetujui."
			},
			requote: {
				a11y: {
					close: "Tutup modal untuk membuat ulang penawaran"
				},
				title: "Buat Ulang Permintaan Penawaran {{ code }}?",
				confirmNote: "Apakah Anda yakin ingin membuat ulang permintaan penawaran ini?",
				warningNote: "Penawaran ini telah berakhir. Jika Anda membuat ulang penawaran ini, permintaan penawaran baru dengan isi yang sama akan dibuat, yang kemudian dapat diedit dan diajukan untuk mendapatkan persetujuan."
			}
		},
		seller: {
			submit: {
				a11y: {
					close: "Tutup modal untuk mengajukan penawaran"
				},
				title: "Ajukan Penawaran {{ code }}?",
				confirmNote: "Apakah Anda yakin ingin mengajukan penawaran ini?",
				warningNote: "Persetujuan tambahan mungkin diperlukan tergantung total nilai penawarannya sebelum pembeli dapat melakukan pembayaran untuk penawaran ini.",
				successMessage: "Penawaran berhasil diajukan"
			}
		},
		sellerapprover: {
			approve: {
				a11y: {
					close: "Tutup modal untuk menyetujui penawaran"
				},
				title: "Setujui Penawaran {{ code }}?",
				confirmNote: "Apakah Anda yakin ingin menyetujui penawaran ini?",
				successMessage: "Penawaran berhasil disetujui"
			},
			reject: {
				a11y: {
					close: "Tutup modal untuk menolak penawaran"
				},
				title: "Tolak Penawaran {{ code }}?",
				confirmNote: "Apakah Anda yakin ingin menolak penawaran ini?",
				successMessage: "Penawaran ditolak"
			}
		},
		cancelled: {
			requote: {
				a11y: {
					close: "Tutup modal untuk membuat ulang penawaran"
				},
				title: "Buat Ulang Permintaan Penawaran {{ code }}?",
				confirmNote: "Apakah Anda yakin ingin membuat ulang permintaan penawaran ini?",
				warningNote: "Keranjang Anda saat ini akan diubah menjadi keranjang tersimpan."
			}
		},
		all: {
			edit: {
				a11y: {
					close: "Tutup modal untuk mengedit penawaran"
				},
				title: "Edit Penawaran {{ code }}?",
				confirmNote: "Apakah Anda yakin ingin mengedit penawaran ini?",
				warningNote: "Keranjang Anda saat ini akan diubah menjadi keranjang tersimpan."
			}
		}
	},
	comments: {
		regionTitle: "Kolom Kontak/Komentar",
		title: "Kontak",
		invalidComment: "Input tidak valid - Silakan ketik lagi...",
		allProducts: "Semua Produk"
	},
	commons: {
		requestQuote: "Minta Penawaran",
		cart: "Keranjang",
		minRequestInitiationNote: "Subtotal minimal ${{minValue}} diperlukan untuk mengajukan penawaran ",
		savedActiveCart: "Keranjang aktif Anda telah diubah menjadi keranjang tersimpan {{ code }}"
	},
	header: {
		buyerEdit: {
			a11y: {
				cancel: "Batalkan pengeditan informasi header penawaran",
				save: "Simpan informasi header penawaran"
			}
		},
		overview: {
			regionTitle: "Ringkasan rincian penawaran",
			id: "ID Penawaran",
			status: "Status",
			information: "Informasi Penawaran",
			name: "Nama",
			description: "Deskripsi",
			charactersLeft: "karakter tersisa: {{count}}",
			priceAndExpiry: "Harga & Masa Berlaku",
			estimatedTotal: "Estimasi Total",
			total: "Total",
			expirationTime: "Tanggal Berakhir",
			a11y: {
				edit: "Edit informasi header penawaran"
			},
			createdAndUpdated: "Dibuat & Diperbarui",
			createdDate: "Dibuat",
			lastUpdatedDate: "Terakhir Diperbarui"
		}
	},
	httpHandlers: {
		cartValidationIssue: "Terdapat masalah dengan entri Anda. Silakan tinjau kembali keranjang Anda.",
		quoteCartIssue: "Perubahan pada entri keranjang tidak dapat dilakukan. Lanjutkan ke proses pembayaran",
		absoluteDiscountIssue: "Pilih diskon yang tidak melebihi nilai total",
		expirationDateIssue: "Pilih tanggal kedaluwarsa yang jatuh di tanggal yang akan datang",
		threshold: {
			underThresholdError: "Harga total permintaan penawaran tidak memenuhi batas minimum"
		},
		expired: "Penawaran ini telah berakhir. Anda harus mengajukan ulang permintaan penawaran untuk menerima penawaran lain dari vendor.",
		downloadPDFError: "Terjadi kesalahan. Tidak dapat mengakses dokumen proposal dalam format PDF."
	},
	items: {
		regionTitle: "Item keranjang"
	},
	links: {
		newCart: "Keranjang Baru",
		quotes: "Penawaran",
		download: "Unduh Proposal",
		order: "Rincian Pesanan",
		a11y: {
			newCart: "Buat keranjang kosong baru dan buka keranjang tersebut.",
			quotes: "Arahkan ke daftar hasil pencarian penawaran.",
			download: "Mulai mengunduh proposal penawaran",
			order: "Arahkan ke pesanan yang berkaitan dengan penawaran ini"
		}
	},
	list: {
		regionTitle: "Ringkasan daftar penawaran",
		title: "Daftar Penawaran",
		name: "Nama",
		updated: "Diperbarui",
		sortBy: "Urutkan berdasarkan",
		sortQuotes: "Urutkan Penawaran",
		empty: "Kami tidak memiliki catatan penawaran untuk akun ini.",
		quoteId: "ID Penawaran",
		status: "Status",
		clickableRow: "Klik baris tersebut untuk melihat rincian penawaran selengkapnya"
	},
	states: {
		BUYER_DRAFT: "Draf",
		BUYER_SUBMITTED: "Diajukan",
		BUYER_ACCEPTED: "Diterima",
		BUYER_APPROVED: "Disetujui",
		BUYER_REJECTED: "Ditolak",
		BUYER_OFFER: "Penawaran Vendor",
		BUYER_ORDERED: "Telah Dipesan",
		SELLER_DRAFT: "Draf",
		SELLER_REQUEST: "Diminta",
		SELLER_SUBMITTED: "Diajukan",
		SELLERAPPROVER_DRAFT: "Draf",
		SELLERAPPROVER_PENDING: "Menunggu Persetujuan",
		SELLERAPPROVER_APPROVED: "Disetujui",
		SELLERAPPROVER_REJECTED: "Ditolak",
		CREATED: "Dibuat",
		CANCELLED: "Dibatalkan",
		EXPIRED: "Berakhir"
	},
	summary: {
		regionTitle: "Ringkasan Pemesanan",
		actions: {
			APPROVE: "Setujui Penawaran",
			CANCEL: "Batalkan Penawaran",
			CHECKOUT: "Terima dan Bayar",
			EDIT: "Edit Penawaran",
			REJECT: "Tolak Penawaran",
			REQUOTE: "Minta Penawaran baru",
			SAVE: "Simpan Penawaran",
			SUBMIT: "Ajukan Penawaran",
			VIEW: "Lihat Penawaran"
		},
		prices: {
			title: "Ringkasan Pemesanan",
			subtotal: "Subtotal",
			productDiscount: "Diskon Item",
			orderDiscount: "Diskon Pemesanan",
			quoteDiscount: "Diskon Penawaran",
			total: "Total",
			hint: "Total tersebut belum termasuk pajak"
		},
		sellerEdit: {
			discount: "Diskon",
			apply: "Terapkan",
			expiryDate: "Tanggal Berakhir",
			discountValidationText: "Masukkan persentase diskon yang valid",
			a11y: {
				apply: "Klik untuk menerapkan nilai diskon yang dimasukkan ke penawaran ini",
				discount: "Masukkan nilai persentase diskon yang akan diterapkan pada penawaran ini",
				expiryDate: "Masukkan tanggal berakhirnya penawaran ini"
			}
		}
	}
};
var quote$h = {
	quote: quote$g
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const id = {
    quote: quote$h,
};

var quote$e = {
	confirmDialog: {
		name: "Nome:",
		description: "Descrizione:",
		validity: "Questa offerta è valida fino al {{ expirationTime }}",
		option: {
			yes: "Sì",
			no: "No"
		},
		buyer: {
			submit: {
				a11y: {
					close: "Chiudi la finestra modale di invio offerta"
				},
				title: "Inviare richiesta di offerta {{ code }}?",
				confirmNote: "Confermare di voler inviare questa richiesta di offerta?",
				successMessage: "Richiesta di offerta inviata correttamente"
			},
			cancel: {
				a11y: {
					close: "Chiudi la finestra modale di annullamento offerta"
				},
				title: "Annullare la richiesta di offerta {{ code }}?",
				confirmNote: "Confermare di voler annullare questa richiesta di offerta?",
				successMessage: "Richiesta di offerta annullata"
			}
		},
		buyer_offer: {
			edit: {
				a11y: {
					close: "Chiudi la finestra modale di modifica offerta"
				},
				title: "Confermare la modifica dell'offerta {{ code }}?",
				confirmNote: "Confermare di voler modificare questa offerta approvata?",
				warningNote: "Questa offerta è stata approvata. La modifica dell'offerta ne impedirà il check-out finché le nuove modifiche non saranno approvate."
			},
			cancel: {
				a11y: {
					close: "Chiudi la finestra modale di annullamento offerta"
				},
				title: "Annullare l'offerta {{ code }}?",
				confirmNote: "Confermare di voler annullare questa offerta?",
				successMessage: "Offerta annullata"
			},
			checkout: {
				a11y: {
					close: "Chiudi la finestra modale di check-out offerta"
				},
				title: "Effettuare il check-out dell'offerta {{ code }}?",
				confirmNote: "Confermare di voler accettare ed eseguire il check-out di questa offerta?"
			}
		},
		expired: {
			edit: {
				a11y: {
					close: "Chiudi la finestra modale di modifica offerta"
				},
				title: "Confermare la modifica dell'offerta{{ code }}?",
				confirmNote: "Confermare di voler modificare questa offerta scaduta?",
				warningNote: "Questa offerta è scaduta. La modifica dell'offerta ne impedirà il check-out finché le nuove modifiche non saranno approvate."
			},
			requote: {
				a11y: {
					close: "Chiudi la finestra modale di invio di nuova offerta"
				},
				title: "Ricreare richiesta dell'offerta {{ code }}?",
				confirmNote: "Confermare di voler ricreare questa richiesta di offerta?",
				warningNote: "Questa offerta è scaduta. L'invio di una nuova offerta creerà una nuova richiesta di offerta con gli stessi contenuti, che potrà essere modificata e inviata per l'approvazione in seguito."
			}
		},
		seller: {
			submit: {
				a11y: {
					close: "Chiudi la finestra modale di invio offerta"
				},
				title: "Inviare offerta {{ code }}?",
				confirmNote: "Confermare di voler inviare questa offerta?",
				warningNote: "A seconda del valore totale dell'offerta, prima che l'acquirente possa effettuare il check-out di questa offerta potrebbe essere richiesta un'ulteriore approvazione.",
				successMessage: "Offerta inviata correttamente"
			}
		},
		sellerapprover: {
			approve: {
				a11y: {
					close: "Chiudi la finestra modale di approvazione offerta"
				},
				title: "Approvare offerta {{ code }}?",
				confirmNote: "Confermare di voler approvare questa offerta?",
				successMessage: "Offerta approvata correttamente"
			},
			reject: {
				a11y: {
					close: "Chiudi la finestra modale di rifiuto offerta"
				},
				title: "Rifiutare offerta {{ code }}?",
				confirmNote: "Confermare di voler rifiutare questa offerta?",
				successMessage: "Offerta rifiutata"
			}
		},
		cancelled: {
			requote: {
				a11y: {
					close: "Chiudi la finestra modale di invio di nuova offerta"
				},
				title: "Ricreare richiesta dell'offerta {{ code }}?",
				confirmNote: "Confermare di voler ricreare questa richiesta di offerta?",
				warningNote: "Il carrello acquisti attuale verrà convertito in carrello acquisti salvato."
			}
		},
		all: {
			edit: {
				a11y: {
					close: "Chiudi la finestra modale di modifica offerta"
				},
				title: "Modificare offerta {{ code }}?",
				confirmNote: "Confermare di voler modificare questa offerta?",
				warningNote: "Il carrello acquisti attuale verrà convertito in carrello acquisti salvato."
			}
		}
	},
	comments: {
		regionTitle: "Contatti/riquadro commenti",
		title: "Contatti",
		invalidComment: "Input non valido - Digitare di nuovo...",
		allProducts: "Tutti i prodotti"
	},
	commons: {
		requestQuote: "Richiedi offerta",
		cart: "Carrello acquisti",
		minRequestInitiationNote: "Per inviare un'offerta occorre almeno un totale parziale di ${{minValue}} ",
		savedActiveCart: "Il carrello acquisti attivo è stato convertito in carrello acquisti salvato {{ code }}"
	},
	header: {
		buyerEdit: {
			a11y: {
				cancel: "Annulla la modifica delle informazioni di intestazione dell'offerta",
				save: "Salva le informazioni di intestazione dell'offerta"
			}
		},
		overview: {
			regionTitle: "Riepilogo dei dettagli dell'offerta",
			id: "ID offerta",
			status: "Stato",
			information: "Informazioni offerta",
			name: "Nome",
			description: "Descrizione",
			charactersLeft: "caratteri rimanenti: {{count}}",
			priceAndExpiry: "Prezzo e scadenza",
			estimatedTotal: "Totale stimato",
			total: "Totale",
			expirationTime: "Data di scadenza",
			a11y: {
				edit: "Modifica le informazioni di intestazione dell'offerta"
			},
			createdAndUpdated: "Creato e aggiornato",
			createdDate: "Creato",
			lastUpdatedDate: "Ultimo aggiornamento"
		}
	},
	httpHandlers: {
		cartValidationIssue: "Sono stati rilevati problemi con gli inserimenti. Rivedere il carrello acquisti.",
		quoteCartIssue: "Impossibile apportare modifiche agli inserimento del carrello acquisti. Procedere al check-out.",
		absoluteDiscountIssue: "Scegli uno sconto che non superi il valore totale",
		expirationDateIssue: "Scegli una data di scadenza nel futuro",
		threshold: {
			underThresholdError: "Il prezzo totale dell'offerta richiesta non raggiunge la soglia minima"
		},
		expired: "Questa offerta è scaduta. È necessario inviare di nuovo la richiesta di offerta per ricevere un'altra offerta del fornitore.",
		downloadPDFError: "Si è verificato un errore. Impossibile ottenere il PDF del documento della proposta."
	},
	items: {
		regionTitle: "Articoli nel carrello acquisti"
	},
	links: {
		newCart: "Nuovo carrello acquisti",
		quotes: "Offerte",
		download: "Scarica proposta",
		order: "Dettagli ordine",
		a11y: {
			newCart: "Creare nuovo carrello acquisti vuoto e visualizzarlo.",
			quotes: "Passare alla lista dei risultati della ricerca di offerta.",
			download: "Inizia a caricare una proposta di offerta",
			order: "Passa all'ordine associato a questa offerta"
		}
	},
	list: {
		regionTitle: "Riepilogo lista di offerte",
		title: "Lista di offerte",
		name: "Nome",
		updated: "Aggiornato",
		sortBy: "Ordina per",
		sortQuotes: "Ordina offerte",
		empty: "Nessun record di offerte per questo account.",
		quoteId: "ID offerta",
		status: "Stato",
		clickableRow: "Fare clic sulla riga per maggiori dettagli sull'offerta."
	},
	states: {
		BUYER_DRAFT: "Bozza",
		BUYER_SUBMITTED: "Inviata",
		BUYER_ACCEPTED: "Accettata",
		BUYER_APPROVED: "Approvata",
		BUYER_REJECTED: "Rifiutata",
		BUYER_OFFER: "Offerta fornitore",
		BUYER_ORDERED: "Ordinata",
		SELLER_DRAFT: "Bozza",
		SELLER_REQUEST: "Richiesta",
		SELLER_SUBMITTED: "Inviata",
		SELLERAPPROVER_DRAFT: "Bozza",
		SELLERAPPROVER_PENDING: "In attesa di approvazione",
		SELLERAPPROVER_APPROVED: "Approvata",
		SELLERAPPROVER_REJECTED: "Rifiutata",
		CREATED: "Creata",
		CANCELLED: "Annullata",
		EXPIRED: "Scaduta"
	},
	summary: {
		regionTitle: "Riepilogo dell'ordine",
		actions: {
			APPROVE: "Approva offerta",
			CANCEL: "Annulla offerta",
			CHECKOUT: "Accetta ed esegui il check-out",
			EDIT: "Modifica offerta",
			REJECT: "Rifiuta offerta",
			REQUOTE: "Richiedi nuova offerta",
			SAVE: "Salva offerta",
			SUBMIT: "Invia offerta",
			VIEW: "Visualizza offerta"
		},
		prices: {
			title: "Riepilogo dell'ordine",
			subtotal: "Totale parziale",
			productDiscount: "Sconto su articolo",
			orderDiscount: "Sconto su ordine",
			quoteDiscount: "Sconto su offerta",
			total: "Totale",
			hint: "Nessuna imposta inclusa nel totale"
		},
		sellerEdit: {
			discount: "Sconto",
			apply: "Applica",
			expiryDate: "Data di scadenza",
			discountValidationText: "Inserisci uno sconto percentuale valido",
			a11y: {
				apply: "Fare clic per applicare il valore di sconto inserito a questa offerta",
				discount: "Inserisci un valore di sconto percentuale da applicare a questa offerta",
				expiryDate: "Inserisci una data di scadenza per questa offerta"
			}
		}
	}
};
var quote$f = {
	quote: quote$e
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const it = {
    quote: quote$f,
};

var quote$c = {
	confirmDialog: {
		name: "名前: ",
		description: "説明: ",
		validity: "この見積は {{ expirationTime }} まで有効です",
		option: {
			yes: "はい",
			no: "いいえ"
		},
		buyer: {
			submit: {
				a11y: {
					close: "見積依頼モーダルを閉じる"
				},
				title: "見積依頼 {{ code }} を送信しますか?",
				confirmNote: "この見積依頼を送信してもよろしいですか?",
				successMessage: "見積依頼が正常に送信されました"
			},
			cancel: {
				a11y: {
					close: "見積キャンセルモーダルを閉じる"
				},
				title: "見積依頼 {{ code }} をキャンセルしますか?",
				confirmNote: "この見積依頼をキャンセルしてもよろしいですか?",
				successMessage: "見積依頼がキャンセルされました"
			}
		},
		buyer_offer: {
			edit: {
				a11y: {
					close: "見積編集モーダルを閉じる"
				},
				title: "見積編集 {{ code }} を確認しますか?",
				confirmNote: "この承認済み見積を編集してもよろしいですか?",
				warningNote: "この見積は承認されました。この見積を編集すると、新しい編集内容が承認されるまで、チェックアウトできません。"
			},
			cancel: {
				a11y: {
					close: "見積キャンセルモーダルを閉じる"
				},
				title: "見積 {{ code }} をキャンセルしますか?",
				confirmNote: "この見積をキャンセルしてもよろしいですか?",
				successMessage: "見積がキャンセルされました"
			},
			checkout: {
				a11y: {
					close: "見積チェックアウトモーダルを閉じる"
				},
				title: "見積 {{ code }} をチェックアウトしますか?",
				confirmNote: "この見積を受け入れてチェックアウトしてもよろしいですか?"
			}
		},
		expired: {
			edit: {
				a11y: {
					close: "見積編集モーダルを閉じる"
				},
				title: "見積編集 {{ code }} を確認しますか?",
				confirmNote: "この期限切れ見積を編集してもよろしいですか?",
				warningNote: "この見積の期限が切れました。この見積を編集すると、新しい編集内容が承認されるまで、チェックアウトできません。"
			},
			requote: {
				a11y: {
					close: "再見積モーダルを閉じる"
				},
				title: "見積依頼 {{ code }} を再作成しますか?",
				confirmNote: "この見積依頼を再作成してもよろしいですか?",
				warningNote: "この見積の期限が切れました。再見積を行うと、同じ内容で新しい見積依頼が作成されます。これは後で編集して承認のために送信することができます。"
			}
		},
		seller: {
			submit: {
				a11y: {
					close: "見積送信モーダルを閉じる"
				},
				title: "見積 {{ code }} を送信しますか?",
				confirmNote: "この見積を送信してもよろしいですか?",
				warningNote: "見積の合計金額に応じて、購買担当者がこの見積をチェックアウトする前に追加承認が必要になる場合があります。",
				successMessage: "見積が正常に送信されました"
			}
		},
		sellerapprover: {
			approve: {
				a11y: {
					close: "見積承認モーダルを閉じる"
				},
				title: "見積 {{ code }} を承認しますか?",
				confirmNote: "この見積を承認してもよろしいですか?",
				successMessage: "見積が正常に承認されました"
			},
			reject: {
				a11y: {
					close: "見積却下モーダルを閉じる"
				},
				title: "見積 {{ code }} を却下しますか?",
				confirmNote: "この見積を却下してもよろしいですか?",
				successMessage: "見積が却下されました"
			}
		},
		cancelled: {
			requote: {
				a11y: {
					close: "再見積モーダルを閉じる"
				},
				title: "見積依頼 {{ code }} を再作成しますか?",
				confirmNote: "この見積依頼をキャンセルしてもよろしいですか?",
				warningNote: "現在のカートは保存されたカートに変換されます。"
			}
		},
		all: {
			edit: {
				a11y: {
					close: "見積編集モーダルを閉じる"
				},
				title: "見積 {{ code }} を編集しますか?",
				confirmNote: "この見積を編集してもよろしいですか?",
				warningNote: "現在のカートは保存済みカートに変換されます。"
			}
		}
	},
	comments: {
		regionTitle: "お問い合わせ/コメントボックス",
		title: "お問い合わせ",
		invalidComment: "無効な入力 - もう一度入力してください...",
		allProducts: "すべての商品"
	},
	commons: {
		requestQuote: "見積依頼",
		cart: "カート",
		minRequestInitiationNote: "見積を送信するには、小計 ${{minValue}} 以上が必要です ",
		savedActiveCart: "有効なカートが保存済みカート {{ code }} に変換されました"
	},
	header: {
		buyerEdit: {
			a11y: {
				cancel: "見積ヘッダ情報の編集をキャンセル",
				save: "見積ヘッダ情報を保存"
			}
		},
		overview: {
			regionTitle: "見積詳細概要",
			id: "見積 ID",
			status: "ステータス",
			information: "見積情報",
			name: "名前",
			description: "説明",
			charactersLeft: "残り文字数: {{count}}",
			priceAndExpiry: "価格および失効日",
			estimatedTotal: "見積合計",
			total: "合計",
			expirationTime: "失効日",
			a11y: {
				edit: "見積ヘッダ情報を編集"
			},
			createdAndUpdated: "作成済みおよび更新済み",
			createdDate: "作成済み",
			lastUpdatedDate: "最終更新"
		}
	},
	httpHandlers: {
		cartValidationIssue: "エントリに問題があります。カートを確認してください。",
		quoteCartIssue: "カートエントリを変更することはできません。チェックアウトに進んでください",
		absoluteDiscountIssue: "合計金額を超えない値引を選択してください",
		expirationDateIssue: "有効期限は将来の日付を選択してください",
		threshold: {
			underThresholdError: "依頼された見積の合計価格が最小しきい値を満たしていません"
		},
		expired: "この見積の期限が切れました。見積依頼を再送信して、別の仕入先見積もりを受け取る必要があります。",
		downloadPDFError: "問題が発生しました。提案文書の PDF を取得できません。"
	},
	items: {
		regionTitle: "カート内のアイテム"
	},
	links: {
		newCart: "新規カート",
		quotes: "見積",
		download: "提案をダウンロード",
		order: "注文詳細",
		a11y: {
			newCart: "空の新規カートを作成し、そこにナビゲートしてください。",
			quotes: "見積検索結果一覧にナビゲートしてください。",
			download: "見積提案のダウンロードを開始",
			order: "この見積に関連付けられている注文にナビゲート"
		}
	},
	list: {
		regionTitle: "見積リスト概要",
		title: "見積リスト",
		name: "名前",
		updated: "更新済み",
		sortBy: "ソート基準",
		sortQuotes: "見積をソート",
		empty: "このアカウントには見積レコードがありません。",
		quoteId: "見積 ID",
		status: "ステータス",
		clickableRow: "さらに見積詳細を表示するには、行をクリックしてください"
	},
	states: {
		BUYER_DRAFT: "下書き",
		BUYER_SUBMITTED: "送信済み",
		BUYER_ACCEPTED: "受入済み",
		BUYER_APPROVED: "承認済み",
		BUYER_REJECTED: "却下済み",
		BUYER_OFFER: "仕入先見積",
		BUYER_ORDERED: "注文済み",
		SELLER_DRAFT: "下書き",
		SELLER_REQUEST: "依頼済み",
		SELLER_SUBMITTED: "送信済み",
		SELLERAPPROVER_DRAFT: "下書き",
		SELLERAPPROVER_PENDING: "保留中の承認",
		SELLERAPPROVER_APPROVED: "承認済み",
		SELLERAPPROVER_REJECTED: "却下済み",
		CREATED: "作成済み",
		CANCELLED: "キャンセル済み",
		EXPIRED: "失効"
	},
	summary: {
		regionTitle: "注文内容",
		actions: {
			APPROVE: "見積を承認",
			CANCEL: "見積をキャンセル",
			CHECKOUT: "受入とチェックアウト",
			EDIT: "見積を編集",
			REJECT: "見積を却下",
			REQUOTE: "新規見積依頼",
			SAVE: "見積を保存",
			SUBMIT: "見積を送信",
			VIEW: "見積を表示"
		},
		prices: {
			title: "注文内容",
			subtotal: "小計",
			productDiscount: "アイテム値引",
			orderDiscount: "注文値引",
			quoteDiscount: "見積値引",
			total: "合計",
			hint: "合計には税金が含まれていません"
		},
		sellerEdit: {
			discount: "値引",
			apply: "適用",
			expiryDate: "失効日",
			discountValidationText: "有効な値引率を入力してください",
			a11y: {
				apply: "クリックして、入力した値引金額をこの見積もりに適用します",
				discount: "この見積に適用する値引率を入力してください",
				expiryDate: "この見積の失効日を入力してください"
			}
		}
	}
};
var quote$d = {
	quote: quote$c
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ja = {
    quote: quote$d,
};

var quote$a = {
	confirmDialog: {
		name: "이름:",
		description: "설명:",
		validity: "이 견적은 {{ expirationTime }}까지 유효합니다.",
		option: {
			yes: "예",
			no: "아니요"
		},
		buyer: {
			submit: {
				a11y: {
					close: "견적 요청 닫기 모달"
				},
				title: "견적 요청 {{ code }}을(를) 제출하시겠습니까?",
				confirmNote: "이 견적 요청을 제출하시겠습니까?",
				successMessage: "견적 요청을 제출했습니다."
			},
			cancel: {
				a11y: {
					close: "견적 요청 닫기 모달"
				},
				title: "견적 요청 {{ code }} 취소",
				confirmNote: "이 견적 요청을 취소하시겠습니까?",
				successMessage: "견적 요청이 취소되었습니다."
			}
		},
		buyer_offer: {
			edit: {
				a11y: {
					close: "견적 편집 닫기 모달"
				},
				title: "견적 {{ code }} 편집 확인",
				confirmNote: "이 승인된 견적을 편집하시겠습니까?",
				warningNote: "이 견적은 승인되었습니다. 이 견적을 편집하면 새 편집이 승인될 때까지 체크아웃할 수 없습니다."
			},
			cancel: {
				a11y: {
					close: "견적 요청 닫기 모달"
				},
				title: "견적 {{ code }} 취소",
				confirmNote: "이 견적을 취소하시겠습니까?",
				successMessage: "견적 요청이 취소되었습니다."
			},
			checkout: {
				a11y: {
					close: "견적 체크아웃 닫기 모달"
				},
				title: "견적 {{ code }} 체크아웃",
				confirmNote: "이 견적을 승인하고 체크아웃하시겠습니까?"
			}
		},
		expired: {
			edit: {
				a11y: {
					close: "견적 편집 닫기 모달"
				},
				title: "견적 {{ code }} 편집 확인",
				confirmNote: "이 만료된 견적을 편집하시겠습니까?",
				warningNote: "이 견적은 만료되었습니다. 이 견적을 편집하면 새 편집이 승인될 때까지 체크아웃할 수 없습니다."
			},
			requote: {
				a11y: {
					close: "재견적 닫기 모달"
				},
				title: "견적 요청 {{ code }} 재생성",
				confirmNote: "이 견적 요청을 재생성하시겠습니까?",
				warningNote: "이 견적은 만료되었습니다. 이 견적을 재생성하면 내용이 같은 견적 요청이 새로 생성되며 나중에 승인을 위해 편집하고 제출할 수 있습니다."
			}
		},
		seller: {
			submit: {
				a11y: {
					close: "견적 요청 닫기 모달"
				},
				title: "견적 {{ code }} 제출",
				confirmNote: "이 견적을 제출하시겠습니까?",
				warningNote: "구매자가 이 견적을 체크아웃하려면 총 견적 금액에 따라 추가 승인이 필요할 수도 있습니다.",
				successMessage: "견적을 제출했습니다."
			}
		},
		sellerapprover: {
			approve: {
				a11y: {
					close: "승인 닫기 모달"
				},
				title: "견적 {{ code }} 승인",
				confirmNote: "이 견적을 승인하시겠습니까?",
				successMessage: "견적이 승인되었습니다."
			},
			reject: {
				a11y: {
					close: "견적 거부 닫기 모달"
				},
				title: "견적 {{ code }} 거부",
				confirmNote: "이 견적을 거부하시겠습니까?",
				successMessage: "견적 거부됨"
			}
		},
		cancelled: {
			requote: {
				a11y: {
					close: "재견적 닫기 모달"
				},
				title: "견적 요청 {{ code }} 재생성",
				confirmNote: "이 견적 요청을 재생성하시겠습니까?",
				warningNote: "현재 장바구니가 저장된 장바구니로 변환됩니다."
			}
		},
		all: {
			edit: {
				a11y: {
					close: "견적 편집 닫기 모달"
				},
				title: "견적 {{ code }} 편집",
				confirmNote: "이 견적을 편집하시겠습니까?",
				warningNote: "현재 장바구니가 저장된 장바구니로 변환됩니다."
			}
		}
	},
	comments: {
		regionTitle: "연락처/의견 상자",
		title: "연락처",
		invalidComment: "잘못된 입력 - 다시 입력하십시오...",
		allProducts: "모든 제품"
	},
	commons: {
		requestQuote: "견적 요청",
		cart: "장바구니",
		minRequestInitiationNote: "견적을 제출하려면 최소 ${{minValue}} 소계가 필요합니다. ",
		savedActiveCart: "사용 중인 장바구니가 저장된 장바구니 {{ code }}(으)로 변환되었습니다."
	},
	header: {
		buyerEdit: {
			a11y: {
				cancel: "견적 머리글 정보 편집 취소",
				save: "견적 머리글 정보 저장"
			}
		},
		overview: {
			regionTitle: "견적 세부사항 요약",
			id: "견적 ID",
			status: "상태",
			information: "견적 정보",
			name: "이름",
			description: "설명",
			charactersLeft: "{{count}}자 남음",
			priceAndExpiry: "가격 및 만료",
			estimatedTotal: "예상 합계",
			total: "합계",
			expirationTime: "만료 날짜",
			a11y: {
				edit: "견적 머리글 정보 편집"
			},
			createdAndUpdated: "작성 및 업데이트",
			createdDate: "작성됨",
			lastUpdatedDate: "마지막 업데이트 날짜"
		}
	},
	httpHandlers: {
		cartValidationIssue: "입력 내용에 문제가 있습니다. 장바구니를 확인하십시오.",
		quoteCartIssue: "장바구니 항목을 변경할 수 없습니다. 체크아웃을 계속하십시오.",
		absoluteDiscountIssue: "값 합계를 초과하지 않는 할인을 선택하십시오.",
		expirationDateIssue: "미래 만료 날짜를 선택하십시오.",
		threshold: {
			underThresholdError: "요청된 견적의 가격 합계가 최소 임계값에 맞지 않습니다."
		},
		expired: "이 견적은 만료되었습니다. 다른 공급업체 견적을 받으려면 견적 요청을 다시 제출해야 합니다.",
		downloadPDFError: "문제가 발생했습니다. 제안서 PDF를 가져올 수 없습니다."
	},
	items: {
		regionTitle: "장바구니 품목"
	},
	links: {
		newCart: "새 장바구니",
		quotes: "견적",
		download: "제안 다운로드",
		order: "오더 세부사항",
		a11y: {
			newCart: "비어 있는 장바구니를 새로 만들고 이동합니다.",
			quotes: "견적 검색 결과 목록으로 이동합니다.",
			download: "견적 제안 다운로드 시작",
			order: "이 견적과 연관된 오더로 이동"
		}
	},
	list: {
		regionTitle: "견적 목록 요약",
		title: "견적 목록",
		name: "이름",
		updated: "업데이트됨",
		sortBy: "정렬 기준",
		sortQuotes: "견적 정렬",
		empty: "이 계정에 견적 기록이 없습니다.",
		quoteId: "견적 ID",
		status: "상태",
		clickableRow: "자세한 견적 세부사항을 보려면 행을 클릭하십시오."
	},
	states: {
		BUYER_DRAFT: "드래프트",
		BUYER_SUBMITTED: "제출됨",
		BUYER_ACCEPTED: "수락됨",
		BUYER_APPROVED: "승인됨",
		BUYER_REJECTED: "거부됨",
		BUYER_OFFER: "공급업체 견적",
		BUYER_ORDERED: "주문됨",
		SELLER_DRAFT: "드래프트",
		SELLER_REQUEST: "요청됨",
		SELLER_SUBMITTED: "제출됨",
		SELLERAPPROVER_DRAFT: "드래프트",
		SELLERAPPROVER_PENDING: "승인 보류 중",
		SELLERAPPROVER_APPROVED: "승인됨",
		SELLERAPPROVER_REJECTED: "거부됨",
		CREATED: "작성됨",
		CANCELLED: "취소됨",
		EXPIRED: "만료됨"
	},
	summary: {
		regionTitle: "주문 요약",
		actions: {
			APPROVE: "견적 승인",
			CANCEL: "견적 취소",
			CHECKOUT: "수락 후 체크아웃",
			EDIT: "견적 편집",
			REJECT: "견적 거부",
			REQUOTE: "새 견적 요청",
			SAVE: "견적 저장",
			SUBMIT: "견적 제출",
			VIEW: "견적 보기"
		},
		prices: {
			title: "주문 요약",
			subtotal: "소계",
			productDiscount: "품목 할인",
			orderDiscount: "주문 할인",
			quoteDiscount: "견적 할인",
			total: "합계",
			hint: "세금은 합계에 포함되지 않습니다."
		},
		sellerEdit: {
			discount: "할인",
			apply: "적용",
			expiryDate: "만료 날짜",
			discountValidationText: "올바른 할인율을 입력하십시오.",
			a11y: {
				apply: "입력한 할인 값을 이 견적에 적용하려면 클릭하십시오.",
				discount: "이 견적에 적용할 할인율을 입력하십시오.",
				expiryDate: "이 견적의 만료 날짜를 입력하십시오."
			}
		}
	}
};
var quote$b = {
	quote: quote$a
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ko = {
    quote: quote$b,
};

var quote$8 = {
	confirmDialog: {
		name: "Nazwa:",
		description: "Opis:",
		validity: "Ta wycena jest ważna do {{ expirationTime }}",
		option: {
			yes: "Tak",
			no: "Nie"
		},
		buyer: {
			submit: {
				a11y: {
					close: "Zamknij okno dialogowe przesyłania wyceny"
				},
				title: "Przesłać zapytanie ofertowe {{ code }}?",
				confirmNote: "Na pewno chcesz przesłać to zapytanie ofertowe?",
				successMessage: "Zapytanie ofertowe zostało przesłane"
			},
			cancel: {
				a11y: {
					close: "Zamknij okno dialogowe anulowania wyceny"
				},
				title: "Anulować zapytanie ofertowe {{ code }}?",
				confirmNote: "Czy na pewno chcesz anulować to zapytanie ofertowe?",
				successMessage: "Zapytanie ofertowe zostało anulowana"
			}
		},
		buyer_offer: {
			edit: {
				a11y: {
					close: "Zamknij okno dialogowe edycji wyceny"
				},
				title: "Potwierdzić edycję wyceny {{ code }}?",
				confirmNote: "Czy na pewno chcesz edytować zatwierdzoną wycenę?",
				warningNote: "Ta wycena została zatwierdzona. Jej edycja uniemożliwi realizację zakupu do czasu zatwierdzenia nowych zmian."
			},
			cancel: {
				a11y: {
					close: "Zamknij okno dialogowe anulowania oferty"
				},
				title: "Anulować ofertę {{ code }}?",
				confirmNote: "Czy na pewno chcesz anulować tę ofertę?",
				successMessage: "Oferta została anulowana"
			},
			checkout: {
				a11y: {
					close: "Zamknij okno dialogowe realizacji oferty"
				},
				title: "Realizować ofertę {{ code }}?",
				confirmNote: "Na pewno chcesz zaakceptować i zrealizować tę ofertę cenową?"
			}
		},
		expired: {
			edit: {
				a11y: {
					close: "Zamknij okno dialogowe edycji oferty"
				},
				title: "Potwierdzić edycję oferty {{ code }}?",
				confirmNote: "Czy na pewno chcesz edytować wygasłą ofertę?",
				warningNote: "Ta oferta wygasła. Jej edycja uniemożliwi realizację zakupu do czasu zatwierdzenia nowych zmian."
			},
			requote: {
				a11y: {
					close: "Zamknij okno ponowienia zapytania"
				},
				title: "Odtworzyć zapytanie ofertowe {{ code }}?",
				confirmNote: "Na pewno chcesz odtworzyć to zapytanie ofertowe?",
				warningNote: "Ta oferta wygasła. Ponowienie prośby utworzy nowe zapytanie ofertowe o tej samej treści, które można następnie edytować i przesłać do zatwierdzenia."
			}
		},
		seller: {
			submit: {
				a11y: {
					close: "Zamknij okno dialogowe przesyłania wyceny"
				},
				title: "Przesłać zapytanie ofertowe {{ code }}?",
				confirmNote: "Czy na pewno chcesz przesłać to zapytanie ofertowe?",
				warningNote: "W zależności od całkowitej wartości wyceny, może być wymagane dodatkowe zatwierdzenie, zanim kupujący będzie mógł procedować tę ofertę.",
				successMessage: "Wycena została przesłana"
			}
		},
		sellerapprover: {
			approve: {
				a11y: {
					close: "Zamknij okno zatwierdzania oferty"
				},
				title: "Zatwierdzić wycenę {{ code }}?",
				confirmNote: "Czy na pewno chcesz zatwierdzić tę wycenę?",
				successMessage: "Zatwierdzono wycenę"
			},
			reject: {
				a11y: {
					close: "Zamknij okno odrzucenia oferty"
				},
				title: "Odrzucić ofertę {{ code }}?",
				confirmNote: "Na pewno chcesz odrzucić tę ofertę?",
				successMessage: "Oferta odrzucona"
			}
		},
		cancelled: {
			requote: {
				a11y: {
					close: "Zamknij okno ponowienia zapytania"
				},
				title: "Odtworzyć zapytanie ofertowe {{ code }}?",
				confirmNote: "Na pewno chcesz odtworzyć to zapytanie ofertowe?",
				warningNote: "Twój aktualny koszyk zostanie przekonwertowany na zapisany koszyk."
			}
		},
		all: {
			edit: {
				a11y: {
					close: "Zamknij okno dialogowe edycji wyceny"
				},
				title: "Edytować ofertę {{ code }}?",
				confirmNote: "Czy na pewno chcesz edytować tę ofertę?",
				warningNote: "Twój aktualny koszyk zostanie przekonwertowany na zapisany koszyk."
			}
		}
	},
	comments: {
		regionTitle: "Kontakt/Komentarz",
		title: "Kontakt",
		invalidComment: "Nieprawidłowy wpis - wpisz ponownie...",
		allProducts: "Wszystkie produkty"
	},
	commons: {
		requestQuote: "Zapytaj o wycenę",
		cart: "Koszyk zakupów",
		minRequestInitiationNote: "Minimalna ${{minValue}} suma częściowa jest wymagana do przesłania oferty. ",
		savedActiveCart: "Twój aktualny koszyk został przekonwertowany na zapisany koszyk {{ code }}"
	},
	header: {
		buyerEdit: {
			a11y: {
				cancel: "Anuluj edycję informacji w nagłówku wyceny",
				save: "Zapisz informacje z nagłówka wyceny"
			}
		},
		overview: {
			regionTitle: "Podsumowanie oferty",
			id: "ID oferty",
			status: "Status",
			information: "Treść oferty cenowej",
			name: "Nazwa",
			description: "Opis",
			charactersLeft: "pozostało znaków: {{count}}",
			priceAndExpiry: "Cena i data wygaśnięcia",
			estimatedTotal: "Szacowana suma",
			total: "Suma",
			expirationTime: "Data wygaśnięcia",
			a11y: {
				edit: "Edytuj informacje w nagłówku wyceny"
			},
			createdAndUpdated: "Utworzone i zaktualizowane",
			createdDate: "Utworzone",
			lastUpdatedDate: "Ostatnio zaktualizowane"
		}
	},
	httpHandlers: {
		cartValidationIssue: "Wystąpiły problemy z twoimi wpisami. Sprawdź swój koszyk.",
		quoteCartIssue: "Nie można wprowadzać zmian we wpisach koszyka. Przejdź do finalizacji zakupu",
		absoluteDiscountIssue: "Wybierz rabat, który nie przekracza sumy całkowitej",
		expirationDateIssue: "Wybierz datę wygaśnięcia w przyszłości",
		threshold: {
			underThresholdError: "Łączna cena wnioskowanej oferty nie osiąga minimalnego progu"
		},
		expired: "Ta wycena wygasła. Musisz ponownie przesłać prośbę o wycenę, aby otrzymać kolejną ofertę od dostawcy.",
		downloadPDFError: "Coś poszło nie tak. Nie można uzyskać pliku PDF z ofertą."
	},
	items: {
		regionTitle: "Pozycje koszyka"
	},
	links: {
		newCart: "Nowy koszyk",
		quotes: "Oferty",
		download: "Pobierz propozycję",
		order: "Szczegóły zamówienia",
		a11y: {
			newCart: "Utwórz nowy pusty koszyk i przejdź do niego.",
			quotes: "Przejdź do listy wyników wyszukiwania ofert.",
			download: "Pobierz proponowaną wycenę",
			order: "Przejdź do zamówienia powiązanego z tą ofertą"
		}
	},
	list: {
		regionTitle: "Podsumowanie listy ofert",
		title: "Lista ofert",
		name: "Nazwa",
		updated: "Zaktualizowane",
		sortBy: "Sortuj według",
		sortQuotes: "Sortuj oferty",
		empty: "Nie mamy rekordów wycen dla tego konta.",
		quoteId: "ID oferty",
		status: "Status",
		clickableRow: "Kliknij wiersz, aby uzyskać więcej szczegółów wyceny"
	},
	states: {
		BUYER_DRAFT: "Wersja robocza",
		BUYER_SUBMITTED: "Przesłane",
		BUYER_ACCEPTED: "Zaakceptowane",
		BUYER_APPROVED: "Zatwierdzone",
		BUYER_REJECTED: "Odrzucone",
		BUYER_OFFER: "Oferta dostawcy",
		BUYER_ORDERED: "Zamówione",
		SELLER_DRAFT: "Wersja robocza",
		SELLER_REQUEST: "Wnioskowane",
		SELLER_SUBMITTED: "Przesłane",
		SELLERAPPROVER_DRAFT: "Wersja robocza",
		SELLERAPPROVER_PENDING: "Oczekuje na zatwierdzenie",
		SELLERAPPROVER_APPROVED: "Zatwierdzone",
		SELLERAPPROVER_REJECTED: "Odrzucone",
		CREATED: "Utworzone",
		CANCELLED: "Anulowane",
		EXPIRED: "Wygasłe"
	},
	summary: {
		regionTitle: "Podsumowanie zamówienia",
		actions: {
			APPROVE: "Zatwierdź ofertę",
			CANCEL: "Anuluj ofertę",
			CHECKOUT: "Zaakceptuj i zrealizuj zakup",
			EDIT: "Edytuj ofertę",
			REJECT: "Odrzuć ofertę",
			REQUOTE: "Poproś o nową wycenę",
			SAVE: "Zapisz ofertę",
			SUBMIT: "Prześlij ofertę",
			VIEW: "Wyświetl ofertę"
		},
		prices: {
			title: "Podsumowanie zamówienia",
			subtotal: "Suma częściowa",
			productDiscount: "Rabat dla pozycji",
			orderDiscount: "Rabat zamówienia",
			quoteDiscount: "Rabat oferty",
			total: "Suma",
			hint: "Podatki nie są uwzględnione w kwocie całkowitej"
		},
		sellerEdit: {
			discount: "Rabat",
			apply: "Zastosuj",
			expiryDate: "Data wygaśnięcia",
			discountValidationText: "Wprowadź ważny upust procentowy",
			a11y: {
				apply: "Kliknij, aby zastosować wprowadzoną wartość rabatu do tej oferty",
				discount: "Wprowadź procentową wartość rabatu, który ma zostać zastosowany do tej oferty",
				expiryDate: "Wprowadź datę wygaśnięcia tej oferty"
			}
		}
	}
};
var quote$9 = {
	quote: quote$8
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const pl = {
    quote: quote$9,
};

var quote$6 = {
	confirmDialog: {
		name: "Nome:",
		description: "Descrição:",
		validity: "Esta cotação é válida até {{ expirationTime }}",
		option: {
			yes: "Sim",
			no: "Não"
		},
		buyer: {
			submit: {
				a11y: {
					close: "Fechar modal de envio de cotação"
				},
				title: "Enviar solicitação de cotação {{ code }}?",
				confirmNote: "Tem a certeza que quer enviar esta solicitação de cotação?",
				successMessage: "Solicitação de cotação enviada com êxito"
			},
			cancel: {
				a11y: {
					close: "Fechar modal de cancelamento de cotação"
				},
				title: "Cancelar solicitação de cotação {{ code }}?",
				confirmNote: "Tem a certeza que quer cancelar esta solicitação de cotação?",
				successMessage: "Solicitação de cotação cancelada"
			}
		},
		buyer_offer: {
			edit: {
				a11y: {
					close: "Fechar modal de edição de cotação"
				},
				title: "Confirmar edição de cotação {{ code }}?",
				confirmNote: "Tem a certeza que quer editar esta cotação aprovada?",
				warningNote: "Esta cotação foi aprovada. A edição desta cotação evitará o check-out até as novas edições serem aprovadas."
			},
			cancel: {
				a11y: {
					close: "Fechar modal de cancelamento de cotação"
				},
				title: "Cancelar cotação {{ code }}?",
				confirmNote: "Tem a certeza que quer cancelar esta cotação?",
				successMessage: "Cotação cancelada"
			},
			checkout: {
				a11y: {
					close: "Fechar modal de check-out de cotação"
				},
				title: "Fazer check-out da cotação {{ code }}?",
				confirmNote: "Tem a certeza que quer aceitar e fazer check-out desta cotação?"
			}
		},
		expired: {
			edit: {
				a11y: {
					close: "Fechar modal de edição de cotação"
				},
				title: "Confirmar edição de cotação {{ code }}?",
				confirmNote: "Tem a certeza que quer editar esta cotação expirada?",
				warningNote: "Esta cotação expirou. A edição desta cotação evitará o check-out até as novas edições serem aprovadas."
			},
			requote: {
				a11y: {
					close: "Fechar modal de nova cotação"
				},
				title: "Recriar solicitação de cotação {{ code }}?",
				confirmNote: "Tem a certeza que quer recriar esta solicitação de cotação?",
				warningNote: "Esta cotação expirou. A nova cotação criará uma nova solicitação de cotação com o mesmo conteúdo, que poderá ser editada e enviada para aprovação posteriormente."
			}
		},
		seller: {
			submit: {
				a11y: {
					close: "Fechar modal de envio de cotação"
				},
				title: "Enviar cotação {{ code }}?",
				confirmNote: "Tem a certeza que quer enviar esta cotação?",
				warningNote: "Dependendo do valor total da cotação, poderá ser necessária uma aprovação adicional antes que o comprador possa fazer check-out dessa cotação.",
				successMessage: "Cotação enviada com êxito"
			}
		},
		sellerapprover: {
			approve: {
				a11y: {
					close: "Fechar modal de aprovação de cotação"
				},
				title: "Aprovar cotação {{ code }}?",
				confirmNote: "Tem a certeza que quer aprovar esta cotação?",
				successMessage: "Cotação aprovada com êxito"
			},
			reject: {
				a11y: {
					close: "Fechar modal de rejeição de cotação"
				},
				title: "Rejeitar cotação {{ code }}?",
				confirmNote: "Tem a certeza que quer rejeitar esta cotação?",
				successMessage: "Cotação rejeitada"
			}
		},
		cancelled: {
			requote: {
				a11y: {
					close: "Fechar modal de nova cotação"
				},
				title: "Recriar solicitação de cotação {{ code }}?",
				confirmNote: "Tem a certeza que quer recriar esta solicitação de cotação?",
				warningNote: "Seu carrinho atual será convertido em um carrinho gravado."
			}
		},
		all: {
			edit: {
				a11y: {
					close: "Fechar modal de edição de cotação"
				},
				title: "Editar cotação {{ code }}?",
				confirmNote: "Tem a certeza que quer editar esta cotação?",
				warningNote: "Seu carrinho atual será convertido em um carrinho gravado."
			}
		}
	},
	comments: {
		regionTitle: "Contato/caixa de comentários",
		title: "Contato",
		invalidComment: "Entrada inválida - Digite novamente...",
		allProducts: "Todos os produtos"
	},
	commons: {
		requestQuote: "Solicitar cotação",
		cart: "Carrinho",
		minRequestInitiationNote: "É necessário um subtotal mínimo de ${{minValue}} para enviar uma cotação ",
		savedActiveCart: "Seu carrinho ativo foi convertido no carrinho gravado {{ code }}"
	},
	header: {
		buyerEdit: {
			a11y: {
				cancel: "Cancelar edição de informações do cabeçalho da cotação",
				save: "Gravar informações do cabeçalho da cotação"
			}
		},
		overview: {
			regionTitle: "Resumo de detalhes da cotação",
			id: "ID da cotação",
			status: "Status",
			information: "Informações da cotação",
			name: "Nome",
			description: "Descrição",
			charactersLeft: "caracteres restantes: {{count}}",
			priceAndExpiry: "Preço e validade",
			estimatedTotal: "Total estimado",
			total: "Total",
			expirationTime: "Data de validade",
			a11y: {
				edit: "Editar informações do cabeçalho da cotação"
			},
			createdAndUpdated: "Criado e atualizado",
			createdDate: "Criado",
			lastUpdatedDate: "Última atualização"
		}
	},
	httpHandlers: {
		cartValidationIssue: "Existem problemas com suas entradas. Revise seu carrinho.",
		quoteCartIssue: "Não é possível efetuar modificações nas entradas do carrinho. Prossiga para o check-out",
		absoluteDiscountIssue: "Selecione um desconto que não exceda o valor total",
		expirationDateIssue: "Selecione uma data de expiração no futuro",
		threshold: {
			underThresholdError: "O preço total da cotação solicitada não cumpre o limite mínimo"
		},
		expired: "Esta cotação expirou. Você deve reenviar sua solicitação de cotação para receber outra cotação do fornecedor.",
		downloadPDFError: "Algo deu errado. Impossível obter PDF do documento de proposta."
	},
	items: {
		regionTitle: "Itens do carrinho"
	},
	links: {
		newCart: "Novo carrinho",
		quotes: "Cotações",
		download: "Baixar proposta",
		order: "Detalhe do pedido",
		a11y: {
			newCart: "Crie um novo carrinho vazio e navegue para o mesmo.",
			quotes: "Navegue para a lista de resultados da pesquisa de cotações.",
			download: "Inicie o download de uma proposta de cotação",
			order: "Navegue para a ordem associada com esta cotação"
		}
	},
	list: {
		regionTitle: "Resumo da lista de cotações ",
		title: "Lista de cotações",
		name: "Nome",
		updated: "Atualizado",
		sortBy: "Ordenar por",
		sortQuotes: "Ordenar cotações",
		empty: "Não temos registros de cotações para essa conta.",
		quoteId: "ID da cotação",
		status: "Status",
		clickableRow: "Clique na linha para obter mais detalhes da cotação"
	},
	states: {
		BUYER_DRAFT: "Rascunho",
		BUYER_SUBMITTED: "Enviado",
		BUYER_ACCEPTED: "Aceito",
		BUYER_APPROVED: "Aprovado",
		BUYER_REJECTED: "Rejeitado",
		BUYER_OFFER: "Cotação do fornecedor",
		BUYER_ORDERED: "Pedido",
		SELLER_DRAFT: "Rascunho",
		SELLER_REQUEST: "Solicitado",
		SELLER_SUBMITTED: "Enviado",
		SELLERAPPROVER_DRAFT: "Rascunho",
		SELLERAPPROVER_PENDING: "Aprovação pendente",
		SELLERAPPROVER_APPROVED: "Aprovado",
		SELLERAPPROVER_REJECTED: "Rejeitado",
		CREATED: "Criado",
		CANCELLED: "Cancelado",
		EXPIRED: "Expirado"
	},
	summary: {
		regionTitle: "Resumo do pedido",
		actions: {
			APPROVE: "Aprovar cotação",
			CANCEL: "Cancelar cotação",
			CHECKOUT: "Aceitar e fazer check-out",
			EDIT: "Editar cotação",
			REJECT: "Rejeitar cotação",
			REQUOTE: "Solicitar nova cotação",
			SAVE: "Gravar cotação",
			SUBMIT: "Enviar cotação",
			VIEW: "Visualizar cotação"
		},
		prices: {
			title: "Resumo do pedido",
			subtotal: "Subtotal",
			productDiscount: "Desconto de item",
			orderDiscount: "Desconto do pedido",
			quoteDiscount: "Desconto de cotação",
			total: "Total",
			hint: "Não são incluídos impostos no total"
		},
		sellerEdit: {
			discount: "Desconto",
			apply: "Aplicar",
			expiryDate: "Data de validade",
			discountValidationText: "Insira um desconto percentual válido",
			a11y: {
				apply: "Clique para aplicar o valor de desconto inserido a essa cotação",
				discount: "Insira um valor do desconto percentual a ser aplicado a essa cotação",
				expiryDate: "Insira uma data de validade para essa cotação"
			}
		}
	}
};
var quote$7 = {
	quote: quote$6
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const pt = {
    quote: quote$7,
};

var quote$4 = {
	confirmDialog: {
		name: "Имя:",
		description: "Описание:",
		validity: "Это предложение действительно до {{ expirationTime }}",
		option: {
			yes: "Да",
			no: "Нет"
		},
		buyer: {
			submit: {
				a11y: {
					close: "Закрыть модальное окно отправки предложения"
				},
				title: "Отправить запрос предложения {{ code }}?",
				confirmNote: "Действительно отправить запрос предложения?",
				successMessage: "Запрос предложения отправлен"
			},
			cancel: {
				a11y: {
					close: "Закрыть модальное окно отмены предложения"
				},
				title: "Отменить запрос предложения {{ code }}?",
				confirmNote: "Действительно отменить запрос предложения?",
				successMessage: "Запрос предложения отменен"
			}
		},
		buyer_offer: {
			edit: {
				a11y: {
					close: "Закрыть модальное окно редактирования предложения"
				},
				title: "Подтвердить редактирование предложения {{ code }}?",
				confirmNote: "Действительно отредактировать утвержденное предложение?",
				warningNote: "Это предложение утверждено. Редактирование предложения не позволит оформить заказ до утверждения новых редакций."
			},
			cancel: {
				a11y: {
					close: "Закрыть модальное окно отмены предложения"
				},
				title: "Отменить предложение {{ code }}?",
				confirmNote: "Действительно отменить предложение?",
				successMessage: "Предложение отменено"
			},
			checkout: {
				a11y: {
					close: "Закрыть модальное окно оформления заказа по предложению"
				},
				title: "Оформить заказ по предложению {{ code }}?",
				confirmNote: "Действительно принять предложение и оформить заказ?"
			}
		},
		expired: {
			edit: {
				a11y: {
					close: "Закрыть модальное окно редактирования предложения"
				},
				title: "Подтвердить редактирование предложения {{ code }}?",
				confirmNote: "Действительно отредактировать просроченное предложение?",
				warningNote: "Это предложение просрочено. Редактирование предложения не позволит оформить заказ до утверждения новых редакций."
			},
			requote: {
				a11y: {
					close: "Закрыть модальное окно повторного предложения"
				},
				title: "Повторно создать запрос предложения {{ code }}?",
				confirmNote: "Действительно повторно создать запрос предложения?",
				warningNote: "Это предложение просрочено. Повторное предложение позволяет создать новый запрос предложения с тем же контентом, который можно отредактировать и отправить на утверждение."
			}
		},
		seller: {
			submit: {
				a11y: {
					close: "Закрыть модальное окно отправки предложения"
				},
				title: "Отправить предложение {{ code }}?",
				confirmNote: "Действительно отправить предложение?",
				warningNote: "В зависимости от общей стоимости предложения может потребоваться дополнительное предложение перед тем, как покупатель сможет оформить заказ по предложению.",
				successMessage: "Предложение отправлено"
			}
		},
		sellerapprover: {
			approve: {
				a11y: {
					close: "Закрыть модальное окно утверждения предложения"
				},
				title: "Утвердить предложение {{ code }}?",
				confirmNote: "Действительно утвердить предложение?",
				successMessage: "Предложение утверждено"
			},
			reject: {
				a11y: {
					close: "Закрыть модальное окно отклонения предложения"
				},
				title: "Отклонить предложение {{ code }}?",
				confirmNote: "Действительно отклонить предложение?",
				successMessage: "Предложение отклонено"
			}
		},
		cancelled: {
			requote: {
				a11y: {
					close: "Закрыть модальное окно повторного предложения"
				},
				title: "Повторно создать запрос предложения {{ code }}?",
				confirmNote: "Действительно повторно создать запрос предложения?",
				warningNote: "Текущая корзина будет преобразована в сохраненную."
			}
		},
		all: {
			edit: {
				a11y: {
					close: "Закрыть модальное окно редактирования предложения"
				},
				title: "Редактировать предложение {{ code }}?",
				confirmNote: "Действительно отредактировать предложение?",
				warningNote: "Текущая корзина будет преобразована в сохраненную."
			}
		}
	},
	comments: {
		regionTitle: "Окно контакта/комментария",
		title: "Контакт",
		invalidComment: "Недействительный ввод. Введите снова...",
		allProducts: "Все продукты"
	},
	commons: {
		requestQuote: "Запросить предложение",
		cart: "Корзина",
		minRequestInitiationNote: "Минимальная промежуточная сумма для отправки предложения: {{minValue}}$ ",
		savedActiveCart: "Ваша активная корзина преобразована в сохраненную {{ code }}"
	},
	header: {
		buyerEdit: {
			a11y: {
				cancel: "Отменить редактирование информации заголовка предложения",
				save: "Сохранить информацию заголовка предложения"
			}
		},
		overview: {
			regionTitle: "Обзор сведений предложения",
			id: "Ид. предложения",
			status: "Статус",
			information: "Информация о предложении",
			name: "Имя",
			description: "Описание",
			charactersLeft: "Осталось символов: {{count}}",
			priceAndExpiry: "Цена и истечение срока",
			estimatedTotal: "Ориентировочная итоговая сумма",
			total: "Итого",
			expirationTime: "Срок действия",
			a11y: {
				edit: "Редактировать информацию заголовка предложения"
			},
			createdAndUpdated: "Создано и обновлено",
			createdDate: "Создано",
			lastUpdatedDate: "Последнее обновление"
		}
	},
	httpHandlers: {
		cartValidationIssue: "Возникла проблема с записями. Проверьте корзину.",
		quoteCartIssue: "Невозможно изменить записи корзины. Выполнен переход к оформлению заказа.",
		absoluteDiscountIssue: "Выберите скидку, которая не превышает общую стоимость",
		expirationDateIssue: "Выберите срок действия в будущем",
		threshold: {
			underThresholdError: "Общая цена запрошенного предложения ниже минимального порогового значения"
		},
		expired: "Это предложение просрочено. Можно повторно отправить запрос предложения, чтобы получить предложение от другого поставщика.",
		downloadPDFError: "Что-то пошло не так. Невозможно получить PDF документа предложения."
	},
	items: {
		regionTitle: "Позиции корзины"
	},
	links: {
		newCart: "Новая корзина",
		quotes: "Предложения",
		download: "Выгрузить предложение",
		order: "Сведения о заказе",
		a11y: {
			newCart: "Создайте новую пустую корзину и перейдите к ней.",
			quotes: "Перейдите к списку результатов поиска предложений.",
			download: "Начать выгрузку предложения",
			order: "Переход к заказу, связанному с этим предложением"
		}
	},
	list: {
		regionTitle: "Обзор списка предложений",
		title: "Список предложений",
		name: "Имя",
		updated: "Обновлено",
		sortBy: "Сортировать по",
		sortQuotes: "Сортировать предложения",
		empty: "Нет записей предложений для этой учетной записи.",
		quoteId: "Ид. предложения",
		status: "Статус",
		clickableRow: "Щелкните строку, чтобы просмотреть сведения о предложении"
	},
	states: {
		BUYER_DRAFT: "Черновик",
		BUYER_SUBMITTED: "Отправлено",
		BUYER_ACCEPTED: "Принято",
		BUYER_APPROVED: "Утверждено",
		BUYER_REJECTED: "Отклонено",
		BUYER_OFFER: "Предложение поставщика",
		BUYER_ORDERED: "Заказано",
		SELLER_DRAFT: "Черновик",
		SELLER_REQUEST: "Запрошено",
		SELLER_SUBMITTED: "Отправлено",
		SELLERAPPROVER_DRAFT: "Черновик",
		SELLERAPPROVER_PENDING: "Ожидает утверждения",
		SELLERAPPROVER_APPROVED: "Утверждено",
		SELLERAPPROVER_REJECTED: "Отклонено",
		CREATED: "Создано",
		CANCELLED: "Отменено",
		EXPIRED: "Просрочено"
	},
	summary: {
		regionTitle: "Обзор заказа",
		actions: {
			APPROVE: "Утвердить предложение",
			CANCEL: "Отменить предложение",
			CHECKOUT: "Принять и оформить заказ",
			EDIT: "Редактировать предложение",
			REJECT: "Отклонить предложение",
			REQUOTE: "Запросить новое предложение",
			SAVE: "Сохранить предложение",
			SUBMIT: "Отправить предложение",
			VIEW: "Просмотреть предложение"
		},
		prices: {
			title: "Обзор заказа",
			subtotal: "Промежуточная сумма",
			productDiscount: "Скидка по позиции",
			orderDiscount: "Скидка по заказу",
			quoteDiscount: "Скидка по предложению",
			total: "Итого",
			hint: "Итоговая сумма не включает налог"
		},
		sellerEdit: {
			discount: "Скидка",
			apply: "Применить",
			expiryDate: "Срок действия",
			discountValidationText: "Введите действительный процент скидки",
			a11y: {
				apply: "Щелкните, чтобы применить указанное значение скидки к предложению",
				discount: "Введите значение процента скидки для предложения",
				expiryDate: "Введите срок действия предложения"
			}
		}
	}
};
var quote$5 = {
	quote: quote$4
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ru = {
    quote: quote$5,
};

var quote$2 = {
	confirmDialog: {
		name: "名称：",
		description: "描述：",
		validity: "此报价在 {{ expirationTime }} 之前有效",
		option: {
			yes: "是",
			no: "否"
		},
		buyer: {
			submit: {
				a11y: {
					close: "关闭提交报价模式"
				},
				title: "提交报价请求 {{ code }}？",
				confirmNote: "是否确定要提交此报价请求？",
				successMessage: "报价请求已成功提交"
			},
			cancel: {
				a11y: {
					close: "关闭取消报价模式"
				},
				title: "取消报价请求 {{ code }}？",
				confirmNote: "是否确定要取消此报价请求？",
				successMessage: "报价请求已取消"
			}
		},
		buyer_offer: {
			edit: {
				a11y: {
					close: "关闭编辑报价模式"
				},
				title: "确认编辑报价 {{ code }}？",
				confirmNote: "是否确定要编辑此已获批准的报价？",
				warningNote: "此报价已获批准。在新编辑获得批准前，编辑此报价将阻止结账。"
			},
			cancel: {
				a11y: {
					close: "关闭取消报价模式"
				},
				title: "取消报价 {{ code }}？",
				confirmNote: "是否确定要取消此报价？",
				successMessage: "报价已取消"
			},
			checkout: {
				a11y: {
					close: "关闭报价结账模式"
				},
				title: "对报价 {{ code }} 进行结账？",
				confirmNote: "是否确定要接受此报价并进行结账？"
			}
		},
		expired: {
			edit: {
				a11y: {
					close: "关闭编辑报价模式"
				},
				title: "确认编辑报价 {{ code }}？",
				confirmNote: "是否确定要编辑此已过期报价？",
				warningNote: "此报价已过期。在新编辑获得批准前，编辑此报价将阻止结账。"
			},
			requote: {
				a11y: {
					close: "关闭重新报价模式"
				},
				title: "重新创建报价请求 {{ code }}？",
				confirmNote: "是否确定要重新创建此报价请求？",
				warningNote: "此报价已过期。为其重新报价将创建一个内容相同的新报价请求，之后可对其进行编辑并提交以供审批。"
			}
		},
		seller: {
			submit: {
				a11y: {
					close: "关闭提交报价模式"
				},
				title: "提交报价 {{ code }}？",
				confirmNote: "是否确定要提交此报价？",
				warningNote: "根据报价的总计值，可能需要先进行附加审批，然后买方才能对此报价进行结账。",
				successMessage: "报价已成功提交"
			}
		},
		sellerapprover: {
			approve: {
				a11y: {
					close: "关闭批准报价模式"
				},
				title: "批准报价 {{ code }}？",
				confirmNote: "是否确定要批准此报价？",
				successMessage: "报价已成功批准"
			},
			reject: {
				a11y: {
					close: "关闭拒绝报价模式"
				},
				title: "拒绝报价 {{ code }}？",
				confirmNote: "是否确定要拒绝此报价？",
				successMessage: "报价已拒绝"
			}
		},
		cancelled: {
			requote: {
				a11y: {
					close: "关闭重新报价模式"
				},
				title: "重新创建报价请求 {{ code }}？",
				confirmNote: "是否确定要重新创建此报价请求？",
				warningNote: "您的当前购物车将转换为已保存购物车。"
			}
		},
		all: {
			edit: {
				a11y: {
					close: "关闭编辑报价模式"
				},
				title: "编辑报价 {{ code }}？",
				confirmNote: "是否确定要编辑此报价？",
				warningNote: "您的当前购物车将转换为已保存购物车。"
			}
		}
	},
	comments: {
		regionTitle: "联系人/评论框",
		title: "联系人",
		invalidComment: "输入无效 - 请重新输入...",
		allProducts: "所有产品"
	},
	commons: {
		requestQuote: "请求报价",
		cart: "购物车",
		minRequestInitiationNote: "提交报价要求最低小计为 {{minValue}} 美元。 ",
		savedActiveCart: "您的已激活购物车转换为已保存购物车 {{ code }}"
	},
	header: {
		buyerEdit: {
			a11y: {
				cancel: "取消编辑报价抬头信息",
				save: "保存报价抬头信息"
			}
		},
		overview: {
			regionTitle: "报价详细信息摘要",
			id: "报价标识",
			status: "状态",
			information: "报价信息",
			name: "名称",
			description: "描述",
			charactersLeft: "剩余字符：{{count}}",
			priceAndExpiry: "价格和过期日期",
			estimatedTotal: "估算总额",
			total: "总计",
			expirationTime: "过期日期",
			a11y: {
				edit: "编辑报价抬头信息"
			},
			createdAndUpdated: "已创建和已更新",
			createdDate: "已创建",
			lastUpdatedDate: "上次更新"
		}
	},
	httpHandlers: {
		cartValidationIssue: "您的条目存在问题。请检查您的购物车。",
		quoteCartIssue: "无法对购物车条目进行更改。继续结账",
		absoluteDiscountIssue: "选择不超过总值的折扣",
		expirationDateIssue: "选择未来过期日期",
		threshold: {
			underThresholdError: "所请求报价的总价格未达到最低阈值"
		},
		expired: "此报价已过期。您必须重新提交报价请求才能接收其他供应商报价。",
		downloadPDFError: "出错了。无法获取提案文档 PDF。"
	},
	items: {
		regionTitle: "购物车项目"
	},
	links: {
		newCart: "新购物车",
		quotes: "报价",
		download: "下载提案",
		order: "订单详细信息",
		a11y: {
			newCart: "创建新的空购物车并导航到此购物车。",
			quotes: "导航到报价搜索结果列表。",
			download: "开始下载报价提案",
			order: "导航到与此报价相关联的订单"
		}
	},
	list: {
		regionTitle: "报价列表摘要",
		title: "报价列表",
		name: "名称",
		updated: "已更新",
		sortBy: "排序依据",
		sortQuotes: "对报价进行排序",
		empty: "我们没有此帐户的报价记录。",
		quoteId: "报价标识",
		status: "状态",
		clickableRow: "单击行即可获得更多报价详细信息"
	},
	states: {
		BUYER_DRAFT: "草稿",
		BUYER_SUBMITTED: "已提交",
		BUYER_ACCEPTED: "已接受",
		BUYER_APPROVED: "已批准",
		BUYER_REJECTED: "已拒绝",
		BUYER_OFFER: "供应商报价",
		BUYER_ORDERED: "已订购",
		SELLER_DRAFT: "草稿",
		SELLER_REQUEST: "已请求",
		SELLER_SUBMITTED: "已提交",
		SELLERAPPROVER_DRAFT: "草稿",
		SELLERAPPROVER_PENDING: "待审批",
		SELLERAPPROVER_APPROVED: "已批准",
		SELLERAPPROVER_REJECTED: "已拒绝",
		CREATED: "已创建",
		CANCELLED: "已取消",
		EXPIRED: "已过期"
	},
	summary: {
		regionTitle: "订单摘要",
		actions: {
			APPROVE: "批准报价",
			CANCEL: "取消报价",
			CHECKOUT: "接受并结账",
			EDIT: "编辑报价",
			REJECT: "拒绝报价",
			REQUOTE: "请求新报价",
			SAVE: "保存报价",
			SUBMIT: "提交报价",
			VIEW: "查看报价"
		},
		prices: {
			title: "订单摘要",
			subtotal: "小计",
			productDiscount: "项目折扣",
			orderDiscount: "订单折扣",
			quoteDiscount: "报价折扣",
			total: "总计",
			hint: "总计中不含税"
		},
		sellerEdit: {
			discount: "折扣",
			apply: "应用",
			expiryDate: "过期日期",
			discountValidationText: "输入有效的百分比折扣",
			a11y: {
				apply: "单击以将输入的折扣值应用到此报价",
				discount: "输入要应用到此报价的百分比折扣值",
				expiryDate: "输入此报价的过期日期"
			}
		}
	}
};
var quote$3 = {
	quote: quote$2
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const zh = {
    quote: quote$3,
};

var quote = {
	confirmDialog: {
		name: "名稱：",
		description: "說明：",
		validity: "此報價 {{ expirationTime }} 前有效",
		option: {
			yes: "是",
			no: "否"
		},
		buyer: {
			submit: {
				a11y: {
					close: "關閉提交報價強制回應視窗"
				},
				title: "提交報價請求 {{ code }} 嗎？",
				confirmNote: "您確定要提交此報價請求嗎？",
				successMessage: "已成功提交報價請求"
			},
			cancel: {
				a11y: {
					close: "關閉取消報價強制回應視窗"
				},
				title: "取消報價請求 {{ code }} 嗎？",
				confirmNote: "您確定要取消此報價請求嗎？",
				successMessage: "已取消報價請求"
			}
		},
		buyer_offer: {
			edit: {
				a11y: {
					close: "關閉編輯報價強制回應視窗"
				},
				title: "確認編輯報價 {{ code }} 嗎？",
				confirmNote: "您確定要編輯此核准的報價嗎？",
				warningNote: "此報價已核准，核准新編輯前若編輯此報價將無法結帳。"
			},
			cancel: {
				a11y: {
					close: "關閉取消報價強制回應視窗"
				},
				title: "取消報價 {{ code }} 嗎？",
				confirmNote: "您確定要取消此報價嗎？",
				successMessage: "已取消報價"
			},
			checkout: {
				a11y: {
					close: "關閉結帳報價強制回應視窗"
				},
				title: "結帳報價 {{ code }} 嗎？",
				confirmNote: "您確定要接受並結帳此報價嗎？"
			}
		},
		expired: {
			edit: {
				a11y: {
					close: "關閉編輯報價強制回應視窗"
				},
				title: "確認編輯報價 {{ code }} 嗎？",
				confirmNote: "您確定要編輯此過期報價嗎？",
				warningNote: "此報價已過期。核准新編輯前若編輯此報價將無法結帳。"
			},
			requote: {
				a11y: {
					close: "關閉重新報價強制回應視窗"
				},
				title: "重新建立報價請求 {{ code }} 嗎？",
				confirmNote: "您確定要重新建立此報價請求嗎？",
				warningNote: "此報價已過期。重新報價將建立包含相同內容的新報價請求，隨後可進行編輯和提交核准。"
			}
		},
		seller: {
			submit: {
				a11y: {
					close: "關閉提交報價強制回應視窗"
				},
				title: "提交報價 {{ code }} 嗎？",
				confirmNote: "您確定要提交此報價嗎？",
				warningNote: "根據報價的總值，買方可能需要額外核准才能結帳此報價。",
				successMessage: "已成功提交報價"
			}
		},
		sellerapprover: {
			approve: {
				a11y: {
					close: "關閉核准報價強制回應視窗"
				},
				title: "核准報價 {{ code }} 嗎？",
				confirmNote: "您確定要核准此報價嗎？",
				successMessage: "已成功核准報價"
			},
			reject: {
				a11y: {
					close: "關閉拒絕報價強制回應視窗"
				},
				title: "拒絕報價 {{ code }} 嗎？",
				confirmNote: "您確定要拒絕此報價嗎？",
				successMessage: "已拒絕報價"
			}
		},
		cancelled: {
			requote: {
				a11y: {
					close: "關閉重新報價強制回應視窗"
				},
				title: "重新建立報價請求 {{ code }} 嗎？",
				confirmNote: "您確定要重新建立此報價請求嗎？",
				warningNote: "您的目前購物車將轉換為儲存的購物車。"
			}
		},
		all: {
			edit: {
				a11y: {
					close: "關閉編輯報價強制回應視窗"
				},
				title: "編輯報價 {{ code }} 嗎？",
				confirmNote: "您確定要編輯此報價嗎？",
				warningNote: "您的目前購物車將轉換為儲存的購物車。"
			}
		}
	},
	comments: {
		regionTitle: "聯絡人/備註方塊",
		title: "聯絡人",
		invalidComment: "無效輸入 - 請重新輸入...",
		allProducts: "所有產品"
	},
	commons: {
		requestQuote: "請求報價",
		cart: "購物車",
		minRequestInitiationNote: "需要最小 ${{minValue}} 小計以提交報價 ",
		savedActiveCart: "您的啟用中購物溝已轉換為儲存的購物車 {{ code }}"
	},
	header: {
		buyerEdit: {
			a11y: {
				cancel: "取消編輯報價表頭資訊",
				save: "儲存報價表頭資訊"
			}
		},
		overview: {
			regionTitle: "報價明細摘要",
			id: "報價 ID",
			status: "狀態",
			information: "報價資訊",
			name: "名稱",
			description: "說明",
			charactersLeft: "剩餘字元：{{count}}",
			priceAndExpiry: "價格和到期",
			estimatedTotal: "預估總計",
			total: "總計",
			expirationTime: "到期日期",
			a11y: {
				edit: "編輯報價表頭資訊"
			},
			createdAndUpdated: "已建立並更新",
			createdDate: "已建立",
			lastUpdatedDate: "上次更新"
		}
	},
	httpHandlers: {
		cartValidationIssue: "您的項目發生問題。請審查您的購物車。",
		quoteCartIssue: "無法更改購物車項目。請繼續結帳",
		absoluteDiscountIssue: "選擇未超過總值的折扣",
		expirationDateIssue: "選擇未來的到期日期",
		threshold: {
			underThresholdError: "請求報價的總價不符合最小門檻"
		},
		expired: "此報價已到期。您必須重新提交報價請求才能接收其他供應商報價。",
		downloadPDFError: "發生錯誤。無法取得建議文件 PDF。"
	},
	items: {
		regionTitle: "購物車項目"
	},
	links: {
		newCart: "新購物車",
		quotes: "報價",
		download: "下載建議",
		order: "訂單明細",
		a11y: {
			newCart: "建立新空白購物車並瀏覽至其中。",
			quotes: "瀏覽至報價搜尋結果清單。",
			download: "開始下載報價建議",
			order: "瀏覽至與此報價相關的訂單"
		}
	},
	list: {
		regionTitle: "報價清單摘要",
		title: "報價清單",
		name: "名稱",
		updated: "已更新",
		sortBy: "排序依據",
		sortQuotes: "排序報價",
		empty: "我們沒有此帳戶的報價記錄。",
		quoteId: "報價 ID",
		status: "狀態",
		clickableRow: "按一下列以取得更多報價明細"
	},
	states: {
		BUYER_DRAFT: "草稿",
		BUYER_SUBMITTED: "已提交",
		BUYER_ACCEPTED: "已接受",
		BUYER_APPROVED: "已核准",
		BUYER_REJECTED: "已拒絕",
		BUYER_OFFER: "供應商報價",
		BUYER_ORDERED: "已訂購",
		SELLER_DRAFT: "草稿",
		SELLER_REQUEST: "已請求",
		SELLER_SUBMITTED: "已提交",
		SELLERAPPROVER_DRAFT: "草稿",
		SELLERAPPROVER_PENDING: "待核准",
		SELLERAPPROVER_APPROVED: "已核准",
		SELLERAPPROVER_REJECTED: "已拒絕",
		CREATED: "已建立",
		CANCELLED: "已取消",
		EXPIRED: "已到期"
	},
	summary: {
		regionTitle: "訂單摘要",
		actions: {
			APPROVE: "核准報價",
			CANCEL: "取消報價",
			CHECKOUT: "接受並結帳",
			EDIT: "編輯報價",
			REJECT: "拒絕報價",
			REQUOTE: "請求新報價",
			SAVE: "儲存報價",
			SUBMIT: "提交報價",
			VIEW: "檢視報價"
		},
		prices: {
			title: "訂單摘要",
			subtotal: "小計",
			productDiscount: "項目折扣",
			orderDiscount: "訂單折扣",
			quoteDiscount: "報價折扣",
			total: "總計",
			hint: "總計未含稅"
		},
		sellerEdit: {
			discount: "折扣",
			apply: "套用",
			expiryDate: "到期日期",
			discountValidationText: "輸入有效的百分比折扣",
			a11y: {
				apply: "按一下以將輸入的折扣值套用至此報價",
				discount: "輸入要套用至此報價的百分比折扣值",
				expiryDate: "輸入此報價的到期日期"
			}
		}
	}
};
var quote$1 = {
	quote: quote
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const zh_TW = {
    quote: quote$1,
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const quoteTranslationChunksConfig = {
    quote: ['quote'],
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { quoteTranslationChunksConfig, cs as quoteTranslationsCs, de as quoteTranslationsDe, en as quoteTranslationsEn, es as quoteTranslationsEs, es_CO as quoteTranslationsEs_CO, fr as quoteTranslationsFr, hi as quoteTranslationsHi, hu as quoteTranslationsHu, id as quoteTranslationsId, it as quoteTranslationsIt, ja as quoteTranslationsJa, ko as quoteTranslationsKo, pl as quoteTranslationsPl, pt as quoteTranslationsPt, ru as quoteTranslationsRu, zh as quoteTranslationsZh, zh_TW as quoteTranslationsZh_TW };
//# sourceMappingURL=spartacus-quote-assets.mjs.map
