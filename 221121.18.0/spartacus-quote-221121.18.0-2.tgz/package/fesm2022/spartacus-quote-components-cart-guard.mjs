import * as i0 from '@angular/core';
import { Component, inject, Injectable, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RoutingService, SemanticPathService, I18nModule, provideDefaultConfig } from '@spartacus/core';
import { Router } from '@angular/router';
import { QuoteCartService } from '@spartacus/quote/core';
import { combineLatest } from 'rxjs';
import { map } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * This component is used as a marker. In case it is present in the CMS composition of a page,
 * this page can be navigated to only if the {@link QuoteCartGuard}, which is attached
 * to this component, allows it. If not, the navigation will be re-directed to the quote
 * details page of the quote that is attached to the current cart.
 */
class QuoteCartGuardComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCartGuardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: QuoteCartGuardComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: "" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCartGuardComponent, decorators: [{
            type: Component,
            args: [{ template: "" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Ensures that the navigation will be re-directed to the quote
 * details page of the quote that is attached to the current cart in case:
 * (1) The current cart is linked to an editable quote
 * (2) The quote status doesn't allow the navigation to checkout
 */
class QuoteCartGuard {
    constructor() {
        this.routingService = inject(RoutingService);
        this.quoteCartService = inject(QuoteCartService);
        this.router = inject(Router);
        this.semanticPathService = inject(SemanticPathService);
    }
    canActivate() {
        return combineLatest([
            this.quoteCartService.isQuoteCartActive(),
            this.quoteCartService.getQuoteId(),
            this.quoteCartService.isCheckoutAllowed(),
            this.routingService.getRouterState(),
        ]).pipe(map(([isQuoteCartActive, quoteId, isCheckoutAllowed, routerState]) => {
            const isAllowedCheckoutNavigation = this.checkAllowedCheckoutNavigation(routerState, isCheckoutAllowed);
            if (isQuoteCartActive && !isAllowedCheckoutNavigation) {
                return this.router.createUrlTree(this.semanticPathService.transform({
                    cxRoute: 'quoteDetails',
                    params: { quoteId },
                }));
            }
            return true;
        }));
    }
    /**
     * Verifies if the current navigation is an allowed checkout navigation.
     *
     * @param routerState - Used to assess if a checkout navigation is attempted
     * @param isCheckoutAllowed - Is checkout allowed although this guard is active? Only happens for quotes in state BUYER_OFFER
     * that can be ordered
     * @returns true if a checkout navigation is attempted and allowed because of the current quote state
     */
    checkAllowedCheckoutNavigation(routerState, isCheckoutAllowed) {
        const nextStateIsCheckout = routerState.nextState?.semanticRoute?.startsWith('checkout');
        const currentStateIsCheckout = routerState.state.semanticRoute?.startsWith('checkout');
        const noNextState = routerState.nextState === undefined;
        return ((nextStateIsCheckout || (currentStateIsCheckout && noNextState)) &&
            isCheckoutAllowed);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCartGuard, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCartGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCartGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteCartGuardComponentModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCartGuardComponentModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QuoteCartGuardComponentModule, imports: [CommonModule, I18nModule, QuoteCartGuardComponent], exports: [QuoteCartGuardComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCartGuardComponentModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    QuoteCartGuardComponent: {
                        component: QuoteCartGuardComponent,
                        guards: [QuoteCartGuard],
                    },
                },
            }),
        ], imports: [CommonModule, I18nModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCartGuardComponentModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, I18nModule, QuoteCartGuardComponent],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                QuoteCartGuardComponent: {
                                    component: QuoteCartGuardComponent,
                                    guards: [QuoteCartGuard],
                                },
                            },
                        }),
                    ],
                    exports: [QuoteCartGuardComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { QuoteCartGuard, QuoteCartGuardComponent, QuoteCartGuardComponentModule };
//# sourceMappingURL=spartacus-quote-components-cart-guard.mjs.map
