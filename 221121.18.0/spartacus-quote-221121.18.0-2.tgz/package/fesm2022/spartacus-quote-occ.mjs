import { HttpClient } from '@angular/common/http';
import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { OccEndpointsService, ConverterService, LoggerService, OccFieldsService, tryNormalizeHttpError, PRODUCT_NORMALIZER, provideDefaultConfig } from '@spartacus/core';
import { OrderConfig } from '@spartacus/order/root';
import { QUOTE_LIST_NORMALIZER, QUOTE_STARTER_SERIALIZER, QUOTE_NORMALIZER, QUOTE_METADATA_SERIALIZER, QUOTE_ACTION_SERIALIZER, QUOTE_COMMENT_SERIALIZER, QUOTE_DISCOUNT_SERIALIZER, QuoteCoreConfig, QuoteCartService, QuoteAdapter } from '@spartacus/quote/core';
import { throwError, combineLatest } from 'rxjs';
import { catchError, take } from 'rxjs/operators';
import { CommonModule } from '@angular/common';
import { QuoteActionType, QuoteState } from '@spartacus/quote/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccQuoteAdapter {
    constructor() {
        this.httpClient = inject(HttpClient);
        this.occEndpointsService = inject(OccEndpointsService);
        this.converterService = inject(ConverterService);
        this.loggerService = inject(LoggerService);
        this.occFieldsService = inject(OccFieldsService);
        this.orderConfig = inject(OrderConfig);
    }
    getQuotes(userId, pagination) {
        const params = {};
        if (pagination.pageSize) {
            params['pageSize'] = pagination.pageSize.toString();
        }
        if (pagination.currentPage) {
            params['currentPage'] = pagination.currentPage.toString();
        }
        if (pagination.sort) {
            params['sort'] = pagination.sort.toString();
        }
        return this.withErrorHandling(this.httpClient.get(this.getQuotesEndpoint(userId, params))).pipe(this.converterService.pipeable(QUOTE_LIST_NORMALIZER));
    }
    getQuotesEndpoint(userId, params) {
        return this.occEndpointsService.buildUrl('getQuotes', {
            urlParams: { userId },
            queryParams: params,
        });
    }
    createQuote(userId, quoteStarter) {
        quoteStarter = this.converterService.convert(quoteStarter, QUOTE_STARTER_SERIALIZER);
        return this.withErrorHandling(this.httpClient.post(this.getCreateQuoteEndpoint(userId), quoteStarter)).pipe(this.converterService.pipeable(QUOTE_NORMALIZER));
    }
    getCreateQuoteEndpoint(userId) {
        return this.occEndpointsService.buildUrl('createQuote', {
            urlParams: { userId },
        });
    }
    getQuote(userId, quoteCode) {
        return this.withErrorHandling(this.httpClient.get(this.getQuoteEndpoint(userId, quoteCode))).pipe(this.converterService.pipeable(QUOTE_NORMALIZER));
    }
    getQuoteEndpoint(userId, quoteCode) {
        if (this.orderConfig.showOrderQuoteLink) {
            const scopes = ['getQuote', 'getOrderCode'];
            const scopedDataWithUrls = scopes.map((scope) => ({
                scopedData: { scope, userId, quoteCode },
                url: this.occEndpointsService.buildUrl(scope, {
                    urlParams: { userId, quoteCode },
                }),
            }));
            const mergedUrl = this.occFieldsService.getOptimalUrlGroups(scopedDataWithUrls);
            return Object.keys(mergedUrl)[0];
        }
        else {
            return this.occEndpointsService.buildUrl('getQuote', {
                urlParams: { userId, quoteCode },
            });
        }
    }
    editQuote(userId, quoteCode, quoteMetadata) {
        quoteMetadata = this.converterService.convert(quoteMetadata, QUOTE_METADATA_SERIALIZER);
        return this.withErrorHandling(this.httpClient.patch(this.getEditQuoteEndpoint(userId, quoteCode), quoteMetadata));
    }
    getEditQuoteEndpoint(userId, quoteCode) {
        return this.occEndpointsService.buildUrl('editQuote', {
            urlParams: { userId, quoteCode },
        });
    }
    performQuoteAction(userId, quoteCode, quoteAction) {
        quoteAction = this.converterService.convert(quoteAction, QUOTE_ACTION_SERIALIZER);
        return this.withErrorHandling(this.httpClient.post(this.getPerformQuoteActionEndpoint(userId, quoteCode), {
            action: quoteAction,
        }));
    }
    getPerformQuoteActionEndpoint(userId, quoteCode) {
        return this.occEndpointsService.buildUrl('performQuoteAction', {
            urlParams: { userId, quoteCode },
        });
    }
    addComment(userId, quoteCode, quoteComment) {
        quoteComment = this.converterService.convert(quoteComment, QUOTE_COMMENT_SERIALIZER);
        return this.withErrorHandling(this.httpClient.post(this.getAddCommentEndpoint(userId, quoteCode), quoteComment));
    }
    getAddCommentEndpoint(userId, quoteCode) {
        return this.occEndpointsService.buildUrl('addComment', {
            urlParams: { userId, quoteCode },
        });
    }
    addDiscount(userId, quoteCode, quoteDiscount) {
        quoteDiscount = this.converterService.convert(quoteDiscount, QUOTE_DISCOUNT_SERIALIZER);
        return this.withErrorHandling(this.httpClient.post(this.getAddDiscountEndpoint(userId, quoteCode), quoteDiscount));
    }
    getAddDiscountEndpoint(userId, quoteCode) {
        return this.occEndpointsService.buildUrl('addDiscount', {
            urlParams: { userId, quoteCode },
        });
    }
    addQuoteEntryComment(userId, quoteCode, entryNumber, comment) {
        comment = this.converterService.convert(comment, QUOTE_COMMENT_SERIALIZER);
        return this.withErrorHandling(this.httpClient.post(this.getAddQuoteEntryCommentEndpoint(userId, quoteCode, entryNumber), comment));
    }
    getAddQuoteEntryCommentEndpoint(userId, quoteCode, entryNumber) {
        return this.occEndpointsService.buildUrl('addQuoteEntryComment', {
            urlParams: { userId, quoteCode, entryNumber },
        });
    }
    downloadAttachment(userId, quoteCode, attachmentId) {
        return this.withErrorHandling(this.httpClient.get(this.getDownloadAttachmentEndpoint(userId, quoteCode, attachmentId), { responseType: 'blob' }));
    }
    getDownloadAttachmentEndpoint(userId, quoteCode, attachmentId) {
        return this.occEndpointsService.buildUrl('downloadAttachment', {
            urlParams: { userId, quoteCode, attachmentId },
        });
    }
    withErrorHandling(quoteObservable) {
        return quoteObservable.pipe(catchError((error) => throwError(tryNormalizeHttpError(error, this.loggerService))));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccQuoteAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccQuoteAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccQuoteAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const PRICE_HEADER_FIELDS = ',totalPrice(formattedValue),quoteDiscounts(formattedValue),orderDiscounts(formattedValue),productDiscounts(formattedValue)';
const defaultOccQuoteConfig = {
    backend: {
        occ: {
            endpoints: {
                getQuotes: 'users/${userId}/quotes',
                createQuote: 'users/${userId}/quotes',
                getQuote: 'users/${userId}/quotes/${quoteCode}?fields=FULL,expirationTime' +
                    PRICE_HEADER_FIELDS +
                    ',entries(FULL)',
                getOrderCode: 'users/${userId}/quotes/${quoteCode}?fields=sapOrderCode',
                editQuote: 'users/${userId}/quotes/${quoteCode}',
                performQuoteAction: 'users/${userId}/quotes/${quoteCode}/action',
                addComment: 'users/${userId}/quotes/${quoteCode}/comments',
                addDiscount: 'users/${userId}/quotes/${quoteCode}/discounts',
                addQuoteEntryComment: 'users/${userId}/quotes/${quoteCode}/entries/${entryNumber}/comments',
                downloadAttachment: 'users/${userId}/quotes/${quoteCode}/attachments/${attachmentId}',
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccQuoteActionNormalizer {
    constructor() {
        this.quoteCoreConfig = inject(QuoteCoreConfig);
        this.quoteCartService = inject(QuoteCartService);
    }
    convert(source, target) {
        if (!target) {
            target = { ...source, allowedActions: [], isEditable: false };
        }
        if (source.allowedActions && source.state) {
            target.allowedActions = this.getOrderedActions(source.state, source.allowedActions, source.code).map((action) => this.getActionCategory(action));
        }
        const switchToEditModeRequired = target.allowedActions?.find((quoteAction) => quoteAction.type === QuoteActionType.EDIT);
        target.isEditable =
            !!source.allowedActions?.includes(QuoteActionType.EDIT) &&
                !switchToEditModeRequired;
        return target;
    }
    getActionCategory(type) {
        const primaryActions = this.quoteCoreConfig.quote?.actions?.primaryActions || [];
        return { type, isPrimary: primaryActions.includes(type) };
    }
    getOrderedActions(state, list, quoteId) {
        const order = this.quoteCoreConfig.quote?.actions?.actionsOrderByState?.[state];
        if (order) {
            //deep copy order list
            const clonedActionList = structuredClone(order);
            combineLatest([
                this.quoteCartService.isQuoteCartActive(),
                this.quoteCartService.getQuoteId(),
            ])
                .pipe(take(1))
                .subscribe(([isQuoteCartActive, cartQuoteId]) => {
                if (state !== QuoteState.BUYER_OFFER &&
                    isQuoteCartActive &&
                    cartQuoteId === quoteId) {
                    const editIndex = clonedActionList.indexOf(QuoteActionType.EDIT);
                    if (editIndex > -1) {
                        clonedActionList.splice(editIndex, 1);
                    }
                }
            });
            return list
                .filter((item) => clonedActionList.includes(item))
                .sort((a, b) => clonedActionList.indexOf(a) - clonedActionList.indexOf(b));
        }
        else {
            return list;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccQuoteActionNormalizer, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccQuoteActionNormalizer, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccQuoteActionNormalizer, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccQuoteEntryNormalizer {
    constructor() {
        this.converterService = inject(ConverterService);
    }
    convert(source, target) {
        if (!target) {
            target = { ...source, allowedActions: [], isEditable: false };
        }
        if (source.entries) {
            target.entries = source.entries.map((entry) => ({
                ...entry,
                quoteCode: source.code,
                product: this.converterService.convert(entry.product, PRODUCT_NORMALIZER),
            }));
        }
        return target;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccQuoteEntryNormalizer, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccQuoteEntryNormalizer, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccQuoteEntryNormalizer, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteOccModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteOccModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QuoteOccModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteOccModule, providers: [
            provideDefaultConfig(defaultOccQuoteConfig),
            {
                provide: QuoteAdapter,
                useClass: OccQuoteAdapter,
            },
            {
                provide: QUOTE_NORMALIZER,
                useExisting: OccQuoteActionNormalizer,
                multi: true,
            },
            {
                provide: QUOTE_NORMALIZER,
                useExisting: OccQuoteEntryNormalizer,
                multi: true,
            },
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteOccModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [
                        provideDefaultConfig(defaultOccQuoteConfig),
                        {
                            provide: QuoteAdapter,
                            useClass: OccQuoteAdapter,
                        },
                        {
                            provide: QUOTE_NORMALIZER,
                            useExisting: OccQuoteActionNormalizer,
                            multi: true,
                        },
                        {
                            provide: QUOTE_NORMALIZER,
                            useExisting: OccQuoteEntryNormalizer,
                            multi: true,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OccQuoteAdapter, QuoteOccModule };
//# sourceMappingURL=spartacus-quote-occ.mjs.map
