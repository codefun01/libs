# Spartacus Organization

`@spartacus/organization` is a package that you can include in your application, which allows you to use various organization features.

It can be added to the existing Spartacus application by running `ng add @spartacus/organization`. For more information about Spartacus schematics, visit the [official Spartacus schematics documentation page](https://sap.github.io/spartacus-docs/schematics/).

The Spartacus Organization library contains the following packages:

- `@spartacus/organization/administration` is a package that contains various organization administration related features (eg. units, budgets, approvers management, etc.).
- `@spartacus/organization/order-approval` is a package that adds order approval dashboard feature.
- `@spartacus/organization/user-registration` is a package that adds registration for organization users.
- `@spartacus/organization/account-summary` is a package that contains account summaries feature.
- `@spartacus/organization/unit-order` is a package that adds unit level orders feature.


For more information about Spartacus, see [Spartacus](https://github.com/SAP/spartacus).
