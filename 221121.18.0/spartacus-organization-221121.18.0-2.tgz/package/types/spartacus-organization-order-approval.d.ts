import * as i0 from '@angular/core';
import { OnDestroy, OnInit, InjectionToken, ModuleWithProviders } from '@angular/core';
import * as i1 from '@angular/forms';
import { UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { Observable } from 'rxjs';
import * as i3 from '@spartacus/core';
import { OrderApprovalPermissionType, Principal, StateUtils, StateWithProcess, UserIdService, SearchConfig, EntitiesModel, RoutingService, TranslationService, Converter, GlobalMessageService, ErrorAction, ListModel, OccEndpointsService, ConverterService, Occ, OccEndpoint } from '@spartacus/core';
import { Order } from '@spartacus/order/root';
import * as i1$2 from '@ngrx/store';
import { Store, MemoizedSelector } from '@ngrx/store';
import * as i1$1 from '@angular/common';
import * as i4 from '@spartacus/storefront';
import * as i5 from '@angular/router';
import { OrderDetailsService } from '@spartacus/order/components';
import { UserAccountFacade } from '@spartacus/user/account/root';
import { HttpClient } from '@angular/common/http';
import * as i2 from '@ngrx/effects';

declare enum OrderApprovalDecisionValue {
    APPROVE = "APPROVE",
    REJECT = "REJECT"
}
interface OrderApprovalDecision {
    decision?: OrderApprovalDecisionValue;
    comment?: string;
}
interface OrderApprovalRecord {
    approver?: Principal;
    comments?: string;
    permissionTypes?: OrderApprovalPermissionType[];
    statusDisplay?: string;
}
interface OrderApproval {
    approvalDecisionRequired?: boolean;
    code?: string;
    customerOrderApprovalRecords?: OrderApprovalRecord[];
    merchantOrderApprovalRecords?: OrderApprovalRecord[];
    order?: Order;
    trigger?: OrderApprovalTrigger;
}
interface OrderApprovalPermissionResult {
    approverName: string;
    approverNotes: string;
    permissionType: OrderApprovalPermissionType;
    statusDisplay: string;
}
interface OrderApprovalTrigger {
    activationTime?: string;
    displayTimeTable?: string;
}

declare const ORDER_APPROVAL_FEATURE = "order-approval";
declare const ORDER_APPROVAL_ENTITIES = "order-approval-entities";
declare const ORDER_APPROVAL_LIST = "order-approval-list";
declare const ORDER_APPROVAL_MAKE_DECISION_PROCESS_ID = "orderApproval.makeDecision";
interface OrderApprovalManagement extends StateUtils.EntityListState<OrderApproval> {
}
interface OrderApprovalState {
    [ORDER_APPROVAL_FEATURE]: OrderApprovalManagement;
}

declare class OrderApprovalService {
    protected store: Store<OrderApprovalState | StateWithProcess<void>>;
    protected userIdService: UserIdService;
    constructor(store: Store<OrderApprovalState | StateWithProcess<void>>, userIdService: UserIdService);
    loadOrderApproval(orderApprovalCode: string): void;
    loadOrderApprovals(params: SearchConfig): void;
    private getOrderApproval;
    private getOrderApprovalList;
    get(orderApprovalCode: string): Observable<OrderApproval | undefined>;
    /**
     * Emits true if a request is currently fetching order approval data from
     * the server.
     *
     * @param orderApprovalCode The approval code for which we want the loading status.
     */
    getOrderApprovalLoading(orderApprovalCode: string): Observable<boolean>;
    getList(params: SearchConfig): Observable<EntitiesModel<OrderApproval> | undefined>;
    makeDecision(orderApprovalCode: string, orderApprovalDecision: OrderApprovalDecision): void;
    /**
     * Returns the makeDecision loading flag.  Returns true when the process triggered
     * by makeDecision() is currently running.
     */
    getMakeDecisionResultLoading(): Observable<boolean>;
    /**
     * Returns the makeDecision failure outcome.  Returns true when the outcome
     * of makeDecision() was an error.
     */
    getMakeDecisionResultError(): Observable<boolean>;
    /**
     * Returns the makeDecision process success outcome.  Returns true when the outcome
     * of makeDecision() was a success.
     */
    getMakeDecisionResultSuccess(): Observable<boolean>;
    /**
     * Resets the makeDecision process state. It is usually preferable to reset the
     * process state before making a call to makeDecision() for which we then want
     * to monitor the loading state or the outcome.
     */
    resetMakeDecisionProcessState(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderApprovalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderApprovalService>;
}

declare class OrderApprovalDetailService {
    protected routingService: RoutingService;
    protected orderApprovalService: OrderApprovalService;
    protected approvalCode$: Observable<any>;
    protected orderApproval$: Observable<OrderApproval | undefined>;
    protected order$: Observable<Order>;
    constructor(routingService: RoutingService, orderApprovalService: OrderApprovalService);
    /**
     * Returns a string that represents the approval code
     * found in the page url.
     */
    getOrderApprovalCodeFromRoute(): Observable<string>;
    /**
     * Returns the order data from the approval details that have been
     * retrieved from the approval code in the page url.
     */
    getOrderDetails(): Observable<Order>;
    /**
     * Returns the approval details that have been retrieved from the
     * approval code in the page url.
     */
    getOrderApproval(): Observable<OrderApproval | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderApprovalDetailService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderApprovalDetailService>;
}

declare class OrderApprovalDetailFormComponent implements OnDestroy {
    protected orderApprovalDetailService: OrderApprovalDetailService;
    protected orderApprovalService: OrderApprovalService;
    private fb;
    approvalDecisionValue: typeof OrderApprovalDecisionValue;
    approvalDecision: OrderApprovalDecisionValue;
    approvalFormVisible: boolean;
    approvalForm: UntypedFormGroup;
    protected orderApprovalLoading$: Observable<boolean>;
    protected decisionResultLoading$: Observable<boolean>;
    loading$: Observable<boolean>;
    orderApproval$: Observable<OrderApproval | undefined>;
    constructor(orderApprovalDetailService: OrderApprovalDetailService, orderApprovalService: OrderApprovalService, fb: UntypedFormBuilder);
    displayDecisionForm(decision: OrderApprovalDecisionValue): void;
    cancelDecisionForm(): void;
    submitDecision(orderApproval: OrderApproval): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderApprovalDetailFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderApprovalDetailFormComponent, "cx-order-approval-detail-form", never, {}, {}, never, never, true, never>;
}

declare class OrderDetailPermissionResultsComponent {
    protected orderDetailsService: OrderDetailsService;
    order$: Observable<Order>;
    constructor(orderDetailsService: OrderDetailsService);
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDetailPermissionResultsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderDetailPermissionResultsComponent, "cx-order-detail-permission-results", never, {}, {}, never, never, true, never>;
}

declare class OrderApprovalDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderApprovalDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderApprovalDetailsModule, never, [typeof i1.ReactiveFormsModule, typeof i1$1.CommonModule, typeof i3.I18nModule, typeof i3.UrlModule, typeof i4.FormErrorsModule, typeof i4.SpinnerModule, typeof i5.RouterModule, typeof i4.BtnLikeLinkModule, typeof i3.ConfigModule, typeof i3.FeaturesConfigModule, typeof OrderApprovalDetailFormComponent, typeof OrderDetailPermissionResultsComponent], [typeof OrderApprovalDetailFormComponent, typeof OrderDetailPermissionResultsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderApprovalDetailsModule>;
}

declare class OrderApprovalListComponent implements OnInit {
    protected routing: RoutingService;
    protected orderApprovalService: OrderApprovalService;
    protected translation: TranslationService;
    constructor(routing: RoutingService, orderApprovalService: OrderApprovalService, translation: TranslationService);
    sortLabels$: Observable<{
        byDate: string;
        byOrderNumber: string;
    }>;
    protected PAGE_SIZE: number;
    sortType: string;
    orderApprovals$: Observable<EntitiesModel<OrderApproval> | undefined>;
    ngOnInit(): void;
    changeSortCode(sortCode: string): void;
    pageChange(page: number): void;
    protected fetchApprovalListPage(searchConfig: SearchConfig): void;
    goToApprovalDetails(event: any, orderApproval: OrderApproval): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderApprovalListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderApprovalListComponent, "cx-order-approval-list", never, {}, {}, never, never, true, never>;
}

declare class OrderApprovalListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderApprovalListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderApprovalListModule, never, [typeof i1$1.CommonModule, typeof i3.ConfigModule, typeof i3.UrlModule, typeof i5.RouterModule, typeof i4.ListNavigationModule, typeof i3.I18nModule, typeof i3.FeaturesConfigModule, typeof OrderApprovalListComponent], [typeof OrderApprovalListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderApprovalListModule>;
}

declare class OrderApprovalComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderApprovalComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderApprovalComponentsModule, never, [typeof i5.RouterModule, typeof OrderApprovalListModule, typeof OrderApprovalDetailsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderApprovalComponentsModule>;
}

declare abstract class OrderApprovalAdapter {
    /**
     * Abstract method used to load orderApprovalManagement's details data.
     * OrderApproval's data can be loaded from alternative sources, as long as the structure
     * converts to the `OrderApproval`.
     *
     * @param userId The `userId` for given orderApprovalManagement
     * @param orderApprovalCode The `orderApprovalCode` for given orderApprovalManagement
     */
    abstract load(userId: string, orderApprovalCode: string): Observable<OrderApproval>;
    abstract loadList(userId: string, params?: SearchConfig): Observable<EntitiesModel<OrderApproval>>;
    abstract makeDecision(userId: string, orderApprovalCode: string, orderApprovalDecision: OrderApprovalDecision): Observable<OrderApprovalDecision>;
}

declare class OrderApprovalConnector {
    protected adapter: OrderApprovalAdapter;
    constructor(adapter: OrderApprovalAdapter);
    get(userId: string, orderApprovalCode: string): Observable<OrderApproval>;
    getList(userId: string, params?: SearchConfig): Observable<EntitiesModel<OrderApproval>>;
    makeDecision(userId: string, orderApprovalCode: string, orderApprovalDecision: OrderApprovalDecision): Observable<OrderApprovalDecision>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderApprovalConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderApprovalConnector>;
}

declare const ORDER_APPROVAL_NORMALIZER: InjectionToken<Converter<any, OrderApproval>>;
declare const ORDER_APPROVALS_NORMALIZER: InjectionToken<Converter<any, EntitiesModel<OrderApproval>>>;
declare const ORDER_APPROVAL_DECISION_NORMALIZER: InjectionToken<Converter<any, OrderApprovalDecision>>;

declare class ApproverGuard {
    protected userAccountFacade: UserAccountFacade;
    protected routingService: RoutingService;
    protected globalMessageService: GlobalMessageService;
    constructor(userAccountFacade: UserAccountFacade, routingService: RoutingService, globalMessageService: GlobalMessageService);
    canActivate(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApproverGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ApproverGuard>;
}

declare module '@spartacus/order/root' {
    interface Order {
        permissionResults?: OrderApprovalPermissionResult[];
    }
}

declare const LOAD_ORDER_APPROVAL = "[OrderApproval] Load OrderApproval Data";
declare const LOAD_ORDER_APPROVAL_FAIL = "[OrderApproval] Load OrderApproval Data Fail";
declare const LOAD_ORDER_APPROVAL_SUCCESS = "[OrderApproval] Load OrderApproval Data Success";
declare const LOAD_ORDER_APPROVALS = "[OrderApproval] Load OrderApprovals";
declare const LOAD_ORDER_APPROVALS_FAIL = "[OrderApproval] Load OrderApprovals Fail";
declare const LOAD_ORDER_APPROVALS_SUCCESS = "[OrderApproval] Load OrderApprovals Success";
declare const MAKE_DECISION = "[OrderApproval] Make OrderApproval Decision";
declare const MAKE_DECISION_FAIL = "[OrderApproval] Make OrderApproval Decision Fail";
declare const MAKE_DECISION_SUCCESS = "[OrderApproval] Make OrderApproval Decision Success";
declare const MAKE_DECISION_RESET = "[OrderApproval] Make OrderApproval Decision Reset";
declare class LoadOrderApproval extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orderApprovalCode: string;
    };
    readonly type = "[OrderApproval] Load OrderApproval Data";
    constructor(payload: {
        userId: string;
        orderApprovalCode: string;
    });
}
declare class LoadOrderApprovalFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orderApprovalCode: string;
        error: any;
    };
    readonly type = "[OrderApproval] Load OrderApproval Data Fail";
    constructor(payload: {
        orderApprovalCode: string;
        error: any;
    });
}
declare class LoadOrderApprovalSuccess extends StateUtils.EntitySuccessAction {
    payload: OrderApproval | OrderApproval[];
    readonly type = "[OrderApproval] Load OrderApproval Data Success";
    constructor(payload: OrderApproval | OrderApproval[]);
}
declare class LoadOrderApprovals extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        params: SearchConfig;
    };
    readonly type = "[OrderApproval] Load OrderApprovals";
    constructor(payload: {
        userId: string;
        params: SearchConfig;
    });
}
declare class LoadOrderApprovalsFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        params: SearchConfig;
        error: any;
    };
    readonly type = "[OrderApproval] Load OrderApprovals Fail";
    constructor(payload: {
        params: SearchConfig;
        error: any;
    });
}
declare class LoadOrderApprovalsSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        page: ListModel;
        params: SearchConfig;
    };
    readonly type = "[OrderApproval] Load OrderApprovals Success";
    constructor(payload: {
        page: ListModel;
        params: SearchConfig;
    });
}
declare class MakeDecision extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orderApprovalCode: string;
        orderApprovalDecision: OrderApprovalDecision;
    };
    readonly type = "[OrderApproval] Make OrderApproval Decision";
    constructor(payload: {
        userId: string;
        orderApprovalCode: string;
        orderApprovalDecision: OrderApprovalDecision;
    });
}
declare class MakeDecisionFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orderApprovalCode: string;
        error: any;
    };
    readonly type = "[OrderApproval] Make OrderApproval Decision Fail";
    constructor(payload: {
        orderApprovalCode: string;
        error: any;
    });
}
declare class MakeDecisionSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        orderApprovalCode: string;
        orderApprovalDecision: OrderApprovalDecision;
    };
    readonly type = "[OrderApproval] Make OrderApproval Decision Success";
    constructor(payload: {
        orderApprovalCode: string;
        orderApprovalDecision: OrderApprovalDecision;
    });
}
declare class MakeDecisionReset extends StateUtils.EntityLoaderResetAction {
    readonly type = "[OrderApproval] Make OrderApproval Decision Reset";
    constructor();
}
type OrderApprovalAction = LoadOrderApproval | LoadOrderApprovalFail | LoadOrderApprovalSuccess | LoadOrderApprovals | LoadOrderApprovalsFail | LoadOrderApprovalsSuccess | MakeDecision | MakeDecisionFail | MakeDecisionSuccess | MakeDecisionReset;

declare const orderApproval_action_d_LOAD_ORDER_APPROVAL: typeof LOAD_ORDER_APPROVAL;
declare const orderApproval_action_d_LOAD_ORDER_APPROVALS: typeof LOAD_ORDER_APPROVALS;
declare const orderApproval_action_d_LOAD_ORDER_APPROVALS_FAIL: typeof LOAD_ORDER_APPROVALS_FAIL;
declare const orderApproval_action_d_LOAD_ORDER_APPROVALS_SUCCESS: typeof LOAD_ORDER_APPROVALS_SUCCESS;
declare const orderApproval_action_d_LOAD_ORDER_APPROVAL_FAIL: typeof LOAD_ORDER_APPROVAL_FAIL;
declare const orderApproval_action_d_LOAD_ORDER_APPROVAL_SUCCESS: typeof LOAD_ORDER_APPROVAL_SUCCESS;
type orderApproval_action_d_LoadOrderApproval = LoadOrderApproval;
declare const orderApproval_action_d_LoadOrderApproval: typeof LoadOrderApproval;
type orderApproval_action_d_LoadOrderApprovalFail = LoadOrderApprovalFail;
declare const orderApproval_action_d_LoadOrderApprovalFail: typeof LoadOrderApprovalFail;
type orderApproval_action_d_LoadOrderApprovalSuccess = LoadOrderApprovalSuccess;
declare const orderApproval_action_d_LoadOrderApprovalSuccess: typeof LoadOrderApprovalSuccess;
type orderApproval_action_d_LoadOrderApprovals = LoadOrderApprovals;
declare const orderApproval_action_d_LoadOrderApprovals: typeof LoadOrderApprovals;
type orderApproval_action_d_LoadOrderApprovalsFail = LoadOrderApprovalsFail;
declare const orderApproval_action_d_LoadOrderApprovalsFail: typeof LoadOrderApprovalsFail;
type orderApproval_action_d_LoadOrderApprovalsSuccess = LoadOrderApprovalsSuccess;
declare const orderApproval_action_d_LoadOrderApprovalsSuccess: typeof LoadOrderApprovalsSuccess;
declare const orderApproval_action_d_MAKE_DECISION: typeof MAKE_DECISION;
declare const orderApproval_action_d_MAKE_DECISION_FAIL: typeof MAKE_DECISION_FAIL;
declare const orderApproval_action_d_MAKE_DECISION_RESET: typeof MAKE_DECISION_RESET;
declare const orderApproval_action_d_MAKE_DECISION_SUCCESS: typeof MAKE_DECISION_SUCCESS;
type orderApproval_action_d_MakeDecision = MakeDecision;
declare const orderApproval_action_d_MakeDecision: typeof MakeDecision;
type orderApproval_action_d_MakeDecisionFail = MakeDecisionFail;
declare const orderApproval_action_d_MakeDecisionFail: typeof MakeDecisionFail;
type orderApproval_action_d_MakeDecisionReset = MakeDecisionReset;
declare const orderApproval_action_d_MakeDecisionReset: typeof MakeDecisionReset;
type orderApproval_action_d_MakeDecisionSuccess = MakeDecisionSuccess;
declare const orderApproval_action_d_MakeDecisionSuccess: typeof MakeDecisionSuccess;
type orderApproval_action_d_OrderApprovalAction = OrderApprovalAction;
declare namespace orderApproval_action_d {
  export { orderApproval_action_d_LOAD_ORDER_APPROVAL as LOAD_ORDER_APPROVAL, orderApproval_action_d_LOAD_ORDER_APPROVALS as LOAD_ORDER_APPROVALS, orderApproval_action_d_LOAD_ORDER_APPROVALS_FAIL as LOAD_ORDER_APPROVALS_FAIL, orderApproval_action_d_LOAD_ORDER_APPROVALS_SUCCESS as LOAD_ORDER_APPROVALS_SUCCESS, orderApproval_action_d_LOAD_ORDER_APPROVAL_FAIL as LOAD_ORDER_APPROVAL_FAIL, orderApproval_action_d_LOAD_ORDER_APPROVAL_SUCCESS as LOAD_ORDER_APPROVAL_SUCCESS, orderApproval_action_d_LoadOrderApproval as LoadOrderApproval, orderApproval_action_d_LoadOrderApprovalFail as LoadOrderApprovalFail, orderApproval_action_d_LoadOrderApprovalSuccess as LoadOrderApprovalSuccess, orderApproval_action_d_LoadOrderApprovals as LoadOrderApprovals, orderApproval_action_d_LoadOrderApprovalsFail as LoadOrderApprovalsFail, orderApproval_action_d_LoadOrderApprovalsSuccess as LoadOrderApprovalsSuccess, orderApproval_action_d_MAKE_DECISION as MAKE_DECISION, orderApproval_action_d_MAKE_DECISION_FAIL as MAKE_DECISION_FAIL, orderApproval_action_d_MAKE_DECISION_RESET as MAKE_DECISION_RESET, orderApproval_action_d_MAKE_DECISION_SUCCESS as MAKE_DECISION_SUCCESS, orderApproval_action_d_MakeDecision as MakeDecision, orderApproval_action_d_MakeDecisionFail as MakeDecisionFail, orderApproval_action_d_MakeDecisionReset as MakeDecisionReset, orderApproval_action_d_MakeDecisionSuccess as MakeDecisionSuccess };
  export type { orderApproval_action_d_OrderApprovalAction as OrderApprovalAction };
}

declare const getOrderApprovalState: MemoizedSelector<OrderApprovalState, OrderApprovalState>;
declare const getOrderApprovalManagementState: MemoizedSelector<OrderApprovalState, OrderApprovalManagement>;
declare const getOrderApprovalsState: MemoizedSelector<OrderApprovalState, StateUtils.EntityLoaderState<OrderApproval>>;
declare const getOrderApproval: (orderApprovalCode: string) => MemoizedSelector<OrderApprovalState, StateUtils.LoaderState<OrderApproval>>;
declare const getOrderApprovalList: (params: SearchConfig) => MemoizedSelector<OrderApprovalState, StateUtils.LoaderState<EntitiesModel<OrderApproval>>>;

declare const orderApproval_selector_d_getOrderApproval: typeof getOrderApproval;
declare const orderApproval_selector_d_getOrderApprovalList: typeof getOrderApprovalList;
declare const orderApproval_selector_d_getOrderApprovalManagementState: typeof getOrderApprovalManagementState;
declare const orderApproval_selector_d_getOrderApprovalState: typeof getOrderApprovalState;
declare const orderApproval_selector_d_getOrderApprovalsState: typeof getOrderApprovalsState;
declare namespace orderApproval_selector_d {
  export {
    orderApproval_selector_d_getOrderApproval as getOrderApproval,
    orderApproval_selector_d_getOrderApprovalList as getOrderApprovalList,
    orderApproval_selector_d_getOrderApprovalManagementState as getOrderApprovalManagementState,
    orderApproval_selector_d_getOrderApprovalState as getOrderApprovalState,
    orderApproval_selector_d_getOrderApprovalsState as getOrderApprovalsState,
  };
}

declare class OccOrderApprovalAdapter implements OrderApprovalAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    load(userId: string, orderApprovalCode: string): Observable<OrderApproval>;
    loadList(userId: string, params?: SearchConfig): Observable<EntitiesModel<OrderApproval>>;
    makeDecision(userId: string, orderApprovalCode: string, orderApprovalDecision: OrderApprovalDecision): Observable<OrderApprovalDecision>;
    protected getOrderApprovalEndpoint(userId: string, orderApprovalCode: string): string;
    protected getOrderApprovalsEndpoint(userId: string, params?: SearchConfig): string;
    protected getOrderApprovalDecisionEndpoint(userId: string, orderApprovalCode: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOrderApprovalAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOrderApprovalAdapter>;
}

declare class OccOrderApprovalDecisionNormalizer implements Converter<Occ.OrderApprovalDecision, OrderApprovalDecision> {
    constructor();
    convert(source: Occ.OrderApprovalDecision, target?: OrderApprovalDecision): OrderApprovalDecision;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOrderApprovalDecisionNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOrderApprovalDecisionNormalizer>;
}

declare class OccOrderApprovalListNormalizer implements Converter<Occ.OrderApprovalsList, EntitiesModel<OrderApproval>> {
    private converter;
    constructor(converter: ConverterService);
    convert(source: Occ.OrderApprovalsList, target?: EntitiesModel<OrderApproval>): EntitiesModel<OrderApproval>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOrderApprovalListNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOrderApprovalListNormalizer>;
}

declare class OccOrderApprovalNormalizer implements Converter<Occ.OrderApproval, OrderApproval> {
    private converter;
    constructor(converter: ConverterService);
    convert(source: Occ.OrderApproval, target?: OrderApproval): OrderApproval;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOrderApprovalNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOrderApprovalNormalizer>;
}

declare module '@spartacus/core' {
    interface OccEndpoints {
        /**
         * Endpoint for order approvals
         *
         * @member {string}
         */
        orderApprovals?: string | OccEndpoint;
        /**
         * Endpoint for order approval
         *
         * @member {string}
         */
        orderApproval?: string | OccEndpoint;
        /**
         * Endpoint for order approval decision
         *
         * @member {string}
         */
        orderApprovalDecision?: string | OccEndpoint;
    }
}

declare class OrderApprovalOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderApprovalOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderApprovalOccModule, never, [typeof i1$1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderApprovalOccModule>;
}

declare class OrderApprovalStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderApprovalStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderApprovalStoreModule, never, [typeof i1$2.StoreFeatureModule, typeof i2.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderApprovalStoreModule>;
}

declare class OrderApprovalCoreModule {
    static forRoot(): ModuleWithProviders<OrderApprovalCoreModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderApprovalCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderApprovalCoreModule, never, [typeof OrderApprovalStoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderApprovalCoreModule>;
}

declare class OrderApprovalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderApprovalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderApprovalModule, never, [typeof OrderApprovalCoreModule, typeof OrderApprovalOccModule, typeof OrderApprovalComponentsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderApprovalModule>;
}

export { ApproverGuard, ORDER_APPROVALS_NORMALIZER, ORDER_APPROVAL_DECISION_NORMALIZER, ORDER_APPROVAL_ENTITIES, ORDER_APPROVAL_FEATURE, ORDER_APPROVAL_LIST, ORDER_APPROVAL_MAKE_DECISION_PROCESS_ID, ORDER_APPROVAL_NORMALIZER, OccOrderApprovalAdapter, OccOrderApprovalDecisionNormalizer, OccOrderApprovalListNormalizer, OccOrderApprovalNormalizer, orderApproval_action_d as OrderApprovalActions, OrderApprovalAdapter, OrderApprovalComponentsModule, OrderApprovalConnector, OrderApprovalDecisionValue, OrderApprovalDetailFormComponent, OrderApprovalDetailService, OrderApprovalDetailsModule, OrderApprovalListComponent, OrderApprovalListModule, OrderApprovalModule, OrderApprovalOccModule, orderApproval_selector_d as OrderApprovalSelectors, OrderApprovalService, OrderDetailPermissionResultsComponent };
export type { OrderApproval, OrderApprovalDecision, OrderApprovalManagement, OrderApprovalPermissionResult, OrderApprovalRecord, OrderApprovalState, OrderApprovalTrigger };
