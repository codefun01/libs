import * as i0 from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { OccEndpointsService, ConverterService, LoggerService, OccEndpoint } from '@spartacus/core';
import { AccountSummaryAdapter } from '@spartacus/organization/account-summary/core';
import { AccountSummaryDetails, DocumentQueryParams, AccountSummaryList } from '@spartacus/organization/account-summary/root';
import { Observable } from 'rxjs';

declare class AccountSummaryOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AccountSummaryOccModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AccountSummaryOccModule>;
}

declare class OccAccountSummaryAdapter implements AccountSummaryAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    getAccountSummary(userId: string, orgUnitId: string): Observable<AccountSummaryDetails>;
    getDocumentList(userId: string, orgUnitId: string, params: DocumentQueryParams): Observable<AccountSummaryList>;
    getDocumentAttachment(userId: string, orgUnitId: string, orgDocumentId: string, orgDocumentAttachmentId: string): Observable<Blob>;
    private buildAccountSummaryUrl;
    private buildDocumentListUrl;
    private buildDocumentAttachmentUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccAccountSummaryAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccAccountSummaryAdapter>;
}

interface AccountSummaryOccEndpoints {
    /**
     * Get Account summary header details
     *
     * @member {string} [accountSummary]
     */
    accountSummary?: string | OccEndpoint;
    /**
     * Get Account summary documents
     *
     * @member {string} [accountSummaryDocument]
     */
    accountSummaryDocument?: string | OccEndpoint;
    /**
     * Get Account summary document attachment
     *
     * @member {string} [accountSummaryDocumentAttachment]
     */
    accountSummaryDocumentAttachment?: string | OccEndpoint;
}
declare module '@spartacus/core' {
    interface OccEndpoints extends AccountSummaryOccEndpoints {
    }
}

export { AccountSummaryOccModule, OccAccountSummaryAdapter };
export type { AccountSummaryOccEndpoints };
