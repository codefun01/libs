import * as i0 from '@angular/core';
import * as i1 from '@spartacus/organization/user-registration/core';
import * as i2 from '@spartacus/organization/user-registration/components';
import * as i3 from '@spartacus/organization/user-registration/occ';

declare class OrganizationUserRegistrationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrganizationUserRegistrationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrganizationUserRegistrationModule, never, [typeof i1.UserRegistrationCoreModule, typeof i2.UserRegistrationComponentsModule, typeof i3.UserRegistrationOccModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrganizationUserRegistrationModule>;
}

export { OrganizationUserRegistrationModule };
