import * as i0 from '@angular/core';
import * as i1 from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { OccEndpointsService, ConverterService, LoggerService, OccEndpoint } from '@spartacus/core';
import { UserRegistrationAdapter } from '@spartacus/organization/user-registration/core';
import { OrganizationUserRegistration } from '@spartacus/organization/user-registration/root';
import { Observable } from 'rxjs';

declare class UserRegistrationOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserRegistrationOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserRegistrationOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserRegistrationOccModule>;
}

declare class OccUserRegistrationAdapter implements UserRegistrationAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    registerUser(userData: OrganizationUserRegistration): Observable<OrganizationUserRegistration>;
    protected getOrganizationUserRegistrationEndpoint(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccUserRegistrationAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccUserRegistrationAdapter>;
}

declare module '@spartacus/core' {
    interface OccEndpoints {
        /**
         * Endpoint for organization user registration
         *
         * @member {string}
         */
        organizationUserRegistration?: string | OccEndpoint;
    }
}

export { OccUserRegistrationAdapter, UserRegistrationOccModule };
