import { CmsConfig, RoutingConfig, Address, B2BUnit, Currency, PaginationModel, SortModel, WindowRef } from '@spartacus/core';
import * as i0 from '@angular/core';
import * as i1 from '@angular/router';
import { Observable } from 'rxjs';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { FileReaderService } from '@spartacus/storefront';

declare function defaultAccountSummaryComponentsConfig(): CmsConfig;
declare class AccountSummaryRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AccountSummaryRootModule, never, [typeof i1.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AccountSummaryRootModule>;
}

declare const defaultAccountSummaryRoutingConfig: RoutingConfig;

interface OrgDocumentAttachment {
    id?: string;
}
interface OrgDocumentType {
    code?: string;
    name?: string;
    payableOrUsable?: string;
}
interface AmountBalance {
    currentBalance?: string;
    dueBalances?: DueBalanceRange[];
    openBalance?: string;
    pastDueBalance?: string;
}
interface DueBalanceRange {
    amount?: string;
    dayRange?: NumberOfDayRange;
}
interface NumberOfDayRange {
    minBoundary?: number;
    maxBoundary?: number;
}
declare enum DocumentStatus {
    ALL = "all",
    OPEN = "open",
    CLOSED = "closed"
}
declare enum DocumentFields {
    BASIC = "BASIC",
    DEFAULT = "DEFAULT",
    FULL = "FULL"
}
declare enum FilterByOptions {
    DOCUMENT_NUMBER = "orgDocumentId",
    DOCUMENT_NUMBER_RANGE = "orgDocumentIdRange",
    DOCUMENT_TYPE = "orgDocumentType",
    DATE_RANGE = "createdAtDateRange",
    DUE_DATE_RANGE = "dueAtDateRange",
    AMOUNT_RANGE = "amountRange",
    OPEN_AMOUNT_RANGE = "openAmountRange"
}
interface AccountSummaryDetails {
    accountManagerEmail?: string;
    accountManagerName?: string;
    amountBalance?: AmountBalance;
    billingAddress?: Address;
    creditLimit?: string;
    orgUnit?: B2BUnit;
}
interface AccountSummaryDocument {
    id?: string;
    orgDocumentType?: OrgDocumentType;
    status?: DocumentStatus;
    createdAtDate?: string;
    dueAtDate?: string;
    formattedAmount?: string;
    amount?: number;
    formattedOpenAmount?: string;
    openAmount?: number;
    currency?: Currency;
    attachments?: OrgDocumentAttachment[];
}
interface AccountSummaryDocumentType {
    code?: string;
    displayInAllList?: boolean;
    includeInOpenBalance?: boolean;
    name?: string;
}
interface AccountSummaryList {
    orgDocumentTypes?: AccountSummaryDocumentType[];
    orgDocuments?: AccountSummaryDocument[];
    pagination?: PaginationModel;
    sorts?: SortModel[];
}
interface DocumentQueryParams {
    page?: number;
    pageSize?: number;
    sort?: string;
    fields?: DocumentFields;
    status?: DocumentStatus;
    startRange?: string;
    endRange?: string;
    filterByKey?: FilterByOptions;
    filterByValue?: string;
}

declare abstract class AccountSummaryFacade {
    /**
     * Returns the account summary header details for a orgUnit and current logged in user
     * @param orgUnitId If provided, it will be used, otherwise it will use orgUnitId from router state.
     */
    abstract getAccountSummary(orgUnitId?: string): Observable<AccountSummaryDetails>;
    /**
     * Returns the result of account summary documents search
     * @param params Search parameters
     * @param orgUnitId If provided, it will be used, otherwise it will use orgUnitId from router state.
     */
    abstract getDocumentList(params: DocumentQueryParams, orgUnitId?: string): Observable<AccountSummaryList>;
    /**
     * Returns the document blob for given orgDocumentId and orgDocumentAttachmentId
     * @param orgDocumentId organization document id
     * @param orgDocumentAttachmentId attachment id belonging to a organization document id
     * @param orgUnitId If provided, it will be used, otherwise it will use orgUnitId from router state.
     */
    abstract getDocumentAttachment(orgDocumentId?: string, orgDocumentAttachmentId?: string, orgUnitId?: string): Observable<Blob>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AccountSummaryFacade>;
}

declare const ORGANIZATION_ACCOUNT_SUMMARY_FEATURE = "organizationAccountSummary";
declare const ORGANIZATION_ACCOUNT_SUMMARY_CORE_FEATURE = "organizationAccountSummaryCore";

declare class BlobErrorInterceptor implements HttpInterceptor {
    protected readonly fileReaderService: FileReaderService;
    protected readonly windowRef: WindowRef;
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BlobErrorInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BlobErrorInterceptor>;
}

export { AccountSummaryFacade, AccountSummaryRootModule, BlobErrorInterceptor, DocumentFields, DocumentStatus, FilterByOptions, ORGANIZATION_ACCOUNT_SUMMARY_CORE_FEATURE, ORGANIZATION_ACCOUNT_SUMMARY_FEATURE, defaultAccountSummaryComponentsConfig, defaultAccountSummaryRoutingConfig };
export type { AccountSummaryDetails, AccountSummaryDocument, AccountSummaryDocumentType, AccountSummaryList, DocumentQueryParams, OrgDocumentType };
