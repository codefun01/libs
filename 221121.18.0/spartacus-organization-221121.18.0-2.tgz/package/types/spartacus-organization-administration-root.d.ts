import { CmsConfig, RoutingConfig } from '@spartacus/core';
import * as i0 from '@angular/core';
import { LayoutConfig } from '@spartacus/storefront';

declare function defaultOrganizationAdministrationComponentsConfig(): CmsConfig;
declare class AdministrationRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AdministrationRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AdministrationRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AdministrationRootModule>;
}

declare const defaultBudgetRoutingConfig: RoutingConfig;

declare const defaultCostCenterRoutingConfig: RoutingConfig;

declare const defaultOrganizationLayoutConfig: LayoutConfig;

/**
 * Configuration for Organization UI features.
 */
declare abstract class OrganizationUIConfig {
    organizationUI?: {
        /**
         * Configuration for list search functionality.
         */
        listSearch?: {
            /**
             * Minimum number of characters required to trigger a search.
             * Default: 3
             */
            minCharacters?: number;
        };
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<OrganizationUIConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrganizationUIConfig>;
}
declare module '@spartacus/core' {
    interface Config extends OrganizationUIConfig {
    }
}

declare const defaultOrganizationUIConfig: OrganizationUIConfig;

declare const defaultPermissionRoutingConfig: RoutingConfig;

declare const defaultUnitsRoutingConfig: RoutingConfig;

declare const defaultUserGroupRoutingConfig: RoutingConfig;

declare const defaultUserRoutingConfig: RoutingConfig;

declare const ORGANIZATION_ADMINISTRATION_FEATURE = "organizationAdministration";

/**
 * Names of the route params used in the organization administration feature
 */
declare const ROUTE_PARAMS: {
    budgetCode: string;
    unitCode: string;
    costCenterCode: string;
    userCode: string;
    userGroupCode: string;
    permissionCode: string;
    addressCode: string;
};

export { AdministrationRootModule, ORGANIZATION_ADMINISTRATION_FEATURE, OrganizationUIConfig, ROUTE_PARAMS, defaultBudgetRoutingConfig, defaultCostCenterRoutingConfig, defaultOrganizationAdministrationComponentsConfig, defaultOrganizationLayoutConfig, defaultOrganizationUIConfig, defaultPermissionRoutingConfig, defaultUnitsRoutingConfig, defaultUserGroupRoutingConfig, defaultUserRoutingConfig };
