import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    unitOrder: {
        unitLevelOrderHistory: {
            orderHistory: string;
            orderId: string;
            emptyPurchaseOrderId: string;
            date: string;
            status: string;
            buyer: string;
            unit: string;
            total: string;
            noOrders: string;
            startShopping: string;
            sortBy: string;
            sortOrders: string;
            purchaseOrderNumber: string;
            startOn: string;
            frequency: string;
            nextOrderDate: string;
            notFound: string;
            applyFilter: string;
            filterBy: string;
            filterByBuyer: string;
            filterByBuyerLabel: string;
            filterByBuyerPlaceholder: string;
            filterByBuyerAriaLabel: string;
            filterByUnit: string;
            filterByUnitLabel: string;
            filterByUnitPlaceholder: string;
            filterByUnitAriaLabel: string;
            search: string;
            clearAll: string;
            removeAppliedFilters: string;
            yourFilters: string;
            and: string;
        };
        unitLevelOrderHistorySorting: {
            date: string;
            orderNumber: string;
            buyer: string;
            buyerDesc: string;
            orgUnit: string;
            orgUnitDesc: string;
        };
        unitLevelOrderDetails: {
            buyer: string;
        };
    };
};

declare const de: {
    unitOrder: {
        unitLevelOrderHistory: {
            orderHistory: string;
            orderId: string;
            emptyPurchaseOrderId: string;
            date: string;
            status: string;
            buyer: string;
            unit: string;
            total: string;
            noOrders: string;
            startShopping: string;
            sortBy: string;
            sortOrders: string;
            purchaseOrderNumber: string;
            startOn: string;
            frequency: string;
            nextOrderDate: string;
            notFound: string;
            applyFilter: string;
            filterBy: string;
            filterByBuyer: string;
            filterByBuyerLabel: string;
            filterByBuyerPlaceholder: string;
            filterByBuyerAriaLabel: string;
            filterByUnit: string;
            filterByUnitLabel: string;
            filterByUnitPlaceholder: string;
            filterByUnitAriaLabel: string;
            search: string;
            clearAll: string;
            removeAppliedFilters: string;
            yourFilters: string;
            and: string;
        };
        unitLevelOrderHistorySorting: {
            date: string;
            orderNumber: string;
            buyer: string;
            buyerDesc: string;
            orgUnit: string;
            orgUnitDesc: string;
        };
        unitLevelOrderDetails: {
            buyer: string;
        };
    };
};

declare const en: {
    unitOrder: {
        unitLevelOrderHistory: {
            orderHistory: string;
            orderId: string;
            emptyPurchaseOrderId: string;
            date: string;
            status: string;
            buyer: string;
            unit: string;
            total: string;
            noOrders: string;
            startShopping: string;
            sortBy: string;
            sortOrders: string;
            purchaseOrderNumber: string;
            startOn: string;
            frequency: string;
            nextOrderDate: string;
            notFound: string;
            applyFilter: string;
            filterBy: string;
            filterByBuyer: string;
            filterByBuyerLabel: string;
            filterByBuyerPlaceholder: string;
            filterByBuyerAriaLabel: string;
            filterByUnit: string;
            filterByUnitLabel: string;
            filterByUnitPlaceholder: string;
            filterByUnitAriaLabel: string;
            search: string;
            searchByNameBuyer: string;
            searchByNameUnit: string;
            clearAll: string;
            removeAppliedFilters: string;
            yourFilters: string;
            and: string;
        };
        unitLevelOrderHistorySorting: {
            date: string;
            orderNumber: string;
            buyer: string;
            buyerDesc: string;
            orgUnit: string;
            orgUnitDesc: string;
        };
        unitLevelOrderDetails: {
            buyer: string;
        };
    };
};

declare const es: {
    unitOrder: {
        unitLevelOrderHistory: {
            orderHistory: string;
            orderId: string;
            emptyPurchaseOrderId: string;
            date: string;
            status: string;
            buyer: string;
            unit: string;
            total: string;
            noOrders: string;
            startShopping: string;
            sortBy: string;
            sortOrders: string;
            purchaseOrderNumber: string;
            startOn: string;
            frequency: string;
            nextOrderDate: string;
            notFound: string;
            applyFilter: string;
            filterBy: string;
            filterByBuyer: string;
            filterByBuyerLabel: string;
            filterByBuyerPlaceholder: string;
            filterByBuyerAriaLabel: string;
            filterByUnit: string;
            filterByUnitLabel: string;
            filterByUnitPlaceholder: string;
            filterByUnitAriaLabel: string;
            search: string;
            clearAll: string;
            removeAppliedFilters: string;
            yourFilters: string;
            and: string;
        };
        unitLevelOrderHistorySorting: {
            date: string;
            orderNumber: string;
            buyer: string;
            buyerDesc: string;
            orgUnit: string;
            orgUnitDesc: string;
        };
        unitLevelOrderDetails: {
            buyer: string;
        };
    };
};

declare const es_CO: {
    unitOrder: {
        unitLevelOrderHistory: {
            orderHistory: string;
            orderId: string;
            emptyPurchaseOrderId: string;
            date: string;
            status: string;
            buyer: string;
            unit: string;
            total: string;
            noOrders: string;
            startShopping: string;
            sortBy: string;
            sortOrders: string;
            purchaseOrderNumber: string;
            startOn: string;
            frequency: string;
            nextOrderDate: string;
            notFound: string;
            applyFilter: string;
            filterBy: string;
            filterByBuyer: string;
            filterByBuyerLabel: string;
            filterByBuyerPlaceholder: string;
            filterByBuyerAriaLabel: string;
            filterByUnit: string;
            filterByUnitLabel: string;
            filterByUnitPlaceholder: string;
            filterByUnitAriaLabel: string;
            search: string;
            clearAll: string;
            removeAppliedFilters: string;
            yourFilters: string;
            and: string;
        };
        unitLevelOrderHistorySorting: {
            date: string;
            orderNumber: string;
            buyer: string;
            buyerDesc: string;
            orgUnit: string;
            orgUnitDesc: string;
        };
        unitLevelOrderDetails: {
            buyer: string;
        };
    };
};

declare const fr: {
    unitOrder: {
        unitLevelOrderHistory: {
            orderHistory: string;
            orderId: string;
            emptyPurchaseOrderId: string;
            date: string;
            status: string;
            buyer: string;
            unit: string;
            total: string;
            noOrders: string;
            startShopping: string;
            sortBy: string;
            sortOrders: string;
            purchaseOrderNumber: string;
            startOn: string;
            frequency: string;
            nextOrderDate: string;
            notFound: string;
            applyFilter: string;
            filterBy: string;
            filterByBuyer: string;
            filterByBuyerLabel: string;
            filterByBuyerPlaceholder: string;
            filterByBuyerAriaLabel: string;
            filterByUnit: string;
            filterByUnitLabel: string;
            filterByUnitPlaceholder: string;
            filterByUnitAriaLabel: string;
            search: string;
            clearAll: string;
            removeAppliedFilters: string;
            yourFilters: string;
            and: string;
        };
        unitLevelOrderHistorySorting: {
            date: string;
            orderNumber: string;
            buyer: string;
            buyerDesc: string;
            orgUnit: string;
            orgUnitDesc: string;
        };
        unitLevelOrderDetails: {
            buyer: string;
        };
    };
};

declare const hi: {
    unitOrder: {
        unitLevelOrderHistory: {
            orderHistory: string;
            orderId: string;
            emptyPurchaseOrderId: string;
            date: string;
            status: string;
            buyer: string;
            unit: string;
            total: string;
            noOrders: string;
            startShopping: string;
            sortBy: string;
            sortOrders: string;
            purchaseOrderNumber: string;
            startOn: string;
            frequency: string;
            nextOrderDate: string;
            notFound: string;
            applyFilter: string;
            filterBy: string;
            filterByBuyer: string;
            filterByBuyerLabel: string;
            filterByBuyerPlaceholder: string;
            filterByBuyerAriaLabel: string;
            filterByUnit: string;
            filterByUnitLabel: string;
            filterByUnitPlaceholder: string;
            filterByUnitAriaLabel: string;
            search: string;
            clearAll: string;
            removeAppliedFilters: string;
            yourFilters: string;
            and: string;
        };
        unitLevelOrderHistorySorting: {
            date: string;
            orderNumber: string;
            buyer: string;
            buyerDesc: string;
            orgUnit: string;
            orgUnitDesc: string;
        };
        unitLevelOrderDetails: {
            buyer: string;
        };
    };
};

declare const hu: {
    unitOrder: {
        unitLevelOrderHistory: {
            orderHistory: string;
            orderId: string;
            emptyPurchaseOrderId: string;
            date: string;
            status: string;
            buyer: string;
            unit: string;
            total: string;
            noOrders: string;
            startShopping: string;
            sortBy: string;
            sortOrders: string;
            purchaseOrderNumber: string;
            startOn: string;
            frequency: string;
            nextOrderDate: string;
            notFound: string;
            applyFilter: string;
            filterBy: string;
            filterByBuyer: string;
            filterByBuyerLabel: string;
            filterByBuyerPlaceholder: string;
            filterByBuyerAriaLabel: string;
            filterByUnit: string;
            filterByUnitLabel: string;
            filterByUnitPlaceholder: string;
            filterByUnitAriaLabel: string;
            search: string;
            clearAll: string;
            removeAppliedFilters: string;
            yourFilters: string;
            and: string;
        };
        unitLevelOrderHistorySorting: {
            date: string;
            orderNumber: string;
            buyer: string;
            buyerDesc: string;
            orgUnit: string;
            orgUnitDesc: string;
        };
        unitLevelOrderDetails: {
            buyer: string;
        };
    };
};

declare const id: {
    unitOrder: {
        unitLevelOrderHistory: {
            orderHistory: string;
            orderId: string;
            emptyPurchaseOrderId: string;
            date: string;
            status: string;
            buyer: string;
            unit: string;
            total: string;
            noOrders: string;
            startShopping: string;
            sortBy: string;
            sortOrders: string;
            purchaseOrderNumber: string;
            startOn: string;
            frequency: string;
            nextOrderDate: string;
            notFound: string;
            applyFilter: string;
            filterBy: string;
            filterByBuyer: string;
            filterByBuyerLabel: string;
            filterByBuyerPlaceholder: string;
            filterByBuyerAriaLabel: string;
            filterByUnit: string;
            filterByUnitLabel: string;
            filterByUnitPlaceholder: string;
            filterByUnitAriaLabel: string;
            search: string;
            clearAll: string;
            removeAppliedFilters: string;
            yourFilters: string;
            and: string;
        };
        unitLevelOrderHistorySorting: {
            date: string;
            orderNumber: string;
            buyer: string;
            buyerDesc: string;
            orgUnit: string;
            orgUnitDesc: string;
        };
        unitLevelOrderDetails: {
            buyer: string;
        };
    };
};

declare const it: {
    unitOrder: {
        unitLevelOrderHistory: {
            orderHistory: string;
            orderId: string;
            emptyPurchaseOrderId: string;
            date: string;
            status: string;
            buyer: string;
            unit: string;
            total: string;
            noOrders: string;
            startShopping: string;
            sortBy: string;
            sortOrders: string;
            purchaseOrderNumber: string;
            startOn: string;
            frequency: string;
            nextOrderDate: string;
            notFound: string;
            applyFilter: string;
            filterBy: string;
            filterByBuyer: string;
            filterByBuyerLabel: string;
            filterByBuyerPlaceholder: string;
            filterByBuyerAriaLabel: string;
            filterByUnit: string;
            filterByUnitLabel: string;
            filterByUnitPlaceholder: string;
            filterByUnitAriaLabel: string;
            search: string;
            clearAll: string;
            removeAppliedFilters: string;
            yourFilters: string;
            and: string;
        };
        unitLevelOrderHistorySorting: {
            date: string;
            orderNumber: string;
            buyer: string;
            buyerDesc: string;
            orgUnit: string;
            orgUnitDesc: string;
        };
        unitLevelOrderDetails: {
            buyer: string;
        };
    };
};

declare const ja: {
    unitOrder: {
        unitLevelOrderHistory: {
            orderHistory: string;
            orderId: string;
            emptyPurchaseOrderId: string;
            date: string;
            status: string;
            buyer: string;
            unit: string;
            total: string;
            noOrders: string;
            startShopping: string;
            sortBy: string;
            sortOrders: string;
            purchaseOrderNumber: string;
            startOn: string;
            frequency: string;
            nextOrderDate: string;
            notFound: string;
            applyFilter: string;
            filterBy: string;
            filterByBuyer: string;
            filterByBuyerLabel: string;
            filterByBuyerPlaceholder: string;
            filterByBuyerAriaLabel: string;
            filterByUnit: string;
            filterByUnitLabel: string;
            filterByUnitPlaceholder: string;
            filterByUnitAriaLabel: string;
            search: string;
            clearAll: string;
            removeAppliedFilters: string;
            yourFilters: string;
            and: string;
        };
        unitLevelOrderHistorySorting: {
            date: string;
            orderNumber: string;
            buyer: string;
            buyerDesc: string;
            orgUnit: string;
            orgUnitDesc: string;
        };
        unitLevelOrderDetails: {
            buyer: string;
        };
    };
};

declare const ko: {
    unitOrder: {
        unitLevelOrderHistory: {
            orderHistory: string;
            orderId: string;
            emptyPurchaseOrderId: string;
            date: string;
            status: string;
            buyer: string;
            unit: string;
            total: string;
            noOrders: string;
            startShopping: string;
            sortBy: string;
            sortOrders: string;
            purchaseOrderNumber: string;
            startOn: string;
            frequency: string;
            nextOrderDate: string;
            notFound: string;
            applyFilter: string;
            filterBy: string;
            filterByBuyer: string;
            filterByBuyerLabel: string;
            filterByBuyerPlaceholder: string;
            filterByBuyerAriaLabel: string;
            filterByUnit: string;
            filterByUnitLabel: string;
            filterByUnitPlaceholder: string;
            filterByUnitAriaLabel: string;
            search: string;
            clearAll: string;
            removeAppliedFilters: string;
            yourFilters: string;
            and: string;
        };
        unitLevelOrderHistorySorting: {
            date: string;
            orderNumber: string;
            buyer: string;
            buyerDesc: string;
            orgUnit: string;
            orgUnitDesc: string;
        };
        unitLevelOrderDetails: {
            buyer: string;
        };
    };
};

declare const pl: {
    unitOrder: {
        unitLevelOrderHistory: {
            orderHistory: string;
            orderId: string;
            emptyPurchaseOrderId: string;
            date: string;
            status: string;
            buyer: string;
            unit: string;
            total: string;
            noOrders: string;
            startShopping: string;
            sortBy: string;
            sortOrders: string;
            purchaseOrderNumber: string;
            startOn: string;
            frequency: string;
            nextOrderDate: string;
            notFound: string;
            applyFilter: string;
            filterBy: string;
            filterByBuyer: string;
            filterByBuyerLabel: string;
            filterByBuyerPlaceholder: string;
            filterByBuyerAriaLabel: string;
            filterByUnit: string;
            filterByUnitLabel: string;
            filterByUnitPlaceholder: string;
            filterByUnitAriaLabel: string;
            search: string;
            clearAll: string;
            removeAppliedFilters: string;
            yourFilters: string;
            and: string;
        };
        unitLevelOrderHistorySorting: {
            date: string;
            orderNumber: string;
            buyer: string;
            buyerDesc: string;
            orgUnit: string;
            orgUnitDesc: string;
        };
        unitLevelOrderDetails: {
            buyer: string;
        };
    };
};

declare const pt: {
    unitOrder: {
        unitLevelOrderHistory: {
            orderHistory: string;
            orderId: string;
            emptyPurchaseOrderId: string;
            date: string;
            status: string;
            buyer: string;
            unit: string;
            total: string;
            noOrders: string;
            startShopping: string;
            sortBy: string;
            sortOrders: string;
            purchaseOrderNumber: string;
            startOn: string;
            frequency: string;
            nextOrderDate: string;
            notFound: string;
            applyFilter: string;
            filterBy: string;
            filterByBuyer: string;
            filterByBuyerLabel: string;
            filterByBuyerPlaceholder: string;
            filterByBuyerAriaLabel: string;
            filterByUnit: string;
            filterByUnitLabel: string;
            filterByUnitPlaceholder: string;
            filterByUnitAriaLabel: string;
            search: string;
            clearAll: string;
            removeAppliedFilters: string;
            yourFilters: string;
            and: string;
        };
        unitLevelOrderHistorySorting: {
            date: string;
            orderNumber: string;
            buyer: string;
            buyerDesc: string;
            orgUnit: string;
            orgUnitDesc: string;
        };
        unitLevelOrderDetails: {
            buyer: string;
        };
    };
};

declare const ru: {
    unitOrder: {
        unitLevelOrderHistory: {
            orderHistory: string;
            orderId: string;
            emptyPurchaseOrderId: string;
            date: string;
            status: string;
            buyer: string;
            unit: string;
            total: string;
            noOrders: string;
            startShopping: string;
            sortBy: string;
            sortOrders: string;
            purchaseOrderNumber: string;
            startOn: string;
            frequency: string;
            nextOrderDate: string;
            notFound: string;
            applyFilter: string;
            filterBy: string;
            filterByBuyer: string;
            filterByBuyerLabel: string;
            filterByBuyerPlaceholder: string;
            filterByBuyerAriaLabel: string;
            filterByUnit: string;
            filterByUnitLabel: string;
            filterByUnitPlaceholder: string;
            filterByUnitAriaLabel: string;
            search: string;
            clearAll: string;
            removeAppliedFilters: string;
            yourFilters: string;
            and: string;
        };
        unitLevelOrderHistorySorting: {
            date: string;
            orderNumber: string;
            buyer: string;
            buyerDesc: string;
            orgUnit: string;
            orgUnitDesc: string;
        };
        unitLevelOrderDetails: {
            buyer: string;
        };
    };
};

declare const zh: {
    unitOrder: {
        unitLevelOrderHistory: {
            orderHistory: string;
            orderId: string;
            emptyPurchaseOrderId: string;
            date: string;
            status: string;
            buyer: string;
            unit: string;
            total: string;
            noOrders: string;
            startShopping: string;
            sortBy: string;
            sortOrders: string;
            purchaseOrderNumber: string;
            startOn: string;
            frequency: string;
            nextOrderDate: string;
            notFound: string;
            applyFilter: string;
            filterBy: string;
            filterByBuyer: string;
            filterByBuyerLabel: string;
            filterByBuyerPlaceholder: string;
            filterByBuyerAriaLabel: string;
            filterByUnit: string;
            filterByUnitLabel: string;
            filterByUnitPlaceholder: string;
            filterByUnitAriaLabel: string;
            search: string;
            clearAll: string;
            removeAppliedFilters: string;
            yourFilters: string;
            and: string;
        };
        unitLevelOrderHistorySorting: {
            date: string;
            orderNumber: string;
            buyer: string;
            buyerDesc: string;
            orgUnit: string;
            orgUnitDesc: string;
        };
        unitLevelOrderDetails: {
            buyer: string;
        };
    };
};

declare const zh_TW: {
    unitOrder: {
        unitLevelOrderHistory: {
            orderHistory: string;
            orderId: string;
            emptyPurchaseOrderId: string;
            date: string;
            status: string;
            buyer: string;
            unit: string;
            total: string;
            noOrders: string;
            startShopping: string;
            sortBy: string;
            sortOrders: string;
            purchaseOrderNumber: string;
            startOn: string;
            frequency: string;
            nextOrderDate: string;
            notFound: string;
            applyFilter: string;
            filterBy: string;
            filterByBuyer: string;
            filterByBuyerLabel: string;
            filterByBuyerPlaceholder: string;
            filterByBuyerAriaLabel: string;
            filterByUnit: string;
            filterByUnitLabel: string;
            filterByUnitPlaceholder: string;
            filterByUnitAriaLabel: string;
            search: string;
            clearAll: string;
            removeAppliedFilters: string;
            yourFilters: string;
            and: string;
        };
        unitLevelOrderHistorySorting: {
            date: string;
            orderNumber: string;
            buyer: string;
            buyerDesc: string;
            orgUnit: string;
            orgUnitDesc: string;
        };
        unitLevelOrderDetails: {
            buyer: string;
        };
    };
};

declare const unitOrderTranslationChunksConfig: TranslationChunksConfig;

export { unitOrderTranslationChunksConfig, cs as unitOrderTranslationsCs, de as unitOrderTranslationsDe, en as unitOrderTranslationsEn, es as unitOrderTranslationsEs, es_CO as unitOrderTranslationsEs_CO, fr as unitOrderTranslationsFr, hi as unitOrderTranslationsHi, hu as unitOrderTranslationsHu, id as unitOrderTranslationsId, it as unitOrderTranslationsIt, ja as unitOrderTranslationsJa, ko as unitOrderTranslationsKo, pl as unitOrderTranslationsPl, pt as unitOrderTranslationsPt, ru as unitOrderTranslationsRu, zh as unitOrderTranslationsZh, zh_TW as unitOrderTranslationsZh_TW };
