import { CmsConfig } from '@spartacus/core';
import * as i0 from '@angular/core';
import * as i1 from '@angular/router';

declare const ORGANIZATION_ORDER_APPROVAL_FEATURE = "organizationOrderApproval";

declare function defaultOrganizationOrderApprovalComponentsConfig(): CmsConfig;
declare class OrderApprovalRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderApprovalRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderApprovalRootModule, never, [typeof i1.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderApprovalRootModule>;
}

export { ORGANIZATION_ORDER_APPROVAL_FEATURE, OrderApprovalRootModule, defaultOrganizationOrderApprovalComponentsConfig };
