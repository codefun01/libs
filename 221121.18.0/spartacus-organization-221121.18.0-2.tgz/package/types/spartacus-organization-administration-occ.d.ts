import { HttpClient } from '@angular/common/http';
import * as i2 from '@spartacus/core';
import { OccEndpointsService, ConverterService, SearchConfig, EntitiesModel, CostCenter, B2BUnit, B2BApprovalProcess, B2BUser, Address, OrderApprovalPermissionType, Converter, Occ, OccEndpoint } from '@spartacus/core';
import { BudgetAdapter, Budget, CostCenterAdapter, OrgUnitAdapter, B2BUnitNode, UserGroupAdapter, UserGroup, Permission, PermissionAdapter, B2BUserAdapter } from '@spartacus/organization/administration/core';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare class OccBudgetAdapter implements BudgetAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    load(userId: string, budgetCode: string): Observable<Budget>;
    loadList(userId: string, params?: SearchConfig): Observable<EntitiesModel<Budget>>;
    create(userId: string, budget: Budget): Observable<Budget>;
    update(userId: string, budgetCode: string, budget: Budget): Observable<Budget>;
    protected getBudgetEndpoint(userId: string, budgetCode: string): string;
    protected getBudgetsEndpoint(userId: string, params?: SearchConfig): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccBudgetAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccBudgetAdapter>;
}

declare class OccCostCenterAdapter implements CostCenterAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    load(userId: string, costCenterCode: string): Observable<CostCenter>;
    loadList(userId: string, params?: SearchConfig): Observable<EntitiesModel<CostCenter>>;
    create(userId: string, costCenter: CostCenter): Observable<CostCenter>;
    update(userId: string, costCenterCode: string, costCenter: CostCenter): Observable<CostCenter>;
    loadBudgets(userId: string, costCenterCode: string, params?: SearchConfig): Observable<EntitiesModel<Budget>>;
    assignBudget(userId: string, costCenterCode: string, budgetCode: string): Observable<any>;
    unassignBudget(userId: string, costCenterCode: string, budgetCode: string): Observable<any>;
    protected getCostCenterEndpoint(userId: string, costCenterCode: string): string;
    protected getCostCentersEndpoint(userId: string, params?: SearchConfig): string;
    protected getAllCostCentersEndpoint(userId: string, params?: SearchConfig): string;
    protected getBudgetsEndpoint(userId: string, costCenterCode: string, params?: SearchConfig | {
        budgetCode: string;
    }): string;
    protected getBudgetEndpoint(userId: string, costCenterCode: string, budgetCode: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCostCenterAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCostCenterAdapter>;
}

declare class OccOrgUnitAdapter implements OrgUnitAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    load(userId: string, orgUnitId: string): Observable<B2BUnit>;
    create(userId: string, orgUnit: B2BUnit): Observable<B2BUnit>;
    update(userId: string, orgUnitId: string, orgUnit: B2BUnit): Observable<B2BUnit>;
    loadTree(userId: string): Observable<B2BUnitNode>;
    loadList(userId: string): Observable<B2BUnitNode[]>;
    loadApprovalProcesses(userId: string): Observable<B2BApprovalProcess[]>;
    loadUsers(userId: string, orgUnitId: string, roleId: string, params?: SearchConfig): Observable<EntitiesModel<B2BUser>>;
    assignRole(userId: string, orgCustomerId: string, roleId: string): Observable<any>;
    unassignRole(userId: string, orgCustomerId: string, roleId: string): Observable<any>;
    assignApprover(userId: string, orgUnitId: string, orgCustomerId: string, roleId: string): Observable<any>;
    unassignApprover(userId: string, orgUnitId: string, orgCustomerId: string, roleId: string): Observable<any>;
    loadAddresses(userId: string, orgUnitId: string): Observable<EntitiesModel<Address>>;
    createAddress(userId: string, orgUnitId: string, address: Address): Observable<Address>;
    updateAddress(userId: string, orgUnitId: string, addressId: string, address: Address): Observable<Address>;
    deleteAddress(userId: string, orgUnitId: string, addressId: string): Observable<any>;
    protected getOrgUnitEndpoint(userId: string, orgUnitId: string): string;
    protected getOrgUnitsEndpoint(userId: string): string;
    protected getAvailableOrgUnitsEndpoint(userId: string): string;
    protected getOrgUnitsTreeEndpoint(userId: string): string;
    protected getOrgUnitsApprovalProcessesEndpoint(userId: string): string;
    protected getUsersEndpoint(userId: string, orgUnitId: string, roleId: string, params?: SearchConfig): string;
    protected getRolesEndpoint(userId: string, orgCustomerId: string, params: {
        roleId: string;
    }): string;
    protected getRoleEndpoint(userId: string, orgCustomerId: string, roleId: string): string;
    protected getApproversEndpoint(userId: string, orgUnitId: string, orgCustomerId: string, params: {
        roleId: string;
    }): string;
    protected getApproverEndpoint(userId: string, orgUnitId: string, orgCustomerId: string, roleId: string): string;
    protected getAddressesEndpoint(userId: string, orgUnitId: string): string;
    protected getAddressEndpoint(userId: string, orgUnitId: string, addressId: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOrgUnitAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOrgUnitAdapter>;
}

declare class OccUserGroupAdapter implements UserGroupAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    load(userId: string, userGroupId: string): Observable<UserGroup>;
    loadList(userId: string, params?: SearchConfig): Observable<EntitiesModel<UserGroup>>;
    loadAvailableOrderApprovalPermissions(userId: string, userGroupId: string, params?: SearchConfig): Observable<EntitiesModel<Permission>>;
    loadAvailableOrgCustomers(userId: string, userGroupId: string, params?: SearchConfig): Observable<EntitiesModel<B2BUser>>;
    create(userId: string, userGroup: UserGroup): Observable<UserGroup>;
    delete(userId: string, userGroupId: string): Observable<UserGroup>;
    update(userId: string, userGroupId: string, userGroup: UserGroup): Observable<UserGroup>;
    assignMember(userId: string, userGroupId: string, orgCustomerId: string): Observable<any>;
    assignOrderApprovalPermission(userId: string, userGroupId: string, orderApprovalPermissionCode: string): Observable<any>;
    unassignMember(userId: string, userGroupId: string, orgCustomerId: string): Observable<any>;
    unassignAllMembers(userId: string, userGroupId: string): Observable<any>;
    unassignOrderApprovalPermission(userId: string, userGroupId: string, orderApprovalPermissionCode: string): Observable<any>;
    protected getUserGroupEndpoint(userId: string, userGroupId: string): string;
    protected getUserGroupsEndpoint(userId: string, params?: SearchConfig): string;
    protected getAvailableCustomersEndpoint(userId: string, userGroupId: string, params?: SearchConfig | {
        orgCustomerId: string;
    }): string;
    protected getPermissionsEndpoint(userId: string, userGroupId: string, params?: SearchConfig | {
        orgCustomerId: string;
    }): string;
    protected getMemberEndpoint(userId: string, userGroupId: string, orgCustomerId: string): string;
    protected getMembersEndpoint(userId: string, userGroupId: string, params?: SearchConfig | {
        orgCustomerId: string;
    }): string;
    protected getOrderApprovalPermissionsEndpoint(userId: string, userGroupId: string, params?: SearchConfig | {
        orderApprovalPermissionCode: string;
    }): string;
    protected getOrderApprovalPermissionEndpoint(userId: string, userGroupId: string, orderApprovalPermissionCode: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccUserGroupAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccUserGroupAdapter>;
}

declare class OccPermissionAdapter implements PermissionAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    load(userId: string, permissionCode: string): Observable<Permission>;
    loadList(userId: string, params?: SearchConfig): Observable<EntitiesModel<Permission>>;
    create(userId: string, permission: Permission): Observable<Permission>;
    update(userId: string, permissionCode: string, permission: Permission): Observable<Permission>;
    loadTypes(): Observable<OrderApprovalPermissionType[]>;
    protected getPermissionEndpoint(userId: string, orderApprovalPermissionCode: string): string;
    protected getPermissionsEndpoint(userId: string, params?: SearchConfig): string;
    protected getPermissionTypesEndpoint(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccPermissionAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccPermissionAdapter>;
}

declare class OccB2BUserAdapter implements B2BUserAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    load(userId: string, orgUnitCustomerId: string): Observable<B2BUser>;
    loadList(userId: string, params?: SearchConfig): Observable<EntitiesModel<B2BUser>>;
    create(userId: string, orgCustomer: B2BUser): Observable<B2BUser>;
    update(userId: string, orgCustomerId: string, orgCustomer: B2BUser): Observable<B2BUser>;
    loadApprovers(userId: string, orgCustomerId: string, params?: SearchConfig): Observable<EntitiesModel<B2BUser>>;
    assignApprover(userId: string, orgCustomerId: string, approverId: string): Observable<any>;
    unassignApprover(userId: string, orgCustomerId: string, approverId: string): Observable<any>;
    loadPermissions(userId: string, orgCustomerId: string, params?: SearchConfig): Observable<EntitiesModel<B2BUser>>;
    assignPermission(userId: string, orgCustomerId: string, permissionId: string): Observable<any>;
    unassignPermission(userId: string, orgCustomerId: string, permissionId: string): Observable<any>;
    loadUserGroups(userId: string, orgCustomerId: string, params?: SearchConfig): Observable<EntitiesModel<UserGroup>>;
    assignUserGroup(userId: string, orgCustomerId: string, userGroupId: string): Observable<any>;
    unassignUserGroup(userId: string, orgCustomerId: string, userGroupId: string): Observable<any>;
    protected getB2BUserEndpoint(userId: string, orgCustomerId: string): string;
    protected getB2BUsersEndpoint(userId: string, params?: SearchConfig): string;
    protected getApproverEndpoint(userId: string, orgCustomerId: string, approverId: string): string;
    protected getApproversEndpoint(userId: string, orgCustomerId: string, params?: SearchConfig | {
        orgCustomerId: string;
    }): string;
    protected getPermissionEndpoint(userId: string, orgCustomerId: string, premissionId: string): string;
    protected getPermissionsEndpoint(userId: string, orgCustomerId: string, params?: SearchConfig): string;
    protected getUserGroupEndpoint(userId: string, orgCustomerId: string, userGroupId: string): string;
    protected getUserGroupsEndpoint(userId: string, orgCustomerId: string, params?: SearchConfig): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccB2BUserAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccB2BUserAdapter>;
}

declare class AdministrationOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AdministrationOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AdministrationOccModule, never, [typeof i1.CommonModule, typeof i2.CostCenterOccModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AdministrationOccModule>;
}

declare class OccB2BUserNormalizer implements Converter<Occ.B2BUser, B2BUser> {
    constructor();
    convert(source: Occ.B2BUser, target?: B2BUser): B2BUser;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccB2BUserNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccB2BUserNormalizer>;
}

declare class OccB2bUserSerializer implements Converter<B2BUser, Occ.B2BUser> {
    constructor();
    convert(source: B2BUser, target?: Occ.B2BUser): Occ.B2BUser;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccB2bUserSerializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccB2bUserSerializer>;
}

declare class OccBudgetListNormalizer implements Converter<Occ.BudgetsList, EntitiesModel<Budget>> {
    private converter;
    constructor(converter: ConverterService);
    convert(source: Occ.BudgetsList, target?: EntitiesModel<Budget>): EntitiesModel<Budget>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccBudgetListNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccBudgetListNormalizer>;
}

declare class OccBudgetNormalizer implements Converter<Occ.Budget, Budget> {
    convert(source: Occ.Budget, target?: Budget): Budget;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccBudgetNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccBudgetNormalizer>;
}

declare class OccBudgetSerializer implements Converter<Budget, Occ.Budget> {
    constructor();
    convert(source: Budget, target?: Occ.Budget): Occ.Budget;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccBudgetSerializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccBudgetSerializer>;
}

declare class OccOrgUnitApprovalProcessNormalizer implements Converter<Occ.B2BApprovalProcessList, B2BApprovalProcess[]> {
    constructor();
    convert(source: Occ.B2BApprovalProcessList, target?: B2BApprovalProcess[]): B2BApprovalProcess[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOrgUnitApprovalProcessNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOrgUnitApprovalProcessNormalizer>;
}

declare class OccOrgUnitNodeListNormalizer implements Converter<Occ.B2BUnitNodeList, B2BUnitNode[]> {
    convert(source: Occ.B2BUnitNodeList, target?: B2BUnitNode[]): B2BUnitNode[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOrgUnitNodeListNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOrgUnitNodeListNormalizer>;
}

declare class OccOrgUnitNodeNormalizer implements Converter<Occ.B2BUnitNode, B2BUnitNode> {
    convert(source: Occ.B2BUnitNode, target?: B2BUnitNode): B2BUnitNode;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOrgUnitNodeNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOrgUnitNodeNormalizer>;
}

declare class OccOrgUnitNormalizer implements Converter<Occ.B2BUnit, B2BUnit> {
    convert(source: Occ.B2BUnit, target?: B2BUnit): B2BUnit;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOrgUnitNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOrgUnitNormalizer>;
}

declare class OccPermissionListNormalizer implements Converter<Occ.PermissionsList, EntitiesModel<Permission>> {
    private converter;
    constructor(converter: ConverterService);
    convert(source: Occ.PermissionsList, target?: EntitiesModel<Permission>): EntitiesModel<Permission>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccPermissionListNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccPermissionListNormalizer>;
}

declare class OccPermissionNormalizer implements Converter<Occ.Permission, Permission> {
    convert(source: Occ.Permission, target?: Permission): Permission;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccPermissionNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccPermissionNormalizer>;
}

declare class OccPermissionTypeListNormalizer implements Converter<Occ.OrderApprovalPermissionTypeList, OrderApprovalPermissionType[]> {
    private converter;
    constructor(converter: ConverterService);
    convert(source: Occ.OrderApprovalPermissionTypeList, target?: OrderApprovalPermissionType[]): OrderApprovalPermissionType[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OccPermissionTypeListNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccPermissionTypeListNormalizer>;
}

declare class OccPermissionTypeNormalizer implements Converter<Occ.OrderApprovalPermissionType, OrderApprovalPermissionType> {
    constructor();
    convert(source: Occ.OrderApprovalPermissionType, target?: OrderApprovalPermissionType): OrderApprovalPermissionType;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccPermissionTypeNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccPermissionTypeNormalizer>;
}

declare class OccUserGroupListNormalizer implements Converter<Occ.OrgUnitUserGroupList, EntitiesModel<UserGroup>> {
    private converter;
    constructor(converter: ConverterService);
    convert(source: Occ.OrgUnitUserGroupList, target?: EntitiesModel<UserGroup>): EntitiesModel<UserGroup>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccUserGroupListNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccUserGroupListNormalizer>;
}

declare class OccUserGroupNormalizer implements Converter<Occ.OrgUnitUserGroup, UserGroup> {
    constructor();
    convert(source: Occ.OrgUnitUserGroup, target?: UserGroup): UserGroup;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccUserGroupNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccUserGroupNormalizer>;
}

declare class OccUserListNormalizer implements Converter<Occ.OrgUnitUserList, EntitiesModel<B2BUser>> {
    private converter;
    constructor(converter: ConverterService);
    convert(source: Occ.OrgUnitUserList, target?: EntitiesModel<B2BUser>): EntitiesModel<B2BUser>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccUserListNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccUserListNormalizer>;
}

declare module '@spartacus/core' {
    interface OccEndpoints {
        /**
         * Endpoint for organization customers
         *
         * @member {string}
         */
        b2bUsers?: string | OccEndpoint;
        /**
         * Endpoint for organization customer
         *
         * @member {string}
         */
        b2bUser?: string | OccEndpoint;
        /**
         * Endpoint for organization customer approvers
         *
         * @member {string}
         */
        b2bUserApprovers?: string | OccEndpoint;
        /**
         * Endpoint for organization customer approver
         *
         * @member {string}
         */
        b2bUserApprover?: string | OccEndpoint;
        /**
         * Endpoint for organization customer user groups
         *
         * @member {string}
         */
        b2bUserUserGroups?: string | OccEndpoint;
        /**
         * Endpoint for organization customer user group
         *
         * @member {string}
         */
        b2bUserUserGroup?: string | OccEndpoint;
        /**
         * Endpoint for organization customer permissions
         *
         * @member {string}
         */
        b2bUserPermissions?: string | OccEndpoint;
        /**
         * Endpoint for organization customer permission
         *
         * @member {string}
         */
        b2bUserPermission?: string | OccEndpoint;
        /**
         * Endpoint for userGroupOrderApprovalPermission
         *
         * @member {string}
         */
        budget?: string | OccEndpoint;
        /**
         * Endpoint for budgets list
         *
         * @member {string}
         */
        budgets?: string | OccEndpoint;
        /**
         * Endpoint for all costCenters
         *
         * @member {string}
         */
        costCentersAll?: string | OccEndpoint;
        /**
         * Endpoint for costCenter
         *
         * @member {string}
         */
        costCenter?: string | OccEndpoint;
        /**
         * Endpoint for userGroupOrderApprovalPermission
         *
         * @member {string}
         */
        costCenters?: string | OccEndpoint;
        /**
         * Endpoint for budgets assigned to costCenter
         *
         * @member {string}
         */
        costCenterBudgets?: string | OccEndpoint;
        /**
         * Endpoint for budget assigned to costCenter
         *
         * @member {string}
         */
        costCenterBudget?: string | OccEndpoint;
        /**
         * Endpoint for organizations
         *
         * @member {string}
         */
        orgUnits?: string | OccEndpoint;
        /**
         * Endpoint for organizations list
         *
         * @member {string}
         */
        orgUnitsAvailable?: string | OccEndpoint;
        /**
         * Endpoint for organization units tree
         *
         * @member {string}
         */
        orgUnitsTree?: string | OccEndpoint;
        /**
         * Endpoint for approval processes for organization units
         *
         * @member {string}
         */
        orgUnitsApprovalProcesses?: string | OccEndpoint;
        /**
         * Endpoint for organization
         *
         * @member {string}
         */
        orgUnit?: string | OccEndpoint;
        /**
         * Endpoint for orgUnitUsers:
         *
         * @member {string}
         */
        orgUnitUsers?: string | OccEndpoint;
        /**
         * Endpoint for add orgUnitUserRoles (except approver):
         *
         * @member {string}
         */
        orgUnitUserRoles?: string | OccEndpoint;
        /**
         * Endpoint for remove orgUnitUserRole (except approver):
         *
         * @member {string}
         */
        orgUnitUserRole?: string | OccEndpoint;
        /**
         * Endpoint for add orgUnitApprovers:
         *
         * @member {string}
         */
        orgUnitApprovers?: string | OccEndpoint;
        /**
         * Endpoint for delete orgUnitApprover:
         *
         * @member {string}
         */
        orgUnitApprover?: string | OccEndpoint;
        /**
         * Endpoint for organizational unit addresses
         *
         * @member {string}
         */
        orgUnitsAddresses?: string | OccEndpoint;
        /**
         * Endpoint for organizational unit address
         *
         * @member {string}
         */
        orgUnitsAddress?: string | OccEndpoint;
        /**
         * Endpoint for permission list
         *
         * @member {string}
         */
        permissions?: string | OccEndpoint;
        /**
         * Endpoint for permission
         *
         * @member {string}
         */
        permission?: string | OccEndpoint;
        /**
         * Endpoint for order approval permission types
         *
         * @member {string}
         */
        orderApprovalPermissionTypes?: string | OccEndpoint;
        /**
         * Endpoint for organizational unit user groups list
         *
         * @member {string}
         */
        userGroups?: string | OccEndpoint;
        /**
         * Endpoint for organizational unit user group
         *
         * @member {string}
         */
        userGroup?: string | OccEndpoint;
        /**
         * Endpoint for costCenter list
         *
         * @member {string}
         */
        userGroupAvailableOrderApprovalPermissions?: string | OccEndpoint;
        /**
         * Endpoint for userGroupAvailableOrderApprovalPermissions list
         *
         * @member {string}
         */
        userGroupAvailableOrgCustomers?: string | OccEndpoint;
        /**
         * Endpoint for userGroupAvailableOrgCustomers list
         *
         * @member {string}
         */
        userGroupMembers?: string | OccEndpoint;
        /**
         * Endpoint for userGroupMembers list
         *
         * @member {string}
         */
        userGroupMember?: string | OccEndpoint;
        /**
         * Endpoint for userGroupMember
         *
         * @member {string}
         */
        userGroupOrderApprovalPermissions?: string | OccEndpoint;
        /**
         * Endpoint for userGroupOrderApprovalPermissions list
         *
         * @member {string}
         */
        userGroupOrderApprovalPermission?: string | OccEndpoint;
    }
}

export { AdministrationOccModule, OccB2BUserAdapter, OccB2BUserNormalizer, OccB2bUserSerializer, OccBudgetAdapter, OccBudgetListNormalizer, OccBudgetNormalizer, OccBudgetSerializer, OccCostCenterAdapter, OccOrgUnitAdapter, OccOrgUnitApprovalProcessNormalizer, OccOrgUnitNodeListNormalizer, OccOrgUnitNodeNormalizer, OccOrgUnitNormalizer, OccPermissionAdapter, OccPermissionListNormalizer, OccPermissionNormalizer, OccPermissionTypeListNormalizer, OccPermissionTypeNormalizer, OccUserGroupAdapter, OccUserGroupListNormalizer, OccUserGroupNormalizer, OccUserListNormalizer };
