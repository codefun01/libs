import { HttpClient } from '@angular/common/http';
import { OccEndpointsService, ConverterService, OccEndpoint } from '@spartacus/core';
import { Observable } from 'rxjs';
import { OrderHistoryList, Order } from '@spartacus/order/root';
import { UnitOrderAdapter } from '@spartacus/organization/unit-order/core';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare class OccUnitOrderAdapter implements UnitOrderAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    loadUnitOrderHistory(userId: string, pageSize?: number, currentPage?: number, filters?: string, sort?: string): Observable<OrderHistoryList>;
    loadUnitOrderDetail(userId: string, orderCode: string): Observable<Order>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccUnitOrderAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccUnitOrderAdapter>;
}

declare module '@spartacus/core' {
    interface OccEndpoints {
        /**
         * Endpoint to retrieve unit-level orders
         *
         * @member {string}
         */
        unitLevelOrderHistory?: string | OccEndpoint;
        /**
         * Endpoint to retrieve unit-level order detail
         *
         * @member {string}
         */
        unitLevelOrderDetail?: string | OccEndpoint;
    }
}

declare class UnitOrderOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitOrderOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitOrderOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitOrderOccModule>;
}

export { OccUnitOrderAdapter, UnitOrderOccModule };
