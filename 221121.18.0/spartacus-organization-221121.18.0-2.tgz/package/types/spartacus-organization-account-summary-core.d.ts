import * as i0 from '@angular/core';
import { OnDestroy, InjectionToken } from '@angular/core';
import { RoutingService, UserIdService, Converter, ContentPageMetaResolver, TranslationService, SemanticPathService, BreadcrumbMeta, Page } from '@spartacus/core';
import { AccountSummaryDetails, DocumentQueryParams, AccountSummaryList, AccountSummaryFacade } from '@spartacus/organization/account-summary/root';
import { Observable, Subscription } from 'rxjs';
import { OrganizationPageMetaResolver } from '@spartacus/organization/administration/core';

declare abstract class AccountSummaryAdapter {
    /**
     * Abstract method to load account summary header data for given
     * @param userId
     * @param orgUnitId
     */
    abstract getAccountSummary(userId: string, orgUnitId: string): Observable<AccountSummaryDetails>;
    /**
     * Abstract method to load account summary document list for given
     * @param userId
     * @param orgUnitId
     */
    abstract getDocumentList(userId: string, orgUnitId: string, params: DocumentQueryParams): Observable<AccountSummaryList>;
    /**
     * Abstract method to load a document attachment file
     * @param userId
     * @param orgUnitId
     * @param orgDocumentId
     * @param orgDocumentAttachmentId
     */
    abstract getDocumentAttachment(userId: string, orgUnitId: string, orgDocumentId: string, orgDocumentAttachmentId: string): Observable<Blob>;
}

declare class AccountSummaryConnector {
    protected accountSummaryAdapter: AccountSummaryAdapter;
    constructor(accountSummaryAdapter: AccountSummaryAdapter);
    getAccountSummary(userId: string, orgUnitId: string): Observable<AccountSummaryDetails>;
    getDocumentList(userId: string, orgUnitId: string, params: DocumentQueryParams): Observable<AccountSummaryList>;
    getDocumentAttachment(userId: string, orgUnitId: string, orgDocumentId: string, orgDocumentAttachmentId: string): Observable<Blob>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AccountSummaryConnector>;
}

declare class AccountSummaryService implements AccountSummaryFacade, OnDestroy {
    private routingService;
    private userIdService;
    private accountSummaryConnector;
    protected subscriptions: Subscription;
    userId: string;
    orgUnitId: string;
    constructor(routingService: RoutingService, userIdService: UserIdService, accountSummaryConnector: AccountSummaryConnector);
    ngOnDestroy(): void;
    getAccountSummary(orgUnitId?: string): Observable<AccountSummaryDetails>;
    getDocumentList(params: DocumentQueryParams, orgUnitId?: string): Observable<AccountSummaryList>;
    getDocumentAttachment(orgDocumentId: string, orgDocumentAttachmentId: string, orgUnitId?: string): Observable<Blob>;
    protected getOrgUnitId(): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AccountSummaryService>;
}

declare const ACCOUNT_SUMMARY_NORMALIZER: InjectionToken<Converter<any, AccountSummaryDetails>>;
declare const ACCOUNT_SUMMARY_DOCUMENT_NORMALIZER: InjectionToken<Converter<any, AccountSummaryList>>;

declare const ACCOUNT_SUMMARY_LIST_TRANSLATION_KEY = "orgAccountSummaryList.breadcrumbs.list";
declare class AccountSummaryPageMetaResolver extends OrganizationPageMetaResolver {
    protected contentPageMetaResolver: ContentPageMetaResolver;
    protected translation: TranslationService;
    protected semanticPath: SemanticPathService;
    protected routingService: RoutingService;
    constructor(contentPageMetaResolver: ContentPageMetaResolver, translation: TranslationService, semanticPath: SemanticPathService, routingService: RoutingService);
    protected readonly ACCOUNT_SUMMARY_SEMANTIC_ROUTE = "orgAccountSummary";
    protected readonly ACCOUNT_SUMMARY_LIST_LABEL = "Account Summaries";
    protected readonly ACCOUNT_SUMMARY_LIST_PATH = "/organization/account-summary";
    /**
     * Breadcrumbs of the Account Summary page.
     */
    protected orgAccountSummaryBreadcrumb$: Observable<BreadcrumbMeta[]>;
    /**
     * Breadcrumbs returned in the method #resolveBreadcrumbs.
     */
    protected breadcrumbs$: Observable<BreadcrumbMeta[]>;
    getScore(page: Page): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryPageMetaResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AccountSummaryPageMetaResolver>;
}

declare class AccountSummaryCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AccountSummaryCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AccountSummaryCoreModule>;
}

export { ACCOUNT_SUMMARY_DOCUMENT_NORMALIZER, ACCOUNT_SUMMARY_LIST_TRANSLATION_KEY, ACCOUNT_SUMMARY_NORMALIZER, AccountSummaryAdapter, AccountSummaryConnector, AccountSummaryCoreModule, AccountSummaryPageMetaResolver, AccountSummaryService };
