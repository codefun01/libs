import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    userRegistration: {
        userRegistrationForm: {
            fields: {
                titleCode: {
                    label: string;
                    placeholder: string;
                };
                titleCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                companyName: {
                    label: string;
                    placeholder: string;
                };
                email: {
                    label: string;
                    placeholder: string;
                };
                city: {
                    label: string;
                    placeholder: string;
                };
                cityOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                country: {
                    label: string;
                    placeholder: string;
                };
                countryOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                state: {
                    label: string;
                    placeholder: string;
                };
                stateOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                postalCode: {
                    label: string;
                    placeholder: string;
                };
                postalCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                addressLine: {
                    label: string;
                    placeholder: string;
                };
                addressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLine: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                phoneNumber: {
                    label: string;
                    placeholder: string;
                };
                phoneNumberOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                message: {
                    label: string;
                    placeholder: string;
                };
                messageOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
            };
            messageToApproverTemplate: string;
            successFormSubmitMessage: string;
            formSubmitButtonLabel: string;
            continueWithOTP: string;
            goToLoginButtonLabel: string;
            httpHandlers: {
                conflict: string;
            };
            messageToFailedToRegister: string;
        };
    };
};

declare const de: {
    userRegistration: {
        userRegistrationForm: {
            fields: {
                titleCode: {
                    label: string;
                    placeholder: string;
                };
                titleCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                companyName: {
                    label: string;
                    placeholder: string;
                };
                email: {
                    label: string;
                    placeholder: string;
                };
                city: {
                    label: string;
                    placeholder: string;
                };
                cityOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                country: {
                    label: string;
                    placeholder: string;
                };
                countryOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                state: {
                    label: string;
                    placeholder: string;
                };
                stateOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                postalCode: {
                    label: string;
                    placeholder: string;
                };
                postalCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                addressLine: {
                    label: string;
                    placeholder: string;
                };
                addressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLine: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                phoneNumber: {
                    label: string;
                    placeholder: string;
                };
                phoneNumberOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                message: {
                    label: string;
                    placeholder: string;
                };
                messageOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
            };
            messageToApproverTemplate: string;
            successFormSubmitMessage: string;
            formSubmitButtonLabel: string;
            continueWithOTP: string;
            goToLoginButtonLabel: string;
            httpHandlers: {
                conflict: string;
            };
            messageToFailedToRegister: string;
        };
    };
};

declare const en: {
    userRegistration: {
        userRegistrationForm: {
            fields: {
                titleCode: {
                    label: string;
                    placeholder: string;
                };
                titleCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                companyName: {
                    label: string;
                    placeholder: string;
                };
                email: {
                    label: string;
                    placeholder: string;
                };
                city: {
                    label: string;
                    placeholder: string;
                };
                cityOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                country: {
                    label: string;
                    placeholder: string;
                };
                countryOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                state: {
                    label: string;
                    placeholder: string;
                };
                stateOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                postalCode: {
                    label: string;
                    placeholder: string;
                };
                postalCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                addressLine: {
                    label: string;
                    placeholder: string;
                };
                addressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLine: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                phoneNumber: {
                    label: string;
                    placeholder: string;
                };
                phoneNumberOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                message: {
                    label: string;
                    placeholder: string;
                };
                messageOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
            };
            messageToApproverTemplate: string;
            successFormSubmitMessage: string;
            formSubmitButtonLabel: string;
            continueWithOTP: string;
            goToLoginButtonLabel: string;
            httpHandlers: {
                conflict: string;
            };
            messageToFailedToRegister: string;
        };
    };
};

declare const es: {
    userRegistration: {
        userRegistrationForm: {
            fields: {
                titleCode: {
                    label: string;
                    placeholder: string;
                };
                titleCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                companyName: {
                    label: string;
                    placeholder: string;
                };
                email: {
                    label: string;
                    placeholder: string;
                };
                city: {
                    label: string;
                    placeholder: string;
                };
                cityOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                country: {
                    label: string;
                    placeholder: string;
                };
                countryOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                state: {
                    label: string;
                    placeholder: string;
                };
                stateOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                postalCode: {
                    label: string;
                    placeholder: string;
                };
                postalCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                addressLine: {
                    label: string;
                    placeholder: string;
                };
                addressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLine: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                phoneNumber: {
                    label: string;
                    placeholder: string;
                };
                phoneNumberOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                message: {
                    label: string;
                    placeholder: string;
                };
                messageOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
            };
            messageToApproverTemplate: string;
            successFormSubmitMessage: string;
            formSubmitButtonLabel: string;
            continueWithOTP: string;
            goToLoginButtonLabel: string;
            httpHandlers: {
                conflict: string;
            };
            messageToFailedToRegister: string;
        };
    };
};

declare const es_CO: {
    userRegistration: {
        userRegistrationForm: {
            fields: {
                titleCode: {
                    label: string;
                    placeholder: string;
                };
                titleCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                companyName: {
                    label: string;
                    placeholder: string;
                };
                email: {
                    label: string;
                    placeholder: string;
                };
                city: {
                    label: string;
                    placeholder: string;
                };
                cityOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                country: {
                    label: string;
                    placeholder: string;
                };
                countryOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                state: {
                    label: string;
                    placeholder: string;
                };
                stateOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                postalCode: {
                    label: string;
                    placeholder: string;
                };
                postalCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                addressLine: {
                    label: string;
                    placeholder: string;
                };
                addressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLine: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                phoneNumber: {
                    label: string;
                    placeholder: string;
                };
                phoneNumberOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                message: {
                    label: string;
                    placeholder: string;
                };
                messageOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
            };
            messageToApproverTemplate: string;
            successFormSubmitMessage: string;
            formSubmitButtonLabel: string;
            continueWithOTP: string;
            goToLoginButtonLabel: string;
            httpHandlers: {
                conflict: string;
            };
            messageToFailedToRegister: string;
        };
    };
};

declare const fr: {
    userRegistration: {
        userRegistrationForm: {
            fields: {
                titleCode: {
                    label: string;
                    placeholder: string;
                };
                titleCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                companyName: {
                    label: string;
                    placeholder: string;
                };
                email: {
                    label: string;
                    placeholder: string;
                };
                city: {
                    label: string;
                    placeholder: string;
                };
                cityOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                country: {
                    label: string;
                    placeholder: string;
                };
                countryOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                state: {
                    label: string;
                    placeholder: string;
                };
                stateOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                postalCode: {
                    label: string;
                    placeholder: string;
                };
                postalCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                addressLine: {
                    label: string;
                    placeholder: string;
                };
                addressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLine: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                phoneNumber: {
                    label: string;
                    placeholder: string;
                };
                phoneNumberOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                message: {
                    label: string;
                    placeholder: string;
                };
                messageOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
            };
            messageToApproverTemplate: string;
            successFormSubmitMessage: string;
            formSubmitButtonLabel: string;
            continueWithOTP: string;
            goToLoginButtonLabel: string;
            httpHandlers: {
                conflict: string;
            };
            messageToFailedToRegister: string;
        };
    };
};

declare const hi: {
    userRegistration: {
        userRegistrationForm: {
            fields: {
                titleCode: {
                    label: string;
                    placeholder: string;
                };
                titleCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                companyName: {
                    label: string;
                    placeholder: string;
                };
                email: {
                    label: string;
                    placeholder: string;
                };
                city: {
                    label: string;
                    placeholder: string;
                };
                cityOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                country: {
                    label: string;
                    placeholder: string;
                };
                countryOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                state: {
                    label: string;
                    placeholder: string;
                };
                stateOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                postalCode: {
                    label: string;
                    placeholder: string;
                };
                postalCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                addressLine: {
                    label: string;
                    placeholder: string;
                };
                addressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLine: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                phoneNumber: {
                    label: string;
                    placeholder: string;
                };
                phoneNumberOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                message: {
                    label: string;
                    placeholder: string;
                };
                messageOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
            };
            messageToApproverTemplate: string;
            successFormSubmitMessage: string;
            formSubmitButtonLabel: string;
            continueWithOTP: string;
            goToLoginButtonLabel: string;
            httpHandlers: {
                conflict: string;
            };
            messageToFailedToRegister: string;
        };
    };
};

declare const hu: {
    userRegistration: {
        userRegistrationForm: {
            fields: {
                titleCode: {
                    label: string;
                    placeholder: string;
                };
                titleCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                companyName: {
                    label: string;
                    placeholder: string;
                };
                email: {
                    label: string;
                    placeholder: string;
                };
                city: {
                    label: string;
                    placeholder: string;
                };
                cityOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                country: {
                    label: string;
                    placeholder: string;
                };
                countryOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                state: {
                    label: string;
                    placeholder: string;
                };
                stateOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                postalCode: {
                    label: string;
                    placeholder: string;
                };
                postalCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                addressLine: {
                    label: string;
                    placeholder: string;
                };
                addressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLine: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                phoneNumber: {
                    label: string;
                    placeholder: string;
                };
                phoneNumberOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                message: {
                    label: string;
                    placeholder: string;
                };
                messageOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
            };
            messageToApproverTemplate: string;
            successFormSubmitMessage: string;
            formSubmitButtonLabel: string;
            continueWithOTP: string;
            goToLoginButtonLabel: string;
            httpHandlers: {
                conflict: string;
            };
            messageToFailedToRegister: string;
        };
    };
};

declare const id: {
    userRegistration: {
        userRegistrationForm: {
            fields: {
                titleCode: {
                    label: string;
                    placeholder: string;
                };
                titleCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                companyName: {
                    label: string;
                    placeholder: string;
                };
                email: {
                    label: string;
                    placeholder: string;
                };
                city: {
                    label: string;
                    placeholder: string;
                };
                cityOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                country: {
                    label: string;
                    placeholder: string;
                };
                countryOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                state: {
                    label: string;
                    placeholder: string;
                };
                stateOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                postalCode: {
                    label: string;
                    placeholder: string;
                };
                postalCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                addressLine: {
                    label: string;
                    placeholder: string;
                };
                addressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLine: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                phoneNumber: {
                    label: string;
                    placeholder: string;
                };
                phoneNumberOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                message: {
                    label: string;
                    placeholder: string;
                };
                messageOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
            };
            messageToApproverTemplate: string;
            successFormSubmitMessage: string;
            formSubmitButtonLabel: string;
            continueWithOTP: string;
            goToLoginButtonLabel: string;
            httpHandlers: {
                conflict: string;
            };
            messageToFailedToRegister: string;
        };
    };
};

declare const it: {
    userRegistration: {
        userRegistrationForm: {
            fields: {
                titleCode: {
                    label: string;
                    placeholder: string;
                };
                titleCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                companyName: {
                    label: string;
                    placeholder: string;
                };
                email: {
                    label: string;
                    placeholder: string;
                };
                city: {
                    label: string;
                    placeholder: string;
                };
                cityOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                country: {
                    label: string;
                    placeholder: string;
                };
                countryOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                state: {
                    label: string;
                    placeholder: string;
                };
                stateOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                postalCode: {
                    label: string;
                    placeholder: string;
                };
                postalCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                addressLine: {
                    label: string;
                    placeholder: string;
                };
                addressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLine: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                phoneNumber: {
                    label: string;
                    placeholder: string;
                };
                phoneNumberOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                message: {
                    label: string;
                    placeholder: string;
                };
                messageOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
            };
            messageToApproverTemplate: string;
            successFormSubmitMessage: string;
            formSubmitButtonLabel: string;
            continueWithOTP: string;
            goToLoginButtonLabel: string;
            httpHandlers: {
                conflict: string;
            };
            messageToFailedToRegister: string;
        };
    };
};

declare const ja: {
    userRegistration: {
        userRegistrationForm: {
            fields: {
                titleCode: {
                    label: string;
                    placeholder: string;
                };
                titleCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                companyName: {
                    label: string;
                    placeholder: string;
                };
                email: {
                    label: string;
                    placeholder: string;
                };
                city: {
                    label: string;
                    placeholder: string;
                };
                cityOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                country: {
                    label: string;
                    placeholder: string;
                };
                countryOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                state: {
                    label: string;
                    placeholder: string;
                };
                stateOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                postalCode: {
                    label: string;
                    placeholder: string;
                };
                postalCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                addressLine: {
                    label: string;
                    placeholder: string;
                };
                addressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLine: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                phoneNumber: {
                    label: string;
                    placeholder: string;
                };
                phoneNumberOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                message: {
                    label: string;
                    placeholder: string;
                };
                messageOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
            };
            messageToApproverTemplate: string;
            successFormSubmitMessage: string;
            formSubmitButtonLabel: string;
            continueWithOTP: string;
            goToLoginButtonLabel: string;
            httpHandlers: {
                conflict: string;
            };
            messageToFailedToRegister: string;
        };
    };
};

declare const ko: {
    userRegistration: {
        userRegistrationForm: {
            fields: {
                titleCode: {
                    label: string;
                    placeholder: string;
                };
                titleCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                companyName: {
                    label: string;
                    placeholder: string;
                };
                email: {
                    label: string;
                    placeholder: string;
                };
                city: {
                    label: string;
                    placeholder: string;
                };
                cityOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                country: {
                    label: string;
                    placeholder: string;
                };
                countryOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                state: {
                    label: string;
                    placeholder: string;
                };
                stateOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                postalCode: {
                    label: string;
                    placeholder: string;
                };
                postalCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                addressLine: {
                    label: string;
                    placeholder: string;
                };
                addressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLine: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                phoneNumber: {
                    label: string;
                    placeholder: string;
                };
                phoneNumberOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                message: {
                    label: string;
                    placeholder: string;
                };
                messageOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
            };
            messageToApproverTemplate: string;
            successFormSubmitMessage: string;
            formSubmitButtonLabel: string;
            continueWithOTP: string;
            goToLoginButtonLabel: string;
            httpHandlers: {
                conflict: string;
            };
            messageToFailedToRegister: string;
        };
    };
};

declare const pl: {
    userRegistration: {
        userRegistrationForm: {
            fields: {
                titleCode: {
                    label: string;
                    placeholder: string;
                };
                titleCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                companyName: {
                    label: string;
                    placeholder: string;
                };
                email: {
                    label: string;
                    placeholder: string;
                };
                city: {
                    label: string;
                    placeholder: string;
                };
                cityOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                country: {
                    label: string;
                    placeholder: string;
                };
                countryOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                state: {
                    label: string;
                    placeholder: string;
                };
                stateOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                postalCode: {
                    label: string;
                    placeholder: string;
                };
                postalCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                addressLine: {
                    label: string;
                    placeholder: string;
                };
                addressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLine: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                phoneNumber: {
                    label: string;
                    placeholder: string;
                };
                phoneNumberOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                message: {
                    label: string;
                    placeholder: string;
                };
                messageOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
            };
            messageToApproverTemplate: string;
            successFormSubmitMessage: string;
            formSubmitButtonLabel: string;
            continueWithOTP: string;
            goToLoginButtonLabel: string;
            httpHandlers: {
                conflict: string;
            };
            messageToFailedToRegister: string;
        };
    };
};

declare const pt: {
    userRegistration: {
        userRegistrationForm: {
            fields: {
                titleCode: {
                    label: string;
                    placeholder: string;
                };
                titleCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                companyName: {
                    label: string;
                    placeholder: string;
                };
                email: {
                    label: string;
                    placeholder: string;
                };
                city: {
                    label: string;
                    placeholder: string;
                };
                cityOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                country: {
                    label: string;
                    placeholder: string;
                };
                countryOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                state: {
                    label: string;
                    placeholder: string;
                };
                stateOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                postalCode: {
                    label: string;
                    placeholder: string;
                };
                postalCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                addressLine: {
                    label: string;
                    placeholder: string;
                };
                addressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLine: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                phoneNumber: {
                    label: string;
                    placeholder: string;
                };
                phoneNumberOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                message: {
                    label: string;
                    placeholder: string;
                };
                messageOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
            };
            messageToApproverTemplate: string;
            successFormSubmitMessage: string;
            formSubmitButtonLabel: string;
            continueWithOTP: string;
            goToLoginButtonLabel: string;
            httpHandlers: {
                conflict: string;
            };
            messageToFailedToRegister: string;
        };
    };
};

declare const ru: {
    userRegistration: {
        userRegistrationForm: {
            fields: {
                titleCode: {
                    label: string;
                    placeholder: string;
                };
                titleCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                companyName: {
                    label: string;
                    placeholder: string;
                };
                email: {
                    label: string;
                    placeholder: string;
                };
                city: {
                    label: string;
                    placeholder: string;
                };
                cityOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                country: {
                    label: string;
                    placeholder: string;
                };
                countryOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                state: {
                    label: string;
                    placeholder: string;
                };
                stateOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                postalCode: {
                    label: string;
                    placeholder: string;
                };
                postalCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                addressLine: {
                    label: string;
                    placeholder: string;
                };
                addressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLine: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                phoneNumber: {
                    label: string;
                    placeholder: string;
                };
                phoneNumberOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                message: {
                    label: string;
                    placeholder: string;
                };
                messageOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
            };
            messageToApproverTemplate: string;
            successFormSubmitMessage: string;
            formSubmitButtonLabel: string;
            continueWithOTP: string;
            goToLoginButtonLabel: string;
            httpHandlers: {
                conflict: string;
            };
            messageToFailedToRegister: string;
        };
    };
};

declare const zh: {
    userRegistration: {
        userRegistrationForm: {
            fields: {
                titleCode: {
                    label: string;
                    placeholder: string;
                };
                titleCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                companyName: {
                    label: string;
                    placeholder: string;
                };
                email: {
                    label: string;
                    placeholder: string;
                };
                city: {
                    label: string;
                    placeholder: string;
                };
                cityOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                country: {
                    label: string;
                    placeholder: string;
                };
                countryOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                state: {
                    label: string;
                    placeholder: string;
                };
                stateOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                postalCode: {
                    label: string;
                    placeholder: string;
                };
                postalCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                addressLine: {
                    label: string;
                    placeholder: string;
                };
                addressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLine: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                phoneNumber: {
                    label: string;
                    placeholder: string;
                };
                phoneNumberOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                message: {
                    label: string;
                    placeholder: string;
                };
                messageOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
            };
            messageToApproverTemplate: string;
            successFormSubmitMessage: string;
            formSubmitButtonLabel: string;
            continueWithOTP: string;
            goToLoginButtonLabel: string;
            httpHandlers: {
                conflict: string;
            };
            messageToFailedToRegister: string;
        };
    };
};

declare const zh_TW: {
    userRegistration: {
        userRegistrationForm: {
            fields: {
                titleCode: {
                    label: string;
                    placeholder: string;
                };
                titleCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                companyName: {
                    label: string;
                    placeholder: string;
                };
                email: {
                    label: string;
                    placeholder: string;
                };
                city: {
                    label: string;
                    placeholder: string;
                };
                cityOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                country: {
                    label: string;
                    placeholder: string;
                };
                countryOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                state: {
                    label: string;
                    placeholder: string;
                };
                stateOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                postalCode: {
                    label: string;
                    placeholder: string;
                };
                postalCodeOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                addressLine: {
                    label: string;
                    placeholder: string;
                };
                addressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLine: {
                    label: string;
                    placeholder: string;
                };
                secondAddressLineOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                phoneNumber: {
                    label: string;
                    placeholder: string;
                };
                phoneNumberOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
                message: {
                    label: string;
                    placeholder: string;
                };
                messageOnOTPForm: {
                    label: string;
                    placeholder: string;
                };
            };
            messageToApproverTemplate: string;
            successFormSubmitMessage: string;
            formSubmitButtonLabel: string;
            continueWithOTP: string;
            goToLoginButtonLabel: string;
            httpHandlers: {
                conflict: string;
            };
            messageToFailedToRegister: string;
        };
    };
};

declare const organizationUserRegistrationTranslationChunksConfig: TranslationChunksConfig;

export { organizationUserRegistrationTranslationChunksConfig, cs as organizationUserRegistrationTranslationsCs, de as organizationUserRegistrationTranslationsDe, en as organizationUserRegistrationTranslationsEn, es as organizationUserRegistrationTranslationsEs, es_CO as organizationUserRegistrationTranslationsEs_CO, fr as organizationUserRegistrationTranslationsFr, hi as organizationUserRegistrationTranslationsHi, hu as organizationUserRegistrationTranslationsHu, id as organizationUserRegistrationTranslationsId, it as organizationUserRegistrationTranslationsIt, ja as organizationUserRegistrationTranslationsJa, ko as organizationUserRegistrationTranslationsKo, pl as organizationUserRegistrationTranslationsPl, pt as organizationUserRegistrationTranslationsPt, ru as organizationUserRegistrationTranslationsRu, zh as organizationUserRegistrationTranslationsZh, zh_TW as organizationUserRegistrationTranslationsZh_TW };
