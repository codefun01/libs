import { OrderHistoryList, Order } from '@spartacus/order/root';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import { ModuleWithProviders } from '@angular/core';
import { RoutingService, GlobalMessageService, B2BUnit, B2BUser, StateUtils, ErrorAction, UserIdService } from '@spartacus/core';
import { UserAccountFacade } from '@spartacus/user/account/root';
import * as i1 from '@ngrx/store';
import { MemoizedSelector, Store } from '@ngrx/store';
import { UnitOrderFacade } from '@spartacus/organization/unit-order/root';
import * as i2 from '@ngrx/effects';

declare abstract class UnitOrderAdapter {
    /**
     * Abstract method used to load order history for units.
     *
     * @param userId The `userId` for given user
     * @param pageSize
     * @param currentPage
     * @param filters
     * @param sort Sorting method
     */
    abstract loadUnitOrderHistory(userId: string, pageSize?: number, currentPage?: number, filters?: string, sort?: string): Observable<OrderHistoryList>;
    /**
     * Abstract method used to load order data.
     *
     * @param userId The `userId` for given user
     * @param orderCode The `orderCode` for given order
     */
    abstract loadUnitOrderDetail(userId: string, orderCode: string): Observable<Order>;
}

declare class UnitOrderConnector {
    protected adapter: UnitOrderAdapter;
    constructor(adapter: UnitOrderAdapter);
    getUnitOrderHistory(userId: string, pageSize?: number, currentPage?: number, filters?: string, sort?: string): Observable<OrderHistoryList>;
    getUnitOrderDetail(userId: string, orderCode: string): Observable<Order>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitOrderConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitOrderConnector>;
}

declare class UnitLevelOrdersViewerGuard {
    protected userAccountFacade: UserAccountFacade;
    protected routingService: RoutingService;
    protected globalMessageService: GlobalMessageService;
    constructor(userAccountFacade: UserAccountFacade, routingService: RoutingService, globalMessageService: GlobalMessageService);
    canActivate(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitLevelOrdersViewerGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitLevelOrdersViewerGuard>;
}

interface OrderHistoryQueryParams {
    currentPage?: number;
    sortCode?: string;
    filters?: string;
}

declare module '@spartacus/order/root' {
    interface OrderHistory {
        orgUnit?: B2BUnit;
        orgCustomer?: B2BUser;
    }
}

declare const LOAD_UNIT_ORDERS = "[Unit Order] Load Unit Orders";
declare const LOAD_UNIT_ORDERS_FAIL = "[Unit Order] Load Unit Orders Fail";
declare const LOAD_UNIT_ORDERS_SUCCESS = "[Unit Order] Load Unit Orders Success";
declare const CLEAR_UNIT_ORDERS = "[Unit Order] Clear Unit Orders";
declare const LOAD_ORDER_DETAILS = "[Unit Order] Load Unit Order Details";
declare const LOAD_ORDER_DETAILS_FAIL = "[Unit Order] Load Unit Order Details Fail";
declare const LOAD_ORDER_DETAILS_SUCCESS = "[Unit Order] Load Unit Order Details Success";
declare const CLEAR_ORDER_DETAILS = "[Unit Order] Clear Unit Order Details";
declare class LoadUnitOrders extends StateUtils.LoaderLoadAction {
    payload: {
        userId: string;
        pageSize?: number;
        currentPage?: number;
        filters?: string;
        sort?: string;
    };
    readonly type = "[Unit Order] Load Unit Orders";
    constructor(payload: {
        userId: string;
        pageSize?: number;
        currentPage?: number;
        filters?: string;
        sort?: string;
    });
}
declare class LoadUnitOrdersFail extends StateUtils.LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Unit Order] Load Unit Orders Fail";
    constructor(payload: any);
}
declare class LoadUnitOrdersSuccess extends StateUtils.LoaderSuccessAction {
    payload?: OrderHistoryList | undefined;
    readonly type = "[Unit Order] Load Unit Orders Success";
    constructor(payload?: OrderHistoryList | undefined);
}
declare class ClearUnitOrders extends StateUtils.LoaderResetAction {
    readonly type = "[Unit Order] Clear Unit Orders";
    constructor();
}
declare class LoadOrderDetails extends StateUtils.LoaderLoadAction {
    payload: {
        userId: string;
        orderCode: string;
    };
    readonly type = "[Unit Order] Load Unit Order Details";
    constructor(payload: {
        userId: string;
        orderCode: string;
    });
}
declare class LoadOrderDetailsFail extends StateUtils.LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Unit Order] Load Unit Order Details Fail";
    constructor(payload: any);
}
declare class LoadOrderDetailsSuccess extends StateUtils.LoaderSuccessAction {
    payload: Order;
    readonly type = "[Unit Order] Load Unit Order Details Success";
    constructor(payload: Order);
}
declare class ClearOrderDetails extends StateUtils.LoaderResetAction {
    readonly type = "[Unit Order] Clear Unit Order Details";
    constructor();
}
type UnitOrdersAction = LoadUnitOrders | LoadUnitOrdersFail | LoadUnitOrdersSuccess | ClearUnitOrders | LoadOrderDetails | LoadOrderDetailsFail | LoadOrderDetailsSuccess | ClearOrderDetails;

declare const unitOrderGroup_actions_d_CLEAR_ORDER_DETAILS: typeof CLEAR_ORDER_DETAILS;
declare const unitOrderGroup_actions_d_CLEAR_UNIT_ORDERS: typeof CLEAR_UNIT_ORDERS;
type unitOrderGroup_actions_d_ClearOrderDetails = ClearOrderDetails;
declare const unitOrderGroup_actions_d_ClearOrderDetails: typeof ClearOrderDetails;
type unitOrderGroup_actions_d_ClearUnitOrders = ClearUnitOrders;
declare const unitOrderGroup_actions_d_ClearUnitOrders: typeof ClearUnitOrders;
declare const unitOrderGroup_actions_d_LOAD_ORDER_DETAILS: typeof LOAD_ORDER_DETAILS;
declare const unitOrderGroup_actions_d_LOAD_ORDER_DETAILS_FAIL: typeof LOAD_ORDER_DETAILS_FAIL;
declare const unitOrderGroup_actions_d_LOAD_ORDER_DETAILS_SUCCESS: typeof LOAD_ORDER_DETAILS_SUCCESS;
declare const unitOrderGroup_actions_d_LOAD_UNIT_ORDERS: typeof LOAD_UNIT_ORDERS;
declare const unitOrderGroup_actions_d_LOAD_UNIT_ORDERS_FAIL: typeof LOAD_UNIT_ORDERS_FAIL;
declare const unitOrderGroup_actions_d_LOAD_UNIT_ORDERS_SUCCESS: typeof LOAD_UNIT_ORDERS_SUCCESS;
type unitOrderGroup_actions_d_LoadOrderDetails = LoadOrderDetails;
declare const unitOrderGroup_actions_d_LoadOrderDetails: typeof LoadOrderDetails;
type unitOrderGroup_actions_d_LoadOrderDetailsFail = LoadOrderDetailsFail;
declare const unitOrderGroup_actions_d_LoadOrderDetailsFail: typeof LoadOrderDetailsFail;
type unitOrderGroup_actions_d_LoadOrderDetailsSuccess = LoadOrderDetailsSuccess;
declare const unitOrderGroup_actions_d_LoadOrderDetailsSuccess: typeof LoadOrderDetailsSuccess;
type unitOrderGroup_actions_d_LoadUnitOrders = LoadUnitOrders;
declare const unitOrderGroup_actions_d_LoadUnitOrders: typeof LoadUnitOrders;
type unitOrderGroup_actions_d_LoadUnitOrdersFail = LoadUnitOrdersFail;
declare const unitOrderGroup_actions_d_LoadUnitOrdersFail: typeof LoadUnitOrdersFail;
type unitOrderGroup_actions_d_LoadUnitOrdersSuccess = LoadUnitOrdersSuccess;
declare const unitOrderGroup_actions_d_LoadUnitOrdersSuccess: typeof LoadUnitOrdersSuccess;
type unitOrderGroup_actions_d_UnitOrdersAction = UnitOrdersAction;
declare namespace unitOrderGroup_actions_d {
  export { unitOrderGroup_actions_d_CLEAR_ORDER_DETAILS as CLEAR_ORDER_DETAILS, unitOrderGroup_actions_d_CLEAR_UNIT_ORDERS as CLEAR_UNIT_ORDERS, unitOrderGroup_actions_d_ClearOrderDetails as ClearOrderDetails, unitOrderGroup_actions_d_ClearUnitOrders as ClearUnitOrders, unitOrderGroup_actions_d_LOAD_ORDER_DETAILS as LOAD_ORDER_DETAILS, unitOrderGroup_actions_d_LOAD_ORDER_DETAILS_FAIL as LOAD_ORDER_DETAILS_FAIL, unitOrderGroup_actions_d_LOAD_ORDER_DETAILS_SUCCESS as LOAD_ORDER_DETAILS_SUCCESS, unitOrderGroup_actions_d_LOAD_UNIT_ORDERS as LOAD_UNIT_ORDERS, unitOrderGroup_actions_d_LOAD_UNIT_ORDERS_FAIL as LOAD_UNIT_ORDERS_FAIL, unitOrderGroup_actions_d_LOAD_UNIT_ORDERS_SUCCESS as LOAD_UNIT_ORDERS_SUCCESS, unitOrderGroup_actions_d_LoadOrderDetails as LoadOrderDetails, unitOrderGroup_actions_d_LoadOrderDetailsFail as LoadOrderDetailsFail, unitOrderGroup_actions_d_LoadOrderDetailsSuccess as LoadOrderDetailsSuccess, unitOrderGroup_actions_d_LoadUnitOrders as LoadUnitOrders, unitOrderGroup_actions_d_LoadUnitOrdersFail as LoadUnitOrdersFail, unitOrderGroup_actions_d_LoadUnitOrdersSuccess as LoadUnitOrdersSuccess };
  export type { unitOrderGroup_actions_d_UnitOrdersAction as UnitOrdersAction };
}

declare const UNIT_ORDER_FEATURE = "unit order";
interface StateWithUnitOrder {
    [UNIT_ORDER_FEATURE]: UnitOrderState;
}
interface UnitOrderState {
    orders: StateUtils.LoaderState<OrderHistoryList>;
    orderDetail: StateUtils.LoaderState<Order>;
}

declare const getOrderState: MemoizedSelector<StateWithUnitOrder, UnitOrderState>;

declare const getOrdersState: MemoizedSelector<StateWithUnitOrder, StateUtils.LoaderState<OrderHistoryList>>;
declare const getOrdersLoaded: MemoizedSelector<StateWithUnitOrder, boolean>;
declare const getOrders: MemoizedSelector<StateWithUnitOrder, OrderHistoryList>;
declare const getOrderDetailState: MemoizedSelector<StateWithUnitOrder, StateUtils.LoaderState<Order>>;
declare const getOrderDetails: MemoizedSelector<StateWithUnitOrder, Order>;

declare const unitOrderGroup_selectors_d_getOrderDetailState: typeof getOrderDetailState;
declare const unitOrderGroup_selectors_d_getOrderDetails: typeof getOrderDetails;
declare const unitOrderGroup_selectors_d_getOrderState: typeof getOrderState;
declare const unitOrderGroup_selectors_d_getOrders: typeof getOrders;
declare const unitOrderGroup_selectors_d_getOrdersLoaded: typeof getOrdersLoaded;
declare const unitOrderGroup_selectors_d_getOrdersState: typeof getOrdersState;
declare namespace unitOrderGroup_selectors_d {
  export {
    unitOrderGroup_selectors_d_getOrderDetailState as getOrderDetailState,
    unitOrderGroup_selectors_d_getOrderDetails as getOrderDetails,
    unitOrderGroup_selectors_d_getOrderState as getOrderState,
    unitOrderGroup_selectors_d_getOrders as getOrders,
    unitOrderGroup_selectors_d_getOrdersLoaded as getOrdersLoaded,
    unitOrderGroup_selectors_d_getOrdersState as getOrdersState,
  };
}

declare class UnitOrderService implements UnitOrderFacade {
    protected store: Store<StateWithUnitOrder>;
    protected userIdService: UserIdService;
    protected routingService: RoutingService;
    constructor(store: Store<StateWithUnitOrder>, userIdService: UserIdService, routingService: RoutingService);
    /**
     * Returns order history list
     */
    getOrderHistoryList(pageSize: number): Observable<OrderHistoryList | undefined>;
    /**
     * Returns a loaded flag for order history list
     */
    getOrderHistoryListLoaded(): Observable<boolean>;
    /**
     * Retrieves an order list
     * @param pageSize page size
     * @param currentPage current page
     * @param sort sort
     */
    loadOrderList(pageSize: number, currentPage?: number, filters?: string, sort?: string): void;
    /**
     * Cleaning order list
     */
    clearOrderList(): void;
    /**
     * Returns an order's detail
     */
    getOrderDetails(): Observable<Order>;
    /**
     * Retrieves order's details
     *
     * @param orderCode an order code
     */
    loadOrderDetails(orderCode: string): void;
    /**
     * Clears order's details
     */
    clearOrderDetails(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitOrderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitOrderService>;
}

declare class UnitOrderStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitOrderStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitOrderStoreModule, never, [typeof i1.StoreFeatureModule, typeof i2.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitOrderStoreModule>;
}

declare class UnitOrderCoreModule {
    static forRoot(): ModuleWithProviders<UnitOrderCoreModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitOrderCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitOrderCoreModule, never, [typeof UnitOrderStoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitOrderCoreModule>;
}

export { UnitLevelOrdersViewerGuard, unitOrderGroup_actions_d as UnitOrderActions, UnitOrderAdapter, UnitOrderConnector, UnitOrderCoreModule, unitOrderGroup_selectors_d as UnitOrderSelectors, UnitOrderService };
export type { OrderHistoryQueryParams };
