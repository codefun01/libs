import { CmsConfig } from '@spartacus/core';
import * as i0 from '@angular/core';
import { Observable } from 'rxjs';

declare function defaultOrganizationUserRegistrationComponentsConfig(): CmsConfig;
declare class OrganizationUserRegistrationRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrganizationUserRegistrationRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrganizationUserRegistrationRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrganizationUserRegistrationRootModule>;
}

interface OrganizationUserRegistration {
    titleCode?: string;
    email: string;
    firstName: string;
    lastName: string;
    message?: string;
    verificationTokenId?: string;
    verificationTokenCode?: string;
}
interface OrganizationUserRegistrationForm extends OrganizationUserRegistration {
    companyName?: string;
    addressLine1?: string;
    addressLine2?: string;
    postalCode?: string;
    town?: string;
    region?: string;
    country?: string;
    phoneNumber?: string;
}

declare abstract class UserRegistrationFacade {
    /**
     * Register a new organization user.
     *
     * @param user as OrganizationUserRegistration
     */
    abstract registerUser(user: OrganizationUserRegistration): Observable<OrganizationUserRegistration>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserRegistrationFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserRegistrationFacade>;
}

declare const ORGANIZATION_USER_REGISTRATION_FEATURE = "organizationUserRegistration";

export { ORGANIZATION_USER_REGISTRATION_FEATURE, OrganizationUserRegistrationRootModule, UserRegistrationFacade, defaultOrganizationUserRegistrationComponentsConfig };
export type { OrganizationUserRegistration, OrganizationUserRegistrationForm };
