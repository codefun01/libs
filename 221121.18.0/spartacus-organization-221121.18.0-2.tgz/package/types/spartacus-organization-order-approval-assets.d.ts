import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    orderApproval: {
        orderApprovalDetails: {
            back: string;
            showForm_APPROVE: string;
            showForm_REJECT: string;
            form: {
                title_APPROVE: string;
                title_REJECT: string;
                submit_APPROVE: string;
                submit_REJECT: string;
                cancel: string;
                comment_APPROVE: {
                    label: string;
                    placeholder: string;
                };
                comment_REJECT: {
                    label: string;
                    placeholder: string;
                };
            };
            permissionResults: {
                header: string;
                permission: string;
                approver: string;
                status: string;
                approverComments: string;
                noApprovalComments: string;
                permissionType_B2BBudgetExceededPermission: string;
                permissionType_B2BOrderThresholdPermission: string;
                permissionType_B2BOrderThresholdTimespanPermission: string;
            };
        };
        orderApprovalList: {
            orderCode: string;
            POCode: string;
            placedBy: string;
            date: string;
            status: string;
            total: string;
            none: string;
            emptyList: string;
            orderApprovalList: string;
        };
        orderApprovalGlobal: {
            notification: {
                noSufficientPermissions: string;
            };
        };
    };
};

declare const de: {
    orderApproval: {
        orderApprovalDetails: {
            back: string;
            showForm_APPROVE: string;
            showForm_REJECT: string;
            form: {
                title_APPROVE: string;
                title_REJECT: string;
                submit_APPROVE: string;
                submit_REJECT: string;
                cancel: string;
                comment_APPROVE: {
                    label: string;
                    placeholder: string;
                };
                comment_REJECT: {
                    label: string;
                    placeholder: string;
                };
            };
            permissionResults: {
                header: string;
                permission: string;
                approver: string;
                status: string;
                approverComments: string;
                noApprovalComments: string;
                permissionType_B2BBudgetExceededPermission: string;
                permissionType_B2BOrderThresholdPermission: string;
                permissionType_B2BOrderThresholdTimespanPermission: string;
            };
        };
        orderApprovalList: {
            orderCode: string;
            POCode: string;
            placedBy: string;
            date: string;
            status: string;
            total: string;
            none: string;
            emptyList: string;
            orderApprovalList: string;
        };
        orderApprovalGlobal: {
            notification: {
                noSufficientPermissions: string;
            };
        };
    };
};

declare const en: {
    orderApproval: {
        orderApprovalDetails: {
            back: string;
            showForm_APPROVE: string;
            showForm_REJECT: string;
            form: {
                title_APPROVE: string;
                title_REJECT: string;
                submit_APPROVE: string;
                submit_REJECT: string;
                cancel: string;
                comment_APPROVE: {
                    label: string;
                    placeholder: string;
                };
                comment_REJECT: {
                    label: string;
                    placeholder: string;
                };
            };
            permissionResults: {
                header: string;
                permission: string;
                approver: string;
                status: string;
                approverComments: string;
                noApprovalComments: string;
                permissionType_B2BBudgetExceededPermission: string;
                permissionType_B2BOrderThresholdPermission: string;
                permissionType_B2BOrderThresholdTimespanPermission: string;
            };
        };
        orderApprovalList: {
            orderCode: string;
            POCode: string;
            placedBy: string;
            date: string;
            status: string;
            total: string;
            none: string;
            emptyList: string;
            orderApprovalList: string;
        };
        orderApprovalGlobal: {
            notification: {
                noSufficientPermissions: string;
            };
        };
    };
};

declare const es: {
    orderApproval: {
        orderApprovalDetails: {
            back: string;
            showForm_APPROVE: string;
            showForm_REJECT: string;
            form: {
                title_APPROVE: string;
                title_REJECT: string;
                submit_APPROVE: string;
                submit_REJECT: string;
                cancel: string;
                comment_APPROVE: {
                    label: string;
                    placeholder: string;
                };
                comment_REJECT: {
                    label: string;
                    placeholder: string;
                };
            };
            permissionResults: {
                header: string;
                permission: string;
                approver: string;
                status: string;
                approverComments: string;
                noApprovalComments: string;
                permissionType_B2BBudgetExceededPermission: string;
                permissionType_B2BOrderThresholdPermission: string;
                permissionType_B2BOrderThresholdTimespanPermission: string;
            };
        };
        orderApprovalList: {
            orderCode: string;
            POCode: string;
            placedBy: string;
            date: string;
            status: string;
            total: string;
            none: string;
            emptyList: string;
            orderApprovalList: string;
        };
        orderApprovalGlobal: {
            notification: {
                noSufficientPermissions: string;
            };
        };
    };
};

declare const es_CO: {
    orderApproval: {
        orderApprovalDetails: {
            back: string;
            showForm_APPROVE: string;
            showForm_REJECT: string;
            form: {
                title_APPROVE: string;
                title_REJECT: string;
                submit_APPROVE: string;
                submit_REJECT: string;
                cancel: string;
                comment_APPROVE: {
                    label: string;
                    placeholder: string;
                };
                comment_REJECT: {
                    label: string;
                    placeholder: string;
                };
            };
            permissionResults: {
                header: string;
                permission: string;
                approver: string;
                status: string;
                approverComments: string;
                noApprovalComments: string;
                permissionType_B2BBudgetExceededPermission: string;
                permissionType_B2BOrderThresholdPermission: string;
                permissionType_B2BOrderThresholdTimespanPermission: string;
            };
        };
        orderApprovalList: {
            orderCode: string;
            POCode: string;
            placedBy: string;
            date: string;
            status: string;
            total: string;
            none: string;
            emptyList: string;
            orderApprovalList: string;
        };
        orderApprovalGlobal: {
            notification: {
                noSufficientPermissions: string;
            };
        };
    };
};

declare const fr: {
    orderApproval: {
        orderApprovalDetails: {
            back: string;
            showForm_APPROVE: string;
            showForm_REJECT: string;
            form: {
                title_APPROVE: string;
                title_REJECT: string;
                submit_APPROVE: string;
                submit_REJECT: string;
                cancel: string;
                comment_APPROVE: {
                    label: string;
                    placeholder: string;
                };
                comment_REJECT: {
                    label: string;
                    placeholder: string;
                };
            };
            permissionResults: {
                header: string;
                permission: string;
                approver: string;
                status: string;
                approverComments: string;
                noApprovalComments: string;
                permissionType_B2BBudgetExceededPermission: string;
                permissionType_B2BOrderThresholdPermission: string;
                permissionType_B2BOrderThresholdTimespanPermission: string;
            };
        };
        orderApprovalList: {
            orderCode: string;
            POCode: string;
            placedBy: string;
            date: string;
            status: string;
            total: string;
            none: string;
            emptyList: string;
            orderApprovalList: string;
        };
        orderApprovalGlobal: {
            notification: {
                noSufficientPermissions: string;
            };
        };
    };
};

declare const hi: {
    orderApproval: {
        orderApprovalDetails: {
            back: string;
            showForm_APPROVE: string;
            showForm_REJECT: string;
            form: {
                title_APPROVE: string;
                title_REJECT: string;
                submit_APPROVE: string;
                submit_REJECT: string;
                cancel: string;
                comment_APPROVE: {
                    label: string;
                    placeholder: string;
                };
                comment_REJECT: {
                    label: string;
                    placeholder: string;
                };
            };
            permissionResults: {
                header: string;
                permission: string;
                approver: string;
                status: string;
                approverComments: string;
                noApprovalComments: string;
                permissionType_B2BBudgetExceededPermission: string;
                permissionType_B2BOrderThresholdPermission: string;
                permissionType_B2BOrderThresholdTimespanPermission: string;
            };
        };
        orderApprovalList: {
            orderCode: string;
            POCode: string;
            placedBy: string;
            date: string;
            status: string;
            total: string;
            none: string;
            emptyList: string;
            orderApprovalList: string;
        };
        orderApprovalGlobal: {
            notification: {
                noSufficientPermissions: string;
            };
        };
    };
};

declare const hu: {
    orderApproval: {
        orderApprovalDetails: {
            back: string;
            showForm_APPROVE: string;
            showForm_REJECT: string;
            form: {
                title_APPROVE: string;
                title_REJECT: string;
                submit_APPROVE: string;
                submit_REJECT: string;
                cancel: string;
                comment_APPROVE: {
                    label: string;
                    placeholder: string;
                };
                comment_REJECT: {
                    label: string;
                    placeholder: string;
                };
            };
            permissionResults: {
                header: string;
                permission: string;
                approver: string;
                status: string;
                approverComments: string;
                noApprovalComments: string;
                permissionType_B2BBudgetExceededPermission: string;
                permissionType_B2BOrderThresholdPermission: string;
                permissionType_B2BOrderThresholdTimespanPermission: string;
            };
        };
        orderApprovalList: {
            orderCode: string;
            POCode: string;
            placedBy: string;
            date: string;
            status: string;
            total: string;
            none: string;
            emptyList: string;
            orderApprovalList: string;
        };
        orderApprovalGlobal: {
            notification: {
                noSufficientPermissions: string;
            };
        };
    };
};

declare const id: {
    orderApproval: {
        orderApprovalDetails: {
            back: string;
            showForm_APPROVE: string;
            showForm_REJECT: string;
            form: {
                title_APPROVE: string;
                title_REJECT: string;
                submit_APPROVE: string;
                submit_REJECT: string;
                cancel: string;
                comment_APPROVE: {
                    label: string;
                    placeholder: string;
                };
                comment_REJECT: {
                    label: string;
                    placeholder: string;
                };
            };
            permissionResults: {
                header: string;
                permission: string;
                approver: string;
                status: string;
                approverComments: string;
                noApprovalComments: string;
                permissionType_B2BBudgetExceededPermission: string;
                permissionType_B2BOrderThresholdPermission: string;
                permissionType_B2BOrderThresholdTimespanPermission: string;
            };
        };
        orderApprovalList: {
            orderCode: string;
            POCode: string;
            placedBy: string;
            date: string;
            status: string;
            total: string;
            none: string;
            emptyList: string;
            orderApprovalList: string;
        };
        orderApprovalGlobal: {
            notification: {
                noSufficientPermissions: string;
            };
        };
    };
};

declare const it: {
    orderApproval: {
        orderApprovalDetails: {
            back: string;
            showForm_APPROVE: string;
            showForm_REJECT: string;
            form: {
                title_APPROVE: string;
                title_REJECT: string;
                submit_APPROVE: string;
                submit_REJECT: string;
                cancel: string;
                comment_APPROVE: {
                    label: string;
                    placeholder: string;
                };
                comment_REJECT: {
                    label: string;
                    placeholder: string;
                };
            };
            permissionResults: {
                header: string;
                permission: string;
                approver: string;
                status: string;
                approverComments: string;
                noApprovalComments: string;
                permissionType_B2BBudgetExceededPermission: string;
                permissionType_B2BOrderThresholdPermission: string;
                permissionType_B2BOrderThresholdTimespanPermission: string;
            };
        };
        orderApprovalList: {
            orderCode: string;
            POCode: string;
            placedBy: string;
            date: string;
            status: string;
            total: string;
            none: string;
            emptyList: string;
            orderApprovalList: string;
        };
        orderApprovalGlobal: {
            notification: {
                noSufficientPermissions: string;
            };
        };
    };
};

declare const ja: {
    orderApproval: {
        orderApprovalDetails: {
            back: string;
            showForm_APPROVE: string;
            showForm_REJECT: string;
            form: {
                title_APPROVE: string;
                title_REJECT: string;
                submit_APPROVE: string;
                submit_REJECT: string;
                cancel: string;
                comment_APPROVE: {
                    label: string;
                    placeholder: string;
                };
                comment_REJECT: {
                    label: string;
                    placeholder: string;
                };
            };
            permissionResults: {
                header: string;
                permission: string;
                approver: string;
                status: string;
                approverComments: string;
                noApprovalComments: string;
                permissionType_B2BBudgetExceededPermission: string;
                permissionType_B2BOrderThresholdPermission: string;
                permissionType_B2BOrderThresholdTimespanPermission: string;
            };
        };
        orderApprovalList: {
            orderCode: string;
            POCode: string;
            placedBy: string;
            date: string;
            status: string;
            total: string;
            none: string;
            emptyList: string;
            orderApprovalList: string;
        };
        orderApprovalGlobal: {
            notification: {
                noSufficientPermissions: string;
            };
        };
    };
};

declare const ko: {
    orderApproval: {
        orderApprovalDetails: {
            back: string;
            showForm_APPROVE: string;
            showForm_REJECT: string;
            form: {
                title_APPROVE: string;
                title_REJECT: string;
                submit_APPROVE: string;
                submit_REJECT: string;
                cancel: string;
                comment_APPROVE: {
                    label: string;
                    placeholder: string;
                };
                comment_REJECT: {
                    label: string;
                    placeholder: string;
                };
            };
            permissionResults: {
                header: string;
                permission: string;
                approver: string;
                status: string;
                approverComments: string;
                noApprovalComments: string;
                permissionType_B2BBudgetExceededPermission: string;
                permissionType_B2BOrderThresholdPermission: string;
                permissionType_B2BOrderThresholdTimespanPermission: string;
            };
        };
        orderApprovalList: {
            orderCode: string;
            POCode: string;
            placedBy: string;
            date: string;
            status: string;
            total: string;
            none: string;
            emptyList: string;
            orderApprovalList: string;
        };
        orderApprovalGlobal: {
            notification: {
                noSufficientPermissions: string;
            };
        };
    };
};

declare const pl: {
    orderApproval: {
        orderApprovalDetails: {
            back: string;
            showForm_APPROVE: string;
            showForm_REJECT: string;
            form: {
                title_APPROVE: string;
                title_REJECT: string;
                submit_APPROVE: string;
                submit_REJECT: string;
                cancel: string;
                comment_APPROVE: {
                    label: string;
                    placeholder: string;
                };
                comment_REJECT: {
                    label: string;
                    placeholder: string;
                };
            };
            permissionResults: {
                header: string;
                permission: string;
                approver: string;
                status: string;
                approverComments: string;
                noApprovalComments: string;
                permissionType_B2BBudgetExceededPermission: string;
                permissionType_B2BOrderThresholdPermission: string;
                permissionType_B2BOrderThresholdTimespanPermission: string;
            };
        };
        orderApprovalList: {
            orderCode: string;
            POCode: string;
            placedBy: string;
            date: string;
            status: string;
            total: string;
            none: string;
            emptyList: string;
            orderApprovalList: string;
        };
        orderApprovalGlobal: {
            notification: {
                noSufficientPermissions: string;
            };
        };
    };
};

declare const pt: {
    orderApproval: {
        orderApprovalDetails: {
            back: string;
            showForm_APPROVE: string;
            showForm_REJECT: string;
            form: {
                title_APPROVE: string;
                title_REJECT: string;
                submit_APPROVE: string;
                submit_REJECT: string;
                cancel: string;
                comment_APPROVE: {
                    label: string;
                    placeholder: string;
                };
                comment_REJECT: {
                    label: string;
                    placeholder: string;
                };
            };
            permissionResults: {
                header: string;
                permission: string;
                approver: string;
                status: string;
                approverComments: string;
                noApprovalComments: string;
                permissionType_B2BBudgetExceededPermission: string;
                permissionType_B2BOrderThresholdPermission: string;
                permissionType_B2BOrderThresholdTimespanPermission: string;
            };
        };
        orderApprovalList: {
            orderCode: string;
            POCode: string;
            placedBy: string;
            date: string;
            status: string;
            total: string;
            none: string;
            emptyList: string;
            orderApprovalList: string;
        };
        orderApprovalGlobal: {
            notification: {
                noSufficientPermissions: string;
            };
        };
    };
};

declare const ru: {
    orderApproval: {
        orderApprovalDetails: {
            back: string;
            showForm_APPROVE: string;
            showForm_REJECT: string;
            form: {
                title_APPROVE: string;
                title_REJECT: string;
                submit_APPROVE: string;
                submit_REJECT: string;
                cancel: string;
                comment_APPROVE: {
                    label: string;
                    placeholder: string;
                };
                comment_REJECT: {
                    label: string;
                    placeholder: string;
                };
            };
            permissionResults: {
                header: string;
                permission: string;
                approver: string;
                status: string;
                approverComments: string;
                noApprovalComments: string;
                permissionType_B2BBudgetExceededPermission: string;
                permissionType_B2BOrderThresholdPermission: string;
                permissionType_B2BOrderThresholdTimespanPermission: string;
            };
        };
        orderApprovalList: {
            orderCode: string;
            POCode: string;
            placedBy: string;
            date: string;
            status: string;
            total: string;
            none: string;
            emptyList: string;
            orderApprovalList: string;
        };
        orderApprovalGlobal: {
            notification: {
                noSufficientPermissions: string;
            };
        };
    };
};

declare const zh: {
    orderApproval: {
        orderApprovalDetails: {
            back: string;
            showForm_APPROVE: string;
            showForm_REJECT: string;
            form: {
                title_APPROVE: string;
                title_REJECT: string;
                submit_APPROVE: string;
                submit_REJECT: string;
                cancel: string;
                comment_APPROVE: {
                    label: string;
                    placeholder: string;
                };
                comment_REJECT: {
                    label: string;
                    placeholder: string;
                };
            };
            permissionResults: {
                header: string;
                permission: string;
                approver: string;
                status: string;
                approverComments: string;
                noApprovalComments: string;
                permissionType_B2BBudgetExceededPermission: string;
                permissionType_B2BOrderThresholdPermission: string;
                permissionType_B2BOrderThresholdTimespanPermission: string;
            };
        };
        orderApprovalList: {
            orderCode: string;
            POCode: string;
            placedBy: string;
            date: string;
            status: string;
            total: string;
            none: string;
            emptyList: string;
            orderApprovalList: string;
        };
        orderApprovalGlobal: {
            notification: {
                noSufficientPermissions: string;
            };
        };
    };
};

declare const zh_TW: {
    orderApproval: {
        orderApprovalDetails: {
            back: string;
            showForm_APPROVE: string;
            showForm_REJECT: string;
            form: {
                title_APPROVE: string;
                title_REJECT: string;
                submit_APPROVE: string;
                submit_REJECT: string;
                cancel: string;
                comment_APPROVE: {
                    label: string;
                    placeholder: string;
                };
                comment_REJECT: {
                    label: string;
                    placeholder: string;
                };
            };
            permissionResults: {
                header: string;
                permission: string;
                approver: string;
                status: string;
                approverComments: string;
                noApprovalComments: string;
                permissionType_B2BBudgetExceededPermission: string;
                permissionType_B2BOrderThresholdPermission: string;
                permissionType_B2BOrderThresholdTimespanPermission: string;
            };
        };
        orderApprovalList: {
            orderCode: string;
            POCode: string;
            placedBy: string;
            date: string;
            status: string;
            total: string;
            none: string;
            emptyList: string;
            orderApprovalList: string;
        };
        orderApprovalGlobal: {
            notification: {
                noSufficientPermissions: string;
            };
        };
    };
};

declare const orderApprovalTranslationChunksConfig: TranslationChunksConfig;

export { orderApprovalTranslationChunksConfig, cs as orderApprovalTranslationsCs, de as orderApprovalTranslationsDe, en as orderApprovalTranslationsEn, es as orderApprovalTranslationsEs, es_CO as orderApprovalTranslationsEs_CO, fr as orderApprovalTranslationsFr, hi as orderApprovalTranslationsHi, hu as orderApprovalTranslationsHu, id as orderApprovalTranslationsId, it as orderApprovalTranslationsIt, ja as orderApprovalTranslationsJa, ko as orderApprovalTranslationsKo, pl as orderApprovalTranslationsPl, pt as orderApprovalTranslationsPt, ru as orderApprovalTranslationsRu, zh as orderApprovalTranslationsZh, zh_TW as orderApprovalTranslationsZh_TW };
