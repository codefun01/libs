import * as i0 from '@angular/core';
import { OnDestroy, OnInit, ChangeDetectorRef, ElementRef } from '@angular/core';
import * as i3 from '@angular/router';
import * as i1 from '@angular/common';
import * as i2 from '@angular/forms';
import { FormBuilder, FormGroup, AbstractControl, UntypedFormGroup } from '@angular/forms';
import * as i4 from '@spartacus/core';
import { UserAddressService, TranslationService, GlobalMessageService, AuthConfigService, RoutingService, Country, Region, WindowRef } from '@spartacus/core';
import * as i5 from '@spartacus/storefront';
import { LaunchDialogService } from '@spartacus/storefront';
import * as i6 from '@ng-select/ng-select';
import { UserRegisterFacade, Title } from '@spartacus/user/profile/root';
import { Observable, BehaviorSubject, Subscription, Subject } from 'rxjs';
import { UserRegistrationFacade, OrganizationUserRegistration } from '@spartacus/organization/user-registration/root';
import { VerificationTokenFacade, VerificationToken, VerificationTokenCreation } from '@spartacus/user/account/root';

declare class UserRegistrationFormService {
    protected userRegisterFacade: UserRegisterFacade;
    protected userAddressService: UserAddressService;
    protected organizationUserRegistrationFacade: UserRegistrationFacade;
    protected translationService: TranslationService;
    protected globalMessageService: GlobalMessageService;
    protected authConfigService: AuthConfigService;
    protected routingService: RoutingService;
    protected formBuilder: FormBuilder;
    private _form;
    private featureToggles;
    protected buildForm(): FormGroup;
    get form(): FormGroup;
    get countryControl(): AbstractControl | null;
    get regionControl(): AbstractControl | null;
    constructor(userRegisterFacade: UserRegisterFacade, userAddressService: UserAddressService, organizationUserRegistrationFacade: UserRegistrationFacade, translationService: TranslationService, globalMessageService: GlobalMessageService, authConfigService: AuthConfigService, routingService: RoutingService, formBuilder: FormBuilder);
    /**
     * Gets all title codes.
     */
    getTitles(): Observable<Title[]>;
    /**
     * Gets all countries list.
     */
    getCountries(): Observable<Country[]>;
    /**
     * Gets all regions list for specific selected country.
     */
    getRegions(): Observable<Region[]>;
    /**
     * Takes form values and builds custom message content.
     */
    protected buildMessageContent(form: FormGroup): Observable<string>;
    /**
     * Displays confirmation global message.
     */
    protected displayGlobalMessage(): void;
    /**
     * Redirects the user back to the login page.
     *
     * This only happens in case of the `ResourceOwnerPasswordFlow` OAuth flow and authorizationCodeFlowByDefault.
     *
     */
    protected redirectToLogin(): void;
    /**
     * Registers new organization user.
     */
    registerUser(form: FormGroup): Observable<OrganizationUserRegistration>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserRegistrationFormService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserRegistrationFormService>;
}

declare class UserRegistrationFormComponent implements OnDestroy {
    protected userRegistrationFormService: UserRegistrationFormService;
    titles$: Observable<Title[]>;
    countries$: Observable<Country[]>;
    regions$: Observable<Region[]>;
    registerForm: FormGroup;
    isLoading$: BehaviorSubject<boolean>;
    protected subscriptions: Subscription;
    protected globalMessageService: GlobalMessageService | null;
    constructor(userRegistrationFormService: UserRegistrationFormService);
    submit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserRegistrationFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserRegistrationFormComponent, "cx-user-registration-form", never, {}, {}, never, never, true, never>;
}

declare class UserRegistrationFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserRegistrationFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserRegistrationFormModule, never, [typeof i1.CommonModule, typeof i2.ReactiveFormsModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i5.SpinnerModule, typeof i5.FormErrorsModule, typeof i5.FormRequiredAsterisksComponent, typeof i5.FormRequiredLegendComponent, typeof i6.NgSelectModule, typeof i5.NgSelectA11yModule, typeof i4.ConfigModule, typeof i4.FeaturesConfigModule, typeof UserRegistrationFormComponent], [typeof UserRegistrationFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserRegistrationFormModule>;
}

declare class UserRegistrationOTPFormComponent {
    protected routingService: RoutingService;
    protected verificationTokenFacade: VerificationTokenFacade;
    protected winRef: WindowRef;
    protected globalMessageService: GlobalMessageService | null;
    protected userRegistrationFormService: UserRegistrationFormService;
    protected busy$: BehaviorSubject<boolean>;
    titles$: Observable<Title[]>;
    countries$: Observable<Country[]>;
    regions$: Observable<Region[]>;
    registerForm: FormGroup;
    isLoading$: BehaviorSubject<boolean>;
    onSubmit(): void;
    protected goToVerificationTokenForm(verificationToken: VerificationToken): void;
    protected collectDataFromRegistrationForm(): VerificationTokenCreation;
    protected onCreateVerificationTokenComplete(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserRegistrationOTPFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserRegistrationOTPFormComponent, "cx-user-registration-form", never, {}, {}, never, never, true, never>;
}

declare class UserRegistrationOTPFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserRegistrationOTPFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserRegistrationOTPFormModule, never, [typeof i1.CommonModule, typeof i2.ReactiveFormsModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i5.SpinnerModule, typeof i5.FormErrorsModule, typeof i6.NgSelectModule, typeof i5.NgSelectA11yModule, typeof i4.ConfigModule, typeof i4.FeaturesConfigModule, typeof i5.FormRequiredAsterisksComponent, typeof UserRegistrationOTPFormComponent], [typeof UserRegistrationOTPFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserRegistrationOTPFormModule>;
}

declare class RegisterVerificationTokenFormComponentService {
    private featureToggles;
    protected globalMessage: GlobalMessageService;
    protected formBuilder: FormBuilder;
    protected organizationUserRegistrationFacade: UserRegistrationFacade;
    protected translationService: TranslationService;
    protected authConfigService: AuthConfigService;
    protected routingService: RoutingService;
    form: UntypedFormGroup;
    protected buildMessageContent(formValue: {
        [key: string]: any;
    }): Observable<string>;
    /**
     * Redirects the user back to the login page.
     *
     * This only happens in case of the `ResourceOwnerPasswordFlow` OAuth flow and authorizationCodeFlowByDefault.
     */
    protected redirectToLogin(): void;
    displayMessage(key: string, params: Object): void;
    registerUser(formValue: {
        [key: string]: any;
    }): Observable<OrganizationUserRegistration>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RegisterVerificationTokenFormComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RegisterVerificationTokenFormComponentService>;
}

declare class RegisterVerificationTokenFormComponent implements OnInit {
    private featureToggles;
    protected service: RegisterVerificationTokenFormComponentService;
    protected launchDialogService: LaunchDialogService;
    protected cdr: ChangeDetectorRef;
    protected routingService: RoutingService;
    protected verificationTokenFacade: VerificationTokenFacade;
    form: UntypedFormGroup;
    isUpdating$: Subject<boolean>;
    waitTime: number;
    protected subscriptions: Subscription;
    style: boolean;
    element: ElementRef;
    resendLink: ElementRef;
    tokenId: string;
    registerData: UntypedFormGroup;
    target: string;
    isResendDisabled: boolean;
    errorStatus: number;
    upToRateLimit: boolean;
    waitTimeForRateLimit: number;
    ngOnInit(): void;
    onSubmit(): void;
    resendOTP(): void;
    startWaitTimeInterval(): void;
    startRateLimitWaitTimeInterval(): void;
    openInfoDailog(): void;
    onOpenInfoDailogKeyDown(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RegisterVerificationTokenFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RegisterVerificationTokenFormComponent, "cx-verification-token-form", never, {}, {}, never, never, true, never>;
}

declare class RegisterVerificationTokenFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RegisterVerificationTokenFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RegisterVerificationTokenFormModule, never, [typeof i1.CommonModule, typeof i2.FormsModule, typeof i5.KeyboardFocusModule, typeof i2.ReactiveFormsModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof i5.IconModule, typeof i4.I18nModule, typeof i5.FormErrorsModule, typeof i5.SpinnerModule, typeof i4.FeaturesConfigModule, typeof i5.FormRequiredAsterisksComponent, typeof RegisterVerificationTokenFormComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RegisterVerificationTokenFormModule>;
}

declare class UserRegistrationComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserRegistrationComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserRegistrationComponentsModule, never, [typeof i3.RouterModule, typeof UserRegistrationFormModule, typeof UserRegistrationOTPFormModule, typeof RegisterVerificationTokenFormModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserRegistrationComponentsModule>;
}

export { RegisterVerificationTokenFormComponent, RegisterVerificationTokenFormComponentService, RegisterVerificationTokenFormModule, UserRegistrationComponentsModule, UserRegistrationFormComponent, UserRegistrationFormModule, UserRegistrationFormService, UserRegistrationOTPFormComponent, UserRegistrationOTPFormModule };
