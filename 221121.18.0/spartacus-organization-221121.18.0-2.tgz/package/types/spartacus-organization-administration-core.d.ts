import * as i0 from '@angular/core';
import { ModuleWithProviders, InjectionToken } from '@angular/core';
import * as i1 from '@ngrx/store';
import { Store, Action, MemoizedSelector } from '@ngrx/store';
import * as i2 from '@ngrx/effects';
import { Currency, OrderApprovalPermissionType, B2BUnit, B2BUser, B2BUserRole, SearchConfig, EntitiesModel, Converter, CostCenter, B2BApprovalProcess, Address, RoutingService, GlobalMessageService, StateUtils, ListModel, UserIdService, B2BUserRight, ErrorAction, PageMetaResolver, PageBreadcrumbResolver, PageTitleResolver, PageDescriptionResolver, PageRobotsResolver, ContentPageMetaResolver, TranslationService, SemanticPathService, PageType, PageRobotsMeta, BreadcrumbMeta, HttpErrorHandler, HttpResponseStatus, ErrorModel, Priority } from '@spartacus/core';
import { Observable } from 'rxjs';
import { UserAccountFacade } from '@spartacus/user/account/root';
import { Router, UrlTree } from '@angular/router';
import { HttpErrorResponse, HttpRequest } from '@angular/common/http';

declare class OrganizationPageMetaModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrganizationPageMetaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrganizationPageMetaModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrganizationPageMetaModule>;
}

declare class OrganizationStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrganizationStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrganizationStoreModule, never, [typeof i1.StoreFeatureModule, typeof i2.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrganizationStoreModule>;
}

declare class OrganizationsGuardsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrganizationsGuardsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrganizationsGuardsModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrganizationsGuardsModule>;
}

declare class AdministrationCoreModule {
    static forRoot(): ModuleWithProviders<AdministrationCoreModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AdministrationCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AdministrationCoreModule, never, [typeof OrganizationPageMetaModule, typeof OrganizationStoreModule, typeof OrganizationsGuardsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AdministrationCoreModule>;
}

declare enum Period {
    DAY = "DAY",
    WEEK = "WEEK",
    MONTH = "MONTH",
    QUARTER = "QUARTER",
    YEAR = "YEAR"
}
interface Permission {
    active?: boolean;
    code?: string;
    currency?: Currency;
    orderApprovalPermissionType?: OrderApprovalPermissionType;
    orgUnit?: B2BUnit;
    periodRange?: Period;
    selected?: boolean;
    threshold?: number;
}

interface UserGroup {
    members?: B2BUser[];
    membersCount?: number;
    name?: string;
    orgUnit?: B2BUnit;
    permissions?: Permission[];
    roles?: B2BUserRole[];
    selected?: boolean;
    subGroups?: UserGroup[];
    uid?: string;
}

declare abstract class B2BUserAdapter {
    /**
     * Abstract method used to load orgUnitCustomerManagement's details data.
     * orgUnitCustomer's data can be loaded from alternative sources, as long as the structure
     * converts to the `B2BUser`.
     *
     * @param userId The `userId` for given orgUnitCustomerManagement
     * @param orgCustomerId The `orgUnitCustomerId` for given orgUnitCustomerManagement
     */
    abstract load(userId: string, orgCustomerId: string): Observable<B2BUser>;
    abstract loadList(userId: string, params?: SearchConfig): Observable<EntitiesModel<B2BUser>>;
    abstract create(userId: string, orgCustomer: B2BUser): Observable<B2BUser>;
    abstract update(userId: string, orgCustomerId: string, orgCustomer: B2BUser): Observable<B2BUser>;
    abstract loadApprovers(userId: string, orgCustomerId: string, params?: SearchConfig): Observable<EntitiesModel<B2BUser>>;
    abstract assignApprover(userId: string, orgCustomerId: string, approverId: string): Observable<any>;
    abstract unassignApprover(userId: string, orgCustomerId: string, approverId: string): Observable<any>;
    abstract loadPermissions(userId: string, orgCustomerId: string, params?: SearchConfig): Observable<EntitiesModel<Permission>>;
    abstract assignPermission(userId: string, orgCustomerId: string, permissionId: string): Observable<any>;
    abstract unassignPermission(userId: string, orgCustomerId: string, permissionId: string): Observable<any>;
    abstract loadUserGroups(userId: string, orgCustomerId: string, params?: SearchConfig): Observable<EntitiesModel<UserGroup>>;
    abstract assignUserGroup(userId: string, orgCustomerId: string, userGroupId: string): Observable<any>;
    abstract unassignUserGroup(userId: string, orgCustomerId: string, userGroupId: string): Observable<any>;
}

declare class B2BUserConnector {
    protected adapter: B2BUserAdapter;
    constructor(adapter: B2BUserAdapter);
    get(userId: string, orgUnitCustomerId: string): Observable<B2BUser>;
    create(userId: string, orgCustomer: B2BUser): Observable<B2BUser>;
    update(userId: string, orgCustomerId: string, orgCustomer: B2BUser): Observable<B2BUser>;
    getList(userId: string, params?: SearchConfig): Observable<EntitiesModel<B2BUser>>;
    getApprovers(userId: string, orgUnitCustomerId: string, params?: SearchConfig): Observable<EntitiesModel<B2BUser>>;
    assignApprover(userId: string, orgCustomerId: string, approverId: string): Observable<any>;
    unassignApprover(userId: string, orgCustomerId: string, approverId: string): Observable<any>;
    getPermissions(userId: string, orgUnitCustomerId: string, params?: SearchConfig): Observable<EntitiesModel<Permission>>;
    assignPermission(userId: string, orgCustomerId: string, permissionId: string): Observable<any>;
    unassignPermission(userId: string, orgCustomerId: string, permissionId: string): Observable<any>;
    getUserGroups(userId: string, orgUnitCustomerId: string, params?: SearchConfig): Observable<EntitiesModel<UserGroup>>;
    assignUserGroup(userId: string, orgCustomerId: string, userGroupId: string): Observable<any>;
    unassignUserGroup(userId: string, orgCustomerId: string, userGroupId: string): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<B2BUserConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<B2BUserConnector>;
}

declare const B2B_USER_NORMALIZER: InjectionToken<Converter<any, B2BUser>>;
declare const B2B_USER_SERIALIZER: InjectionToken<Converter<B2BUser, any>>;
declare const B2B_USERS_NORMALIZER: InjectionToken<Converter<any, EntitiesModel<B2BUser>>>;

interface Budget {
    active?: boolean;
    budget?: number;
    code?: string;
    currency?: Currency;
    endDate?: string;
    startDate?: string;
    name?: string;
    orgUnit?: B2BUnit;
    costCenters?: CostCenter[];
    selected?: boolean;
}

declare abstract class BudgetAdapter {
    /**
     * Abstract method used to load budgetManagement's details data.
     * Budget's data can be loaded from alternative sources, as long as the structure
     * converts to the `Budget`.
     *
     * @param userId The `userId` for given budgetManagement
     * @param budgetCode The `budgetCode` for given budgetManagement
     */
    abstract load(userId: string, budgetCode: string): Observable<Budget>;
    abstract loadList(userId: string, params?: SearchConfig): Observable<EntitiesModel<Budget>>;
    abstract create(userId: string, budget: Budget): Observable<Budget>;
    abstract update(userId: string, budgetCode: string, budget: Budget): Observable<Budget>;
}

declare class BudgetConnector {
    protected adapter: BudgetAdapter;
    constructor(adapter: BudgetAdapter);
    get(userId: string, budgetCode: string): Observable<Budget>;
    getList(userId: string, params?: SearchConfig): Observable<EntitiesModel<Budget>>;
    create(userId: string, budget: Budget): Observable<Budget>;
    update(userId: string, budgetCode: string, budget: Budget): Observable<Budget>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BudgetConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BudgetConnector>;
}

declare const BUDGET_NORMALIZER: InjectionToken<Converter<any, Budget>>;
declare const BUDGETS_NORMALIZER: InjectionToken<Converter<any, EntitiesModel<Budget>>>;
declare const BUDGET_SERIALIZER: InjectionToken<Converter<Budget, any>>;

declare abstract class CostCenterAdapter {
    /**
     * Abstract method used to load costCenterManagement's details data.
     * CostCenter's data can be loaded from alternative sources, as long as the structure
     * converts to the `CostCenter`.
     *
     * @param userId The `userId` for given costCenterManagement
     * @param costCenterCode The `costCenterCode` for given costCenterManagement
     */
    abstract load(userId: string, costCenterCode: string): Observable<CostCenter>;
    abstract loadList(userId: string, params?: SearchConfig): Observable<EntitiesModel<CostCenter>>;
    abstract create(userId: string, costCenter: CostCenter): Observable<CostCenter>;
    abstract update(userId: string, costCenterCode: string, costCenter: CostCenter): Observable<CostCenter>;
    abstract loadBudgets(userId: string, costCenterCode: string, params?: SearchConfig): Observable<EntitiesModel<Budget>>;
    abstract assignBudget(userId: string, costCenterCode: string, budgetCode: string): Observable<any>;
    abstract unassignBudget(userId: string, costCenterCode: string, budgetCode: string): Observable<any>;
}

declare class CostCenterConnector {
    protected adapter: CostCenterAdapter;
    constructor(adapter: CostCenterAdapter);
    get(userId: string, costCenterCode: string): Observable<CostCenter>;
    getList(userId: string, params?: SearchConfig): Observable<EntitiesModel<CostCenter>>;
    create(userId: string, costCenter: CostCenter): Observable<CostCenter>;
    update(userId: string, costCenterCode: string, costCenter: CostCenter): Observable<CostCenter>;
    getBudgets(userId: string, costCenterCode: string, params?: SearchConfig): Observable<EntitiesModel<Budget>>;
    assignBudget(userId: string, costCenterCode: string, budgetCode: string): Observable<any>;
    unassignBudget(userId: string, costCenterCode: string, budgetCode: string): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CostCenterConnector>;
}

interface B2BUnitNode {
    active?: boolean;
    children?: B2BUnitNode[];
    id?: string;
    name?: string;
    parent?: string;
}
interface B2BUnitTreeNode extends B2BUnitNode {
    expanded: boolean;
    depthLevel: number;
    count: number;
    uid: string;
}

declare abstract class OrgUnitAdapter {
    /**
     * Abstract method used to load orgUnit's details data.
     * B2BUnitNode's data can be loaded from alternative sources, as long as the structure
     * converts to the `B2BUnitNode`.
     *
     * @param userId The `userId` for given orgUnit
     * @param orgUnitId The `orgUnitId` for given orgUnit
     */
    abstract load(userId: string, orgUnitId: string): Observable<B2BUnit>;
    abstract loadList(userId: string): Observable<B2BUnitNode[]>;
    abstract create(userId: string, orgUnit: B2BUnit): Observable<B2BUnit>;
    abstract update(userId: string, orgUnitId: string, orgUnit: B2BUnit): Observable<B2BUnit>;
    abstract loadApprovalProcesses(userId: string): Observable<B2BApprovalProcess[]>;
    abstract loadTree(userId: string): Observable<B2BUnitNode>;
    abstract loadUsers(userId: string, orgUnitId: string, roleId: string, params?: SearchConfig): Observable<EntitiesModel<B2BUser>>;
    abstract assignRole(userId: string, orgCustomerId: string, roleId: string): Observable<any>;
    abstract unassignRole(userId: string, orgCustomerId: string, roleId: string): Observable<any>;
    abstract assignApprover(userId: string, orgUnitId: string, orgCustomerId: string, roleId: string): Observable<any>;
    abstract unassignApprover(userId: string, orgUnitId: string, orgCustomerId: string, roleId: string): Observable<any>;
    abstract loadAddresses(userId: string, orgUnitId: string): Observable<EntitiesModel<Address>>;
    abstract createAddress(userId: string, orgUnitId: string, address: Address): Observable<Address>;
    abstract updateAddress(userId: string, orgUnitId: string, addressId: string, address: Address): Observable<Address>;
    abstract deleteAddress(userId: string, orgUnitId: string, addressId: string): Observable<any>;
}

declare class OrgUnitConnector {
    protected adapter: OrgUnitAdapter;
    constructor(adapter: OrgUnitAdapter);
    get(userId: string, orgUnitId: string): Observable<B2BUnit>;
    create(userId: string, orgUnit: B2BUnit): Observable<B2BUnit>;
    update(userId: string, orgUnitId: string, orgUnit: B2BUnit): Observable<B2BUnit>;
    getList(userId: string): Observable<B2BUnitNode[]>;
    getApprovalProcesses(userId: string): Observable<B2BApprovalProcess[]>;
    getTree(userId: string): Observable<B2BUnitNode>;
    getUsers(userId: string, orgUnitId: string, roleId: string, params?: SearchConfig): Observable<EntitiesModel<B2BUser>>;
    assignRole(userId: string, orgCustomerId: string, roleId: string): Observable<any>;
    unassignRole(userId: string, orgCustomerId: string, roleId: string): Observable<any>;
    assignApprover(userId: string, orgUnitId: string, orgCustomerId: string, roleId: string): Observable<any>;
    unassignApprover(userId: string, orgUnitId: string, orgCustomerId: string, roleId: string): Observable<any>;
    getAddresses(userId: string, orgUnitId: string): Observable<EntitiesModel<Address>>;
    createAddress(userId: string, orgUnitId: string, address: Address): Observable<Address>;
    updateAddress(userId: string, orgUnitId: string, addressId: string, address: Address): Observable<Address>;
    deleteAddress(userId: string, orgUnitId: string, addressId: string): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrgUnitConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrgUnitConnector>;
}

declare const B2BUNIT_NODE_NORMALIZER: InjectionToken<Converter<any, B2BUnitNode>>;
declare const B2BUNIT_NODE_LIST_NORMALIZER: InjectionToken<Converter<any, B2BUnitNode[]>>;
declare const B2BUNIT_NORMALIZER: InjectionToken<Converter<any, B2BUnit>>;
declare const B2BUNIT_SERIALIZER: InjectionToken<Converter<B2BUnit, any>>;
declare const B2BUNIT_APPROVAL_PROCESSES_NORMALIZER: InjectionToken<Converter<any, B2BApprovalProcess[]>>;

declare abstract class PermissionAdapter {
    /**
     * Abstract method used to load permissionManagement's details data.
     * Permission's data can be loaded from alternative sources, as long as the structure
     * converts to the `Permission`.
     *
     * @param userId The `userId` for given permissionManagement
     * @param permissionCode The `permissionCode` for given permissionManagement
     */
    abstract load(userId: string, permissionCode: string): Observable<Permission>;
    abstract loadList(userId: string, params?: SearchConfig): Observable<EntitiesModel<Permission>>;
    abstract create(userId: string, permission: Permission): Observable<Permission>;
    abstract update(userId: string, permissionCode: string, permission: Permission): Observable<Permission>;
    abstract loadTypes(): Observable<OrderApprovalPermissionType[]>;
}

declare class PermissionConnector {
    protected adapter: PermissionAdapter;
    constructor(adapter: PermissionAdapter);
    get(userId: string, permissionCode: string): Observable<Permission>;
    getList(userId: string, params?: SearchConfig): Observable<EntitiesModel<Permission>>;
    create(userId: string, permission: Permission): Observable<Permission>;
    update(userId: string, permissionCode: string, permission: Permission): Observable<Permission>;
    getTypes(): Observable<OrderApprovalPermissionType[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PermissionConnector>;
}

declare const PERMISSION_NORMALIZER: InjectionToken<Converter<any, Permission>>;
declare const PERMISSIONS_NORMALIZER: InjectionToken<Converter<any, EntitiesModel<Permission>>>;
declare const PERMISSION_TYPE_NORMALIZER: InjectionToken<Converter<any, OrderApprovalPermissionType>>;
declare const PERMISSION_TYPES_NORMALIZER: InjectionToken<Converter<any, OrderApprovalPermissionType[]>>;
declare const PERMISSION_SERIALIZER: InjectionToken<Converter<Permission, any>>;

declare abstract class UserGroupAdapter {
    /**
     * Abstract method used to load userGroupManagement's details data.
     * userGroup's data can be loaded from alternative sources, as long as the structure
     * converts to the `OrgUnitUserGroup`.
     *
     * @param userId The `userId` for given userGroupManagement
     * @param userGroupId The `userGroupId` for given userGroupManagement
     */
    abstract load(userId: string, userGroupId: string): Observable<UserGroup>;
    abstract loadList(userId: string, params?: SearchConfig): Observable<EntitiesModel<UserGroup>>;
    abstract loadAvailableOrderApprovalPermissions(userId: string, userGroupId: string, params?: SearchConfig): Observable<EntitiesModel<Permission>>;
    abstract loadAvailableOrgCustomers(userId: string, userGroupId: string, params?: SearchConfig): Observable<EntitiesModel<B2BUser>>;
    abstract create(userId: string, userGroup: UserGroup): Observable<UserGroup>;
    abstract update(userId: string, userGroupId: string, userGroup: UserGroup): Observable<UserGroup>;
    abstract delete(userId: string, userGroupId: string): Observable<UserGroup>;
    abstract assignMember(userId: string, userGroupId: string, orgCustomerId: string): Observable<any>;
    abstract assignOrderApprovalPermission(userId: string, userGroupId: string, orderApprovalPermissionCode: string): Observable<any>;
    abstract unassignMember(userId: string, userGroupId: string, orgCustomerId: string): Observable<any>;
    abstract unassignAllMembers(userId: string, userGroupId: string): Observable<any>;
    abstract unassignOrderApprovalPermission(userId: string, userGroupId: string, orderApprovalPermissionCode: string): Observable<any>;
}

declare class UserGroupConnector {
    protected adapter: UserGroupAdapter;
    constructor(adapter: UserGroupAdapter);
    get(userId: string, userGroupId: string): Observable<UserGroup>;
    getList(userId: string, params?: SearchConfig): Observable<EntitiesModel<UserGroup>>;
    getAvailableOrderApprovalPermissions(userId: string, userGroupId: string, params?: SearchConfig): Observable<EntitiesModel<Permission>>;
    getAvailableOrgCustomers(userId: string, userGroupId: string, params?: SearchConfig): Observable<EntitiesModel<B2BUser>>;
    create(userId: string, userGroup: UserGroup): Observable<UserGroup>;
    delete(userId: string, userGroupId: string): Observable<UserGroup>;
    update(userId: string, userGroupId: string, userGroup: UserGroup): Observable<UserGroup>;
    assignMember(userId: string, userGroupId: string, orgCustomerId: string): Observable<any>;
    assignOrderApprovalPermission(userId: string, userGroupId: string, orderApprovalPermissionCode: string): Observable<any>;
    unassignMember(userId: string, userGroupId: string, orgCustomerId: string): Observable<any>;
    unassignAllMembers(userId: string, userGroupId: string): Observable<any>;
    unassignOrderApprovalPermission(userId: string, userGroupId: string, orderApprovalPermissionCode: string): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserGroupConnector>;
}

declare const USER_GROUP_NORMALIZER: InjectionToken<Converter<any, UserGroup>>;
declare const USER_GROUP_SERIALIZER: InjectionToken<Converter<UserGroup, any>>;
declare const USER_GROUPS_NORMALIZER: InjectionToken<Converter<any, EntitiesModel<UserGroup>>>;

declare class AdminGuard {
    protected userAccountFacade: UserAccountFacade;
    protected routingService: RoutingService;
    protected globalMessageService: GlobalMessageService;
    constructor(userAccountFacade: UserAccountFacade, routingService: RoutingService, globalMessageService: GlobalMessageService);
    canActivate(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AdminGuard>;
}

declare enum LoadStatus {
    SUCCESS = 0,
    ERROR = 1
}
interface OrganizationItemStatus<T> {
    status: LoadStatus | null;
    item: T | undefined;
}

declare const ORGANIZATION_FEATURE = "organization";
declare const BUDGET_FEATURE = "budget";
declare const BUDGET_ENTITIES = "budget-entities";
declare const BUDGET_LIST = "budget-list";
declare const COST_CENTER_FEATURE = "costCenter";
declare const COST_CENTER_ENTITIES = "costCenter-entities";
declare const COST_CENTER_LIST = "costCenter-list";
declare const COST_CENTER_ASSIGNED_BUDGETS = "costCenter-assigned-budgets";
declare const PERMISSION_FEATURE = "permission";
declare const PERMISSION_ENTITIES = "permission-entities";
declare const PERMISSION_LIST = "permission-list";
declare const PERMISSION_TYPES = "permission-types";
declare const PERMISSION_TYPES_LIST = "permission-types-list";
declare const ORG_UNIT_FEATURE = "orgUnit";
declare const ORG_UNIT_NODE_ENTITIES = "orgUnitNode-entities";
declare const ORG_UNIT_NODE_LIST = "orgUnitNode-list";
declare const ORG_UNIT_ENTITIES = "orgUnit-entities";
declare const ORG_UNIT_TREE_ENTITY = "orgUnit-tree";
declare const ORG_UNIT_APPROVAL_PROCESSES_ENTITIES = "orgUnit-approval-processes";
declare const ORG_UNIT_ASSIGNED_USERS = "orgUnit-assigned-users";
declare const ORG_UNIT_TREE = "tree";
declare const ORG_UNIT_APPROVAL_PROCESSES = "approvalProcesses";
declare const ORG_UNIT_NODES = "availableOrgUnitNodes";
declare const B2B_USER_FEATURE = "b2bUser";
declare const B2B_USER_ENTITIES = "b2bUser-entities";
declare const USER_LIST = "b2bUser-list";
declare const B2B_USER_APPROVERS = "b2bUser-approvers";
declare const B2B_USER_PERMISSIONS = "b2bUser-permissions";
declare const B2B_USER_USER_GROUPS = "b2bUser-user-groups";
declare const USER_GROUP_FEATURE = "userGroup";
declare const USER_GROUP_ENTITIES = "userGroup-entities";
declare const USER_GROUP_LIST = "userGroup-list";
declare const USER_GROUP_PERMISSIONS = "userGroup-available-order-approval-permissions";
declare const USER_GROUP_AVAILABLE_CUSTOMERS = "userGroup-available-org-customers";
declare const ADDRESS_ENTITIES = "addresses-entities";
declare const ADDRESS_LIST = "addresses-list";
interface Management<Type> extends StateUtils.EntityListState<Type> {
}
interface BudgetManagement extends Management<Budget> {
}
interface OrgUnits {
    availableOrgUnitNodes: StateUtils.EntityLoaderState<B2BUnitNode[]>;
    entities: StateUtils.EntityLoaderState<B2BUnit>;
    tree: StateUtils.EntityLoaderState<B2BUnitNode>;
    approvalProcesses: StateUtils.EntityLoaderState<B2BApprovalProcess[]>;
    users: StateUtils.EntityLoaderState<ListModel>;
    addressList: StateUtils.EntityLoaderState<ListModel>;
    addressEntities: StateUtils.EntityLoaderState<Address>;
}
interface UserGroupManagement extends Management<UserGroup> {
    permissions: StateUtils.EntityLoaderState<ListModel>;
    customers: StateUtils.EntityLoaderState<ListModel>;
}
interface PermissionManagement extends Management<Permission> {
    permissionTypes: StateUtils.EntityLoaderState<OrderApprovalPermissionType[]>;
}
interface CostCenterManagement extends Management<CostCenter> {
    budgets: StateUtils.EntityLoaderState<ListModel>;
}
interface B2BUserManagement extends Management<B2BUser> {
    approvers: StateUtils.EntityLoaderState<ListModel>;
    permissions: StateUtils.EntityLoaderState<ListModel>;
    userGroups: StateUtils.EntityLoaderState<ListModel>;
}
interface StateWithOrganization {
    [ORGANIZATION_FEATURE]: OrganizationState;
}
interface OrganizationState {
    [BUDGET_FEATURE]: BudgetManagement;
    [ORG_UNIT_FEATURE]: OrgUnits;
    [USER_GROUP_FEATURE]: UserGroupManagement;
    [PERMISSION_FEATURE]: PermissionManagement;
    [COST_CENTER_FEATURE]: CostCenterManagement;
    [B2B_USER_FEATURE]: B2BUserManagement;
}

declare class B2BUserService {
    protected store: Store<StateWithOrganization>;
    protected userIdService: UserIdService;
    constructor(store: Store<StateWithOrganization>, userIdService: UserIdService);
    load(orgCustomerId: string): void;
    loadList(params: SearchConfig): void;
    private getB2BUserValue;
    get(orgCustomerId: string): Observable<B2BUser>;
    getList(params: SearchConfig): Observable<EntitiesModel<B2BUser> | undefined>;
    getErrorState(orgCustomerId: string): Observable<boolean>;
    create(orgCustomer: B2BUser): void;
    update(orgCustomerId: string, orgCustomer: B2BUser): void;
    getLoadingStatus(orgCustomerId: string): Observable<OrganizationItemStatus<B2BUser>>;
    loadApprovers(orgCustomerId: string, params: SearchConfig): void;
    getApprovers(orgCustomerId: string, params: SearchConfig): Observable<EntitiesModel<B2BUser> | undefined>;
    assignApprover(orgCustomerId: string, approverId: string): void;
    unassignApprover(orgCustomerId: string, approverId: string): void;
    loadPermissions(orgCustomerId: string, params: SearchConfig): void;
    getPermissions(orgCustomerId: string, params: SearchConfig): Observable<EntitiesModel<Permission> | undefined>;
    assignPermission(orgCustomerId: string, permissionId: string): void;
    unassignPermission(orgCustomerId: string, permissionId: string): void;
    loadUserGroups(orgCustomerId: string, params: SearchConfig): void;
    getUserGroups(orgCustomerId: string, params: SearchConfig): Observable<EntitiesModel<UserGroup> | undefined>;
    assignUserGroup(orgCustomerId: string, userGroupId: string): void;
    unassignUserGroup(orgCustomerId: string, userGroupId: string): void;
    /**
     * Get list of all roles for B2BUser sorted by increasing privileges.
     *
     * This list is not driven by the backend (lack of API), but reflects roles
     * from the backend: `b2badmingroup`, `b2bcustomergroup`, `b2bmanagergroup` and `b2bapprovergroup`.
     *
     * If you reconfigure those roles in the backend or extend the list, you should change
     * this implementation accordingly.
     */
    getAllRoles(): B2BUserRole[];
    /**
     * Get list of all rights for B2BUser.
     *
     * This list is not driven by the backend (lack of API), but reflects rights
     * from the backend: `unitorderviewer'.
     *
     * If you reconfigure those rights in the backend or extend the list, you should change
     * this implementation accordingly.
     */
    getAllRights(): B2BUserRight[];
    private getB2BUserApproverList;
    private getB2BUserPermissionList;
    private getB2BUserUserGroupList;
    private getB2BUserState;
    private getUserList;
    isUpdatingUserAllowed(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<B2BUserService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<B2BUserService>;
}

declare const LOAD_BUDGET = "[Budget] Load Budget Data";
declare const LOAD_BUDGET_FAIL = "[Budget] Load Budget Data Fail";
declare const LOAD_BUDGET_SUCCESS = "[Budget] Load Budget Data Success";
declare const LOAD_BUDGETS = "[Budget] Load Budgets";
declare const LOAD_BUDGETS_FAIL = "[Budget] Load Budgets Fail";
declare const LOAD_BUDGETS_SUCCESS = "[Budget] Load Budgets Success";
declare const CREATE_BUDGET = "[Budget] Create Budget";
declare const CREATE_BUDGET_FAIL = "[Budget] Create Budget Fail";
declare const CREATE_BUDGET_SUCCESS = "[Budget] Create Budget Success";
declare const UPDATE_BUDGET = "[Budget] Update Budget";
declare const UPDATE_BUDGET_FAIL = "[Budget] Update Budget Fail";
declare const UPDATE_BUDGET_SUCCESS = "[Budget] Update Budget Success";
declare class LoadBudget extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        budgetCode: string;
    };
    readonly type = "[Budget] Load Budget Data";
    constructor(payload: {
        userId: string;
        budgetCode: string;
    });
}
declare class LoadBudgetFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        budgetCode: string;
        error: any;
    };
    readonly type = "[Budget] Load Budget Data Fail";
    constructor(payload: {
        budgetCode: string;
        error: any;
    });
}
declare class LoadBudgetSuccess extends StateUtils.EntitySuccessAction {
    payload: Budget | Budget[];
    readonly type = "[Budget] Load Budget Data Success";
    constructor(payload: Budget | Budget[]);
}
declare class LoadBudgets extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        params: SearchConfig;
    };
    readonly type = "[Budget] Load Budgets";
    constructor(payload: {
        userId: string;
        params: SearchConfig;
    });
}
declare class LoadBudgetsFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        params: SearchConfig;
        error: any;
    };
    readonly type = "[Budget] Load Budgets Fail";
    constructor(payload: {
        params: SearchConfig;
        error: any;
    });
}
declare class LoadBudgetsSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        page: ListModel;
        params: SearchConfig;
    };
    readonly type = "[Budget] Load Budgets Success";
    constructor(payload: {
        page: ListModel;
        params: SearchConfig;
    });
}
declare class CreateBudget extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        budget: Budget;
    };
    readonly type = "[Budget] Create Budget";
    constructor(payload: {
        userId: string;
        budget: Budget;
    });
}
declare class CreateBudgetFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        budgetCode: string;
        error: any;
    };
    readonly type = "[Budget] Create Budget Fail";
    constructor(payload: {
        budgetCode: string;
        error: any;
    });
}
declare class CreateBudgetSuccess extends StateUtils.EntitySuccessAction {
    payload: Budget;
    readonly type = "[Budget] Create Budget Success";
    constructor(payload: Budget);
}
declare class UpdateBudget extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        budgetCode: string;
        budget: Budget;
    };
    readonly type = "[Budget] Update Budget";
    constructor(payload: {
        userId: string;
        budgetCode: string;
        budget: Budget;
    });
}
declare class UpdateBudgetFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        budgetCode: string;
        error: any;
    };
    readonly type = "[Budget] Update Budget Fail";
    constructor(payload: {
        budgetCode: string;
        error: any;
    });
}
declare class UpdateBudgetSuccess extends StateUtils.EntitySuccessAction {
    payload: Budget;
    readonly type = "[Budget] Update Budget Success";
    constructor(payload: Budget);
}
type BudgetAction = LoadBudget | LoadBudgetFail | LoadBudgetSuccess | LoadBudgets | LoadBudgetsFail | LoadBudgetsSuccess | CreateBudget | CreateBudgetFail | CreateBudgetSuccess | UpdateBudget | UpdateBudgetFail | UpdateBudgetSuccess;

type budget_action_d_BudgetAction = BudgetAction;
declare const budget_action_d_CREATE_BUDGET: typeof CREATE_BUDGET;
declare const budget_action_d_CREATE_BUDGET_FAIL: typeof CREATE_BUDGET_FAIL;
declare const budget_action_d_CREATE_BUDGET_SUCCESS: typeof CREATE_BUDGET_SUCCESS;
type budget_action_d_CreateBudget = CreateBudget;
declare const budget_action_d_CreateBudget: typeof CreateBudget;
type budget_action_d_CreateBudgetFail = CreateBudgetFail;
declare const budget_action_d_CreateBudgetFail: typeof CreateBudgetFail;
type budget_action_d_CreateBudgetSuccess = CreateBudgetSuccess;
declare const budget_action_d_CreateBudgetSuccess: typeof CreateBudgetSuccess;
declare const budget_action_d_LOAD_BUDGET: typeof LOAD_BUDGET;
declare const budget_action_d_LOAD_BUDGETS: typeof LOAD_BUDGETS;
declare const budget_action_d_LOAD_BUDGETS_FAIL: typeof LOAD_BUDGETS_FAIL;
declare const budget_action_d_LOAD_BUDGETS_SUCCESS: typeof LOAD_BUDGETS_SUCCESS;
declare const budget_action_d_LOAD_BUDGET_FAIL: typeof LOAD_BUDGET_FAIL;
declare const budget_action_d_LOAD_BUDGET_SUCCESS: typeof LOAD_BUDGET_SUCCESS;
type budget_action_d_LoadBudget = LoadBudget;
declare const budget_action_d_LoadBudget: typeof LoadBudget;
type budget_action_d_LoadBudgetFail = LoadBudgetFail;
declare const budget_action_d_LoadBudgetFail: typeof LoadBudgetFail;
type budget_action_d_LoadBudgetSuccess = LoadBudgetSuccess;
declare const budget_action_d_LoadBudgetSuccess: typeof LoadBudgetSuccess;
type budget_action_d_LoadBudgets = LoadBudgets;
declare const budget_action_d_LoadBudgets: typeof LoadBudgets;
type budget_action_d_LoadBudgetsFail = LoadBudgetsFail;
declare const budget_action_d_LoadBudgetsFail: typeof LoadBudgetsFail;
type budget_action_d_LoadBudgetsSuccess = LoadBudgetsSuccess;
declare const budget_action_d_LoadBudgetsSuccess: typeof LoadBudgetsSuccess;
declare const budget_action_d_UPDATE_BUDGET: typeof UPDATE_BUDGET;
declare const budget_action_d_UPDATE_BUDGET_FAIL: typeof UPDATE_BUDGET_FAIL;
declare const budget_action_d_UPDATE_BUDGET_SUCCESS: typeof UPDATE_BUDGET_SUCCESS;
type budget_action_d_UpdateBudget = UpdateBudget;
declare const budget_action_d_UpdateBudget: typeof UpdateBudget;
type budget_action_d_UpdateBudgetFail = UpdateBudgetFail;
declare const budget_action_d_UpdateBudgetFail: typeof UpdateBudgetFail;
type budget_action_d_UpdateBudgetSuccess = UpdateBudgetSuccess;
declare const budget_action_d_UpdateBudgetSuccess: typeof UpdateBudgetSuccess;
declare namespace budget_action_d {
  export { budget_action_d_CREATE_BUDGET as CREATE_BUDGET, budget_action_d_CREATE_BUDGET_FAIL as CREATE_BUDGET_FAIL, budget_action_d_CREATE_BUDGET_SUCCESS as CREATE_BUDGET_SUCCESS, budget_action_d_CreateBudget as CreateBudget, budget_action_d_CreateBudgetFail as CreateBudgetFail, budget_action_d_CreateBudgetSuccess as CreateBudgetSuccess, budget_action_d_LOAD_BUDGET as LOAD_BUDGET, budget_action_d_LOAD_BUDGETS as LOAD_BUDGETS, budget_action_d_LOAD_BUDGETS_FAIL as LOAD_BUDGETS_FAIL, budget_action_d_LOAD_BUDGETS_SUCCESS as LOAD_BUDGETS_SUCCESS, budget_action_d_LOAD_BUDGET_FAIL as LOAD_BUDGET_FAIL, budget_action_d_LOAD_BUDGET_SUCCESS as LOAD_BUDGET_SUCCESS, budget_action_d_LoadBudget as LoadBudget, budget_action_d_LoadBudgetFail as LoadBudgetFail, budget_action_d_LoadBudgetSuccess as LoadBudgetSuccess, budget_action_d_LoadBudgets as LoadBudgets, budget_action_d_LoadBudgetsFail as LoadBudgetsFail, budget_action_d_LoadBudgetsSuccess as LoadBudgetsSuccess, budget_action_d_UPDATE_BUDGET as UPDATE_BUDGET, budget_action_d_UPDATE_BUDGET_FAIL as UPDATE_BUDGET_FAIL, budget_action_d_UPDATE_BUDGET_SUCCESS as UPDATE_BUDGET_SUCCESS, budget_action_d_UpdateBudget as UpdateBudget, budget_action_d_UpdateBudgetFail as UpdateBudgetFail, budget_action_d_UpdateBudgetSuccess as UpdateBudgetSuccess };
  export type { budget_action_d_BudgetAction as BudgetAction };
}

declare const LOAD_ORG_UNIT = "[B2BUnit] Load B2BUnit Data";
declare const LOAD_ORG_UNIT_FAIL = "[B2BUnit] Load B2BUnit Data Fail";
declare const LOAD_ORG_UNIT_SUCCESS = "[B2BUnit] Load B2BUnit Data Success";
declare const LOAD_UNIT_NODE = "[B2BUnitNode] Load B2BUnitNode Data";
declare const LOAD_UNIT_NODE_FAIL = "[B2BUnitNode] Load B2BUnitNode Data Fail";
declare const LOAD_UNIT_NODE_SUCCESS = "[B2BUnitNode] Load B2BUnitNode Data Success";
declare const LOAD_UNIT_NODES = "[B2BUnitNode] Load B2BUnitNodes";
declare const LOAD_UNIT_NODES_FAIL = "[B2BUnitNode] Load B2BUnitNodes Fail";
declare const LOAD_UNIT_NODES_SUCCESS = "[B2BUnitNode] Load B2BUnitNodes Success";
declare const CREATE_ORG_UNIT = "[B2BUnit] Create B2BUnitNode";
declare const CREATE_ORG_UNIT_FAIL = "[B2BUnit] Create B2BUnitNode Fail";
declare const CREATE_ORG_UNIT_SUCCESS = "[B2BUnit] Create B2BUnitNode Success";
declare const UPDATE_ORG_UNIT = "[B2BUnit] Update B2BUnitNode";
declare const UPDATE_ORG_UNIT_FAIL = "[B2BUnit] Update B2BUnitNode Fail";
declare const UPDATE_ORG_UNIT_SUCCESS = "[B2BUnit] Update B2BUnitNode Success";
declare const LOAD_UNIT_TREE = "[B2BUnitNode] Load Tree";
declare const LOAD_UNIT_TREE_FAIL = "[B2BUnitNode] Load Tree Fail";
declare const LOAD_UNIT_TREE_SUCCESS = "[B2BUnitNode] Load Tree Success";
declare const LOAD_APPROVAL_PROCESSES = "[B2BApprovalProcess] Load Approval Processes";
declare const LOAD_APPROVAL_PROCESSES_FAIL = "[B2BApprovalProcess] Load Approval Processes Fail";
declare const LOAD_APPROVAL_PROCESSES_SUCCESS = "[B2BApprovalProcess] Load Approval Processes Success";
declare const LOAD_ASSIGNED_USERS = "[B2BUnit] Load Users";
declare const LOAD_ASSIGNED_USERS_SUCCESS = "[B2BUnit] Load Users success";
declare const LOAD_ASSIGNED_USERS_FAIL = "[B2BUnit] Load Users fail";
declare const ASSIGN_ROLE = "[B2BUnit] Assign Role";
declare const ASSIGN_ROLE_SUCCESS = "[B2BUnit] Assign Role success";
declare const ASSIGN_ROLE_FAIL = "[B2BUnit] Assign Role fail";
declare const UNASSIGN_ROLE = "[B2BUnit] Unassign Role";
declare const UNASSIGN_ROLE_SUCCESS = "[B2BUnit] Unassign Role success";
declare const UNASSIGN_ROLE_FAIL = "[B2BUnit] Unassign Role fail";
declare const ASSIGN_APPROVER = "[B2BUnit] Assign Approver";
declare const ASSIGN_APPROVER_SUCCESS = "[B2BUnit] Assign Approver success";
declare const ASSIGN_APPROVER_FAIL = "[B2BUnit] Assign Approver fail";
declare const UNASSIGN_APPROVER = "[B2BUnit] Unassign Approver";
declare const UNASSIGN_APPROVER_SUCCESS = "[B2BUnit] Unassign Approver success";
declare const UNASSIGN_APPROVER_FAIL = "[B2BUnit] Unassign Approver fail";
declare const CREATE_ADDRESS = "[B2BUnit] Create address";
declare const CREATE_ADDRESS_SUCCESS = "[B2BUnit] Create address success";
declare const CREATE_ADDRESS_FAIL = "[B2BUnit] Create address fail";
declare const UPDATE_ADDRESS = "[B2BUnit] Update address";
declare const UPDATE_ADDRESS_SUCCESS = "[B2BUnit] Update address success";
declare const UPDATE_ADDRESS_FAIL = "[B2BUnit] Update address fail";
declare const DELETE_ADDRESS = "[B2BUnit] Delete address";
declare const DELETE_ADDRESS_SUCCESS = "[B2BUnit] Delete address success";
declare const DELETE_ADDRESS_FAIL = "[B2BUnit] Delete address fail";
declare const LOAD_ADDRESS_SUCCESS = "[B2BUnit] Load address success";
declare const LOAD_ADDRESSES = "[B2BUnit] Load addresses";
declare const LOAD_ADDRESSES_SUCCESS = "[B2BUnit] Load addresses success";
declare const LOAD_ADDRESSES_FAIL = "[B2BUnit] Load addresses fail";
declare const CLEAR_ASSIGNED_USERS = "[B2BUnit] Clear Assigned Users";
declare class LoadOrgUnit extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgUnitId: string;
    };
    readonly type = "[B2BUnit] Load B2BUnit Data";
    constructor(payload: {
        userId: string;
        orgUnitId: string;
    });
}
declare class LoadOrgUnitFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgUnitId: string;
        error: any;
    };
    readonly type = "[B2BUnit] Load B2BUnit Data Fail";
    constructor(payload: {
        orgUnitId: string;
        error: any;
    });
}
declare class LoadOrgUnitSuccess extends StateUtils.EntitySuccessAction {
    payload: B2BUnit | B2BUnit[];
    readonly type = "[B2BUnit] Load B2BUnit Data Success";
    constructor(payload: B2BUnit | B2BUnit[]);
}
declare class LoadOrgUnitNodes extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
    };
    readonly type = "[B2BUnitNode] Load B2BUnitNodes";
    constructor(payload: {
        userId: string;
    });
}
declare class LoadOrgUnitNodesFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: any;
    readonly type = "[B2BUnitNode] Load B2BUnitNodes Fail";
    constructor(payload: any);
}
declare class LoadOrgUnitNodesSuccess extends StateUtils.EntitySuccessAction {
    payload: B2BUnitNode[];
    readonly type = "[B2BUnitNode] Load B2BUnitNodes Success";
    constructor(payload: B2BUnitNode[]);
}
declare class CreateUnit extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        unit: B2BUnit;
    };
    readonly type = "[B2BUnit] Create B2BUnitNode";
    constructor(payload: {
        userId: string;
        unit: B2BUnit;
    });
}
declare class CreateUnitFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        unitCode: string;
        error: any;
    };
    readonly type = "[B2BUnit] Create B2BUnitNode Fail";
    constructor(payload: {
        unitCode: string;
        error: any;
    });
}
declare class CreateUnitSuccess extends StateUtils.EntitySuccessAction {
    payload: B2BUnit;
    readonly type = "[B2BUnit] Create B2BUnitNode Success";
    constructor(payload: B2BUnit);
}
declare class UpdateUnit extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        unitCode: string;
        unit: B2BUnit;
    };
    readonly type = "[B2BUnit] Update B2BUnitNode";
    constructor(payload: {
        userId: string;
        unitCode: string;
        unit: B2BUnit;
    });
}
declare class UpdateUnitFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        unitCode: string;
        error: any;
    };
    readonly type = "[B2BUnit] Update B2BUnitNode Fail";
    constructor(payload: {
        unitCode: string;
        error: any;
    });
}
declare class UpdateUnitSuccess extends StateUtils.EntitySuccessAction {
    payload: B2BUnit;
    readonly type = "[B2BUnit] Update B2BUnitNode Success";
    constructor(payload: B2BUnit);
}
declare class LoadTree extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
    };
    readonly type = "[B2BUnitNode] Load Tree";
    constructor(payload: {
        userId: string;
    });
}
declare class LoadTreeFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        error: any;
    };
    readonly type = "[B2BUnitNode] Load Tree Fail";
    constructor(payload: {
        error: any;
    });
}
declare class LoadTreeSuccess extends StateUtils.EntitySuccessAction {
    payload: B2BUnitNode;
    readonly type = "[B2BUnitNode] Load Tree Success";
    constructor(payload: B2BUnitNode);
}
declare class LoadApprovalProcesses extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
    };
    readonly type = "[B2BApprovalProcess] Load Approval Processes";
    constructor(payload: {
        userId: string;
    });
}
declare class LoadApprovalProcessesFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        error: any;
    };
    readonly type = "[B2BApprovalProcess] Load Approval Processes Fail";
    constructor(payload: {
        error: any;
    });
}
declare class LoadApprovalProcessesSuccess extends StateUtils.EntitySuccessAction {
    payload: B2BApprovalProcess[];
    readonly type = "[B2BApprovalProcess] Load Approval Processes Success";
    constructor(payload: B2BApprovalProcess[]);
}
declare class LoadAssignedUsers extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgUnitId: string;
        roleId: string;
        params: SearchConfig;
    };
    readonly type = "[B2BUnit] Load Users";
    constructor(payload: {
        userId: string;
        orgUnitId: string;
        roleId: string;
        params: SearchConfig;
    });
}
declare class ClearAssignedUsers extends StateUtils.EntityRemoveAction {
    payload: {
        orgUnitId: string;
        roleId: string;
        params: SearchConfig;
    };
    readonly type = "[B2BUnit] Clear Assigned Users";
    constructor(payload: {
        orgUnitId: string;
        roleId: string;
        params: SearchConfig;
    });
}
declare class LoadAssignedUsersFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgUnitId: string;
        roleId: string;
        params: SearchConfig;
        error: any;
    };
    readonly type = "[B2BUnit] Load Users fail";
    constructor(payload: {
        orgUnitId: string;
        roleId: string;
        params: SearchConfig;
        error: any;
    });
}
declare class LoadAssignedUsersSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        orgUnitId: string;
        roleId: string;
        page: ListModel;
        params: SearchConfig;
    };
    readonly type = "[B2BUnit] Load Users success";
    constructor(payload: {
        orgUnitId: string;
        roleId: string;
        page: ListModel;
        params: SearchConfig;
    });
}
declare class AssignRole extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgCustomerId: string;
        roleId: string;
    };
    readonly type = "[B2BUnit] Assign Role";
    constructor(payload: {
        userId: string;
        orgCustomerId: string;
        roleId: string;
    });
}
declare class AssignRoleFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgCustomerId: string;
        error: any;
    };
    readonly type = "[B2BUnit] Assign Role fail";
    constructor(payload: {
        orgCustomerId: string;
        error: any;
    });
}
declare class AssignRoleSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        uid: string;
        roleId: string;
        selected: boolean;
    };
    readonly type = "[B2BUnit] Assign Role success";
    constructor(payload: {
        uid: string;
        roleId: string;
        selected: boolean;
    });
}
declare class UnassignRole extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgCustomerId: string;
        roleId: string;
    };
    readonly type = "[B2BUnit] Unassign Role";
    constructor(payload: {
        userId: string;
        orgCustomerId: string;
        roleId: string;
    });
}
declare class UnassignRoleFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgCustomerId: string;
        error: any;
    };
    readonly type = "[B2BUnit] Unassign Role fail";
    constructor(payload: {
        orgCustomerId: string;
        error: any;
    });
}
declare class UnassignRoleSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        uid: string;
        roleId: string;
        selected: boolean;
    };
    readonly type = "[B2BUnit] Unassign Role success";
    constructor(payload: {
        uid: string;
        roleId: string;
        selected: boolean;
    });
}
declare class AssignApprover extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgUnitId: string;
        orgCustomerId: string;
        roleId: string;
    };
    readonly type = "[B2BUnit] Assign Approver";
    constructor(payload: {
        userId: string;
        orgUnitId: string;
        orgCustomerId: string;
        roleId: string;
    });
}
declare class AssignApproverFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgCustomerId: string;
        error: any;
    };
    readonly type = "[B2BUnit] Assign Approver fail";
    constructor(payload: {
        orgCustomerId: string;
        error: any;
    });
}
declare class AssignApproverSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        uid: string;
        roleId: string;
        selected: boolean;
    };
    readonly type = "[B2BUnit] Assign Approver success";
    constructor(payload: {
        uid: string;
        roleId: string;
        selected: boolean;
    });
}
declare class UnassignApprover extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgUnitId: string;
        orgCustomerId: string;
        roleId: string;
    };
    readonly type = "[B2BUnit] Unassign Approver";
    constructor(payload: {
        userId: string;
        orgUnitId: string;
        orgCustomerId: string;
        roleId: string;
    });
}
declare class UnassignApproverFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgCustomerId: string;
        error: any;
    };
    readonly type = "[B2BUnit] Unassign Approver fail";
    constructor(payload: {
        orgCustomerId: string;
        error: any;
    });
}
declare class UnassignApproverSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        uid: string;
        roleId: string;
        selected: boolean;
    };
    readonly type = "[B2BUnit] Unassign Approver success";
    constructor(payload: {
        uid: string;
        roleId: string;
        selected: boolean;
    });
}
declare class CreateAddress extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgUnitId: string;
        address: Address;
    };
    readonly type = "[B2BUnit] Create address";
    constructor(payload: {
        userId: string;
        orgUnitId: string;
        address: Address;
    });
}
declare class CreateAddressFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        addressId: string;
        error: any;
    };
    readonly type = "[B2BUnit] Create address fail";
    constructor(payload: {
        addressId: string;
        error: any;
    });
}
declare class CreateAddressSuccess extends StateUtils.EntitySuccessAction {
    payload: Address;
    readonly type = "[B2BUnit] Create address success";
    constructor(payload: Address);
}
declare class UpdateAddress extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgUnitId: string;
        addressId: string;
        address: Address;
    };
    readonly type = "[B2BUnit] Update address";
    constructor(payload: {
        userId: string;
        orgUnitId: string;
        addressId: string;
        address: Address;
    });
}
declare class UpdateAddressFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        addressId: string;
        error: any;
    };
    readonly type = "[B2BUnit] Update address fail";
    constructor(payload: {
        addressId: string;
        error: any;
    });
}
declare class UpdateAddressSuccess extends StateUtils.EntitySuccessAction {
    payload: Address;
    readonly type = "[B2BUnit] Update address success";
    constructor(payload: Address);
}
declare class DeleteAddress extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgUnitId: string;
        addressId: string;
    };
    readonly type = "[B2BUnit] Delete address";
    constructor(payload: {
        userId: string;
        orgUnitId: string;
        addressId: string;
    });
}
declare class DeleteAddressFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        addressId: string;
        error: any;
    };
    readonly type = "[B2BUnit] Delete address fail";
    constructor(payload: {
        addressId: string;
        error: any;
    });
}
declare class DeleteAddressSuccess extends StateUtils.EntityRemoveAction {
    payload: Address;
    readonly type = "[B2BUnit] Delete address success";
    constructor(payload: Address);
}
declare class LoadAddressSuccess extends StateUtils.EntitySuccessAction {
    payload: Address | Address[];
    readonly type = "[B2BUnit] Load address success";
    constructor(payload: Address | Address[]);
}
declare class LoadAddresses extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgUnitId: string;
    };
    readonly type = "[B2BUnit] Load addresses";
    constructor(payload: {
        userId: string;
        orgUnitId: string;
    });
}
declare class LoadAddressesFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgUnitId: string;
        error: any;
    };
    readonly type = "[B2BUnit] Load addresses fail";
    constructor(payload: {
        orgUnitId: string;
        error: any;
    });
}
declare class LoadAddressesSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        page: ListModel;
        orgUnitId: string;
    };
    readonly type = "[B2BUnit] Load addresses success";
    constructor(payload: {
        page: ListModel;
        orgUnitId: string;
    });
}
type OrgUnitAction = LoadOrgUnitNodes | LoadOrgUnitNodesFail | LoadOrgUnitNodesSuccess | LoadOrgUnit | LoadOrgUnitFail | LoadOrgUnitSuccess | CreateUnit | CreateUnitFail | CreateUnitSuccess | UpdateUnit | UpdateUnitFail | UpdateUnitSuccess | LoadTree | LoadTreeSuccess | LoadTreeFail | LoadApprovalProcesses | LoadApprovalProcessesSuccess | LoadApprovalProcessesFail | AssignRole | AssignRoleSuccess | AssignRoleFail | UnassignRole | UnassignRoleSuccess | UnassignRoleFail | AssignApprover | AssignApproverSuccess | AssignApproverFail | UnassignApprover | UnassignApproverSuccess | UnassignApproverFail | CreateAddress | CreateAddressSuccess | CreateAddressFail | UpdateAddress | UpdateAddressSuccess | UpdateAddressFail | DeleteAddress | DeleteAddressSuccess | DeleteAddressFail | LoadAddresses | LoadAddressesFail | LoadAddressesSuccess | LoadAddressSuccess | ClearAssignedUsers;

declare const orgUnit_action_d_ASSIGN_APPROVER: typeof ASSIGN_APPROVER;
declare const orgUnit_action_d_ASSIGN_APPROVER_FAIL: typeof ASSIGN_APPROVER_FAIL;
declare const orgUnit_action_d_ASSIGN_APPROVER_SUCCESS: typeof ASSIGN_APPROVER_SUCCESS;
declare const orgUnit_action_d_ASSIGN_ROLE: typeof ASSIGN_ROLE;
declare const orgUnit_action_d_ASSIGN_ROLE_FAIL: typeof ASSIGN_ROLE_FAIL;
declare const orgUnit_action_d_ASSIGN_ROLE_SUCCESS: typeof ASSIGN_ROLE_SUCCESS;
type orgUnit_action_d_AssignApprover = AssignApprover;
declare const orgUnit_action_d_AssignApprover: typeof AssignApprover;
type orgUnit_action_d_AssignApproverFail = AssignApproverFail;
declare const orgUnit_action_d_AssignApproverFail: typeof AssignApproverFail;
type orgUnit_action_d_AssignApproverSuccess = AssignApproverSuccess;
declare const orgUnit_action_d_AssignApproverSuccess: typeof AssignApproverSuccess;
type orgUnit_action_d_AssignRole = AssignRole;
declare const orgUnit_action_d_AssignRole: typeof AssignRole;
type orgUnit_action_d_AssignRoleFail = AssignRoleFail;
declare const orgUnit_action_d_AssignRoleFail: typeof AssignRoleFail;
type orgUnit_action_d_AssignRoleSuccess = AssignRoleSuccess;
declare const orgUnit_action_d_AssignRoleSuccess: typeof AssignRoleSuccess;
declare const orgUnit_action_d_CLEAR_ASSIGNED_USERS: typeof CLEAR_ASSIGNED_USERS;
declare const orgUnit_action_d_CREATE_ADDRESS: typeof CREATE_ADDRESS;
declare const orgUnit_action_d_CREATE_ADDRESS_FAIL: typeof CREATE_ADDRESS_FAIL;
declare const orgUnit_action_d_CREATE_ADDRESS_SUCCESS: typeof CREATE_ADDRESS_SUCCESS;
declare const orgUnit_action_d_CREATE_ORG_UNIT: typeof CREATE_ORG_UNIT;
declare const orgUnit_action_d_CREATE_ORG_UNIT_FAIL: typeof CREATE_ORG_UNIT_FAIL;
declare const orgUnit_action_d_CREATE_ORG_UNIT_SUCCESS: typeof CREATE_ORG_UNIT_SUCCESS;
type orgUnit_action_d_ClearAssignedUsers = ClearAssignedUsers;
declare const orgUnit_action_d_ClearAssignedUsers: typeof ClearAssignedUsers;
type orgUnit_action_d_CreateAddress = CreateAddress;
declare const orgUnit_action_d_CreateAddress: typeof CreateAddress;
type orgUnit_action_d_CreateAddressFail = CreateAddressFail;
declare const orgUnit_action_d_CreateAddressFail: typeof CreateAddressFail;
type orgUnit_action_d_CreateAddressSuccess = CreateAddressSuccess;
declare const orgUnit_action_d_CreateAddressSuccess: typeof CreateAddressSuccess;
type orgUnit_action_d_CreateUnit = CreateUnit;
declare const orgUnit_action_d_CreateUnit: typeof CreateUnit;
type orgUnit_action_d_CreateUnitFail = CreateUnitFail;
declare const orgUnit_action_d_CreateUnitFail: typeof CreateUnitFail;
type orgUnit_action_d_CreateUnitSuccess = CreateUnitSuccess;
declare const orgUnit_action_d_CreateUnitSuccess: typeof CreateUnitSuccess;
declare const orgUnit_action_d_DELETE_ADDRESS: typeof DELETE_ADDRESS;
declare const orgUnit_action_d_DELETE_ADDRESS_FAIL: typeof DELETE_ADDRESS_FAIL;
declare const orgUnit_action_d_DELETE_ADDRESS_SUCCESS: typeof DELETE_ADDRESS_SUCCESS;
type orgUnit_action_d_DeleteAddress = DeleteAddress;
declare const orgUnit_action_d_DeleteAddress: typeof DeleteAddress;
type orgUnit_action_d_DeleteAddressFail = DeleteAddressFail;
declare const orgUnit_action_d_DeleteAddressFail: typeof DeleteAddressFail;
type orgUnit_action_d_DeleteAddressSuccess = DeleteAddressSuccess;
declare const orgUnit_action_d_DeleteAddressSuccess: typeof DeleteAddressSuccess;
declare const orgUnit_action_d_LOAD_ADDRESSES: typeof LOAD_ADDRESSES;
declare const orgUnit_action_d_LOAD_ADDRESSES_FAIL: typeof LOAD_ADDRESSES_FAIL;
declare const orgUnit_action_d_LOAD_ADDRESSES_SUCCESS: typeof LOAD_ADDRESSES_SUCCESS;
declare const orgUnit_action_d_LOAD_ADDRESS_SUCCESS: typeof LOAD_ADDRESS_SUCCESS;
declare const orgUnit_action_d_LOAD_APPROVAL_PROCESSES: typeof LOAD_APPROVAL_PROCESSES;
declare const orgUnit_action_d_LOAD_APPROVAL_PROCESSES_FAIL: typeof LOAD_APPROVAL_PROCESSES_FAIL;
declare const orgUnit_action_d_LOAD_APPROVAL_PROCESSES_SUCCESS: typeof LOAD_APPROVAL_PROCESSES_SUCCESS;
declare const orgUnit_action_d_LOAD_ASSIGNED_USERS: typeof LOAD_ASSIGNED_USERS;
declare const orgUnit_action_d_LOAD_ASSIGNED_USERS_FAIL: typeof LOAD_ASSIGNED_USERS_FAIL;
declare const orgUnit_action_d_LOAD_ASSIGNED_USERS_SUCCESS: typeof LOAD_ASSIGNED_USERS_SUCCESS;
declare const orgUnit_action_d_LOAD_ORG_UNIT: typeof LOAD_ORG_UNIT;
declare const orgUnit_action_d_LOAD_ORG_UNIT_FAIL: typeof LOAD_ORG_UNIT_FAIL;
declare const orgUnit_action_d_LOAD_ORG_UNIT_SUCCESS: typeof LOAD_ORG_UNIT_SUCCESS;
declare const orgUnit_action_d_LOAD_UNIT_NODE: typeof LOAD_UNIT_NODE;
declare const orgUnit_action_d_LOAD_UNIT_NODES: typeof LOAD_UNIT_NODES;
declare const orgUnit_action_d_LOAD_UNIT_NODES_FAIL: typeof LOAD_UNIT_NODES_FAIL;
declare const orgUnit_action_d_LOAD_UNIT_NODES_SUCCESS: typeof LOAD_UNIT_NODES_SUCCESS;
declare const orgUnit_action_d_LOAD_UNIT_NODE_FAIL: typeof LOAD_UNIT_NODE_FAIL;
declare const orgUnit_action_d_LOAD_UNIT_NODE_SUCCESS: typeof LOAD_UNIT_NODE_SUCCESS;
declare const orgUnit_action_d_LOAD_UNIT_TREE: typeof LOAD_UNIT_TREE;
declare const orgUnit_action_d_LOAD_UNIT_TREE_FAIL: typeof LOAD_UNIT_TREE_FAIL;
declare const orgUnit_action_d_LOAD_UNIT_TREE_SUCCESS: typeof LOAD_UNIT_TREE_SUCCESS;
type orgUnit_action_d_LoadAddressSuccess = LoadAddressSuccess;
declare const orgUnit_action_d_LoadAddressSuccess: typeof LoadAddressSuccess;
type orgUnit_action_d_LoadAddresses = LoadAddresses;
declare const orgUnit_action_d_LoadAddresses: typeof LoadAddresses;
type orgUnit_action_d_LoadAddressesFail = LoadAddressesFail;
declare const orgUnit_action_d_LoadAddressesFail: typeof LoadAddressesFail;
type orgUnit_action_d_LoadAddressesSuccess = LoadAddressesSuccess;
declare const orgUnit_action_d_LoadAddressesSuccess: typeof LoadAddressesSuccess;
type orgUnit_action_d_LoadApprovalProcesses = LoadApprovalProcesses;
declare const orgUnit_action_d_LoadApprovalProcesses: typeof LoadApprovalProcesses;
type orgUnit_action_d_LoadApprovalProcessesFail = LoadApprovalProcessesFail;
declare const orgUnit_action_d_LoadApprovalProcessesFail: typeof LoadApprovalProcessesFail;
type orgUnit_action_d_LoadApprovalProcessesSuccess = LoadApprovalProcessesSuccess;
declare const orgUnit_action_d_LoadApprovalProcessesSuccess: typeof LoadApprovalProcessesSuccess;
type orgUnit_action_d_LoadAssignedUsers = LoadAssignedUsers;
declare const orgUnit_action_d_LoadAssignedUsers: typeof LoadAssignedUsers;
type orgUnit_action_d_LoadAssignedUsersFail = LoadAssignedUsersFail;
declare const orgUnit_action_d_LoadAssignedUsersFail: typeof LoadAssignedUsersFail;
type orgUnit_action_d_LoadAssignedUsersSuccess = LoadAssignedUsersSuccess;
declare const orgUnit_action_d_LoadAssignedUsersSuccess: typeof LoadAssignedUsersSuccess;
type orgUnit_action_d_LoadOrgUnit = LoadOrgUnit;
declare const orgUnit_action_d_LoadOrgUnit: typeof LoadOrgUnit;
type orgUnit_action_d_LoadOrgUnitFail = LoadOrgUnitFail;
declare const orgUnit_action_d_LoadOrgUnitFail: typeof LoadOrgUnitFail;
type orgUnit_action_d_LoadOrgUnitNodes = LoadOrgUnitNodes;
declare const orgUnit_action_d_LoadOrgUnitNodes: typeof LoadOrgUnitNodes;
type orgUnit_action_d_LoadOrgUnitNodesFail = LoadOrgUnitNodesFail;
declare const orgUnit_action_d_LoadOrgUnitNodesFail: typeof LoadOrgUnitNodesFail;
type orgUnit_action_d_LoadOrgUnitNodesSuccess = LoadOrgUnitNodesSuccess;
declare const orgUnit_action_d_LoadOrgUnitNodesSuccess: typeof LoadOrgUnitNodesSuccess;
type orgUnit_action_d_LoadOrgUnitSuccess = LoadOrgUnitSuccess;
declare const orgUnit_action_d_LoadOrgUnitSuccess: typeof LoadOrgUnitSuccess;
type orgUnit_action_d_LoadTree = LoadTree;
declare const orgUnit_action_d_LoadTree: typeof LoadTree;
type orgUnit_action_d_LoadTreeFail = LoadTreeFail;
declare const orgUnit_action_d_LoadTreeFail: typeof LoadTreeFail;
type orgUnit_action_d_LoadTreeSuccess = LoadTreeSuccess;
declare const orgUnit_action_d_LoadTreeSuccess: typeof LoadTreeSuccess;
type orgUnit_action_d_OrgUnitAction = OrgUnitAction;
declare const orgUnit_action_d_UNASSIGN_APPROVER: typeof UNASSIGN_APPROVER;
declare const orgUnit_action_d_UNASSIGN_APPROVER_FAIL: typeof UNASSIGN_APPROVER_FAIL;
declare const orgUnit_action_d_UNASSIGN_APPROVER_SUCCESS: typeof UNASSIGN_APPROVER_SUCCESS;
declare const orgUnit_action_d_UNASSIGN_ROLE: typeof UNASSIGN_ROLE;
declare const orgUnit_action_d_UNASSIGN_ROLE_FAIL: typeof UNASSIGN_ROLE_FAIL;
declare const orgUnit_action_d_UNASSIGN_ROLE_SUCCESS: typeof UNASSIGN_ROLE_SUCCESS;
declare const orgUnit_action_d_UPDATE_ADDRESS: typeof UPDATE_ADDRESS;
declare const orgUnit_action_d_UPDATE_ADDRESS_FAIL: typeof UPDATE_ADDRESS_FAIL;
declare const orgUnit_action_d_UPDATE_ADDRESS_SUCCESS: typeof UPDATE_ADDRESS_SUCCESS;
declare const orgUnit_action_d_UPDATE_ORG_UNIT: typeof UPDATE_ORG_UNIT;
declare const orgUnit_action_d_UPDATE_ORG_UNIT_FAIL: typeof UPDATE_ORG_UNIT_FAIL;
declare const orgUnit_action_d_UPDATE_ORG_UNIT_SUCCESS: typeof UPDATE_ORG_UNIT_SUCCESS;
type orgUnit_action_d_UnassignApprover = UnassignApprover;
declare const orgUnit_action_d_UnassignApprover: typeof UnassignApprover;
type orgUnit_action_d_UnassignApproverFail = UnassignApproverFail;
declare const orgUnit_action_d_UnassignApproverFail: typeof UnassignApproverFail;
type orgUnit_action_d_UnassignApproverSuccess = UnassignApproverSuccess;
declare const orgUnit_action_d_UnassignApproverSuccess: typeof UnassignApproverSuccess;
type orgUnit_action_d_UnassignRole = UnassignRole;
declare const orgUnit_action_d_UnassignRole: typeof UnassignRole;
type orgUnit_action_d_UnassignRoleFail = UnassignRoleFail;
declare const orgUnit_action_d_UnassignRoleFail: typeof UnassignRoleFail;
type orgUnit_action_d_UnassignRoleSuccess = UnassignRoleSuccess;
declare const orgUnit_action_d_UnassignRoleSuccess: typeof UnassignRoleSuccess;
type orgUnit_action_d_UpdateAddress = UpdateAddress;
declare const orgUnit_action_d_UpdateAddress: typeof UpdateAddress;
type orgUnit_action_d_UpdateAddressFail = UpdateAddressFail;
declare const orgUnit_action_d_UpdateAddressFail: typeof UpdateAddressFail;
type orgUnit_action_d_UpdateAddressSuccess = UpdateAddressSuccess;
declare const orgUnit_action_d_UpdateAddressSuccess: typeof UpdateAddressSuccess;
type orgUnit_action_d_UpdateUnit = UpdateUnit;
declare const orgUnit_action_d_UpdateUnit: typeof UpdateUnit;
type orgUnit_action_d_UpdateUnitFail = UpdateUnitFail;
declare const orgUnit_action_d_UpdateUnitFail: typeof UpdateUnitFail;
type orgUnit_action_d_UpdateUnitSuccess = UpdateUnitSuccess;
declare const orgUnit_action_d_UpdateUnitSuccess: typeof UpdateUnitSuccess;
declare namespace orgUnit_action_d {
  export { orgUnit_action_d_ASSIGN_APPROVER as ASSIGN_APPROVER, orgUnit_action_d_ASSIGN_APPROVER_FAIL as ASSIGN_APPROVER_FAIL, orgUnit_action_d_ASSIGN_APPROVER_SUCCESS as ASSIGN_APPROVER_SUCCESS, orgUnit_action_d_ASSIGN_ROLE as ASSIGN_ROLE, orgUnit_action_d_ASSIGN_ROLE_FAIL as ASSIGN_ROLE_FAIL, orgUnit_action_d_ASSIGN_ROLE_SUCCESS as ASSIGN_ROLE_SUCCESS, orgUnit_action_d_AssignApprover as AssignApprover, orgUnit_action_d_AssignApproverFail as AssignApproverFail, orgUnit_action_d_AssignApproverSuccess as AssignApproverSuccess, orgUnit_action_d_AssignRole as AssignRole, orgUnit_action_d_AssignRoleFail as AssignRoleFail, orgUnit_action_d_AssignRoleSuccess as AssignRoleSuccess, orgUnit_action_d_CLEAR_ASSIGNED_USERS as CLEAR_ASSIGNED_USERS, orgUnit_action_d_CREATE_ADDRESS as CREATE_ADDRESS, orgUnit_action_d_CREATE_ADDRESS_FAIL as CREATE_ADDRESS_FAIL, orgUnit_action_d_CREATE_ADDRESS_SUCCESS as CREATE_ADDRESS_SUCCESS, orgUnit_action_d_CREATE_ORG_UNIT as CREATE_ORG_UNIT, orgUnit_action_d_CREATE_ORG_UNIT_FAIL as CREATE_ORG_UNIT_FAIL, orgUnit_action_d_CREATE_ORG_UNIT_SUCCESS as CREATE_ORG_UNIT_SUCCESS, orgUnit_action_d_ClearAssignedUsers as ClearAssignedUsers, orgUnit_action_d_CreateAddress as CreateAddress, orgUnit_action_d_CreateAddressFail as CreateAddressFail, orgUnit_action_d_CreateAddressSuccess as CreateAddressSuccess, orgUnit_action_d_CreateUnit as CreateUnit, orgUnit_action_d_CreateUnitFail as CreateUnitFail, orgUnit_action_d_CreateUnitSuccess as CreateUnitSuccess, orgUnit_action_d_DELETE_ADDRESS as DELETE_ADDRESS, orgUnit_action_d_DELETE_ADDRESS_FAIL as DELETE_ADDRESS_FAIL, orgUnit_action_d_DELETE_ADDRESS_SUCCESS as DELETE_ADDRESS_SUCCESS, orgUnit_action_d_DeleteAddress as DeleteAddress, orgUnit_action_d_DeleteAddressFail as DeleteAddressFail, orgUnit_action_d_DeleteAddressSuccess as DeleteAddressSuccess, orgUnit_action_d_LOAD_ADDRESSES as LOAD_ADDRESSES, orgUnit_action_d_LOAD_ADDRESSES_FAIL as LOAD_ADDRESSES_FAIL, orgUnit_action_d_LOAD_ADDRESSES_SUCCESS as LOAD_ADDRESSES_SUCCESS, orgUnit_action_d_LOAD_ADDRESS_SUCCESS as LOAD_ADDRESS_SUCCESS, orgUnit_action_d_LOAD_APPROVAL_PROCESSES as LOAD_APPROVAL_PROCESSES, orgUnit_action_d_LOAD_APPROVAL_PROCESSES_FAIL as LOAD_APPROVAL_PROCESSES_FAIL, orgUnit_action_d_LOAD_APPROVAL_PROCESSES_SUCCESS as LOAD_APPROVAL_PROCESSES_SUCCESS, orgUnit_action_d_LOAD_ASSIGNED_USERS as LOAD_ASSIGNED_USERS, orgUnit_action_d_LOAD_ASSIGNED_USERS_FAIL as LOAD_ASSIGNED_USERS_FAIL, orgUnit_action_d_LOAD_ASSIGNED_USERS_SUCCESS as LOAD_ASSIGNED_USERS_SUCCESS, orgUnit_action_d_LOAD_ORG_UNIT as LOAD_ORG_UNIT, orgUnit_action_d_LOAD_ORG_UNIT_FAIL as LOAD_ORG_UNIT_FAIL, orgUnit_action_d_LOAD_ORG_UNIT_SUCCESS as LOAD_ORG_UNIT_SUCCESS, orgUnit_action_d_LOAD_UNIT_NODE as LOAD_UNIT_NODE, orgUnit_action_d_LOAD_UNIT_NODES as LOAD_UNIT_NODES, orgUnit_action_d_LOAD_UNIT_NODES_FAIL as LOAD_UNIT_NODES_FAIL, orgUnit_action_d_LOAD_UNIT_NODES_SUCCESS as LOAD_UNIT_NODES_SUCCESS, orgUnit_action_d_LOAD_UNIT_NODE_FAIL as LOAD_UNIT_NODE_FAIL, orgUnit_action_d_LOAD_UNIT_NODE_SUCCESS as LOAD_UNIT_NODE_SUCCESS, orgUnit_action_d_LOAD_UNIT_TREE as LOAD_UNIT_TREE, orgUnit_action_d_LOAD_UNIT_TREE_FAIL as LOAD_UNIT_TREE_FAIL, orgUnit_action_d_LOAD_UNIT_TREE_SUCCESS as LOAD_UNIT_TREE_SUCCESS, orgUnit_action_d_LoadAddressSuccess as LoadAddressSuccess, orgUnit_action_d_LoadAddresses as LoadAddresses, orgUnit_action_d_LoadAddressesFail as LoadAddressesFail, orgUnit_action_d_LoadAddressesSuccess as LoadAddressesSuccess, orgUnit_action_d_LoadApprovalProcesses as LoadApprovalProcesses, orgUnit_action_d_LoadApprovalProcessesFail as LoadApprovalProcessesFail, orgUnit_action_d_LoadApprovalProcessesSuccess as LoadApprovalProcessesSuccess, orgUnit_action_d_LoadAssignedUsers as LoadAssignedUsers, orgUnit_action_d_LoadAssignedUsersFail as LoadAssignedUsersFail, orgUnit_action_d_LoadAssignedUsersSuccess as LoadAssignedUsersSuccess, orgUnit_action_d_LoadOrgUnit as LoadOrgUnit, orgUnit_action_d_LoadOrgUnitFail as LoadOrgUnitFail, orgUnit_action_d_LoadOrgUnitNodes as LoadOrgUnitNodes, orgUnit_action_d_LoadOrgUnitNodesFail as LoadOrgUnitNodesFail, orgUnit_action_d_LoadOrgUnitNodesSuccess as LoadOrgUnitNodesSuccess, orgUnit_action_d_LoadOrgUnitSuccess as LoadOrgUnitSuccess, orgUnit_action_d_LoadTree as LoadTree, orgUnit_action_d_LoadTreeFail as LoadTreeFail, orgUnit_action_d_LoadTreeSuccess as LoadTreeSuccess, orgUnit_action_d_UNASSIGN_APPROVER as UNASSIGN_APPROVER, orgUnit_action_d_UNASSIGN_APPROVER_FAIL as UNASSIGN_APPROVER_FAIL, orgUnit_action_d_UNASSIGN_APPROVER_SUCCESS as UNASSIGN_APPROVER_SUCCESS, orgUnit_action_d_UNASSIGN_ROLE as UNASSIGN_ROLE, orgUnit_action_d_UNASSIGN_ROLE_FAIL as UNASSIGN_ROLE_FAIL, orgUnit_action_d_UNASSIGN_ROLE_SUCCESS as UNASSIGN_ROLE_SUCCESS, orgUnit_action_d_UPDATE_ADDRESS as UPDATE_ADDRESS, orgUnit_action_d_UPDATE_ADDRESS_FAIL as UPDATE_ADDRESS_FAIL, orgUnit_action_d_UPDATE_ADDRESS_SUCCESS as UPDATE_ADDRESS_SUCCESS, orgUnit_action_d_UPDATE_ORG_UNIT as UPDATE_ORG_UNIT, orgUnit_action_d_UPDATE_ORG_UNIT_FAIL as UPDATE_ORG_UNIT_FAIL, orgUnit_action_d_UPDATE_ORG_UNIT_SUCCESS as UPDATE_ORG_UNIT_SUCCESS, orgUnit_action_d_UnassignApprover as UnassignApprover, orgUnit_action_d_UnassignApproverFail as UnassignApproverFail, orgUnit_action_d_UnassignApproverSuccess as UnassignApproverSuccess, orgUnit_action_d_UnassignRole as UnassignRole, orgUnit_action_d_UnassignRoleFail as UnassignRoleFail, orgUnit_action_d_UnassignRoleSuccess as UnassignRoleSuccess, orgUnit_action_d_UpdateAddress as UpdateAddress, orgUnit_action_d_UpdateAddressFail as UpdateAddressFail, orgUnit_action_d_UpdateAddressSuccess as UpdateAddressSuccess, orgUnit_action_d_UpdateUnit as UpdateUnit, orgUnit_action_d_UpdateUnitFail as UpdateUnitFail, orgUnit_action_d_UpdateUnitSuccess as UpdateUnitSuccess };
  export type { orgUnit_action_d_OrgUnitAction as OrgUnitAction };
}

declare const LOAD_USER_GROUP = "[UserGroup] Load UserGroup Data";
declare const LOAD_USER_GROUP_FAIL = "[UserGroup] Load UserGroup Data Fail";
declare const LOAD_USER_GROUP_SUCCESS = "[UserGroup] Load UserGroup Data Success";
declare const LOAD_USER_GROUPS = "[UserGroup] Load UserGroups";
declare const LOAD_USER_GROUPS_FAIL = "[UserGroup] Load UserGroups Fail";
declare const LOAD_USER_GROUPS_SUCCESS = "[UserGroup] Load UserGroups Success";
declare const LOAD_USER_GROUP_PERMISSIONS = "[UserGroup] Load Permissions Data";
declare const LOAD_USER_GROUP_PERMISSIONS_FAIL = "[UserGroup] Load Permissions Data Fail";
declare const LOAD_USER_GROUP_PERMISSIONS_SUCCESS = "[UserGroup] Load Permissions Data Success";
declare const LOAD_USER_GROUP_AVAILABLE_CUSTOMERS = "[UserGroup] Load Customers Data";
declare const LOAD_USER_GROUP_AVAILABLE_CUSTOMERS_FAIL = "[UserGroup] Load Customers Data Fail";
declare const LOAD_USER_GROUP_AVAILABLE_CUSTOMERS_SUCCESS = "[UserGroup] Load Customers Data Success";
declare const CREATE_USER_GROUP = "[UserGroup] Create UserGroup";
declare const CREATE_USER_GROUP_FAIL = "[UserGroup] Create UserGroup Fail";
declare const CREATE_USER_GROUP_SUCCESS = "[UserGroup] Create UserGroup Success";
declare const USER_GROUP_ASSIGN_MEMBER = "[UserGroup] Assign Member";
declare const USER_GROUP_ASSIGN_MEMBER_FAIL = "[UserGroup] Assign Member Fail";
declare const USER_GROUP_ASSIGN_MEMBER_SUCCESS = "[UserGroup] Assign Member Success";
declare const USER_GROUP_ASSIGN_PERMISSION = "[UserGroup] Assign Permissions";
declare const USER_GROUP_ASSIGN_PERMISSION_FAIL = "[UserGroup] Assign Permissions Fail";
declare const USER_GROUP_ASSIGN_PERMISSION_SUCCESS = "[UserGroup] Assign Permissions Success";
declare const UPDATE_USER_GROUP = "[UserGroup] Update UserGroup";
declare const UPDATE_USER_GROUP_FAIL = "[UserGroup] Update UserGroup Fail";
declare const UPDATE_USER_GROUP_SUCCESS = "[UserGroup] Update UserGroup Success";
declare const DELETE_USER_GROUP = "[UserGroup] Delete UserGroup";
declare const DELETE_USER_GROUP_FAIL = "[UserGroup] Delete UserGroup Fail";
declare const DELETE_USER_GROUP_SUCCESS = "[UserGroup] Delete UserGroup Success";
declare const USER_GROUP_UNASSIGN_ALL_MEMBERS = "[UserGroup] Unassign Members";
declare const USER_GROUP_UNASSIGN_ALL_MEMBERS_FAIL = "[UserGroup] Unassign Members Fail";
declare const USER_GROUP_UNASSIGN_ALL_MEMBERS_SUCCESS = "[UserGroup] Unassign Members Success";
declare const USER_GROUP_UNASSIGN_MEMBER = "[UserGroup] Unassign Member";
declare const USER_GROUP_UNASSIGN_MEMBER_FAIL = "[UserGroup] Unassign Member Fail";
declare const USER_GROUP_UNASSIGN_MEMBER_SUCCESS = "[UserGroup] Unassign Member Success";
declare const USER_GROUP_UNASSIGN_PERMISSION = "[UserGroup] Unassign Permission";
declare const USER_GROUP_UNASSIGN_PERMISSION_FAIL = "[UserGroup] Unassign Permission Fail";
declare const USER_GROUP_UNASSIGN_PERMISSION_SUCCESS = "[UserGroup] Unassign Permission Success";
declare class LoadUserGroup extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        userGroupId: string;
    };
    readonly type = "[UserGroup] Load UserGroup Data";
    constructor(payload: {
        userId: string;
        userGroupId: string;
    });
}
declare class LoadUserGroupFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userGroupId: string;
        error: any;
    };
    readonly type = "[UserGroup] Load UserGroup Data Fail";
    constructor(payload: {
        userGroupId: string;
        error: any;
    });
}
declare class LoadUserGroupSuccess extends StateUtils.EntitySuccessAction {
    payload: UserGroup | UserGroup[];
    readonly type = "[UserGroup] Load UserGroup Data Success";
    constructor(payload: UserGroup | UserGroup[]);
}
declare class LoadUserGroups extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        params: SearchConfig;
    };
    readonly type = "[UserGroup] Load UserGroups";
    constructor(payload: {
        userId: string;
        params: SearchConfig;
    });
}
declare class LoadUserGroupsFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        params: SearchConfig;
        error: any;
    };
    readonly type = "[UserGroup] Load UserGroups Fail";
    constructor(payload: {
        params: SearchConfig;
        error: any;
    });
}
declare class LoadUserGroupsSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        page: ListModel;
        params: SearchConfig;
    };
    readonly type = "[UserGroup] Load UserGroups Success";
    constructor(payload: {
        page: ListModel;
        params: SearchConfig;
    });
}
declare class LoadPermissions$1 extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        userGroupId: string;
        params: SearchConfig;
    };
    readonly type = "[UserGroup] Load Permissions Data";
    constructor(payload: {
        userId: string;
        userGroupId: string;
        params: SearchConfig;
    });
}
declare class LoadPermissionsFail$1 extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userGroupId: string;
        params: SearchConfig;
        error: any;
    };
    readonly type = "[UserGroup] Load Permissions Data Fail";
    constructor(payload: {
        userGroupId: string;
        params: SearchConfig;
        error: any;
    });
}
declare class LoadPermissionsSuccess$1 extends StateUtils.EntitySuccessAction {
    payload: {
        userGroupId: string;
        page: ListModel;
        params: SearchConfig;
    };
    readonly type = "[UserGroup] Load Permissions Data Success";
    constructor(payload: {
        userGroupId: string;
        page: ListModel;
        params: SearchConfig;
    });
}
declare class LoadAvailableOrgCustomers extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        userGroupId: string;
        params: SearchConfig;
    };
    readonly type = "[UserGroup] Load Customers Data";
    constructor(payload: {
        userId: string;
        userGroupId: string;
        params: SearchConfig;
    });
}
declare class LoadAvailableOrgCustomersFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userGroupId: string;
        params: SearchConfig;
        error: any;
    };
    readonly type = "[UserGroup] Load Customers Data Fail";
    constructor(payload: {
        userGroupId: string;
        params: SearchConfig;
        error: any;
    });
}
declare class LoadAvailableOrgCustomersSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        userGroupId: string;
        page: ListModel;
        params: SearchConfig;
    };
    readonly type = "[UserGroup] Load Customers Data Success";
    constructor(payload: {
        userGroupId: string;
        page: ListModel;
        params: SearchConfig;
    });
}
declare class CreateUserGroup extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        userGroup: UserGroup;
    };
    readonly type = "[UserGroup] Create UserGroup";
    constructor(payload: {
        userId: string;
        userGroup: UserGroup;
    });
}
declare class CreateUserGroupFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userGroupId: string;
        error: any;
    };
    readonly type = "[UserGroup] Create UserGroup Fail";
    constructor(payload: {
        userGroupId: string;
        error: any;
    });
}
declare class CreateUserGroupSuccess extends StateUtils.EntitySuccessAction {
    payload: UserGroup;
    readonly type = "[UserGroup] Create UserGroup Success";
    constructor(payload: UserGroup);
}
declare class AssignMember extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        userGroupId: string;
        customerId: string;
    };
    readonly type = "[UserGroup] Assign Member";
    constructor(payload: {
        userId: string;
        userGroupId: string;
        customerId: string;
    });
}
declare class AssignMemberFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userGroupId: string;
        customerId: string;
        error: any;
    };
    readonly type = "[UserGroup] Assign Member Fail";
    constructor(payload: {
        userGroupId: string;
        customerId: string;
        error: any;
    });
}
declare class AssignMemberSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        customerId: string;
        selected: boolean;
    };
    readonly type = "[UserGroup] Assign Member Success";
    constructor(payload: {
        customerId: string;
        selected: boolean;
    });
}
declare class AssignPermission extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        userGroupId: string;
        permissionUid: string;
    };
    readonly type = "[UserGroup] Assign Permissions";
    constructor(payload: {
        userId: string;
        userGroupId: string;
        permissionUid: string;
    });
}
declare class AssignPermissionFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userGroupId: string;
        permissionUid: string;
        error: any;
    };
    readonly type = "[UserGroup] Assign Permissions Fail";
    constructor(payload: {
        userGroupId: string;
        permissionUid: string;
        error: any;
    });
}
declare class AssignPermissionSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        permissionUid: string;
        selected: boolean;
    };
    readonly type = "[UserGroup] Assign Permissions Success";
    constructor(payload: {
        permissionUid: string;
        selected: boolean;
    });
}
declare class UpdateUserGroup extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        userGroupId: string;
        userGroup: UserGroup;
    };
    readonly type = "[UserGroup] Update UserGroup";
    constructor(payload: {
        userId: string;
        userGroupId: string;
        userGroup: UserGroup;
    });
}
declare class UpdateUserGroupFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userGroupId: string;
        error: any;
    };
    readonly type = "[UserGroup] Update UserGroup Fail";
    constructor(payload: {
        userGroupId: string;
        error: any;
    });
}
declare class UpdateUserGroupSuccess extends StateUtils.EntitySuccessAction {
    payload: UserGroup;
    readonly type = "[UserGroup] Update UserGroup Success";
    constructor(payload: UserGroup);
}
declare class DeleteUserGroup extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        userGroupId: string;
    };
    readonly type = "[UserGroup] Delete UserGroup";
    constructor(payload: {
        userId: string;
        userGroupId: string;
    });
}
declare class DeleteUserGroupFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userGroupId: string;
        error: any;
    };
    readonly type = "[UserGroup] Delete UserGroup Fail";
    constructor(payload: {
        userGroupId: string;
        error: any;
    });
}
declare class DeleteUserGroupSuccess extends StateUtils.EntitySuccessAction {
    payload: UserGroup;
    readonly type = "[UserGroup] Delete UserGroup Success";
    constructor(payload: UserGroup);
}
declare class UnassignMember extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        userGroupId: string;
        customerId: string;
    };
    readonly type = "[UserGroup] Unassign Member";
    constructor(payload: {
        userId: string;
        userGroupId: string;
        customerId: string;
    });
}
declare class UnassignMemberFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userGroupId: string;
        customerId: string;
        error: any;
    };
    readonly type = "[UserGroup] Unassign Member Fail";
    constructor(payload: {
        userGroupId: string;
        customerId: string;
        error: any;
    });
}
declare class UnassignMemberSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        customerId: string;
        selected: boolean;
    };
    readonly type = "[UserGroup] Unassign Member Success";
    constructor(payload: {
        customerId: string;
        selected: boolean;
    });
}
declare class UnassignAllMembers extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        userGroupId: string;
    };
    readonly type = "[UserGroup] Unassign Members";
    constructor(payload: {
        userId: string;
        userGroupId: string;
    });
}
declare class UnassignAllMembersFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userGroupId: string;
        error: any;
    };
    readonly type = "[UserGroup] Unassign Members Fail";
    constructor(payload: {
        userGroupId: string;
        error: any;
    });
}
declare class UnassignAllMembersSuccess extends StateUtils.EntitySuccessAction {
    payload: UserGroup;
    readonly type = "[UserGroup] Unassign Members Success";
    constructor(payload: UserGroup);
}
declare class UnassignPermission extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        userGroupId: string;
        permissionUid: string;
    };
    readonly type = "[UserGroup] Unassign Permission";
    constructor(payload: {
        userId: string;
        userGroupId: string;
        permissionUid: string;
    });
}
declare class UnassignPermissionFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userGroupId: string;
        permissionUid: string;
        error: any;
    };
    readonly type = "[UserGroup] Unassign Permission Fail";
    constructor(payload: {
        userGroupId: string;
        permissionUid: string;
        error: any;
    });
}
declare class UnassignPermissionSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        permissionUid: string;
        selected: boolean;
    };
    readonly type = "[UserGroup] Unassign Permission Success";
    constructor(payload: {
        permissionUid: string;
        selected: boolean;
    });
}
type UserGroupAction = LoadUserGroup | LoadUserGroupFail | LoadUserGroupSuccess | LoadUserGroups | LoadUserGroupsFail | LoadUserGroupsSuccess | LoadPermissions$1 | LoadPermissionsFail$1 | LoadPermissionsSuccess$1 | LoadAvailableOrgCustomers | LoadAvailableOrgCustomersFail | LoadAvailableOrgCustomersSuccess | CreateUserGroup | CreateUserGroupFail | CreateUserGroupSuccess | AssignMember | AssignMemberFail | AssignMemberSuccess | AssignPermission | AssignPermissionFail | AssignPermissionSuccess | UpdateUserGroup | UpdateUserGroupFail | UpdateUserGroupSuccess | DeleteUserGroup | DeleteUserGroupFail | DeleteUserGroupSuccess | UnassignMember | UnassignMemberFail | UnassignMemberSuccess | UnassignAllMembers | UnassignAllMembersFail | UnassignAllMembersSuccess | UnassignPermission | UnassignPermissionFail | UnassignPermissionSuccess;

type userGroup_action_d_AssignMember = AssignMember;
declare const userGroup_action_d_AssignMember: typeof AssignMember;
type userGroup_action_d_AssignMemberFail = AssignMemberFail;
declare const userGroup_action_d_AssignMemberFail: typeof AssignMemberFail;
type userGroup_action_d_AssignMemberSuccess = AssignMemberSuccess;
declare const userGroup_action_d_AssignMemberSuccess: typeof AssignMemberSuccess;
type userGroup_action_d_AssignPermission = AssignPermission;
declare const userGroup_action_d_AssignPermission: typeof AssignPermission;
type userGroup_action_d_AssignPermissionFail = AssignPermissionFail;
declare const userGroup_action_d_AssignPermissionFail: typeof AssignPermissionFail;
type userGroup_action_d_AssignPermissionSuccess = AssignPermissionSuccess;
declare const userGroup_action_d_AssignPermissionSuccess: typeof AssignPermissionSuccess;
declare const userGroup_action_d_CREATE_USER_GROUP: typeof CREATE_USER_GROUP;
declare const userGroup_action_d_CREATE_USER_GROUP_FAIL: typeof CREATE_USER_GROUP_FAIL;
declare const userGroup_action_d_CREATE_USER_GROUP_SUCCESS: typeof CREATE_USER_GROUP_SUCCESS;
type userGroup_action_d_CreateUserGroup = CreateUserGroup;
declare const userGroup_action_d_CreateUserGroup: typeof CreateUserGroup;
type userGroup_action_d_CreateUserGroupFail = CreateUserGroupFail;
declare const userGroup_action_d_CreateUserGroupFail: typeof CreateUserGroupFail;
type userGroup_action_d_CreateUserGroupSuccess = CreateUserGroupSuccess;
declare const userGroup_action_d_CreateUserGroupSuccess: typeof CreateUserGroupSuccess;
declare const userGroup_action_d_DELETE_USER_GROUP: typeof DELETE_USER_GROUP;
declare const userGroup_action_d_DELETE_USER_GROUP_FAIL: typeof DELETE_USER_GROUP_FAIL;
declare const userGroup_action_d_DELETE_USER_GROUP_SUCCESS: typeof DELETE_USER_GROUP_SUCCESS;
type userGroup_action_d_DeleteUserGroup = DeleteUserGroup;
declare const userGroup_action_d_DeleteUserGroup: typeof DeleteUserGroup;
type userGroup_action_d_DeleteUserGroupFail = DeleteUserGroupFail;
declare const userGroup_action_d_DeleteUserGroupFail: typeof DeleteUserGroupFail;
type userGroup_action_d_DeleteUserGroupSuccess = DeleteUserGroupSuccess;
declare const userGroup_action_d_DeleteUserGroupSuccess: typeof DeleteUserGroupSuccess;
declare const userGroup_action_d_LOAD_USER_GROUP: typeof LOAD_USER_GROUP;
declare const userGroup_action_d_LOAD_USER_GROUPS: typeof LOAD_USER_GROUPS;
declare const userGroup_action_d_LOAD_USER_GROUPS_FAIL: typeof LOAD_USER_GROUPS_FAIL;
declare const userGroup_action_d_LOAD_USER_GROUPS_SUCCESS: typeof LOAD_USER_GROUPS_SUCCESS;
declare const userGroup_action_d_LOAD_USER_GROUP_AVAILABLE_CUSTOMERS: typeof LOAD_USER_GROUP_AVAILABLE_CUSTOMERS;
declare const userGroup_action_d_LOAD_USER_GROUP_AVAILABLE_CUSTOMERS_FAIL: typeof LOAD_USER_GROUP_AVAILABLE_CUSTOMERS_FAIL;
declare const userGroup_action_d_LOAD_USER_GROUP_AVAILABLE_CUSTOMERS_SUCCESS: typeof LOAD_USER_GROUP_AVAILABLE_CUSTOMERS_SUCCESS;
declare const userGroup_action_d_LOAD_USER_GROUP_FAIL: typeof LOAD_USER_GROUP_FAIL;
declare const userGroup_action_d_LOAD_USER_GROUP_PERMISSIONS: typeof LOAD_USER_GROUP_PERMISSIONS;
declare const userGroup_action_d_LOAD_USER_GROUP_PERMISSIONS_FAIL: typeof LOAD_USER_GROUP_PERMISSIONS_FAIL;
declare const userGroup_action_d_LOAD_USER_GROUP_PERMISSIONS_SUCCESS: typeof LOAD_USER_GROUP_PERMISSIONS_SUCCESS;
declare const userGroup_action_d_LOAD_USER_GROUP_SUCCESS: typeof LOAD_USER_GROUP_SUCCESS;
type userGroup_action_d_LoadAvailableOrgCustomers = LoadAvailableOrgCustomers;
declare const userGroup_action_d_LoadAvailableOrgCustomers: typeof LoadAvailableOrgCustomers;
type userGroup_action_d_LoadAvailableOrgCustomersFail = LoadAvailableOrgCustomersFail;
declare const userGroup_action_d_LoadAvailableOrgCustomersFail: typeof LoadAvailableOrgCustomersFail;
type userGroup_action_d_LoadAvailableOrgCustomersSuccess = LoadAvailableOrgCustomersSuccess;
declare const userGroup_action_d_LoadAvailableOrgCustomersSuccess: typeof LoadAvailableOrgCustomersSuccess;
type userGroup_action_d_LoadUserGroup = LoadUserGroup;
declare const userGroup_action_d_LoadUserGroup: typeof LoadUserGroup;
type userGroup_action_d_LoadUserGroupFail = LoadUserGroupFail;
declare const userGroup_action_d_LoadUserGroupFail: typeof LoadUserGroupFail;
type userGroup_action_d_LoadUserGroupSuccess = LoadUserGroupSuccess;
declare const userGroup_action_d_LoadUserGroupSuccess: typeof LoadUserGroupSuccess;
type userGroup_action_d_LoadUserGroups = LoadUserGroups;
declare const userGroup_action_d_LoadUserGroups: typeof LoadUserGroups;
type userGroup_action_d_LoadUserGroupsFail = LoadUserGroupsFail;
declare const userGroup_action_d_LoadUserGroupsFail: typeof LoadUserGroupsFail;
type userGroup_action_d_LoadUserGroupsSuccess = LoadUserGroupsSuccess;
declare const userGroup_action_d_LoadUserGroupsSuccess: typeof LoadUserGroupsSuccess;
declare const userGroup_action_d_UPDATE_USER_GROUP: typeof UPDATE_USER_GROUP;
declare const userGroup_action_d_UPDATE_USER_GROUP_FAIL: typeof UPDATE_USER_GROUP_FAIL;
declare const userGroup_action_d_UPDATE_USER_GROUP_SUCCESS: typeof UPDATE_USER_GROUP_SUCCESS;
declare const userGroup_action_d_USER_GROUP_ASSIGN_MEMBER: typeof USER_GROUP_ASSIGN_MEMBER;
declare const userGroup_action_d_USER_GROUP_ASSIGN_MEMBER_FAIL: typeof USER_GROUP_ASSIGN_MEMBER_FAIL;
declare const userGroup_action_d_USER_GROUP_ASSIGN_MEMBER_SUCCESS: typeof USER_GROUP_ASSIGN_MEMBER_SUCCESS;
declare const userGroup_action_d_USER_GROUP_ASSIGN_PERMISSION: typeof USER_GROUP_ASSIGN_PERMISSION;
declare const userGroup_action_d_USER_GROUP_ASSIGN_PERMISSION_FAIL: typeof USER_GROUP_ASSIGN_PERMISSION_FAIL;
declare const userGroup_action_d_USER_GROUP_ASSIGN_PERMISSION_SUCCESS: typeof USER_GROUP_ASSIGN_PERMISSION_SUCCESS;
declare const userGroup_action_d_USER_GROUP_UNASSIGN_ALL_MEMBERS: typeof USER_GROUP_UNASSIGN_ALL_MEMBERS;
declare const userGroup_action_d_USER_GROUP_UNASSIGN_ALL_MEMBERS_FAIL: typeof USER_GROUP_UNASSIGN_ALL_MEMBERS_FAIL;
declare const userGroup_action_d_USER_GROUP_UNASSIGN_ALL_MEMBERS_SUCCESS: typeof USER_GROUP_UNASSIGN_ALL_MEMBERS_SUCCESS;
declare const userGroup_action_d_USER_GROUP_UNASSIGN_MEMBER: typeof USER_GROUP_UNASSIGN_MEMBER;
declare const userGroup_action_d_USER_GROUP_UNASSIGN_MEMBER_FAIL: typeof USER_GROUP_UNASSIGN_MEMBER_FAIL;
declare const userGroup_action_d_USER_GROUP_UNASSIGN_MEMBER_SUCCESS: typeof USER_GROUP_UNASSIGN_MEMBER_SUCCESS;
declare const userGroup_action_d_USER_GROUP_UNASSIGN_PERMISSION: typeof USER_GROUP_UNASSIGN_PERMISSION;
declare const userGroup_action_d_USER_GROUP_UNASSIGN_PERMISSION_FAIL: typeof USER_GROUP_UNASSIGN_PERMISSION_FAIL;
declare const userGroup_action_d_USER_GROUP_UNASSIGN_PERMISSION_SUCCESS: typeof USER_GROUP_UNASSIGN_PERMISSION_SUCCESS;
type userGroup_action_d_UnassignAllMembers = UnassignAllMembers;
declare const userGroup_action_d_UnassignAllMembers: typeof UnassignAllMembers;
type userGroup_action_d_UnassignAllMembersFail = UnassignAllMembersFail;
declare const userGroup_action_d_UnassignAllMembersFail: typeof UnassignAllMembersFail;
type userGroup_action_d_UnassignAllMembersSuccess = UnassignAllMembersSuccess;
declare const userGroup_action_d_UnassignAllMembersSuccess: typeof UnassignAllMembersSuccess;
type userGroup_action_d_UnassignMember = UnassignMember;
declare const userGroup_action_d_UnassignMember: typeof UnassignMember;
type userGroup_action_d_UnassignMemberFail = UnassignMemberFail;
declare const userGroup_action_d_UnassignMemberFail: typeof UnassignMemberFail;
type userGroup_action_d_UnassignMemberSuccess = UnassignMemberSuccess;
declare const userGroup_action_d_UnassignMemberSuccess: typeof UnassignMemberSuccess;
type userGroup_action_d_UnassignPermission = UnassignPermission;
declare const userGroup_action_d_UnassignPermission: typeof UnassignPermission;
type userGroup_action_d_UnassignPermissionFail = UnassignPermissionFail;
declare const userGroup_action_d_UnassignPermissionFail: typeof UnassignPermissionFail;
type userGroup_action_d_UnassignPermissionSuccess = UnassignPermissionSuccess;
declare const userGroup_action_d_UnassignPermissionSuccess: typeof UnassignPermissionSuccess;
type userGroup_action_d_UpdateUserGroup = UpdateUserGroup;
declare const userGroup_action_d_UpdateUserGroup: typeof UpdateUserGroup;
type userGroup_action_d_UpdateUserGroupFail = UpdateUserGroupFail;
declare const userGroup_action_d_UpdateUserGroupFail: typeof UpdateUserGroupFail;
type userGroup_action_d_UpdateUserGroupSuccess = UpdateUserGroupSuccess;
declare const userGroup_action_d_UpdateUserGroupSuccess: typeof UpdateUserGroupSuccess;
type userGroup_action_d_UserGroupAction = UserGroupAction;
declare namespace userGroup_action_d {
  export { userGroup_action_d_AssignMember as AssignMember, userGroup_action_d_AssignMemberFail as AssignMemberFail, userGroup_action_d_AssignMemberSuccess as AssignMemberSuccess, userGroup_action_d_AssignPermission as AssignPermission, userGroup_action_d_AssignPermissionFail as AssignPermissionFail, userGroup_action_d_AssignPermissionSuccess as AssignPermissionSuccess, userGroup_action_d_CREATE_USER_GROUP as CREATE_USER_GROUP, userGroup_action_d_CREATE_USER_GROUP_FAIL as CREATE_USER_GROUP_FAIL, userGroup_action_d_CREATE_USER_GROUP_SUCCESS as CREATE_USER_GROUP_SUCCESS, userGroup_action_d_CreateUserGroup as CreateUserGroup, userGroup_action_d_CreateUserGroupFail as CreateUserGroupFail, userGroup_action_d_CreateUserGroupSuccess as CreateUserGroupSuccess, userGroup_action_d_DELETE_USER_GROUP as DELETE_USER_GROUP, userGroup_action_d_DELETE_USER_GROUP_FAIL as DELETE_USER_GROUP_FAIL, userGroup_action_d_DELETE_USER_GROUP_SUCCESS as DELETE_USER_GROUP_SUCCESS, userGroup_action_d_DeleteUserGroup as DeleteUserGroup, userGroup_action_d_DeleteUserGroupFail as DeleteUserGroupFail, userGroup_action_d_DeleteUserGroupSuccess as DeleteUserGroupSuccess, userGroup_action_d_LOAD_USER_GROUP as LOAD_USER_GROUP, userGroup_action_d_LOAD_USER_GROUPS as LOAD_USER_GROUPS, userGroup_action_d_LOAD_USER_GROUPS_FAIL as LOAD_USER_GROUPS_FAIL, userGroup_action_d_LOAD_USER_GROUPS_SUCCESS as LOAD_USER_GROUPS_SUCCESS, userGroup_action_d_LOAD_USER_GROUP_AVAILABLE_CUSTOMERS as LOAD_USER_GROUP_AVAILABLE_CUSTOMERS, userGroup_action_d_LOAD_USER_GROUP_AVAILABLE_CUSTOMERS_FAIL as LOAD_USER_GROUP_AVAILABLE_CUSTOMERS_FAIL, userGroup_action_d_LOAD_USER_GROUP_AVAILABLE_CUSTOMERS_SUCCESS as LOAD_USER_GROUP_AVAILABLE_CUSTOMERS_SUCCESS, userGroup_action_d_LOAD_USER_GROUP_FAIL as LOAD_USER_GROUP_FAIL, userGroup_action_d_LOAD_USER_GROUP_PERMISSIONS as LOAD_USER_GROUP_PERMISSIONS, userGroup_action_d_LOAD_USER_GROUP_PERMISSIONS_FAIL as LOAD_USER_GROUP_PERMISSIONS_FAIL, userGroup_action_d_LOAD_USER_GROUP_PERMISSIONS_SUCCESS as LOAD_USER_GROUP_PERMISSIONS_SUCCESS, userGroup_action_d_LOAD_USER_GROUP_SUCCESS as LOAD_USER_GROUP_SUCCESS, userGroup_action_d_LoadAvailableOrgCustomers as LoadAvailableOrgCustomers, userGroup_action_d_LoadAvailableOrgCustomersFail as LoadAvailableOrgCustomersFail, userGroup_action_d_LoadAvailableOrgCustomersSuccess as LoadAvailableOrgCustomersSuccess, LoadPermissions$1 as LoadPermissions, LoadPermissionsFail$1 as LoadPermissionsFail, LoadPermissionsSuccess$1 as LoadPermissionsSuccess, userGroup_action_d_LoadUserGroup as LoadUserGroup, userGroup_action_d_LoadUserGroupFail as LoadUserGroupFail, userGroup_action_d_LoadUserGroupSuccess as LoadUserGroupSuccess, userGroup_action_d_LoadUserGroups as LoadUserGroups, userGroup_action_d_LoadUserGroupsFail as LoadUserGroupsFail, userGroup_action_d_LoadUserGroupsSuccess as LoadUserGroupsSuccess, userGroup_action_d_UPDATE_USER_GROUP as UPDATE_USER_GROUP, userGroup_action_d_UPDATE_USER_GROUP_FAIL as UPDATE_USER_GROUP_FAIL, userGroup_action_d_UPDATE_USER_GROUP_SUCCESS as UPDATE_USER_GROUP_SUCCESS, userGroup_action_d_USER_GROUP_ASSIGN_MEMBER as USER_GROUP_ASSIGN_MEMBER, userGroup_action_d_USER_GROUP_ASSIGN_MEMBER_FAIL as USER_GROUP_ASSIGN_MEMBER_FAIL, userGroup_action_d_USER_GROUP_ASSIGN_MEMBER_SUCCESS as USER_GROUP_ASSIGN_MEMBER_SUCCESS, userGroup_action_d_USER_GROUP_ASSIGN_PERMISSION as USER_GROUP_ASSIGN_PERMISSION, userGroup_action_d_USER_GROUP_ASSIGN_PERMISSION_FAIL as USER_GROUP_ASSIGN_PERMISSION_FAIL, userGroup_action_d_USER_GROUP_ASSIGN_PERMISSION_SUCCESS as USER_GROUP_ASSIGN_PERMISSION_SUCCESS, userGroup_action_d_USER_GROUP_UNASSIGN_ALL_MEMBERS as USER_GROUP_UNASSIGN_ALL_MEMBERS, userGroup_action_d_USER_GROUP_UNASSIGN_ALL_MEMBERS_FAIL as USER_GROUP_UNASSIGN_ALL_MEMBERS_FAIL, userGroup_action_d_USER_GROUP_UNASSIGN_ALL_MEMBERS_SUCCESS as USER_GROUP_UNASSIGN_ALL_MEMBERS_SUCCESS, userGroup_action_d_USER_GROUP_UNASSIGN_MEMBER as USER_GROUP_UNASSIGN_MEMBER, userGroup_action_d_USER_GROUP_UNASSIGN_MEMBER_FAIL as USER_GROUP_UNASSIGN_MEMBER_FAIL, userGroup_action_d_USER_GROUP_UNASSIGN_MEMBER_SUCCESS as USER_GROUP_UNASSIGN_MEMBER_SUCCESS, userGroup_action_d_USER_GROUP_UNASSIGN_PERMISSION as USER_GROUP_UNASSIGN_PERMISSION, userGroup_action_d_USER_GROUP_UNASSIGN_PERMISSION_FAIL as USER_GROUP_UNASSIGN_PERMISSION_FAIL, userGroup_action_d_USER_GROUP_UNASSIGN_PERMISSION_SUCCESS as USER_GROUP_UNASSIGN_PERMISSION_SUCCESS, userGroup_action_d_UnassignAllMembers as UnassignAllMembers, userGroup_action_d_UnassignAllMembersFail as UnassignAllMembersFail, userGroup_action_d_UnassignAllMembersSuccess as UnassignAllMembersSuccess, userGroup_action_d_UnassignMember as UnassignMember, userGroup_action_d_UnassignMemberFail as UnassignMemberFail, userGroup_action_d_UnassignMemberSuccess as UnassignMemberSuccess, userGroup_action_d_UnassignPermission as UnassignPermission, userGroup_action_d_UnassignPermissionFail as UnassignPermissionFail, userGroup_action_d_UnassignPermissionSuccess as UnassignPermissionSuccess, userGroup_action_d_UpdateUserGroup as UpdateUserGroup, userGroup_action_d_UpdateUserGroupFail as UpdateUserGroupFail, userGroup_action_d_UpdateUserGroupSuccess as UpdateUserGroupSuccess };
  export type { userGroup_action_d_UserGroupAction as UserGroupAction };
}

declare const LOAD_PERMISSION = "[Permission] Load Permission Data";
declare const LOAD_PERMISSION_FAIL = "[Permission] Load Permission Data Fail";
declare const LOAD_PERMISSION_SUCCESS = "[Permission] Load Permission Data Success";
declare const LOAD_PERMISSIONS = "[Permission] Load Permissions";
declare const LOAD_PERMISSIONS_FAIL = "[Permission] Load Permissions Fail";
declare const LOAD_PERMISSIONS_SUCCESS = "[Permission] Load Permissions Success";
declare const CREATE_PERMISSION = "[Permission] Create Permission";
declare const CREATE_PERMISSION_FAIL = "[Permission] Create Permission Fail";
declare const CREATE_PERMISSION_SUCCESS = "[Permission] Create Permission Success";
declare const UPDATE_PERMISSION = "[Permission] Update Permission";
declare const UPDATE_PERMISSION_FAIL = "[Permission] Update Permission Fail";
declare const UPDATE_PERMISSION_SUCCESS = "[Permission] Update Permission Success";
declare const LOAD_PERMISSION_TYPES = "[Permission Types] Load Permission Types";
declare const LOAD_PERMISSION_TYPES_FAIL = "[Permission Types] Load Permission Types Fail";
declare const LOAD_PERMISSION_TYPES_SUCCESS = "[Permission Types] Load Permission Types Success";
declare class LoadPermission extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        permissionCode: string;
    };
    readonly type = "[Permission] Load Permission Data";
    constructor(payload: {
        userId: string;
        permissionCode: string;
    });
}
declare class LoadPermissionFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        permissionCode: string;
        error: any;
    };
    readonly type = "[Permission] Load Permission Data Fail";
    constructor(payload: {
        permissionCode: string;
        error: any;
    });
}
declare class LoadPermissionSuccess extends StateUtils.EntitySuccessAction {
    payload: Permission | Permission[];
    readonly type = "[Permission] Load Permission Data Success";
    constructor(payload: Permission | Permission[]);
}
declare class LoadPermissions extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        params: SearchConfig;
    };
    readonly type = "[Permission] Load Permissions";
    constructor(payload: {
        userId: string;
        params: SearchConfig;
    });
}
declare class LoadPermissionsFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        params: SearchConfig;
        error: any;
    };
    readonly type = "[Permission] Load Permissions Fail";
    constructor(payload: {
        params: SearchConfig;
        error: any;
    });
}
declare class LoadPermissionsSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        page: ListModel;
        params: SearchConfig;
    };
    readonly type = "[Permission] Load Permissions Success";
    constructor(payload: {
        page: ListModel;
        params: SearchConfig;
    });
}
declare class CreatePermission extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        permission: Permission;
    };
    readonly type = "[Permission] Create Permission";
    constructor(payload: {
        userId: string;
        permission: Permission;
    });
}
declare class CreatePermissionFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        permissionCode: string;
        error: any;
    };
    readonly type = "[Permission] Create Permission Fail";
    constructor(payload: {
        permissionCode: string;
        error: any;
    });
}
declare class CreatePermissionSuccess extends StateUtils.EntitySuccessAction {
    payload: Permission;
    readonly type = "[Permission] Create Permission Success";
    constructor(payload: Permission);
}
declare class UpdatePermission extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        permissionCode: string;
        permission: Permission;
    };
    readonly type = "[Permission] Update Permission";
    constructor(payload: {
        userId: string;
        permissionCode: string;
        permission: Permission;
    });
}
declare class UpdatePermissionFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        permissionCode: string;
        error: any;
    };
    readonly type = "[Permission] Update Permission Fail";
    constructor(payload: {
        permissionCode: string;
        error: any;
    });
}
declare class UpdatePermissionSuccess extends StateUtils.EntitySuccessAction {
    payload: Permission;
    readonly type = "[Permission] Update Permission Success";
    constructor(payload: Permission);
}
declare class LoadPermissionTypes extends StateUtils.EntityLoadAction {
    readonly type = "[Permission Types] Load Permission Types";
    constructor();
}
declare class LoadPermissionTypesFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Permission Types] Load Permission Types Fail";
    constructor(payload: any);
}
declare class LoadPermissionTypesSuccess extends StateUtils.EntitySuccessAction {
    payload: OrderApprovalPermissionType[];
    readonly type = "[Permission Types] Load Permission Types Success";
    constructor(payload: OrderApprovalPermissionType[]);
}
type PermissionAction = LoadPermission | LoadPermissionFail | LoadPermissionSuccess | LoadPermissions | LoadPermissionsFail | LoadPermissionsSuccess | CreatePermission | CreatePermissionFail | CreatePermissionSuccess | UpdatePermission | UpdatePermissionFail | UpdatePermissionSuccess | LoadPermissionTypes | LoadPermissionTypesFail | LoadPermissionTypesSuccess;

declare const permission_action_d_CREATE_PERMISSION: typeof CREATE_PERMISSION;
declare const permission_action_d_CREATE_PERMISSION_FAIL: typeof CREATE_PERMISSION_FAIL;
declare const permission_action_d_CREATE_PERMISSION_SUCCESS: typeof CREATE_PERMISSION_SUCCESS;
type permission_action_d_CreatePermission = CreatePermission;
declare const permission_action_d_CreatePermission: typeof CreatePermission;
type permission_action_d_CreatePermissionFail = CreatePermissionFail;
declare const permission_action_d_CreatePermissionFail: typeof CreatePermissionFail;
type permission_action_d_CreatePermissionSuccess = CreatePermissionSuccess;
declare const permission_action_d_CreatePermissionSuccess: typeof CreatePermissionSuccess;
declare const permission_action_d_LOAD_PERMISSION: typeof LOAD_PERMISSION;
declare const permission_action_d_LOAD_PERMISSIONS: typeof LOAD_PERMISSIONS;
declare const permission_action_d_LOAD_PERMISSIONS_FAIL: typeof LOAD_PERMISSIONS_FAIL;
declare const permission_action_d_LOAD_PERMISSIONS_SUCCESS: typeof LOAD_PERMISSIONS_SUCCESS;
declare const permission_action_d_LOAD_PERMISSION_FAIL: typeof LOAD_PERMISSION_FAIL;
declare const permission_action_d_LOAD_PERMISSION_SUCCESS: typeof LOAD_PERMISSION_SUCCESS;
declare const permission_action_d_LOAD_PERMISSION_TYPES: typeof LOAD_PERMISSION_TYPES;
declare const permission_action_d_LOAD_PERMISSION_TYPES_FAIL: typeof LOAD_PERMISSION_TYPES_FAIL;
declare const permission_action_d_LOAD_PERMISSION_TYPES_SUCCESS: typeof LOAD_PERMISSION_TYPES_SUCCESS;
type permission_action_d_LoadPermission = LoadPermission;
declare const permission_action_d_LoadPermission: typeof LoadPermission;
type permission_action_d_LoadPermissionFail = LoadPermissionFail;
declare const permission_action_d_LoadPermissionFail: typeof LoadPermissionFail;
type permission_action_d_LoadPermissionSuccess = LoadPermissionSuccess;
declare const permission_action_d_LoadPermissionSuccess: typeof LoadPermissionSuccess;
type permission_action_d_LoadPermissionTypes = LoadPermissionTypes;
declare const permission_action_d_LoadPermissionTypes: typeof LoadPermissionTypes;
type permission_action_d_LoadPermissionTypesFail = LoadPermissionTypesFail;
declare const permission_action_d_LoadPermissionTypesFail: typeof LoadPermissionTypesFail;
type permission_action_d_LoadPermissionTypesSuccess = LoadPermissionTypesSuccess;
declare const permission_action_d_LoadPermissionTypesSuccess: typeof LoadPermissionTypesSuccess;
type permission_action_d_LoadPermissions = LoadPermissions;
declare const permission_action_d_LoadPermissions: typeof LoadPermissions;
type permission_action_d_LoadPermissionsFail = LoadPermissionsFail;
declare const permission_action_d_LoadPermissionsFail: typeof LoadPermissionsFail;
type permission_action_d_LoadPermissionsSuccess = LoadPermissionsSuccess;
declare const permission_action_d_LoadPermissionsSuccess: typeof LoadPermissionsSuccess;
type permission_action_d_PermissionAction = PermissionAction;
declare const permission_action_d_UPDATE_PERMISSION: typeof UPDATE_PERMISSION;
declare const permission_action_d_UPDATE_PERMISSION_FAIL: typeof UPDATE_PERMISSION_FAIL;
declare const permission_action_d_UPDATE_PERMISSION_SUCCESS: typeof UPDATE_PERMISSION_SUCCESS;
type permission_action_d_UpdatePermission = UpdatePermission;
declare const permission_action_d_UpdatePermission: typeof UpdatePermission;
type permission_action_d_UpdatePermissionFail = UpdatePermissionFail;
declare const permission_action_d_UpdatePermissionFail: typeof UpdatePermissionFail;
type permission_action_d_UpdatePermissionSuccess = UpdatePermissionSuccess;
declare const permission_action_d_UpdatePermissionSuccess: typeof UpdatePermissionSuccess;
declare namespace permission_action_d {
  export { permission_action_d_CREATE_PERMISSION as CREATE_PERMISSION, permission_action_d_CREATE_PERMISSION_FAIL as CREATE_PERMISSION_FAIL, permission_action_d_CREATE_PERMISSION_SUCCESS as CREATE_PERMISSION_SUCCESS, permission_action_d_CreatePermission as CreatePermission, permission_action_d_CreatePermissionFail as CreatePermissionFail, permission_action_d_CreatePermissionSuccess as CreatePermissionSuccess, permission_action_d_LOAD_PERMISSION as LOAD_PERMISSION, permission_action_d_LOAD_PERMISSIONS as LOAD_PERMISSIONS, permission_action_d_LOAD_PERMISSIONS_FAIL as LOAD_PERMISSIONS_FAIL, permission_action_d_LOAD_PERMISSIONS_SUCCESS as LOAD_PERMISSIONS_SUCCESS, permission_action_d_LOAD_PERMISSION_FAIL as LOAD_PERMISSION_FAIL, permission_action_d_LOAD_PERMISSION_SUCCESS as LOAD_PERMISSION_SUCCESS, permission_action_d_LOAD_PERMISSION_TYPES as LOAD_PERMISSION_TYPES, permission_action_d_LOAD_PERMISSION_TYPES_FAIL as LOAD_PERMISSION_TYPES_FAIL, permission_action_d_LOAD_PERMISSION_TYPES_SUCCESS as LOAD_PERMISSION_TYPES_SUCCESS, permission_action_d_LoadPermission as LoadPermission, permission_action_d_LoadPermissionFail as LoadPermissionFail, permission_action_d_LoadPermissionSuccess as LoadPermissionSuccess, permission_action_d_LoadPermissionTypes as LoadPermissionTypes, permission_action_d_LoadPermissionTypesFail as LoadPermissionTypesFail, permission_action_d_LoadPermissionTypesSuccess as LoadPermissionTypesSuccess, permission_action_d_LoadPermissions as LoadPermissions, permission_action_d_LoadPermissionsFail as LoadPermissionsFail, permission_action_d_LoadPermissionsSuccess as LoadPermissionsSuccess, permission_action_d_UPDATE_PERMISSION as UPDATE_PERMISSION, permission_action_d_UPDATE_PERMISSION_FAIL as UPDATE_PERMISSION_FAIL, permission_action_d_UPDATE_PERMISSION_SUCCESS as UPDATE_PERMISSION_SUCCESS, permission_action_d_UpdatePermission as UpdatePermission, permission_action_d_UpdatePermissionFail as UpdatePermissionFail, permission_action_d_UpdatePermissionSuccess as UpdatePermissionSuccess };
  export type { permission_action_d_PermissionAction as PermissionAction };
}

declare const LOAD_COST_CENTER = "[CostCenter] Load CostCenter Data";
declare const LOAD_COST_CENTER_FAIL = "[CostCenter] Load CostCenter Data Fail";
declare const LOAD_COST_CENTER_SUCCESS = "[CostCenter] Load CostCenter Data Success";
declare const LOAD_COST_CENTERS = "[CostCenter] Load CostCenters";
declare const LOAD_COST_CENTERS_FAIL = "[CostCenter] Load CostCenters Fail";
declare const LOAD_COST_CENTERS_SUCCESS = "[CostCenter] Load CostCenters Success";
declare const CREATE_COST_CENTER = "[CostCenter] Create CostCenter";
declare const CREATE_COST_CENTER_FAIL = "[CostCenter] Create CostCenter Fail";
declare const CREATE_COST_CENTER_SUCCESS = "[CostCenter] Create CostCenter Success";
declare const UPDATE_COST_CENTER = "[CostCenter] Update CostCenter";
declare const UPDATE_COST_CENTER_FAIL = "[CostCenter] Update CostCenter Fail";
declare const UPDATE_COST_CENTER_SUCCESS = "[CostCenter] Update CostCenter Success";
declare const LOAD_ASSIGNED_BUDGETS = "[CostCenter] Load Budgets";
declare const LOAD_ASSIGNED_BUDGETS_SUCCESS = "[CostCenter] Load Budgets success";
declare const LOAD_ASSIGNED_BUDGETS_FAIL = "[CostCenter] Load Budgets fail";
declare const ASSIGN_BUDGET = "[CostCenter] Assign Budget";
declare const ASSIGN_BUDGET_SUCCESS = "[CostCenter] Assign Budget success";
declare const ASSIGN_BUDGET_FAIL = "[CostCenter] Assign Budget fail";
declare const UNASSIGN_BUDGET = "[CostCenter] Unassign Budget";
declare const UNASSIGN_BUDGET_SUCCESS = "[CostCenter] Unassign Budget success";
declare const UNASSIGN_BUDGET_FAIL = "[CostCenter] Unassign Budget fail";
declare class LoadCostCenter extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        costCenterCode: string;
    };
    readonly type = "[CostCenter] Load CostCenter Data";
    constructor(payload: {
        userId: string;
        costCenterCode: string;
    });
}
declare class LoadCostCenterFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        costCenterCode: string;
        error: any;
    };
    readonly type = "[CostCenter] Load CostCenter Data Fail";
    constructor(payload: {
        costCenterCode: string;
        error: any;
    });
}
declare class LoadCostCenterSuccess extends StateUtils.EntitySuccessAction {
    payload: CostCenter | CostCenter[];
    readonly type = "[CostCenter] Load CostCenter Data Success";
    constructor(payload: CostCenter | CostCenter[]);
}
declare class LoadCostCenters extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        params: SearchConfig;
    };
    readonly type = "[CostCenter] Load CostCenters";
    constructor(payload: {
        userId: string;
        params: SearchConfig;
    });
}
declare class LoadCostCentersFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        params: SearchConfig;
        error: any;
    };
    readonly type = "[CostCenter] Load CostCenters Fail";
    constructor(payload: {
        params: SearchConfig;
        error: any;
    });
}
declare class LoadCostCentersSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        page: ListModel;
        params: SearchConfig;
    };
    readonly type = "[CostCenter] Load CostCenters Success";
    constructor(payload: {
        page: ListModel;
        params: SearchConfig;
    });
}
declare class CreateCostCenter extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        costCenter: CostCenter;
    };
    readonly type = "[CostCenter] Create CostCenter";
    constructor(payload: {
        userId: string;
        costCenter: CostCenter;
    });
}
declare class CreateCostCenterFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        costCenterCode: string;
        error: any;
    };
    readonly type = "[CostCenter] Create CostCenter Fail";
    constructor(payload: {
        costCenterCode: string;
        error: any;
    });
}
declare class CreateCostCenterSuccess extends StateUtils.EntitySuccessAction {
    payload: CostCenter;
    readonly type = "[CostCenter] Create CostCenter Success";
    constructor(payload: CostCenter);
}
declare class UpdateCostCenter extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        costCenterCode: string;
        costCenter: CostCenter;
    };
    readonly type = "[CostCenter] Update CostCenter";
    constructor(payload: {
        userId: string;
        costCenterCode: string;
        costCenter: CostCenter;
    });
}
declare class UpdateCostCenterFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        costCenterCode: string;
        error: any;
    };
    readonly type = "[CostCenter] Update CostCenter Fail";
    constructor(payload: {
        costCenterCode: string;
        error: any;
    });
}
declare class UpdateCostCenterSuccess extends StateUtils.EntitySuccessAction {
    payload: CostCenter;
    readonly type = "[CostCenter] Update CostCenter Success";
    constructor(payload: CostCenter);
}
declare class LoadAssignedBudgets extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        costCenterCode: string;
        params: SearchConfig;
    };
    readonly type = "[CostCenter] Load Budgets";
    constructor(payload: {
        userId: string;
        costCenterCode: string;
        params: SearchConfig;
    });
}
declare class LoadAssignedBudgetsFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        costCenterCode: string;
        params: SearchConfig;
        error: any;
    };
    readonly type = "[CostCenter] Load Budgets fail";
    constructor(payload: {
        costCenterCode: string;
        params: SearchConfig;
        error: any;
    });
}
declare class LoadAssignedBudgetsSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        costCenterCode: string;
        page: ListModel;
        params: SearchConfig;
    };
    readonly type = "[CostCenter] Load Budgets success";
    constructor(payload: {
        costCenterCode: string;
        page: ListModel;
        params: SearchConfig;
    });
}
declare class AssignBudget extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        costCenterCode: string;
        budgetCode: string;
    };
    readonly type = "[CostCenter] Assign Budget";
    constructor(payload: {
        userId: string;
        costCenterCode: string;
        budgetCode: string;
    });
}
declare class AssignBudgetFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        budgetCode: string;
        error: any;
    };
    readonly type = "[CostCenter] Assign Budget fail";
    constructor(payload: {
        budgetCode: string;
        error: any;
    });
}
declare class AssignBudgetSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        code: string;
        selected: boolean;
    };
    readonly type = "[CostCenter] Assign Budget success";
    constructor(payload: {
        code: string;
        selected: boolean;
    });
}
declare class UnassignBudget extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        costCenterCode: string;
        budgetCode: string;
    };
    readonly type = "[CostCenter] Unassign Budget";
    constructor(payload: {
        userId: string;
        costCenterCode: string;
        budgetCode: string;
    });
}
declare class UnassignBudgetFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        budgetCode: string;
        error: any;
    };
    readonly type = "[CostCenter] Unassign Budget fail";
    constructor(payload: {
        budgetCode: string;
        error: any;
    });
}
declare class UnassignBudgetSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        code: string;
        selected: boolean;
    };
    readonly type = "[CostCenter] Unassign Budget success";
    constructor(payload: {
        code: string;
        selected: boolean;
    });
}
type CostCenterAction = LoadCostCenter | LoadCostCenterFail | LoadCostCenterSuccess | LoadCostCenters | LoadCostCentersFail | LoadCostCentersSuccess | CreateCostCenter | CreateCostCenterFail | CreateCostCenterSuccess | UpdateCostCenter | UpdateCostCenterFail | UpdateCostCenterSuccess | LoadAssignedBudgets | LoadAssignedBudgetsSuccess | LoadAssignedBudgetsFail | AssignBudget | AssignBudgetFail | AssignBudgetSuccess | UnassignBudget | UnassignBudgetFail | UnassignBudgetSuccess;

declare const costCenter_action_d_ASSIGN_BUDGET: typeof ASSIGN_BUDGET;
declare const costCenter_action_d_ASSIGN_BUDGET_FAIL: typeof ASSIGN_BUDGET_FAIL;
declare const costCenter_action_d_ASSIGN_BUDGET_SUCCESS: typeof ASSIGN_BUDGET_SUCCESS;
type costCenter_action_d_AssignBudget = AssignBudget;
declare const costCenter_action_d_AssignBudget: typeof AssignBudget;
type costCenter_action_d_AssignBudgetFail = AssignBudgetFail;
declare const costCenter_action_d_AssignBudgetFail: typeof AssignBudgetFail;
type costCenter_action_d_AssignBudgetSuccess = AssignBudgetSuccess;
declare const costCenter_action_d_AssignBudgetSuccess: typeof AssignBudgetSuccess;
declare const costCenter_action_d_CREATE_COST_CENTER: typeof CREATE_COST_CENTER;
declare const costCenter_action_d_CREATE_COST_CENTER_FAIL: typeof CREATE_COST_CENTER_FAIL;
declare const costCenter_action_d_CREATE_COST_CENTER_SUCCESS: typeof CREATE_COST_CENTER_SUCCESS;
type costCenter_action_d_CostCenterAction = CostCenterAction;
type costCenter_action_d_CreateCostCenter = CreateCostCenter;
declare const costCenter_action_d_CreateCostCenter: typeof CreateCostCenter;
type costCenter_action_d_CreateCostCenterFail = CreateCostCenterFail;
declare const costCenter_action_d_CreateCostCenterFail: typeof CreateCostCenterFail;
type costCenter_action_d_CreateCostCenterSuccess = CreateCostCenterSuccess;
declare const costCenter_action_d_CreateCostCenterSuccess: typeof CreateCostCenterSuccess;
declare const costCenter_action_d_LOAD_ASSIGNED_BUDGETS: typeof LOAD_ASSIGNED_BUDGETS;
declare const costCenter_action_d_LOAD_ASSIGNED_BUDGETS_FAIL: typeof LOAD_ASSIGNED_BUDGETS_FAIL;
declare const costCenter_action_d_LOAD_ASSIGNED_BUDGETS_SUCCESS: typeof LOAD_ASSIGNED_BUDGETS_SUCCESS;
declare const costCenter_action_d_LOAD_COST_CENTER: typeof LOAD_COST_CENTER;
declare const costCenter_action_d_LOAD_COST_CENTERS: typeof LOAD_COST_CENTERS;
declare const costCenter_action_d_LOAD_COST_CENTERS_FAIL: typeof LOAD_COST_CENTERS_FAIL;
declare const costCenter_action_d_LOAD_COST_CENTERS_SUCCESS: typeof LOAD_COST_CENTERS_SUCCESS;
declare const costCenter_action_d_LOAD_COST_CENTER_FAIL: typeof LOAD_COST_CENTER_FAIL;
declare const costCenter_action_d_LOAD_COST_CENTER_SUCCESS: typeof LOAD_COST_CENTER_SUCCESS;
type costCenter_action_d_LoadAssignedBudgets = LoadAssignedBudgets;
declare const costCenter_action_d_LoadAssignedBudgets: typeof LoadAssignedBudgets;
type costCenter_action_d_LoadAssignedBudgetsFail = LoadAssignedBudgetsFail;
declare const costCenter_action_d_LoadAssignedBudgetsFail: typeof LoadAssignedBudgetsFail;
type costCenter_action_d_LoadAssignedBudgetsSuccess = LoadAssignedBudgetsSuccess;
declare const costCenter_action_d_LoadAssignedBudgetsSuccess: typeof LoadAssignedBudgetsSuccess;
type costCenter_action_d_LoadCostCenter = LoadCostCenter;
declare const costCenter_action_d_LoadCostCenter: typeof LoadCostCenter;
type costCenter_action_d_LoadCostCenterFail = LoadCostCenterFail;
declare const costCenter_action_d_LoadCostCenterFail: typeof LoadCostCenterFail;
type costCenter_action_d_LoadCostCenterSuccess = LoadCostCenterSuccess;
declare const costCenter_action_d_LoadCostCenterSuccess: typeof LoadCostCenterSuccess;
type costCenter_action_d_LoadCostCenters = LoadCostCenters;
declare const costCenter_action_d_LoadCostCenters: typeof LoadCostCenters;
type costCenter_action_d_LoadCostCentersFail = LoadCostCentersFail;
declare const costCenter_action_d_LoadCostCentersFail: typeof LoadCostCentersFail;
type costCenter_action_d_LoadCostCentersSuccess = LoadCostCentersSuccess;
declare const costCenter_action_d_LoadCostCentersSuccess: typeof LoadCostCentersSuccess;
declare const costCenter_action_d_UNASSIGN_BUDGET: typeof UNASSIGN_BUDGET;
declare const costCenter_action_d_UNASSIGN_BUDGET_FAIL: typeof UNASSIGN_BUDGET_FAIL;
declare const costCenter_action_d_UNASSIGN_BUDGET_SUCCESS: typeof UNASSIGN_BUDGET_SUCCESS;
declare const costCenter_action_d_UPDATE_COST_CENTER: typeof UPDATE_COST_CENTER;
declare const costCenter_action_d_UPDATE_COST_CENTER_FAIL: typeof UPDATE_COST_CENTER_FAIL;
declare const costCenter_action_d_UPDATE_COST_CENTER_SUCCESS: typeof UPDATE_COST_CENTER_SUCCESS;
type costCenter_action_d_UnassignBudget = UnassignBudget;
declare const costCenter_action_d_UnassignBudget: typeof UnassignBudget;
type costCenter_action_d_UnassignBudgetFail = UnassignBudgetFail;
declare const costCenter_action_d_UnassignBudgetFail: typeof UnassignBudgetFail;
type costCenter_action_d_UnassignBudgetSuccess = UnassignBudgetSuccess;
declare const costCenter_action_d_UnassignBudgetSuccess: typeof UnassignBudgetSuccess;
type costCenter_action_d_UpdateCostCenter = UpdateCostCenter;
declare const costCenter_action_d_UpdateCostCenter: typeof UpdateCostCenter;
type costCenter_action_d_UpdateCostCenterFail = UpdateCostCenterFail;
declare const costCenter_action_d_UpdateCostCenterFail: typeof UpdateCostCenterFail;
type costCenter_action_d_UpdateCostCenterSuccess = UpdateCostCenterSuccess;
declare const costCenter_action_d_UpdateCostCenterSuccess: typeof UpdateCostCenterSuccess;
declare namespace costCenter_action_d {
  export { costCenter_action_d_ASSIGN_BUDGET as ASSIGN_BUDGET, costCenter_action_d_ASSIGN_BUDGET_FAIL as ASSIGN_BUDGET_FAIL, costCenter_action_d_ASSIGN_BUDGET_SUCCESS as ASSIGN_BUDGET_SUCCESS, costCenter_action_d_AssignBudget as AssignBudget, costCenter_action_d_AssignBudgetFail as AssignBudgetFail, costCenter_action_d_AssignBudgetSuccess as AssignBudgetSuccess, costCenter_action_d_CREATE_COST_CENTER as CREATE_COST_CENTER, costCenter_action_d_CREATE_COST_CENTER_FAIL as CREATE_COST_CENTER_FAIL, costCenter_action_d_CREATE_COST_CENTER_SUCCESS as CREATE_COST_CENTER_SUCCESS, costCenter_action_d_CreateCostCenter as CreateCostCenter, costCenter_action_d_CreateCostCenterFail as CreateCostCenterFail, costCenter_action_d_CreateCostCenterSuccess as CreateCostCenterSuccess, costCenter_action_d_LOAD_ASSIGNED_BUDGETS as LOAD_ASSIGNED_BUDGETS, costCenter_action_d_LOAD_ASSIGNED_BUDGETS_FAIL as LOAD_ASSIGNED_BUDGETS_FAIL, costCenter_action_d_LOAD_ASSIGNED_BUDGETS_SUCCESS as LOAD_ASSIGNED_BUDGETS_SUCCESS, costCenter_action_d_LOAD_COST_CENTER as LOAD_COST_CENTER, costCenter_action_d_LOAD_COST_CENTERS as LOAD_COST_CENTERS, costCenter_action_d_LOAD_COST_CENTERS_FAIL as LOAD_COST_CENTERS_FAIL, costCenter_action_d_LOAD_COST_CENTERS_SUCCESS as LOAD_COST_CENTERS_SUCCESS, costCenter_action_d_LOAD_COST_CENTER_FAIL as LOAD_COST_CENTER_FAIL, costCenter_action_d_LOAD_COST_CENTER_SUCCESS as LOAD_COST_CENTER_SUCCESS, costCenter_action_d_LoadAssignedBudgets as LoadAssignedBudgets, costCenter_action_d_LoadAssignedBudgetsFail as LoadAssignedBudgetsFail, costCenter_action_d_LoadAssignedBudgetsSuccess as LoadAssignedBudgetsSuccess, costCenter_action_d_LoadCostCenter as LoadCostCenter, costCenter_action_d_LoadCostCenterFail as LoadCostCenterFail, costCenter_action_d_LoadCostCenterSuccess as LoadCostCenterSuccess, costCenter_action_d_LoadCostCenters as LoadCostCenters, costCenter_action_d_LoadCostCentersFail as LoadCostCentersFail, costCenter_action_d_LoadCostCentersSuccess as LoadCostCentersSuccess, costCenter_action_d_UNASSIGN_BUDGET as UNASSIGN_BUDGET, costCenter_action_d_UNASSIGN_BUDGET_FAIL as UNASSIGN_BUDGET_FAIL, costCenter_action_d_UNASSIGN_BUDGET_SUCCESS as UNASSIGN_BUDGET_SUCCESS, costCenter_action_d_UPDATE_COST_CENTER as UPDATE_COST_CENTER, costCenter_action_d_UPDATE_COST_CENTER_FAIL as UPDATE_COST_CENTER_FAIL, costCenter_action_d_UPDATE_COST_CENTER_SUCCESS as UPDATE_COST_CENTER_SUCCESS, costCenter_action_d_UnassignBudget as UnassignBudget, costCenter_action_d_UnassignBudgetFail as UnassignBudgetFail, costCenter_action_d_UnassignBudgetSuccess as UnassignBudgetSuccess, costCenter_action_d_UpdateCostCenter as UpdateCostCenter, costCenter_action_d_UpdateCostCenterFail as UpdateCostCenterFail, costCenter_action_d_UpdateCostCenterSuccess as UpdateCostCenterSuccess };
  export type { costCenter_action_d_CostCenterAction as CostCenterAction };
}

declare const LOAD_B2B_USER = "[B2BUser] Load B2BUser Data";
declare const LOAD_B2B_USER_FAIL = "[B2BUser] Load B2BUser Data Fail";
declare const LOAD_B2B_USER_SUCCESS = "[B2BUser] Load B2BUser Data Success";
declare const CREATE_B2B_USER = "[B2BUser] Create B2BUser Data";
declare const CREATE_B2B_USER_FAIL = "[B2BUser] Create B2BUser Data Fail";
declare const CREATE_B2B_USER_SUCCESS = "[B2BUser] Create B2BUser Data Success";
declare const UPDATE_B2B_USER = "[B2BUser] Update B2BUser Data";
declare const UPDATE_B2B_USER_FAIL = "[B2BUser] Update B2BUser Data Fail";
declare const UPDATE_B2B_USER_SUCCESS = "[B2BUser] Update B2BUser Data Success";
declare const LOAD_B2B_USERS = "[B2BUser] Load B2BUsers";
declare const LOAD_B2B_USERS_FAIL = "[B2BUser] Load B2BUsers Fail";
declare const LOAD_B2B_USERS_SUCCESS = "[B2BUser] Load B2BUsers Success";
declare const LOAD_B2B_USER_APPROVERS = "[B2BUser] Load B2BUser Approvers";
declare const LOAD_B2B_USER_APPROVERS_FAIL = "[B2BUser] Load B2BUser Approvers Fail";
declare const LOAD_B2B_USER_APPROVERS_SUCCESS = "[B2BUser] Load B2BUser Approvers Success";
declare const ASSIGN_B2B_USER_APPROVER = "[B2BUser] Assign B2BUser Approver";
declare const ASSIGN_B2B_USER_APPROVER_FAIL = "[B2BUser] Assign B2BUser Approver Fail";
declare const ASSIGN_B2B_USER_APPROVER_SUCCESS = "[B2BUser] Assign B2BUser Approver Success";
declare const UNASSIGN_B2B_USER_APPROVER = "[B2BUser] Unassign B2BUser Approver";
declare const UNASSIGN_B2B_USER_APPROVER_FAIL = "[B2BUser] Unassign B2BUser Approver Fail";
declare const UNASSIGN_B2B_USER_APPROVER_SUCCESS = "[B2BUser] Unassign B2BUser Approver Success";
declare const LOAD_B2B_USER_PERMISSIONS = "[B2BUser] Load B2BUser Permissions";
declare const LOAD_B2B_USER_PERMISSIONS_FAIL = "[B2BUser] Load B2BUser Permissions Fail";
declare const LOAD_B2B_USER_PERMISSIONS_SUCCESS = "[B2BUser] Load B2BUser Permissions Success";
declare const ASSIGN_B2B_USER_PERMISSION = "[B2BUser] Assign B2BUser Permission";
declare const ASSIGN_B2B_USER_PERMISSION_FAIL = "[B2BUser] Assign B2BUser Permission Fail";
declare const ASSIGN_B2B_USER_PERMISSION_SUCCESS = "[B2BUser] Assign B2BUser Permission Success";
declare const UNASSIGN_B2B_USER_PERMISSION = "[B2BUser] Unassign B2BUser Permission";
declare const UNASSIGN_B2B_USER_PERMISSION_FAIL = "[B2BUser] Unassign B2BUser Permission Fail";
declare const UNASSIGN_B2B_USER_PERMISSION_SUCCESS = "[B2BUser] Unassign B2BUser Permission Success";
declare const LOAD_B2B_USER_USER_GROUPS = "[B2BUser] Load B2BUser User Groups";
declare const LOAD_B2B_USER_USER_GROUPS_FAIL = "[B2BUser] Load B2BUser User Groups Fail";
declare const LOAD_B2B_USER_USER_GROUPS_SUCCESS = "[B2BUser] Load B2BUser User Groups Success";
declare const ASSIGN_B2B_USER_USER_GROUP = "[B2BUser] Assign B2BUser User Group";
declare const ASSIGN_B2B_USER_USER_GROUP_FAIL = "[B2BUser] Assign B2BUser User Group Fail";
declare const ASSIGN_B2B_USER_USER_GROUP_SUCCESS = "[B2BUser] Assign B2BUser User Group Success";
declare const UNASSIGN_B2B_USER_USER_GROUP = "[B2BUser] Unassign B2BUser User Group";
declare const UNASSIGN_B2B_USER_USER_GROUP_FAIL = "[B2BUser] Unassign B2BUser User Group Fail";
declare const UNASSIGN_B2B_USER_USER_GROUP_SUCCESS = "[B2BUser] Unassign B2BUser User Group Success";
declare class LoadB2BUser extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgCustomerId: string;
    };
    readonly type = "[B2BUser] Load B2BUser Data";
    constructor(payload: {
        userId: string;
        orgCustomerId: string;
    });
}
declare class LoadB2BUserFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgCustomerId: string;
        error: any;
    };
    readonly type = "[B2BUser] Load B2BUser Data Fail";
    constructor(payload: {
        orgCustomerId: string;
        error: any;
    });
}
declare class LoadB2BUserSuccess extends StateUtils.EntitySuccessAction {
    payload: B2BUser | B2BUser[];
    readonly type = "[B2BUser] Load B2BUser Data Success";
    constructor(payload: B2BUser | B2BUser[]);
}
declare class CreateB2BUser extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgCustomer: B2BUser;
    };
    readonly type = "[B2BUser] Create B2BUser Data";
    constructor(payload: {
        userId: string;
        orgCustomer: B2BUser;
    });
}
declare class CreateB2BUserFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgCustomerId: string;
        error: any;
    };
    readonly type = "[B2BUser] Create B2BUser Data Fail";
    constructor(payload: {
        orgCustomerId: string;
        error: any;
    });
}
declare class CreateB2BUserSuccess extends StateUtils.EntitySuccessAction {
    payload: B2BUser;
    readonly type = "[B2BUser] Create B2BUser Data Success";
    constructor(payload: B2BUser);
}
declare class UpdateB2BUser extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgCustomerId: string;
        orgCustomer: B2BUser;
    };
    readonly type = "[B2BUser] Update B2BUser Data";
    constructor(payload: {
        userId: string;
        orgCustomerId: string;
        orgCustomer: B2BUser;
    });
}
declare class UpdateB2BUserFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgCustomerId: string;
        error: any;
    };
    readonly type = "[B2BUser] Update B2BUser Data Fail";
    constructor(payload: {
        orgCustomerId: string;
        error: any;
    });
}
declare class UpdateB2BUserSuccess extends StateUtils.EntitySuccessAction {
    payload: B2BUser;
    readonly type = "[B2BUser] Update B2BUser Data Success";
    constructor(payload: B2BUser);
}
declare class LoadB2BUsers extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        params: SearchConfig;
    };
    readonly type = "[B2BUser] Load B2BUsers";
    constructor(payload: {
        userId: string;
        params: SearchConfig;
    });
}
declare class LoadB2BUsersFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        params: SearchConfig;
        error: any;
    };
    readonly type = "[B2BUser] Load B2BUsers Fail";
    constructor(payload: {
        params: SearchConfig;
        error: any;
    });
}
declare class LoadB2BUsersSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        page: ListModel;
        params: SearchConfig;
    };
    readonly type = "[B2BUser] Load B2BUsers Success";
    constructor(payload: {
        page: ListModel;
        params: SearchConfig;
    });
}
declare class LoadB2BUserApprovers extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgCustomerId: string;
        params: SearchConfig;
    };
    readonly type = "[B2BUser] Load B2BUser Approvers";
    constructor(payload: {
        userId: string;
        orgCustomerId: string;
        params: SearchConfig;
    });
}
declare class LoadB2BUserApproversFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgCustomerId: string;
        params: SearchConfig;
        error: any;
    };
    readonly type = "[B2BUser] Load B2BUser Approvers Fail";
    constructor(payload: {
        orgCustomerId: string;
        params: SearchConfig;
        error: any;
    });
}
declare class LoadB2BUserApproversSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        orgCustomerId: string;
        page: ListModel;
        params: SearchConfig;
    };
    readonly type = "[B2BUser] Load B2BUser Approvers Success";
    constructor(payload: {
        orgCustomerId: string;
        page: ListModel;
        params: SearchConfig;
    });
}
declare class AssignB2BUserApprover extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgCustomerId: string;
        approverId: string;
    };
    readonly type = "[B2BUser] Assign B2BUser Approver";
    constructor(payload: {
        userId: string;
        orgCustomerId: string;
        approverId: string;
    });
}
declare class AssignB2BUserApproverFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgCustomerId: string;
        approverId: string;
        error: any;
    };
    readonly type = "[B2BUser] Assign B2BUser Approver Fail";
    constructor(payload: {
        orgCustomerId: string;
        approverId: string;
        error: any;
    });
}
declare class AssignB2BUserApproverSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        approverId: string;
        selected: boolean;
    };
    readonly type = "[B2BUser] Assign B2BUser Approver Success";
    constructor(payload: {
        approverId: string;
        selected: boolean;
    });
}
declare class UnassignB2BUserApprover extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgCustomerId: string;
        approverId: string;
    };
    readonly type = "[B2BUser] Unassign B2BUser Approver";
    constructor(payload: {
        userId: string;
        orgCustomerId: string;
        approverId: string;
    });
}
declare class UnassignB2BUserApproverFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgCustomerId: string;
        approverId: string;
        error: any;
    };
    readonly type = "[B2BUser] Unassign B2BUser Approver Fail";
    constructor(payload: {
        orgCustomerId: string;
        approverId: string;
        error: any;
    });
}
declare class UnassignB2BUserApproverSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        approverId: string;
        selected: boolean;
    };
    readonly type = "[B2BUser] Unassign B2BUser Approver Success";
    constructor(payload: {
        approverId: string;
        selected: boolean;
    });
}
declare class LoadB2BUserPermissions extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgCustomerId: string;
        params: SearchConfig;
    };
    readonly type = "[B2BUser] Load B2BUser Permissions";
    constructor(payload: {
        userId: string;
        orgCustomerId: string;
        params: SearchConfig;
    });
}
declare class LoadB2BUserPermissionsFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgCustomerId: string;
        params: SearchConfig;
        error: any;
    };
    readonly type = "[B2BUser] Load B2BUser Permissions Fail";
    constructor(payload: {
        orgCustomerId: string;
        params: SearchConfig;
        error: any;
    });
}
declare class LoadB2BUserPermissionsSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        orgCustomerId: string;
        page: ListModel;
        params: SearchConfig;
    };
    readonly type = "[B2BUser] Load B2BUser Permissions Success";
    constructor(payload: {
        orgCustomerId: string;
        page: ListModel;
        params: SearchConfig;
    });
}
declare class AssignB2BUserPermission extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgCustomerId: string;
        permissionId: string;
    };
    readonly type = "[B2BUser] Assign B2BUser Permission";
    constructor(payload: {
        userId: string;
        orgCustomerId: string;
        permissionId: string;
    });
}
declare class AssignB2BUserPermissionFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgCustomerId: string;
        permissionId: string;
        error: any;
    };
    readonly type = "[B2BUser] Assign B2BUser Permission Fail";
    constructor(payload: {
        orgCustomerId: string;
        permissionId: string;
        error: any;
    });
}
declare class AssignB2BUserPermissionSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        permissionId: string;
        selected: boolean;
    };
    readonly type = "[B2BUser] Assign B2BUser Permission Success";
    constructor(payload: {
        permissionId: string;
        selected: boolean;
    });
}
declare class UnassignB2BUserPermission extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgCustomerId: string;
        permissionId: string;
    };
    readonly type = "[B2BUser] Unassign B2BUser Permission";
    constructor(payload: {
        userId: string;
        orgCustomerId: string;
        permissionId: string;
    });
}
declare class UnassignB2BUserPermissionFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgCustomerId: string;
        permissionId: string;
        error: any;
    };
    readonly type = "[B2BUser] Unassign B2BUser Permission Fail";
    constructor(payload: {
        orgCustomerId: string;
        permissionId: string;
        error: any;
    });
}
declare class UnassignB2BUserPermissionSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        permissionId: string;
        selected: boolean;
    };
    readonly type = "[B2BUser] Unassign B2BUser Permission Success";
    constructor(payload: {
        permissionId: string;
        selected: boolean;
    });
}
declare class LoadB2BUserUserGroups extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgCustomerId: string;
        params: SearchConfig;
    };
    readonly type = "[B2BUser] Load B2BUser User Groups";
    constructor(payload: {
        userId: string;
        orgCustomerId: string;
        params: SearchConfig;
    });
}
declare class LoadB2BUserUserGroupsFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgCustomerId: string;
        params: SearchConfig;
        error: any;
    };
    readonly type = "[B2BUser] Load B2BUser User Groups Fail";
    constructor(payload: {
        orgCustomerId: string;
        params: SearchConfig;
        error: any;
    });
}
declare class LoadB2BUserUserGroupsSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        orgCustomerId: string;
        page: ListModel;
        params: SearchConfig;
    };
    readonly type = "[B2BUser] Load B2BUser User Groups Success";
    constructor(payload: {
        orgCustomerId: string;
        page: ListModel;
        params: SearchConfig;
    });
}
declare class AssignB2BUserUserGroup extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgCustomerId: string;
        userGroupId: string;
    };
    readonly type = "[B2BUser] Assign B2BUser User Group";
    constructor(payload: {
        userId: string;
        orgCustomerId: string;
        userGroupId: string;
    });
}
declare class AssignB2BUserUserGroupFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgCustomerId: string;
        userGroupId: string;
        error: any;
    };
    readonly type = "[B2BUser] Assign B2BUser User Group Fail";
    constructor(payload: {
        orgCustomerId: string;
        userGroupId: string;
        error: any;
    });
}
declare class AssignB2BUserUserGroupSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        uid: string;
        selected: boolean;
    };
    readonly type = "[B2BUser] Assign B2BUser User Group Success";
    constructor(payload: {
        uid: string;
        selected: boolean;
    });
}
declare class UnassignB2BUserUserGroup extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orgCustomerId: string;
        userGroupId: string;
    };
    readonly type = "[B2BUser] Unassign B2BUser User Group";
    constructor(payload: {
        userId: string;
        orgCustomerId: string;
        userGroupId: string;
    });
}
declare class UnassignB2BUserUserGroupFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orgCustomerId: string;
        userGroupId: string;
        error: any;
    };
    readonly type = "[B2BUser] Unassign B2BUser User Group Fail";
    constructor(payload: {
        orgCustomerId: string;
        userGroupId: string;
        error: any;
    });
}
declare class UnassignB2BUserUserGroupSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        uid: string;
        selected: boolean;
    };
    readonly type = "[B2BUser] Unassign B2BUser User Group Success";
    constructor(payload: {
        uid: string;
        selected: boolean;
    });
}
type B2BUserAction = LoadB2BUser | LoadB2BUserFail | LoadB2BUserSuccess | CreateB2BUser | CreateB2BUserFail | CreateB2BUserSuccess | UpdateB2BUser | UpdateB2BUserFail | UpdateB2BUserSuccess | LoadB2BUsers | LoadB2BUsersFail | LoadB2BUsersSuccess | LoadB2BUserApprovers | LoadB2BUserApproversFail | LoadB2BUserApproversSuccess | AssignB2BUserApprover | AssignB2BUserApproverFail | AssignB2BUserApproverSuccess | UnassignB2BUserApprover | UnassignB2BUserApproverFail | UnassignB2BUserApproverSuccess | LoadB2BUserPermissions | LoadB2BUserPermissionsFail | LoadB2BUserPermissionsSuccess | AssignB2BUserPermission | AssignB2BUserPermissionFail | AssignB2BUserPermissionSuccess | UnassignB2BUserPermission | UnassignB2BUserPermissionFail | UnassignB2BUserPermissionSuccess | LoadB2BUserUserGroups | LoadB2BUserUserGroupsFail | LoadB2BUserUserGroupsSuccess | AssignB2BUserUserGroup | AssignB2BUserUserGroupFail | AssignB2BUserUserGroupSuccess | UnassignB2BUserUserGroup | UnassignB2BUserUserGroupFail | UnassignB2BUserUserGroupSuccess;

declare const b2bUser_action_d_ASSIGN_B2B_USER_APPROVER: typeof ASSIGN_B2B_USER_APPROVER;
declare const b2bUser_action_d_ASSIGN_B2B_USER_APPROVER_FAIL: typeof ASSIGN_B2B_USER_APPROVER_FAIL;
declare const b2bUser_action_d_ASSIGN_B2B_USER_APPROVER_SUCCESS: typeof ASSIGN_B2B_USER_APPROVER_SUCCESS;
declare const b2bUser_action_d_ASSIGN_B2B_USER_PERMISSION: typeof ASSIGN_B2B_USER_PERMISSION;
declare const b2bUser_action_d_ASSIGN_B2B_USER_PERMISSION_FAIL: typeof ASSIGN_B2B_USER_PERMISSION_FAIL;
declare const b2bUser_action_d_ASSIGN_B2B_USER_PERMISSION_SUCCESS: typeof ASSIGN_B2B_USER_PERMISSION_SUCCESS;
declare const b2bUser_action_d_ASSIGN_B2B_USER_USER_GROUP: typeof ASSIGN_B2B_USER_USER_GROUP;
declare const b2bUser_action_d_ASSIGN_B2B_USER_USER_GROUP_FAIL: typeof ASSIGN_B2B_USER_USER_GROUP_FAIL;
declare const b2bUser_action_d_ASSIGN_B2B_USER_USER_GROUP_SUCCESS: typeof ASSIGN_B2B_USER_USER_GROUP_SUCCESS;
type b2bUser_action_d_AssignB2BUserApprover = AssignB2BUserApprover;
declare const b2bUser_action_d_AssignB2BUserApprover: typeof AssignB2BUserApprover;
type b2bUser_action_d_AssignB2BUserApproverFail = AssignB2BUserApproverFail;
declare const b2bUser_action_d_AssignB2BUserApproverFail: typeof AssignB2BUserApproverFail;
type b2bUser_action_d_AssignB2BUserApproverSuccess = AssignB2BUserApproverSuccess;
declare const b2bUser_action_d_AssignB2BUserApproverSuccess: typeof AssignB2BUserApproverSuccess;
type b2bUser_action_d_AssignB2BUserPermission = AssignB2BUserPermission;
declare const b2bUser_action_d_AssignB2BUserPermission: typeof AssignB2BUserPermission;
type b2bUser_action_d_AssignB2BUserPermissionFail = AssignB2BUserPermissionFail;
declare const b2bUser_action_d_AssignB2BUserPermissionFail: typeof AssignB2BUserPermissionFail;
type b2bUser_action_d_AssignB2BUserPermissionSuccess = AssignB2BUserPermissionSuccess;
declare const b2bUser_action_d_AssignB2BUserPermissionSuccess: typeof AssignB2BUserPermissionSuccess;
type b2bUser_action_d_AssignB2BUserUserGroup = AssignB2BUserUserGroup;
declare const b2bUser_action_d_AssignB2BUserUserGroup: typeof AssignB2BUserUserGroup;
type b2bUser_action_d_AssignB2BUserUserGroupFail = AssignB2BUserUserGroupFail;
declare const b2bUser_action_d_AssignB2BUserUserGroupFail: typeof AssignB2BUserUserGroupFail;
type b2bUser_action_d_AssignB2BUserUserGroupSuccess = AssignB2BUserUserGroupSuccess;
declare const b2bUser_action_d_AssignB2BUserUserGroupSuccess: typeof AssignB2BUserUserGroupSuccess;
type b2bUser_action_d_B2BUserAction = B2BUserAction;
declare const b2bUser_action_d_CREATE_B2B_USER: typeof CREATE_B2B_USER;
declare const b2bUser_action_d_CREATE_B2B_USER_FAIL: typeof CREATE_B2B_USER_FAIL;
declare const b2bUser_action_d_CREATE_B2B_USER_SUCCESS: typeof CREATE_B2B_USER_SUCCESS;
type b2bUser_action_d_CreateB2BUser = CreateB2BUser;
declare const b2bUser_action_d_CreateB2BUser: typeof CreateB2BUser;
type b2bUser_action_d_CreateB2BUserFail = CreateB2BUserFail;
declare const b2bUser_action_d_CreateB2BUserFail: typeof CreateB2BUserFail;
type b2bUser_action_d_CreateB2BUserSuccess = CreateB2BUserSuccess;
declare const b2bUser_action_d_CreateB2BUserSuccess: typeof CreateB2BUserSuccess;
declare const b2bUser_action_d_LOAD_B2B_USER: typeof LOAD_B2B_USER;
declare const b2bUser_action_d_LOAD_B2B_USERS: typeof LOAD_B2B_USERS;
declare const b2bUser_action_d_LOAD_B2B_USERS_FAIL: typeof LOAD_B2B_USERS_FAIL;
declare const b2bUser_action_d_LOAD_B2B_USERS_SUCCESS: typeof LOAD_B2B_USERS_SUCCESS;
declare const b2bUser_action_d_LOAD_B2B_USER_APPROVERS: typeof LOAD_B2B_USER_APPROVERS;
declare const b2bUser_action_d_LOAD_B2B_USER_APPROVERS_FAIL: typeof LOAD_B2B_USER_APPROVERS_FAIL;
declare const b2bUser_action_d_LOAD_B2B_USER_APPROVERS_SUCCESS: typeof LOAD_B2B_USER_APPROVERS_SUCCESS;
declare const b2bUser_action_d_LOAD_B2B_USER_FAIL: typeof LOAD_B2B_USER_FAIL;
declare const b2bUser_action_d_LOAD_B2B_USER_PERMISSIONS: typeof LOAD_B2B_USER_PERMISSIONS;
declare const b2bUser_action_d_LOAD_B2B_USER_PERMISSIONS_FAIL: typeof LOAD_B2B_USER_PERMISSIONS_FAIL;
declare const b2bUser_action_d_LOAD_B2B_USER_PERMISSIONS_SUCCESS: typeof LOAD_B2B_USER_PERMISSIONS_SUCCESS;
declare const b2bUser_action_d_LOAD_B2B_USER_SUCCESS: typeof LOAD_B2B_USER_SUCCESS;
declare const b2bUser_action_d_LOAD_B2B_USER_USER_GROUPS: typeof LOAD_B2B_USER_USER_GROUPS;
declare const b2bUser_action_d_LOAD_B2B_USER_USER_GROUPS_FAIL: typeof LOAD_B2B_USER_USER_GROUPS_FAIL;
declare const b2bUser_action_d_LOAD_B2B_USER_USER_GROUPS_SUCCESS: typeof LOAD_B2B_USER_USER_GROUPS_SUCCESS;
type b2bUser_action_d_LoadB2BUser = LoadB2BUser;
declare const b2bUser_action_d_LoadB2BUser: typeof LoadB2BUser;
type b2bUser_action_d_LoadB2BUserApprovers = LoadB2BUserApprovers;
declare const b2bUser_action_d_LoadB2BUserApprovers: typeof LoadB2BUserApprovers;
type b2bUser_action_d_LoadB2BUserApproversFail = LoadB2BUserApproversFail;
declare const b2bUser_action_d_LoadB2BUserApproversFail: typeof LoadB2BUserApproversFail;
type b2bUser_action_d_LoadB2BUserApproversSuccess = LoadB2BUserApproversSuccess;
declare const b2bUser_action_d_LoadB2BUserApproversSuccess: typeof LoadB2BUserApproversSuccess;
type b2bUser_action_d_LoadB2BUserFail = LoadB2BUserFail;
declare const b2bUser_action_d_LoadB2BUserFail: typeof LoadB2BUserFail;
type b2bUser_action_d_LoadB2BUserPermissions = LoadB2BUserPermissions;
declare const b2bUser_action_d_LoadB2BUserPermissions: typeof LoadB2BUserPermissions;
type b2bUser_action_d_LoadB2BUserPermissionsFail = LoadB2BUserPermissionsFail;
declare const b2bUser_action_d_LoadB2BUserPermissionsFail: typeof LoadB2BUserPermissionsFail;
type b2bUser_action_d_LoadB2BUserPermissionsSuccess = LoadB2BUserPermissionsSuccess;
declare const b2bUser_action_d_LoadB2BUserPermissionsSuccess: typeof LoadB2BUserPermissionsSuccess;
type b2bUser_action_d_LoadB2BUserSuccess = LoadB2BUserSuccess;
declare const b2bUser_action_d_LoadB2BUserSuccess: typeof LoadB2BUserSuccess;
type b2bUser_action_d_LoadB2BUserUserGroups = LoadB2BUserUserGroups;
declare const b2bUser_action_d_LoadB2BUserUserGroups: typeof LoadB2BUserUserGroups;
type b2bUser_action_d_LoadB2BUserUserGroupsFail = LoadB2BUserUserGroupsFail;
declare const b2bUser_action_d_LoadB2BUserUserGroupsFail: typeof LoadB2BUserUserGroupsFail;
type b2bUser_action_d_LoadB2BUserUserGroupsSuccess = LoadB2BUserUserGroupsSuccess;
declare const b2bUser_action_d_LoadB2BUserUserGroupsSuccess: typeof LoadB2BUserUserGroupsSuccess;
type b2bUser_action_d_LoadB2BUsers = LoadB2BUsers;
declare const b2bUser_action_d_LoadB2BUsers: typeof LoadB2BUsers;
type b2bUser_action_d_LoadB2BUsersFail = LoadB2BUsersFail;
declare const b2bUser_action_d_LoadB2BUsersFail: typeof LoadB2BUsersFail;
type b2bUser_action_d_LoadB2BUsersSuccess = LoadB2BUsersSuccess;
declare const b2bUser_action_d_LoadB2BUsersSuccess: typeof LoadB2BUsersSuccess;
declare const b2bUser_action_d_UNASSIGN_B2B_USER_APPROVER: typeof UNASSIGN_B2B_USER_APPROVER;
declare const b2bUser_action_d_UNASSIGN_B2B_USER_APPROVER_FAIL: typeof UNASSIGN_B2B_USER_APPROVER_FAIL;
declare const b2bUser_action_d_UNASSIGN_B2B_USER_APPROVER_SUCCESS: typeof UNASSIGN_B2B_USER_APPROVER_SUCCESS;
declare const b2bUser_action_d_UNASSIGN_B2B_USER_PERMISSION: typeof UNASSIGN_B2B_USER_PERMISSION;
declare const b2bUser_action_d_UNASSIGN_B2B_USER_PERMISSION_FAIL: typeof UNASSIGN_B2B_USER_PERMISSION_FAIL;
declare const b2bUser_action_d_UNASSIGN_B2B_USER_PERMISSION_SUCCESS: typeof UNASSIGN_B2B_USER_PERMISSION_SUCCESS;
declare const b2bUser_action_d_UNASSIGN_B2B_USER_USER_GROUP: typeof UNASSIGN_B2B_USER_USER_GROUP;
declare const b2bUser_action_d_UNASSIGN_B2B_USER_USER_GROUP_FAIL: typeof UNASSIGN_B2B_USER_USER_GROUP_FAIL;
declare const b2bUser_action_d_UNASSIGN_B2B_USER_USER_GROUP_SUCCESS: typeof UNASSIGN_B2B_USER_USER_GROUP_SUCCESS;
declare const b2bUser_action_d_UPDATE_B2B_USER: typeof UPDATE_B2B_USER;
declare const b2bUser_action_d_UPDATE_B2B_USER_FAIL: typeof UPDATE_B2B_USER_FAIL;
declare const b2bUser_action_d_UPDATE_B2B_USER_SUCCESS: typeof UPDATE_B2B_USER_SUCCESS;
type b2bUser_action_d_UnassignB2BUserApprover = UnassignB2BUserApprover;
declare const b2bUser_action_d_UnassignB2BUserApprover: typeof UnassignB2BUserApprover;
type b2bUser_action_d_UnassignB2BUserApproverFail = UnassignB2BUserApproverFail;
declare const b2bUser_action_d_UnassignB2BUserApproverFail: typeof UnassignB2BUserApproverFail;
type b2bUser_action_d_UnassignB2BUserApproverSuccess = UnassignB2BUserApproverSuccess;
declare const b2bUser_action_d_UnassignB2BUserApproverSuccess: typeof UnassignB2BUserApproverSuccess;
type b2bUser_action_d_UnassignB2BUserPermission = UnassignB2BUserPermission;
declare const b2bUser_action_d_UnassignB2BUserPermission: typeof UnassignB2BUserPermission;
type b2bUser_action_d_UnassignB2BUserPermissionFail = UnassignB2BUserPermissionFail;
declare const b2bUser_action_d_UnassignB2BUserPermissionFail: typeof UnassignB2BUserPermissionFail;
type b2bUser_action_d_UnassignB2BUserPermissionSuccess = UnassignB2BUserPermissionSuccess;
declare const b2bUser_action_d_UnassignB2BUserPermissionSuccess: typeof UnassignB2BUserPermissionSuccess;
type b2bUser_action_d_UnassignB2BUserUserGroup = UnassignB2BUserUserGroup;
declare const b2bUser_action_d_UnassignB2BUserUserGroup: typeof UnassignB2BUserUserGroup;
type b2bUser_action_d_UnassignB2BUserUserGroupFail = UnassignB2BUserUserGroupFail;
declare const b2bUser_action_d_UnassignB2BUserUserGroupFail: typeof UnassignB2BUserUserGroupFail;
type b2bUser_action_d_UnassignB2BUserUserGroupSuccess = UnassignB2BUserUserGroupSuccess;
declare const b2bUser_action_d_UnassignB2BUserUserGroupSuccess: typeof UnassignB2BUserUserGroupSuccess;
type b2bUser_action_d_UpdateB2BUser = UpdateB2BUser;
declare const b2bUser_action_d_UpdateB2BUser: typeof UpdateB2BUser;
type b2bUser_action_d_UpdateB2BUserFail = UpdateB2BUserFail;
declare const b2bUser_action_d_UpdateB2BUserFail: typeof UpdateB2BUserFail;
type b2bUser_action_d_UpdateB2BUserSuccess = UpdateB2BUserSuccess;
declare const b2bUser_action_d_UpdateB2BUserSuccess: typeof UpdateB2BUserSuccess;
declare namespace b2bUser_action_d {
  export { b2bUser_action_d_ASSIGN_B2B_USER_APPROVER as ASSIGN_B2B_USER_APPROVER, b2bUser_action_d_ASSIGN_B2B_USER_APPROVER_FAIL as ASSIGN_B2B_USER_APPROVER_FAIL, b2bUser_action_d_ASSIGN_B2B_USER_APPROVER_SUCCESS as ASSIGN_B2B_USER_APPROVER_SUCCESS, b2bUser_action_d_ASSIGN_B2B_USER_PERMISSION as ASSIGN_B2B_USER_PERMISSION, b2bUser_action_d_ASSIGN_B2B_USER_PERMISSION_FAIL as ASSIGN_B2B_USER_PERMISSION_FAIL, b2bUser_action_d_ASSIGN_B2B_USER_PERMISSION_SUCCESS as ASSIGN_B2B_USER_PERMISSION_SUCCESS, b2bUser_action_d_ASSIGN_B2B_USER_USER_GROUP as ASSIGN_B2B_USER_USER_GROUP, b2bUser_action_d_ASSIGN_B2B_USER_USER_GROUP_FAIL as ASSIGN_B2B_USER_USER_GROUP_FAIL, b2bUser_action_d_ASSIGN_B2B_USER_USER_GROUP_SUCCESS as ASSIGN_B2B_USER_USER_GROUP_SUCCESS, b2bUser_action_d_AssignB2BUserApprover as AssignB2BUserApprover, b2bUser_action_d_AssignB2BUserApproverFail as AssignB2BUserApproverFail, b2bUser_action_d_AssignB2BUserApproverSuccess as AssignB2BUserApproverSuccess, b2bUser_action_d_AssignB2BUserPermission as AssignB2BUserPermission, b2bUser_action_d_AssignB2BUserPermissionFail as AssignB2BUserPermissionFail, b2bUser_action_d_AssignB2BUserPermissionSuccess as AssignB2BUserPermissionSuccess, b2bUser_action_d_AssignB2BUserUserGroup as AssignB2BUserUserGroup, b2bUser_action_d_AssignB2BUserUserGroupFail as AssignB2BUserUserGroupFail, b2bUser_action_d_AssignB2BUserUserGroupSuccess as AssignB2BUserUserGroupSuccess, b2bUser_action_d_CREATE_B2B_USER as CREATE_B2B_USER, b2bUser_action_d_CREATE_B2B_USER_FAIL as CREATE_B2B_USER_FAIL, b2bUser_action_d_CREATE_B2B_USER_SUCCESS as CREATE_B2B_USER_SUCCESS, b2bUser_action_d_CreateB2BUser as CreateB2BUser, b2bUser_action_d_CreateB2BUserFail as CreateB2BUserFail, b2bUser_action_d_CreateB2BUserSuccess as CreateB2BUserSuccess, b2bUser_action_d_LOAD_B2B_USER as LOAD_B2B_USER, b2bUser_action_d_LOAD_B2B_USERS as LOAD_B2B_USERS, b2bUser_action_d_LOAD_B2B_USERS_FAIL as LOAD_B2B_USERS_FAIL, b2bUser_action_d_LOAD_B2B_USERS_SUCCESS as LOAD_B2B_USERS_SUCCESS, b2bUser_action_d_LOAD_B2B_USER_APPROVERS as LOAD_B2B_USER_APPROVERS, b2bUser_action_d_LOAD_B2B_USER_APPROVERS_FAIL as LOAD_B2B_USER_APPROVERS_FAIL, b2bUser_action_d_LOAD_B2B_USER_APPROVERS_SUCCESS as LOAD_B2B_USER_APPROVERS_SUCCESS, b2bUser_action_d_LOAD_B2B_USER_FAIL as LOAD_B2B_USER_FAIL, b2bUser_action_d_LOAD_B2B_USER_PERMISSIONS as LOAD_B2B_USER_PERMISSIONS, b2bUser_action_d_LOAD_B2B_USER_PERMISSIONS_FAIL as LOAD_B2B_USER_PERMISSIONS_FAIL, b2bUser_action_d_LOAD_B2B_USER_PERMISSIONS_SUCCESS as LOAD_B2B_USER_PERMISSIONS_SUCCESS, b2bUser_action_d_LOAD_B2B_USER_SUCCESS as LOAD_B2B_USER_SUCCESS, b2bUser_action_d_LOAD_B2B_USER_USER_GROUPS as LOAD_B2B_USER_USER_GROUPS, b2bUser_action_d_LOAD_B2B_USER_USER_GROUPS_FAIL as LOAD_B2B_USER_USER_GROUPS_FAIL, b2bUser_action_d_LOAD_B2B_USER_USER_GROUPS_SUCCESS as LOAD_B2B_USER_USER_GROUPS_SUCCESS, b2bUser_action_d_LoadB2BUser as LoadB2BUser, b2bUser_action_d_LoadB2BUserApprovers as LoadB2BUserApprovers, b2bUser_action_d_LoadB2BUserApproversFail as LoadB2BUserApproversFail, b2bUser_action_d_LoadB2BUserApproversSuccess as LoadB2BUserApproversSuccess, b2bUser_action_d_LoadB2BUserFail as LoadB2BUserFail, b2bUser_action_d_LoadB2BUserPermissions as LoadB2BUserPermissions, b2bUser_action_d_LoadB2BUserPermissionsFail as LoadB2BUserPermissionsFail, b2bUser_action_d_LoadB2BUserPermissionsSuccess as LoadB2BUserPermissionsSuccess, b2bUser_action_d_LoadB2BUserSuccess as LoadB2BUserSuccess, b2bUser_action_d_LoadB2BUserUserGroups as LoadB2BUserUserGroups, b2bUser_action_d_LoadB2BUserUserGroupsFail as LoadB2BUserUserGroupsFail, b2bUser_action_d_LoadB2BUserUserGroupsSuccess as LoadB2BUserUserGroupsSuccess, b2bUser_action_d_LoadB2BUsers as LoadB2BUsers, b2bUser_action_d_LoadB2BUsersFail as LoadB2BUsersFail, b2bUser_action_d_LoadB2BUsersSuccess as LoadB2BUsersSuccess, b2bUser_action_d_UNASSIGN_B2B_USER_APPROVER as UNASSIGN_B2B_USER_APPROVER, b2bUser_action_d_UNASSIGN_B2B_USER_APPROVER_FAIL as UNASSIGN_B2B_USER_APPROVER_FAIL, b2bUser_action_d_UNASSIGN_B2B_USER_APPROVER_SUCCESS as UNASSIGN_B2B_USER_APPROVER_SUCCESS, b2bUser_action_d_UNASSIGN_B2B_USER_PERMISSION as UNASSIGN_B2B_USER_PERMISSION, b2bUser_action_d_UNASSIGN_B2B_USER_PERMISSION_FAIL as UNASSIGN_B2B_USER_PERMISSION_FAIL, b2bUser_action_d_UNASSIGN_B2B_USER_PERMISSION_SUCCESS as UNASSIGN_B2B_USER_PERMISSION_SUCCESS, b2bUser_action_d_UNASSIGN_B2B_USER_USER_GROUP as UNASSIGN_B2B_USER_USER_GROUP, b2bUser_action_d_UNASSIGN_B2B_USER_USER_GROUP_FAIL as UNASSIGN_B2B_USER_USER_GROUP_FAIL, b2bUser_action_d_UNASSIGN_B2B_USER_USER_GROUP_SUCCESS as UNASSIGN_B2B_USER_USER_GROUP_SUCCESS, b2bUser_action_d_UPDATE_B2B_USER as UPDATE_B2B_USER, b2bUser_action_d_UPDATE_B2B_USER_FAIL as UPDATE_B2B_USER_FAIL, b2bUser_action_d_UPDATE_B2B_USER_SUCCESS as UPDATE_B2B_USER_SUCCESS, b2bUser_action_d_UnassignB2BUserApprover as UnassignB2BUserApprover, b2bUser_action_d_UnassignB2BUserApproverFail as UnassignB2BUserApproverFail, b2bUser_action_d_UnassignB2BUserApproverSuccess as UnassignB2BUserApproverSuccess, b2bUser_action_d_UnassignB2BUserPermission as UnassignB2BUserPermission, b2bUser_action_d_UnassignB2BUserPermissionFail as UnassignB2BUserPermissionFail, b2bUser_action_d_UnassignB2BUserPermissionSuccess as UnassignB2BUserPermissionSuccess, b2bUser_action_d_UnassignB2BUserUserGroup as UnassignB2BUserUserGroup, b2bUser_action_d_UnassignB2BUserUserGroupFail as UnassignB2BUserUserGroupFail, b2bUser_action_d_UnassignB2BUserUserGroupSuccess as UnassignB2BUserUserGroupSuccess, b2bUser_action_d_UpdateB2BUser as UpdateB2BUser, b2bUser_action_d_UpdateB2BUserFail as UpdateB2BUserFail, b2bUser_action_d_UpdateB2BUserSuccess as UpdateB2BUserSuccess };
  export type { b2bUser_action_d_B2BUserAction as B2BUserAction };
}

declare const CLEAR_ORGANIZATION_DATA = "[Organization] Clear Data";
declare class OrganizationClearData implements Action {
    readonly type = "[Organization] Clear Data";
}
type OrganizationAction = OrganizationClearData;

declare const organization_action_d_CLEAR_ORGANIZATION_DATA: typeof CLEAR_ORGANIZATION_DATA;
type organization_action_d_OrganizationAction = OrganizationAction;
type organization_action_d_OrganizationClearData = OrganizationClearData;
declare const organization_action_d_OrganizationClearData: typeof OrganizationClearData;
declare namespace organization_action_d {
  export { organization_action_d_CLEAR_ORGANIZATION_DATA as CLEAR_ORGANIZATION_DATA, organization_action_d_OrganizationClearData as OrganizationClearData };
  export type { organization_action_d_OrganizationAction as OrganizationAction };
}

declare const getBudgetManagementState: MemoizedSelector<StateWithOrganization, BudgetManagement>;
declare const getBudgetsState: MemoizedSelector<StateWithOrganization, StateUtils.EntityLoaderState<Budget>>;
declare const getBudget: (budgetCode: string) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<Budget>>;
declare const getBudgetValue: (budgetCode: string) => MemoizedSelector<StateWithOrganization, Budget>;
declare const getBudgetList: (params: SearchConfig) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<EntitiesModel<Budget>>>;

declare const budget_selector_d_getBudget: typeof getBudget;
declare const budget_selector_d_getBudgetList: typeof getBudgetList;
declare const budget_selector_d_getBudgetManagementState: typeof getBudgetManagementState;
declare const budget_selector_d_getBudgetValue: typeof getBudgetValue;
declare const budget_selector_d_getBudgetsState: typeof getBudgetsState;
declare namespace budget_selector_d {
  export {
    budget_selector_d_getBudget as getBudget,
    budget_selector_d_getBudgetList as getBudgetList,
    budget_selector_d_getBudgetManagementState as getBudgetManagementState,
    budget_selector_d_getBudgetValue as getBudgetValue,
    budget_selector_d_getBudgetsState as getBudgetsState,
  };
}

declare const getPermissionManagementState: MemoizedSelector<StateWithOrganization, PermissionManagement>;
declare const getPermissionsState: MemoizedSelector<StateWithOrganization, StateUtils.EntityLoaderState<Permission>>;
declare const getPermissionState: (permissionId: string) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<Permission>>;
declare const getPermissionTypesState: MemoizedSelector<StateWithOrganization, StateUtils.EntityLoaderState<OrderApprovalPermissionType[]>>;
declare const getPermission: (permissionCode: string) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<Permission>>;
declare const getPermissionValue: (permissionCode: string) => MemoizedSelector<StateWithOrganization, Permission>;
declare const getPermissionList: (params: SearchConfig) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<EntitiesModel<Permission>>>;
declare const getPermissionTypes: () => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<OrderApprovalPermissionType[]>>;

declare const permission_selector_d_getPermission: typeof getPermission;
declare const permission_selector_d_getPermissionList: typeof getPermissionList;
declare const permission_selector_d_getPermissionManagementState: typeof getPermissionManagementState;
declare const permission_selector_d_getPermissionState: typeof getPermissionState;
declare const permission_selector_d_getPermissionTypes: typeof getPermissionTypes;
declare const permission_selector_d_getPermissionTypesState: typeof getPermissionTypesState;
declare const permission_selector_d_getPermissionValue: typeof getPermissionValue;
declare const permission_selector_d_getPermissionsState: typeof getPermissionsState;
declare namespace permission_selector_d {
  export {
    permission_selector_d_getPermission as getPermission,
    permission_selector_d_getPermissionList as getPermissionList,
    permission_selector_d_getPermissionManagementState as getPermissionManagementState,
    permission_selector_d_getPermissionState as getPermissionState,
    permission_selector_d_getPermissionTypes as getPermissionTypes,
    permission_selector_d_getPermissionTypesState as getPermissionTypesState,
    permission_selector_d_getPermissionValue as getPermissionValue,
    permission_selector_d_getPermissionsState as getPermissionsState,
  };
}

declare const getB2BOrgUnitState: MemoizedSelector<StateWithOrganization, OrgUnits>;
declare const getOrgUnitsNodeListState: MemoizedSelector<StateWithOrganization, StateUtils.EntityLoaderState<B2BUnitNode[]>>;
declare const getOrgUnitsState: MemoizedSelector<StateWithOrganization, StateUtils.EntityLoaderState<B2BUnitNode>>;
declare const getOrgUnitsTreeState: MemoizedSelector<StateWithOrganization, StateUtils.EntityLoaderState<B2BUnitNode>>;
declare const getAddressesState: MemoizedSelector<StateWithOrganization, StateUtils.EntityLoaderState<Address>>;
declare const getApprovalProcessesState: MemoizedSelector<StateWithOrganization, StateUtils.EntityLoaderState<B2BApprovalProcess[]>>;
declare const getOrgUnit: (orgUnitId: string) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<B2BUnit>>;
declare const getOrgUnitValue: (orgUnitId: string) => MemoizedSelector<StateWithOrganization, B2BUnit>;
declare const getOrgUnitState: (orgUnitId: string) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<B2BUnit>>;
declare const getOrgUnitList: () => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<B2BUnitNode[]>>;
declare const getOrgUnitTree: () => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<B2BUnitNode>>;
declare const getApprovalProcesses: () => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<B2BApprovalProcess[]>>;
declare const getAssignedUsers: (orgUnitId: string, roleId: string, params: SearchConfig) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<EntitiesModel<B2BUser>>>;
declare const getB2BAddresses: (orgUnitId: string, params?: SearchConfig) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<EntitiesModel<Address>>>;
declare const getB2BAddress: (addressId: string) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<Address>>;

declare const orgUnit_selector_d_getAddressesState: typeof getAddressesState;
declare const orgUnit_selector_d_getApprovalProcesses: typeof getApprovalProcesses;
declare const orgUnit_selector_d_getApprovalProcessesState: typeof getApprovalProcessesState;
declare const orgUnit_selector_d_getAssignedUsers: typeof getAssignedUsers;
declare const orgUnit_selector_d_getB2BAddress: typeof getB2BAddress;
declare const orgUnit_selector_d_getB2BAddresses: typeof getB2BAddresses;
declare const orgUnit_selector_d_getB2BOrgUnitState: typeof getB2BOrgUnitState;
declare const orgUnit_selector_d_getOrgUnit: typeof getOrgUnit;
declare const orgUnit_selector_d_getOrgUnitList: typeof getOrgUnitList;
declare const orgUnit_selector_d_getOrgUnitState: typeof getOrgUnitState;
declare const orgUnit_selector_d_getOrgUnitTree: typeof getOrgUnitTree;
declare const orgUnit_selector_d_getOrgUnitValue: typeof getOrgUnitValue;
declare const orgUnit_selector_d_getOrgUnitsNodeListState: typeof getOrgUnitsNodeListState;
declare const orgUnit_selector_d_getOrgUnitsState: typeof getOrgUnitsState;
declare const orgUnit_selector_d_getOrgUnitsTreeState: typeof getOrgUnitsTreeState;
declare namespace orgUnit_selector_d {
  export {
    orgUnit_selector_d_getAddressesState as getAddressesState,
    orgUnit_selector_d_getApprovalProcesses as getApprovalProcesses,
    orgUnit_selector_d_getApprovalProcessesState as getApprovalProcessesState,
    orgUnit_selector_d_getAssignedUsers as getAssignedUsers,
    orgUnit_selector_d_getB2BAddress as getB2BAddress,
    orgUnit_selector_d_getB2BAddresses as getB2BAddresses,
    orgUnit_selector_d_getB2BOrgUnitState as getB2BOrgUnitState,
    orgUnit_selector_d_getOrgUnit as getOrgUnit,
    orgUnit_selector_d_getOrgUnitList as getOrgUnitList,
    orgUnit_selector_d_getOrgUnitState as getOrgUnitState,
    orgUnit_selector_d_getOrgUnitTree as getOrgUnitTree,
    orgUnit_selector_d_getOrgUnitValue as getOrgUnitValue,
    orgUnit_selector_d_getOrgUnitsNodeListState as getOrgUnitsNodeListState,
    orgUnit_selector_d_getOrgUnitsState as getOrgUnitsState,
    orgUnit_selector_d_getOrgUnitsTreeState as getOrgUnitsTreeState,
  };
}

declare const getUserGroupManagementState: MemoizedSelector<StateWithOrganization, UserGroupManagement>;
declare const getUserGroupsState: MemoizedSelector<StateWithOrganization, StateUtils.EntityLoaderState<UserGroup>>;
declare const getUserGroup: (userGroupId: string) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<UserGroup>>;
declare const getUserGroupValue: (userGroupId: string) => MemoizedSelector<StateWithOrganization, UserGroup>;
declare const getUserGroupList: (params: SearchConfig) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<EntitiesModel<UserGroup>>>;
declare const getAvailableOrgCustomers: (code: string, params: SearchConfig) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<EntitiesModel<B2BUser>>>;
declare const getAvailableOrderApprovalPermissions: (code: string, params: SearchConfig) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<EntitiesModel<Permission>>>;
declare const getUserGroupState: (code: string) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<UserGroup>>;

declare const userGroup_selector_d_getAvailableOrderApprovalPermissions: typeof getAvailableOrderApprovalPermissions;
declare const userGroup_selector_d_getAvailableOrgCustomers: typeof getAvailableOrgCustomers;
declare const userGroup_selector_d_getUserGroup: typeof getUserGroup;
declare const userGroup_selector_d_getUserGroupList: typeof getUserGroupList;
declare const userGroup_selector_d_getUserGroupManagementState: typeof getUserGroupManagementState;
declare const userGroup_selector_d_getUserGroupState: typeof getUserGroupState;
declare const userGroup_selector_d_getUserGroupValue: typeof getUserGroupValue;
declare const userGroup_selector_d_getUserGroupsState: typeof getUserGroupsState;
declare namespace userGroup_selector_d {
  export {
    userGroup_selector_d_getAvailableOrderApprovalPermissions as getAvailableOrderApprovalPermissions,
    userGroup_selector_d_getAvailableOrgCustomers as getAvailableOrgCustomers,
    userGroup_selector_d_getUserGroup as getUserGroup,
    userGroup_selector_d_getUserGroupList as getUserGroupList,
    userGroup_selector_d_getUserGroupManagementState as getUserGroupManagementState,
    userGroup_selector_d_getUserGroupState as getUserGroupState,
    userGroup_selector_d_getUserGroupValue as getUserGroupValue,
    userGroup_selector_d_getUserGroupsState as getUserGroupsState,
  };
}

declare const getCostCenterManagementState: MemoizedSelector<StateWithOrganization, CostCenterManagement>;
declare const getCostCentersState: MemoizedSelector<StateWithOrganization, StateUtils.EntityLoaderState<CostCenter>>;
declare const getCostCenter: (costCenterCode: string) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<CostCenter>>;
declare const getCostCenterValue: (costCenterCode: string) => MemoizedSelector<StateWithOrganization, Budget>;
declare const getCostCenterList: (params: SearchConfig) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<EntitiesModel<CostCenter>>>;
declare const getAssignedBudgets: (code: string, params: SearchConfig) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<EntitiesModel<Budget>>>;
declare const getCostCenterState: (code: string) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<CostCenter>>;

declare const costCenter_selector_d_getAssignedBudgets: typeof getAssignedBudgets;
declare const costCenter_selector_d_getCostCenter: typeof getCostCenter;
declare const costCenter_selector_d_getCostCenterList: typeof getCostCenterList;
declare const costCenter_selector_d_getCostCenterManagementState: typeof getCostCenterManagementState;
declare const costCenter_selector_d_getCostCenterState: typeof getCostCenterState;
declare const costCenter_selector_d_getCostCenterValue: typeof getCostCenterValue;
declare const costCenter_selector_d_getCostCentersState: typeof getCostCentersState;
declare namespace costCenter_selector_d {
  export {
    costCenter_selector_d_getAssignedBudgets as getAssignedBudgets,
    costCenter_selector_d_getCostCenter as getCostCenter,
    costCenter_selector_d_getCostCenterList as getCostCenterList,
    costCenter_selector_d_getCostCenterManagementState as getCostCenterManagementState,
    costCenter_selector_d_getCostCenterState as getCostCenterState,
    costCenter_selector_d_getCostCenterValue as getCostCenterValue,
    costCenter_selector_d_getCostCentersState as getCostCentersState,
  };
}

declare const getB2BUserManagementState: MemoizedSelector<StateWithOrganization, B2BUserManagement>;
declare const getB2BUsersState: MemoizedSelector<StateWithOrganization, StateUtils.EntityLoaderState<B2BUser>>;
declare const getB2BUserState: (orgCustomerId: string) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<B2BUser>>;
declare const getB2BUserValue: (orgCustomerId: string) => MemoizedSelector<StateWithOrganization, B2BUser>;
declare const getUserList: (params: SearchConfig) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<EntitiesModel<B2BUser>>>;
declare const getB2BUserApprovers: (code: string, params: SearchConfig) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<EntitiesModel<B2BUser>>>;
declare const getB2BUserPermissions: (code: string, params: SearchConfig) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<EntitiesModel<Permission>>>;
declare const getB2BUserUserGroups: (code: string, params: SearchConfig) => MemoizedSelector<StateWithOrganization, StateUtils.LoaderState<EntitiesModel<UserGroup>>>;

declare const b2bUser_selector_d_getB2BUserApprovers: typeof getB2BUserApprovers;
declare const b2bUser_selector_d_getB2BUserManagementState: typeof getB2BUserManagementState;
declare const b2bUser_selector_d_getB2BUserPermissions: typeof getB2BUserPermissions;
declare const b2bUser_selector_d_getB2BUserState: typeof getB2BUserState;
declare const b2bUser_selector_d_getB2BUserUserGroups: typeof getB2BUserUserGroups;
declare const b2bUser_selector_d_getB2BUserValue: typeof getB2BUserValue;
declare const b2bUser_selector_d_getB2BUsersState: typeof getB2BUsersState;
declare const b2bUser_selector_d_getUserList: typeof getUserList;
declare namespace b2bUser_selector_d {
  export {
    b2bUser_selector_d_getB2BUserApprovers as getB2BUserApprovers,
    b2bUser_selector_d_getB2BUserManagementState as getB2BUserManagementState,
    b2bUser_selector_d_getB2BUserPermissions as getB2BUserPermissions,
    b2bUser_selector_d_getB2BUserState as getB2BUserState,
    b2bUser_selector_d_getB2BUserUserGroups as getB2BUserUserGroups,
    b2bUser_selector_d_getB2BUserValue as getB2BUserValue,
    b2bUser_selector_d_getB2BUsersState as getB2BUsersState,
    b2bUser_selector_d_getUserList as getUserList,
  };
}

declare class BudgetService {
    protected store: Store<StateWithOrganization>;
    protected userIdService: UserIdService;
    constructor(store: Store<StateWithOrganization>, userIdService: UserIdService);
    loadBudget(budgetCode: string): void;
    loadBudgets(params: SearchConfig): void;
    private getBudgetState;
    private getBudgetValue;
    private getBudgetList;
    get(budgetCode: string): Observable<Budget>;
    getList(params: SearchConfig): Observable<EntitiesModel<Budget> | undefined>;
    getCostCenters(budgetCode: string): Observable<EntitiesModel<CostCenter>>;
    getErrorState(budgetCode: string): Observable<boolean>;
    create(budget: Budget): void;
    update(budgetCode: string, budget: Budget): void;
    getLoadingStatus(budgetCode: string): Observable<OrganizationItemStatus<Budget>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BudgetService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BudgetService>;
}

declare class CostCenterService {
    protected store: Store<StateWithOrganization>;
    protected userIdService: UserIdService;
    constructor(store: Store<StateWithOrganization>, userIdService: UserIdService);
    load(costCenterCode: string): void;
    loadList(params: SearchConfig): void;
    private getCostCenter;
    private getCostCenterValue;
    private getCostCenterList;
    private getBudgetList;
    get(costCenterCode: string): Observable<Budget>;
    getList(params: SearchConfig): Observable<EntitiesModel<CostCenter> | undefined>;
    private getCostCenterState;
    create(costCenter: CostCenter): void;
    update(costCenterCode: string, costCenter: CostCenter): void;
    getLoadingStatus(costCenterCode: string): Observable<OrganizationItemStatus<CostCenter>>;
    loadBudgets(costCenterCode: string, params: SearchConfig): void;
    getBudgets(costCenterCode: string, params: SearchConfig): Observable<EntitiesModel<Budget> | undefined>;
    assignBudget(costCenterCode: string, budgetCode: string): void;
    unassignBudget(costCenterCode: string, budgetCode: string): void;
    getErrorState(costCenterCode: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CostCenterService>;
}

declare class OrgUnitService {
    protected store: Store<StateWithOrganization>;
    protected userIdService: UserIdService;
    constructor(store: Store<StateWithOrganization>, userIdService: UserIdService);
    clearAssignedUsersList(orgUnitId: string, roleId: string, params: SearchConfig): void;
    load(orgUnitId: string): void;
    loadList(): void;
    loadTree(): void;
    loadApprovalProcesses(): void;
    loadUsers(orgUnitId: string, roleId: string, params: SearchConfig): void;
    loadAddresses(orgUnitId: string): void;
    private getOrgUnit;
    private getOrgUnitValue;
    private getTreeState;
    private getOrgUnitsList;
    private getAddressesState;
    private getAddressState;
    private getAssignedUsers;
    private getApprovalProcessesList;
    get(orgUnitId: string): Observable<B2BUnit>;
    getCostCenters(orgUnitId: string): Observable<EntitiesModel<CostCenter>>;
    protected findUnitChildrenInTree(orginitId: string, unit: B2BUnitNode): B2BUnitNode[];
    getChildUnits(orgUnitId: string): Observable<EntitiesModel<B2BUnitNode>>;
    getTree(): Observable<B2BUnitNode | undefined>;
    getApprovalProcesses(): Observable<B2BApprovalProcess[] | undefined>;
    getList(): Observable<B2BUnitNode[] | undefined>;
    getActiveUnitList(): Observable<B2BUnitNode[] | undefined>;
    protected sortUnitList(a: B2BUnitNode, b: B2BUnitNode): 0 | 1 | -1;
    getUsers(orgUnitId: string, roleId: string, params: SearchConfig): Observable<EntitiesModel<B2BUser> | undefined>;
    getErrorState(orgCustomerId: string): Observable<boolean>;
    create(unit: B2BUnit): void;
    update(unitCode: string, unit: B2BUnit): void;
    getLoadingStatus(orgUnitId: string): Observable<OrganizationItemStatus<B2BUnit>>;
    assignRole(orgCustomerId: string, roleId: string): void;
    unassignRole(orgCustomerId: string, roleId: string): void;
    assignApprover(orgUnitId: string, orgCustomerId: string, roleId: string): void;
    unassignApprover(orgUnitId: string, orgCustomerId: string, roleId: string): void;
    createAddress(orgUnitId: string, address: Address): void;
    getAddresses(orgUnitId: string): Observable<EntitiesModel<Address> | undefined>;
    getAddress(orgUnitId: string, addressId: string): Observable<Address | undefined>;
    updateAddress(orgUnitId: string, addressId: string, address: Address): void;
    getAddressLoadingStatus(addressId: string): Observable<OrganizationItemStatus<Address>>;
    deleteAddress(orgUnitId: string, addressId: string): void;
    private getOrgUnitState;
    isUpdatingUnitAllowed(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrgUnitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrgUnitService>;
}

/**
 * Resolves the page data for Organization Pages.
 *
 * Breadcrumbs are built in this implementation only.
 *
 * @property {string} ORGANIZATION_SEMANTIC_ROUTE the default root path for organization pages.
 * @property {string} ORGANIZATION_TRANSLATION_KEY the default i18n key for the organization breadcrumb label.
 */
declare class OrganizationPageMetaResolver extends PageMetaResolver implements PageBreadcrumbResolver, PageTitleResolver, PageDescriptionResolver, PageRobotsResolver {
    protected contentPageMetaResolver: ContentPageMetaResolver;
    protected translation: TranslationService;
    protected semanticPath: SemanticPathService;
    protected routingService: RoutingService;
    pageTemplate: string;
    pageType: PageType;
    /**
     * Translation key for the breadcrumb of Organization home page
     */
    protected readonly ORGANIZATION_TRANSLATION_KEY = "organization.breadcrumb";
    /**
     * The semantic route of the organization landing page. It's used to recognize whether
     * we are on this page. In such a case we avoid showing the breadcrumb for this page.
     */
    protected readonly ORGANIZATION_SEMANTIC_ROUTE = "organization";
    constructor(contentPageMetaResolver: ContentPageMetaResolver, translation: TranslationService, semanticPath: SemanticPathService, routingService: RoutingService);
    resolveTitle(): Observable<string | undefined>;
    resolveDescription(): Observable<string | undefined>;
    resolveRobots(): Observable<PageRobotsMeta[]>;
    /**
     * Returns list of breadcrumbs for:
     * - the home page
     * - the organization home page
     * - the organization's child pages (i.e. cost center list)
     * - sub-routes of the organization's child pages (i.e. cost center details, edit cost center, ...)
     */
    resolveBreadcrumbs(): Observable<BreadcrumbMeta[]>;
    /**
     * Breadcrumb of the Organization page.
     * It's empty when the current page is the Organization page.
     */
    protected organizationPageBreadcrumb$: Observable<BreadcrumbMeta[]>;
    /**
     * Breadcrumbs returned in the method #resolveBreadcrumbs.
     */
    protected breadcrumbs$: Observable<BreadcrumbMeta[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrganizationPageMetaResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrganizationPageMetaResolver>;
}

declare class PermissionService {
    protected store: Store<StateWithOrganization>;
    protected userIdService: UserIdService;
    constructor(store: Store<StateWithOrganization>, userIdService: UserIdService);
    loadPermission(permissionCode: string): void;
    loadPermissions(params: SearchConfig): void;
    loadPermissionTypes(): void;
    private getPermission;
    private getPermissionValue;
    private getPermissionList;
    private getPermissionTypeList;
    get(permissionCode: string): Observable<Permission>;
    getTypes(): Observable<OrderApprovalPermissionType[] | undefined>;
    getList(params: SearchConfig): Observable<EntitiesModel<Permission> | undefined>;
    create(permission: Permission): void;
    update(permissionCode: string, permission: Permission): void;
    getLoadingStatus(permissionCode: string): Observable<OrganizationItemStatus<Permission>>;
    private getPermissionState;
    getErrorState(permissionCode: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PermissionService>;
}

declare class UserGroupService {
    protected store: Store<StateWithOrganization>;
    protected userIdService: UserIdService;
    constructor(store: Store<StateWithOrganization>, userIdService: UserIdService);
    load(userGroupId: string): void;
    loadList(params: SearchConfig): void;
    private getUserGroup;
    private getUserGroupValue;
    private getUserGroupList;
    private getAvailableOrgCustomersList;
    private getAvailableOrderApprovalPermissionsList;
    get(userGroupUid: string): Observable<UserGroup>;
    getList(params: SearchConfig): Observable<EntitiesModel<UserGroup> | undefined>;
    create(userGroup: UserGroup): void;
    update(userGroupId: string, userGroup: UserGroup): void;
    getLoadingStatus(budgetCode: string): Observable<OrganizationItemStatus<UserGroup>>;
    delete(userGroupId: string): void;
    loadAvailableOrgCustomers(userGroupId: string, params: SearchConfig): void;
    loadAvailableOrderApprovalPermissions(userGroupId: string, params: SearchConfig): void;
    getAvailableOrgCustomers(userGroupId: string, params: SearchConfig): Observable<EntitiesModel<B2BUser> | undefined>;
    getAvailableOrderApprovalPermissions(userGroupId: string, params: SearchConfig): Observable<EntitiesModel<Permission> | undefined>;
    assignMember(userGroupId: string, customerId: string): void;
    unassignMember(userGroupId: string, customerId: string): void;
    unassignAllMembers(userGroupId: string): void;
    assignPermission(userGroupId: string, permissionUid: string): void;
    unassignPermission(userGroupId: string, permissionUid: string): void;
    private getUserGroupState;
    getErrorState(code: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserGroupService>;
}

declare class UserGuard {
    protected globalMessageService: GlobalMessageService;
    protected b2bUserService: B2BUserService;
    protected semanticPathService: SemanticPathService;
    protected router: Router;
    constructor(globalMessageService: GlobalMessageService, b2bUserService: B2BUserService, semanticPathService: SemanticPathService, router: Router);
    canActivate(): boolean | UrlTree;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserGuard>;
}

declare class OrgUnitGuard {
    protected globalMessageService: GlobalMessageService;
    protected orgUnitService: OrgUnitService;
    protected semanticPathService: SemanticPathService;
    protected router: Router;
    constructor(globalMessageService: GlobalMessageService, orgUnitService: OrgUnitService, semanticPathService: SemanticPathService, router: Router);
    canActivate(): boolean | UrlTree;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrgUnitGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrgUnitGuard>;
}

declare class OrganizationBadRequestHandler extends HttpErrorHandler {
    responseStatus: HttpResponseStatus;
    protected costCenterMask: RegExp;
    protected unitMask: RegExp;
    protected permissionMask: RegExp;
    protected unknownMask: RegExp;
    hasMatch(errorResponse: HttpErrorResponse): boolean;
    handleError(_request: HttpRequest<any>, response: HttpErrorResponse): void;
    protected matchMask(response: HttpErrorResponse): boolean;
    protected handleOrganizationConflict(message: string, mask: RegExp, key: string): void;
    protected getErrors(response: HttpErrorResponse): ErrorModel[];
    getPriority(): Priority;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrganizationBadRequestHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrganizationBadRequestHandler>;
}

declare class OrganizationConflictHandler extends HttpErrorHandler {
    responseStatus: HttpResponseStatus;
    protected budgetMask: RegExp;
    protected userMask: RegExp;
    protected userGroupMask: RegExp;
    protected unitMask: RegExp;
    protected costCenterMask: RegExp;
    hasMatch(errorResponse: HttpErrorResponse): boolean;
    handleError(request: HttpRequest<any>, response: HttpErrorResponse): void;
    protected matchMask(response: HttpErrorResponse): boolean;
    protected handleConflict(message: string, mask: RegExp, key: string, code?: string): void;
    protected getErrors(response: HttpErrorResponse): ErrorModel[];
    getPriority(): Priority;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrganizationConflictHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrganizationConflictHandler>;
}

declare module '@spartacus/core' {
    interface B2BUnit {
        parentOrgUnit?: Partial<B2BUnit>;
        approvalProcess?: B2BApprovalProcess;
        administrators?: B2BUser[];
        approvers?: B2BUser[];
        customers?: B2BUser[];
        costCenters?: CostCenter[];
        managers?: B2BUser[];
    }
    interface B2BUser {
        approvers?: [];
        orgUnit?: B2BUnit;
        selected?: boolean;
        isAssignedToApprovers?: boolean;
        email?: string;
    }
    interface CostCenter {
        activeFlag?: boolean;
        currency?: Currency;
        originalCode?: string;
    }
}

export { ADDRESS_ENTITIES, ADDRESS_LIST, AdminGuard, AdministrationCoreModule, B2BUNIT_APPROVAL_PROCESSES_NORMALIZER, B2BUNIT_NODE_LIST_NORMALIZER, B2BUNIT_NODE_NORMALIZER, B2BUNIT_NORMALIZER, B2BUNIT_SERIALIZER, b2bUser_action_d as B2BUserActions, B2BUserAdapter, B2BUserConnector, b2bUser_selector_d as B2BUserSelectors, B2BUserService, B2B_USERS_NORMALIZER, B2B_USER_APPROVERS, B2B_USER_ENTITIES, B2B_USER_FEATURE, B2B_USER_NORMALIZER, B2B_USER_PERMISSIONS, B2B_USER_SERIALIZER, B2B_USER_USER_GROUPS, BUDGETS_NORMALIZER, BUDGET_ENTITIES, BUDGET_FEATURE, BUDGET_LIST, BUDGET_NORMALIZER, BUDGET_SERIALIZER, budget_action_d as BudgetActions, BudgetAdapter, BudgetConnector, budget_selector_d as BudgetSelectors, BudgetService, COST_CENTER_ASSIGNED_BUDGETS, COST_CENTER_ENTITIES, COST_CENTER_FEATURE, COST_CENTER_LIST, costCenter_action_d as CostCenterActions, CostCenterAdapter, CostCenterConnector, costCenter_selector_d as CostCenterSelectors, CostCenterService, LoadStatus, ORGANIZATION_FEATURE, ORG_UNIT_APPROVAL_PROCESSES, ORG_UNIT_APPROVAL_PROCESSES_ENTITIES, ORG_UNIT_ASSIGNED_USERS, ORG_UNIT_ENTITIES, ORG_UNIT_FEATURE, ORG_UNIT_NODES, ORG_UNIT_NODE_ENTITIES, ORG_UNIT_NODE_LIST, ORG_UNIT_TREE, ORG_UNIT_TREE_ENTITY, orgUnit_action_d as OrgUnitActions, OrgUnitAdapter, OrgUnitConnector, OrgUnitGuard, orgUnit_selector_d as OrgUnitSelectors, OrgUnitService, organization_action_d as OrganizationActions, OrganizationBadRequestHandler, OrganizationConflictHandler, OrganizationPageMetaModule, OrganizationPageMetaResolver, OrganizationsGuardsModule, PERMISSIONS_NORMALIZER, PERMISSION_ENTITIES, PERMISSION_FEATURE, PERMISSION_LIST, PERMISSION_NORMALIZER, PERMISSION_SERIALIZER, PERMISSION_TYPES, PERMISSION_TYPES_LIST, PERMISSION_TYPES_NORMALIZER, PERMISSION_TYPE_NORMALIZER, Period, permission_action_d as PermissionActions, PermissionAdapter, PermissionConnector, permission_selector_d as PermissionSelectors, PermissionService, USER_GROUPS_NORMALIZER, USER_GROUP_AVAILABLE_CUSTOMERS, USER_GROUP_ENTITIES, USER_GROUP_FEATURE, USER_GROUP_LIST, USER_GROUP_NORMALIZER, USER_GROUP_PERMISSIONS, USER_GROUP_SERIALIZER, USER_LIST, userGroup_action_d as UserGroupActions, UserGroupAdapter, UserGroupConnector, userGroup_selector_d as UserGroupSelectors, UserGroupService, UserGuard };
export type { B2BUnitNode, B2BUnitTreeNode, B2BUserManagement, Budget, BudgetManagement, CostCenterManagement, Management, OrgUnits, OrganizationItemStatus, OrganizationState, Permission, PermissionManagement, StateWithOrganization, UserGroup, UserGroupManagement };
