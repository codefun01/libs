import * as i0 from '@angular/core';
import { OnDestroy, Renderer2, ElementRef, EventEmitter, OnInit } from '@angular/core';
import * as i6 from '@spartacus/core';
import { RoutingService, TranslationService, PaymentDetails, CostCenter, Address, B2BUser } from '@spartacus/core';
import { OrderHistoryList, Order } from '@spartacus/order/root';
import { OrderHistoryQueryParams } from '@spartacus/organization/unit-order/core';
import { UnitOrderFacade } from '@spartacus/organization/unit-order/root';
import { Observable } from 'rxjs';
import * as i1 from '@angular/common';
import * as i2$1 from '@angular/router';
import * as i2 from '@angular/forms';
import { FormGroup } from '@angular/forms';
import * as i4 from '@ng-select/ng-select';
import * as i5 from '@spartacus/storefront';
import { ICON_TYPE, Card } from '@spartacus/storefront';
import { DeliveryMode, GetOrderEntriesContext, OrderEntriesSource, OrderEntry } from '@spartacus/cart/base/root';

declare class UnitLevelOrderHistoryComponent implements OnDestroy {
    protected routing: RoutingService;
    protected unitOrdersFacade: UnitOrderFacade;
    protected translation: TranslationService;
    private PAGE_SIZE;
    sortType: string;
    queryParams: OrderHistoryQueryParams;
    constructor(routing: RoutingService, unitOrdersFacade: UnitOrderFacade, translation: TranslationService);
    orders$: Observable<OrderHistoryList | undefined>;
    isLoaded$: Observable<boolean>;
    ngOnDestroy(): void;
    filterChange(newFilters: OrderHistoryQueryParams): void;
    private updateQueryParams;
    changeSortCode(sortCode: string): void;
    pageChange(page: number): void;
    goToOrderDetail(order: Order): void;
    getSortLabels(): Observable<{
        byDate: string;
        byOrderNumber: string;
    }>;
    private fetchOrders;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitLevelOrderHistoryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitLevelOrderHistoryComponent, "cx-unit-level-order-history", never, {}, {}, never, never, true, never>;
}

declare class UnitLevelOrderHistoryFilterComponent {
    protected renderer: Renderer2;
    iconTypes: typeof ICON_TYPE;
    encodedFilter: string;
    filterForm: FormGroup;
    filterFormMobile: FormGroup;
    filterByBuyer: string;
    filterByUnit: string;
    filterNav: ElementRef;
    filterNavUnit: ElementRef;
    filterNavBuyer: ElementRef;
    buyerFilterMobileId: ElementRef;
    unitFilterMobileId: ElementRef;
    filterListEvent: EventEmitter<OrderHistoryQueryParams>;
    unitFilterMobileValue: string | null;
    buyerFilterMobileValue: string | null;
    constructor(renderer: Renderer2);
    searchUnitLevelOrders(): void;
    emitFilterEvent(buyer: string, unit: string): void;
    clearAll(): void;
    launchMobileFilters(): void;
    searchUnitLevelOrdersForMobile(): void;
    getFormValuesForMobileAndEmitFilterEvent(): void;
    closeFilterNav(): void;
    backFilterSubNav(): void;
    launchSubNav(option: string): void;
    clearUnit(): void;
    clearBuyer(): void;
    clearUnitMobile(): void;
    clearBuyerMobile(): void;
    searchBuyer(inputElement: HTMLInputElement): void;
    searchUnit(inputElement: HTMLInputElement): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitLevelOrderHistoryFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitLevelOrderHistoryFilterComponent, "cx-unit-level-order-history-filter", never, {}, { "filterListEvent": "filterListEvent"; }, never, never, true, never>;
}

declare class UnitLevelOrderHistoryFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitLevelOrderHistoryFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitLevelOrderHistoryFilterModule, never, [typeof i1.CommonModule, typeof i2.ReactiveFormsModule, typeof i6.I18nModule, typeof i5.IconModule, typeof UnitLevelOrderHistoryFilterComponent], [typeof UnitLevelOrderHistoryFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitLevelOrderHistoryFilterModule>;
}

declare class UnitLevelOrderHistoryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitLevelOrderHistoryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitLevelOrderHistoryModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof i2.ReactiveFormsModule, typeof i4.NgSelectModule, typeof i5.ListNavigationModule, typeof i6.UrlModule, typeof i6.I18nModule, typeof UnitLevelOrderHistoryFilterModule, typeof i5.BtnLikeLinkModule, typeof i6.FeaturesConfigModule, typeof UnitLevelOrderHistoryComponent], [typeof UnitLevelOrderHistoryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitLevelOrderHistoryModule>;
}

declare class UnitLevelOrderDetailService {
    private unitOrderFacade;
    private routingService;
    orderCode$: Observable<string>;
    orderLoad$: Observable<string>;
    constructor(unitOrderFacade: UnitOrderFacade, routingService: RoutingService);
    getOrderDetails(): Observable<Order>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitLevelOrderDetailService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitLevelOrderDetailService>;
}

declare class UnitLevelOrderOverviewComponent implements OnInit {
    protected translation: TranslationService;
    protected unitLevelOrderDetailsService: UnitLevelOrderDetailService;
    constructor(translation: TranslationService, unitLevelOrderDetailsService: UnitLevelOrderDetailService);
    order$: Observable<Order>;
    ngOnInit(): void;
    getOrderCodeCardContent(orderCode: string | undefined): Observable<Card>;
    getOrderCurrentDateCardContent(isoDate: string | null): Observable<Card>;
    getOrderStatusCardContent(status: string | undefined): Observable<Card>;
    getPurchaseOrderNumber(poNumber: string | undefined): Observable<Card>;
    getMethodOfPaymentCardContent(hasPaymentInfo: PaymentDetails | undefined): Observable<Card>;
    getCostCenterCardContent(costCenter: CostCenter | undefined): Observable<Card>;
    getAddressCardContent(deliveryAddress: Address | undefined): Observable<Card>;
    getDeliveryModeCardContent(deliveryMode: DeliveryMode | undefined): Observable<Card>;
    getPaymentInfoCardContent(payment: PaymentDetails | undefined): Observable<Card>;
    getBillingAddressCardContent(billingAddress: Address | undefined): Observable<Card>;
    getBuyerNameCardContent(customer: B2BUser | undefined): Observable<Card>;
    getUnitNameCardContent(orgUnit: string | undefined): Observable<Card>;
    private normalizeFormattedAddress;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitLevelOrderOverviewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitLevelOrderOverviewComponent, "cx-unit-level-order-overview", never, {}, {}, never, never, true, never>;
}

declare class UnitLevelOrderOverviewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitLevelOrderOverviewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitLevelOrderOverviewModule, never, [typeof i1.CommonModule, typeof i6.I18nModule, typeof i5.CardModule, typeof UnitLevelOrderOverviewComponent], [typeof UnitLevelOrderOverviewComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitLevelOrderOverviewModule>;
}

declare class UnitLevelOrderDetailModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitLevelOrderDetailModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitLevelOrderDetailModule, never, [typeof i1.CommonModule, typeof UnitLevelOrderOverviewModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitLevelOrderDetailModule>;
}

declare class UnitOrderDetailsOrderEntriesContext implements GetOrderEntriesContext {
    protected unitLevelOrderDetailService: UnitLevelOrderDetailService;
    readonly type = OrderEntriesSource.UNIT_ORDER_DETAILS;
    constructor(unitLevelOrderDetailService: UnitLevelOrderDetailService);
    getEntries(): Observable<OrderEntry[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitOrderDetailsOrderEntriesContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitOrderDetailsOrderEntriesContext>;
}

declare class UnitOrderComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitOrderComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitOrderComponentsModule, never, [typeof i2$1.RouterModule, typeof UnitLevelOrderHistoryModule, typeof UnitLevelOrderDetailModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitOrderComponentsModule>;
}

export { UnitLevelOrderDetailModule, UnitLevelOrderDetailService, UnitLevelOrderHistoryComponent, UnitLevelOrderHistoryModule, UnitOrderComponentsModule, UnitOrderDetailsOrderEntriesContext };
