import * as i0 from '@angular/core';
import { ModuleWithProviders, InjectionToken } from '@angular/core';
import { Converter, HttpErrorHandler, HttpResponseStatus, ErrorModel, Priority } from '@spartacus/core';
import { OrganizationUserRegistration } from '@spartacus/organization/user-registration/root';
import { Observable } from 'rxjs';
import { HttpRequest, HttpErrorResponse } from '@angular/common/http';

declare class UserRegistrationCoreModule {
    static forRoot(): ModuleWithProviders<UserRegistrationCoreModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserRegistrationCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserRegistrationCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserRegistrationCoreModule>;
}

declare const ORGANIZATION_USER_REGISTRATION_SERIALIZER: InjectionToken<Converter<OrganizationUserRegistration, any>>;

declare abstract class UserRegistrationAdapter {
    /**
     *
     * Abstract method used to register B2B user
     */
    abstract registerUser(userData: OrganizationUserRegistration): Observable<OrganizationUserRegistration>;
}

declare class UserRegistrationConnector {
    protected adapter: UserRegistrationAdapter;
    constructor(adapter: UserRegistrationAdapter);
    registerUser(userData: OrganizationUserRegistration): Observable<OrganizationUserRegistration>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserRegistrationConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserRegistrationConnector>;
}

declare class OrganizationUserRegistrationConflictHandler extends HttpErrorHandler {
    responseStatus: HttpResponseStatus;
    handleError(request: HttpRequest<any>, response: HttpErrorResponse): void;
    protected getErrors(response: HttpErrorResponse): ErrorModel[];
    getPriority(): Priority;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrganizationUserRegistrationConflictHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrganizationUserRegistrationConflictHandler>;
}

export { ORGANIZATION_USER_REGISTRATION_SERIALIZER, OrganizationUserRegistrationConflictHandler, UserRegistrationAdapter, UserRegistrationConnector, UserRegistrationCoreModule };
