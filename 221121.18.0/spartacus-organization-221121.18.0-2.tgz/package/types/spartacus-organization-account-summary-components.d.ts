import * as i0 from '@angular/core';
import { OnInit, OnDestroy, EventEmitter } from '@angular/core';
import * as i3 from '@spartacus/core';
import { LanguageService, TranslationService, Address, CmsConfig, SortModel, RoutingService, B2BUnit } from '@spartacus/core';
import * as i2 from '@spartacus/organization/administration/components';
import { UnitListComponent, UnitListService } from '@spartacus/organization/administration/components';
import * as i4 from '@spartacus/storefront';
import { Card, FileDownloadService, ICON_TYPE, TableConfig } from '@spartacus/storefront';
import * as i2$1 from '@angular/common';
import { AccountSummaryFacade, AccountSummaryDetails, AccountSummaryDocumentType, DocumentQueryParams, FilterByOptions, AccountSummaryList } from '@spartacus/organization/account-summary/root';
import { Observable, Subscription, BehaviorSubject } from 'rxjs';
import * as i3$1 from '@ng-select/ng-select';
import * as i5 from '@angular/forms';
import { FormBuilder, FormGroup } from '@angular/forms';

declare class AccountSummaryListComponent extends UnitListComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccountSummaryListComponent, "cx-account-summary-list", never, {}, {}, never, never, true, never>;
}

declare class AccountSummaryListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AccountSummaryListModule, never, [typeof i3.I18nModule, typeof i2.ListModule, typeof AccountSummaryListComponent], [typeof AccountSummaryListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AccountSummaryListModule>;
}

declare class AccountSummaryHeaderComponent implements OnInit, OnDestroy {
    protected accountSummaryFacade: AccountSummaryFacade;
    protected languageService: LanguageService;
    protected translation: TranslationService;
    notApplicable: string;
    headerDetails$: Observable<AccountSummaryDetails>;
    protected subscriptions: Subscription;
    constructor(accountSummaryFacade: AccountSummaryFacade, languageService: LanguageService, translation: TranslationService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    getIdCardContent(id?: string): Observable<Card>;
    getNameCardContent(name?: string): Observable<Card>;
    getAddressCardContent(billingAddress?: Address): Observable<Card>;
    getCreditRepCardContent(creditRep?: string): Observable<Card>;
    getCreditLineCardContent(creditLine?: string): Observable<Card>;
    getCurrentBalanceCardContent(currentBalance?: string): Observable<Card>;
    getOpenBalanceCardContent(openBalance?: string): Observable<Card>;
    getPastDueBalanceCardContent(pastDueBalance?: string): Observable<Card>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccountSummaryHeaderComponent, "cx-account-summary-header", never, {}, {}, never, never, true, never>;
}

declare const accountSummaryHeaderCmsConfig: CmsConfig;
declare class AccountSummaryHeaderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryHeaderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AccountSummaryHeaderModule, never, [typeof i4.CardModule, typeof i2$1.CommonModule, typeof i3.I18nModule, typeof AccountSummaryHeaderComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AccountSummaryHeaderModule>;
}

interface ItemType {
    code: string;
    name?: string;
}
declare class AccountSummaryDocumentFilterComponent implements OnInit, OnDestroy {
    protected translation: TranslationService;
    protected fb: FormBuilder;
    cxNgSelectA11yAriaControls?: string;
    documentTypeOptions: Array<AccountSummaryDocumentType>;
    set initialFilters(initialFilters: DocumentQueryParams);
    filterListEvent: EventEmitter<DocumentQueryParams>;
    FilterByOptions: typeof FilterByOptions;
    filterForm: FormGroup;
    private subscription;
    statusOptions: ItemType[];
    filterByOptions: ItemType[];
    constructor(translation: TranslationService, fb: FormBuilder);
    ngOnInit(): void;
    ngOnDestroy(): void;
    formSearch(): void;
    resetForm(andSearch?: boolean): void;
    protected getStatusOptions(): Observable<ItemType[]>;
    protected getFilterByOptions(): Observable<ItemType[]>;
    private initializeForm;
    private filterByChanged;
    private encodeDate;
    private decodeDate;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryDocumentFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccountSummaryDocumentFilterComponent, "cx-account-summary-document-filter", never, { "cxNgSelectA11yAriaControls": { "alias": "cxNgSelectA11yAriaControls"; "required": false; }; "documentTypeOptions": { "alias": "documentTypeOptions"; "required": false; }; "initialFilters": { "alias": "initialFilters"; "required": false; }; }, { "filterListEvent": "filterListEvent"; }, never, never, true, never>;
}

declare class AccountSummaryDocumentFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryDocumentFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AccountSummaryDocumentFilterModule, never, [typeof i2$1.CommonModule, typeof i3.I18nModule, typeof i3$1.NgSelectModule, typeof i4.NgSelectA11yModule, typeof i5.ReactiveFormsModule, typeof i4.DatePickerModule, typeof i4.FormErrorsModule, typeof i3.FeaturesConfigModule, typeof AccountSummaryDocumentFilterComponent], [typeof AccountSummaryDocumentFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AccountSummaryDocumentFilterModule>;
}

declare class AccountSummaryDocumentComponent implements OnInit, OnDestroy {
    protected accountSummaryFacade: AccountSummaryFacade;
    protected translation: TranslationService;
    protected downloadService: FileDownloadService;
    protected languageService: LanguageService;
    ICON_TYPE: typeof ICON_TYPE;
    documentTypeOptions: AccountSummaryDocumentType[];
    sortOptions: SortModel[];
    _queryParams: DocumentQueryParams;
    queryParams$: BehaviorSubject<DocumentQueryParams>;
    accountSummary$: Observable<AccountSummaryList>;
    private subscription;
    constructor(accountSummaryFacade: AccountSummaryFacade, translation: TranslationService, downloadService: FileDownloadService, languageService: LanguageService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    pageChange(page: number): void;
    changeSortCode(sortCode: string): void;
    filterChange(newFilters: DocumentQueryParams): void;
    downloadAttachment(documentId?: string, attachmentId?: string): void;
    private updateQueryParams;
    private addNamesToSortModel;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryDocumentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AccountSummaryDocumentComponent, "cx-account-summary-document", never, {}, {}, never, never, true, never>;
}

declare const accountSummaryDocumentCmsConfig: CmsConfig;
declare class AccountSummaryDocumentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryDocumentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AccountSummaryDocumentModule, never, [typeof AccountSummaryDocumentFilterModule, typeof i2$1.CommonModule, typeof i3.I18nModule, typeof i4.SortingModule, typeof i4.PaginationModule, typeof i4.IconModule, typeof i3.FeaturesConfigModule, typeof AccountSummaryDocumentComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AccountSummaryDocumentModule>;
}

declare class AccountSummaryComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AccountSummaryComponentsModule, never, [typeof AccountSummaryListModule, typeof AccountSummaryHeaderModule, typeof AccountSummaryDocumentModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AccountSummaryComponentsModule>;
}

declare const ACCOUNT_SUMMARY_DETAILS_TRANSLATION_KEY = "orgAccountSummaryList.breadcrumbs.details";
declare function accountSummaryUnitsTableConfigFactory(): TableConfig;
declare const accountSummaryListCmsConfig: CmsConfig;

declare module '@spartacus/organization/administration/components' {
    enum OrganizationTableType {
        ACCOUNT_SUMMARY_UNIT = "orgAccountSummary"
    }
}

declare class AccountSummaryItemService {
    protected routingService: RoutingService;
    constructor(routingService: RoutingService);
    launchDetails(item: B2BUnit): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryItemService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AccountSummaryItemService>;
}

declare class AccountSummaryUnitListService extends UnitListService {
    protected tableType: any;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountSummaryUnitListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AccountSummaryUnitListService>;
}

export { ACCOUNT_SUMMARY_DETAILS_TRANSLATION_KEY, AccountSummaryComponentsModule, AccountSummaryDocumentComponent, AccountSummaryDocumentFilterComponent, AccountSummaryDocumentFilterModule, AccountSummaryDocumentModule, AccountSummaryHeaderComponent, AccountSummaryHeaderModule, AccountSummaryItemService, AccountSummaryListComponent, AccountSummaryListModule, AccountSummaryUnitListService, accountSummaryDocumentCmsConfig, accountSummaryHeaderCmsConfig, accountSummaryListCmsConfig, accountSummaryUnitsTableConfigFactory };
