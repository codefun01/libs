import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    accountSummary: {
        orgAccountSummary: {
            groupName: string;
            header: string;
            name: string;
            details: {
                header: string;
                uid: string;
                name: string;
                address: string;
                creditRep: string;
                creditLine: string;
                currentBalance: string;
                openBalance: string;
                pastDueBalance: string;
                dayRange: string;
                dayPlus: string;
                notApplicable: string;
            };
            document: {
                header: string;
                id: string;
                type: string;
                date: string;
                dueDate: string;
                originalAmount: string;
                openAmount: string;
                status: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            sorts: {
                byCreatedAtDateAsc: string;
                byCreatedAtDateDesc: string;
                byDueAtDateAsc: string;
                byDueAtDateDesc: string;
                byOriginalAmountAsc: string;
                byOriginalAmountDesc: string;
                byOpenAmountAsc: string;
                byOpenAmountDesc: string;
                byOrgDocumentTypeAsc: string;
                byOrgDocumentTypeDesc: string;
                byStatusAsc: string;
                byStatusDesc: string;
                byOrgDocumentIdAsc: string;
                byOrgDocumentIdDesc: string;
            };
            statuses: {
                open: string;
                closed: string;
                all: string;
            };
            filterByOptions: {
                orgDocumentId: string;
                orgDocumentIdRange: string;
                orgDocumentType: string;
                createdAtDateRange: string;
                dueAtDateRange: string;
                amountRange: string;
                openAmountRange: string;
            };
            sortBy: string;
            sortDocuments: string;
            filter: {
                status: string;
                filterBy: string;
                documentNumber: string;
                documentType: string;
                startRange: string;
                endRange: string;
                clear: string;
                search: string;
                errors: {
                    toDateMustComeAfterFrom: string;
                    toAmountMustBeLargeThanFrom: string;
                };
            };
            hint: string;
        };
        orgAccountSummaryList: {
            breadcrumbs: {
                list: string;
                details: string;
            };
        };
    };
};

declare const de: {
    accountSummary: {
        orgAccountSummary: {
            groupName: string;
            header: string;
            name: string;
            details: {
                header: string;
                uid: string;
                name: string;
                address: string;
                creditRep: string;
                creditLine: string;
                currentBalance: string;
                openBalance: string;
                pastDueBalance: string;
                dayRange: string;
                dayPlus: string;
                notApplicable: string;
            };
            document: {
                header: string;
                id: string;
                type: string;
                date: string;
                dueDate: string;
                originalAmount: string;
                openAmount: string;
                status: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            sorts: {
                byCreatedAtDateAsc: string;
                byCreatedAtDateDesc: string;
                byDueAtDateAsc: string;
                byDueAtDateDesc: string;
                byOriginalAmountAsc: string;
                byOriginalAmountDesc: string;
                byOpenAmountAsc: string;
                byOpenAmountDesc: string;
                byOrgDocumentTypeAsc: string;
                byOrgDocumentTypeDesc: string;
                byStatusAsc: string;
                byStatusDesc: string;
                byOrgDocumentIdAsc: string;
                byOrgDocumentIdDesc: string;
            };
            statuses: {
                open: string;
                closed: string;
                all: string;
            };
            filterByOptions: {
                orgDocumentId: string;
                orgDocumentIdRange: string;
                orgDocumentType: string;
                createdAtDateRange: string;
                dueAtDateRange: string;
                amountRange: string;
                openAmountRange: string;
            };
            sortBy: string;
            sortDocuments: string;
            filter: {
                status: string;
                filterBy: string;
                documentNumber: string;
                documentType: string;
                startRange: string;
                endRange: string;
                clear: string;
                search: string;
                errors: {
                    toDateMustComeAfterFrom: string;
                    toAmountMustBeLargeThanFrom: string;
                };
            };
            hint: string;
        };
        orgAccountSummaryList: {
            breadcrumbs: {
                list: string;
                details: string;
            };
        };
    };
};

declare const en: {
    accountSummary: {
        orgAccountSummary: {
            groupName: string;
            header: string;
            name: string;
            details: {
                header: string;
                uid: string;
                name: string;
                address: string;
                creditRep: string;
                creditLine: string;
                currentBalance: string;
                openBalance: string;
                pastDueBalance: string;
                dayRange: string;
                dayPlus: string;
                notApplicable: string;
            };
            document: {
                header: string;
                id: string;
                type: string;
                date: string;
                dueDate: string;
                originalAmount: string;
                openAmount: string;
                status: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            sorts: {
                byCreatedAtDateAsc: string;
                byCreatedAtDateDesc: string;
                byDueAtDateAsc: string;
                byDueAtDateDesc: string;
                byOriginalAmountAsc: string;
                byOriginalAmountDesc: string;
                byOpenAmountAsc: string;
                byOpenAmountDesc: string;
                byOrgDocumentTypeAsc: string;
                byOrgDocumentTypeDesc: string;
                byStatusAsc: string;
                byStatusDesc: string;
                byOrgDocumentIdAsc: string;
                byOrgDocumentIdDesc: string;
            };
            statuses: {
                open: string;
                closed: string;
                all: string;
            };
            filterByOptions: {
                orgDocumentId: string;
                orgDocumentIdRange: string;
                orgDocumentType: string;
                createdAtDateRange: string;
                dueAtDateRange: string;
                amountRange: string;
                openAmountRange: string;
            };
            sortBy: string;
            sortDocuments: string;
            filter: {
                status: string;
                filterBy: string;
                documentNumber: string;
                documentType: string;
                startRange: string;
                endRange: string;
                clear: string;
                search: string;
                errors: {
                    toDateMustComeAfterFrom: string;
                    toAmountMustBeLargeThanFrom: string;
                };
            };
            hint: string;
        };
        orgAccountSummaryList: {
            breadcrumbs: {
                list: string;
                details: string;
            };
        };
    };
};

declare const es: {
    accountSummary: {
        orgAccountSummary: {
            groupName: string;
            header: string;
            name: string;
            details: {
                header: string;
                uid: string;
                name: string;
                address: string;
                creditRep: string;
                creditLine: string;
                currentBalance: string;
                openBalance: string;
                pastDueBalance: string;
                dayRange: string;
                dayPlus: string;
                notApplicable: string;
            };
            document: {
                header: string;
                id: string;
                type: string;
                date: string;
                dueDate: string;
                originalAmount: string;
                openAmount: string;
                status: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            sorts: {
                byCreatedAtDateAsc: string;
                byCreatedAtDateDesc: string;
                byDueAtDateAsc: string;
                byDueAtDateDesc: string;
                byOriginalAmountAsc: string;
                byOriginalAmountDesc: string;
                byOpenAmountAsc: string;
                byOpenAmountDesc: string;
                byOrgDocumentTypeAsc: string;
                byOrgDocumentTypeDesc: string;
                byStatusAsc: string;
                byStatusDesc: string;
                byOrgDocumentIdAsc: string;
                byOrgDocumentIdDesc: string;
            };
            statuses: {
                open: string;
                closed: string;
                all: string;
            };
            filterByOptions: {
                orgDocumentId: string;
                orgDocumentIdRange: string;
                orgDocumentType: string;
                createdAtDateRange: string;
                dueAtDateRange: string;
                amountRange: string;
                openAmountRange: string;
            };
            sortBy: string;
            sortDocuments: string;
            filter: {
                status: string;
                filterBy: string;
                documentNumber: string;
                documentType: string;
                startRange: string;
                endRange: string;
                clear: string;
                search: string;
                errors: {
                    toDateMustComeAfterFrom: string;
                    toAmountMustBeLargeThanFrom: string;
                };
            };
            hint: string;
        };
        orgAccountSummaryList: {
            breadcrumbs: {
                list: string;
                details: string;
            };
        };
    };
};

declare const es_CO: {
    accountSummary: {
        orgAccountSummary: {
            groupName: string;
            header: string;
            name: string;
            details: {
                header: string;
                uid: string;
                name: string;
                address: string;
                creditRep: string;
                creditLine: string;
                currentBalance: string;
                openBalance: string;
                pastDueBalance: string;
                dayRange: string;
                dayPlus: string;
                notApplicable: string;
            };
            document: {
                header: string;
                id: string;
                type: string;
                date: string;
                dueDate: string;
                originalAmount: string;
                openAmount: string;
                status: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            sorts: {
                byCreatedAtDateAsc: string;
                byCreatedAtDateDesc: string;
                byDueAtDateAsc: string;
                byDueAtDateDesc: string;
                byOriginalAmountAsc: string;
                byOriginalAmountDesc: string;
                byOpenAmountAsc: string;
                byOpenAmountDesc: string;
                byOrgDocumentTypeAsc: string;
                byOrgDocumentTypeDesc: string;
                byStatusAsc: string;
                byStatusDesc: string;
                byOrgDocumentIdAsc: string;
                byOrgDocumentIdDesc: string;
            };
            statuses: {
                open: string;
                closed: string;
                all: string;
            };
            filterByOptions: {
                orgDocumentId: string;
                orgDocumentIdRange: string;
                orgDocumentType: string;
                createdAtDateRange: string;
                dueAtDateRange: string;
                amountRange: string;
                openAmountRange: string;
            };
            sortBy: string;
            sortDocuments: string;
            filter: {
                status: string;
                filterBy: string;
                documentNumber: string;
                documentType: string;
                startRange: string;
                endRange: string;
                clear: string;
                search: string;
                errors: {
                    toDateMustComeAfterFrom: string;
                    toAmountMustBeLargeThanFrom: string;
                };
            };
            hint: string;
        };
        orgAccountSummaryList: {
            breadcrumbs: {
                list: string;
                details: string;
            };
        };
    };
};

declare const fr: {
    accountSummary: {
        orgAccountSummary: {
            groupName: string;
            header: string;
            name: string;
            details: {
                header: string;
                uid: string;
                name: string;
                address: string;
                creditRep: string;
                creditLine: string;
                currentBalance: string;
                openBalance: string;
                pastDueBalance: string;
                dayRange: string;
                dayPlus: string;
                notApplicable: string;
            };
            document: {
                header: string;
                id: string;
                type: string;
                date: string;
                dueDate: string;
                originalAmount: string;
                openAmount: string;
                status: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            sorts: {
                byCreatedAtDateAsc: string;
                byCreatedAtDateDesc: string;
                byDueAtDateAsc: string;
                byDueAtDateDesc: string;
                byOriginalAmountAsc: string;
                byOriginalAmountDesc: string;
                byOpenAmountAsc: string;
                byOpenAmountDesc: string;
                byOrgDocumentTypeAsc: string;
                byOrgDocumentTypeDesc: string;
                byStatusAsc: string;
                byStatusDesc: string;
                byOrgDocumentIdAsc: string;
                byOrgDocumentIdDesc: string;
            };
            statuses: {
                open: string;
                closed: string;
                all: string;
            };
            filterByOptions: {
                orgDocumentId: string;
                orgDocumentIdRange: string;
                orgDocumentType: string;
                createdAtDateRange: string;
                dueAtDateRange: string;
                amountRange: string;
                openAmountRange: string;
            };
            sortBy: string;
            sortDocuments: string;
            filter: {
                status: string;
                filterBy: string;
                documentNumber: string;
                documentType: string;
                startRange: string;
                endRange: string;
                clear: string;
                search: string;
                errors: {
                    toDateMustComeAfterFrom: string;
                    toAmountMustBeLargeThanFrom: string;
                };
            };
            hint: string;
        };
        orgAccountSummaryList: {
            breadcrumbs: {
                list: string;
                details: string;
            };
        };
    };
};

declare const hi: {
    accountSummary: {
        orgAccountSummary: {
            groupName: string;
            header: string;
            name: string;
            details: {
                header: string;
                uid: string;
                name: string;
                address: string;
                creditRep: string;
                creditLine: string;
                currentBalance: string;
                openBalance: string;
                pastDueBalance: string;
                dayRange: string;
                dayPlus: string;
                notApplicable: string;
            };
            document: {
                header: string;
                id: string;
                type: string;
                date: string;
                dueDate: string;
                originalAmount: string;
                openAmount: string;
                status: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            sorts: {
                byCreatedAtDateAsc: string;
                byCreatedAtDateDesc: string;
                byDueAtDateAsc: string;
                byDueAtDateDesc: string;
                byOriginalAmountAsc: string;
                byOriginalAmountDesc: string;
                byOpenAmountAsc: string;
                byOpenAmountDesc: string;
                byOrgDocumentTypeAsc: string;
                byOrgDocumentTypeDesc: string;
                byStatusAsc: string;
                byStatusDesc: string;
                byOrgDocumentIdAsc: string;
                byOrgDocumentIdDesc: string;
            };
            statuses: {
                open: string;
                closed: string;
                all: string;
            };
            filterByOptions: {
                orgDocumentId: string;
                orgDocumentIdRange: string;
                orgDocumentType: string;
                createdAtDateRange: string;
                dueAtDateRange: string;
                amountRange: string;
                openAmountRange: string;
            };
            sortBy: string;
            sortDocuments: string;
            filter: {
                status: string;
                filterBy: string;
                documentNumber: string;
                documentType: string;
                startRange: string;
                endRange: string;
                clear: string;
                search: string;
                errors: {
                    toDateMustComeAfterFrom: string;
                    toAmountMustBeLargeThanFrom: string;
                };
            };
            hint: string;
        };
        orgAccountSummaryList: {
            breadcrumbs: {
                list: string;
                details: string;
            };
        };
    };
};

declare const hu: {
    accountSummary: {
        orgAccountSummary: {
            groupName: string;
            header: string;
            name: string;
            details: {
                header: string;
                uid: string;
                name: string;
                address: string;
                creditRep: string;
                creditLine: string;
                currentBalance: string;
                openBalance: string;
                pastDueBalance: string;
                dayRange: string;
                dayPlus: string;
                notApplicable: string;
            };
            document: {
                header: string;
                id: string;
                type: string;
                date: string;
                dueDate: string;
                originalAmount: string;
                openAmount: string;
                status: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            sorts: {
                byCreatedAtDateAsc: string;
                byCreatedAtDateDesc: string;
                byDueAtDateAsc: string;
                byDueAtDateDesc: string;
                byOriginalAmountAsc: string;
                byOriginalAmountDesc: string;
                byOpenAmountAsc: string;
                byOpenAmountDesc: string;
                byOrgDocumentTypeAsc: string;
                byOrgDocumentTypeDesc: string;
                byStatusAsc: string;
                byStatusDesc: string;
                byOrgDocumentIdAsc: string;
                byOrgDocumentIdDesc: string;
            };
            statuses: {
                open: string;
                closed: string;
                all: string;
            };
            filterByOptions: {
                orgDocumentId: string;
                orgDocumentIdRange: string;
                orgDocumentType: string;
                createdAtDateRange: string;
                dueAtDateRange: string;
                amountRange: string;
                openAmountRange: string;
            };
            sortBy: string;
            sortDocuments: string;
            filter: {
                status: string;
                filterBy: string;
                documentNumber: string;
                documentType: string;
                startRange: string;
                endRange: string;
                clear: string;
                search: string;
                errors: {
                    toDateMustComeAfterFrom: string;
                    toAmountMustBeLargeThanFrom: string;
                };
            };
            hint: string;
        };
        orgAccountSummaryList: {
            breadcrumbs: {
                list: string;
                details: string;
            };
        };
    };
};

declare const id: {
    accountSummary: {
        orgAccountSummary: {
            groupName: string;
            header: string;
            name: string;
            details: {
                header: string;
                uid: string;
                name: string;
                address: string;
                creditRep: string;
                creditLine: string;
                currentBalance: string;
                openBalance: string;
                pastDueBalance: string;
                dayRange: string;
                dayPlus: string;
                notApplicable: string;
            };
            document: {
                header: string;
                id: string;
                type: string;
                date: string;
                dueDate: string;
                originalAmount: string;
                openAmount: string;
                status: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            sorts: {
                byCreatedAtDateAsc: string;
                byCreatedAtDateDesc: string;
                byDueAtDateAsc: string;
                byDueAtDateDesc: string;
                byOriginalAmountAsc: string;
                byOriginalAmountDesc: string;
                byOpenAmountAsc: string;
                byOpenAmountDesc: string;
                byOrgDocumentTypeAsc: string;
                byOrgDocumentTypeDesc: string;
                byStatusAsc: string;
                byStatusDesc: string;
                byOrgDocumentIdAsc: string;
                byOrgDocumentIdDesc: string;
            };
            statuses: {
                open: string;
                closed: string;
                all: string;
            };
            filterByOptions: {
                orgDocumentId: string;
                orgDocumentIdRange: string;
                orgDocumentType: string;
                createdAtDateRange: string;
                dueAtDateRange: string;
                amountRange: string;
                openAmountRange: string;
            };
            sortBy: string;
            sortDocuments: string;
            filter: {
                status: string;
                filterBy: string;
                documentNumber: string;
                documentType: string;
                startRange: string;
                endRange: string;
                clear: string;
                search: string;
                errors: {
                    toDateMustComeAfterFrom: string;
                    toAmountMustBeLargeThanFrom: string;
                };
            };
            hint: string;
        };
        orgAccountSummaryList: {
            breadcrumbs: {
                list: string;
                details: string;
            };
        };
    };
};

declare const it: {
    accountSummary: {
        orgAccountSummary: {
            groupName: string;
            header: string;
            name: string;
            details: {
                header: string;
                uid: string;
                name: string;
                address: string;
                creditRep: string;
                creditLine: string;
                currentBalance: string;
                openBalance: string;
                pastDueBalance: string;
                dayRange: string;
                dayPlus: string;
                notApplicable: string;
            };
            document: {
                header: string;
                id: string;
                type: string;
                date: string;
                dueDate: string;
                originalAmount: string;
                openAmount: string;
                status: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            sorts: {
                byCreatedAtDateAsc: string;
                byCreatedAtDateDesc: string;
                byDueAtDateAsc: string;
                byDueAtDateDesc: string;
                byOriginalAmountAsc: string;
                byOriginalAmountDesc: string;
                byOpenAmountAsc: string;
                byOpenAmountDesc: string;
                byOrgDocumentTypeAsc: string;
                byOrgDocumentTypeDesc: string;
                byStatusAsc: string;
                byStatusDesc: string;
                byOrgDocumentIdAsc: string;
                byOrgDocumentIdDesc: string;
            };
            statuses: {
                open: string;
                closed: string;
                all: string;
            };
            filterByOptions: {
                orgDocumentId: string;
                orgDocumentIdRange: string;
                orgDocumentType: string;
                createdAtDateRange: string;
                dueAtDateRange: string;
                amountRange: string;
                openAmountRange: string;
            };
            sortBy: string;
            sortDocuments: string;
            filter: {
                status: string;
                filterBy: string;
                documentNumber: string;
                documentType: string;
                startRange: string;
                endRange: string;
                clear: string;
                search: string;
                errors: {
                    toDateMustComeAfterFrom: string;
                    toAmountMustBeLargeThanFrom: string;
                };
            };
            hint: string;
        };
        orgAccountSummaryList: {
            breadcrumbs: {
                list: string;
                details: string;
            };
        };
    };
};

declare const ja: {
    accountSummary: {
        orgAccountSummary: {
            groupName: string;
            header: string;
            name: string;
            details: {
                header: string;
                uid: string;
                name: string;
                address: string;
                creditRep: string;
                creditLine: string;
                currentBalance: string;
                openBalance: string;
                pastDueBalance: string;
                dayRange: string;
                dayPlus: string;
                notApplicable: string;
            };
            document: {
                header: string;
                id: string;
                type: string;
                date: string;
                dueDate: string;
                originalAmount: string;
                openAmount: string;
                status: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            sorts: {
                byCreatedAtDateAsc: string;
                byCreatedAtDateDesc: string;
                byDueAtDateAsc: string;
                byDueAtDateDesc: string;
                byOriginalAmountAsc: string;
                byOriginalAmountDesc: string;
                byOpenAmountAsc: string;
                byOpenAmountDesc: string;
                byOrgDocumentTypeAsc: string;
                byOrgDocumentTypeDesc: string;
                byStatusAsc: string;
                byStatusDesc: string;
                byOrgDocumentIdAsc: string;
                byOrgDocumentIdDesc: string;
            };
            statuses: {
                open: string;
                closed: string;
                all: string;
            };
            filterByOptions: {
                orgDocumentId: string;
                orgDocumentIdRange: string;
                orgDocumentType: string;
                createdAtDateRange: string;
                dueAtDateRange: string;
                amountRange: string;
                openAmountRange: string;
            };
            sortBy: string;
            sortDocuments: string;
            filter: {
                status: string;
                filterBy: string;
                documentNumber: string;
                documentType: string;
                startRange: string;
                endRange: string;
                clear: string;
                search: string;
                errors: {
                    toDateMustComeAfterFrom: string;
                    toAmountMustBeLargeThanFrom: string;
                };
            };
            hint: string;
        };
        orgAccountSummaryList: {
            breadcrumbs: {
                list: string;
                details: string;
            };
        };
    };
};

declare const ko: {
    accountSummary: {
        orgAccountSummary: {
            groupName: string;
            header: string;
            name: string;
            details: {
                header: string;
                uid: string;
                name: string;
                address: string;
                creditRep: string;
                creditLine: string;
                currentBalance: string;
                openBalance: string;
                pastDueBalance: string;
                dayRange: string;
                dayPlus: string;
                notApplicable: string;
            };
            document: {
                header: string;
                id: string;
                type: string;
                date: string;
                dueDate: string;
                originalAmount: string;
                openAmount: string;
                status: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            sorts: {
                byCreatedAtDateAsc: string;
                byCreatedAtDateDesc: string;
                byDueAtDateAsc: string;
                byDueAtDateDesc: string;
                byOriginalAmountAsc: string;
                byOriginalAmountDesc: string;
                byOpenAmountAsc: string;
                byOpenAmountDesc: string;
                byOrgDocumentTypeAsc: string;
                byOrgDocumentTypeDesc: string;
                byStatusAsc: string;
                byStatusDesc: string;
                byOrgDocumentIdAsc: string;
                byOrgDocumentIdDesc: string;
            };
            statuses: {
                open: string;
                closed: string;
                all: string;
            };
            filterByOptions: {
                orgDocumentId: string;
                orgDocumentIdRange: string;
                orgDocumentType: string;
                createdAtDateRange: string;
                dueAtDateRange: string;
                amountRange: string;
                openAmountRange: string;
            };
            sortBy: string;
            sortDocuments: string;
            filter: {
                status: string;
                filterBy: string;
                documentNumber: string;
                documentType: string;
                startRange: string;
                endRange: string;
                clear: string;
                search: string;
                errors: {
                    toDateMustComeAfterFrom: string;
                    toAmountMustBeLargeThanFrom: string;
                };
            };
            hint: string;
        };
        orgAccountSummaryList: {
            breadcrumbs: {
                list: string;
                details: string;
            };
        };
    };
};

declare const pl: {
    accountSummary: {
        orgAccountSummary: {
            groupName: string;
            header: string;
            name: string;
            details: {
                header: string;
                uid: string;
                name: string;
                address: string;
                creditRep: string;
                creditLine: string;
                currentBalance: string;
                openBalance: string;
                pastDueBalance: string;
                dayRange: string;
                dayPlus: string;
                notApplicable: string;
            };
            document: {
                header: string;
                id: string;
                type: string;
                date: string;
                dueDate: string;
                originalAmount: string;
                openAmount: string;
                status: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            sorts: {
                byCreatedAtDateAsc: string;
                byCreatedAtDateDesc: string;
                byDueAtDateAsc: string;
                byDueAtDateDesc: string;
                byOriginalAmountAsc: string;
                byOriginalAmountDesc: string;
                byOpenAmountAsc: string;
                byOpenAmountDesc: string;
                byOrgDocumentTypeAsc: string;
                byOrgDocumentTypeDesc: string;
                byStatusAsc: string;
                byStatusDesc: string;
                byOrgDocumentIdAsc: string;
                byOrgDocumentIdDesc: string;
            };
            statuses: {
                open: string;
                closed: string;
                all: string;
            };
            filterByOptions: {
                orgDocumentId: string;
                orgDocumentIdRange: string;
                orgDocumentType: string;
                createdAtDateRange: string;
                dueAtDateRange: string;
                amountRange: string;
                openAmountRange: string;
            };
            sortBy: string;
            sortDocuments: string;
            filter: {
                status: string;
                filterBy: string;
                documentNumber: string;
                documentType: string;
                startRange: string;
                endRange: string;
                clear: string;
                search: string;
                errors: {
                    toDateMustComeAfterFrom: string;
                    toAmountMustBeLargeThanFrom: string;
                };
            };
            hint: string;
        };
        orgAccountSummaryList: {
            breadcrumbs: {
                list: string;
                details: string;
            };
        };
    };
};

declare const pt: {
    accountSummary: {
        orgAccountSummary: {
            groupName: string;
            header: string;
            name: string;
            details: {
                header: string;
                uid: string;
                name: string;
                address: string;
                creditRep: string;
                creditLine: string;
                currentBalance: string;
                openBalance: string;
                pastDueBalance: string;
                dayRange: string;
                dayPlus: string;
                notApplicable: string;
            };
            document: {
                header: string;
                id: string;
                type: string;
                date: string;
                dueDate: string;
                originalAmount: string;
                openAmount: string;
                status: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            sorts: {
                byCreatedAtDateAsc: string;
                byCreatedAtDateDesc: string;
                byDueAtDateAsc: string;
                byDueAtDateDesc: string;
                byOriginalAmountAsc: string;
                byOriginalAmountDesc: string;
                byOpenAmountAsc: string;
                byOpenAmountDesc: string;
                byOrgDocumentTypeAsc: string;
                byOrgDocumentTypeDesc: string;
                byStatusAsc: string;
                byStatusDesc: string;
                byOrgDocumentIdAsc: string;
                byOrgDocumentIdDesc: string;
            };
            statuses: {
                open: string;
                closed: string;
                all: string;
            };
            filterByOptions: {
                orgDocumentId: string;
                orgDocumentIdRange: string;
                orgDocumentType: string;
                createdAtDateRange: string;
                dueAtDateRange: string;
                amountRange: string;
                openAmountRange: string;
            };
            sortBy: string;
            sortDocuments: string;
            filter: {
                status: string;
                filterBy: string;
                documentNumber: string;
                documentType: string;
                startRange: string;
                endRange: string;
                clear: string;
                search: string;
                errors: {
                    toDateMustComeAfterFrom: string;
                    toAmountMustBeLargeThanFrom: string;
                };
            };
            hint: string;
        };
        orgAccountSummaryList: {
            breadcrumbs: {
                list: string;
                details: string;
            };
        };
    };
};

declare const ru: {
    accountSummary: {
        orgAccountSummary: {
            groupName: string;
            header: string;
            name: string;
            details: {
                header: string;
                uid: string;
                name: string;
                address: string;
                creditRep: string;
                creditLine: string;
                currentBalance: string;
                openBalance: string;
                pastDueBalance: string;
                dayRange: string;
                dayPlus: string;
                notApplicable: string;
            };
            document: {
                header: string;
                id: string;
                type: string;
                date: string;
                dueDate: string;
                originalAmount: string;
                openAmount: string;
                status: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            sorts: {
                byCreatedAtDateAsc: string;
                byCreatedAtDateDesc: string;
                byDueAtDateAsc: string;
                byDueAtDateDesc: string;
                byOriginalAmountAsc: string;
                byOriginalAmountDesc: string;
                byOpenAmountAsc: string;
                byOpenAmountDesc: string;
                byOrgDocumentTypeAsc: string;
                byOrgDocumentTypeDesc: string;
                byStatusAsc: string;
                byStatusDesc: string;
                byOrgDocumentIdAsc: string;
                byOrgDocumentIdDesc: string;
            };
            statuses: {
                open: string;
                closed: string;
                all: string;
            };
            filterByOptions: {
                orgDocumentId: string;
                orgDocumentIdRange: string;
                orgDocumentType: string;
                createdAtDateRange: string;
                dueAtDateRange: string;
                amountRange: string;
                openAmountRange: string;
            };
            sortBy: string;
            sortDocuments: string;
            filter: {
                status: string;
                filterBy: string;
                documentNumber: string;
                documentType: string;
                startRange: string;
                endRange: string;
                clear: string;
                search: string;
                errors: {
                    toDateMustComeAfterFrom: string;
                    toAmountMustBeLargeThanFrom: string;
                };
            };
            hint: string;
        };
        orgAccountSummaryList: {
            breadcrumbs: {
                list: string;
                details: string;
            };
        };
    };
};

declare const zh: {
    accountSummary: {
        orgAccountSummary: {
            groupName: string;
            header: string;
            name: string;
            details: {
                header: string;
                uid: string;
                name: string;
                address: string;
                creditRep: string;
                creditLine: string;
                currentBalance: string;
                openBalance: string;
                pastDueBalance: string;
                dayRange: string;
                dayPlus: string;
                notApplicable: string;
            };
            document: {
                header: string;
                id: string;
                type: string;
                date: string;
                dueDate: string;
                originalAmount: string;
                openAmount: string;
                status: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            sorts: {
                byCreatedAtDateAsc: string;
                byCreatedAtDateDesc: string;
                byDueAtDateAsc: string;
                byDueAtDateDesc: string;
                byOriginalAmountAsc: string;
                byOriginalAmountDesc: string;
                byOpenAmountAsc: string;
                byOpenAmountDesc: string;
                byOrgDocumentTypeAsc: string;
                byOrgDocumentTypeDesc: string;
                byStatusAsc: string;
                byStatusDesc: string;
                byOrgDocumentIdAsc: string;
                byOrgDocumentIdDesc: string;
            };
            statuses: {
                open: string;
                closed: string;
                all: string;
            };
            filterByOptions: {
                orgDocumentId: string;
                orgDocumentIdRange: string;
                orgDocumentType: string;
                createdAtDateRange: string;
                dueAtDateRange: string;
                amountRange: string;
                openAmountRange: string;
            };
            sortBy: string;
            sortDocuments: string;
            filter: {
                status: string;
                filterBy: string;
                documentNumber: string;
                documentType: string;
                startRange: string;
                endRange: string;
                clear: string;
                search: string;
                errors: {
                    toDateMustComeAfterFrom: string;
                    toAmountMustBeLargeThanFrom: string;
                };
            };
            hint: string;
        };
        orgAccountSummaryList: {
            breadcrumbs: {
                list: string;
                details: string;
            };
        };
    };
};

declare const zh_TW: {
    accountSummary: {
        orgAccountSummary: {
            groupName: string;
            header: string;
            name: string;
            details: {
                header: string;
                uid: string;
                name: string;
                address: string;
                creditRep: string;
                creditLine: string;
                currentBalance: string;
                openBalance: string;
                pastDueBalance: string;
                dayRange: string;
                dayPlus: string;
                notApplicable: string;
            };
            document: {
                header: string;
                id: string;
                type: string;
                date: string;
                dueDate: string;
                originalAmount: string;
                openAmount: string;
                status: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            sorts: {
                byCreatedAtDateAsc: string;
                byCreatedAtDateDesc: string;
                byDueAtDateAsc: string;
                byDueAtDateDesc: string;
                byOriginalAmountAsc: string;
                byOriginalAmountDesc: string;
                byOpenAmountAsc: string;
                byOpenAmountDesc: string;
                byOrgDocumentTypeAsc: string;
                byOrgDocumentTypeDesc: string;
                byStatusAsc: string;
                byStatusDesc: string;
                byOrgDocumentIdAsc: string;
                byOrgDocumentIdDesc: string;
            };
            statuses: {
                open: string;
                closed: string;
                all: string;
            };
            filterByOptions: {
                orgDocumentId: string;
                orgDocumentIdRange: string;
                orgDocumentType: string;
                createdAtDateRange: string;
                dueAtDateRange: string;
                amountRange: string;
                openAmountRange: string;
            };
            sortBy: string;
            sortDocuments: string;
            filter: {
                status: string;
                filterBy: string;
                documentNumber: string;
                documentType: string;
                startRange: string;
                endRange: string;
                clear: string;
                search: string;
                errors: {
                    toDateMustComeAfterFrom: string;
                    toAmountMustBeLargeThanFrom: string;
                };
            };
            hint: string;
        };
        orgAccountSummaryList: {
            breadcrumbs: {
                list: string;
                details: string;
            };
        };
    };
};

declare const accountSummaryTranslationChunksConfig: TranslationChunksConfig;

export { accountSummaryTranslationChunksConfig, cs as accountSummaryTranslationsCs, de as accountSummaryTranslationsDe, en as accountSummaryTranslationsEn, es as accountSummaryTranslationsEs, es_CO as accountSummaryTranslationsEs_CO, fr as accountSummaryTranslationsFr, hi as accountSummaryTranslationsHi, hu as accountSummaryTranslationsHu, id as accountSummaryTranslationsId, it as accountSummaryTranslationsIt, ja as accountSummaryTranslationsJa, ko as accountSummaryTranslationsKo, pl as accountSummaryTranslationsPl, pt as accountSummaryTranslationsPt, ru as accountSummaryTranslationsRu, zh as accountSummaryTranslationsZh, zh_TW as accountSummaryTranslationsZh_TW };
