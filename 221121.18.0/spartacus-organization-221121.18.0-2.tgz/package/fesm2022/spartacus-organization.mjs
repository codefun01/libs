export * from '@spartacus/organization/administration';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/*
 * Public API Surface of my-account
 */

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=spartacus-organization.mjs.map
