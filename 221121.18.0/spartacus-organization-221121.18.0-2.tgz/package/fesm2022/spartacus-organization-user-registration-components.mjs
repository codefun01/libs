import * as i0 from '@angular/core';
import { inject, Injectable, ChangeDetectionStrategy, Component, NgModule, ChangeDetectorRef, ViewChild, HostBinding } from '@angular/core';
import { RouterLink, RouterModule } from '@angular/router';
import { NgIf, AsyncPipe, CommonModule, NgClass } from '@angular/common';
import * as i1$1 from '@angular/forms';
import { Validators, FormsModule, ReactiveFormsModule, FormBuilder, UntypedFormGroup, UntypedFormControl } from '@angular/forms';
import { NgSelectComponent, NgSelectModule } from '@ng-select/ng-select';
import * as i2 from '@spartacus/core';
import { FeatureToggles, GlobalMessageType, OAuthFlow, GlobalMessageService, UrlPipe, TranslatePipe, UrlModule, I18nModule, FeaturesConfigModule, ConfigModule, NotAuthGuard, RoutingService, WindowRef, TranslationService, AuthConfigService, provideDefaultConfig, AuthService } from '@spartacus/core';
import { CustomFormValidators, FormRequiredLegendComponent, NgSelectA11yDirective, FormRequiredAsterisksComponent, FormErrorsComponent, SpinnerComponent, SpinnerModule, FormErrorsModule, NgSelectA11yModule, LaunchDialogService, LAUNCH_CALLER, KeyboardFocusModule, IconModule } from '@spartacus/storefront';
import { of, BehaviorSubject, Subscription, Subject } from 'rxjs';
import { tap, filter, switchMap, take } from 'rxjs/operators';
import * as i1 from '@spartacus/user/profile/root';
import * as i3 from '@spartacus/organization/user-registration/root';
import { UserRegistrationFacade } from '@spartacus/organization/user-registration/root';
import { VerificationTokenFacade } from '@spartacus/user/account/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserRegistrationFormService {
    /*
     * Initializes form structure for registration.
     */
    buildForm() {
        return this.formBuilder.group({
            titleCode: [null],
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            companyName: ['', Validators.required],
            email: ['', [Validators.required, CustomFormValidators.emailValidator]],
            country: this.formBuilder.group({
                isocode: [null],
            }),
            line1: [''],
            line2: [''],
            town: [''],
            region: this.formBuilder.group({
                isocode: [null],
            }),
            postalCode: [''],
            phoneNumber: [''],
            message: [''],
        });
    }
    /*
     * Gets form structure for registration.
     */
    get form() {
        return this._form;
    }
    /*
     * Gets form control for country isocode.
     */
    get countryControl() {
        return this.form.get('country.isocode');
    }
    /*
     *  Gets form control for region isocode.
     */
    get regionControl() {
        return this.form.get('region.isocode');
    }
    constructor(userRegisterFacade, userAddressService, organizationUserRegistrationFacade, translationService, globalMessageService, authConfigService, routingService, formBuilder) {
        this.userRegisterFacade = userRegisterFacade;
        this.userAddressService = userAddressService;
        this.organizationUserRegistrationFacade = organizationUserRegistrationFacade;
        this.translationService = translationService;
        this.globalMessageService = globalMessageService;
        this.authConfigService = authConfigService;
        this.routingService = routingService;
        this.formBuilder = formBuilder;
        this._form = this.buildForm();
        this.featureToggles = inject(FeatureToggles);
    }
    /**
     * Gets all title codes.
     */
    getTitles() {
        return this.userRegisterFacade.getTitles();
    }
    /**
     * Gets all countries list.
     */
    getCountries() {
        return this.userAddressService.getDeliveryCountries().pipe(tap((countries) => {
            if (Object.keys(countries).length === 0) {
                this.userAddressService.loadDeliveryCountries();
            }
        }));
    }
    /**
     * Gets all regions list for specific selected country.
     */
    getRegions() {
        const regions = [];
        return (this.countryControl?.valueChanges.pipe(filter((countryIsoCode) => !!countryIsoCode), switchMap((countryIsoCode) => {
            this.regionControl?.reset();
            return this.userAddressService.getRegions(countryIsoCode);
        })) ?? of(regions));
    }
    /**
     * Takes form values and builds custom message content.
     */
    buildMessageContent(form) {
        return this.translationService.translate('userRegistrationForm.messageToApproverTemplate', {
            phoneNumber: form.get('phoneNumber')?.value,
            addressLine: form.get('line1')?.value,
            secondAddressLine: form.get('line2')?.value,
            city: form.get('city')?.value,
            state: form.get('region')?.get('isocode')?.value,
            postalCode: form.get('postalCode')?.value,
            country: form.get('country')?.get('isocode')?.value,
            companyName: form.get('companyName')?.value,
            message: form.get('message')?.value,
        });
    }
    /**
     * Displays confirmation global message.
     */
    displayGlobalMessage() {
        return this.globalMessageService.add({ key: 'userRegistrationForm.successFormSubmitMessage' }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
    }
    /**
     * Redirects the user back to the login page.
     *
     * This only happens in case of the `ResourceOwnerPasswordFlow` OAuth flow and authorizationCodeFlowByDefault.
     *
     */
    redirectToLogin() {
        if (this.authConfigService.getOAuthFlow() ===
            OAuthFlow.ResourceOwnerPasswordFlow ||
            this.featureToggles.authorizationCodeFlowByDefault) {
            this.routingService.go({ cxRoute: 'login' });
        }
    }
    /**
     * Registers new organization user.
     */
    registerUser(form) {
        return this.buildMessageContent(form).pipe(take(1), switchMap((message) => this.organizationUserRegistrationFacade.registerUser({
            titleCode: form.get('titleCode')?.value,
            firstName: form.get('firstName')?.value,
            lastName: form.get('lastName')?.value,
            email: form.get('email')?.value,
            message: message,
        })), tap(() => {
            this.displayGlobalMessage();
            this.redirectToLogin();
            form.reset();
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationFormService, deps: [{ token: i1.UserRegisterFacade }, { token: i2.UserAddressService }, { token: i3.UserRegistrationFacade }, { token: i2.TranslationService }, { token: i2.GlobalMessageService }, { token: i2.AuthConfigService }, { token: i2.RoutingService }, { token: i1$1.FormBuilder }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationFormService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationFormService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.UserRegisterFacade }, { type: i2.UserAddressService }, { type: i3.UserRegistrationFacade }, { type: i2.TranslationService }, { type: i2.GlobalMessageService }, { type: i2.AuthConfigService }, { type: i2.RoutingService }, { type: i1$1.FormBuilder }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserRegistrationFormComponent {
    constructor(userRegistrationFormService) {
        this.userRegistrationFormService = userRegistrationFormService;
        this.titles$ = this.userRegistrationFormService.getTitles();
        this.countries$ = this.userRegistrationFormService.getCountries();
        this.regions$ = this.userRegistrationFormService.getRegions();
        this.registerForm = this.userRegistrationFormService.form;
        this.isLoading$ = new BehaviorSubject(false);
        this.subscriptions = new Subscription();
        this.globalMessageService = inject(GlobalMessageService, {
            optional: true,
        });
    }
    submit() {
        if (this.registerForm.valid) {
            this.isLoading$.next(true);
            this.subscriptions.add(this.userRegistrationFormService
                .registerUser(this.registerForm)
                .subscribe({
                complete: () => this.isLoading$.next(false),
                error: () => {
                    this.isLoading$.next(false);
                    this.globalMessageService?.add({ key: 'userRegistrationForm.messageToFailedToRegister' }, GlobalMessageType.MSG_TYPE_ERROR);
                },
            }));
        }
        else {
            this.registerForm.markAllAsTouched();
        }
    }
    ngOnDestroy() {
        this.subscriptions.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationFormComponent, deps: [{ token: UserRegistrationFormService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: UserRegistrationFormComponent, isStandalone: true, selector: "cx-user-registration-form", ngImport: i0, template: "<section *ngIf=\"!(isLoading$ | async); else loading\">\n  <form [formGroup]=\"registerForm\" (ngSubmit)=\"submit()\">\n    <cx-form-required-legend />\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.titleCode.label' | cxTranslate\n      }}</span>\n      <ng-select\n        id=\"title-code-select\"\n        formControlName=\"titleCode\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"(titles$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"code\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.titleCode.placeholder' | cxTranslate\n        }}\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n        [cxNgSelectA11y]=\"{\n          ariaLabel:\n            'userRegistrationForm.fields.titleCode.label' | cxTranslate,\n        }\"\n      >\n      </ng-select>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'userRegistrationForm.fields.firstName.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"text\"\n        name=\"firstname\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.firstName.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"firstName\"\n        [attr.aria-invalid]=\"\n          registerForm.get('firstName')?.touched &&\n          registerForm.get('firstName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'firstNameError'\"\n      />\n\n      <cx-form-errors\n        id=\"firstNameError\"\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.firstName.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('firstName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'userRegistrationForm.fields.lastName.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"text\"\n        name=\"lastname\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.lastName.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"lastName\"\n        [attr.aria-invalid]=\"\n          registerForm.get('lastName')?.touched &&\n          registerForm.get('lastName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'lastNameError'\"\n      />\n\n      <cx-form-errors\n        id=\"lastNameError\"\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.lastName.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('lastName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'userRegistrationForm.fields.companyName.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"text\"\n        name=\"companyName\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.companyName.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"companyName\"\n        [attr.aria-invalid]=\"\n          registerForm.get('companyName')?.touched &&\n          registerForm.get('companyName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'companyNameError'\"\n      />\n      <cx-form-errors\n        id=\"companyNameError\"\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.companyName.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('companyName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'userRegistrationForm.fields.email.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"email\"\n        name=\"email\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.email.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"email\"\n        [attr.aria-invalid]=\"\n          registerForm.get('email')?.touched &&\n          registerForm.get('email')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'emailError'\"\n      />\n\n      <cx-form-errors\n        id=\"emailError\"\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.email.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('email')\"\n      ></cx-form-errors>\n    </label>\n\n    <ng-container\n      *ngIf=\"countries$ | async as countries\"\n      formGroupName=\"country\"\n    >\n      <label *ngIf=\"countries.length !== 0\">\n        <span class=\"label-content\">{{\n          'userRegistrationForm.fields.country.label' | cxTranslate\n        }}</span>\n        <ng-select\n          class=\"country-select\"\n          id=\"country-select\"\n          formControlName=\"isocode\"\n          [searchable]=\"true\"\n          [clearable]=\"false\"\n          [items]=\"countries\"\n          bindLabel=\"name\"\n          bindValue=\"isocode\"\n          placeholder=\"{{\n            'userRegistrationForm.fields.country.placeholder' | cxTranslate\n          }}\"\n          ariaLabelDropdown=\"{{\n            'common.ngSelectDropdownOptionsList' | cxTranslate\n          }}\"\n          [cxNgSelectA11y]=\"{\n            ariaLabel:\n              'userRegistrationForm.fields.country.label' | cxTranslate,\n          }\"\n        >\n        </ng-select>\n\n        <cx-form-errors\n          [translationParams]=\"{\n            label: 'userRegistrationForm.fields.country.label' | cxTranslate,\n          }\"\n          [control]=\"registerForm.get('country.isocode')\"\n        ></cx-form-errors>\n      </label>\n    </ng-container>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.addressLine.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.addressLine.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"line1\"\n        [attr.aria-invalid]=\"\n          registerForm.get('line1')?.touched &&\n          registerForm.get('line1')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'line1Error'\"\n      />\n\n      <cx-form-errors\n        id=\"line1Error\"\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.addressLine.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('line1')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.secondAddressLine.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.secondAddressLine.placeholder'\n            | cxTranslate\n        }}\"\n        formControlName=\"line2\"\n        [attr.aria-invalid]=\"\n          registerForm.get('line2')?.touched &&\n          registerForm.get('line2')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'line2Error'\"\n      />\n      <cx-form-errors\n        id=\"line2Error\"\n        [control]=\"registerForm.get('line2')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.city.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.city.label' | cxTranslate\n        }}\"\n        formControlName=\"town\"\n        [attr.aria-invalid]=\"\n          registerForm.get('town')?.touched && registerForm.get('town')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'townError'\"\n      />\n      <cx-form-errors\n        id=\"townError\"\n        [control]=\"registerForm.get('town')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.postalCode.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.postalCode.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"postalCode\"\n        [attr.aria-invalid]=\"\n          registerForm.get('postalCode')?.touched &&\n          registerForm.get('postalCode')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'postalCodeError'\"\n      />\n\n      <cx-form-errors\n        id=\"postalCodeError\"\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.postalCode.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('postalCode')\"\n      ></cx-form-errors>\n    </label>\n\n    <ng-container *ngIf=\"regions$ | async as regions\" formGroupName=\"region\">\n      <label *ngIf=\"regions.length !== 0\">\n        <span class=\"label-content\">{{\n          'userRegistrationForm.fields.state.label' | cxTranslate\n        }}</span>\n        <ng-select\n          class=\"region-select\"\n          formControlName=\"isocode\"\n          [searchable]=\"true\"\n          [clearable]=\"false\"\n          [items]=\"regions\"\n          bindLabel=\"name\"\n          bindValue=\"isocode\"\n          placeholder=\"{{\n            'userRegistrationForm.fields.state.placeholder' | cxTranslate\n          }}\"\n          id=\"region-select\"\n          ariaLabelDropdown=\"{{\n            'common.ngSelectDropdownOptionsList' | cxTranslate\n          }}\"\n          [cxNgSelectA11y]=\"{\n            ariaLabel: 'userRegistrationForm.fields.state.label' | cxTranslate,\n          }\"\n        >\n        </ng-select>\n\n        <cx-form-errors\n          [translationParams]=\"{\n            label: 'userRegistrationForm.fields.state.label' | cxTranslate,\n          }\"\n          [control]=\"registerForm.get('region.isocode')\"\n        ></cx-form-errors>\n      </label>\n    </ng-container>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.phoneNumber.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"tel\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.phoneNumber.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"phoneNumber\"\n        [attr.aria-invalid]=\"\n          registerForm.get('phoneNumber')?.touched &&\n          registerForm.get('phoneNumber')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'phoneNumberError'\"\n      />\n\n      <cx-form-errors\n        id=\"phoneNumberError\"\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.phoneNumber.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('phoneNumber')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.message.label' | cxTranslate\n      }}</span>\n      <textarea\n        class=\"form-control\"\n        formControlName=\"message\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.message.placeholder' | cxTranslate\n        }}\"\n        rows=\"5\"\n        [attr.aria-invalid]=\"\n          registerForm.get('message')?.touched &&\n          registerForm.get('message')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'messageError'\"\n      ></textarea>\n\n      <cx-form-errors\n        id=\"messageError\"\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.message.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('message')\"\n      ></cx-form-errors>\n    </label>\n\n    <button type=\"submit\" class=\"btn btn-block btn-primary\">\n      {{ 'userRegistrationForm.formSubmitButtonLabel' | cxTranslate }}\n    </button>\n    <a\n      class=\"cx-login-link btn-link\"\n      [routerLink]=\"{ cxRoute: 'login' } | cxUrl\"\n      >{{ 'userRegistrationForm.goToLoginButtonLabel' | cxTranslate }}</a\n    >\n  </form>\n</section>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\"><cx-spinner></cx-spinner></div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: i1$1.FormGroupName, selector: "[formGroupName]", inputs: ["formGroupName"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "directive", type: NgSelectA11yDirective, selector: "[cxNgSelectA11y]", inputs: ["cxNgSelectA11y"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-user-registration-form', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredLegendComponent,
                        NgSelectComponent,
                        NgSelectA11yDirective,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        RouterLink,
                        SpinnerComponent,
                        AsyncPipe,
                        UrlPipe,
                        TranslatePipe,
                    ], template: "<section *ngIf=\"!(isLoading$ | async); else loading\">\n  <form [formGroup]=\"registerForm\" (ngSubmit)=\"submit()\">\n    <cx-form-required-legend />\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.titleCode.label' | cxTranslate\n      }}</span>\n      <ng-select\n        id=\"title-code-select\"\n        formControlName=\"titleCode\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"(titles$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"code\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.titleCode.placeholder' | cxTranslate\n        }}\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n        [cxNgSelectA11y]=\"{\n          ariaLabel:\n            'userRegistrationForm.fields.titleCode.label' | cxTranslate,\n        }\"\n      >\n      </ng-select>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'userRegistrationForm.fields.firstName.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"text\"\n        name=\"firstname\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.firstName.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"firstName\"\n        [attr.aria-invalid]=\"\n          registerForm.get('firstName')?.touched &&\n          registerForm.get('firstName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'firstNameError'\"\n      />\n\n      <cx-form-errors\n        id=\"firstNameError\"\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.firstName.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('firstName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'userRegistrationForm.fields.lastName.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"text\"\n        name=\"lastname\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.lastName.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"lastName\"\n        [attr.aria-invalid]=\"\n          registerForm.get('lastName')?.touched &&\n          registerForm.get('lastName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'lastNameError'\"\n      />\n\n      <cx-form-errors\n        id=\"lastNameError\"\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.lastName.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('lastName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'userRegistrationForm.fields.companyName.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"text\"\n        name=\"companyName\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.companyName.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"companyName\"\n        [attr.aria-invalid]=\"\n          registerForm.get('companyName')?.touched &&\n          registerForm.get('companyName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'companyNameError'\"\n      />\n      <cx-form-errors\n        id=\"companyNameError\"\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.companyName.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('companyName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'userRegistrationForm.fields.email.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"email\"\n        name=\"email\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.email.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"email\"\n        [attr.aria-invalid]=\"\n          registerForm.get('email')?.touched &&\n          registerForm.get('email')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'emailError'\"\n      />\n\n      <cx-form-errors\n        id=\"emailError\"\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.email.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('email')\"\n      ></cx-form-errors>\n    </label>\n\n    <ng-container\n      *ngIf=\"countries$ | async as countries\"\n      formGroupName=\"country\"\n    >\n      <label *ngIf=\"countries.length !== 0\">\n        <span class=\"label-content\">{{\n          'userRegistrationForm.fields.country.label' | cxTranslate\n        }}</span>\n        <ng-select\n          class=\"country-select\"\n          id=\"country-select\"\n          formControlName=\"isocode\"\n          [searchable]=\"true\"\n          [clearable]=\"false\"\n          [items]=\"countries\"\n          bindLabel=\"name\"\n          bindValue=\"isocode\"\n          placeholder=\"{{\n            'userRegistrationForm.fields.country.placeholder' | cxTranslate\n          }}\"\n          ariaLabelDropdown=\"{{\n            'common.ngSelectDropdownOptionsList' | cxTranslate\n          }}\"\n          [cxNgSelectA11y]=\"{\n            ariaLabel:\n              'userRegistrationForm.fields.country.label' | cxTranslate,\n          }\"\n        >\n        </ng-select>\n\n        <cx-form-errors\n          [translationParams]=\"{\n            label: 'userRegistrationForm.fields.country.label' | cxTranslate,\n          }\"\n          [control]=\"registerForm.get('country.isocode')\"\n        ></cx-form-errors>\n      </label>\n    </ng-container>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.addressLine.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.addressLine.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"line1\"\n        [attr.aria-invalid]=\"\n          registerForm.get('line1')?.touched &&\n          registerForm.get('line1')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'line1Error'\"\n      />\n\n      <cx-form-errors\n        id=\"line1Error\"\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.addressLine.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('line1')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.secondAddressLine.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.secondAddressLine.placeholder'\n            | cxTranslate\n        }}\"\n        formControlName=\"line2\"\n        [attr.aria-invalid]=\"\n          registerForm.get('line2')?.touched &&\n          registerForm.get('line2')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'line2Error'\"\n      />\n      <cx-form-errors\n        id=\"line2Error\"\n        [control]=\"registerForm.get('line2')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.city.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.city.label' | cxTranslate\n        }}\"\n        formControlName=\"town\"\n        [attr.aria-invalid]=\"\n          registerForm.get('town')?.touched && registerForm.get('town')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'townError'\"\n      />\n      <cx-form-errors\n        id=\"townError\"\n        [control]=\"registerForm.get('town')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.postalCode.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.postalCode.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"postalCode\"\n        [attr.aria-invalid]=\"\n          registerForm.get('postalCode')?.touched &&\n          registerForm.get('postalCode')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'postalCodeError'\"\n      />\n\n      <cx-form-errors\n        id=\"postalCodeError\"\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.postalCode.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('postalCode')\"\n      ></cx-form-errors>\n    </label>\n\n    <ng-container *ngIf=\"regions$ | async as regions\" formGroupName=\"region\">\n      <label *ngIf=\"regions.length !== 0\">\n        <span class=\"label-content\">{{\n          'userRegistrationForm.fields.state.label' | cxTranslate\n        }}</span>\n        <ng-select\n          class=\"region-select\"\n          formControlName=\"isocode\"\n          [searchable]=\"true\"\n          [clearable]=\"false\"\n          [items]=\"regions\"\n          bindLabel=\"name\"\n          bindValue=\"isocode\"\n          placeholder=\"{{\n            'userRegistrationForm.fields.state.placeholder' | cxTranslate\n          }}\"\n          id=\"region-select\"\n          ariaLabelDropdown=\"{{\n            'common.ngSelectDropdownOptionsList' | cxTranslate\n          }}\"\n          [cxNgSelectA11y]=\"{\n            ariaLabel: 'userRegistrationForm.fields.state.label' | cxTranslate,\n          }\"\n        >\n        </ng-select>\n\n        <cx-form-errors\n          [translationParams]=\"{\n            label: 'userRegistrationForm.fields.state.label' | cxTranslate,\n          }\"\n          [control]=\"registerForm.get('region.isocode')\"\n        ></cx-form-errors>\n      </label>\n    </ng-container>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.phoneNumber.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"tel\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.phoneNumber.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"phoneNumber\"\n        [attr.aria-invalid]=\"\n          registerForm.get('phoneNumber')?.touched &&\n          registerForm.get('phoneNumber')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'phoneNumberError'\"\n      />\n\n      <cx-form-errors\n        id=\"phoneNumberError\"\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.phoneNumber.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('phoneNumber')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.message.label' | cxTranslate\n      }}</span>\n      <textarea\n        class=\"form-control\"\n        formControlName=\"message\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.message.placeholder' | cxTranslate\n        }}\"\n        rows=\"5\"\n        [attr.aria-invalid]=\"\n          registerForm.get('message')?.touched &&\n          registerForm.get('message')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'messageError'\"\n      ></textarea>\n\n      <cx-form-errors\n        id=\"messageError\"\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.message.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('message')\"\n      ></cx-form-errors>\n    </label>\n\n    <button type=\"submit\" class=\"btn btn-block btn-primary\">\n      {{ 'userRegistrationForm.formSubmitButtonLabel' | cxTranslate }}\n    </button>\n    <a\n      class=\"cx-login-link btn-link\"\n      [routerLink]=\"{ cxRoute: 'login' } | cxUrl\"\n      >{{ 'userRegistrationForm.goToLoginButtonLabel' | cxTranslate }}</a\n    >\n  </form>\n</section>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\"><cx-spinner></cx-spinner></div>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: UserRegistrationFormService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserRegistrationFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationFormModule, imports: [CommonModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            SpinnerModule,
            FormErrorsModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            NgSelectModule,
            NgSelectA11yModule, i2.ConfigModule, FeaturesConfigModule,
            UserRegistrationFormComponent], exports: [UserRegistrationFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationFormModule, providers: [UserRegistrationFormService], imports: [CommonModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            SpinnerModule,
            FormErrorsModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            NgSelectModule,
            NgSelectA11yModule,
            ConfigModule.withConfig({
                cmsComponents: {
                    OrganizationUserRegistrationComponent: {
                        component: UserRegistrationFormComponent,
                        guards: [NotAuthGuard],
                    },
                },
            }),
            FeaturesConfigModule,
            UserRegistrationFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        SpinnerModule,
                        FormErrorsModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        NgSelectModule,
                        NgSelectA11yModule,
                        ConfigModule.withConfig({
                            cmsComponents: {
                                OrganizationUserRegistrationComponent: {
                                    component: UserRegistrationFormComponent,
                                    guards: [NotAuthGuard],
                                },
                            },
                        }),
                        FeaturesConfigModule,
                        UserRegistrationFormComponent,
                    ],
                    exports: [UserRegistrationFormComponent],
                    providers: [UserRegistrationFormService],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ONE_TIME_PASSWORD_REGISTRATION_PURPOSE = 'REGISTRATION';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserRegistrationOTPFormComponent {
    constructor() {
        this.routingService = inject(RoutingService);
        this.verificationTokenFacade = inject(VerificationTokenFacade);
        this.winRef = inject(WindowRef);
        this.globalMessageService = inject(GlobalMessageService, {
            optional: true,
        });
        this.userRegistrationFormService = inject(UserRegistrationFormService);
        this.busy$ = new BehaviorSubject(false);
        this.titles$ = this.userRegistrationFormService.getTitles();
        this.countries$ = this.userRegistrationFormService.getCountries();
        this.regions$ = this.userRegistrationFormService.getRegions();
        this.registerForm = this.userRegistrationFormService.form;
        this.isLoading$ = new BehaviorSubject(false);
    }
    onSubmit() {
        if (!this.registerForm.valid) {
            this.registerForm.markAllAsTouched();
            return;
        }
        this.busy$.next(true);
        const tokenCreationReqBody = this.collectDataFromRegistrationForm();
        this.verificationTokenFacade
            .createVerificationToken(tokenCreationReqBody)
            .subscribe({
            next: (result) => this.goToVerificationTokenForm(result),
            error: (error) => {
                this.routingService.go({
                    cxRoute: 'verifyTokenForRegistration',
                }, {
                    state: {
                        registrationDataForm: this.registerForm.value,
                        loginId: this.registerForm.value.email.toLowerCase(),
                        errorStatus: error.status,
                        form: this.registerForm.value,
                    },
                });
                this.busy$.next(false);
            },
            complete: () => this.onCreateVerificationTokenComplete(),
        });
    }
    goToVerificationTokenForm(verificationToken) {
        this.routingService.go({
            cxRoute: 'verifyTokenForRegistration',
        }, {
            state: {
                registrationDataForm: this.registerForm.value,
                loginId: this.registerForm.value.email.toLowerCase(),
                tokenId: verificationToken.tokenId,
                expiresIn: verificationToken.expiresIn,
            },
        });
    }
    collectDataFromRegistrationForm() {
        return {
            loginId: this.registerForm.value.email.toLowerCase(),
            purpose: ONE_TIME_PASSWORD_REGISTRATION_PURPOSE,
        };
    }
    onCreateVerificationTokenComplete() {
        this.registerForm.reset();
        this.busy$.next(false);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationOTPFormComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: UserRegistrationOTPFormComponent, isStandalone: true, selector: "cx-user-registration-form", ngImport: i0, template: "<section *ngIf=\"!(isLoading$ | async); else loading\">\n  <form [formGroup]=\"registerForm\" (ngSubmit)=\"onSubmit()\">\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.titleCodeOnOTPForm.label' | cxTranslate\n      }}</span>\n      <ng-select\n        id=\"title-code-select\"\n        formControlName=\"titleCode\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"(titles$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"code\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.titleCodeOnOTPForm.placeholder'\n            | cxTranslate\n        }}\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n        [cxNgSelectA11y]=\"{\n          ariaLabel:\n            'userRegistrationForm.fields.titleCodeOnOTPForm.label'\n            | cxTranslate,\n        }\"\n      >\n      </ng-select>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'userRegistrationForm.fields.firstName.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"text\"\n        name=\"firstname\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.firstName.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"firstName\"\n      />\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.firstName.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('firstName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'userRegistrationForm.fields.lastName.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"text\"\n        name=\"lastname\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.lastName.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"lastName\"\n      />\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.lastName.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('lastName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'userRegistrationForm.fields.companyName.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"text\"\n        name=\"companyName\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.companyName.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"companyName\"\n      />\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.companyName.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('companyName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'userRegistrationForm.fields.email.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"email\"\n        name=\"email\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.email.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"email\"\n      />\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.email.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('email')\"\n      ></cx-form-errors>\n    </label>\n\n    <ng-container\n      *ngIf=\"countries$ | async as countries\"\n      formGroupName=\"country\"\n    >\n      <label *ngIf=\"countries.length !== 0\">\n        <span class=\"label-content\">{{\n          'userRegistrationForm.fields.countryOnOTPForm.label' | cxTranslate\n        }}</span>\n        <ng-select\n          class=\"country-select\"\n          id=\"country-select\"\n          formControlName=\"isocode\"\n          [searchable]=\"true\"\n          [clearable]=\"false\"\n          [items]=\"countries\"\n          bindLabel=\"name\"\n          bindValue=\"isocode\"\n          placeholder=\"{{\n            'userRegistrationForm.fields.countryOnOTPForm.placeholder'\n              | cxTranslate\n          }}\"\n          ariaLabelDropdown=\"{{\n            'common.ngSelectDropdownOptionsList' | cxTranslate\n          }}\"\n          [cxNgSelectA11y]=\"{\n            ariaLabel:\n              'userRegistrationForm.fields.countryOnOTPForm.label'\n              | cxTranslate,\n          }\"\n        >\n        </ng-select>\n\n        <cx-form-errors\n          [translationParams]=\"{\n            label:\n              'userRegistrationForm.fields.countryOnOTPForm.label'\n              | cxTranslate,\n          }\"\n          [control]=\"registerForm.get('country.isocode')\"\n        ></cx-form-errors>\n      </label>\n    </ng-container>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.addressLineOnOTPForm.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.addressLineOnOTPForm.placeholder'\n            | cxTranslate\n        }}\"\n        formControlName=\"line1\"\n      />\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label:\n            'userRegistrationForm.fields.addressLineOnOTPForm.label'\n            | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('line1')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.secondAddressLineOnOTPForm.label'\n          | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.secondAddressLineOnOTPForm.placeholder'\n            | cxTranslate\n        }}\"\n        formControlName=\"line2\"\n      />\n      <cx-form-errors [control]=\"registerForm.get('line2')\"></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.cityOnOTPForm.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.cityOnOTPForm.label' | cxTranslate\n        }}\"\n        formControlName=\"town\"\n      />\n      <cx-form-errors [control]=\"registerForm.get('town')\"></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.postalCodeOnOTPForm.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.postalCodeOnOTPForm.placeholder'\n            | cxTranslate\n        }}\"\n        formControlName=\"postalCode\"\n      />\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label:\n            'userRegistrationForm.fields.postalCodeOnOTPForm.label'\n            | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('postalCode')\"\n      ></cx-form-errors>\n    </label>\n\n    <ng-container *ngIf=\"regions$ | async as regions\" formGroupName=\"region\">\n      <label *ngIf=\"regions.length !== 0\">\n        <span class=\"label-content\">{{\n          'userRegistrationForm.fields.stateOnOTPForm.label' | cxTranslate\n        }}</span>\n        <ng-select\n          class=\"region-select\"\n          formControlName=\"isocode\"\n          [searchable]=\"true\"\n          [clearable]=\"false\"\n          [items]=\"regions\"\n          bindLabel=\"name\"\n          bindValue=\"isocode\"\n          placeholder=\"{{\n            'userRegistrationForm.fields.stateOnOTPForm.placeholder'\n              | cxTranslate\n          }}\"\n          id=\"region-select\"\n          ariaLabelDropdown=\"{{\n            'common.ngSelectDropdownOptionsList' | cxTranslate\n          }}\"\n          [cxNgSelectA11y]=\"{\n            ariaLabel:\n              'userRegistrationForm.fields.stateOnOTPForm.label' | cxTranslate,\n          }\"\n        >\n        </ng-select>\n\n        <cx-form-errors\n          [translationParams]=\"{\n            label:\n              'userRegistrationForm.fields.stateOnOTPForm.label' | cxTranslate,\n          }\"\n          [control]=\"registerForm.get('region.isocode')\"\n        ></cx-form-errors>\n      </label>\n    </ng-container>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.phoneNumberOnOTPForm.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"tel\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.phoneNumberOnOTPForm.placeholder'\n            | cxTranslate\n        }}\"\n        formControlName=\"phoneNumber\"\n      />\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label:\n            'userRegistrationForm.fields.phoneNumberOnOTPForm.label'\n            | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('phoneNumber')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.messageOnOTPForm.label' | cxTranslate\n      }}</span>\n      <textarea\n        class=\"form-control\"\n        formControlName=\"message\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.messageOnOTPForm.placeholder'\n            | cxTranslate\n        }}\"\n        rows=\"5\"\n      ></textarea>\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label:\n            'userRegistrationForm.fields.messageOnOTPForm.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('message')\"\n      ></cx-form-errors>\n    </label>\n\n    <button type=\"submit\" class=\"btn btn-block btn-primary\">\n      {{ 'userRegistrationForm.continueWithOTP' | cxTranslate }}\n    </button>\n    <!-- <a\n      class=\"cx-login-link btn-link\"\n      [routerLink]=\"{ cxRoute: 'login' } | cxUrl\"\n      >{{ 'userRegistrationForm.goToLoginButtonLabel' | cxTranslate }}</a\n    > -->\n  </form>\n</section>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\"><cx-spinner></cx-spinner></div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: i1$1.FormGroupName, selector: "[formGroupName]", inputs: ["formGroupName"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "directive", type: NgSelectA11yDirective, selector: "[cxNgSelectA11y]", inputs: ["cxNgSelectA11y"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationOTPFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-user-registration-form', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        NgSelectComponent,
                        NgSelectA11yDirective,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<section *ngIf=\"!(isLoading$ | async); else loading\">\n  <form [formGroup]=\"registerForm\" (ngSubmit)=\"onSubmit()\">\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.titleCodeOnOTPForm.label' | cxTranslate\n      }}</span>\n      <ng-select\n        id=\"title-code-select\"\n        formControlName=\"titleCode\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"(titles$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"code\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.titleCodeOnOTPForm.placeholder'\n            | cxTranslate\n        }}\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n        [cxNgSelectA11y]=\"{\n          ariaLabel:\n            'userRegistrationForm.fields.titleCodeOnOTPForm.label'\n            | cxTranslate,\n        }\"\n      >\n      </ng-select>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'userRegistrationForm.fields.firstName.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"text\"\n        name=\"firstname\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.firstName.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"firstName\"\n      />\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.firstName.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('firstName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'userRegistrationForm.fields.lastName.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"text\"\n        name=\"lastname\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.lastName.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"lastName\"\n      />\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.lastName.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('lastName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'userRegistrationForm.fields.companyName.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"text\"\n        name=\"companyName\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.companyName.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"companyName\"\n      />\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.companyName.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('companyName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'userRegistrationForm.fields.email.label' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"email\"\n        name=\"email\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.email.placeholder' | cxTranslate\n        }}\"\n        formControlName=\"email\"\n      />\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'userRegistrationForm.fields.email.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('email')\"\n      ></cx-form-errors>\n    </label>\n\n    <ng-container\n      *ngIf=\"countries$ | async as countries\"\n      formGroupName=\"country\"\n    >\n      <label *ngIf=\"countries.length !== 0\">\n        <span class=\"label-content\">{{\n          'userRegistrationForm.fields.countryOnOTPForm.label' | cxTranslate\n        }}</span>\n        <ng-select\n          class=\"country-select\"\n          id=\"country-select\"\n          formControlName=\"isocode\"\n          [searchable]=\"true\"\n          [clearable]=\"false\"\n          [items]=\"countries\"\n          bindLabel=\"name\"\n          bindValue=\"isocode\"\n          placeholder=\"{{\n            'userRegistrationForm.fields.countryOnOTPForm.placeholder'\n              | cxTranslate\n          }}\"\n          ariaLabelDropdown=\"{{\n            'common.ngSelectDropdownOptionsList' | cxTranslate\n          }}\"\n          [cxNgSelectA11y]=\"{\n            ariaLabel:\n              'userRegistrationForm.fields.countryOnOTPForm.label'\n              | cxTranslate,\n          }\"\n        >\n        </ng-select>\n\n        <cx-form-errors\n          [translationParams]=\"{\n            label:\n              'userRegistrationForm.fields.countryOnOTPForm.label'\n              | cxTranslate,\n          }\"\n          [control]=\"registerForm.get('country.isocode')\"\n        ></cx-form-errors>\n      </label>\n    </ng-container>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.addressLineOnOTPForm.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.addressLineOnOTPForm.placeholder'\n            | cxTranslate\n        }}\"\n        formControlName=\"line1\"\n      />\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label:\n            'userRegistrationForm.fields.addressLineOnOTPForm.label'\n            | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('line1')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.secondAddressLineOnOTPForm.label'\n          | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.secondAddressLineOnOTPForm.placeholder'\n            | cxTranslate\n        }}\"\n        formControlName=\"line2\"\n      />\n      <cx-form-errors [control]=\"registerForm.get('line2')\"></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.cityOnOTPForm.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.cityOnOTPForm.label' | cxTranslate\n        }}\"\n        formControlName=\"town\"\n      />\n      <cx-form-errors [control]=\"registerForm.get('town')\"></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.postalCodeOnOTPForm.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.postalCodeOnOTPForm.placeholder'\n            | cxTranslate\n        }}\"\n        formControlName=\"postalCode\"\n      />\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label:\n            'userRegistrationForm.fields.postalCodeOnOTPForm.label'\n            | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('postalCode')\"\n      ></cx-form-errors>\n    </label>\n\n    <ng-container *ngIf=\"regions$ | async as regions\" formGroupName=\"region\">\n      <label *ngIf=\"regions.length !== 0\">\n        <span class=\"label-content\">{{\n          'userRegistrationForm.fields.stateOnOTPForm.label' | cxTranslate\n        }}</span>\n        <ng-select\n          class=\"region-select\"\n          formControlName=\"isocode\"\n          [searchable]=\"true\"\n          [clearable]=\"false\"\n          [items]=\"regions\"\n          bindLabel=\"name\"\n          bindValue=\"isocode\"\n          placeholder=\"{{\n            'userRegistrationForm.fields.stateOnOTPForm.placeholder'\n              | cxTranslate\n          }}\"\n          id=\"region-select\"\n          ariaLabelDropdown=\"{{\n            'common.ngSelectDropdownOptionsList' | cxTranslate\n          }}\"\n          [cxNgSelectA11y]=\"{\n            ariaLabel:\n              'userRegistrationForm.fields.stateOnOTPForm.label' | cxTranslate,\n          }\"\n        >\n        </ng-select>\n\n        <cx-form-errors\n          [translationParams]=\"{\n            label:\n              'userRegistrationForm.fields.stateOnOTPForm.label' | cxTranslate,\n          }\"\n          [control]=\"registerForm.get('region.isocode')\"\n        ></cx-form-errors>\n      </label>\n    </ng-container>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.phoneNumberOnOTPForm.label' | cxTranslate\n      }}</span>\n      <input\n        type=\"tel\"\n        class=\"form-control\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.phoneNumberOnOTPForm.placeholder'\n            | cxTranslate\n        }}\"\n        formControlName=\"phoneNumber\"\n      />\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label:\n            'userRegistrationForm.fields.phoneNumberOnOTPForm.label'\n            | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('phoneNumber')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">{{\n        'userRegistrationForm.fields.messageOnOTPForm.label' | cxTranslate\n      }}</span>\n      <textarea\n        class=\"form-control\"\n        formControlName=\"message\"\n        placeholder=\"{{\n          'userRegistrationForm.fields.messageOnOTPForm.placeholder'\n            | cxTranslate\n        }}\"\n        rows=\"5\"\n      ></textarea>\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label:\n            'userRegistrationForm.fields.messageOnOTPForm.label' | cxTranslate,\n        }\"\n        [control]=\"registerForm.get('message')\"\n      ></cx-form-errors>\n    </label>\n\n    <button type=\"submit\" class=\"btn btn-block btn-primary\">\n      {{ 'userRegistrationForm.continueWithOTP' | cxTranslate }}\n    </button>\n    <!-- <a\n      class=\"cx-login-link btn-link\"\n      [routerLink]=\"{ cxRoute: 'login' } | cxUrl\"\n      >{{ 'userRegistrationForm.goToLoginButtonLabel' | cxTranslate }}</a\n    > -->\n  </form>\n</section>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\"><cx-spinner></cx-spinner></div>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserRegistrationOTPFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationOTPFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationOTPFormModule, imports: [CommonModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            SpinnerModule,
            FormErrorsModule,
            NgSelectModule,
            NgSelectA11yModule, i2.ConfigModule, FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            UserRegistrationOTPFormComponent], exports: [UserRegistrationOTPFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationOTPFormModule, imports: [CommonModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            SpinnerModule,
            FormErrorsModule,
            NgSelectModule,
            NgSelectA11yModule,
            ConfigModule.withConfig({
                cmsComponents: {
                    RegisterB2BCustomerWithOTPComponent: {
                        component: UserRegistrationOTPFormComponent,
                        guards: [NotAuthGuard],
                    },
                },
            }),
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            UserRegistrationOTPFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationOTPFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        SpinnerModule,
                        FormErrorsModule,
                        NgSelectModule,
                        NgSelectA11yModule,
                        ConfigModule.withConfig({
                            cmsComponents: {
                                RegisterB2BCustomerWithOTPComponent: {
                                    component: UserRegistrationOTPFormComponent,
                                    guards: [NotAuthGuard],
                                },
                            },
                        }),
                        FeaturesConfigModule,
                        FormRequiredAsterisksComponent,
                        UserRegistrationOTPFormComponent,
                    ],
                    exports: [UserRegistrationOTPFormComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const globalMsgShowTime = 10000;
class RegisterVerificationTokenFormComponentService {
    constructor() {
        this.featureToggles = inject(FeatureToggles);
        this.globalMessage = inject(GlobalMessageService);
        this.formBuilder = inject(FormBuilder);
        this.organizationUserRegistrationFacade = inject(UserRegistrationFacade);
        this.translationService = inject(TranslationService);
        this.authConfigService = inject(AuthConfigService);
        this.routingService = inject(RoutingService);
        this.form = new UntypedFormGroup({
            tokenId: new UntypedFormControl('', [Validators.required]),
            tokenCode: new UntypedFormControl('', [Validators.required]),
        });
    }
    buildMessageContent(formValue) {
        return this.translationService.translate('userRegistrationForm.messageToApproverTemplate', {
            phoneNumber: formValue.phoneNumber,
            addressLine: formValue.line1,
            secondAddressLine: formValue.line2,
            city: formValue.city,
            state: formValue.region?.isocode,
            postalCode: formValue.postalCode,
            country: formValue.country?.isocode,
            companyName: formValue.companyName,
            message: formValue.message,
        });
    }
    /**
     * Redirects the user back to the login page.
     *
     * This only happens in case of the `ResourceOwnerPasswordFlow` OAuth flow and authorizationCodeFlowByDefault.
     */
    redirectToLogin() {
        if (this.authConfigService.getOAuthFlow() ===
            OAuthFlow.ResourceOwnerPasswordFlow ||
            this.featureToggles.authorizationCodeFlowByDefault) {
            this.routingService.go({ cxRoute: 'login' });
        }
    }
    displayMessage(key, params) {
        this.globalMessage.add({
            key: key,
            params,
        }, GlobalMessageType.MSG_TYPE_CONFIRMATION, globalMsgShowTime);
    }
    registerUser(formValue) {
        return this.buildMessageContent(formValue).pipe(take(1), switchMap((message) => this.organizationUserRegistrationFacade.registerUser({
            titleCode: formValue.titleCode,
            firstName: formValue.firstName,
            lastName: formValue.lastName,
            email: formValue.email,
            message: message,
            verificationTokenId: this.form.get('tokenId')?.value,
            verificationTokenCode: this.form.get('tokenCode')?.value,
        })), tap(() => {
            this.displayMessage('userRegistrationForm.successFormSubmitMessage', {});
            this.redirectToLogin();
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegisterVerificationTokenFormComponentService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegisterVerificationTokenFormComponentService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegisterVerificationTokenFormComponentService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class RegisterVerificationTokenFormComponent {
    constructor() {
        this.featureToggles = inject(FeatureToggles);
        this.service = inject(RegisterVerificationTokenFormComponentService);
        this.launchDialogService = inject(LaunchDialogService);
        this.cdr = inject(ChangeDetectorRef);
        this.routingService = inject(RoutingService);
        this.verificationTokenFacade = inject(VerificationTokenFacade);
        this.form = this.service.form;
        this.isUpdating$ = new Subject();
        this.waitTime = 60;
        this.subscriptions = new Subscription();
        this.style = true;
        this.isResendDisabled = true;
        this.waitTimeForRateLimit = 300;
    }
    ngOnInit() {
        if (history.state) {
            this.registerData = history.state['registrationDataForm'];
            this.tokenId = history.state['tokenId'];
            this.target = history.state['loginId'];
            this.errorStatus = history.state['errorStatus'];
            history.pushState({
                tokenId: '',
                loginId: '',
                errorStatus: '',
            }, 'verifyToken');
            if (this.errorStatus === 400) {
                this.upToRateLimit = true;
                this.tokenId = 'invalidTokenId';
                this.startRateLimitWaitTimeInterval();
                this.isUpdating$.next(false);
            }
            else if (!this.target || !this.tokenId) {
                this.service.displayMessage('verificationTokenForm.needInputCredentials', {});
                this.routingService.go(this.featureToggles.authorizationCodeFlowByDefault
                    ? { cxRoute: 'register' }
                    : ['/login/register']);
                this.routingService.go(['/login/register']);
            }
            else {
                this.startWaitTimeInterval();
                this.service.displayMessage('verificationTokenForm.createVerificationToken', { target: this.target });
            }
        }
    }
    onSubmit() {
        if (!this.form.valid) {
            this.form.markAllAsTouched();
            return;
        }
        this.isUpdating$.next(true);
        this.subscriptions.add(this.service.registerUser(this.registerData).subscribe({
            complete: () => this.isUpdating$.next(false),
            error: () => {
                this.isUpdating$.next(false);
                this.form
                    .get('tokenCode')
                    ?.setErrors({ invalidTokenCodeError: true });
            },
        }));
    }
    resendOTP() {
        this.isResendDisabled = true;
        this.waitTime = 60;
        this.resendLink.nativeElement.tabIndex = -1;
        this.resendLink.nativeElement.blur();
        this.startWaitTimeInterval();
        this.verificationTokenFacade
            .createVerificationToken({
            loginId: this.target,
            purpose: ONE_TIME_PASSWORD_REGISTRATION_PURPOSE,
        })
            .subscribe({
            next: (result) => (this.tokenId = result.tokenId),
            complete: () => this.service.displayMessage('verificationTokenForm.createVerificationToken', { target: this.target }),
        });
    }
    startWaitTimeInterval() {
        const interval = setInterval(() => {
            this.waitTime--;
            this.cdr.detectChanges();
            if (this.waitTime <= 0) {
                clearInterval(interval);
                this.isResendDisabled = false;
                this.resendLink.nativeElement.tabIndex = 0;
                this.cdr.detectChanges();
            }
        }, 1000);
    }
    startRateLimitWaitTimeInterval() {
        const interval = setInterval(() => {
            this.waitTimeForRateLimit--;
            this.cdr.detectChanges();
            if (this.waitTimeForRateLimit <= 0) {
                clearInterval(interval);
                this.upToRateLimit = false;
                this.isResendDisabled = false;
                this.cdr.detectChanges();
            }
        }, 1000);
    }
    openInfoDailog() {
        this.launchDialogService.openDialogAndSubscribe(LAUNCH_CALLER.ACCOUNT_VERIFICATION_TOKEN, this.element);
    }
    onOpenInfoDailogKeyDown(event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.openInfoDailog();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegisterVerificationTokenFormComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: RegisterVerificationTokenFormComponent, isStandalone: true, selector: "cx-verification-token-form", host: { properties: { "class.user-form": "this.style" } }, viewQueries: [{ propertyName: "element", first: true, predicate: ["noReceiveCodeLink"], descendants: true }, { propertyName: "resendLink", first: true, predicate: ["resendLink"], descendants: true }], ngImport: i0, template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"></cx-spinner>\n\n<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n  <label>\n    <span class=\"label-content\">\n      {{ 'verificationTokenForm.verificationCode.label' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      class=\"form-control\"\n      formControlName=\"tokenCode\"\n      [placeholder]=\"\n        'verificationTokenForm.verificationCode.placeholder' | cxTranslate\n      \"\n      aria-describedby=\"tokenInputHint\"\n    />\n    <cx-form-errors [control]=\"form.get('tokenCode')\"></cx-form-errors>\n    <div class=\"rate-limit-error-display\" *ngIf=\"upToRateLimit\">\n      {{\n        'register.rateLimitForRegistrationMessage'\n          | cxTranslate: { seconds: waitTimeForRateLimit }\n      }}\n    </div>\n  </label>\n  <span id=\"tokenInputHint\" class=\"cx-visually-hidden\">\n    {{ 'verificationTokenForm.tokenInputHint' | cxTranslate }}\n  </span>\n\n  <input type=\"hidden\" formControlName=\"tokenId\" [(ngModel)]=\"tokenId\" />\n\n  <div\n    *ngIf=\"!upToRateLimit\"\n    class=\"resend-link-text register-b2b-otp-resend-link-text\"\n  >\n    <div class=\"left-text\">\n      <span role=\"timer\" aria-live=\"polite\" aria-atomic=\"true\">\n        <a\n          role=\"button\"\n          tabindex=\"-1\"\n          #resendLink\n          (keydown.enter)=\"resendOTP()\"\n          (keydown.space)=\"resendOTP()\"\n          (click)=\"resendOTP()\"\n          class=\"btn-link\"\n          [ngClass]=\"{ 'disabled-link': isResendDisabled }\"\n        >\n          {{ 'verificationTokenForm.resend' | cxTranslate }}\n        </a>\n        <ng-container *ngIf=\"isResendDisabled\">\n          {{\n            'verificationTokenForm.sendRateLime'\n              | cxTranslate: { waitTime: waitTime }\n          }}\n        </ng-container>\n      </span>\n    </div>\n    <div class=\"right-text\">\n      <a\n        role=\"button\"\n        tabindex=\"0\"\n        #noReceiveCodeLink\n        (keydown)=\"onOpenInfoDailogKeyDown($event)\"\n        (click)=\"openInfoDailog()\"\n        class=\"btn-link\"\n      >\n        {{ 'verificationTokenForm.noReceiveCode' | cxTranslate }}\n      </a>\n    </div>\n  </div>\n\n  <div class=\"verify-container\">\n    <button\n      type=\"submit\"\n      class=\"btn btn-block btn-primary\"\n      [disabled]=\"form.disabled\"\n    >\n      {{ 'verificationTokenForm.registerVerify' | cxTranslate }}\n    </button>\n    <button\n      [routerLink]=\"{ cxRoute: 'register' } | cxUrl\"\n      class=\"btn btn-block btn-secondary btn-register\"\n    >\n      {{ 'verificationTokenForm.back' | cxTranslate }}\n    </button>\n  </div>\n</form>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegisterVerificationTokenFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-verification-token-form', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        SpinnerComponent,
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        NgClass,
                        RouterLink,
                        AsyncPipe,
                        UrlPipe,
                        TranslatePipe,
                    ], template: "<cx-spinner class=\"overlay\" *ngIf=\"isUpdating$ | async\"></cx-spinner>\n\n<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"form\">\n  <label>\n    <span class=\"label-content\">\n      {{ 'verificationTokenForm.verificationCode.label' | cxTranslate }}\n      <cx-form-required-asterisks />\n    </span>\n    <input\n      required=\"true\"\n      class=\"form-control\"\n      formControlName=\"tokenCode\"\n      [placeholder]=\"\n        'verificationTokenForm.verificationCode.placeholder' | cxTranslate\n      \"\n      aria-describedby=\"tokenInputHint\"\n    />\n    <cx-form-errors [control]=\"form.get('tokenCode')\"></cx-form-errors>\n    <div class=\"rate-limit-error-display\" *ngIf=\"upToRateLimit\">\n      {{\n        'register.rateLimitForRegistrationMessage'\n          | cxTranslate: { seconds: waitTimeForRateLimit }\n      }}\n    </div>\n  </label>\n  <span id=\"tokenInputHint\" class=\"cx-visually-hidden\">\n    {{ 'verificationTokenForm.tokenInputHint' | cxTranslate }}\n  </span>\n\n  <input type=\"hidden\" formControlName=\"tokenId\" [(ngModel)]=\"tokenId\" />\n\n  <div\n    *ngIf=\"!upToRateLimit\"\n    class=\"resend-link-text register-b2b-otp-resend-link-text\"\n  >\n    <div class=\"left-text\">\n      <span role=\"timer\" aria-live=\"polite\" aria-atomic=\"true\">\n        <a\n          role=\"button\"\n          tabindex=\"-1\"\n          #resendLink\n          (keydown.enter)=\"resendOTP()\"\n          (keydown.space)=\"resendOTP()\"\n          (click)=\"resendOTP()\"\n          class=\"btn-link\"\n          [ngClass]=\"{ 'disabled-link': isResendDisabled }\"\n        >\n          {{ 'verificationTokenForm.resend' | cxTranslate }}\n        </a>\n        <ng-container *ngIf=\"isResendDisabled\">\n          {{\n            'verificationTokenForm.sendRateLime'\n              | cxTranslate: { waitTime: waitTime }\n          }}\n        </ng-container>\n      </span>\n    </div>\n    <div class=\"right-text\">\n      <a\n        role=\"button\"\n        tabindex=\"0\"\n        #noReceiveCodeLink\n        (keydown)=\"onOpenInfoDailogKeyDown($event)\"\n        (click)=\"openInfoDailog()\"\n        class=\"btn-link\"\n      >\n        {{ 'verificationTokenForm.noReceiveCode' | cxTranslate }}\n      </a>\n    </div>\n  </div>\n\n  <div class=\"verify-container\">\n    <button\n      type=\"submit\"\n      class=\"btn btn-block btn-primary\"\n      [disabled]=\"form.disabled\"\n    >\n      {{ 'verificationTokenForm.registerVerify' | cxTranslate }}\n    </button>\n    <button\n      [routerLink]=\"{ cxRoute: 'register' } | cxUrl\"\n      class=\"btn btn-block btn-secondary btn-register\"\n    >\n      {{ 'verificationTokenForm.back' | cxTranslate }}\n    </button>\n  </div>\n</form>\n" }]
        }], propDecorators: { style: [{
                type: HostBinding,
                args: ['class.user-form']
            }], element: [{
                type: ViewChild,
                args: ['noReceiveCodeLink']
            }], resendLink: [{
                type: ViewChild,
                args: ['resendLink']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class RegisterVerificationTokenFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegisterVerificationTokenFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: RegisterVerificationTokenFormModule, imports: [CommonModule,
            FormsModule,
            KeyboardFocusModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            IconModule,
            I18nModule,
            FormErrorsModule,
            SpinnerModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            RegisterVerificationTokenFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegisterVerificationTokenFormModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    VerifyOTPForB2BRegistrationComponent: {
                        component: RegisterVerificationTokenFormComponent,
                        guards: [NotAuthGuard],
                        providers: [
                            {
                                provide: RegisterVerificationTokenFormComponentService,
                                useClass: RegisterVerificationTokenFormComponentService,
                                deps: [
                                    AuthService,
                                    GlobalMessageService,
                                    VerificationTokenFacade,
                                    WindowRef,
                                ],
                            },
                        ],
                    },
                },
            }),
        ], imports: [CommonModule,
            FormsModule,
            KeyboardFocusModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            IconModule,
            I18nModule,
            FormErrorsModule,
            SpinnerModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            RegisterVerificationTokenFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RegisterVerificationTokenFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        FormsModule,
                        KeyboardFocusModule,
                        ReactiveFormsModule,
                        RouterModule,
                        UrlModule,
                        IconModule,
                        I18nModule,
                        FormErrorsModule,
                        SpinnerModule,
                        FeaturesConfigModule,
                        FormRequiredAsterisksComponent,
                        RegisterVerificationTokenFormComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                VerifyOTPForB2BRegistrationComponent: {
                                    component: RegisterVerificationTokenFormComponent,
                                    guards: [NotAuthGuard],
                                    providers: [
                                        {
                                            provide: RegisterVerificationTokenFormComponentService,
                                            useClass: RegisterVerificationTokenFormComponentService,
                                            deps: [
                                                AuthService,
                                                GlobalMessageService,
                                                VerificationTokenFacade,
                                                WindowRef,
                                            ],
                                        },
                                    ],
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserRegistrationComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationComponentsModule, imports: [RouterModule,
            UserRegistrationFormModule,
            UserRegistrationOTPFormModule,
            RegisterVerificationTokenFormModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationComponentsModule, imports: [RouterModule,
            UserRegistrationFormModule,
            UserRegistrationOTPFormModule,
            RegisterVerificationTokenFormModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegistrationComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        RouterModule,
                        UserRegistrationFormModule,
                        UserRegistrationOTPFormModule,
                        RegisterVerificationTokenFormModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { RegisterVerificationTokenFormComponent, RegisterVerificationTokenFormComponentService, RegisterVerificationTokenFormModule, UserRegistrationComponentsModule, UserRegistrationFormComponent, UserRegistrationFormModule, UserRegistrationFormService, UserRegistrationOTPFormComponent, UserRegistrationOTPFormModule };
//# sourceMappingURL=spartacus-organization-user-registration-components.mjs.map
