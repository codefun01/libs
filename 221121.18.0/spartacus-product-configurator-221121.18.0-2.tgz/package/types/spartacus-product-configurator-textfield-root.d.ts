import { CmsConfig } from '@spartacus/core';
import * as i0 from '@angular/core';
import { ModuleWithProviders } from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/product-configurator/common';
import * as i5 from '@angular/router';

declare const PRODUCT_CONFIGURATOR_TEXTFIELD_FEATURE = "productConfiguratorTextfield";

declare function defaultProductConfiguratorTextfieldComponentsConfig(): CmsConfig;
/**
 * Contains feature module configuration
 */
declare class TextfieldConfiguratorRootFeatureModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextfieldConfiguratorRootFeatureModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TextfieldConfiguratorRootFeatureModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TextfieldConfiguratorRootFeatureModule>;
}

/**
 * Provides the default cx routing configuration for the textfield configurator
 */
declare class TextfieldConfiguratorRoutingModule {
    static forRoot(): ModuleWithProviders<TextfieldConfiguratorRoutingModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextfieldConfiguratorRoutingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TextfieldConfiguratorRoutingModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TextfieldConfiguratorRoutingModule>;
}

/**
 * Exposes the root modules that we need to statically load. Contains page mappings
 */
declare class TextfieldConfiguratorRootModule {
    static forRoot(): ModuleWithProviders<TextfieldConfiguratorRootModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextfieldConfiguratorRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TextfieldConfiguratorRootModule, never, [typeof i1.CommonModule, typeof i2.CommonConfiguratorModule, typeof TextfieldConfiguratorRootFeatureModule, typeof TextfieldConfiguratorRoutingModule, typeof i5.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TextfieldConfiguratorRootModule>;
}

export { PRODUCT_CONFIGURATOR_TEXTFIELD_FEATURE, TextfieldConfiguratorRootFeatureModule, TextfieldConfiguratorRootModule, TextfieldConfiguratorRoutingModule, defaultProductConfiguratorTextfieldComponentsConfig };
