import * as i0 from '@angular/core';
import { ModuleWithProviders } from '@angular/core';
import * as i1 from '@angular/router';
import * as i2 from '@spartacus/storefront';
import { PageLayoutHandler, BreakpointService, LayoutConfig } from '@spartacus/storefront';
import { HttpErrorResponse, HttpRequest } from '@angular/common/http';
import { HttpErrorHandler, GlobalMessageService, HttpResponseStatus, Priority, ErrorModel, CmsConfig } from '@spartacus/core';
import * as i1$1 from '@angular/common';
import * as i2$1 from '@spartacus/product-configurator/common';
import { ConfiguratorRouterExtractorService, CommonConfiguratorUtilsService } from '@spartacus/product-configurator/common';
import { Observable } from 'rxjs';

/**
 *  Contains the layout configuration for the CPQ configurator pages. This configuration is
 *  optional as of version 4.2, and reduces the components that are rendered in the header section.
 *  It needs to be explicitly imported, otherwise the default configuration
 *  from CpqConfiguratorInteractiveModule is active
 */
declare class CpqConfiguratorLayoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqConfiguratorLayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CpqConfiguratorLayoutModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CpqConfiguratorLayoutModule>;
}

/**
 * Takes care of the interactive configuration process (the user enters new attribute values and navigates through the configuration).
 * Provides routing, assignment of ng components to CMS components and assignment of CMS components to the layout slots
 */
declare class CpqConfiguratorInteractiveModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqConfiguratorInteractiveModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CpqConfiguratorInteractiveModule, never, [typeof i1.RouterModule, typeof i2.HamburgerMenuModule, typeof CpqConfiguratorLayoutModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CpqConfiguratorInteractiveModule>;
}

/**
 * Takes care of the configuration overview that visualizes the attribute value assignments that have been done already in a condensed, read-only form.
 * The end-user can switch between the interactive view and this overview.
 * Provides routing, assignment of ng components to CMS components and assignment of CMS components to the layout slots.
 * Some of the ng components on this view (tab bar, price summary and addToCart button) are shared between the interactive view and the overview.
 */
declare class CpqConfiguratorOverviewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqConfiguratorOverviewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CpqConfiguratorOverviewModule, never, [typeof i1.RouterModule, typeof CpqConfiguratorLayoutModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CpqConfiguratorOverviewModule>;
}

/**
 * Exposes the CPQ aspects that we need to load eagerly, like page mappings, routing
 * and interceptor related entities
 */
declare class CpqConfiguratorRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqConfiguratorRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CpqConfiguratorRootModule, never, [typeof CpqConfiguratorInteractiveModule, typeof CpqConfiguratorOverviewModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CpqConfiguratorRootModule>;
}

declare const PRODUCT_CONFIGURATOR_RULEBASED_FEATURE = "productConfiguratorRulebased";

declare class ConfiguratorBadRequestHandler extends HttpErrorHandler {
    protected globalMessageService: GlobalMessageService;
    responseStatus: HttpResponseStatus;
    constructor(globalMessageService: GlobalMessageService);
    getPriority(): Priority;
    hasMatch(errorResponse: HttpErrorResponse): boolean;
    handleError(_request: HttpRequest<any>, response: HttpErrorResponse): void;
    protected handleIllegalArgumentIssues(message: string): void;
    protected isNotEmpty(errors: ErrorModel[]): boolean;
    protected isIllegalStateErrorRelatedToMakeToStock(message: string): boolean;
    protected isIllegalStateErrorRelatedToProductConfigurator(message?: string): boolean | "" | undefined;
    protected getIllegalStateErrorsRelatedToProductConfigurator(response: HttpErrorResponse): ErrorModel[];
    protected isRelatedToProductConfigurator(response: HttpErrorResponse): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorBadRequestHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorBadRequestHandler>;
}

declare function defaultProductConfiguratorRulebasedComponentsConfig(): CmsConfig;
/**
 * Contains feature module configuration
 */
declare class RulebasedConfiguratorRootFeatureModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RulebasedConfiguratorRootFeatureModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RulebasedConfiguratorRootFeatureModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RulebasedConfiguratorRootFeatureModule>;
}

/**
 *  Contains the layout configuration for the interactive configuration page. This configuration is
 *  optional as of version 4.2, and reduces the components that are rendered in the header section.
 *  It needs to be explicitly imported, otherwise the default configuration
 *  from VariantConfiguratorInteractiveModule is active
 */
declare class VariantConfiguratorInteractiveLayoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VariantConfiguratorInteractiveLayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VariantConfiguratorInteractiveLayoutModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VariantConfiguratorInteractiveLayoutModule>;
}

/**
 * Takes care of the interactive configuration process (the user enters new attribute values and navigates through the configuration).
 * Provides routing, assignment of ng components to CMS components and assignment of CMS components to the layout slots
 */
declare class VariantConfiguratorInteractiveModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VariantConfiguratorInteractiveModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VariantConfiguratorInteractiveModule, never, [typeof i1.RouterModule, typeof i2.HamburgerMenuModule, typeof VariantConfiguratorInteractiveLayoutModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VariantConfiguratorInteractiveModule>;
}

/**
 *  Contains the layout configuration for the overview configuration page. This configuration is
 *  optional as of version 4.2, and reduces the components that are rendered in the header section.
 *  It needs to be explicitly imported, otherwise the default configuration
 *  from VariantConfiguratorOverviewModule is active
 */
declare class VariantConfiguratorOverviewLayoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VariantConfiguratorOverviewLayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VariantConfiguratorOverviewLayoutModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VariantConfiguratorOverviewLayoutModule>;
}

/**
 * Takes care of the configuration overview that visualizes the attribute value assignments that have been done already in a condensed, read-only form.
 * The end-user can switch between the interactive view and this overview.
 * Provides routing, assignment of ng components to CMS components and assignment of CMS components to the layout slots.
 * Some of the ng components on this view (tab bar, price summary and addToCart button) are shared between the interactive view and the overview.
 */
declare class VariantConfiguratorOverviewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VariantConfiguratorOverviewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VariantConfiguratorOverviewModule, never, [typeof i1.RouterModule, typeof VariantConfiguratorOverviewLayoutModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VariantConfiguratorOverviewModule>;
}

/**
 * Provides the default cx routing configuration for the rulebased configurator
 */
declare class RulebasedConfiguratorRoutingModule {
    static forRoot(): ModuleWithProviders<RulebasedConfiguratorRoutingModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RulebasedConfiguratorRoutingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RulebasedConfiguratorRoutingModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RulebasedConfiguratorRoutingModule>;
}

/**
 * Exposes the root modules that we need to load statically. Contains page mappings, route configurations
 * and feature configuration
 */
declare class RulebasedConfiguratorRootModule {
    static forRoot(): ModuleWithProviders<RulebasedConfiguratorRootModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RulebasedConfiguratorRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RulebasedConfiguratorRootModule, never, [typeof i1$1.CommonModule, typeof i2$1.CommonConfiguratorModule, typeof RulebasedConfiguratorRootFeatureModule, typeof VariantConfiguratorInteractiveModule, typeof VariantConfiguratorOverviewModule, typeof RulebasedConfiguratorRoutingModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RulebasedConfiguratorRootModule>;
}

declare class VariantConfiguratorPageLayoutHandler implements PageLayoutHandler {
    protected configuratorRouterExtractorService: ConfiguratorRouterExtractorService;
    protected breakpointService: BreakpointService;
    protected layoutConfig: LayoutConfig;
    protected commonConfiguratorUtilsService: CommonConfiguratorUtilsService;
    protected static templateName: string;
    protected static sectionDisplayOnlyName: string;
    constructor(configuratorRouterExtractorService: ConfiguratorRouterExtractorService, breakpointService: BreakpointService, layoutConfig: LayoutConfig, commonConfiguratorUtilsService: CommonConfiguratorUtilsService);
    handle(slots$: Observable<string[]>, pageTemplate?: string, section?: string): Observable<string[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<VariantConfiguratorPageLayoutHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VariantConfiguratorPageLayoutHandler>;
}

export { ConfiguratorBadRequestHandler, CpqConfiguratorInteractiveModule, CpqConfiguratorLayoutModule, CpqConfiguratorOverviewModule, CpqConfiguratorRootModule, PRODUCT_CONFIGURATOR_RULEBASED_FEATURE, RulebasedConfiguratorRootFeatureModule, RulebasedConfiguratorRootModule, RulebasedConfiguratorRoutingModule, VariantConfiguratorInteractiveLayoutModule, VariantConfiguratorInteractiveModule, VariantConfiguratorOverviewLayoutModule, VariantConfiguratorOverviewModule, VariantConfiguratorPageLayoutHandler, defaultProductConfiguratorRulebasedComponentsConfig };
