import * as i3$1 from '@ngrx/store';
import { Store } from '@ngrx/store';
import { ActiveCartFacade, CartModification } from '@spartacus/cart/base/root';
import * as i5 from '@spartacus/core';
import { StateUtils, UserIdService, OccEndpoint, Converter, OccEndpointsService, ConverterService } from '@spartacus/core';
import { CommonConfigurator, CommonConfiguratorUtilsService, ConfiguratorRouterExtractorService } from '@spartacus/product-configurator/common';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import { OnInit, EventEmitter } from '@angular/core';
import * as i2 from '@angular/forms';
import { UntypedFormControl } from '@angular/forms';
import * as i1 from '@angular/router';
import * as i3 from '@ng-select/ng-select';
import * as i1$1 from '@angular/common';
import * as i4 from '@ngrx/effects';
import { HttpClient } from '@angular/common/http';

declare namespace ConfiguratorTextfield {
    /**
     * Textfield configuration. Consists of a list of attributes and the configuration owner
     */
    interface Configuration {
        configurationInfos: ConfigurationInfo[];
        owner: CommonConfigurator.Owner;
    }
    /**
     * Represents a textfield configuration attribute. Carries a label, an alphanumeric value and a status
     */
    interface ConfigurationInfo {
        configurationLabel: string;
        configurationValue?: string;
        status?: ConfigurationStatus;
    }
    /**
     * Textfield configuration status
     */
    enum ConfigurationStatus {
        SUCCESS = "SUCCESS",
        ERROR = "ERROR"
    }
    /**
     * Collection of parameters needed to add a textfield product to the cart
     */
    interface AddToCartParameters {
        userId: string;
        cartId: string;
        productCode: string;
        quantity: number;
        configuration?: Configuration;
    }
    /**
     * Collection of parameters needed to update the configuration that is attached
     * to a cart entry
     */
    interface UpdateCartEntryParameters {
        userId: string;
        cartId: string;
        cartEntryNumber: string;
        configuration?: Configuration;
    }
}

declare const CONFIGURATION_TEXTFIELD_FEATURE = "productConfigurationTextfield";
interface StateWithConfigurationTextfield {
    [CONFIGURATION_TEXTFIELD_FEATURE]: ConfigurationTextfieldState;
}
interface ConfigurationTextfieldState {
    loaderState: StateUtils.LoaderState<ConfiguratorTextfield.Configuration>;
}

declare class ConfiguratorTextfieldService {
    protected store: Store<StateWithConfigurationTextfield>;
    protected activeCartService: ActiveCartFacade;
    protected configuratorUtils: CommonConfiguratorUtilsService;
    protected userIdService: UserIdService;
    constructor(store: Store<StateWithConfigurationTextfield>, activeCartService: ActiveCartFacade, configuratorUtils: CommonConfiguratorUtilsService, userIdService: UserIdService);
    protected ensureConfigurationDefined: (value?: ConfiguratorTextfield.Configuration) => ConfiguratorTextfield.Configuration;
    /**
     * Creates a default textfield configuration for a product specified by the configuration owner.
     *
     * @param owner - Configuration owner
     *
     * @returns {Observable<ConfiguratorTextfield.Configuration>}
     */
    createConfiguration(owner: CommonConfigurator.Owner): Observable<ConfiguratorTextfield.Configuration>;
    /**
     * Updates a textfield configuration, specified by the changed attribute.
     *
     * @param changedAttribute - Changed attribute
     */
    updateConfiguration(changedAttribute: ConfiguratorTextfield.ConfigurationInfo): void;
    /**
     * Adds the textfield configuration to the cart
     *
     * @param productCode - Product code of the configuration root product. Cart entry carries refers to this product
     * @param configuration Textfield configuration
     */
    addToCart(productCode: string, configuration: ConfiguratorTextfield.Configuration): void;
    /**
     * Updates a cart entry, specified by its cart entry number.
     *
     * @param cartEntryNumber - Cart entry number
     * @param configuration Textfield configuration (list of alphanumeric attributes)
     */
    updateCartEntry(cartEntryNumber: string, configuration: ConfiguratorTextfield.Configuration): void;
    /**
     * Returns a textfield configuration for a cart entry.
     *
     * @param owner - Configuration owner
     *
     * @returns {Observable<ConfiguratorTextfield.Configuration>}
     */
    readConfigurationForCartEntry(owner: CommonConfigurator.Owner): Observable<ConfiguratorTextfield.Configuration>;
    /**
     * Returns the textfield configuration attached to an order entry.
     *
     * @param {CommonConfigurator.Owner} owner - Configuration owner
     *
     * @returns {Observable<ConfiguratorTextfield.Configuration>}
     */
    readConfigurationForOrderEntry(owner: CommonConfigurator.Owner): Observable<ConfiguratorTextfield.Configuration>;
    /**
     * Creates a textfield configuration supposed to be sent to the backend when an attribute
     * has been changed
     * @param changedAttribute Attribute changed by the end user
     * @param oldConfiguration Existing configuration to which the attribute change is applied to
     * @returns Textfield configuration (merge of existing configuration and the changed attribute)
     */
    createNewConfigurationWithChange(changedAttribute: ConfiguratorTextfield.ConfigurationInfo, oldConfiguration: ConfiguratorTextfield.Configuration): ConfiguratorTextfield.Configuration;
    protected isConfigurationInitial(configuration?: ConfiguratorTextfield.Configuration): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorTextfieldService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorTextfieldService>;
}

declare class ConfiguratorTextfieldAddToCartButtonComponent {
    protected configuratorTextfieldService: ConfiguratorTextfieldService;
    configuration: ConfiguratorTextfield.Configuration;
    productCode: string;
    constructor(configuratorTextfieldService: ConfiguratorTextfieldService);
    /**
     * Adds the textfield configuration to the cart or updates it
     */
    onAddToCart(): void;
    /**
     * Returns button description. Button will display 'addToCart' or 'done' in case configuration indicates that owner is a cart entry
     * @returns Resource key of button description
     */
    getButtonText(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorTextfieldAddToCartButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorTextfieldAddToCartButtonComponent, "cx-configurator-textfield-add-to-cart-button", never, { "configuration": { "alias": "configuration"; "required": false; }; "productCode": { "alias": "productCode"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ConfiguratorTextfieldFormComponent {
    protected configuratorTextfieldService: ConfiguratorTextfieldService;
    protected configRouterExtractorService: ConfiguratorRouterExtractorService;
    configuration$: Observable<ConfiguratorTextfield.Configuration>;
    isEditable$: Observable<boolean>;
    constructor(configuratorTextfieldService: ConfiguratorTextfieldService, configRouterExtractorService: ConfiguratorRouterExtractorService);
    /**
     * Updates a configuration attribute
     * @param attribute - Configuration attribute, always containing a string typed value
     */
    updateConfiguration(attribute: ConfiguratorTextfield.ConfigurationInfo): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorTextfieldFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorTextfieldFormComponent, "cx-configurator-textfield-form", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorTextfieldInputFieldComponent implements OnInit {
    PREFIX_TEXTFIELD: string;
    attributeInputForm: UntypedFormControl;
    attribute: ConfiguratorTextfield.ConfigurationInfo;
    inputChange: EventEmitter<ConfiguratorTextfield.ConfigurationInfo>;
    constructor();
    ngOnInit(): void;
    /**
     * Triggered if an attribute value is changed. Triggers the emission of the inputChange event emitter that is
     * in turn received in the form component
     */
    onInputChange(): void;
    /**
     * Compiles an ID for the attribute label by using the label from the backend and a prefix 'label'
     * @param attribute Textfield configurator attribute. Carries the attribute label information from the backend
     * @returns ID
     */
    getIdLabel(attribute: ConfiguratorTextfield.ConfigurationInfo): string;
    /**
     * Compiles an ID for the attribute value by using the label from the backend
     * @param attribute Textfield configurator attribute. Carries the attribute label information from the backend
     * @returns ID
     */
    getId(attribute: ConfiguratorTextfield.ConfigurationInfo): string;
    protected getLabelForIdGeneration(attribute: ConfiguratorTextfield.ConfigurationInfo): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorTextfieldInputFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorTextfieldInputFieldComponent, "cx-configurator-textfield-input-field", never, { "attribute": { "alias": "attribute"; "required": false; }; }, { "inputChange": "inputChange"; }, never, never, true, never>;
}

declare class ConfiguratorTextfieldInputFieldReadonlyComponent {
    PREFIX_TEXTFIELD: string;
    attribute: ConfiguratorTextfield.ConfigurationInfo;
    /**
     * Compiles an ID for the attribute label by using the label from the backend and a prefix 'label'
     * @param {ConfiguratorTextfield.ConfigurationInfo} attribute Textfield configurator attribute. Carries the attribute label information from the backend
     * @returns {string} ID
     */
    getIdLabel(attribute: ConfiguratorTextfield.ConfigurationInfo): string;
    protected getLabelForIdGeneration(attribute: ConfiguratorTextfield.ConfigurationInfo): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorTextfieldInputFieldReadonlyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorTextfieldInputFieldReadonlyComponent, "cx-configurator-textfield-input-field-readonly", never, { "attribute": { "alias": "attribute"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TextfieldConfiguratorComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextfieldConfiguratorComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TextfieldConfiguratorComponentsModule, never, [typeof i1.RouterModule, typeof i2.FormsModule, typeof i2.ReactiveFormsModule, typeof i3.NgSelectModule, typeof i1$1.CommonModule, typeof i5.I18nModule, typeof i5.UrlModule, typeof ConfiguratorTextfieldFormComponent, typeof ConfiguratorTextfieldInputFieldComponent, typeof ConfiguratorTextfieldInputFieldReadonlyComponent, typeof ConfiguratorTextfieldAddToCartButtonComponent], [typeof ConfiguratorTextfieldFormComponent, typeof ConfiguratorTextfieldInputFieldComponent, typeof ConfiguratorTextfieldInputFieldReadonlyComponent, typeof ConfiguratorTextfieldAddToCartButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TextfieldConfiguratorComponentsModule>;
}

declare class ConfiguratorTextfieldStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorTextfieldStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorTextfieldStoreModule, never, [typeof i1$1.CommonModule, typeof i5.StateModule, typeof i3$1.StoreFeatureModule, typeof i4.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorTextfieldStoreModule>;
}

/**
 * Exposes the textfield configurator core entities.
 * Explicit providing of connector because otherwise lazy loading does not work
 */
declare class TextfieldConfiguratorCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextfieldConfiguratorCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TextfieldConfiguratorCoreModule, never, [typeof ConfiguratorTextfieldStoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TextfieldConfiguratorCoreModule>;
}

declare module '@spartacus/core' {
    interface OccEndpoints {
        readTextfieldConfigurationForOrderEntry?: string | OccEndpoint;
        readTextfieldConfigurationForQuoteEntry?: string | OccEndpoint;
    }
}

declare namespace OccConfiguratorTextfield {
    /**
     * An interface representing the textfield configuration consumed through OCC.
     */
    interface Configuration {
        configurationInfos: ConfigurationInfo[];
    }
    interface ConfigurationInfo {
        configurationLabel?: string;
        configurationValue?: string;
        status?: string;
        configuratorType?: string;
    }
    interface AddToCartParameters {
        userId?: string;
        cartId?: string;
        product?: AddToCartProductData;
        quantity?: number;
        configurationInfos?: ConfigurationInfo[];
    }
    interface UpdateCartEntryParameters {
        userId?: string;
        cartId?: string;
        cartEntryNumber?: string;
        configurationInfos?: ConfigurationInfo[];
    }
    interface AddToCartProductData {
        code?: string;
    }
}

declare const CONFIGURATOR_TYPE_TEXTFIELD = "TEXTFIELD";
declare class OccConfiguratorTextfieldAddToCartSerializer implements Converter<ConfiguratorTextfield.AddToCartParameters, OccConfiguratorTextfield.AddToCartParameters> {
    constructor();
    /**
     * Converts addToCart parameters into the OCC format
     * @param source Add to cart parameters in generic format
     * @param target Add to cart parameters in OCC format. Optional, can be used in case converters should be chained
     * @returns Add to cart parameters in OCC format
     */
    convert(source: ConfiguratorTextfield.AddToCartParameters, target?: OccConfiguratorTextfield.AddToCartParameters): OccConfiguratorTextfield.AddToCartParameters;
    protected convertInfo(source: ConfiguratorTextfield.ConfigurationInfo, occConfigurationInfos: OccConfiguratorTextfield.ConfigurationInfo[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccConfiguratorTextfieldAddToCartSerializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccConfiguratorTextfieldAddToCartSerializer>;
}

declare class OccConfiguratorTextfieldNormalizer implements Converter<OccConfiguratorTextfield.Configuration, ConfiguratorTextfield.Configuration> {
    constructor();
    /**
     * Converts addToCart parameters into the generic format
     * @param source Add to cart parameters in OCC format
     * @param target Optional result, can be provided in case converters should be chained
     * @returns Add to cart parameters in generic format
     */
    convert(source: OccConfiguratorTextfield.Configuration, target?: ConfiguratorTextfield.Configuration): ConfiguratorTextfield.Configuration;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccConfiguratorTextfieldNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccConfiguratorTextfieldNormalizer>;
}

declare abstract class ConfiguratorTextfieldAdapter {
    /**
     * Abstract method used to create a default configuration based on product code
     * and owner
     *
     * @param productCode Root product code
     * @param owner Configuration owner
     * @returns Observable of configurations
     */
    abstract createConfiguration(productCode: string, owner: CommonConfigurator.Owner): Observable<ConfiguratorTextfield.Configuration>;
    /**
     * Abstract method to add a configuration to cart, based on a product, a configuration,
     * and other attributes part of parameters
     *
     * @param parameters add to cart parameters object
     * @returns Observable of cart modifications
     */
    abstract addToCart(parameters: ConfiguratorTextfield.AddToCartParameters): Observable<CartModification>;
    /**
     * Abstract method to read a configuration for a cart entry
     *
     * @param parameters read from cart entry parameters object
     * @returns Observable of configurations
     */
    abstract readConfigurationForCartEntry(parameters: CommonConfigurator.ReadConfigurationFromCartEntryParameters): Observable<ConfiguratorTextfield.Configuration>;
    /**
     * Abstract method to read a configuration for an order entry
     *
     * @param {CommonConfigurator.ReadConfigurationFromOrderEntryParameters} parameters read from order entry parameters object
     * @returns {Observable<ConfiguratorTextfield.Configuration>} Observable of configurations
     */
    abstract readConfigurationForOrderEntry(parameters: CommonConfigurator.ReadConfigurationFromOrderEntryParameters): Observable<ConfiguratorTextfield.Configuration>;
    /**
     * Abstract method to update a configuration attached to a cart entry
     *
     * @param parameters contains attributes needed to update the cart entries' configuration
     * @returns Observable of cart modifications
     */
    abstract updateConfigurationForCartEntry(parameters: ConfiguratorTextfield.UpdateCartEntryParameters): Observable<CartModification>;
}

declare class OccConfiguratorTextfieldAdapter implements ConfiguratorTextfieldAdapter {
    protected http: HttpClient;
    protected occEndpointsService: OccEndpointsService;
    protected converterService: ConverterService;
    constructor(http: HttpClient, occEndpointsService: OccEndpointsService, converterService: ConverterService);
    createConfiguration(productCode: string, owner: CommonConfigurator.Owner): Observable<ConfiguratorTextfield.Configuration>;
    addToCart(parameters: ConfiguratorTextfield.AddToCartParameters): Observable<CartModification>;
    readConfigurationForCartEntry(parameters: CommonConfigurator.ReadConfigurationFromCartEntryParameters): Observable<ConfiguratorTextfield.Configuration>;
    readConfigurationForOrderEntry(parameters: CommonConfigurator.ReadConfigurationFromOrderEntryParameters): Observable<ConfiguratorTextfield.Configuration>;
    updateConfigurationForCartEntry(parameters: ConfiguratorTextfield.UpdateCartEntryParameters): Observable<CartModification>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccConfiguratorTextfieldAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccConfiguratorTextfieldAdapter>;
}

declare class TextfieldConfiguratorOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextfieldConfiguratorOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TextfieldConfiguratorOccModule, never, [typeof i1$1.CommonModule, typeof i5.ConfigModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TextfieldConfiguratorOccModule>;
}

/**
 * Exposes the textfield configurator, a small configurator that only provides 3 attributes at product level without any dependencies between them,
 * and in the first place serves as a template for other configurator implementations.
 */
declare class TextfieldConfiguratorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TextfieldConfiguratorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TextfieldConfiguratorModule, never, [typeof TextfieldConfiguratorCoreModule, typeof TextfieldConfiguratorComponentsModule, typeof TextfieldConfiguratorOccModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TextfieldConfiguratorModule>;
}

export { CONFIGURATOR_TYPE_TEXTFIELD, ConfiguratorTextfieldAddToCartButtonComponent, ConfiguratorTextfieldFormComponent, ConfiguratorTextfieldInputFieldComponent, ConfiguratorTextfieldInputFieldReadonlyComponent, OccConfiguratorTextfieldAdapter, OccConfiguratorTextfieldAddToCartSerializer, OccConfiguratorTextfieldNormalizer, TextfieldConfiguratorComponentsModule, TextfieldConfiguratorCoreModule, TextfieldConfiguratorModule, TextfieldConfiguratorOccModule };
