import * as i0 from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/core';
import { UserIdService, RoutingService, LoggerService, TranslationService, Product, RouterState } from '@spartacus/core';
import * as i3 from '@spartacus/storefront';
import { LayoutConfig, BREAKPOINT, ICON_TYPE, BreakpointService, ProductListItemContext, CurrentProductService } from '@spartacus/storefront';
import * as i4 from '@angular/router';
import { AbstractOrderContext } from '@spartacus/cart/base/components';
import { Cart, OrderEntry, CartItemContext, AbstractOrderKey } from '@spartacus/cart/base/root';
import { Observable } from 'rxjs';
import { UntypedFormControl } from '@angular/forms';

declare class CommonConfiguratorOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonConfiguratorOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CommonConfiguratorOccModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CommonConfiguratorOccModule>;
}

declare namespace CommonConfigurator {
    /**
     * Specifies the owner of a product configuration
     */
    interface Owner {
        /**
         * Type of the owner, can be product or document related
         */
        type: OwnerType;
        /**
         * Specifies an owner uniquely, is used as key in the configuration store
         */
        key: string;
        /**
         * Business identifier of the owner.
         * Can be a product code, a cart entry number, or an order code with order entry number
         */
        id: string;
        /**
         * Configurator type. Derived from the cxRoute
         */
        configuratorType: string;
    }
    interface ReadConfigurationFromCartEntryParameters {
        userId?: string;
        cartId?: string;
        cartEntryNumber?: string;
        owner: CommonConfigurator.Owner;
    }
    interface ReadConfigurationFromOrderEntryParameters {
        userId?: string;
        orderId?: string;
        orderEntryNumber?: string;
        owner: CommonConfigurator.Owner;
    }
    /**
     * Possible types of owners: Product, cart or order entry
     */
    enum OwnerType {
        PRODUCT = "product",
        CART_ENTRY = "cartEntry",
        ORDER_ENTRY = "orderEntry",
        QUOTE_ENTRY = "quoteEntry",
        SAVED_CART_ENTRY = "savedCartEntry"
    }
}
/**
 * Possible configurator types
 */
declare enum ConfiguratorType {
    CPQ = "CLOUDCPQCONFIGURATOR",
    VARIANT = "CPQCONFIGURATOR",
    TEXTFIELD = "TEXTFIELD"
}
/**
 * Configurator types including this postfix are
 * treated as view-only
 */
declare const ReadOnlyPostfix = "_READ_ONLY";
/**
 * Statuses that can occur in the generic configuration
 * status summary
 */
declare enum OrderEntryStatus {
    Success = "SUCCESS",
    Info = "INFO",
    Warning = "WARNING",
    Error = "ERROR"
}
/**
 * Status Summary
 */
interface StatusSummary {
    numberOfIssues?: number;
    status?: OrderEntryStatus;
}
/**
 * Configuration information attached to a cart or order entry.
 * Does not reflect the entire configuration but gives only a summary,
 * in order to better identify different configurations in a cart or order.
 */
interface ConfigurationInfo {
    configurationLabel?: string;
    configurationValue?: string;
    configuratorType?: string;
    status?: string;
}
/**
 *
 * An enum representing ConfigurationInfo fields.
 */
declare enum ConfigurationInfoFields {
    KEY = "KEY",
    NAME = "NAME",
    QTY = "QTY",
    FORMATTED_PRICE = "FORMATTED_PRICE",
    PRICE_VALUE = "PRICE_VALUE",
    PARENT = "PARENT"
}
/**
 *
 * An enum representing ConfigurationInfo special fields.
 */
declare enum ConfigurationInfoSpecialFields {
    VERSION = "CI#@#VERSION",
    CURRENCY = "CI#@#CURRENCY",
    LINE_ITEM = "LI",
    LINE_ITEM_DELIMITER = "#"
}

/**
 * Utilities for generic configuration
 */
declare class CommonConfiguratorUtilsService {
    protected userIdService: UserIdService;
    constructor(userIdService: UserIdService);
    /**
     * Compiles a unique key for a configuration owner and sets it into the 'key'
     * attribute
     * @param {CommonConfigurator.Owner }owner - Specifies the owner of a product configuration
     */
    setOwnerKey(owner: CommonConfigurator.Owner): void;
    /**
     * Composes owner ID from document ID and entry number
     * @param {string} documentId - ID of document the entry is part of, like the order or quote code
     * @param {string} entryNumber - Entry number
     * @returns {string} - owner ID
     */
    getComposedOwnerId(documentId: string, entryNumber: number): string;
    /**
     * Decomposes an owner ID into documentId and entryNumber
     * @param {string} ownerId - ID of owner
     * @returns {any} object containing documentId and entryNumber
     */
    decomposeOwnerId(ownerId: string): any;
    /**
     * Gets cart ID (which can be either its guid or its code)
     * @param {Cart} cart - Cart
     * @returns {string} - Cart identifier
     */
    getCartId(cart?: Cart): string;
    /**
     * Verifies whether the item has any issues.
     *
     * @param {OrderEntry} cartItem - Cart item
     * @returns {boolean} - whether there are any issues
     */
    hasIssues(cartItem: OrderEntry): boolean;
    /**
     * Retrieves the number of issues at the cart item.
     *
     * @param {OrderEntry} cartItem - Cart item
     * @returns {number} - the number of issues at the cart item
     */
    getNumberOfIssues(cartItem: OrderEntry): number;
    /**
     * Verifies whether the configurator type is an attribute based one.
     *
     * @param {string} configuratorType - Configurator type
     * @returns {boolean} - 'True' if the expected configurator type, otherwise 'false'
     */
    isAttributeBasedConfigurator(configuratorType: string | undefined): boolean;
    /**
     * Verifies whether the configurator type is a bundle based one.
     *
     * @param {string} configuratorType - Configurator type
     * @returns {boolean} - 'True' if the expected configurator type, otherwise 'fasle'
     */
    isBundleBasedConfigurator(configuratorType: string | undefined): boolean;
    /**
     * Determines whether we are in the context of an active cart
     * @param cartItemContext Cart item context
     * @returns Item part of an active cart?
     */
    isActiveCartContext(cartItemContext: CartItemContext | undefined): Observable<boolean>;
    /**
     * Reads slots from layout config, taking the breakpoint into account
     * @param layoutConfig Layout config
     * @param templateName Page template name
     * @param sectionName Section name like 'header'
     * @param breakPoint Current breakpoint
     * @returns Array of slots
     */
    getSlotsFromLayoutConfiguration(layoutConfig: LayoutConfig, templateName: string, sectionName: string, breakPoint: BREAKPOINT.lg | BREAKPOINT.md | BREAKPOINT.sm | BREAKPOINT.xs): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonConfiguratorUtilsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CommonConfiguratorUtilsService>;
}

declare class ConfigureCartEntryComponent {
    protected commonConfigUtilsService: CommonConfiguratorUtilsService;
    protected routingService: RoutingService;
    cartEntry: OrderEntry;
    readOnly: boolean;
    msgBanner: boolean;
    disabled: boolean;
    abstractOrderContext: AbstractOrderContext | null;
    abstractOrderKey$: Observable<AbstractOrderKey>;
    queryParams$: Observable<{
        forceReload: boolean;
        resolveIssues: boolean;
        navigateToCheckout: boolean;
        productCode: string | undefined;
    }>;
    /**
     * Verifies whether the entry has any issues.
     *
     * @returns - whether there are any issues
     */
    hasIssues(): boolean;
    /**
     * Retrieves owner for an abstract order type
     *
     * @returns - an owner type
     */
    retrieveOwnerTypeFromAbstractOrderType(abstractOrderKey: AbstractOrderKey): CommonConfigurator.OwnerType;
    /**
     * Verifies whether the cart entry has an order code, retrieves a composed owner ID
     * and concatenates a corresponding entry number.
     *
     * @returns - an entry key
     */
    retrieveEntityKey(abstractOrderKey: AbstractOrderKey): string;
    /**
     * Retrieves a corresponding route depending whether the configuration is read only or not.
     *
     * @returns - a route
     */
    getRoute(): string;
    /**
     * Retrieves the state of the configuration.
     *
     *  @returns - 'true' if the configuration is read only or configurator type contains a read-only postfix, otherwise 'false'
     */
    getDisplayOnly(): boolean;
    /**
     * Verifies whether the link to the configuration is disabled.
     *
     *  @returns - 'true' if the the configuration is not read only, otherwise 'false'
     */
    isDisabled(): boolean;
    /**
     * Retrieves the additional resolve issues accessibility description.
     *
     * @returns - If there is a 'resolve issues' link, the ID to the element with additional description will be returned.
     */
    getResolveIssuesA11yDescription(): string | undefined;
    protected isInCheckout(): Observable<boolean>;
    constructor(commonConfigUtilsService: CommonConfiguratorUtilsService);
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfigureCartEntryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfigureCartEntryComponent, "cx-configure-cart-entry", never, { "cartEntry": { "alias": "cartEntry"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "msgBanner": { "alias": "msgBanner"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ConfigureCartEntryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfigureCartEntryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfigureCartEntryModule, never, [typeof i1.CommonModule, typeof i2.UrlModule, typeof i2.I18nModule, typeof i3.IconModule, typeof i4.RouterModule, typeof ConfigureCartEntryComponent], [typeof ConfigureCartEntryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfigureCartEntryModule>;
}

declare class ConfiguratorIssuesNotificationComponent {
    protected commonConfigUtilsService: CommonConfiguratorUtilsService;
    protected cartItemContext: CartItemContext;
    iconTypes: typeof ICON_TYPE;
    constructor(commonConfigUtilsService: CommonConfiguratorUtilsService, cartItemContext: CartItemContext);
    readonly orderEntry$: Observable<OrderEntry>;
    readonly quantityControl$: Observable<UntypedFormControl>;
    readonly readonly$: Observable<boolean>;
    readonly shouldShowButton$: Observable<boolean>;
    /**
     * Verifies whether the item has any issues.
     *
     * @param item - Cart item
     * @returns - whether there are any issues
     */
    hasIssues(item: OrderEntry): boolean;
    /**
     * Retrieves the number of issues at the cart item.
     *
     * @param item - Cart item
     * @returns - the number of issues at the cart item
     */
    getNumberOfIssues(item: OrderEntry): number;
    /**
     * Retrieves the unique id for the error message.
     *
     * @param item - Cart item
     * @returns - Unique id for error message
     */
    getErrorMessageId(item: OrderEntry): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorIssuesNotificationComponent, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorIssuesNotificationComponent, "cx-configurator-issues-notification", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorIssuesNotificationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorIssuesNotificationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorIssuesNotificationModule, never, [typeof i1.CommonModule, typeof i2.UrlModule, typeof i2.I18nModule, typeof i3.IconModule, typeof ConfigureCartEntryModule, typeof ConfiguratorIssuesNotificationComponent], [typeof ConfiguratorIssuesNotificationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorIssuesNotificationModule>;
}

declare class ConfiguratorCartEntryInfoComponent {
    protected cartItemContext: CartItemContext;
    protected commonConfigUtilsService: CommonConfiguratorUtilsService;
    constructor(cartItemContext: CartItemContext, commonConfigUtilsService: CommonConfiguratorUtilsService);
    readonly orderEntry$: Observable<OrderEntry>;
    readonly quantityControl$: Observable<UntypedFormControl>;
    readonly readonly$: Observable<boolean>;
    readonly shouldShowButton$: Observable<boolean>;
    /**
     * Verifies whether the configuration infos have any entries and the first entry has a status.
     * Only in this case we want to display the configuration summary
     *
     * @param {OrderEntry} item - Cart item
     * @returns {boolean} - whether the status of configuration infos entry has status
     */
    hasStatus(item: OrderEntry): boolean;
    /**
     * Verifies whether the configurator type is attribute based one.
     *
     * @param {OrderEntry} item - Order entry item
     * @returns {boolean} - 'True' if the expected configurator type, otherwise 'fasle'
     */
    isAttributeBasedConfigurator(item: OrderEntry): boolean;
    getHiddenConfigurationInfoId(index: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorCartEntryInfoComponent, [{ optional: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorCartEntryInfoComponent, "cx-configurator-cart-entry-info", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorCartEntryInfoModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorCartEntryInfoModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorCartEntryInfoModule, never, [typeof i1.CommonModule, typeof i2.UrlModule, typeof i2.I18nModule, typeof i3.IconModule, typeof ConfiguratorIssuesNotificationModule, typeof ConfigureCartEntryModule, typeof ConfiguratorCartEntryInfoComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorCartEntryInfoModule>;
}

/**
 * An interface representing the CPQ Line item from order entry.
 */
interface LineItem {
    name?: string;
    formattedQuantity?: string;
    formattedPrice?: string;
}

/**
 * Service for mapping of the CPQ line items from order entry
 */
declare class ConfiguratorCartEntryBundleInfoService {
    protected logger: LoggerService;
    /**
     * Retrieves the CPQ line items for an order entry
     *
     * @param {OrderEntry} entry - Order entry
     * @returns {LineItem[]} - Line item array
     */
    retrieveLineItems(entry: OrderEntry): LineItem[];
    protected prepareLineItem(configurationInfo: ConfigurationInfo): LineItem;
    protected removeDelimiter(label: string): string;
    protected processConfigurationInfos(configurationInfos: ConfigurationInfo[]): LineItem[];
    protected processConfigurationInfoEntry(lineItemMap: Map<number, LineItem>, configurationInfo: ConfigurationInfo): void;
    protected addLineItemData(lineItemMap: Map<number, LineItem>, configurationInfoSplit: string[], configurationInfoValue: string): void;
    protected getOrCreateLineItem(lineItemMap: Map<number, LineItem>, lineItemNumber: number): LineItem;
    protected logWarning(text: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorCartEntryBundleInfoService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorCartEntryBundleInfoService>;
}

/**
 * Requires default change detection strategy, as the disabled state of the quantity from control may change,
 * which would not be proper detected with onPush strategy.
 */
declare class ConfiguratorCartEntryBundleInfoComponent {
    protected commonConfigUtilsService: CommonConfiguratorUtilsService;
    protected configCartEntryBundleInfoService: ConfiguratorCartEntryBundleInfoService;
    protected breakpointService: BreakpointService;
    protected translation: TranslationService;
    protected cartItemContext?: CartItemContext | undefined;
    constructor(commonConfigUtilsService: CommonConfiguratorUtilsService, configCartEntryBundleInfoService: ConfiguratorCartEntryBundleInfoService, breakpointService: BreakpointService, translation: TranslationService, cartItemContext?: CartItemContext | undefined);
    readonly orderEntry$: Observable<OrderEntry>;
    readonly quantityControl$: Observable<UntypedFormControl>;
    readonly readonly$: Observable<boolean>;
    hideItems: boolean;
    lineItems$: Observable<LineItem[]>;
    numberOfLineItems$: Observable<number>;
    /**
     * Toggles the state of the items list.
     */
    toggleItems(): void;
    /**
     * Verifies whether the configurator type is a bundle based one.
     *
     * @param {OrderEntry} entry - Order entry
     * @returns {boolean} - 'true' if the expected configurator type, otherwise 'false'
     */
    isBundleBasedConfigurator(entry: OrderEntry): boolean;
    readonly shouldShowButton$: Observable<boolean>;
    getButtonText(translatedText?: string): string;
    getItemsMsg(items: number): string;
    getHiddenItemInfo(item: LineItem): string;
    getHiddenItemInfoId(index: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorCartEntryBundleInfoComponent, [null, null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorCartEntryBundleInfoComponent, "cx-configurator-cart-entry-bundle-info", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorCartEntryBundleInfoModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorCartEntryBundleInfoModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorCartEntryBundleInfoModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof ConfigureCartEntryModule, typeof ConfiguratorCartEntryBundleInfoComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorCartEntryBundleInfoModule>;
}

declare class ConfigureProductComponent {
    protected productListItemContext: ProductListItemContext;
    protected currentProductService: CurrentProductService;
    nonConfigurable: Product;
    product$: Observable<Product>;
    ownerTypeProduct: CommonConfigurator.OwnerType;
    protected routingService: RoutingService | null;
    protected getProduct(): Observable<Product | null>;
    /**
     * Retrieves a translation key for aria-label depending on the condition.
     *
     * @param configuratorType - configurator type
     * @returns - If the configurator type contains a read-only postfix then 'configurator.a11y.showDetailsProduct' translation key will be returned,
     * otherwise 'configurator.a11y.configureProduct'.
     */
    getAriaLabelTranslationKey(configuratorType?: string): string;
    /**
     * Retrieves a translation key depending on the condition.
     *
     * @param configuratorType - configurator type
     * @returns - If the configurator type contains a read-only postfix then 'configurator.header.toConfigReadOnly' translation key will be returned,
     * otherwise 'configurator.header.toconfig'.
     */
    getTranslationKey(configuratorType?: string): string;
    /**
     * Verifies whether restart dialog should be displayed or not.
     *
     * @param configuratorType
     * @returns - If the configurator type contains a read-only postfix then false will be returned, otherwise true.
     */
    isDisplayRestartDialog(configuratorType?: string): string;
    /**
     * Verifies whether a configurator type of a product contains a read-only postfix and
     * a product is a base product.
     *
     * @param product - product
     * @returns - If the configurator type contains a read-only postfix and
     * a product is a base product then returns true, otherwise false.
     */
    isReadOnlyBaseProduct(product: Product): boolean;
    /**
     * Verifies whether a product is a base product.
     *
     * The `baseProduct` property contains the product code of the base product.
     * If the `baseProduct` is undefined or if the provided product code equals the code of the base product,
     * then this product is a base product.
     *
     * @param product - product
     * @returns - If a product is a base product then returns true, otherwise false.
     * @protected
     */
    protected isBaseProduct(product: Product): boolean;
    navigateToConfigurator(product: Product): void;
    protected isConfiguratorTypeReadOnly(configuratorType?: string): boolean;
    constructor(productListItemContext: ProductListItemContext, // when on PLP
    currentProductService: CurrentProductService);
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfigureProductComponent, [{ optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfigureProductComponent, "cx-configure-product", never, {}, {}, never, never, true, never>;
}

declare class ConfigureProductModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfigureProductModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfigureProductModule, never, [typeof i1.CommonModule, typeof i4.RouterModule, typeof i2.ConfigModule, typeof i2.UrlModule, typeof i2.I18nModule, typeof i3.IconModule, typeof i3.BtnLikeLinkModule, typeof ConfigureProductComponent], [typeof ConfigureProductComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfigureProductModule>;
}

declare class CommonConfiguratorComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonConfiguratorComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CommonConfiguratorComponentsModule, never, [typeof ConfiguratorIssuesNotificationModule, typeof ConfiguratorCartEntryInfoModule, typeof ConfiguratorCartEntryBundleInfoModule, typeof ConfigureCartEntryModule, typeof ConfigureProductModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CommonConfiguratorComponentsModule>;
}

declare class CommonConfiguratorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonConfiguratorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CommonConfiguratorModule, never, [typeof CommonConfiguratorOccModule, typeof CommonConfiguratorComponentsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CommonConfiguratorModule>;
}

declare namespace ConfiguratorRouter {
    enum PageType {
        CONFIGURATION = "configuration",
        OVERVIEW = "overview"
    }
    interface Data {
        pageType?: PageType;
        isOwnerCartEntry?: boolean;
        owner: CommonConfigurator.Owner;
        displayOnly?: boolean;
        forceReload?: boolean;
        resolveIssues?: boolean;
        skipConflicts?: boolean;
        expMode?: boolean;
        configIdTemplate?: string;
        displayRestartDialog?: boolean;
        navigationId?: number;
        navigateToCheckout?: boolean;
        productCode?: string;
    }
}

/**
 * Service to extract the configuration owner key from the current route
 */
declare class ConfiguratorRouterExtractorService {
    protected configUtilsService: CommonConfiguratorUtilsService;
    protected routingService: RoutingService;
    protected readonly ROUTE_FRAGMENT_CONFIGURE = "configure";
    protected readonly ROUTE_FRAGMENT_OVERVIEW = "configureOverview";
    constructor(configUtilsService: CommonConfiguratorUtilsService, routingService: RoutingService);
    extractRouterData(): Observable<ConfiguratorRouter.Data>;
    createOwnerFromRouterState(routerState: RouterState): CommonConfigurator.Owner;
    /**
     * Compiles the configurator type from the semantic route
     * @param semanticRoute Consists of a prefix that indicates if target is interactive configuration or overview and
     *                      the commerce configurator type as postfix.
     *                      Example: configureTEXTFIELD or configureOverviewCPQCONFIGURATOR
     * @returns Configurator type
     */
    protected getConfiguratorTypeFromSemanticRoute(semanticRoute: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorRouterExtractorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorRouterExtractorService>;
}

declare enum ConfiguratorProductScope {
    CONFIGURATOR = "configurator",
    CONFIGURATOR_PRODUCT_CARD = "configuratorProductCard"
}

interface ProductConfiguratorConfig {
}
declare module '@spartacus/core' {
    interface Config {
        productConfigurator?: ProductConfiguratorConfig;
    }
}

declare module '@spartacus/core' {
    interface Product {
        configurable?: boolean;
        configuratorType?: string;
    }
}
declare module '@spartacus/cart/base/root' {
    interface OrderEntry {
        statusSummaryList?: StatusSummary[];
        configurationInfos?: ConfigurationInfo[];
    }
}

declare class ConfiguratorModelUtils {
    /**
     * Compiles a unique key for a configuration owner from id and type
     * @param owner Specifies the owner of a product configuration
     * @returns Owner key
     */
    static getOwnerKey(ownerType?: CommonConfigurator.OwnerType, ownerId?: string): string;
    /**
     * Creates an initial owner object
     * @returns Initial owner
     */
    static createInitialOwner(): CommonConfigurator.Owner;
    /**
     * Checks if an owner is an initial one
     * @param owner Owner
     * @returns Is owner initial?
     */
    static isInitialOwner(owner: CommonConfigurator.Owner): boolean;
    /**
     * Creates a configuration owner object based on its essential attributes
     * @param ownerType Owner type (Does it refer to product, cart or order?)
     * @param ownerId Owner identifier
     * @param configuratorType Configurator type
     * @returns Owner
     */
    static createOwner(ownerType: CommonConfigurator.OwnerType, ownerId: string, configuratorType?: string): CommonConfigurator.Owner;
}

export { CommonConfigurator, CommonConfiguratorComponentsModule, CommonConfiguratorModule, CommonConfiguratorOccModule, CommonConfiguratorUtilsService, ConfigurationInfoFields, ConfigurationInfoSpecialFields, ConfiguratorCartEntryBundleInfoComponent, ConfiguratorCartEntryBundleInfoModule, ConfiguratorCartEntryBundleInfoService, ConfiguratorCartEntryInfoComponent, ConfiguratorCartEntryInfoModule, ConfiguratorIssuesNotificationComponent, ConfiguratorIssuesNotificationModule, ConfiguratorModelUtils, ConfiguratorProductScope, ConfiguratorRouter, ConfiguratorRouterExtractorService, ConfiguratorType, ConfigureCartEntryComponent, ConfigureCartEntryModule, ConfigureProductComponent, ConfigureProductModule, OrderEntryStatus, ReadOnlyPostfix };
export type { ConfigurationInfo, LineItem, ProductConfiguratorConfig, StatusSummary };
