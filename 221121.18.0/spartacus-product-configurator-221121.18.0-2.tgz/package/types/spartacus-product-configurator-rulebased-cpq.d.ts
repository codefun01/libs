import { LanguageService, LoggerService, Converter, TranslationService, OccEndpointsService, ConverterService, OccEndpoint } from '@spartacus/core';
import { Configurator, RulebasedConfiguratorAdapter } from '@spartacus/product-configurator/rulebased';
import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import * as i1 from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { CartModification } from '@spartacus/cart/base/root';
import { CommonConfigurator } from '@spartacus/product-configurator/common';
import { Observable } from 'rxjs';

/**
 *
 * An interface representing the models used for the communication with the CPQ configurator
 */
declare namespace Cpq {
    /**
     * Response of create configuration requests
     */
    interface ConfigurationCreatedResponseData {
        /**
         * CPQ configuration ID of the newly created configuration
         */
        configurationId: string;
    }
    /**
     * An interface representing the CPQ configuration.
     */
    interface Configuration {
        productSystemId: string;
        productName?: string;
        completed?: boolean;
        incompleteMessages?: string[];
        incompleteAttributes?: string[];
        invalidMessages?: string[];
        failedValidations?: string[];
        errorMessages?: string[];
        conflictMessages?: string[];
        numberOfConflicts?: number;
        currencyISOCode: string;
        currencySign?: string;
        responder?: Cpq.Responder;
        tabs?: Tab[];
        attributes?: Attribute[];
        configurationId?: string;
        hasFullConfigurationState?: boolean;
    }
    /**
     *
     * An interface representing the CPQ configuration responder.
     */
    interface Responder {
        totalPrice?: string;
        baseProductPrice?: string;
    }
    /**
     *
     * An interface representing the CPQ configuration tab.
     */
    interface Tab {
        id: number;
        name?: string;
        displayName?: string;
        isIncomplete?: boolean;
        isSelected?: boolean;
        attributes?: Attribute[];
    }
    /**
     *
     * An interface representing the CPQ configuration attribute.
     */
    interface Attribute {
        pA_ID: number;
        stdAttrCode: number;
        name?: string;
        description?: string;
        label?: string;
        displayAs?: number;
        dataType?: Cpq.DataType;
        required?: boolean;
        incomplete?: boolean;
        isEnabled?: boolean;
        isLineItem?: boolean;
        hasConflict?: boolean;
        userInput?: string;
        quantity?: string;
        values?: Value[];
    }
    /**
     *
     * An interface representing the CPQ configuration attribute value.
     */
    interface Value {
        paV_ID: number;
        valueCode?: string;
        valueDisplay?: string;
        description?: string;
        productSystemId?: string;
        selected?: boolean;
        price?: string;
        quantity?: string;
    }
    /**
     *
     * An interface representing the structure for update of CPQ configuration attribute.
     */
    interface UpdateAttribute {
        configurationId: string;
        standardAttributeCode: string;
        changeAttributeValue: ChangeAttributeValue;
        tabId: string;
    }
    /**
     *
     * An interface representing the update request body structure for update of CPQ configuration attribute.
     */
    interface ChangeAttributeValue {
        attributeValueIds?: string;
        userInput?: string;
        quantity?: number;
    }
    /**
     *
     * An interface representing the structure for update quantity of CPQ configuration attribute value.
     */
    interface UpdateValue {
        configurationId: string;
        standardAttributeCode: string;
        attributeValueId: string;
        quantity: number;
        tabId: string;
    }
    /**
     *
     * An enum representing possible displayAs value.
     */
    enum DisplayAs {
        RADIO_BUTTON = 1,
        CHECK_BOX = 2,
        DROPDOWN = 3,
        LIST_BOX = 4,
        LIST_BOX_MULTI = 5,
        READ_ONLY = 71,
        INPUT = 95,
        AUTO_COMPLETE_CUSTOM = 102
    }
    enum DataType {
        INPUT_STRING = "String",
        INPUT_NUMBER = "Number",
        QTY_ATTRIBUTE_LEVEL = "Quantity",
        QTY_VALUE_LEVEL = "Attr.Quantity",
        N_A = "N/A"
    }
}

/**
 * Utilities for CPQ configuration
 */
declare class CpqConfiguratorNormalizerUtilsService {
    protected languageService: LanguageService;
    protected logger: LoggerService;
    constructor(languageService: LanguageService);
    /**
     * Converts quantity to be shown in the overview page
     *
     * @param {Cpq.Value} value - CPQ Value
     * @param {Cpq.Attribute} attribute - CPQ Attribute
     * @returns {number} - Quantity
     */
    convertQuantity(value: Cpq.Value, attribute: Cpq.Attribute): number | undefined;
    /**
     * Converts value price
     *
     * @param { Cpq.Value} value - CPQ Value
     * @param {string} currency - Currency code ISO
     * @returns {Configurator.PriceDetails}
     */
    convertValuePrice(value: Cpq.Value, currency: string): Configurator.PriceDetails | undefined;
    /**
     * Calculates total value price
     *
     * @param {number} quantity - Quantity
     * @param {Configurator.PriceDetails} valuePrice - PriceDetails of the single value price
     * @returns {Configurator.PriceDetails } - total value price
     */
    calculateValuePriceTotal(quantity: number, valuePrice?: Configurator.PriceDetails): Configurator.PriceDetails | undefined;
    /**
     * Calculates total attribute price
     *
     * @param {Configurator.Attribute} attribute - Configurator Attribute
     * @param {string} currency - Currency
     * @returns {Configurator.PriceDetails} - total attribute price
     */
    calculateAttributePriceTotal(attribute: Configurator.Attribute, currency: string): Configurator.PriceDetails;
    /**
     * Formats price for given PriceDetails object and Locale
     *
     * @param {Configurator.PriceDetails} price - Price details
     * @param {string} availableLocale - Original locale
     */
    protected formatPriceForLocale(price: Configurator.PriceDetails, availableLocale: string): void;
    /**
     * Converts the CPQ Attribute data type into the Configurator Attribute data type
     *
     * @param {Cpq.Attribute} cpqAttribute - CPQ Attribute
     * @returns {Configurator.DataType} Data type of the configurator attribute
     */
    convertDataType(cpqAttribute: Cpq.Attribute): Configurator.DataType;
    /**
     * Converts price summary
     *
     * @param {cpqConfiguration: Cpq.Configuration} cpqConfiguration - CPQ configuration
     * @returns {Configurator.PriceSummary} - price summary
     */
    convertPriceSummary(cpqConfiguration: Cpq.Configuration): Configurator.PriceSummary;
    /**
     * Verifies whether at least one value of a CPQ Attribute has an assigned product
     *
     * @param {Cpq.Value[]} attributeValues - CPQ Attribute values
     * @returns {boolean} - true, if at least one value of a CPQ Attribute has an assigned product
     */
    hasAnyProducts(attributeValues: Cpq.Value[]): boolean;
    /**
     * Convert attribute label
     *
     * @param {attribute: Cpq.Attribute} attribute - CPQ Attribute
     * @returns {string} - attribute label
     */
    convertAttributeLabel(attribute: Cpq.Attribute): string;
    /**
     * Gets the current language.
     *
     * @return {string} - current language
     */
    protected getLanguage(): string;
    /**
     * Gets the active language.
     *
     * @return {string} - active language
     */
    protected getActiveLanguage(): string;
    /**
     * Logs the message for the missing local data.
     *
     * @param {string} lang - Active language
     */
    protected reportMissingLocaleData(lang: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqConfiguratorNormalizerUtilsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CpqConfiguratorNormalizerUtilsService>;
}

declare class CpqConfiguratorNormalizer implements Converter<Cpq.Configuration, Configurator.Configuration> {
    protected cpqConfiguratorNormalizerUtilsService: CpqConfiguratorNormalizerUtilsService;
    protected translation: TranslationService;
    constructor(cpqConfiguratorNormalizerUtilsService: CpqConfiguratorNormalizerUtilsService, translation: TranslationService);
    convert(source: Cpq.Configuration, target?: Configurator.Configuration): Configurator.Configuration;
    protected generateTotalNumberOfIssues(source: Cpq.Configuration): number;
    protected generateWarningMessages(source: Cpq.Configuration): string[];
    protected generateErrorMessages(source: Cpq.Configuration): string[];
    protected convertGroup(source: Cpq.Tab, sourceAttributes: Cpq.Attribute[], currency: string, groupList: Configurator.Group[], flatGroupList: Configurator.Group[]): void;
    protected convertGenericGroup(sourceAttributes: Cpq.Attribute[], incompleteAttributes: string[], currency: string, groupList: Configurator.Group[], flatGroupList: Configurator.Group[]): void;
    protected isUITypeReadOnly(attribute: Configurator.Attribute): boolean;
    protected hasRetractValue(sourceAttribute: Cpq.Attribute): boolean;
    protected isNoValueSelected(sourceAttribute: Cpq.Attribute): boolean;
    protected setRetractValueDisplay(attribute: Configurator.Attribute, value: Configurator.Value): void;
    protected isSingleSelectionUiType(attribute: Configurator.Attribute): boolean;
    protected isDropDownUiType(attribute: Configurator.Attribute): boolean;
    /**
     * Determines whether a retract value needs to be added for the given attribute.
     * A retract value is added when the attribute is not required and is of a single
     * selection ui type (`RADIOBUTTON`, `DROPDOWN`, `DROPDOWN_PRODUCT` or
     * `RADIOBUTTON_PRODUCT`). It allows the user to deselect a previously selected value.
     *
     * @param attribute - converted attribute
     * @returns `true` - if a retract value needs to be added
     */
    protected isRetractValueNeeded(attribute: Configurator.Attribute): boolean;
    /**
     * Determines whether a documentation value needs to be added for a required
     * drop-down list. This is the case when the attribute is required, is of a
     * drop-down ui type (`DROPDOWN` or `DROPDOWN_PRODUCT`) and no value is selected.
     * It documents in the UI that a value still needs to be picked, without acting
     * as a retract value.
     *
     * @param sourceAttribute - source CPQ attribute
     * @param attribute - converted attribute
     * @returns `true` - if a documentation value needs to be added
     */
    protected isRequiredDropDownDocumentationValueNeeded(sourceAttribute: Cpq.Attribute, attribute: Configurator.Attribute): boolean;
    /**
     * Adds a retract value for a not required single selection attribute, so that the
     * user can deselect a previously selected value.
     *
     * @param sourceAttribute - source CPQ attribute
     * @param attribute - converted attribute
     * @param values - list of converted values the retract value is added to
     */
    protected addRetractValue(sourceAttribute: Cpq.Attribute, attribute: Configurator.Attribute, values: Configurator.Value[]): void;
    /**
     * Adds a required selection prompt value for a required drop-down list when
     * no value is selected. Although it looks the same in the UI as a retract
     * value, it only prompts the user that a value still needs to be picked.
     *
     * @param sourceAttribute - source CPQ attribute
     * @param attribute - converted attribute
     * @param values - list of converted values the required selection prompt value is added to
     */
    protected addRequiredSelectionPromptValue(sourceAttribute: Cpq.Attribute, attribute: Configurator.Attribute, values: Configurator.Value[]): void;
    /**
     * Creates and adds a generic value (using the retract value code)
     * to the given list of values and sets its display text.
     *
     * @param sourceAttribute - source CPQ attribute
     * @param attribute - converted attribute
     * @param values - list of converted values the value is added to
     */
    protected addGenericValue(sourceAttribute: Cpq.Attribute, attribute: Configurator.Attribute, values: Configurator.Value[]): void;
    protected convertAttribute(sourceAttribute: Cpq.Attribute, groupId: number, currency: string, attributeList: Configurator.Attribute[]): void;
    /**
     * In case the CPQ API is called via REST, the attribute id is returned using field name pA_ID.
     * If we call CPQ via OCC the attribute is mapped to field name PA_ID.
     * This can't be changed easily and is related to the non-standard conform name 'pA_ID';
     * @param sourceAttribute source attribute
     * @returns value of PA_ID or pA_ID, depending on which field is filled.
     */
    protected mapPAId(sourceAttribute: Cpq.Attribute): string;
    protected setSelectedSingleValue(attribute: Configurator.Attribute): void;
    protected convertValueDisplay(sourceValue: Cpq.Value, sourceAttribute: Cpq.Attribute, value: Configurator.Value): void;
    protected convertValueCode(valueCode: number): string;
    protected convertValue(sourceValue: Cpq.Value, sourceAttribute: Cpq.Attribute, currency: string, values: Configurator.Value[]): void;
    protected convertAttributeType(sourceAttribute: Cpq.Attribute): Configurator.UiType;
    protected findUiTypeFromDisplayType(displayAs: number | undefined, displayAsProduct: boolean, sourceAttribute: Cpq.Attribute): Configurator.UiType;
    protected compileAttributeIncomplete(attribute: Configurator.Attribute): void;
    protected hasValueToBeIgnored(attribute: Cpq.Attribute, value: Cpq.Value): boolean;
    protected getTabAttributes(source: Cpq.Configuration, tab: Cpq.Tab): Cpq.Attribute[];
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqConfiguratorNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CpqConfiguratorNormalizer>;
}

declare class CpqConfiguratorOverviewNormalizer implements Converter<Cpq.Configuration, Configurator.Overview> {
    protected cpqConfiguratorNormalizerUtilsService: CpqConfiguratorNormalizerUtilsService;
    protected translation: TranslationService;
    protected readonly NO_OPTION_SELECTED = 0;
    protected logger: LoggerService;
    constructor(cpqConfiguratorNormalizerUtilsService: CpqConfiguratorNormalizerUtilsService, translation: TranslationService);
    convert(source: Cpq.Configuration, target?: Configurator.Overview): Configurator.Overview;
    protected convertTab(tab: Cpq.Tab, currency: string): Configurator.GroupOverview;
    protected convertAttribute(attr: Cpq.Attribute, currency: string): Configurator.AttributeOverview[];
    protected convertAttributeValue(attr: Cpq.Attribute, currency: string): Configurator.AttributeOverview[];
    protected extractValue(valueSelected: Cpq.Value, attr: Cpq.Attribute, currency: string): Configurator.AttributeOverview;
    protected extractValueUserInput(attr: Cpq.Attribute, currency: string): Configurator.AttributeOverview;
    protected calculateTotalNumberOfIssues(source: Cpq.Configuration): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqConfiguratorOverviewNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CpqConfiguratorOverviewNormalizer>;
}

declare class CpqConfiguratorSerializer implements Converter<Configurator.Configuration, Cpq.UpdateAttribute> {
    convert(source: Configurator.Configuration): Cpq.UpdateAttribute;
    protected convertQuantity(attribute: Configurator.Attribute, configId: string): Cpq.UpdateAttribute;
    protected convertAttribute(attribute: Configurator.Attribute, configurationId: string): Cpq.UpdateAttribute;
    protected processValueCode(valueCode?: string): string | undefined;
    protected processSelectedSingleValue(singleValue?: string): string;
    protected prepareValueIds(attribute: Configurator.Attribute): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqConfiguratorSerializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CpqConfiguratorSerializer>;
}

declare class CpqConfiguratorValueSerializer implements Converter<Configurator.Configuration, Cpq.UpdateValue> {
    convert(source: Configurator.Configuration): Cpq.UpdateValue;
    protected convertAttribute(attribute: Configurator.Attribute, configurationId: string): Cpq.UpdateValue;
    protected findFirstChangedValue(attribute: Configurator.Attribute): Configurator.Value;
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqConfiguratorValueSerializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CpqConfiguratorValueSerializer>;
}

declare const CPQ_CONFIGURATOR_NORMALIZER: InjectionToken<Converter<Cpq.Configuration, Configurator.Configuration>>;
declare const CPQ_CONFIGURATOR_SERIALIZER: InjectionToken<Converter<Configurator.Configuration, Cpq.UpdateAttribute>>;
declare const CPQ_CONFIGURATOR_QUANTITY_SERIALIZER: InjectionToken<Converter<Configurator.Configuration, Cpq.UpdateValue>>;
declare const CPQ_CONFIGURATOR_OVERVIEW_NORMALIZER: InjectionToken<Converter<Cpq.Configuration, Configurator.Overview>>;

declare class CpqConfiguratorCommonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqConfiguratorCommonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CpqConfiguratorCommonModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CpqConfiguratorCommonModule>;
}

/**
 * An interface representing the models used for the communication with the OCC part of the CPQ configurator
 */
declare namespace OccCpqConfigurator {
    interface AddToCartParameters {
        userId?: string;
        cartId?: string;
        product?: AddToCartProductData;
        quantity?: number;
        configId?: string;
    }
    interface AddToCartProductData {
        code?: string;
    }
    interface UpdateConfigurationForCartEntryParameters {
        userId?: string;
        cartId?: string;
        configId: string;
        entryNumber: string;
    }
}

declare const CPQ_CONFIGURATOR_ADD_TO_CART_SERIALIZER: InjectionToken<Converter<Configurator.AddToCartParameters, OccCpqConfigurator.AddToCartParameters>>;
declare const CPQ_CONFIGURATOR_UPDATE_CART_ENTRY_SERIALIZER: InjectionToken<Converter<Configurator.AddToCartParameters, OccCpqConfigurator.UpdateConfigurationForCartEntryParameters>>;

declare class OccConfiguratorCpqAddToCartSerializer implements Converter<Configurator.AddToCartParameters, OccCpqConfigurator.AddToCartParameters> {
    convert(source: Configurator.AddToCartParameters, target?: OccCpqConfigurator.AddToCartParameters): OccCpqConfigurator.AddToCartParameters;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccConfiguratorCpqAddToCartSerializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccConfiguratorCpqAddToCartSerializer>;
}

declare class OccConfiguratorCpqUpdateCartEntrySerializer implements Converter<Configurator.UpdateConfigurationForCartEntryParameters, OccCpqConfigurator.UpdateConfigurationForCartEntryParameters> {
    convert(source: Configurator.UpdateConfigurationForCartEntryParameters, target?: OccCpqConfigurator.UpdateConfigurationForCartEntryParameters): OccCpqConfigurator.UpdateConfigurationForCartEntryParameters;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccConfiguratorCpqUpdateCartEntrySerializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccConfiguratorCpqUpdateCartEntrySerializer>;
}

declare class CpqConfiguratorOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqConfiguratorOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CpqConfiguratorOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CpqConfiguratorOccModule>;
}

declare class CpqConfiguratorOccService {
    protected http: HttpClient;
    protected occEndpointsService: OccEndpointsService;
    protected converterService: ConverterService;
    constructor(http: HttpClient, occEndpointsService: OccEndpointsService, converterService: ConverterService);
    addToCart(parameters: Configurator.AddToCartParameters): Observable<CartModification>;
    updateCartEntry(parameters: Configurator.UpdateConfigurationForCartEntryParameters): Observable<CartModification>;
    getConfigIdForCartEntry(parameters: CommonConfigurator.ReadConfigurationFromCartEntryParameters): Observable<string>;
    getConfigIdForOrderEntry(parameters: CommonConfigurator.ReadConfigurationFromOrderEntryParameters): Observable<string>;
    /**
     * Creates a new default runtime configuration for the given product id
     * and read it from the CPQ system over OCC.
     *
     * @param {string} productSystemId - Product system ID
     * @returns {Observable<Configurator.Configuration>} - Created configuration
     */
    createConfiguration(productSystemId: string): Observable<Configurator.Configuration>;
    /**
     * Retrieves a configuration from the CPQ system over OCC by its configuration ID and for a certain tab.
     *
     * @param {string} configId - Configuration ID
     * @param {string} tabId - Tab ID
     * @returns {Observable<Configurator.Configuration>} - Retrieved configuration
     */
    readConfiguration(configId: string, tabId?: string): Observable<Configurator.Configuration>;
    /**
     * Retrieves a configuration overview from the CPQ system over OCC by its configuration ID.
     *
     * @param {string} configId - Configuration ID
     * @returns {Observable<Configurator.Overview>} - Retrieved overview
     */
    readConfigurationOverview(configId: string): Observable<Configurator.Overview>;
    /**
     * Updates an attribute of the runtime configuration for the given configuration id and attribute code
     * and read the desired configuration tab from the CPQ system over OCC.
     *
     * @param {Configurator.Configuration} configuration - Configuration
     * @returns {Observable<Configurator.Configuration>} - Updated configuration
     */
    updateAttribute(configuration: Configurator.Configuration): Observable<Configurator.Configuration>;
    /**
     * Updates a quantity for an attribute of the runtime configuration for the given configuration id and attribute code
     * and read the desired configuration tab from the CPQ system over OCC.
     *
     * @param {Configurator.Configuration} configuration - Configuration
     * @returns {Observable<Configurator.Configuration>} - Updated configuration
     */
    updateValueQuantity(configuration: Configurator.Configuration): Observable<Configurator.Configuration>;
    /**
     * Retrieves a configuration assigned to a cart entry.
     *
     * @param {CommonConfigurator.ReadConfigurationFromCartEntryParameters} parameters - Cart entry parameters
     * @returns {Observable<Configurator.Configuration>} - Retrieved configuration
     */
    readConfigurationForCartEntry(parameters: CommonConfigurator.ReadConfigurationFromCartEntryParameters): Observable<Configurator.Configuration>;
    /**
     * Retrieves a configuration assigned to an order entry.
     *
     * @param {CommonConfigurator.ReadConfigurationFromOrderEntryParameters} parameters - Order entry parameters
     * @returns {Observable<Configurator.Configuration>} - Retrieved configuration
     */
    readConfigurationForOrderEntry(parameters: CommonConfigurator.ReadConfigurationFromOrderEntryParameters): Observable<Configurator.Configuration>;
    protected callCreateConfiguration(productSystemId: string): Observable<Cpq.Configuration>;
    protected callReadConfiguration(configId: string, tabId?: string): Observable<Cpq.Configuration>;
    protected callReadConfigurationOverview(configId: string): Observable<Cpq.Configuration>;
    protected callUpdateAttribute(updateAttribute: Cpq.UpdateAttribute): Observable<Cpq.Configuration>;
    protected callUpdateValue(updateValue: Cpq.UpdateValue): Observable<Cpq.Configuration>;
    protected callReadConfigurationForCartEntry(parameters: CommonConfigurator.ReadConfigurationFromCartEntryParameters): Observable<Cpq.Configuration>;
    protected callReadConfigurationForOrderEntry(parameters: CommonConfigurator.ReadConfigurationFromOrderEntryParameters): Observable<Cpq.Configuration>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqConfiguratorOccService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CpqConfiguratorOccService>;
}

declare class CpqConfiguratorOccAdapter implements RulebasedConfiguratorAdapter {
    protected cpqOccService: CpqConfiguratorOccService;
    constructor(cpqOccService: CpqConfiguratorOccService);
    getConfiguratorType(): string;
    createConfiguration(owner: CommonConfigurator.Owner): Observable<Configurator.Configuration>;
    readConfiguration(configId: string, groupId: string, owner: CommonConfigurator.Owner): Observable<Configurator.Configuration>;
    updateConfiguration(configuration: Configurator.Configuration): Observable<Configurator.Configuration>;
    updateConfigurationOverview(): Observable<Configurator.Overview>;
    addToCart(parameters: Configurator.AddToCartParameters): Observable<CartModification>;
    readConfigurationForCartEntry(parameters: CommonConfigurator.ReadConfigurationFromCartEntryParameters): Observable<Configurator.Configuration>;
    updateConfigurationForCartEntry(parameters: Configurator.UpdateConfigurationForCartEntryParameters): Observable<CartModification>;
    readConfigurationForOrderEntry(parameters: CommonConfigurator.ReadConfigurationFromOrderEntryParameters): Observable<Configurator.Configuration>;
    readPriceSummary(configuration: Configurator.Configuration): Observable<Configurator.Configuration>;
    getConfigurationOverview(configId: string): Observable<Configurator.Overview>;
    searchVariants(): Observable<Configurator.Variant[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqConfiguratorOccAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CpqConfiguratorOccAdapter>;
}

declare module '@spartacus/core' {
    interface OccEndpoints {
        /**
         * Endpoint to get Cpq token
         *
         * @member {string}
         */
        getCpqAccessData?: string | OccEndpoint;
        /**
         * Endpoint to add a cpq configuration to the current cart
         *
         * @member {string}
         */
        addCpqConfigurationToCart?: string | OccEndpoint;
        /**
         * Endpoint for updating a cpq configuration attached to the given cart entry
         */
        updateCpqConfigurationForCartEntry?: string | OccEndpoint;
        /**
         * Endpoint for reading the Id of a CPQ configuration attached to the given cart entry
         */
        readCpqConfigurationForCartEntry?: string | OccEndpoint;
        /**
         * Endpoint for reading the Id of a CPQ configuration attached to the given order entry
         */
        readCpqConfigurationForOrderEntry?: string | OccEndpoint;
        /**
         * Endpoint for creation a CPQ configuration over OCC
         */
        createCpqConfiguration?: string | OccEndpoint;
        /**
         * Endpoint for retrieving a CPQ configuration over OCC
         */
        readCpqConfiguration?: string | OccEndpoint;
        /**
         * Endpoint for retrieving a CPQ configuration overview over OCC
         */
        readCpqConfigurationOverview?: string | OccEndpoint;
        /**
         * Endpoint for update a CPQ attribute over OCC
         */
        updateCpqAttribute?: string | OccEndpoint;
        /**
         * Endpoint for update a CPQ attribute value quantity over OCC
         */
        updateCpqAttributeValueQuantity?: string | OccEndpoint;
        /**
         * Endpoint for reading a CPQ configuration attached to the given cart entry over OCC
         */
        readCpqConfigurationForCartEntryFull?: string | OccEndpoint;
        /**
         * Endpoint for reading a CPQ configuration attached to a given order entry over OCC
         */
        readCpqConfigurationForOrderEntryFull?: string | OccEndpoint;
        /**
         * Endpoint for reading an entire CPQ configuration attached to a given quote entry over OCC
         */
        readCpqConfigurationForQuoteEntryFull?: string | OccEndpoint;
        /**
         * Endpoint for reading a CPQ configuration attached to a given saved cart entry over OCC
         */
        readCpqConfigurationForSavedCartEntryFull?: string | OccEndpoint;
    }
}

interface CpqUpdateInformation {
    standardAttributeCode: string;
    tabId: string;
}
declare class CpqConfiguratorUtils {
    /**
     * Collects information that we need to fire a CPQ update
     *
     * @param {Configurator.Attribute} attribute Configurator attribute
     * @returns {CpqUpdateInformation} Update information
     */
    static getUpdateInformation(attribute: Configurator.Attribute): CpqUpdateInformation;
    /**
     * Finds first changed attribute
     * @param {Configurator.Configuration} source Configuration
     * @returns {Configurator.Attribute} First attribute of first group
     */
    static findFirstChangedAttribute(source: Configurator.Configuration): Configurator.Attribute;
}

/**
 * Exposes the CPQ flavor of rulebase configurator
 */
declare class RulebasedCpqConfiguratorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RulebasedCpqConfiguratorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RulebasedCpqConfiguratorModule, never, [typeof CpqConfiguratorCommonModule, typeof CpqConfiguratorOccModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RulebasedCpqConfiguratorModule>;
}

export { CPQ_CONFIGURATOR_ADD_TO_CART_SERIALIZER, CPQ_CONFIGURATOR_NORMALIZER, CPQ_CONFIGURATOR_OVERVIEW_NORMALIZER, CPQ_CONFIGURATOR_QUANTITY_SERIALIZER, CPQ_CONFIGURATOR_SERIALIZER, CPQ_CONFIGURATOR_UPDATE_CART_ENTRY_SERIALIZER, Cpq, CpqConfiguratorCommonModule, CpqConfiguratorNormalizer, CpqConfiguratorNormalizerUtilsService, CpqConfiguratorOccAdapter, CpqConfiguratorOccModule, CpqConfiguratorOccService, CpqConfiguratorOverviewNormalizer, CpqConfiguratorSerializer, CpqConfiguratorUtils, CpqConfiguratorValueSerializer, OccConfiguratorCpqAddToCartSerializer, OccConfiguratorCpqUpdateCartEntrySerializer, OccCpqConfigurator, RulebasedCpqConfiguratorModule };
