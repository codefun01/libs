import * as i0 from '@angular/core';
import { Injectable, inject, Input, ChangeDetectionStrategy, Component, NgModule, Optional, isDevMode } from '@angular/core';
import { NgIf, AsyncPipe, CommonModule, NgFor } from '@angular/common';
import * as i2 from '@spartacus/cart/base/root';
import { PromotionLocation, AbstractOrderType, CartOutlets } from '@spartacus/cart/base/root';
import * as i1 from '@spartacus/core';
import { OCC_USER_ID_ANONYMOUS, RoutingService, UrlPipe, TranslatePipe, UrlModule, I18nModule, ProductScope, ConfigModule, LoggerService, CxNumericPipe, provideDefaultConfig } from '@spartacus/core';
import * as i1$1 from '@spartacus/storefront';
import { IconModule, ICON_TYPE, IconComponent, provideOutlet, OutletPosition, BtnLikeLinkModule, ProductListOutlets } from '@spartacus/storefront';
import { RouterLink, RouterModule } from '@angular/router';
import { AbstractOrderContext } from '@spartacus/cart/base/components';
import { EMPTY, of } from 'rxjs';
import { map, take, filter } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var CommonConfigurator;
(function (CommonConfigurator) {
    /**
     * Possible types of owners: Product, cart or order entry
     */
    let OwnerType;
    (function (OwnerType) {
        OwnerType["PRODUCT"] = "product";
        OwnerType["CART_ENTRY"] = "cartEntry";
        OwnerType["ORDER_ENTRY"] = "orderEntry";
        OwnerType["QUOTE_ENTRY"] = "quoteEntry";
        OwnerType["SAVED_CART_ENTRY"] = "savedCartEntry";
    })(OwnerType = CommonConfigurator.OwnerType || (CommonConfigurator.OwnerType = {}));
})(CommonConfigurator || (CommonConfigurator = {}));
/**
 * Possible configurator types
 */
var ConfiguratorType;
(function (ConfiguratorType) {
    ConfiguratorType["CPQ"] = "CLOUDCPQCONFIGURATOR";
    ConfiguratorType["VARIANT"] = "CPQCONFIGURATOR";
    ConfiguratorType["TEXTFIELD"] = "TEXTFIELD";
})(ConfiguratorType || (ConfiguratorType = {}));
/**
 * Configurator types including this postfix are
 * treated as view-only
 */
const ReadOnlyPostfix = '_READ_ONLY';
/**
 * Statuses that can occur in the generic configuration
 * status summary
 */
var OrderEntryStatus;
(function (OrderEntryStatus) {
    OrderEntryStatus["Success"] = "SUCCESS";
    OrderEntryStatus["Info"] = "INFO";
    OrderEntryStatus["Warning"] = "WARNING";
    OrderEntryStatus["Error"] = "ERROR";
})(OrderEntryStatus || (OrderEntryStatus = {}));
/**
 *
 * An enum representing ConfigurationInfo fields.
 */
var ConfigurationInfoFields;
(function (ConfigurationInfoFields) {
    ConfigurationInfoFields["KEY"] = "KEY";
    ConfigurationInfoFields["NAME"] = "NAME";
    ConfigurationInfoFields["QTY"] = "QTY";
    ConfigurationInfoFields["FORMATTED_PRICE"] = "FORMATTED_PRICE";
    ConfigurationInfoFields["PRICE_VALUE"] = "PRICE_VALUE";
    ConfigurationInfoFields["PARENT"] = "PARENT";
})(ConfigurationInfoFields || (ConfigurationInfoFields = {}));
/**
 *
 * An enum representing ConfigurationInfo special fields.
 */
var ConfigurationInfoSpecialFields;
(function (ConfigurationInfoSpecialFields) {
    ConfigurationInfoSpecialFields["VERSION"] = "CI#@#VERSION";
    ConfigurationInfoSpecialFields["CURRENCY"] = "CI#@#CURRENCY";
    ConfigurationInfoSpecialFields["LINE_ITEM"] = "LI";
    ConfigurationInfoSpecialFields["LINE_ITEM_DELIMITER"] = "#";
})(ConfigurationInfoSpecialFields || (ConfigurationInfoSpecialFields = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const initialIndicator = 'INITIAL';
class ConfiguratorModelUtils {
    /**
     * Compiles a unique key for a configuration owner from id and type
     * @param owner Specifies the owner of a product configuration
     * @returns Owner key
     */
    static getOwnerKey(ownerType, ownerId) {
        if (!ownerId || !ownerType) {
            throw new Error('We expect an owner ID and an owner type');
        }
        return ownerType + '/' + ownerId;
    }
    /**
     * Creates an initial owner object
     * @returns Initial owner
     */
    static createInitialOwner() {
        return {
            key: initialIndicator,
            configuratorType: initialIndicator,
            id: initialIndicator,
            type: CommonConfigurator.OwnerType.PRODUCT,
        };
    }
    /**
     * Checks if an owner is an initial one
     * @param owner Owner
     * @returns Is owner initial?
     */
    static isInitialOwner(owner) {
        return owner.configuratorType === initialIndicator;
    }
    /**
     * Creates a configuration owner object based on its essential attributes
     * @param ownerType Owner type (Does it refer to product, cart or order?)
     * @param ownerId Owner identifier
     * @param configuratorType Configurator type
     * @returns Owner
     */
    static createOwner(ownerType, ownerId, configuratorType = ConfiguratorType.VARIANT) {
        return {
            type: ownerType,
            id: ownerId,
            configuratorType: configuratorType,
            key: ConfiguratorModelUtils.getOwnerKey(ownerType, ownerId),
        };
    }
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Utilities for generic configuration
 */
class CommonConfiguratorUtilsService {
    constructor(userIdService) {
        this.userIdService = userIdService;
    }
    /**
     * Compiles a unique key for a configuration owner and sets it into the 'key'
     * attribute
     * @param {CommonConfigurator.Owner }owner - Specifies the owner of a product configuration
     */
    setOwnerKey(owner) {
        owner.key = ConfiguratorModelUtils.getOwnerKey(owner.type, owner.id);
    }
    /**
     * Composes owner ID from document ID and entry number
     * @param {string} documentId - ID of document the entry is part of, like the order or quote code
     * @param {string} entryNumber - Entry number
     * @returns {string} - owner ID
     */
    getComposedOwnerId(documentId, entryNumber) {
        return documentId + '+' + entryNumber;
    }
    /**
     * Decomposes an owner ID into documentId and entryNumber
     * @param {string} ownerId - ID of owner
     * @returns {any} object containing documentId and entryNumber
     */
    decomposeOwnerId(ownerId) {
        const parts = ownerId.split('+');
        if (parts.length !== 2) {
            throw new Error('We only expect 2 parts in ownerId, separated by +, but was: ' + ownerId);
        }
        const result = { documentId: parts[0], entryNumber: parts[1] };
        return result;
    }
    /**
     * Gets cart ID (which can be either its guid or its code)
     * @param {Cart} cart - Cart
     * @returns {string} - Cart identifier
     */
    getCartId(cart) {
        const cartId = cart?.user?.uid === OCC_USER_ID_ANONYMOUS ? cart.guid : cart?.code;
        if (!cartId) {
            throw new Error('Cart ID is not defined');
        }
        return cartId;
    }
    /**
     * Verifies whether the item has any issues.
     *
     * @param {OrderEntry} cartItem - Cart item
     * @returns {boolean} - whether there are any issues
     */
    hasIssues(cartItem) {
        return this.getNumberOfIssues(cartItem) > 0;
    }
    /**
     * Retrieves the number of issues at the cart item.
     *
     * @param {OrderEntry} cartItem - Cart item
     * @returns {number} - the number of issues at the cart item
     */
    getNumberOfIssues(cartItem) {
        let numberOfIssues = 0;
        cartItem?.statusSummaryList?.forEach((statusSummary) => {
            if (statusSummary.status === OrderEntryStatus.Error) {
                const numberOfIssuesFromStatus = statusSummary.numberOfIssues;
                numberOfIssues = numberOfIssuesFromStatus
                    ? numberOfIssuesFromStatus
                    : 0;
            }
        });
        return numberOfIssues;
    }
    /**
     * Verifies whether the configurator type is an attribute based one.
     *
     * @param {string} configuratorType - Configurator type
     * @returns {boolean} - 'True' if the expected configurator type, otherwise 'false'
     */
    isAttributeBasedConfigurator(configuratorType) {
        if (configuratorType) {
            return (configuratorType === ConfiguratorType.VARIANT ||
                configuratorType === ConfiguratorType.TEXTFIELD);
        }
        return false;
    }
    /**
     * Verifies whether the configurator type is a bundle based one.
     *
     * @param {string} configuratorType - Configurator type
     * @returns {boolean} - 'True' if the expected configurator type, otherwise 'fasle'
     */
    isBundleBasedConfigurator(configuratorType) {
        if (configuratorType) {
            return configuratorType === ConfiguratorType.CPQ;
        }
        return false;
    }
    /**
     * Determines whether we are in the context of an active cart
     * @param cartItemContext Cart item context
     * @returns Item part of an active cart?
     */
    isActiveCartContext(cartItemContext) {
        return (cartItemContext?.location$ ?? EMPTY).pipe(map((location) => location !== PromotionLocation.SaveForLater &&
            location !== PromotionLocation.SavedCart));
    }
    /**
     * Reads slots from layout config, taking the breakpoint into account
     * @param layoutConfig Layout config
     * @param templateName Page template name
     * @param sectionName Section name like 'header'
     * @param breakPoint Current breakpoint
     * @returns Array of slots
     */
    getSlotsFromLayoutConfiguration(layoutConfig, templateName, sectionName, breakPoint) {
        const slots = layoutConfig.layoutSlots;
        if (slots) {
            const slotsForTemplate = (slots[templateName]);
            const slotGroupForSection = (slotsForTemplate[sectionName]);
            const slotConfigForBreakpoint = (slotGroupForSection[breakPoint]);
            return slotConfigForBreakpoint['slots'];
        }
        else {
            return [];
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CommonConfiguratorUtilsService, deps: [{ token: i1.UserIdService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CommonConfiguratorUtilsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CommonConfiguratorUtilsService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1.UserIdService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ConfigureCartEntryComponent {
    /**
     * Verifies whether the entry has any issues.
     *
     * @returns - whether there are any issues
     */
    hasIssues() {
        return this.commonConfigUtilsService.hasIssues(this.cartEntry);
    }
    /**
     * Retrieves owner for an abstract order type
     *
     * @returns - an owner type
     */
    retrieveOwnerTypeFromAbstractOrderType(abstractOrderKey) {
        switch (abstractOrderKey.type) {
            case AbstractOrderType.ORDER: {
                return CommonConfigurator.OwnerType.ORDER_ENTRY;
            }
            case AbstractOrderType.QUOTE: {
                return CommonConfigurator.OwnerType.QUOTE_ENTRY;
            }
            case AbstractOrderType.SAVED_CART: {
                return CommonConfigurator.OwnerType.SAVED_CART_ENTRY;
            }
            default: {
                return CommonConfigurator.OwnerType.CART_ENTRY;
            }
        }
    }
    /**
     * Verifies whether the cart entry has an order code, retrieves a composed owner ID
     * and concatenates a corresponding entry number.
     *
     * @returns - an entry key
     */
    retrieveEntityKey(abstractOrderKey) {
        const entryNumber = this.cartEntry.entryNumber;
        if (entryNumber === undefined) {
            throw new Error('No entryNumber present in entry');
        }
        return abstractOrderKey.type !== AbstractOrderType.CART
            ? this.commonConfigUtilsService.getComposedOwnerId(abstractOrderKey.id, entryNumber)
            : entryNumber.toString();
    }
    /**
     * Retrieves a corresponding route depending whether the configuration is read only or not.
     *
     * @returns - a route
     */
    getRoute() {
        const configuratorType = this.cartEntry.product?.configuratorType;
        return !this.readOnly || configuratorType?.endsWith(ReadOnlyPostfix)
            ? 'configure' + configuratorType
            : 'configureOverview' + configuratorType;
    }
    /**
     * Retrieves the state of the configuration.
     *
     *  @returns - 'true' if the configuration is read only or configurator type contains a read-only postfix, otherwise 'false'
     */
    getDisplayOnly() {
        const configuratorType = this.cartEntry.product?.configuratorType;
        return (this.readOnly ||
            !configuratorType ||
            configuratorType.endsWith(ReadOnlyPostfix));
    }
    /**
     * Verifies whether the link to the configuration is disabled.
     *
     *  @returns - 'true' if the the configuration is not read only, otherwise 'false'
     */
    isDisabled() {
        return this.readOnly ? false : this.disabled;
    }
    /**
     * Retrieves the additional resolve issues accessibility description.
     *
     * @returns - If there is a 'resolve issues' link, the ID to the element with additional description will be returned.
     */
    getResolveIssuesA11yDescription() {
        const errorMsgId = 'cx-error-msg-' + this.cartEntry.entryNumber;
        return !this.getDisplayOnly() && this.msgBanner ? errorMsgId : undefined;
    }
    isInCheckout() {
        return this.routingService.getRouterState().pipe(map((routerState) => {
            return routerState.state.semanticRoute === 'checkoutReviewOrder';
        }));
    }
    constructor(commonConfigUtilsService) {
        this.commonConfigUtilsService = commonConfigUtilsService;
        this.routingService = inject(RoutingService);
        this.abstractOrderContext = inject(AbstractOrderContext, { optional: true });
        // we default to active cart as owner in case no context is provided
        // in this case no id of abstract order is needed
        this.abstractOrderKey$ = this.abstractOrderContext
            ? this.abstractOrderContext.key$
            : of({ type: AbstractOrderType.CART });
        this.queryParams$ = this.isInCheckout().pipe(map((isInCheckout) => ({
            forceReload: true,
            resolveIssues: this.msgBanner && this.hasIssues(),
            navigateToCheckout: isInCheckout,
            productCode: this.cartEntry.product?.code,
        })));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfigureCartEntryComponent, deps: [{ token: CommonConfiguratorUtilsService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: ConfigureCartEntryComponent, isStandalone: true, selector: "cx-configure-cart-entry", inputs: { cartEntry: "cartEntry", readOnly: "readOnly", msgBanner: "msgBanner", disabled: "disabled" }, ngImport: i0, template: "<ng-container *ngIf=\"abstractOrderKey$ | async as abstractOrderKey\">\n  <ng-container *ngIf=\"cartEntry\">\n    <label *ngIf=\"isDisabled()\" class=\"disabled-link\">\n      <ng-container *ngIf=\"isDisabled(); then configureText\"> </ng-container>\n    </label>\n\n    <a\n      *ngIf=\"!isDisabled()\"\n      class=\"link cx-action-link\"\n      [routerLink]=\"\n        {\n          cxRoute: getRoute(),\n          params: {\n            ownerType: retrieveOwnerTypeFromAbstractOrderType(abstractOrderKey),\n            entityKey: retrieveEntityKey(abstractOrderKey),\n            displayOnly: getDisplayOnly(),\n          },\n        } | cxUrl\n      \"\n      [queryParams]=\"queryParams$ | async\"\n      cxAutoFocus\n      attr.aria-describedby=\"{{ getResolveIssuesA11yDescription() }}\"\n    >\n      <ng-container *ngIf=\"!isDisabled(); then configureText\"> </ng-container>\n    </a>\n  </ng-container>\n\n  <ng-template #configureText>\n    <ng-container *ngIf=\"getDisplayOnly()\">\n      {{\n        'configurator.header.displayConfiguration' | cxTranslate\n      }}</ng-container\n    >\n    <ng-container *ngIf=\"!getDisplayOnly() && !msgBanner\">\n      {{ 'configurator.header.editConfiguration' | cxTranslate }}\n    </ng-container>\n\n    <ng-container *ngIf=\"!getDisplayOnly() && msgBanner\">\n      {{ 'configurator.header.resolveIssues' | cxTranslate }}\n    </ng-container>\n  </ng-template>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfigureCartEntryComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-configure-cart-entry', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, RouterLink, AsyncPipe, UrlPipe, TranslatePipe], template: "<ng-container *ngIf=\"abstractOrderKey$ | async as abstractOrderKey\">\n  <ng-container *ngIf=\"cartEntry\">\n    <label *ngIf=\"isDisabled()\" class=\"disabled-link\">\n      <ng-container *ngIf=\"isDisabled(); then configureText\"> </ng-container>\n    </label>\n\n    <a\n      *ngIf=\"!isDisabled()\"\n      class=\"link cx-action-link\"\n      [routerLink]=\"\n        {\n          cxRoute: getRoute(),\n          params: {\n            ownerType: retrieveOwnerTypeFromAbstractOrderType(abstractOrderKey),\n            entityKey: retrieveEntityKey(abstractOrderKey),\n            displayOnly: getDisplayOnly(),\n          },\n        } | cxUrl\n      \"\n      [queryParams]=\"queryParams$ | async\"\n      cxAutoFocus\n      attr.aria-describedby=\"{{ getResolveIssuesA11yDescription() }}\"\n    >\n      <ng-container *ngIf=\"!isDisabled(); then configureText\"> </ng-container>\n    </a>\n  </ng-container>\n\n  <ng-template #configureText>\n    <ng-container *ngIf=\"getDisplayOnly()\">\n      {{\n        'configurator.header.displayConfiguration' | cxTranslate\n      }}</ng-container\n    >\n    <ng-container *ngIf=\"!getDisplayOnly() && !msgBanner\">\n      {{ 'configurator.header.editConfiguration' | cxTranslate }}\n    </ng-container>\n\n    <ng-container *ngIf=\"!getDisplayOnly() && msgBanner\">\n      {{ 'configurator.header.resolveIssues' | cxTranslate }}\n    </ng-container>\n  </ng-template>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: CommonConfiguratorUtilsService }], propDecorators: { cartEntry: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], msgBanner: [{
                type: Input
            }], disabled: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ConfigureCartEntryModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfigureCartEntryModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: ConfigureCartEntryModule, imports: [CommonModule,
            UrlModule,
            I18nModule,
            IconModule,
            RouterModule,
            ConfigureCartEntryComponent], exports: [ConfigureCartEntryComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfigureCartEntryModule, imports: [CommonModule,
            UrlModule,
            I18nModule,
            IconModule,
            RouterModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfigureCartEntryModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        UrlModule,
                        I18nModule,
                        IconModule,
                        RouterModule,
                        ConfigureCartEntryComponent,
                    ],
                    exports: [ConfigureCartEntryComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ConfiguratorIssuesNotificationComponent {
    constructor(commonConfigUtilsService, cartItemContext) {
        this.commonConfigUtilsService = commonConfigUtilsService;
        this.cartItemContext = cartItemContext;
        this.iconTypes = ICON_TYPE;
        this.orderEntry$ = this.cartItemContext?.item$ ?? EMPTY;
        this.quantityControl$ = this.cartItemContext?.quantityControl$ ?? EMPTY;
        this.readonly$ = this.cartItemContext?.readonly$ ?? EMPTY;
        // TODO: remove the logic below when configurable products support "Saved Cart" and "Save For Later"
        this.shouldShowButton$ = this.commonConfigUtilsService.isActiveCartContext(this.cartItemContext);
    }
    /**
     * Verifies whether the item has any issues.
     *
     * @param item - Cart item
     * @returns - whether there are any issues
     */
    hasIssues(item) {
        return this.commonConfigUtilsService.hasIssues(item);
    }
    /**
     * Retrieves the number of issues at the cart item.
     *
     * @param item - Cart item
     * @returns - the number of issues at the cart item
     */
    getNumberOfIssues(item) {
        return this.commonConfigUtilsService.getNumberOfIssues(item);
    }
    /**
     * Retrieves the unique id for the error message.
     *
     * @param item - Cart item
     * @returns - Unique id for error message
     */
    getErrorMessageId(item) {
        return 'cx-error-msg-' + item.entryNumber;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorIssuesNotificationComponent, deps: [{ token: CommonConfiguratorUtilsService }, { token: i2.CartItemContext, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: ConfiguratorIssuesNotificationComponent, isStandalone: true, selector: "cx-configurator-issues-notification", ngImport: i0, template: "<ng-container *ngIf=\"orderEntry$ | async as orderEntry\">\n  <ng-container *ngIf=\"hasIssues(orderEntry) && !(readonly$ | async)\">\n    <cx-icon [type]=\"iconTypes.ERROR\"></cx-icon>\n    <div id=\"{{ getErrorMessageId(orderEntry) }}\">\n      {{\n        'configurator.notificationBanner.numberOfIssues'\n          | cxTranslate: { count: getNumberOfIssues(orderEntry) }\n      }}\n      <ng-container *ngIf=\"quantityControl$ | async as quantityControl\">\n        <cx-configure-cart-entry\n          class=\"cx-error-msg-action\"\n          *ngIf=\"\n            (shouldShowButton$ | async) && orderEntry?.product?.configurable\n          \"\n          [cartEntry]=\"orderEntry\"\n          [readOnly]=\"(readonly$ | async) ?? false\"\n          [msgBanner]=\"true\"\n          [disabled]=\"quantityControl.disabled\"\n        ></cx-configure-cart-entry>\n      </ng-container>\n    </div>\n  </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "component", type: ConfigureCartEntryComponent, selector: "cx-configure-cart-entry", inputs: ["cartEntry", "readOnly", "msgBanner", "disabled"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorIssuesNotificationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-configurator-issues-notification', imports: [
                        NgIf,
                        IconComponent,
                        ConfigureCartEntryComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<ng-container *ngIf=\"orderEntry$ | async as orderEntry\">\n  <ng-container *ngIf=\"hasIssues(orderEntry) && !(readonly$ | async)\">\n    <cx-icon [type]=\"iconTypes.ERROR\"></cx-icon>\n    <div id=\"{{ getErrorMessageId(orderEntry) }}\">\n      {{\n        'configurator.notificationBanner.numberOfIssues'\n          | cxTranslate: { count: getNumberOfIssues(orderEntry) }\n      }}\n      <ng-container *ngIf=\"quantityControl$ | async as quantityControl\">\n        <cx-configure-cart-entry\n          class=\"cx-error-msg-action\"\n          *ngIf=\"\n            (shouldShowButton$ | async) && orderEntry?.product?.configurable\n          \"\n          [cartEntry]=\"orderEntry\"\n          [readOnly]=\"(readonly$ | async) ?? false\"\n          [msgBanner]=\"true\"\n          [disabled]=\"quantityControl.disabled\"\n        ></cx-configure-cart-entry>\n      </ng-container>\n    </div>\n  </ng-container>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: CommonConfiguratorUtilsService }, { type: i2.CartItemContext, decorators: [{
                    type: Optional
                }] }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ConfiguratorIssuesNotificationModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorIssuesNotificationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorIssuesNotificationModule, imports: [CommonModule,
            UrlModule,
            I18nModule,
            IconModule,
            ConfigureCartEntryModule,
            ConfiguratorIssuesNotificationComponent], exports: [ConfiguratorIssuesNotificationComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorIssuesNotificationModule, providers: [
            provideOutlet({
                id: CartOutlets.ITEM_CONFIGURATOR_ISSUES,
                position: OutletPosition.REPLACE,
                component: ConfiguratorIssuesNotificationComponent,
            }),
        ], imports: [CommonModule,
            UrlModule,
            I18nModule,
            IconModule,
            ConfigureCartEntryModule,
            ConfiguratorIssuesNotificationComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorIssuesNotificationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        UrlModule,
                        I18nModule,
                        IconModule,
                        ConfigureCartEntryModule,
                        ConfiguratorIssuesNotificationComponent,
                    ],
                    providers: [
                        provideOutlet({
                            id: CartOutlets.ITEM_CONFIGURATOR_ISSUES,
                            position: OutletPosition.REPLACE,
                            component: ConfiguratorIssuesNotificationComponent,
                        }),
                    ],
                    exports: [ConfiguratorIssuesNotificationComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ConfiguratorCartEntryInfoComponent {
    constructor(cartItemContext, commonConfigUtilsService) {
        this.cartItemContext = cartItemContext;
        this.commonConfigUtilsService = commonConfigUtilsService;
        this.orderEntry$ = this.cartItemContext?.item$ ?? EMPTY;
        this.quantityControl$ = this.cartItemContext?.quantityControl$ ?? EMPTY;
        this.readonly$ = this.cartItemContext?.readonly$ ?? EMPTY;
        // TODO: remove the logic below when configurable products support "Saved Cart" and "Save For Later"
        this.shouldShowButton$ = this.commonConfigUtilsService.isActiveCartContext(this.cartItemContext);
    }
    /**
     * Verifies whether the configuration infos have any entries and the first entry has a status.
     * Only in this case we want to display the configuration summary
     *
     * @param {OrderEntry} item - Cart item
     * @returns {boolean} - whether the status of configuration infos entry has status
     */
    hasStatus(item) {
        const configurationInfos = item.configurationInfos;
        return configurationInfos
            ? configurationInfos.length > 0 && configurationInfos[0].status !== 'NONE'
            : false;
    }
    /**
     * Verifies whether the configurator type is attribute based one.
     *
     * @param {OrderEntry} item - Order entry item
     * @returns {boolean} - 'True' if the expected configurator type, otherwise 'fasle'
     */
    isAttributeBasedConfigurator(item) {
        const configurationInfos = item.configurationInfos;
        return configurationInfos
            ? this.commonConfigUtilsService.isAttributeBasedConfigurator(configurationInfos[0]?.configuratorType)
            : false;
    }
    getHiddenConfigurationInfoId(index) {
        return 'cx-configuration-hidden-info-' + index.toString();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorCartEntryInfoComponent, deps: [{ token: i2.CartItemContext, optional: true }, { token: CommonConfiguratorUtilsService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: ConfiguratorCartEntryInfoComponent, isStandalone: true, selector: "cx-configurator-cart-entry-info", ngImport: i0, template: "<ng-container *ngIf=\"orderEntry$ | async as orderEntry\">\n  <ng-container *ngIf=\"isAttributeBasedConfigurator(orderEntry)\">\n    <ng-container *ngIf=\"hasStatus(orderEntry)\">\n      <span\n        *ngIf=\"orderEntry.configurationInfos?.length ?? 0 > 0\"\n        class=\"cx-intro cx-visually-hidden\"\n      >\n        {{ 'configurator.a11y.cartEntryInfoIntro' | cxTranslate }}\n      </span>\n      <div\n        *ngFor=\"let info of orderEntry.configurationInfos; let i = index\"\n        class=\"cx-configuration-info\"\n        attr.aria-describedby=\"{{ getHiddenConfigurationInfoId(i) }}\"\n      >\n        <span\n          id=\"{{ getHiddenConfigurationInfoId(i) }}\"\n          class=\"cx-visually-hidden\"\n        >\n          {{\n            'configurator.a11y.cartEntryInfo'\n              | cxTranslate\n                : {\n                    attribute: info.configurationLabel,\n                    value: info.configurationValue,\n                  }\n          }}\n        </span>\n        <div class=\"cx-label\" aria-hidden=\"true\">\n          {{ info?.configurationLabel }}:\n        </div>\n        <div class=\"cx-value\" aria-hidden=\"true\">\n          {{ info?.configurationValue }}\n        </div>\n      </div>\n    </ng-container>\n    <ng-container *ngIf=\"quantityControl$ | async as quantityControl\">\n      <cx-configure-cart-entry\n        *ngIf=\"(shouldShowButton$ | async) && orderEntry?.product?.configurable\"\n        [cartEntry]=\"orderEntry\"\n        [readOnly]=\"(readonly$ | async) ?? false\"\n        [msgBanner]=\"false\"\n        [disabled]=\"quantityControl.disabled\"\n      ></cx-configure-cart-entry\n    ></ng-container>\n  </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: ConfigureCartEntryComponent, selector: "cx-configure-cart-entry", inputs: ["cartEntry", "readOnly", "msgBanner", "disabled"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorCartEntryInfoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-configurator-cart-entry-info', imports: [NgIf, NgFor, ConfigureCartEntryComponent, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"orderEntry$ | async as orderEntry\">\n  <ng-container *ngIf=\"isAttributeBasedConfigurator(orderEntry)\">\n    <ng-container *ngIf=\"hasStatus(orderEntry)\">\n      <span\n        *ngIf=\"orderEntry.configurationInfos?.length ?? 0 > 0\"\n        class=\"cx-intro cx-visually-hidden\"\n      >\n        {{ 'configurator.a11y.cartEntryInfoIntro' | cxTranslate }}\n      </span>\n      <div\n        *ngFor=\"let info of orderEntry.configurationInfos; let i = index\"\n        class=\"cx-configuration-info\"\n        attr.aria-describedby=\"{{ getHiddenConfigurationInfoId(i) }}\"\n      >\n        <span\n          id=\"{{ getHiddenConfigurationInfoId(i) }}\"\n          class=\"cx-visually-hidden\"\n        >\n          {{\n            'configurator.a11y.cartEntryInfo'\n              | cxTranslate\n                : {\n                    attribute: info.configurationLabel,\n                    value: info.configurationValue,\n                  }\n          }}\n        </span>\n        <div class=\"cx-label\" aria-hidden=\"true\">\n          {{ info?.configurationLabel }}:\n        </div>\n        <div class=\"cx-value\" aria-hidden=\"true\">\n          {{ info?.configurationValue }}\n        </div>\n      </div>\n    </ng-container>\n    <ng-container *ngIf=\"quantityControl$ | async as quantityControl\">\n      <cx-configure-cart-entry\n        *ngIf=\"(shouldShowButton$ | async) && orderEntry?.product?.configurable\"\n        [cartEntry]=\"orderEntry\"\n        [readOnly]=\"(readonly$ | async) ?? false\"\n        [msgBanner]=\"false\"\n        [disabled]=\"quantityControl.disabled\"\n      ></cx-configure-cart-entry\n    ></ng-container>\n  </ng-container>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: i2.CartItemContext, decorators: [{
                    type: Optional
                }] }, { type: CommonConfiguratorUtilsService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ConfiguratorCartEntryInfoModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorCartEntryInfoModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorCartEntryInfoModule, imports: [CommonModule,
            UrlModule,
            I18nModule,
            IconModule,
            ConfiguratorIssuesNotificationModule,
            ConfigureCartEntryModule,
            ConfiguratorCartEntryInfoComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorCartEntryInfoModule, providers: [
            provideOutlet({
                id: CartOutlets.ITEM_DETAILS,
                position: OutletPosition.AFTER,
                component: ConfiguratorCartEntryInfoComponent,
            }),
        ], imports: [CommonModule,
            UrlModule,
            I18nModule,
            IconModule,
            ConfiguratorIssuesNotificationModule,
            ConfigureCartEntryModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorCartEntryInfoModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        UrlModule,
                        I18nModule,
                        IconModule,
                        ConfiguratorIssuesNotificationModule,
                        ConfigureCartEntryModule,
                        ConfiguratorCartEntryInfoComponent,
                    ],
                    providers: [
                        provideOutlet({
                            id: CartOutlets.ITEM_DETAILS,
                            position: OutletPosition.AFTER,
                            component: ConfiguratorCartEntryInfoComponent,
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var ConfiguratorProductScope;
(function (ConfiguratorProductScope) {
    ConfiguratorProductScope["CONFIGURATOR"] = "configurator";
    ConfiguratorProductScope["CONFIGURATOR_PRODUCT_CARD"] = "configuratorProductCard";
})(ConfiguratorProductScope || (ConfiguratorProductScope = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ConfigureProductComponent {
    getProduct() {
        if (this.productListItemContext) {
            return this.productListItemContext.product$;
        }
        return this.currentProductService
            ? this.currentProductService.getProduct([
                ProductScope.DETAILS,
                ConfiguratorProductScope.CONFIGURATOR,
            ])
            : of(null);
    }
    /**
     * Retrieves a translation key for aria-label depending on the condition.
     *
     * @param configuratorType - configurator type
     * @returns - If the configurator type contains a read-only postfix then 'configurator.a11y.showDetailsProduct' translation key will be returned,
     * otherwise 'configurator.a11y.configureProduct'.
     */
    getAriaLabelTranslationKey(configuratorType) {
        return this.isConfiguratorTypeReadOnly(configuratorType)
            ? 'configurator.a11y.showDetailsProduct'
            : 'configurator.a11y.configureProduct';
    }
    /**
     * Retrieves a translation key depending on the condition.
     *
     * @param configuratorType - configurator type
     * @returns - If the configurator type contains a read-only postfix then 'configurator.header.toConfigReadOnly' translation key will be returned,
     * otherwise 'configurator.header.toconfig'.
     */
    getTranslationKey(configuratorType) {
        return this.isConfiguratorTypeReadOnly(configuratorType)
            ? 'configurator.header.toConfigReadOnly'
            : 'configurator.header.toconfig';
    }
    /**
     * Verifies whether restart dialog should be displayed or not.
     *
     * @param configuratorType
     * @returns - If the configurator type contains a read-only postfix then false will be returned, otherwise true.
     */
    isDisplayRestartDialog(configuratorType) {
        return this.isConfiguratorTypeReadOnly(configuratorType) ? 'false' : 'true';
    }
    /**
     * Verifies whether a configurator type of a product contains a read-only postfix and
     * a product is a base product.
     *
     * @param product - product
     * @returns - If the configurator type contains a read-only postfix and
     * a product is a base product then returns true, otherwise false.
     */
    isReadOnlyBaseProduct(product) {
        return (this.isConfiguratorTypeReadOnly(product.configuratorType) &&
            this.isBaseProduct(product));
    }
    /**
     * Verifies whether a product is a base product.
     *
     * The `baseProduct` property contains the product code of the base product.
     * If the `baseProduct` is undefined or if the provided product code equals the code of the base product,
     * then this product is a base product.
     *
     * @param product - product
     * @returns - If a product is a base product then returns true, otherwise false.
     * @protected
     */
    isBaseProduct(product) {
        return !product.baseProduct || product.baseProduct === product.code;
    }
    navigateToConfigurator(product) {
        this.routingService?.go({
            cxRoute: 'configure' + product.configuratorType,
            params: {
                ownerType: this.ownerTypeProduct,
                entityKey: product.code,
            },
        }, {
            queryParams: {
                displayRestartDialog: this.isDisplayRestartDialog(product.configuratorType),
                productCode: product.code,
            },
        });
    }
    isConfiguratorTypeReadOnly(configuratorType) {
        return (!!configuratorType && configuratorType.trim().endsWith(ReadOnlyPostfix));
    }
    constructor(productListItemContext, // when on PLP
    currentProductService // when on PDP
    ) {
        this.productListItemContext = productListItemContext;
        this.currentProductService = currentProductService;
        this.nonConfigurable = { configurable: false };
        this.product$ = this.getProduct().pipe(
        //needed because also currentProductService might return null
        map((product) => (product ? product : this.nonConfigurable)));
        this.ownerTypeProduct = CommonConfigurator.OwnerType.PRODUCT;
        this.routingService = inject(RoutingService, {
            optional: true,
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfigureProductComponent, deps: [{ token: i1$1.ProductListItemContext, optional: true }, { token: i1$1.CurrentProductService, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: ConfigureProductComponent, isStandalone: true, selector: "cx-configure-product", ngImport: i0, template: "<ng-container *ngIf=\"product$ | async as product\">\n  <ng-container *ngIf=\"product.configurable && !isReadOnlyBaseProduct(product)\">\n    <button\n      (click)=\"navigateToConfigurator(product)\"\n      class=\"btn btn-primary btn-block\"\n      cxAutoFocus\n      [attr.aria-label]=\"\n        getAriaLabelTranslationKey(product.configuratorType) | cxTranslate\n      \"\n    >\n      {{ getTranslationKey(product.configuratorType) | cxTranslate }}\n    </button>\n  </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfigureProductComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-configure-product', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"product$ | async as product\">\n  <ng-container *ngIf=\"product.configurable && !isReadOnlyBaseProduct(product)\">\n    <button\n      (click)=\"navigateToConfigurator(product)\"\n      class=\"btn btn-primary btn-block\"\n      cxAutoFocus\n      [attr.aria-label]=\"\n        getAriaLabelTranslationKey(product.configuratorType) | cxTranslate\n      \"\n    >\n      {{ getTranslationKey(product.configuratorType) | cxTranslate }}\n    </button>\n  </ng-container>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: i1$1.ProductListItemContext, decorators: [{
                    type: Optional
                }] }, { type: i1$1.CurrentProductService, decorators: [{
                    type: Optional
                }] }], propDecorators: { routingService: [{
                type: Optional
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ConfigureProductModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfigureProductModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: ConfigureProductModule, imports: [CommonModule,
            RouterModule, i1.ConfigModule, UrlModule,
            I18nModule,
            IconModule,
            BtnLikeLinkModule,
            ConfigureProductComponent], exports: [ConfigureProductComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfigureProductModule, providers: [
            provideOutlet({
                id: ProductListOutlets.ITEM_ACTIONS,
                position: OutletPosition.AFTER,
                component: ConfigureProductComponent,
            }),
        ], imports: [CommonModule,
            RouterModule,
            ConfigModule.withConfig({
                cmsComponents: {
                    ConfigureProductComponent: {
                        component: ConfigureProductComponent,
                    },
                },
            }),
            UrlModule,
            I18nModule,
            IconModule,
            BtnLikeLinkModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfigureProductModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        ConfigModule.withConfig({
                            cmsComponents: {
                                ConfigureProductComponent: {
                                    component: ConfigureProductComponent,
                                },
                            },
                        }),
                        UrlModule,
                        I18nModule,
                        IconModule,
                        BtnLikeLinkModule,
                        ConfigureProductComponent,
                    ],
                    providers: [
                        provideOutlet({
                            id: ProductListOutlets.ITEM_ACTIONS,
                            position: OutletPosition.AFTER,
                            component: ConfigureProductComponent,
                        }),
                    ],
                    exports: [ConfigureProductComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Service for mapping of the CPQ line items from order entry
 */
class ConfiguratorCartEntryBundleInfoService {
    constructor() {
        this.logger = inject(LoggerService);
    }
    /**
     * Retrieves the CPQ line items for an order entry
     *
     * @param {OrderEntry} entry - Order entry
     * @returns {LineItem[]} - Line item array
     */
    retrieveLineItems(entry) {
        let lineItems = [];
        if (entry.configurationInfos) {
            const configurationInfos = entry.configurationInfos.filter((configurationInfo) => configurationInfo &&
                (configurationInfo.configurationLabel ||
                    configurationInfo.configurationValue));
            const firstLabel = configurationInfos[0]?.configurationLabel;
            const firstValue = configurationInfos[0]?.configurationValue;
            if (firstLabel !== ConfigurationInfoSpecialFields.VERSION) {
                configurationInfos.forEach((configurationInfo) => lineItems.push(this.prepareLineItem(configurationInfo)));
            }
            else if (firstLabel === ConfigurationInfoSpecialFields.VERSION &&
                Number(firstValue) >= 2) {
                lineItems = this.processConfigurationInfos(configurationInfos);
            }
            else {
                this.logWarning('Wrong ConfigurationInfo version');
            }
        }
        return lineItems;
    }
    prepareLineItem(configurationInfo) {
        const quantityAndPrice = configurationInfo.configurationValue
            ? configurationInfo.configurationValue.split('x')
            : [];
        return {
            name: configurationInfo.configurationLabel
                ? this.removeDelimiter(configurationInfo.configurationLabel)
                : '',
            formattedQuantity: quantityAndPrice.length >= 1 ? quantityAndPrice[0].trim() : '',
            formattedPrice: quantityAndPrice.length >= 2 ? quantityAndPrice[1].trim() : '',
        };
    }
    removeDelimiter(label) {
        let preparedLabel = label.trim();
        const lastCharacter = preparedLabel.charAt(preparedLabel.length - 1);
        if (lastCharacter === ':') {
            preparedLabel = preparedLabel.substring(0, preparedLabel.length - 1);
        }
        return preparedLabel;
    }
    processConfigurationInfos(configurationInfos) {
        const lineItemMap = new Map();
        configurationInfos.forEach((configurationInfo) => this.processConfigurationInfoEntry(lineItemMap, configurationInfo));
        // sort
        const lineItemMapSorted = new Map(Array.from(lineItemMap).sort((a, b) => {
            return a[0] - b[0];
        }));
        // convert to array
        const lineItems = Array.from(lineItemMapSorted.values());
        return lineItems;
    }
    processConfigurationInfoEntry(lineItemMap, configurationInfo) {
        if (configurationInfo.configurationLabel) {
            const configurationInfoSplit = configurationInfo.configurationLabel.split(ConfigurationInfoSpecialFields.LINE_ITEM_DELIMITER);
            if (configurationInfoSplit[0] === ConfigurationInfoSpecialFields.LINE_ITEM) {
                const configurationInfoValue = configurationInfo.configurationValue
                    ? configurationInfo.configurationValue
                    : '';
                this.addLineItemData(lineItemMap, configurationInfoSplit, configurationInfoValue);
            }
        }
    }
    addLineItemData(lineItemMap, configurationInfoSplit, configurationInfoValue) {
        if (configurationInfoSplit.length === 3) {
            const lineItemNumber = Number(configurationInfoSplit[1]);
            let lineItem;
            switch (configurationInfoSplit[2]) {
                case ConfigurationInfoFields.NAME:
                    lineItem = this.getOrCreateLineItem(lineItemMap, lineItemNumber);
                    lineItem.name = configurationInfoValue;
                    break;
                case ConfigurationInfoFields.QTY:
                    lineItem = this.getOrCreateLineItem(lineItemMap, lineItemNumber);
                    lineItem.formattedQuantity = configurationInfoValue;
                    break;
                case ConfigurationInfoFields.FORMATTED_PRICE:
                    lineItem = this.getOrCreateLineItem(lineItemMap, lineItemNumber);
                    lineItem.formattedPrice = configurationInfoValue;
                    break;
                case ConfigurationInfoFields.KEY:
                case ConfigurationInfoFields.PRICE_VALUE:
                case ConfigurationInfoFields.PARENT:
                    break;
                default: {
                    this.logWarning('Wrong LineItem format');
                }
            }
        }
        else {
            this.logWarning('Wrong LineItem format');
        }
    }
    getOrCreateLineItem(lineItemMap, lineItemNumber) {
        const lineItem = lineItemMap.get(lineItemNumber) ?? {
            name: '',
            formattedQuantity: '',
            formattedPrice: '',
        };
        if (!lineItemMap.get(lineItemNumber)) {
            lineItemMap.set(lineItemNumber, lineItem);
        }
        return lineItem;
    }
    logWarning(text) {
        if (isDevMode()) {
            this.logger.warn(text);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorCartEntryBundleInfoService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorCartEntryBundleInfoService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorCartEntryBundleInfoService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Requires default change detection strategy, as the disabled state of the quantity from control may change,
 * which would not be proper detected with onPush strategy.
 */
class ConfiguratorCartEntryBundleInfoComponent {
    constructor(commonConfigUtilsService, configCartEntryBundleInfoService, breakpointService, translation, cartItemContext) {
        this.commonConfigUtilsService = commonConfigUtilsService;
        this.configCartEntryBundleInfoService = configCartEntryBundleInfoService;
        this.breakpointService = breakpointService;
        this.translation = translation;
        this.cartItemContext = cartItemContext;
        this.orderEntry$ = this.cartItemContext?.item$ ?? EMPTY;
        this.quantityControl$ = this.cartItemContext?.quantityControl$ ?? EMPTY;
        this.readonly$ = this.cartItemContext?.readonly$ ?? EMPTY;
        this.hideItems = true;
        this.lineItems$ = this.orderEntry$.pipe(map((entry) => this.configCartEntryBundleInfoService.retrieveLineItems(entry)));
        this.numberOfLineItems$ = this.lineItems$.pipe(map((items) => items.length));
        // TODO: remove the logic below when configurable products support "Saved Cart" and "Save For Later"
        this.shouldShowButton$ = this.commonConfigUtilsService.isActiveCartContext(this.cartItemContext);
    }
    /**
     * Toggles the state of the items list.
     */
    toggleItems() {
        this.hideItems = !this.hideItems;
    }
    /**
     * Verifies whether the configurator type is a bundle based one.
     *
     * @param {OrderEntry} entry - Order entry
     * @returns {boolean} - 'true' if the expected configurator type, otherwise 'false'
     */
    isBundleBasedConfigurator(entry) {
        const configInfos = entry.configurationInfos;
        return configInfos
            ? this.commonConfigUtilsService.isBundleBasedConfigurator(configInfos[0]?.configuratorType)
            : false;
    }
    getButtonText(translatedText) {
        if (!translatedText) {
            translatedText = '';
        }
        if (this.hideItems) {
            this.translation
                .translate('configurator.header.show')
                .pipe(take(1))
                .subscribe((text) => (translatedText += text));
        }
        else {
            this.translation
                .translate('configurator.header.hide')
                .pipe(take(1))
                .subscribe((text) => (translatedText += text));
        }
        return translatedText;
    }
    getItemsMsg(items) {
        let translatedText = '';
        this.translation
            .translate('configurator.a11y.cartEntryBundleInfo', { items: items })
            .pipe(take(1))
            .subscribe((text) => (translatedText = text));
        return this.getButtonText(translatedText);
    }
    getHiddenItemInfo(item) {
        let translatedText = '';
        if (item.name && item.formattedPrice && item.formattedQuantity) {
            this.translation
                .translate('configurator.a11y.cartEntryBundle', {
                name: item.name,
                price: item.formattedPrice,
                quantity: item.formattedQuantity,
            })
                .pipe(take(1))
                .subscribe((text) => (translatedText = text));
        }
        else if (item.name && item.formattedPrice) {
            this.translation
                .translate('configurator.a11y.cartEntryBundleNameWithPrice', {
                name: item.name,
                price: item.formattedPrice,
            })
                .pipe(take(1))
                .subscribe((text) => (translatedText = text));
        }
        else if (item.name && item.formattedQuantity) {
            this.translation
                .translate('configurator.a11y.cartEntryBundleNameWithQuantity', {
                name: item.name,
                quantity: item.formattedQuantity,
            })
                .pipe(take(1))
                .subscribe((text) => (translatedText = text));
        }
        else {
            this.translation
                .translate('configurator.a11y.cartEntryBundleName', {
                name: item.name,
            })
                .pipe(take(1))
                .subscribe((text) => (translatedText = text));
        }
        return translatedText;
    }
    getHiddenItemInfoId(index) {
        return 'cx-item-hidden-info-' + index.toString();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorCartEntryBundleInfoComponent, deps: [{ token: CommonConfiguratorUtilsService }, { token: ConfiguratorCartEntryBundleInfoService }, { token: i1$1.BreakpointService }, { token: i1.TranslationService }, { token: i2.CartItemContext, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: ConfiguratorCartEntryBundleInfoComponent, isStandalone: true, selector: "cx-configurator-cart-entry-bundle-info", ngImport: i0, template: "<ng-container *ngIf=\"orderEntry$ | async as orderEntry\">\n  <ng-container *ngIf=\"isBundleBasedConfigurator(orderEntry)\">\n    <ng-container *ngIf=\"numberOfLineItems$ | async as numberOfItems\">\n      <div class=\"cx-number-items\">\n        {{\n          'configurator.header.items' | cxTranslate: { count: numberOfItems }\n        }}\n      </div>\n      <button\n        (click)=\"toggleItems()\"\n        [attr.aria-expanded]=\"!this.hideItems\"\n        [attr.aria-label]=\"getItemsMsg(numberOfItems)\"\n      >\n        <div class=\"cx-toggle-hide-items\">\n          {{ getButtonText() }}\n        </div>\n      </button>\n\n      <div class=\"cx-item-infos\" [class.open]=\"!hideItems\">\n        <div\n          *ngFor=\"let lineItem of lineItems$ | async; let i = index\"\n          class=\"cx-item-info\"\n          attr.aria-describedby=\"{{ getHiddenItemInfoId(i) }}\"\n        >\n          <span id=\"{{ getHiddenItemInfoId(i) }}\" class=\"cx-visually-hidden\">\n            {{ getHiddenItemInfo(lineItem) }}\n          </span>\n          <div class=\"cx-item-name\" aria-hidden=\"true\">\n            {{ lineItem?.name }}\n          </div>\n          <div class=\"cx-item-quantity\" aria-hidden=\"true\">\n            <ng-container *ngIf=\"lineItem?.formattedQuantity\">\n              <span class=\"cx-identifier\">{{\n                'configurator.attribute.quantity' | cxTranslate\n              }}</span>\n              <span class=\"cx-item\">{{\n                lineItem?.formattedQuantity | cxNumeric\n              }}</span>\n            </ng-container>\n          </div>\n          <div class=\"cx-item-price\" aria-hidden=\"true\">\n            <ng-container *ngIf=\"lineItem?.formattedPrice\">\n              <span class=\"cx-identifier\">{{\n                'configurator.overviewForm.itemPrice' | cxTranslate\n              }}</span>\n              <span class=\"cx-item\">{{ lineItem?.formattedPrice }}</span>\n            </ng-container>\n          </div>\n        </div>\n      </div>\n    </ng-container>\n    <ng-container *ngIf=\"quantityControl$ | async as quantityControl\">\n      <cx-configure-cart-entry\n        *ngIf=\"(shouldShowButton$ | async) && orderEntry?.product?.configurable\"\n        [cartEntry]=\"orderEntry\"\n        [readOnly]=\"(readonly$ | async) ?? false\"\n        [msgBanner]=\"false\"\n        [disabled]=\"quantityControl.disabled\"\n      ></cx-configure-cart-entry\n    ></ng-container>\n  </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: ConfigureCartEntryComponent, selector: "cx-configure-cart-entry", inputs: ["cartEntry", "readOnly", "msgBanner", "disabled"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: CxNumericPipe, name: "cxNumeric" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorCartEntryBundleInfoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-configurator-cart-entry-bundle-info', imports: [
                        NgIf,
                        NgFor,
                        ConfigureCartEntryComponent,
                        AsyncPipe,
                        TranslatePipe,
                        CxNumericPipe,
                    ], template: "<ng-container *ngIf=\"orderEntry$ | async as orderEntry\">\n  <ng-container *ngIf=\"isBundleBasedConfigurator(orderEntry)\">\n    <ng-container *ngIf=\"numberOfLineItems$ | async as numberOfItems\">\n      <div class=\"cx-number-items\">\n        {{\n          'configurator.header.items' | cxTranslate: { count: numberOfItems }\n        }}\n      </div>\n      <button\n        (click)=\"toggleItems()\"\n        [attr.aria-expanded]=\"!this.hideItems\"\n        [attr.aria-label]=\"getItemsMsg(numberOfItems)\"\n      >\n        <div class=\"cx-toggle-hide-items\">\n          {{ getButtonText() }}\n        </div>\n      </button>\n\n      <div class=\"cx-item-infos\" [class.open]=\"!hideItems\">\n        <div\n          *ngFor=\"let lineItem of lineItems$ | async; let i = index\"\n          class=\"cx-item-info\"\n          attr.aria-describedby=\"{{ getHiddenItemInfoId(i) }}\"\n        >\n          <span id=\"{{ getHiddenItemInfoId(i) }}\" class=\"cx-visually-hidden\">\n            {{ getHiddenItemInfo(lineItem) }}\n          </span>\n          <div class=\"cx-item-name\" aria-hidden=\"true\">\n            {{ lineItem?.name }}\n          </div>\n          <div class=\"cx-item-quantity\" aria-hidden=\"true\">\n            <ng-container *ngIf=\"lineItem?.formattedQuantity\">\n              <span class=\"cx-identifier\">{{\n                'configurator.attribute.quantity' | cxTranslate\n              }}</span>\n              <span class=\"cx-item\">{{\n                lineItem?.formattedQuantity | cxNumeric\n              }}</span>\n            </ng-container>\n          </div>\n          <div class=\"cx-item-price\" aria-hidden=\"true\">\n            <ng-container *ngIf=\"lineItem?.formattedPrice\">\n              <span class=\"cx-identifier\">{{\n                'configurator.overviewForm.itemPrice' | cxTranslate\n              }}</span>\n              <span class=\"cx-item\">{{ lineItem?.formattedPrice }}</span>\n            </ng-container>\n          </div>\n        </div>\n      </div>\n    </ng-container>\n    <ng-container *ngIf=\"quantityControl$ | async as quantityControl\">\n      <cx-configure-cart-entry\n        *ngIf=\"(shouldShowButton$ | async) && orderEntry?.product?.configurable\"\n        [cartEntry]=\"orderEntry\"\n        [readOnly]=\"(readonly$ | async) ?? false\"\n        [msgBanner]=\"false\"\n        [disabled]=\"quantityControl.disabled\"\n      ></cx-configure-cart-entry\n    ></ng-container>\n  </ng-container>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: CommonConfiguratorUtilsService }, { type: ConfiguratorCartEntryBundleInfoService }, { type: i1$1.BreakpointService }, { type: i1.TranslationService }, { type: i2.CartItemContext, decorators: [{
                    type: Optional
                }] }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ConfiguratorCartEntryBundleInfoModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorCartEntryBundleInfoModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorCartEntryBundleInfoModule, imports: [CommonModule,
            I18nModule,
            ConfigureCartEntryModule,
            ConfiguratorCartEntryBundleInfoComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorCartEntryBundleInfoModule, providers: [
            provideOutlet({
                id: CartOutlets.ITEM_BUNDLE_DETAILS,
                position: OutletPosition.AFTER,
                component: ConfiguratorCartEntryBundleInfoComponent,
            }),
        ], imports: [CommonModule,
            I18nModule,
            ConfigureCartEntryModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorCartEntryBundleInfoModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        ConfigureCartEntryModule,
                        ConfiguratorCartEntryBundleInfoComponent,
                    ],
                    providers: [
                        provideOutlet({
                            id: CartOutlets.ITEM_BUNDLE_DETAILS,
                            position: OutletPosition.AFTER,
                            component: ConfiguratorCartEntryBundleInfoComponent,
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CommonConfiguratorComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CommonConfiguratorComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CommonConfiguratorComponentsModule, imports: [ConfiguratorIssuesNotificationModule,
            ConfiguratorCartEntryInfoModule,
            ConfiguratorCartEntryBundleInfoModule,
            ConfigureCartEntryModule,
            ConfigureProductModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CommonConfiguratorComponentsModule, imports: [ConfiguratorIssuesNotificationModule,
            ConfiguratorCartEntryInfoModule,
            ConfiguratorCartEntryBundleInfoModule,
            ConfigureCartEntryModule,
            ConfigureProductModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CommonConfiguratorComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        ConfiguratorIssuesNotificationModule,
                        ConfiguratorCartEntryInfoModule,
                        ConfiguratorCartEntryBundleInfoModule,
                        ConfigureCartEntryModule,
                        ConfigureProductModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOccConfiguratorProductConfig = {
    backend: {
        occ: {
            endpoints: {
                product: {
                    configurator: 'products/${productCode}?fields=code,configurable,configuratorType',
                    configuratorProductCard: 'products/${productCode}?fields=code,description,images(DEFAULT)',
                },
            },
        },
        loadingScopes: {
            product: {
                list: {
                    include: [ConfiguratorProductScope.CONFIGURATOR],
                },
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CommonConfiguratorOccModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CommonConfiguratorOccModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CommonConfiguratorOccModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CommonConfiguratorOccModule, providers: [provideDefaultConfig(defaultOccConfiguratorProductConfig)] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CommonConfiguratorOccModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [provideDefaultConfig(defaultOccConfiguratorProductConfig)],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CommonConfiguratorModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CommonConfiguratorModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CommonConfiguratorModule, imports: [CommonConfiguratorOccModule, CommonConfiguratorComponentsModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CommonConfiguratorModule, imports: [CommonConfiguratorOccModule, CommonConfiguratorComponentsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CommonConfiguratorModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonConfiguratorOccModule, CommonConfiguratorComponentsModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var ConfiguratorRouter;
(function (ConfiguratorRouter) {
    let PageType;
    (function (PageType) {
        PageType["CONFIGURATION"] = "configuration";
        PageType["OVERVIEW"] = "overview";
    })(PageType = ConfiguratorRouter.PageType || (ConfiguratorRouter.PageType = {}));
})(ConfiguratorRouter || (ConfiguratorRouter = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Service to extract the configuration owner key from the current route
 */
class ConfiguratorRouterExtractorService {
    constructor(configUtilsService, routingService) {
        this.configUtilsService = configUtilsService;
        this.routingService = routingService;
        this.ROUTE_FRAGMENT_CONFIGURE = 'configure';
        this.ROUTE_FRAGMENT_OVERVIEW = 'configureOverview';
    }
    extractRouterData() {
        return this.routingService.getRouterState().pipe(filter((routingData) => routingData.state.params.entityKey), 
        //we don't need to cover the intermediate router states where a future route is already known.
        //only changes to the URL are relevant. Otherwise we get wrong hits where e.g. the config form fires although
        //the OV already loads
        filter((routingData) => routingData.nextState === undefined), map((routingData) => {
            const owner = this.createOwnerFromRouterState(routingData);
            const semanticRoute = routingData.state.semanticRoute;
            const routerData = {
                owner: owner,
                isOwnerCartEntry: owner.type === CommonConfigurator.OwnerType.CART_ENTRY,
                displayOnly: routingData.state.params.displayOnly,
                resolveIssues: routingData.state.queryParams?.resolveIssues === 'true',
                skipConflicts: routingData.state.queryParams?.skipConflicts === 'true',
                forceReload: routingData.state.queryParams?.forceReload === 'true',
                expMode: routingData.state.queryParams?.expMode === 'true',
                displayRestartDialog: routingData.state.queryParams?.displayRestartDialog === 'true',
                configIdTemplate: routingData.state.queryParams?.configIdTemplate,
                navigationId: routingData.navigationId,
                pageType: semanticRoute &&
                    semanticRoute.includes(this.ROUTE_FRAGMENT_OVERVIEW)
                    ? ConfiguratorRouter.PageType.OVERVIEW
                    : ConfiguratorRouter.PageType.CONFIGURATION,
                navigateToCheckout: routingData.state.queryParams?.navigateToCheckout === 'true',
                productCode: routingData.state.queryParams?.productCode,
            };
            return routerData;
        }));
    }
    createOwnerFromRouterState(routerState) {
        const owner = ConfiguratorModelUtils.createInitialOwner();
        const params = routerState.state.params;
        if (params.ownerType) {
            const entityKey = params.entityKey;
            owner.type = params.ownerType;
            owner.id = entityKey;
        }
        else {
            owner.type = CommonConfigurator.OwnerType.PRODUCT;
            owner.id = params.rootProduct;
        }
        const semanticRoute = routerState.state.semanticRoute;
        if (semanticRoute) {
            const configuratorType = this.getConfiguratorTypeFromSemanticRoute(semanticRoute);
            owner.configuratorType = configuratorType;
        }
        this.configUtilsService.setOwnerKey(owner);
        return owner;
    }
    /**
     * Compiles the configurator type from the semantic route
     * @param semanticRoute Consists of a prefix that indicates if target is interactive configuration or overview and
     *                      the commerce configurator type as postfix.
     *                      Example: configureTEXTFIELD or configureOverviewCPQCONFIGURATOR
     * @returns Configurator type
     */
    getConfiguratorTypeFromSemanticRoute(semanticRoute) {
        if (semanticRoute.startsWith(this.ROUTE_FRAGMENT_OVERVIEW)) {
            return semanticRoute.split(this.ROUTE_FRAGMENT_OVERVIEW)[1];
        }
        else if (semanticRoute.startsWith(this.ROUTE_FRAGMENT_CONFIGURE)) {
            return semanticRoute.split(this.ROUTE_FRAGMENT_CONFIGURE)[1];
        }
        else {
            throw new Error('Not able to determine configurator type');
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorRouterExtractorService, deps: [{ token: CommonConfiguratorUtilsService }, { token: i1.RoutingService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorRouterExtractorService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ConfiguratorRouterExtractorService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: CommonConfiguratorUtilsService }, { type: i1.RoutingService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/** AUGMENTABLE_TYPES_END */

/**
 * Generated bundle index. Do not edit.
 */

export { CommonConfigurator, CommonConfiguratorComponentsModule, CommonConfiguratorModule, CommonConfiguratorOccModule, CommonConfiguratorUtilsService, ConfigurationInfoFields, ConfigurationInfoSpecialFields, ConfiguratorCartEntryBundleInfoComponent, ConfiguratorCartEntryBundleInfoModule, ConfiguratorCartEntryBundleInfoService, ConfiguratorCartEntryInfoComponent, ConfiguratorCartEntryInfoModule, ConfiguratorIssuesNotificationComponent, ConfiguratorIssuesNotificationModule, ConfiguratorModelUtils, ConfiguratorProductScope, ConfiguratorRouter, ConfiguratorRouterExtractorService, ConfiguratorType, ConfigureCartEntryComponent, ConfigureCartEntryModule, ConfigureProductComponent, ConfigureProductModule, OrderEntryStatus, ReadOnlyPostfix };
//# sourceMappingURL=spartacus-product-configurator-common.mjs.map
