import { Config, CmsConfig } from '@spartacus/core';
import * as i0 from '@angular/core';
import { Renderer2 } from '@angular/core';

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface UsageId {
    name: string;
    keys: UsageIdKey[];
}
/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface UsageIdKey {
    name: string;
    value: string;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface UsageIdDefinition {
    name: string;
    keyName: string;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare abstract class EpdVisualizationConfig implements Config {
    /**
     * This field introduces a namespace for EPD Visualization to avoid collisions when configuration merging occurs.
     */
    epdVisualization?: EpdVisualizationInnerConfig;
    static ɵfac: i0.ɵɵFactoryDeclaration<EpdVisualizationConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EpdVisualizationConfig>;
}
/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface EpdVisualizationInnerConfig {
    /**
     * UI5 configuration
     */
    ui5?: Ui5Config;
    /**
     * SAP Enterprise Product Development Visualization API endpoint configuration.
     */
    apis?: VisualizationApiConfig;
    /**
     * SAP Enterprise Product Development Visualization Usage ID configuration.
     */
    usageIds?: UsageIdConfig;
    /**
     * Configuration for the visual picking scenario.
     */
    visualPicking?: VisualPickingConfig;
}
/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface Ui5Config {
    /**
     * This is the URL that SAPUI5 is bootstrapped from.
     * The value that is configured by default in a given Spartacus release is the SAPUI5 version supported for that Spartacus release.
     *
     * Important: Please check the *End of Cloud Provisioning* column in https://sapui5.hana.ondemand.com/versionoverview.html
     * When the Cloud Provisioning period ends for a particular SAPUI5 version, that version will no longer be available on https://sapui5.hana.ondemand.com
     */
    bootstrapUrl: string;
}
/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface VisualizationApiConfig {
    /**
     * This is the base URL that is used to access the EPD Visualization APIs.
     * Use the origin portion of the URL for your EPD Visualization Fiori Launchpad.
     * i.e. https://mytenant.visualization.eu20.epd.cloud.sap
     */
    baseUrl: string;
}
/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface UsageIdConfig {
    /**
     * Folders in the configured SAP EPD Visualization tenant that have anonymous access enabled and have this Usage ID
     * value applied will be searched for visualizations.
     * This configuration option allows for a separation between staging visualization data and production visualization data.
     */
    folderUsageId: UsageId;
    /**
     * Defines the EPD Visualization usage ID to use to refer to a product in SAP Commerce Cloud.
     * This Usage ID is used on:
     * - Visualizations to allow a visualization to be linked with a product.
     *   This allows a visualization to be found and loaded for the current product in a product details page.
     * - Scene nodes to allow a scene node to be linked with a product.
     *   This allows two way linking between scene nodes and products (which typically represent spare parts).
     */
    productUsageId: UsageIdDefinition;
}
/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface VisualPickingConfig {
    /**
     * This is the type of product reference to list for the active product (typically SPAREPART)
     */
    productReferenceType: string;
}
/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare module '@spartacus/core' {
    interface Config extends EpdVisualizationConfig {
    }
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare function epdVisualizationConfigValidator(epdVisualizationConfig: EpdVisualizationConfig): string | void;

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare function getEpdVisualizationDefaultConfig(): EpdVisualizationConfig;

declare function defaultEpdVisualizationComponentsConfig(): CmsConfig;
/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class EpdVisualizationRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<EpdVisualizationRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EpdVisualizationRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EpdVisualizationRootModule>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const EPD_VISUALIZATION_FEATURE = "epd-visualization";

/**
 * A subset of the content types that may be returned by the EPD Visualization service.
 * We use filtering to ensure that we only get visualizations of the types below returned.
 * Some values start with numbers, so the identifiers do not match the values
 *
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare enum ContentType {
    /**
     * 3D content (rendered using WebGL)
     */
    Model3D = "3DModel",
    /**
     * 2D vector content (rendered using SVG)
     */
    Drawing2D = "2DDrawing"
}

/**
 * Information about a visualization stored in an EPD Visualization service.
 *
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface VisualizationInfo {
    /**
     * The visualization ID.
     */
    visualizationId: string;
    /**
     * The visualization version.
     */
    version: string;
    /**
     * The scene ID.
     */
    sceneId: string;
    /**
     *  The content type of the visualization.
     */
    contentType: ContentType;
    /**
     * The visualization category.
     */
    category: string;
    /**
     * The folderId of the folder containing the visualization. This is intended for debugging purposes only.
     */
    folderId: string;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface Listener {
    nativeElement: any;
    eventName: string;
    endListener: () => void;
}
/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class EventListenerUtils {
    initialize(renderer: Renderer2): void;
    private renderer;
    private listeners;
    attachEventListener(nativeElement: any, eventName: string, callback: (event: any) => void): void;
    detachEventListeners(nativeElement: any, eventName: string): void;
    detachAllEventListeners(nativeElement: any): void;
    _detachEventListeners(eventListeners: Listener[]): void;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare function getUrl(urlString: string): URL | null;
/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare function isHttpOrHttps(url: URL): boolean;

export { ContentType, EPD_VISUALIZATION_FEATURE, EpdVisualizationConfig, EpdVisualizationRootModule, EventListenerUtils, defaultEpdVisualizationComponentsConfig, epdVisualizationConfigValidator, getEpdVisualizationDefaultConfig, getUrl, isHttpOrHttps };
export type { EpdVisualizationInnerConfig, Listener, Ui5Config, UsageId, UsageIdConfig, UsageIdDefinition, UsageIdKey, VisualPickingConfig, VisualizationApiConfig, VisualizationInfo };
