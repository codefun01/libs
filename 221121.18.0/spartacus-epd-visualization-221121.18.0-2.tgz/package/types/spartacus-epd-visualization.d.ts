import * as i0 from '@angular/core';
import * as i1 from '@spartacus/epd-visualization/components';
import * as i2 from '@spartacus/epd-visualization/core';
import * as i3 from '@spartacus/epd-visualization/epd-visualization-api';

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class EpdVisualizationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<EpdVisualizationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EpdVisualizationModule, never, [typeof i1.EpdVisualizationComponentsModule, typeof i2.EpdVisualizationCoreModule, typeof i3.EpdVisualizationApiModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EpdVisualizationModule>;
}

export { EpdVisualizationModule };
