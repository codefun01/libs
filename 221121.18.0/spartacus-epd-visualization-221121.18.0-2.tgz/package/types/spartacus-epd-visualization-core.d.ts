import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import { Converter } from '@spartacus/core';
import { Observable } from 'rxjs';
import { VisualizationInfo, UsageId as UsageId$1, EpdVisualizationConfig } from '@spartacus/epd-visualization/root';

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface NodesResponse {
    nodes?: TreeNode[];
}
/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface TreeNode {
    sid: string;
    usageIds?: UsageId[];
}
/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface UsageId {
    name: string;
    keys: UsageIdKey[];
}
/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface UsageIdKey {
    name: string;
    value: string;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const NODES_RESPONSE_NORMALIZER: InjectionToken<Converter<any, NodesResponse>>;

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare abstract class SceneAdapter {
    /**
     * Used for invoking the EPD Visualization API for retrieving scene node information.
     * @param sceneId The scene id to use as the sceneId path parameter.
     * @param nodeIds An array of scene node ids to pass in id query parameters.
     * @param $expand A set of strings to combine to form the $expand query parameter.
     * @param $filter A set of strings to combine to form the $filter query parameter.
     * @param contentType The contentType query parameter.
     * @returns An Observable producing a NodesResponse which contains an array of objects describing scene nodes.
     */
    abstract getNodes(sceneId: string, nodeIds?: string[], $expand?: string[], $filter?: string[], contentType?: string): Observable<NodesResponse>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class SceneConnector {
    protected sceneAdapter: SceneAdapter;
    constructor(sceneAdapter: SceneAdapter);
    /**
     * Used for invoking the EPD Visualization API for retrieving scene node information.
     * @param sceneId The scene id to use as the sceneId path parameter.
     * @param nodeIds An array of scene node ids to pass in id query parameters.
     * @param $expand A set of strings to combine to form the $expand query parameter.
     * @param $filter A set of strings to combine to form the $filter query parameter.
     * @param contentType The contentType query parameter.
     * @returns An Observable producing a NodesResponse which contains an array of objects describing scene nodes.
     */
    getNodes(sceneId: string, nodeIds?: string[], $expand?: string[], $filter?: string[], contentType?: string): Observable<NodesResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SceneConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SceneConnector>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface LookupVisualizationsResponse {
    visualizations?: VisualizationInfo[];
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const LOOKUP_VISUALIZATIONS_RESPONSE_NORMALIZER: InjectionToken<Converter<any, LookupVisualizationsResponse>>;

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare abstract class VisualizationAdapter {
    /**
     * Used for finding a visualization by Usage ID that has anonymous (unauthenticated) read access enabled.
     * The search is performed in the SAP EPD Visualization service instance associated with the SaaS subscription for the SAP EPD tenant.
     * @param visualizationUsageId The SAP EPD Visualization usage ID value identifying visualizations to match.
     * Only visualizations that have the specified usage ID value will be returned.
     * @param folderUsageId The SAP EPD Visualization usage ID identifying folders to search for visualizations.
     * Only folders that are tagged with the specified usage ID value that have anonymous access enabled will be searched.
     * @returns An Observable producing a LookupVisualizationsResponse which contains an array of objects describing matched visualizations.
     */
    abstract lookupVisualization(visualizationUsageId: UsageId$1, folderUsageId: UsageId$1): Observable<LookupVisualizationsResponse>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualizationConnector {
    protected visualizationAdapter: VisualizationAdapter;
    constructor(visualizationAdapter: VisualizationAdapter);
    /**
     * Used for finding a visualization by Usage ID that has anonymous (unauthenticated) read access enabled.
     * The search is performed in the SAP EPD Visualization service instance associated with the SaaS subscription for the SAP EPD tenant.
     * @param visualizationUsageId The SAP EPD Visualization usage ID value identifying visualizations to match.
     * Only visualizations that have the specified usage ID value will be returned.
     * @param folderUsageId The SAP EPD Visualization usage ID identifying folders to search for visualizations.
     * Only folders that are tagged with the specified usage ID value that have anonymous access enabled will be searched.
     * @returns An Observable producing a LookupVisualizationsResponse which contains an array of objects describing matched visualizations.
     */
    lookupVisualization(visualizationUsageId: UsageId$1, folderUsageId: UsageId$1): Observable<LookupVisualizationsResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualizationConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VisualizationConnector>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface NodeIdProductCodes {
    nodeId: string;
    productCodes: string[];
}
/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class SceneNodeToProductLookupService {
    protected epdVisualizationConfig: EpdVisualizationConfig;
    protected sceneConnector: SceneConnector;
    constructor(epdVisualizationConfig: EpdVisualizationConfig, sceneConnector: SceneConnector);
    private productUsageId;
    /**
     * Called to populate the maps with the data for the given scene.
     * This can be done before the scene has been loaded since this just involves a storage service API call
     * @param sceneId The scene id of the loaded scene.
     */
    populateMapsForScene(sceneId: string): void;
    private productCodesByNodeIdMap$;
    private nodeIdsByProductCodeMap$;
    private getNodeIdProductCodesForScene;
    private getProductCodesByNodeIdMap;
    private getNodeIdsByProductCodeMap;
    /**
     * Get distinct values while retaining ordering.
     */
    private distinct;
    private _lookupProductCodes;
    /**
     * Returns an Observable producing an array of product codes corresponding to the specified scene node ids in the currently loaded scene.
     * @param nodeIds The scene node ids.
     * @returns An Observable producing an array of product codes corresponding to the specified scene node ids in the currently loaded scene.
     */
    lookupProductCodes(nodeIds: string[]): Observable<string[]>;
    /**
     * Returns an array of product codes corresponding to the specified scene node ids in the currently loaded scene.
     * Returns an empty array if the map of product codes by node id has not yet been populated.
     * For cases where the code must execute synchronously.
     * @param nodeIds The scene node ids.
     * @returns An array of product codes corresponding to the specified scene node ids in the currently loaded scene.
     */
    syncLookupProductCodes(nodeIds: string[]): string[];
    private _lookupNodeIds;
    /**
     * Returns an Observable producing an array of scene node ids corresponding to the specified product codes in the currently loaded scene.
     * @param productCodes The product codes.
     * @returns An Observable producing an array of scene node ids corresponding to the specified product codes in the currently loaded scene.
     */
    lookupNodeIds(productCodes: string[]): Observable<string[]>;
    /**
     * Returns an array of scene node ids corresponding to the specified product codes in the currently loaded scene.
     * Returns an empty array if the map of node ids by product code has not yet been populated.
     * For cases where the code must execute synchronously.
     * @param productCodes The product codes.
     * @returns An array of scene node ids corresponding to the specified product codes in the currently loaded scene.
     */
    syncLookupNodeIds(productCodes: string[]): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<SceneNodeToProductLookupService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SceneNodeToProductLookupService>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualizationLookupService {
    protected epdVisualizationConfig: EpdVisualizationConfig;
    protected visualizationConnector: VisualizationConnector;
    constructor(epdVisualizationConfig: EpdVisualizationConfig, visualizationConnector: VisualizationConnector);
    /**
     * Finds visualizations by usage id containing product code values.
     * The search space is limited to folders with a configured usage id value.
     * @param productCode The product code value to search for.
     * @returns An Observable producing an VisualizationInfo array containing the set of matching visualizations.
     */
    findMatchingVisualizations(productCode: string): Observable<VisualizationInfo[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualizationLookupService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VisualizationLookupService>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class EpdVisualizationCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<EpdVisualizationCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EpdVisualizationCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EpdVisualizationCoreModule>;
}

export { EpdVisualizationCoreModule, LOOKUP_VISUALIZATIONS_RESPONSE_NORMALIZER, NODES_RESPONSE_NORMALIZER, SceneAdapter, SceneConnector, SceneNodeToProductLookupService, VisualizationAdapter, VisualizationConnector, VisualizationLookupService };
export type { LookupVisualizationsResponse, NodeIdProductCodes, NodesResponse, TreeNode, UsageId, UsageIdKey };
