import * as i0 from '@angular/core';
import { ElementRef, Renderer2, ChangeDetectorRef, EventEmitter, AfterViewInit, OnDestroy, OnInit, TemplateRef } from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@angular/router';
import * as i5 from '@spartacus/core';
import { WindowRef, LoggerService, Product, ProductReference, ProductReferenceService, GlobalMessageService } from '@spartacus/core';
import * as i3 from '@spartacus/storefront';
import { ICON_TYPE, CurrentProductService } from '@spartacus/storefront';
import { BehaviorSubject, Observable } from 'rxjs';
import { VisualizationInfo, ContentType, EpdVisualizationConfig } from '@spartacus/epd-visualization/root';
import { SceneNodeToProductLookupService, VisualizationLookupService } from '@spartacus/epd-visualization/core';
import * as i2$1 from '@angular/forms';
import { AddToCartComponent } from '@spartacus/cart/base/components/add-to-cart';

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualViewerToolbarButtonComponent {
    text: string;
    iconLibraryClass: string;
    iconClass: string;
    disabled: boolean;
    checked: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualViewerToolbarButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VisualViewerToolbarButtonComponent, "cx-epd-visualization-viewer-toolbar-button", never, { "text": { "alias": "text"; "required": false; }; "iconLibraryClass": { "alias": "iconLibraryClass"; "required": false; }; "iconClass": { "alias": "iconClass"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualViewerToolbarButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualViewerToolbarButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VisualViewerToolbarButtonModule, never, [typeof i1.CommonModule, typeof i3.IconModule, typeof VisualViewerToolbarButtonComponent], [typeof VisualViewerToolbarButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VisualViewerToolbarButtonModule>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualViewerAnimationSliderService {
    private elementRef;
    private windowRef;
    private renderer;
    private changeDetectorRef;
    constructor(elementRef: ElementRef, windowRef: WindowRef, renderer: Renderer2, changeDetectorRef: ChangeDetectorRef);
    initialize(): void;
    private setInitialized;
    get initialized(): boolean;
    private _initialized;
    initializedChange: EventEmitter<boolean>;
    /**
     * Slider value. Value is in the range [0-1].
     */
    set value(value: number);
    get value(): number;
    private _value;
    valueChange: EventEmitter<number>;
    set disabled(disabled: boolean);
    get disabled(): boolean;
    private _disabled;
    set hidden(hidden: boolean);
    get hidden(): boolean;
    private _hidden;
    get position(): number;
    get rightToLeft(): boolean;
    set barElement(barElement: ElementRef);
    get barElement(): ElementRef;
    _barElement: ElementRef;
    set handleElement(handleElement: ElementRef);
    get handleElement(): ElementRef;
    _handleElement: ElementRef;
    private set resizeObserver(value);
    private get resizeObserver();
    private _resizeObserver?;
    private eventListenerUtils;
    private set touchIdentifier(value);
    private get touchIdentifier();
    private _touchIdentifier?;
    private getClientWidth;
    private getClientRect;
    private resizeObserverSupported;
    private setupResizeObserver;
    private onResize;
    sizeChange: EventEmitter<any>;
    private updateEventBindings;
    get handleWidth(): number;
    get barWidth(): number;
    get handleMaxPosition(): number;
    private valueToPosition;
    private positionToValue;
    private findTouch;
    private get sliderClientPosition();
    private onTouchStart;
    private onTouchStartOnBar;
    private onMouseDown;
    private onMouseDownOnBar;
    private onMouseMove;
    private onMouseUp;
    private onTouchMove;
    private onTouchEnd;
    private onHandleFocus;
    private onHandleBlur;
    private onKeyboardEvent;
    protected readonly stepDelta: number;
    protected readonly pageDelta: number;
    private getKeyHandler;
    private applyValue;
    private clampToRange;
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualViewerAnimationSliderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VisualViewerAnimationSliderService>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualViewerAnimationSliderComponent implements AfterViewInit {
    protected visualViewerAnimationSliderService: VisualViewerAnimationSliderService;
    constructor(visualViewerAnimationSliderService: VisualViewerAnimationSliderService);
    ngAfterViewInit(): void;
    set hidden(hidden: boolean);
    get hidden(): boolean;
    set value(value: number);
    get value(): number;
    valueChange: EventEmitter<number>;
    get position(): number;
    set disabled(disabled: boolean);
    get disabled(): boolean;
    get initialized(): boolean;
    initializedChange: EventEmitter<boolean>;
    set barElement(barElement: ElementRef);
    set handleElement(handleElement: ElementRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualViewerAnimationSliderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VisualViewerAnimationSliderComponent, "cx-epd-visualization-animation-slider", never, { "hidden": { "alias": "hidden"; "required": false; }; "value": { "alias": "value"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "valueChange": "valueChange"; "initializedChange": "initializedChange"; }, never, never, true, never>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualViewerAnimationSliderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualViewerAnimationSliderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VisualViewerAnimationSliderModule, never, [typeof i1.CommonModule, typeof i5.I18nModule, typeof VisualViewerAnimationSliderComponent], [typeof VisualViewerAnimationSliderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VisualViewerAnimationSliderModule>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare enum NavigationMode {
    /**
     * Left mouse button drag causes turntable rotation.
     */
    Turntable = "Turntable",
    /**
     * Left mouse button drag performs panning.
     */
    Pan = "Pan",
    /**
     * Left mouse button drag performs zooming.
     */
    Zoom = "Zoom"
}

/**
 * Defines the selection behaviour.
 *
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare enum SelectionMode {
    /**
     * Clicking/tapping in the viewport can select at most one item.
     * Selecting a new item in this way will deselect any pre
     */
    Exclusive = "exclusive",
    /**
     * Clicking/tapping in the viewport will not affect selection.
     */
    None = "none",
    /**
     * A multiple selection mode in which clicking/tapping an item toggles its selection state.
     */
    Sticky = "sticky"
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare enum VisualizationLookupResult {
    UniqueMatchFound = "UniqueMatchFound",
    NoMatchFound = "NoMatchFound",
    MultipleMatchesFound = "MultipleMatchesFound",
    UnexpectedError = "UnexpectedError"
}
/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare enum VisualizationLoadStatus {
    NotStarted = "NotStarted",
    Loading = "Loading",
    Loaded = "Loaded",
    UnexpectedError = "UnexpectedError"
}
/**
 * Information relating to an attempt to resolve and load a visualization.
 *
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface VisualizationLoadInfo {
    lookupResult: VisualizationLookupResult;
    loadStatus: VisualizationLoadStatus;
    matches?: VisualizationInfo[];
    visualization?: VisualizationInfo;
    errorMessage?: string;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare enum SceneLoadState {
    NotStarted = 0,
    Loading = 1,
    Loaded = 2,
    Failed = 3
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface LoadedSceneInfo {
    sceneId: string;
    contentType: ContentType;
}
/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface SceneLoadInfo {
    sceneLoadState: SceneLoadState;
    loadedSceneInfo?: LoadedSceneInfo;
    errorMessage?: string;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualViewerService implements OnDestroy {
    protected epdVisualizationConfig: EpdVisualizationConfig;
    protected _sceneNodeToProductLookupService: SceneNodeToProductLookupService;
    protected visualizationLookupService: VisualizationLookupService;
    protected elementRef: ElementRef;
    protected changeDetectorRef: ChangeDetectorRef;
    protected windowRef: WindowRef;
    constructor(epdVisualizationConfig: EpdVisualizationConfig, _sceneNodeToProductLookupService: SceneNodeToProductLookupService, visualizationLookupService: VisualizationLookupService, elementRef: ElementRef, changeDetectorRef: ChangeDetectorRef, windowRef: WindowRef);
    ngOnDestroy(): void;
    private selectedNodeIdsSubscription?;
    private get sceneNodeToProductLookupService();
    private set sceneNodeToProductLookupService(value);
    private _scene;
    private get scene();
    private set scene(value);
    private _nodeHierarchy;
    private get nodeHierarchy();
    private set nodeHierarchy(value);
    private _contentConnector;
    private get contentConnector();
    private set contentConnector(value);
    private _viewport;
    private get viewport();
    private set viewport(value);
    private _viewStateManager;
    private get viewStateManager();
    private set viewStateManager(value);
    private _animationPlayer;
    private get animationPlayer();
    private set animationPlayer(value);
    private _viewManager;
    private get viewManager();
    private set viewManager(value);
    private _drawerToolbar;
    private get drawerToolbar();
    private set drawerToolbar(value);
    private _sceneId;
    private get sceneId();
    private set sceneId(value);
    private _contentType;
    private get contentType();
    private set contentType(value);
    private _initialViewInfo;
    private get initialViewInfo();
    private set initialViewInfo(value);
    private _leafNodeRefs;
    private get leafNodeRefs();
    private set leafNodeRefs(value);
    private _viewPriorToIsolateViewInfo;
    private get viewPriorToIsolateViewInfo();
    private set viewPriorToIsolateViewInfo(value);
    private _viewportAdded$;
    private get viewportAdded$();
    private set viewportAdded$(value);
    private _selectedNodeIds$;
    private get selectedNodeIds$();
    private set selectedNodeIds$(value);
    private _sceneLoadInfo$;
    get sceneLoadInfo$(): BehaviorSubject<SceneLoadInfo>;
    protected readonly DEFAULT_BACKGROUND_TOP_COLOR = "--cx-color-inverse";
    protected readonly DEFAULT_BACKGROUND_BOTTOM_COLOR = "--cx-color-inverse";
    protected readonly DEFAULT_HOTSPOT_SELECTION_HIGHLIGHT_COLOR = "rgba(255, 0, 0, 0.6)";
    protected readonly DEFAULT_SHOW_ALL_HOTSPOTS_COLOR = "rgba(255, 255, 0, 0.3)";
    protected readonly DEFAULT_OUTLINE_COLOR = "red";
    protected readonly DEFAULT_OUTLINE_WIDTH = 5;
    protected readonly DEFAULT_SELECTION_MODE = SelectionMode.Exclusive;
    protected readonly DEFAULT_SHOW_ALL_HOTSPOTS_ENABLED = false;
    protected readonly DEFAULT_EXCLUDED_OPACITY = 0.2;
    protected readonly DEFAULT_ZOOM_TO_MARGIN = 0.2;
    protected readonly DEFAULT_FLY_TO_DURATION = 1;
    private _flyToDurationInSeconds;
    private get flyToDurationInSeconds();
    private set flyToDurationInSeconds(value);
    private _zoomToMargin;
    private get zoomToMargin();
    private set zoomToMargin(value);
    /**
     * The top colour of the background gradient.
     * Can be passed in the CSS color format or as a Spartacus theme color i.e. '--cx-color-background' with the quotes.
     */
    set backgroundTopColor(backgroundTopColor: string);
    get backgroundTopColor(): string;
    private _backgroundTopColor;
    /**
     * The bottom colour of the background gradient.
     * Can be passed in the CSS color format or as a Spartacus theme color i.e. '--cx-color-background' with the quotes.
     */
    set backgroundBottomColor(backgroundBottomColor: string);
    get backgroundBottomColor(): string;
    private _backgroundBottomColor;
    /**
     * The colour applied to selected 2D hotspots in 2D content.
     * Can be passed in the CSS color format or as a Spartacus theme color i.e. '--cx-color-primary' with the quotes.
     */
    set hotspotSelectionColor(hotspotSelectionColor: string);
    get hotspotSelectionColor(): string;
    private _hotspotSelectionColor;
    /**
     * Highlights all hotspots in 2D content that are included in the includedProductCodes property using the colour specified by the showAllHotspotsColor property.
     */
    set showAllHotspotsEnabled(showAllHotspotsEnabled: boolean);
    get showAllHotspotsEnabled(): boolean;
    private _showAllHotspotsEnabled;
    /**
     * The colour used to highlight hotspots in 2D content when the showAllHotspotsEnabled property has a value of true.
     * Can be passed in the CSS color format or as a Spartacus theme color i.e. '--cx-color-primary' with the quotes.
     */
    set showAllHotspotsColor(showAllHotspotsColor: string);
    get showAllHotspotsColor(): string;
    private _showAllHotspotsColor;
    /**
     * The outline colour used to indicate selected objects in 3D content.
     * Can be passed in the CSS color format or as a Spartacus theme color i.e. '--cx-color-primary' with the quotes.
     */
    set outlineColor(outlineColor: string);
    get outlineColor(): string;
    private _outlineColor;
    /**
     * The width of the outline used to indicate selected objects in 3D content.
     */
    set outlineWidth(outlineWidth: number);
    get outlineWidth(): number;
    private _outlineWidth;
    /**
     * The selection mode.
     * None - Selection is disabled.
     * Exclusive - When selecting objects in the viewport, at most one object can be selected at a time. Clicking/tapping to select a new object will deselect any previously selected objects.
     * Sticky - A multiple selection mode in which clicking/tapping on an object that is not part of the current selection will toggle its selection state without modifying the selection state of the currently selected objects.
     */
    set selectionMode(selectionMode: SelectionMode);
    get selectionMode(): SelectionMode;
    private _selectionMode;
    /**
     * Gets/sets the selection in terms of product codes.
     * Gets the set of product codes applied to the selected scene nodes.
     * Sets the selection set based on the set of supplied product codes.
     */
    set selectedProductCodes(selectedProductCodes: string[]);
    get selectedProductCodes(): string[];
    private _selectedProductCodes;
    selectedProductCodesChange: EventEmitter<string[]>;
    /**
     * Gets/sets which objects should be selectable (in terms of product codes).
     * For 3D content:
     * - objects that are included will be selectable and opaque
     * - objects that are not included will not be selectable and will have an opacity specified by the excludedOpacity property.
     *
     * For 2D content:
     * - hotspots that are included will be selectable and can be made visible
     * - hotspots that are not included will not be selectable or visible
     */
    set includedProductCodes(includedProductCodes: string[]);
    get includedProductCodes(): string[];
    private _includedProductCodes;
    /**
     * Gets/sets the opacity to apply to 3D objects that are not in the set specified by the includedProductCodes property.
     */
    set excludedOpacity(excludedOpacity: number);
    get excludedOpacity(): number;
    private _excludedOpacity;
    /**
     * The current time position in seconds in the animation (if there is one).
     */
    set animationTime(animationTime: number);
    get animationTime(): number;
    private _animationTime;
    animationTimeChange: EventEmitter<number>;
    /**
     * The total duration of the animation in seconds.
     * Returns 0 when there is no animation present (or when a scene has not been loaded).
     */
    get animationTotalDuration(): number;
    /**
     * The animation playback position as a fractional value between 0 (start) and 1 (end).
     */
    set animationPosition(position: number);
    get animationPosition(): number;
    private _animationPosition;
    animationPositionChange: EventEmitter<number>;
    /**
     * Gets/sets whether the animation (if there is one) is currently playing.
     */
    set animationPlaying(animationPlaying: boolean);
    get animationPlaying(): boolean;
    private _animationPlaying;
    animationPlayingChange: EventEmitter<boolean>;
    /**
     * Controls the behaviour when a left mouse button drag is initiated in the viewport.
     * Turntable: A left mouse drag performs a turntable mode rotation.
     * Pan: A left mouse drag pans the camera in the viewport.
     * Zoom: A left mouse drag zooms the camera in the viewport in or out
     */
    set navigationMode(navigationMode: NavigationMode);
    get navigationMode(): NavigationMode;
    private _navigationMode;
    /**
     * Isolate mode allows a single object to be viewed in isolation.
     */
    set isolateModeEnabled(isolateModeEnabled: boolean);
    get isolateModeEnabled(): boolean;
    private _isolateModeEnabled;
    isolateModeEnabledChange: EventEmitter<boolean>;
    /**
     * Gets whether the viewport is displaying 2D content.
     */
    get is2D(): boolean;
    private setIs2D;
    private _is2D;
    /**
     * Indicates that a scene has been loaded and the viewport is ready for interaction.
     */
    get viewportReady(): boolean;
    private setViewportReady;
    private _viewportReady;
    viewportReadyChange: EventEmitter<boolean>;
    /**
     * Returns the user to the initial camera position used when a scene was first loaded.
     */
    activateHomeView(): void;
    /**
     * Plays the animation (if one exists).
     */
    playAnimation(): void;
    /**
     * Pauses animation playback.
     */
    pauseAnimation(): void;
    private contentChangesFinished;
    private contentLoadFinished;
    private setInitialPropertyValues;
    private executeWhenSceneLoaded;
    private applyInclusionStyle;
    private applyInclusionStyle2D;
    private applyInclusionStyle3D;
    private isTopLevelHotspotNode;
    private isReferenceNode;
    private getLeafDescendants;
    private getAllLeafNodeRefs;
    private isolateNodes;
    private animationPlayerSetTime;
    private onViewActivated;
    private onTimeChanged;
    private setVisualizationLoadInfo;
    get visualizationLoadInfo(): VisualizationLoadInfo;
    private _visualizationLoadInfo;
    visualizationLoadInfoChange: EventEmitter<VisualizationLoadInfo>;
    loadVisualization(productCode: string): Observable<VisualizationLoadInfo>;
    private isUi5BootStrapped;
    private getCore;
    private bootstrapUi5;
    private initializeUi5;
    private destroyViewportAssociations;
    private destroyContentConnector;
    private destroyViewManagers;
    private onContentChangesStarted;
    private onContentChangesFinished;
    private onContentLoadingFinished;
    private onNodesPicked;
    private isNodeIncluded;
    private onNodesPicked2D;
    private onNodesPicked3D;
    private addViewport;
    private getCSSPropertyValue;
    private getCSSColor;
    private resolveVisualization;
    private persistentIdToNodeRef;
    private nodeRefToPersistentId;
    private getViewStateManagerImplementation;
    private handleSelectedNodeIds;
    private handleSelectedNodes2D;
    private handleSelectedNodes3D;
    private setShouldRenderFrame;
    private is2DContentType;
    private loadScene;
    private onSelectionChanged;
    private onOutliningChanged;
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualViewerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VisualViewerService>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualViewerComponent {
    protected visualViewerService: VisualViewerService;
    constructor(visualViewerService: VisualViewerService);
    /**
     * The top colour of the background gradient.
     * Can be passed in the CSS color format or as a Spartacus theme color i.e. '--cx-color-background' with the quotes.
     */
    set backgroundTopColor(backgroundTopColor: string);
    get backgroundTopColor(): string;
    /**
     * The bottom colour of the background gradient.
     * Can be passed in the CSS color format or as a Spartacus theme color i.e. '--cx-color-background' with the quotes.
     */
    set backgroundBottomColor(backgroundBottomColor: string);
    get backgroundBottomColor(): string;
    /**
     * The colour applied to selected 2D hotspots in 2D content.
     * Can be passed in the CSS color format or as a Spartacus theme color i.e. '--cx-color-primary' with the quotes.
     */
    set hotspotSelectionColor(hotspotSelectionColor: string);
    get hotspotSelectionColor(): string;
    /**
     * When true, all hotspots in 2D content that are included in the includedProductCodes property are highlighted using the colour specified by the showAllHotspotsColor property.
     */
    set showAllHotspotsEnabled(showAllHotspotsEnabled: boolean);
    get showAllHotspotsEnabled(): boolean;
    /**
     * The colour used to highlight hotspots in 2D content when the showAllHotspotsEnabled property has a value of true.
     * Can be passed in the CSS color format or as a Spartacus theme color i.e. '--cx-color-primary' with the quotes.
     */
    set showAllHotspotsColor(showAllHotspotsColor: string);
    get showAllHotspotsColor(): string;
    /**
     * The outline colour used to indicate selected objects in 3D content.
     * Can be passed in the CSS color format or as a Spartacus theme color i.e. '--cx-color-primary' with the quotes.
     */
    set outlineColor(outlineColor: string);
    get outlineColor(): string;
    /**
     * The width of the outline (in pixels) used to indicate selected objects in 3D content.
     */
    set outlineWidth(outlineWidth: number);
    get outlineWidth(): number;
    /**
     * The selection mode.
     * None - Selection is disabled.
     * Exclusive - When selecting objects in the viewport, at most one object can be selected at a time. Clicking/tapping to select a new object will deselect any previously selected objects.
     * Sticky - A multiple selection mode in which clicking/tapping on an object that is not part of the current selection will toggle its selection state without modifying the selection state of the currently selected objects.
     */
    set selectionMode(selectionMode: SelectionMode);
    get selectionMode(): SelectionMode;
    /**
     * Gets/sets the selection in terms of product codes.
     * Gets the set of product codes applied to the selected scene nodes.
     * Sets the selection set based on the set of supplied product codes.
     */
    set selectedProductCodes(selectedProductCodes: string[]);
    get selectedProductCodes(): string[];
    selectedProductCodesChange: i0.EventEmitter<string[]>;
    /**
     * Gets/sets which objects should be selectable (in terms of product codes).
     * For 3D content:
     * - objects that are included will be selectable and opaque
     * - objects that are not included will not be selectable and will have an opacity specified by the excludedOpacity property.
     *
     * For 2D content:
     * - hotspots that are included will be selectable and can be made visible
     * - hotspots that are not included will not be selectable or visible
     */
    set includedProductCodes(includedProductCodes: string[]);
    get includedProductCodes(): string[];
    /**
     *  Gets/sets the opacity to apply to 3D objects that are not in the set specified by the includedProductCodes property
     */
    set excludedOpacity(excludedOpacity: number);
    get excludedOpacity(): number;
    /**
     * The current time position in seconds in the animation (if there is one).
     */
    set animationTime(animationTime: number);
    get animationTime(): number;
    animationTimeChange: i0.EventEmitter<number>;
    /**
     * Gets the total duration of the animation (if there is one). A total duration of 0 indicates that there is no animation that can be played.
     */
    get animationTotalDuration(): number;
    /**
     *  The animation playback position as a fractional value between 0 (start) and 1 (end).
     */
    set animationPosition(animationPosition: number);
    get animationPosition(): number;
    animationPositionChange: i0.EventEmitter<number>;
    /**
     * Gets/sets whether the animation (if there is one) is currently playing.
     */
    set animationPlaying(animationPlaying: boolean);
    get animationPlaying(): boolean;
    animationPlayingChange: i0.EventEmitter<boolean>;
    /**
     * Controls the behaviour when a left mouse button drag is initiated in the viewport.
     * Turntable: A left mouse drag performs a turntable mode rotation.
     * Pan: A left mouse drag pans the camera in the viewport.
     * Zoom: A left mouse drag zooms the camera in the viewport in or out
     */
    set navigationMode(navigationMode: NavigationMode);
    get navigationMode(): NavigationMode;
    /**
     * Isolate mode allows a single object to be viewed in isolation.
     */
    set isolateModeEnabled(isolateModeEnabled: boolean);
    get isolateModeEnabled(): boolean;
    isolateModeEnabledChange: i0.EventEmitter<boolean>;
    /**
     * Gets whether the viewport is displaying 2D content.
     */
    get is2D(): boolean;
    /**
     * Indicates that a scene has been loaded and the viewport is ready for interaction.
     */
    get viewportReady(): boolean;
    viewportReadyChange: i0.EventEmitter<boolean>;
    /**
     * Returns the user to the initial camera position used when a scene was first loaded.
     */
    activateHomeView(): void;
    /**
     * Plays the animation (if one exists).
     */
    playAnimation(): void;
    /**
     * Pauses animation playback.
     */
    pauseAnimation(): void;
    /**
     * Loads the visualization specified by the product code.
     * @param productCode The product code of the visualization to load.
     * @returns An observable that returns a single VisualizationLoadInfo value.
     */
    loadVisualization(productCode: string): Observable<VisualizationLoadInfo>;
    SelectionMode: typeof SelectionMode;
    NavigationMode: typeof NavigationMode;
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualViewerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VisualViewerComponent, "cx-epd-visualization-viewer", never, { "backgroundTopColor": { "alias": "backgroundTopColor"; "required": false; }; "backgroundBottomColor": { "alias": "backgroundBottomColor"; "required": false; }; "hotspotSelectionColor": { "alias": "hotspotSelectionColor"; "required": false; }; "showAllHotspotsEnabled": { "alias": "showAllHotspotsEnabled"; "required": false; }; "showAllHotspotsColor": { "alias": "showAllHotspotsColor"; "required": false; }; "outlineColor": { "alias": "outlineColor"; "required": false; }; "outlineWidth": { "alias": "outlineWidth"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectedProductCodes": { "alias": "selectedProductCodes"; "required": false; }; "includedProductCodes": { "alias": "includedProductCodes"; "required": false; }; "excludedOpacity": { "alias": "excludedOpacity"; "required": false; }; "animationTime": { "alias": "animationTime"; "required": false; }; "animationPosition": { "alias": "animationPosition"; "required": false; }; "animationPlaying": { "alias": "animationPlaying"; "required": false; }; "navigationMode": { "alias": "navigationMode"; "required": false; }; "isolateModeEnabled": { "alias": "isolateModeEnabled"; "required": false; }; }, { "selectedProductCodesChange": "selectedProductCodesChange"; "animationTimeChange": "animationTimeChange"; "animationPositionChange": "animationPositionChange"; "animationPlayingChange": "animationPlayingChange"; "isolateModeEnabledChange": "isolateModeEnabledChange"; "viewportReadyChange": "viewportReadyChange"; }, never, never, true, never>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualViewerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualViewerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VisualViewerModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i5.I18nModule, typeof VisualViewerToolbarButtonModule, typeof VisualViewerAnimationSliderModule, typeof i3.SpinnerModule, typeof i5.FeaturesConfigModule, typeof VisualViewerComponent], [typeof VisualViewerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VisualViewerModule>;
}

/**
 * Generic in-memory paged list component that can be used to render arbitrary items in
 * a vertical orientation.
 * Previous/next buttons as well as indicator-buttons can used to navigate the slides (pages).
 *
 * To allow for flexible rendering of items, the rendering is delegated to the
 * given `template` and `headerTemplate`.
 *
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class PagedListComponent implements OnInit {
    protected el: ElementRef;
    /**
     * The title is rendered as the carousel heading.
     */
    title: string;
    /**
     * The items$ represent the carousel items.
     */
    items: Observable<any>[];
    /**
     * The headerTemplate is rendered above the item rows.
     */
    headerTemplate: TemplateRef<any>;
    /**
     * The template is rendered for each item, so that the actual
     * view can be given by the component that uses the `PagedListComponent`.
     */
    template: TemplateRef<any>;
    /**
     * The maximum number of items per slide
     */
    itemsPerSlide: number;
    /**
     * Indicates whether the visual indicators are used.
     */
    hideIndicators: boolean;
    indicatorIcon: ICON_TYPE;
    previousIcon: ICON_TYPE;
    nextIcon: ICON_TYPE;
    activeSlideStartIndex: number;
    activeSlideStartIndexChange: EventEmitter<number>;
    setActiveSlideStartIndex(activeSlideStartIndex: number): void;
    protected logger: LoggerService;
    constructor(el: ElementRef);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PagedListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PagedListComponent, "cx-epd-visualization-paged-list", never, { "title": { "alias": "title"; "required": false; }; "items": { "alias": "items"; "required": false; }; "headerTemplate": { "alias": "headerTemplate"; "required": false; }; "template": { "alias": "template"; "required": false; }; "itemsPerSlide": { "alias": "itemsPerSlide"; "required": false; }; "hideIndicators": { "alias": "hideIndicators"; "required": false; }; "indicatorIcon": { "alias": "indicatorIcon"; "required": false; }; "previousIcon": { "alias": "previousIcon"; "required": false; }; "nextIcon": { "alias": "nextIcon"; "required": false; }; "activeSlideStartIndex": { "alias": "activeSlideStartIndex"; "required": false; }; }, { "activeSlideStartIndexChange": "activeSlideStartIndexChange"; }, never, never, true, never>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class PagedListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PagedListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PagedListModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i3.IconModule, typeof i3.MediaModule, typeof i5.UrlModule, typeof PagedListComponent], [typeof PagedListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PagedListModule>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class CompactAddToCartComponent extends AddToCartComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CompactAddToCartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CompactAddToCartComponent, "cx-epd-visualization-compact-add-to-cart", never, {}, {}, never, never, true, never>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class CompactAddToCartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CompactAddToCartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CompactAddToCartModule, never, [typeof i1.CommonModule, typeof i2$1.ReactiveFormsModule, typeof i2.RouterModule, typeof i3.SpinnerModule, typeof i3.PromotionsModule, typeof i5.I18nModule, typeof i5.UrlModule, typeof i3.IconModule, typeof i5.I18nModule, typeof i3.ItemCounterModule, typeof CompactAddToCartComponent], [typeof CompactAddToCartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CompactAddToCartModule>;
}

/**
 * A model object representing a product item in the visual picking product list.
 *
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
interface VisualPickingProductListItem {
    /**
     * The product data.
     */
    product: Product;
    /**
     * Whether the item is selected.
     */
    selected: boolean;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualPickingProductFilterService {
    constructor();
    /**
     * The current filter value.
     * @param filter The filter value to apply.
     */
    set filter(filterStr: string);
    get filter(): string;
    private _filter;
    private filter$;
    /**
     * The set of fields in product objects to perform matching against.
     */
    protected fieldsToMatch: string[];
    protected applyFilter(filterToApply: string, unfilteredProductReferences: ProductReference[]): ProductReference[];
    /**
     * Returns an Observable that produces a ProductReference[] each time the filter is updated or the set of product references to filter changes.
     * @param unfilteredProductReferences$ An Observable that returns the unfiltered ProductReference[] to apply filtering to.
     * @returns An Observable that produces a ProductReference[] each time the filter is updated or the set of product references to filter changes.
     */
    getFilteredProducts(unfilteredProductReferences$: Observable<ProductReference[]>): Observable<ProductReference[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualPickingProductFilterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VisualPickingProductFilterService>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualPickingProductListService implements OnDestroy {
    protected currentProductService: CurrentProductService;
    protected productReferenceService: ProductReferenceService;
    protected visualPickingProductFilterService: VisualPickingProductFilterService;
    protected epdVisualizationConfig: EpdVisualizationConfig;
    constructor(currentProductService: CurrentProductService, productReferenceService: ProductReferenceService, visualPickingProductFilterService: VisualPickingProductFilterService, epdVisualizationConfig: EpdVisualizationConfig);
    protected readonly DEFAULT_ITEMS_PER_SLIDE = 7;
    private getFilteredProductReferencesSubscription;
    private productReferencesSubscription;
    private filteredItemsSubscription;
    /**
     * Initializes the service.
     */
    initialize(): void;
    ngOnDestroy(): void;
    private get productReferenceType();
    currentProduct$: Observable<Product>;
    private productReferences$;
    /**
     * Returns an Observable that produces the spare part product references for the current product.
     * @returns An Observable that produces the spare part product references for the current product.
     */
    getProductReferences(): Observable<ProductReference[]>;
    private _getProductReferences;
    /**
     * Returns an Observable that produces a filtered array of spare part product references for the current product.
     * Filtering is performed by the VisualPickingProductFilterService.
     * @returns An Observable that produces a filtered array of spare part product references for the current product.
     */
    getFilteredProductReferences(): Observable<ProductReference[]>;
    activeSlideStartIndex: number;
    itemsPerSlide: number;
    set selectedProductCodes(selectedProductCodes: string[]);
    get selectedProductCodes(): string[];
    private _selectedProductCodes;
    selectedProductCodesChange: EventEmitter<string[]>;
    /**
     * Used to create the list item model data for the visual picking product list.
     * Returns an observable containing an array of VisualPickingProductListItem objects created by combining the latest values from
     * an Observable producing an array of product references and
     * an Observable producing an array of selected product codes.
     * The VisualPickingProductListItem model object combines a ProductReference for a spare part and the selected state of the list item.
     * @param productReferences$ An Observable producing the array of ProductReference values to map.
     * @param selectedProductCodes$ An Observable producing the array of selected product codes.
     * @returns An Observable producing an array of VisualPickingProductListItem values.
     */
    getVisualPickingProductListItems(productReferences$: Observable<ProductReference[]>, selectedProductCodes$: Observable<string[]>): Observable<VisualPickingProductListItem[]>;
    filteredItems$: Observable<VisualPickingProductListItem[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualPickingProductListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VisualPickingProductListService>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualPickingProductListComponent implements OnInit {
    protected visualPickingProductListService: VisualPickingProductListService;
    constructor(visualPickingProductListService: VisualPickingProductListService);
    title: string;
    singleSelection: boolean;
    set selectedProductCodes(selectedProductCodes: string[]);
    get selectedProductCodes(): string[];
    selectedProductCodesChange: i0.EventEmitter<string[]>;
    get itemsPerSlide(): number;
    set itemsPerSlide(itemsPerSlide: number);
    get activeSlideStartIndex(): number;
    set activeSlideStartIndex(activeSlideStartIndex: number);
    get filteredItems$(): Observable<VisualPickingProductListItem[]>;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualPickingProductListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VisualPickingProductListComponent, "cx-epd-visualization-product-list", never, { "title": { "alias": "title"; "required": false; }; "singleSelection": { "alias": "singleSelection"; "required": false; }; "selectedProductCodes": { "alias": "selectedProductCodes"; "required": false; }; }, { "selectedProductCodesChange": "selectedProductCodesChange"; }, never, never, true, never>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualPickingProductListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualPickingProductListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VisualPickingProductListModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i3.ProductReferencesModule, typeof i3.MediaModule, typeof i3.IconModule, typeof i3.CarouselModule, typeof PagedListModule, typeof i5.UrlModule, typeof i5.I18nModule, typeof CompactAddToCartModule, typeof VisualPickingProductListComponent], [typeof VisualPickingProductListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VisualPickingProductListModule>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualPickingProductFilterComponent {
    protected visualPickingProductFilterService: VisualPickingProductFilterService;
    constructor(visualPickingProductFilterService: VisualPickingProductFilterService);
    /**
     * The filter input value.
     */
    set filter(filter: string);
    get filter(): string;
    iconTypes: typeof ICON_TYPE;
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualPickingProductFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VisualPickingProductFilterComponent, "cx-epd-visualization-product-filter", never, { "filter": { "alias": "filter"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualPickingProductFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualPickingProductFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VisualPickingProductFilterModule, never, [typeof i1.CommonModule, typeof i2$1.FormsModule, typeof i3.IconModule, typeof i5.UrlModule, typeof i5.I18nModule, typeof VisualPickingProductFilterComponent], [typeof VisualPickingProductFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VisualPickingProductFilterModule>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualPickingTabService implements OnDestroy {
    protected currentProductService: CurrentProductService;
    protected globalMessageService: GlobalMessageService;
    protected changeDetectorRef: ChangeDetectorRef;
    protected windowRef: WindowRef;
    constructor(currentProductService: CurrentProductService, globalMessageService: GlobalMessageService, changeDetectorRef: ChangeDetectorRef, windowRef: WindowRef);
    /**
     * Initialize the service.
     * @param visualViewerService The VisualViewerService instance to use.
     * @param visualPickingProductListService The VisualPickingProductListService instance to use.
     */
    initialize(visualViewerService: VisualViewerService, visualPickingProductListService: VisualPickingProductListService): void;
    ngOnDestroy(): void;
    private visualizationLoadInfoChangeSubscription;
    private getProductReferencesSubscription;
    private getFilteredProductReferencesSubscription;
    private _selectedProductCodes;
    get selectedProductCodes(): string[];
    set selectedProductCodes(selectedProducts: string[]);
    /**
     * When true, error messages will be shown when visualization load/lookup failures occur.
     */
    protected showErrorMessages: boolean;
    private _productReferences;
    private get productReferences();
    private setProductReferences;
    private get visualizationLoadStatus();
    get hideNoProductReferencesText(): boolean;
    get hideProductList(): boolean;
    get hideViewport(): boolean;
    private showErrorMessage;
    private handleLoadVisualizationInfoChange;
    private _visualViewerService;
    get visualViewerService(): VisualViewerService;
    set visualViewerService(value: VisualViewerService);
    private _visualPickingProductListService;
    get visualPickingProductListService(): VisualPickingProductListService;
    set visualPickingProductListService(value: VisualPickingProductListService);
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualPickingTabService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VisualPickingTabService>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualPickingTabComponent implements AfterViewInit {
    protected visualPickingTabService: VisualPickingTabService;
    constructor(visualPickingTabService: VisualPickingTabService);
    ngAfterViewInit(): void;
    get selectedProductCodes(): string[];
    set selectedProductCodes(selectedProducts: string[]);
    visualViewerService: VisualViewerService;
    visualPickingProductListService: VisualPickingProductListService;
    get hideNoProductReferencesIndicator(): boolean;
    get hideProductList(): boolean;
    get hideViewport(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualPickingTabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VisualPickingTabComponent, "cx-epd-visualization-visual-picking-tab", never, {}, {}, never, never, true, never>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class VisualPickingTabModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VisualPickingTabModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VisualPickingTabModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i5.I18nModule, typeof VisualViewerModule, typeof VisualPickingProductListModule, typeof VisualPickingProductFilterModule, typeof VisualPickingTabComponent], [typeof VisualPickingTabComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VisualPickingTabModule>;
}

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class EpdVisualizationComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<EpdVisualizationComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EpdVisualizationComponentsModule, never, [typeof VisualPickingTabModule, typeof VisualViewerModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EpdVisualizationComponentsModule>;
}

export { CompactAddToCartComponent, CompactAddToCartModule, EpdVisualizationComponentsModule, NavigationMode, PagedListComponent, PagedListModule, SelectionMode, VisualPickingProductFilterComponent, VisualPickingProductFilterModule, VisualPickingProductFilterService, VisualPickingProductListComponent, VisualPickingProductListModule, VisualPickingProductListService, VisualPickingTabComponent, VisualPickingTabModule, VisualPickingTabService, VisualViewerAnimationSliderComponent, VisualViewerAnimationSliderModule, VisualViewerAnimationSliderService, VisualViewerComponent, VisualViewerModule, VisualViewerService, VisualViewerToolbarButtonComponent, VisualViewerToolbarButtonModule, VisualizationLoadStatus, VisualizationLookupResult };
export type { VisualPickingProductListItem, VisualizationLoadInfo };
