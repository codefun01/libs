import { TranslationChunksConfig } from '@spartacus/core';

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const cs: {
    epdVisualization: {
        epdVisualization: {
            visualViewer: {
                contentType: {
                    drawing2D: string;
                    model3D: string;
                };
                toolbar: {
                    homeButton: {
                        label: string;
                    };
                    zoomButton: {
                        label: string;
                    };
                    panButton: {
                        label: string;
                    };
                    rotateButton: {
                        label: string;
                    };
                    isolateButton: {
                        label: string;
                    };
                    playButton: {
                        label: string;
                    };
                    pauseButton: {
                        label: string;
                    };
                    hotspotsButton: {
                        label: string;
                        show: string;
                        hide: string;
                    };
                    visualViewerAnimationSlider: {
                        label: string;
                        role: string;
                    };
                };
            };
            visualPicking: {
                visualPickingTab: {
                    noProductReferences: string;
                };
                visualPickingProductList: {
                    description: string;
                    itemPrice: string;
                    outOfStock: string;
                    id: string;
                };
                visualPickingProductFilter: {
                    input: {
                        placeholder: string;
                    };
                    searchButton: {
                        label: string;
                    };
                    resetButton: {
                        label: string;
                    };
                };
            };
            errors: {
                visualLoad: {
                    noMatchingVisualFound: string;
                    multipleMatchingVisualsFound: string;
                    unexpectedLoadError: string;
                };
            };
        };
    };
};

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const de: {
    epdVisualization: {
        epdVisualization: {
            visualViewer: {
                contentType: {
                    drawing2D: string;
                    model3D: string;
                };
                toolbar: {
                    homeButton: {
                        label: string;
                    };
                    zoomButton: {
                        label: string;
                    };
                    panButton: {
                        label: string;
                    };
                    rotateButton: {
                        label: string;
                    };
                    isolateButton: {
                        label: string;
                    };
                    playButton: {
                        label: string;
                    };
                    pauseButton: {
                        label: string;
                    };
                    hotspotsButton: {
                        label: string;
                        show: string;
                        hide: string;
                    };
                    visualViewerAnimationSlider: {
                        label: string;
                        role: string;
                    };
                };
            };
            visualPicking: {
                visualPickingTab: {
                    noProductReferences: string;
                };
                visualPickingProductList: {
                    description: string;
                    itemPrice: string;
                    outOfStock: string;
                    id: string;
                };
                visualPickingProductFilter: {
                    input: {
                        placeholder: string;
                    };
                    searchButton: {
                        label: string;
                    };
                    resetButton: {
                        label: string;
                    };
                };
            };
            errors: {
                visualLoad: {
                    noMatchingVisualFound: string;
                    multipleMatchingVisualsFound: string;
                    unexpectedLoadError: string;
                };
            };
        };
    };
};

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const en: {
    epdVisualization: {
        epdVisualization: {
            visualViewer: {
                contentType: {
                    drawing2D: string;
                    model3D: string;
                };
                toolbar: {
                    homeButton: {
                        label: string;
                    };
                    zoomButton: {
                        label: string;
                    };
                    panButton: {
                        label: string;
                    };
                    rotateButton: {
                        label: string;
                    };
                    isolateButton: {
                        label: string;
                    };
                    playButton: {
                        label: string;
                    };
                    pauseButton: {
                        label: string;
                    };
                    hotspotsButton: {
                        label: string;
                        show: string;
                        hide: string;
                    };
                    visualViewerAnimationSlider: {
                        label: string;
                        role: string;
                    };
                };
            };
            visualPicking: {
                visualPickingTab: {
                    noProductReferences: string;
                };
                visualPickingProductList: {
                    description: string;
                    itemPrice: string;
                    outOfStock: string;
                    id: string;
                };
                visualPickingProductFilter: {
                    input: {
                        placeholder: string;
                    };
                    searchButton: {
                        label: string;
                    };
                    resetButton: {
                        label: string;
                    };
                };
            };
            errors: {
                visualLoad: {
                    noMatchingVisualFound: string;
                    multipleMatchingVisualsFound: string;
                    unexpectedLoadError: string;
                };
            };
        };
    };
};

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const es: {
    epdVisualization: {
        epdVisualization: {
            visualViewer: {
                contentType: {
                    drawing2D: string;
                    model3D: string;
                };
                toolbar: {
                    homeButton: {
                        label: string;
                    };
                    zoomButton: {
                        label: string;
                    };
                    panButton: {
                        label: string;
                    };
                    rotateButton: {
                        label: string;
                    };
                    isolateButton: {
                        label: string;
                    };
                    playButton: {
                        label: string;
                    };
                    pauseButton: {
                        label: string;
                    };
                    hotspotsButton: {
                        label: string;
                        show: string;
                        hide: string;
                    };
                    visualViewerAnimationSlider: {
                        label: string;
                        role: string;
                    };
                };
            };
            visualPicking: {
                visualPickingTab: {
                    noProductReferences: string;
                };
                visualPickingProductList: {
                    description: string;
                    itemPrice: string;
                    outOfStock: string;
                    id: string;
                };
                visualPickingProductFilter: {
                    input: {
                        placeholder: string;
                    };
                    searchButton: {
                        label: string;
                    };
                    resetButton: {
                        label: string;
                    };
                };
            };
            errors: {
                visualLoad: {
                    noMatchingVisualFound: string;
                    multipleMatchingVisualsFound: string;
                    unexpectedLoadError: string;
                };
            };
        };
    };
};

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const es_CO: {
    epdVisualization: {
        epdVisualization: {
            visualViewer: {
                contentType: {
                    drawing2D: string;
                    model3D: string;
                };
                toolbar: {
                    homeButton: {
                        label: string;
                    };
                    zoomButton: {
                        label: string;
                    };
                    panButton: {
                        label: string;
                    };
                    rotateButton: {
                        label: string;
                    };
                    isolateButton: {
                        label: string;
                    };
                    playButton: {
                        label: string;
                    };
                    pauseButton: {
                        label: string;
                    };
                    hotspotsButton: {
                        label: string;
                        show: string;
                        hide: string;
                    };
                    visualViewerAnimationSlider: {
                        label: string;
                        role: string;
                    };
                };
            };
            visualPicking: {
                visualPickingTab: {
                    noProductReferences: string;
                };
                visualPickingProductList: {
                    description: string;
                    itemPrice: string;
                    outOfStock: string;
                    id: string;
                };
                visualPickingProductFilter: {
                    input: {
                        placeholder: string;
                    };
                    searchButton: {
                        label: string;
                    };
                    resetButton: {
                        label: string;
                    };
                };
            };
            errors: {
                visualLoad: {
                    noMatchingVisualFound: string;
                    multipleMatchingVisualsFound: string;
                    unexpectedLoadError: string;
                };
            };
        };
    };
};

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const fr: {
    epdVisualization: {
        epdVisualization: {
            visualViewer: {
                contentType: {
                    drawing2D: string;
                    model3D: string;
                };
                toolbar: {
                    homeButton: {
                        label: string;
                    };
                    zoomButton: {
                        label: string;
                    };
                    panButton: {
                        label: string;
                    };
                    rotateButton: {
                        label: string;
                    };
                    isolateButton: {
                        label: string;
                    };
                    playButton: {
                        label: string;
                    };
                    pauseButton: {
                        label: string;
                    };
                    hotspotsButton: {
                        label: string;
                        show: string;
                        hide: string;
                    };
                    visualViewerAnimationSlider: {
                        label: string;
                        role: string;
                    };
                };
            };
            visualPicking: {
                visualPickingTab: {
                    noProductReferences: string;
                };
                visualPickingProductList: {
                    description: string;
                    itemPrice: string;
                    outOfStock: string;
                    id: string;
                };
                visualPickingProductFilter: {
                    input: {
                        placeholder: string;
                    };
                    searchButton: {
                        label: string;
                    };
                    resetButton: {
                        label: string;
                    };
                };
            };
            errors: {
                visualLoad: {
                    noMatchingVisualFound: string;
                    multipleMatchingVisualsFound: string;
                    unexpectedLoadError: string;
                };
            };
        };
    };
};

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const hi: {
    epdVisualization: {
        epdVisualization: {
            visualViewer: {
                contentType: {
                    drawing2D: string;
                    model3D: string;
                };
                toolbar: {
                    homeButton: {
                        label: string;
                    };
                    zoomButton: {
                        label: string;
                    };
                    panButton: {
                        label: string;
                    };
                    rotateButton: {
                        label: string;
                    };
                    isolateButton: {
                        label: string;
                    };
                    playButton: {
                        label: string;
                    };
                    pauseButton: {
                        label: string;
                    };
                    hotspotsButton: {
                        label: string;
                        show: string;
                        hide: string;
                    };
                    visualViewerAnimationSlider: {
                        label: string;
                        role: string;
                    };
                };
            };
            visualPicking: {
                visualPickingTab: {
                    noProductReferences: string;
                };
                visualPickingProductList: {
                    description: string;
                    itemPrice: string;
                    outOfStock: string;
                    id: string;
                };
                visualPickingProductFilter: {
                    input: {
                        placeholder: string;
                    };
                    searchButton: {
                        label: string;
                    };
                    resetButton: {
                        label: string;
                    };
                };
            };
            errors: {
                visualLoad: {
                    noMatchingVisualFound: string;
                    multipleMatchingVisualsFound: string;
                    unexpectedLoadError: string;
                };
            };
        };
    };
};

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const hu: {
    epdVisualization: {
        epdVisualization: {
            visualViewer: {
                contentType: {
                    drawing2D: string;
                    model3D: string;
                };
                toolbar: {
                    homeButton: {
                        label: string;
                    };
                    zoomButton: {
                        label: string;
                    };
                    panButton: {
                        label: string;
                    };
                    rotateButton: {
                        label: string;
                    };
                    isolateButton: {
                        label: string;
                    };
                    playButton: {
                        label: string;
                    };
                    pauseButton: {
                        label: string;
                    };
                    hotspotsButton: {
                        label: string;
                        show: string;
                        hide: string;
                    };
                    visualViewerAnimationSlider: {
                        label: string;
                        role: string;
                    };
                };
            };
            visualPicking: {
                visualPickingTab: {
                    noProductReferences: string;
                };
                visualPickingProductList: {
                    description: string;
                    itemPrice: string;
                    outOfStock: string;
                    id: string;
                };
                visualPickingProductFilter: {
                    input: {
                        placeholder: string;
                    };
                    searchButton: {
                        label: string;
                    };
                    resetButton: {
                        label: string;
                    };
                };
            };
            errors: {
                visualLoad: {
                    noMatchingVisualFound: string;
                    multipleMatchingVisualsFound: string;
                    unexpectedLoadError: string;
                };
            };
        };
    };
};

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const id: {
    epdVisualization: {
        epdVisualization: {
            visualViewer: {
                contentType: {
                    drawing2D: string;
                    model3D: string;
                };
                toolbar: {
                    homeButton: {
                        label: string;
                    };
                    zoomButton: {
                        label: string;
                    };
                    panButton: {
                        label: string;
                    };
                    rotateButton: {
                        label: string;
                    };
                    isolateButton: {
                        label: string;
                    };
                    playButton: {
                        label: string;
                    };
                    pauseButton: {
                        label: string;
                    };
                    hotspotsButton: {
                        label: string;
                        show: string;
                        hide: string;
                    };
                    visualViewerAnimationSlider: {
                        label: string;
                        role: string;
                    };
                };
            };
            visualPicking: {
                visualPickingTab: {
                    noProductReferences: string;
                };
                visualPickingProductList: {
                    description: string;
                    itemPrice: string;
                    outOfStock: string;
                    id: string;
                };
                visualPickingProductFilter: {
                    input: {
                        placeholder: string;
                    };
                    searchButton: {
                        label: string;
                    };
                    resetButton: {
                        label: string;
                    };
                };
            };
            errors: {
                visualLoad: {
                    noMatchingVisualFound: string;
                    multipleMatchingVisualsFound: string;
                    unexpectedLoadError: string;
                };
            };
        };
    };
};

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const it: {
    epdVisualization: {
        epdVisualization: {
            visualViewer: {
                contentType: {
                    drawing2D: string;
                    model3D: string;
                };
                toolbar: {
                    homeButton: {
                        label: string;
                    };
                    zoomButton: {
                        label: string;
                    };
                    panButton: {
                        label: string;
                    };
                    rotateButton: {
                        label: string;
                    };
                    isolateButton: {
                        label: string;
                    };
                    playButton: {
                        label: string;
                    };
                    pauseButton: {
                        label: string;
                    };
                    hotspotsButton: {
                        label: string;
                        show: string;
                        hide: string;
                    };
                    visualViewerAnimationSlider: {
                        label: string;
                        role: string;
                    };
                };
            };
            visualPicking: {
                visualPickingTab: {
                    noProductReferences: string;
                };
                visualPickingProductList: {
                    description: string;
                    itemPrice: string;
                    outOfStock: string;
                    id: string;
                };
                visualPickingProductFilter: {
                    input: {
                        placeholder: string;
                    };
                    searchButton: {
                        label: string;
                    };
                    resetButton: {
                        label: string;
                    };
                };
            };
            errors: {
                visualLoad: {
                    noMatchingVisualFound: string;
                    multipleMatchingVisualsFound: string;
                    unexpectedLoadError: string;
                };
            };
        };
    };
};

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const ja: {
    epdVisualization: {
        epdVisualization: {
            visualViewer: {
                contentType: {
                    drawing2D: string;
                    model3D: string;
                };
                toolbar: {
                    homeButton: {
                        label: string;
                    };
                    zoomButton: {
                        label: string;
                    };
                    panButton: {
                        label: string;
                    };
                    rotateButton: {
                        label: string;
                    };
                    isolateButton: {
                        label: string;
                    };
                    playButton: {
                        label: string;
                    };
                    pauseButton: {
                        label: string;
                    };
                    hotspotsButton: {
                        label: string;
                        show: string;
                        hide: string;
                    };
                    visualViewerAnimationSlider: {
                        label: string;
                        role: string;
                    };
                };
            };
            visualPicking: {
                visualPickingTab: {
                    noProductReferences: string;
                };
                visualPickingProductList: {
                    description: string;
                    itemPrice: string;
                    outOfStock: string;
                    id: string;
                };
                visualPickingProductFilter: {
                    input: {
                        placeholder: string;
                    };
                    searchButton: {
                        label: string;
                    };
                    resetButton: {
                        label: string;
                    };
                };
            };
            errors: {
                visualLoad: {
                    noMatchingVisualFound: string;
                    multipleMatchingVisualsFound: string;
                    unexpectedLoadError: string;
                };
            };
        };
    };
};

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const ko: {
    epdVisualization: {
        epdVisualization: {
            visualViewer: {
                contentType: {
                    drawing2D: string;
                    model3D: string;
                };
                toolbar: {
                    homeButton: {
                        label: string;
                    };
                    zoomButton: {
                        label: string;
                    };
                    panButton: {
                        label: string;
                    };
                    rotateButton: {
                        label: string;
                    };
                    isolateButton: {
                        label: string;
                    };
                    playButton: {
                        label: string;
                    };
                    pauseButton: {
                        label: string;
                    };
                    hotspotsButton: {
                        label: string;
                        show: string;
                        hide: string;
                    };
                    visualViewerAnimationSlider: {
                        label: string;
                        role: string;
                    };
                };
            };
            visualPicking: {
                visualPickingTab: {
                    noProductReferences: string;
                };
                visualPickingProductList: {
                    description: string;
                    itemPrice: string;
                    outOfStock: string;
                    id: string;
                };
                visualPickingProductFilter: {
                    input: {
                        placeholder: string;
                    };
                    searchButton: {
                        label: string;
                    };
                    resetButton: {
                        label: string;
                    };
                };
            };
            errors: {
                visualLoad: {
                    noMatchingVisualFound: string;
                    multipleMatchingVisualsFound: string;
                    unexpectedLoadError: string;
                };
            };
        };
    };
};

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const pl: {
    epdVisualization: {
        epdVisualization: {
            visualViewer: {
                contentType: {
                    drawing2D: string;
                    model3D: string;
                };
                toolbar: {
                    homeButton: {
                        label: string;
                    };
                    zoomButton: {
                        label: string;
                    };
                    panButton: {
                        label: string;
                    };
                    rotateButton: {
                        label: string;
                    };
                    isolateButton: {
                        label: string;
                    };
                    playButton: {
                        label: string;
                    };
                    pauseButton: {
                        label: string;
                    };
                    hotspotsButton: {
                        label: string;
                        show: string;
                        hide: string;
                    };
                    visualViewerAnimationSlider: {
                        label: string;
                        role: string;
                    };
                };
            };
            visualPicking: {
                visualPickingTab: {
                    noProductReferences: string;
                };
                visualPickingProductList: {
                    description: string;
                    itemPrice: string;
                    outOfStock: string;
                    id: string;
                };
                visualPickingProductFilter: {
                    input: {
                        placeholder: string;
                    };
                    searchButton: {
                        label: string;
                    };
                    resetButton: {
                        label: string;
                    };
                };
            };
            errors: {
                visualLoad: {
                    noMatchingVisualFound: string;
                    multipleMatchingVisualsFound: string;
                    unexpectedLoadError: string;
                };
            };
        };
    };
};

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const pt: {
    epdVisualization: {
        epdVisualization: {
            visualViewer: {
                contentType: {
                    drawing2D: string;
                    model3D: string;
                };
                toolbar: {
                    homeButton: {
                        label: string;
                    };
                    zoomButton: {
                        label: string;
                    };
                    panButton: {
                        label: string;
                    };
                    rotateButton: {
                        label: string;
                    };
                    isolateButton: {
                        label: string;
                    };
                    playButton: {
                        label: string;
                    };
                    pauseButton: {
                        label: string;
                    };
                    hotspotsButton: {
                        label: string;
                        show: string;
                        hide: string;
                    };
                    visualViewerAnimationSlider: {
                        label: string;
                        role: string;
                    };
                };
            };
            visualPicking: {
                visualPickingTab: {
                    noProductReferences: string;
                };
                visualPickingProductList: {
                    description: string;
                    itemPrice: string;
                    outOfStock: string;
                    id: string;
                };
                visualPickingProductFilter: {
                    input: {
                        placeholder: string;
                    };
                    searchButton: {
                        label: string;
                    };
                    resetButton: {
                        label: string;
                    };
                };
            };
            errors: {
                visualLoad: {
                    noMatchingVisualFound: string;
                    multipleMatchingVisualsFound: string;
                    unexpectedLoadError: string;
                };
            };
        };
    };
};

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const ru: {
    epdVisualization: {
        epdVisualization: {
            visualViewer: {
                contentType: {
                    drawing2D: string;
                    model3D: string;
                };
                toolbar: {
                    homeButton: {
                        label: string;
                    };
                    zoomButton: {
                        label: string;
                    };
                    panButton: {
                        label: string;
                    };
                    rotateButton: {
                        label: string;
                    };
                    isolateButton: {
                        label: string;
                    };
                    playButton: {
                        label: string;
                    };
                    pauseButton: {
                        label: string;
                    };
                    hotspotsButton: {
                        label: string;
                        show: string;
                        hide: string;
                    };
                    visualViewerAnimationSlider: {
                        label: string;
                        role: string;
                    };
                };
            };
            visualPicking: {
                visualPickingTab: {
                    noProductReferences: string;
                };
                visualPickingProductList: {
                    description: string;
                    itemPrice: string;
                    outOfStock: string;
                    id: string;
                };
                visualPickingProductFilter: {
                    input: {
                        placeholder: string;
                    };
                    searchButton: {
                        label: string;
                    };
                    resetButton: {
                        label: string;
                    };
                };
            };
            errors: {
                visualLoad: {
                    noMatchingVisualFound: string;
                    multipleMatchingVisualsFound: string;
                    unexpectedLoadError: string;
                };
            };
        };
    };
};

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const zh: {
    epdVisualization: {
        epdVisualization: {
            visualViewer: {
                contentType: {
                    drawing2D: string;
                    model3D: string;
                };
                toolbar: {
                    homeButton: {
                        label: string;
                    };
                    zoomButton: {
                        label: string;
                    };
                    panButton: {
                        label: string;
                    };
                    rotateButton: {
                        label: string;
                    };
                    isolateButton: {
                        label: string;
                    };
                    playButton: {
                        label: string;
                    };
                    pauseButton: {
                        label: string;
                    };
                    hotspotsButton: {
                        label: string;
                        show: string;
                        hide: string;
                    };
                    visualViewerAnimationSlider: {
                        label: string;
                        role: string;
                    };
                };
            };
            visualPicking: {
                visualPickingTab: {
                    noProductReferences: string;
                };
                visualPickingProductList: {
                    description: string;
                    itemPrice: string;
                    outOfStock: string;
                    id: string;
                };
                visualPickingProductFilter: {
                    input: {
                        placeholder: string;
                    };
                    searchButton: {
                        label: string;
                    };
                    resetButton: {
                        label: string;
                    };
                };
            };
            errors: {
                visualLoad: {
                    noMatchingVisualFound: string;
                    multipleMatchingVisualsFound: string;
                    unexpectedLoadError: string;
                };
            };
        };
    };
};

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const zh_TW: {
    epdVisualization: {
        epdVisualization: {
            visualViewer: {
                contentType: {
                    drawing2D: string;
                    model3D: string;
                };
                toolbar: {
                    homeButton: {
                        label: string;
                    };
                    zoomButton: {
                        label: string;
                    };
                    panButton: {
                        label: string;
                    };
                    rotateButton: {
                        label: string;
                    };
                    isolateButton: {
                        label: string;
                    };
                    playButton: {
                        label: string;
                    };
                    pauseButton: {
                        label: string;
                    };
                    hotspotsButton: {
                        label: string;
                        show: string;
                        hide: string;
                    };
                    visualViewerAnimationSlider: {
                        label: string;
                        role: string;
                    };
                };
            };
            visualPicking: {
                visualPickingTab: {
                    noProductReferences: string;
                };
                visualPickingProductList: {
                    description: string;
                    itemPrice: string;
                    outOfStock: string;
                    id: string;
                };
                visualPickingProductFilter: {
                    input: {
                        placeholder: string;
                    };
                    searchButton: {
                        label: string;
                    };
                    resetButton: {
                        label: string;
                    };
                };
            };
            errors: {
                visualLoad: {
                    noMatchingVisualFound: string;
                    multipleMatchingVisualsFound: string;
                    unexpectedLoadError: string;
                };
            };
        };
    };
};

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare const epdVisualizationTranslationChunksConfig: TranslationChunksConfig;

export { epdVisualizationTranslationChunksConfig, cs as epdVisualizationTranslationsCs, de as epdVisualizationTranslationsDe, en as epdVisualizationTranslationsEn, es as epdVisualizationTranslationsEs, es_CO as epdVisualizationTranslationsEs_CO, fr as epdVisualizationTranslationsFr, hi as epdVisualizationTranslationsHi, hu as epdVisualizationTranslationsHu, id as epdVisualizationTranslationsId, it as epdVisualizationTranslationsIt, ja as epdVisualizationTranslationsJa, ko as epdVisualizationTranslationsKo, pl as epdVisualizationTranslationsPl, pt as epdVisualizationTranslationsPt, ru as epdVisualizationTranslationsRu, zh as epdVisualizationTranslationsZh, zh_TW as epdVisualizationTranslationsZh_TW };
