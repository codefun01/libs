import * as i0 from '@angular/core';

/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
declare class EpdVisualizationApiModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<EpdVisualizationApiModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EpdVisualizationApiModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EpdVisualizationApiModule>;
}

export { EpdVisualizationApiModule };
