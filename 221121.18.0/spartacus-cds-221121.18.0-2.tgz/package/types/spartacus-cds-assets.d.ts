import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    cds: {
        cdsRecentSearches: {
            ariaRecentSearches: string;
        };
        cdsTrendingSearches: {
            ariaTrendingSearches: string;
        };
    };
};

declare const de: {
    cds: {
        cdsRecentSearches: {
            ariaRecentSearches: string;
        };
        cdsTrendingSearches: {
            ariaTrendingSearches: string;
        };
    };
};

declare const en: {
    cds: {
        cdsRecentSearches: {
            ariaRecentSearches: string;
            header: string;
            clear: string;
        };
        cdsTrendingSearches: {
            ariaTrendingSearches: string;
        };
    };
};

declare const es: {
    cds: {
        cdsRecentSearches: {
            ariaRecentSearches: string;
        };
        cdsTrendingSearches: {
            ariaTrendingSearches: string;
        };
    };
};

declare const es_CO: {
    cds: {
        cdsRecentSearches: {
            ariaRecentSearches: string;
        };
        cdsTrendingSearches: {
            ariaTrendingSearches: string;
        };
    };
};

declare const fr: {
    cds: {
        cdsRecentSearches: {
            ariaRecentSearches: string;
        };
        cdsTrendingSearches: {
            ariaTrendingSearches: string;
        };
    };
};

declare const hi: {
    cds: {
        cdsRecentSearches: {
            ariaRecentSearches: string;
        };
        cdsTrendingSearches: {
            ariaTrendingSearches: string;
        };
    };
};

declare const hu: {
    cds: {
        cdsRecentSearches: {
            ariaRecentSearches: string;
        };
        cdsTrendingSearches: {
            ariaTrendingSearches: string;
        };
    };
};

declare const id: {
    cds: {
        cdsRecentSearches: {
            ariaRecentSearches: string;
        };
        cdsTrendingSearches: {
            ariaTrendingSearches: string;
        };
    };
};

declare const it: {
    cds: {
        cdsRecentSearches: {
            ariaRecentSearches: string;
        };
        cdsTrendingSearches: {
            ariaTrendingSearches: string;
        };
    };
};

declare const ja: {
    cds: {
        cdsRecentSearches: {
            ariaRecentSearches: string;
        };
        cdsTrendingSearches: {
            ariaTrendingSearches: string;
        };
    };
};

declare const ko: {
    cds: {
        cdsRecentSearches: {
            ariaRecentSearches: string;
        };
        cdsTrendingSearches: {
            ariaTrendingSearches: string;
        };
    };
};

declare const pl: {
    cds: {
        cdsRecentSearches: {
            ariaRecentSearches: string;
        };
        cdsTrendingSearches: {
            ariaTrendingSearches: string;
        };
    };
};

declare const pt: {
    cds: {
        cdsRecentSearches: {
            ariaRecentSearches: string;
        };
        cdsTrendingSearches: {
            ariaTrendingSearches: string;
        };
    };
};

declare const ru: {
    cds: {
        cdsRecentSearches: {
            ariaRecentSearches: string;
        };
        cdsTrendingSearches: {
            ariaTrendingSearches: string;
        };
    };
};

declare const zh: {
    cds: {
        cdsRecentSearches: {
            ariaRecentSearches: string;
        };
        cdsTrendingSearches: {
            ariaTrendingSearches: string;
        };
    };
};

declare const zh_TW: {
    cds: {
        cdsRecentSearches: {
            ariaRecentSearches: string;
        };
        cdsTrendingSearches: {
            ariaTrendingSearches: string;
        };
    };
};

declare const cdsTranslationChunksConfig: TranslationChunksConfig;

export { cdsTranslationChunksConfig, cs as cdsTranslationsCs, de as cdsTranslationsDe, en as cdsTranslationsEn, es as cdsTranslationsEs, es_CO as cdsTranslationsEs_CO, fr as cdsTranslationsFr, hi as cdsTranslationsHi, hu as cdsTranslationsHu, id as cdsTranslationsId, it as cdsTranslationsIt, ja as cdsTranslationsJa, ko as cdsTranslationsKo, pl as cdsTranslationsPl, pt as cdsTranslationsPt, ru as cdsTranslationsRu, zh as cdsTranslationsZh, zh_TW as cdsTranslationsZh_TW };
