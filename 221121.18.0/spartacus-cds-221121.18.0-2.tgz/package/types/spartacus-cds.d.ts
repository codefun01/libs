import * as i2 from '@spartacus/core';
import { CmsComponent, ConsentService, LoggerService, WindowRef, BaseSiteService, Product, OccEndpointsService, EventService, LanguageService, RoutingService, ProductSearchService, ProductService } from '@spartacus/core';
import * as i0 from '@angular/core';
import { OnDestroy, OnChanges, Renderer2, ElementRef, OnInit, ModuleWithProviders } from '@angular/core';
import * as i1 from '@angular/common';
import * as rxjs from 'rxjs';
import { Observable, Subscription, BehaviorSubject } from 'rxjs';
import { ActionsSubject } from '@ngrx/store';
import { PersonalizationAction, PersonalizationContextService } from '@spartacus/tracking/personalization/core';
import { Cart, ActiveCartFacade } from '@spartacus/cart/base/root';
import * as i3 from '@spartacus/storefront';
import { FacetService, CmsComponentData, IntersectionService, OutletContextData, SearchBoxComponentService, ICON_TYPE } from '@spartacus/storefront';
import * as i4 from '@angular/router';
import { HttpClient, HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';

interface CdsEndpoints {
    /**
     * Get products for a given merchandising strategy
     *
     * @member {string}
     */
    strategyProducts: string;
    searchIntelligence: string;
}

/**
 * A model class that is used when sending a request to the Context-Driven Services Merchandising Strategy service for returning
 * products for a carousel. There are a number of things that can affect which products are returned, based on the users current
 * context
 */
interface StrategyRequest {
    queryParams?: {
        products?: string[];
        category?: string;
        facets?: string;
        date?: Date;
        site?: string;
        language?: string;
        pageNumber?: number;
        pageSize?: number;
        searchPhrase?: string;
    };
    headers?: {
        consentReference?: string;
    };
}

interface CmsMerchandisingCarouselComponent extends CmsComponent {
    title?: string;
    strategy?: string;
    numberToDisplay?: number;
    scroll?: string;
    container?: string;
    textColour?: string;
    backgroundColour?: string;
    viewportPercentage?: number;
}

interface MerchandisingConfig {
    defaultCarouselViewportThreshold?: number;
}

interface ProfileTagConfig {
    javascriptUrl?: string;
    configUrl?: string;
    cdsSiteId?: string;
    allowInsecureCookies?: boolean;
    gtmId?: string;
    sciEnabled?: boolean;
}

declare abstract class CdsConfig {
    cds?: {
        baseSite?: string[];
        tenant?: string;
        baseUrl?: string;
        consentTemplateId?: string;
        endpoints?: CdsEndpoints;
        merchandising?: MerchandisingConfig;
        profileTag?: ProfileTagConfig;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<CdsConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdsConfig>;
}
declare module '@spartacus/core' {
    interface Config extends CdsConfig {
    }
}

declare function cdsConfigValidator(config: CdsConfig): string | void;

declare function defaultCdsConfigFactory(): CdsConfig;

declare abstract class CdsBackendNotificationAdapter {
    abstract notifySuccessfulLogin(): Observable<void>;
}

declare class CdsBackendConnector {
    private cdsBackendNotificationAdapter;
    constructor(cdsBackendNotificationAdapter: CdsBackendNotificationAdapter);
    notifySuccessfulLogin(): Observable<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdsBackendConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdsBackendConnector>;
}

interface RecentSearches {
    getPhrases(): string[];
    addListener(callback: (recentSearches: string[]) => void): void;
    removePhrase(phrase: string): void;
    clearPhrases(): void;
}
interface ProfileTagWindowObject extends Window {
    Y_TRACKING: {
        q?: ProfileTagJsConfig[][];
        eventLayer?: ProfileTagPushEvent[];
        recentSearches?: RecentSearches;
        config?: {
            cdsSiteId?: string;
        };
    };
}
interface ProfileTagJsConfig {
    tenant?: string;
    siteId?: string;
    spa: boolean;
    javascriptUrl?: string;
    configUrl?: string;
    allowInsecureCookies?: boolean;
    gtmId?: string;
}
interface ConsentReferenceEvent extends CustomEvent {
    detail: {
        consentReference: string;
    };
}
interface DebugEvent extends CustomEvent {
    detail: {
        debug: boolean;
    };
}
declare enum InternalProfileTagEventNames {
    CONSENT_REFERENCE_LOADED = "profiletag_consentReferenceLoaded",
    DEBUG_FLAG_CHANGED = "profiletag_debugFlagChanged"
}
interface ProfileTagPushEvent {
    name: string;
    data?: {
        segments?: string[];
        actions?: PersonalizationAction[];
        [x: string]: any;
    };
}
declare class NavigatedPushEvent implements ProfileTagPushEvent {
    name: string;
    data: any;
    constructor(data?: any);
}
declare class ConsentChangedPushEvent implements ProfileTagPushEvent {
    name: string;
    data: {
        granted?: boolean;
    };
    constructor(granted: boolean);
}
declare class KeywordSearchPushEvent implements ProfileTagPushEvent {
    name: string;
    data: any;
    constructor(data: {
        searchTerm: string;
        numResults: Number;
    });
}
declare class ProductViewPushEvent implements ProfileTagPushEvent {
    name: string;
    data: any;
    constructor(data: {
        productSku: string;
        productName: string;
        productPrice: Number;
        productCategory: string;
        productCategoryName: string;
        categories: Array<string>;
    });
}
declare class CategoryViewPushEvent implements ProfileTagPushEvent {
    name: string;
    data: any;
    constructor(data: {
        productCategory: string;
        productCategoryName: string;
    });
}
declare class BrandPageVisitedEvent implements ProfileTagPushEvent {
    name: string;
    data: {
        brandCode: string;
        brandName: string;
    };
    constructor(data: {
        brandCode: string;
        brandName: string;
    });
}
declare class HomePageViewPushEvent implements ProfileTagPushEvent {
    name: string;
    data: any;
    constructor(data?: any);
}
declare class OrderConfirmationPushEvent implements ProfileTagPushEvent {
    name: string;
    data: any;
    constructor(data?: any);
}
declare class CartViewPushEvent implements ProfileTagPushEvent {
    name: string;
    data: any;
    constructor(data?: any);
}
declare class AddedToCartPushEvent implements ProfileTagPushEvent {
    name: string;
    data: any;
    constructor(data: {
        productQty: number;
        productSku: string;
        productName: string;
        cartId: string;
        cartCode: string;
        categories: Array<string>;
        productCategoryName: string;
        productCategory: string;
        productPrice: Number;
    });
}
declare class RemovedFromCartPushEvent implements ProfileTagPushEvent {
    name: string;
    data: any;
    constructor(data: {
        productSku: string;
        productName: string;
        productCategory: string;
        cartId: string;
        cartCode: string;
        productCategoryName: string;
        categories: Array<string>;
    });
}
declare class ModifiedCartPushEvent implements ProfileTagPushEvent {
    name: string;
    data: any;
    constructor(data: {
        productQty: number;
        productSku: string;
        productName: string;
        cartId: string;
        cartCode: string;
        categories: Array<string>;
        productCategoryName: string;
        productCategory: string;
    });
}
declare class CartSnapshotPushEvent implements ProfileTagPushEvent {
    name: string;
    data: any;
    constructor(data: {
        cart: Cart;
    });
}

declare class ProfileTagLifecycleService {
    protected consentService: ConsentService;
    protected config: CdsConfig;
    protected actionsSubject: ActionsSubject;
    private readonly loginEnvelopes$;
    constructor(consentService: ConsentService, config: CdsConfig, actionsSubject: ActionsSubject);
    consentChanged(): Observable<ConsentChangedPushEvent>;
    /**
     * Emits true only for unique login envelopes (deduped by timestamp across the app lifetime).
     */
    loginSuccessful(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProfileTagLifecycleService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProfileTagLifecycleService>;
}

declare class ProfileTagEventService implements OnDestroy {
    private winRef;
    private config;
    private baseSiteService;
    private platform;
    protected subscription: Subscription;
    latestConsentReference: BehaviorSubject<string | null> | undefined;
    profileTagDebug: boolean;
    private consentReference$;
    private profileTagWindow;
    private profileTagEvents$;
    protected logger: LoggerService;
    constructor(winRef: WindowRef, config: CdsConfig, baseSiteService: BaseSiteService, platform: any);
    private setConsentReferenceFromLocalStorage;
    getProfileTagEvents(): Observable<string | DebugEvent | Event | null>;
    getConsentReference(): Observable<string | null> | null;
    handleConsentWithdrawn(): void;
    addTracker(): Observable<string>;
    notifyProfileTagOfEventOccurrence(event: ProfileTagPushEvent): void;
    private setConsentReference;
    private debugModeChanged;
    private createConfig;
    private isScriptLoaded;
    private addScript;
    private initWindow;
    private exposeConfig;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProfileTagEventService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProfileTagEventService>;
}

declare class ProfileTagInjectorService {
    private profileTagEventTracker;
    private cdsBackendConnector;
    private profileTagLifecycleService;
    constructor(profileTagEventTracker: ProfileTagEventService, cdsBackendConnector: CdsBackendConnector, profileTagLifecycleService: ProfileTagLifecycleService);
    track(): Observable<boolean>;
    private notifyEcOfLoginSuccessful;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProfileTagInjectorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProfileTagInjectorService>;
}

declare class ProfileTagComponent {
    private profileTagInjector;
    profileTagEnabled$: Observable<boolean>;
    constructor(profileTagInjector: ProfileTagInjectorService);
    static ɵfac: i0.ɵɵFactoryDeclaration<ProfileTagComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProfileTagComponent, "cx-profiletag", never, {}, {}, never, never, true, never>;
}

declare class ProfileTagCmsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProfileTagCmsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProfileTagCmsModule, never, [typeof i1.CommonModule, typeof ProfileTagComponent], [typeof ProfileTagComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProfileTagCmsModule>;
}

declare class ProfileTagModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProfileTagModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProfileTagModule, never, [typeof ProfileTagCmsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProfileTagModule>;
}

declare class TrackingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TrackingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TrackingModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TrackingModule>;
}

declare class AttributesDirective implements OnChanges {
    private renderer;
    private elementRef;
    cxAttributes: {
        [attribute: string]: any;
    };
    private _attributesNamePrefix;
    set cxAttributesNamePrefix(attributesNamePrefix: string);
    constructor(renderer: Renderer2, elementRef: ElementRef);
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttributesDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AttributesDirective, "[cxAttributes]", never, { "cxAttributes": { "alias": "cxAttributes"; "required": false; }; "cxAttributesNamePrefix": { "alias": "cxAttributesNamePrefix"; "required": false; }; }, {}, never, never, true, never>;
}

declare class AttributesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AttributesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AttributesModule, never, [typeof i1.CommonModule, typeof AttributesDirective], [typeof AttributesDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AttributesModule>;
}

interface MerchandisingFacet {
    code: string;
    value: string;
}

interface MerchandisingMetadata {
    [metadataKey: string]: any;
}

interface MerchandisingProduct extends Product {
    metadata?: MerchandisingMetadata;
}
interface MerchandisingProducts {
    metadata?: MerchandisingMetadata;
    products?: MerchandisingProduct[];
}

interface MerchandisingSiteContext {
    site?: string;
    language?: string;
}

interface MerchandisingUserContext {
    category?: string;
    products?: string[];
    facets?: string;
    consentReference?: string;
    searchPhrase?: string;
}

interface StrategyProduct {
    id?: string;
    metadata?: {
        [metadataAttributeName: string]: string;
    };
}
interface Paged {
    from?: number;
    size?: number;
}
interface StrategyProducts {
    resultCount?: number;
    products?: StrategyProduct[];
    paged?: Paged;
    metadata?: {
        [metadataAttributeName: string]: string;
    };
}
interface StrategyResponse {
    request: StrategyRequest;
    products: StrategyProducts;
}

declare class OccBackendNotification implements CdsBackendNotificationAdapter {
    private http;
    private occEndpoints;
    private userIdService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService);
    notifySuccessfulLogin(): Observable<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccBackendNotification, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccBackendNotification>;
}

declare class ConsentReferenceInterceptor implements HttpInterceptor {
    private profileTagEventTracker;
    private occEndpoints;
    constructor(profileTagEventTracker: ProfileTagEventService, occEndpoints: OccEndpointsService);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    private isOccUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConsentReferenceInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConsentReferenceInterceptor>;
}

declare class DebugInterceptor implements HttpInterceptor {
    private profileTagEventTracker;
    private occEndpoints;
    constructor(profileTagEventTracker: ProfileTagEventService, occEndpoints: OccEndpointsService);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    private isOccUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<DebugInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DebugInterceptor>;
}

/**
 * A service to convert spartacus events into profiletag push events that can be picked up and processed by profiletag.
 * The service observes the event service and the active cart service for supported events. These events are parsed into
 * a profiletag compliant format and enriched by segments and actions from the latest personalization context.
 *
 * Currently supported events from the event service:
 *  - CartPageVisited
 *  - CategoryPageVisited
 *  - HomePageVisited
 *  - KeywordSearchPageVisited
 *  - OrderConfirmationPageVisited
 *  - PageVisited
 *  - ProductDetailsPageVisited
 *  - CartAddEntrySuccessEvent
 *  - CartRemoveEntrySuccessEvent
 *  - CartUpdateEntrySuccessEvent
 */
declare class ProfileTagPushEventsService {
    protected eventService: EventService;
    protected personalizationContextService: PersonalizationContextService;
    protected activeCartFacade: ActiveCartFacade;
    private pushEvents$;
    constructor(eventService: EventService, personalizationContextService: PersonalizationContextService, activeCartFacade: ActiveCartFacade);
    /**
     * Returns a push event emitting observable that emits all converted events emitted by the event or the active cart service.
     * These events are enriched with segments and actions from the latest personalization context.
     *
     * @returns an observable emitting profiletag push events
     */
    getPushEvents(): Observable<ProfileTagPushEvent>;
    /**
     * Adds a new push event emitting observable to this service. This observable will be merged with the internal one.
     * This method can be used to extend the functionality of this service at runtime.
     *
     * @param event an observable emitting profiltag push events
     */
    addPushEvent(event: Observable<ProfileTagPushEvent>): void;
    /**
     * Emits the category page visited event.
     *
     * @returns an observable emitting events that describe category page visits in a profiltag compliant way
     * @see CategoryPageResultsEvent
     * @see CategoryViewPushEvent
     */
    protected categoryPageVisited(): Observable<ProfileTagPushEvent>;
    /**
     * Listens to SearchPageResultsEvent events
     *
     * @returns an observable emitting events that describe keyword search page visits in a profiltag compliant way
     * @see SearchPageResultsEvent
     * @see KeywordSearchPushEvent
     */
    protected searchResultsChanged(): Observable<ProfileTagPushEvent>;
    /**
     * Listens to ProductDetailsPageEvent events
     *
     * @returns an observable emitting events that describe product detail page visits in a profiltag compliant way
     * @see ProductDetailsPageEvent
     * @see ProductViewPushEvent
     */
    protected productDetailsPageView(): Observable<ProfileTagPushEvent>;
    /**
     * Listens to PageVisited events
     *
     * @returns an observable emitting events that describe page visits in a profiltag compliant way
     * @see PageVisited
     * @see NavigatedPushEvent
     */
    protected navigatedEvent(): Observable<ProfileTagPushEvent>;
    /**
     * Listens to CartPageVisited events
     *
     * @returns an observable emitting events that describe cart page visits in a profiltag compliant way
     * @see CartPageVisited
     * @see CartViewPushEvent
     */
    protected cartPageVisitedEvent(): Observable<ProfileTagPushEvent>;
    /**
     * Listens to HomePageEvent events
     *
     * @returns an observable emitting events that describe home page visits in a profiltag compliant way
     * @see HomePageEvent
     * @see HomePageViewPushEvent
     */
    protected homePageVisitedEvent(): Observable<ProfileTagPushEvent>;
    /**
     * Listens to OrderPlacedEvent events
     *
     * @returns an observable emitting events that describe order confirmation page visits in a profiltag compliant way
     * @see OrderPlacedEvent
     * @see OrderConfirmationPushEvent
     */
    protected orderConfirmationPageVisited(): Observable<ProfileTagPushEvent>;
    /**
     * Listens to @CartAddEntrySuccessEvent events, transforms them to @AddedToCartPushEvent .
     *
     * @returns an observable emitting @AddedToCartPushEvent events
     * @see CartAddEntrySuccessEvent
     * @see AddedToCartPushEvent
     */
    protected addedToCart(): Observable<ProfileTagPushEvent>;
    /**
     * Listens to @CartRemoveEntrySuccessEvent events, transforms them to @RemovedFromCartPushEvent
     *
     * @returns an observable emitting @RemovedFromCartPushEvent events
     * @see CartRemoveEntrySuccessEvent
     * @see RemovedFromCartPushEvent
     */
    protected removedFromCart(): Observable<ProfileTagPushEvent>;
    /**
     * Listens to @CartUpdateEntrySuccessEvent events, transforms them to @ModifiedCartPushEvent
     *
     * @returns an observable emitting @ModifiedCartPushEvent events
     * @see CartUpdateEntrySuccessEvent
     * @see ModifiedCartPushEvent
     */
    protected modifiedCart(): Observable<ProfileTagPushEvent>;
    /**
     * Listens to @CartAddEntrySuccessEvent , @CartUpdateEntrySuccessEvent and @CartRemoveEntrySuccessEvent events,
     * transforms them to @CartSnapshotPushEvent whenever there is an activity on the cart.
     *
     * @returns an observable emitting @CartSnapshotPushEvent events
     * @see CartAddEntrySuccessEvent
     * @see CartUpdateEntrySuccessEvent
     * @see CartRemoveEntrySuccessEvent
     * @see MergeCartSuccessEvent
     * @see CartSnapshotPushEvent
     */
    protected cartChangedEvent(): Observable<ProfileTagPushEvent>;
    private getProductPrice;
    private categoriesToIds;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProfileTagPushEventsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProfileTagPushEventsService>;
}

declare class TrackingService {
    protected profileTagLifecycleService: ProfileTagLifecycleService;
    protected profileTagPushEventsService: ProfileTagPushEventsService;
    private profileTagEventTracker;
    constructor(profileTagLifecycleService: ProfileTagLifecycleService, profileTagPushEventsService: ProfileTagPushEventsService, profileTagEventTracker: ProfileTagEventService);
    static factory(trackingService: TrackingService): () => void;
    trackEvents(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TrackingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TrackingService>;
}

declare abstract class MerchandisingStrategyAdapter {
    /**
     * Load products for a given merchandising strategy
     *
     * @param strategyId the id of the merchandising strategy to load products for
     */
    abstract loadProductsForStrategy(strategyId: string, strategyRequest?: StrategyRequest): Observable<StrategyProducts>;
}

declare class MerchandisingStrategyConnector {
    protected strategyAdapter: MerchandisingStrategyAdapter;
    constructor(strategyAdapter: MerchandisingStrategyAdapter);
    loadProductsForStrategy(strategyId: string, strategyRequest?: StrategyRequest): Observable<StrategyProducts>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MerchandisingStrategyConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MerchandisingStrategyConnector>;
}

declare class CdsMerchandisingSiteContextService {
    protected baseSiteService: BaseSiteService;
    protected languageService: LanguageService;
    constructor(baseSiteService: BaseSiteService, languageService: LanguageService);
    getSiteContext(): Observable<MerchandisingSiteContext>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdsMerchandisingSiteContextService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdsMerchandisingSiteContextService>;
}

declare class CdsMerchandisingUserContextService {
    private routingService;
    private productSearchService;
    private profileTagEventService;
    private profileTagLifecycleService;
    private facetService;
    constructor(routingService: RoutingService, productSearchService: ProductSearchService, profileTagEventService: ProfileTagEventService, profileTagLifecycleService: ProfileTagLifecycleService, facetService: FacetService);
    getUserContext(): Observable<MerchandisingUserContext>;
    private getConsentReferenceContext;
    private getPageContext;
    private getSearchContext;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdsMerchandisingUserContextService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdsMerchandisingUserContextService>;
}

declare class CdsMerchandisingProductService {
    protected strategyConnector: MerchandisingStrategyConnector;
    protected merchandisingUserContextService: CdsMerchandisingUserContextService;
    protected merchandisingSiteContextService: CdsMerchandisingSiteContextService;
    constructor(strategyConnector: MerchandisingStrategyConnector, merchandisingUserContextService: CdsMerchandisingUserContextService, merchandisingSiteContextService: CdsMerchandisingSiteContextService);
    loadProductsForStrategy(strategyId: string, numberToDisplay?: number): Observable<StrategyResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdsMerchandisingProductService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdsMerchandisingProductService>;
}

interface CarouselEvent {
    carouselId: string;
    carouselName: string;
    strategyId: string;
    metadata?: MerchandisingMetadata;
}
declare class MerchandisingCarouselViewedEvent implements ProfileTagPushEvent {
    name: string;
    data: any;
    constructor(carouselEvent: CarouselEvent, productSkus: string[]);
}
declare class MerchandisingCarouselClickedEvent implements ProfileTagPushEvent {
    name: string;
    data: any;
    constructor(carouselEvent: CarouselEvent, slotId: string, sku: string, imageUrl: string);
}

interface MerchandisingCarouselModel {
    id: string;
    items$: Observable<MerchandisingProduct>[];
    productIds: string[];
    metadata: MerchandisingMetadata;
    title: string;
    backgroundColor: string | Object | undefined;
    textColor: string | Object | undefined;
}

declare class MerchandisingCarouselComponentService {
    protected cdsMerchandisingProductService: CdsMerchandisingProductService;
    protected productService: ProductService;
    protected profileTagEventService: ProfileTagEventService;
    protected cdsConfig: CdsConfig;
    constructor(cdsMerchandisingProductService: CdsMerchandisingProductService, productService: ProductService, profileTagEventService: ProfileTagEventService, cdsConfig: CdsConfig);
    getMerchandisingCaourselViewportThreshold(cmsComponent: CmsMerchandisingCarouselComponent): number;
    getMerchandisingCarouselModel(cmsComponent: CmsMerchandisingCarouselComponent): Observable<MerchandisingCarouselModel>;
    sendCarouselViewEvent(lastSendModelId: string, merchandisingCarouselModel$: Observable<MerchandisingCarouselModel>): Observable<MerchandisingCarouselModel>;
    sendCarouselItemClickedEvent(merchandisingCarouselModel: MerchandisingCarouselModel, clickedProduct: MerchandisingProduct): void;
    private getCarouselMetadata;
    private mapStrategyProductsToCarouselItems;
    private mapStrategyProductsToProductIds;
    private getMerchandisingCarouselModelId;
    private getCarouselItemMetadata;
    private getCarouselEventFromCarouselModel;
    static ɵfac: i0.ɵɵFactoryDeclaration<MerchandisingCarouselComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MerchandisingCarouselComponentService>;
}

declare class MerchandisingCarouselComponent {
    protected componentData: CmsComponentData<CmsMerchandisingCarouselComponent>;
    protected merchandisingCarouselComponentService: MerchandisingCarouselComponentService;
    protected routingService: RoutingService;
    protected intersectionService: IntersectionService;
    protected el: ElementRef;
    protected lastEventModelId: string;
    constructor(componentData: CmsComponentData<CmsMerchandisingCarouselComponent>, merchandisingCarouselComponentService: MerchandisingCarouselComponentService, routingService: RoutingService, intersectionService: IntersectionService, el: ElementRef);
    /**
     * returns an Observable string for the title.
     */
    title$: Observable<string | undefined>;
    private fetchProducts$;
    private intersection$;
    merchandisingCarouselModel$: Observable<MerchandisingCarouselModel>;
    onMerchandisingCarouselItemClick(merchandisingCarouselModel: MerchandisingCarouselModel, clickedProduct: MerchandisingProduct): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MerchandisingCarouselComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MerchandisingCarouselComponent, "cx-merchandising-carousel", never, {}, {}, never, never, true, never>;
}

declare class MerchandisingCarouselCmsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MerchandisingCarouselCmsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MerchandisingCarouselCmsModule, never, [typeof i1.CommonModule, typeof AttributesModule, typeof i3.CarouselModule, typeof i3.MediaModule, typeof i4.RouterModule, typeof i2.UrlModule, typeof MerchandisingCarouselComponent], [typeof MerchandisingCarouselComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MerchandisingCarouselCmsModule>;
}

declare class MerchandisingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MerchandisingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MerchandisingModule, never, [typeof MerchandisingCarouselCmsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MerchandisingModule>;
}

declare class RecentSearchesService {
    protected winRef: WindowRef;
    private readonly recentSearchesSource;
    recentSearches$: rxjs.Observable<string[]>;
    constructor(winRef: WindowRef);
    private checkAvailability;
    private addRecentSearchesListener;
    removePhrase(phrase: string): void;
    clearPhrases(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RecentSearchesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RecentSearchesService>;
}

interface SearchBoxOutlet {
    search: string;
    searchBoxActive: boolean;
    maxRecentSearches?: number;
}
declare class RecentSearchesComponent implements OnInit {
    protected outletContext: OutletContextData<SearchBoxOutlet>;
    result$: Observable<string[]>;
    outletContext$: Observable<SearchBoxOutlet>;
    protected recentSearchesService: RecentSearchesService;
    protected searchBoxComponentService: SearchBoxComponentService;
    private readonly featureToggles;
    constructor(outletContext: OutletContextData<SearchBoxOutlet>);
    ngOnInit(): void;
    preventDefault(ev: UIEvent): void;
    updateChosenWord(chosenWord: string): void;
    shareEvent(event: KeyboardEvent | FocusEvent): void;
    removeFromRecentSearch(phrase?: string): void;
    handleCloseButtonEnter(event: KeyboardEvent, phrase: string): void;
    protected readonly iconTypes: typeof ICON_TYPE;
    static ɵfac: i0.ɵɵFactoryDeclaration<RecentSearchesComponent, [{ optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RecentSearchesComponent, "cx-recent-searches", never, {}, {}, never, never, true, never>;
}

declare class RecentSearchesHeaderComponent {
    protected recentSearchesService: RecentSearchesService;
    protected searchBoxComponentService: SearchBoxComponentService;
    clearPhrases(event?: MouseEvent): void;
    onArrowDown(event: UIEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RecentSearchesHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RecentSearchesHeaderComponent, "cx-recent-searches-header", never, {}, {}, never, never, true, never>;
}

declare class RecentSearchesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RecentSearchesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RecentSearchesModule, never, [typeof i1.CommonModule, typeof i2.FeaturesConfigModule, typeof i2.I18nModule, typeof i3.SearchBoxModule, typeof i2.UrlModule, typeof i4.RouterModule, typeof RecentSearchesComponent, typeof RecentSearchesHeaderComponent, typeof i3.IconModule], [typeof RecentSearchesComponent, typeof RecentSearchesHeaderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RecentSearchesModule>;
}

interface SearchPhrases {
    searchPhrase: string;
    count: number;
}
interface SearchBoxOutletTrendingSearches {
    maxTrendingSearches?: number;
}

declare class CdsEndpointsService {
    private cdsConfig;
    constructor(cdsConfig: CdsConfig);
    getUrl(endpoint: string, urlParams?: object, queryParams?: object): string;
    private getEndpoint;
    private getBaseEndpoint;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdsEndpointsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdsEndpointsService>;
}

declare class TrendingSearchesService implements OnDestroy {
    protected baseSiteService: BaseSiteService;
    protected cdsConfig: CdsConfig;
    protected cdsEndpointsService: CdsEndpointsService;
    protected httpClient: HttpClient;
    protected winRef: WindowRef;
    private destroy$;
    private trendingSearches$;
    protected checkAvailability(): Observable<string>;
    protected getTrendingSearchUrl(cdsSiteId: string): string;
    protected fetchTrendingSearches(url: string): Observable<SearchPhrases[]>;
    protected initTrendingSearches(): Observable<SearchPhrases[]>;
    getTrendingSearches(): Observable<SearchPhrases[]>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TrendingSearchesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TrendingSearchesService>;
}

declare class TrendingSearchesComponent implements OnInit {
    searchPhrases$: Observable<SearchPhrases[]>;
    protected searchBoxComponentService: SearchBoxComponentService;
    protected trendingSearchesService: TrendingSearchesService;
    protected outletContext: OutletContextData | null;
    ngOnInit(): void;
    protected getSearchPhrases(): Observable<SearchPhrases[]>;
    get contextObservable(): Observable<any>;
    shareEvent(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TrendingSearchesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TrendingSearchesComponent, "cx-trending-searches", never, {}, {}, never, never, true, never>;
}

declare class TrendingSearchesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TrendingSearchesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TrendingSearchesModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.SearchBoxModule, typeof i2.UrlModule, typeof i4.RouterModule, typeof TrendingSearchesComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TrendingSearchesModule>;
}

declare class CdsModule {
    static forRoot(config?: CdsConfig): ModuleWithProviders<CdsModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CdsModule, never, [typeof ProfileTagModule, typeof TrackingModule, typeof MerchandisingModule, typeof RecentSearchesModule, typeof TrendingSearchesModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CdsModule>;
}

declare class CdsMerchandisingStrategyAdapter implements MerchandisingStrategyAdapter {
    private cdsEndpointsService;
    private baseSiteService;
    protected http: HttpClient;
    protected windowRef: WindowRef;
    constructor(cdsEndpointsService: CdsEndpointsService, baseSiteService: BaseSiteService, http: HttpClient);
    loadProductsForStrategy(strategyId: string, strategyRequest?: StrategyRequest): Observable<StrategyProducts>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdsMerchandisingStrategyAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdsMerchandisingStrategyAdapter>;
}

export { AddedToCartPushEvent, AttributesDirective, AttributesModule, BrandPageVisitedEvent, CartSnapshotPushEvent, CartViewPushEvent, CategoryViewPushEvent, CdsBackendConnector, CdsBackendNotificationAdapter, CdsConfig, CdsMerchandisingProductService, CdsMerchandisingSiteContextService, CdsMerchandisingStrategyAdapter, CdsMerchandisingUserContextService, CdsModule, ConsentChangedPushEvent, ConsentReferenceInterceptor, DebugInterceptor, HomePageViewPushEvent, InternalProfileTagEventNames, KeywordSearchPushEvent, MerchandisingCarouselClickedEvent, MerchandisingCarouselCmsModule, MerchandisingCarouselComponent, MerchandisingCarouselComponentService, MerchandisingCarouselViewedEvent, MerchandisingModule, MerchandisingStrategyAdapter, MerchandisingStrategyConnector, ModifiedCartPushEvent, NavigatedPushEvent, OccBackendNotification, OrderConfirmationPushEvent, ProductViewPushEvent, ProfileTagCmsModule, ProfileTagComponent, ProfileTagEventService, ProfileTagInjectorService, ProfileTagLifecycleService, ProfileTagModule, ProfileTagPushEventsService, RemovedFromCartPushEvent, TrackingModule, TrackingService, TrendingSearchesComponent, TrendingSearchesModule, TrendingSearchesService, cdsConfigValidator, defaultCdsConfigFactory };
export type { CarouselEvent, CdsEndpoints, CmsMerchandisingCarouselComponent, ConsentReferenceEvent, DebugEvent, MerchandisingCarouselModel, MerchandisingConfig, MerchandisingFacet, MerchandisingMetadata, MerchandisingProduct, MerchandisingProducts, MerchandisingSiteContext, MerchandisingUserContext, Paged, ProfileTagConfig, ProfileTagJsConfig, ProfileTagPushEvent, ProfileTagWindowObject, RecentSearches, SearchBoxOutletTrendingSearches, SearchPhrases, StrategyProduct, StrategyProducts, StrategyRequest, StrategyResponse };
