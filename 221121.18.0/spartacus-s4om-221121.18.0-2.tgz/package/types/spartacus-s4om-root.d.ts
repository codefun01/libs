import { CartItemContext, OrderEntry } from '@spartacus/cart/base/root';
import * as i2 from '@spartacus/core';
import { TranslationService, CxDatePipe, ProductCatalogService, Product } from '@spartacus/core';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';
import * as i3 from '@spartacus/storefront';
import * as i2$1 from '@spartacus/requested-delivery-date/root';
import * as i3$1 from '@spartacus/pdf-invoices/components';

declare class ScheduleLinesComponent {
    protected cartItemContext: CartItemContext;
    protected translationService: TranslationService;
    protected datePipe: CxDatePipe;
    constructor(cartItemContext: CartItemContext, translationService: TranslationService, datePipe: CxDatePipe);
    readonly orderEntry$: Observable<OrderEntry>;
    /**
     * Verifies whether the Schedule Line infos have any entries.
     * Only in this case we want to display the schedule line summary
     *
     * @param {OrderEntry} item - Cart item
     * @returns {boolean} - whether the Schedule Line information is present for the order
     */
    hasScheduleLines(item: OrderEntry): boolean;
    getScheduleLineInfoId(index: number): string;
    getLongDate(date?: Date): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScheduleLinesComponent, [{ optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScheduleLinesComponent, "cx-schedule-lines", never, {}, {}, never, never, true, never>;
}

declare class ScheduleLinesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ScheduleLinesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ScheduleLinesModule, never, [typeof i1.CommonModule, typeof i2.UrlModule, typeof i2.I18nModule, typeof i3.IconModule, typeof ScheduleLinesComponent], [typeof ScheduleLinesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ScheduleLinesModule>;
}

declare const S4OM_FEATURE = "S4HANA-Order-Management";

interface ScheduleLine {
    confirmedAt?: Date;
    confirmedQuantity?: number;
}

declare module '@spartacus/cart/base/root' {
    interface OrderEntry {
        scheduleLines?: ScheduleLine[];
    }
}

declare class S4omRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<S4omRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<S4omRootModule, never, [typeof ScheduleLinesModule, typeof i2$1.RequestedDeliveryDateComponentsModule, typeof i3$1.PDFInvoicesComponentsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<S4omRootModule>;
}

declare class S4omProductCatalogService extends ProductCatalogService {
    readonly PRODUCT_NOT_IN_CATALOGUE_STOCK_LEVEL_STATUS = "notOrderable";
    /**
     * Returns whether product is present in commerce product catalog.
     * Product will have specific stock level status set if fetched from S4 but not present in sap commerce.
     *
     * @param product product to check
     * @return true if product is present in catalog, false otherwise
     */
    isProductInCatalog(product?: Product): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<S4omProductCatalogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<S4omProductCatalogService>;
}

export { S4OM_FEATURE, S4omProductCatalogService, S4omRootModule, ScheduleLinesComponent, ScheduleLinesModule };
export type { ScheduleLine };
