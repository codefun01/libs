import * as i0 from '@angular/core';

declare class S4omModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<S4omModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<S4omModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<S4omModule>;
}

export { S4omModule };
