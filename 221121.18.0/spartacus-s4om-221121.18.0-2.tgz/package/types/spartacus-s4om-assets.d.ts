import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    s4omScheduleLines: {
        s4omScheduleLines: {
            quantity: string;
            a11y: {
                scheduleLineEntryInfo: string;
            };
        };
    };
};

declare const de: {
    s4omScheduleLines: {
        s4omScheduleLines: {
            quantity: string;
            a11y: {
                scheduleLineEntryInfo: string;
            };
        };
    };
};

declare const en: {
    s4omScheduleLines: {
        s4omScheduleLines: {
            quantity: string;
            a11y: {
                scheduleLineEntryInfo: string;
            };
        };
    };
};

declare const es: {
    s4omScheduleLines: {
        s4omScheduleLines: {
            quantity: string;
            a11y: {
                scheduleLineEntryInfo: string;
            };
        };
    };
};

declare const es_CO: {
    s4omScheduleLines: {
        s4omScheduleLines: {
            quantity: string;
            a11y: {
                scheduleLineEntryInfo: string;
            };
        };
    };
};

declare const fr: {
    s4omScheduleLines: {
        s4omScheduleLines: {
            quantity: string;
            a11y: {
                scheduleLineEntryInfo: string;
            };
        };
    };
};

declare const hi: {
    s4omScheduleLines: {
        s4omScheduleLines: {
            quantity: string;
            a11y: {
                scheduleLineEntryInfo: string;
            };
        };
    };
};

declare const hu: {
    s4omScheduleLines: {
        s4omScheduleLines: {
            quantity: string;
            a11y: {
                scheduleLineEntryInfo: string;
            };
        };
    };
};

declare const id: {
    s4omScheduleLines: {
        s4omScheduleLines: {
            quantity: string;
            a11y: {
                scheduleLineEntryInfo: string;
            };
        };
    };
};

declare const it: {
    s4omScheduleLines: {
        s4omScheduleLines: {
            quantity: string;
            a11y: {
                scheduleLineEntryInfo: string;
            };
        };
    };
};

declare const ja: {
    s4omScheduleLines: {
        s4omScheduleLines: {
            quantity: string;
            a11y: {
                scheduleLineEntryInfo: string;
            };
        };
    };
};

declare const ko: {
    s4omScheduleLines: {
        s4omScheduleLines: {
            quantity: string;
            a11y: {
                scheduleLineEntryInfo: string;
            };
        };
    };
};

declare const pl: {
    s4omScheduleLines: {
        s4omScheduleLines: {
            quantity: string;
            a11y: {
                scheduleLineEntryInfo: string;
            };
        };
    };
};

declare const pt: {
    s4omScheduleLines: {
        s4omScheduleLines: {
            quantity: string;
            a11y: {
                scheduleLineEntryInfo: string;
            };
        };
    };
};

declare const ru: {
    s4omScheduleLines: {
        s4omScheduleLines: {
            quantity: string;
            a11y: {
                scheduleLineEntryInfo: string;
            };
        };
    };
};

declare const zh: {
    s4omScheduleLines: {
        s4omScheduleLines: {
            quantity: string;
            a11y: {
                scheduleLineEntryInfo: string;
            };
        };
    };
};

declare const zh_TW: {
    s4omScheduleLines: {
        s4omScheduleLines: {
            quantity: string;
            a11y: {
                scheduleLineEntryInfo: string;
            };
        };
    };
};

declare const s4omTranslationChunksConfig: TranslationChunksConfig;

export { s4omTranslationChunksConfig, cs as s4omTranslationsCs, de as s4omTranslationsDe, en as s4omTranslationsEn, es as s4omTranslationsEs, es_CO as s4omTranslationsEs_CO, fr as s4omTranslationsFr, hi as s4omTranslationsHi, hu as s4omTranslationsHu, id as s4omTranslationsId, it as s4omTranslationsIt, ja as s4omTranslationsJa, ko as s4omTranslationsKo, pl as s4omTranslationsPl, pt as s4omTranslationsPt, ru as s4omTranslationsRu, zh as s4omTranslationsZh, zh_TW as s4omTranslationsZh_TW };
