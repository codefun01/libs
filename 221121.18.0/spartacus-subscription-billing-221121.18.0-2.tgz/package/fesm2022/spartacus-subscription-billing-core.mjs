import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import * as i1 from '@spartacus/core';
import { QueryService, UserIdService, RoutingService, PageMetaResolver, PageType } from '@spartacus/core';
import { GetSubscriptionByCodeReloadEvent, GetSubscriptionListReloadEvent, GetSubscriptionBillByCodeReloadEvent, GetSubscriptionBillsListReloadEvent, SubscriptionFacade, SubscriptionActionsFacade, SubscriptionBillingFacade } from '@spartacus/subscription-billing/root';
import { switchMap, take, map, combineLatest, of, throwError } from 'rxjs';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionConnector {
    constructor() {
        this.adapter = inject(SubscriptionAdapter);
    }
    getSubscriptionByCode(userId, subscriptionCode) {
        return this.adapter.getSubscriptionByCode(userId, subscriptionCode);
    }
    getSubscriptionList(userId, pageSize, currentPage, sort) {
        return this.adapter.getSubscriptionList(userId, pageSize, currentPage, sort);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionActionsAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionActionsConnector {
    constructor() {
        this.adapter = inject(SubscriptionActionsAdapter);
    }
    getEffectiveCancellationDate(userId, subscriptionCode) {
        return this.adapter.getEffectiveCancellationDate(userId, subscriptionCode);
    }
    cancelSubscription(userId, subscriptionCode, cancellationDetails) {
        return this.adapter.cancelSubscription(userId, subscriptionCode, cancellationDetails);
    }
    reverseCancellation(userId, subscriptionCode) {
        return this.adapter.reverseCancellation(userId, subscriptionCode);
    }
    withdrawSubscription(userId, subscriptionCode, withdrawalData) {
        return this.adapter.withdrawSubscription(userId, subscriptionCode, withdrawalData);
    }
    getExtensionEffectiveDate(userId, subscriptionCode, extendDuration, isUnlimitedDuration) {
        return this.adapter.getExtensionEffectiveDate(userId, subscriptionCode, extendDuration, isUnlimitedDuration);
    }
    extendSubscription(userId, subscriptionCode, extendDuration, isUnlimitedDuration) {
        return this.adapter.extendSubscription(userId, subscriptionCode, extendDuration, isUnlimitedDuration);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsConnector, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsConnector, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2025 SAP Spartacus team <spartacus-team@sap.com>
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionBillingAdapter {
}

/*
 * SPDX-FileCopyrightText: 2025 SAP Spartacus team <spartacus-team@sap.com>
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionBillingConnector {
    constructor() {
        this.adapter = inject(SubscriptionBillingAdapter);
    }
    getSubscriptionBillsList(userId, pageSize, currentPage, sort, filters) {
        return this.adapter.getSubscriptionBillsList(userId, pageSize, currentPage, sort, filters);
    }
    getSubscriptionBillByCode(userId, billCode) {
        return this.adapter.getSubscriptionBillByCode(userId, billCode);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionService {
    constructor() {
        this.queryService = inject(QueryService);
        this.userIdService = inject(UserIdService);
        this.subscriptionConnector = inject(SubscriptionConnector);
        this.routingService = inject(RoutingService);
        /** queries */
        this.getSubscriptionByCodeQuery$ = this.queryService.create(() => this.subscriptionDetailsPreConditions().pipe(switchMap(([customerId, subscriptionCode]) => this.subscriptionConnector.getSubscriptionByCode(customerId, subscriptionCode))), {
            reloadOn: this.getSubscriptionByCodeReloadEvents(),
            // resetOn: this.getTicketQueryResetEvents(),
        });
    }
    /** events */
    getSubscriptionByCodeReloadEvents() {
        return [GetSubscriptionByCodeReloadEvent];
    }
    getSubscriptionListReloadEvents() {
        return [GetSubscriptionListReloadEvent];
    }
    getSubscriptionListQuery$(pageSize, currentPage, sort) {
        return this.queryService.create(() => this.subscriptionListPreConditions().pipe(switchMap((customerId) => this.subscriptionConnector.getSubscriptionList(customerId, pageSize, currentPage, sort))), {
            reloadOn: this.getSubscriptionListReloadEvents(),
        });
    }
    /** query states */
    getSubscriptionByCodeState() {
        return this.getSubscriptionByCodeQuery$.getState();
    }
    getSubscriptionListState(pageSize, currentPage, sort) {
        return this.getSubscriptionListQuery$(pageSize, currentPage, sort).getState();
    }
    /** pre-conditions */
    subscriptionListPreConditions() {
        return this.userIdService.getUserId().pipe(take(1), map((userId) => {
            if (!userId) {
                throw new Error('Subscriptions list pre conditions not met');
            }
            return userId;
        }));
    }
    subscriptionDetailsPreConditions() {
        return combineLatest([
            this.userIdService.getUserId(),
            this.getSubscriptionCodeFromRoute(),
        ]).pipe(map(([userId, subscriptionCode]) => {
            if (!userId || !subscriptionCode) {
                throw new Error('Subscription details pre conditions not met');
            }
            return [userId, subscriptionCode];
        }));
    }
    /** public methods */
    getSubscriptionCodeFromRoute() {
        return this.routingService.getRouterState().pipe(map((route) => {
            const guidPattern = /\/subscription\/([^/?#]+)/;
            const match = route.state.url.match(guidPattern);
            return match ? match[1] : undefined;
        }));
    }
    getSubscriptionByCode() {
        return this.getSubscriptionByCodeState().pipe(map((state) => state.data));
    }
    getSubscriptionList(pageSize, currentPage, sort) {
        return this.getSubscriptionListState(pageSize, currentPage, sort).pipe(map((state) => state.data));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionActionsService {
    constructor() {
        this.queryService = inject(QueryService);
        this.userIdService = inject(UserIdService);
        this.subscriptionActionsConnector = inject(SubscriptionActionsConnector);
        this.routingService = inject(RoutingService);
    }
    getSubscriptionByCodeReloadEvents() {
        return [GetSubscriptionByCodeReloadEvent];
    }
    getEffectiveCancellationDate(subscriptionCode) {
        return combineLatest([
            this.userIdService.getUserId(),
            of(subscriptionCode),
        ]).pipe(take(1), switchMap(([userId, code]) => {
            if (!userId || !code) {
                throw new Error('Cannot fetch cancellation effective date: missing user ID or subscription code.');
            }
            return this.subscriptionActionsConnector.getEffectiveCancellationDate(userId, code);
        }));
    }
    cancelSubscription(cancellationDetails, subscriptionCode) {
        return combineLatest([
            this.userIdService.getUserId(),
            of(subscriptionCode),
        ]).pipe(take(1), switchMap(([userId, code]) => {
            if (!userId || !code) {
                throw new Error('Cannot cancel subscription: missing user ID or subscription code.');
            }
            return this.subscriptionActionsConnector.cancelSubscription(userId, code, cancellationDetails);
        }));
    }
    reverseCancellation(subscriptionCode) {
        return combineLatest([
            this.userIdService.getUserId(),
            of(subscriptionCode),
        ]).pipe(take(1), switchMap(([userId, code]) => {
            if (!userId || !code) {
                throw new Error('Cannot reverse cancellation: missing user ID or subscription code.');
            }
            return this.subscriptionActionsConnector.reverseCancellation(userId, code);
        }));
    }
    withdrawSubscription(withdrawalData, subscriptionCode) {
        return combineLatest([
            this.userIdService.getUserId(),
            of(subscriptionCode),
        ]).pipe(take(1), switchMap(([userId, code]) => {
            if (!userId || !code) {
                throw new Error('Cannot withdraw subscription: missing user ID or subscription code.');
            }
            return this.subscriptionActionsConnector.withdrawSubscription(userId, code, withdrawalData);
        }));
    }
    getExtensionEffectiveDate(extendDuration, isUnlimitedDuration, code) {
        return combineLatest([this.userIdService.getUserId(), of(code)]).pipe(switchMap(([userId, subscriptionCode]) => this.subscriptionActionsConnector.getExtensionEffectiveDate(userId, subscriptionCode, extendDuration, isUnlimitedDuration)));
    }
    extendSubscription(extendDuration, isUnlimitedDuration, subscriptionCode) {
        return combineLatest([
            this.userIdService.getUserId(),
            of(subscriptionCode),
        ]).pipe(take(1), switchMap(([userId, code]) => this.subscriptionActionsConnector.extendSubscription(userId, code, extendDuration, isUnlimitedDuration)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2025 SAP Spartacus team <spartacus-team@sap.com>
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionBillingService {
    constructor() {
        this.queryService = inject(QueryService);
        this.userIdService = inject(UserIdService);
        this.routingService = inject(RoutingService);
        this.subscriptionBillsConnector = inject(SubscriptionBillingConnector);
        this.getSubscriptionBillByCodeQuery$ = this.queryService.create(() => this.subscriptionBillPreConditions().pipe(switchMap(({ userId, subscriptionBillCode }) => this.subscriptionBillsConnector.getSubscriptionBillByCode(userId, subscriptionBillCode))), {
            reloadOn: [GetSubscriptionBillByCodeReloadEvent],
        });
    }
    subscriptionBillPreConditions() {
        return combineLatest([
            this.userIdService.getUserId(),
            this.getSubscriptionBillCodeFromRoute(),
        ]).pipe(switchMap(([userId, subscriptionBillCode]) => {
            if (!userId || !subscriptionBillCode) {
                return throwError(() => new Error('Subscription bill details pre conditions not met'));
            }
            return of({ userId, subscriptionBillCode });
        }));
    }
    subscriptionBillsListPreConditions() {
        return this.userIdService.getUserId().pipe(take(1), switchMap((userId) => {
            if (!userId) {
                return throwError(() => new Error('Subscription Bills List pre conditions are not met'));
            }
            return of(userId);
        }));
    }
    getSubscriptionBillListQuery$(pageSize, currentPage, sort, filter) {
        return this.queryService.create(() => this.subscriptionBillsListPreConditions().pipe(switchMap((userId) => this.subscriptionBillsConnector.getSubscriptionBillsList(userId, pageSize, currentPage, sort, filter))), {
            reloadOn: [GetSubscriptionBillsListReloadEvent],
        });
    }
    getSubscriptionBillByCodeState() {
        return this.getSubscriptionBillByCodeQuery$.getState();
    }
    getSubscriptionBillsListState(pageSize, currentPage, sort, filter) {
        return this.getSubscriptionBillListQuery$(pageSize, currentPage, sort, filter).getState();
    }
    getSubscriptionBillsList(pageSize, currentPage, sort, filters) {
        return this.getSubscriptionBillsListState(pageSize, currentPage, sort, filters).pipe(map((state) => state.data));
    }
    getSubscriptionBillByCode() {
        return this.getSubscriptionBillByCodeState().pipe(map((state) => state.data));
    }
    getSubscriptionBillCodeFromRoute() {
        return this.routingService.getRouterState().pipe(map((route) => {
            const guidPattern = /\/subscription-bill\/([^/?#]+)/;
            const match = route.state.url.match(guidPattern);
            return match ? match[1] : undefined;
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionDetailsPageMetaResolver extends PageMetaResolver {
    constructor(basePageMetaResolver, translation) {
        super();
        this.basePageMetaResolver = basePageMetaResolver;
        this.translation = translation;
        this.pageType = PageType.CONTENT_PAGE;
        this.pageTemplate = 'AccountPageTemplate';
        this.pageUid = 'subscription-details';
    }
    resolveHeading() {
        return this.basePageMetaResolver.resolveTitle();
    }
    resolveTitle() {
        return this.basePageMetaResolver.resolveTitle();
    }
    resolveDescription() {
        return this.basePageMetaResolver.resolveDescription();
    }
    resolveBreadcrumbs() {
        return combineLatest([
            this.translation.translate('subscriptionPageBreadcrumb.home'),
            this.translation.translate('subscriptionPageBreadcrumb.subscriptions'),
        ]).pipe(map(([homeLabel, subscriptionsLabel]) => {
            return [
                { label: homeLabel, link: '/' },
                {
                    label: subscriptionsLabel,
                    link: '/my-account/subscriptions',
                },
            ];
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionDetailsPageMetaResolver, deps: [{ token: i1.BasePageMetaResolver }, { token: i1.TranslationService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionDetailsPageMetaResolver, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionDetailsPageMetaResolver, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.BasePageMetaResolver }, { type: i1.TranslationService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionBillingDetailsPageMetaResolver extends PageMetaResolver {
    constructor(basePageMetaResolver, translation) {
        super();
        this.basePageMetaResolver = basePageMetaResolver;
        this.translation = translation;
        this.pageType = PageType.CONTENT_PAGE;
        this.pageTemplate = 'AccountPageTemplate';
        this.pageUid = 'subscription-bill-details';
    }
    resolveHeading() {
        return this.basePageMetaResolver.resolveTitle();
    }
    resolveTitle() {
        return this.basePageMetaResolver.resolveTitle();
    }
    resolveDescription() {
        return this.basePageMetaResolver.resolveDescription();
    }
    resolveBreadcrumbs() {
        return combineLatest([
            this.translation.translate('subscriptionPageBreadcrumb.home'),
            this.translation.translate('subscriptionPageBreadcrumb.subscriptionBills'),
        ]).pipe(map(([homeLabel, subscriptionBillsLabel]) => {
            return [
                { label: homeLabel, link: '/' },
                {
                    label: subscriptionBillsLabel,
                    link: '/my-account/subscription-bills',
                },
            ];
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingDetailsPageMetaResolver, deps: [{ token: i1.BasePageMetaResolver }, { token: i1.TranslationService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingDetailsPageMetaResolver, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingDetailsPageMetaResolver, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.BasePageMetaResolver }, { type: i1.TranslationService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const facadeProviders = [
    SubscriptionService,
    {
        provide: SubscriptionFacade,
        useExisting: SubscriptionService,
    },
    SubscriptionActionsService,
    {
        provide: SubscriptionActionsFacade,
        useExisting: SubscriptionActionsService,
    },
    SubscriptionBillingService,
    {
        provide: SubscriptionBillingFacade,
        useExisting: SubscriptionBillingService,
    },
    {
        provide: PageMetaResolver,
        useExisting: SubscriptionDetailsPageMetaResolver,
        multi: true,
    },
    {
        provide: PageMetaResolver,
        useExisting: SubscriptionBillingDetailsPageMetaResolver,
        multi: true,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionBillingCoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingCoreModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingCoreModule, providers: [
            ...facadeProviders,
            SubscriptionConnector,
            SubscriptionActionsConnector,
            SubscriptionBillingConnector,
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    providers: [
                        ...facadeProviders,
                        SubscriptionConnector,
                        SubscriptionActionsConnector,
                        SubscriptionBillingConnector,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { SubscriptionActionsAdapter, SubscriptionActionsConnector, SubscriptionActionsService, SubscriptionAdapter, SubscriptionBillingAdapter, SubscriptionBillingConnector, SubscriptionBillingCoreModule, SubscriptionBillingDetailsPageMetaResolver, SubscriptionBillingService, SubscriptionConnector, SubscriptionDetailsPageMetaResolver, SubscriptionService, facadeProviders };
//# sourceMappingURL=spartacus-subscription-billing-core.mjs.map
