import * as i0 from '@angular/core';
import { computed, Input, Component, NgModule, inject, signal, Injectable, DestroyRef, effect } from '@angular/core';
import * as i1 from '@angular/common';
import { NgIf, NgTemplateOutlet, NgFor, CommonModule, NgClass, AsyncPipe } from '@angular/common';
import * as i4 from '@spartacus/core';
import { TranslatePipe, I18nModule, EventService, CxDatePipe, UrlPipe, UrlModule, provideDefaultConfig, AuthGuard, GlobalMessageService, GlobalMessageType } from '@spartacus/core';
import { UsageChargeType, SubscriptionFacade, GetSubscriptionByCodeReloadEvent, SubscriptionProductService, SubscriptionActionsFacade, defaultExtendDropdownOptions, SubscriptionBillingFacade, GetSubscriptionBillsListReloadEvent, GetSubscriptionBillByCodeReloadEvent } from '@spartacus/subscription-billing/root';
import { RouterLink, RouterModule } from '@angular/router';
import * as i2 from '@spartacus/storefront';
import { LaunchDialogService, LAUNCH_CALLER, SpinnerComponent, SpinnerModule, IconModule, SortingComponent, PaginationComponent, ListNavigationModule, ICON_TYPE, CardModule, KeyboardFocusModule, FormRequiredAsterisksComponent, DIALOG_TYPE, DatePickerService, CustomFormValidators, IconComponent, DatePickerComponent, DatePickerModule, FormErrorsModule } from '@spartacus/storefront';
import { of, take, switchMap, catchError, EMPTY } from 'rxjs';
import { toSignal, toObservable, takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i3 from '@ng-select/ng-select';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionProductUsageChargeComponent {
    constructor() {
        this.blockUsageCharges = computed(() => {
            return (this.product()?.sapPricePlan?.perUnitUsageCharges?.filter((item) => item.usageChargeType === UsageChargeType.BLOCK) ?? []);
        }, ...(ngDevMode ? [{ debugName: "blockUsageCharges" }] : /* istanbul ignore next */ []));
        this.percentageUsageCharges = computed(() => {
            return (this.product()?.sapPricePlan?.perUnitUsageCharges?.filter((item) => item.usageChargeType === UsageChargeType.PERCENTAGE) ?? []);
        }, ...(ngDevMode ? [{ debugName: "percentageUsageCharges" }] : /* istanbul ignore next */ []));
        this.tierUsageCharges = computed(() => {
            return (this.product()?.sapPricePlan?.perUnitUsageCharges?.filter((item) => item.usageChargeType === UsageChargeType.TIER) ?? []);
        }, ...(ngDevMode ? [{ debugName: "tierUsageCharges" }] : /* istanbul ignore next */ []));
        this.volumeUsageCharges = computed(() => this.product()?.sapPricePlan?.volumeUsageCharges ?? [], ...(ngDevMode ? [{ debugName: "volumeUsageCharges" }] : /* istanbul ignore next */ []));
    }
    getIncludedQuantity(charge) {
        if (charge.includedQty) {
            return (charge.includedQty +
                ' ' +
                (charge.includedQty > 1
                    ? charge.usageUnit?.namePlural
                    : charge.usageUnit?.name));
        }
        return '';
    }
    getLastTierValue(tierUsageChargeEntries) {
        return (tierUsageChargeEntries[tierUsageChargeEntries.length - 1].tierEnd ?? 0);
    }
    isUsageChargePresent() {
        return Boolean(this.product()?.sapPricePlan?.perUnitUsageCharges ??
            this.product()?.sapPricePlan?.volumeUsageCharges);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionProductUsageChargeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: SubscriptionProductUsageChargeComponent, isStandalone: true, selector: "cx-subscription-product-usage-charge", inputs: { product: "product" }, ngImport: i0, template: "<div class=\"subscription-usage-charge\">\n  <div *ngIf=\"isUsageChargePresent()\" class=\"subscription-heading\">\n    {{ 'subscriptionProduct.usageCharges' | cxTranslate }}:\n  </div>\n\n  <ng-container *ngIf=\"tierUsageCharges().length > 0\">\n    <ng-container *ngTemplateOutlet=\"showTierUsageCharges\"></ng-container>\n  </ng-container>\n\n  <ng-container *ngIf=\"volumeUsageCharges().length > 0\">\n    <ng-container *ngTemplateOutlet=\"showVolumeUsageCharges\"></ng-container>\n  </ng-container>\n\n  <ng-container *ngIf=\"percentageUsageCharges().length > 0\">\n    <ng-container *ngTemplateOutlet=\"showPercentageUsageCharges\"></ng-container>\n  </ng-container>\n\n  <ng-container *ngIf=\"blockUsageCharges().length > 0\">\n    <ng-container *ngTemplateOutlet=\"showBlockUsageCharges\"></ng-container>\n  </ng-container>\n</div>\n\n<!-- Block Usage Charges -->\n<ng-template #showBlockUsageCharges>\n  <ng-container *ngFor=\"let usageCharge of blockUsageCharges(); let i = index\">\n    <ul>\n      <ng-container *ngIf=\"(usageCharge.includedQty ?? 0) > 0\">\n        <li>\n          {{\n            'subscriptionProduct.includedQuantity'\n              | cxTranslate: { quantity: getIncludedQuantity(usageCharge) }\n          }}\n        </li>\n      </ng-container>\n\n      <ng-container\n        *ngFor=\"\n          let usageChargeEntry of usageCharge.perUnitUsageChargeEntries;\n          let j = index\n        \"\n      >\n        <li>\n          <ng-container *ngIf=\"usageCharge.blockSize === 1\">\n            {{\n              'subscriptionProduct.oneBlockUsage'\n                | cxTranslate\n                  : {\n                      price: usageChargeEntry.price?.formattedValue,\n                      usage: usageCharge.usageUnit?.name,\n                    }\n            }}\n          </ng-container>\n          <ng-container *ngIf=\"(usageCharge.blockSize ?? 0) > 1\">\n            {{\n              'subscriptionProduct.multiBlockUsage'\n                | cxTranslate\n                  : {\n                      price: usageChargeEntry.price?.formattedValue,\n                      block:\n                        usageCharge.blockSize +\n                        ' ' +\n                        usageCharge?.usageUnit?.namePlural,\n                    }\n            }}\n          </ng-container>\n        </li>\n      </ng-container>\n    </ul>\n  </ng-container>\n</ng-template>\n\n<!-- Volume Usage Charges -->\n<ng-template #showVolumeUsageCharges>\n  <ng-container *ngFor=\"let usageCharge of volumeUsageCharges(); let i = index\">\n    <ul>\n      <ng-container\n        *ngFor=\"\n          let usageChargeEntry of usageCharge.tierUsageChargeEntries;\n          let j = index\n        \"\n      >\n        <li>\n          {{\n            'subscriptionProduct.volumeUsage'\n              | cxTranslate\n                : {\n                    from:\n                      usageChargeEntry.tierStart +\n                      ' ' +\n                      usageCharge.usageUnit?.name,\n                    to:\n                      usageChargeEntry.tierEnd +\n                      ' ' +\n                      usageCharge.usageUnit?.name,\n                    fixed: usageChargeEntry.fixedPrice?.formattedValue,\n                    price: usageChargeEntry.price?.formattedValue,\n                    usage: usageCharge.usageUnit?.name,\n                  }\n          }}\n        </li>\n      </ng-container>\n\n      <ng-container\n        *ngFor=\"\n          let usageChargeEntry of usageCharge.overageUsageChargeEntries;\n          let k = index\n        \"\n      >\n        <li>\n          {{\n            'subscriptionProduct.volumeOverageUsage'\n              | cxTranslate\n                : {\n                    from:\n                      getLastTierValue(\n                        usageCharge.tierUsageChargeEntries ?? []\n                      ) +\n                      1 +\n                      ' ' +\n                      usageCharge.usageUnit?.name,\n                    fixed: usageChargeEntry.fixedPrice?.formattedValue,\n                    price: usageChargeEntry.price?.formattedValue,\n                    usage: usageCharge.usageUnit?.name,\n                  }\n          }}\n        </li>\n      </ng-container>\n    </ul>\n    <div class=\"subscription-message\">\n      {{ 'subscriptionProduct.volumeUsageMessage' | cxTranslate }}\n    </div>\n  </ng-container>\n</ng-template>\n\n<!-- Tier Usage Charges -->\n<ng-template #showTierUsageCharges>\n  <ng-container *ngFor=\"let usageCharge of tierUsageCharges(); let i = index\">\n    <ul>\n      <ng-container\n        *ngFor=\"\n          let usageChargeEntry of usageCharge.tierUsageChargeEntries;\n          let j = index\n        \"\n      >\n        <li>\n          {{\n            'subscriptionProduct.tierUsage'\n              | cxTranslate\n                : {\n                    from:\n                      usageChargeEntry.tierStart +\n                      ' ' +\n                      usageCharge.usageUnit?.name,\n                    to:\n                      usageChargeEntry.tierEnd +\n                      ' ' +\n                      usageCharge.usageUnit?.name,\n                    price: usageChargeEntry.price?.formattedValue,\n                    usage: usageCharge.usageUnit?.name,\n                  }\n          }}\n        </li>\n      </ng-container>\n\n      <ng-container\n        *ngFor=\"\n          let usageChargeEntry of usageCharge.overageUsageChargeEntries;\n          let k = index\n        \"\n      >\n        <li>\n          {{\n            'subscriptionProduct.tierOverageUsage'\n              | cxTranslate\n                : {\n                    from:\n                      getLastTierValue(\n                        usageCharge?.tierUsageChargeEntries || []\n                      ) +\n                      1 +\n                      (usageCharge?.usageUnit?.name || ''),\n                    price: usageChargeEntry.price?.formattedValue,\n                    usage: usageCharge.usageUnit?.name,\n                  }\n          }}\n        </li>\n      </ng-container>\n    </ul>\n\n    <div class=\"subscription-message\">\n      {{ 'subscriptionProduct.tierUsageMessage' | cxTranslate }}\n    </div>\n  </ng-container>\n</ng-template>\n\n<!-- Percentage Usage Charges -->\n<ng-template #showPercentageUsageCharges>\n  <ul>\n    <ng-container\n      *ngFor=\"let usageCharge of percentageUsageCharges(); let i = index\"\n    >\n      <ng-container\n        *ngFor=\"\n          let usageChargeEntry of usageCharge.perUnitUsageChargeEntries;\n          let j = index\n        \"\n      >\n        <li>\n          {{\n            'subscriptionProduct.percentageUsage'\n              | cxTranslate\n                : {\n                    ratio: usageCharge.ratio,\n                    price: usageChargeEntry.price?.formattedValue,\n                    usage: usageCharge.usageUnit?.name,\n                  }\n          }}\n        </li>\n      </ng-container>\n    </ng-container>\n  </ul>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionProductUsageChargeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-subscription-product-usage-charge', imports: [NgIf, NgTemplateOutlet, NgFor, TranslatePipe], template: "<div class=\"subscription-usage-charge\">\n  <div *ngIf=\"isUsageChargePresent()\" class=\"subscription-heading\">\n    {{ 'subscriptionProduct.usageCharges' | cxTranslate }}:\n  </div>\n\n  <ng-container *ngIf=\"tierUsageCharges().length > 0\">\n    <ng-container *ngTemplateOutlet=\"showTierUsageCharges\"></ng-container>\n  </ng-container>\n\n  <ng-container *ngIf=\"volumeUsageCharges().length > 0\">\n    <ng-container *ngTemplateOutlet=\"showVolumeUsageCharges\"></ng-container>\n  </ng-container>\n\n  <ng-container *ngIf=\"percentageUsageCharges().length > 0\">\n    <ng-container *ngTemplateOutlet=\"showPercentageUsageCharges\"></ng-container>\n  </ng-container>\n\n  <ng-container *ngIf=\"blockUsageCharges().length > 0\">\n    <ng-container *ngTemplateOutlet=\"showBlockUsageCharges\"></ng-container>\n  </ng-container>\n</div>\n\n<!-- Block Usage Charges -->\n<ng-template #showBlockUsageCharges>\n  <ng-container *ngFor=\"let usageCharge of blockUsageCharges(); let i = index\">\n    <ul>\n      <ng-container *ngIf=\"(usageCharge.includedQty ?? 0) > 0\">\n        <li>\n          {{\n            'subscriptionProduct.includedQuantity'\n              | cxTranslate: { quantity: getIncludedQuantity(usageCharge) }\n          }}\n        </li>\n      </ng-container>\n\n      <ng-container\n        *ngFor=\"\n          let usageChargeEntry of usageCharge.perUnitUsageChargeEntries;\n          let j = index\n        \"\n      >\n        <li>\n          <ng-container *ngIf=\"usageCharge.blockSize === 1\">\n            {{\n              'subscriptionProduct.oneBlockUsage'\n                | cxTranslate\n                  : {\n                      price: usageChargeEntry.price?.formattedValue,\n                      usage: usageCharge.usageUnit?.name,\n                    }\n            }}\n          </ng-container>\n          <ng-container *ngIf=\"(usageCharge.blockSize ?? 0) > 1\">\n            {{\n              'subscriptionProduct.multiBlockUsage'\n                | cxTranslate\n                  : {\n                      price: usageChargeEntry.price?.formattedValue,\n                      block:\n                        usageCharge.blockSize +\n                        ' ' +\n                        usageCharge?.usageUnit?.namePlural,\n                    }\n            }}\n          </ng-container>\n        </li>\n      </ng-container>\n    </ul>\n  </ng-container>\n</ng-template>\n\n<!-- Volume Usage Charges -->\n<ng-template #showVolumeUsageCharges>\n  <ng-container *ngFor=\"let usageCharge of volumeUsageCharges(); let i = index\">\n    <ul>\n      <ng-container\n        *ngFor=\"\n          let usageChargeEntry of usageCharge.tierUsageChargeEntries;\n          let j = index\n        \"\n      >\n        <li>\n          {{\n            'subscriptionProduct.volumeUsage'\n              | cxTranslate\n                : {\n                    from:\n                      usageChargeEntry.tierStart +\n                      ' ' +\n                      usageCharge.usageUnit?.name,\n                    to:\n                      usageChargeEntry.tierEnd +\n                      ' ' +\n                      usageCharge.usageUnit?.name,\n                    fixed: usageChargeEntry.fixedPrice?.formattedValue,\n                    price: usageChargeEntry.price?.formattedValue,\n                    usage: usageCharge.usageUnit?.name,\n                  }\n          }}\n        </li>\n      </ng-container>\n\n      <ng-container\n        *ngFor=\"\n          let usageChargeEntry of usageCharge.overageUsageChargeEntries;\n          let k = index\n        \"\n      >\n        <li>\n          {{\n            'subscriptionProduct.volumeOverageUsage'\n              | cxTranslate\n                : {\n                    from:\n                      getLastTierValue(\n                        usageCharge.tierUsageChargeEntries ?? []\n                      ) +\n                      1 +\n                      ' ' +\n                      usageCharge.usageUnit?.name,\n                    fixed: usageChargeEntry.fixedPrice?.formattedValue,\n                    price: usageChargeEntry.price?.formattedValue,\n                    usage: usageCharge.usageUnit?.name,\n                  }\n          }}\n        </li>\n      </ng-container>\n    </ul>\n    <div class=\"subscription-message\">\n      {{ 'subscriptionProduct.volumeUsageMessage' | cxTranslate }}\n    </div>\n  </ng-container>\n</ng-template>\n\n<!-- Tier Usage Charges -->\n<ng-template #showTierUsageCharges>\n  <ng-container *ngFor=\"let usageCharge of tierUsageCharges(); let i = index\">\n    <ul>\n      <ng-container\n        *ngFor=\"\n          let usageChargeEntry of usageCharge.tierUsageChargeEntries;\n          let j = index\n        \"\n      >\n        <li>\n          {{\n            'subscriptionProduct.tierUsage'\n              | cxTranslate\n                : {\n                    from:\n                      usageChargeEntry.tierStart +\n                      ' ' +\n                      usageCharge.usageUnit?.name,\n                    to:\n                      usageChargeEntry.tierEnd +\n                      ' ' +\n                      usageCharge.usageUnit?.name,\n                    price: usageChargeEntry.price?.formattedValue,\n                    usage: usageCharge.usageUnit?.name,\n                  }\n          }}\n        </li>\n      </ng-container>\n\n      <ng-container\n        *ngFor=\"\n          let usageChargeEntry of usageCharge.overageUsageChargeEntries;\n          let k = index\n        \"\n      >\n        <li>\n          {{\n            'subscriptionProduct.tierOverageUsage'\n              | cxTranslate\n                : {\n                    from:\n                      getLastTierValue(\n                        usageCharge?.tierUsageChargeEntries || []\n                      ) +\n                      1 +\n                      (usageCharge?.usageUnit?.name || ''),\n                    price: usageChargeEntry.price?.formattedValue,\n                    usage: usageCharge.usageUnit?.name,\n                  }\n          }}\n        </li>\n      </ng-container>\n    </ul>\n\n    <div class=\"subscription-message\">\n      {{ 'subscriptionProduct.tierUsageMessage' | cxTranslate }}\n    </div>\n  </ng-container>\n</ng-template>\n\n<!-- Percentage Usage Charges -->\n<ng-template #showPercentageUsageCharges>\n  <ul>\n    <ng-container\n      *ngFor=\"let usageCharge of percentageUsageCharges(); let i = index\"\n    >\n      <ng-container\n        *ngFor=\"\n          let usageChargeEntry of usageCharge.perUnitUsageChargeEntries;\n          let j = index\n        \"\n      >\n        <li>\n          {{\n            'subscriptionProduct.percentageUsage'\n              | cxTranslate\n                : {\n                    ratio: usageCharge.ratio,\n                    price: usageChargeEntry.price?.formattedValue,\n                    usage: usageCharge.usageUnit?.name,\n                  }\n          }}\n        </li>\n      </ng-container>\n    </ng-container>\n  </ul>\n</ng-template>\n" }]
        }], propDecorators: { product: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionProductUsageChargeModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionProductUsageChargeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionProductUsageChargeModule, imports: [CommonModule, I18nModule, SubscriptionProductUsageChargeComponent], exports: [SubscriptionProductUsageChargeComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionProductUsageChargeModule, imports: [CommonModule, I18nModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionProductUsageChargeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, I18nModule, SubscriptionProductUsageChargeComponent],
                    exports: [SubscriptionProductUsageChargeComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionDetailsComponent {
    constructor() {
        this.subscriptionFacade = inject(SubscriptionFacade);
        this.eventService = inject(EventService);
        this.launchDialogService = inject(LaunchDialogService);
        this.subscriptionDetails$ = of(undefined);
    }
    ngOnInit() {
        this.eventService.dispatch({}, GetSubscriptionByCodeReloadEvent);
        this.subscriptionDetails$ = this.subscriptionFacade.getSubscriptionByCode();
    }
    showSubscriptionActionsDialog(mode) {
        this.subscriptionDetails$.pipe(take(1)).subscribe((subscription) => {
            if (!subscription) {
                return;
            }
            const dataToPass = {
                ...subscription,
                code: subscription.id,
                mode,
            };
            this.launchDialogService.openDialogAndSubscribe(LAUNCH_CALLER.SUBSCRIPTION_ACTION_CONFIRMATION, undefined, dataToPass);
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionDetailsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: SubscriptionDetailsComponent, isStandalone: true, selector: "cx-subscription-details", ngImport: i0, template: "<ng-container\n  *ngIf=\"subscriptionDetails$ | async as subscription; else loading\"\n>\n  <div class=\"subscription\">\n    <div class=\"subscription-header\">\n      <div\n        class=\"subscription-name\"\n        *ngIf=\"subscription.name\"\n        [attr.aria-label]=\"'subscriptionList.product' | cxTranslate\"\n      >\n        {{ subscription.name }}\n      </div>\n      <div\n        class=\"subscription-status\"\n        [attr.aria-label]=\"'subscriptionList.status' | cxTranslate\"\n        *ngIf=\"subscription.status\"\n      >\n        {{ 'subscriptionList.status' | cxTranslate }}\n        <span [ngClass]=\"subscription.status\">{{ subscription.status }}</span>\n      </div>\n    </div>\n    <div class=\"subscription-body\">\n      <div class=\"subscription-column-1\">\n        <div class=\"subscription-info\">\n          {{ 'subscriptionDetails.info' | cxTranslate }}\n        </div>\n        <div *ngIf=\"subscription.documentNumber\">\n          {{\n            'subscriptionList.id'\n              | cxTranslate: { id: subscription.documentNumber }\n          }}\n        </div>\n        <div *ngIf=\"subscription.productCode\">\n          {{ 'subscriptionDetails.productCode' | cxTranslate }}\n          <a\n            [routerLink]=\"\n              { cxRoute: 'product', params: { code: subscription.productCode } }\n                | cxUrl\n            \"\n          >\n            {{ subscription.productCode }}\n          </a>\n        </div>\n        <div\n          *ngIf=\"\n            subscription?.pricePlan?.recurringCharges[0]?.price\n              ?.formattedValue && subscription.billingTime\n          \"\n        >\n          {{\n            'subscriptionList.amount'\n              | cxTranslate\n                : {\n                    amount:\n                      subscription?.pricePlan?.recurringCharges[0]?.price\n                        ?.formattedValue,\n                    time: subscription.billingTime,\n                  }\n          }}\n        </div>\n        <div *ngIf=\"subscription.startAt\">\n          {{\n            'subscriptionList.startDate'\n              | cxTranslate: { date: subscription.startAt | cxDate }\n          }}\n        </div>\n        <div *ngIf=\"subscription.endAt\">\n          {{\n            'subscriptionDetails.endDate'\n              | cxTranslate: { date: subscription.endAt | cxDate }\n          }}\n        </div>\n        <div *ngIf=\"subscription.withdrawalPeriodEndAt\">\n          {{\n            'subscriptionDetails.withdrawalEnd'\n              | cxTranslate\n                : { date: subscription.withdrawalPeriodEndAt | cxDate }\n          }}\n        </div>\n        <div *ngIf=\"subscription.orderCode\">\n          {{ 'subscriptionDetails.orderCode' | cxTranslate }}\n          <a\n            [routerLink]=\"\n              {\n                cxRoute: 'orderDetails',\n                params: { code: subscription.orderCode },\n              } | cxUrl\n            \"\n          >\n            {{ subscription.orderCode }}\n          </a>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"subscription-actions row\">\n    <span\n      class=\"col-xs-12 col-md-4 col-lg-3 action-button\"\n      *ngIf=\"subscription.isWithdrawalPossible\"\n    >\n      <a\n        [attr.aria-label]=\"\n          'subscriptionDetails.withdrawSubscription' | cxTranslate\n        \"\n        (click)=\"showSubscriptionActionsDialog('withdraw')\"\n        cxBtnLikeLink\n        class=\"btn btn-block btn-secondary\"\n      >\n        {{ 'subscriptionDetails.withdrawSubscription' | cxTranslate }}\n      </a>\n    </span>\n    <span\n      class=\"col-xs-12 col-md-4 col-lg-3 action-button\"\n      *ngIf=\"subscription.isCancellationPossible\"\n    >\n      <a\n        cxBtnLikeLink\n        class=\"btn btn-block btn-secondary\"\n        (click)=\"showSubscriptionActionsDialog('cancel')\"\n        [attr.aria-label]=\"\n          'subscriptionDetails.cancelSubscription' | cxTranslate\n        \"\n      >\n        {{ 'subscriptionDetails.cancelSubscription' | cxTranslate }}\n      </a>\n    </span>\n    <span\n      class=\"col-xs-12 col-md-4 col-lg-3 action-button\"\n      *ngIf=\"subscription.isExtensionPossible\"\n    >\n      <a\n        #extendSubscriptionBtn\n        [attr.aria-label]=\"\n          'subscriptionDetails.extendSubscription' | cxTranslate\n        \"\n        cxBtnLikeLink\n        class=\"btn btn-block btn-primary\"\n        (click)=\"showSubscriptionActionsDialog('extend')\"\n      >\n        {{ 'subscriptionDetails.extendSubscription' | cxTranslate }}\n      </a>\n    </span>\n    <span\n      class=\"col-xs-12 col-md-4 col-lg-3 action-button\"\n      *ngIf=\"subscription.isCancellationReversalPossible\"\n    >\n      <a\n        cxBtnLikeLink\n        class=\"btn btn-block btn-primary\"\n        [attr.aria-label]=\"'subscriptionDetails.reSubscribe' | cxTranslate\"\n        (click)=\"showSubscriptionActionsDialog('resubscribe')\"\n      >\n        {{ 'subscriptionDetails.reSubscribe' | cxTranslate }}\n      </a>\n    </span>\n  </div>\n</ng-container>\n<ng-template #loading>\n  <cx-spinner></cx-spinner>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: CxDatePipe, name: "cxDate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-subscription-details', imports: [
                        NgIf,
                        NgClass,
                        RouterLink,
                        AsyncPipe,
                        TranslatePipe,
                        CxDatePipe,
                        UrlPipe,
                        SpinnerComponent,
                    ], template: "<ng-container\n  *ngIf=\"subscriptionDetails$ | async as subscription; else loading\"\n>\n  <div class=\"subscription\">\n    <div class=\"subscription-header\">\n      <div\n        class=\"subscription-name\"\n        *ngIf=\"subscription.name\"\n        [attr.aria-label]=\"'subscriptionList.product' | cxTranslate\"\n      >\n        {{ subscription.name }}\n      </div>\n      <div\n        class=\"subscription-status\"\n        [attr.aria-label]=\"'subscriptionList.status' | cxTranslate\"\n        *ngIf=\"subscription.status\"\n      >\n        {{ 'subscriptionList.status' | cxTranslate }}\n        <span [ngClass]=\"subscription.status\">{{ subscription.status }}</span>\n      </div>\n    </div>\n    <div class=\"subscription-body\">\n      <div class=\"subscription-column-1\">\n        <div class=\"subscription-info\">\n          {{ 'subscriptionDetails.info' | cxTranslate }}\n        </div>\n        <div *ngIf=\"subscription.documentNumber\">\n          {{\n            'subscriptionList.id'\n              | cxTranslate: { id: subscription.documentNumber }\n          }}\n        </div>\n        <div *ngIf=\"subscription.productCode\">\n          {{ 'subscriptionDetails.productCode' | cxTranslate }}\n          <a\n            [routerLink]=\"\n              { cxRoute: 'product', params: { code: subscription.productCode } }\n                | cxUrl\n            \"\n          >\n            {{ subscription.productCode }}\n          </a>\n        </div>\n        <div\n          *ngIf=\"\n            subscription?.pricePlan?.recurringCharges[0]?.price\n              ?.formattedValue && subscription.billingTime\n          \"\n        >\n          {{\n            'subscriptionList.amount'\n              | cxTranslate\n                : {\n                    amount:\n                      subscription?.pricePlan?.recurringCharges[0]?.price\n                        ?.formattedValue,\n                    time: subscription.billingTime,\n                  }\n          }}\n        </div>\n        <div *ngIf=\"subscription.startAt\">\n          {{\n            'subscriptionList.startDate'\n              | cxTranslate: { date: subscription.startAt | cxDate }\n          }}\n        </div>\n        <div *ngIf=\"subscription.endAt\">\n          {{\n            'subscriptionDetails.endDate'\n              | cxTranslate: { date: subscription.endAt | cxDate }\n          }}\n        </div>\n        <div *ngIf=\"subscription.withdrawalPeriodEndAt\">\n          {{\n            'subscriptionDetails.withdrawalEnd'\n              | cxTranslate\n                : { date: subscription.withdrawalPeriodEndAt | cxDate }\n          }}\n        </div>\n        <div *ngIf=\"subscription.orderCode\">\n          {{ 'subscriptionDetails.orderCode' | cxTranslate }}\n          <a\n            [routerLink]=\"\n              {\n                cxRoute: 'orderDetails',\n                params: { code: subscription.orderCode },\n              } | cxUrl\n            \"\n          >\n            {{ subscription.orderCode }}\n          </a>\n        </div>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"subscription-actions row\">\n    <span\n      class=\"col-xs-12 col-md-4 col-lg-3 action-button\"\n      *ngIf=\"subscription.isWithdrawalPossible\"\n    >\n      <a\n        [attr.aria-label]=\"\n          'subscriptionDetails.withdrawSubscription' | cxTranslate\n        \"\n        (click)=\"showSubscriptionActionsDialog('withdraw')\"\n        cxBtnLikeLink\n        class=\"btn btn-block btn-secondary\"\n      >\n        {{ 'subscriptionDetails.withdrawSubscription' | cxTranslate }}\n      </a>\n    </span>\n    <span\n      class=\"col-xs-12 col-md-4 col-lg-3 action-button\"\n      *ngIf=\"subscription.isCancellationPossible\"\n    >\n      <a\n        cxBtnLikeLink\n        class=\"btn btn-block btn-secondary\"\n        (click)=\"showSubscriptionActionsDialog('cancel')\"\n        [attr.aria-label]=\"\n          'subscriptionDetails.cancelSubscription' | cxTranslate\n        \"\n      >\n        {{ 'subscriptionDetails.cancelSubscription' | cxTranslate }}\n      </a>\n    </span>\n    <span\n      class=\"col-xs-12 col-md-4 col-lg-3 action-button\"\n      *ngIf=\"subscription.isExtensionPossible\"\n    >\n      <a\n        #extendSubscriptionBtn\n        [attr.aria-label]=\"\n          'subscriptionDetails.extendSubscription' | cxTranslate\n        \"\n        cxBtnLikeLink\n        class=\"btn btn-block btn-primary\"\n        (click)=\"showSubscriptionActionsDialog('extend')\"\n      >\n        {{ 'subscriptionDetails.extendSubscription' | cxTranslate }}\n      </a>\n    </span>\n    <span\n      class=\"col-xs-12 col-md-4 col-lg-3 action-button\"\n      *ngIf=\"subscription.isCancellationReversalPossible\"\n    >\n      <a\n        cxBtnLikeLink\n        class=\"btn btn-block btn-primary\"\n        [attr.aria-label]=\"'subscriptionDetails.reSubscribe' | cxTranslate\"\n        (click)=\"showSubscriptionActionsDialog('resubscribe')\"\n      >\n        {{ 'subscriptionDetails.reSubscribe' | cxTranslate }}\n      </a>\n    </span>\n  </div>\n</ng-container>\n<ng-template #loading>\n  <cx-spinner></cx-spinner>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionDetailsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionDetailsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionDetailsModule, imports: [CommonModule,
            I18nModule,
            UrlModule,
            RouterModule,
            SpinnerModule,
            IconModule,
            SubscriptionDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionDetailsModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    SubscriptionDetailsComponent: {
                        component: SubscriptionDetailsComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            UrlModule,
            RouterModule,
            SpinnerModule,
            IconModule,
            SubscriptionDetailsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionDetailsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        UrlModule,
                        RouterModule,
                        SpinnerModule,
                        IconModule,
                        SubscriptionDetailsComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                SubscriptionDetailsComponent: {
                                    component: SubscriptionDetailsComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionProductPriceComponent {
    constructor() {
        this.productService = inject(SubscriptionProductService);
        this.productDetail = toSignal(this.productService.getSubscriptionData(this.productCode));
        this.isCurrentProductSubscription = computed(() => {
            const product = this.productDetail();
            if (product !== null && product !== undefined) {
                return this.productService.isSubscription(product);
            }
            else {
                return false;
            }
        }, ...(ngDevMode ? [{ debugName: "isCurrentProductSubscription" }] : /* istanbul ignore next */ []));
        this.oneTimeCharges = computed(() => this.productDetail()?.sapPricePlan?.oneTimeCharges ?? [], ...(ngDevMode ? [{ debugName: "oneTimeCharges" }] : /* istanbul ignore next */ []));
        this.recurringCharges = computed(() => this.productDetail()?.sapPricePlan?.recurringCharges ?? [], ...(ngDevMode ? [{ debugName: "recurringCharges" }] : /* istanbul ignore next */ []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionProductPriceComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: SubscriptionProductPriceComponent, isStandalone: true, selector: "cx-subscription-product-price", inputs: { productCode: "productCode" }, ngImport: i0, template: "<ng-container *ngIf=\"productDetail() as product\">\n  <ng-container *ngIf=\"isCurrentProductSubscription()\">\n    <div>\n      <ng-container *ngIf=\"recurringCharges().length > 0\">\n        <ng-container *ngTemplateOutlet=\"showRecurringCharges\"></ng-container>\n      </ng-container>\n\n      <ng-container *ngIf=\"oneTimeCharges().length > 0\">\n        <ng-container *ngTemplateOutlet=\"showOneTimeCharges\"></ng-container>\n      </ng-container>\n\n      <ng-container *ngTemplateOutlet=\"showTerm\"></ng-container>\n\n      <cx-subscription-product-usage-charge\n        [product]=\"productDetail\"\n      ></cx-subscription-product-usage-charge>\n    </div>\n  </ng-container>\n\n  <ng-template #showOneTimeCharges>\n    <ng-container *ngFor=\"let charge of oneTimeCharges(); index as i\">\n      <div class=\"subscription-onetimecharge\">\n        *{{ charge.billingTime?.name }}: {{ charge.price?.formattedValue }}\n      </div>\n    </ng-container>\n  </ng-template>\n\n  <ng-template #showRecurringCharges>\n    <ng-container *ngFor=\"let charge of recurringCharges(); index as i\">\n      <div class=\"subscription-heading\">\n        {{ charge.price?.formattedValue }}\n        {{ product.sapSubscriptionTerm?.billingPlan?.billingTime?.name }}\n      </div>\n    </ng-container>\n  </ng-template>\n\n  <ng-template #showTerm>\n    <div *ngIf=\"product.sapSubscriptionTerm\" class=\"subscription-term\">\n      <div class=\"subscription-heading\">\n        {{ 'subscriptionProduct.subscriptionTerms' | cxTranslate }}\n      </div>\n      <ul>\n        <li>\n          {{\n            'subscriptionProduct.minimumTerm'\n              | cxTranslate\n                : {\n                    term:\n                      product.sapSubscriptionTerm?.minimumTerm?.value +\n                      ' ' +\n                      product.sapSubscriptionTerm?.minimumTerm?.frequency?.name,\n                  }\n          }}\n        </li>\n        <li>\n          {{\n            'subscriptionProduct.renewalTerm'\n              | cxTranslate\n                : {\n                    term:\n                      product.sapSubscriptionTerm?.renewalTerm?.value +\n                      ' ' +\n                      product.sapSubscriptionTerm?.renewalTerm?.frequency?.name,\n                  }\n          }}\n        </li>\n      </ul>\n    </div>\n  </ng-template>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: SubscriptionProductUsageChargeComponent, selector: "cx-subscription-product-usage-charge", inputs: ["product"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionProductPriceComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-subscription-product-price', imports: [
                        NgIf,
                        NgTemplateOutlet,
                        SubscriptionProductUsageChargeComponent,
                        NgFor,
                        TranslatePipe,
                    ], template: "<ng-container *ngIf=\"productDetail() as product\">\n  <ng-container *ngIf=\"isCurrentProductSubscription()\">\n    <div>\n      <ng-container *ngIf=\"recurringCharges().length > 0\">\n        <ng-container *ngTemplateOutlet=\"showRecurringCharges\"></ng-container>\n      </ng-container>\n\n      <ng-container *ngIf=\"oneTimeCharges().length > 0\">\n        <ng-container *ngTemplateOutlet=\"showOneTimeCharges\"></ng-container>\n      </ng-container>\n\n      <ng-container *ngTemplateOutlet=\"showTerm\"></ng-container>\n\n      <cx-subscription-product-usage-charge\n        [product]=\"productDetail\"\n      ></cx-subscription-product-usage-charge>\n    </div>\n  </ng-container>\n\n  <ng-template #showOneTimeCharges>\n    <ng-container *ngFor=\"let charge of oneTimeCharges(); index as i\">\n      <div class=\"subscription-onetimecharge\">\n        *{{ charge.billingTime?.name }}: {{ charge.price?.formattedValue }}\n      </div>\n    </ng-container>\n  </ng-template>\n\n  <ng-template #showRecurringCharges>\n    <ng-container *ngFor=\"let charge of recurringCharges(); index as i\">\n      <div class=\"subscription-heading\">\n        {{ charge.price?.formattedValue }}\n        {{ product.sapSubscriptionTerm?.billingPlan?.billingTime?.name }}\n      </div>\n    </ng-container>\n  </ng-template>\n\n  <ng-template #showTerm>\n    <div *ngIf=\"product.sapSubscriptionTerm\" class=\"subscription-term\">\n      <div class=\"subscription-heading\">\n        {{ 'subscriptionProduct.subscriptionTerms' | cxTranslate }}\n      </div>\n      <ul>\n        <li>\n          {{\n            'subscriptionProduct.minimumTerm'\n              | cxTranslate\n                : {\n                    term:\n                      product.sapSubscriptionTerm?.minimumTerm?.value +\n                      ' ' +\n                      product.sapSubscriptionTerm?.minimumTerm?.frequency?.name,\n                  }\n          }}\n        </li>\n        <li>\n          {{\n            'subscriptionProduct.renewalTerm'\n              | cxTranslate\n                : {\n                    term:\n                      product.sapSubscriptionTerm?.renewalTerm?.value +\n                      ' ' +\n                      product.sapSubscriptionTerm?.renewalTerm?.frequency?.name,\n                  }\n          }}\n        </li>\n      </ul>\n    </div>\n  </ng-template>\n</ng-container>\n" }]
        }], propDecorators: { productCode: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionProductPriceModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionProductPriceModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionProductPriceModule, imports: [CommonModule,
            I18nModule,
            SubscriptionProductUsageChargeModule,
            SubscriptionProductPriceComponent], exports: [SubscriptionProductPriceComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionProductPriceModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    SubscriptionProductPriceComponent: {
                        component: SubscriptionProductPriceComponent,
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            SubscriptionProductUsageChargeModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionProductPriceModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        SubscriptionProductUsageChargeModule,
                        SubscriptionProductPriceComponent,
                    ],
                    exports: [SubscriptionProductPriceComponent],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                SubscriptionProductPriceComponent: {
                                    component: SubscriptionProductPriceComponent,
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionListComponent {
    constructor() {
        this.subscriptionFacade = inject(SubscriptionFacade);
        this.PAGE_SIZE = 5;
        this.listParams = signal({
            sortCode: undefined,
            currentPage: 0,
        }, ...(ngDevMode ? [{ debugName: "listParams" }] : /* istanbul ignore next */ []));
        this.subscriptions$ = toObservable(this.listParams).pipe(switchMap((params) => this.subscriptionFacade.getSubscriptionList(this.PAGE_SIZE, params.currentPage, params.sortCode)));
        this.subscriptions = toSignal(this.subscriptions$);
    }
    changeSortCode(sortCode) {
        this.listParams.update(() => ({
            currentPage: 0,
            sortCode,
        }));
    }
    pageChange(page) {
        this.listParams.update((params) => ({
            ...params,
            currentPage: page,
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: SubscriptionListComponent, isStandalone: true, selector: "cx-subscription-list", ngImport: i0, template: "<ng-container *ngIf=\"subscriptions() as list; else loading\">\n  <h2 class=\"subscription-list-title\">\n    {{ 'subscriptionList.title' | cxTranslate }}\n    ({{ list.pagination?.totalResults || 0 }})\n  </h2>\n\n  <ng-container *ngIf=\"list.results?.length; else noSubscriptions\">\n    <div class=\"subscription-list-sort top\">\n      <label class=\"subscription-list-form-group form-group\">\n        <span>\n          {{ 'subscriptionList.sortSubtitle' | cxTranslate }}\n        </span>\n        <cx-sorting\n          [sortOptions]=\"list.sorts\"\n          (sortListEvent)=\"changeSortCode($event)\"\n          [selectedOption]=\"list.pagination?.sort\"\n          placeholder=\"{{ 'subscriptionList.sortSubtitle' | cxTranslate }}\"\n          [ariaLabel]=\"'subscriptionList.sortOrders' | cxTranslate\"\n          ariaControls=\"subscription-list-table\"\n        ></cx-sorting>\n      </label>\n    </div>\n\n    <ng-container *ngFor=\"let subscription of list.results\">\n      <div class=\"subscription\">\n        <div class=\"subscription-header\">\n          <div\n            class=\"subscription-name\"\n            *ngIf=\"subscription.name\"\n            [attr.aria-label]=\"'subscriptionList.product' | cxTranslate\"\n          >\n            {{ subscription.name }}\n          </div>\n          <div\n            class=\"subscription-status\"\n            *ngIf=\"subscription.status\"\n            [attr.aria-label]=\"'subscriptionList.status' | cxTranslate\"\n          >\n            {{ 'subscriptionList.status' | cxTranslate }}\n            <span [ngClass]=\"subscription.status\">{{\n              subscription.status\n            }}</span>\n          </div>\n        </div>\n        <div class=\"subscription-body\">\n          <div class=\"subscription-column-1\">\n            <div *ngIf=\"subscription.documentNumber\">\n              {{\n                'subscriptionList.id'\n                  | cxTranslate: { id: subscription.documentNumber }\n              }}\n            </div>\n            <div\n              *ngIf=\"\n                subscription?.pricePlan?.recurringCharges[0]?.price\n                  ?.formattedValue && subscription.billingTime\n              \"\n            >\n              {{\n                'subscriptionList.amount'\n                  | cxTranslate\n                    : {\n                        amount:\n                          subscription?.pricePlan?.recurringCharges[0]?.price\n                            ?.formattedValue,\n                        time: subscription.billingTime,\n                      }\n              }}\n            </div>\n            <div *ngIf=\"subscription.startAt\">\n              {{\n                'subscriptionList.startDate'\n                  | cxTranslate: { date: subscription.startAt | cxDate }\n              }}\n            </div>\n          </div>\n          <div class=\"subscription-column-2\">\n            <span>\n              <a\n                class=\"btn-link cx-action-link\"\n                [attr.aria-label]=\"'subscriptionList.manageService'\"\n                [routerLink]=\"\n                  {\n                    cxRoute: 'subscriptionDetails',\n                    params: { subscriptionId: subscription.id },\n                  } | cxUrl\n                \"\n              >\n                {{ 'subscriptionList.manageService' | cxTranslate }}\n              </a>\n            </span>\n          </div>\n        </div>\n      </div>\n    </ng-container>\n\n    <div class=\"subscription-list-sort bottom\">\n      <ng-container *ngIf=\"(list.pagination?.totalPages ?? 0) > 1\">\n        <cx-pagination\n          [pagination]=\"list.pagination\"\n          (viewPageEvent)=\"pageChange($event)\"\n        ></cx-pagination>\n      </ng-container>\n    </div>\n  </ng-container>\n</ng-container>\n\n<ng-template #noSubscriptions>\n  <div class=\"text-center\">\n    <h3>{{ 'subscriptionList.noSubscriptions' | cxTranslate }}</h3>\n  </div>\n</ng-template>\n\n<ng-template #loading>\n  <cx-spinner></cx-spinner>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: SortingComponent, selector: "cx-sorting", inputs: ["sortOptions", "ariaControls", "ariaLabel", "selectedOption", "placeholder", "sortLabels"], outputs: ["sortListEvent"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: PaginationComponent, selector: "cx-pagination", inputs: ["pageRoute", "queryParam", "defaultPage", "pagination", "paginationID"], outputs: ["viewPageEvent"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: CxDatePipe, name: "cxDate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-subscription-list', imports: [
                        NgIf,
                        NgClass,
                        SortingComponent,
                        NgFor,
                        RouterLink,
                        PaginationComponent,
                        SpinnerComponent,
                        TranslatePipe,
                        CxDatePipe,
                        UrlPipe,
                    ], template: "<ng-container *ngIf=\"subscriptions() as list; else loading\">\n  <h2 class=\"subscription-list-title\">\n    {{ 'subscriptionList.title' | cxTranslate }}\n    ({{ list.pagination?.totalResults || 0 }})\n  </h2>\n\n  <ng-container *ngIf=\"list.results?.length; else noSubscriptions\">\n    <div class=\"subscription-list-sort top\">\n      <label class=\"subscription-list-form-group form-group\">\n        <span>\n          {{ 'subscriptionList.sortSubtitle' | cxTranslate }}\n        </span>\n        <cx-sorting\n          [sortOptions]=\"list.sorts\"\n          (sortListEvent)=\"changeSortCode($event)\"\n          [selectedOption]=\"list.pagination?.sort\"\n          placeholder=\"{{ 'subscriptionList.sortSubtitle' | cxTranslate }}\"\n          [ariaLabel]=\"'subscriptionList.sortOrders' | cxTranslate\"\n          ariaControls=\"subscription-list-table\"\n        ></cx-sorting>\n      </label>\n    </div>\n\n    <ng-container *ngFor=\"let subscription of list.results\">\n      <div class=\"subscription\">\n        <div class=\"subscription-header\">\n          <div\n            class=\"subscription-name\"\n            *ngIf=\"subscription.name\"\n            [attr.aria-label]=\"'subscriptionList.product' | cxTranslate\"\n          >\n            {{ subscription.name }}\n          </div>\n          <div\n            class=\"subscription-status\"\n            *ngIf=\"subscription.status\"\n            [attr.aria-label]=\"'subscriptionList.status' | cxTranslate\"\n          >\n            {{ 'subscriptionList.status' | cxTranslate }}\n            <span [ngClass]=\"subscription.status\">{{\n              subscription.status\n            }}</span>\n          </div>\n        </div>\n        <div class=\"subscription-body\">\n          <div class=\"subscription-column-1\">\n            <div *ngIf=\"subscription.documentNumber\">\n              {{\n                'subscriptionList.id'\n                  | cxTranslate: { id: subscription.documentNumber }\n              }}\n            </div>\n            <div\n              *ngIf=\"\n                subscription?.pricePlan?.recurringCharges[0]?.price\n                  ?.formattedValue && subscription.billingTime\n              \"\n            >\n              {{\n                'subscriptionList.amount'\n                  | cxTranslate\n                    : {\n                        amount:\n                          subscription?.pricePlan?.recurringCharges[0]?.price\n                            ?.formattedValue,\n                        time: subscription.billingTime,\n                      }\n              }}\n            </div>\n            <div *ngIf=\"subscription.startAt\">\n              {{\n                'subscriptionList.startDate'\n                  | cxTranslate: { date: subscription.startAt | cxDate }\n              }}\n            </div>\n          </div>\n          <div class=\"subscription-column-2\">\n            <span>\n              <a\n                class=\"btn-link cx-action-link\"\n                [attr.aria-label]=\"'subscriptionList.manageService'\"\n                [routerLink]=\"\n                  {\n                    cxRoute: 'subscriptionDetails',\n                    params: { subscriptionId: subscription.id },\n                  } | cxUrl\n                \"\n              >\n                {{ 'subscriptionList.manageService' | cxTranslate }}\n              </a>\n            </span>\n          </div>\n        </div>\n      </div>\n    </ng-container>\n\n    <div class=\"subscription-list-sort bottom\">\n      <ng-container *ngIf=\"(list.pagination?.totalPages ?? 0) > 1\">\n        <cx-pagination\n          [pagination]=\"list.pagination\"\n          (viewPageEvent)=\"pageChange($event)\"\n        ></cx-pagination>\n      </ng-container>\n    </div>\n  </ng-container>\n</ng-container>\n\n<ng-template #noSubscriptions>\n  <div class=\"text-center\">\n    <h3>{{ 'subscriptionList.noSubscriptions' | cxTranslate }}</h3>\n  </div>\n</ng-template>\n\n<ng-template #loading>\n  <cx-spinner></cx-spinner>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionListModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionListModule, imports: [I18nModule,
            UrlModule,
            ListNavigationModule,
            RouterModule,
            SpinnerModule,
            CommonModule,
            SubscriptionListComponent], exports: [SubscriptionListComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionListModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    SubscriptionHistoryComponent: {
                        component: SubscriptionListComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
        ], imports: [I18nModule,
            UrlModule,
            ListNavigationModule,
            RouterModule,
            SpinnerModule,
            CommonModule,
            SubscriptionListComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        I18nModule,
                        UrlModule,
                        ListNavigationModule,
                        RouterModule,
                        SpinnerModule,
                        CommonModule,
                        SubscriptionListComponent,
                    ],
                    exports: [SubscriptionListComponent],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                SubscriptionHistoryComponent: {
                                    component: SubscriptionListComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionActionsModalComponentService {
    constructor() {
        this.globalMessageService = inject(GlobalMessageService);
        this.eventService = inject(EventService);
    }
    handleError(onDialogClose, errorMessageKey = 'subscriptionActions.unknownError') {
        return catchError(() => {
            if (onDialogClose) {
                onDialogClose('error');
            }
            this.globalMessageService.add({ key: errorMessageKey }, GlobalMessageType.MSG_TYPE_ERROR);
            return EMPTY;
        });
    }
    handleSuccess(messageKey, onDialogClose, dispatchReloadEvent = true) {
        return {
            next: () => {
                if (onDialogClose) {
                    onDialogClose('Success');
                }
                if (dispatchReloadEvent) {
                    this.eventService.dispatch({}, GetSubscriptionByCodeReloadEvent);
                }
                this.globalMessageService.add({ key: messageKey }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
            },
        };
    }
    onError() {
        this.globalMessageService.add({ key: 'subscriptionActions.unknownError' }, GlobalMessageType.MSG_TYPE_ERROR);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsModalComponentService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsModalComponentService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsModalComponentService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionActionsModalComponent {
    constructor() {
        this.actionsFacade = inject(SubscriptionActionsFacade);
        this.launchDialogService = inject(LaunchDialogService);
        this.destroyRef = inject(DestroyRef);
        this.actionHandler = inject(SubscriptionActionsModalComponentService);
        this.subscriptionDetailSignal = toSignal(this.launchDialogService.data$);
        this.isUnlimitedDurationSelected = false;
        this.isExtendSubscriptionBtnClicked = signal(false, ...(ngDevMode ? [{ debugName: "isExtendSubscriptionBtnClicked" }] : /* istanbul ignore next */ []));
        this.isExtensionEffectiveDateAvailable = signal(false, ...(ngDevMode ? [{ debugName: "isExtensionEffectiveDateAvailable" }] : /* istanbul ignore next */ []));
        this.extensionEffectiveDate = signal(undefined, ...(ngDevMode ? [{ debugName: "extensionEffectiveDate" }] : /* istanbul ignore next */ []));
        this.subscriptionContractFrequency = this.subscriptionDetailSignal()
            ?.contractFrequency;
        this.extendFrequencyMaxOptions = defaultExtendDropdownOptions;
        this.UNLIMITED_DURATION = 'Unlimited';
        this.mode = computed(() => this.subscriptionDetailSignal()?.mode ?? 'cancel', ...(ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []));
        this.subscriptionCode = computed(() => this.subscriptionDetailSignal()?.code ?? '', ...(ngDevMode ? [{ debugName: "subscriptionCode" }] : /* istanbul ignore next */ []));
        this.cancelData = signal(undefined, ...(ngDevMode ? [{ debugName: "cancelData" }] : /* istanbul ignore next */ []));
        this.extensionData = signal(undefined, ...(ngDevMode ? [{ debugName: "extensionData" }] : /* istanbul ignore next */ []));
        this.iconTypes = ICON_TYPE;
        this.focusConfig = {
            trap: false,
            block: false,
            autofocus: 'button',
            focusOnEscape: true,
        };
        this.registerSubscriptionCancellationEffect();
        this.initExtendDurationOptions();
    }
    initExtendDurationOptions() {
        const frequency = this.subscriptionContractFrequency;
        const maxOptions = (this.extendFrequencyMaxOptions[frequency] ?? 0) + 1; // +1 to include the unlimited duration option
        this.extendDurationOptions = Array.from({ length: maxOptions }, (_, i) => i + 1 === maxOptions
            ? this.UNLIMITED_DURATION
            : (i + 1).toString() + ' ' + this.subscriptionContractFrequency);
    }
    registerSubscriptionCancellationEffect() {
        effect(() => {
            const mode = this.mode();
            const code = this.subscriptionCode();
            if (mode === 'cancel' && code) {
                this.actionsFacade
                    .getEffectiveCancellationDate(code)
                    .pipe(takeUntilDestroyed(this.destroyRef), catchError(() => {
                    this.actionHandler.onError();
                    return of(undefined);
                }))
                    .subscribe((data) => {
                    this.cancelData.set(data);
                });
            }
        });
    }
    getExtensionEffectiveDate() {
        this.isExtendSubscriptionBtnClicked.set(true);
        this.actionsFacade
            .getExtensionEffectiveDate(this.extendDuration, this.isUnlimitedDurationSelected, this.subscriptionCode())
            .pipe(takeUntilDestroyed(this.destroyRef), catchError(() => {
            this.actionHandler.onError();
            return of(undefined);
        }))
            .subscribe((date) => {
            this.extensionEffectiveDate.set(date?.subscriptionEndAt);
            this.isExtensionEffectiveDateAvailable.set(true);
        });
    }
    onConfirm() {
        const mode = this.mode();
        const code = this.subscriptionCode();
        const detail = this.subscriptionDetailSignal();
        const cancelDataVal = this.cancelData();
        if (!code || !detail) {
            this.actionHandler.onError();
            return;
        }
        const handlers = {
            cancel: () => {
                if (!cancelDataVal?.subscriptionEndAt) {
                    this.actionHandler.onError();
                    return;
                }
                const payload = {
                    subscriptionEndAt: cancelDataVal.subscriptionEndAt,
                };
                this.actionsFacade
                    .cancelSubscription(payload, code)
                    .pipe(takeUntilDestroyed(this.destroyRef), this.actionHandler.handleError(() => this.onDialogClose('error')))
                    .subscribe(this.actionHandler.handleSuccess('subscriptionActions.cancelSuccess', () => this.onDialogClose('Success')));
            },
            withdraw: () => {
                this.actionsFacade
                    .withdrawSubscription({ subscriptionId: detail.id }, code)
                    .pipe(takeUntilDestroyed(this.destroyRef), this.actionHandler.handleError(() => this.onDialogClose('error')))
                    .subscribe(this.actionHandler.handleSuccess('subscriptionActions.withdrawSuccess', () => this.onDialogClose('Success')));
            },
            resubscribe: () => {
                this.actionsFacade
                    .reverseCancellation(code)
                    .pipe(takeUntilDestroyed(this.destroyRef), this.actionHandler.handleError(() => this.onDialogClose('error')))
                    .subscribe(this.actionHandler.handleSuccess('subscriptionActions.reverseCancellationSuccess', () => this.onDialogClose('Success')));
            },
            extend: () => {
                const confirmedExtendDuration = this.isUnlimitedDurationSelected
                    ? 0
                    : this.extendDuration;
                this.actionsFacade
                    .extendSubscription(confirmedExtendDuration, this.isUnlimitedDurationSelected, code)
                    .pipe(takeUntilDestroyed(this.destroyRef), this.actionHandler.handleError(() => this.onDialogClose('error')))
                    .subscribe(this.actionHandler.handleSuccess('subscriptionActions.extendedSuccessfully', () => {
                    this.isExtendSubscriptionBtnClicked.set(true);
                    this.onDialogClose('subscriptionActions.extendedSuccessfully');
                }));
            },
        };
        handlers[mode]?.();
    }
    onExtendActionDurationChange(durationSelected) {
        const duration = durationSelected.split(' ')[0];
        if (duration === this.UNLIMITED_DURATION) {
            this.isUnlimitedDurationSelected = true;
        }
        else {
            this.isUnlimitedDurationSelected = false;
            this.extendDuration = parseInt(duration, 10);
        }
    }
    onDialogClose(reason) {
        this.launchDialogService.closeDialog(reason);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsModalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: SubscriptionActionsModalComponent, isStandalone: true, selector: "cx-subscription-actions-modal", ngImport: i0, template: "<div\n  #modalDialog\n  class=\"modal-dialog modal-dialog-centered\"\n  [ngClass]=\"{\n    'extend-subscription-dialog': mode() === 'extend',\n    'subscription-actions-dialog': mode() !== 'extend',\n  }\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"onDialogClose('Escape pressed')\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <div class=\"cx-modal-content\" *ngIf=\"mode() !== 'extend'\">\n    <!-- Modal Header -->\n    <div class=\"cx-dialog-header modal-header cx-dialog-header-cancel\">\n      <div id=\"dialogTitle\" class=\"cx-dialog-title modal-title\">\n        <h4>\n          <strong>\n            {{\n              'subscriptionActions.askConfirm'\n                | cxTranslate\n                  : {\n                      action:\n                        mode() === 'withdraw'\n                          ? 'Withdraw'\n                          : mode() === 'resubscribe'\n                            ? 'Resubscribe'\n                            : 'Cancel',\n                    }\n            }}\n          </strong>\n        </h4>\n      </div>\n      <button\n        type=\"button\"\n        class=\"close pt-0\"\n        attr.aria-label=\"{{ 'subscriptionActions.closeModal' | cxTranslate }}\"\n        (click)=\"onDialogClose('Cross click')\"\n      >\n        <span\n          ><small><cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon></small\n        ></span>\n      </button>\n    </div>\n\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\">\n      <div class=\"row\">\n        <div class=\"col-md-12\">\n          <!-- CANCEL MODE: show cancelData and spinner -->\n          <ng-container *ngIf=\"mode() === 'cancel'\">\n            <ng-container *ngIf=\"cancelData(); else loading\">\n              <p *ngIf=\"cancelData()?.subscriptionEndAt\">\n                {{\n                  'subscriptionActions.loseSubscription'\n                    | cxTranslate\n                      : { date: (cancelData()?.subscriptionEndAt | cxDate) }\n                }}\n              </p>\n              <p>\n                {{ 'subscriptionActions.changeMind' | cxTranslate }}\n              </p>\n            </ng-container>\n          </ng-container>\n\n          <!-- WITHDRAW MODE: simpler message -->\n          <ng-container *ngIf=\"mode() === 'withdraw'\">\n            <p>{{ 'subscriptionActions.withdrawConfirm' | cxTranslate }}</p>\n          </ng-container>\n\n          <ng-container *ngIf=\"mode() === 'resubscribe'\">\n            <p>{{ 'subscriptionActions.resubscribeConfirm' | cxTranslate }}</p>\n          </ng-container>\n          <!-- Common footer for both -->\n          <div class=\"row justify-content-end mt-3\">\n            <div class=\"cx-quote col-sm-12 col-md-6 p-1\">\n              <button\n                type=\"button\"\n                class=\"btn btn-block btn-secondary\"\n                (click)=\"onDialogClose('Cancel click')\"\n              >\n                {{ 'subscriptionActions.cancel' | cxTranslate }}\n              </button>\n            </div>\n            <div class=\"cx-quote col-sm-12 col-md-6 p-1\">\n              <button\n                type=\"submit\"\n                class=\"btn btn-primary btn-block\"\n                (click)=\"onConfirm()\"\n              >\n                {{ 'subscriptionActions.confirm' | cxTranslate }}\n              </button>\n            </div>\n          </div>\n        </div>\n\n        <!-- Loading spinner only if mode is cancel -->\n        <ng-template #loading>\n          <div class=\"d-flex justify-content-center p-4\">\n            <cx-spinner></cx-spinner>\n          </div>\n        </ng-template>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"modal-content\" *ngIf=\"mode() === 'extend'\">\n    <!-- Modal Header -->\n\n    <div class=\"modal-header\">\n      <h3\n        id=\"dialogTitle\"\n        class=\"title modal-title\"\n        *ngIf=\"!isExtendSubscriptionBtnClicked()\"\n      >\n        {{ 'subscriptionDetails.extendSubscription' | cxTranslate }}\n      </h3>\n      <h3\n        id=\"dialogTitle\"\n        class=\"title modal-title\"\n        *ngIf=\"isExtendSubscriptionBtnClicked()\"\n      >\n        {{ 'subscriptionActions.confirmExtensionTitle' | cxTranslate }}\n      </h3>\n      <button\n        type=\"button\"\n        class=\"close\"\n        title=\"{{ 'common.close' | cxTranslate }}\"\n        [attr.aria-label]=\"'common.close' | cxTranslate\"\n        (click)=\"onDialogClose('close-dialog')\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n        </span>\n      </button>\n    </div>\n\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\" ngForm>\n      <div class=\"cx-dialog-info\">\n        <p\n          *ngIf=\"!isExtendSubscriptionBtnClicked()\"\n          [innerHTML]=\"'subscriptionActions.disclaimer' | cxTranslate\"\n        ></p>\n        <p\n          *ngIf=\"isExtendSubscriptionBtnClicked()\"\n          [innerHTML]=\"\n            'subscriptionActions.disclaimerWithExtensionEndDate'\n              | cxTranslate: { endDate: extensionEffectiveDate() | cxDate }\n          \"\n        ></p>\n        <p *ngIf=\"isExtendSubscriptionBtnClicked()\">\n          {{ 'subscriptionActions.noActionMessage' | cxTranslate }}\n        </p>\n      </div>\n\n      <label class=\"form-check extend-duration-dropdown-label\">\n        <span class=\"form-check-label extend-duration-label\">\n          {{ 'subscriptionActions.durationInputLabel' | cxTranslate }}\n          <cx-form-required-asterisks />\n        </span>\n        <ng-select\n          name=\"extendDuration\"\n          [clearable]=\"false\"\n          [searchable]=\"false\"\n          id=\"extendDurationDropdown\"\n          [items]=\"extendDurationOptions\"\n          [readonly]=\"isExtendSubscriptionBtnClicked()\"\n          [placeholder]=\"\n            'subscriptionActions.durationInputPlaceholder'\n              | cxTranslate: { frequency: subscriptionContractFrequency }\n          \"\n          (change)=\"onExtendActionDurationChange($event)\"\n          ariaLabelDropdown=\"{{\n            'common.ngSelectDropdownOptionsList' | cxTranslate\n          }}\"\n        >\n          <ng-template ng-option-tmp ng-label-tmp let-item=\"item\">\n            {{ item }}\n          </ng-template>\n        </ng-select>\n      </label>\n    </div>\n\n    <div class=\"cx-modal-footer extend-subscription-dialog-footer\">\n      <button\n        (click)=\"onDialogClose('Cross click')\"\n        class=\"btn btn-secondary cx-dialog-buttons\"\n      >\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n      <button\n        class=\"btn btn-primary dialog-buttons\"\n        [disabled]=\"!extendDuration && !isUnlimitedDurationSelected\"\n        *ngIf=\"!isExtendSubscriptionBtnClicked()\"\n        (click)=\"getExtensionEffectiveDate()\"\n      >\n        {{ 'subscriptionActions.extend' | cxTranslate }}\n      </button>\n      <button\n        class=\"btn btn-primary dialog-buttons\"\n        (click)=\"onConfirm()\"\n        *ngIf=\"\n          isExtendSubscriptionBtnClicked() &&\n          isExtensionEffectiveDateAvailable()\n        \"\n      >\n        {{ 'subscriptionActions.confirm' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: CardModule }, { kind: "ngmodule", type: RouterModule }, { kind: "ngmodule", type: I18nModule }, { kind: "ngmodule", type: UrlModule }, { kind: "ngmodule", type: IconModule }, { kind: "component", type: i2.IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "ngmodule", type: KeyboardFocusModule }, { kind: "directive", type: i2.FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "ngmodule", type: SpinnerModule }, { kind: "component", type: i2.SpinnerComponent, selector: "cx-spinner" }, { kind: "ngmodule", type: NgSelectModule }, { kind: "component", type: i3.NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "directive", type: i3.NgOptionTemplateDirective, selector: "[ng-option-tmp]" }, { kind: "directive", type: i3.NgLabelTemplateDirective, selector: "[ng-label-tmp]" }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "pipe", type: i4.TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: i4.CxDatePipe, name: "cxDate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-subscription-actions-modal', standalone: true, imports: [
                        CommonModule,
                        CardModule,
                        RouterModule,
                        I18nModule,
                        UrlModule,
                        IconModule,
                        KeyboardFocusModule,
                        SpinnerModule,
                        NgSelectModule,
                        FormRequiredAsterisksComponent,
                        NgIf,
                    ], template: "<div\n  #modalDialog\n  class=\"modal-dialog modal-dialog-centered\"\n  [ngClass]=\"{\n    'extend-subscription-dialog': mode() === 'extend',\n    'subscription-actions-dialog': mode() !== 'extend',\n  }\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"onDialogClose('Escape pressed')\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <div class=\"cx-modal-content\" *ngIf=\"mode() !== 'extend'\">\n    <!-- Modal Header -->\n    <div class=\"cx-dialog-header modal-header cx-dialog-header-cancel\">\n      <div id=\"dialogTitle\" class=\"cx-dialog-title modal-title\">\n        <h4>\n          <strong>\n            {{\n              'subscriptionActions.askConfirm'\n                | cxTranslate\n                  : {\n                      action:\n                        mode() === 'withdraw'\n                          ? 'Withdraw'\n                          : mode() === 'resubscribe'\n                            ? 'Resubscribe'\n                            : 'Cancel',\n                    }\n            }}\n          </strong>\n        </h4>\n      </div>\n      <button\n        type=\"button\"\n        class=\"close pt-0\"\n        attr.aria-label=\"{{ 'subscriptionActions.closeModal' | cxTranslate }}\"\n        (click)=\"onDialogClose('Cross click')\"\n      >\n        <span\n          ><small><cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon></small\n        ></span>\n      </button>\n    </div>\n\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\">\n      <div class=\"row\">\n        <div class=\"col-md-12\">\n          <!-- CANCEL MODE: show cancelData and spinner -->\n          <ng-container *ngIf=\"mode() === 'cancel'\">\n            <ng-container *ngIf=\"cancelData(); else loading\">\n              <p *ngIf=\"cancelData()?.subscriptionEndAt\">\n                {{\n                  'subscriptionActions.loseSubscription'\n                    | cxTranslate\n                      : { date: (cancelData()?.subscriptionEndAt | cxDate) }\n                }}\n              </p>\n              <p>\n                {{ 'subscriptionActions.changeMind' | cxTranslate }}\n              </p>\n            </ng-container>\n          </ng-container>\n\n          <!-- WITHDRAW MODE: simpler message -->\n          <ng-container *ngIf=\"mode() === 'withdraw'\">\n            <p>{{ 'subscriptionActions.withdrawConfirm' | cxTranslate }}</p>\n          </ng-container>\n\n          <ng-container *ngIf=\"mode() === 'resubscribe'\">\n            <p>{{ 'subscriptionActions.resubscribeConfirm' | cxTranslate }}</p>\n          </ng-container>\n          <!-- Common footer for both -->\n          <div class=\"row justify-content-end mt-3\">\n            <div class=\"cx-quote col-sm-12 col-md-6 p-1\">\n              <button\n                type=\"button\"\n                class=\"btn btn-block btn-secondary\"\n                (click)=\"onDialogClose('Cancel click')\"\n              >\n                {{ 'subscriptionActions.cancel' | cxTranslate }}\n              </button>\n            </div>\n            <div class=\"cx-quote col-sm-12 col-md-6 p-1\">\n              <button\n                type=\"submit\"\n                class=\"btn btn-primary btn-block\"\n                (click)=\"onConfirm()\"\n              >\n                {{ 'subscriptionActions.confirm' | cxTranslate }}\n              </button>\n            </div>\n          </div>\n        </div>\n\n        <!-- Loading spinner only if mode is cancel -->\n        <ng-template #loading>\n          <div class=\"d-flex justify-content-center p-4\">\n            <cx-spinner></cx-spinner>\n          </div>\n        </ng-template>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"modal-content\" *ngIf=\"mode() === 'extend'\">\n    <!-- Modal Header -->\n\n    <div class=\"modal-header\">\n      <h3\n        id=\"dialogTitle\"\n        class=\"title modal-title\"\n        *ngIf=\"!isExtendSubscriptionBtnClicked()\"\n      >\n        {{ 'subscriptionDetails.extendSubscription' | cxTranslate }}\n      </h3>\n      <h3\n        id=\"dialogTitle\"\n        class=\"title modal-title\"\n        *ngIf=\"isExtendSubscriptionBtnClicked()\"\n      >\n        {{ 'subscriptionActions.confirmExtensionTitle' | cxTranslate }}\n      </h3>\n      <button\n        type=\"button\"\n        class=\"close\"\n        title=\"{{ 'common.close' | cxTranslate }}\"\n        [attr.aria-label]=\"'common.close' | cxTranslate\"\n        (click)=\"onDialogClose('close-dialog')\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n        </span>\n      </button>\n    </div>\n\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\" ngForm>\n      <div class=\"cx-dialog-info\">\n        <p\n          *ngIf=\"!isExtendSubscriptionBtnClicked()\"\n          [innerHTML]=\"'subscriptionActions.disclaimer' | cxTranslate\"\n        ></p>\n        <p\n          *ngIf=\"isExtendSubscriptionBtnClicked()\"\n          [innerHTML]=\"\n            'subscriptionActions.disclaimerWithExtensionEndDate'\n              | cxTranslate: { endDate: extensionEffectiveDate() | cxDate }\n          \"\n        ></p>\n        <p *ngIf=\"isExtendSubscriptionBtnClicked()\">\n          {{ 'subscriptionActions.noActionMessage' | cxTranslate }}\n        </p>\n      </div>\n\n      <label class=\"form-check extend-duration-dropdown-label\">\n        <span class=\"form-check-label extend-duration-label\">\n          {{ 'subscriptionActions.durationInputLabel' | cxTranslate }}\n          <cx-form-required-asterisks />\n        </span>\n        <ng-select\n          name=\"extendDuration\"\n          [clearable]=\"false\"\n          [searchable]=\"false\"\n          id=\"extendDurationDropdown\"\n          [items]=\"extendDurationOptions\"\n          [readonly]=\"isExtendSubscriptionBtnClicked()\"\n          [placeholder]=\"\n            'subscriptionActions.durationInputPlaceholder'\n              | cxTranslate: { frequency: subscriptionContractFrequency }\n          \"\n          (change)=\"onExtendActionDurationChange($event)\"\n          ariaLabelDropdown=\"{{\n            'common.ngSelectDropdownOptionsList' | cxTranslate\n          }}\"\n        >\n          <ng-template ng-option-tmp ng-label-tmp let-item=\"item\">\n            {{ item }}\n          </ng-template>\n        </ng-select>\n      </label>\n    </div>\n\n    <div class=\"cx-modal-footer extend-subscription-dialog-footer\">\n      <button\n        (click)=\"onDialogClose('Cross click')\"\n        class=\"btn btn-secondary cx-dialog-buttons\"\n      >\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n      <button\n        class=\"btn btn-primary dialog-buttons\"\n        [disabled]=\"!extendDuration && !isUnlimitedDurationSelected\"\n        *ngIf=\"!isExtendSubscriptionBtnClicked()\"\n        (click)=\"getExtensionEffectiveDate()\"\n      >\n        {{ 'subscriptionActions.extend' | cxTranslate }}\n      </button>\n      <button\n        class=\"btn btn-primary dialog-buttons\"\n        (click)=\"onConfirm()\"\n        *ngIf=\"\n          isExtendSubscriptionBtnClicked() &&\n          isExtensionEffectiveDateAvailable()\n        \"\n      >\n        {{ 'subscriptionActions.confirm' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [] });

/*
 * Copyright (C) 2025 SAP SE or an SAP affiliate company. All rights reserved.
 * SPDX-FileCopyrightText: 2025 SAP Spartacus team <spartacus-team@sap.com>
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const subscriptionActionsPopupConfig = {
    launch: {
        SUBSCRIPTION_ACTION_CONFIRMATION: {
            inlineRoot: true,
            component: SubscriptionActionsModalComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionActionsModalModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsModalModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsModalModule, imports: [SubscriptionActionsModalComponent], exports: [SubscriptionActionsModalComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsModalModule, providers: [provideDefaultConfig(subscriptionActionsPopupConfig)], imports: [SubscriptionActionsModalComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsModalModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [SubscriptionActionsModalComponent],
                    exports: [SubscriptionActionsModalComponent],
                    providers: [provideDefaultConfig(subscriptionActionsPopupConfig)],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2025 SAP Spartacus team <spartacus-team@sap.com>
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionBillingListComponent {
    constructor() {
        this.subscriptionBillsFacade = inject(SubscriptionBillingFacade);
        this.datePickerService = inject(DatePickerService);
        this.launchDialogService = inject(LaunchDialogService);
        this.eventService = inject(EventService);
        this.cxDatePipe = inject(CxDatePipe);
        this.minDate = null;
        this.maxDate = null;
        this.DATE_FILTER_PARAM = 'startAt:%s:endAt:%s';
        this.PAGE_SIZE = 5;
        this.listParams = {
            sortCode: undefined,
            pageNumber: 0,
            dateFilter: undefined,
        };
        this.iconTypes = ICON_TYPE;
        this.billingList$ = this.subscriptionBillsFacade.getSubscriptionBillsList(this.PAGE_SIZE);
        this.billsDateFilterForm = new FormGroup({
            from: new FormControl(''),
            to: new FormControl(''),
        });
        this.billsDateFilterForm.addValidators(CustomFormValidators.dateRange('from', 'to', (value) => this.datePickerService.getDate(value)));
        this.launchDialogService.dialogClose.subscribe((data) => {
            if (typeof data === 'object' && data !== null) {
                this.minDate = data.minDate;
                this.maxDate = data.maxDate;
                this.onDateRangeSelection();
            }
        });
    }
    onSortCodeChange(sortCode) {
        this.listParams = {
            ...this.listParams,
            sortCode,
            pageNumber: 0,
        };
        this.getSubscriptionBillsList();
    }
    onPageChange(pageNumber) {
        this.listParams = {
            ...this.listParams,
            pageNumber: Number(pageNumber),
        };
        this.getSubscriptionBillsList();
    }
    /**
     * @deprecated - Selection of date range and relevant methods have been moved to DateRangeModalComponent
     */
    onFilterDateChange() {
        this.minDate = this.billsDateFilterForm.controls.from.value;
        this.maxDate = this.billsDateFilterForm.controls.to.value;
        this.billsDateFilterForm.controls['from'].updateValueAndValidity();
        this.billsDateFilterForm.controls['to'].updateValueAndValidity();
    }
    getSubscriptionBillsList() {
        const { pageNumber, sortCode, dateFilter } = this.listParams;
        this.billingList$ = this.subscriptionBillsFacade.getSubscriptionBillsList(this.PAGE_SIZE, pageNumber, sortCode, dateFilter);
    }
    /**
     * @deprecated - Selection of date range and relevant methods have been moved to DateRangeModalComponent
     */
    onResetFilterDate() {
        if (this.minDate || this.maxDate) {
            this.billsDateFilterForm.reset();
            this.minDate = null;
            this.maxDate = null;
            this.listParams = {
                ...this.listParams,
                dateFilter: undefined,
                pageNumber: 0,
            };
            this.getSubscriptionBillsList();
        }
    }
    /**
     * @deprecated - Selection of date range and relevant methods have been moved to DateRangeModalComponent
     */
    onDateFilterSubmit() {
        if (this.minDate && this.maxDate && this.billsDateFilterForm.valid) {
            const dateFilterParam = this.buildDateFilter(this.minDate, this.maxDate);
            this.listParams = {
                ...this.listParams,
                dateFilter: dateFilterParam,
                pageNumber: 0,
            };
            this.getSubscriptionBillsList();
        }
    }
    buildDateFilter(startDate, endDate) {
        return this.DATE_FILTER_PARAM.replace('%s', startDate).replace('%s', endDate);
    }
    onResetDateRange() {
        if (this.minDate || this.maxDate) {
            this.minDate = null;
            this.maxDate = null;
            this.listParams = {
                ...this.listParams,
                dateFilter: undefined,
                pageNumber: 0,
            };
            this.getSubscriptionBillsList();
        }
    }
    onDateRangeSelection() {
        if (this.minDate && this.maxDate) {
            const dateFilterParam = this.buildDateFilter(this.minDate, this.maxDate);
            this.listParams = {
                ...this.listParams,
                dateFilter: dateFilterParam,
                pageNumber: 0,
            };
        }
        else {
            this.listParams = {
                ...this.listParams,
                dateFilter: undefined,
                pageNumber: 0,
            };
        }
        this.eventService.dispatch({}, GetSubscriptionBillsListReloadEvent);
        this.getSubscriptionBillsList();
    }
    getDateRangeFieldValue() {
        if (this.minDate && this.maxDate) {
            const fromDate = this.cxDatePipe.transform(this.minDate);
            const toDate = this.cxDatePipe.transform(this.maxDate);
            return `${fromDate} - ${toDate}`;
        }
        else {
            return '';
        }
    }
    launchDateRangeModal() {
        this.launchDialogService.openDialogAndSubscribe(LAUNCH_CALLER.DATE_RANGE_MODAL, undefined, {
            minDate: this.minDate,
            maxDate: this.maxDate,
        });
    }
    getTrailingSubscriptionItems(result) {
        let billItems = '';
        result.items?.slice(1).forEach((bill, index) => {
            billItems = billItems + bill.productName;
            if (result?.items?.length && index !== result.items.length - 2) {
                billItems = billItems + ', ';
            }
        });
        return billItems;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: SubscriptionBillingListComponent, isStandalone: true, selector: "cx-billing-list", providers: [CxDatePipe], ngImport: i0, template: "<ng-container *ngIf=\"billingList$ | async as billingList; else loading\">\n  <div class=\"billing-list-title-section\">\n    <h3>{{ 'subscriptionBillsList.title' | cxTranslate }}</h3>\n  </div>\n\n  <div class=\"billing-list-filter-section\">\n    <div class=\"date-filters-wrapper\">\n      <div class=\"date-filters\">\n        <div class=\"dateRangeInputContainer\" (click)=\"launchDateRangeModal()\">\n          <span class=\"sort-label label-text\">\n            {{ 'subscriptionBillsList.dateRangeLabel' | cxTranslate }}\n          </span>\n          <input\n            type=\"text\"\n            disabled\n            class=\"form-control\"\n            [placeholder]=\"\n              'subscriptionBillsList.dateRangeInputPlaceholder' | cxTranslate\n            \"\n            [value]=\"getDateRangeFieldValue()\"\n          />\n          <button class=\"btn btn-tertiary btn-calendar\">\n            <cx-icon class=\"fa fa-calendar\"></cx-icon>\n          </button>\n        </div>\n        <button\n          class=\"btn btn-tertiary btn-clear\"\n          *ngIf=\"getDateRangeFieldValue()\"\n          (click)=\"onResetDateRange()\"\n        >\n          {{ 'subscriptionBillsList.clear' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n\n    <div class=\"billing-list-sorting-bar\">\n      <span class=\"sort-label label-text\">\n        {{ 'subscriptionBillsList.sortLabel' | cxTranslate }}\n      </span>\n      <cx-sorting\n        [sortOptions]=\"billingList.sorts\"\n        (sortListEvent)=\"onSortCodeChange($event)\"\n        [selectedOption]=\"billingList.pagination?.sort\"\n        placeholder=\"{{ 'subscriptionBillsList.sortLabel' | cxTranslate }}\"\n        [ariaLabel]=\"'subscriptionBillsList.sortOrders'\"\n      ></cx-sorting>\n    </div>\n  </div>\n  <ng-container *ngIf=\"billingList.results?.length > 0; else noBills\">\n    <!-- table starts -->\n    <table id=\"billing-list-table\" class=\"table cx-billing-list-table\">\n      <thead class=\"cx-billing-list-thead\">\n        <tr scope=\"row\">\n          <th scope=\"col\">\n            <div class=\"cx-billing-list-table-header\">\n              {{ 'subscriptionBillsList.tableHeaderColId' | cxTranslate }}\n            </div>\n          </th>\n          <th scope=\"col\">\n            <div class=\"cx-billing-list-table-header\">\n              {{ 'subscriptionBillsList.tableHeaderColDate' | cxTranslate }}\n            </div>\n          </th>\n          <th scope=\"col\">\n            <div class=\"cx-billing-list-table-header\">\n              {{\n                'subscriptionBillsList.tableHeaderColSubscriptions'\n                  | cxTranslate\n              }}\n            </div>\n          </th>\n          <th scope=\"col\">\n            <div class=\"cx-billing-list-table-header\">\n              {{ 'subscriptionBillsList.tableHeaderColTotal' | cxTranslate }}\n            </div>\n          </th>\n          <th scope=\"col\">\n            <div class=\"cx-billing-list-table-header\"></div>\n          </th>\n        </tr>\n      </thead>\n      <tbody>\n        <tr *ngFor=\"let billing of billingList.results\">\n          <td>\n            <div class=\"cx-billing-list-table-col\">\n              {{ billing.documentNumber }}\n            </div>\n          </td>\n          <td>\n            <div class=\"cx-billing-list-table-col\">\n              {{ billing.billAt | cxDate }}\n            </div>\n          </td>\n          <td>\n            <div class=\"cx-billing-list-table-col\">\n              {{ billing.items?.[0]?.productName }}\n              <ng-container *ngIf=\"billing.items.length > 1\">\n                ...\n                <a\n                  [title]=\"getTrailingSubscriptionItems(billing)\"\n                  [routerLink]=\"\n                    {\n                      cxRoute: 'subscriptionBillingDetails',\n                      params: { subscriptionBillId: billing.documentNumber },\n                    } | cxUrl\n                  \"\n                  >{{\n                    'subscriptionBillsList.descriptionSuffix'\n                      | cxTranslate: { numberOfItems: billing.items.length - 1 }\n                  }}\n                </a>\n              </ng-container>\n            </div>\n          </td>\n          <td>\n            <div class=\"cx-billing-list-table-col\">\n              {{ billing.netAmount.replace('USD', '$') }}\n            </div>\n          </td>\n          <td>\n            <div class=\"cx-billing-list-table-col\">\n              <a\n                [routerLink]=\"\n                  {\n                    cxRoute: 'subscriptionBillingDetails',\n                    params: { subscriptionBillId: billing.documentNumber },\n                  } | cxUrl\n                \"\n              >\n                <div class=\"cx-billing-list-table-col\">\n                  {{ 'subscriptionBillsList.tableViewBillCol' | cxTranslate }}\n                </div>\n              </a>\n            </div>\n          </td>\n        </tr>\n      </tbody>\n    </table>\n\n    <div class=\"billing-list-pagination-bar\">\n      <ng-container *ngIf=\"(billingList.pagination?.totalPages ?? 0) > 1\">\n        <cx-pagination\n          [pagination]=\"billingList.pagination\"\n          (viewPageEvent)=\"onPageChange($event)\"\n        ></cx-pagination>\n      </ng-container>\n    </div>\n  </ng-container>\n</ng-container>\n\n<ng-template #loading>\n  <cx-spinner></cx-spinner>\n</ng-template>\n\n<ng-template #noBills>\n  <div class=\"text-center\">\n    <h3>{{ 'subscriptionBillsList.noSubscriptionBills' | cxTranslate }}</h3>\n  </div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "component", type: PaginationComponent, selector: "cx-pagination", inputs: ["pageRoute", "queryParam", "defaultPage", "pagination", "paginationID"], outputs: ["viewPageEvent"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: SortingComponent, selector: "cx-sorting", inputs: ["sortOptions", "ariaControls", "ariaLabel", "selectedOption", "placeholder", "sortLabels"], outputs: ["sortListEvent"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: CxDatePipe, name: "cxDate" }, { kind: "pipe", type: AsyncPipe, name: "async" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-billing-list', imports: [
                        NgIf,
                        NgFor,
                        SpinnerComponent,
                        TranslatePipe,
                        PaginationComponent,
                        UrlPipe,
                        RouterLink,
                        CxDatePipe,
                        AsyncPipe,
                        SortingComponent,
                        IconComponent,
                    ], providers: [CxDatePipe], template: "<ng-container *ngIf=\"billingList$ | async as billingList; else loading\">\n  <div class=\"billing-list-title-section\">\n    <h3>{{ 'subscriptionBillsList.title' | cxTranslate }}</h3>\n  </div>\n\n  <div class=\"billing-list-filter-section\">\n    <div class=\"date-filters-wrapper\">\n      <div class=\"date-filters\">\n        <div class=\"dateRangeInputContainer\" (click)=\"launchDateRangeModal()\">\n          <span class=\"sort-label label-text\">\n            {{ 'subscriptionBillsList.dateRangeLabel' | cxTranslate }}\n          </span>\n          <input\n            type=\"text\"\n            disabled\n            class=\"form-control\"\n            [placeholder]=\"\n              'subscriptionBillsList.dateRangeInputPlaceholder' | cxTranslate\n            \"\n            [value]=\"getDateRangeFieldValue()\"\n          />\n          <button class=\"btn btn-tertiary btn-calendar\">\n            <cx-icon class=\"fa fa-calendar\"></cx-icon>\n          </button>\n        </div>\n        <button\n          class=\"btn btn-tertiary btn-clear\"\n          *ngIf=\"getDateRangeFieldValue()\"\n          (click)=\"onResetDateRange()\"\n        >\n          {{ 'subscriptionBillsList.clear' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n\n    <div class=\"billing-list-sorting-bar\">\n      <span class=\"sort-label label-text\">\n        {{ 'subscriptionBillsList.sortLabel' | cxTranslate }}\n      </span>\n      <cx-sorting\n        [sortOptions]=\"billingList.sorts\"\n        (sortListEvent)=\"onSortCodeChange($event)\"\n        [selectedOption]=\"billingList.pagination?.sort\"\n        placeholder=\"{{ 'subscriptionBillsList.sortLabel' | cxTranslate }}\"\n        [ariaLabel]=\"'subscriptionBillsList.sortOrders'\"\n      ></cx-sorting>\n    </div>\n  </div>\n  <ng-container *ngIf=\"billingList.results?.length > 0; else noBills\">\n    <!-- table starts -->\n    <table id=\"billing-list-table\" class=\"table cx-billing-list-table\">\n      <thead class=\"cx-billing-list-thead\">\n        <tr scope=\"row\">\n          <th scope=\"col\">\n            <div class=\"cx-billing-list-table-header\">\n              {{ 'subscriptionBillsList.tableHeaderColId' | cxTranslate }}\n            </div>\n          </th>\n          <th scope=\"col\">\n            <div class=\"cx-billing-list-table-header\">\n              {{ 'subscriptionBillsList.tableHeaderColDate' | cxTranslate }}\n            </div>\n          </th>\n          <th scope=\"col\">\n            <div class=\"cx-billing-list-table-header\">\n              {{\n                'subscriptionBillsList.tableHeaderColSubscriptions'\n                  | cxTranslate\n              }}\n            </div>\n          </th>\n          <th scope=\"col\">\n            <div class=\"cx-billing-list-table-header\">\n              {{ 'subscriptionBillsList.tableHeaderColTotal' | cxTranslate }}\n            </div>\n          </th>\n          <th scope=\"col\">\n            <div class=\"cx-billing-list-table-header\"></div>\n          </th>\n        </tr>\n      </thead>\n      <tbody>\n        <tr *ngFor=\"let billing of billingList.results\">\n          <td>\n            <div class=\"cx-billing-list-table-col\">\n              {{ billing.documentNumber }}\n            </div>\n          </td>\n          <td>\n            <div class=\"cx-billing-list-table-col\">\n              {{ billing.billAt | cxDate }}\n            </div>\n          </td>\n          <td>\n            <div class=\"cx-billing-list-table-col\">\n              {{ billing.items?.[0]?.productName }}\n              <ng-container *ngIf=\"billing.items.length > 1\">\n                ...\n                <a\n                  [title]=\"getTrailingSubscriptionItems(billing)\"\n                  [routerLink]=\"\n                    {\n                      cxRoute: 'subscriptionBillingDetails',\n                      params: { subscriptionBillId: billing.documentNumber },\n                    } | cxUrl\n                  \"\n                  >{{\n                    'subscriptionBillsList.descriptionSuffix'\n                      | cxTranslate: { numberOfItems: billing.items.length - 1 }\n                  }}\n                </a>\n              </ng-container>\n            </div>\n          </td>\n          <td>\n            <div class=\"cx-billing-list-table-col\">\n              {{ billing.netAmount.replace('USD', '$') }}\n            </div>\n          </td>\n          <td>\n            <div class=\"cx-billing-list-table-col\">\n              <a\n                [routerLink]=\"\n                  {\n                    cxRoute: 'subscriptionBillingDetails',\n                    params: { subscriptionBillId: billing.documentNumber },\n                  } | cxUrl\n                \"\n              >\n                <div class=\"cx-billing-list-table-col\">\n                  {{ 'subscriptionBillsList.tableViewBillCol' | cxTranslate }}\n                </div>\n              </a>\n            </div>\n          </td>\n        </tr>\n      </tbody>\n    </table>\n\n    <div class=\"billing-list-pagination-bar\">\n      <ng-container *ngIf=\"(billingList.pagination?.totalPages ?? 0) > 1\">\n        <cx-pagination\n          [pagination]=\"billingList.pagination\"\n          (viewPageEvent)=\"onPageChange($event)\"\n        ></cx-pagination>\n      </ng-container>\n    </div>\n  </ng-container>\n</ng-container>\n\n<ng-template #loading>\n  <cx-spinner></cx-spinner>\n</ng-template>\n\n<ng-template #noBills>\n  <div class=\"text-center\">\n    <h3>{{ 'subscriptionBillsList.noSubscriptionBills' | cxTranslate }}</h3>\n  </div>\n</ng-template>\n" }]
        }], ctorParameters: () => [] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DateRangeModalComponent {
    constructor() {
        this.datePickerService = inject(DatePickerService);
        this.launchDialogService = inject(LaunchDialogService);
        this.minDate = null;
        this.maxDate = null;
        this.billsDateFilterForm = new FormGroup({
            from: new FormControl(this.minDate, { validators: [Validators.required] }),
            to: new FormControl(this.maxDate, { validators: [Validators.required] }),
        });
        this.iconTypes = ICON_TYPE;
        this.focusConfig = {
            trap: false,
            block: false,
            autofocus: 'button',
            focusOnEscape: true,
        };
        this.billsDateFilterForm.addValidators(CustomFormValidators.dateRange('from', 'to', (value) => this.datePickerService.getDate(value)));
        this.launchDialogService.data$.subscribe((data) => {
            this.minDate = data.minDate;
            this.maxDate = data.maxDate;
            this.billsDateFilterForm.controls.from.setValue(data.minDate);
            this.billsDateFilterForm.controls.to.setValue(data.maxDate);
        });
    }
    onFilterDateChange() {
        this.minDate = this.billsDateFilterForm.controls.from.value;
        this.maxDate = this.billsDateFilterForm.controls.to.value;
        this.billsDateFilterForm.controls['from'].updateValueAndValidity();
        this.billsDateFilterForm.controls['to'].updateValueAndValidity();
    }
    onResetFilterDate() {
        if (this.minDate || this.maxDate) {
            this.billsDateFilterForm.reset();
            this.minDate = null;
            this.maxDate = null;
        }
    }
    onDateFilterSubmit() {
        this.onDialogClose({
            minDate: this.minDate,
            maxDate: this.maxDate,
        });
    }
    onDialogClose(closingData) {
        this.launchDialogService.closeDialog(closingData);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DateRangeModalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: DateRangeModalComponent, isStandalone: true, selector: "cx-date-range-modal", ngImport: i0, template: "<div\n  class=\"modal-dialog modal-dialog-centered\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  aria-labelledby=\"dateRangeModalTitle\"\n  (esc)=\"onDialogClose('Modal dismissed with ESC key')\"\n>\n  <div class=\"modal-content\">\n    <!-- Modal Header -->\n    <div class=\"cx-dialog-header modal-header cx-dialog-header-cancel\">\n      <div id=\"dialogTitle\" class=\"cx-dialog-title modal-title\">\n        <h3>\n          {{ 'subscriptionBillsList.dateRangeModalTitle' | cxTranslate }}\n        </h3>\n      </div>\n      <button\n        type=\"button\"\n        class=\"close\"\n        attr.aria-label=\"{{ 'subscriptionActions.closeModal' | cxTranslate }}\"\n        (click)=\"onDialogClose('Modal dismissed')\"\n      >\n        <span><cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon></span>\n      </button>\n    </div>\n    <div class=\"cx-dialog-body modal-body\">\n      <div class=\"billing-list-filter-section\">\n        <div class=\"date-filters-wrapper\">\n          <div class=\"from-date-filter date-filters\">\n            <span class=\"sort-label label-text\">\n              {{ 'subscriptionBillsList.filterFromDateLabel' | cxTranslate }}\n            </span>\n            <cx-date-picker\n              [control]=\"$any(billsDateFilterForm.get('from'))\"\n              [label]=\"'subscriptionBillsList.filterFromDateLabel'\"\n              (update)=\"onFilterDateChange()\"\n              [min]=\"minDate\"\n              [max]=\"maxDate\"\n            ></cx-date-picker>\n          </div>\n          <div class=\"to-date-filter date-filters\">\n            <span class=\"sort-label label-text\">\n              {{ 'subscriptionBillsList.filterToDateLabel' | cxTranslate }}\n            </span>\n            <cx-date-picker\n              [control]=\"$any(billsDateFilterForm.get('to'))\"\n              [label]=\"'subscriptionBillsList.filterToDateLabel'\"\n              (update)=\"onFilterDateChange()\"\n              [min]=\"minDate\"\n              [max]=\"maxDate\"\n            ></cx-date-picker>\n          </div>\n          <div class=\"reset-filter-wrapper\">\n            <button\n              class=\"btn btn-block btn-tertiary\"\n              (click)=\"onResetFilterDate()\"\n            >\n              {{ 'subscriptionBillsList.reset' | cxTranslate }}\n            </button>\n          </div>\n          <div class=\"date-filters-buttons-wrapper\">\n            <div class=\"date-filters-buttons reset\">\n              <button\n                type=\"button\"\n                class=\"btn btn-block btn-secondary\"\n                (click)=\"onDialogClose('Modal dismissed')\"\n              >\n                {{ 'subscriptionBillsList.cancel' | cxTranslate }}\n              </button>\n            </div>\n            <div class=\"date-filters-buttons submit\">\n              <button\n                type=\"submit\"\n                class=\"btn btn-primary btn-block\"\n                [disabled]=\"!billsDateFilterForm.valid\"\n                (click)=\"onDateFilterSubmit()\"\n              >\n                {{ 'subscriptionBillsList.submit' | cxTranslate }}\n              </button>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n", dependencies: [{ kind: "component", type: DatePickerComponent, selector: "cx-date-picker", inputs: ["control", "min", "max", "required", "label"], outputs: ["update"] }, { kind: "ngmodule", type: KeyboardFocusModule }, { kind: "directive", type: i2.FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "ngmodule", type: IconModule }, { kind: "component", type: i2.IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DateRangeModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-date-range-modal', imports: [
                        TranslatePipe,
                        DatePickerComponent,
                        KeyboardFocusModule,
                        IconModule,
                    ], template: "<div\n  class=\"modal-dialog modal-dialog-centered\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  aria-labelledby=\"dateRangeModalTitle\"\n  (esc)=\"onDialogClose('Modal dismissed with ESC key')\"\n>\n  <div class=\"modal-content\">\n    <!-- Modal Header -->\n    <div class=\"cx-dialog-header modal-header cx-dialog-header-cancel\">\n      <div id=\"dialogTitle\" class=\"cx-dialog-title modal-title\">\n        <h3>\n          {{ 'subscriptionBillsList.dateRangeModalTitle' | cxTranslate }}\n        </h3>\n      </div>\n      <button\n        type=\"button\"\n        class=\"close\"\n        attr.aria-label=\"{{ 'subscriptionActions.closeModal' | cxTranslate }}\"\n        (click)=\"onDialogClose('Modal dismissed')\"\n      >\n        <span><cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon></span>\n      </button>\n    </div>\n    <div class=\"cx-dialog-body modal-body\">\n      <div class=\"billing-list-filter-section\">\n        <div class=\"date-filters-wrapper\">\n          <div class=\"from-date-filter date-filters\">\n            <span class=\"sort-label label-text\">\n              {{ 'subscriptionBillsList.filterFromDateLabel' | cxTranslate }}\n            </span>\n            <cx-date-picker\n              [control]=\"$any(billsDateFilterForm.get('from'))\"\n              [label]=\"'subscriptionBillsList.filterFromDateLabel'\"\n              (update)=\"onFilterDateChange()\"\n              [min]=\"minDate\"\n              [max]=\"maxDate\"\n            ></cx-date-picker>\n          </div>\n          <div class=\"to-date-filter date-filters\">\n            <span class=\"sort-label label-text\">\n              {{ 'subscriptionBillsList.filterToDateLabel' | cxTranslate }}\n            </span>\n            <cx-date-picker\n              [control]=\"$any(billsDateFilterForm.get('to'))\"\n              [label]=\"'subscriptionBillsList.filterToDateLabel'\"\n              (update)=\"onFilterDateChange()\"\n              [min]=\"minDate\"\n              [max]=\"maxDate\"\n            ></cx-date-picker>\n          </div>\n          <div class=\"reset-filter-wrapper\">\n            <button\n              class=\"btn btn-block btn-tertiary\"\n              (click)=\"onResetFilterDate()\"\n            >\n              {{ 'subscriptionBillsList.reset' | cxTranslate }}\n            </button>\n          </div>\n          <div class=\"date-filters-buttons-wrapper\">\n            <div class=\"date-filters-buttons reset\">\n              <button\n                type=\"button\"\n                class=\"btn btn-block btn-secondary\"\n                (click)=\"onDialogClose('Modal dismissed')\"\n              >\n                {{ 'subscriptionBillsList.cancel' | cxTranslate }}\n              </button>\n            </div>\n            <div class=\"date-filters-buttons submit\">\n              <button\n                type=\"submit\"\n                class=\"btn btn-primary btn-block\"\n                [disabled]=\"!billsDateFilterForm.valid\"\n                (click)=\"onDateFilterSubmit()\"\n              >\n                {{ 'subscriptionBillsList.submit' | cxTranslate }}\n              </button>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [] });

/*
 * Copyright (C) 2025 SAP SE or an SAP affiliate company. All rights reserved.
 * SPDX-FileCopyrightText: 2025 SAP Spartacus team <spartacus-team@sap.com>
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const dateRangeModalConfig = {
    launch: {
        DATE_RANGE_MODAL: {
            inlineRoot: true,
            component: DateRangeModalComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2025 SAP Spartacus team <spartacus-team@sap.com>
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionBillingListModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingListModule, imports: [I18nModule,
            UrlModule,
            ListNavigationModule,
            RouterModule,
            SpinnerModule,
            CommonModule,
            DatePickerModule,
            FormErrorsModule,
            ReactiveFormsModule,
            SubscriptionBillingListComponent,
            DateRangeModalComponent], exports: [SubscriptionBillingListComponent, DateRangeModalComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingListModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    SubscriptionBillsHistoryComponent: {
                        component: SubscriptionBillingListComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
            provideDefaultConfig(dateRangeModalConfig),
        ], imports: [I18nModule,
            UrlModule,
            ListNavigationModule,
            RouterModule,
            SpinnerModule,
            CommonModule,
            DatePickerModule,
            FormErrorsModule,
            ReactiveFormsModule,
            SubscriptionBillingListComponent,
            DateRangeModalComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        I18nModule,
                        UrlModule,
                        ListNavigationModule,
                        RouterModule,
                        SpinnerModule,
                        CommonModule,
                        DatePickerModule,
                        FormErrorsModule,
                        ReactiveFormsModule,
                        SubscriptionBillingListComponent,
                        DateRangeModalComponent,
                    ],
                    exports: [SubscriptionBillingListComponent, DateRangeModalComponent],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                SubscriptionBillsHistoryComponent: {
                                    component: SubscriptionBillingListComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                        provideDefaultConfig(dateRangeModalConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionBillingDetailsComponent {
    constructor() {
        this.subscriptionBillingFacade = inject(SubscriptionBillingFacade);
        this.eventService = inject(EventService);
        this.subscriptionBill$ = this.subscriptionBillingFacade.getSubscriptionBillByCode();
    }
    ngOnInit() {
        this.eventService.dispatch({}, GetSubscriptionBillByCodeReloadEvent);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingDetailsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: SubscriptionBillingDetailsComponent, isStandalone: true, selector: "cx-subscription-billing-details", ngImport: i0, template: "<ng-container\n  *ngIf=\"subscriptionBill$ | async as subscriptionBill; else loading\"\n>\n  <div class=\"subscription-bill-item\">\n    <div class=\"subscription-bill-item-header\">\n      <div class=\"subscription-bill-item-meta\">\n        <div class=\"subscription-id\" *ngIf=\"subscriptionBill.documentNumber\">\n          {{ 'subscriptionBillingDetails.billId' | cxTranslate }}\n          {{ subscriptionBill.documentNumber }}\n        </div>\n      </div>\n      <div\n        class=\"subscription-bill-item-total\"\n        *ngIf=\"subscriptionBill.netAmount\"\n      >\n        {{ 'subscriptionBillingDetails.totalAmount' | cxTranslate }}\n        {{ subscriptionBill.netAmount }}\n      </div>\n    </div>\n    <div\n      class=\"subscription-bill-item-body\"\n      *ngIf=\"subscriptionBill.items?.length\"\n    >\n      <div\n        class=\"subscription-bill-item-details\"\n        *ngFor=\"let subscriptionBillItem of subscriptionBill.items\"\n      >\n        <p class=\"subscription-product\">\n          <a\n            *ngIf=\"subscriptionBillItem.subscriptionId\"\n            [routerLink]=\"\n              {\n                cxRoute: 'subscriptionDetails',\n                params: { subscriptionId: subscriptionBillItem.subscriptionId },\n              } | cxUrl\n            \"\n          >\n            {{\n              subscriptionBillItem.productName\n                ? subscriptionBillItem.productName\n                : ('subscriptionBillingDetails.subscriptionProduct'\n                  | cxTranslate)\n            }}\n          </a>\n        </p>\n        <p\n          class=\"usage-charge\"\n          *ngFor=\"let usageCharge of subscriptionBillItem.usageCharges\"\n        >\n          {{\n            usageCharge.typeName\n              ? usageCharge.typeName\n              : ('subscriptionBillingDetails.netAmount' | cxTranslate)\n          }}\n          -\n          {{ usageCharge.netAmount }}\n        </p>\n        <p\n          class=\"subscription-total-due\"\n          *ngIf=\"subscriptionBillItem.netAmount\"\n        >\n          {{ 'subscriptionBillingDetails.totalAmount' | cxTranslate }}\n          {{ subscriptionBillItem.netAmount }}\n        </p>\n        <p\n          class=\"subscription-bill-period\"\n          *ngIf=\"subscriptionBill.periodStartAt && subscriptionBill.periodEndAt\"\n        >\n          {{\n            'subscriptionBillingDetails.billingPeriod'\n              | cxTranslate\n                : {\n                    startDate: subscriptionBill.periodStartAt | cxDate,\n                    endDate: subscriptionBill.periodEndAt | cxDate,\n                  }\n          }}\n        </p>\n      </div>\n    </div>\n  </div>\n</ng-container>\n<ng-template #loading>\n  <cx-spinner></cx-spinner>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: CxDatePipe, name: "cxDate" }, { kind: "pipe", type: AsyncPipe, name: "async" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-subscription-billing-details', imports: [
                        NgIf,
                        NgFor,
                        SpinnerComponent,
                        TranslatePipe,
                        UrlPipe,
                        RouterLink,
                        CxDatePipe,
                        AsyncPipe,
                    ], template: "<ng-container\n  *ngIf=\"subscriptionBill$ | async as subscriptionBill; else loading\"\n>\n  <div class=\"subscription-bill-item\">\n    <div class=\"subscription-bill-item-header\">\n      <div class=\"subscription-bill-item-meta\">\n        <div class=\"subscription-id\" *ngIf=\"subscriptionBill.documentNumber\">\n          {{ 'subscriptionBillingDetails.billId' | cxTranslate }}\n          {{ subscriptionBill.documentNumber }}\n        </div>\n      </div>\n      <div\n        class=\"subscription-bill-item-total\"\n        *ngIf=\"subscriptionBill.netAmount\"\n      >\n        {{ 'subscriptionBillingDetails.totalAmount' | cxTranslate }}\n        {{ subscriptionBill.netAmount }}\n      </div>\n    </div>\n    <div\n      class=\"subscription-bill-item-body\"\n      *ngIf=\"subscriptionBill.items?.length\"\n    >\n      <div\n        class=\"subscription-bill-item-details\"\n        *ngFor=\"let subscriptionBillItem of subscriptionBill.items\"\n      >\n        <p class=\"subscription-product\">\n          <a\n            *ngIf=\"subscriptionBillItem.subscriptionId\"\n            [routerLink]=\"\n              {\n                cxRoute: 'subscriptionDetails',\n                params: { subscriptionId: subscriptionBillItem.subscriptionId },\n              } | cxUrl\n            \"\n          >\n            {{\n              subscriptionBillItem.productName\n                ? subscriptionBillItem.productName\n                : ('subscriptionBillingDetails.subscriptionProduct'\n                  | cxTranslate)\n            }}\n          </a>\n        </p>\n        <p\n          class=\"usage-charge\"\n          *ngFor=\"let usageCharge of subscriptionBillItem.usageCharges\"\n        >\n          {{\n            usageCharge.typeName\n              ? usageCharge.typeName\n              : ('subscriptionBillingDetails.netAmount' | cxTranslate)\n          }}\n          -\n          {{ usageCharge.netAmount }}\n        </p>\n        <p\n          class=\"subscription-total-due\"\n          *ngIf=\"subscriptionBillItem.netAmount\"\n        >\n          {{ 'subscriptionBillingDetails.totalAmount' | cxTranslate }}\n          {{ subscriptionBillItem.netAmount }}\n        </p>\n        <p\n          class=\"subscription-bill-period\"\n          *ngIf=\"subscriptionBill.periodStartAt && subscriptionBill.periodEndAt\"\n        >\n          {{\n            'subscriptionBillingDetails.billingPeriod'\n              | cxTranslate\n                : {\n                    startDate: subscriptionBill.periodStartAt | cxDate,\n                    endDate: subscriptionBill.periodEndAt | cxDate,\n                  }\n          }}\n        </p>\n      </div>\n    </div>\n  </div>\n</ng-container>\n<ng-template #loading>\n  <cx-spinner></cx-spinner>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionBillingDetailsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingDetailsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingDetailsModule, imports: [CommonModule,
            RouterModule,
            UrlModule,
            I18nModule,
            SpinnerModule,
            SubscriptionBillingDetailsComponent], exports: [SubscriptionBillingDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingDetailsModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    SubscriptionBillDetailsComponent: {
                        component: SubscriptionBillingDetailsComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            RouterModule,
            UrlModule,
            I18nModule,
            SpinnerModule,
            SubscriptionBillingDetailsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingDetailsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        SpinnerModule,
                        SubscriptionBillingDetailsComponent,
                    ],
                    exports: [SubscriptionBillingDetailsComponent],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                SubscriptionBillDetailsComponent: {
                                    component: SubscriptionBillingDetailsComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionBillingComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingComponentsModule, imports: [SubscriptionListModule,
            SubscriptionDetailsModule,
            SubscriptionBillingDetailsModule,
            SubscriptionProductPriceModule,
            SubscriptionProductUsageChargeModule,
            SubscriptionBillingListModule,
            SubscriptionActionsModalModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingComponentsModule, imports: [SubscriptionListModule,
            SubscriptionDetailsModule,
            SubscriptionBillingDetailsModule,
            SubscriptionProductPriceModule,
            SubscriptionProductUsageChargeModule,
            SubscriptionBillingListModule,
            SubscriptionActionsModalModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        SubscriptionListModule,
                        SubscriptionDetailsModule,
                        SubscriptionBillingDetailsModule,
                        SubscriptionProductPriceModule,
                        SubscriptionProductUsageChargeModule,
                        SubscriptionBillingListModule,
                        SubscriptionActionsModalModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DateRangeModalComponent, SubscriptionActionsModalComponent, SubscriptionActionsModalComponentService, SubscriptionActionsModalModule, SubscriptionBillingComponentsModule, SubscriptionBillingDetailsComponent, SubscriptionBillingDetailsModule, SubscriptionBillingListComponent, SubscriptionBillingListModule, SubscriptionDetailsComponent, SubscriptionDetailsModule, SubscriptionListComponent, SubscriptionListModule, SubscriptionProductPriceComponent, SubscriptionProductPriceModule, SubscriptionProductUsageChargeComponent, SubscriptionProductUsageChargeModule, subscriptionActionsPopupConfig };
//# sourceMappingURL=spartacus-subscription-billing-components.mjs.map
