import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { SubscriptionBillingComponentsModule } from '@spartacus/subscription-billing/components';
import { SubscriptionBillingCoreModule } from '@spartacus/subscription-billing/core';
import { SubscriptionBillingOccModule } from '@spartacus/subscription-billing/occ';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionBillingModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingModule, imports: [SubscriptionBillingComponentsModule,
            SubscriptionBillingCoreModule,
            SubscriptionBillingOccModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingModule, imports: [SubscriptionBillingComponentsModule,
            SubscriptionBillingCoreModule,
            SubscriptionBillingOccModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        SubscriptionBillingComponentsModule,
                        SubscriptionBillingCoreModule,
                        SubscriptionBillingOccModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/*
 * Public API Surface of segment
 */

/**
 * Generated bundle index. Do not edit.
 */

export { SubscriptionBillingModule };
//# sourceMappingURL=spartacus-subscription-billing.mjs.map
