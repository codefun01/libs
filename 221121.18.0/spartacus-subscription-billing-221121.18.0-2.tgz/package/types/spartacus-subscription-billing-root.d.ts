import { EventService, CmsConfig, Price, PaginationModel, SortModel, QueryState, CxEvent, ProductService, Product, RoutingConfig } from '@spartacus/core';
import * as i0 from '@angular/core';
import { OnDestroy } from '@angular/core';
import { Subscription, Observable } from 'rxjs';
import { CurrentProductService, OutletContextData } from '@spartacus/storefront';

declare class SubscriptionBillingEventListener implements OnDestroy {
    protected subscriptions: Subscription;
    protected eventService: EventService;
    constructor();
    protected onLanguageAndCurrencySetEvent(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionBillingEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubscriptionBillingEventListener>;
}

declare class SubscriptionBillingEventModule {
    constructor(_subscriptionBillingEventListener: SubscriptionBillingEventListener);
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionBillingEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SubscriptionBillingEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SubscriptionBillingEventModule>;
}

declare function defaultSubscriptionBillingComponentsConfig(): CmsConfig;
declare class SubscriptionBillingRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionBillingRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SubscriptionBillingRootModule, never, [typeof SubscriptionBillingEventModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SubscriptionBillingRootModule>;
}

declare const SUBSCRIPTION_BILLING_FEATURE = "subscriptionBilling";
declare const SUBSCRIPTION_BILLING_CORE_FEATURE = "subscriptionBillingCore";

declare enum UsageChargeType {
    BLOCK = "block_usage_charge",
    PERCENTAGE = "percentage_usage_charge",
    TIER = "each_respective_tier"
}
interface RenewalTerm {
    period?: number;
    endAt?: string;
}
interface SubscriptionTerm {
    renewalTerm?: TermType;
    minimumTerm?: TermType;
    billingPlan?: {
        billingTime?: BillingTime;
    };
}
interface BillingTime {
    name?: string;
    namePastTense?: string;
}
interface TermType {
    value?: number;
    frequency?: {
        id?: string;
        name?: string;
    };
}
interface PricePlan {
    oneTimeCharges?: OneTimeCharge[];
    recurringCharges?: RecurringCharge[];
    perUnitUsageCharges?: PerUnitUsageCharge[];
    volumeUsageCharges?: VolumeUsageCharge[];
}
interface OneTimeCharge {
    price?: Price;
    name?: string;
    billingTime?: BillingTime;
}
interface RecurringCharge {
    price?: Price;
}
interface UsageCharge {
    usageUnit?: UsageUnit;
    minBlocks?: number;
    blockSize?: number;
    tierUsageChargeEntries?: TierUsageChargeEntry[];
    overageUsageChargeEntries?: OverageUsageChargeEntry[];
    typeName?: string;
    netAmount?: string;
}
interface PerUnitUsageCharge extends UsageCharge {
    includedQty?: number;
    ratio?: string;
    usageChargeType?: string;
    perUnitUsageChargeEntries?: PerUnitUsageChargeEntry[];
}
interface VolumeUsageCharge extends UsageCharge {
}
interface UsageChargeEntry {
    price?: Price;
}
interface OverageUsageChargeEntry extends UsageChargeEntry {
    fixedPrice?: Price;
}
interface TierUsageChargeEntry extends UsageChargeEntry {
    fixedPrice?: Price;
    tierStart?: number;
    tierEnd?: number;
}
interface PerUnitUsageChargeEntry extends UsageChargeEntry {
}
interface UsageUnit {
    name?: string;
    namePlural?: string;
}
declare module '@spartacus/core' {
    interface Product {
        sapSubscriptionTerm?: SubscriptionTerm;
        sapPricePlan?: PricePlan;
    }
}
declare module '@spartacus/core' {
    enum ProductScope {
        SUBSCRIPTION = "subscription"
    }
}

interface SubscriptionDetail {
    id?: string;
    name?: string;
    productCode?: string;
    startAt?: string;
    endAt?: string;
    status?: string;
    isCancellationPossible?: boolean;
    isExtensionPossible?: boolean;
    isWithdrawalPossible?: boolean;
    isCancellationReversalPossible?: boolean;
    contractFrequency?: string;
    documentNumber?: string;
    pricePlan?: PricePlan;
    withdrawalPeriodEndAt?: string;
    billingTime?: string;
    orderCode?: string;
}
interface SubscriptionList {
    results?: SubscriptionDetail[];
    pagination?: PaginationModel;
    sorts?: SortModel[];
}
/** Actions related models */
interface SubscriptionCancelData {
    subscriptionEndAt?: string;
}
interface SubscriptionCancellationDetails {
    subscriptionEndAt?: string;
}
interface SubscriptionReverseCancellation {
    subscriptionId?: string;
    version?: string;
}
interface SubscriptionWithdraw {
    subscriptionId?: string;
    version?: string;
    withdrawnAt?: string;
    withdrawalPeriodEndDate?: string;
}
type SubscriptionActionMode = 'cancel' | 'withdraw' | 'resubscribe' | 'extend';
declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        SUBSCRIPTION_ACTION_CONFIRMATION = "SUBSCRIPTION_ACTION_CONFIRMATION",
        DATE_RANGE_MODAL = "DATE_RANGE_MODAL"
    }
}
interface SubscriptionExtensionEffectiveDate {
    subscriptionEndAt: string;
}

interface SubscriptionBillsList {
    results?: SubscriptionBill[];
    pagination?: PaginationModel;
    sorts?: SortModel[];
}
interface SubscriptionBill {
    id?: string;
    documentNumber?: string;
    periodStartAt?: string;
    periodEndAt?: string;
    billAt?: string;
    dueAt?: string;
    netAmount?: string;
    grossAmount?: string;
    numberOfSubscriptions?: number;
    items?: SubscriptionBillItem[];
    status?: SubscriptionBillStatus;
}
interface SubscriptionBillItem {
    subscriptionId?: string;
    subscriptionDocumentNumber?: string;
    productCode?: string;
    productName?: string;
    netAmount?: string;
    grossAmount?: string;
    usageCharges?: BillUsageCharge[];
}
declare enum SubscriptionBillStatus {
    PAID = "Paid",
    DUE = "Due"
}
interface BillUsageCharge {
    name?: string;
    typeName?: string;
    usageQuantity?: number;
    usageUnit?: UsageUnit;
    netAmount?: string;
    grossAmount?: string;
}

declare abstract class SubscriptionFacade {
    abstract getSubscriptionByCodeState(): Observable<QueryState<SubscriptionDetail | undefined>>;
    abstract getSubscriptionByCode(code?: string): Observable<SubscriptionDetail | undefined>;
    abstract getSubscriptionListState(pageSize: number, currentPage?: number, sort?: string): Observable<QueryState<SubscriptionList | undefined>>;
    abstract getSubscriptionList(pageSize?: number, currentPage?: number, sort?: string): Observable<SubscriptionList | undefined>;
    abstract getSubscriptionCodeFromRoute(): Observable<string | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubscriptionFacade>;
}

declare abstract class SubscriptionActionsFacade {
    abstract cancelSubscription(cancellationDetails: SubscriptionCancellationDetails, code?: string): Observable<unknown>;
    abstract getEffectiveCancellationDate(code: string): Observable<any>;
    abstract reverseCancellation(code?: string): Observable<unknown>;
    abstract withdrawSubscription(withdrawal: SubscriptionWithdraw, code?: string): Observable<unknown>;
    abstract getExtensionEffectiveDate(extendDuration: number, isUnlimitedDuration: boolean, code: string): Observable<SubscriptionExtensionEffectiveDate>;
    abstract extendSubscription(extendDuration: number, isUnlimitedDuration: boolean, code: string): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionActionsFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubscriptionActionsFacade>;
}

declare abstract class SubscriptionBillingFacade {
    abstract getSubscriptionBillByCodeState(): Observable<QueryState<SubscriptionBill | undefined>>;
    abstract getSubscriptionBillByCode(code?: string): Observable<SubscriptionBill | undefined>;
    abstract getSubscriptionBillsListState(pageSize?: number, currentPage?: number, sort?: string, filter?: string): Observable<QueryState<SubscriptionBillsList | undefined>>;
    abstract getSubscriptionBillsList(pageSize?: number, currentPage?: number, sort?: string, filters?: string): Observable<SubscriptionBillsList | undefined>;
    abstract getSubscriptionBillCodeFromRoute(): Observable<string | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionBillingFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubscriptionBillingFacade>;
}

declare class GetSubscriptionByCodeReloadEvent extends CxEvent {
    static readonly type = "GetSubscriptionByCodeReloadEvent";
}
declare class GetSubscriptionListReloadEvent extends CxEvent {
    static readonly type = "GetSubscriptionListReloadEvent";
}
declare class GetSubscriptionBillsListReloadEvent extends CxEvent {
    static readonly type = "GetSubscriptionBillsListReloadEvent";
}
declare class GetSubscriptionBillByCodeReloadEvent extends CxEvent {
    static readonly type = "GetSubscriptionBillByCodeReloadEvent";
}

declare class SubscriptionProductService {
    protected currentProductService: CurrentProductService;
    protected productService: ProductService;
    isSubscription(product: Product): boolean;
    getSubscriptionData(productCode?: string): Observable<Product | null | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionProductService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubscriptionProductService>;
}

declare class SubscriptionCartPriceHeadingComponent {
    protected outletData: OutletContextData<any> | null;
    protected productService: SubscriptionProductService;
    cartItems: i0.Signal<any>;
    subscriptionItem: i0.Signal<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionCartPriceHeadingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SubscriptionCartPriceHeadingComponent, "cx-subscription-cart-price-heading", never, {}, {}, never, never, true, never>;
}

declare class SubscriptionCartPriceBodyComponent {
    protected outletContext: OutletContextData<any> | null;
    protected productService: SubscriptionProductService;
    outletData: i0.Signal<any>;
    parent: i0.Signal<any>;
    subscriptionItemExists: i0.Signal<any>;
    item: i0.Signal<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionCartPriceBodyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SubscriptionCartPriceBodyComponent, "cx-subscription-cart-price-body", never, {}, {}, never, never, true, never>;
}

declare abstract class ExtendSubscriptionFrequencyDropdownOptionsConfig {
    Months?: number;
    Years?: number;
    Days?: number;
    Weeks?: number;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExtendSubscriptionFrequencyDropdownOptionsConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ExtendSubscriptionFrequencyDropdownOptionsConfig>;
}
declare module '@spartacus/core' {
    interface Config extends ExtendSubscriptionFrequencyDropdownOptionsConfig {
    }
}

declare const defaultExtendDropdownOptions: ExtendSubscriptionFrequencyDropdownOptionsConfig;

declare const defaultSubscriptionBillingRoutingConfig: RoutingConfig;

export { ExtendSubscriptionFrequencyDropdownOptionsConfig, GetSubscriptionBillByCodeReloadEvent, GetSubscriptionBillsListReloadEvent, GetSubscriptionByCodeReloadEvent, GetSubscriptionListReloadEvent, SUBSCRIPTION_BILLING_CORE_FEATURE, SUBSCRIPTION_BILLING_FEATURE, SubscriptionActionsFacade, SubscriptionBillStatus, SubscriptionBillingEventListener, SubscriptionBillingEventModule, SubscriptionBillingFacade, SubscriptionBillingRootModule, SubscriptionCartPriceBodyComponent, SubscriptionCartPriceHeadingComponent, SubscriptionFacade, SubscriptionProductService, UsageChargeType, defaultExtendDropdownOptions, defaultSubscriptionBillingComponentsConfig, defaultSubscriptionBillingRoutingConfig };
export type { BillUsageCharge, BillingTime, OneTimeCharge, OverageUsageChargeEntry, PerUnitUsageCharge, PerUnitUsageChargeEntry, PricePlan, RecurringCharge, RenewalTerm, SubscriptionActionMode, SubscriptionBill, SubscriptionBillItem, SubscriptionBillsList, SubscriptionCancelData, SubscriptionCancellationDetails, SubscriptionDetail, SubscriptionExtensionEffectiveDate, SubscriptionList, SubscriptionReverseCancellation, SubscriptionTerm, SubscriptionWithdraw, TermType, TierUsageChargeEntry, UsageCharge, UsageChargeEntry, UsageUnit, VolumeUsageCharge };
