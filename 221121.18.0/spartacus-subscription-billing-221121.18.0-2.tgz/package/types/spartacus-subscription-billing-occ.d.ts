import { OccEndpoint, LoggerService, OccEndpointsService } from '@spartacus/core';
import * as i0 from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SubscriptionAdapter, SubscriptionActionsAdapter, SubscriptionBillingAdapter } from '@spartacus/subscription-billing/core';
import { SubscriptionDetail, SubscriptionList, SubscriptionCancellationDetails, SubscriptionWithdraw, SubscriptionExtensionEffectiveDate, SubscriptionBillsList, SubscriptionBill } from '@spartacus/subscription-billing/root';
import { Observable } from 'rxjs';

interface SubscriptionBillingOccEndpoints {
    /**
     * Endpoint for the list of one user's subscriptions
     *
     * @member {string}
     */
    subscriptionList?: string | OccEndpoint;
    /**
     * Endpoint for the details of one user's subscription
     *
     * @member {string}
     */
    subscriptionByCode?: string | OccEndpoint;
    /**
     * Endpoint for the extension validity date of one user's subscription
     *
     * @member {string}
     */
    extensionEffectiveDate?: string | OccEndpoint;
    /**
     * Endpoint for the extending one user's subscription
     *
     * @member {string}
     */
    extendSubscription?: string | OccEndpoint;
    /**
     * Endpoint for cancelling a specific subscription.
     */
    cancelSubscription?: string | OccEndpoint;
    /**
     * Endpoint for retrieving the effective cancellation date of a subscription.
     */
    getEffectiveCancellationDate?: string | OccEndpoint;
    /**
     * Endpoint for withdrawing a previously cancelled subscription.
     */
    withdrawSubscription?: string | OccEndpoint;
    /**
     * Endpoint for reversing a cancellation of a subscription.
     */
    reverseCancellation?: string | OccEndpoint;
    /**
     * Endpoint for retrieving the list of subscription bills for a user.
     */
    subscriptionBillsList?: string | OccEndpoint;
    /**
     * Endpoint for retrieving a specific subscription bill by its ID.
     */
    subscriptionBillByCode?: string | OccEndpoint;
}
declare module '@spartacus/core' {
    interface OccEndpoints extends SubscriptionBillingOccEndpoints {
    }
}

declare class SubscriptionBillingOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionBillingOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SubscriptionBillingOccModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SubscriptionBillingOccModule>;
}

declare class OccSubscriptionAdapter implements SubscriptionAdapter {
    protected logger: LoggerService;
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    getSubscriptionByCode(userId: string, subscriptionCode: string): Observable<SubscriptionDetail>;
    getSubscriptionList(userId: string, pageSize?: number, currentPage?: number, sort?: string): Observable<SubscriptionList>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccSubscriptionAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccSubscriptionAdapter>;
}

declare class OccSubscriptionActionsAdapter implements SubscriptionActionsAdapter {
    protected logger: LoggerService;
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    cancelSubscription(userId: string, subscriptionCode: string, cancellationDetails: SubscriptionCancellationDetails): Observable<any>;
    getEffectiveCancellationDate(userId: string, subscriptionCode: string): Observable<any>;
    withdrawSubscription(userId: string, subscriptionCode: string, withdrawalData: SubscriptionWithdraw): Observable<any>;
    reverseCancellation(userId: string, subscriptionCode: string): Observable<any>;
    getExtensionEffectiveDate(userId: string, subscriptionCode: string, durationInMonth: number | null, unlimited: boolean): Observable<SubscriptionExtensionEffectiveDate>;
    extendSubscription(userId: string, subscriptionCode: string, durationInMonth: number | null, unlimited: boolean): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccSubscriptionActionsAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccSubscriptionActionsAdapter>;
}

declare class OccSubscriptionBillingAdapter implements SubscriptionBillingAdapter {
    protected logger: LoggerService;
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    getSubscriptionBillsList(userId: string, pageSize?: number, currentPage?: number, sort?: string, filters?: string): Observable<SubscriptionBillsList>;
    getSubscriptionBillByCode(userId: string, billId: string): Observable<SubscriptionBill>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccSubscriptionBillingAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccSubscriptionBillingAdapter>;
}

export { OccSubscriptionActionsAdapter, OccSubscriptionAdapter, OccSubscriptionBillingAdapter, SubscriptionBillingOccModule };
export type { SubscriptionBillingOccEndpoints };
