import { TranslationChunksConfig } from '@spartacus/core';

declare const en: {
    subscriptionBilling: {
        subscriptionProduct: {
            subscriptionTerms: string;
            minimumTerm: string;
            renewalTerm: string;
            usageCharges: string;
            volumeUsage: string;
            volumeOverageUsage: string;
            volumeUsageMessage: string;
            tierOverageUsage: string;
            tierUsageMessage: string;
            tierUsage: string;
            includedQuantity: string;
            oneBlockUsage: string;
            multiBlockUsage: string;
            percentageUsage: string;
        };
        subscriptionList: {
            id: string;
            product: string;
            title: string;
            sortSubtitle: string;
            startDate: string;
            status: string;
            noSubscriptions: string;
            sortOrders: string;
            manageService: string;
            amount: string;
            sorts: {
                byDocumentNumberDesc: string;
                byDocumentNumberAsc: string;
            };
        };
        subscriptionDetails: {
            info: string;
            productCode: string;
            endDate: string;
            cancelSubscription: string;
            extendSubscription: string;
            withdrawSubscription: string;
            reSubscribe: string;
            back: string;
            withdrawalEnd: string;
            orderCode: string;
        };
        subscriptionActions: {
            cancel: string;
            confirm: string;
            cancelSuccess: string;
            withdrawSuccess: string;
            reverseCancellationSuccess: string;
            unknownError: string;
            askConfirm: string;
            closeModal: string;
            loseSubscription: string;
            changeMind: string;
            withdrawConfirm: string;
            resubscribeConfirm: string;
            changeMindresubscribe: string;
            extend: string;
            durationInputLabel: string;
            durationInputPlaceholder: string;
            disclaimer: string;
            disclaimerWithExtensionEndDate: string;
            noActionMessage: string;
            confirmExtensionTitle: string;
            extendedSuccessfully: string;
        };
        subscriptionCartItemList: {
            itemPriceHeader: string;
            dueNowHeader: string;
        };
        subscriptionBillsList: {
            title: string;
            dateRangeLabel: string;
            filterFromDateLabel: string;
            filterToDateLabel: string;
            sortLabel: string;
            noSubscriptionBills: string;
            tableHeaderColId: string;
            tableHeaderColDate: string;
            tableHeaderColSubscriptions: string;
            tableHeaderColTotal: string;
            tableViewBillCol: string;
            reset: string;
            submit: string;
            cancel: string;
            clear: string;
            descriptionSuffix: string;
            dateRangeInputPlaceholder: string;
            dateRangeModalTitle: string;
        };
        subscriptionBillingDetails: {
            billId: string;
            totalAmount: string;
            subscriptionProduct: string;
            billingPeriod: string;
        };
        subscriptionPageBreadcrumb: {
            home: string;
            subscriptions: string;
            subscriptionBills: string;
        };
    };
};

declare const subscriptionBillingTranslationChunksConfig: TranslationChunksConfig;

export { subscriptionBillingTranslationChunksConfig, en as subscriptionBillingTranslationsEn };
