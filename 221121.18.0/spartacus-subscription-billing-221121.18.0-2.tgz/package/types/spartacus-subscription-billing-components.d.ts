import * as i0 from '@angular/core';
import { WritableSignal, OnInit, Signal, DestroyRef } from '@angular/core';
import * as i2 from '@spartacus/core';
import { EventService, Product, CxDatePipe } from '@spartacus/core';
import * as i2$1 from '@spartacus/storefront';
import { LaunchDialogService, DatePickerService, ICON_TYPE, FocusConfig, LayoutConfig } from '@spartacus/storefront';
import * as i3 from '@angular/router';
import * as i1 from '@angular/common';
import * as rxjs from 'rxjs';
import { Observable } from 'rxjs';
import { SubscriptionFacade, SubscriptionList, SubscriptionDetail, SubscriptionActionMode, SubscriptionBillingFacade, SubscriptionBill, PerUnitUsageCharge, VolumeUsageCharge, TierUsageChargeEntry, SubscriptionProductService, OneTimeCharge, RecurringCharge, SubscriptionBillsList, SubscriptionActionsFacade, ExtendSubscriptionFrequencyDropdownOptionsConfig, SubscriptionCancelData, SubscriptionExtensionEffectiveDate } from '@spartacus/subscription-billing/root';
import * as i5 from '@angular/forms';
import { FormGroup, FormControl } from '@angular/forms';

declare class SubscriptionListComponent {
    protected subscriptionFacade: SubscriptionFacade;
    PAGE_SIZE: number;
    listParams: WritableSignal<{
        sortCode: string | undefined;
        currentPage: number;
    }>;
    subscriptions$: rxjs.Observable<SubscriptionList | undefined>;
    subscriptions: i0.Signal<SubscriptionList | null | undefined>;
    changeSortCode(sortCode: string): void;
    pageChange(page: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SubscriptionListComponent, "cx-subscription-list", never, {}, {}, never, never, true, never>;
}

declare class SubscriptionListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SubscriptionListModule, never, [typeof i2.I18nModule, typeof i2.UrlModule, typeof i2$1.ListNavigationModule, typeof i3.RouterModule, typeof i2$1.SpinnerModule, typeof i1.CommonModule, typeof SubscriptionListComponent], [typeof SubscriptionListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SubscriptionListModule>;
}

declare class SubscriptionDetailsComponent implements OnInit {
    protected subscriptionFacade: SubscriptionFacade;
    protected eventService: EventService;
    protected launchDialogService: LaunchDialogService;
    subscriptionDetails$: Observable<SubscriptionDetail | undefined>;
    ngOnInit(): void;
    showSubscriptionActionsDialog(mode: SubscriptionActionMode): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SubscriptionDetailsComponent, "cx-subscription-details", never, {}, {}, never, never, true, never>;
}

declare class SubscriptionDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SubscriptionDetailsModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i2.UrlModule, typeof i3.RouterModule, typeof i2$1.SpinnerModule, typeof i2$1.IconModule, typeof SubscriptionDetailsComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SubscriptionDetailsModule>;
}

declare class SubscriptionBillingDetailsComponent implements OnInit {
    protected subscriptionBillingFacade: SubscriptionBillingFacade;
    protected eventService: EventService;
    protected subscriptionBill$: Observable<SubscriptionBill | undefined>;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionBillingDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SubscriptionBillingDetailsComponent, "cx-subscription-billing-details", never, {}, {}, never, never, true, never>;
}

declare class SubscriptionBillingDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionBillingDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SubscriptionBillingDetailsModule, never, [typeof i1.CommonModule, typeof i3.RouterModule, typeof i2.UrlModule, typeof i2.I18nModule, typeof i2$1.SpinnerModule, typeof SubscriptionBillingDetailsComponent], [typeof SubscriptionBillingDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SubscriptionBillingDetailsModule>;
}

declare class SubscriptionProductUsageChargeComponent {
    product: Signal<Product | undefined | null>;
    blockUsageCharges: Signal<PerUnitUsageCharge[]>;
    getIncludedQuantity(charge: PerUnitUsageCharge): string;
    percentageUsageCharges: Signal<PerUnitUsageCharge[]>;
    tierUsageCharges: Signal<PerUnitUsageCharge[]>;
    volumeUsageCharges: Signal<VolumeUsageCharge[]>;
    getLastTierValue(tierUsageChargeEntries: TierUsageChargeEntry[]): number;
    isUsageChargePresent(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionProductUsageChargeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SubscriptionProductUsageChargeComponent, "cx-subscription-product-usage-charge", never, { "product": { "alias": "product"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SubscriptionProductUsageChargeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionProductUsageChargeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SubscriptionProductUsageChargeModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof SubscriptionProductUsageChargeComponent], [typeof SubscriptionProductUsageChargeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SubscriptionProductUsageChargeModule>;
}

declare class SubscriptionProductPriceComponent {
    productCode?: string;
    protected productService: SubscriptionProductService;
    productDetail: Signal<Product | null | undefined>;
    isCurrentProductSubscription: Signal<boolean>;
    oneTimeCharges: Signal<OneTimeCharge[]>;
    recurringCharges: Signal<RecurringCharge[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionProductPriceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SubscriptionProductPriceComponent, "cx-subscription-product-price", never, { "productCode": { "alias": "productCode"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SubscriptionProductPriceModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionProductPriceModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SubscriptionProductPriceModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof SubscriptionProductUsageChargeModule, typeof SubscriptionProductPriceComponent], [typeof SubscriptionProductPriceComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SubscriptionProductPriceModule>;
}

declare class SubscriptionBillingListComponent {
    protected subscriptionBillsFacade: SubscriptionBillingFacade;
    protected datePickerService: DatePickerService;
    protected launchDialogService: LaunchDialogService;
    protected eventService: EventService;
    protected cxDatePipe: CxDatePipe;
    minDate: string | null;
    maxDate: string | null;
    DATE_FILTER_PARAM: string;
    PAGE_SIZE: number;
    listParams: {
        sortCode?: string;
        pageNumber?: number;
        dateFilter?: string;
    };
    iconTypes: typeof ICON_TYPE;
    constructor();
    billingList$: Observable<SubscriptionBillsList | undefined>;
    billsDateFilterForm: FormGroup<{
        from: FormControl<string | null>;
        to: FormControl<string | null>;
    }>;
    onSortCodeChange(sortCode: string): void;
    onPageChange(pageNumber: string): void;
    /**
     * @deprecated - Selection of date range and relevant methods have been moved to DateRangeModalComponent
     */
    onFilterDateChange(): void;
    private getSubscriptionBillsList;
    /**
     * @deprecated - Selection of date range and relevant methods have been moved to DateRangeModalComponent
     */
    onResetFilterDate(): void;
    /**
     * @deprecated - Selection of date range and relevant methods have been moved to DateRangeModalComponent
     */
    onDateFilterSubmit(): void;
    private buildDateFilter;
    onResetDateRange(): void;
    onDateRangeSelection(): void;
    getDateRangeFieldValue(): string;
    launchDateRangeModal(): void;
    getTrailingSubscriptionItems(result: SubscriptionBill): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionBillingListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SubscriptionBillingListComponent, "cx-billing-list", never, {}, {}, never, never, true, never>;
}

declare class DateRangeModalComponent {
    protected datePickerService: DatePickerService;
    protected launchDialogService: LaunchDialogService;
    minDate: string | null;
    maxDate: string | null;
    billsDateFilterForm: FormGroup<{
        from: FormControl<string | null>;
        to: FormControl<string | null>;
    }>;
    constructor();
    iconTypes: typeof ICON_TYPE;
    focusConfig: FocusConfig;
    onFilterDateChange(): void;
    onResetFilterDate(): void;
    onDateFilterSubmit(): void;
    onDialogClose(closingData: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateRangeModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DateRangeModalComponent, "cx-date-range-modal", never, {}, {}, never, never, true, never>;
}

declare class SubscriptionBillingListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionBillingListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SubscriptionBillingListModule, never, [typeof i2.I18nModule, typeof i2.UrlModule, typeof i2$1.ListNavigationModule, typeof i3.RouterModule, typeof i2$1.SpinnerModule, typeof i1.CommonModule, typeof i2$1.DatePickerModule, typeof i2$1.FormErrorsModule, typeof i5.ReactiveFormsModule, typeof SubscriptionBillingListComponent, typeof DateRangeModalComponent], [typeof SubscriptionBillingListComponent, typeof DateRangeModalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SubscriptionBillingListModule>;
}

declare class SubscriptionActionsModalComponentService {
    private globalMessageService;
    private eventService;
    handleError(onDialogClose?: (reason: string) => void, errorMessageKey?: string): rxjs.OperatorFunction<unknown, unknown>;
    handleSuccess(messageKey: string, onDialogClose?: (reason: string) => void, dispatchReloadEvent?: boolean): {
        next: () => void;
    };
    onError(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionActionsModalComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubscriptionActionsModalComponentService>;
}

declare class SubscriptionActionsModalComponent {
    protected actionsFacade: SubscriptionActionsFacade;
    protected launchDialogService: LaunchDialogService;
    protected destroyRef: DestroyRef;
    protected actionHandler: SubscriptionActionsModalComponentService;
    protected subscriptionDetailSignal: i0.Signal<(SubscriptionDetail & {
        code?: string;
        mode?: SubscriptionActionMode;
    }) | undefined>;
    extendDuration: number;
    isUnlimitedDurationSelected: boolean;
    isExtendSubscriptionBtnClicked: i0.WritableSignal<boolean>;
    isExtensionEffectiveDateAvailable: i0.WritableSignal<boolean>;
    extensionEffectiveDate: i0.WritableSignal<string | undefined>;
    subscriptionContractFrequency: keyof ExtendSubscriptionFrequencyDropdownOptionsConfig;
    extendFrequencyMaxOptions: ExtendSubscriptionFrequencyDropdownOptionsConfig;
    extendDurationOptions: string[];
    UNLIMITED_DURATION: string;
    mode: i0.Signal<SubscriptionActionMode>;
    subscriptionCode: i0.Signal<string>;
    cancelData: i0.WritableSignal<SubscriptionCancelData | undefined>;
    extensionData: i0.WritableSignal<SubscriptionExtensionEffectiveDate | undefined>;
    iconTypes: typeof ICON_TYPE;
    focusConfig: FocusConfig;
    constructor();
    protected initExtendDurationOptions(): void;
    protected registerSubscriptionCancellationEffect(): void;
    getExtensionEffectiveDate(): void;
    onConfirm(): void;
    onExtendActionDurationChange(durationSelected: string): void;
    onDialogClose(reason: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionActionsModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SubscriptionActionsModalComponent, "cx-subscription-actions-modal", never, {}, {}, never, never, true, never>;
}

declare class SubscriptionActionsModalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionActionsModalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SubscriptionActionsModalModule, never, [typeof SubscriptionActionsModalComponent], [typeof SubscriptionActionsModalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SubscriptionActionsModalModule>;
}

declare class SubscriptionBillingComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionBillingComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SubscriptionBillingComponentsModule, never, [typeof SubscriptionListModule, typeof SubscriptionDetailsModule, typeof SubscriptionBillingDetailsModule, typeof SubscriptionProductPriceModule, typeof SubscriptionProductUsageChargeModule, typeof SubscriptionBillingListModule, typeof SubscriptionActionsModalModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SubscriptionBillingComponentsModule>;
}

declare const subscriptionActionsPopupConfig: LayoutConfig;

export { DateRangeModalComponent, SubscriptionActionsModalComponent, SubscriptionActionsModalComponentService, SubscriptionActionsModalModule, SubscriptionBillingComponentsModule, SubscriptionBillingDetailsComponent, SubscriptionBillingDetailsModule, SubscriptionBillingListComponent, SubscriptionBillingListModule, SubscriptionDetailsComponent, SubscriptionDetailsModule, SubscriptionListComponent, SubscriptionListModule, SubscriptionProductPriceComponent, SubscriptionProductPriceModule, SubscriptionProductUsageChargeComponent, SubscriptionProductUsageChargeModule, subscriptionActionsPopupConfig };
