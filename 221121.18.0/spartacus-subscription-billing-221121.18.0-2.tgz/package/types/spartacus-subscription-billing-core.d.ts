import * as i0 from '@angular/core';
import { Provider } from '@angular/core';
import { QueryService, UserIdService, RoutingService, QueryNotifier, Query, QueryState, PageMetaResolver, PageHeadingResolver, PageTitleResolver, PageDescriptionResolver, PageBreadcrumbResolver, BasePageMetaResolver, TranslationService, BreadcrumbMeta } from '@spartacus/core';
import { SubscriptionDetail, SubscriptionList, SubscriptionCancellationDetails, SubscriptionWithdraw, SubscriptionExtensionEffectiveDate, SubscriptionBillsList, SubscriptionBill, SubscriptionFacade, SubscriptionActionsFacade, SubscriptionBillingFacade } from '@spartacus/subscription-billing/root';
import { Observable } from 'rxjs';

declare class SubscriptionBillingCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionBillingCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SubscriptionBillingCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SubscriptionBillingCoreModule>;
}

declare abstract class SubscriptionAdapter {
    abstract getSubscriptionByCode(userId: string, subscriptionCode: string): Observable<SubscriptionDetail>;
    abstract getSubscriptionList(userId: string, pageSize?: number, currentPage?: number, sort?: string): Observable<SubscriptionList>;
}

declare class SubscriptionConnector {
    protected adapter: SubscriptionAdapter;
    getSubscriptionByCode(userId: string, subscriptionCode: string): Observable<SubscriptionDetail>;
    getSubscriptionList(userId: string, pageSize?: number, currentPage?: number, sort?: string): Observable<SubscriptionList>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubscriptionConnector>;
}

declare abstract class SubscriptionActionsAdapter {
    abstract getEffectiveCancellationDate(userId: string, subscriptionCode: string): Observable<any>;
    abstract cancelSubscription(userId: string, subscriptionCode: string, cancellationDetails: SubscriptionCancellationDetails): Observable<unknown>;
    abstract reverseCancellation(userId: string, subscriptionCode: string): Observable<unknown>;
    abstract withdrawSubscription(userId: string, subscriptionCode: string, withdrawal: SubscriptionWithdraw): Observable<unknown>;
    abstract getExtensionEffectiveDate(userId: string, subscriptionCode: string, extendDuration: number, isUnlimitedDuration: boolean): Observable<SubscriptionExtensionEffectiveDate>;
    abstract extendSubscription(userId: string, subscriptionCode: string, extendDuration: number, isUnlimitedDuration: boolean): Observable<any>;
}

declare class SubscriptionActionsConnector {
    protected adapter: SubscriptionActionsAdapter;
    getEffectiveCancellationDate(userId: string, subscriptionCode: string): Observable<unknown>;
    cancelSubscription(userId: string, subscriptionCode: string, cancellationDetails: SubscriptionCancellationDetails): Observable<unknown>;
    reverseCancellation(userId: string, subscriptionCode: string): Observable<unknown>;
    withdrawSubscription(userId: string, subscriptionCode: string, withdrawalData: SubscriptionWithdraw): Observable<unknown>;
    getExtensionEffectiveDate(userId: string, subscriptionCode: string, extendDuration: number, isUnlimitedDuration: boolean): Observable<SubscriptionExtensionEffectiveDate>;
    extendSubscription(userId: string, subscriptionCode: string, extendDuration: number, isUnlimitedDuration: boolean): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionActionsConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubscriptionActionsConnector>;
}

declare abstract class SubscriptionBillingAdapter {
    abstract getSubscriptionBillsList(userId: string, pageSize?: number, currentPage?: number, sort?: string, filters?: string): Observable<SubscriptionBillsList>;
    abstract getSubscriptionBillByCode(userId: string, billId: string): Observable<SubscriptionBill>;
}

declare class SubscriptionBillingConnector {
    protected adapter: SubscriptionBillingAdapter;
    getSubscriptionBillsList(userId: string, pageSize?: number, currentPage?: number, sort?: string, filters?: string): Observable<SubscriptionBillsList>;
    getSubscriptionBillByCode(userId: string, billCode: string): Observable<SubscriptionBill>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionBillingConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubscriptionBillingConnector>;
}

declare class SubscriptionService implements SubscriptionFacade {
    protected queryService: QueryService;
    protected userIdService: UserIdService;
    protected subscriptionConnector: SubscriptionConnector;
    protected routingService: RoutingService;
    /** events */
    protected getSubscriptionByCodeReloadEvents(): QueryNotifier[];
    protected getSubscriptionListReloadEvents(): QueryNotifier[];
    /** queries */
    protected getSubscriptionByCodeQuery$: Query<SubscriptionDetail | undefined>;
    protected getSubscriptionListQuery$(pageSize: number, currentPage: number, sort: string): Query<SubscriptionList | undefined>;
    /** query states */
    getSubscriptionByCodeState(): Observable<QueryState<SubscriptionDetail | undefined>>;
    getSubscriptionListState(pageSize: number, currentPage: number, sort: string): Observable<QueryState<SubscriptionList | undefined>>;
    /** pre-conditions */
    protected subscriptionListPreConditions(): Observable<string>;
    protected subscriptionDetailsPreConditions(): Observable<[string, string]>;
    /** public methods */
    getSubscriptionCodeFromRoute(): Observable<string | undefined>;
    getSubscriptionByCode(): Observable<SubscriptionDetail | undefined>;
    getSubscriptionList(pageSize: number, currentPage: number, sort: string): Observable<SubscriptionList | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubscriptionService>;
}

declare const facadeProviders: Provider[];

declare class SubscriptionActionsService implements SubscriptionActionsFacade {
    protected queryService: QueryService;
    protected userIdService: UserIdService;
    protected subscriptionActionsConnector: SubscriptionActionsConnector;
    protected routingService: RoutingService;
    protected getSubscriptionByCodeReloadEvents(): QueryNotifier[];
    getEffectiveCancellationDate(subscriptionCode?: string): Observable<unknown>;
    cancelSubscription(cancellationDetails: SubscriptionCancellationDetails, subscriptionCode?: string): Observable<unknown>;
    reverseCancellation(subscriptionCode?: string): Observable<unknown>;
    withdrawSubscription(withdrawalData: SubscriptionWithdraw, subscriptionCode?: string): Observable<unknown>;
    getExtensionEffectiveDate(extendDuration: number, isUnlimitedDuration: boolean, code: string): Observable<SubscriptionExtensionEffectiveDate>;
    extendSubscription(extendDuration: number, isUnlimitedDuration: boolean, subscriptionCode: string): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionActionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubscriptionActionsService>;
}

declare class SubscriptionBillingService implements SubscriptionBillingFacade {
    protected queryService: QueryService;
    protected userIdService: UserIdService;
    protected routingService: RoutingService;
    protected subscriptionBillsConnector: SubscriptionBillingConnector;
    protected subscriptionBillPreConditions(): Observable<{
        userId: string;
        subscriptionBillCode: string;
    }>;
    protected getSubscriptionBillByCodeQuery$: Query<SubscriptionBill | undefined>;
    protected subscriptionBillsListPreConditions(): Observable<string>;
    protected getSubscriptionBillListQuery$(pageSize?: number, currentPage?: number, sort?: string, filter?: string): Query<SubscriptionBillsList | undefined>;
    getSubscriptionBillByCodeState(): Observable<QueryState<SubscriptionBill | undefined>>;
    getSubscriptionBillsListState(pageSize?: number, currentPage?: number, sort?: string, filter?: string): Observable<QueryState<SubscriptionBillsList | undefined>>;
    getSubscriptionBillsList(pageSize?: number, currentPage?: number, sort?: string, filters?: string): Observable<SubscriptionBillsList | undefined>;
    getSubscriptionBillByCode(): Observable<SubscriptionBill | undefined>;
    getSubscriptionBillCodeFromRoute(): Observable<string | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionBillingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubscriptionBillingService>;
}

declare class SubscriptionDetailsPageMetaResolver extends PageMetaResolver implements PageHeadingResolver, PageTitleResolver, PageDescriptionResolver, PageBreadcrumbResolver {
    protected basePageMetaResolver: BasePageMetaResolver;
    protected translation: TranslationService;
    constructor(basePageMetaResolver: BasePageMetaResolver, translation: TranslationService);
    resolveHeading(): Observable<string | undefined>;
    resolveTitle(): Observable<string | undefined>;
    resolveDescription(): Observable<string | undefined>;
    resolveBreadcrumbs(): Observable<BreadcrumbMeta[] | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionDetailsPageMetaResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubscriptionDetailsPageMetaResolver>;
}

declare class SubscriptionBillingDetailsPageMetaResolver extends PageMetaResolver implements PageHeadingResolver, PageTitleResolver, PageDescriptionResolver, PageBreadcrumbResolver {
    protected basePageMetaResolver: BasePageMetaResolver;
    protected translation: TranslationService;
    constructor(basePageMetaResolver: BasePageMetaResolver, translation: TranslationService);
    resolveHeading(): Observable<string | undefined>;
    resolveTitle(): Observable<string | undefined>;
    resolveDescription(): Observable<string | undefined>;
    resolveBreadcrumbs(): Observable<BreadcrumbMeta[] | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionBillingDetailsPageMetaResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubscriptionBillingDetailsPageMetaResolver>;
}

export { SubscriptionActionsAdapter, SubscriptionActionsConnector, SubscriptionActionsService, SubscriptionAdapter, SubscriptionBillingAdapter, SubscriptionBillingConnector, SubscriptionBillingCoreModule, SubscriptionBillingDetailsPageMetaResolver, SubscriptionBillingService, SubscriptionConnector, SubscriptionDetailsPageMetaResolver, SubscriptionService, facadeProviders };
