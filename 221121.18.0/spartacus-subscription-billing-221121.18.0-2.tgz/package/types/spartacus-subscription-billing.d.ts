import * as i0 from '@angular/core';
import * as i1 from '@spartacus/subscription-billing/components';
import * as i2 from '@spartacus/subscription-billing/core';
import * as i3 from '@spartacus/subscription-billing/occ';

declare class SubscriptionBillingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SubscriptionBillingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SubscriptionBillingModule, never, [typeof i1.SubscriptionBillingComponentsModule, typeof i2.SubscriptionBillingCoreModule, typeof i3.SubscriptionBillingOccModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SubscriptionBillingModule>;
}

export { SubscriptionBillingModule };
