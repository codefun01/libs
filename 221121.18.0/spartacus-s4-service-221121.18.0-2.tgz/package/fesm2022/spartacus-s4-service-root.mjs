import * as i1 from '@spartacus/core';
import { Config, facadeFactory, BaseSiteService, CxDatePipe, TimeUtils, PriceType, provideDefaultConfig, provideDefaultConfigFactory } from '@spartacus/core';
import * as i0 from '@angular/core';
import { Injectable, NgModule, inject } from '@angular/core';
import { CheckoutStepType, DeliveryModePreferences, CheckoutEvent, CheckoutQueryResetEvent, CHECKOUT_CORE_FEATURE, CHECKOUT_FEATURE, CheckoutConfig } from '@spartacus/checkout/base/root';
import { CHECKOUT_B2B_CMS_COMPONENTS } from '@spartacus/checkout/b2b/root';
import { Subscription } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { ORDER_FEATURE, ORDER_CMS_COMPONENTS } from '@spartacus/order/root';
import * as i1$1 from '@angular/router';
import { RouterModule } from '@angular/router';
import { PageLayoutComponent, CmsPageGuard } from '@spartacus/storefront';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ServiceOrderConfiguration {
}
CheckoutStepType['SERVICE_DETAILS'] = 'serviceDetails';
class S4ServiceDeliveryModeConfig {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: S4ServiceDeliveryModeConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: S4ServiceDeliveryModeConfig, providedIn: 'root', useExisting: Config }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: S4ServiceDeliveryModeConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useExisting: Config,
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultServiceOrdersRoutingConfig = {
    routing: {
        routes: {
            checkoutServiceDetails: { paths: ['checkout/service-details'] },
            cancelServiceDetails: {
                paths: ['my-account/order/cancelservice/:orderCode'],
                paramsMapping: { orderCode: 'code' },
            },
            rescheduleServiceDetails: {
                paths: ['my-account/order/rescheduleservice/:orderCode'],
                paramsMapping: { orderCode: 'code' },
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultServiceDetailsCheckoutConfig = {
    checkout: {
        steps: [
            {
                id: 'paymentType',
                name: 'checkoutB2B.progress.methodOfPayment',
                routeName: 'checkoutPaymentType',
                type: [CheckoutStepType.PAYMENT_TYPE],
            },
            {
                id: 'deliveryAddress',
                name: 'checkoutProgress.deliveryAddress',
                routeName: 'checkoutDeliveryAddress',
                type: [CheckoutStepType.DELIVERY_ADDRESS],
            },
            {
                id: 'deliveryMode',
                name: 'checkoutProgress.deliveryMode',
                routeName: 'checkoutDeliveryMode',
                type: [CheckoutStepType.DELIVERY_MODE],
            },
            {
                id: 'paymentDetails',
                name: 'checkoutProgress.paymentDetails',
                routeName: 'checkoutPaymentDetails',
                type: [CheckoutStepType.PAYMENT_DETAILS],
            },
            {
                id: 'serviceDetails',
                name: 'serviceOrderCheckout.serviceDetails',
                routeName: 'checkoutServiceDetails',
                type: [CheckoutStepType.SERVICE_DETAILS],
            },
            {
                id: 'reviewOrder',
                name: 'checkoutProgress.reviewOrder',
                routeName: 'checkoutReviewOrder',
                type: [CheckoutStepType.REVIEW_ORDER],
            },
        ],
        express: false,
        defaultDeliveryMode: [DeliveryModePreferences.FREE],
        guest: false,
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * An abstract event for all the service details related events.
 */
class CheckoutServiceDetailsEvent extends CheckoutEvent {
}
/**
 * Fired when the service details has been set
 */
class CheckoutServiceDetailsSetEvent extends CheckoutServiceDetailsEvent {
    /**
     * Event's type
     */
    static { this.type = 'CheckoutServiceDetailsSetEvent'; }
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CheckoutServiceDetailsEventListener {
    constructor(eventService) {
        this.eventService = eventService;
        this.subscriptions = new Subscription();
        this.onServiceDetailsSet();
    }
    onServiceDetailsSet() {
        this.subscriptions.add(this.eventService.get(CheckoutServiceDetailsSetEvent).subscribe(() => {
            this.eventService.dispatch({}, CheckoutQueryResetEvent);
        }));
    }
    ngOnDestroy() {
        this.subscriptions.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutServiceDetailsEventListener, deps: [{ token: i1.EventService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutServiceDetailsEventListener, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutServiceDetailsEventListener, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.EventService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CheckoutServiceDetailsEventModule {
    constructor(_checkoutServiceDetailsEventListener) {
        // Intentional empty constructor
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutServiceDetailsEventModule, deps: [{ token: CheckoutServiceDetailsEventListener }], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CheckoutServiceDetailsEventModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutServiceDetailsEventModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutServiceDetailsEventModule, decorators: [{
            type: NgModule,
            args: [{}]
        }], ctorParameters: () => [{ type: CheckoutServiceDetailsEventListener }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CheckoutServiceDetailsFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutServiceDetailsFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutServiceDetailsFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: CheckoutServiceDetailsFacade,
            feature: CHECKOUT_CORE_FEATURE,
            methods: [
                'setServiceScheduleSlot',
                'getSelectedServiceDetailsState',
                'getServiceProducts',
                'hasServiceItems',
                'hasNonServiceItems',
            ],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutServiceDetailsFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: CheckoutServiceDetailsFacade,
                        feature: CHECKOUT_CORE_FEATURE,
                        methods: [
                            'setServiceScheduleSlot',
                            'getSelectedServiceDetailsState',
                            'getServiceProducts',
                            'hasServiceItems',
                            'hasNonServiceItems',
                        ],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const dateFormat = 'yyyy-MM-dd';
class CheckoutServiceSchedulePickerService {
    constructor() {
        this.baseSiteService = inject(BaseSiteService);
        this.datePipe = inject(CxDatePipe);
    }
    /**
     * Returns the minimum date for scheduling a service.
     * It is the current date + lead days from the base site configuration.
     */
    getMinDateForService() {
        return this.getServiceOrderConfiguration().pipe(map((config) => {
            const minDate = new Date();
            minDate.setDate(minDate.getDate() + (config?.leadDays ?? 0) + 1);
            return this.datePipe.transform(minDate, dateFormat) ?? '';
        }));
    }
    /**
     * Returns an array of service schedule times in HH:MM format (24-hour clock).
     * Example: ['08:00', '12:00', '16:00']
     */
    getScheduledServiceTimes() {
        return this.getServiceOrderConfiguration().pipe(map((config) => config?.serviceScheduleTimes ?? []));
    }
    /**
     * Retrieves the Service Order Configuration object with lead days and service schedule times.
     * This method returns an observable since it depends on asynchronous data.
     */
    getServiceOrderConfiguration() {
        return this.baseSiteService.get().pipe(take(1), map((baseSite) => {
            const config = { leadDays: 0, serviceScheduleTimes: [] };
            config.leadDays =
                baseSite?.baseStore?.serviceOrderConfiguration?.leadDays ?? 0;
            config.serviceScheduleTimes =
                baseSite?.baseStore?.serviceOrderConfiguration
                    ?.serviceScheduleTimes ?? [];
            return config;
        }));
    }
    /**
     * Converts a date and time string into DateTime format including timezone offset.
     * @param date Date in YYYY-MM-DD format. Example: '2024-06-27'
     * @param time Time in HH:MM format (24-hour clock). Example: '14:30'
     * @returns String in DateTime format with timezone offset.
     * Example: 2024-06-27T14:30:00±HH:MM (based on your local timezone offset)
     */
    convertToDateTime(date, time) {
        const dateTimeString = `${date}T${time}:00`;
        const timezoneOffset = TimeUtils.getLocalTimezoneOffset();
        return `${dateTimeString}${timezoneOffset}`;
    }
    /**
     * Converts a DateTime string with timezone offset into a readable string format.
     * @param dateTime String in DateTime format with timezone offset.
     * Example: 2024-07-11T14:30:00+05:30
     * @returns Readable string format. Example: 11/07/2024, 02:30:00 PM
     */
    convertDateTimeToReadableString(dateTime) {
        const date = new Date(dateTime);
        return date.toLocaleString();
    }
    /**
     * Converts a string containing both date and time into an object with separate properties - date and time.
     * @param input Date and time in format `MM/DD/YYYY, HH:mm:ss`
     * @returns Object with date and time separately as { date: 'YYYY-MM-DD', time: 'HH:mm' }
     */
    getServiceDetailsFromDateTime(input) {
        const inputDate = new Date(input);
        const hours = inputDate.getHours().toString().padStart(2, '0');
        const minutes = inputDate.getMinutes().toString().padStart(2, '0');
        return {
            date: this.datePipe.transform(inputDate, dateFormat) ?? '',
            time: `${hours}:${minutes}`,
        };
    }
    /**
     * Calculates the difference in hours between a scheduled date of a service and the current date.
     * @param dateTime The dateTime to check in string format.
     * @returns Number representing the difference in hours.
     */
    getHoursFromServiceSchedule(dateTime) {
        const now = new Date();
        const targetDateTime = new Date(dateTime);
        const differenceInMilliseconds = targetDateTime.getTime() - now.getTime();
        return differenceInMilliseconds / (1000 * 60 * 60);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutServiceSchedulePickerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutServiceSchedulePickerService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutServiceSchedulePickerService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CancelServiceOrderFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CancelServiceOrderFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CancelServiceOrderFacade, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CancelServiceOrderFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class RescheduleServiceOrderFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RescheduleServiceOrderFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RescheduleServiceOrderFacade, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RescheduleServiceOrderFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultServiceDeliveryModeConfig = {
    s4ServiceDeliveryMode: {
        code: 'service-delivery',
        deliveryCost: {
            currencyIso: 'USD',
            formattedValue: 'USD0.00',
            priceType: PriceType.BUY,
            value: 0,
        },
        description: 'Not applicable',
        name: 'No Delivery Charges for Service',
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const S4_SERVICE_CMS_COMPONENTS = [
    ...CHECKOUT_B2B_CMS_COMPONENTS,
    'CheckoutServiceDetails',
];
const S4_SERVICE_ORDER_CMS_COMPONENTS = [
    'RescheduleServiceOrder',
    'CancelServiceOrderHeadline',
    'CancelServiceOrder',
];
function defaultS4ServiceComponentsConfig() {
    const config = {
        featureModules: {
            [CHECKOUT_FEATURE]: {
                cmsComponents: S4_SERVICE_CMS_COMPONENTS,
            },
            [ORDER_FEATURE]: {
                cmsComponents: [
                    ...ORDER_CMS_COMPONENTS,
                    ...S4_SERVICE_ORDER_CMS_COMPONENTS,
                ],
            },
        },
    };
    return config;
}
class S4ServiceRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: S4ServiceRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: S4ServiceRootModule, imports: [CheckoutServiceDetailsEventModule, i1$1.RouterModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: S4ServiceRootModule, providers: [
            { provide: CheckoutConfig, useValue: defaultServiceDetailsCheckoutConfig },
            provideDefaultConfig(defaultServiceOrdersRoutingConfig),
            provideDefaultConfig(defaultServiceDeliveryModeConfig),
            provideDefaultConfigFactory(defaultS4ServiceComponentsConfig),
            CxDatePipe,
            CheckoutServiceSchedulePickerService,
        ], imports: [CheckoutServiceDetailsEventModule,
            RouterModule.forChild([
                {
                    path: '',
                    canActivate: [CmsPageGuard],
                    component: PageLayoutComponent,
                    data: { cxRoute: 'cancelServiceDetails' },
                },
                {
                    path: '',
                    canActivate: [CmsPageGuard],
                    component: PageLayoutComponent,
                    data: { cxRoute: 'rescheduleServiceDetails' },
                },
            ])] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: S4ServiceRootModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CheckoutServiceDetailsEventModule,
                        RouterModule.forChild([
                            {
                                path: '',
                                canActivate: [CmsPageGuard],
                                component: PageLayoutComponent,
                                data: { cxRoute: 'cancelServiceDetails' },
                            },
                            {
                                path: '',
                                canActivate: [CmsPageGuard],
                                component: PageLayoutComponent,
                                data: { cxRoute: 'rescheduleServiceDetails' },
                            },
                        ]),
                    ],
                    providers: [
                        { provide: CheckoutConfig, useValue: defaultServiceDetailsCheckoutConfig },
                        provideDefaultConfig(defaultServiceOrdersRoutingConfig),
                        provideDefaultConfig(defaultServiceDeliveryModeConfig),
                        provideDefaultConfigFactory(defaultS4ServiceComponentsConfig),
                        CxDatePipe,
                        CheckoutServiceSchedulePickerService,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const S4_SERVICE_FEATURE = 's4-service';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CancelServiceOrderFacade, CheckoutServiceDetailsEvent, CheckoutServiceDetailsEventListener, CheckoutServiceDetailsEventModule, CheckoutServiceDetailsFacade, CheckoutServiceDetailsSetEvent, CheckoutServiceSchedulePickerService, RescheduleServiceOrderFacade, S4ServiceDeliveryModeConfig, S4ServiceRootModule, S4_SERVICE_CMS_COMPONENTS, S4_SERVICE_FEATURE, S4_SERVICE_ORDER_CMS_COMPONENTS, ServiceOrderConfiguration, defaultS4ServiceComponentsConfig, defaultServiceDetailsCheckoutConfig, defaultServiceOrdersRoutingConfig };
//# sourceMappingURL=spartacus-s4-service-root.mjs.map
