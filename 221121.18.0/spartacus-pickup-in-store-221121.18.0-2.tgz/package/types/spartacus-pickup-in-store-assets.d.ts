import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    pickupInStore: {
        pickupInfo: {
            inStorePickup: string;
            pickupBy: string;
            pickupFrom: string;
        };
        pickupOptionDialog: {
            close: string;
            modalHeader: string;
        };
        pickupOptions: {
            legend: string;
            changeStore: string;
            delivery: string;
            pickup: string;
            shipIt: string;
            selectStore: string;
            freeReturn: string;
            storeIsNotSelected: string;
        };
        setPreferredStore: {
            makeThisMyStore: string;
            myStore: string;
        };
        store: {
            pickupFromHere: string;
            stockLevel_inStock: string;
            stockLevel_outOfStock: string;
            viewHours: string;
        };
        storeList: {
            noStoresMessage: string;
        };
        storeSchedule: {
            closed: string;
            storeHours: string;
        };
        storeSearch: {
            findAStore: string;
            findStores: string;
            hideOutOfStockOptions: string;
            searchPlaceholder: string;
            useMyLocation: string;
        };
        addressBookPickupInStore: {
            heading: string;
        };
        storeFinderPickupInStore: {
            heading: string;
        };
        checkoutPickupInStore: {
            heading: string;
            storeItemHeading: string;
        };
        cardActions: {
            getDirections: string;
        };
        deliveryPointOfServiceDetails: {
            itemsToBePickUp: string;
            pickUpInStoreAddress: string;
            itemsToBeShipped: string;
            shippingAddress: string;
            deliveryMethod: string;
            deliveryOptions: string;
            statusDisplay_cancelled: string;
            statusDisplay_cancelling: string;
            statusDisplay_completed: string;
            statusDisplay_created: string;
            statusDisplay_error: string;
            statusDisplay_Error: string;
            statusDisplay_processing: string;
            statusDisplay_open: string;
            statusDisplay_pending: {
                approval: string;
                merchant: {
                    approval: string;
                };
            };
            statusDisplay_approved: string;
            statusDisplay_rejected: string;
            statusDisplay_merchant: {
                approved: string;
                rejected: string;
            };
            statusDisplay_assigned: {
                admin: string;
            };
        };
    };
};

declare const de: {
    pickupInStore: {
        pickupInfo: {
            inStorePickup: string;
            pickupBy: string;
            pickupFrom: string;
        };
        pickupOptionDialog: {
            close: string;
            modalHeader: string;
        };
        pickupOptions: {
            legend: string;
            changeStore: string;
            delivery: string;
            pickup: string;
            shipIt: string;
            selectStore: string;
            freeReturn: string;
            storeIsNotSelected: string;
        };
        setPreferredStore: {
            makeThisMyStore: string;
            myStore: string;
        };
        store: {
            pickupFromHere: string;
            stockLevel_inStock: string;
            stockLevel_outOfStock: string;
            viewHours: string;
        };
        storeList: {
            noStoresMessage: string;
        };
        storeSchedule: {
            closed: string;
            storeHours: string;
        };
        storeSearch: {
            findAStore: string;
            findStores: string;
            hideOutOfStockOptions: string;
            searchPlaceholder: string;
            useMyLocation: string;
        };
        addressBookPickupInStore: {
            heading: string;
        };
        storeFinderPickupInStore: {
            heading: string;
        };
        checkoutPickupInStore: {
            heading: string;
            storeItemHeading: string;
        };
        cardActions: {
            getDirections: string;
        };
        deliveryPointOfServiceDetails: {
            itemsToBePickUp: string;
            pickUpInStoreAddress: string;
            itemsToBeShipped: string;
            shippingAddress: string;
            deliveryMethod: string;
            deliveryOptions: string;
            statusDisplay_cancelled: string;
            statusDisplay_cancelling: string;
            statusDisplay_completed: string;
            statusDisplay_created: string;
            statusDisplay_error: string;
            statusDisplay_Error: string;
            statusDisplay_processing: string;
            statusDisplay_open: string;
            statusDisplay_pending: {
                approval: string;
                merchant: {
                    approval: string;
                };
            };
            statusDisplay_approved: string;
            statusDisplay_rejected: string;
            statusDisplay_merchant: {
                approved: string;
                rejected: string;
            };
            statusDisplay_assigned: {
                admin: string;
            };
        };
    };
};

declare const en: {
    pickupInStore: {
        pickupInfo: {
            inStorePickup: string;
            pickupBy: string;
            pickupFrom: string;
        };
        pickupOptionDialog: {
            close: string;
            modalHeader: string;
        };
        pickupOptions: {
            legend: string;
            changeStore: string;
            delivery: string;
            pickup: string;
            shipIt: string;
            selectStore: string;
            freeReturn: string;
            storeIsNotSelected: string;
        };
        setPreferredStore: {
            makeThisMyStore: string;
            myStore: string;
        };
        store: {
            pickupFromHere: string;
            stockLevel_inStock: string;
            stockLevel_outOfStock: string;
            viewHours: string;
        };
        storeList: {
            noStoresMessage: string;
        };
        storeSchedule: {
            closed: string;
            storeHours: string;
        };
        storeSearch: {
            findAStore: string;
            findStores: string;
            hideOutOfStockOptions: string;
            searchPlaceholder: string;
            useMyLocation: string;
        };
        addressBookPickupInStore: {
            heading: string;
        };
        storeFinderPickupInStore: {
            heading: string;
        };
        checkoutPickupInStore: {
            heading: string;
            storeItemHeading: string;
        };
        cardActions: {
            getDirections: string;
        };
        deliveryPointOfServiceDetails: {
            itemsToBePickUp: string;
            pickUpInStoreAddress: string;
            itemsToBeShipped: string;
            shippingAddress: string;
            deliveryMethod: string;
            deliveryOptions: string;
            statusDisplay_cancelled: string;
            statusDisplay_cancelling: string;
            statusDisplay_completed: string;
            statusDisplay_created: string;
            statusDisplay_error: string;
            statusDisplay_Error: string;
            statusDisplay_processing: string;
            statusDisplay_open: string;
            statusDisplay_pending: {
                approval: string;
                merchant: {
                    approval: string;
                };
            };
            statusDisplay_approved: string;
            statusDisplay_rejected: string;
            statusDisplay_merchant: {
                approved: string;
                rejected: string;
            };
            statusDisplay_assigned: {
                admin: string;
            };
        };
    };
};

declare const es: {
    pickupInStore: {
        pickupInfo: {
            inStorePickup: string;
            pickupBy: string;
            pickupFrom: string;
        };
        pickupOptionDialog: {
            close: string;
            modalHeader: string;
        };
        pickupOptions: {
            legend: string;
            changeStore: string;
            delivery: string;
            pickup: string;
            shipIt: string;
            selectStore: string;
            freeReturn: string;
            storeIsNotSelected: string;
        };
        setPreferredStore: {
            makeThisMyStore: string;
            myStore: string;
        };
        store: {
            pickupFromHere: string;
            stockLevel_inStock: string;
            stockLevel_outOfStock: string;
            viewHours: string;
        };
        storeList: {
            noStoresMessage: string;
        };
        storeSchedule: {
            closed: string;
            storeHours: string;
        };
        storeSearch: {
            findAStore: string;
            findStores: string;
            hideOutOfStockOptions: string;
            searchPlaceholder: string;
            useMyLocation: string;
        };
        addressBookPickupInStore: {
            heading: string;
        };
        storeFinderPickupInStore: {
            heading: string;
        };
        checkoutPickupInStore: {
            heading: string;
            storeItemHeading: string;
        };
        cardActions: {
            getDirections: string;
        };
        deliveryPointOfServiceDetails: {
            itemsToBePickUp: string;
            pickUpInStoreAddress: string;
            itemsToBeShipped: string;
            shippingAddress: string;
            deliveryMethod: string;
            deliveryOptions: string;
            statusDisplay_cancelled: string;
            statusDisplay_cancelling: string;
            statusDisplay_completed: string;
            statusDisplay_created: string;
            statusDisplay_error: string;
            statusDisplay_Error: string;
            statusDisplay_processing: string;
            statusDisplay_open: string;
            statusDisplay_pending: {
                approval: string;
                merchant: {
                    approval: string;
                };
            };
            statusDisplay_approved: string;
            statusDisplay_rejected: string;
            statusDisplay_merchant: {
                approved: string;
                rejected: string;
            };
            statusDisplay_assigned: {
                admin: string;
            };
        };
    };
};

declare const es_CO: {
    pickupInStore: {
        pickupInfo: {
            inStorePickup: string;
            pickupBy: string;
            pickupFrom: string;
        };
        pickupOptionDialog: {
            close: string;
            modalHeader: string;
        };
        pickupOptions: {
            legend: string;
            changeStore: string;
            delivery: string;
            pickup: string;
            shipIt: string;
            selectStore: string;
            freeReturn: string;
            storeIsNotSelected: string;
        };
        setPreferredStore: {
            makeThisMyStore: string;
            myStore: string;
        };
        store: {
            pickupFromHere: string;
            stockLevel_inStock: string;
            stockLevel_outOfStock: string;
            viewHours: string;
        };
        storeList: {
            noStoresMessage: string;
        };
        storeSchedule: {
            closed: string;
            storeHours: string;
        };
        storeSearch: {
            findAStore: string;
            findStores: string;
            hideOutOfStockOptions: string;
            searchPlaceholder: string;
            useMyLocation: string;
        };
        addressBookPickupInStore: {
            heading: string;
        };
        storeFinderPickupInStore: {
            heading: string;
        };
        checkoutPickupInStore: {
            heading: string;
            storeItemHeading: string;
        };
        cardActions: {
            getDirections: string;
        };
        deliveryPointOfServiceDetails: {
            itemsToBePickUp: string;
            pickUpInStoreAddress: string;
            itemsToBeShipped: string;
            shippingAddress: string;
            deliveryMethod: string;
            deliveryOptions: string;
            statusDisplay_cancelled: string;
            statusDisplay_cancelling: string;
            statusDisplay_completed: string;
            statusDisplay_created: string;
            statusDisplay_error: string;
            statusDisplay_Error: string;
            statusDisplay_processing: string;
            statusDisplay_open: string;
            statusDisplay_pending: {
                approval: string;
                merchant: {
                    approval: string;
                };
            };
            statusDisplay_approved: string;
            statusDisplay_rejected: string;
            statusDisplay_merchant: {
                approved: string;
                rejected: string;
            };
            statusDisplay_assigned: {
                admin: string;
            };
        };
    };
};

declare const fr: {
    pickupInStore: {
        pickupInfo: {
            inStorePickup: string;
            pickupBy: string;
            pickupFrom: string;
        };
        pickupOptionDialog: {
            close: string;
            modalHeader: string;
        };
        pickupOptions: {
            legend: string;
            changeStore: string;
            delivery: string;
            pickup: string;
            shipIt: string;
            selectStore: string;
            freeReturn: string;
            storeIsNotSelected: string;
        };
        setPreferredStore: {
            makeThisMyStore: string;
            myStore: string;
        };
        store: {
            pickupFromHere: string;
            stockLevel_inStock: string;
            stockLevel_outOfStock: string;
            viewHours: string;
        };
        storeList: {
            noStoresMessage: string;
        };
        storeSchedule: {
            closed: string;
            storeHours: string;
        };
        storeSearch: {
            findAStore: string;
            findStores: string;
            hideOutOfStockOptions: string;
            searchPlaceholder: string;
            useMyLocation: string;
        };
        addressBookPickupInStore: {
            heading: string;
        };
        storeFinderPickupInStore: {
            heading: string;
        };
        checkoutPickupInStore: {
            heading: string;
            storeItemHeading: string;
        };
        cardActions: {
            getDirections: string;
        };
        deliveryPointOfServiceDetails: {
            itemsToBePickUp: string;
            pickUpInStoreAddress: string;
            itemsToBeShipped: string;
            shippingAddress: string;
            deliveryMethod: string;
            deliveryOptions: string;
            statusDisplay_cancelled: string;
            statusDisplay_cancelling: string;
            statusDisplay_completed: string;
            statusDisplay_created: string;
            statusDisplay_error: string;
            statusDisplay_Error: string;
            statusDisplay_processing: string;
            statusDisplay_open: string;
            statusDisplay_pending: {
                approval: string;
                merchant: {
                    approval: string;
                };
            };
            statusDisplay_approved: string;
            statusDisplay_rejected: string;
            statusDisplay_merchant: {
                approved: string;
                rejected: string;
            };
            statusDisplay_assigned: {
                admin: string;
            };
        };
    };
};

declare const hi: {
    pickupInStore: {
        pickupInfo: {
            inStorePickup: string;
            pickupBy: string;
            pickupFrom: string;
        };
        pickupOptionDialog: {
            close: string;
            modalHeader: string;
        };
        pickupOptions: {
            legend: string;
            changeStore: string;
            delivery: string;
            pickup: string;
            shipIt: string;
            selectStore: string;
            freeReturn: string;
            storeIsNotSelected: string;
        };
        setPreferredStore: {
            makeThisMyStore: string;
            myStore: string;
        };
        store: {
            pickupFromHere: string;
            stockLevel_inStock: string;
            stockLevel_outOfStock: string;
            viewHours: string;
        };
        storeList: {
            noStoresMessage: string;
        };
        storeSchedule: {
            closed: string;
            storeHours: string;
        };
        storeSearch: {
            findAStore: string;
            findStores: string;
            hideOutOfStockOptions: string;
            searchPlaceholder: string;
            useMyLocation: string;
        };
        addressBookPickupInStore: {
            heading: string;
        };
        storeFinderPickupInStore: {
            heading: string;
        };
        checkoutPickupInStore: {
            heading: string;
            storeItemHeading: string;
        };
        cardActions: {
            getDirections: string;
        };
        deliveryPointOfServiceDetails: {
            itemsToBePickUp: string;
            pickUpInStoreAddress: string;
            itemsToBeShipped: string;
            shippingAddress: string;
            deliveryMethod: string;
            deliveryOptions: string;
            statusDisplay_cancelled: string;
            statusDisplay_cancelling: string;
            statusDisplay_completed: string;
            statusDisplay_created: string;
            statusDisplay_error: string;
            statusDisplay_Error: string;
            statusDisplay_processing: string;
            statusDisplay_open: string;
            statusDisplay_pending: {
                approval: string;
                merchant: {
                    approval: string;
                };
            };
            statusDisplay_approved: string;
            statusDisplay_rejected: string;
            statusDisplay_merchant: {
                approved: string;
                rejected: string;
            };
            statusDisplay_assigned: {
                admin: string;
            };
        };
    };
};

declare const hu: {
    pickupInStore: {
        pickupInfo: {
            inStorePickup: string;
            pickupBy: string;
            pickupFrom: string;
        };
        pickupOptionDialog: {
            close: string;
            modalHeader: string;
        };
        pickupOptions: {
            legend: string;
            changeStore: string;
            delivery: string;
            pickup: string;
            shipIt: string;
            selectStore: string;
            freeReturn: string;
            storeIsNotSelected: string;
        };
        setPreferredStore: {
            makeThisMyStore: string;
            myStore: string;
        };
        store: {
            pickupFromHere: string;
            stockLevel_inStock: string;
            stockLevel_outOfStock: string;
            viewHours: string;
        };
        storeList: {
            noStoresMessage: string;
        };
        storeSchedule: {
            closed: string;
            storeHours: string;
        };
        storeSearch: {
            findAStore: string;
            findStores: string;
            hideOutOfStockOptions: string;
            searchPlaceholder: string;
            useMyLocation: string;
        };
        addressBookPickupInStore: {
            heading: string;
        };
        storeFinderPickupInStore: {
            heading: string;
        };
        checkoutPickupInStore: {
            heading: string;
            storeItemHeading: string;
        };
        cardActions: {
            getDirections: string;
        };
        deliveryPointOfServiceDetails: {
            itemsToBePickUp: string;
            pickUpInStoreAddress: string;
            itemsToBeShipped: string;
            shippingAddress: string;
            deliveryMethod: string;
            deliveryOptions: string;
            statusDisplay_cancelled: string;
            statusDisplay_cancelling: string;
            statusDisplay_completed: string;
            statusDisplay_created: string;
            statusDisplay_error: string;
            statusDisplay_Error: string;
            statusDisplay_processing: string;
            statusDisplay_open: string;
            statusDisplay_pending: {
                approval: string;
                merchant: {
                    approval: string;
                };
            };
            statusDisplay_approved: string;
            statusDisplay_rejected: string;
            statusDisplay_merchant: {
                approved: string;
                rejected: string;
            };
            statusDisplay_assigned: {
                admin: string;
            };
        };
    };
};

declare const id: {
    pickupInStore: {
        pickupInfo: {
            inStorePickup: string;
            pickupBy: string;
            pickupFrom: string;
        };
        pickupOptionDialog: {
            close: string;
            modalHeader: string;
        };
        pickupOptions: {
            legend: string;
            changeStore: string;
            delivery: string;
            pickup: string;
            shipIt: string;
            selectStore: string;
            freeReturn: string;
            storeIsNotSelected: string;
        };
        setPreferredStore: {
            makeThisMyStore: string;
            myStore: string;
        };
        store: {
            pickupFromHere: string;
            stockLevel_inStock: string;
            stockLevel_outOfStock: string;
            viewHours: string;
        };
        storeList: {
            noStoresMessage: string;
        };
        storeSchedule: {
            closed: string;
            storeHours: string;
        };
        storeSearch: {
            findAStore: string;
            findStores: string;
            hideOutOfStockOptions: string;
            searchPlaceholder: string;
            useMyLocation: string;
        };
        addressBookPickupInStore: {
            heading: string;
        };
        storeFinderPickupInStore: {
            heading: string;
        };
        checkoutPickupInStore: {
            heading: string;
            storeItemHeading: string;
        };
        cardActions: {
            getDirections: string;
        };
        deliveryPointOfServiceDetails: {
            itemsToBePickUp: string;
            pickUpInStoreAddress: string;
            itemsToBeShipped: string;
            shippingAddress: string;
            deliveryMethod: string;
            deliveryOptions: string;
            statusDisplay_cancelled: string;
            statusDisplay_cancelling: string;
            statusDisplay_completed: string;
            statusDisplay_created: string;
            statusDisplay_error: string;
            statusDisplay_Error: string;
            statusDisplay_processing: string;
            statusDisplay_open: string;
            statusDisplay_pending: {
                approval: string;
                merchant: {
                    approval: string;
                };
            };
            statusDisplay_approved: string;
            statusDisplay_rejected: string;
            statusDisplay_merchant: {
                approved: string;
                rejected: string;
            };
            statusDisplay_assigned: {
                admin: string;
            };
        };
    };
};

declare const it: {
    pickupInStore: {
        pickupInfo: {
            inStorePickup: string;
            pickupBy: string;
            pickupFrom: string;
        };
        pickupOptionDialog: {
            close: string;
            modalHeader: string;
        };
        pickupOptions: {
            legend: string;
            changeStore: string;
            delivery: string;
            pickup: string;
            shipIt: string;
            selectStore: string;
            freeReturn: string;
            storeIsNotSelected: string;
        };
        setPreferredStore: {
            makeThisMyStore: string;
            myStore: string;
        };
        store: {
            pickupFromHere: string;
            stockLevel_inStock: string;
            stockLevel_outOfStock: string;
            viewHours: string;
        };
        storeList: {
            noStoresMessage: string;
        };
        storeSchedule: {
            closed: string;
            storeHours: string;
        };
        storeSearch: {
            findAStore: string;
            findStores: string;
            hideOutOfStockOptions: string;
            searchPlaceholder: string;
            useMyLocation: string;
        };
        addressBookPickupInStore: {
            heading: string;
        };
        storeFinderPickupInStore: {
            heading: string;
        };
        checkoutPickupInStore: {
            heading: string;
            storeItemHeading: string;
        };
        cardActions: {
            getDirections: string;
        };
        deliveryPointOfServiceDetails: {
            itemsToBePickUp: string;
            pickUpInStoreAddress: string;
            itemsToBeShipped: string;
            shippingAddress: string;
            deliveryMethod: string;
            deliveryOptions: string;
            statusDisplay_cancelled: string;
            statusDisplay_cancelling: string;
            statusDisplay_completed: string;
            statusDisplay_created: string;
            statusDisplay_error: string;
            statusDisplay_Error: string;
            statusDisplay_processing: string;
            statusDisplay_open: string;
            statusDisplay_pending: {
                approval: string;
                merchant: {
                    approval: string;
                };
            };
            statusDisplay_approved: string;
            statusDisplay_rejected: string;
            statusDisplay_merchant: {
                approved: string;
                rejected: string;
            };
            statusDisplay_assigned: {
                admin: string;
            };
        };
    };
};

declare const ja: {
    pickupInStore: {
        pickupInfo: {
            inStorePickup: string;
            pickupBy: string;
            pickupFrom: string;
        };
        pickupOptionDialog: {
            close: string;
            modalHeader: string;
        };
        pickupOptions: {
            legend: string;
            changeStore: string;
            delivery: string;
            pickup: string;
            shipIt: string;
            selectStore: string;
            freeReturn: string;
            storeIsNotSelected: string;
        };
        setPreferredStore: {
            makeThisMyStore: string;
            myStore: string;
        };
        store: {
            pickupFromHere: string;
            stockLevel_inStock: string;
            stockLevel_outOfStock: string;
            viewHours: string;
        };
        storeList: {
            noStoresMessage: string;
        };
        storeSchedule: {
            closed: string;
            storeHours: string;
        };
        storeSearch: {
            findAStore: string;
            findStores: string;
            hideOutOfStockOptions: string;
            searchPlaceholder: string;
            useMyLocation: string;
        };
        addressBookPickupInStore: {
            heading: string;
        };
        storeFinderPickupInStore: {
            heading: string;
        };
        checkoutPickupInStore: {
            heading: string;
            storeItemHeading: string;
        };
        cardActions: {
            getDirections: string;
        };
        deliveryPointOfServiceDetails: {
            itemsToBePickUp: string;
            pickUpInStoreAddress: string;
            itemsToBeShipped: string;
            shippingAddress: string;
            deliveryMethod: string;
            deliveryOptions: string;
            statusDisplay_cancelled: string;
            statusDisplay_cancelling: string;
            statusDisplay_completed: string;
            statusDisplay_created: string;
            statusDisplay_error: string;
            statusDisplay_Error: string;
            statusDisplay_processing: string;
            statusDisplay_open: string;
            statusDisplay_pending: {
                approval: string;
                merchant: {
                    approval: string;
                };
            };
            statusDisplay_approved: string;
            statusDisplay_rejected: string;
            statusDisplay_merchant: {
                approved: string;
                rejected: string;
            };
            statusDisplay_assigned: {
                admin: string;
            };
        };
    };
};

declare const ko: {
    pickupInStore: {
        pickupInfo: {
            inStorePickup: string;
            pickupBy: string;
            pickupFrom: string;
        };
        pickupOptionDialog: {
            close: string;
            modalHeader: string;
        };
        pickupOptions: {
            legend: string;
            changeStore: string;
            delivery: string;
            pickup: string;
            shipIt: string;
            selectStore: string;
            freeReturn: string;
            storeIsNotSelected: string;
        };
        setPreferredStore: {
            makeThisMyStore: string;
            myStore: string;
        };
        store: {
            pickupFromHere: string;
            stockLevel_inStock: string;
            stockLevel_outOfStock: string;
            viewHours: string;
        };
        storeList: {
            noStoresMessage: string;
        };
        storeSchedule: {
            closed: string;
            storeHours: string;
        };
        storeSearch: {
            findAStore: string;
            findStores: string;
            hideOutOfStockOptions: string;
            searchPlaceholder: string;
            useMyLocation: string;
        };
        addressBookPickupInStore: {
            heading: string;
        };
        storeFinderPickupInStore: {
            heading: string;
        };
        checkoutPickupInStore: {
            heading: string;
            storeItemHeading: string;
        };
        cardActions: {
            getDirections: string;
        };
        deliveryPointOfServiceDetails: {
            itemsToBePickUp: string;
            pickUpInStoreAddress: string;
            itemsToBeShipped: string;
            shippingAddress: string;
            deliveryMethod: string;
            deliveryOptions: string;
            statusDisplay_cancelled: string;
            statusDisplay_cancelling: string;
            statusDisplay_completed: string;
            statusDisplay_created: string;
            statusDisplay_error: string;
            statusDisplay_Error: string;
            statusDisplay_processing: string;
            statusDisplay_open: string;
            statusDisplay_pending: {
                approval: string;
                merchant: {
                    approval: string;
                };
            };
            statusDisplay_approved: string;
            statusDisplay_rejected: string;
            statusDisplay_merchant: {
                approved: string;
                rejected: string;
            };
            statusDisplay_assigned: {
                admin: string;
            };
        };
    };
};

declare const pl: {
    pickupInStore: {
        pickupInfo: {
            inStorePickup: string;
            pickupBy: string;
            pickupFrom: string;
        };
        pickupOptionDialog: {
            close: string;
            modalHeader: string;
        };
        pickupOptions: {
            legend: string;
            changeStore: string;
            delivery: string;
            pickup: string;
            shipIt: string;
            selectStore: string;
            freeReturn: string;
            storeIsNotSelected: string;
        };
        setPreferredStore: {
            makeThisMyStore: string;
            myStore: string;
        };
        store: {
            pickupFromHere: string;
            stockLevel_inStock: string;
            stockLevel_outOfStock: string;
            viewHours: string;
        };
        storeList: {
            noStoresMessage: string;
        };
        storeSchedule: {
            closed: string;
            storeHours: string;
        };
        storeSearch: {
            findAStore: string;
            findStores: string;
            hideOutOfStockOptions: string;
            searchPlaceholder: string;
            useMyLocation: string;
        };
        addressBookPickupInStore: {
            heading: string;
        };
        storeFinderPickupInStore: {
            heading: string;
        };
        checkoutPickupInStore: {
            heading: string;
            storeItemHeading: string;
        };
        cardActions: {
            getDirections: string;
        };
        deliveryPointOfServiceDetails: {
            itemsToBePickUp: string;
            pickUpInStoreAddress: string;
            itemsToBeShipped: string;
            shippingAddress: string;
            deliveryMethod: string;
            deliveryOptions: string;
            statusDisplay_cancelled: string;
            statusDisplay_cancelling: string;
            statusDisplay_completed: string;
            statusDisplay_created: string;
            statusDisplay_error: string;
            statusDisplay_Error: string;
            statusDisplay_processing: string;
            statusDisplay_open: string;
            statusDisplay_pending: {
                approval: string;
                merchant: {
                    approval: string;
                };
            };
            statusDisplay_approved: string;
            statusDisplay_rejected: string;
            statusDisplay_merchant: {
                approved: string;
                rejected: string;
            };
            statusDisplay_assigned: {
                admin: string;
            };
        };
    };
};

declare const pt: {
    pickupInStore: {
        pickupInfo: {
            inStorePickup: string;
            pickupBy: string;
            pickupFrom: string;
        };
        pickupOptionDialog: {
            close: string;
            modalHeader: string;
        };
        pickupOptions: {
            legend: string;
            changeStore: string;
            delivery: string;
            pickup: string;
            shipIt: string;
            selectStore: string;
            freeReturn: string;
            storeIsNotSelected: string;
        };
        setPreferredStore: {
            makeThisMyStore: string;
            myStore: string;
        };
        store: {
            pickupFromHere: string;
            stockLevel_inStock: string;
            stockLevel_outOfStock: string;
            viewHours: string;
        };
        storeList: {
            noStoresMessage: string;
        };
        storeSchedule: {
            closed: string;
            storeHours: string;
        };
        storeSearch: {
            findAStore: string;
            findStores: string;
            hideOutOfStockOptions: string;
            searchPlaceholder: string;
            useMyLocation: string;
        };
        addressBookPickupInStore: {
            heading: string;
        };
        storeFinderPickupInStore: {
            heading: string;
        };
        checkoutPickupInStore: {
            heading: string;
            storeItemHeading: string;
        };
        cardActions: {
            getDirections: string;
        };
        deliveryPointOfServiceDetails: {
            itemsToBePickUp: string;
            pickUpInStoreAddress: string;
            itemsToBeShipped: string;
            shippingAddress: string;
            deliveryMethod: string;
            deliveryOptions: string;
            statusDisplay_cancelled: string;
            statusDisplay_cancelling: string;
            statusDisplay_completed: string;
            statusDisplay_created: string;
            statusDisplay_error: string;
            statusDisplay_Error: string;
            statusDisplay_processing: string;
            statusDisplay_open: string;
            statusDisplay_pending: {
                approval: string;
                merchant: {
                    approval: string;
                };
            };
            statusDisplay_approved: string;
            statusDisplay_rejected: string;
            statusDisplay_merchant: {
                approved: string;
                rejected: string;
            };
            statusDisplay_assigned: {
                admin: string;
            };
        };
    };
};

declare const ru: {
    pickupInStore: {
        pickupInfo: {
            inStorePickup: string;
            pickupBy: string;
            pickupFrom: string;
        };
        pickupOptionDialog: {
            close: string;
            modalHeader: string;
        };
        pickupOptions: {
            legend: string;
            changeStore: string;
            delivery: string;
            pickup: string;
            shipIt: string;
            selectStore: string;
            freeReturn: string;
            storeIsNotSelected: string;
        };
        setPreferredStore: {
            makeThisMyStore: string;
            myStore: string;
        };
        store: {
            pickupFromHere: string;
            stockLevel_inStock: string;
            stockLevel_outOfStock: string;
            viewHours: string;
        };
        storeList: {
            noStoresMessage: string;
        };
        storeSchedule: {
            closed: string;
            storeHours: string;
        };
        storeSearch: {
            findAStore: string;
            findStores: string;
            hideOutOfStockOptions: string;
            searchPlaceholder: string;
            useMyLocation: string;
        };
        addressBookPickupInStore: {
            heading: string;
        };
        storeFinderPickupInStore: {
            heading: string;
        };
        checkoutPickupInStore: {
            heading: string;
            storeItemHeading: string;
        };
        cardActions: {
            getDirections: string;
        };
        deliveryPointOfServiceDetails: {
            itemsToBePickUp: string;
            pickUpInStoreAddress: string;
            itemsToBeShipped: string;
            shippingAddress: string;
            deliveryMethod: string;
            deliveryOptions: string;
            statusDisplay_cancelled: string;
            statusDisplay_cancelling: string;
            statusDisplay_completed: string;
            statusDisplay_created: string;
            statusDisplay_error: string;
            statusDisplay_Error: string;
            statusDisplay_processing: string;
            statusDisplay_open: string;
            statusDisplay_pending: {
                approval: string;
                merchant: {
                    approval: string;
                };
            };
            statusDisplay_approved: string;
            statusDisplay_rejected: string;
            statusDisplay_merchant: {
                approved: string;
                rejected: string;
            };
            statusDisplay_assigned: {
                admin: string;
            };
        };
    };
};

declare const zh: {
    pickupInStore: {
        pickupInfo: {
            inStorePickup: string;
            pickupBy: string;
            pickupFrom: string;
        };
        pickupOptionDialog: {
            close: string;
            modalHeader: string;
        };
        pickupOptions: {
            legend: string;
            changeStore: string;
            delivery: string;
            pickup: string;
            shipIt: string;
            selectStore: string;
            freeReturn: string;
            storeIsNotSelected: string;
        };
        setPreferredStore: {
            makeThisMyStore: string;
            myStore: string;
        };
        store: {
            pickupFromHere: string;
            stockLevel_inStock: string;
            stockLevel_outOfStock: string;
            viewHours: string;
        };
        storeList: {
            noStoresMessage: string;
        };
        storeSchedule: {
            closed: string;
            storeHours: string;
        };
        storeSearch: {
            findAStore: string;
            findStores: string;
            hideOutOfStockOptions: string;
            searchPlaceholder: string;
            useMyLocation: string;
        };
        addressBookPickupInStore: {
            heading: string;
        };
        storeFinderPickupInStore: {
            heading: string;
        };
        checkoutPickupInStore: {
            heading: string;
            storeItemHeading: string;
        };
        cardActions: {
            getDirections: string;
        };
        deliveryPointOfServiceDetails: {
            itemsToBePickUp: string;
            pickUpInStoreAddress: string;
            itemsToBeShipped: string;
            shippingAddress: string;
            deliveryMethod: string;
            deliveryOptions: string;
            statusDisplay_cancelled: string;
            statusDisplay_cancelling: string;
            statusDisplay_completed: string;
            statusDisplay_created: string;
            statusDisplay_error: string;
            statusDisplay_Error: string;
            statusDisplay_processing: string;
            statusDisplay_open: string;
            statusDisplay_pending: {
                approval: string;
                merchant: {
                    approval: string;
                };
            };
            statusDisplay_approved: string;
            statusDisplay_rejected: string;
            statusDisplay_merchant: {
                approved: string;
                rejected: string;
            };
            statusDisplay_assigned: {
                admin: string;
            };
        };
    };
};

declare const zh_TW: {
    pickupInStore: {
        pickupInfo: {
            inStorePickup: string;
            pickupBy: string;
            pickupFrom: string;
        };
        pickupOptionDialog: {
            close: string;
            modalHeader: string;
        };
        pickupOptions: {
            legend: string;
            changeStore: string;
            delivery: string;
            pickup: string;
            shipIt: string;
            selectStore: string;
            freeReturn: string;
            storeIsNotSelected: string;
        };
        setPreferredStore: {
            makeThisMyStore: string;
            myStore: string;
        };
        store: {
            pickupFromHere: string;
            stockLevel_inStock: string;
            stockLevel_outOfStock: string;
            viewHours: string;
        };
        storeList: {
            noStoresMessage: string;
        };
        storeSchedule: {
            closed: string;
            storeHours: string;
        };
        storeSearch: {
            findAStore: string;
            findStores: string;
            hideOutOfStockOptions: string;
            searchPlaceholder: string;
            useMyLocation: string;
        };
        addressBookPickupInStore: {
            heading: string;
        };
        storeFinderPickupInStore: {
            heading: string;
        };
        checkoutPickupInStore: {
            heading: string;
            storeItemHeading: string;
        };
        cardActions: {
            getDirections: string;
        };
        deliveryPointOfServiceDetails: {
            itemsToBePickUp: string;
            pickUpInStoreAddress: string;
            itemsToBeShipped: string;
            shippingAddress: string;
            deliveryMethod: string;
            deliveryOptions: string;
            statusDisplay_cancelled: string;
            statusDisplay_cancelling: string;
            statusDisplay_completed: string;
            statusDisplay_created: string;
            statusDisplay_error: string;
            statusDisplay_Error: string;
            statusDisplay_processing: string;
            statusDisplay_open: string;
            statusDisplay_pending: {
                approval: string;
                merchant: {
                    approval: string;
                };
            };
            statusDisplay_approved: string;
            statusDisplay_rejected: string;
            statusDisplay_merchant: {
                approved: string;
                rejected: string;
            };
            statusDisplay_assigned: {
                admin: string;
            };
        };
    };
};

declare const pickupInStoreTranslationChunksConfig: TranslationChunksConfig;

export { pickupInStoreTranslationChunksConfig, cs as pickupInStoreTranslationsCs, de as pickupInStoreTranslationsDe, en as pickupInStoreTranslationsEn, es as pickupInStoreTranslationsEs, es_CO as pickupInStoreTranslationsEs_CO, fr as pickupInStoreTranslationsFr, hi as pickupInStoreTranslationsHi, hu as pickupInStoreTranslationsHu, id as pickupInStoreTranslationsId, it as pickupInStoreTranslationsIt, ja as pickupInStoreTranslationsJa, ko as pickupInStoreTranslationsKo, pl as pickupInStoreTranslationsPl, pt as pickupInStoreTranslationsPt, ru as pickupInStoreTranslationsRu, zh as pickupInStoreTranslationsZh, zh_TW as pickupInStoreTranslationsZh_TW };
