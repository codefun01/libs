import * as i0 from '@angular/core';
import { Provider, InjectionToken, OnDestroy } from '@angular/core';
import * as _spartacus_core from '@spartacus/core';
import { PointOfService, StoreFinderStockSearchPage, Stock, StateUtils, ErrorAction, WindowRef, LoggerService, PointOfServiceStock } from '@spartacus/core';
import * as rxjs from 'rxjs';
import { Observable, Subscription } from 'rxjs';
import { LocationSearchParams, PointOfServiceNames, AugmentedPointOfService, PickupOption, StockLocationSearchParams, PickupLocationsSearchFacade, PickupOptionFacade, PreferredStoreFacade } from '@spartacus/pickup-in-store/root';
import * as _ngrx_store from '@ngrx/store';
import { Action, Store, ActionReducerMap, MetaReducer, ActionReducer, MemoizedSelector } from '@ngrx/store';
import * as i1 from '@angular/common';
import * as _ngrx_effects from '@ngrx/effects';
import { Actions } from '@ngrx/effects';
import { UserProfileFacade } from '@spartacus/user/profile/root';

declare abstract class PickupInStoreConfig {
    pickupInStore?: {
        consentTemplateId?: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupInStoreConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PickupInStoreConfig>;
}
declare module '@spartacus/core' {
    interface Config extends PickupInStoreConfig {
    }
}

declare const defaultPickupInStoreConfig: PickupInStoreConfig;

/**
 * Adapter for getting store details.
 */
declare abstract class PickupLocationAdapter {
    /**
     * Get the store details by store name.
     * @param storeName The store name to get details for
     */
    abstract getStoreDetails(storeName: string): Observable<PointOfService>;
}

/**
 * Connector for getting store details.
 */
declare class PickupLocationConnector {
    protected adapter: PickupLocationAdapter;
    constructor(adapter: PickupLocationAdapter);
    /**
     * Get the store details by store name.
     * @param storeName The store name to get details for
     */
    getStoreDetails(storeName: string): Observable<PointOfService>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupLocationConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PickupLocationConnector>;
}

/**
 * Adapter for finding stock levels of a product in stores.
 */
declare abstract class StockAdapter {
    /**
     * Finds stock levels of a product at stores near a location.
     * @param productCode the product code of the product to find stock levels for
     * @param location the location to find stock levels at, either lat long or free text search
     */
    abstract loadStockLevels(productCode: string, location: LocationSearchParams): Observable<StoreFinderStockSearchPage>;
    /**
     * Finds stock levels of a product at an individual store.
     * @param productCode the product code of the product to find stock levels for
     * @param storeName the name of the store to find stock levels at
     */
    abstract loadStockLevelAtStore(productCode: string, storeName: string): Observable<Stock>;
}

/**
 * Connector for finding stock levels of a product in stores.
 */
declare class StockConnector {
    protected adapter: StockAdapter;
    constructor(adapter: StockAdapter);
    /**
     * Finds stock levels of a product at stores near a location.
     * @param productCode the product code of the product to find stock levels for
     * @param location the location to find stock levels at, either lat long or free text search
     */
    loadStockLevels(productCode: string, location: LocationSearchParams): Observable<StoreFinderStockSearchPage>;
    /**
     * Finds stock levels of a product at an individual store.
     * @param productCode the product code of the product to find stock levels for
     * @param storeName the name of the store to find stock levels at
     */
    loadStockLevelAtStore(productCode: string, storeName: string): Observable<Stock>;
    static ɵfac: i0.ɵɵFactoryDeclaration<StockConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StockConnector>;
}

declare const facadeProviders: Provider[];

declare const ADD_BROWSER_LOCATION = "[Pickup Locations] Add Browser Location";
type AddBrowserLocationProps = {
    longitude: number;
    latitude: number;
};
declare const AddBrowserLocation: _ngrx_store.ActionCreator<"[Pickup Locations] Add Browser Location", (props: {
    payload: AddBrowserLocationProps;
}) => {
    payload: AddBrowserLocationProps;
} & _ngrx_store.Action<"[Pickup Locations] Add Browser Location">>;

declare const browserLocation_action_d_ADD_BROWSER_LOCATION: typeof ADD_BROWSER_LOCATION;
declare const browserLocation_action_d_AddBrowserLocation: typeof AddBrowserLocation;
type browserLocation_action_d_AddBrowserLocationProps = AddBrowserLocationProps;
declare namespace browserLocation_action_d {
  export { browserLocation_action_d_ADD_BROWSER_LOCATION as ADD_BROWSER_LOCATION, browserLocation_action_d_AddBrowserLocation as AddBrowserLocation };
  export type { browserLocation_action_d_AddBrowserLocationProps as AddBrowserLocationProps };
}

declare const LOAD_DEFAULT_POINT_OF_SERVICE = "[Default Point Of Service] Load Default Point Of Service";
declare const LOAD_DEFAULT_POINT_OF_SERVICE_SUCCESS = "[Default Point Of Service] Load Default Point Of Service Success";
declare const SET_DEFAULT_POINT_OF_SERVICE = "[Default Point Of Service] Set Default Point Of Service";
declare const LoadDefaultPointOfService: _ngrx_store.ActionCreator<"[Default Point Of Service] Load Default Point Of Service", () => _ngrx_store.Action<"[Default Point Of Service] Load Default Point Of Service">>;
declare const LoadDefaultPointOfServiceSuccess: _ngrx_store.ActionCreator<"[Default Point Of Service] Load Default Point Of Service Success", (props: {
    payload: PointOfServiceNames;
}) => {
    payload: PointOfServiceNames;
} & _ngrx_store.Action<"[Default Point Of Service] Load Default Point Of Service Success">>;
declare const SetDefaultPointOfService: _ngrx_store.ActionCreator<"[Default Point Of Service] Set Default Point Of Service", (props: {
    payload: PointOfServiceNames;
}) => {
    payload: PointOfServiceNames;
} & _ngrx_store.Action<"[Default Point Of Service] Set Default Point Of Service">>;

declare const defaultPointOfServiceName_action_d_LOAD_DEFAULT_POINT_OF_SERVICE: typeof LOAD_DEFAULT_POINT_OF_SERVICE;
declare const defaultPointOfServiceName_action_d_LOAD_DEFAULT_POINT_OF_SERVICE_SUCCESS: typeof LOAD_DEFAULT_POINT_OF_SERVICE_SUCCESS;
declare const defaultPointOfServiceName_action_d_LoadDefaultPointOfService: typeof LoadDefaultPointOfService;
declare const defaultPointOfServiceName_action_d_LoadDefaultPointOfServiceSuccess: typeof LoadDefaultPointOfServiceSuccess;
declare const defaultPointOfServiceName_action_d_SET_DEFAULT_POINT_OF_SERVICE: typeof SET_DEFAULT_POINT_OF_SERVICE;
declare const defaultPointOfServiceName_action_d_SetDefaultPointOfService: typeof SetDefaultPointOfService;
declare namespace defaultPointOfServiceName_action_d {
  export {
    defaultPointOfServiceName_action_d_LOAD_DEFAULT_POINT_OF_SERVICE as LOAD_DEFAULT_POINT_OF_SERVICE,
    defaultPointOfServiceName_action_d_LOAD_DEFAULT_POINT_OF_SERVICE_SUCCESS as LOAD_DEFAULT_POINT_OF_SERVICE_SUCCESS,
    defaultPointOfServiceName_action_d_LoadDefaultPointOfService as LoadDefaultPointOfService,
    defaultPointOfServiceName_action_d_LoadDefaultPointOfServiceSuccess as LoadDefaultPointOfServiceSuccess,
    defaultPointOfServiceName_action_d_SET_DEFAULT_POINT_OF_SERVICE as SET_DEFAULT_POINT_OF_SERVICE,
    defaultPointOfServiceName_action_d_SetDefaultPointOfService as SetDefaultPointOfService,
  };
}

declare const ADD_LOCATION = "[Pickup Locations] Add Location";
declare const REMOVE_LOCATION = "[Pickup Locations] Remove Location";
declare const SET_PICKUP_OPTION = "[Pickup Locations] Set Pickup Option";
declare const GET_STORE_DETAILS = "[Pickup Locations] Get Store Details";
declare const STORE_DETAILS_SUCCESS = "[Pickup Locations] Get Store Details Success";
declare const STORE_DETAILS_FAIL = "[Pickup Locations] Get Store Details Fail";
declare const SET_PICKUP_OPTION_TO_DELIVERY = "[Pickup Locations] Set Pickup Option To Delivery";
declare const SET_PICKUP_OPTION_TO_DELIVERY_SUCCESS = "[Pickup Locations] Set Pickup Option To Delivery Success";
declare const SET_PICKUP_OPTION_TO_PICKUP_IN_STORE = "[Pickup Locations] Set Pickup Option To Pickup In Store";
declare const SET_PICKUP_OPTION_TO_PICKUP_IN_STORE_SUCCESS = "[Pickup Locations] Set Pickup Option To Pickup In Store Success";
declare const CART_RELOAD_SUCCESS = "[Pickup Locations] CART_RELOAD_SUCCESS";
declare const DELIVERY_MODE_SET_PICKUP_OPTION_TO_PICKUP_IN_STORE_SUCCESS = "[Pickup Locations CHECKOUT] CHECKOUT_SET_PICKUP_OPTION_TO_PICKUP_IN_STORE_SUCCESS";
type AddLocationProps = {
    payload: {
        productCode: string;
        location: AugmentedPointOfService;
    };
};
type SetPickupOptionProps = {
    productCode: string;
    pickupOption: PickupOption;
};
/**
 * Add a proposed pickup location for a product code.
 */
declare const AddLocation: _ngrx_store.ActionCreator<"[Pickup Locations] Add Location", (props: AddLocationProps) => AddLocationProps & Action<"[Pickup Locations] Add Location">>;
/**
 * Remove a proposed pickup location for a product code.
 */
declare const RemoveLocation: _ngrx_store.ActionCreator<"[Pickup Locations] Remove Location", (props: {
    payload: string;
}) => {
    payload: string;
} & Action<"[Pickup Locations] Remove Location">>;
/**
 * Set pickup option for a product code.
 */
declare const SetPickupOption$1: _ngrx_store.ActionCreator<"[Pickup Locations] Set Pickup Option", (props: {
    payload: SetPickupOptionProps;
}) => {
    payload: SetPickupOptionProps;
} & Action<"[Pickup Locations] Set Pickup Option">>;
/**
 * Get Store Details By Id
 */
declare const GetStoreDetailsById: _ngrx_store.ActionCreator<"[Pickup Locations] Get Store Details", (props: {
    payload: string;
}) => {
    payload: string;
} & Action<"[Pickup Locations] Get Store Details">>;
declare const SetStoreDetailsSuccess: _ngrx_store.ActionCreator<"[Pickup Locations] Get Store Details Success", (props: {
    payload: PointOfService;
}) => {
    payload: PointOfService;
} & Action<"[Pickup Locations] Get Store Details Success">>;
declare const SetStoreDetailsFailure: ($props: {
    payload: any;
}) => {
    payload: any;
    error: any;
} & Action<typeof STORE_DETAILS_FAIL>;

declare const pickupLocation_action_d_ADD_LOCATION: typeof ADD_LOCATION;
declare const pickupLocation_action_d_AddLocation: typeof AddLocation;
type pickupLocation_action_d_AddLocationProps = AddLocationProps;
declare const pickupLocation_action_d_CART_RELOAD_SUCCESS: typeof CART_RELOAD_SUCCESS;
declare const pickupLocation_action_d_DELIVERY_MODE_SET_PICKUP_OPTION_TO_PICKUP_IN_STORE_SUCCESS: typeof DELIVERY_MODE_SET_PICKUP_OPTION_TO_PICKUP_IN_STORE_SUCCESS;
declare const pickupLocation_action_d_GET_STORE_DETAILS: typeof GET_STORE_DETAILS;
declare const pickupLocation_action_d_GetStoreDetailsById: typeof GetStoreDetailsById;
declare const pickupLocation_action_d_REMOVE_LOCATION: typeof REMOVE_LOCATION;
declare const pickupLocation_action_d_RemoveLocation: typeof RemoveLocation;
declare const pickupLocation_action_d_SET_PICKUP_OPTION: typeof SET_PICKUP_OPTION;
declare const pickupLocation_action_d_SET_PICKUP_OPTION_TO_DELIVERY: typeof SET_PICKUP_OPTION_TO_DELIVERY;
declare const pickupLocation_action_d_SET_PICKUP_OPTION_TO_DELIVERY_SUCCESS: typeof SET_PICKUP_OPTION_TO_DELIVERY_SUCCESS;
declare const pickupLocation_action_d_SET_PICKUP_OPTION_TO_PICKUP_IN_STORE: typeof SET_PICKUP_OPTION_TO_PICKUP_IN_STORE;
declare const pickupLocation_action_d_SET_PICKUP_OPTION_TO_PICKUP_IN_STORE_SUCCESS: typeof SET_PICKUP_OPTION_TO_PICKUP_IN_STORE_SUCCESS;
declare const pickupLocation_action_d_STORE_DETAILS_FAIL: typeof STORE_DETAILS_FAIL;
declare const pickupLocation_action_d_STORE_DETAILS_SUCCESS: typeof STORE_DETAILS_SUCCESS;
type pickupLocation_action_d_SetPickupOptionProps = SetPickupOptionProps;
declare const pickupLocation_action_d_SetStoreDetailsFailure: typeof SetStoreDetailsFailure;
declare const pickupLocation_action_d_SetStoreDetailsSuccess: typeof SetStoreDetailsSuccess;
declare namespace pickupLocation_action_d {
  export { pickupLocation_action_d_ADD_LOCATION as ADD_LOCATION, pickupLocation_action_d_AddLocation as AddLocation, pickupLocation_action_d_CART_RELOAD_SUCCESS as CART_RELOAD_SUCCESS, pickupLocation_action_d_DELIVERY_MODE_SET_PICKUP_OPTION_TO_PICKUP_IN_STORE_SUCCESS as DELIVERY_MODE_SET_PICKUP_OPTION_TO_PICKUP_IN_STORE_SUCCESS, pickupLocation_action_d_GET_STORE_DETAILS as GET_STORE_DETAILS, pickupLocation_action_d_GetStoreDetailsById as GetStoreDetailsById, pickupLocation_action_d_REMOVE_LOCATION as REMOVE_LOCATION, pickupLocation_action_d_RemoveLocation as RemoveLocation, pickupLocation_action_d_SET_PICKUP_OPTION as SET_PICKUP_OPTION, pickupLocation_action_d_SET_PICKUP_OPTION_TO_DELIVERY as SET_PICKUP_OPTION_TO_DELIVERY, pickupLocation_action_d_SET_PICKUP_OPTION_TO_DELIVERY_SUCCESS as SET_PICKUP_OPTION_TO_DELIVERY_SUCCESS, pickupLocation_action_d_SET_PICKUP_OPTION_TO_PICKUP_IN_STORE as SET_PICKUP_OPTION_TO_PICKUP_IN_STORE, pickupLocation_action_d_SET_PICKUP_OPTION_TO_PICKUP_IN_STORE_SUCCESS as SET_PICKUP_OPTION_TO_PICKUP_IN_STORE_SUCCESS, pickupLocation_action_d_STORE_DETAILS_FAIL as STORE_DETAILS_FAIL, pickupLocation_action_d_STORE_DETAILS_SUCCESS as STORE_DETAILS_SUCCESS, SetPickupOption$1 as SetPickupOption, pickupLocation_action_d_SetStoreDetailsFailure as SetStoreDetailsFailure, pickupLocation_action_d_SetStoreDetailsSuccess as SetStoreDetailsSuccess };
  export type { pickupLocation_action_d_AddLocationProps as AddLocationProps, pickupLocation_action_d_SetPickupOptionProps as SetPickupOptionProps };
}

declare const SetPickupOption: _ngrx_store.ActionCreator<"[PickupOption] Set Pickup Option", (props: {
    payload: {
        entryNumber: number;
        pickupOption: PickupOption;
    };
}) => {
    payload: {
        entryNumber: number;
        pickupOption: PickupOption;
    };
} & _ngrx_store.Action<"[PickupOption] Set Pickup Option">>;
declare const RemovePickupOption: _ngrx_store.ActionCreator<"[PickupOption] Remove Pickup Option", (props: {
    payload: {
        entryNumber: number;
    };
}) => {
    payload: {
        entryNumber: number;
    };
} & _ngrx_store.Action<"[PickupOption] Remove Pickup Option">>;
declare const RemoveAllPickupOptions: _ngrx_store.ActionCreator<"[PickupOption] Remove All Pickup Option", () => _ngrx_store.Action<"[PickupOption] Remove All Pickup Option">>;
declare const SetPageContext: _ngrx_store.ActionCreator<"[PickupOption] Set Page Context", (props: {
    payload: {
        pageContext: string;
    };
}) => {
    payload: {
        pageContext: string;
    };
} & _ngrx_store.Action<"[PickupOption] Set Page Context">>;

declare const pickupOption_action_d_RemoveAllPickupOptions: typeof RemoveAllPickupOptions;
declare const pickupOption_action_d_RemovePickupOption: typeof RemovePickupOption;
declare const pickupOption_action_d_SetPageContext: typeof SetPageContext;
declare const pickupOption_action_d_SetPickupOption: typeof SetPickupOption;
declare namespace pickupOption_action_d {
  export {
    pickupOption_action_d_RemoveAllPickupOptions as RemoveAllPickupOptions,
    pickupOption_action_d_RemovePickupOption as RemovePickupOption,
    pickupOption_action_d_SetPageContext as SetPageContext,
    pickupOption_action_d_SetPickupOption as SetPickupOption,
  };
}

declare const STOCK_LEVEL = "[Stock] Get Stock Level";
declare const STOCK_LEVEL_ON_HOLD = "[Stock] On Hold";
declare const STOCK_LEVEL_FAIL = "[Stock] Get Stock Level Fail";
declare const STOCK_LEVEL_SUCCESS = "[Stock] Get Stock Level Success";
declare const CLEAR_STOCK_DATA = "[Stock] Clear Data";
declare const STOCK_LEVEL_AT_STORE = "[Stock] Get Stock Level at Store";
declare const STOCK_LEVEL_AT_STORE_SUCCESS = "[Stock] Get Stock Level at Store Success";
declare class StockLevel extends StateUtils.LoaderLoadAction {
    payload: StockLocationSearchParams;
    readonly type = "[Stock] Get Stock Level";
    constructor(payload: StockLocationSearchParams);
}
declare class StockLevelOnHold extends StateUtils.LoaderLoadAction {
    readonly type = "[Stock] On Hold";
    constructor();
}
declare class StockLevelFail extends StateUtils.LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Stock] Get Stock Level Fail";
    constructor(payload: any);
}
type StockLevelSuccessPayload = {
    productCode: string;
    stockLevels: StoreFinderStockSearchPage;
};
declare class StockLevelSuccess extends StateUtils.LoaderSuccessAction {
    payload: StockLevelSuccessPayload;
    readonly type = "[Stock] Get Stock Level Success";
    constructor(payload: StockLevelSuccessPayload);
}
declare class ClearStockData extends StateUtils.LoaderResetAction {
    readonly type = "[Stock] Clear Data";
    constructor();
}
type StockLevelAction = StockLevel | StockLevelOnHold | StockLevelFail | StockLevelSuccess | ClearStockData;
type StockLevelAtStorePayload = {
    productCode: string;
    storeName: string;
};
/**
 * Add a proposed pickup location for a product code.
 */
declare const StockLevelAtStore: _ngrx_store.ActionCreator<"[Stock] Get Stock Level at Store", (props: {
    payload: StockLevelAtStorePayload;
}) => {
    payload: StockLevelAtStorePayload;
} & _ngrx_store.Action<"[Stock] Get Stock Level at Store">>;
type StockLevelAtStoreAction = ReturnType<typeof StockLevelAtStore>;
type StockLevelAtStoreSuccessPayload = StockLevelAtStorePayload & {
    stockLevel: Stock;
};
/**
 * Add the stock level for a product at a store.
 */
declare const StockLevelAtStoreSuccess: _ngrx_store.ActionCreator<"[Stock] Get Stock Level at Store Success", (props: {
    payload: StockLevelAtStoreSuccessPayload;
}) => {
    payload: StockLevelAtStoreSuccessPayload;
} & _ngrx_store.Action<"[Stock] Get Stock Level at Store Success">>;

declare const stock_action_d_CLEAR_STOCK_DATA: typeof CLEAR_STOCK_DATA;
type stock_action_d_ClearStockData = ClearStockData;
declare const stock_action_d_ClearStockData: typeof ClearStockData;
declare const stock_action_d_STOCK_LEVEL: typeof STOCK_LEVEL;
declare const stock_action_d_STOCK_LEVEL_AT_STORE: typeof STOCK_LEVEL_AT_STORE;
declare const stock_action_d_STOCK_LEVEL_AT_STORE_SUCCESS: typeof STOCK_LEVEL_AT_STORE_SUCCESS;
declare const stock_action_d_STOCK_LEVEL_FAIL: typeof STOCK_LEVEL_FAIL;
declare const stock_action_d_STOCK_LEVEL_ON_HOLD: typeof STOCK_LEVEL_ON_HOLD;
declare const stock_action_d_STOCK_LEVEL_SUCCESS: typeof STOCK_LEVEL_SUCCESS;
type stock_action_d_StockLevel = StockLevel;
declare const stock_action_d_StockLevel: typeof StockLevel;
type stock_action_d_StockLevelAction = StockLevelAction;
declare const stock_action_d_StockLevelAtStore: typeof StockLevelAtStore;
type stock_action_d_StockLevelAtStoreAction = StockLevelAtStoreAction;
declare const stock_action_d_StockLevelAtStoreSuccess: typeof StockLevelAtStoreSuccess;
type stock_action_d_StockLevelFail = StockLevelFail;
declare const stock_action_d_StockLevelFail: typeof StockLevelFail;
type stock_action_d_StockLevelOnHold = StockLevelOnHold;
declare const stock_action_d_StockLevelOnHold: typeof StockLevelOnHold;
type stock_action_d_StockLevelSuccess = StockLevelSuccess;
declare const stock_action_d_StockLevelSuccess: typeof StockLevelSuccess;
type stock_action_d_StockLevelSuccessPayload = StockLevelSuccessPayload;
declare namespace stock_action_d {
  export { stock_action_d_CLEAR_STOCK_DATA as CLEAR_STOCK_DATA, stock_action_d_ClearStockData as ClearStockData, stock_action_d_STOCK_LEVEL as STOCK_LEVEL, stock_action_d_STOCK_LEVEL_AT_STORE as STOCK_LEVEL_AT_STORE, stock_action_d_STOCK_LEVEL_AT_STORE_SUCCESS as STOCK_LEVEL_AT_STORE_SUCCESS, stock_action_d_STOCK_LEVEL_FAIL as STOCK_LEVEL_FAIL, stock_action_d_STOCK_LEVEL_ON_HOLD as STOCK_LEVEL_ON_HOLD, stock_action_d_STOCK_LEVEL_SUCCESS as STOCK_LEVEL_SUCCESS, stock_action_d_StockLevel as StockLevel, stock_action_d_StockLevelAtStore as StockLevelAtStore, stock_action_d_StockLevelAtStoreSuccess as StockLevelAtStoreSuccess, stock_action_d_StockLevelFail as StockLevelFail, stock_action_d_StockLevelOnHold as StockLevelOnHold, stock_action_d_StockLevelSuccess as StockLevelSuccess };
  export type { stock_action_d_StockLevelAction as StockLevelAction, stock_action_d_StockLevelAtStoreAction as StockLevelAtStoreAction, stock_action_d_StockLevelSuccessPayload as StockLevelSuccessPayload };
}

declare const TOGGLE_HIDE_OUT_OF_STOCK_OPTIONS = "[Stock] Toggle Hide Out Of Stock Options";
declare const ToggleHideOutOfStockOptionsAction: _ngrx_store.ActionCreator<"[Stock] Toggle Hide Out Of Stock Options", () => _ngrx_store.Action<"[Stock] Toggle Hide Out Of Stock Options">>;

declare const PICKUP_LOCATIONS_FEATURE = "pickup-locations";
interface StateWithPickupLocations {
    [PICKUP_LOCATIONS_FEATURE]: PickupLocationsState;
}
interface PickupLocationsState {
    defaultPointOfService: PointOfServiceNames | null;
    intendedPickupLocations: IntendedPickupLocationsState;
    storeDetails: Record<string, PointOfService>;
}
type IntendedPickupLocationsState = {
    [productCode: string]: AugmentedPointOfService;
};

declare class DefaultPointOfServiceEffect {
    private actions$;
    protected store: Store<StateWithPickupLocations>;
    protected userProfileService: UserProfileFacade;
    protected winRef: WindowRef;
    constructor(actions$: Actions, store: Store<StateWithPickupLocations>, userProfileService: UserProfileFacade, winRef: WindowRef);
    loadDefaultPointOfService$: rxjs.Observable<{
        payload: PointOfServiceNames;
    } & _ngrx_store.Action<"[Default Point Of Service] Load Default Point Of Service Success">> & _ngrx_effects.CreateEffectMetadata;
    setDefaultPointOfService$: rxjs.Observable<_ngrx_store.Action<"[Default Point Of Service] Load Default Point Of Service">> & _ngrx_effects.CreateEffectMetadata;
    static ɵfac: i0.ɵɵFactoryDeclaration<DefaultPointOfServiceEffect, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DefaultPointOfServiceEffect>;
}

declare class PickupLocationEffect {
    private actions$;
    private pickupLocationConnector;
    protected logger: LoggerService;
    constructor(actions$: Actions, pickupLocationConnector: PickupLocationConnector);
    storeDetails$: rxjs.Observable<({
        payload: any;
        error: any;
    } & _ngrx_store.Action<"[Pickup Locations] Get Store Details Fail">) | ({
        payload: _spartacus_core.PointOfService;
    } & _ngrx_store.Action<"[Pickup Locations] Get Store Details Success">)> & _ngrx_effects.CreateEffectMetadata;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupLocationEffect, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PickupLocationEffect>;
}

declare class StockEffect {
    private actions$;
    private stockConnector;
    protected logger: LoggerService;
    constructor(actions$: Actions, stockConnector: StockConnector);
    loadStockLevels$: rxjs.Observable<StockLevelFail | StockLevelSuccess> & _ngrx_effects.CreateEffectMetadata;
    loadStockLevelAtStore$: rxjs.Observable<{
        payload: {
            productCode: string;
            storeName: string;
        } & {
            stockLevel: _spartacus_core.Stock;
        };
    } & _ngrx_store.Action<"[Stock] Get Stock Level at Store Success">> & _ngrx_effects.CreateEffectMetadata;
    static ɵfac: i0.ɵɵFactoryDeclaration<StockEffect, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StockEffect>;
}

declare const effects: any[];

declare class PickupInStoreStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupInStoreStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PickupInStoreStoreModule, never, [typeof i1.CommonModule, typeof _ngrx_store.StoreFeatureModule, typeof _ngrx_store.StoreFeatureModule, typeof _ngrx_store.StoreFeatureModule, typeof _ngrx_effects.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PickupInStoreStoreModule>;
}

declare const PICKUP_OPTION_FEATURE = "pickup-option";
interface StateWithPickupOption {
    [PICKUP_OPTION_FEATURE]: PickupOptionState;
}
type EntryPickupOption = {
    entryNumber: number;
    pickupOption: PickupOption;
};
interface PickupOptionState {
    pageContext: string;
    pickupOption: EntryPickupOption[];
}

declare function getReducers(): ActionReducerMap<PickupLocationsState>;
declare const pickupLocationsReducersToken: InjectionToken<ActionReducerMap<PickupLocationsState>>;
declare const pickupLocationsReducersProvider: Provider;
declare const pickupLocationsMetaReducers: MetaReducer<any>[];

declare function getPickupReducers(): ActionReducerMap<PickupOptionState>;
declare const pickupOptionReducersToken: InjectionToken<ActionReducerMap<PickupOptionState>>;
declare const pickupOptionReducersProvider: Provider;
declare const pickupOptionMetaReducers: MetaReducer<any>[];

declare const STOCK_FEATURE = "stock";
declare const STOCK_DATA = "[Stock] Stock Data";
interface StateWithStock {
    [STOCK_FEATURE]: StockState;
}
interface BrowserLocation {
    latitude: number | null;
    longitude: number | null;
}
interface StockState {
    browserLocation: BrowserLocation;
    hideOutOfStock: boolean;
    stockLevel: StateUtils.LoaderState<StockLevelState>;
    stockLevelAtStore: Record<string, Record<string, Stock | undefined>>;
}
type StockLevelState = Record<string, StoreFinderStockSearchPage>;

declare const stockReducersToken: InjectionToken<ActionReducerMap<StockState>>;
declare const stockReducersProvider: Provider;
declare function clearStockState(reducer: ActionReducer<StockState, Action>): ActionReducer<StockState, Action>;
declare const stockMetaReducers: MetaReducer<any>[];

declare const getPreferredStore: MemoizedSelector<StateWithPickupLocations, PickupLocationsState['defaultPointOfService']>;

declare const defaultPointOfServiceName_selectors_d_getPreferredStore: typeof getPreferredStore;
declare namespace defaultPointOfServiceName_selectors_d {
  export {
    defaultPointOfServiceName_selectors_d_getPreferredStore as getPreferredStore,
  };
}

declare const getHideOutOfStockState: MemoizedSelector<StateWithStock, StockState['hideOutOfStock']>;

declare const hideOutOfStock_selectors_d_getHideOutOfStockState: typeof getHideOutOfStockState;
declare namespace hideOutOfStock_selectors_d {
  export {
    hideOutOfStock_selectors_d_getHideOutOfStockState as getHideOutOfStockState,
  };
}

/**
 * Get all the intended pickup locations.
 */
declare const getIntendedPickupLocations: MemoizedSelector<StateWithPickupLocations, PickupLocationsState['intendedPickupLocations']>;
/**
 * Get the intended pickup location for a given product.
 * @param productCode The product code of the product to get the intended pickup location for.
 * @returns The intended pickup location for the product.
 */
declare const getIntendedPickupLocationByProductCode: (productCode: string) => MemoizedSelector<StateWithPickupLocations, AugmentedPointOfService | undefined>;
declare const getPickupOptionByProductCode: (productCode: string) => MemoizedSelector<StateWithPickupLocations, PickupOption>;
declare const getStoreDetailsByName: (storeName: string) => MemoizedSelector<StateWithPickupLocations, PointOfService>;

declare const pickupLocations_selectors_d_getIntendedPickupLocationByProductCode: typeof getIntendedPickupLocationByProductCode;
declare const pickupLocations_selectors_d_getIntendedPickupLocations: typeof getIntendedPickupLocations;
declare const pickupLocations_selectors_d_getPickupOptionByProductCode: typeof getPickupOptionByProductCode;
declare const pickupLocations_selectors_d_getStoreDetailsByName: typeof getStoreDetailsByName;
declare namespace pickupLocations_selectors_d {
  export {
    pickupLocations_selectors_d_getIntendedPickupLocationByProductCode as getIntendedPickupLocationByProductCode,
    pickupLocations_selectors_d_getIntendedPickupLocations as getIntendedPickupLocations,
    pickupLocations_selectors_d_getPickupOptionByProductCode as getPickupOptionByProductCode,
    pickupLocations_selectors_d_getStoreDetailsByName as getStoreDetailsByName,
  };
}

declare const getPageContext: () => MemoizedSelector<StateWithPickupOption, string>;
declare const getPickupOption: (entryNumber: number) => MemoizedSelector<StateWithPickupOption, PickupOption | undefined>;

declare const pickupOption_selectors_d_getPageContext: typeof getPageContext;
declare const pickupOption_selectors_d_getPickupOption: typeof getPickupOption;
declare namespace pickupOption_selectors_d {
  export {
    pickupOption_selectors_d_getPageContext as getPageContext,
    pickupOption_selectors_d_getPickupOption as getPickupOption,
  };
}

declare const getStockLevelState: MemoizedSelector<StateWithStock, StateUtils.LoaderState<StockLevelState>>;
declare const getStockEntities: MemoizedSelector<StateWithStock, StockLevelState>;
declare const getStockLoading: MemoizedSelector<StateWithStock, boolean>;
declare const getStockSuccess: MemoizedSelector<StateWithStock, boolean>;
declare const getStockError: MemoizedSelector<StateWithStock, boolean>;
declare const hasSearchStarted: MemoizedSelector<StateWithStock, boolean>;
declare const hasSearchStartedForProductCode: (productCode: string) => MemoizedSelector<StateWithStock, boolean>;
declare const getStoresWithStockForProductCode: (productCode: string) => MemoizedSelector<StateWithStock, PointOfServiceStock[]>;
declare const getStockAtStore: (productCode: string, storeName: string) => MemoizedSelector<StateWithStock, Stock | undefined>;

declare const stock_selectors_d_getStockAtStore: typeof getStockAtStore;
declare const stock_selectors_d_getStockEntities: typeof getStockEntities;
declare const stock_selectors_d_getStockError: typeof getStockError;
declare const stock_selectors_d_getStockLevelState: typeof getStockLevelState;
declare const stock_selectors_d_getStockLoading: typeof getStockLoading;
declare const stock_selectors_d_getStockSuccess: typeof getStockSuccess;
declare const stock_selectors_d_getStoresWithStockForProductCode: typeof getStoresWithStockForProductCode;
declare const stock_selectors_d_hasSearchStarted: typeof hasSearchStarted;
declare const stock_selectors_d_hasSearchStartedForProductCode: typeof hasSearchStartedForProductCode;
declare namespace stock_selectors_d {
  export {
    stock_selectors_d_getStockAtStore as getStockAtStore,
    stock_selectors_d_getStockEntities as getStockEntities,
    stock_selectors_d_getStockError as getStockError,
    stock_selectors_d_getStockLevelState as getStockLevelState,
    stock_selectors_d_getStockLoading as getStockLoading,
    stock_selectors_d_getStockSuccess as getStockSuccess,
    stock_selectors_d_getStoresWithStockForProductCode as getStoresWithStockForProductCode,
    stock_selectors_d_hasSearchStarted as hasSearchStarted,
    stock_selectors_d_hasSearchStartedForProductCode as hasSearchStartedForProductCode,
  };
}

declare class PickupLocationsSearchService implements PickupLocationsSearchFacade, OnDestroy {
    protected store: Store<StateWithStock & StateWithPickupLocations>;
    subscription: Subscription;
    constructor(store: Store<StateWithStock & StateWithPickupLocations>);
    stockLevelAtStore(productCode: string, storeName: string): void;
    getStockLevelAtStore(productCode: string, storeName: string): Observable<Stock | undefined>;
    startSearch(searchParams: StockLocationSearchParams): void;
    hasSearchStarted(productCode: string): Observable<boolean>;
    isSearchRunning(): Observable<boolean>;
    getSearchResults(productCode: string): Observable<PointOfServiceStock[]>;
    clearSearchResults(): void;
    getHideOutOfStock(): Observable<boolean>;
    setBrowserLocation(latitude: number, longitude: number): void;
    toggleHideOutOfStock(): void;
    loadStoreDetails(storeName: string): void;
    getStoreDetails(name: string): Observable<PointOfService>;
    loadAndGetStoreDetails(name: string): Observable<PointOfService>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupLocationsSearchService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PickupLocationsSearchService>;
}

/**
 * A service for managing the page context and pickup option for a cart entry.
 */
declare class PickupOptionService implements PickupOptionFacade {
    protected store: Store<StateWithPickupOption>;
    constructor(store: Store<StateWithPickupOption>);
    setPageContext(pageContext: string): void;
    getPageContext(): Observable<string>;
    setPickupOption(entryNumber: number, pickupOption: PickupOption): void;
    getPickupOption(entryNumber: number): Observable<PickupOption | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupOptionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PickupOptionService>;
}

declare class PickupInStoreCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupInStoreCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PickupInStoreCoreModule, never, [typeof PickupInStoreStoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PickupInStoreCoreModule>;
}

/**
 * Service to store the user's preferred store for Pickup in Store in local storage.
 */
declare class PreferredStoreService implements PreferredStoreFacade {
    protected config: PickupInStoreConfig;
    protected pickupLocationsSearchService: PickupLocationsSearchFacade;
    protected winRef: WindowRef;
    protected store: Store<StateWithPickupLocations>;
    constructor(config: PickupInStoreConfig, pickupLocationsSearchService: PickupLocationsSearchFacade, winRef: WindowRef, store: Store<StateWithPickupLocations>);
    /**
     * Gets the user's preferred store for Pickup in Store.
     * @returns the preferred store from the store
     */
    getPreferredStore$(): Observable<PointOfServiceNames | null>;
    /**
     * Sets the user's preferred store for Pickup in Store.
     * @param preferredStore the preferred store to set
     */
    setPreferredStore(preferredStore: PointOfServiceNames): void;
    /**
     * Clears the user's preferred store for Pickup in Store.
     */
    clearPreferredStore(): void;
    /**
     * Get the user's preferred store from local storage and only return it if it
     * has stock for the given product.
     * @param productCode The product code to check the stock level of
     */
    getPreferredStoreWithProductInStock(productCode: string): Observable<PointOfServiceNames>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PreferredStoreService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PreferredStoreService>;
}

declare function isInStock(stockInfo: Stock | undefined): boolean;
declare function storeHasStock({ stockInfo }: PointOfServiceStock): boolean;

export { browserLocation_action_d as BrowserLocationActions, defaultPointOfServiceName_action_d as DefaultPointOfServiceActions, DefaultPointOfServiceEffect, defaultPointOfServiceName_selectors_d as DefaultPointOfServiceSelectors, hideOutOfStock_selectors_d as HideOutOfStockSelectors, PICKUP_LOCATIONS_FEATURE, PICKUP_OPTION_FEATURE, PickupInStoreConfig, PickupInStoreCoreModule, PickupInStoreStoreModule, pickupLocation_action_d as PickupLocationActions, PickupLocationAdapter, PickupLocationConnector, PickupLocationEffect, PickupLocationsSearchService, pickupLocations_selectors_d as PickupLocationsSelectors, pickupOption_action_d as PickupOptionActions, pickupOption_selectors_d as PickupOptionSelectors, PickupOptionService, PreferredStoreService, STOCK_DATA, STOCK_FEATURE, StockAdapter, StockConnector, StockEffect, stock_action_d as StockLevelActions, stock_selectors_d as StockSelectors, TOGGLE_HIDE_OUT_OF_STOCK_OPTIONS, ToggleHideOutOfStockOptionsAction, clearStockState, defaultPickupInStoreConfig, effects, facadeProviders, getPickupReducers, getReducers, isInStock, pickupLocationsMetaReducers, pickupLocationsReducersProvider, pickupLocationsReducersToken, pickupOptionMetaReducers, pickupOptionReducersProvider, pickupOptionReducersToken, stockMetaReducers, stockReducersProvider, stockReducersToken, storeHasStock };
export type { BrowserLocation, EntryPickupOption, IntendedPickupLocationsState, PickupLocationsState, PickupOptionState, StateWithPickupLocations, StateWithPickupOption, StateWithStock, StockLevelState, StockState };
