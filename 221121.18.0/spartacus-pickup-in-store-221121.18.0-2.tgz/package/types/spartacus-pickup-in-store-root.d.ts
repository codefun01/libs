import { Observable } from 'rxjs';
import { PointOfService, PointOfServiceStock, Stock, CmsConfig } from '@spartacus/core';
import * as i0 from '@angular/core';
import { OrderEntry, Cart } from '@spartacus/cart/base/root';

/** The options for receiving a product, either 'delivery' or 'pickup'. */
type PickupOption = 'delivery' | 'pickup';
/** A point of service with the additional pickup option information. */
type AugmentedPointOfService = PointOfService & {
    pickupOption: PickupOption;
};

/**
 * Store the Point of Service a user wants to collect a product from before it is added to the cart.
 */
declare abstract class IntendedPickupLocationFacade {
    /**
     * Get the Point of Service a user wants to collect a product from before it is added to the cart.
     * @param productCode The product code of the product the user wants to collect.
     */
    abstract getIntendedLocation(productCode: string): Observable<AugmentedPointOfService | undefined>;
    /**
     * Set the Point of Service a user wants to collect a product from before it is added to the cart.
     * @param productCode The product code of the product the user wants to collect.
     * @param location The Point of Service the user wants to collect the product from.
     */
    abstract setIntendedLocation(productCode: string, location: AugmentedPointOfService): void;
    /**
     * Remove the Point of Service a user wanted to collect a product from before it was to be added to the cart.
     * @param productCode The product code of the product the user wants to collect.
     */
    abstract removeIntendedLocation(productCode: string): void;
    /**
     * Get the Pickup Option ('pickup' or 'delivery') a user wants
     * @param productCode The product code of the product the user wants to collect.
     */
    abstract getPickupOption(productCode: string): Observable<PickupOption>;
    /**
     * Set the Pickup Option ('pickup' or 'delivery') a user wants
     * @param productCode The product code of the product the user wants to set the pickup location for.
     */
    abstract setPickupOption(productCode: string, pickupOption: PickupOption): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IntendedPickupLocationFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IntendedPickupLocationFacade>;
}

declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        PICKUP_IN_STORE = "PICKUP_IN_STORE"
    }
}

type DeliveryPointOfServiceItems = {
    name: string;
    storeDetails: PointOfService;
    value: Array<OrderEntry>;
};
type DeliveryPointOfService = {
    name: string;
    value: Array<OrderEntry>;
    storeDetails: PointOfService;
};

/** The latitude and longitude of the user for searching for a location. */
type BrowserLocationSearchParameters = {
    latitude: number;
    longitude: number;
};
/** The free text string for search for a location. */
type FreeTextSearchParameters = {
    location: string;
};
/** The search parameters for finding a location, either by latitude and longitude or a free text search. */
type LocationSearchParams = BrowserLocationSearchParameters | FreeTextSearchParameters;
/** A product code and the search parameters for finding a store with stock for it. */
type StockLocationSearchParams = {
    productCode: string;
} & LocationSearchParams;

/** A utility type that represents the type of items in an array without the first item */
type Shift<T extends any[]> = ((...t: T) => any) extends (first: any, ...rest: infer Rest) => any ? Rest : never;
/** A distributed conditional utility type for Shift */
type ShiftUnion<P extends PropertyKey, T extends any[]> = T extends any[] ? T[0] extends P ? Shift<T> : never : never;
/**
 * A utility type that takes a base type and a union of arrays of strings that
 * represent the paths to properties on that type. The returned type is the same
 * as the base but with all referenced properties required.
 */
type RequiredDeepArray<T, P extends string[]> = T extends object ? Omit<T, Extract<keyof T, P[0]>> & PickRequiredDeepArray<T, P> : T;
/**
 * A utility type that takes a base type and a union of arrays of strings that
 * represent the paths to properties on that type. The returned type has only
 * the referenced properties and makes them all required.
 */
type PickRequiredDeepArray<T, P extends string[]> = T extends object ? Required<{
    [K in Extract<keyof T, P[0]>]: NonNullable<PickRequiredDeepArray<T[K], ShiftUnion<P[0], P>>>;
}> : T;
/** A utility type that takes a string literal type and splits it are the `.` character */
type PathToStringArray<T extends string> = T extends `${infer Head}.${infer Tail}` ? [...PathToStringArray<Head>, ...PathToStringArray<Tail>] : [T];
/**
 * A utility type that takes a base type and a union of strings that represent
 * the paths to properties on that type. The returned type is the same as the
 * base but with all referenced properties required.
 *
 * @example ```ts
    type Foo = { a?: 2, b?: { c?: 3, d: 4 } }
    type A = RequiredDeepPath<Foo, "a">; // {a: 2, b?: { c?: 3, d: 4 } }
    type B = RequiredDeepPath<Foo, "b">; // {a?: 2, b: { c?: 3, d: 4 } }
    type BC = RequiredDeepPath<Foo, "b.c">; // {a?: 2, b: { c: 3, d: 4 } }
    type ABC = RequiredDeepPath<Foo, "a" | "b.c">; // {a: 2, b: { c: 3, d: 4 } }
 * ```
 */
type RequiredDeepPath<T, P extends string> = RequiredDeepArray<T, PathToStringArray<P>>;
/**
 * A utility type that takes a base type and a union of strings that represent
 * the paths to properties on that type. The returned type has only the
 * referenced properties and makes them all required.
 *
 * @example ```ts
    type Foo = { a?: 2, b?: { c?: 3, d: 4 } }
    type A = PickRequiredDeep<Foo, "a">; // { a: 2 }
    type B = PickRequiredDeep<Foo, "b">; // { b: {} }
    type BC = PickRequiredDeep<Foo, "b.c">; // { b: { c: 3 }}
    type ABC = PickRequiredDeep<Foo, "a" | "b.c">; // { a: 2, b: { c: 3 } }
 * ```
 */
type PickRequiredDeep<T, P extends string> = PickRequiredDeepArray<T, PathToStringArray<P>>;
/** A cart with the ids required for pickup in store */
type CartWithIdAndUserId = RequiredDeepPath<Cart, 'guid' | 'user.uid' | 'code'>;

declare const getProperty: (o: Record<string, any> | undefined | null, property: string) => any | null;
/** Custom type guard to ensure we have a cart with the required ids for pickup in store */
declare function cartWithIdAndUserId(cart: Cart | undefined): cart is CartWithIdAndUserId;

type PointOfServiceNames = PickRequiredDeep<PointOfServiceStock, 'name' | 'displayName'>;

declare abstract class PickupLocationsSearchFacade {
    abstract stockLevelAtStore(productCode: string, storeName: string): void;
    abstract getStockLevelAtStore(productCode: string, storeName: string): Observable<Stock | undefined>;
    abstract startSearch(searchParams: StockLocationSearchParams): void;
    abstract hasSearchStarted(productCode: string): Observable<boolean>;
    abstract isSearchRunning(): Observable<boolean>;
    abstract getSearchResults(productCode: string): Observable<PointOfServiceStock[]>;
    abstract clearSearchResults(): void;
    abstract getHideOutOfStock(): Observable<boolean>;
    abstract setBrowserLocation(latitude: number, longitude: number): void;
    abstract toggleHideOutOfStock(): void;
    abstract getStoreDetails(name: string): Observable<PointOfService>;
    abstract loadStoreDetails(name: string): void;
    abstract loadAndGetStoreDetails(name: string): Observable<PointOfService>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupLocationsSearchFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PickupLocationsSearchFacade>;
}

declare abstract class PickupOptionFacade {
    abstract setPageContext(pageContext: string): void;
    abstract getPageContext(): Observable<string>;
    abstract setPickupOption(entryNumber: number, pickupOption: PickupOption): void;
    abstract getPickupOption(entryNumber: number): Observable<PickupOption | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupOptionFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PickupOptionFacade>;
}

/**
 * Service to store the user's preferred store for Pickup in Store in local storage.
 */
declare abstract class PreferredStoreFacade {
    /**
     * Gets the user's preferred store for Pickup in Store.
     * @returns the preferred store from the store
     */
    abstract getPreferredStore$(): Observable<PointOfServiceNames | null>;
    /**
     * Sets the user's preferred store for Pickup in Store.
     * @param preferredStore the preferred store to set
     */
    abstract setPreferredStore(preferredStore: PointOfServiceNames): void;
    /**
     * Clears the user's preferred store for Pickup in Store.
     */
    abstract clearPreferredStore(): void;
    /**
     * Get the user's preferred store from local storage and only return it if it
     * has stock for the given product.
     * @param productCode The product code to check the stock level of
     */
    abstract getPreferredStoreWithProductInStock(productCode: string): Observable<PointOfServiceNames>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PreferredStoreFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PreferredStoreFacade>;
}

/** pickup-in-store feature name. */
declare const PICKUP_IN_STORE_FEATURE = "pickupInStore";
/** pickup-in-store core feature name. */
declare const PICKUP_IN_STORE_CORE_FEATURE = "pickupInStoreCore";

/** The used for storing the name of the user's preferred store in browser local storage. */
declare const PREFERRED_STORE_LOCAL_STORAGE_KEY = "preferred_store";

declare function defaultPickupInStoreComponentsConfig(): CmsConfig;
declare class PickupInStoreRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupInStoreRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PickupInStoreRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PickupInStoreRootModule>;
}

export { IntendedPickupLocationFacade, PICKUP_IN_STORE_CORE_FEATURE, PICKUP_IN_STORE_FEATURE, PREFERRED_STORE_LOCAL_STORAGE_KEY, PickupInStoreRootModule, PickupLocationsSearchFacade, PickupOptionFacade, PreferredStoreFacade, cartWithIdAndUserId, defaultPickupInStoreComponentsConfig, getProperty };
export type { AugmentedPointOfService, CartWithIdAndUserId, DeliveryPointOfService, DeliveryPointOfServiceItems, LocationSearchParams, PickRequiredDeep, PickupOption, PointOfServiceNames, RequiredDeepPath, StockLocationSearchParams };
