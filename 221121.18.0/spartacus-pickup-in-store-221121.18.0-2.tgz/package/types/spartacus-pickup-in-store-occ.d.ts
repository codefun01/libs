import { OccConfig, OccEndpointsService, LoggerService, PointOfService, StoreFinderStockSearchPage, Stock, OccEndpoint } from '@spartacus/core';
import { HttpClient } from '@angular/common/http';
import { PickupLocationAdapter, StockAdapter } from '@spartacus/pickup-in-store/core';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import { LocationSearchParams } from '@spartacus/pickup-in-store/root';

/**
 * The endpoints to call from the OCC adapter for pickup locations.
 */
declare const defaultOccPickupLocationConfig: OccConfig;

/**
 * The endpoints to call from the OCC adapter for stock levels.
 */
declare const defaultOccStockConfig: OccConfig;

declare class OccPickupLocationAdapter implements PickupLocationAdapter {
    protected http: HttpClient;
    protected occEndpointsService: OccEndpointsService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpointsService: OccEndpointsService);
    getStoreDetails(storeName: string): Observable<PointOfService>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccPickupLocationAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccPickupLocationAdapter>;
}

/**
 * Adapter for finding stock levels of a product in stores from the OCC APIs.
 */
declare class OccStockAdapter implements StockAdapter {
    protected http: HttpClient;
    protected occEndpointsService: OccEndpointsService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpointsService: OccEndpointsService);
    loadStockLevels(productCode: string, location: LocationSearchParams): Observable<StoreFinderStockSearchPage>;
    loadStockLevelAtStore(productCode: string, storeName: string): Observable<Stock>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccStockAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccStockAdapter>;
}

declare module '@spartacus/core' {
    interface OccEndpoints {
        /**
         * Get store details by store Name.
         *
         * @member {string} [storeDetails]
         */
        storeDetails?: string | OccEndpoint;
    }
}

declare module '@spartacus/core' {
    interface OccEndpoints {
        /**
         * Get a stock level for a product.
         *
         * @member {string} [page]
         */
        stock?: string | OccEndpoint;
        /**
         * Get a stock level for a product at a specific store.
         *
         * @member {string} [page]
         */
        stockAtStore?: string | OccEndpoint;
    }
}

declare class PickupInStoreOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupInStoreOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PickupInStoreOccModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PickupInStoreOccModule>;
}

export { OccPickupLocationAdapter, OccStockAdapter, PickupInStoreOccModule, defaultOccPickupLocationConfig, defaultOccStockConfig };
