import * as i0 from '@angular/core';

declare class SegmentRefsRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SegmentRefsRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SegmentRefsRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SegmentRefsRootModule>;
}

export { SegmentRefsRootModule };
