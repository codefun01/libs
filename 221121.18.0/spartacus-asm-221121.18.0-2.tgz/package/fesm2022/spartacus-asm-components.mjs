import * as i0 from '@angular/core';
import { Component, ChangeDetectionStrategy, inject, Injectable, ViewChild, Pipe, EventEmitter, Output, Input, ViewChildren, HostBinding, NgModule } from '@angular/core';
import * as i1$1 from '@spartacus/core';
import { TranslatePipe, GlobalMessageType, RoutingService, OCC_CART_ID_CURRENT, HttpResponseStatus, FeatureModulesService, OAuthLibWrapperService, FeatureDirective, I18nModule, FeaturesConfigModule, provideDefaultConfig } from '@spartacus/core';
import * as i1 from '@spartacus/storefront';
import { FocusDirective, MessageComponent, LAUNCH_CALLER, ICON_TYPE, CustomFormValidators, FormErrorsComponent, FormRequiredAsterisksComponent, FormRequiredLegendComponent, SpinnerComponent, DIALOG_TYPE, PasswordVisibilityToggleDirective, DirectionMode, IconComponent, BREAKPOINT, PaginationComponent, SortingComponent, NgSelectA11yDirective, FormErrorsModule, IconModule, SpinnerModule, PasswordVisibilityToggleModule, KeyboardFocusModule, NgSelectA11yModule, SortingModule, PaginationModule, MessageComponentModule } from '@spartacus/storefront';
import { NgIf, AsyncPipe, NgClass, NgFor, NgTemplateOutlet, CommonModule } from '@angular/common';
import * as i1$2 from '@angular/forms';
import { FormControl, Validators, FormsModule, ReactiveFormsModule, UntypedFormControl } from '@angular/forms';
import { BehaviorSubject, Subscription, combineLatest, iif, defer, EMPTY, of, NEVER } from 'rxjs';
import { take, map, shareReplay, filter, tap, concatMap, finalize, first, distinctUntilChanged, debounceTime, switchMap } from 'rxjs/operators';
import * as i2 from '@spartacus/cart/saved-cart/root';
import * as i2$2 from '@spartacus/cart/base/root';
import * as i2$1 from '@spartacus/asm/root';
import { ASM_ENABLED_LOCAL_STORAGE_KEY, AsmConfig, CustomerListColumnActionType, CLOSE_DIALOG_REASON } from '@spartacus/asm/root';
import { AsmDialogActionType } from '@spartacus/asm/customer-360/root';
import { NgSelectComponent, NgSelectModule } from '@ng-select/ng-select';
import * as i1$3 from '@spartacus/asm/core';
import * as i2$3 from '@spartacus/user/account/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var BIND_CART_DIALOG_ACTION;
(function (BIND_CART_DIALOG_ACTION) {
    BIND_CART_DIALOG_ACTION["CANCEL"] = "CANCEL";
    BIND_CART_DIALOG_ACTION["REPLACE"] = "REPLACE";
})(BIND_CART_DIALOG_ACTION || (BIND_CART_DIALOG_ACTION = {}));
class AsmBindCartDialogComponent {
    constructor(launchDialogService) {
        this.launchDialogService = launchDialogService;
        this.BIND_CART_ACTION = BIND_CART_DIALOG_ACTION;
        this.focusConfig = {
            trap: true,
            block: true,
            autofocus: true,
            focusOnEscape: true,
        };
    }
    closeModal(reason) {
        this.launchDialogService.closeDialog(reason);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmBindCartDialogComponent, deps: [{ token: i1.LaunchDialogService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: AsmBindCartDialogComponent, isStandalone: true, selector: "cx-asm-bind-cart-dialog", ngImport: i0, template: "<div\n  class=\"cx-asm-bind-cart-dialog cx-modal-container cx-asm-dialog\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"closeModal(BIND_CART_ACTION.CANCEL)\"\n  aria-labelledby=\"asm-bind-cart-dialog-title\"\n>\n  <div class=\"cx-modal-content\">\n    <!-- Modal Header -->\n    <div class=\"cx-dialog-header modal-header\">\n      <h2 id=\"asm-bind-cart-dialog-title\" class=\"title modal-title\">\n        {{ 'asm.bindCart.dialog.title' | cxTranslate }}\n      </h2>\n    </div>\n\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\">\n      <div class=\"cx-dialog-row\">\n        <div class=\"cx-dialog-item\">\n          {{ 'asm.bindCart.dialog.body' | cxTranslate }}\n        </div>\n      </div>\n    </div>\n\n    <!-- Modal Footer -->\n    <div class=\"cx-dialog-footer modal-footer\">\n      <button\n        (click)=\"closeModal(BIND_CART_ACTION.REPLACE)\"\n        [attr.aria-label]=\"'asm.bindCart.dialog.actions.replace' | cxTranslate\"\n        class=\"btn btn-primary\"\n        type=\"button\"\n      >\n        {{ 'asm.bindCart.dialog.actions.replace' | cxTranslate }}\n      </button>\n\n      <button\n        (click)=\"closeModal(BIND_CART_ACTION.CANCEL)\"\n        [attr.aria-label]=\"'common.cancel' | cxTranslate\"\n        class=\"btn btn-secondary\"\n        type=\"button\"\n      >\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmBindCartDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-asm-bind-cart-dialog', imports: [FocusDirective, TranslatePipe], template: "<div\n  class=\"cx-asm-bind-cart-dialog cx-modal-container cx-asm-dialog\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"closeModal(BIND_CART_ACTION.CANCEL)\"\n  aria-labelledby=\"asm-bind-cart-dialog-title\"\n>\n  <div class=\"cx-modal-content\">\n    <!-- Modal Header -->\n    <div class=\"cx-dialog-header modal-header\">\n      <h2 id=\"asm-bind-cart-dialog-title\" class=\"title modal-title\">\n        {{ 'asm.bindCart.dialog.title' | cxTranslate }}\n      </h2>\n    </div>\n\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\">\n      <div class=\"cx-dialog-row\">\n        <div class=\"cx-dialog-item\">\n          {{ 'asm.bindCart.dialog.body' | cxTranslate }}\n        </div>\n      </div>\n    </div>\n\n    <!-- Modal Footer -->\n    <div class=\"cx-dialog-footer modal-footer\">\n      <button\n        (click)=\"closeModal(BIND_CART_ACTION.REPLACE)\"\n        [attr.aria-label]=\"'asm.bindCart.dialog.actions.replace' | cxTranslate\"\n        class=\"btn btn-primary\"\n        type=\"button\"\n      >\n        {{ 'asm.bindCart.dialog.actions.replace' | cxTranslate }}\n      </button>\n\n      <button\n        (click)=\"closeModal(BIND_CART_ACTION.CANCEL)\"\n        [attr.aria-label]=\"'common.cancel' | cxTranslate\"\n        class=\"btn btn-secondary\"\n        type=\"button\"\n      >\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1.LaunchDialogService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var SAVE_CART_DIALOG_ACTION;
(function (SAVE_CART_DIALOG_ACTION) {
    SAVE_CART_DIALOG_ACTION["CANCEL"] = "CANCEL";
    SAVE_CART_DIALOG_ACTION["SAVE"] = "SAVE";
})(SAVE_CART_DIALOG_ACTION || (SAVE_CART_DIALOG_ACTION = {}));
class AsmSaveCartDialogComponent {
    constructor(launchDialogService, savedCartFacade) {
        this.launchDialogService = launchDialogService;
        this.savedCartFacade = savedCartFacade;
        this.BIND_CART_ACTION = SAVE_CART_DIALOG_ACTION;
        this.showDialogAlert$ = new BehaviorSubject(true);
        this.globalMessageType = GlobalMessageType;
        this.focusConfig = {
            trap: true,
            block: true,
            autofocus: true,
            focusOnEscape: true,
        };
    }
    ngOnInit() {
        this.launchDialogService.data$.pipe(take(1)).subscribe((data) => {
            this.cart = data;
            this.setCartTotalQty();
        });
    }
    setCartTotalQty() {
        let count = 0;
        if (this.cart.entries) {
            for (const entry of this.cart.entries) {
                count += entry.quantity ? entry.quantity : 0;
            }
        }
        this.cartQty = count;
    }
    closeDialogAlert() {
        this.showDialogAlert$.next(false);
    }
    closeModal(reason) {
        if (reason === SAVE_CART_DIALOG_ACTION.SAVE) {
            this.saveCart();
        }
        this.launchDialogService.closeDialog(reason);
    }
    saveCart() {
        this.savedCartFacade.saveCart({
            cartId: this.cart.code,
            saveCartName: this.cart.code,
            saveCartDescription: '-',
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmSaveCartDialogComponent, deps: [{ token: i1.LaunchDialogService }, { token: i2.SavedCartFacade }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: AsmSaveCartDialogComponent, isStandalone: true, selector: "cx-asm-save-cart-dialog", ngImport: i0, template: "<div\n  class=\"cx-asm-save-cart-dialog cx-modal-container cx-asm-dialog\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"closeModal(BIND_CART_ACTION.CANCEL)\"\n  aria-labelledby=\"asm-save-cart-dialog-title\"\n>\n  <div class=\"cx-modal-content\">\n    <!-- Modal Header -->\n    <div class=\"cx-dialog-header modal-header\">\n      <h2 id=\"asm-save-cart-dialog-title\" class=\"title modal-title\">\n        {{ 'asm.saveCart.dialog.title' | cxTranslate }}\n      </h2>\n    </div>\n\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\">\n      <ng-container *ngIf=\"cartQty > 0; else showSaveCartWarning\">\n        <div class=\"message-container\">\n          <cx-message\n            *ngIf=\"showDialogAlert$ | async\"\n            [text]=\"'asm.saveCart.dialog.saveInfo' | cxTranslate\"\n            [type]=\"globalMessageType.MSG_TYPE_INFO\"\n            (closeMessage)=\"closeDialogAlert()\"\n          >\n          </cx-message>\n        </div>\n      </ng-container>\n      <ng-template #showSaveCartWarning>\n        <div class=\"message-container\">\n          <cx-message\n            *ngIf=\"showDialogAlert$ | async\"\n            [text]=\"'asm.saveCart.dialog.disableInfo' | cxTranslate\"\n            [type]=\"globalMessageType.MSG_TYPE_WARNING\"\n            (closeMessage)=\"closeDialogAlert()\"\n          >\n          </cx-message>\n        </div>\n      </ng-template>\n\n      <div class=\"cx-dialog-content\">\n        <div class=\"cx-dialog-row row\">\n          <div\n            class=\"cx-dialog-item col-sm-6 col-md-6 text-right item-left-text\"\n          >\n            {{ 'asm.saveCart.dialog.row.id' | cxTranslate }}\n          </div>\n          <div\n            class=\"cx-dialog-item col-sm-6 col-md-6 text-left item-right-text\"\n          >\n            {{ cart.code }}\n          </div>\n        </div>\n        <div class=\"cx-dialog-row row\">\n          <div\n            class=\"cx-dialog-item col-sm-6 col-md-6 text-right item-left-text\"\n          >\n            {{ 'asm.saveCart.dialog.row.qtyFull' | cxTranslate }}\n          </div>\n          <div\n            class=\"cx-dialog-item col-sm-6 col-md-6 text-left item-right-text\"\n          >\n            {{ cartQty }}\n          </div>\n        </div>\n        <div class=\"cx-dialog-row row\">\n          <div\n            class=\"cx-dialog-item col-sm-6 col-md-6 text-right item-left-text\"\n          >\n            {{ 'asm.saveCart.dialog.row.total' | cxTranslate }}\n          </div>\n          <div\n            class=\"cx-dialog-item col-sm-6 col-md-6 text-left item-right-text\"\n          >\n            {{ cart.totalPriceWithTax?.formattedValue }}\n          </div>\n        </div>\n      </div>\n    </div>\n\n    <!-- Modal Footer -->\n    <div class=\"cx-dialog-footer modal-footer\">\n      <button\n        id=\"asm-save-cart-dialog-btn\"\n        (click)=\"closeModal(BIND_CART_ACTION.SAVE)\"\n        [attr.aria-label]=\"'asm.saveCart.dialog.actions.save' | cxTranslate\"\n        class=\"btn btn-primary\"\n        type=\"button\"\n        [disabled]=\"this.cartQty === 0\"\n      >\n        {{ 'asm.saveCart.dialog.actions.save' | cxTranslate }}\n      </button>\n\n      <button\n        (click)=\"closeModal(BIND_CART_ACTION.CANCEL)\"\n        [attr.aria-label]=\"'common.cancel' | cxTranslate\"\n        class=\"btn btn-secondary\"\n        type=\"button\"\n      >\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: MessageComponent, selector: "cx-message", inputs: ["text", "actionButtonText", "actionButtonMessage", "accordionText", "showBody", "isVisibleCloseButton", "type"], outputs: ["closeMessage", "buttonAction"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmSaveCartDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-asm-save-cart-dialog', imports: [FocusDirective, NgIf, MessageComponent, AsyncPipe, TranslatePipe], template: "<div\n  class=\"cx-asm-save-cart-dialog cx-modal-container cx-asm-dialog\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"closeModal(BIND_CART_ACTION.CANCEL)\"\n  aria-labelledby=\"asm-save-cart-dialog-title\"\n>\n  <div class=\"cx-modal-content\">\n    <!-- Modal Header -->\n    <div class=\"cx-dialog-header modal-header\">\n      <h2 id=\"asm-save-cart-dialog-title\" class=\"title modal-title\">\n        {{ 'asm.saveCart.dialog.title' | cxTranslate }}\n      </h2>\n    </div>\n\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\">\n      <ng-container *ngIf=\"cartQty > 0; else showSaveCartWarning\">\n        <div class=\"message-container\">\n          <cx-message\n            *ngIf=\"showDialogAlert$ | async\"\n            [text]=\"'asm.saveCart.dialog.saveInfo' | cxTranslate\"\n            [type]=\"globalMessageType.MSG_TYPE_INFO\"\n            (closeMessage)=\"closeDialogAlert()\"\n          >\n          </cx-message>\n        </div>\n      </ng-container>\n      <ng-template #showSaveCartWarning>\n        <div class=\"message-container\">\n          <cx-message\n            *ngIf=\"showDialogAlert$ | async\"\n            [text]=\"'asm.saveCart.dialog.disableInfo' | cxTranslate\"\n            [type]=\"globalMessageType.MSG_TYPE_WARNING\"\n            (closeMessage)=\"closeDialogAlert()\"\n          >\n          </cx-message>\n        </div>\n      </ng-template>\n\n      <div class=\"cx-dialog-content\">\n        <div class=\"cx-dialog-row row\">\n          <div\n            class=\"cx-dialog-item col-sm-6 col-md-6 text-right item-left-text\"\n          >\n            {{ 'asm.saveCart.dialog.row.id' | cxTranslate }}\n          </div>\n          <div\n            class=\"cx-dialog-item col-sm-6 col-md-6 text-left item-right-text\"\n          >\n            {{ cart.code }}\n          </div>\n        </div>\n        <div class=\"cx-dialog-row row\">\n          <div\n            class=\"cx-dialog-item col-sm-6 col-md-6 text-right item-left-text\"\n          >\n            {{ 'asm.saveCart.dialog.row.qtyFull' | cxTranslate }}\n          </div>\n          <div\n            class=\"cx-dialog-item col-sm-6 col-md-6 text-left item-right-text\"\n          >\n            {{ cartQty }}\n          </div>\n        </div>\n        <div class=\"cx-dialog-row row\">\n          <div\n            class=\"cx-dialog-item col-sm-6 col-md-6 text-right item-left-text\"\n          >\n            {{ 'asm.saveCart.dialog.row.total' | cxTranslate }}\n          </div>\n          <div\n            class=\"cx-dialog-item col-sm-6 col-md-6 text-left item-right-text\"\n          >\n            {{ cart.totalPriceWithTax?.formattedValue }}\n          </div>\n        </div>\n      </div>\n    </div>\n\n    <!-- Modal Footer -->\n    <div class=\"cx-dialog-footer modal-footer\">\n      <button\n        id=\"asm-save-cart-dialog-btn\"\n        (click)=\"closeModal(BIND_CART_ACTION.SAVE)\"\n        [attr.aria-label]=\"'asm.saveCart.dialog.actions.save' | cxTranslate\"\n        class=\"btn btn-primary\"\n        type=\"button\"\n        [disabled]=\"this.cartQty === 0\"\n      >\n        {{ 'asm.saveCart.dialog.actions.save' | cxTranslate }}\n      </button>\n\n      <button\n        (click)=\"closeModal(BIND_CART_ACTION.CANCEL)\"\n        [attr.aria-label]=\"'common.cancel' | cxTranslate\"\n        class=\"btn btn-secondary\"\n        type=\"button\"\n      >\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1.LaunchDialogService }, { type: i2.SavedCartFacade }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DotSpinnerComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DotSpinnerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: DotSpinnerComponent, isStandalone: true, selector: "cx-dot-spinner", ngImport: i0, template: "<div></div>\n<div></div>\n<div></div>\n", changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DotSpinnerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-dot-spinner', changeDetection: ChangeDetectionStrategy.OnPush, template: "<div></div>\n<div></div>\n<div></div>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AsmComponentService {
    constructor(authService, csAgentAuthService, winRef, asmEnablerService, asmDeepLinkService) {
        this.authService = authService;
        this.csAgentAuthService = csAgentAuthService;
        this.winRef = winRef;
        this.asmEnablerService = asmEnablerService;
        this.asmDeepLinkService = asmDeepLinkService;
        this.isEmulatedByDeepLink$ = new BehaviorSubject(false);
        this.showDeeplinkCartInfoAlert$ = new BehaviorSubject(false);
        this.routingService = inject(RoutingService);
    }
    /**
     * Returns a deep link parameter value if it is in the url.
     */
    getSearchParameter(key) {
        return this.asmDeepLinkService?.getSearchParameter(key);
    }
    isEmulatedByDeepLink() {
        return this.isEmulatedByDeepLink$;
    }
    setEmulatedByDeepLink(emulated) {
        this.isEmulatedByDeepLink$.next(emulated);
    }
    setShowDeeplinkCartInfoAlert(display) {
        this.showDeeplinkCartInfoAlert$.next(display);
    }
    shouldShowDeeplinkCartInfoAlert() {
        return this.showDeeplinkCartInfoAlert$;
    }
    logoutCustomerSupportAgentAndCustomer() {
        this.csAgentAuthService.logoutCustomerSupportAgent();
    }
    logoutCustomer() {
        this.authService.logout();
    }
    isCustomerEmulationSessionInProgress() {
        return this.csAgentAuthService.isCustomerEmulated();
    }
    /**
     * We're currently only removing the persisted storage in the browser
     * to ensure the ASM experience isn't loaded on the next visit. There are a few
     * optimizations we could think of:
     * - drop the `asm` parameter from the URL, in case it's still there
     * - remove the generated UI from the DOM (outlets currently do not support this)
     */
    unload() {
        if (this.winRef.localStorage) {
            this.winRef.localStorage.removeItem(ASM_ENABLED_LOCAL_STORAGE_KEY);
        }
    }
    /**
     * check whether try to emulate customer from deeplink
     */
    isEmulateInURL() {
        return this.asmDeepLinkService?.isEmulateInURL() || false;
    }
    /**
     * Returns valid deep link parameters in the url.
     */
    getDeepLinkUrlParams() {
        return this.asmDeepLinkService?.getParamsInUrl();
    }
    /**
     * Handles the navigation based on deep link parameters in the URL
     * or passed parameter.
     */
    handleDeepLinkNavigation(parameters = this.getDeepLinkUrlParams()) {
        this.asmDeepLinkService?.handleNavigation(parameters);
    }
    handleAsmDialogAction(event) {
        if (typeof event === 'object' &&
            event.actionType === AsmDialogActionType.NAVIGATE) {
            this.routingService.go(event.route);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmComponentService, deps: [{ token: i1$1.AuthService }, { token: i2$1.CsAgentAuthService }, { token: i1$1.WindowRef }, { token: i2$1.AsmEnablerService }, { token: i2$1.AsmDeepLinkService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmComponentService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmComponentService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.AuthService }, { type: i2$1.CsAgentAuthService }, { type: i1$1.WindowRef }, { type: i2$1.AsmEnablerService }, { type: i2$1.AsmDeepLinkService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AsmBindCartComponent {
    constructor(globalMessageService, activeCartFacade, multiCartFacade, asmBindCartFacade, launchDialogService, savedCartFacade, asmComponentService, routing) {
        this.globalMessageService = globalMessageService;
        this.activeCartFacade = activeCartFacade;
        this.multiCartFacade = multiCartFacade;
        this.asmBindCartFacade = asmBindCartFacade;
        this.launchDialogService = launchDialogService;
        this.savedCartFacade = savedCartFacade;
        this.asmComponentService = asmComponentService;
        this.routing = routing;
        this.activeCartValidator = (control) => {
            if (control.value === this.activeCartId) {
                return { activeCartError: true };
            }
            if (this.deepLinkCartId && control.value !== this.deepLinkCartId) {
                this.resetDeeplinkCart();
            }
            return null;
        };
        this.cartId = new FormControl('', [
            Validators.required,
            Validators.minLength(1),
            this.activeCartValidator,
        ]);
        this.loading$ = new BehaviorSubject(false);
        this.valid$ = this.cartId.statusChanges.pipe(map((status) => status === 'VALID'), shareReplay(1));
        this.activeCartId = '';
        this.deepLinkCartId = '';
        this.displayBindCartBtn$ = new BehaviorSubject(true);
        this.displaySaveCartBtn$ = new BehaviorSubject(false);
        this.subscription = new Subscription();
    }
    ngOnInit() {
        this.subscribeForDeeplinkCart();
        this.subscription.add(this.activeCartFacade.getActiveCartId().subscribe((response) => {
            this.activeCartId = response ?? '';
        }));
    }
    /**
     * Bind the input cart number to the customer
     */
    bindCartToCustomer() {
        const anonymousCartId = this.cartId.value;
        const subscription = combineLatest([
            this.loading$.asObservable(),
            this.valid$,
        ])
            .pipe(take(1), filter(([loading, valid]) => !loading && valid), tap(() => this.loading$.next(true)), concatMap(() => this.activeCartFacade.getActive().pipe(map((cart) => cart.deliveryItemsQuantity ?? 0), take(1))), concatMap((cartItemCount) => iif(() => Boolean(this.activeCartId && cartItemCount), this.openDialog(this.activeCartId, anonymousCartId), this.simpleBindCart(anonymousCartId))), finalize(() => this.loading$.next(false)))
            .subscribe({
            next: () => {
                this.globalMessageService.add({ key: 'asm.bindCart.success' }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
            },
            error: (error) => {
                this.globalMessageService.add(error.details?.[0].message ?? '', GlobalMessageType.MSG_TYPE_ERROR);
            },
        });
        this.subscription.add(subscription);
    }
    onSaveInactiveCart() {
        this.asmComponentService?.setShowDeeplinkCartInfoAlert(false);
        const customerId = this.asmComponentService?.getSearchParameter('customerId');
        this.multiCartFacade.loadCart({
            cartId: this.deepLinkCartId,
            userId: customerId,
        });
        this.multiCartFacade
            .getCartEntity(this.deepLinkCartId)
            .pipe(filter((state) => state.loading === false && state.success === true), take(1), map((state) => state.value), filter((cart) => !!cart))
            .subscribe((cart) => {
            this.openASMSaveCartDialog(cart);
        });
        this.afterCloseASMSaveCartDialog();
    }
    clearText() {
        this.cartId.setValue('');
        this.resetDeeplinkCart();
    }
    resetDeeplinkCart() {
        this.deepLinkCartId = '';
        this.displayBindCartBtn$.next(true);
        this.displaySaveCartBtn$.next(false);
        this.asmComponentService?.setShowDeeplinkCartInfoAlert(false);
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    /**
     * Binds cart on subscription and reloads cart
     */
    simpleBindCart(anonymousCartId) {
        return defer(() => this.asmBindCartFacade.bindCart(anonymousCartId)).pipe(tap(() => this.multiCartFacade.reloadCart(OCC_CART_ID_CURRENT)));
    }
    /**
     * Opens dialog and passes non-cancel result to select action
     */
    openDialog(activeCartId, anonymousCartId) {
        return defer(() => {
            this.launchDialogService.openDialogAndSubscribe(LAUNCH_CALLER.ASM_BIND_CART, this.bindToCartElemRef);
            return this.launchDialogService.dialogClose.pipe(filter((result) => Boolean(result)), take(1));
        }).pipe(filter((dialogResult) => Boolean(dialogResult)), concatMap((dialogResult) => {
            return this.selectBindAction(activeCartId, anonymousCartId, dialogResult);
        }));
    }
    selectBindAction(activeCartId, anonymousCartId, action) {
        switch (action) {
            case BIND_CART_DIALOG_ACTION.REPLACE:
                return this.replaceCart(activeCartId, anonymousCartId);
            case BIND_CART_DIALOG_ACTION.CANCEL:
            default:
                return EMPTY;
        }
    }
    replaceCart(previousActiveCartId, anonymousCartId) {
        return this.simpleBindCart(anonymousCartId).pipe(tap(() => {
            this.savedCartFacade.saveCart({
                cartId: previousActiveCartId,
                saveCartName: previousActiveCartId,
                // TODO(#12660): Remove default value once backend is updated
                saveCartDescription: '-',
            });
        }));
    }
    subscribeForDeeplinkCart() {
        this.subscription.add(this.asmComponentService
            ?.isEmulatedByDeepLink()
            .pipe(filter((emulated) => emulated &&
            !!this.asmComponentService?.getSearchParameter('cartId')))
            .subscribe(() => {
            const cartType = this.asmComponentService?.getSearchParameter('cartType');
            if (cartType === 'inactive' || cartType === 'active') {
                this.displayBindCartBtn$.next(false);
                this.displaySaveCartBtn$.next(cartType === 'inactive');
                this.deepLinkCartId = this.asmComponentService?.getSearchParameter('cartId');
                if (cartType === 'inactive') {
                    this.cartId.setValue(this.deepLinkCartId);
                }
                this.asmComponentService?.setShowDeeplinkCartInfoAlert(true);
                this.asmComponentService?.handleDeepLinkNavigation();
            }
        }));
    }
    openASMSaveCartDialog(inactiveCart) {
        this.launchDialogService.openDialogAndSubscribe(LAUNCH_CALLER.ASM_SAVE_CART, this.saveInactiveCartElemRef, inactiveCart);
    }
    afterCloseASMSaveCartDialog() {
        this.launchDialogService.dialogClose
            .pipe(filter((result) => result === SAVE_CART_DIALOG_ACTION.SAVE), take(1), tap(() => this.loading$.next(true)))
            .subscribe();
        this.savedCartFacade
            .getSaveCartProcessSuccess()
            .pipe(filter((success) => success), take(1), tap(() => this.loading$.next(false)))
            .subscribe(() => {
            this.goToSavedCartDetails(this.deepLinkCartId);
            this.displaySaveCartBtn$.next(false);
        });
        this.savedCartFacade
            .getSaveCartProcessError()
            .pipe(filter((error) => error), take(1), tap(() => this.loading$.next(false)))
            .subscribe();
    }
    goToSavedCartDetails(cartId) {
        this.routing?.go({
            cxRoute: 'savedCartsDetails',
            params: { savedCartId: cartId },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmBindCartComponent, deps: [{ token: i1$1.GlobalMessageService }, { token: i2$2.ActiveCartFacade }, { token: i2$2.MultiCartFacade }, { token: i2$1.AsmBindCartFacade }, { token: i1.LaunchDialogService }, { token: i2.SavedCartFacade }, { token: AsmComponentService }, { token: i1$1.RoutingService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: AsmBindCartComponent, isStandalone: true, selector: "cx-asm-bind-cart", viewQueries: [{ propertyName: "bindToCartElemRef", first: true, predicate: ["bindToCart"], descendants: true }, { propertyName: "saveInactiveCartElemRef", first: true, predicate: ["saveInactiveCart"], descendants: true }], ngImport: i0, template: "<form>\n  <label for=\"cartNumber\">{{ 'asm.bindCart.cartNumber' | cxTranslate }} </label>\n  <div\n    [ngClass]=\"'cx-asm-assignCart-input-show-no-button'\"\n    [class.active]=\"valid$ | async\"\n    (click)=\"cartIdElement.focus()\"\n  >\n    <input\n      id=\"cartNumber\"\n      autocomplete=\"off\"\n      #cartIdElement\n      formcontrolname=\"cartNumber\"\n      [formControl]=\"cartId\"\n      (keydown.enter)=\"bindCartToCustomer()\"\n    />\n  </div>\n  <button\n    #bindToCart\n    *ngIf=\"displayBindCartBtn$ | async\"\n    class=\"cx-asm-bindCartToCustomer\"\n    [disabled]=\"!(valid$ | async)\"\n    type=\"submit\"\n    [class.cx-asm-active]=\"valid$ | async\"\n    [class.cx-bind-loading]=\"loading$ | async\"\n    (click)=\"bindCartToCustomer()\"\n  >\n    <span [attr.aria-hidden]=\"loading$ | async\">\n      {{ 'asm.bindCart.bindCartToCustomer' | cxTranslate }}\n    </span>\n    <cx-dot-spinner\n      [attr.aria-hidden]=\"!(loading$ | async)\"\n      [attr.aria-label]=\"'common.loading' | cxTranslate\"\n    ></cx-dot-spinner>\n  </button>\n\n  <button\n    id=\"asm-save-inactive-cart-btn\"\n    #saveInactiveCart\n    *ngIf=\"displaySaveCartBtn$ | async\"\n    class=\"cx-asm-bindCartToCustomer cx-asm-active\"\n    type=\"submit\"\n    [class.cx-bind-loading]=\"loading$ | async\"\n    (click)=\"onSaveInactiveCart()\"\n  >\n    <span [attr.aria-hidden]=\"loading$ | async\">\n      {{ 'asm.saveCart.saveCartBtn' | cxTranslate }}\n    </span>\n    <cx-dot-spinner\n      [attr.aria-hidden]=\"!(loading$ | async)\"\n      [attr.aria-label]=\"'common.loading' | cxTranslate\"\n    ></cx-dot-spinner>\n  </button>\n</form>\n", dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.NgForm, selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: DotSpinnerComponent, selector: "cx-dot-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmBindCartComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-asm-bind-cart', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        FormsModule,
                        NgClass,
                        ReactiveFormsModule,
                        NgIf,
                        DotSpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<form>\n  <label for=\"cartNumber\">{{ 'asm.bindCart.cartNumber' | cxTranslate }} </label>\n  <div\n    [ngClass]=\"'cx-asm-assignCart-input-show-no-button'\"\n    [class.active]=\"valid$ | async\"\n    (click)=\"cartIdElement.focus()\"\n  >\n    <input\n      id=\"cartNumber\"\n      autocomplete=\"off\"\n      #cartIdElement\n      formcontrolname=\"cartNumber\"\n      [formControl]=\"cartId\"\n      (keydown.enter)=\"bindCartToCustomer()\"\n    />\n  </div>\n  <button\n    #bindToCart\n    *ngIf=\"displayBindCartBtn$ | async\"\n    class=\"cx-asm-bindCartToCustomer\"\n    [disabled]=\"!(valid$ | async)\"\n    type=\"submit\"\n    [class.cx-asm-active]=\"valid$ | async\"\n    [class.cx-bind-loading]=\"loading$ | async\"\n    (click)=\"bindCartToCustomer()\"\n  >\n    <span [attr.aria-hidden]=\"loading$ | async\">\n      {{ 'asm.bindCart.bindCartToCustomer' | cxTranslate }}\n    </span>\n    <cx-dot-spinner\n      [attr.aria-hidden]=\"!(loading$ | async)\"\n      [attr.aria-label]=\"'common.loading' | cxTranslate\"\n    ></cx-dot-spinner>\n  </button>\n\n  <button\n    id=\"asm-save-inactive-cart-btn\"\n    #saveInactiveCart\n    *ngIf=\"displaySaveCartBtn$ | async\"\n    class=\"cx-asm-bindCartToCustomer cx-asm-active\"\n    type=\"submit\"\n    [class.cx-bind-loading]=\"loading$ | async\"\n    (click)=\"onSaveInactiveCart()\"\n  >\n    <span [attr.aria-hidden]=\"loading$ | async\">\n      {{ 'asm.saveCart.saveCartBtn' | cxTranslate }}\n    </span>\n    <cx-dot-spinner\n      [attr.aria-hidden]=\"!(loading$ | async)\"\n      [attr.aria-label]=\"'common.loading' | cxTranslate\"\n    ></cx-dot-spinner>\n  </button>\n</form>\n" }]
        }], ctorParameters: () => [{ type: i1$1.GlobalMessageService }, { type: i2$2.ActiveCartFacade }, { type: i2$2.MultiCartFacade }, { type: i2$1.AsmBindCartFacade }, { type: i1.LaunchDialogService }, { type: i2.SavedCartFacade }, { type: AsmComponentService }, { type: i1$1.RoutingService }], propDecorators: { bindToCartElemRef: [{
                type: ViewChild,
                args: ['bindToCart']
            }], saveInactiveCartElemRef: [{
                type: ViewChild,
                args: ['saveInactiveCart']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AsmCreateCustomerFormComponent {
    constructor(launchDialogService, fb, asmCreateCustomerFacade, translationService) {
        this.launchDialogService = launchDialogService;
        this.fb = fb;
        this.asmCreateCustomerFacade = asmCreateCustomerFacade;
        this.translationService = translationService;
        this.iconTypes = ICON_TYPE;
        this.isLoading$ = new BehaviorSubject(false);
        this.showDialogInfoAlert = true;
        this.globalMessageType = GlobalMessageType;
        this.focusConfig = {
            trap: true,
            block: true,
            autofocus: true,
            focusOnEscape: true,
        };
        this.registerForm = this.fb.group({
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            email: ['', [Validators.required, CustomFormValidators.emailValidator]],
        });
    }
    submitForm() {
        if (this.registerForm.valid) {
            this.registerUser();
        }
        else {
            this.registerForm.markAllAsTouched();
        }
    }
    registerUser() {
        this.isLoading$.next(true);
        const { firstName, lastName, email } = this.registerForm.value;
        this.createdCustomer = {
            firstName: firstName ?? '',
            lastName: lastName ?? '',
            email: email ?? '',
        };
        const obs$ = this.asmCreateCustomerFacade.createCustomer(this.collectDataFromRegisterForm());
        obs$.subscribe({
            next: (result) => this.onRegisterUserSuccess(result),
            error: (error) => this.onRegisterUserFail(error),
        });
        obs$.subscribe({
            complete: () => this.isLoading$.next(false),
        });
    }
    collectDataFromRegisterForm() {
        return {
            firstName: this.createdCustomer.firstName,
            lastName: this.createdCustomer.lastName,
            emailAddress: this.createdCustomer.email,
        };
    }
    closeModal(reason) {
        this.launchDialogService.closeDialog(reason);
    }
    closeDialogInfoAlert() {
        this.showDialogInfoAlert = false;
    }
    closeDialogBackendErroAlert(index) {
        this.showDialogBackendErrorAlerts[index] = false;
    }
    onRegisterUserSuccess(user) {
        this.launchDialogService.closeDialog(user);
    }
    onRegisterUserFail(error) {
        this.isLoading$.next(false);
        this.backendErrorMessages = [];
        this.showDialogBackendErrorAlerts = [];
        const unknownError = 'httpHandlers.unknownError';
        const errorDetails = error.details ?? [];
        if (errorDetails.length === 0) {
            this.addErrorMessage(unknownError);
        }
        errorDetails.forEach((errorDetail) => {
            switch (errorDetail.type || '') {
                case 'ValidationError':
                    this.addErrorMessage(`asm.createCustomerForm.validationErrors.${errorDetail.subject}`);
                    break;
                case 'AssistedServiceDuplicatedUidError':
                    this.addErrorMessage('asm.createCustomerForm.badRequestDuplicatedEmail', {
                        emailAddress: this.createdCustomer.email,
                    });
                    break;
                default:
                    this.addErrorMessage(unknownError);
            }
        });
    }
    addErrorMessage(key, options) {
        this.translationService
            .translate(key, options)
            .pipe(first())
            .subscribe((text) => {
            this.backendErrorMessages.push(text);
            this.showDialogBackendErrorAlerts.push(true);
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmCreateCustomerFormComponent, deps: [{ token: i1.LaunchDialogService }, { token: i1$2.FormBuilder }, { token: i2$1.AsmCreateCustomerFacade }, { token: i1$1.TranslationService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: AsmCreateCustomerFormComponent, isStandalone: true, selector: "cx-asm-create-customer-form", ngImport: i0, template: "<div\n  class=\"cx-modal-container cx-asm-dialog\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"closeModal('Escape clicked')\"\n  aria-labelledby=\"asm-create-customer-form-title\"\n>\n  <div class=\"cx-modal-content\">\n    <ng-container>\n      <form (ngSubmit)=\"submitForm()\" [formGroup]=\"registerForm\">\n        <!-- Modal Header -->\n        <div class=\"cx-dialog-header modal-header\">\n          <h2 id=\"asm-create-customer-form-title\" class=\"title modal-title\">\n            {{ 'asm.createCustomerForm.title' | cxTranslate }}\n          </h2>\n        </div>\n        <!-- Modal Body -->\n        <div class=\"cx-dialog-body modal-body\">\n          <div class=\"message-container\">\n            <cx-message\n              *ngIf=\"showDialogInfoAlert\"\n              [text]=\"'asm.createCustomerForm.createAccountAlert' | cxTranslate\"\n              [type]=\"globalMessageType.MSG_TYPE_INFO\"\n              (closeMessage)=\"closeDialogInfoAlert()\"\n            >\n            </cx-message>\n            <ng-container\n              *ngFor=\"let errorMessage of backendErrorMessages; let i = index\"\n            >\n              <cx-message\n                *ngIf=\"showDialogBackendErrorAlerts[i]\"\n                [text]=\"errorMessage\"\n                [type]=\"globalMessageType.MSG_TYPE_ERROR\"\n                (closeMessage)=\"closeDialogBackendErroAlert(i)\"\n              >\n              </cx-message>\n            </ng-container>\n          </div>\n\n          <div *ngIf=\"!(isLoading$ | async); else loading\">\n            <cx-form-required-legend />\n            <div class=\"form-group\">\n              <label>\n                <span class=\"label-content\"\n                  >{{ 'asm.createCustomerForm.firstName.label' | cxTranslate }}\n                  <cx-form-required-asterisks />\n                </span>\n                <input\n                  required=\"true\"\n                  class=\"form-control\"\n                  placeholder=\"{{\n                    'asm.createCustomerForm.firstName.placeholder' | cxTranslate\n                  }}\"\n                  [attr.aria-invalid]=\"\n                    registerForm.get('firstName')?.touched &&\n                    registerForm.get('firstName')?.invalid\n                  \"\n                  [attr.aria-errormessage]=\"'firstNameError'\"\n                  formControlName=\"firstName\"\n                  name=\"text\"\n                />\n                <cx-form-errors\n                  id=\"firstNameError\"\n                  [control]=\"registerForm.get('firstName')\"\n                ></cx-form-errors>\n              </label>\n            </div>\n\n            <div class=\"form-group\">\n              <label>\n                <span class=\"label-content\"\n                  >{{ 'asm.createCustomerForm.lastName.label' | cxTranslate }}\n                  <cx-form-required-asterisks />\n                </span>\n                <input\n                  required=\"true\"\n                  class=\"form-control\"\n                  placeholder=\"{{\n                    'asm.createCustomerForm.lastName.placeholder' | cxTranslate\n                  }}\"\n                  [attr.aria-invalid]=\"\n                    registerForm.get('lastName')?.touched &&\n                    registerForm.get('lastName')?.invalid\n                  \"\n                  [attr.aria-errormessage]=\"'lastNameError'\"\n                  name=\"text\"\n                  formControlName=\"lastName\"\n                />\n                <cx-form-errors\n                  id=\"lastNameError\"\n                  [control]=\"registerForm.get('lastName')\"\n                ></cx-form-errors>\n              </label>\n            </div>\n\n            <div class=\"form-group\">\n              <label>\n                <span class=\"label-content\"\n                  >{{\n                    'asm.createCustomerForm.emailAddress.label' | cxTranslate\n                  }}\n                  <cx-form-required-asterisks />\n                </span>\n                <input\n                  required=\"true\"\n                  class=\"form-control\"\n                  placeholder=\"{{\n                    'asm.createCustomerForm.emailAddress.placeholder'\n                      | cxTranslate\n                  }}\"\n                  [attr.aria-invalid]=\"\n                    registerForm.get('email')?.touched &&\n                    registerForm.get('email')?.invalid\n                  \"\n                  [attr.aria-errormessage]=\"'emailError'\"\n                  name=\"email\"\n                  formControlName=\"email\"\n                />\n                <cx-form-errors\n                  id=\"emailError\"\n                  [control]=\"registerForm.get('email')\"\n                ></cx-form-errors>\n              </label>\n            </div>\n          </div>\n        </div>\n        <!-- Modal Footer -->\n        <div class=\"modal-footer\">\n          <button\n            type=\"submit\"\n            class=\"btn cx-asm-create-customer-btn cx-asm-create-customer-btn-create\"\n          >\n            {{ 'asm.createCustomerForm.createAccount' | cxTranslate }}\n          </button>\n          <button\n            type=\"button\"\n            class=\"btn cx-asm-create-customer-btn cx-asm-create-customer-btn-cancel\"\n            (click)=\"closeModal('Cancel click')\"\n          >\n            {{ 'asm.createCustomerForm.cancel' | cxTranslate }}\n          </button>\n        </div>\n      </form>\n    </ng-container>\n  </div>\n</div>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\"><cx-spinner></cx-spinner></div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: MessageComponent, selector: "cx-message", inputs: ["text", "actionButtonText", "actionButtonMessage", "accordionText", "showBody", "isVisibleCloseButton", "type"], outputs: ["closeMessage", "buttonAction"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmCreateCustomerFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-asm-create-customer-form', imports: [
                        FocusDirective,
                        FormsModule,
                        ReactiveFormsModule,
                        NgIf,
                        MessageComponent,
                        NgFor,
                        FormErrorsComponent,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<div\n  class=\"cx-modal-container cx-asm-dialog\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"closeModal('Escape clicked')\"\n  aria-labelledby=\"asm-create-customer-form-title\"\n>\n  <div class=\"cx-modal-content\">\n    <ng-container>\n      <form (ngSubmit)=\"submitForm()\" [formGroup]=\"registerForm\">\n        <!-- Modal Header -->\n        <div class=\"cx-dialog-header modal-header\">\n          <h2 id=\"asm-create-customer-form-title\" class=\"title modal-title\">\n            {{ 'asm.createCustomerForm.title' | cxTranslate }}\n          </h2>\n        </div>\n        <!-- Modal Body -->\n        <div class=\"cx-dialog-body modal-body\">\n          <div class=\"message-container\">\n            <cx-message\n              *ngIf=\"showDialogInfoAlert\"\n              [text]=\"'asm.createCustomerForm.createAccountAlert' | cxTranslate\"\n              [type]=\"globalMessageType.MSG_TYPE_INFO\"\n              (closeMessage)=\"closeDialogInfoAlert()\"\n            >\n            </cx-message>\n            <ng-container\n              *ngFor=\"let errorMessage of backendErrorMessages; let i = index\"\n            >\n              <cx-message\n                *ngIf=\"showDialogBackendErrorAlerts[i]\"\n                [text]=\"errorMessage\"\n                [type]=\"globalMessageType.MSG_TYPE_ERROR\"\n                (closeMessage)=\"closeDialogBackendErroAlert(i)\"\n              >\n              </cx-message>\n            </ng-container>\n          </div>\n\n          <div *ngIf=\"!(isLoading$ | async); else loading\">\n            <cx-form-required-legend />\n            <div class=\"form-group\">\n              <label>\n                <span class=\"label-content\"\n                  >{{ 'asm.createCustomerForm.firstName.label' | cxTranslate }}\n                  <cx-form-required-asterisks />\n                </span>\n                <input\n                  required=\"true\"\n                  class=\"form-control\"\n                  placeholder=\"{{\n                    'asm.createCustomerForm.firstName.placeholder' | cxTranslate\n                  }}\"\n                  [attr.aria-invalid]=\"\n                    registerForm.get('firstName')?.touched &&\n                    registerForm.get('firstName')?.invalid\n                  \"\n                  [attr.aria-errormessage]=\"'firstNameError'\"\n                  formControlName=\"firstName\"\n                  name=\"text\"\n                />\n                <cx-form-errors\n                  id=\"firstNameError\"\n                  [control]=\"registerForm.get('firstName')\"\n                ></cx-form-errors>\n              </label>\n            </div>\n\n            <div class=\"form-group\">\n              <label>\n                <span class=\"label-content\"\n                  >{{ 'asm.createCustomerForm.lastName.label' | cxTranslate }}\n                  <cx-form-required-asterisks />\n                </span>\n                <input\n                  required=\"true\"\n                  class=\"form-control\"\n                  placeholder=\"{{\n                    'asm.createCustomerForm.lastName.placeholder' | cxTranslate\n                  }}\"\n                  [attr.aria-invalid]=\"\n                    registerForm.get('lastName')?.touched &&\n                    registerForm.get('lastName')?.invalid\n                  \"\n                  [attr.aria-errormessage]=\"'lastNameError'\"\n                  name=\"text\"\n                  formControlName=\"lastName\"\n                />\n                <cx-form-errors\n                  id=\"lastNameError\"\n                  [control]=\"registerForm.get('lastName')\"\n                ></cx-form-errors>\n              </label>\n            </div>\n\n            <div class=\"form-group\">\n              <label>\n                <span class=\"label-content\"\n                  >{{\n                    'asm.createCustomerForm.emailAddress.label' | cxTranslate\n                  }}\n                  <cx-form-required-asterisks />\n                </span>\n                <input\n                  required=\"true\"\n                  class=\"form-control\"\n                  placeholder=\"{{\n                    'asm.createCustomerForm.emailAddress.placeholder'\n                      | cxTranslate\n                  }}\"\n                  [attr.aria-invalid]=\"\n                    registerForm.get('email')?.touched &&\n                    registerForm.get('email')?.invalid\n                  \"\n                  [attr.aria-errormessage]=\"'emailError'\"\n                  name=\"email\"\n                  formControlName=\"email\"\n                />\n                <cx-form-errors\n                  id=\"emailError\"\n                  [control]=\"registerForm.get('email')\"\n                ></cx-form-errors>\n              </label>\n            </div>\n          </div>\n        </div>\n        <!-- Modal Footer -->\n        <div class=\"modal-footer\">\n          <button\n            type=\"submit\"\n            class=\"btn cx-asm-create-customer-btn cx-asm-create-customer-btn-create\"\n          >\n            {{ 'asm.createCustomerForm.createAccount' | cxTranslate }}\n          </button>\n          <button\n            type=\"button\"\n            class=\"btn cx-asm-create-customer-btn cx-asm-create-customer-btn-cancel\"\n            (click)=\"closeModal('Cancel click')\"\n          >\n            {{ 'asm.createCustomerForm.cancel' | cxTranslate }}\n          </button>\n        </div>\n      </form>\n    </ng-container>\n  </div>\n</div>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\"><cx-spinner></cx-spinner></div>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1.LaunchDialogService }, { type: i1$2.FormBuilder }, { type: i2$1.AsmCreateCustomerFacade }, { type: i1$1.TranslationService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultAsmCreateCustomerFormLayoutConfig = {
    launch: {
        ASM_CREATE_CUSTOMER_FORM: {
            inlineRoot: true,
            component: AsmCreateCustomerFormComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class FormatTimerPipe {
    transform(totalSeconds) {
        if (totalSeconds < 0) {
            totalSeconds = 0;
        }
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        let zeroPaddedMinutes;
        if (minutes < 10) {
            zeroPaddedMinutes = ('00' + minutes).slice(-2);
        }
        else {
            zeroPaddedMinutes = minutes + '';
        }
        const zeroPaddedSeconds = ('00' + seconds).slice(-2);
        return `${zeroPaddedMinutes}:${zeroPaddedSeconds}`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: FormatTimerPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: FormatTimerPipe, isStandalone: true, name: "formatTimer" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: FormatTimerPipe, decorators: [{
            type: Pipe,
            args: [{ name: 'formatTimer' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AsmSessionTimerComponent {
    constructor(config, asmComponentService, routingService, changeDetectorRef, userIdService) {
        this.config = config;
        this.asmComponentService = asmComponentService;
        this.routingService = routingService;
        this.changeDetectorRef = changeDetectorRef;
        this.userIdService = userIdService;
        this.subscriptions = new Subscription();
        this.maxStartDelayInSeconds = 60000;
    }
    ngOnInit() {
        this.initTimer();
        this.interval = setInterval(() => {
            const currentSeconds = new Date().getTime() / 1000;
            this.timeLeft = Math.floor(this.expiredTime - currentSeconds);
            if (this.timeLeft <= 0) {
                clearInterval(this.interval);
                this.asmComponentService.logoutCustomerSupportAgentAndCustomer();
            }
            this.changeDetectorRef.markForCheck();
        }, 1000);
        this.resetOnNavigate();
        this.resetOnCustomerSessionChange();
    }
    resetOnNavigate() {
        this.subscriptions.add(this.routingService.isNavigating().subscribe((isNavigating) => {
            if (isNavigating) {
                this.resetTimer();
            }
        }));
    }
    resetOnCustomerSessionChange() {
        this.subscriptions.add(this.userIdService
            .getUserId()
            .pipe(distinctUntilChanged())
            .subscribe(() => this.resetTimer()));
    }
    initTimer() {
        const timeoutPropertyInSeconds = this.getTimerStartDelayInSeconds();
        const currentSeconds = new Date().getTime() / 1000;
        this.timeLeft = timeoutPropertyInSeconds;
        this.expiredTime = currentSeconds + this.timeLeft;
    }
    resetTimer() {
        if (this.timeLeft > 0) {
            this.initTimer();
        }
    }
    getTimerStartDelayInSeconds() {
        if (this.config.asm?.agentSessionTimer?.startingDelayInSeconds === undefined) {
            return 600;
        }
        if (this.config.asm.agentSessionTimer.startingDelayInSeconds >
            this.maxStartDelayInSeconds) {
            return this.maxStartDelayInSeconds;
        }
        else {
            return this.config.asm.agentSessionTimer.startingDelayInSeconds;
        }
    }
    ngOnDestroy() {
        this.subscriptions.unsubscribe();
        if (this.interval) {
            clearInterval(this.interval);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmSessionTimerComponent, deps: [{ token: i2$1.AsmConfig }, { token: AsmComponentService }, { token: i1$1.RoutingService }, { token: i0.ChangeDetectorRef }, { token: i1$1.UserIdService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: AsmSessionTimerComponent, isStandalone: true, selector: "cx-asm-session-timer", ngImport: i0, template: "<span class=\"label\" aria-hidden=\"true\"\n  >{{ 'asm.agentSessionTimer.label' | cxTranslate }}:</span\n>\n<span\n  class=\"time\"\n  role=\"timer\"\n  tabindex=\"0\"\n  [attr.aria-label]=\"\n    ('asm.agentSessionTimer.label' | cxTranslate) +\n    ': ' +\n    (timeLeft | formatTimer) +\n    ' ' +\n    ('asm.agentSessionTimer.minutes' | cxTranslate)\n  \"\n  >{{ timeLeft | formatTimer }}\n  {{ 'asm.agentSessionTimer.minutes' | cxTranslate }}</span\n>\n<button\n  class=\"reset\"\n  [attr.aria-label]=\"'asm.agentSessionTimer.reset' | cxTranslate\"\n  (click)=\"resetTimer()\"\n></button>\n", dependencies: [{ kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: FormatTimerPipe, name: "formatTimer" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmSessionTimerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-asm-session-timer', imports: [TranslatePipe, FormatTimerPipe], template: "<span class=\"label\" aria-hidden=\"true\"\n  >{{ 'asm.agentSessionTimer.label' | cxTranslate }}:</span\n>\n<span\n  class=\"time\"\n  role=\"timer\"\n  tabindex=\"0\"\n  [attr.aria-label]=\"\n    ('asm.agentSessionTimer.label' | cxTranslate) +\n    ': ' +\n    (timeLeft | formatTimer) +\n    ' ' +\n    ('asm.agentSessionTimer.minutes' | cxTranslate)\n  \"\n  >{{ timeLeft | formatTimer }}\n  {{ 'asm.agentSessionTimer.minutes' | cxTranslate }}</span\n>\n<button\n  class=\"reset\"\n  [attr.aria-label]=\"'asm.agentSessionTimer.reset' | cxTranslate\"\n  (click)=\"resetTimer()\"\n></button>\n" }]
        }], ctorParameters: () => [{ type: i2$1.AsmConfig }, { type: AsmComponentService }, { type: i1$1.RoutingService }, { type: i0.ChangeDetectorRef }, { type: i1$1.UserIdService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AsmToggleUiComponent {
    constructor(asmService) {
        this.asmService = asmService;
        this.subscription = new Subscription();
    }
    ngOnInit() {
        this.subscription.add(this.asmService.getAsmUiState().subscribe((uiState) => {
            this.isCollapsed =
                uiState.collapsed === undefined ? false : uiState.collapsed;
        }));
    }
    toggleUi() {
        this.asmService.updateAsmUiState({ collapsed: !this.isCollapsed });
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmToggleUiComponent, deps: [{ token: i1$3.AsmService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: AsmToggleUiComponent, isStandalone: true, selector: "cx-asm-toggle-ui", ngImport: i0, template: "<a class=\"toggleUi\" (click)=\"toggleUi()\" tabindex=\"0\" role=\"button\">\n  <span [ngClass]=\"!isCollapsed ? 'collapseIcon' : 'expandIcon'\"></span>\n  <span *ngIf=\"!isCollapsed\" class=\"label\">\n    {{ 'asm.toggleUi.collapse' | cxTranslate }}\n  </span>\n  <span *ngIf=\"isCollapsed\" class=\"label\">\n    {{ 'asm.toggleUi.expand' | cxTranslate }}\n  </span>\n</a>\n", dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmToggleUiComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-asm-toggle-ui', imports: [NgClass, NgIf, TranslatePipe], template: "<a class=\"toggleUi\" (click)=\"toggleUi()\" tabindex=\"0\" role=\"button\">\n  <span [ngClass]=\"!isCollapsed ? 'collapseIcon' : 'expandIcon'\"></span>\n  <span *ngIf=\"!isCollapsed\" class=\"label\">\n    {{ 'asm.toggleUi.collapse' | cxTranslate }}\n  </span>\n  <span *ngIf=\"isCollapsed\" class=\"label\">\n    {{ 'asm.toggleUi.expand' | cxTranslate }}\n  </span>\n</a>\n" }]
        }], ctorParameters: () => [{ type: i1$3.AsmService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CSAgentLoginFormComponent {
    constructor(fb) {
        this.fb = fb;
        this.csAgentTokenLoading = false;
        this.submitEvent = new EventEmitter();
    }
    ngOnInit() {
        this.csAgentLoginForm = this.fb.group({
            userId: ['', [Validators.required]],
            password: ['', [Validators.required]],
        });
    }
    onSubmit() {
        if (this.csAgentLoginForm.valid) {
            this.submitEvent.emit({
                userId: this.csAgentLoginForm.get('userId')?.value,
                password: this.csAgentLoginForm.get('password')?.value,
            });
        }
        else {
            this.csAgentLoginForm.markAllAsTouched();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CSAgentLoginFormComponent, deps: [{ token: i1$2.UntypedFormBuilder }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CSAgentLoginFormComponent, isStandalone: true, selector: "cx-csagent-login-form", inputs: { csAgentTokenLoading: "csAgentTokenLoading" }, outputs: { submitEvent: "submitEvent" }, host: { attributes: { "ngSkipHydration": "true" } }, ngImport: i0, template: "<form\n  (ngSubmit)=\"onSubmit()\"\n  [formGroup]=\"csAgentLoginForm\"\n  *ngIf=\"!csAgentTokenLoading\"\n>\n  <span class=\"label-content\">\n    {{ 'asm.loginForm.userId.label' | cxTranslate }}\n  </span>\n  <label>\n    <input\n      required=\"true\"\n      type=\"text\"\n      formControlName=\"userId\"\n      [attr.aria-label]=\"'asm.loginForm.userId.label' | cxTranslate\"\n      [attr.aria-invalid]=\"\n        csAgentLoginForm.get('userId')?.touched &&\n        csAgentLoginForm.get('userId')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'userIdError'\"\n    />\n\n    <cx-form-errors\n      id=\"userIdError\"\n      [translationParams]=\"{\n        label: 'asm.loginForm.userId.label' | cxTranslate,\n      }\"\n      [control]=\"csAgentLoginForm.get('userId')\"\n    ></cx-form-errors>\n  </label>\n\n  <span class=\"label-content\">\n    {{ 'asm.loginForm.password.label' | cxTranslate }}\n  </span>\n  <label>\n    <input\n      required=\"true\"\n      type=\"password\"\n      formControlName=\"password\"\n      [attr.aria-label]=\"'asm.loginForm.password.label' | cxTranslate\"\n      [attr.aria-invalid]=\"\n        csAgentLoginForm.get('password')?.touched &&\n        csAgentLoginForm.get('password')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'passwordError'\"\n      cxPasswordVisibilitySwitch\n    />\n\n    <cx-form-errors\n      id=\"passwordError\"\n      [translationParams]=\"{\n        label: 'asm.loginForm.password.label' | cxTranslate,\n      }\"\n      [control]=\"csAgentLoginForm.get('password')\"\n    ></cx-form-errors>\n  </label>\n  <button type=\"submit\">\n    {{ 'asm.loginForm.submit' | cxTranslate }}\n  </button>\n</form>\n\n<cx-dot-spinner\n  *ngIf=\"csAgentTokenLoading\"\n  aria-hidden=\"false\"\n  [attr.aria-label]=\"'common.loading' | cxTranslate\"\n></cx-dot-spinner>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: PasswordVisibilityToggleDirective, selector: "[cxPasswordVisibilitySwitch][type=\"password\"]" }, { kind: "component", type: DotSpinnerComponent, selector: "cx-dot-spinner" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CSAgentLoginFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-csagent-login-form', host: { ngSkipHydration: 'true' }, imports: [
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        FormErrorsComponent,
                        PasswordVisibilityToggleDirective,
                        DotSpinnerComponent,
                        TranslatePipe,
                    ], template: "<form\n  (ngSubmit)=\"onSubmit()\"\n  [formGroup]=\"csAgentLoginForm\"\n  *ngIf=\"!csAgentTokenLoading\"\n>\n  <span class=\"label-content\">\n    {{ 'asm.loginForm.userId.label' | cxTranslate }}\n  </span>\n  <label>\n    <input\n      required=\"true\"\n      type=\"text\"\n      formControlName=\"userId\"\n      [attr.aria-label]=\"'asm.loginForm.userId.label' | cxTranslate\"\n      [attr.aria-invalid]=\"\n        csAgentLoginForm.get('userId')?.touched &&\n        csAgentLoginForm.get('userId')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'userIdError'\"\n    />\n\n    <cx-form-errors\n      id=\"userIdError\"\n      [translationParams]=\"{\n        label: 'asm.loginForm.userId.label' | cxTranslate,\n      }\"\n      [control]=\"csAgentLoginForm.get('userId')\"\n    ></cx-form-errors>\n  </label>\n\n  <span class=\"label-content\">\n    {{ 'asm.loginForm.password.label' | cxTranslate }}\n  </span>\n  <label>\n    <input\n      required=\"true\"\n      type=\"password\"\n      formControlName=\"password\"\n      [attr.aria-label]=\"'asm.loginForm.password.label' | cxTranslate\"\n      [attr.aria-invalid]=\"\n        csAgentLoginForm.get('password')?.touched &&\n        csAgentLoginForm.get('password')?.invalid\n      \"\n      [attr.aria-errormessage]=\"'passwordError'\"\n      cxPasswordVisibilitySwitch\n    />\n\n    <cx-form-errors\n      id=\"passwordError\"\n      [translationParams]=\"{\n        label: 'asm.loginForm.password.label' | cxTranslate,\n      }\"\n      [control]=\"csAgentLoginForm.get('password')\"\n    ></cx-form-errors>\n  </label>\n  <button type=\"submit\">\n    {{ 'asm.loginForm.submit' | cxTranslate }}\n  </button>\n</form>\n\n<cx-dot-spinner\n  *ngIf=\"csAgentTokenLoading\"\n  aria-hidden=\"false\"\n  [attr.aria-label]=\"'common.loading' | cxTranslate\"\n></cx-dot-spinner>\n" }]
        }], ctorParameters: () => [{ type: i1$2.UntypedFormBuilder }], propDecorators: { csAgentTokenLoading: [{
                type: Input
            }], submitEvent: [{
                type: Output
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerEmulationComponent {
    constructor(asmComponentService, userAccountFacade, launchDialogService, featureModules) {
        this.asmComponentService = asmComponentService;
        this.userAccountFacade = userAccountFacade;
        this.launchDialogService = launchDialogService;
        this.featureModules = featureModules;
        this.isAsmCustomer360Configured = false;
        this.isAsmCustomer360Loaded$ = new BehaviorSubject(false);
        this.subscription = new Subscription();
    }
    ngOnInit() {
        this.isAsmCustomer360Configured =
            this.featureModules?.isConfigured('asmCustomer360');
        if (this.isAsmCustomer360Configured) {
            // trigger lazy loading of the Customer 360 feature:
            this.featureModules?.resolveFeature('asmCustomer360').subscribe(() => {
                this.isAsmCustomer360Loaded$.next(true);
            });
        }
        this.subscription.add(this.userAccountFacade.get().subscribe((user) => {
            if (user) {
                this.customer = user;
            }
        }));
        this.isCustomerEmulationSessionInProgress$ =
            this.asmComponentService.isCustomerEmulationSessionInProgress();
    }
    logoutCustomer() {
        this.asmComponentService.logoutCustomer();
    }
    openAsmCustomer360() {
        this.subscription.add(this.isAsmCustomer360Loaded$
            .pipe(filter((isReady) => Boolean(isReady)))
            .subscribe(() => {
            const data = { customer: this.customer };
            this.launchDialogService?.openDialogAndSubscribe(LAUNCH_CALLER.ASM_CUSTOMER_360, this.asmCustomer360LauncherElement, data);
            this.subscription.add(this.launchDialogService?.dialogClose
                .pipe(filter((result) => Boolean(result)))
                .subscribe((event) => {
                this.asmComponentService.handleAsmDialogAction(event);
            }));
        }));
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CustomerEmulationComponent, deps: [{ token: AsmComponentService }, { token: i2$3.UserAccountFacade }, { token: i1.LaunchDialogService }, { token: i1$1.FeatureModulesService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CustomerEmulationComponent, isStandalone: true, selector: "cx-customer-emulation", viewQueries: [{ propertyName: "asmCustomer360LauncherElement", first: true, predicate: ["asmCustomer360Launcher"], descendants: true }], ngImport: i0, template: "<ng-container *ngIf=\"isCustomerEmulationSessionInProgress$ | async\">\n  <div class=\"cx-asm-customerInfo\">\n    <label class=\"cx-asm-name\">{{ customer?.name }}</label>\n    <label class=\"cx-asm-uid\">{{ customer?.uid }}</label>\n  </div>\n  <cx-asm-bind-cart></cx-asm-bind-cart>\n  <button\n    *ngIf=\"isAsmCustomer360Configured && customer\"\n    #asmCustomer360Launcher\n    class=\"cx-360-button\"\n    (click)=\"openAsmCustomer360()\"\n  >\n    {{ 'asm.asmCustomer360ViewButton' | cxTranslate }}\n  </button>\n  <button\n    formcontrolname=\"logoutCustomer\"\n    (click)=\"logoutCustomer()\"\n    [attr.aria-label]=\"'asm.endSessionAriaLabel' | cxTranslate\"\n  >\n    {{ 'asm.endSession' | cxTranslate }}\n  </button>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: AsmBindCartComponent, selector: "cx-asm-bind-cart" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CustomerEmulationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-customer-emulation', imports: [NgIf, AsmBindCartComponent, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"isCustomerEmulationSessionInProgress$ | async\">\n  <div class=\"cx-asm-customerInfo\">\n    <label class=\"cx-asm-name\">{{ customer?.name }}</label>\n    <label class=\"cx-asm-uid\">{{ customer?.uid }}</label>\n  </div>\n  <cx-asm-bind-cart></cx-asm-bind-cart>\n  <button\n    *ngIf=\"isAsmCustomer360Configured && customer\"\n    #asmCustomer360Launcher\n    class=\"cx-360-button\"\n    (click)=\"openAsmCustomer360()\"\n  >\n    {{ 'asm.asmCustomer360ViewButton' | cxTranslate }}\n  </button>\n  <button\n    formcontrolname=\"logoutCustomer\"\n    (click)=\"logoutCustomer()\"\n    [attr.aria-label]=\"'asm.endSessionAriaLabel' | cxTranslate\"\n  >\n    {{ 'asm.endSession' | cxTranslate }}\n  </button>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: AsmComponentService }, { type: i2$3.UserAccountFacade }, { type: i1.LaunchDialogService }, { type: i1$1.FeatureModulesService }], propDecorators: { asmCustomer360LauncherElement: [{
                type: ViewChild,
                args: ['asmCustomer360Launcher']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerSelectionComponent {
    constructor(fb, asmService, config, directionService, launchDialogService) {
        this.fb = fb;
        this.asmService = asmService;
        this.config = config;
        this.directionService = directionService;
        this.launchDialogService = launchDialogService;
        this.subscription = new Subscription();
        this.searchByCustomer = false;
        this.searchByOrder = false;
        this.isLoading = false;
        this.activeFocusedButtonIndex = -1;
        this.submitEvent = new EventEmitter();
    }
    ngOnInit() {
        this.customerSelectionForm = this.fb.group({
            searchTerm: '',
            searchOrder: '',
        });
        this.subscription.add(this.customerSelectionForm.controls.searchOrder.valueChanges
            .pipe(debounceTime(300))
            .subscribe((searchTermValue) => {
            this.searchByCustomer = false;
            this.searchByOrder = true;
            this.handleSearchByOrder(searchTermValue);
        }));
        this.asmService.customerSearchReset();
        this.searchResultsLoading$ =
            this.asmService.getCustomerSearchResultsLoading();
        this.searchResults = this.asmService.getCustomerSearchResults();
        this.subscription.add(this.customerSelectionForm.controls.searchTerm.valueChanges
            .pipe(debounceTime(300))
            .subscribe((searchTermValue) => {
            this.searchByCustomer = true;
            this.searchByOrder = false;
            this.handleSearchByCustomer(searchTermValue);
        }));
        this.subscription.add(this.searchResultsLoading$.subscribe((loading) => {
            this.isLoading = loading;
        }));
    }
    handleSearchTerm(searchTermValue) {
        if (!!this.selectedCustomer &&
            searchTermValue !== this.selectedCustomer.name) {
            this.selectedCustomer = undefined;
        }
        if (this.selectedCustomer) {
            return;
        }
        this.asmService.customerSearchReset();
        this.activeFocusedButtonIndex = -1;
        if (searchTermValue.trim().length >= 3) {
            this.asmService.customerSearch({
                query: searchTermValue,
                pageSize: this.config.asm?.customerSearch?.maxResults,
            });
        }
    }
    handleSearchByCustomer(searchTermValue) {
        if (this.selectedCustomer) {
            this.selectedCustomer = undefined;
        }
        if (this.customerSelectionForm.controls.searchOrder.value) {
            this.customerSelectionForm.controls.searchOrder.setValue(undefined, {
                emitEvent: false,
            });
        }
        this.asmService.customerSearchReset();
        this.activeFocusedButtonIndex = -1;
        if (searchTermValue.trim().length >= 3) {
            this.asmService.customerSearch({
                query: searchTermValue,
                pageSize: this.config.asm?.customerSearch?.maxResults,
            });
        }
    }
    handleSearchByOrder(searchOrderValue) {
        if (this.selectedCustomer) {
            this.selectedCustomer = undefined;
        }
        if (this.customerSelectionForm.controls.searchTerm.value) {
            this.customerSelectionForm.controls.searchTerm.setValue(undefined, {
                emitEvent: false,
            });
        }
        this.asmService.customerSearchReset();
        this.activeFocusedButtonIndex = -1;
        if (searchOrderValue.trim().length >= 3) {
            this.asmService.customerSearch({
                orderId: searchOrderValue,
                pageSize: this.config.asm?.customerSearch?.maxResults,
            });
        }
    }
    isNoResultMessageInfoVisible(results, searchFlag, searchElement) {
        const searchTermValid = searchElement.value.length >= 3;
        const hasEntries = !!results.entries && results.entries.length > 0;
        return !this.isLoading && searchTermValid && searchFlag && !hasEntries;
    }
    isSearchResultsVisible(results, searchFlag) {
        return !!results.entries && searchFlag && results.entries.length > 0;
    }
    selectCustomerFromList(event, customer) {
        this.selectedCustomer = customer;
        this.customerSelectionForm.controls.searchTerm.setValue(this.selectedCustomer.name, {
            emitEvent: false,
        });
        this.asmService.customerSearchReset();
        event.preventDefault();
        event.stopPropagation();
    }
    onSubmit() {
        if (this.selectedCustomer) {
            this.submitEvent.emit({
                customerId: this.selectedCustomer.customerId,
                parameters: {
                    orderId: this.customerSelectionForm.controls.searchOrder.value,
                },
            });
        }
        else {
            this.customerSelectionForm.markAllAsTouched();
        }
    }
    onDocumentClick(event) {
        if (this.resultList) {
            if (this.resultList.nativeElement.contains(event.target) ||
                this.searchTerm.nativeElement.contains(event.target)) {
                return;
            }
            else {
                this.asmService.customerSearchReset();
            }
        }
    }
    closeResults(event) {
        this.asmService.customerSearchReset();
        this.searchTerm.nativeElement.focus();
        event.preventDefault();
        event.stopPropagation();
    }
    closeOrderSearchResults(event) {
        this.asmService.customerSearchReset();
        this.searchOrder.nativeElement.focus();
        event.preventDefault();
        event.stopPropagation();
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
        this.asmService.customerSearchReset();
    }
    /**
     * set focus to the first searched item
     * @param event keyboard event
     */
    focusFirstItem(event) {
        event.preventDefault();
        this.activeFocusedButtonIndex = 0;
        this.updateItemIndex(this.activeFocusedButtonIndex);
    }
    /**
     * set mouse cursor to the end of search text
     * @param event keyboard event
     */
    setSelectionEnd(event) {
        event.preventDefault();
        if (this.searchTerm.nativeElement.value?.length) {
            const selectionStart = this.searchTerm.nativeElement.value.length;
            this.searchTerm.nativeElement.selectionStart = selectionStart;
            this.searchTerm.nativeElement.selectionEnd = selectionStart;
        }
    }
    /**
     * set mouse cursor to the end of search order text
     * @param event keyboard event
     */
    setOrderSearchSelectionEnd(event) {
        event.preventDefault();
        if (this.searchOrder.nativeElement.value?.length) {
            const selectionStart = this.searchOrder.nativeElement.value.length;
            this.searchOrder.nativeElement.selectionStart = selectionStart;
            this.searchOrder.nativeElement.selectionEnd = selectionStart;
        }
    }
    /**
     * set focus on previous searh result item.  If no previous item then go to end of item.
     * @param event keyboard event
     */
    focusPreviousChild(event) {
        event.preventDefault();
        this.activeFocusedButtonIndex--;
        if (this.activeFocusedButtonIndex < 0) {
            this.activeFocusedButtonIndex = this.searchResultItems.length - 1;
        }
        this.updateItemIndex(this.activeFocusedButtonIndex);
    }
    /**
     * set focus on next searh result item.  if no next item then go to the first item
     * @param event keyboard event
     */
    focusNextChild(event) {
        event.preventDefault();
        this.activeFocusedButtonIndex++;
        if (this.activeFocusedButtonIndex > this.searchResultItems.length - 1) {
            this.activeFocusedButtonIndex = 0;
        }
        this.updateItemIndex(this.activeFocusedButtonIndex);
    }
    /**
     * set focus to input search text
     * @param event keyboard event
     */
    focusInputText(event) {
        event.preventDefault();
        this.activeFocusedButtonIndex = -1;
        this.searchTerm.nativeElement.focus();
        if (this.searchTerm.nativeElement.value?.length) {
            let selectionPos = this.searchTerm.nativeElement.selectionEnd;
            const searchTermLength = this.searchTerm.nativeElement.value.length;
            if (this.isBackNavigation(event)) {
                selectionPos = selectionPos <= 0 ? 0 : selectionPos - 1;
            }
            else if (this.isForwardsNavigation(event)) {
                selectionPos =
                    selectionPos >= searchTermLength
                        ? searchTermLength
                        : selectionPos + 1;
            }
            else if (event.code === 'Home') {
                selectionPos = 0;
            }
            else if (event.code === 'End') {
                selectionPos = searchTermLength;
            }
            this.searchTerm.nativeElement.selectionStart = selectionPos;
            this.searchTerm.nativeElement.selectionEnd = selectionPos;
        }
    }
    /**
     * set focus to order search input search text
     * @param event keyboard event
     */
    focusOrderSearchInputText(event) {
        event.preventDefault();
        this.activeFocusedButtonIndex = -1;
        this.searchOrder.nativeElement.focus();
        if (this.searchOrder.nativeElement.value?.length) {
            let selectionPos = this.searchOrder.nativeElement.selectionEnd;
            const searchTermLength = this.searchOrder.nativeElement.value.length;
            if (this.isBackNavigation(event)) {
                selectionPos = selectionPos <= 0 ? 0 : selectionPos - 1;
            }
            else if (this.isForwardsNavigation(event)) {
                selectionPos =
                    selectionPos >= searchTermLength
                        ? searchTermLength
                        : selectionPos + 1;
            }
            else if (event.code === 'Home') {
                selectionPos = 0;
            }
            else if (event.code === 'End') {
                selectionPos = searchTermLength;
            }
            this.searchOrder.nativeElement.selectionStart = selectionPos;
            this.searchOrder.nativeElement.selectionEnd = selectionPos;
        }
    }
    /**
     * set focus to selected item
     * @param {number} selectedIndex - current selected item index
     */
    updateItemIndex(selectedIndex) {
        this.searchResultItems.toArray()?.[selectedIndex]?.nativeElement.focus();
    }
    createCustomer() {
        this.asmService.customerSearchReset();
        this.launchDialogService.openDialogAndSubscribe(LAUNCH_CALLER.ASM_CREATE_CUSTOMER_FORM, this.createCustomerLink);
        setTimeout(() => {
            this.searchTerm.nativeElement.blur();
        });
    }
    /**
     * Verifies whether the user navigates into a subgroup of the main group menu.
     *
     * @param {KeyboardEvent} event - Keyboard event
     * @returns {boolean} -'true' if the user navigates into the subgroup, otherwise 'false'.
     * @protected
     */
    isForwardsNavigation(event) {
        return ((event.code === 'ArrowRight' && this.isLTRDirection()) ||
            (event.code === 'ArrowLeft' && this.isRTLDirection()));
    }
    /**
     * Verifies whether the user navigates from a subgroup back to the main group menu.
     *
     * @param {KeyboardEvent} event - Keyboard event
     * @returns {boolean} -'true' if the user navigates back into the main group menu, otherwise 'false'.
     * @protected
     */
    isBackNavigation(event) {
        return ((event.code === 'ArrowLeft' && this.isLTRDirection()) ||
            (event.code === 'ArrowRight' && this.isRTLDirection()));
    }
    isLTRDirection() {
        return this.directionService.getDirection() === DirectionMode.LTR;
    }
    isRTLDirection() {
        return this.directionService.getDirection() === DirectionMode.RTL;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CustomerSelectionComponent, deps: [{ token: i1$2.UntypedFormBuilder }, { token: i1$3.AsmService }, { token: i2$1.AsmConfig }, { token: i1.DirectionService }, { token: i1.LaunchDialogService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CustomerSelectionComponent, isStandalone: true, selector: "cx-customer-selection", outputs: { submitEvent: "submitEvent" }, host: { listeners: { "document:click": "onDocumentClick($event)" } }, viewQueries: [{ propertyName: "resultList", first: true, predicate: ["resultList"], descendants: true }, { propertyName: "searchTerm", first: true, predicate: ["searchTerm"], descendants: true }, { propertyName: "searchOrder", first: true, predicate: ["searchOrder"], descendants: true }, { propertyName: "createCustomerLink", first: true, predicate: ["createCustomerLink"], descendants: true }, { propertyName: "searchResultItems", predicate: ["searchResultItem"], descendants: true }], ngImport: i0, template: "<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"customerSelectionForm\">\n  <span class=\"searchLabel\">{{\n    'asm.customerSearch.customer' | cxTranslate\n  }}</span>\n  <label>\n    <input\n      required=\"true\"\n      #searchTerm\n      type=\"text\"\n      formControlName=\"searchTerm\"\n      [attr.aria-label]=\"\n        'asm.customerSearch.searchCustomer.label' | cxTranslate\n      \"\n      placeholder=\"{{\n        'asm.customerSearch.searchCustomer.label' | cxTranslate\n      }}\"\n      (keydown.arrowdown)=\"focusFirstItem($event)\"\n      (keydown.end)=\"setSelectionEnd($event)\"\n    />\n\n    <div *ngIf=\"searchResults | async as results\" #resultList>\n      <div\n        *ngIf=\"\n          isNoResultMessageInfoVisible(results, searchByCustomer, searchTerm)\n        \"\n        class=\"cx-message cx-message-info selection-message-info\"\n      >\n        <div class=\"cx-message-content\">\n          <div class=\"cx-message-header\">\n            <span class=\"cx-message-icon\">\n              <cx-icon\n                class=\"cx-icon fas fa-info-circle\"\n                ng-reflect-type=\"INFO\"\n              ></cx-icon>\n            </span>\n            <span class=\"cx-message-text\"\n              >{{ 'asm.customerSearch.noCustomerMatchResult' | cxTranslate }}\n            </span>\n            <span\n              #createCustomerLink\n              *ngIf=\"config.asm?.createCustomer?.enable\"\n              class=\"linkStyleLabel\"\n              (click)=\"createCustomer()\"\n            >\n              {{ 'asm.customerSearch.createCustomer' | cxTranslate }}\n            </span>\n          </div>\n        </div>\n      </div>\n      <div\n        *ngIf=\"isSearchResultsVisible(results, searchByCustomer)\"\n        class=\"asm-results\"\n      >\n        <button\n          #searchResultItem\n          *ngFor=\"let result of results.entries; let i = index\"\n          [tabindex]=\"activeFocusedButtonIndex === i ? 0 : -1\"\n          [attr.aria-selected]=\"activeFocusedButtonIndex === i\"\n          [class.active]=\"activeFocusedButtonIndex === i\"\n          (keydown.arrowup)=\"focusPreviousChild($event)\"\n          (keydown.arrowdown)=\"focusNextChild($event)\"\n          (keydown.arrowright)=\"focusInputText($event)\"\n          (keydown.arrowleft)=\"focusInputText($event)\"\n          (keydown.enter)=\"selectCustomerFromList($event, result)\"\n          (keydown.escape)=\"closeResults($event)\"\n          (keydown.home)=\"focusInputText($event)\"\n          (keydown.end)=\"focusInputText($event)\"\n          (click)=\"selectCustomerFromList($event, result)\"\n        >\n          <div class=\"result-name\">{{ result.name }}</div>\n          <div class=\"result-id\">\n            <span>{{ result.uid }}</span>\n          </div>\n        </button>\n      </div>\n    </div>\n\n    <div class=\"asm-results\" *ngIf=\"isLoading && searchByCustomer\">\n      <cx-dot-spinner\n        aria-hidden=\"false\"\n        [attr.aria-label]=\"'common.loading' | cxTranslate\"\n      ></cx-dot-spinner>\n    </div>\n  </label>\n  <span class=\"searchLabel\">{{\n    'asm.customerSearch.orderID' | cxTranslate\n  }}</span>\n\n  <label>\n    <input\n      required=\"true\"\n      #searchOrder\n      type=\"text\"\n      formControlName=\"searchOrder\"\n      [attr.aria-label]=\"'asm.customerSearch.searchOrder.label' | cxTranslate\"\n      placeholder=\"{{ 'asm.customerSearch.searchOrder.label' | cxTranslate }}\"\n      (keydown.arrowdown)=\"focusFirstItem($event)\"\n      (keydown.end)=\"setOrderSearchSelectionEnd($event)\"\n    />\n    <div *ngIf=\"searchResults | async as results\" #resultList>\n      <div\n        *ngIf=\"\n          isNoResultMessageInfoVisible(results, searchByOrder, searchOrder)\n        \"\n        class=\"cx-message cx-message-info selection-message-info\"\n      >\n        <div class=\"cx-message-content\">\n          <div class=\"cx-message-header\">\n            <span class=\"cx-message-icon\">\n              <cx-icon\n                class=\"cx-icon fas fa-info-circle\"\n                ng-reflect-type=\"INFO\"\n              ></cx-icon>\n            </span>\n            <span class=\"cx-message-text\">\n              {{ 'asm.customerSearch.noOrderMatchResult' | cxTranslate }}\n            </span>\n          </div>\n        </div>\n      </div>\n      <div\n        *ngIf=\"isSearchResultsVisible(results, searchByOrder)\"\n        class=\"asm-results\"\n      >\n        <button\n          #searchResultItem\n          *ngFor=\"let result of results.entries; let i = index\"\n          [tabindex]=\"activeFocusedButtonIndex === i ? 0 : -1\"\n          [attr.aria-selected]=\"activeFocusedButtonIndex === i\"\n          [class.active]=\"activeFocusedButtonIndex === i\"\n          (keydown.arrowup)=\"focusPreviousChild($event)\"\n          (keydown.arrowdown)=\"focusNextChild($event)\"\n          (keydown.arrowright)=\"focusOrderSearchInputText($event)\"\n          (keydown.arrowleft)=\"focusOrderSearchInputText($event)\"\n          (keydown.enter)=\"selectCustomerFromList($event, result)\"\n          (keydown.escape)=\"closeOrderSearchResults($event)\"\n          (keydown.home)=\"focusOrderSearchInputText($event)\"\n          (keydown.end)=\"focusOrderSearchInputText($event)\"\n          (click)=\"selectCustomerFromList($event, result)\"\n        >\n          <div class=\"result-name\">{{ searchOrder.value }}</div>\n          <div class=\"result-id\">\n            <span>{{ result.name }}</span>\n          </div>\n        </button>\n      </div>\n    </div>\n\n    <div class=\"asm-results\" *ngIf=\"isLoading && searchByOrder\">\n      <cx-dot-spinner\n        aria-hidden=\"false\"\n        [attr.aria-label]=\"'common.loading' | cxTranslate\"\n      ></cx-dot-spinner>\n    </div>\n  </label>\n\n  <button\n    type=\"submit\"\n    [class.active]=\"selectedCustomer\"\n    [disabled]=\"!selectedCustomer\"\n  >\n    {{ 'asm.customerSearch.submit' | cxTranslate }}\n  </button>\n</form>\n", dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: DotSpinnerComponent, selector: "cx-dot-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CustomerSelectionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-customer-selection', host: {
                        '(document:click)': 'onDocumentClick($event)',
                    }, imports: [
                        FormsModule,
                        ReactiveFormsModule,
                        NgIf,
                        IconComponent,
                        NgFor,
                        DotSpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"customerSelectionForm\">\n  <span class=\"searchLabel\">{{\n    'asm.customerSearch.customer' | cxTranslate\n  }}</span>\n  <label>\n    <input\n      required=\"true\"\n      #searchTerm\n      type=\"text\"\n      formControlName=\"searchTerm\"\n      [attr.aria-label]=\"\n        'asm.customerSearch.searchCustomer.label' | cxTranslate\n      \"\n      placeholder=\"{{\n        'asm.customerSearch.searchCustomer.label' | cxTranslate\n      }}\"\n      (keydown.arrowdown)=\"focusFirstItem($event)\"\n      (keydown.end)=\"setSelectionEnd($event)\"\n    />\n\n    <div *ngIf=\"searchResults | async as results\" #resultList>\n      <div\n        *ngIf=\"\n          isNoResultMessageInfoVisible(results, searchByCustomer, searchTerm)\n        \"\n        class=\"cx-message cx-message-info selection-message-info\"\n      >\n        <div class=\"cx-message-content\">\n          <div class=\"cx-message-header\">\n            <span class=\"cx-message-icon\">\n              <cx-icon\n                class=\"cx-icon fas fa-info-circle\"\n                ng-reflect-type=\"INFO\"\n              ></cx-icon>\n            </span>\n            <span class=\"cx-message-text\"\n              >{{ 'asm.customerSearch.noCustomerMatchResult' | cxTranslate }}\n            </span>\n            <span\n              #createCustomerLink\n              *ngIf=\"config.asm?.createCustomer?.enable\"\n              class=\"linkStyleLabel\"\n              (click)=\"createCustomer()\"\n            >\n              {{ 'asm.customerSearch.createCustomer' | cxTranslate }}\n            </span>\n          </div>\n        </div>\n      </div>\n      <div\n        *ngIf=\"isSearchResultsVisible(results, searchByCustomer)\"\n        class=\"asm-results\"\n      >\n        <button\n          #searchResultItem\n          *ngFor=\"let result of results.entries; let i = index\"\n          [tabindex]=\"activeFocusedButtonIndex === i ? 0 : -1\"\n          [attr.aria-selected]=\"activeFocusedButtonIndex === i\"\n          [class.active]=\"activeFocusedButtonIndex === i\"\n          (keydown.arrowup)=\"focusPreviousChild($event)\"\n          (keydown.arrowdown)=\"focusNextChild($event)\"\n          (keydown.arrowright)=\"focusInputText($event)\"\n          (keydown.arrowleft)=\"focusInputText($event)\"\n          (keydown.enter)=\"selectCustomerFromList($event, result)\"\n          (keydown.escape)=\"closeResults($event)\"\n          (keydown.home)=\"focusInputText($event)\"\n          (keydown.end)=\"focusInputText($event)\"\n          (click)=\"selectCustomerFromList($event, result)\"\n        >\n          <div class=\"result-name\">{{ result.name }}</div>\n          <div class=\"result-id\">\n            <span>{{ result.uid }}</span>\n          </div>\n        </button>\n      </div>\n    </div>\n\n    <div class=\"asm-results\" *ngIf=\"isLoading && searchByCustomer\">\n      <cx-dot-spinner\n        aria-hidden=\"false\"\n        [attr.aria-label]=\"'common.loading' | cxTranslate\"\n      ></cx-dot-spinner>\n    </div>\n  </label>\n  <span class=\"searchLabel\">{{\n    'asm.customerSearch.orderID' | cxTranslate\n  }}</span>\n\n  <label>\n    <input\n      required=\"true\"\n      #searchOrder\n      type=\"text\"\n      formControlName=\"searchOrder\"\n      [attr.aria-label]=\"'asm.customerSearch.searchOrder.label' | cxTranslate\"\n      placeholder=\"{{ 'asm.customerSearch.searchOrder.label' | cxTranslate }}\"\n      (keydown.arrowdown)=\"focusFirstItem($event)\"\n      (keydown.end)=\"setOrderSearchSelectionEnd($event)\"\n    />\n    <div *ngIf=\"searchResults | async as results\" #resultList>\n      <div\n        *ngIf=\"\n          isNoResultMessageInfoVisible(results, searchByOrder, searchOrder)\n        \"\n        class=\"cx-message cx-message-info selection-message-info\"\n      >\n        <div class=\"cx-message-content\">\n          <div class=\"cx-message-header\">\n            <span class=\"cx-message-icon\">\n              <cx-icon\n                class=\"cx-icon fas fa-info-circle\"\n                ng-reflect-type=\"INFO\"\n              ></cx-icon>\n            </span>\n            <span class=\"cx-message-text\">\n              {{ 'asm.customerSearch.noOrderMatchResult' | cxTranslate }}\n            </span>\n          </div>\n        </div>\n      </div>\n      <div\n        *ngIf=\"isSearchResultsVisible(results, searchByOrder)\"\n        class=\"asm-results\"\n      >\n        <button\n          #searchResultItem\n          *ngFor=\"let result of results.entries; let i = index\"\n          [tabindex]=\"activeFocusedButtonIndex === i ? 0 : -1\"\n          [attr.aria-selected]=\"activeFocusedButtonIndex === i\"\n          [class.active]=\"activeFocusedButtonIndex === i\"\n          (keydown.arrowup)=\"focusPreviousChild($event)\"\n          (keydown.arrowdown)=\"focusNextChild($event)\"\n          (keydown.arrowright)=\"focusOrderSearchInputText($event)\"\n          (keydown.arrowleft)=\"focusOrderSearchInputText($event)\"\n          (keydown.enter)=\"selectCustomerFromList($event, result)\"\n          (keydown.escape)=\"closeOrderSearchResults($event)\"\n          (keydown.home)=\"focusOrderSearchInputText($event)\"\n          (keydown.end)=\"focusOrderSearchInputText($event)\"\n          (click)=\"selectCustomerFromList($event, result)\"\n        >\n          <div class=\"result-name\">{{ searchOrder.value }}</div>\n          <div class=\"result-id\">\n            <span>{{ result.name }}</span>\n          </div>\n        </button>\n      </div>\n    </div>\n\n    <div class=\"asm-results\" *ngIf=\"isLoading && searchByOrder\">\n      <cx-dot-spinner\n        aria-hidden=\"false\"\n        [attr.aria-label]=\"'common.loading' | cxTranslate\"\n      ></cx-dot-spinner>\n    </div>\n  </label>\n\n  <button\n    type=\"submit\"\n    [class.active]=\"selectedCustomer\"\n    [disabled]=\"!selectedCustomer\"\n  >\n    {{ 'asm.customerSearch.submit' | cxTranslate }}\n  </button>\n</form>\n" }]
        }], ctorParameters: () => [{ type: i1$2.UntypedFormBuilder }, { type: i1$3.AsmService }, { type: i2$1.AsmConfig }, { type: i1.DirectionService }, { type: i1.LaunchDialogService }], propDecorators: { submitEvent: [{
                type: Output
            }], resultList: [{
                type: ViewChild,
                args: ['resultList']
            }], searchTerm: [{
                type: ViewChild,
                args: ['searchTerm']
            }], searchOrder: [{
                type: ViewChild,
                args: ['searchOrder']
            }], createCustomerLink: [{
                type: ViewChild,
                args: ['createCustomerLink']
            }], searchResultItems: [{
                type: ViewChildren,
                args: ['searchResultItem']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const CART_TYPE_KEY = {
    active: 'asm.activeCartAlertInfo',
    inactive: 'asm.saveInactiveCartAlertInfo',
};
class AsmMainUiComponent {
    constructor(authService, csAgentAuthService, asmComponentService, globalMessageService, routingService, asmService, userAccountFacade, launchDialogService) {
        this.authService = authService;
        this.csAgentAuthService = csAgentAuthService;
        this.asmComponentService = asmComponentService;
        this.globalMessageService = globalMessageService;
        this.routingService = routingService;
        this.asmService = asmService;
        this.userAccountFacade = userAccountFacade;
        this.launchDialogService = launchDialogService;
        this.iconTypes = ICON_TYPE;
        this.forbiddenResponseStatus = HttpResponseStatus.FORBIDDEN;
        this.showDeeplinkCartInfoAlert$ = this.asmComponentService.shouldShowDeeplinkCartInfoAlert();
        this.deeplinkCartAlertKey = '';
        this.showCreateCustomerSuccessfullyAlert = false;
        this.globalMessageType = GlobalMessageType;
        this.disabled = false;
        this.startingCustomerSession = false;
        this.showCustomerEmulationInfoAlert = true;
        this.subscription = new Subscription();
        this.isAsmCustomer360Configured = false;
        this.isAsmCustomer360Loaded$ = new BehaviorSubject(false);
        this.featureModules = inject(FeatureModulesService);
        this.asmConfig = inject(AsmConfig);
        this.oAuthLibWrapperService = inject(OAuthLibWrapperService);
        this.isAsmSessionConfigured = false;
    }
    ngOnInit() {
        this.isAsmCustomer360Configured =
            this.featureModules.isConfigured('asmCustomer360');
        if (this.isAsmCustomer360Configured) {
            // trigger lazy loading of the Customer 360 feature:
            this.featureModules.resolveFeature('asmCustomer360').subscribe(() => {
                this.isAsmCustomer360Loaded$.next(true);
            });
        }
        this.isAsmSessionConfigured =
            this.asmConfig.asm?.asmSessionSupport?.enabled ?? false;
        this.customerSupportAgentLoggedIn$ = this.csAgentAuthService
            .isCustomerSupportAgentLoggedIn()
            .pipe(distinctUntilChanged(), tap((loggedIn) => {
            if (!loggedIn) {
                this.closeModal();
            }
        }));
        this.csAgentTokenLoading$ =
            this.csAgentAuthService.getCustomerSupportAgentTokenLoading();
        this.customer$ = this.authService.isUserLoggedIn().pipe(switchMap((isLoggedIn) => {
            if (isLoggedIn) {
                this.handleCustomerSessionStartRedirection();
                return this.userAccountFacade.get();
            }
            else {
                return of(undefined);
            }
        }));
        this.isCollapsed$ = this.asmService
            .getAsmUiState()
            .pipe(map((uiState) => uiState.collapsed === undefined ? false : uiState.collapsed));
        this.asmService.getAsmUiState().subscribe((state) => {
            if (state.status === this.forbiddenResponseStatus) {
                this.logout();
                this.hideUi();
                this.asmService.updateAsmUiState({ status: undefined });
            }
        });
        this.subscription.add(this.launchDialogService.dialogClose
            .pipe(filter((result) => Boolean(result)))
            .subscribe((result) => {
            if (typeof result !== 'string') {
                if ('selectedUser' in result) {
                    this.startCustomerEmulationSession(result.selectedUser);
                    if (result.actionType === CustomerListColumnActionType.ORDER_HISTORY) {
                        this.routingService.go({ cxRoute: 'orders' });
                    }
                }
                else if ('customerId' in result) {
                    this.startCustomerEmulationSession({
                        customerId: result.customerId,
                    });
                    this.showCreateCustomerSuccessfullyAlert = true;
                    this.routingService.go('/');
                }
                if ('actionType' in result &&
                    result.actionType === CustomerListColumnActionType.ACTIVE_CART) {
                    this.routingService.go({ cxRoute: 'cart' });
                }
                else if ('actionType' in result &&
                    result.actionType === CustomerListColumnActionType.CUSTOMER_360) {
                    this.customer$
                        .pipe(filter((curCustomer) => !!curCustomer), take(1))
                        .subscribe((customer) => {
                        this.showC360Dialog(customer);
                    });
                }
            }
            if (result === CLOSE_DIALOG_REASON.FORBIDDEN) {
                this.logout();
                this.hideUi();
            }
        }));
        this.subscription.add(combineLatest([
            this.customerSupportAgentLoggedIn$,
            this.asmComponentService.isCustomerEmulationSessionInProgress(),
        ])
            .pipe(debounceTime(500), distinctUntilChanged(), filter(([agentLoggedIn]) => Boolean(agentLoggedIn)))
            .subscribe(() => {
            this.asmService.customerSearch({
                query: 'autoSearchToAvoidUnauthorizedLogin',
                pageSize: 1,
            });
        }));
        this.subscribeForDeeplink();
    }
    showC360Dialog(customer) {
        this.isAsmCustomer360Loaded$
            .pipe(filter((isReady) => Boolean(isReady)))
            .subscribe(() => {
            const data = { customer: customer };
            this.launchDialogService.openDialogAndSubscribe(LAUNCH_CALLER.ASM_CUSTOMER_360, this.element, data);
        });
        this.subscription.add(this.launchDialogService.dialogClose
            .pipe(filter((closeContent) => Boolean(closeContent)))
            .subscribe((event) => {
            this.asmComponentService.handleAsmDialogAction(event);
        }));
    }
    /**
     * When agent is logged in and deep link has customerID,
     * call logout if has customer emulated(userLoggedin) but not emulated by deep link.
     * call startSessionWithParameters
     */
    subscribeForDeeplink() {
        if (this.asmComponentService.isEmulateInURL()) {
            //Always route to home page to avoid 404
            this.routingService.go('/');
        }
        const parameters = this.asmComponentService.getDeepLinkUrlParams() ?? {
            customerId: this.asmComponentService.getSearchParameter('customerId'),
            orderId: this.asmComponentService.getSearchParameter('orderId'),
            ticketId: this.asmComponentService.getSearchParameter('ticketId'),
            cartId: this.asmComponentService.getSearchParameter('cartId'),
            cartType: this.asmComponentService.getSearchParameter('cartType'),
            emulated: false,
        };
        this.deeplinkCartAlertKey = CART_TYPE_KEY[parameters.cartType || ''];
        this.subscription.add(combineLatest([
            this.customerSupportAgentLoggedIn$,
            this.authService.isUserLoggedIn(),
            this.asmComponentService.isEmulatedByDeepLink(),
        ]).subscribe(([agentLoggedIn, userLoggedin, isEmulatedByDeepLink]) => {
            if (agentLoggedIn && parameters.customerId) {
                if (!isEmulatedByDeepLink && userLoggedin) {
                    this.confirmSwitchCustomer(parameters.customerId);
                }
                else {
                    setTimeout(() => this.startSessionWithParameters({
                        ...parameters,
                        emulated: isEmulatedByDeepLink,
                    }));
                }
            }
        }));
    }
    confirmSwitchCustomer(switchCustomerId) {
        this.customer$
            .pipe(filter((curCustomer) => !!curCustomer), take(1))
            .subscribe((curCustomer) => {
            if (curCustomer?.customerId !== switchCustomerId) {
                this.userAccountFacade.getById(switchCustomerId).subscribe({
                    next: (switchCustomer) => {
                        this.launchDialogService.openDialogAndSubscribe(LAUNCH_CALLER.ASM_SWITCH_CUSTOMER, this.element, { curCustomer: curCustomer, switchCustomer: switchCustomer });
                    },
                    error: (error) => {
                        this.globalMessageService.add(error.details?.[0].message ?? '', GlobalMessageType.MSG_TYPE_ERROR);
                    },
                });
            }
            else {
                this.asmComponentService.setEmulatedByDeepLink(true);
            }
        });
    }
    /**
     * If url contains customerId and we haven't emulatedFromURL, we'll change the isEmulatedByDeepLink flag and
     * start emulate customer in URL.
     */
    startSessionWithParameters(parameters) {
        if (!parameters.emulated) {
            this.asmComponentService.setEmulatedByDeepLink(true);
            this.startCustomerEmulationSession({
                customerId: parameters.customerId,
            }, parameters);
        }
    }
    handleCustomerSessionStartRedirection() {
        this.asmComponentService
            .isCustomerEmulationSessionInProgress()
            .pipe(take(1))
            .subscribe((isCustomerEmulated) => {
            if (this.startingCustomerSession && isCustomerEmulated) {
                this.startingCustomerSession = false;
                this.globalMessageService.remove(GlobalMessageType.MSG_TYPE_ERROR);
                this.routingService.go('/');
            }
        });
    }
    loginCustomerSupportAgent({ userId, password, }) {
        this.csAgentAuthService.authorizeCustomerSupportAgent(userId, password);
    }
    loginCustomerSupportAgentWithAuthorizationCodeFlow() {
        this.csAgentAuthService.authorizeCustomerSupportAgentWhenUseCodeFlow();
    }
    logout() {
        this.asmComponentService.logoutCustomerSupportAgentAndCustomer();
    }
    startCustomerEmulationSession({ customerId }, parameters) {
        if (customerId) {
            this.csAgentAuthService.startCustomerEmulationSession(customerId);
            this.startingCustomerSession = true;
            this.showCustomerEmulationInfoAlert = true;
            this.showCreateCustomerSuccessfullyAlert = false;
            if (this.isAsmSessionConfigured) {
                this.asmService.createAsmSessionEvent({ eventType: 'StartSession' });
            }
            if (parameters) {
                this.asmComponentService.handleDeepLinkNavigation({
                    customerId,
                    ...parameters,
                });
            }
        }
        else {
            this.globalMessageService.add({ key: 'asm.error.noCustomerId' }, GlobalMessageType.MSG_TYPE_ERROR);
        }
    }
    hideUi() {
        this.disabled = true;
        this.asmComponentService.unload();
        this.oAuthLibWrapperService.refreshAuthConfig();
        this.authService.updateIsUsingASMClient(false);
    }
    showCustomList() {
        this.launchDialogService.openDialogAndSubscribe(LAUNCH_CALLER.ASM_CUSTOMER_LIST, this.element);
    }
    closeModal() {
        this.launchDialogService.closeDialog('logout');
    }
    createCustomer() {
        this.launchDialogService?.openDialogAndSubscribe(LAUNCH_CALLER.ASM_CREATE_CUSTOMER_FORM, this.addNewCustomerLink);
    }
    closeDialogConfirmationAlert() {
        this.showCreateCustomerSuccessfullyAlert = false;
    }
    closeDeeplinkCartInfoAlert() {
        this.asmComponentService.setShowDeeplinkCartInfoAlert(false);
    }
    closeCustomerEmulationInfoAlert() {
        this.showCustomerEmulationInfoAlert = false;
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmMainUiComponent, deps: [{ token: i1$1.AuthService }, { token: i2$1.CsAgentAuthService }, { token: AsmComponentService }, { token: i1$1.GlobalMessageService }, { token: i1$1.RoutingService }, { token: i1$3.AsmService }, { token: i2$3.UserAccountFacade }, { token: i1.LaunchDialogService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: AsmMainUiComponent, isStandalone: true, selector: "cx-asm-main-ui", host: { properties: { "class.hidden": "this.disabled" } }, viewQueries: [{ propertyName: "element", first: true, predicate: ["customerListLink"], descendants: true }, { propertyName: "addNewCustomerLink", first: true, predicate: ["addNewCustomerLink"], descendants: true }], ngImport: i0, template: "<div class=\"asm-bar\">\n  <div class=\"asm-bar-branding\">\n    <img\n      class=\"logo\"\n      src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAwCAYAAADuFn/PAAAAAXNSR0IArs4c6QAAD7RJREFUeAHtW3twVGcVP7t795V30rwJBBJeASq01NJgnZa2otTW2nHAqrRak+rUKfgYZ/xDW5lRR2e0/mGtAadqq6WjUAdNa4udqVZaEdtCKQ2FQEh5JSQh5Lnvp7/ft9lkd9l7swkhwMiZ3N27937fd8533ufcG9P1L/VE5SpMOwdMmk0iocDzWjAUnnbk/9cITSYx2xwS9Xs3Wzs7NmqhcOT/mh/Tunkw32SzScjr2Vy2v3XDa5tWhbRI5KoHmi4hmGx2ifi8mz8UmvHI9k2VyvVokasWMC38N8HtRHyezUejex5pXbdu1O9r5qsCuLgCUD4fmu/1bq5sbd9wdNMY84lYM10VwMUTAJlvtUnU491c0XZc+fxUZFo0Mn4QjiJMMFREcKJG4xxrC/7ETCQ854+JAtbBny5Mak3d1ab3BsKtCrhhuJ2K9lNpmU+KYAHpWRAFa4K4x7t5NouU5WhS4rRIvt0idotJ3MGIDPgj0usNSZ8vLMOBiIQhJQukoZkpHGOJcGXLiPD0WBNStOmvQ8ETAjp7iN0d++RelBLhBFsAnVQe/fXHZk7wDEuarXaJBrxNFe2nNzLb0VsBMWA0HoyO8WNDDnDxIzOy5ONzcuX6MqdU5VhxLZlYWoUvFJEud0iODQZkb5dXHa19PnEFw2LDBi0QRqqac14BBPnz2yul0GEZxZt68vzhQXm6pS+Gl9xLANL4uUWFsm5hPmiIjiPu2EQqSY8nJCeHAnK4zy+tOLrdQXXTClqVLFLwJKDM7BSLmMD8iN/btCRn3obtm+adz+CElTTlW0YuEDe1qR6M//oNJXJDRVbC0PNPqYFZVrPUFNjU8bHqHGUF3NxLx4ZkZ/uQdLnOF34Acad+To6srDRe/7ML8+T5Q/3KEpNFD5lijVKnWa4tdpxPWIZXeiGM/3S65Y/vD8hbnR6lLBdkEdR8DZrv9zUtyT+wYfu6+YbMJ5mjQZjMZ1H20HXF8s0VZWKjjU4C6IIWgyk8PlqVLY0vnhDGkMTVNJjA3bV5464+t9AhS4vtsqfDBWuiKY0Bk4dIhq5nbFbyWXGWJnfPzZc1NRT0gDy+p1uG/WHlmpJHZvALG6TmR/2epoOFBzccTEg1jWabTXBBpkhYgoGQNCy9Rr6zsnzSzE9ERKZvazknAX9IzFhf4QGuMFofNXmarKjMThye9pwWtqYmV6Jwc2R4fI3Rb/qyKQDGgvsWF8ovVlcJSEOPJsaTUTzkkdGBRMZstorA7SwqXLRBMmQ+STczC/IHwnA3TvlGfdkUbCe2xBsnhmVna79YTQi3YB7x8AhA0LfPzpNsW7JG6yG+BWOLHWYJgwHxNUa/KeUphPqZOfKt+nKlJIk0j+Ib2UPyb8QfMD/q8zYV9/Ru3L7ONK7bSSTZHIUZm6FJDdeXIrsZnynMdBh4jfbuR1B8YnenhBCIVZZFV4GDuLLh2j4xLz+RBsPzylyrspYAlIRrJB1TZAGJBHxmUZFcV5YFRUmDLxU/fpP5aC80Fff1GWY7iTgSzzWa26wCu6yA9I3g7VPDsu1Ar3zQ75MAGEwNLnBoUgtfv2JmriybkSM5SFcJO1p65Z3Tw2JnPgqtiUMIgluGsXUlzviljL7vnF8gLx86h7UShnNdIy3A0NeODcrrHwwqn56LrKv2GtA6K0+K4Pv1wAoF+STw7T05lBy4kibQ8lhkMdvxNZUMD06K+VxSC0NLawtto8xLwjPyYx+Y2bCtVVwjAYrpGvdOBXzlcFSeguVUF9rlzroiuXlOgfzmv2fEwgFwG4kQhitag80xUE8EbgLTZsISOgb9Y3MhzPEE8NapIdmyu0McyNRIDjOcmVC2x1ZXy621BbokLK/KEZQ8CPLJ9I9OwDpm9POR7fzqYPXyjTJBtzO6Dk4QH8MosPQ1goND4DSDNFCKDT4dHk99O8xRRSjKaTnR65Ff7jolX37ufTnT78UYBE1oafygT2Uhd9vcwkT8GZ3noVa4tSY/5tIS1jQBrxFYIWdkqurIAkMdoL2jzyvf/1u7dA8HdKdW5FmlCHEnFozH9qASAfDCYtLYz2+qe7P9gphPAhADEBipTQZwIzTwJ3fVSmm2VTy+kARgNeyiqkDFbzDFooQioh7w4PfovZFxDL7U5Mp8W1pMrLppYXqwBtbFuJ2MF2ptAFEwK4kO0MWkoGPAK/s7hnVnMhZmw30m4eI+aEZgPtzOr+pqTmzYvj25saa7oMENiDIq3UN+gyGxW5+6tkRurM6XHe/2yIstZ6XtrEcJTgOxTOPoluIVbypb+JvK+slF1+jiae/1yuvH+qVx5Yy0Y66tzJX5xVnScsYlrFpZA5AfRkCGcVwEljoKoDOMaz5UxXqgIQ7Aa6lxo1Mxj3l+OOD73eEFKze2rKvX1xa9hdNcx1aicqjLJb0ufZOMzyvPs8nDH62SPzculWceWAJmVUkNAlsAgdwFywhCS0LQstTDz0BfZJebEB/0YM8HA7Jjf7eqpNONYWF4x4JC8QVDav0g8LCvYwS8z3GJ9NDaEY9lfql+Fc4kg/sJJ8wNm20S9nu3+sKBr12Iz0+l10wtOQ2fTa3OFBjUbpqdL9/9xBz5y1eXyVNfWCy0EA0bc6Pw4oZJfPzwwWXdPr9IcrhzHdjV1icHod20LD1YXVes1qCgufZ4AmDKTOFTQUgDafPg+PwNFbIAqaYeuOEKe90B5XIUHgseIwa9W/3RYOPxTat8evMmc121o+m/m/51QlaBSdVFE0sRnVaLmse5LZ0ueeK14/IShKk6nbQvCDiLqd3iYl36uuAC950cFK8/KK9DEAvK0lfJc0uyZHlVrvzzyLmY+xnHAvIg8CpYrQM0ZiGAVF+TJXdDUe6+ttSwC9ra7ZJ+eASVraG3A5+/1VLqbmjfeOf4vlp3l+lvQAAoxHDvNLKDh7e+J1vWf0hmogczGVhSmSNbPr9EnvnPafnB344iINP8o3Lj7AJZDB+uB3va+6V70KcC+T9bz0nDyplpny8wzty1pFRePXQ2IwE8WD9DPgdtN2EiBWBFvMoEXnm/V/xwddnOLHY1n9OGfQ1tP5x65pMW1PgIRjiYYew/MSj3bdkrfz/YkwmdumO+WF8lP753IVLQqEod74LWscDRg1cP9ap+jxWMOgBL6BjQt/JVC4qkIgfv1JBurG8E1PyCLKvkI83OlPknoYgvvtslDjzDDQe8W8H8L7c9cXGYT9qRa2ETPJAZ2OEyTvS65StPvysP//6AvH18wGh/hvfWLq+QtcvLhW5g9aIS3bH96Mf/tw09IygAApL0DvlkdxuqXh0oy7PLzaglmNbGzEBn4CQuM2b86IUjctYFrxD0bTU5LI0Xk/kk0RxhMEs4GCbplnbs7ZC1T74lX9jytvzpzQ45Y6CVentdf1OVrIHLmGkQV/a098mpc24xgfmKDmj2Ky3GFnjX0jIIi3pjbAF6dKW7zjrksR2Hpfm9PtEi/q3RLG3KA246vBrdRCrQWTjgL1kJ/gPM4FGe75Dl8OV3LC6VW5CNVBSMHycWVuTKN1fXpi6f9Jsuh81Atq0JVIAPetwyhEedeToV+sraIvSgnOhank+7WmSCH0eRhv8Ymr8TzwSQ7zxr7rc9dPzxqc129Egy1Xz9paRd8Eeqt+Y1lVNjwzwvRz/l08tnyCNgbhH88YUAU8O2brd0IhX24zlzCVzMbGQ7FLDR06nvbTsodvitR++tmxT6QU9QDqEafuGdTmned0b6fSaxg/mRwa6Hjj/9oH4QmhQ2/UnnWQALFWYbDFpxQfCb+QMrRAqgH02xJ3celdOIF5sbl+NhRHykPiK9O9l2TZbOyleH3ph019fADe05qh8rOOeNw72y+0gv6I7thSnxOaSXp895YGUelfmxTnA4nGKPBrfCrTW2P/3glKea6eiPX9Ms8P9xYMq4/iOzlAvY09qrLttIfDr+QiLtnUMqflM40w3LqgtQNxh3A954v0cebz4szpE2OWnkXpiWMsdnC8XuQLaDgBs1WxoudsBNxyNYQEwAZP6c0hx5dO0SVUTthGlu//cJOXC8X4bx8JouSAkCJsAZOXgW8NAdtcoq0i18sa9lA//NC/WLO+Jnzygbb3Kkvs2haIMgzKhwI0g1oxbrJWE+6dAs9CmAIPzvA7fORsESaxfcc2OVfOrDVXKsa1gOnhyQDrSbB1Ce0y+XoVBbsaBEFs3M/MlWDMvUfjoSNDvdyrRM7i++x8QxJjI/6Hs2rFkveqqZiDf1XFkAU7B55Tny6fpZSfep8XORyfC4IoEtWFp4BBsZAb4wpv45Iuh/1uvvY8CdVp8fpyP+rbH4iSIQrV81B2kfnuxPA/AlgJ9tf0/KUR8sqi6U8kInyn6rCvpMAs6hGDuJVHQ/CrL7bquRuZXjv8KSjmy0/tWTOfV0bmSAcjsh/7OewMC0Zjvp6OM1ja+J1MGVrL1ljt6YKb/ehuD93KvHVJfSjnaB06aJNvLWHRXWj86lF+mpF4IqRTo6WQHwAQULPB4EExtrYL7X6Wg8/utLq/lxpppZUfrQ+37tnTNq4/Ebk/lmoH793TOKeUbzd2EM35jIBvMZcfxgthvxhYfXizYwqmEnnkjxIf+/W7rQqoox0GjNdPdoASw0eZjRzxf4fG+H45L6/FQ6zVS8M2dd8u0nd8v9P/yH/H7nETnd40odZ/ib7NmHfPurP90lbx7uESdyeyPYtb8TjwbBHAiMLpDtcAoifvAa7/Hd0kNoVUyUnjhu9b4n10fANQX8f3BndTa2vXzxGmtxvBP5Nl33pW1KvUCnejWR2laEarQOvnnZvGKpm10olXgUWJhrFxs0lsCxLk9AulG9toBBb0Cj6a/d3qCsva1W5lTQZ6tl1fjEj0Fo+XOvHAUuMHksNiYOSTpnS/tOJAcLZvFhfvo1kyYk/Njd0i1vHxlAbAltc3VlP3C5MZ+kmq574E/n7YquhO+JsuPLgsWJjiaDZLylywk+uI1hMJzpKythK1wGGcrfRi6DYyjIDHgfYyUGBrDmZP6XzWZHO0NCzR6LfX3rb+/Rfwofw3RJPrV4gErErlwBKmDlE3AjDAYMBn1J3V8ykk+9NPaRCTQL/KmXeg16/6Nj1UkGH1iT/48AZBkMHhvCt5Qj4UCzW3NctswntRr5lgmo/DmVBzGeZzJ9WseQ+eFgoNkz5Frf2vzZy1Lz4wxBDM5QAvEZl/m32cJUE8y3kfkNlzXzyUr1XtBlztOMyVNuJ+Rvdg571u+7Apg/IoCM93dZD+S7mnA7f/W4PPdfKcwfEcCV74KU26HPd3vvvxLcTqImX4pWfiL+Cz7nf6ZEI8G/ut3eK8Lnp254pAOTevnK+G0yI4RFQvtzQ9r6vc0NEyvfL5Mt/g8XIbTVhsig+gAAAABJRU5ErkJggg==\"\n      width=\"48\"\n      height=\"24\"\n      alt=\"{{ 'asm.mainLogoLabel' | cxTranslate }}\"\n      title=\"{{ 'asm.mainLogoLabel' | cxTranslate }}\"\n    />\n\n    <div class=\"asm-title\">\n      {{ 'asm.mainTitle' | cxTranslate }}\n    </div>\n  </div>\n  <div class=\"asm-bar-actions\">\n    <div class=\"cx-asm-help-portal\">\n      <a\n        href=\"https://help.sap.com/docs/SAP_COMMERCE_COMPOSABLE_STOREFRONT/d1ca9a1517f847a5b57b4e08400807c1/2367ff04ccb649ac82a3795ecf72a804.html?locale=en-US\"\n        target=\"_blank\"\n        rel=\"noopener noreferrer\"\n        role=\"button\"\n      >\n        <cx-icon [type]=\"iconTypes.HELP\"></cx-icon>\n        <span>{{ 'asm.helpPortalUrl' | cxTranslate }}</span></a\n      >\n    </div>\n\n    <div\n      class=\"cx-asm-customer-list\"\n      *ngIf=\"customerSupportAgentLoggedIn$ | async\"\n    >\n      <a\n        #customerListLink\n        tabindex=\"0\"\n        role=\"button\"\n        class=\"cx-asm-customer-list-link\"\n        (click)=\"showCustomList()\"\n      >\n        <cx-icon [type]=\"iconTypes.USER_FRIENDS\"></cx-icon>\n        <span>{{ 'asm.customers' | cxTranslate }}</span></a\n      >\n    </div>\n\n    <ng-container *cxFeature=\"'!authorizationCodeFlowByDefault'\">\n      <cx-asm-toggle-ui\n        *ngIf=\"customerSupportAgentLoggedIn$ | async\"\n      ></cx-asm-toggle-ui>\n    </ng-container>\n\n    <cx-asm-session-timer\n      *ngIf=\"customerSupportAgentLoggedIn$ | async\"\n    ></cx-asm-session-timer>\n\n    <ng-container *cxFeature=\"'authorizationCodeFlowByDefault'\">\n      <div\n        class=\"cx-asm-customer-list\"\n        *ngIf=\"!(customerSupportAgentLoggedIn$ | async)\"\n      >\n        <a\n          role=\"link\"\n          class=\"cx-asm-customer-list-link\"\n          (click)=\"loginCustomerSupportAgentWithAuthorizationCodeFlow()\"\n          >{{ 'asm.asmSignIn' | cxTranslate }}</a\n        >\n      </div>\n    </ng-container>\n    <button\n      class=\"close\"\n      title=\"{{ 'asm.hideUi' | cxTranslate }}\"\n      *ngIf=\"\n        !(customerSupportAgentLoggedIn$ | async) &&\n        !(csAgentTokenLoading$ | async)\n      \"\n      (click)=\"hideUi()\"\n    ></button>\n\n    <button\n      class=\"logout\"\n      title=\"{{ 'asm.logout' | cxTranslate }}\"\n      *ngIf=\"customerSupportAgentLoggedIn$ | async\"\n      (click)=\"logout()\"\n    ></button>\n  </div>\n</div>\n\n<ng-container *ngIf=\"!(isCollapsed$ | async) as notCollapsed\">\n  <ng-container\n    *ngIf=\"customerSupportAgentLoggedIn$ | async; else showLoginForm\"\n  >\n    <ng-container *ngIf=\"customer$ | async; else showCustomerSelection\">\n      <cx-customer-emulation *ngIf=\"notCollapsed\"></cx-customer-emulation>\n      <cx-message\n        *ngIf=\"notCollapsed && showCreateCustomerSuccessfullyAlert\"\n        [text]=\"'asm.createCustomerSuccessfullyAlert' | cxTranslate\"\n        [type]=\"globalMessageType.MSG_TYPE_CONFIRMATION\"\n        (closeMessage)=\"closeDialogConfirmationAlert()\"\n      >\n      </cx-message>\n      <cx-message\n        *ngIf=\"showDeeplinkCartInfoAlert$ | async\"\n        [text]=\"deeplinkCartAlertKey | cxTranslate\"\n        [type]=\"globalMessageType.MSG_TYPE_INFO\"\n        (closeMessage)=\"closeDeeplinkCartInfoAlert()\"\n      >\n      </cx-message>\n      <cx-message\n        *ngIf=\"notCollapsed && showCustomerEmulationInfoAlert\"\n        [text]=\"'asm.startCustomerEmulationAlertInfo' | cxTranslate\"\n        [type]=\"globalMessageType.MSG_TYPE_INFO\"\n        (closeMessage)=\"closeCustomerEmulationInfoAlert()\"\n      >\n      </cx-message>\n    </ng-container>\n    <ng-template #showCustomerSelection>\n      <cx-customer-selection\n        *ngIf=\"notCollapsed\"\n        (submitEvent)=\"startCustomerEmulationSession($event, $event.parameters)\"\n      ></cx-customer-selection>\n    </ng-template>\n  </ng-container>\n\n  <ng-template #showLoginForm>\n    <ng-container *cxFeature=\"'!authorizationCodeFlowByDefault'\">\n      <cx-csagent-login-form\n        *ngIf=\"notCollapsed\"\n        (submitEvent)=\"loginCustomerSupportAgent($event)\"\n        [csAgentTokenLoading]=\"csAgentTokenLoading$ | async\"\n      ></cx-csagent-login-form>\n    </ng-container>\n  </ng-template>\n</ng-container>\n", dependencies: [{ kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: FeatureDirective, selector: "[cxFeature]", inputs: ["cxFeature"] }, { kind: "component", type: AsmToggleUiComponent, selector: "cx-asm-toggle-ui" }, { kind: "component", type: AsmSessionTimerComponent, selector: "cx-asm-session-timer" }, { kind: "component", type: CustomerEmulationComponent, selector: "cx-customer-emulation" }, { kind: "component", type: MessageComponent, selector: "cx-message", inputs: ["text", "actionButtonText", "actionButtonMessage", "accordionText", "showBody", "isVisibleCloseButton", "type"], outputs: ["closeMessage", "buttonAction"] }, { kind: "component", type: CustomerSelectionComponent, selector: "cx-customer-selection", outputs: ["submitEvent"] }, { kind: "component", type: CSAgentLoginFormComponent, selector: "cx-csagent-login-form", inputs: ["csAgentTokenLoading"], outputs: ["submitEvent"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmMainUiComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-asm-main-ui', imports: [
                        IconComponent,
                        NgIf,
                        FeatureDirective,
                        AsmToggleUiComponent,
                        AsmSessionTimerComponent,
                        CustomerEmulationComponent,
                        MessageComponent,
                        CustomerSelectionComponent,
                        CSAgentLoginFormComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<div class=\"asm-bar\">\n  <div class=\"asm-bar-branding\">\n    <img\n      class=\"logo\"\n      src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAAAwCAYAAADuFn/PAAAAAXNSR0IArs4c6QAAD7RJREFUeAHtW3twVGcVP7t795V30rwJBBJeASq01NJgnZa2otTW2nHAqrRak+rUKfgYZ/xDW5lRR2e0/mGtAadqq6WjUAdNa4udqVZaEdtCKQ2FQEh5JSQh5Lnvp7/ft9lkd9l7swkhwMiZ3N27937fd8533ufcG9P1L/VE5SpMOwdMmk0iocDzWjAUnnbk/9cITSYx2xwS9Xs3Wzs7NmqhcOT/mh/Tunkw32SzScjr2Vy2v3XDa5tWhbRI5KoHmi4hmGx2ifi8mz8UmvHI9k2VyvVokasWMC38N8HtRHyezUejex5pXbdu1O9r5qsCuLgCUD4fmu/1bq5sbd9wdNMY84lYM10VwMUTAJlvtUnU491c0XZc+fxUZFo0Mn4QjiJMMFREcKJG4xxrC/7ETCQ854+JAtbBny5Mak3d1ab3BsKtCrhhuJ2K9lNpmU+KYAHpWRAFa4K4x7t5NouU5WhS4rRIvt0idotJ3MGIDPgj0usNSZ8vLMOBiIQhJQukoZkpHGOJcGXLiPD0WBNStOmvQ8ETAjp7iN0d++RelBLhBFsAnVQe/fXHZk7wDEuarXaJBrxNFe2nNzLb0VsBMWA0HoyO8WNDDnDxIzOy5ONzcuX6MqdU5VhxLZlYWoUvFJEud0iODQZkb5dXHa19PnEFw2LDBi0QRqqac14BBPnz2yul0GEZxZt68vzhQXm6pS+Gl9xLANL4uUWFsm5hPmiIjiPu2EQqSY8nJCeHAnK4zy+tOLrdQXXTClqVLFLwJKDM7BSLmMD8iN/btCRn3obtm+adz+CElTTlW0YuEDe1qR6M//oNJXJDRVbC0PNPqYFZVrPUFNjU8bHqHGUF3NxLx4ZkZ/uQdLnOF34Acad+To6srDRe/7ML8+T5Q/3KEpNFD5lijVKnWa4tdpxPWIZXeiGM/3S65Y/vD8hbnR6lLBdkEdR8DZrv9zUtyT+wYfu6+YbMJ5mjQZjMZ1H20HXF8s0VZWKjjU4C6IIWgyk8PlqVLY0vnhDGkMTVNJjA3bV5464+t9AhS4vtsqfDBWuiKY0Bk4dIhq5nbFbyWXGWJnfPzZc1NRT0gDy+p1uG/WHlmpJHZvALG6TmR/2epoOFBzccTEg1jWabTXBBpkhYgoGQNCy9Rr6zsnzSzE9ERKZvazknAX9IzFhf4QGuMFofNXmarKjMThye9pwWtqYmV6Jwc2R4fI3Rb/qyKQDGgvsWF8ovVlcJSEOPJsaTUTzkkdGBRMZstorA7SwqXLRBMmQ+STczC/IHwnA3TvlGfdkUbCe2xBsnhmVna79YTQi3YB7x8AhA0LfPzpNsW7JG6yG+BWOLHWYJgwHxNUa/KeUphPqZOfKt+nKlJIk0j+Ib2UPyb8QfMD/q8zYV9/Ru3L7ONK7bSSTZHIUZm6FJDdeXIrsZnynMdBh4jfbuR1B8YnenhBCIVZZFV4GDuLLh2j4xLz+RBsPzylyrspYAlIRrJB1TZAGJBHxmUZFcV5YFRUmDLxU/fpP5aC80Fff1GWY7iTgSzzWa26wCu6yA9I3g7VPDsu1Ar3zQ75MAGEwNLnBoUgtfv2JmriybkSM5SFcJO1p65Z3Tw2JnPgqtiUMIgluGsXUlzviljL7vnF8gLx86h7UShnNdIy3A0NeODcrrHwwqn56LrKv2GtA6K0+K4Pv1wAoF+STw7T05lBy4kibQ8lhkMdvxNZUMD06K+VxSC0NLawtto8xLwjPyYx+Y2bCtVVwjAYrpGvdOBXzlcFSeguVUF9rlzroiuXlOgfzmv2fEwgFwG4kQhitag80xUE8EbgLTZsISOgb9Y3MhzPEE8NapIdmyu0McyNRIDjOcmVC2x1ZXy621BbokLK/KEZQ8CPLJ9I9OwDpm9POR7fzqYPXyjTJBtzO6Dk4QH8MosPQ1goND4DSDNFCKDT4dHk99O8xRRSjKaTnR65Ff7jolX37ufTnT78UYBE1oafygT2Uhd9vcwkT8GZ3noVa4tSY/5tIS1jQBrxFYIWdkqurIAkMdoL2jzyvf/1u7dA8HdKdW5FmlCHEnFozH9qASAfDCYtLYz2+qe7P9gphPAhADEBipTQZwIzTwJ3fVSmm2VTy+kARgNeyiqkDFbzDFooQioh7w4PfovZFxDL7U5Mp8W1pMrLppYXqwBtbFuJ2MF2ptAFEwK4kO0MWkoGPAK/s7hnVnMhZmw30m4eI+aEZgPtzOr+pqTmzYvj25saa7oMENiDIq3UN+gyGxW5+6tkRurM6XHe/2yIstZ6XtrEcJTgOxTOPoluIVbypb+JvK+slF1+jiae/1yuvH+qVx5Yy0Y66tzJX5xVnScsYlrFpZA5AfRkCGcVwEljoKoDOMaz5UxXqgIQ7Aa6lxo1Mxj3l+OOD73eEFKze2rKvX1xa9hdNcx1aicqjLJb0ufZOMzyvPs8nDH62SPzculWceWAJmVUkNAlsAgdwFywhCS0LQstTDz0BfZJebEB/0YM8HA7Jjf7eqpNONYWF4x4JC8QVDav0g8LCvYwS8z3GJ9NDaEY9lfql+Fc4kg/sJJ8wNm20S9nu3+sKBr12Iz0+l10wtOQ2fTa3OFBjUbpqdL9/9xBz5y1eXyVNfWCy0EA0bc6Pw4oZJfPzwwWXdPr9IcrhzHdjV1icHod20LD1YXVes1qCgufZ4AmDKTOFTQUgDafPg+PwNFbIAqaYeuOEKe90B5XIUHgseIwa9W/3RYOPxTat8evMmc121o+m/m/51QlaBSdVFE0sRnVaLmse5LZ0ueeK14/IShKk6nbQvCDiLqd3iYl36uuAC950cFK8/KK9DEAvK0lfJc0uyZHlVrvzzyLmY+xnHAvIg8CpYrQM0ZiGAVF+TJXdDUe6+ttSwC9ra7ZJ+eASVraG3A5+/1VLqbmjfeOf4vlp3l+lvQAAoxHDvNLKDh7e+J1vWf0hmogczGVhSmSNbPr9EnvnPafnB344iINP8o3Lj7AJZDB+uB3va+6V70KcC+T9bz0nDyplpny8wzty1pFRePXQ2IwE8WD9DPgdtN2EiBWBFvMoEXnm/V/xwddnOLHY1n9OGfQ1tP5x65pMW1PgIRjiYYew/MSj3bdkrfz/YkwmdumO+WF8lP753IVLQqEod74LWscDRg1cP9ap+jxWMOgBL6BjQt/JVC4qkIgfv1JBurG8E1PyCLKvkI83OlPknoYgvvtslDjzDDQe8W8H8L7c9cXGYT9qRa2ETPJAZ2OEyTvS65StPvysP//6AvH18wGh/hvfWLq+QtcvLhW5g9aIS3bH96Mf/tw09IygAApL0DvlkdxuqXh0oy7PLzaglmNbGzEBn4CQuM2b86IUjctYFrxD0bTU5LI0Xk/kk0RxhMEs4GCbplnbs7ZC1T74lX9jytvzpzQ45Y6CVentdf1OVrIHLmGkQV/a098mpc24xgfmKDmj2Ky3GFnjX0jIIi3pjbAF6dKW7zjrksR2Hpfm9PtEi/q3RLG3KA246vBrdRCrQWTjgL1kJ/gPM4FGe75Dl8OV3LC6VW5CNVBSMHycWVuTKN1fXpi6f9Jsuh81Atq0JVIAPetwyhEedeToV+sraIvSgnOhank+7WmSCH0eRhv8Ymr8TzwSQ7zxr7rc9dPzxqc129Egy1Xz9paRd8Eeqt+Y1lVNjwzwvRz/l08tnyCNgbhH88YUAU8O2brd0IhX24zlzCVzMbGQ7FLDR06nvbTsodvitR++tmxT6QU9QDqEafuGdTmned0b6fSaxg/mRwa6Hjj/9oH4QmhQ2/UnnWQALFWYbDFpxQfCb+QMrRAqgH02xJ3celdOIF5sbl+NhRHykPiK9O9l2TZbOyleH3ph019fADe05qh8rOOeNw72y+0gv6I7thSnxOaSXp895YGUelfmxTnA4nGKPBrfCrTW2P/3glKea6eiPX9Ms8P9xYMq4/iOzlAvY09qrLttIfDr+QiLtnUMqflM40w3LqgtQNxh3A954v0cebz4szpE2OWnkXpiWMsdnC8XuQLaDgBs1WxoudsBNxyNYQEwAZP6c0hx5dO0SVUTthGlu//cJOXC8X4bx8JouSAkCJsAZOXgW8NAdtcoq0i18sa9lA//NC/WLO+Jnzygbb3Kkvs2haIMgzKhwI0g1oxbrJWE+6dAs9CmAIPzvA7fORsESaxfcc2OVfOrDVXKsa1gOnhyQDrSbB1Ce0y+XoVBbsaBEFs3M/MlWDMvUfjoSNDvdyrRM7i++x8QxJjI/6Hs2rFkveqqZiDf1XFkAU7B55Tny6fpZSfep8XORyfC4IoEtWFp4BBsZAb4wpv45Iuh/1uvvY8CdVp8fpyP+rbH4iSIQrV81B2kfnuxPA/AlgJ9tf0/KUR8sqi6U8kInyn6rCvpMAs6hGDuJVHQ/CrL7bquRuZXjv8KSjmy0/tWTOfV0bmSAcjsh/7OewMC0Zjvp6OM1ja+J1MGVrL1ljt6YKb/ehuD93KvHVJfSjnaB06aJNvLWHRXWj86lF+mpF4IqRTo6WQHwAQULPB4EExtrYL7X6Wg8/utLq/lxpppZUfrQ+37tnTNq4/Ebk/lmoH793TOKeUbzd2EM35jIBvMZcfxgthvxhYfXizYwqmEnnkjxIf+/W7rQqoox0GjNdPdoASw0eZjRzxf4fG+H45L6/FQ6zVS8M2dd8u0nd8v9P/yH/H7nETnd40odZ/ib7NmHfPurP90lbx7uESdyeyPYtb8TjwbBHAiMLpDtcAoifvAa7/Hd0kNoVUyUnjhu9b4n10fANQX8f3BndTa2vXzxGmtxvBP5Nl33pW1KvUCnejWR2laEarQOvnnZvGKpm10olXgUWJhrFxs0lsCxLk9AulG9toBBb0Cj6a/d3qCsva1W5lTQZ6tl1fjEj0Fo+XOvHAUuMHksNiYOSTpnS/tOJAcLZvFhfvo1kyYk/Njd0i1vHxlAbAltc3VlP3C5MZ+kmq574E/n7YquhO+JsuPLgsWJjiaDZLylywk+uI1hMJzpKythK1wGGcrfRi6DYyjIDHgfYyUGBrDmZP6XzWZHO0NCzR6LfX3rb+/Rfwofw3RJPrV4gErErlwBKmDlE3AjDAYMBn1J3V8ykk+9NPaRCTQL/KmXeg16/6Nj1UkGH1iT/48AZBkMHhvCt5Qj4UCzW3NctswntRr5lgmo/DmVBzGeZzJ9WseQ+eFgoNkz5Frf2vzZy1Lz4wxBDM5QAvEZl/m32cJUE8y3kfkNlzXzyUr1XtBlztOMyVNuJ+Rvdg571u+7Apg/IoCM93dZD+S7mnA7f/W4PPdfKcwfEcCV74KU26HPd3vvvxLcTqImX4pWfiL+Cz7nf6ZEI8G/ut3eK8Lnp254pAOTevnK+G0yI4RFQvtzQ9r6vc0NEyvfL5Mt/g8XIbTVhsig+gAAAABJRU5ErkJggg==\"\n      width=\"48\"\n      height=\"24\"\n      alt=\"{{ 'asm.mainLogoLabel' | cxTranslate }}\"\n      title=\"{{ 'asm.mainLogoLabel' | cxTranslate }}\"\n    />\n\n    <div class=\"asm-title\">\n      {{ 'asm.mainTitle' | cxTranslate }}\n    </div>\n  </div>\n  <div class=\"asm-bar-actions\">\n    <div class=\"cx-asm-help-portal\">\n      <a\n        href=\"https://help.sap.com/docs/SAP_COMMERCE_COMPOSABLE_STOREFRONT/d1ca9a1517f847a5b57b4e08400807c1/2367ff04ccb649ac82a3795ecf72a804.html?locale=en-US\"\n        target=\"_blank\"\n        rel=\"noopener noreferrer\"\n        role=\"button\"\n      >\n        <cx-icon [type]=\"iconTypes.HELP\"></cx-icon>\n        <span>{{ 'asm.helpPortalUrl' | cxTranslate }}</span></a\n      >\n    </div>\n\n    <div\n      class=\"cx-asm-customer-list\"\n      *ngIf=\"customerSupportAgentLoggedIn$ | async\"\n    >\n      <a\n        #customerListLink\n        tabindex=\"0\"\n        role=\"button\"\n        class=\"cx-asm-customer-list-link\"\n        (click)=\"showCustomList()\"\n      >\n        <cx-icon [type]=\"iconTypes.USER_FRIENDS\"></cx-icon>\n        <span>{{ 'asm.customers' | cxTranslate }}</span></a\n      >\n    </div>\n\n    <ng-container *cxFeature=\"'!authorizationCodeFlowByDefault'\">\n      <cx-asm-toggle-ui\n        *ngIf=\"customerSupportAgentLoggedIn$ | async\"\n      ></cx-asm-toggle-ui>\n    </ng-container>\n\n    <cx-asm-session-timer\n      *ngIf=\"customerSupportAgentLoggedIn$ | async\"\n    ></cx-asm-session-timer>\n\n    <ng-container *cxFeature=\"'authorizationCodeFlowByDefault'\">\n      <div\n        class=\"cx-asm-customer-list\"\n        *ngIf=\"!(customerSupportAgentLoggedIn$ | async)\"\n      >\n        <a\n          role=\"link\"\n          class=\"cx-asm-customer-list-link\"\n          (click)=\"loginCustomerSupportAgentWithAuthorizationCodeFlow()\"\n          >{{ 'asm.asmSignIn' | cxTranslate }}</a\n        >\n      </div>\n    </ng-container>\n    <button\n      class=\"close\"\n      title=\"{{ 'asm.hideUi' | cxTranslate }}\"\n      *ngIf=\"\n        !(customerSupportAgentLoggedIn$ | async) &&\n        !(csAgentTokenLoading$ | async)\n      \"\n      (click)=\"hideUi()\"\n    ></button>\n\n    <button\n      class=\"logout\"\n      title=\"{{ 'asm.logout' | cxTranslate }}\"\n      *ngIf=\"customerSupportAgentLoggedIn$ | async\"\n      (click)=\"logout()\"\n    ></button>\n  </div>\n</div>\n\n<ng-container *ngIf=\"!(isCollapsed$ | async) as notCollapsed\">\n  <ng-container\n    *ngIf=\"customerSupportAgentLoggedIn$ | async; else showLoginForm\"\n  >\n    <ng-container *ngIf=\"customer$ | async; else showCustomerSelection\">\n      <cx-customer-emulation *ngIf=\"notCollapsed\"></cx-customer-emulation>\n      <cx-message\n        *ngIf=\"notCollapsed && showCreateCustomerSuccessfullyAlert\"\n        [text]=\"'asm.createCustomerSuccessfullyAlert' | cxTranslate\"\n        [type]=\"globalMessageType.MSG_TYPE_CONFIRMATION\"\n        (closeMessage)=\"closeDialogConfirmationAlert()\"\n      >\n      </cx-message>\n      <cx-message\n        *ngIf=\"showDeeplinkCartInfoAlert$ | async\"\n        [text]=\"deeplinkCartAlertKey | cxTranslate\"\n        [type]=\"globalMessageType.MSG_TYPE_INFO\"\n        (closeMessage)=\"closeDeeplinkCartInfoAlert()\"\n      >\n      </cx-message>\n      <cx-message\n        *ngIf=\"notCollapsed && showCustomerEmulationInfoAlert\"\n        [text]=\"'asm.startCustomerEmulationAlertInfo' | cxTranslate\"\n        [type]=\"globalMessageType.MSG_TYPE_INFO\"\n        (closeMessage)=\"closeCustomerEmulationInfoAlert()\"\n      >\n      </cx-message>\n    </ng-container>\n    <ng-template #showCustomerSelection>\n      <cx-customer-selection\n        *ngIf=\"notCollapsed\"\n        (submitEvent)=\"startCustomerEmulationSession($event, $event.parameters)\"\n      ></cx-customer-selection>\n    </ng-template>\n  </ng-container>\n\n  <ng-template #showLoginForm>\n    <ng-container *cxFeature=\"'!authorizationCodeFlowByDefault'\">\n      <cx-csagent-login-form\n        *ngIf=\"notCollapsed\"\n        (submitEvent)=\"loginCustomerSupportAgent($event)\"\n        [csAgentTokenLoading]=\"csAgentTokenLoading$ | async\"\n      ></cx-csagent-login-form>\n    </ng-container>\n  </ng-template>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: i1$1.AuthService }, { type: i2$1.CsAgentAuthService }, { type: AsmComponentService }, { type: i1$1.GlobalMessageService }, { type: i1$1.RoutingService }, { type: i1$3.AsmService }, { type: i2$3.UserAccountFacade }, { type: i1.LaunchDialogService }], propDecorators: { disabled: [{
                type: HostBinding,
                args: ['class.hidden']
            }], element: [{
                type: ViewChild,
                args: ['customerListLink']
            }], addNewCustomerLink: [{
                type: ViewChild,
                args: ['addNewCustomerLink']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var SWITCH_CUSTOMER_DIALOG_ACTION;
(function (SWITCH_CUSTOMER_DIALOG_ACTION) {
    SWITCH_CUSTOMER_DIALOG_ACTION["CANCEL"] = "CANCEL";
    SWITCH_CUSTOMER_DIALOG_ACTION["SWITCH"] = "SWITCH";
})(SWITCH_CUSTOMER_DIALOG_ACTION || (SWITCH_CUSTOMER_DIALOG_ACTION = {}));
class AsmSwitchCustomerDialogComponent {
    constructor(launchDialogService, asmComponentService) {
        this.launchDialogService = launchDialogService;
        this.asmComponentService = asmComponentService;
        this.SWITCH_CUSTOMER_DIALOG_ACTION = SWITCH_CUSTOMER_DIALOG_ACTION;
        this.focusConfig = {
            trap: true,
            block: true,
            autofocus: true,
            focusOnEscape: true,
        };
    }
    ngOnInit() {
        this.launchDialogService.data$
            .pipe(take(1))
            .subscribe((data) => {
            this.curCustomerName = data.curCustomer.name || '';
            this.switchCustomerName = data.switchCustomer.name || '';
        });
    }
    closeModal(reason) {
        if (reason === SWITCH_CUSTOMER_DIALOG_ACTION.SWITCH) {
            this.asmComponentService.logoutCustomer();
        }
        this.launchDialogService.closeDialog(reason);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmSwitchCustomerDialogComponent, deps: [{ token: i1.LaunchDialogService }, { token: AsmComponentService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: AsmSwitchCustomerDialogComponent, isStandalone: true, selector: "cx-asm-switch-customer-dialog", ngImport: i0, template: "<div\n  class=\"cx-asm-switch-customer-dialog cx-modal-container cx-asm-dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"closeModal(SWITCH_CUSTOMER_DIALOG_ACTION.CANCEL)\"\n  role=\"dialog\"\n  aria-labelledby=\"asm-switch-customer-dialog-title\"\n>\n  <div class=\"cx-modal-content\">\n    <!-- Modal Header -->\n    <div class=\"cx-dialog-header modal-header\">\n      <div>\n        <span>\n          <cx-icon type=\"WARNING\"></cx-icon>\n        </span>\n        <span id=\"asm-switch-customer-dialog-title\" class=\"title modal-title\">\n          {{ 'asm.switchCustomer.dialog.title' | cxTranslate }}\n        </span>\n      </div>\n    </div>\n\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\">\n      <div class=\"cx-dialog-row switch-customer-content\">\n        <div class=\"cx-dialog-item\">\n          {{\n            'asm.switchCustomer.dialog.body'\n              | cxTranslate\n                : {\n                    customerA: curCustomerName,\n                    customerB: switchCustomerName,\n                  }\n          }}\n        </div>\n      </div>\n    </div>\n\n    <!-- Modal Footer -->\n    <div class=\"cx-dialog-footer modal-footer\">\n      <button\n        (click)=\"closeModal(SWITCH_CUSTOMER_DIALOG_ACTION.SWITCH)\"\n        [attr.aria-label]=\"\n          'asm.switchCustomer.dialog.actions.switch' | cxTranslate\n        \"\n        class=\"btn btn-primary\"\n        type=\"button\"\n      >\n        {{ 'asm.switchCustomer.dialog.actions.switch' | cxTranslate }}\n      </button>\n\n      <button\n        (click)=\"closeModal(SWITCH_CUSTOMER_DIALOG_ACTION.CANCEL)\"\n        [attr.aria-label]=\"'common.cancel' | cxTranslate\"\n        class=\"btn btn-secondary\"\n        type=\"button\"\n      >\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmSwitchCustomerDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-asm-switch-customer-dialog', imports: [FocusDirective, IconComponent, TranslatePipe], template: "<div\n  class=\"cx-asm-switch-customer-dialog cx-modal-container cx-asm-dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"closeModal(SWITCH_CUSTOMER_DIALOG_ACTION.CANCEL)\"\n  role=\"dialog\"\n  aria-labelledby=\"asm-switch-customer-dialog-title\"\n>\n  <div class=\"cx-modal-content\">\n    <!-- Modal Header -->\n    <div class=\"cx-dialog-header modal-header\">\n      <div>\n        <span>\n          <cx-icon type=\"WARNING\"></cx-icon>\n        </span>\n        <span id=\"asm-switch-customer-dialog-title\" class=\"title modal-title\">\n          {{ 'asm.switchCustomer.dialog.title' | cxTranslate }}\n        </span>\n      </div>\n    </div>\n\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\">\n      <div class=\"cx-dialog-row switch-customer-content\">\n        <div class=\"cx-dialog-item\">\n          {{\n            'asm.switchCustomer.dialog.body'\n              | cxTranslate\n                : {\n                    customerA: curCustomerName,\n                    customerB: switchCustomerName,\n                  }\n          }}\n        </div>\n      </div>\n    </div>\n\n    <!-- Modal Footer -->\n    <div class=\"cx-dialog-footer modal-footer\">\n      <button\n        (click)=\"closeModal(SWITCH_CUSTOMER_DIALOG_ACTION.SWITCH)\"\n        [attr.aria-label]=\"\n          'asm.switchCustomer.dialog.actions.switch' | cxTranslate\n        \"\n        class=\"btn btn-primary\"\n        type=\"button\"\n      >\n        {{ 'asm.switchCustomer.dialog.actions.switch' | cxTranslate }}\n      </button>\n\n      <button\n        (click)=\"closeModal(SWITCH_CUSTOMER_DIALOG_ACTION.CANCEL)\"\n        [attr.aria-label]=\"'common.cancel' | cxTranslate\"\n        class=\"btn btn-secondary\"\n        type=\"button\"\n      >\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1.LaunchDialogService }, { type: AsmComponentService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerListComponent {
    constructor(launchDialogService, breakpointService, asmConfig, translation, asmCustomerListFacade, occConfig) {
        this.launchDialogService = launchDialogService;
        this.breakpointService = breakpointService;
        this.asmConfig = asmConfig;
        this.translation = translation;
        this.asmCustomerListFacade = asmCustomerListFacade;
        this.occConfig = occConfig;
        this.DEFAULT_PAGE_SIZE = 5;
        this.focusConfig = {
            trap: true,
            block: true,
            autofocus: 'customer-list-selector',
            focusOnEscape: true,
        };
        this.iconTypes = ICON_TYPE;
        this.BREAKPOINT = BREAKPOINT;
        this.currentPage = 0;
        this.maxPage = 0;
        this.loaded = false;
        this.listsError = false;
        this.listsEmpty = false;
        this.enableAsmB2bCustomerList = false;
        this.customerListColumnActionType = CustomerListColumnActionType;
        this.searchBox = new UntypedFormControl();
        this.forbiddenResponseStatus = HttpResponseStatus.FORBIDDEN;
        this.teardown = new Subscription();
        this.isAsmCustomer360Configured = false;
        this.featureModules = inject(FeatureModulesService);
        this.breakpoint$ = this.getBreakpoint();
    }
    ngOnInit() {
        this.isAsmCustomer360Configured =
            this.featureModules.isConfigured('asmCustomer360');
        this.pageSize =
            this.asmConfig.asm?.customerList?.pageSize ?? this.DEFAULT_PAGE_SIZE;
        this.customerListConfig = this.asmConfig?.asm?.customerList;
        this.customerListsPage$ =
            this.asmCustomerListFacade.getCustomerListsState().pipe(tap((state) => (this.listsError = !!state.error)), map((state) => {
                if (state.error &&
                    typeof state.error === 'object' &&
                    'status' in state.error &&
                    state.error.status === this.forbiddenResponseStatus) {
                    this.launchDialogService.closeDialog(CLOSE_DIALOG_REASON.FORBIDDEN);
                }
                if (state?.data?.userGroups?.length === 0) {
                    this.listsEmpty = true;
                    return undefined;
                }
                else {
                    return state.data;
                }
            }), distinctUntilChanged(), tap((result) => {
                // set the first value of this.customerListsPage$ to be selected
                if (!this.selectedUserGroupId) {
                    this.selectedUserGroupId = result?.userGroups?.[0]?.uid;
                    this.sorts = null;
                    this.fetchCustomers();
                }
            })) ?? NEVER;
        this.customerSearchLoading$ = this.asmCustomerListFacade
            .getCustomerListCustomersSearchResultsLoading()
            .pipe(tap((loading) => (this.loaded = !loading)));
        this.teardown.add(this.customerSearchLoading$.subscribe());
        this.teardown.add(() => this.asmCustomerListFacade.customerListCustomersSearchReset());
        this.customerSearchError$ =
            this.asmCustomerListFacade.getCustomerListCustomersSearchResultsError();
        this.customerSearchPage$ = this.asmCustomerListFacade
            .getCustomerListCustomersSearchResults()
            .pipe(tap((result) => {
            if (result?.sorts) {
                this.sorts = result.sorts;
                this.sortCode = result.pagination?.sort;
            }
            if (result?.entries.length < this.pageSize) {
                this.maxPage = result.pagination?.currentPage ?? 0;
            }
            else {
                this.maxPage = this.currentPage + 1;
            }
        }));
    }
    ngOnDestroy() {
        this.teardown.unsubscribe();
    }
    changePage(page) {
        const options = {
            customerListId: this.selectedUserGroupId,
            pageSize: this.pageSize,
            page: page,
            sort: this.sortCode,
        };
        if (this.searchBox?.value) {
            options.query = this.searchBox.value;
        }
        this.asmCustomerListFacade.customerListCustomersSearch(options);
    }
    fetchCustomers() {
        this.enableAsmB2bCustomerList =
            this.selectedUserGroupId === 'b2bCustomerList';
        if (this.selectedUserGroupId) {
            const options = {
                customerListId: this.selectedUserGroupId,
                pageSize: this.pageSize,
                page: this.currentPage,
            };
            if (this.sortCode) {
                options.sort = this.sortCode;
            }
            if (this.searchBox?.value) {
                options.query = this.searchBox.value;
            }
            this.asmCustomerListFacade.customerListCustomersSearchReset();
            this.asmCustomerListFacade.customerListCustomersSearch(options);
        }
        this.updateCustomerListColumns();
    }
    updateCustomerListColumns() {
        const columns = this.customerListConfig?.columns || [];
        for (const column of columns) {
            if (column.headerLocalizationKey ===
                'asm.customerList.tableHeader.account' ||
                column.headerLocalizationKey === 'hideHeaders') {
                column.headerLocalizationKey = this.enableAsmB2bCustomerList
                    ? 'asm.customerList.tableHeader.account'
                    : 'hideHeaders';
            }
            if (!this.isAsmCustomer360Configured &&
                column.headerLocalizationKey ===
                    'asm.customerList.tableHeader.customer360') {
                column.headerLocalizationKey = 'hideHeaders';
            }
        }
    }
    onChangeCustomerGroup() {
        this.currentPage = 0;
        this.sorts = null;
        this.sortCode = '';
        this.fetchCustomers();
    }
    getGroupName(customerListsPage, id) {
        return (customerListsPage?.userGroups?.find((userGroup) => userGroup.uid === id)
            ?.name ?? '');
    }
    getBadgeText(customerEntry) {
        return ((customerEntry.firstName?.charAt(0) ?? '') +
            (customerEntry.lastName?.charAt(0) ?? ''));
    }
    startColumnAction(customerEntry, action) {
        this.selectedCustomer = customerEntry;
        const closeValue = {
            actionType: action,
            selectedUser: customerEntry,
        };
        this.closeModal(closeValue);
    }
    onKey(event) {
        if (event.key === 'Enter') {
            this.searchCustomers();
        }
    }
    searchCustomers() {
        this.currentPage = 0;
        this.fetchCustomers();
    }
    isRequired(customerEntry, type) {
        if (type === CustomerListColumnActionType.ACTIVE_CART &&
            !customerEntry.lastCartId) {
            return true;
        }
        if (type === CustomerListColumnActionType.ORDER_HISTORY &&
            customerEntry.hasOrder !== true) {
            return true;
        }
        return false;
    }
    changeSortCode(sortCode) {
        this.sortCode = sortCode;
        this.fetchCustomers();
    }
    goToNextPage() {
        if (this.currentPage >= this.maxPage) {
            this.currentPage = this.maxPage;
        }
        else {
            if (this.loaded) {
                this.currentPage++;
                this.fetchCustomers();
            }
        }
    }
    goToPreviousPage() {
        if (this.currentPage <= 0) {
            this.currentPage = 0;
        }
        else {
            if (this.loaded) {
                this.currentPage--;
                this.fetchCustomers();
            }
        }
    }
    closeModal(reason) {
        this.launchDialogService.closeDialog(reason);
    }
    getSortLabels() {
        return combineLatest([
            this.translation.translate('asm.customerList.tableSort.byName'),
            this.translation.translate('asm.customerList.tableSort.byNameAsc'),
            this.translation.translate('asm.customerList.tableSort.byNameDesc'),
            this.translation.translate('asm.customerList.tableSort.byDateAsc'),
            this.translation.translate('asm.customerList.tableSort.byDateDesc'),
            this.translation.translate('asm.customerList.tableSort.byOrderDateAsc'),
            this.translation.translate('asm.customerList.tableSort.byOrderDateDesc'),
            this.translation.translate('asm.customerList.tableSort.byUnit'),
            this.translation.translate('asm.customerList.tableSort.byUnitDesc'),
        ]).pipe(map(([textByName, textByNameAsc, textByNameDesc, textByDateAsc, textByDateDesc, textByOrderDateAsc, textByOrderDateDesc, textByUnit, textByUnitDesc,]) => {
            return {
                byName: textByName,
                byNameAsc: textByNameAsc,
                byNameDesc: textByNameDesc,
                byOrderDateAsc: textByOrderDateAsc,
                byOrderDateDesc: textByOrderDateDesc,
                byDateAsc: textByDateAsc,
                byDateDesc: textByDateDesc,
                byUnit: textByUnit,
                byUnitDesc: textByUnitDesc,
            };
        }));
    }
    createCustomer() {
        this.launchDialogService.closeDialog('Create customer click');
        this.launchDialogService?.openDialogAndSubscribe(LAUNCH_CALLER.ASM_CREATE_CUSTOMER_FORM, this.addNewCustomerLink);
    }
    getBreakpoint() {
        return this.breakpointService.breakpoint$.pipe(map((breakpoint) => {
            if (breakpoint === BREAKPOINT.lg || breakpoint === BREAKPOINT.xl) {
                breakpoint = BREAKPOINT.md;
            }
            return breakpoint;
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CustomerListComponent, deps: [{ token: i1.LaunchDialogService }, { token: i1.BreakpointService }, { token: i2$1.AsmConfig }, { token: i1$1.TranslationService }, { token: i2$1.AsmCustomerListFacade }, { token: i1$1.OccConfig }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CustomerListComponent, isStandalone: true, selector: "cx-customer-list", viewQueries: [{ propertyName: "addNewCustomerLink", first: true, predicate: ["addNewCustomerLink"], descendants: true }], ngImport: i0, template: "<div\n  class=\"cx-asm-customer-list cx-modal-container cx-asm-dialog\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"closeModal('Escape clicked')\"\n  aria-labelledby=\"asm-customer-list-title\"\n>\n  <div class=\"cx-modal-content\">\n    <!-- Modal Header -->\n    <ng-container>\n      <div class=\"cx-dialog-header modal-header\">\n        <h2 id=\"asm-customer-list-title\" class=\"title modal-title\">\n          {{ 'asm.customerList.title' | cxTranslate }}\n        </h2>\n        <div id=\"asm-customer-list-desc\" class=\"cx-visually-hidden\">\n          {{ 'asm.customerList.description' | cxTranslate }}\n        </div>\n        <ng-template *ngTemplateOutlet=\"createCustomerButton\"></ng-template>\n      </div>\n      <div\n        class=\"cx-dialog-sub-header modal-header\"\n        [class.tablet-mobile]=\"(breakpoint$ | async) !== BREAKPOINT.md\"\n        *ngIf=\"customerListsPage$ | async as customerListsPage\"\n      >\n        <div\n          class=\"cx-header-select\"\n          [class.mobile]=\"(breakpoint$ | async) === BREAKPOINT.xs\"\n        >\n          <ng-template\n            *ngTemplateOutlet=\"\n              groupSelector;\n              context: { customerListsPage: customerListsPage }\n            \"\n          ></ng-template>\n          <ng-template\n            *ngTemplateOutlet=\"\n              total;\n              context: {\n                customerSearchPage: customerSearchPage$ | async,\n              }\n            \"\n          >\n          </ng-template>\n        </div>\n\n        <div\n          class=\"cx-header-actions\"\n          [class.mobile]=\"(breakpoint$ | async) === BREAKPOINT.xs\"\n        >\n          <ng-template *ngTemplateOutlet=\"sort\"></ng-template>\n          <ng-template *ngTemplateOutlet=\"search\"></ng-template>\n        </div>\n      </div>\n      <!-- Modal Body -->\n      <div class=\"cx-dialog-body modal-body\">\n        <div class=\"cx-dialog-row\">\n          <div class=\"cx-dialog-item\">\n            <div *ngIf=\"listsEmpty\" class=\"cx-error-state\">\n              {{ 'asm.customerList.noLists' | cxTranslate }}\n            </div>\n            <div *ngIf=\"listsError\" class=\"cx-error-state\">\n              {{ 'asm.customerList.listsError' | cxTranslate }}\n            </div>\n            <div *ngIf=\"customerSearchError$ | async\" class=\"cx-error-state\">\n              {{ 'generalErrors.pageFailure' | cxTranslate }}\n            </div>\n            <cx-spinner *ngIf=\"customerSearchLoading$ | async\"></cx-spinner>\n            <div *ngIf=\"customerSearchPage$ | async as customerSearchPage\">\n              <table\n                id=\"asm-cusomer-list-table\"\n                role=\"table\"\n                class=\"table\"\n                *ngIf=\"loaded\"\n              >\n                <caption class=\"cx-visually-hidden\">\n                  {{\n                    'asm.customerList.title' | cxTranslate\n                  }}\n                </caption>\n                <thead *ngIf=\"(breakpoint$ | async) === BREAKPOINT.md\">\n                  <tr role=\"row\">\n                    <th\n                      role=\"columnheader\"\n                      *ngFor=\"let column of customerListConfig?.columns\"\n                    >\n                      <span\n                        *ngIf=\"\n                          column.headerLocalizationKey &&\n                          column.headerLocalizationKey !== 'hideHeaders'\n                        \"\n                      >\n                        <ng-container\n                          *ngIf=\"\n                            column.headerLocalizationKey ===\n                            'asm.customerList.tableHeader.customer'\n                          \"\n                        >\n                          {{\n                            'asm.customerList.tableHeader.customerName'\n                              | cxTranslate\n                          }}\n                        </ng-container>\n                        <ng-container\n                          *ngIf=\"\n                            column.headerLocalizationKey ===\n                            'asm.customerList.tableHeader.email'\n                          \"\n                        >\n                          {{\n                            'asm.customerList.tableHeader.emailId' | cxTranslate\n                          }}\n                        </ng-container>\n                        <ng-container\n                          *ngIf=\"\n                            column.headerLocalizationKey !==\n                              'asm.customerList.tableHeader.customer' &&\n                            column.headerLocalizationKey !==\n                              'asm.customerList.tableHeader.email'\n                          \"\n                        >\n                          {{ column.headerLocalizationKey | cxTranslate }}\n                        </ng-container>\n                      </span>\n                    </th>\n                  </tr>\n                </thead>\n                <tbody>\n                  <tr\n                    role=\"row\"\n                    *ngFor=\"let customerEntry of customerSearchPage?.entries\"\n                  >\n                    <!-- multi columns if desktop -->\n                    <ng-container\n                      *ngIf=\"(breakpoint$ | async) === BREAKPOINT.md\"\n                    >\n                      <td\n                        role=\"cell\"\n                        *ngFor=\"let column of customerListConfig?.columns\"\n                      >\n                        <ng-template\n                          *ngTemplateOutlet=\"\n                            cell;\n                            context: {\n                              customerEntry: customerEntry,\n                              column: column,\n                              showHeader: false,\n                            }\n                          \"\n                        ></ng-template>\n                      </td>\n                    </ng-container>\n                    <!-- two column if tablet -->\n                    <ng-container\n                      *ngIf=\"(breakpoint$ | async) === BREAKPOINT.sm\"\n                    >\n                      <td role=\"cell\" class=\"cx-multi-cell\">\n                        <ng-container\n                          *ngFor=\"\n                            let column of customerListConfig?.columns;\n                            let even = even\n                          \"\n                        >\n                          <ng-container *ngIf=\"even\">\n                            <ng-template\n                              *ngTemplateOutlet=\"\n                                cell;\n                                context: {\n                                  customerEntry: customerEntry,\n                                  column: column,\n                                  showHeader: true,\n                                }\n                              \"\n                            ></ng-template>\n                          </ng-container>\n                        </ng-container>\n                      </td>\n                      <td role=\"cell\" class=\"cx-multi-cell\">\n                        <ng-container\n                          *ngFor=\"\n                            let column of customerListConfig?.columns;\n                            let odd = odd\n                          \"\n                        >\n                          <ng-container *ngIf=\"odd\">\n                            <ng-template\n                              *ngTemplateOutlet=\"\n                                cell;\n                                context: {\n                                  customerEntry: customerEntry,\n                                  column: column,\n                                  showHeader: true,\n                                }\n                              \"\n                            ></ng-template>\n                          </ng-container>\n                        </ng-container>\n                      </td>\n                    </ng-container>\n                    <!-- one column if mobile -->\n                    <td\n                      role=\"cell\"\n                      class=\"cx-multi-cell\"\n                      *ngIf=\"(breakpoint$ | async) === BREAKPOINT.xs\"\n                    >\n                      <ng-container\n                        *ngFor=\"let column of customerListConfig?.columns\"\n                      >\n                        <ng-template\n                          *ngTemplateOutlet=\"\n                            cell;\n                            context: {\n                              customerEntry: customerEntry,\n                              column: column,\n                              showHeader: true,\n                            }\n                          \"\n                        ></ng-template>\n                      </ng-container>\n                    </td>\n                  </tr>\n                </tbody>\n              </table>\n              <div\n                class=\"cx-empty-state\"\n                *ngIf=\"!customerSearchPage?.entries.length\"\n              >\n                {{ 'asm.customerList.noCustomers' | cxTranslate }}\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n      <!-- Modal Foot -->\n      <div\n        class=\"cx-dialog-sub-header modal-header cx-dialog-foot\"\n        [class.asm-mobile-pagination]=\"(breakpoint$ | async) !== BREAKPOINT.md\"\n        *ngIf=\"customerListsPage$ | async as customerListsPage\"\n      >\n        <div\n          class=\"cx-header-actions\"\n          [class.mobile]=\"(breakpoint$ | async) === BREAKPOINT.xs\"\n        >\n          <div *ngIf=\"customerSearchPage$ | async as customerSearchPage\">\n            <cx-pagination\n              [pagination]=\"customerSearchPage.pagination\"\n              (viewPageEvent)=\"changePage($event)\"\n            ></cx-pagination>\n          </div>\n        </div>\n      </div>\n      <div class=\"cx-dialog-footer modal-footer\">\n        <button\n          type=\"button\"\n          class=\"btn cx-asm-customer-list-btn-cancel\"\n          (click)=\"closeModal('Cancel click')\"\n        >\n          {{ 'asm.createCustomerForm.cancel' | cxTranslate }}\n        </button>\n      </div>\n    </ng-container>\n  </div>\n</div>\n\n<ng-template\n  #cell\n  let-customerEntry=\"customerEntry\"\n  let-column=\"column\"\n  let-showHeader=\"showHeader\"\n>\n  <div\n    class=\"cx-cell-container\"\n    *ngIf=\"column.headerLocalizationKey !== 'hideHeaders'\"\n  >\n    <span class=\"cx-header-text\" *ngIf=\"showHeader\">\n      {{ column.headerLocalizationKey | cxTranslate }}\n    </span>\n\n    <ng-container *ngIf=\"!column.actionType\">\n      <ng-container\n        *ngTemplateOutlet=\"\n          cellContent;\n          context: { column: column, customerEntry: customerEntry }\n        \"\n      ></ng-container>\n    </ng-container>\n\n    <div\n      class=\"cx-avatar\"\n      *ngIf=\"\n        customerListConfig?.showAvatar &&\n        column?.actionType === customerListColumnActionType?.START_SESSION\n      \"\n    >\n      <img\n        *ngIf=\"customerEntry?.userAvatar?.url\"\n        [attr.src]=\"\n          occConfig?.backend?.occ?.baseUrl + customerEntry?.userAvatar?.url\n        \"\n        alt=\"{{ 'asm.mainLogoLabel' | cxTranslate }}\"\n        title=\"{{ 'asm.mainLogoLabel' | cxTranslate }}\"\n      />\n      <div class=\"cx-avatar-text\" *ngIf=\"!customerEntry?.userAvatar?.url\">\n        {{ getBadgeText(customerEntry) }}\n      </div>\n    </div>\n\n    <button\n      *ngIf=\"column.actionType\"\n      (click)=\"startColumnAction(customerEntry, column.actionType)\"\n      class=\"btn btn-link cx-action-link cx-btn-cell\"\n      [class]=\"\n        (column.actionType === 'ACTIVE_CART' ? 'cx-cart ' : '') +\n        (column.actionType !== 'START_SESSION' ? 'cx-action-disable' : '')\n      \"\n      [disabled]=\"isRequired(customerEntry, column.actionType)\"\n      [attr.title]=\"\n        column.icon\n          ? (column.icon.captionLocalizationKey ?? column.headerLocalizationKey\n            | cxTranslate)\n          : undefined\n      \"\n      [attr.aria-label]=\"\n        column.icon\n          ? (column.icon.captionLocalizationKey ?? column.headerLocalizationKey\n            | cxTranslate)\n          : undefined\n      \"\n    >\n      <ng-container\n        *ngTemplateOutlet=\"\n          cellContent;\n          context: { column: column, customerEntry: customerEntry }\n        \"\n      ></ng-container>\n    </button>\n  </div>\n</ng-template>\n<ng-template #cellContent let-customerEntry=\"customerEntry\" let-column=\"column\">\n  <div>\n    <span *ngIf=\"!column.icon\">{{\n      column.renderer?.(customerEntry) || ''\n    }}</span>\n    <cx-icon\n      *ngIf=\"column.icon\"\n      [attr.title]=\"\n        !column.actionType\n          ? (column.icon.captionLocalizationKey ?? column.headerLocalizationKey\n            | cxTranslate)\n          : undefined\n      \"\n      [class.cx-action-color]=\"\n        column.actionType && !isRequired(customerEntry, column.actionType)\n      \"\n      [type]=\"column.icon.symbol\"\n      [attr.aria-label]=\"\n        !column.actionType\n          ? (column.icon.captionLocalizationKey ?? column.headerLocalizationKey\n            | cxTranslate)\n          : undefined\n      \"\n    ></cx-icon>\n  </div>\n</ng-template>\n\n<ng-template #search>\n  <div class=\"form-group search-wrapper\">\n    <input\n      [formControl]=\"searchBox\"\n      (keyup)=\"onKey($event)\"\n      type=\"text\"\n      class=\"form-control\"\n      placeholder=\"{{ 'asm.customerList.searchBox' | cxTranslate }}\"\n    />\n    <cx-icon\n      [type]=\"iconTypes.SEARCH\"\n      role=\"button\"\n      [attr.aria-label]=\"'storeFinder.searchNearestStores' | cxTranslate\"\n      [title]=\"'storeFinder.searchNearestStores' | cxTranslate\"\n      class=\"search\"\n      (click)=\"searchCustomers()\"\n    ></cx-icon>\n  </div>\n</ng-template>\n\n<ng-template #total let-customerSearchPage=\"customerSearchPage\">\n  <span class=\"cx-total\" *ngIf=\"customerSearchPage?.pagination?.totalResults\">\n    <ng-container *ngIf=\"customerSearchPage?.pagination?.totalResults > 1\">\n      {{\n        'asm.customerList.noOfCustomers'\n          | cxTranslate: { count: customerSearchPage?.pagination?.totalResults }\n      }}\n    </ng-container>\n    <ng-container *ngIf=\"customerSearchPage?.pagination?.totalResults === 1\">\n      {{ 'asm.customerList.oneCustomer' | cxTranslate }}\n    </ng-container>\n  </span>\n</ng-template>\n\n<ng-template #sort>\n  <label>\n    <span class=\"label-content\">{{\n      'asm.customerList.tableSort.sortBy' | cxTranslate\n    }}</span>\n    <cx-sorting\n      class=\"sort-selector\"\n      [sortOptions]=\"sorts\"\n      [sortLabels]=\"getSortLabels() | async\"\n      (sortListEvent)=\"changeSortCode($event)\"\n      [selectedOption]=\"sortCode\"\n      placeholder=\"{{ 'asm.customerList.tableSort.sortBy' | cxTranslate }}\"\n      [ariaLabel]=\"sortCode\"\n      ariaControls=\"asm-cusomer-list-table\"\n    ></cx-sorting>\n  </label>\n</ng-template>\n\n<ng-template #pagination>\n  <div class=\"cx-pagination-buttons\">\n    <div>\n      {{\n        'asm.customerList.page.page' | cxTranslate: { count: currentPage + 1 }\n      }}\n    </div>\n    <button\n      *ngIf=\"maxPage > 0\"\n      (click)=\"goToPreviousPage()\"\n      class=\"btn btn-link cx-action-link cx-btn-previous\"\n      [disabled]=\"currentPage === 0 || !loaded\"\n    >\n      <cx-icon class=\"previous\" [type]=\"iconTypes.CARET_LEFT\"></cx-icon\n      ><span>{{ 'asm.customerList.page.previous' | cxTranslate }}</span>\n    </button>\n    <button\n      *ngIf=\"maxPage > 0\"\n      (click)=\"goToNextPage()\"\n      class=\"btn btn-link cx-action-link cx-btn-next\"\n      [disabled]=\"currentPage === maxPage || !loaded\"\n    >\n      <span>{{ 'asm.customerList.page.next' | cxTranslate }}</span\n      ><cx-icon class=\"next\" [type]=\"iconTypes.CARET_RIGHT\"></cx-icon>\n    </button>\n  </div>\n</ng-template>\n\n<ng-template #groupSelector let-customerListsPage=\"customerListsPage\">\n  <label>\n    <span class=\"label-content\">{{\n      'asm.customerList.title' | cxTranslate\n    }}</span>\n    <ng-select\n      class=\"customer-list-selector\"\n      [searchable]=\"false\"\n      [clearable]=\"false\"\n      (change)=\"onChangeCustomerGroup()\"\n      [tabIndex]=\"0\"\n      [(ngModel)]=\"selectedUserGroupId\"\n      [items]=\"customerListsPage?.userGroups\"\n      bindLabel=\"name\"\n      bindValue=\"uid\"\n      ariaLabelDropdown=\"{{\n        'common.ngSelectDropdownOptionsList' | cxTranslate\n      }}\"\n      [cxNgSelectA11y]=\"{\n        ariaLabel: 'asm.customerList.title' | cxTranslate,\n        ariaControls: 'asm-cusomer-list-table',\n      }\"\n    >\n    </ng-select>\n  </label>\n</ng-template>\n\n<ng-template #closeButton>\n  <button\n    type=\"button\"\n    class=\"close\"\n    attr.aria-label=\"{{ 'common.close' | cxTranslate }}\"\n    (click)=\"closeModal('Cross click')\"\n    title=\"{{ 'common.close' | cxTranslate }}\"\n  >\n    <span aria-hidden=\"true\">\n      <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n    </span>\n  </button>\n</ng-template>\n\n<ng-template #createCustomerButton>\n  <button\n    *ngIf=\"asmConfig.asm?.createCustomer?.enable\"\n    type=\"button\"\n    class=\"btn cx-asm-create-customer-btn\"\n    (click)=\"createCustomer()\"\n  >\n    <cx-icon [type]=\"iconTypes.USER_PLUS\"></cx-icon>\n    <span>{{ 'asm.customerList.createCustomer' | cxTranslate }}</span>\n  </button>\n</ng-template>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: PaginationComponent, selector: "cx-pagination", inputs: ["pageRoute", "queryParam", "defaultPage", "pagination", "paginationID"], outputs: ["viewPageEvent"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "component", type: SortingComponent, selector: "cx-sorting", inputs: ["sortOptions", "ariaControls", "ariaLabel", "selectedOption", "placeholder", "sortLabels"], outputs: ["sortListEvent"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "directive", type: NgSelectA11yDirective, selector: "[cxNgSelectA11y]", inputs: ["cxNgSelectA11y"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CustomerListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-customer-list', imports: [
                        FocusDirective,
                        NgTemplateOutlet,
                        NgIf,
                        SpinnerComponent,
                        NgFor,
                        PaginationComponent,
                        IconComponent,
                        FormsModule,
                        ReactiveFormsModule,
                        SortingComponent,
                        NgSelectComponent,
                        NgSelectA11yDirective,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<div\n  class=\"cx-asm-customer-list cx-modal-container cx-asm-dialog\"\n  role=\"dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"closeModal('Escape clicked')\"\n  aria-labelledby=\"asm-customer-list-title\"\n>\n  <div class=\"cx-modal-content\">\n    <!-- Modal Header -->\n    <ng-container>\n      <div class=\"cx-dialog-header modal-header\">\n        <h2 id=\"asm-customer-list-title\" class=\"title modal-title\">\n          {{ 'asm.customerList.title' | cxTranslate }}\n        </h2>\n        <div id=\"asm-customer-list-desc\" class=\"cx-visually-hidden\">\n          {{ 'asm.customerList.description' | cxTranslate }}\n        </div>\n        <ng-template *ngTemplateOutlet=\"createCustomerButton\"></ng-template>\n      </div>\n      <div\n        class=\"cx-dialog-sub-header modal-header\"\n        [class.tablet-mobile]=\"(breakpoint$ | async) !== BREAKPOINT.md\"\n        *ngIf=\"customerListsPage$ | async as customerListsPage\"\n      >\n        <div\n          class=\"cx-header-select\"\n          [class.mobile]=\"(breakpoint$ | async) === BREAKPOINT.xs\"\n        >\n          <ng-template\n            *ngTemplateOutlet=\"\n              groupSelector;\n              context: { customerListsPage: customerListsPage }\n            \"\n          ></ng-template>\n          <ng-template\n            *ngTemplateOutlet=\"\n              total;\n              context: {\n                customerSearchPage: customerSearchPage$ | async,\n              }\n            \"\n          >\n          </ng-template>\n        </div>\n\n        <div\n          class=\"cx-header-actions\"\n          [class.mobile]=\"(breakpoint$ | async) === BREAKPOINT.xs\"\n        >\n          <ng-template *ngTemplateOutlet=\"sort\"></ng-template>\n          <ng-template *ngTemplateOutlet=\"search\"></ng-template>\n        </div>\n      </div>\n      <!-- Modal Body -->\n      <div class=\"cx-dialog-body modal-body\">\n        <div class=\"cx-dialog-row\">\n          <div class=\"cx-dialog-item\">\n            <div *ngIf=\"listsEmpty\" class=\"cx-error-state\">\n              {{ 'asm.customerList.noLists' | cxTranslate }}\n            </div>\n            <div *ngIf=\"listsError\" class=\"cx-error-state\">\n              {{ 'asm.customerList.listsError' | cxTranslate }}\n            </div>\n            <div *ngIf=\"customerSearchError$ | async\" class=\"cx-error-state\">\n              {{ 'generalErrors.pageFailure' | cxTranslate }}\n            </div>\n            <cx-spinner *ngIf=\"customerSearchLoading$ | async\"></cx-spinner>\n            <div *ngIf=\"customerSearchPage$ | async as customerSearchPage\">\n              <table\n                id=\"asm-cusomer-list-table\"\n                role=\"table\"\n                class=\"table\"\n                *ngIf=\"loaded\"\n              >\n                <caption class=\"cx-visually-hidden\">\n                  {{\n                    'asm.customerList.title' | cxTranslate\n                  }}\n                </caption>\n                <thead *ngIf=\"(breakpoint$ | async) === BREAKPOINT.md\">\n                  <tr role=\"row\">\n                    <th\n                      role=\"columnheader\"\n                      *ngFor=\"let column of customerListConfig?.columns\"\n                    >\n                      <span\n                        *ngIf=\"\n                          column.headerLocalizationKey &&\n                          column.headerLocalizationKey !== 'hideHeaders'\n                        \"\n                      >\n                        <ng-container\n                          *ngIf=\"\n                            column.headerLocalizationKey ===\n                            'asm.customerList.tableHeader.customer'\n                          \"\n                        >\n                          {{\n                            'asm.customerList.tableHeader.customerName'\n                              | cxTranslate\n                          }}\n                        </ng-container>\n                        <ng-container\n                          *ngIf=\"\n                            column.headerLocalizationKey ===\n                            'asm.customerList.tableHeader.email'\n                          \"\n                        >\n                          {{\n                            'asm.customerList.tableHeader.emailId' | cxTranslate\n                          }}\n                        </ng-container>\n                        <ng-container\n                          *ngIf=\"\n                            column.headerLocalizationKey !==\n                              'asm.customerList.tableHeader.customer' &&\n                            column.headerLocalizationKey !==\n                              'asm.customerList.tableHeader.email'\n                          \"\n                        >\n                          {{ column.headerLocalizationKey | cxTranslate }}\n                        </ng-container>\n                      </span>\n                    </th>\n                  </tr>\n                </thead>\n                <tbody>\n                  <tr\n                    role=\"row\"\n                    *ngFor=\"let customerEntry of customerSearchPage?.entries\"\n                  >\n                    <!-- multi columns if desktop -->\n                    <ng-container\n                      *ngIf=\"(breakpoint$ | async) === BREAKPOINT.md\"\n                    >\n                      <td\n                        role=\"cell\"\n                        *ngFor=\"let column of customerListConfig?.columns\"\n                      >\n                        <ng-template\n                          *ngTemplateOutlet=\"\n                            cell;\n                            context: {\n                              customerEntry: customerEntry,\n                              column: column,\n                              showHeader: false,\n                            }\n                          \"\n                        ></ng-template>\n                      </td>\n                    </ng-container>\n                    <!-- two column if tablet -->\n                    <ng-container\n                      *ngIf=\"(breakpoint$ | async) === BREAKPOINT.sm\"\n                    >\n                      <td role=\"cell\" class=\"cx-multi-cell\">\n                        <ng-container\n                          *ngFor=\"\n                            let column of customerListConfig?.columns;\n                            let even = even\n                          \"\n                        >\n                          <ng-container *ngIf=\"even\">\n                            <ng-template\n                              *ngTemplateOutlet=\"\n                                cell;\n                                context: {\n                                  customerEntry: customerEntry,\n                                  column: column,\n                                  showHeader: true,\n                                }\n                              \"\n                            ></ng-template>\n                          </ng-container>\n                        </ng-container>\n                      </td>\n                      <td role=\"cell\" class=\"cx-multi-cell\">\n                        <ng-container\n                          *ngFor=\"\n                            let column of customerListConfig?.columns;\n                            let odd = odd\n                          \"\n                        >\n                          <ng-container *ngIf=\"odd\">\n                            <ng-template\n                              *ngTemplateOutlet=\"\n                                cell;\n                                context: {\n                                  customerEntry: customerEntry,\n                                  column: column,\n                                  showHeader: true,\n                                }\n                              \"\n                            ></ng-template>\n                          </ng-container>\n                        </ng-container>\n                      </td>\n                    </ng-container>\n                    <!-- one column if mobile -->\n                    <td\n                      role=\"cell\"\n                      class=\"cx-multi-cell\"\n                      *ngIf=\"(breakpoint$ | async) === BREAKPOINT.xs\"\n                    >\n                      <ng-container\n                        *ngFor=\"let column of customerListConfig?.columns\"\n                      >\n                        <ng-template\n                          *ngTemplateOutlet=\"\n                            cell;\n                            context: {\n                              customerEntry: customerEntry,\n                              column: column,\n                              showHeader: true,\n                            }\n                          \"\n                        ></ng-template>\n                      </ng-container>\n                    </td>\n                  </tr>\n                </tbody>\n              </table>\n              <div\n                class=\"cx-empty-state\"\n                *ngIf=\"!customerSearchPage?.entries.length\"\n              >\n                {{ 'asm.customerList.noCustomers' | cxTranslate }}\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n      <!-- Modal Foot -->\n      <div\n        class=\"cx-dialog-sub-header modal-header cx-dialog-foot\"\n        [class.asm-mobile-pagination]=\"(breakpoint$ | async) !== BREAKPOINT.md\"\n        *ngIf=\"customerListsPage$ | async as customerListsPage\"\n      >\n        <div\n          class=\"cx-header-actions\"\n          [class.mobile]=\"(breakpoint$ | async) === BREAKPOINT.xs\"\n        >\n          <div *ngIf=\"customerSearchPage$ | async as customerSearchPage\">\n            <cx-pagination\n              [pagination]=\"customerSearchPage.pagination\"\n              (viewPageEvent)=\"changePage($event)\"\n            ></cx-pagination>\n          </div>\n        </div>\n      </div>\n      <div class=\"cx-dialog-footer modal-footer\">\n        <button\n          type=\"button\"\n          class=\"btn cx-asm-customer-list-btn-cancel\"\n          (click)=\"closeModal('Cancel click')\"\n        >\n          {{ 'asm.createCustomerForm.cancel' | cxTranslate }}\n        </button>\n      </div>\n    </ng-container>\n  </div>\n</div>\n\n<ng-template\n  #cell\n  let-customerEntry=\"customerEntry\"\n  let-column=\"column\"\n  let-showHeader=\"showHeader\"\n>\n  <div\n    class=\"cx-cell-container\"\n    *ngIf=\"column.headerLocalizationKey !== 'hideHeaders'\"\n  >\n    <span class=\"cx-header-text\" *ngIf=\"showHeader\">\n      {{ column.headerLocalizationKey | cxTranslate }}\n    </span>\n\n    <ng-container *ngIf=\"!column.actionType\">\n      <ng-container\n        *ngTemplateOutlet=\"\n          cellContent;\n          context: { column: column, customerEntry: customerEntry }\n        \"\n      ></ng-container>\n    </ng-container>\n\n    <div\n      class=\"cx-avatar\"\n      *ngIf=\"\n        customerListConfig?.showAvatar &&\n        column?.actionType === customerListColumnActionType?.START_SESSION\n      \"\n    >\n      <img\n        *ngIf=\"customerEntry?.userAvatar?.url\"\n        [attr.src]=\"\n          occConfig?.backend?.occ?.baseUrl + customerEntry?.userAvatar?.url\n        \"\n        alt=\"{{ 'asm.mainLogoLabel' | cxTranslate }}\"\n        title=\"{{ 'asm.mainLogoLabel' | cxTranslate }}\"\n      />\n      <div class=\"cx-avatar-text\" *ngIf=\"!customerEntry?.userAvatar?.url\">\n        {{ getBadgeText(customerEntry) }}\n      </div>\n    </div>\n\n    <button\n      *ngIf=\"column.actionType\"\n      (click)=\"startColumnAction(customerEntry, column.actionType)\"\n      class=\"btn btn-link cx-action-link cx-btn-cell\"\n      [class]=\"\n        (column.actionType === 'ACTIVE_CART' ? 'cx-cart ' : '') +\n        (column.actionType !== 'START_SESSION' ? 'cx-action-disable' : '')\n      \"\n      [disabled]=\"isRequired(customerEntry, column.actionType)\"\n      [attr.title]=\"\n        column.icon\n          ? (column.icon.captionLocalizationKey ?? column.headerLocalizationKey\n            | cxTranslate)\n          : undefined\n      \"\n      [attr.aria-label]=\"\n        column.icon\n          ? (column.icon.captionLocalizationKey ?? column.headerLocalizationKey\n            | cxTranslate)\n          : undefined\n      \"\n    >\n      <ng-container\n        *ngTemplateOutlet=\"\n          cellContent;\n          context: { column: column, customerEntry: customerEntry }\n        \"\n      ></ng-container>\n    </button>\n  </div>\n</ng-template>\n<ng-template #cellContent let-customerEntry=\"customerEntry\" let-column=\"column\">\n  <div>\n    <span *ngIf=\"!column.icon\">{{\n      column.renderer?.(customerEntry) || ''\n    }}</span>\n    <cx-icon\n      *ngIf=\"column.icon\"\n      [attr.title]=\"\n        !column.actionType\n          ? (column.icon.captionLocalizationKey ?? column.headerLocalizationKey\n            | cxTranslate)\n          : undefined\n      \"\n      [class.cx-action-color]=\"\n        column.actionType && !isRequired(customerEntry, column.actionType)\n      \"\n      [type]=\"column.icon.symbol\"\n      [attr.aria-label]=\"\n        !column.actionType\n          ? (column.icon.captionLocalizationKey ?? column.headerLocalizationKey\n            | cxTranslate)\n          : undefined\n      \"\n    ></cx-icon>\n  </div>\n</ng-template>\n\n<ng-template #search>\n  <div class=\"form-group search-wrapper\">\n    <input\n      [formControl]=\"searchBox\"\n      (keyup)=\"onKey($event)\"\n      type=\"text\"\n      class=\"form-control\"\n      placeholder=\"{{ 'asm.customerList.searchBox' | cxTranslate }}\"\n    />\n    <cx-icon\n      [type]=\"iconTypes.SEARCH\"\n      role=\"button\"\n      [attr.aria-label]=\"'storeFinder.searchNearestStores' | cxTranslate\"\n      [title]=\"'storeFinder.searchNearestStores' | cxTranslate\"\n      class=\"search\"\n      (click)=\"searchCustomers()\"\n    ></cx-icon>\n  </div>\n</ng-template>\n\n<ng-template #total let-customerSearchPage=\"customerSearchPage\">\n  <span class=\"cx-total\" *ngIf=\"customerSearchPage?.pagination?.totalResults\">\n    <ng-container *ngIf=\"customerSearchPage?.pagination?.totalResults > 1\">\n      {{\n        'asm.customerList.noOfCustomers'\n          | cxTranslate: { count: customerSearchPage?.pagination?.totalResults }\n      }}\n    </ng-container>\n    <ng-container *ngIf=\"customerSearchPage?.pagination?.totalResults === 1\">\n      {{ 'asm.customerList.oneCustomer' | cxTranslate }}\n    </ng-container>\n  </span>\n</ng-template>\n\n<ng-template #sort>\n  <label>\n    <span class=\"label-content\">{{\n      'asm.customerList.tableSort.sortBy' | cxTranslate\n    }}</span>\n    <cx-sorting\n      class=\"sort-selector\"\n      [sortOptions]=\"sorts\"\n      [sortLabels]=\"getSortLabels() | async\"\n      (sortListEvent)=\"changeSortCode($event)\"\n      [selectedOption]=\"sortCode\"\n      placeholder=\"{{ 'asm.customerList.tableSort.sortBy' | cxTranslate }}\"\n      [ariaLabel]=\"sortCode\"\n      ariaControls=\"asm-cusomer-list-table\"\n    ></cx-sorting>\n  </label>\n</ng-template>\n\n<ng-template #pagination>\n  <div class=\"cx-pagination-buttons\">\n    <div>\n      {{\n        'asm.customerList.page.page' | cxTranslate: { count: currentPage + 1 }\n      }}\n    </div>\n    <button\n      *ngIf=\"maxPage > 0\"\n      (click)=\"goToPreviousPage()\"\n      class=\"btn btn-link cx-action-link cx-btn-previous\"\n      [disabled]=\"currentPage === 0 || !loaded\"\n    >\n      <cx-icon class=\"previous\" [type]=\"iconTypes.CARET_LEFT\"></cx-icon\n      ><span>{{ 'asm.customerList.page.previous' | cxTranslate }}</span>\n    </button>\n    <button\n      *ngIf=\"maxPage > 0\"\n      (click)=\"goToNextPage()\"\n      class=\"btn btn-link cx-action-link cx-btn-next\"\n      [disabled]=\"currentPage === maxPage || !loaded\"\n    >\n      <span>{{ 'asm.customerList.page.next' | cxTranslate }}</span\n      ><cx-icon class=\"next\" [type]=\"iconTypes.CARET_RIGHT\"></cx-icon>\n    </button>\n  </div>\n</ng-template>\n\n<ng-template #groupSelector let-customerListsPage=\"customerListsPage\">\n  <label>\n    <span class=\"label-content\">{{\n      'asm.customerList.title' | cxTranslate\n    }}</span>\n    <ng-select\n      class=\"customer-list-selector\"\n      [searchable]=\"false\"\n      [clearable]=\"false\"\n      (change)=\"onChangeCustomerGroup()\"\n      [tabIndex]=\"0\"\n      [(ngModel)]=\"selectedUserGroupId\"\n      [items]=\"customerListsPage?.userGroups\"\n      bindLabel=\"name\"\n      bindValue=\"uid\"\n      ariaLabelDropdown=\"{{\n        'common.ngSelectDropdownOptionsList' | cxTranslate\n      }}\"\n      [cxNgSelectA11y]=\"{\n        ariaLabel: 'asm.customerList.title' | cxTranslate,\n        ariaControls: 'asm-cusomer-list-table',\n      }\"\n    >\n    </ng-select>\n  </label>\n</ng-template>\n\n<ng-template #closeButton>\n  <button\n    type=\"button\"\n    class=\"close\"\n    attr.aria-label=\"{{ 'common.close' | cxTranslate }}\"\n    (click)=\"closeModal('Cross click')\"\n    title=\"{{ 'common.close' | cxTranslate }}\"\n  >\n    <span aria-hidden=\"true\">\n      <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n    </span>\n  </button>\n</ng-template>\n\n<ng-template #createCustomerButton>\n  <button\n    *ngIf=\"asmConfig.asm?.createCustomer?.enable\"\n    type=\"button\"\n    class=\"btn cx-asm-create-customer-btn\"\n    (click)=\"createCustomer()\"\n  >\n    <cx-icon [type]=\"iconTypes.USER_PLUS\"></cx-icon>\n    <span>{{ 'asm.customerList.createCustomer' | cxTranslate }}</span>\n  </button>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1.LaunchDialogService }, { type: i1.BreakpointService }, { type: i2$1.AsmConfig }, { type: i1$1.TranslationService }, { type: i2$1.AsmCustomerListFacade }, { type: i1$1.OccConfig }], propDecorators: { addNewCustomerLink: [{
                type: ViewChild,
                args: ['addNewCustomerLink']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultCustomerListLayoutConfig = {
    launch: {
        ASM_CUSTOMER_LIST: {
            inlineRoot: true,
            component: CustomerListComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultAsmLayoutConfig = {
    launch: {
        ASM: {
            outlet: 'cx-storefront',
            component: AsmMainUiComponent,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultAsmPaginationConfig = {
    pagination: {
        rangeCount: 2,
        addPrevious: true,
        addNext: true,
        addStart: false,
        addEnd: false,
        addFirst: true,
        addLast: true,
        addDots: true,
        substituteDotsForSingularPage: true,
        dotsLabel: '···',
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultBindCartLayoutConfig = {
    launch: {
        [LAUNCH_CALLER.ASM_BIND_CART]: {
            inlineRoot: true,
            component: AsmBindCartDialogComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultSaveCartLayoutConfig = {
    launch: {
        [LAUNCH_CALLER.ASM_SAVE_CART]: {
            inlineRoot: true,
            component: AsmSaveCartDialogComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultSwitchCustomerLayoutConfig = {
    launch: {
        [LAUNCH_CALLER.ASM_SWITCH_CUSTOMER]: {
            inlineRoot: true,
            component: AsmSwitchCustomerDialogComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AsmComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: AsmComponentsModule, imports: [CommonModule,
            ReactiveFormsModule,
            I18nModule,
            FormErrorsModule,
            IconModule,
            NgSelectModule,
            FormsModule,
            SpinnerModule,
            PasswordVisibilityToggleModule,
            KeyboardFocusModule,
            NgSelectA11yModule,
            SortingModule,
            PaginationModule,
            MessageComponentModule,
            FeaturesConfigModule,
            AsmBindCartDialogComponent,
            AsmSaveCartDialogComponent,
            AsmMainUiComponent,
            CSAgentLoginFormComponent,
            CustomerListComponent,
            CustomerSelectionComponent,
            AsmSessionTimerComponent,
            FormatTimerPipe,
            CustomerEmulationComponent,
            AsmToggleUiComponent,
            AsmBindCartComponent,
            AsmSwitchCustomerDialogComponent,
            DotSpinnerComponent,
            AsmCreateCustomerFormComponent], exports: [AsmBindCartDialogComponent,
            AsmSaveCartDialogComponent,
            AsmMainUiComponent,
            CSAgentLoginFormComponent,
            CustomerListComponent,
            CustomerSelectionComponent,
            AsmSessionTimerComponent,
            FormatTimerPipe,
            CustomerEmulationComponent,
            AsmToggleUiComponent,
            AsmBindCartComponent,
            AsmSwitchCustomerDialogComponent,
            DotSpinnerComponent,
            AsmCreateCustomerFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmComponentsModule, providers: [
            provideDefaultConfig(defaultAsmLayoutConfig),
            provideDefaultConfig(defaultBindCartLayoutConfig),
            provideDefaultConfig(defaultSaveCartLayoutConfig),
            provideDefaultConfig(defaultSwitchCustomerLayoutConfig),
            provideDefaultConfig(defaultCustomerListLayoutConfig),
            provideDefaultConfig(defaultAsmPaginationConfig),
            provideDefaultConfig(defaultAsmCreateCustomerFormLayoutConfig),
        ], imports: [CommonModule,
            ReactiveFormsModule,
            I18nModule,
            FormErrorsModule,
            IconModule,
            NgSelectModule,
            FormsModule,
            SpinnerModule,
            PasswordVisibilityToggleModule,
            KeyboardFocusModule,
            NgSelectA11yModule,
            SortingModule,
            PaginationModule,
            MessageComponentModule,
            FeaturesConfigModule,
            AsmSaveCartDialogComponent,
            AsmMainUiComponent,
            CSAgentLoginFormComponent,
            CustomerListComponent,
            CustomerSelectionComponent,
            CustomerEmulationComponent,
            AsmBindCartComponent,
            AsmSwitchCustomerDialogComponent,
            AsmCreateCustomerFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: AsmComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        I18nModule,
                        FormErrorsModule,
                        IconModule,
                        NgSelectModule,
                        FormsModule,
                        SpinnerModule,
                        PasswordVisibilityToggleModule,
                        KeyboardFocusModule,
                        NgSelectA11yModule,
                        SortingModule,
                        PaginationModule,
                        MessageComponentModule,
                        FeaturesConfigModule,
                        AsmBindCartDialogComponent,
                        AsmSaveCartDialogComponent,
                        AsmMainUiComponent,
                        CSAgentLoginFormComponent,
                        CustomerListComponent,
                        CustomerSelectionComponent,
                        AsmSessionTimerComponent,
                        FormatTimerPipe,
                        CustomerEmulationComponent,
                        AsmToggleUiComponent,
                        AsmBindCartComponent,
                        AsmSwitchCustomerDialogComponent,
                        DotSpinnerComponent,
                        AsmCreateCustomerFormComponent,
                    ],
                    exports: [
                        AsmBindCartDialogComponent,
                        AsmSaveCartDialogComponent,
                        AsmMainUiComponent,
                        CSAgentLoginFormComponent,
                        CustomerListComponent,
                        CustomerSelectionComponent,
                        AsmSessionTimerComponent,
                        FormatTimerPipe,
                        CustomerEmulationComponent,
                        AsmToggleUiComponent,
                        AsmBindCartComponent,
                        AsmSwitchCustomerDialogComponent,
                        DotSpinnerComponent,
                        AsmCreateCustomerFormComponent,
                    ],
                    providers: [
                        provideDefaultConfig(defaultAsmLayoutConfig),
                        provideDefaultConfig(defaultBindCartLayoutConfig),
                        provideDefaultConfig(defaultSaveCartLayoutConfig),
                        provideDefaultConfig(defaultSwitchCustomerLayoutConfig),
                        provideDefaultConfig(defaultCustomerListLayoutConfig),
                        provideDefaultConfig(defaultAsmPaginationConfig),
                        provideDefaultConfig(defaultAsmCreateCustomerFormLayoutConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AsmBindCartComponent, AsmBindCartDialogComponent, AsmComponentService, AsmComponentsModule, AsmCreateCustomerFormComponent, AsmMainUiComponent, AsmSaveCartDialogComponent, AsmSessionTimerComponent, AsmSwitchCustomerDialogComponent, AsmToggleUiComponent, BIND_CART_DIALOG_ACTION, CART_TYPE_KEY, CSAgentLoginFormComponent, CustomerEmulationComponent, CustomerListComponent, CustomerSelectionComponent, DotSpinnerComponent, FormatTimerPipe, SAVE_CART_DIALOG_ACTION, SWITCH_CUSTOMER_DIALOG_ACTION };
//# sourceMappingURL=spartacus-asm-components.mjs.map
