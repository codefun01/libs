import * as i0 from '@angular/core';
import { Injectable, Optional, Inject, Component, Input, NgModule } from '@angular/core';
import * as i3 from '@spartacus/storefront';
import { OutletContextData, IconModule, provideOutlet, OutletPosition } from '@spartacus/storefront';
import * as i2 from '@spartacus/cart/base/root';
import { CartItemContext, CartOutlets } from '@spartacus/cart/base/root';
import { NgIf, NgFor, NgClass, DecimalPipe, CommonModule } from '@angular/common';
import { BehaviorSubject, Subscription } from 'rxjs';
import * as i1 from '@spartacus/core';
import { TranslatePipe, UrlModule, I18nModule } from '@spartacus/core';
import { CartItemListComponentService } from '@spartacus/cart/base/components';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CpqQuoteService {
    constructor() {
        this.isFlagSubject = new BehaviorSubject(true); // Default value is true
        this.isFlag$ = this.isFlagSubject.asObservable();
    }
    setFlag(value) {
        this.isFlagSubject.next(value);
    }
    getFlag$() {
        return this.isFlagSubject.getValue();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqQuoteService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqQuoteService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqQuoteService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CpqQuoteDiscountComponent {
    constructor(cartItemContext, cpqQuoteService) {
        this.cartItemContext = cartItemContext;
        this.cpqQuoteService = cpqQuoteService;
        this.orderEntry$ = this.cartItemContext?.item$;
        this.isFlagQuote = true;
        this.subscription = this.cpqQuoteService.isFlag$.subscribe((isFlag) => {
            this.isFlagQuote = isFlag;
        });
    }
    ngOnInit() {
        if (this.cartItemContext) {
            this.subscription = this.orderEntry$.subscribe((data) => {
                this.quoteDiscountData = data;
            });
        }
        else {
            this.quoteDiscountData = null;
        }
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    getDiscountedPrice(basePrice, appliedDiscount, quantity) {
        if (basePrice > 0 &&
            appliedDiscount !== undefined &&
            quantity !== undefined &&
            quantity > 0) {
            const totalBasePrice = basePrice * quantity;
            const discountedPrice = totalBasePrice - appliedDiscount;
            return discountedPrice / quantity;
        }
        return undefined;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqQuoteDiscountComponent, deps: [{ token: CartItemContext, optional: true }, { token: CpqQuoteService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CpqQuoteDiscountComponent, isStandalone: true, selector: "cx-cpq-quote", ngImport: i0, template: "<td class=\"cx-center\" *ngIf=\"!isFlagQuote\">\n  <ng-container\n    *ngIf=\"\n      quoteDiscountData &&\n      quoteDiscountData.basePrice?.value !== undefined &&\n      quoteDiscountData.cpqDiscounts &&\n      quoteDiscountData.cpqDiscounts.length > 0\n    \"\n  >\n    <ng-container *ngFor=\"let discount of quoteDiscountData.cpqDiscounts\">\n      <span role=\"cell\" class=\"cx-total cx-discount\">\n        {{ discount.isoCode\n        }}{{\n          getDiscountedPrice(\n            quoteDiscountData.basePrice?.value ?? 0,\n            discount.appliedValue,\n            quoteDiscountData.quantity\n          ) | number: '1.2-2' : 'en-US'\n        }}\n      </span>\n    </ng-container>\n  </ng-container>\n  <!-- Iterate over quoteDiscountData.basePrice -->\n  <span\n    class=\"cx-formatted-value\"\n    [ngClass]=\"{\n      'strike-through':\n        quoteDiscountData &&\n        quoteDiscountData.cpqDiscounts &&\n        quoteDiscountData.cpqDiscounts.length > 0,\n    }\"\n  >\n    {{ quoteDiscountData?.basePrice?.formattedValue }}\n  </span>\n</td>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "pipe", type: DecimalPipe, name: "number" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqQuoteDiscountComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-cpq-quote', imports: [NgIf, NgFor, NgClass, DecimalPipe], template: "<td class=\"cx-center\" *ngIf=\"!isFlagQuote\">\n  <ng-container\n    *ngIf=\"\n      quoteDiscountData &&\n      quoteDiscountData.basePrice?.value !== undefined &&\n      quoteDiscountData.cpqDiscounts &&\n      quoteDiscountData.cpqDiscounts.length > 0\n    \"\n  >\n    <ng-container *ngFor=\"let discount of quoteDiscountData.cpqDiscounts\">\n      <span role=\"cell\" class=\"cx-total cx-discount\">\n        {{ discount.isoCode\n        }}{{\n          getDiscountedPrice(\n            quoteDiscountData.basePrice?.value ?? 0,\n            discount.appliedValue,\n            quoteDiscountData.quantity\n          ) | number: '1.2-2' : 'en-US'\n        }}\n      </span>\n    </ng-container>\n  </ng-container>\n  <!-- Iterate over quoteDiscountData.basePrice -->\n  <span\n    class=\"cx-formatted-value\"\n    [ngClass]=\"{\n      'strike-through':\n        quoteDiscountData &&\n        quoteDiscountData.cpqDiscounts &&\n        quoteDiscountData.cpqDiscounts.length > 0,\n    }\"\n  >\n    {{ quoteDiscountData?.basePrice?.formattedValue }}\n  </span>\n</td>\n" }]
        }], ctorParameters: () => [{ type: i2.CartItemContext, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CartItemContext]
                }] }, { type: CpqQuoteService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CpqQuoteHeadingComponent {
    constructor(
    // Inject OutletContextData dependency
    outlet, translationService, cpqQuoteService) {
        this.outlet = outlet;
        this.translationService = translationService;
        this.cpqQuoteService = cpqQuoteService;
        this.subscription = new Subscription();
        // discountLabel: string = 'Discount Percentage';
        this.dataAvailable = false;
    }
    ngOnInit() {
        this.subscription.add(this.translationService
            .translate('cpqQuoteHeading')
            .subscribe((translation) => {
            this.discountLabel = translation;
        }));
        if (this.outlet?.context$) {
            this.subscription.add(this.outlet.context$.subscribe((context) => {
                this.datacheck = context;
                const hasDiscounts = this.datacheck.some((item) => item.cpqDiscounts && item.cpqDiscounts.length > 0);
                // Set flag based on the existence of cpqDiscounts in any item
                this.cpqQuoteService.setFlag(!hasDiscounts);
                if (context && context.length > 0) {
                    this.dataAvailable = context.some((item) => item.cpqDiscounts && item.cpqDiscounts.length > 0);
                }
                else {
                    this.dataAvailable = false;
                }
            }));
        }
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqQuoteHeadingComponent, deps: [{ token: OutletContextData, optional: true }, { token: i1.TranslationService }, { token: CpqQuoteService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CpqQuoteHeadingComponent, isStandalone: true, selector: "cx-cpq-quote-heading", inputs: { quoteDiscountData: "quoteDiscountData" }, ngImport: i0, template: "<ng-container *ngIf=\"dataAvailable\">\n  <th role=\"columnheader\" class=\"cx-item-list-discount\">\n    {{ discountLabel }}\n  </th></ng-container\n>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqQuoteHeadingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-cpq-quote-heading', imports: [NgIf], template: "<ng-container *ngIf=\"dataAvailable\">\n  <th role=\"columnheader\" class=\"cx-item-list-discount\">\n    {{ discountLabel }}\n  </th></ng-container\n>\n" }]
        }], ctorParameters: () => [{ type: i3.OutletContextData, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [OutletContextData]
                }] }, { type: i1.TranslationService }, { type: CpqQuoteService }], propDecorators: { quoteDiscountData: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CpqQuoteOfferComponent {
    constructor(cartItemContext) {
        this.cartItemContext = cartItemContext;
        this.orderEntry$ = this.cartItemContext?.item$;
    }
    ngOnInit() {
        if (this.cartItemContext) {
            this.subscription = this.orderEntry$.subscribe((data) => {
                this.quoteDiscountData = data;
            });
        }
        else {
            this.quoteDiscountData = null;
        }
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    getDiscountPercentage(basePrice, appliedDiscount, quantity) {
        if (basePrice > 0 &&
            appliedDiscount !== undefined &&
            quantity !== undefined &&
            quantity > 0) {
            const totalBasePrice = basePrice * quantity;
            return (appliedDiscount / totalBasePrice) * 100;
        }
        return undefined;
    }
    formatDiscount(value) {
        if (value === undefined) {
            return '';
        }
        return Number.isInteger(value) ? value.toFixed(0) : value.toFixed(2);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqQuoteOfferComponent, deps: [{ token: CartItemContext, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CpqQuoteOfferComponent, isStandalone: true, selector: "cx-cpq-quote-offer", ngImport: i0, template: "<ng-container\n  *ngIf=\"\n    quoteDiscountData &&\n    quoteDiscountData.basePrice?.value !== undefined &&\n    quoteDiscountData.cpqDiscounts &&\n    quoteDiscountData.cpqDiscounts.length > 0\n  \"\n  class=\"cx-cpq-quote-discount\"\n>\n  <ng-container *ngFor=\"let discount of quoteDiscountData.cpqDiscounts\">\n    <div class=\"cx-offer\">\n      {{\n        'discountCaption'\n          | cxTranslate\n            : {\n                discount: formatDiscount(\n                  getDiscountPercentage(\n                    quoteDiscountData.basePrice?.value ?? 0,\n                    discount.appliedValue,\n                    quoteDiscountData.quantity\n                  )\n                ),\n              }\n      }}\n    </div>\n  </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqQuoteOfferComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-cpq-quote-offer', imports: [NgIf, NgFor, TranslatePipe], template: "<ng-container\n  *ngIf=\"\n    quoteDiscountData &&\n    quoteDiscountData.basePrice?.value !== undefined &&\n    quoteDiscountData.cpqDiscounts &&\n    quoteDiscountData.cpqDiscounts.length > 0\n  \"\n  class=\"cx-cpq-quote-discount\"\n>\n  <ng-container *ngFor=\"let discount of quoteDiscountData.cpqDiscounts\">\n    <div class=\"cx-offer\">\n      {{\n        'discountCaption'\n          | cxTranslate\n            : {\n                discount: formatDiscount(\n                  getDiscountPercentage(\n                    quoteDiscountData.basePrice?.value ?? 0,\n                    discount.appliedValue,\n                    quoteDiscountData.quantity\n                  )\n                ),\n              }\n      }}\n    </div>\n  </ng-container>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: i2.CartItemContext, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [CartItemContext]
                }] }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
// cpq-quote-status.service.ts
class CpqQuoteSharedService extends CartItemListComponentService {
    constructor(flagService) {
        super();
        this.flagService = flagService;
    }
    showBasePriceWithDiscount() {
        return this.flagService.getFlag$();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqQuoteSharedService, deps: [{ token: CpqQuoteService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqQuoteSharedService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqQuoteSharedService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: CpqQuoteService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CpqDiscountModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqDiscountModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CpqDiscountModule, imports: [CommonModule,
            UrlModule,
            I18nModule,
            IconModule,
            CpqQuoteHeadingComponent,
            CpqQuoteDiscountComponent,
            CpqQuoteOfferComponent], exports: [CpqQuoteHeadingComponent,
            CpqQuoteDiscountComponent,
            CpqQuoteOfferComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqDiscountModule, providers: [
            CpqQuoteService,
            { provide: CartItemListComponentService, useClass: CpqQuoteSharedService },
            provideOutlet({
                id: CartOutlets.CPQ_QUOTE_MODULE,
                position: OutletPosition.AFTER,
                component: CpqQuoteDiscountComponent,
            }),
            provideOutlet({
                id: CartOutlets.CPQ_QUOTE_HEADING,
                position: OutletPosition.AFTER,
                component: CpqQuoteHeadingComponent,
            }),
            provideOutlet({
                id: CartOutlets.CPQ_QUOTE,
                position: OutletPosition.AFTER,
                component: CpqQuoteOfferComponent,
            }),
        ], imports: [CommonModule,
            UrlModule,
            I18nModule,
            IconModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqDiscountModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        UrlModule,
                        I18nModule,
                        IconModule,
                        CpqQuoteHeadingComponent,
                        CpqQuoteDiscountComponent,
                        CpqQuoteOfferComponent,
                    ],
                    exports: [
                        CpqQuoteHeadingComponent,
                        CpqQuoteDiscountComponent,
                        CpqQuoteOfferComponent,
                    ],
                    providers: [
                        CpqQuoteService,
                        { provide: CartItemListComponentService, useClass: CpqQuoteSharedService },
                        provideOutlet({
                            id: CartOutlets.CPQ_QUOTE_MODULE,
                            position: OutletPosition.AFTER,
                            component: CpqQuoteDiscountComponent,
                        }),
                        provideOutlet({
                            id: CartOutlets.CPQ_QUOTE_HEADING,
                            position: OutletPosition.AFTER,
                            component: CpqQuoteHeadingComponent,
                        }),
                        provideOutlet({
                            id: CartOutlets.CPQ_QUOTE,
                            position: OutletPosition.AFTER,
                            component: CpqQuoteOfferComponent,
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CpqQuoteModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqQuoteModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CpqQuoteModule, imports: [CpqDiscountModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqQuoteModule, imports: [CpqDiscountModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CpqQuoteModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CpqDiscountModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/*
 * Public API Surface of estimated-delivery-date
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CpqDiscountModule, CpqQuoteDiscountComponent, CpqQuoteHeadingComponent, CpqQuoteModule, CpqQuoteOfferComponent, CpqQuoteService, CpqQuoteSharedService };
//# sourceMappingURL=spartacus-cpq-quote.mjs.map
