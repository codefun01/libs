var cpqQuoteHeading$g = "Cena položky";
var discountCaption$g = "Tato položka má slevu {{ discount }} %";
var cpqQuote$g = {
	cpqQuoteHeading: cpqQuoteHeading$g,
	discountCaption: discountCaption$g
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const cs = {
    cpqQuote: cpqQuote$g,
};

var cpqQuoteHeading$f = "Positionspreis";
var discountCaption$f = "Für diese Position gibt es einen Rabatt von {{ discount }} %";
var cpqQuote$f = {
	cpqQuoteHeading: cpqQuoteHeading$f,
	discountCaption: discountCaption$f
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const de = {
    cpqQuote: cpqQuote$f,
};

var cpqQuoteHeading$e = "Item Price";
var discountCaption$e = "This item is {{ discount }}% off";
var cpqQuote$e = {
	cpqQuoteHeading: cpqQuoteHeading$e,
	discountCaption: discountCaption$e
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const en = {
    cpqQuote: cpqQuote$e,
};

var cpqQuoteHeading$d = "Precio del artículo";
var discountCaption$d = "Este artículo tiene un {{ discount }} % de descuento";
var cpqQuote$d = {
	cpqQuoteHeading: cpqQuoteHeading$d,
	discountCaption: discountCaption$d
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const es = {
    cpqQuote: cpqQuote$d,
};

var cpqQuoteHeading$c = "Precio del artículo";
var discountCaption$c = "Este artículo tiene un {{ discount }} % de descuento";
var cpqQuote$c = {
	cpqQuoteHeading: cpqQuoteHeading$c,
	discountCaption: discountCaption$c
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const es_CO = {
    cpqQuote: cpqQuote$c,
};

var cpqQuoteHeading$b = "Prix de l'article";
var discountCaption$b = "Cet article bénéficie d'une réduction de {{ discount }} 10%.";
var cpqQuote$b = {
	cpqQuoteHeading: cpqQuoteHeading$b,
	discountCaption: discountCaption$b
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const fr = {
    cpqQuote: cpqQuote$b,
};

var cpqQuoteHeading$a = "आइटम मूल्य";
var discountCaption$a = "इस आइटम पर {{ discount }}% की छूट है";
var cpqQuote$a = {
	cpqQuoteHeading: cpqQuoteHeading$a,
	discountCaption: discountCaption$a
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const hi = {
    cpqQuote: cpqQuote$a,
};

var cpqQuoteHeading$9 = "Tétel ára";
var discountCaption$9 = "A tételre {{ discount }}%-os engedmény van érvényben";
var cpqQuote$9 = {
	cpqQuoteHeading: cpqQuoteHeading$9,
	discountCaption: discountCaption$9
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const hu = {
    cpqQuote: cpqQuote$9,
};

var cpqQuoteHeading$8 = "Harga Item";
var discountCaption$8 = "Item ini mendapatkan diskon {{ discount }}%";
var cpqQuote$8 = {
	cpqQuoteHeading: cpqQuoteHeading$8,
	discountCaption: discountCaption$8
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const id = {
    cpqQuote: cpqQuote$8,
};

var cpqQuoteHeading$7 = "Prezzo articolo";
var discountCaption$7 = "Questo articolo ha uno sconto del {{ discount }}%";
var cpqQuote$7 = {
	cpqQuoteHeading: cpqQuoteHeading$7,
	discountCaption: discountCaption$7
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const it = {
    cpqQuote: cpqQuote$7,
};

var cpqQuoteHeading$6 = "アイテム価格";
var discountCaption$6 = "このアイテムは {{ discount }}% オフです";
var cpqQuote$6 = {
	cpqQuoteHeading: cpqQuoteHeading$6,
	discountCaption: discountCaption$6
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ja = {
    cpqQuote: cpqQuote$6,
};

var cpqQuoteHeading$5 = "품목 가격";
var discountCaption$5 = "이 품목은 {{ discount }}% 할인입니다.";
var cpqQuote$5 = {
	cpqQuoteHeading: cpqQuoteHeading$5,
	discountCaption: discountCaption$5
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ko = {
    cpqQuote: cpqQuote$5,
};

var cpqQuoteHeading$4 = "Cena pozycji";
var discountCaption$4 = "Pozycja przeceniona o {{ discount }}%";
var cpqQuote$4 = {
	cpqQuoteHeading: cpqQuoteHeading$4,
	discountCaption: discountCaption$4
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const pl = {
    cpqQuote: cpqQuote$4,
};

var cpqQuoteHeading$3 = "Preço do item";
var discountCaption$3 = "Este item tem {{ discount }}% de desconto";
var cpqQuote$3 = {
	cpqQuoteHeading: cpqQuoteHeading$3,
	discountCaption: discountCaption$3
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const pt = {
    cpqQuote: cpqQuote$3,
};

var cpqQuoteHeading$2 = "Цена позиции";
var discountCaption$2 = "Цена на эту позицию снижена на {{ discount }}%";
var cpqQuote$2 = {
	cpqQuoteHeading: cpqQuoteHeading$2,
	discountCaption: discountCaption$2
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ru = {
    cpqQuote: cpqQuote$2,
};

var cpqQuoteHeading$1 = "商品价格";
var discountCaption$1 = "此商品降价 {{ discount }}%";
var cpqQuote$1 = {
	cpqQuoteHeading: cpqQuoteHeading$1,
	discountCaption: discountCaption$1
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const zh = {
    cpqQuote: cpqQuote$1,
};

var cpqQuoteHeading = "項目價格";
var discountCaption = "此項目折扣 {{ discount }}%";
var cpqQuote = {
	cpqQuoteHeading: cpqQuoteHeading,
	discountCaption: discountCaption
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const zh_TW = {
    cpqQuote,
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const cpqquoteTranslationChunksConfig = {
    cpqQuote: ['cpqQuoteHeading', 'discountCaption'],
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { cpqquoteTranslationChunksConfig, cs as cpqquoteTranslationsCs, de as cpqquoteTranslationsDe, en as cpqquoteTranslationsEn, es as cpqquoteTranslationsEs, es_CO as cpqquoteTranslationsEs_CO, fr as cpqquoteTranslationsFr, hi as cpqquoteTranslationsHi, hu as cpqquoteTranslationsHu, id as cpqquoteTranslationsId, it as cpqquoteTranslationsIt, ja as cpqquoteTranslationsJa, ko as cpqquoteTranslationsKo, pl as cpqquoteTranslationsPl, pt as cpqquoteTranslationsPt, ru as cpqquoteTranslationsRu, zh as cpqquoteTranslationsZh, zh_TW as cpqquoteTranslationsZh_TW };
//# sourceMappingURL=spartacus-cpq-quote-assets.mjs.map
