import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    cpqQuote: {
        cpqQuoteHeading: string;
        discountCaption: string;
    };
};

declare const de: {
    cpqQuote: {
        cpqQuoteHeading: string;
        discountCaption: string;
    };
};

declare const en: {
    cpqQuote: {
        cpqQuoteHeading: string;
        discountCaption: string;
    };
};

declare const es: {
    cpqQuote: {
        cpqQuoteHeading: string;
        discountCaption: string;
    };
};

declare const es_CO: {
    cpqQuote: {
        cpqQuoteHeading: string;
        discountCaption: string;
    };
};

declare const fr: {
    cpqQuote: {
        cpqQuoteHeading: string;
        discountCaption: string;
    };
};

declare const hi: {
    cpqQuote: {
        cpqQuoteHeading: string;
        discountCaption: string;
    };
};

declare const hu: {
    cpqQuote: {
        cpqQuoteHeading: string;
        discountCaption: string;
    };
};

declare const id: {
    cpqQuote: {
        cpqQuoteHeading: string;
        discountCaption: string;
    };
};

declare const it: {
    cpqQuote: {
        cpqQuoteHeading: string;
        discountCaption: string;
    };
};

declare const ja: {
    cpqQuote: {
        cpqQuoteHeading: string;
        discountCaption: string;
    };
};

declare const ko: {
    cpqQuote: {
        cpqQuoteHeading: string;
        discountCaption: string;
    };
};

declare const pl: {
    cpqQuote: {
        cpqQuoteHeading: string;
        discountCaption: string;
    };
};

declare const pt: {
    cpqQuote: {
        cpqQuoteHeading: string;
        discountCaption: string;
    };
};

declare const ru: {
    cpqQuote: {
        cpqQuoteHeading: string;
        discountCaption: string;
    };
};

declare const zh: {
    cpqQuote: {
        cpqQuoteHeading: string;
        discountCaption: string;
    };
};

declare const zh_TW: {
    cpqQuote: {
        cpqQuoteHeading: string;
        discountCaption: string;
    };
};

declare const cpqquoteTranslationChunksConfig: TranslationChunksConfig;

export { cpqquoteTranslationChunksConfig, cs as cpqquoteTranslationsCs, de as cpqquoteTranslationsDe, en as cpqquoteTranslationsEn, es as cpqquoteTranslationsEs, es_CO as cpqquoteTranslationsEs_CO, fr as cpqquoteTranslationsFr, hi as cpqquoteTranslationsHi, hu as cpqquoteTranslationsHu, id as cpqquoteTranslationsId, it as cpqquoteTranslationsIt, ja as cpqquoteTranslationsJa, ko as cpqquoteTranslationsKo, pl as cpqquoteTranslationsPl, pt as cpqquoteTranslationsPt, ru as cpqquoteTranslationsRu, zh as cpqquoteTranslationsZh, zh_TW as cpqquoteTranslationsZh_TW };
