import * as i0 from '@angular/core';
import { OnInit, OnDestroy } from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/core';
import { TranslationService } from '@spartacus/core';
import * as i3 from '@spartacus/storefront';
import { OutletContextData } from '@spartacus/storefront';
import { OrderEntry, CartItemContext } from '@spartacus/cart/base/root';
import * as rxjs from 'rxjs';
import { Subscription, Observable } from 'rxjs';
import { CpqDiscounts } from '@spartacus/cpq-quote/root';
import { CartItemListComponentService } from '@spartacus/cart/base/components';

declare class CpqQuoteService {
    private isFlagSubject;
    isFlag$: rxjs.Observable<boolean>;
    setFlag(value: boolean): void;
    getFlag$(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqQuoteService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CpqQuoteService>;
}

declare class CpqQuoteHeadingComponent implements OnInit, OnDestroy {
    protected outlet: OutletContextData;
    protected translationService: TranslationService;
    private cpqQuoteService;
    quoteDiscountData: OrderEntry;
    protected subscription: Subscription;
    discountLabel: string;
    datacheck: any;
    constructor(outlet: OutletContextData, translationService: TranslationService, cpqQuoteService: CpqQuoteService);
    dataAvailable: boolean;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqQuoteHeadingComponent, [{ optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CpqQuoteHeadingComponent, "cx-cpq-quote-heading", never, { "quoteDiscountData": { "alias": "quoteDiscountData"; "required": false; }; }, {}, never, never, true, never>;
}

interface ExtendedOrderEntry$1 extends OrderEntry {
    cpqDiscounts?: CpqDiscounts[];
}
declare class CpqQuoteDiscountComponent implements OnInit, OnDestroy {
    protected cartItemContext: CartItemContext;
    private cpqQuoteService;
    quoteDiscountData: ExtendedOrderEntry$1 | null;
    private subscription;
    readonly orderEntry$: Observable<ExtendedOrderEntry$1>;
    isFlagQuote: boolean;
    constructor(cartItemContext: CartItemContext, cpqQuoteService: CpqQuoteService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    getDiscountedPrice(basePrice: number, appliedDiscount: number | undefined, quantity: number | undefined): number | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqQuoteDiscountComponent, [{ optional: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CpqQuoteDiscountComponent, "cx-cpq-quote", never, {}, {}, never, never, true, never>;
}

interface ExtendedOrderEntry extends OrderEntry {
    cpqDiscounts?: CpqDiscounts[];
}
declare class CpqQuoteOfferComponent implements OnInit, OnDestroy {
    protected cartItemContext: CartItemContext;
    quoteDiscountData: ExtendedOrderEntry | null;
    private subscription;
    readonly orderEntry$: Observable<ExtendedOrderEntry>;
    constructor(cartItemContext: CartItemContext);
    ngOnInit(): void;
    ngOnDestroy(): void;
    getDiscountPercentage(basePrice: number, appliedDiscount: number | undefined, quantity: number | undefined): number | undefined;
    formatDiscount(value: number | undefined): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqQuoteOfferComponent, [{ optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CpqQuoteOfferComponent, "cx-cpq-quote-offer", never, {}, {}, never, never, true, never>;
}

declare class CpqDiscountModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqDiscountModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CpqDiscountModule, never, [typeof i1.CommonModule, typeof i2.UrlModule, typeof i2.I18nModule, typeof i3.IconModule, typeof CpqQuoteHeadingComponent, typeof CpqQuoteDiscountComponent, typeof CpqQuoteOfferComponent], [typeof CpqQuoteHeadingComponent, typeof CpqQuoteDiscountComponent, typeof CpqQuoteOfferComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CpqDiscountModule>;
}

declare class CpqQuoteModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqQuoteModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CpqQuoteModule, never, [typeof CpqDiscountModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CpqQuoteModule>;
}

declare class CpqQuoteSharedService extends CartItemListComponentService {
    private flagService;
    constructor(flagService: CpqQuoteService);
    showBasePriceWithDiscount(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqQuoteSharedService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CpqQuoteSharedService>;
}

export { CpqDiscountModule, CpqQuoteDiscountComponent, CpqQuoteHeadingComponent, CpqQuoteModule, CpqQuoteOfferComponent, CpqQuoteService, CpqQuoteSharedService };
