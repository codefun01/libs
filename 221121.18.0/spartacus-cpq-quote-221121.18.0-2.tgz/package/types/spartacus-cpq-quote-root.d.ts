import * as i0 from '@angular/core';

interface CpqDiscounts {
    appliedValue?: any;
    isoCode?: any;
    value?: any;
}

declare module '@spartacus/cart/base/root' {
    interface OrderEntry {
        cpqDiscounts?: CpqDiscounts[];
    }
}

declare class CpqQuoteRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CpqQuoteRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CpqQuoteRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CpqQuoteRootModule>;
}

declare const CPQ_QUOTE_FEATURE = "cpq-quote";

export { CPQ_QUOTE_FEATURE, CpqQuoteRootModule };
export type { CpqDiscounts };
