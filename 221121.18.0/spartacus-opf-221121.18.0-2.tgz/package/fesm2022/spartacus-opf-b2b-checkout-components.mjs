import * as i0 from '@angular/core';
import { inject, DestroyRef, ViewChild, ChangeDetectionStrategy, Component, NgModule, Input } from '@angular/core';
import { NgIf, AsyncPipe, CommonModule, NgClass, NgFor } from '@angular/common';
import * as i1 from '@angular/forms';
import { FormBuilder, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, RouterLink, RouterModule } from '@angular/router';
import { ActiveCartFacade } from '@spartacus/cart/base/root';
import { CheckoutPaymentTypeFacade, B2BPaymentTypeEnum, CheckoutCostCenterFacade } from '@spartacus/checkout/b2b/root';
import { CheckoutStepService, CheckoutAuthGuard, CartNotEmptyGuard, CheckoutPlaceOrderComponent, CheckoutReviewSubmitComponent, CheckoutPlaceOrderModule } from '@spartacus/checkout/base/components';
import { CheckoutStepType } from '@spartacus/checkout/base/root';
import { UserIdService, GlobalMessageService, FeatureToggles, TranslatePipe, I18nModule, FeaturesConfigModule, provideDefaultConfig, CmsService, normalizeEmpty, UrlPipe, UrlModule } from '@spartacus/core';
import { OpfMetadataStoreService, OpfBaseFacade } from '@spartacus/opf/base/root';
import { OpfCheckoutPaymentsComponent, OpfCheckoutPaymentsModule, OpfCheckoutReviewCardComponent, OpfCheckoutTermsAndConditionsAlertComponent, OpfCheckoutReviewCartDetailsComponent, OpfCheckoutReviewCardModule, OpfCheckoutTermsAndConditionsAlertModule, OpfCheckoutBillingAddressFormModule, OpfCheckoutReviewCartDetailsModule, OpfCheckoutPaymentAndReviewComponent, OpfCheckoutBillingAddressFormComponent, OpfCheckoutPaymentWrapperModule } from '@spartacus/opf/checkout/components';
import { OpfPaymentFacade } from '@spartacus/opf/payment/root';
import { SpinnerComponent, SpinnerModule, AtMessageDirective, AtMessageModule, FormErrorsModule, FormRequiredAsterisksComponent, FormRequiredLegendComponent, CardComponent, CardModule, OutletModule, PromotionsModule, IconModule } from '@spartacus/storefront';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { BehaviorSubject, Subscription, take, filter, switchMap, map as map$1, combineLatest } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { CartValidationGuard } from '@spartacus/cart/base/core';
import { OPF_EXPLICIT_TERMS_AND_CONDITIONS_COMPONENT } from '@spartacus/opf/checkout/root';
import { CheckoutCostCenterComponent, B2BCheckoutDeliveryAddressComponent, CheckoutCostCenterModule } from '@spartacus/checkout/b2b/components';
import { AddressFormComponent, AddressFormModule } from '@spartacus/user/profile/components';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfB2bCheckoutPaymentTypeComponent {
    constructor() {
        this.opfPaymentFacade = inject(OpfPaymentFacade);
        this.userIdService = inject(UserIdService);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.checkoutPaymentTypeFacade = inject(CheckoutPaymentTypeFacade);
        this.checkoutStepService = inject(CheckoutStepService);
        this.activatedRoute = inject(ActivatedRoute);
        this.globalMessageService = inject(GlobalMessageService);
        this.opfMetadataStoreService = inject(OpfMetadataStoreService);
        this.fb = inject(FormBuilder);
        this.destroyRef = inject(DestroyRef);
        this.featureToggles = inject(FeatureToggles);
        this.isUpdating$ = new BehaviorSubject(false);
        this.subscription = new Subscription();
        this.selectedPaymentOption = undefined;
        this.form = this.fb.group({
            poNumber: [''],
        });
    }
    updatePoNumberField() {
        if (this.poNumberInputElement?.nativeElement && this.poNumberValue) {
            this.poNumberInputElement.nativeElement.value = this.poNumberValue;
        }
    }
    adaptCheckoutSteps(paymentType) {
        if (paymentType) {
            this.checkoutStepService.disableEnableStep(CheckoutStepType.PAYMENT_DETAILS, paymentType === B2BPaymentTypeEnum.ACCOUNT_PAYMENT);
            this.checkoutStepService.disableEnableStep(CheckoutStepType.REVIEW_ORDER, paymentType !== B2BPaymentTypeEnum.ACCOUNT_PAYMENT);
        }
    }
    getCartPoNumber() {
        return this.activeCartFacade.getActive().pipe(take(1), map((cart) => cart.purchaseOrderNumber));
    }
    next() {
        const poNumberInput = this.form.get('poNumber')?.value;
        if (this.selectedPaymentOption) {
            this.isUpdating$.next(true);
            this.checkoutPaymentTypeFacade
                .setPaymentType(this.selectedPaymentOption, poNumberInput)
                .subscribe({
                complete: () => {
                    this.activeCartFacade.reloadActiveCart();
                    this.checkoutStepService.next(this.activatedRoute);
                    this.isUpdating$.next(false);
                },
            });
        }
    }
    back() {
        this.checkoutStepService.back(this.activatedRoute);
    }
    getSelectedPaymentOption() {
        return this.opfMetadataStoreService.getOpfMetadataState().pipe(take(1), map((state) => state.selectedPaymentOptionId?.toString()));
    }
    setPaymentOption(paymentOption, poNumber) {
        return this.checkoutPaymentTypeFacade
            .setPaymentType(paymentOption, poNumber)
            .pipe(take(1));
    }
    handlePaymentChange(payment) {
        this.selectedPaymentOption = payment?.id?.toString();
        this.adaptCheckoutSteps(payment?.paymentType);
        if (this.selectedPaymentOption) {
            this.isUpdating$.next(true);
            this.setPaymentOption(this.selectedPaymentOption, this.form.get('poNumber')?.value).subscribe({
                complete: () => {
                    this.activeCartFacade.reloadActiveCart();
                    this.isUpdating$.next(false);
                },
            });
        }
    }
    ngOnInit() {
        this.cartPoNumber$ = this.getCartPoNumber();
        this.getSelectedPaymentOption().subscribe((selectedOption) => (this.selectedPaymentOption = selectedOption));
        if (this.featureToggles.opfUseDestroyRef) {
            this.cartPoNumber$
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe((poNumber) => {
                this.poNumberValue = poNumber;
                this.form.patchValue({ poNumber });
            });
        }
        else {
            this.subscription.add(this.cartPoNumber$.subscribe((poNumber) => {
                this.poNumberValue = poNumber;
                this.form.patchValue({ poNumber });
            }));
        }
    }
    ngAfterViewInit() {
        if (this.poNumberValue) {
            this.form.patchValue({ poNumber: this.poNumberValue });
        }
        this.getSelectedPaymentOption()
            .pipe(take(1), filter((paymentOption) => paymentOption === undefined), tap(() => this.opfMetadataStoreService.clearOpfMetadata()), switchMap(() => this.opfMetadataStoreService.getOpfMetadataState().pipe(filter((state) => state.defaultSelectedPaymentOptionId !== undefined), take(1))), switchMap((state) => {
            const paymentId = state.defaultSelectedPaymentOptionId;
            this.selectedPaymentOption = paymentId.toString();
            return this.setPaymentOption(this.selectedPaymentOption, this.poNumberValue).pipe(take(1));
        }))
            .subscribe();
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPaymentTypeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfB2bCheckoutPaymentTypeComponent, isStandalone: true, selector: "cx-opf-b2b-checkout-payment-type", viewQueries: [{ propertyName: "poNumberInputElement", first: true, predicate: ["poNumber"], descendants: true }], ngImport: i0, template: "<h2 class=\"cx-checkout-title d-none d-lg-block d-xl-block\">\n  {{ 'checkoutB2B.methodOfPayment.paymentType' | cxTranslate }}\n</h2>\n\n<ng-container>\n  <form [formGroup]=\"form\">\n    <div class=\"row\">\n      <div class=\"col-md-12 col-lg-6\">\n        <label>\n          <span class=\"label-content\">{{\n            'checkoutB2B.poNumber' | cxTranslate\n          }}</span>\n          <input\n            #poNumber\n            class=\"form-control\"\n            formControlName=\"poNumber\"\n            type=\"text\"\n            placeholder=\"{{ 'checkoutB2B.placeholder' | cxTranslate }}\"\n          />\n        </label>\n      </div>\n    </div>\n    <ng-container *ngIf=\"!(isUpdating$ | async); else loading\">\n      <span class=\"cx-payment-method-label\">{{\n        'opfCheckout.paymentMethod' | cxTranslate\n      }}</span>\n      <cx-opf-checkout-payments\n        [isHeadingDisplayed]=\"false\"\n        [isPaymentRenderBelow]=\"false\"\n        [isPaymentInfoMessageEnabled]=\"false\"\n        [showBeforePaymentOptionsOutlet]=\"false\"\n        (paymentChange)=\"handlePaymentChange($event)\"\n        [forceDefaultPaymentOptionInputSelection]=\"true\"\n      ></cx-opf-checkout-payments>\n\n      <div class=\"cx-checkout-btns row\">\n        <div class=\"col-md-12 col-lg-6\">\n          <button class=\"btn btn-block btn-secondary\" (click)=\"back()\">\n            {{ 'checkout.backToCart' | cxTranslate }}\n          </button>\n        </div>\n        <div class=\"col-md-12 col-lg-6\">\n          <button class=\"btn btn-block btn-primary\" (click)=\"next()\">\n            {{ 'common.continue' | cxTranslate }}\n          </button>\n        </div>\n      </div>\n    </ng-container>\n  </form>\n</ng-container>\n<ng-template #loading>\n  <div class=\"cx-spinner\">\n    <cx-spinner></cx-spinner>\n  </div>\n</ng-template>\n", dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: OpfCheckoutPaymentsComponent, selector: "cx-opf-checkout-payments", inputs: ["isHeadingDisplayed", "headingTranslationKey", "isPaymentRenderBelow", "isPaymentInfoMessageEnabled", "elementsPerPage", "disabled", "explicitTermsAndConditions", "onlyPaymentWrapperMode", "showBeforePaymentOptionsOutlet", "customPaymentTemplate", "hideOnlyOnePaymentProviderLabel", "forceRadioInputsView", "forceDefaultPaymentOptionInputSelection", "renderPaymentWrapper", "noRenderPaymentWrapperMessage"], outputs: ["paymentChange", "selectedPaymentProviderName"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPaymentTypeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-b2b-checkout-payment-type', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        FormsModule,
                        ReactiveFormsModule,
                        NgIf,
                        OpfCheckoutPaymentsComponent,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<h2 class=\"cx-checkout-title d-none d-lg-block d-xl-block\">\n  {{ 'checkoutB2B.methodOfPayment.paymentType' | cxTranslate }}\n</h2>\n\n<ng-container>\n  <form [formGroup]=\"form\">\n    <div class=\"row\">\n      <div class=\"col-md-12 col-lg-6\">\n        <label>\n          <span class=\"label-content\">{{\n            'checkoutB2B.poNumber' | cxTranslate\n          }}</span>\n          <input\n            #poNumber\n            class=\"form-control\"\n            formControlName=\"poNumber\"\n            type=\"text\"\n            placeholder=\"{{ 'checkoutB2B.placeholder' | cxTranslate }}\"\n          />\n        </label>\n      </div>\n    </div>\n    <ng-container *ngIf=\"!(isUpdating$ | async); else loading\">\n      <span class=\"cx-payment-method-label\">{{\n        'opfCheckout.paymentMethod' | cxTranslate\n      }}</span>\n      <cx-opf-checkout-payments\n        [isHeadingDisplayed]=\"false\"\n        [isPaymentRenderBelow]=\"false\"\n        [isPaymentInfoMessageEnabled]=\"false\"\n        [showBeforePaymentOptionsOutlet]=\"false\"\n        (paymentChange)=\"handlePaymentChange($event)\"\n        [forceDefaultPaymentOptionInputSelection]=\"true\"\n      ></cx-opf-checkout-payments>\n\n      <div class=\"cx-checkout-btns row\">\n        <div class=\"col-md-12 col-lg-6\">\n          <button class=\"btn btn-block btn-secondary\" (click)=\"back()\">\n            {{ 'checkout.backToCart' | cxTranslate }}\n          </button>\n        </div>\n        <div class=\"col-md-12 col-lg-6\">\n          <button class=\"btn btn-block btn-primary\" (click)=\"next()\">\n            {{ 'common.continue' | cxTranslate }}\n          </button>\n        </div>\n      </div>\n    </ng-container>\n  </form>\n</ng-container>\n<ng-template #loading>\n  <div class=\"cx-spinner\">\n    <cx-spinner></cx-spinner>\n  </div>\n</ng-template>\n" }]
        }], ctorParameters: () => [], propDecorators: { poNumberInputElement: [{
                type: ViewChild,
                args: ['poNumber', { static: false }]
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfB2bCheckoutPaymentTypeModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPaymentTypeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPaymentTypeModule, imports: [CommonModule,
            I18nModule,
            SpinnerModule,
            FeaturesConfigModule,
            OpfCheckoutPaymentsModule,
            ReactiveFormsModule,
            OpfB2bCheckoutPaymentTypeComponent], exports: [OpfB2bCheckoutPaymentTypeComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPaymentTypeModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    OpfCheckoutPaymentType: {
                        component: OpfB2bCheckoutPaymentTypeComponent,
                        guards: [CheckoutAuthGuard, CartNotEmptyGuard, CartValidationGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            SpinnerModule,
            FeaturesConfigModule,
            OpfCheckoutPaymentsModule,
            ReactiveFormsModule,
            OpfB2bCheckoutPaymentTypeComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPaymentTypeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        SpinnerModule,
                        FeaturesConfigModule,
                        OpfCheckoutPaymentsModule,
                        ReactiveFormsModule,
                        OpfB2bCheckoutPaymentTypeComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                OpfCheckoutPaymentType: {
                                    component: OpfB2bCheckoutPaymentTypeComponent,
                                    guards: [CheckoutAuthGuard, CartNotEmptyGuard, CartValidationGuard],
                                },
                            },
                        }),
                    ],
                    exports: [OpfB2bCheckoutPaymentTypeComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfB2bCheckoutPlaceOrderComponent extends CheckoutPlaceOrderComponent {
    constructor() {
        super(...arguments);
        this.isDisabled = false;
    }
    ngOnInit() {
        this.checkoutSubmitForm
            .get('termsAndConditions')
            ?.setValue(!this.isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPlaceOrderComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfB2bCheckoutPlaceOrderComponent, isStandalone: true, selector: "cx-opf-b2b-checkout-place-order", inputs: { isDisabled: "isDisabled" }, usesInheritance: true, ngImport: i0, template: "<form class=\"cx-place-order-form form-check\" [formGroup]=\"checkoutSubmitForm\">\n  <button\n    (click)=\"submitForm()\"\n    class=\"btn btn-primary btn-block\"\n    [disabled]=\"isDisabled\"\n    [cxAtMessage]=\"'checkoutReview.orderInProcess' | cxTranslate\"\n  >\n    {{ 'checkoutReview.placeOrder' | cxTranslate }}\n  </button>\n</form>\n", dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: AtMessageDirective, selector: "[cxAtMessage]", inputs: ["cxAtMessage"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPlaceOrderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-b2b-checkout-place-order', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        FormsModule,
                        ReactiveFormsModule,
                        AtMessageDirective,
                        TranslatePipe,
                    ], template: "<form class=\"cx-place-order-form form-check\" [formGroup]=\"checkoutSubmitForm\">\n  <button\n    (click)=\"submitForm()\"\n    class=\"btn btn-primary btn-block\"\n    [disabled]=\"isDisabled\"\n    [cxAtMessage]=\"'checkoutReview.orderInProcess' | cxTranslate\"\n  >\n    {{ 'checkoutReview.placeOrder' | cxTranslate }}\n  </button>\n</form>\n" }]
        }], propDecorators: { isDisabled: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfB2bCheckoutReviewComponent extends CheckoutReviewSubmitComponent {
    constructor() {
        super(...arguments);
        this.fb = inject(FormBuilder);
        this.opfMetadataStoreService = inject(OpfMetadataStoreService);
        this.cmsService = inject(CmsService);
        this.checkoutPaymentTypeFacade = inject(CheckoutPaymentTypeFacade);
        this.opfBaseFacade = inject(OpfBaseFacade);
        this.checkoutCostCenterFacade = inject(CheckoutCostCenterFacade);
        this.defaultTermsAndConditionsFieldValue = false;
        this.checkoutStepTypePaymentType = CheckoutStepType.PAYMENT_TYPE;
        this.explicitTermsAndConditions$ = this.cmsService
            .getCurrentPage()
            .pipe(map$1((page) => {
            return this.isCmsComponentInPage(OPF_EXPLICIT_TERMS_AND_CONDITIONS_COMPONENT, page);
        }));
        this.checkoutSubmitForm = this.fb.group({
            termsAndConditions: [
                this.defaultTermsAndConditionsFieldValue,
                Validators.requiredTrue,
            ],
        });
        this.poNumber$ = this.checkoutPaymentTypeFacade.getPurchaseOrderNumberState().pipe(filter((state) => !state.loading && !state.error), map$1((state) => state.data));
        this.costCenter$ = this.checkoutCostCenterFacade.getCostCenterState().pipe(filter((state) => !state.loading && !state.error), map$1((state) => state.data));
    }
    get termsAndConditionInvalid() {
        return this.checkoutSubmitForm?.invalid ?? true;
    }
    get termsAndConditionsFieldValue() {
        return Boolean(this.checkoutSubmitForm?.get('termsAndConditions')?.value);
    }
    get paymentType$() {
        return this.activeCartFacade
            .getActive()
            .pipe(map$1((cart) => cart.paymentType));
    }
    getCostCenterCard(costCenter) {
        return combineLatest([
            this.translationService.translate('opfCheckout.costCenter'),
            this.translationService.translate('opfCheckout.noCostCenter'),
        ]).pipe(map$1(([title, noCostCenter]) => ({
            title,
            textBold: costCenter?.name ?? noCostCenter,
            text: [],
        })));
    }
    getPoNumberCard(poNumber) {
        return combineLatest([
            this.translationService.translate('opfCheckout.poNumber'),
            this.translationService.translate('opfCheckout.noPoNumber'),
        ]).pipe(map$1(([textTitle, noneTextTitle]) => {
            return {
                title: textTitle,
                textBold: normalizeEmpty(poNumber) ?? noneTextTitle,
            };
        }));
    }
    isCmsComponentInPage(cmsComponentUid, page) {
        return !!page && JSON.stringify(page).includes(cmsComponentUid);
    }
    updateTermsAndConditionsState() {
        this.opfMetadataStoreService.updateOpfMetadata({
            termsAndConditionsChecked: this.termsAndConditionsFieldValue,
        });
    }
    toggleTermsAndConditions() {
        this.updateTermsAndConditionsState();
    }
    ngOnInit() {
        this.updateTermsAndConditionsState();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutReviewComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfB2bCheckoutReviewComponent, isStandalone: true, selector: "cx-opf-b2b-checkout-review", usesInheritance: true, ngImport: i0, template: "<ng-container\n  *ngIf=\"{\n    value: explicitTermsAndConditions$ | async,\n  } as explicitTermsAndConditions\"\n>\n  <div class=\"cx-opf-review-card-wrapper\">\n    <cx-opf-checkout-review-card\n      [cardContent$]=\"getPoNumberCard(poNumber$ | async)\"\n      [editConfig]=\"{\n        route: getCheckoutStepUrl(checkoutStepTypePaymentType),\n        ariaLabelKey: 'checkoutReview.editPoNumber',\n      }\"\n    ></cx-opf-checkout-review-card>\n    <cx-opf-checkout-review-card\n      [cardContent$]=\"getCostCenterCard(costCenter$ | async)\"\n      [editConfig]=\"{\n        route: getCheckoutStepUrl(checkoutStepTypeDeliveryAddress),\n        ariaLabelKey: 'checkoutReview.editDeliveryAddressDetails',\n      }\"\n    ></cx-opf-checkout-review-card>\n    <cx-opf-checkout-review-card\n      *ngIf=\"deliveryAddress$ | async as deliveryAddress\"\n      [cardContent$]=\"getDeliveryAddressCard(deliveryAddress)\"\n      [editConfig]=\"{\n        route: getCheckoutStepUrl(checkoutStepTypeDeliveryAddress),\n        ariaLabelKey: 'checkoutReview.editDeliveryAddressDetails',\n      }\"\n    ></cx-opf-checkout-review-card>\n    <cx-opf-checkout-review-card\n      *ngIf=\"deliveryMode$ | async as deliveryMode\"\n      [cardContent$]=\"getDeliveryModeCard(deliveryMode)\"\n      [editConfig]=\"{\n        route: getCheckoutStepUrl(checkoutStepTypeDeliveryMode),\n        ariaLabelKey: 'checkoutReview.editDeliveryMode',\n      }\"\n    ></cx-opf-checkout-review-card>\n  </div>\n\n  <cx-opf-checkout-terms-and-conditions-alert\n    *ngIf=\"!explicitTermsAndConditions.value\"\n    [isDismissible]=\"true\"\n    [isVisible]=\"termsAndConditionInvalid\"\n    [isExplicit]=\"explicitTermsAndConditions.value\"\n    [ngClass]=\"['for-mobile']\"\n  ></cx-opf-checkout-terms-and-conditions-alert>\n\n  <div\n    *ngIf=\"explicitTermsAndConditions.value\"\n    class=\"cx-opf-terms-and-conditions\"\n    [attr.aria-label]=\"'opfCheckout.termsAndConditions' | cxTranslate\"\n  >\n    <h3>{{ 'opfCheckout.termsAndConditions' | cxTranslate }}</h3>\n\n    <cx-opf-checkout-terms-and-conditions-alert\n      [isVisible]=\"termsAndConditionInvalid\"\n      [isExplicit]=\"explicitTermsAndConditions.value\"\n      [isDismissible]=\"false\"\n    ></cx-opf-checkout-terms-and-conditions-alert>\n\n    <form\n      class=\"cx-place-order-form form-check\"\n      [formGroup]=\"checkoutSubmitForm\"\n    >\n      <div class=\"form-group\">\n        <label>\n          <input\n            formControlName=\"termsAndConditions\"\n            class=\"scaled-input form-check-input\"\n            type=\"checkbox\"\n            (change)=\"toggleTermsAndConditions()\"\n          />\n          <span class=\"form-check-label\">\n            {{ 'checkoutReview.confirmThatRead' | cxTranslate }}\n            <a\n              [routerLink]=\"{ cxRoute: 'termsAndConditions' } | cxUrl\"\n              class=\"cx-tc-link\"\n              target=\"_blank\"\n              rel=\"noopener noreferrer\"\n            >\n              {{ 'checkoutReview.termsAndConditions' | cxTranslate }}\n            </a>\n          </span>\n        </label>\n      </div>\n    </form>\n  </div>\n\n  <cx-opf-checkout-payments\n    [onlyPaymentWrapperMode]=\"true\"\n    [showBeforePaymentOptionsOutlet]=\"false\"\n    [isPaymentInfoMessageEnabled]=\"false\"\n    [renderPaymentWrapper]=\"\n      !explicitTermsAndConditions.value ||\n      (explicitTermsAndConditions.value && !termsAndConditionInvalid)\n    \"\n    [noRenderPaymentWrapperMessage]=\"\n      'opfCheckout.termsAndConditionsDisclaimer' | cxTranslate\n    \"\n    [disabled]=\"termsAndConditionInvalid\"\n    [customPaymentTemplate]=\"placeOrderTemplate\"\n  >\n    <cx-opf-checkout-terms-and-conditions-alert\n      *ngIf=\"!explicitTermsAndConditions.value\"\n      [isDismissible]=\"true\"\n      [isVisible]=\"termsAndConditionInvalid\"\n      [isExplicit]=\"explicitTermsAndConditions.value\"\n      [ngClass]=\"['for-desktop']\"\n    ></cx-opf-checkout-terms-and-conditions-alert>\n  </cx-opf-checkout-payments>\n\n  <cx-opf-checkout-review-cart-details\n    [cart]=\"cart$ | async\"\n    [entries]=\"entries$ | async\"\n  ></cx-opf-checkout-review-cart-details>\n\n  <ng-template #placeOrderTemplate>\n    <cx-opf-b2b-checkout-place-order\n      [isDisabled]=\"false\"\n    ></cx-opf-b2b-checkout-place-order>\n  </ng-template>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: OpfCheckoutReviewCardComponent, selector: "cx-opf-checkout-review-card", inputs: ["cardContent$", "editConfig"] }, { kind: "component", type: OpfCheckoutTermsAndConditionsAlertComponent, selector: "cx-opf-checkout-terms-and-conditions-alert", inputs: ["isDismissible", "isVisible", "isExplicit"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: OpfCheckoutPaymentsComponent, selector: "cx-opf-checkout-payments", inputs: ["isHeadingDisplayed", "headingTranslationKey", "isPaymentRenderBelow", "isPaymentInfoMessageEnabled", "elementsPerPage", "disabled", "explicitTermsAndConditions", "onlyPaymentWrapperMode", "showBeforePaymentOptionsOutlet", "customPaymentTemplate", "hideOnlyOnePaymentProviderLabel", "forceRadioInputsView", "forceDefaultPaymentOptionInputSelection", "renderPaymentWrapper", "noRenderPaymentWrapperMessage"], outputs: ["paymentChange", "selectedPaymentProviderName"] }, { kind: "component", type: OpfCheckoutReviewCartDetailsComponent, selector: "cx-opf-checkout-review-cart-details", inputs: ["cart", "entries", "isAddressCardVisible"] }, { kind: "component", type: OpfB2bCheckoutPlaceOrderComponent, selector: "cx-opf-b2b-checkout-place-order", inputs: ["isDisabled"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutReviewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-b2b-checkout-review', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        OpfCheckoutReviewCardComponent,
                        OpfCheckoutTermsAndConditionsAlertComponent,
                        NgClass,
                        FormsModule,
                        ReactiveFormsModule,
                        RouterLink,
                        OpfCheckoutPaymentsComponent,
                        OpfCheckoutReviewCartDetailsComponent,
                        OpfB2bCheckoutPlaceOrderComponent,
                        AsyncPipe,
                        TranslatePipe,
                        UrlPipe,
                    ], template: "<ng-container\n  *ngIf=\"{\n    value: explicitTermsAndConditions$ | async,\n  } as explicitTermsAndConditions\"\n>\n  <div class=\"cx-opf-review-card-wrapper\">\n    <cx-opf-checkout-review-card\n      [cardContent$]=\"getPoNumberCard(poNumber$ | async)\"\n      [editConfig]=\"{\n        route: getCheckoutStepUrl(checkoutStepTypePaymentType),\n        ariaLabelKey: 'checkoutReview.editPoNumber',\n      }\"\n    ></cx-opf-checkout-review-card>\n    <cx-opf-checkout-review-card\n      [cardContent$]=\"getCostCenterCard(costCenter$ | async)\"\n      [editConfig]=\"{\n        route: getCheckoutStepUrl(checkoutStepTypeDeliveryAddress),\n        ariaLabelKey: 'checkoutReview.editDeliveryAddressDetails',\n      }\"\n    ></cx-opf-checkout-review-card>\n    <cx-opf-checkout-review-card\n      *ngIf=\"deliveryAddress$ | async as deliveryAddress\"\n      [cardContent$]=\"getDeliveryAddressCard(deliveryAddress)\"\n      [editConfig]=\"{\n        route: getCheckoutStepUrl(checkoutStepTypeDeliveryAddress),\n        ariaLabelKey: 'checkoutReview.editDeliveryAddressDetails',\n      }\"\n    ></cx-opf-checkout-review-card>\n    <cx-opf-checkout-review-card\n      *ngIf=\"deliveryMode$ | async as deliveryMode\"\n      [cardContent$]=\"getDeliveryModeCard(deliveryMode)\"\n      [editConfig]=\"{\n        route: getCheckoutStepUrl(checkoutStepTypeDeliveryMode),\n        ariaLabelKey: 'checkoutReview.editDeliveryMode',\n      }\"\n    ></cx-opf-checkout-review-card>\n  </div>\n\n  <cx-opf-checkout-terms-and-conditions-alert\n    *ngIf=\"!explicitTermsAndConditions.value\"\n    [isDismissible]=\"true\"\n    [isVisible]=\"termsAndConditionInvalid\"\n    [isExplicit]=\"explicitTermsAndConditions.value\"\n    [ngClass]=\"['for-mobile']\"\n  ></cx-opf-checkout-terms-and-conditions-alert>\n\n  <div\n    *ngIf=\"explicitTermsAndConditions.value\"\n    class=\"cx-opf-terms-and-conditions\"\n    [attr.aria-label]=\"'opfCheckout.termsAndConditions' | cxTranslate\"\n  >\n    <h3>{{ 'opfCheckout.termsAndConditions' | cxTranslate }}</h3>\n\n    <cx-opf-checkout-terms-and-conditions-alert\n      [isVisible]=\"termsAndConditionInvalid\"\n      [isExplicit]=\"explicitTermsAndConditions.value\"\n      [isDismissible]=\"false\"\n    ></cx-opf-checkout-terms-and-conditions-alert>\n\n    <form\n      class=\"cx-place-order-form form-check\"\n      [formGroup]=\"checkoutSubmitForm\"\n    >\n      <div class=\"form-group\">\n        <label>\n          <input\n            formControlName=\"termsAndConditions\"\n            class=\"scaled-input form-check-input\"\n            type=\"checkbox\"\n            (change)=\"toggleTermsAndConditions()\"\n          />\n          <span class=\"form-check-label\">\n            {{ 'checkoutReview.confirmThatRead' | cxTranslate }}\n            <a\n              [routerLink]=\"{ cxRoute: 'termsAndConditions' } | cxUrl\"\n              class=\"cx-tc-link\"\n              target=\"_blank\"\n              rel=\"noopener noreferrer\"\n            >\n              {{ 'checkoutReview.termsAndConditions' | cxTranslate }}\n            </a>\n          </span>\n        </label>\n      </div>\n    </form>\n  </div>\n\n  <cx-opf-checkout-payments\n    [onlyPaymentWrapperMode]=\"true\"\n    [showBeforePaymentOptionsOutlet]=\"false\"\n    [isPaymentInfoMessageEnabled]=\"false\"\n    [renderPaymentWrapper]=\"\n      !explicitTermsAndConditions.value ||\n      (explicitTermsAndConditions.value && !termsAndConditionInvalid)\n    \"\n    [noRenderPaymentWrapperMessage]=\"\n      'opfCheckout.termsAndConditionsDisclaimer' | cxTranslate\n    \"\n    [disabled]=\"termsAndConditionInvalid\"\n    [customPaymentTemplate]=\"placeOrderTemplate\"\n  >\n    <cx-opf-checkout-terms-and-conditions-alert\n      *ngIf=\"!explicitTermsAndConditions.value\"\n      [isDismissible]=\"true\"\n      [isVisible]=\"termsAndConditionInvalid\"\n      [isExplicit]=\"explicitTermsAndConditions.value\"\n      [ngClass]=\"['for-desktop']\"\n    ></cx-opf-checkout-terms-and-conditions-alert>\n  </cx-opf-checkout-payments>\n\n  <cx-opf-checkout-review-cart-details\n    [cart]=\"cart$ | async\"\n    [entries]=\"entries$ | async\"\n  ></cx-opf-checkout-review-cart-details>\n\n  <ng-template #placeOrderTemplate>\n    <cx-opf-b2b-checkout-place-order\n      [isDisabled]=\"false\"\n    ></cx-opf-b2b-checkout-place-order>\n  </ng-template>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfB2bCheckoutPlaceOrderModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPlaceOrderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPlaceOrderModule, imports: [CommonModule,
            RouterModule,
            SpinnerModule,
            I18nModule,
            UrlModule,
            FeaturesConfigModule,
            AtMessageModule,
            ReactiveFormsModule,
            FormErrorsModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            CheckoutPlaceOrderModule,
            OpfB2bCheckoutPlaceOrderComponent], exports: [OpfB2bCheckoutPlaceOrderComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPlaceOrderModule, imports: [CommonModule,
            RouterModule,
            SpinnerModule,
            I18nModule,
            UrlModule,
            FeaturesConfigModule,
            AtMessageModule,
            ReactiveFormsModule,
            FormErrorsModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            CheckoutPlaceOrderModule,
            OpfB2bCheckoutPlaceOrderComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPlaceOrderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        SpinnerModule,
                        I18nModule,
                        UrlModule,
                        FeaturesConfigModule,
                        AtMessageModule,
                        ReactiveFormsModule,
                        FormErrorsModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        CheckoutPlaceOrderModule,
                        OpfB2bCheckoutPlaceOrderComponent,
                    ],
                    exports: [OpfB2bCheckoutPlaceOrderComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfB2bCheckoutReviewModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutReviewModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutReviewModule, imports: [CommonModule,
            ReactiveFormsModule,
            RouterModule,
            I18nModule,
            UrlModule,
            OpfCheckoutReviewCardModule,
            OpfCheckoutTermsAndConditionsAlertModule,
            OpfCheckoutBillingAddressFormModule,
            OpfCheckoutPaymentsModule,
            OpfCheckoutReviewCartDetailsModule,
            OpfB2bCheckoutPlaceOrderModule,
            CheckoutPlaceOrderModule,
            OpfB2bCheckoutReviewComponent], exports: [OpfB2bCheckoutReviewComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutReviewModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    OpfCheckoutReview: {
                        component: OpfB2bCheckoutReviewComponent,
                    },
                },
            }),
        ], imports: [CommonModule,
            ReactiveFormsModule,
            RouterModule,
            I18nModule,
            UrlModule,
            OpfCheckoutReviewCardModule,
            OpfCheckoutTermsAndConditionsAlertModule,
            OpfCheckoutBillingAddressFormModule,
            OpfCheckoutPaymentsModule,
            OpfCheckoutReviewCartDetailsModule,
            OpfB2bCheckoutPlaceOrderModule,
            CheckoutPlaceOrderModule,
            OpfB2bCheckoutReviewComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutReviewModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        RouterModule,
                        I18nModule,
                        UrlModule,
                        OpfCheckoutReviewCardModule,
                        OpfCheckoutTermsAndConditionsAlertModule,
                        OpfCheckoutBillingAddressFormModule,
                        OpfCheckoutPaymentsModule,
                        OpfCheckoutReviewCartDetailsModule,
                        OpfB2bCheckoutPlaceOrderModule,
                        CheckoutPlaceOrderModule,
                        OpfB2bCheckoutReviewComponent,
                    ],
                    exports: [OpfB2bCheckoutReviewComponent],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                OpfCheckoutReview: {
                                    component: OpfB2bCheckoutReviewComponent,
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfB2bCheckoutCostCenterComponent extends CheckoutCostCenterComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutCostCenterComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfB2bCheckoutCostCenterComponent, isStandalone: true, selector: "cx-opf-b2b-checkout-cost-center", usesInheritance: true, ngImport: i0, template: "<ng-container *ngIf=\"isAccountPayment\">\n  <div class=\"row\">\n    <div class=\"col-md-12\">\n      <ng-container *ngIf=\"costCenters$ | async as costCenters\">\n        <div *ngIf=\"costCenters.length !== 0\">\n          <label>\n            <span class=\"label-content required\">{{\n              'checkoutB2B.costCenter' | cxTranslate\n            }}</span>\n            <select\n              #costCenterSelect\n              (change)=\"setCostCenter(costCenterSelect.value)\"\n            >\n              <option\n                *ngFor=\"let costCenter of costCenters\"\n                value=\"{{ costCenter.code }}\"\n                [selected]=\"costCenterId === costCenter.code\"\n              >\n                {{ costCenter.name }}\n              </option>\n            </select>\n          </label>\n        </div>\n        <span class=\"cx-cost-center-description\">{{\n          'checkoutB2B.availableLabel' | cxTranslate\n        }}</span>\n      </ng-container>\n    </div>\n  </div>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutCostCenterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-b2b-checkout-cost-center', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, NgFor, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"isAccountPayment\">\n  <div class=\"row\">\n    <div class=\"col-md-12\">\n      <ng-container *ngIf=\"costCenters$ | async as costCenters\">\n        <div *ngIf=\"costCenters.length !== 0\">\n          <label>\n            <span class=\"label-content required\">{{\n              'checkoutB2B.costCenter' | cxTranslate\n            }}</span>\n            <select\n              #costCenterSelect\n              (change)=\"setCostCenter(costCenterSelect.value)\"\n            >\n              <option\n                *ngFor=\"let costCenter of costCenters\"\n                value=\"{{ costCenter.code }}\"\n                [selected]=\"costCenterId === costCenter.code\"\n              >\n                {{ costCenter.name }}\n              </option>\n            </select>\n          </label>\n        </div>\n        <span class=\"cx-cost-center-description\">{{\n          'checkoutB2B.availableLabel' | cxTranslate\n        }}</span>\n      </ng-container>\n    </div>\n  </div>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfB2bCheckoutDeliveryAddressComponent extends B2BCheckoutDeliveryAddressComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutDeliveryAddressComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfB2bCheckoutDeliveryAddressComponent, isStandalone: true, selector: "cx-opf-b2b-checkout-delivery-address", usesInheritance: true, ngImport: i0, template: "<h2 class=\"cx-checkout-title d-none d-lg-block d-xl-block\">\n  {{ 'checkoutAddress.shippingAddress' | cxTranslate }}\n</h2>\n<cx-opf-b2b-checkout-cost-center></cx-opf-b2b-checkout-cost-center>\n<ng-container *ngIf=\"cards$ | async as cards\">\n  <ng-container *ngIf=\"!(isUpdating$ | async); else loading\">\n    <ng-container\n      *ngIf=\"\n        isAccountPayment || (cards?.length && !addressFormOpened);\n        then showExistingAddresses;\n        else newAddressForm\n      \"\n    >\n    </ng-container>\n\n    <ng-template #showExistingAddresses>\n      <p class=\"cx-checkout-text\">\n        {{ 'checkoutAddress.selectYourDeliveryAddress' | cxTranslate }}\n      </p>\n      <div class=\"cx-checkout-btns row\" *ngIf=\"!isAccountPayment\">\n        <div class=\"col-sm-12 col-md-12 col-lg-6\">\n          <button\n            class=\"btn btn-block btn-secondary\"\n            (click)=\"showNewAddressForm()\"\n          >\n            {{ 'checkoutAddress.addNewAddress' | cxTranslate }}\n          </button>\n        </div>\n      </div>\n\n      <div class=\"cx-checkout-body row\">\n        <div\n          class=\"cx-delivery-address-card col-md-12 col-lg-6\"\n          *ngFor=\"let card of cards; let i = index\"\n        >\n          <div\n            class=\"cx-delivery-address-card-inner\"\n            (click)=\"selectAddress(card.address)\"\n          >\n            <cx-card\n              [border]=\"true\"\n              [index]=\"i\"\n              [fitToContainer]=\"true\"\n              [content]=\"card.card\"\n              (sendCard)=\"selectAddress(card.address)\"\n              [role]=\"'group'\"\n            ></cx-card>\n          </div>\n        </div>\n      </div>\n\n      <div class=\"cx-checkout-btns row\">\n        <div class=\"col-md-12 col-lg-6\">\n          <button class=\"cx-btn btn btn-block btn-secondary\" (click)=\"back()\">\n            {{ backBtnText | cxTranslate }}\n          </button>\n        </div>\n        <div class=\"col-md-12 col-lg-6\">\n          <button\n            class=\"cx-btn btn btn-block btn-primary\"\n            [disabled]=\"!(selectedAddress$ | async)?.id\"\n            (click)=\"next()\"\n          >\n            {{ 'common.continue' | cxTranslate }}\n          </button>\n        </div>\n      </div>\n    </ng-template>\n\n    <ng-template #newAddressForm>\n      <cx-address-form\n        *ngIf=\"cards.length; else initialAddressForm\"\n        [showTitleCode]=\"true\"\n        (backToAddress)=\"hideNewAddressForm(false)\"\n        (submitAddress)=\"addAddress($event)\"\n      ></cx-address-form>\n      <ng-template #initialAddressForm>\n        <cx-address-form\n          [showTitleCode]=\"true\"\n          [setAsDefaultField]=\"!isGuestCheckout\"\n          cancelBtnLabel=\"{{ backBtnText | cxTranslate }}\"\n          (backToAddress)=\"hideNewAddressForm(true)\"\n          (submitAddress)=\"addAddress($event)\"\n        ></cx-address-form>\n      </ng-template>\n    </ng-template>\n  </ng-container>\n</ng-container>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\">\n    <cx-spinner></cx-spinner>\n  </div>\n</ng-template>\n", dependencies: [{ kind: "component", type: OpfB2bCheckoutCostCenterComponent, selector: "cx-opf-b2b-checkout-cost-center" }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: CardComponent, selector: "cx-card", inputs: ["border", "editMode", "isDefault", "content", "fitToContainer", "truncateText", "truncateParagraphText", "charactersLimit", "index", "role"], outputs: ["deleteCard", "setDefaultCard", "sendCard", "editCard", "cancelCard"] }, { kind: "component", type: AddressFormComponent, selector: "cx-address-form", inputs: ["addressData", "actionBtnLabel", "cancelBtnLabel", "setAsDefaultField", "showTitleCode", "showCancelBtn", "countries"], outputs: ["submitAddress", "backToAddress"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutDeliveryAddressComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-b2b-checkout-delivery-address', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        OpfB2bCheckoutCostCenterComponent,
                        NgIf,
                        NgFor,
                        CardComponent,
                        AddressFormComponent,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<h2 class=\"cx-checkout-title d-none d-lg-block d-xl-block\">\n  {{ 'checkoutAddress.shippingAddress' | cxTranslate }}\n</h2>\n<cx-opf-b2b-checkout-cost-center></cx-opf-b2b-checkout-cost-center>\n<ng-container *ngIf=\"cards$ | async as cards\">\n  <ng-container *ngIf=\"!(isUpdating$ | async); else loading\">\n    <ng-container\n      *ngIf=\"\n        isAccountPayment || (cards?.length && !addressFormOpened);\n        then showExistingAddresses;\n        else newAddressForm\n      \"\n    >\n    </ng-container>\n\n    <ng-template #showExistingAddresses>\n      <p class=\"cx-checkout-text\">\n        {{ 'checkoutAddress.selectYourDeliveryAddress' | cxTranslate }}\n      </p>\n      <div class=\"cx-checkout-btns row\" *ngIf=\"!isAccountPayment\">\n        <div class=\"col-sm-12 col-md-12 col-lg-6\">\n          <button\n            class=\"btn btn-block btn-secondary\"\n            (click)=\"showNewAddressForm()\"\n          >\n            {{ 'checkoutAddress.addNewAddress' | cxTranslate }}\n          </button>\n        </div>\n      </div>\n\n      <div class=\"cx-checkout-body row\">\n        <div\n          class=\"cx-delivery-address-card col-md-12 col-lg-6\"\n          *ngFor=\"let card of cards; let i = index\"\n        >\n          <div\n            class=\"cx-delivery-address-card-inner\"\n            (click)=\"selectAddress(card.address)\"\n          >\n            <cx-card\n              [border]=\"true\"\n              [index]=\"i\"\n              [fitToContainer]=\"true\"\n              [content]=\"card.card\"\n              (sendCard)=\"selectAddress(card.address)\"\n              [role]=\"'group'\"\n            ></cx-card>\n          </div>\n        </div>\n      </div>\n\n      <div class=\"cx-checkout-btns row\">\n        <div class=\"col-md-12 col-lg-6\">\n          <button class=\"cx-btn btn btn-block btn-secondary\" (click)=\"back()\">\n            {{ backBtnText | cxTranslate }}\n          </button>\n        </div>\n        <div class=\"col-md-12 col-lg-6\">\n          <button\n            class=\"cx-btn btn btn-block btn-primary\"\n            [disabled]=\"!(selectedAddress$ | async)?.id\"\n            (click)=\"next()\"\n          >\n            {{ 'common.continue' | cxTranslate }}\n          </button>\n        </div>\n      </div>\n    </ng-template>\n\n    <ng-template #newAddressForm>\n      <cx-address-form\n        *ngIf=\"cards.length; else initialAddressForm\"\n        [showTitleCode]=\"true\"\n        (backToAddress)=\"hideNewAddressForm(false)\"\n        (submitAddress)=\"addAddress($event)\"\n      ></cx-address-form>\n      <ng-template #initialAddressForm>\n        <cx-address-form\n          [showTitleCode]=\"true\"\n          [setAsDefaultField]=\"!isGuestCheckout\"\n          cancelBtnLabel=\"{{ backBtnText | cxTranslate }}\"\n          (backToAddress)=\"hideNewAddressForm(true)\"\n          (submitAddress)=\"addAddress($event)\"\n        ></cx-address-form>\n      </ng-template>\n    </ng-template>\n  </ng-container>\n</ng-container>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\">\n    <cx-spinner></cx-spinner>\n  </div>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfB2bCheckoutCostCenterModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutCostCenterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutCostCenterModule, imports: [CommonModule,
            I18nModule,
            CheckoutCostCenterModule,
            OpfB2bCheckoutCostCenterComponent], exports: [OpfB2bCheckoutCostCenterComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutCostCenterModule, imports: [CommonModule,
            I18nModule,
            CheckoutCostCenterModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutCostCenterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        CheckoutCostCenterModule,
                        OpfB2bCheckoutCostCenterComponent,
                    ],
                    exports: [OpfB2bCheckoutCostCenterComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfB2bCheckoutDeliveryAddressModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutDeliveryAddressModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutDeliveryAddressModule, imports: [CommonModule,
            RouterModule,
            AddressFormModule,
            CardModule,
            SpinnerModule,
            I18nModule,
            FeaturesConfigModule,
            OpfB2bCheckoutCostCenterModule,
            OpfB2bCheckoutDeliveryAddressComponent], exports: [OpfB2bCheckoutDeliveryAddressComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutDeliveryAddressModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    OpfCheckoutDeliveryAddress: {
                        component: OpfB2bCheckoutDeliveryAddressComponent,
                    },
                },
            }),
        ], imports: [CommonModule,
            RouterModule,
            AddressFormModule,
            CardModule,
            SpinnerModule,
            I18nModule,
            FeaturesConfigModule,
            OpfB2bCheckoutCostCenterModule,
            OpfB2bCheckoutDeliveryAddressComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutDeliveryAddressModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        AddressFormModule,
                        CardModule,
                        SpinnerModule,
                        I18nModule,
                        FeaturesConfigModule,
                        OpfB2bCheckoutCostCenterModule,
                        OpfB2bCheckoutDeliveryAddressComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                OpfCheckoutDeliveryAddress: {
                                    component: OpfB2bCheckoutDeliveryAddressComponent,
                                },
                            },
                        }),
                    ],
                    exports: [OpfB2bCheckoutDeliveryAddressComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfB2bCheckoutPaymentAndReviewComponent extends OpfCheckoutPaymentAndReviewComponent {
    constructor() {
        super(...arguments);
        this.checkoutStepTypePaymentType = CheckoutStepType.PAYMENT_TYPE;
        this.paymentType$ = this.activeCartFacade
            .getActive()
            .pipe(map$1((cart) => cart.paymentType));
        this.poNumber$ = this.checkoutPaymentTypeFacade.getPurchaseOrderNumberState().pipe(filter((state) => !state.loading && !state.error), map$1((state) => state.data));
        this.getSelectedPayment$ = this.opfBaseFacade.getActiveConfigurationsState();
        this.getSelectedPaymentId$ = this.opfMetadataStoreService
            .getOpfMetadataState()
            .pipe(take(1), map$1((data) => data?.selectedPaymentOptionId));
    }
    getPoNumberCard(poNumber) {
        return combineLatest([
            this.translationService.translate('opfCheckout.poNumber'),
            this.translationService.translate('opfCheckout.noPoNumber'),
        ]).pipe(map$1(([textTitle, noneTextTitle]) => {
            return {
                title: textTitle,
                textBold: normalizeEmpty(poNumber) ?? noneTextTitle,
            };
        }));
    }
    getPaymentMethodNameCard(methodName) {
        return combineLatest([
            this.translationService.translate('opfCheckout.paymentMethod'),
            this.translationService.translate('opfCheckout.noPaymentMethod'),
        ]).pipe(map$1(([title, noPaymentMethod]) => ({
            title,
            textBold: methodName ?? noPaymentMethod,
            text: [],
        })));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPaymentAndReviewComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfB2bCheckoutPaymentAndReviewComponent, isStandalone: true, selector: "cx-opf-b2b-checkout-payment-and-review", usesInheritance: true, ngImport: i0, template: "<ng-container\n  *ngIf=\"{\n    value: explicitTermsAndConditions$ | async,\n  } as explicitTermsAndConditions\"\n>\n  <div class=\"cx-opf-review-card-wrapper\">\n    <cx-opf-checkout-review-card\n      [cardContent$]=\"getPoNumberCard(poNumber$ | async)\"\n      [editConfig]=\"{\n        route: getCheckoutStepUrl(checkoutStepTypePaymentType),\n        ariaLabelKey: 'checkoutReview.editPoNumber',\n      }\"\n    ></cx-opf-checkout-review-card>\n    <cx-opf-checkout-review-card\n      [cardContent$]=\"\n        getPaymentMethodNameCard(\n          (selectedPaymentProviderName$ | async) || undefined\n        )\n      \"\n      [editConfig]=\"{\n        route: getCheckoutStepUrl(checkoutStepTypePaymentType),\n        ariaLabelKey: 'checkoutReview.editPaymentMethod',\n      }\"\n    ></cx-opf-checkout-review-card>\n    <cx-opf-checkout-review-card\n      *ngIf=\"deliveryAddress$ | async as deliveryAddress\"\n      [cardContent$]=\"getDeliveryAddressCard(deliveryAddress)\"\n      [editConfig]=\"{\n        route: getCheckoutStepUrl(checkoutStepTypeDeliveryAddress),\n        ariaLabelKey: 'checkoutReview.editDeliveryAddressDetails',\n      }\"\n    ></cx-opf-checkout-review-card>\n\n    <cx-opf-checkout-review-card\n      *ngIf=\"deliveryMode$ | async as deliveryMode\"\n      [cardContent$]=\"getDeliveryModeCard(deliveryMode)\"\n      [editConfig]=\"{\n        route: getCheckoutStepUrl(checkoutStepTypeDeliveryMode),\n        ariaLabelKey: 'checkoutReview.editDeliveryMode',\n      }\"\n    ></cx-opf-checkout-review-card>\n  </div>\n\n  <cx-opf-checkout-terms-and-conditions-alert\n    *ngIf=\"!explicitTermsAndConditions.value\"\n    [isDismissible]=\"true\"\n    [isVisible]=\"termsAndConditionInvalid\"\n    [isExplicit]=\"explicitTermsAndConditions.value\"\n    [ngClass]=\"['for-mobile']\"\n  ></cx-opf-checkout-terms-and-conditions-alert>\n\n  <div\n    *ngIf=\"explicitTermsAndConditions.value\"\n    class=\"cx-opf-terms-and-conditions\"\n    [attr.aria-label]=\"'opfCheckout.termsAndConditions' | cxTranslate\"\n  >\n    <h3>{{ 'opfCheckout.termsAndConditions' | cxTranslate }}</h3>\n\n    <form\n      class=\"cx-place-order-form form-check\"\n      [formGroup]=\"checkoutSubmitForm\"\n    >\n      <div class=\"form-group\">\n        <label>\n          <input\n            formControlName=\"termsAndConditions\"\n            class=\"scaled-input form-check-input\"\n            type=\"checkbox\"\n            (change)=\"toggleTermsAndConditions()\"\n          />\n          <span class=\"form-check-label\">\n            {{ 'checkoutReview.confirmThatRead' | cxTranslate }}\n            <a\n              [routerLink]=\"{ cxRoute: 'termsAndConditions' } | cxUrl\"\n              class=\"cx-tc-link\"\n              target=\"_blank\"\n              rel=\"noopener noreferrer\"\n            >\n              {{ 'checkoutReview.termsAndConditions' | cxTranslate }}\n            </a>\n          </span>\n        </label>\n      </div>\n    </form>\n  </div>\n\n  <cx-opf-checkout-billing-address-form></cx-opf-checkout-billing-address-form>\n\n  <cx-opf-checkout-payments\n    [onlyPaymentWrapperMode]=\"true\"\n    [showBeforePaymentOptionsOutlet]=\"false\"\n    [renderPaymentWrapper]=\"\n      !explicitTermsAndConditions.value ||\n      (explicitTermsAndConditions.value && !termsAndConditionInvalid)\n    \"\n    [noRenderPaymentWrapperMessage]=\"\n      'opfCheckout.termsAndConditionsDisclaimer' | cxTranslate\n    \"\n    (selectedPaymentProviderName)=\"onPaymentProviderSelected($event)\"\n    [hideOnlyOnePaymentProviderLabel]=\"true\"\n  >\n    <cx-opf-checkout-terms-and-conditions-alert\n      *ngIf=\"!explicitTermsAndConditions.value\"\n      [isDismissible]=\"true\"\n      [isVisible]=\"termsAndConditionInvalid\"\n      [isExplicit]=\"explicitTermsAndConditions.value\"\n      [ngClass]=\"['for-desktop']\"\n    ></cx-opf-checkout-terms-and-conditions-alert>\n  </cx-opf-checkout-payments>\n\n  <cx-opf-checkout-review-cart-details\n    [cart]=\"cart$ | async\"\n    [entries]=\"entries$ | async\"\n  ></cx-opf-checkout-review-cart-details>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: OpfCheckoutReviewCardComponent, selector: "cx-opf-checkout-review-card", inputs: ["cardContent$", "editConfig"] }, { kind: "component", type: OpfCheckoutTermsAndConditionsAlertComponent, selector: "cx-opf-checkout-terms-and-conditions-alert", inputs: ["isDismissible", "isVisible", "isExplicit"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: OpfCheckoutBillingAddressFormComponent, selector: "cx-opf-checkout-billing-address-form" }, { kind: "component", type: OpfCheckoutPaymentsComponent, selector: "cx-opf-checkout-payments", inputs: ["isHeadingDisplayed", "headingTranslationKey", "isPaymentRenderBelow", "isPaymentInfoMessageEnabled", "elementsPerPage", "disabled", "explicitTermsAndConditions", "onlyPaymentWrapperMode", "showBeforePaymentOptionsOutlet", "customPaymentTemplate", "hideOnlyOnePaymentProviderLabel", "forceRadioInputsView", "forceDefaultPaymentOptionInputSelection", "renderPaymentWrapper", "noRenderPaymentWrapperMessage"], outputs: ["paymentChange", "selectedPaymentProviderName"] }, { kind: "component", type: OpfCheckoutReviewCartDetailsComponent, selector: "cx-opf-checkout-review-cart-details", inputs: ["cart", "entries", "isAddressCardVisible"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPaymentAndReviewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-b2b-checkout-payment-and-review', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        OpfCheckoutReviewCardComponent,
                        OpfCheckoutTermsAndConditionsAlertComponent,
                        NgClass,
                        FormsModule,
                        ReactiveFormsModule,
                        RouterLink,
                        OpfCheckoutBillingAddressFormComponent,
                        OpfCheckoutPaymentsComponent,
                        OpfCheckoutReviewCartDetailsComponent,
                        AsyncPipe,
                        TranslatePipe,
                        UrlPipe,
                    ], template: "<ng-container\n  *ngIf=\"{\n    value: explicitTermsAndConditions$ | async,\n  } as explicitTermsAndConditions\"\n>\n  <div class=\"cx-opf-review-card-wrapper\">\n    <cx-opf-checkout-review-card\n      [cardContent$]=\"getPoNumberCard(poNumber$ | async)\"\n      [editConfig]=\"{\n        route: getCheckoutStepUrl(checkoutStepTypePaymentType),\n        ariaLabelKey: 'checkoutReview.editPoNumber',\n      }\"\n    ></cx-opf-checkout-review-card>\n    <cx-opf-checkout-review-card\n      [cardContent$]=\"\n        getPaymentMethodNameCard(\n          (selectedPaymentProviderName$ | async) || undefined\n        )\n      \"\n      [editConfig]=\"{\n        route: getCheckoutStepUrl(checkoutStepTypePaymentType),\n        ariaLabelKey: 'checkoutReview.editPaymentMethod',\n      }\"\n    ></cx-opf-checkout-review-card>\n    <cx-opf-checkout-review-card\n      *ngIf=\"deliveryAddress$ | async as deliveryAddress\"\n      [cardContent$]=\"getDeliveryAddressCard(deliveryAddress)\"\n      [editConfig]=\"{\n        route: getCheckoutStepUrl(checkoutStepTypeDeliveryAddress),\n        ariaLabelKey: 'checkoutReview.editDeliveryAddressDetails',\n      }\"\n    ></cx-opf-checkout-review-card>\n\n    <cx-opf-checkout-review-card\n      *ngIf=\"deliveryMode$ | async as deliveryMode\"\n      [cardContent$]=\"getDeliveryModeCard(deliveryMode)\"\n      [editConfig]=\"{\n        route: getCheckoutStepUrl(checkoutStepTypeDeliveryMode),\n        ariaLabelKey: 'checkoutReview.editDeliveryMode',\n      }\"\n    ></cx-opf-checkout-review-card>\n  </div>\n\n  <cx-opf-checkout-terms-and-conditions-alert\n    *ngIf=\"!explicitTermsAndConditions.value\"\n    [isDismissible]=\"true\"\n    [isVisible]=\"termsAndConditionInvalid\"\n    [isExplicit]=\"explicitTermsAndConditions.value\"\n    [ngClass]=\"['for-mobile']\"\n  ></cx-opf-checkout-terms-and-conditions-alert>\n\n  <div\n    *ngIf=\"explicitTermsAndConditions.value\"\n    class=\"cx-opf-terms-and-conditions\"\n    [attr.aria-label]=\"'opfCheckout.termsAndConditions' | cxTranslate\"\n  >\n    <h3>{{ 'opfCheckout.termsAndConditions' | cxTranslate }}</h3>\n\n    <form\n      class=\"cx-place-order-form form-check\"\n      [formGroup]=\"checkoutSubmitForm\"\n    >\n      <div class=\"form-group\">\n        <label>\n          <input\n            formControlName=\"termsAndConditions\"\n            class=\"scaled-input form-check-input\"\n            type=\"checkbox\"\n            (change)=\"toggleTermsAndConditions()\"\n          />\n          <span class=\"form-check-label\">\n            {{ 'checkoutReview.confirmThatRead' | cxTranslate }}\n            <a\n              [routerLink]=\"{ cxRoute: 'termsAndConditions' } | cxUrl\"\n              class=\"cx-tc-link\"\n              target=\"_blank\"\n              rel=\"noopener noreferrer\"\n            >\n              {{ 'checkoutReview.termsAndConditions' | cxTranslate }}\n            </a>\n          </span>\n        </label>\n      </div>\n    </form>\n  </div>\n\n  <cx-opf-checkout-billing-address-form></cx-opf-checkout-billing-address-form>\n\n  <cx-opf-checkout-payments\n    [onlyPaymentWrapperMode]=\"true\"\n    [showBeforePaymentOptionsOutlet]=\"false\"\n    [renderPaymentWrapper]=\"\n      !explicitTermsAndConditions.value ||\n      (explicitTermsAndConditions.value && !termsAndConditionInvalid)\n    \"\n    [noRenderPaymentWrapperMessage]=\"\n      'opfCheckout.termsAndConditionsDisclaimer' | cxTranslate\n    \"\n    (selectedPaymentProviderName)=\"onPaymentProviderSelected($event)\"\n    [hideOnlyOnePaymentProviderLabel]=\"true\"\n  >\n    <cx-opf-checkout-terms-and-conditions-alert\n      *ngIf=\"!explicitTermsAndConditions.value\"\n      [isDismissible]=\"true\"\n      [isVisible]=\"termsAndConditionInvalid\"\n      [isExplicit]=\"explicitTermsAndConditions.value\"\n      [ngClass]=\"['for-desktop']\"\n    ></cx-opf-checkout-terms-and-conditions-alert>\n  </cx-opf-checkout-payments>\n\n  <cx-opf-checkout-review-cart-details\n    [cart]=\"cart$ | async\"\n    [entries]=\"entries$ | async\"\n  ></cx-opf-checkout-review-cart-details>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfB2bCheckoutPaymentAndReviewModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPaymentAndReviewModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPaymentAndReviewModule, imports: [CommonModule,
            I18nModule,
            OpfCheckoutPaymentsModule,
            UrlModule,
            ReactiveFormsModule,
            RouterModule,
            OpfCheckoutBillingAddressFormModule,
            AddressFormModule,
            OutletModule,
            PromotionsModule,
            IconModule,
            CardModule,
            OpfCheckoutTermsAndConditionsAlertModule,
            OpfCheckoutPaymentWrapperModule,
            OpfCheckoutReviewCardModule,
            OpfCheckoutReviewCartDetailsModule,
            OpfB2bCheckoutPaymentAndReviewComponent], exports: [OpfB2bCheckoutPaymentAndReviewComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPaymentAndReviewModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    OpfB2bCheckoutPaymentAndReview: {
                        component: OpfB2bCheckoutPaymentAndReviewComponent,
                        guards: [CheckoutAuthGuard, CartNotEmptyGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            OpfCheckoutPaymentsModule,
            UrlModule,
            ReactiveFormsModule,
            RouterModule,
            OpfCheckoutBillingAddressFormModule,
            AddressFormModule,
            OutletModule,
            PromotionsModule,
            IconModule,
            CardModule,
            OpfCheckoutTermsAndConditionsAlertModule,
            OpfCheckoutPaymentWrapperModule,
            OpfCheckoutReviewCardModule,
            OpfCheckoutReviewCartDetailsModule,
            OpfB2bCheckoutPaymentAndReviewComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPaymentAndReviewModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        OpfCheckoutPaymentsModule,
                        UrlModule,
                        ReactiveFormsModule,
                        RouterModule,
                        OpfCheckoutBillingAddressFormModule,
                        AddressFormModule,
                        OutletModule,
                        PromotionsModule,
                        IconModule,
                        CardModule,
                        OpfCheckoutTermsAndConditionsAlertModule,
                        OpfCheckoutPaymentWrapperModule,
                        OpfCheckoutReviewCardModule,
                        OpfCheckoutReviewCartDetailsModule,
                        OpfB2bCheckoutPaymentAndReviewComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                OpfB2bCheckoutPaymentAndReview: {
                                    component: OpfB2bCheckoutPaymentAndReviewComponent,
                                    guards: [CheckoutAuthGuard, CartNotEmptyGuard],
                                },
                            },
                        }),
                    ],
                    exports: [OpfB2bCheckoutPaymentAndReviewComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfB2bCheckoutComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutComponentsModule, imports: [OpfB2bCheckoutPaymentTypeModule,
            OpfB2bCheckoutReviewModule,
            OpfB2bCheckoutPaymentAndReviewModule,
            OpfB2bCheckoutDeliveryAddressModule,
            OpfB2bCheckoutCostCenterModule,
            OpfB2bCheckoutPlaceOrderModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutComponentsModule, imports: [OpfB2bCheckoutPaymentTypeModule,
            OpfB2bCheckoutReviewModule,
            OpfB2bCheckoutPaymentAndReviewModule,
            OpfB2bCheckoutDeliveryAddressModule,
            OpfB2bCheckoutCostCenterModule,
            OpfB2bCheckoutPlaceOrderModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        OpfB2bCheckoutPaymentTypeModule,
                        OpfB2bCheckoutReviewModule,
                        OpfB2bCheckoutPaymentAndReviewModule,
                        OpfB2bCheckoutDeliveryAddressModule,
                        OpfB2bCheckoutCostCenterModule,
                        OpfB2bCheckoutPlaceOrderModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfB2bCheckoutComponentsModule, OpfB2bCheckoutCostCenterComponent, OpfB2bCheckoutCostCenterModule, OpfB2bCheckoutDeliveryAddressComponent, OpfB2bCheckoutDeliveryAddressModule, OpfB2bCheckoutPaymentAndReviewComponent, OpfB2bCheckoutPaymentAndReviewModule, OpfB2bCheckoutPaymentTypeComponent, OpfB2bCheckoutPaymentTypeModule, OpfB2bCheckoutPlaceOrderComponent, OpfB2bCheckoutPlaceOrderModule, OpfB2bCheckoutReviewComponent, OpfB2bCheckoutReviewModule };
//# sourceMappingURL=spartacus-opf-b2b-checkout-components.mjs.map
