import * as rxjs from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { OccEndpointsService, OccEndpoint } from '@spartacus/core';
import { RequestedDeliveryDateAdapter } from '@spartacus/requested-delivery-date/core';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare class OccRequestedDeliveryDateAdapter implements RequestedDeliveryDateAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService);
    setRequestedDeliveryDate(userId: string, cartId: string, requestedRetrievalAt: string): rxjs.Observable<Object>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccRequestedDeliveryDateAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccRequestedDeliveryDateAdapter>;
}

declare module '@spartacus/core' {
    interface OccEndpoints {
        /**
         * Endpoint for requested delivery date
         *
         * @member {string}
         */
        requestedDeliveryDate?: string | OccEndpoint;
    }
}

declare class RequestedDeliveryDateOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RequestedDeliveryDateOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RequestedDeliveryDateOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RequestedDeliveryDateOccModule>;
}

export { OccRequestedDeliveryDateAdapter, RequestedDeliveryDateOccModule };
