import { HttpErrorResponse } from '@angular/common/http';
import * as i0 from '@angular/core';
import { OnInit, OnDestroy } from '@angular/core';
import * as i4 from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { Cart } from '@spartacus/cart/base/root';
import * as i3 from '@spartacus/core';
import { CxDatePipe, EventService, TranslationService, GlobalMessageService, ErrorModel, CmsConfig } from '@spartacus/core';
import * as i2 from '@spartacus/storefront';
import { OutletContextData, Card } from '@spartacus/storefront';
import { Observable, Subscription } from 'rxjs';
import { Order } from '@spartacus/order/root';
import * as i1 from '@angular/common';

declare function requestedDeliveryDateFacadeFactory(): RequestedDeliveryDateFacade;
declare abstract class RequestedDeliveryDateFacade {
    /**
     * Set the requested delivery date
     */
    abstract setRequestedDeliveryDate(userId: string, cartId: string, requestedDate: string): Observable<{}>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RequestedDeliveryDateFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RequestedDeliveryDateFacade>;
}

declare class DateValidationService {
    /**
     * Validates if the string is containing a date string.
     * @param value Date string in the format 'dd-mm-yyy'
     * @returns true if valid, false if invalid
     */
    isDateStringValid(value: string | undefined): boolean;
    /**
     * Returns a Date object from a date string in the format 'dd-mm-yyy'
     * @param value Date string in the format 'dd-mm-yyy'
     */
    getDateFromDateString(value: string): Date;
    /**
     * Checks if the source date is greater than or equal to the target
     * @param source Date string in the format 'dd-mm-yyy'
     * @param target Date string in the format 'dd-mm-yyy'
     * @returns true if `source` date is greater than or equal to `target` date
     */
    isDateGreaterOrEqual(source: string, target: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateValidationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DateValidationService>;
}

declare class DeliveryModeDatePickerComponent implements OnInit, OnDestroy {
    protected datePipe: CxDatePipe;
    protected requestedDelDateFacade: RequestedDeliveryDateFacade;
    protected dateValidationService: DateValidationService;
    protected eventService: EventService;
    protected translation: TranslationService;
    protected globalMessageService: GlobalMessageService;
    protected deliveryOutlet?: OutletContextData | undefined;
    constructor(datePipe: CxDatePipe, requestedDelDateFacade: RequestedDeliveryDateFacade, dateValidationService: DateValidationService, eventService: EventService, translation: TranslationService, globalMessageService: GlobalMessageService, deliveryOutlet?: OutletContextData | undefined);
    protected cartEntry: Cart;
    protected subscription: Subscription;
    protected earliestRetrievalAt: string | undefined;
    protected requestedRetrievalAt: string | undefined;
    protected form: FormGroup;
    protected isDatePickerReadOnly: boolean;
    ngOnInit(): void;
    isEarliestRetrievalDatePresent(): boolean;
    isRequestedDeliveryDatePresent(): boolean;
    getRequestedDeliveryDateCardContent(isoDate: string | null): Observable<Card>;
    setRequestedDeliveryDate(): void;
    getErrors(response: HttpErrorResponse): ErrorModel[];
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeliveryModeDatePickerComponent, [null, null, null, null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeliveryModeDatePickerComponent, "cx-request-delivery-date", never, {}, {}, never, never, true, never>;
}

declare class OrderOverviewDeliveryDateComponent implements OnInit, OnDestroy {
    protected dateValidationService: DateValidationService;
    protected translation: TranslationService;
    protected orderOutlet?: OutletContextData | undefined;
    constructor(dateValidationService: DateValidationService, translation: TranslationService, orderOutlet?: OutletContextData | undefined);
    protected subscription: Subscription;
    order: Order;
    ngOnInit(): void;
    isRequestedDeliveryDatePresent(): boolean;
    getRequestedDeliveryDateCardContent(isoDate: string | null): Observable<Card>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderOverviewDeliveryDateComponent, [null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderOverviewDeliveryDateComponent, "cx-order-overview-delivery-date", never, {}, {}, never, never, true, never>;
}

declare class RequestedDeliveryDateComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RequestedDeliveryDateComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RequestedDeliveryDateComponentsModule, never, [typeof i1.CommonModule, typeof i2.DatePickerModule, typeof i3.I18nModule, typeof i4.ReactiveFormsModule, typeof i2.CardModule, typeof DeliveryModeDatePickerComponent, typeof OrderOverviewDeliveryDateComponent], [typeof DeliveryModeDatePickerComponent, typeof OrderOverviewDeliveryDateComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RequestedDeliveryDateComponentsModule>;
}

declare const REQUESTED_DELIVERY_DATE_FEATURE = "requestedDeliveryDate";
declare const REQUESTED_DELIVERY_DATE_CORE_FEATURE = "requestedDeliveryDateCore";

declare module '@spartacus/cart/base/root' {
    interface Cart {
        earliestRetrievalAt?: string;
        requestedRetrievalAt?: string;
    }
}
declare module '@spartacus/order/root' {
    interface Order {
        requestedRetrievalAt?: string;
    }
}

declare function defaultRequestedDeliveryDateComponentsConfig(): CmsConfig;
declare class RequestedDeliveryDateRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RequestedDeliveryDateRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RequestedDeliveryDateRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RequestedDeliveryDateRootModule>;
}

export { DeliveryModeDatePickerComponent, OrderOverviewDeliveryDateComponent, REQUESTED_DELIVERY_DATE_CORE_FEATURE, REQUESTED_DELIVERY_DATE_FEATURE, RequestedDeliveryDateComponentsModule, RequestedDeliveryDateFacade, RequestedDeliveryDateRootModule, defaultRequestedDeliveryDateComponentsConfig, requestedDeliveryDateFacadeFactory };
