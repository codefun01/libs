import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import { RequestedDeliveryDateFacade } from '@spartacus/requested-delivery-date/root';

declare abstract class RequestedDeliveryDateAdapter {
    /**
     * Abstract method used to set the requested delivery date for a cart entry
     */
    abstract setRequestedDeliveryDate(userId: string, cartId: string, requestedDate: string): Observable<{}>;
}

declare class RequestedDeliveryDateConnector {
    protected adapter: RequestedDeliveryDateAdapter;
    constructor(adapter: RequestedDeliveryDateAdapter);
    setRequestedDeliveryDate(userId: string, cartId: string, requestedDate: string): Observable<{}>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RequestedDeliveryDateConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RequestedDeliveryDateConnector>;
}

declare class RequestedDeliveryDateCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RequestedDeliveryDateCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RequestedDeliveryDateCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RequestedDeliveryDateCoreModule>;
}

declare class RequestedDeliveryDateService implements RequestedDeliveryDateFacade {
    protected requestedDeliveryDateConnector: RequestedDeliveryDateConnector;
    /**
     * Set requested delivery date
     */
    setRequestedDeliveryDate(userId: string, cartId: string, requestedDate: string): Observable<{}>;
    constructor(requestedDeliveryDateConnector: RequestedDeliveryDateConnector);
    static ɵfac: i0.ɵɵFactoryDeclaration<RequestedDeliveryDateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RequestedDeliveryDateService>;
}

export { RequestedDeliveryDateAdapter, RequestedDeliveryDateConnector, RequestedDeliveryDateCoreModule, RequestedDeliveryDateService };
