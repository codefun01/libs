import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    requestedDeliveryDate: {
        requestedDeliveryDate: {
            datePickerLabel: string;
            readOnlyTextLabel: string;
            successMessage: string;
            errorMessage: string;
        };
    };
};

declare const de: {
    requestedDeliveryDate: {
        requestedDeliveryDate: {
            datePickerLabel: string;
            readOnlyTextLabel: string;
            successMessage: string;
            errorMessage: string;
        };
    };
};

declare const en: {
    requestedDeliveryDate: {
        requestedDeliveryDate: {
            datePickerLabel: string;
            readOnlyTextLabel: string;
            successMessage: string;
            errorMessage: string;
        };
    };
};

declare const es: {
    requestedDeliveryDate: {
        requestedDeliveryDate: {
            datePickerLabel: string;
            readOnlyTextLabel: string;
            successMessage: string;
            errorMessage: string;
        };
    };
};

declare const es_CO: {
    requestedDeliveryDate: {
        requestedDeliveryDate: {
            datePickerLabel: string;
            readOnlyTextLabel: string;
            successMessage: string;
            errorMessage: string;
        };
    };
};

declare const fr: {
    requestedDeliveryDate: {
        requestedDeliveryDate: {
            datePickerLabel: string;
            readOnlyTextLabel: string;
            successMessage: string;
            errorMessage: string;
        };
    };
};

declare const hi: {
    requestedDeliveryDate: {
        requestedDeliveryDate: {
            datePickerLabel: string;
            readOnlyTextLabel: string;
            successMessage: string;
            errorMessage: string;
        };
    };
};

declare const hu: {
    requestedDeliveryDate: {
        requestedDeliveryDate: {
            datePickerLabel: string;
            readOnlyTextLabel: string;
            successMessage: string;
            errorMessage: string;
        };
    };
};

declare const id: {
    requestedDeliveryDate: {
        requestedDeliveryDate: {
            datePickerLabel: string;
            readOnlyTextLabel: string;
            successMessage: string;
            errorMessage: string;
        };
    };
};

declare const it: {
    requestedDeliveryDate: {
        requestedDeliveryDate: {
            datePickerLabel: string;
            readOnlyTextLabel: string;
            successMessage: string;
            errorMessage: string;
        };
    };
};

declare const ja: {
    requestedDeliveryDate: {
        requestedDeliveryDate: {
            datePickerLabel: string;
            readOnlyTextLabel: string;
            successMessage: string;
            errorMessage: string;
        };
    };
};

declare const ko: {
    requestedDeliveryDate: {
        requestedDeliveryDate: {
            datePickerLabel: string;
            readOnlyTextLabel: string;
            successMessage: string;
            errorMessage: string;
        };
    };
};

declare const pl: {
    requestedDeliveryDate: {
        requestedDeliveryDate: {
            datePickerLabel: string;
            readOnlyTextLabel: string;
            successMessage: string;
            errorMessage: string;
        };
    };
};

declare const pt: {
    requestedDeliveryDate: {
        requestedDeliveryDate: {
            datePickerLabel: string;
            readOnlyTextLabel: string;
            successMessage: string;
            errorMessage: string;
        };
    };
};

declare const ru: {
    requestedDeliveryDate: {
        requestedDeliveryDate: {
            datePickerLabel: string;
            readOnlyTextLabel: string;
            successMessage: string;
            errorMessage: string;
        };
    };
};

declare const zh: {
    requestedDeliveryDate: {
        requestedDeliveryDate: {
            datePickerLabel: string;
            readOnlyTextLabel: string;
            successMessage: string;
            errorMessage: string;
        };
    };
};

declare const zh_TW: {
    requestedDeliveryDate: {
        requestedDeliveryDate: {
            datePickerLabel: string;
            readOnlyTextLabel: string;
            successMessage: string;
            errorMessage: string;
        };
    };
};

declare const requestedDeliveryDateTranslationChunksConfig: TranslationChunksConfig;

export { requestedDeliveryDateTranslationChunksConfig, cs as requestedDeliveryDateTranslationsCs, de as requestedDeliveryDateTranslationsDe, en as requestedDeliveryDateTranslationsEn, es as requestedDeliveryDateTranslationsEs, es_CO as requestedDeliveryDateTranslationsEs_CO, fr as requestedDeliveryDateTranslationsFr, hi as requestedDeliveryDateTranslationsHi, hu as requestedDeliveryDateTranslationsHu, id as requestedDeliveryDateTranslationsId, it as requestedDeliveryDateTranslationsIt, ja as requestedDeliveryDateTranslationsJa, ko as requestedDeliveryDateTranslationsKo, pl as requestedDeliveryDateTranslationsPl, pt as requestedDeliveryDateTranslationsPt, ru as requestedDeliveryDateTranslationsRu, zh as requestedDeliveryDateTranslationsZh, zh_TW as requestedDeliveryDateTranslationsZh_TW };
