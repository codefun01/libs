import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { RequestedDeliveryDateCoreModule } from '@spartacus/requested-delivery-date/core';
import { RequestedDeliveryDateOccModule } from '@spartacus/requested-delivery-date/occ';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class RequestedDeliveryDateModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RequestedDeliveryDateModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: RequestedDeliveryDateModule, imports: [RequestedDeliveryDateCoreModule, RequestedDeliveryDateOccModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RequestedDeliveryDateModule, imports: [RequestedDeliveryDateCoreModule, RequestedDeliveryDateOccModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: RequestedDeliveryDateModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [RequestedDeliveryDateCoreModule, RequestedDeliveryDateOccModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/*
 * Public API Surface of requested-delivery-date
 */

/**
 * Generated bundle index. Do not edit.
 */

export { RequestedDeliveryDateModule };
//# sourceMappingURL=spartacus-requested-delivery-date.mjs.map
