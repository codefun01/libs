import * as i0 from '@angular/core';
import { OnInit, PipeTransform, EventEmitter, OnDestroy, ViewContainerRef, ComponentRef, AfterViewInit } from '@angular/core';
import * as i1 from '@angular/common';
import * as i1$1 from '@spartacus/storefront';
import { LaunchDialogService, Card, ICON_TYPE, SelectFocusUtility } from '@spartacus/storefront';
import * as _spartacus_cart_base_root from '@spartacus/cart/base/root';
import { ActiveCartFacade, Cart, CartOutlets, DeliveryMode, PromotionLocation, OrderEntry } from '@spartacus/cart/base/root';
import { Observable, BehaviorSubject, Subscription } from 'rxjs';
import * as i2 from '@spartacus/core';
import { BaseSiteService, RoutingService, RoutingConfigService, GlobalMessageService, Address, Country, Region, UserPaymentService, UserAddressService, TranslationService, AddressValidation, CardType, PaymentDetails, WindowRef, AuthRedirectService, SemanticPathService, AuthService, LoggerService } from '@spartacus/core';
import * as i3 from '@angular/router';
import { ActivatedRoute, Router, GuardResult, UrlTree, ActivatedRouteSnapshot } from '@angular/router';
import * as _spartacus_checkout_base_root from '@spartacus/checkout/base/root';
import { CheckoutConfig, CheckoutFlow, CheckoutStep, CheckoutStepType, CheckoutStepState, CheckoutDeliveryModesFacade, CheckoutDeliveryAddressFacade, CheckoutPaymentFacade } from '@spartacus/checkout/base/root';
import * as i3$1 from '@angular/forms';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import * as i4 from '@ng-select/ng-select';
import { OrderFacade } from '@spartacus/order/root';
import * as i3$2 from '@spartacus/user/profile/components';

declare class CheckoutOrchestratorComponent {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutOrchestratorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutOrchestratorComponent, "cx-checkout-orchestrator", never, {}, {}, never, never, true, never>;
}

declare class CheckoutOrchestratorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutOrchestratorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutOrchestratorModule, never, [typeof i1.CommonModule, typeof CheckoutOrchestratorComponent], [typeof CheckoutOrchestratorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutOrchestratorModule>;
}

declare class CheckoutOrderSummaryComponent {
    protected activeCartFacade: ActiveCartFacade;
    cart$: Observable<Cart>;
    readonly cartOutlets: typeof CartOutlets;
    constructor(activeCartFacade: ActiveCartFacade);
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutOrderSummaryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutOrderSummaryComponent, "cx-checkout-order-summary", never, {}, {}, never, never, true, never>;
}

declare class CheckoutOrderSummaryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutOrderSummaryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutOrderSummaryModule, never, [typeof i1.CommonModule, typeof i1$1.OutletModule, typeof CheckoutOrderSummaryComponent], [typeof CheckoutOrderSummaryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutOrderSummaryModule>;
}

declare class CheckoutFlowOrchestratorService {
    protected checkoutConfig: CheckoutConfig;
    protected baseSiteService: BaseSiteService;
    constructor();
    protected paymentProviderName: string | undefined;
    getPaymentProvider(): Observable<string | undefined>;
    getCheckoutFlow(): CheckoutFlow | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutFlowOrchestratorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutFlowOrchestratorService>;
}

declare class CheckoutStepService {
    protected routingService: RoutingService;
    protected checkoutConfig: CheckoutConfig;
    protected routingConfigService: RoutingConfigService;
    protected checkoutFlowOrchestratorService: CheckoutFlowOrchestratorService;
    allSteps: CheckoutStep[];
    readonly steps$: BehaviorSubject<CheckoutStep[]>;
    readonly activeStepIndex$: Observable<number>;
    constructor(routingService: RoutingService, checkoutConfig: CheckoutConfig, routingConfigService: RoutingConfigService);
    back(activatedRoute: ActivatedRoute): void;
    next(activatedRoute: ActivatedRoute): void;
    goToStepWithIndex(stepIndex: number): void;
    getBackBntText(activatedRoute: ActivatedRoute): string;
    resetSteps(): void;
    disableEnableStep(currentStepType: CheckoutStepType | string, disabled: boolean): void;
    getCheckoutStep(currentStepType: CheckoutStepType): CheckoutStep | undefined;
    getCheckoutStepRoute(currentStepType: CheckoutStepType): string | undefined;
    getFirstCheckoutStepRoute(): string;
    getNextCheckoutStepUrl(activatedRoute: ActivatedRoute): string | null;
    getPreviousCheckoutStepUrl(activatedRoute: ActivatedRoute): string | null;
    getCurrentStepIndex(activatedRoute: ActivatedRoute): number | null;
    private getStepUrlFromActivatedRoute;
    private getStepUrlFromStepRoute;
    private getCheckoutStepIndex;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutStepService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutStepService>;
}

declare class CheckoutProgressComponent implements OnInit {
    protected checkoutStepService: CheckoutStepService;
    params$: Observable<string[]>;
    private _steps$;
    private currencyService;
    private languageService;
    constructor(checkoutStepService: CheckoutStepService);
    activeStepIndex: number;
    activeStepIndex$: Observable<number>;
    get steps$(): Observable<CheckoutStep[]>;
    ngOnInit(): void;
    getTabIndex(stepIndex: number): number;
    isActive(index: number): boolean;
    isDisabled(index: number): boolean;
    getStepState(index: number): CheckoutStepState;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutProgressComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutProgressComponent, "cx-checkout-progress", never, {}, {}, never, never, true, never>;
}

declare class MultiLinePipe implements PipeTransform {
    transform(value: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiLinePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<MultiLinePipe, "cxMultiLine", true>;
}

declare class CheckoutProgressModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutProgressModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutProgressModule, never, [typeof i1.CommonModule, typeof i2.UrlModule, typeof i2.I18nModule, typeof i3.RouterModule, typeof CheckoutProgressComponent, typeof MultiLinePipe], [typeof CheckoutProgressComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutProgressModule>;
}

declare class CheckoutProgressMobileTopComponent {
    protected activeCartFacade: ActiveCartFacade;
    protected checkoutStepService: CheckoutStepService;
    private _steps$;
    cart$: Observable<Cart>;
    constructor(activeCartFacade: ActiveCartFacade, checkoutStepService: CheckoutStepService);
    activeStepIndex: number;
    activeStepIndex$: Observable<number>;
    get steps$(): Observable<CheckoutStep[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutProgressMobileTopComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutProgressMobileTopComponent, "cx-checkout-progress-mobile-top", never, {}, {}, never, never, true, never>;
}

declare class CheckoutProgressMobileTopModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutProgressMobileTopModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutProgressMobileTopModule, never, [typeof i1.CommonModule, typeof i2.UrlModule, typeof i2.I18nModule, typeof i3.RouterModule, typeof CheckoutProgressMobileTopComponent], [typeof CheckoutProgressMobileTopComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutProgressMobileTopModule>;
}

declare class CheckoutProgressMobileBottomComponent {
    protected checkoutStepService: CheckoutStepService;
    private _steps$;
    constructor(checkoutStepService: CheckoutStepService);
    activeStepIndex: number;
    activeStepIndex$: Observable<number>;
    get steps$(): Observable<CheckoutStep[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutProgressMobileBottomComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutProgressMobileBottomComponent, "cx-checkout-progress-mobile-bottom", never, {}, {}, never, never, true, never>;
}

declare class CheckoutProgressMobileBottomModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutProgressMobileBottomModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutProgressMobileBottomModule, never, [typeof i1.CommonModule, typeof i2.UrlModule, typeof i2.I18nModule, typeof i3.RouterModule, typeof CheckoutProgressMobileBottomComponent], [typeof CheckoutProgressMobileBottomComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutProgressMobileBottomModule>;
}

declare class CheckoutConfigService {
    private checkoutConfig;
    protected checkoutFlowOrchestratorService: CheckoutFlowOrchestratorService;
    private express;
    private guest;
    private defaultDeliveryMode;
    protected checkoutFlow: _spartacus_checkout_base_root.CheckoutFlow | undefined;
    constructor(checkoutConfig: CheckoutConfig);
    protected compareDeliveryCost(deliveryMode1: DeliveryMode, deliveryMode2: DeliveryMode): number;
    protected findMatchingDeliveryMode(deliveryModes: DeliveryMode[], index?: number): string | undefined;
    shouldUseAddressSavedInCart(): boolean;
    getPreferredDeliveryMode(deliveryModes: DeliveryMode[]): string | undefined;
    isExpressCheckout(): boolean;
    isGuestCheckout(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutConfigService>;
}

declare class CheckoutDeliveryModeComponent {
    protected fb: UntypedFormBuilder;
    protected checkoutConfigService: CheckoutConfigService;
    protected activatedRoute: ActivatedRoute;
    protected checkoutStepService: CheckoutStepService;
    protected checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade;
    protected activeCartFacade: ActiveCartFacade;
    protected globalMessageService: GlobalMessageService;
    protected busy$: BehaviorSubject<boolean>;
    protected readonly isSetDeliveryModeHttpErrorSub: BehaviorSubject<boolean>;
    readonly CartOutlets: typeof CartOutlets;
    isSetDeliveryModeHttpError$: Observable<boolean>;
    selectedDeliveryModeCode$: Observable<string | undefined>;
    supportedDeliveryModes$: Observable<_spartacus_cart_base_root.DeliveryMode[]>;
    backBtnText: string;
    mode: UntypedFormGroup;
    isUpdating$: Observable<boolean>;
    get deliveryModeInvalid(): boolean;
    constructor(fb: UntypedFormBuilder, checkoutConfigService: CheckoutConfigService, activatedRoute: ActivatedRoute, checkoutStepService: CheckoutStepService, checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade, activeCartFacade: ActiveCartFacade);
    changeMode(code: string | undefined, event?: Event): void;
    next(): void;
    back(): void;
    getAriaChecked(code: string | undefined): boolean;
    protected onSuccess(): void;
    protected onError(): void;
    /**
     * Restores focus after data is updated.
     */
    protected restoreFocus(lastFocusedId: string, code: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutDeliveryModeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutDeliveryModeComponent, "cx-delivery-mode", never, {}, {}, never, never, true, never>;
}

declare class CheckoutDeliveryModeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutDeliveryModeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutDeliveryModeModule, never, [typeof i1.CommonModule, typeof i3$1.ReactiveFormsModule, typeof i2.I18nModule, typeof i1$1.SpinnerModule, typeof i1$1.OutletModule, typeof i1$1.PageComponentModule, typeof i2.FeaturesConfigModule, typeof CheckoutDeliveryModeComponent], [typeof CheckoutDeliveryModeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutDeliveryModeModule>;
}

declare class CheckoutBillingAddressFormService {
    protected fb: UntypedFormBuilder;
    protected billingAddress: Address | undefined;
    private form;
    getBillingAddressForm(): UntypedFormGroup;
    setDeliveryAddressAsBillingAddress(address: Address | undefined): void;
    isBillingAddressSameAsDeliveryAddress(): boolean;
    isBillingAddressFormValid(): boolean;
    markAllAsTouched(): void;
    getBillingAddress(): Address;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutBillingAddressFormService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutBillingAddressFormService>;
}

declare class CheckoutBillingAddressFormComponent implements OnInit {
    showSameAsDeliveryAddressCheckbox$: Observable<boolean>;
    sameAsDeliveryAddress: boolean;
    deliveryAddress$: Observable<Address | undefined>;
    countries$: Observable<Country[]>;
    regions$: Observable<Region[]>;
    selectedCountry$: BehaviorSubject<string>;
    protected checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade;
    protected userPaymentService: UserPaymentService;
    protected globalMessageService: GlobalMessageService;
    protected userAddressService: UserAddressService;
    protected launchDialogService: LaunchDialogService;
    protected translationService: TranslationService;
    protected billingAddressFormService: CheckoutBillingAddressFormService;
    ngOnInit(): void;
    billingAddressForm: UntypedFormGroup;
    toggleSameAsDeliveryAddress(): void;
    /**
     *TODO: This method is not used, but should be. It triggers suggested addresses modal under the hood.
     *
     * See ticket CXSPA-1276
     */
    verifyAddress(): void;
    protected handleAddressVerificationResults(results: AddressValidation): void;
    countrySelected(country: Country): void;
    openSuggestedAddress(results: AddressValidation): void;
    getAddressCardContent(address: Address): Observable<Card>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutBillingAddressFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutBillingAddressFormComponent, "cx-checkout-billing-address-form", never, {}, {}, never, never, true, never>;
}

declare class CheckoutBillingAddressFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutBillingAddressFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutBillingAddressFormModule, never, [typeof i1$1.NgSelectA11yModule, typeof i1.CommonModule, typeof i3$1.ReactiveFormsModule, typeof i4.NgSelectModule, typeof i1$1.CardModule, typeof i2.I18nModule, typeof i1$1.IconModule, typeof i1$1.SpinnerModule, typeof i1$1.FormErrorsModule, typeof i2.FeaturesConfigModule, typeof i1$1.FormRequiredAsterisksComponent, typeof i1$1.FormRequiredLegendComponent, typeof CheckoutBillingAddressFormComponent], [typeof CheckoutBillingAddressFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutBillingAddressFormModule>;
}

declare class CheckoutPaymentFormComponent implements OnInit {
    protected checkoutPaymentFacade: CheckoutPaymentFacade;
    protected checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade;
    protected userPaymentService: UserPaymentService;
    protected globalMessageService: GlobalMessageService;
    protected fb: UntypedFormBuilder;
    protected userAddressService: UserAddressService;
    protected launchDialogService: LaunchDialogService;
    protected translationService: TranslationService;
    iconTypes: typeof ICON_TYPE;
    months: string[];
    years: number[];
    cardTypes$: Observable<CardType[]>;
    loading: boolean;
    setAsDefaultField: boolean;
    paymentMethodsCount: number;
    paymentDetails?: PaymentDetails;
    goBack: EventEmitter<any>;
    closeForm: EventEmitter<any>;
    setPaymentDetails: EventEmitter<any>;
    paymentForm: UntypedFormGroup;
    protected billingAddressService: CheckoutBillingAddressFormService;
    constructor(checkoutPaymentFacade: CheckoutPaymentFacade, checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade, userPaymentService: UserPaymentService, globalMessageService: GlobalMessageService, fb: UntypedFormBuilder, userAddressService: UserAddressService, launchDialogService: LaunchDialogService, translationService: TranslationService);
    /**
     * @deprecated  This property is obsolete since 2211.42
     */
    useExtractedBillingAddressComponent: boolean;
    ngOnInit(): void;
    expMonthAndYear(): void;
    toggleDefaultPaymentMethod(): void;
    close(): void;
    back(): void;
    next(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPaymentFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutPaymentFormComponent, "cx-payment-form", never, { "loading": { "alias": "loading"; "required": false; }; "setAsDefaultField": { "alias": "setAsDefaultField"; "required": false; }; "paymentMethodsCount": { "alias": "paymentMethodsCount"; "required": false; }; "paymentDetails": { "alias": "paymentDetails"; "required": false; }; }, { "goBack": "goBack"; "closeForm": "closeForm"; "setPaymentDetails": "setPaymentDetails"; }, never, never, true, never>;
}

declare class CheckoutPaymentFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPaymentFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutPaymentFormModule, never, [typeof i1$1.NgSelectA11yModule, typeof i1.CommonModule, typeof i3$1.ReactiveFormsModule, typeof i4.NgSelectModule, typeof i1$1.CardModule, typeof i2.I18nModule, typeof i1$1.IconModule, typeof i1$1.SpinnerModule, typeof i1$1.FormErrorsModule, typeof i2.FeaturesConfigModule, typeof CheckoutBillingAddressFormModule, typeof i1$1.FormRequiredAsterisksComponent, typeof i1$1.FormRequiredLegendComponent, typeof CheckoutPaymentFormComponent], [typeof CheckoutPaymentFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutPaymentFormModule>;
}

declare class CheckoutPaymentMethodComponent implements OnInit, OnDestroy {
    protected userPaymentService: UserPaymentService;
    protected checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade;
    protected checkoutPaymentFacade: CheckoutPaymentFacade;
    protected activatedRoute: ActivatedRoute;
    protected translationService: TranslationService;
    protected activeCartFacade: ActiveCartFacade;
    protected checkoutStepService: CheckoutStepService;
    protected globalMessageService: GlobalMessageService;
    protected subscriptions: Subscription;
    protected deliveryAddress: Address | undefined;
    protected busy$: BehaviorSubject<boolean>;
    protected focusService: SelectFocusUtility;
    protected windowRef: WindowRef;
    cards$: Observable<{
        content: Card;
        paymentMethod: PaymentDetails;
    }[]>;
    iconTypes: typeof ICON_TYPE;
    isGuestCheckout: boolean;
    newPaymentFormManuallyOpened: boolean;
    doneAutoSelect: boolean;
    paymentDetails?: PaymentDetails;
    isUpdating$: Observable<boolean>;
    get backBtnText(): string;
    get existingPaymentMethods$(): Observable<PaymentDetails[]>;
    get selectedMethod$(): Observable<PaymentDetails | undefined>;
    constructor(userPaymentService: UserPaymentService, checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade, checkoutPaymentFacade: CheckoutPaymentFacade, activatedRoute: ActivatedRoute, translationService: TranslationService, activeCartFacade: ActiveCartFacade, checkoutStepService: CheckoutStepService, globalMessageService: GlobalMessageService);
    ngOnInit(): void;
    selectDefaultPaymentMethod(paymentMethods: {
        payment: PaymentDetails;
        expiryTranslation: string;
    }[], selectedMethod: PaymentDetails | undefined): void;
    selectPaymentMethod(paymentDetails: PaymentDetails): void;
    /**
     * Restores the focus to the Card component after it has been selected and the checkout has finished updating.
     * The focus is lost due to DOM changes making it otherwise impossible to target elements that have been removed.
     */
    focusCardAfterSelecting(): void;
    showNewPaymentForm(): void;
    hideNewPaymentForm(): void;
    setPaymentDetails({ paymentDetails, billingAddress, }: {
        paymentDetails: PaymentDetails;
        billingAddress?: Address;
    }): void;
    next(): void;
    back(): void;
    protected savePaymentMethod(paymentDetails: PaymentDetails): void;
    protected getCardIcon(code: string): string;
    protected createCard(paymentDetails: PaymentDetails, cardLabels: {
        textDefaultPaymentMethod: string;
        textExpires: string;
        textUseThisPayment: string;
        textSelected: string;
    }, selected: PaymentDetails | undefined): Card;
    protected onSuccess(): void;
    protected onError(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPaymentMethodComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutPaymentMethodComponent, "cx-payment-method", never, {}, {}, never, never, true, never>;
}

declare class CheckoutPaymentMethodModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPaymentMethodModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutPaymentMethodModule, never, [typeof i1.CommonModule, typeof i3.RouterModule, typeof CheckoutPaymentFormModule, typeof i1$1.CardModule, typeof i1$1.SpinnerModule, typeof i2.I18nModule, typeof i2.FeaturesConfigModule, typeof CheckoutPaymentMethodComponent], [typeof CheckoutPaymentMethodComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutPaymentMethodModule>;
}

declare class CheckoutPlaceOrderComponent implements OnDestroy, OnInit {
    protected orderFacade: OrderFacade;
    protected routingService: RoutingService;
    protected fb: UntypedFormBuilder;
    protected launchDialogService: LaunchDialogService;
    protected vcr: ViewContainerRef;
    placedOrder: void | Observable<ComponentRef<any> | undefined>;
    params$: Observable<string[]>;
    checkoutSubmitForm: UntypedFormGroup;
    private currencyService;
    private languageService;
    get termsAndConditionInvalid(): boolean;
    constructor(orderFacade: OrderFacade, routingService: RoutingService, fb: UntypedFormBuilder, launchDialogService: LaunchDialogService, vcr: ViewContainerRef);
    ngOnInit(): void;
    submitForm(): void;
    onSuccess(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPlaceOrderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutPlaceOrderComponent, "cx-place-order", never, {}, {}, never, never, true, never>;
}

declare class CheckoutPlaceOrderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPlaceOrderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutPlaceOrderModule, never, [typeof i1$1.AtMessageModule, typeof i1.CommonModule, typeof i3.RouterModule, typeof i2.UrlModule, typeof i2.I18nModule, typeof i3$1.ReactiveFormsModule, typeof i1$1.FormErrorsModule, typeof i2.FeaturesConfigModule, typeof i1$1.FormRequiredAsterisksComponent, typeof i1$1.FormRequiredLegendComponent, typeof CheckoutPlaceOrderComponent], [typeof CheckoutPlaceOrderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutPlaceOrderModule>;
}

declare class CheckoutReviewSubmitComponent {
    protected checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade;
    protected checkoutPaymentFacade: CheckoutPaymentFacade;
    protected activeCartFacade: ActiveCartFacade;
    protected translationService: TranslationService;
    protected checkoutStepService: CheckoutStepService;
    protected checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade;
    readonly cartOutlets: typeof CartOutlets;
    iconTypes: typeof ICON_TYPE;
    checkoutStepTypeDeliveryAddress: CheckoutStepType;
    checkoutStepTypePaymentDetails: CheckoutStepType;
    checkoutStepTypeDeliveryMode: CheckoutStepType;
    promotionLocation: PromotionLocation;
    constructor(checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade, checkoutPaymentFacade: CheckoutPaymentFacade, activeCartFacade: ActiveCartFacade, translationService: TranslationService, checkoutStepService: CheckoutStepService, checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade);
    get cart$(): Observable<Cart>;
    get entries$(): Observable<OrderEntry[]>;
    protected getCheckoutDeliverySteps(): Array<CheckoutStepType | string>;
    protected getCheckoutPaymentSteps(): Array<CheckoutStepType | string>;
    steps$: Observable<CheckoutStep[]>;
    deliveryAddress$: Observable<Address | undefined>;
    deliveryMode$: Observable<DeliveryMode | undefined>;
    paymentDetails$: Observable<PaymentDetails | undefined>;
    getDeliveryAddressCard(deliveryAddress: Address, countryName?: string): Observable<Card>;
    getDeliveryModeCard(deliveryMode: DeliveryMode): Observable<Card>;
    getPaymentMethodCard(paymentDetails: PaymentDetails): Observable<Card>;
    getCheckoutStepUrl(stepType: CheckoutStepType | string): string | undefined;
    deliverySteps(steps: CheckoutStep[]): CheckoutStep[];
    paymentSteps(steps: CheckoutStep[]): CheckoutStep[];
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutReviewSubmitComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutReviewSubmitComponent, "cx-review-submit", never, {}, {}, never, never, true, never>;
}

declare class CheckoutReviewSubmitModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutReviewSubmitModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutReviewSubmitModule, never, [typeof i1.CommonModule, typeof i1$1.CardModule, typeof i2.I18nModule, typeof i2.UrlModule, typeof i3.RouterModule, typeof i1$1.PromotionsModule, typeof i1$1.IconModule, typeof i1$1.OutletModule, typeof CheckoutReviewSubmitComponent], [typeof CheckoutReviewSubmitComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutReviewSubmitModule>;
}

declare class CheckoutReviewPaymentComponent {
    protected checkoutStepService: CheckoutStepService;
    protected checkoutPaymentFacade: CheckoutPaymentFacade;
    protected translationService: TranslationService;
    iconTypes: typeof ICON_TYPE;
    paymentDetailsStepRoute: string | undefined;
    constructor(checkoutStepService: CheckoutStepService, checkoutPaymentFacade: CheckoutPaymentFacade, translationService: TranslationService);
    paymentDetails$: Observable<PaymentDetails | undefined>;
    getPaymentMethodCard(paymentDetails: PaymentDetails): Observable<Card>;
    getBillingAddressCard(paymentDetails: PaymentDetails): Observable<Card>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutReviewPaymentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutReviewPaymentComponent, "cx-checkout-review-payment", never, {}, {}, never, never, true, never>;
}

declare class CheckoutReviewPaymentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutReviewPaymentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutReviewPaymentModule, never, [typeof i1.CommonModule, typeof i1$1.CardModule, typeof i2.I18nModule, typeof i2.UrlModule, typeof i3.RouterModule, typeof i1$1.IconModule, typeof CheckoutReviewPaymentComponent], [typeof CheckoutReviewPaymentComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutReviewPaymentModule>;
}

declare class CheckoutReviewShippingComponent {
    protected activeCartFacade: ActiveCartFacade;
    protected checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade;
    protected checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade;
    protected translationService: TranslationService;
    protected checkoutStepService: CheckoutStepService;
    readonly cartOutlets: typeof CartOutlets;
    iconTypes: typeof ICON_TYPE;
    deliveryAddressStepRoute: string | undefined;
    deliveryModeStepRoute: string | undefined;
    constructor(activeCartFacade: ActiveCartFacade, checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade, checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade, translationService: TranslationService, checkoutStepService: CheckoutStepService);
    entries$: Observable<OrderEntry[]>;
    deliveryAddress$: Observable<Address | undefined>;
    deliveryMode$: Observable<DeliveryMode | undefined>;
    getDeliveryAddressCard(deliveryAddress: Address, countryName?: string): Observable<Card>;
    getDeliveryModeCard(deliveryMode: DeliveryMode): Observable<Card>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutReviewShippingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutReviewShippingComponent, "cx-checkout-review-shipping", never, {}, {}, never, never, true, never>;
}

declare class CheckoutReviewShippingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutReviewShippingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutReviewShippingModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i1$1.CardModule, typeof i2.UrlModule, typeof i3.RouterModule, typeof i1$1.IconModule, typeof i1$1.OutletModule, typeof CheckoutReviewShippingComponent], [typeof CheckoutReviewShippingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutReviewShippingModule>;
}

declare class CheckoutReviewOverviewComponent implements AfterViewInit {
    protected activeCartFacade: ActiveCartFacade;
    protected document: Document | null;
    protected translationService: TranslationService | null;
    protected readonly CHECKOUT_COMPONENTS: string[];
    constructor(activeCartFacade: ActiveCartFacade);
    ngAfterViewInit(): void;
    get cart$(): Observable<Cart>;
    /**
     * Wraps checkout review components with section element required
     * for applying correct a11y practices.
     *
     * Note: We need to do it this way because there is no single parent component
     * template we can use to wrap all related components because the layout is
     * CMS-driven (ie. by page slot).
     */
    protected wrapComponentsWithSectionEl(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutReviewOverviewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutReviewOverviewComponent, "cx-checkout-review-overview", never, {}, {}, never, never, true, never>;
}

declare class CheckoutReviewOverviewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutReviewOverviewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutReviewOverviewModule, never, [typeof i1.CommonModule, typeof i1$1.PromotionsModule, typeof i2.I18nModule, typeof CheckoutReviewOverviewComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutReviewOverviewModule>;
}

declare class ExpressCheckoutService {
    protected userAddressService: UserAddressService;
    protected userPaymentService: UserPaymentService;
    protected checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade;
    protected checkoutPaymentFacade: CheckoutPaymentFacade;
    protected checkoutConfigService: CheckoutConfigService;
    protected checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade;
    private deliveryAddressSet$;
    private deliveryModeSet$;
    private paymentMethodSet$;
    constructor(userAddressService: UserAddressService, userPaymentService: UserPaymentService, checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade, checkoutPaymentFacade: CheckoutPaymentFacade, checkoutConfigService: CheckoutConfigService, checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade);
    protected setDeliveryAddress(): void;
    protected setDeliveryMode(): void;
    protected setPaymentMethod(): void;
    trySetDefaultCheckoutDetails(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpressCheckoutService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ExpressCheckoutService>;
}

interface CardWithAddress {
    card: Card;
    address: Address;
}
declare class CheckoutDeliveryAddressComponent implements OnInit {
    protected userAddressService: UserAddressService;
    protected checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade;
    protected activatedRoute: ActivatedRoute;
    protected translationService: TranslationService;
    protected activeCartFacade: ActiveCartFacade;
    protected checkoutStepService: CheckoutStepService;
    protected checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade;
    protected globalMessageService: GlobalMessageService;
    protected checkoutConfigService: CheckoutConfigService;
    protected busy$: BehaviorSubject<boolean>;
    cards$: Observable<CardWithAddress[]>;
    isUpdating$: Observable<boolean>;
    addressFormOpened: boolean;
    doneAutoSelect: boolean;
    selectedAddress?: Address;
    get isGuestCheckout(): boolean;
    get backBtnText(): string;
    get selectedAddress$(): Observable<Address | undefined>;
    protected focusService: SelectFocusUtility;
    protected windowRef: WindowRef;
    constructor(userAddressService: UserAddressService, checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade, activatedRoute: ActivatedRoute, translationService: TranslationService, activeCartFacade: ActiveCartFacade, checkoutStepService: CheckoutStepService, checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade, globalMessageService: GlobalMessageService);
    ngOnInit(): void;
    getCardContent(address: Address, selected: any, textDefaultDeliveryAddress: string, textShipToThisAddress: string, textSelected: string, textPhone: string, textMobile: string): Card;
    selectAddress(address: Address): void;
    /**
     * Restores the focus to the Card component after it has been selected and the checkout has finished updating.
     * The focus is lost due to DOM changes making it otherwise impossible to target elements that have been removed.
     */
    focusCardAfterSelecting(): void;
    addAddress(address: Address | undefined): void;
    showNewAddressForm(): void;
    hideNewAddressForm(goPrevious?: boolean): void;
    next(): void;
    back(): void;
    protected loadAddresses(): void;
    protected createCards(): Observable<CardWithAddress[]>;
    protected selectDefaultAddress(addresses: Address[], selected: Address | undefined): void;
    protected getSupportedAddresses(): Observable<Address[]>;
    protected createIsUpdating(): Observable<boolean>;
    protected getAddressLoading(): Observable<boolean>;
    protected setAddress(address: Address): void;
    protected onSuccess(): void;
    protected onError(): void;
    protected shouldUseAddressSavedInCart(): boolean;
    /**
     * @deprecated since 221121.8. No longer used internally.
     * The role logic is now inlined in `getCardContent()` method.
     * This method will be removed in a future major version.
     */
    protected getCardRole(isCardSelected: boolean): 'button' | 'application';
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutDeliveryAddressComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutDeliveryAddressComponent, "cx-delivery-address", never, {}, {}, never, never, true, never>;
}

declare class CheckoutDeliveryAddressModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutDeliveryAddressModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutDeliveryAddressModule, never, [typeof i1.CommonModule, typeof i3.RouterModule, typeof i3$2.AddressFormModule, typeof i1$1.CardModule, typeof i1$1.SpinnerModule, typeof i2.I18nModule, typeof i2.FeaturesConfigModule, typeof CheckoutDeliveryAddressComponent], [typeof CheckoutDeliveryAddressComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutDeliveryAddressModule>;
}

declare class CheckoutLoginComponent implements OnDestroy {
    protected formBuilder: UntypedFormBuilder;
    protected authRedirectService: AuthRedirectService;
    protected activeCartFacade: ActiveCartFacade;
    checkoutLoginForm: UntypedFormGroup;
    sub: Subscription;
    constructor(formBuilder: UntypedFormBuilder, authRedirectService: AuthRedirectService, activeCartFacade: ActiveCartFacade);
    onSubmit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutLoginComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutLoginComponent, "cx-checkout-login", never, {}, {}, never, never, true, never>;
}

declare class CheckoutLoginModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutLoginModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutLoginModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3$1.FormsModule, typeof i3$1.ReactiveFormsModule, typeof i1$1.FormErrorsModule, typeof i2.FeaturesConfigModule, typeof i1$1.FormRequiredAsterisksComponent, typeof i1$1.FormRequiredLegendComponent, typeof CheckoutLoginComponent], [typeof CheckoutLoginComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutLoginModule>;
}

declare class CheckoutComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutComponentsModule, never, [typeof CheckoutOrchestratorModule, typeof CheckoutOrderSummaryModule, typeof CheckoutProgressModule, typeof CheckoutProgressMobileTopModule, typeof CheckoutProgressMobileBottomModule, typeof CheckoutDeliveryModeModule, typeof CheckoutPaymentMethodModule, typeof CheckoutPlaceOrderModule, typeof CheckoutReviewSubmitModule, typeof CheckoutReviewPaymentModule, typeof CheckoutReviewShippingModule, typeof CheckoutReviewOverviewModule, typeof CheckoutDeliveryAddressModule, typeof CheckoutLoginModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutComponentsModule>;
}

declare class CartNotEmptyGuard {
    protected activeCartFacade: ActiveCartFacade;
    protected semanticPathService: SemanticPathService;
    protected router: Router;
    constructor(activeCartFacade: ActiveCartFacade, semanticPathService: SemanticPathService, router: Router);
    canActivate(): Observable<GuardResult>;
    private isEmpty;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartNotEmptyGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartNotEmptyGuard>;
}

declare class CheckoutAuthGuard {
    protected authService: AuthService;
    protected authRedirectService: AuthRedirectService;
    protected checkoutConfigService: CheckoutConfigService;
    protected activeCartFacade: ActiveCartFacade;
    protected semanticPathService: SemanticPathService;
    protected router: Router;
    private featureToggles;
    protected windowRef: WindowRef;
    constructor(authService: AuthService, authRedirectService: AuthRedirectService, checkoutConfigService: CheckoutConfigService, activeCartFacade: ActiveCartFacade, semanticPathService: SemanticPathService, router: Router);
    canActivate(): Observable<GuardResult>;
    protected handleAnonymousUser(): boolean | UrlTree;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutAuthGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutAuthGuard>;
}

declare class CheckoutStepsSetGuard implements OnDestroy {
    protected checkoutStepService: CheckoutStepService;
    protected routingConfigService: RoutingConfigService;
    protected checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade;
    protected checkoutPaymentFacade: CheckoutPaymentFacade;
    protected checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade;
    protected router: Router;
    protected activeCartFacade: ActiveCartFacade;
    protected subscription: Subscription;
    protected logger: LoggerService;
    constructor(checkoutStepService: CheckoutStepService, routingConfigService: RoutingConfigService, checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade, checkoutPaymentFacade: CheckoutPaymentFacade, checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade, router: Router, activeCartFacade: ActiveCartFacade);
    canActivate(route: ActivatedRouteSnapshot): Observable<GuardResult>;
    protected isStepSet(step: CheckoutStep): Observable<GuardResult>;
    protected isDeliveryAddress(step: CheckoutStep): Observable<GuardResult>;
    protected isDeliveryModeSet(step: CheckoutStep): Observable<GuardResult>;
    protected isPaymentDetailsSet(step: CheckoutStep): Observable<GuardResult>;
    protected getUrl(routeName: string): UrlTree;
    protected setStepNameMultiLine(stepType: CheckoutStepType, value: boolean): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutStepsSetGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutStepsSetGuard>;
}

declare class CheckoutGuard {
    protected router: Router;
    protected routingConfigService: RoutingConfigService;
    protected checkoutConfigService: CheckoutConfigService;
    protected expressCheckoutService: ExpressCheckoutService;
    protected activeCartFacade: ActiveCartFacade;
    protected checkoutStepService: CheckoutStepService;
    private readonly firstStep$;
    constructor(router: Router, routingConfigService: RoutingConfigService, checkoutConfigService: CheckoutConfigService, expressCheckoutService: ExpressCheckoutService, activeCartFacade: ActiveCartFacade, checkoutStepService: CheckoutStepService);
    canActivate(): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutGuard>;
}

declare class NotCheckoutAuthGuard {
    protected authService: AuthService;
    protected activeCartFacade: ActiveCartFacade;
    protected semanticPathService: SemanticPathService;
    protected router: Router;
    constructor(authService: AuthService, activeCartFacade: ActiveCartFacade, semanticPathService: SemanticPathService, router: Router);
    canActivate(): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotCheckoutAuthGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NotCheckoutAuthGuard>;
}

export { CartNotEmptyGuard, CheckoutAuthGuard, CheckoutBillingAddressFormComponent, CheckoutBillingAddressFormModule, CheckoutBillingAddressFormService, CheckoutComponentsModule, CheckoutConfigService, CheckoutDeliveryAddressComponent, CheckoutDeliveryAddressModule, CheckoutDeliveryModeComponent, CheckoutDeliveryModeModule, CheckoutFlowOrchestratorService, CheckoutGuard, CheckoutLoginComponent, CheckoutLoginModule, CheckoutOrchestratorComponent, CheckoutOrchestratorModule, CheckoutOrderSummaryComponent, CheckoutOrderSummaryModule, CheckoutPaymentFormComponent, CheckoutPaymentFormModule, CheckoutPaymentMethodComponent, CheckoutPaymentMethodModule, CheckoutPlaceOrderComponent, CheckoutPlaceOrderModule, CheckoutProgressComponent, CheckoutProgressMobileBottomComponent, CheckoutProgressMobileBottomModule, CheckoutProgressMobileTopComponent, CheckoutProgressMobileTopModule, CheckoutProgressModule, CheckoutReviewOverviewComponent, CheckoutReviewOverviewModule, CheckoutReviewPaymentComponent, CheckoutReviewPaymentModule, CheckoutReviewShippingComponent, CheckoutReviewShippingModule, CheckoutReviewSubmitComponent, CheckoutReviewSubmitModule, CheckoutStepService, CheckoutStepsSetGuard, ExpressCheckoutService, NotCheckoutAuthGuard };
export type { CardWithAddress };
