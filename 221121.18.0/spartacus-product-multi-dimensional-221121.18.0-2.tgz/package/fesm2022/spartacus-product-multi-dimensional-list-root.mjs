import * as i0 from '@angular/core';
import { inject, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { NgIf, AsyncPipe } from '@angular/common';
import { TranslatePipe, I18nModule, provideDefaultConfigFactory } from '@spartacus/core';
import { ProductListItemContext, StarRatingComponent, StarRatingModule, provideOutlet, OutletPosition, ProductListOutlets } from '@spartacus/storefront';
import { EMPTY } from 'rxjs';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const PRODUCT_MULTI_DIMENSIONAL_LIST_FEATURE = 'productMultiDimensionalList';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ProductMultiDimensionalListItemDetailsComponent {
    constructor() {
        this.productListItemContext = inject(ProductListItemContext);
        this.product$ = this.productListItemContext?.product$ ?? EMPTY;
    }
    getProductPrice(product) {
        const defaultValue = '0';
        if (!product.multidimensional) {
            return product.price?.formattedValue ?? defaultValue;
        }
        const priceRange = product.priceRange;
        const maxPrice = priceRange?.maxPrice?.formattedValue;
        const minPrice = priceRange?.minPrice?.formattedValue;
        return maxPrice && minPrice ? `${minPrice} - ${maxPrice}` : '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalListItemDetailsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: ProductMultiDimensionalListItemDetailsComponent, isStandalone: true, selector: "cx-product-multi-dimensional-list-item-details", ngImport: i0, template: "<ng-container *ngIf=\"product$ | async as product\">\n  <cx-star-rating\n    *ngIf=\"product.averageRating\"\n    [rating]=\"product?.averageRating ?? 0\"\n  ></cx-star-rating>\n\n  <div *ngIf=\"!product.averageRating\" class=\"cx-product-no-review\">\n    {{ 'productDetails.noReviews' | cxTranslate }}\n  </div>\n\n  <div\n    class=\"cx-product-price\"\n    [attr.aria-label]=\"'productDetails.productPrice' | cxTranslate\"\n  >\n    {{ getProductPrice(product) }}\n  </div>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: StarRatingComponent, selector: "cx-star-rating", inputs: ["disabled", "rating"], outputs: ["change"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalListItemDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-product-multi-dimensional-list-item-details', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, StarRatingComponent, TranslatePipe, AsyncPipe], template: "<ng-container *ngIf=\"product$ | async as product\">\n  <cx-star-rating\n    *ngIf=\"product.averageRating\"\n    [rating]=\"product?.averageRating ?? 0\"\n  ></cx-star-rating>\n\n  <div *ngIf=\"!product.averageRating\" class=\"cx-product-no-review\">\n    {{ 'productDetails.noReviews' | cxTranslate }}\n  </div>\n\n  <div\n    class=\"cx-product-price\"\n    [attr.aria-label]=\"'productDetails.productPrice' | cxTranslate\"\n  >\n    {{ getProductPrice(product) }}\n  </div>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ProductMultiDimensionalListItemDetailsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalListItemDetailsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalListItemDetailsModule, imports: [I18nModule,
            NgIf,
            AsyncPipe,
            StarRatingModule,
            ProductMultiDimensionalListItemDetailsComponent], exports: [ProductMultiDimensionalListItemDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalListItemDetailsModule, imports: [I18nModule,
            StarRatingModule,
            ProductMultiDimensionalListItemDetailsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalListItemDetailsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        I18nModule,
                        NgIf,
                        AsyncPipe,
                        StarRatingModule,
                        ProductMultiDimensionalListItemDetailsComponent,
                    ],
                    exports: [ProductMultiDimensionalListItemDetailsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
function defaultProductMultiDimensionalListConfig() {
    return {
        featureModules: {
            [PRODUCT_MULTI_DIMENSIONAL_LIST_FEATURE]: {
                cmsComponents: [
                    'CMSProductListComponent',
                    'ProductGridComponent',
                    'SearchResultsListComponent',
                ],
            },
        },
    };
}
class ProductMultiDimensionalListRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalListRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalListRootModule, imports: [ProductMultiDimensionalListItemDetailsModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalListRootModule, providers: [
            provideDefaultConfigFactory(defaultProductMultiDimensionalListConfig),
            provideOutlet({
                id: ProductListOutlets.ITEM_DETAILS,
                position: OutletPosition.REPLACE,
                component: ProductMultiDimensionalListItemDetailsComponent,
            }),
        ], imports: [ProductMultiDimensionalListItemDetailsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalListRootModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [ProductMultiDimensionalListItemDetailsModule],
                    providers: [
                        provideDefaultConfigFactory(defaultProductMultiDimensionalListConfig),
                        provideOutlet({
                            id: ProductListOutlets.ITEM_DETAILS,
                            position: OutletPosition.REPLACE,
                            component: ProductMultiDimensionalListItemDetailsComponent,
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { PRODUCT_MULTI_DIMENSIONAL_LIST_FEATURE, ProductMultiDimensionalListItemDetailsComponent, ProductMultiDimensionalListItemDetailsModule, ProductMultiDimensionalListRootModule, defaultProductMultiDimensionalListConfig };
//# sourceMappingURL=spartacus-product-multi-dimensional-list-root.mjs.map
