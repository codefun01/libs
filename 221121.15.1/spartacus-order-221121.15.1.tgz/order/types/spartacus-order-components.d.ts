import * as i2$1 from '@angular/forms';
import { UntypedFormGroup, UntypedFormControl, UntypedFormBuilder } from '@angular/forms';
import * as i3 from '@spartacus/core';
import { RoutingService, Price, GlobalMessageType, GlobalMessageService, SemanticPathService, TranslationService, PaymentDetails, CmsOrderDetailItemsComponent, ProductCatalogService, EventService, CmsOrderDetailOverviewComponent, CostCenter, Address, Images, AuthRedirectService, Product } from '@spartacus/core';
import * as i0 from '@angular/core';
import { OnDestroy, OnInit, ViewContainerRef, ElementRef, AfterViewChecked, ChangeDetectorRef, DestroyRef, AfterViewInit } from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@angular/router';
import { Router, GuardResult, Params } from '@angular/router';
import * as i1$1 from '@spartacus/storefront';
import { Card, CmsComponentData, LaunchDialogService, FocusConfig, ICON_TYPE, SelectFocusUtility, OutletContextData, LayoutConfig, CustomFormValidators } from '@spartacus/storefront';
import { OrderEntry, CartOutlets, AbstractOrderType, PromotionLocation, MultiCartFacade, CartModification, CartValidationStatusCode, DeliveryMode, GetOrderEntriesContext, OrderEntriesSource } from '@spartacus/cart/base/root';
import * as rxjs from 'rxjs';
import { Observable, BehaviorSubject, Subscription } from 'rxjs';
import { OrderHistoryFacade, Order, OrderReturnRequestFacade, Consignment, OrderFacade, ReplenishmentOrderHistoryFacade, OrderHistoryList, OrderHistoryListView, OrderOutlets, ConsignmentTracking, ReorderOrderFacade, DownloadOrderInvoicesEvent, OrderConfig, OrderAttachmentsFacade, OrderAttachment, OrderHistoryView, ConsignmentView, ReplenishmentOrder, ReplenishmentOrderList, ReturnRequestList, ReturnRequest } from '@spartacus/order/root';
import * as i4$1 from '@ng-select/ng-select';
import { MyAccountV2OrderHistoryService } from '@spartacus/order/core';
import * as i5 from '@spartacus/cart/base/components/add-to-cart';
import * as i4 from '@spartacus/pdf-invoices/components';
import { InvoicesListComponent } from '@spartacus/pdf-invoices/components';
import * as i7 from '@spartacus/cart/base/components';
import { UserRegisterFacade } from '@spartacus/user/profile/root';

declare class AmendOrderActionsComponent {
    protected routingService: RoutingService;
    orderCode: string;
    amendOrderForm: UntypedFormGroup;
    backRoute: string;
    forwardRoute: string;
    styles: string;
    constructor(routingService: RoutingService);
    continue(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AmendOrderActionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AmendOrderActionsComponent, "cx-amend-order-actions", never, { "orderCode": { "alias": "orderCode"; "required": false; }; "amendOrderForm": { "alias": "amendOrderForm"; "required": false; }; "backRoute": { "alias": "backRoute"; "required": false; }; "forwardRoute": { "alias": "forwardRoute"; "required": false; }; }, {}, never, never, true, never>;
}

declare class AmendOrderActionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AmendOrderActionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AmendOrderActionsModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof i1$1.BtnLikeLinkModule, typeof AmendOrderActionsComponent], [typeof AmendOrderActionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AmendOrderActionsModule>;
}

declare class OrderDetailsService {
    private orderHistoryFacade;
    private routingService;
    orderCode$: Observable<string>;
    orderLoad$: Observable<{}>;
    constructor(orderHistoryFacade: OrderHistoryFacade, routingService: RoutingService);
    isOrderDetailsLoading(): Observable<boolean>;
    getOrderDetails(): Observable<Order>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDetailsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderDetailsService>;
}

declare enum AmendOrderType {
    CANCEL = 0,
    RETURN = 1
}

declare abstract class OrderAmendService {
    protected orderDetailsService: OrderDetailsService;
    protected amendType: AmendOrderType;
    protected form: UntypedFormGroup;
    constructor(orderDetailsService: OrderDetailsService);
    /**
     * Returns entries for the given order.
     */
    abstract getEntries(): Observable<OrderEntry[]>;
    /**
     * Returns entries with an amended quantity.
     */
    getAmendedEntries(): Observable<OrderEntry[]>;
    /**
     * Submits the amended order.
     */
    abstract save(): void;
    getOrder(): Observable<Order>;
    /**
     * returns the form with form data at runtime
     */
    getForm(): Observable<UntypedFormGroup>;
    private buildForm;
    protected getFormControl(form: UntypedFormGroup, entry: OrderEntry): UntypedFormControl;
    /**
     * As discussed, this calculation is moved to SPA side.
     * The calculation and validation should be in backend facade layer.
     */
    getAmendedPrice(entry: OrderEntry): Price;
    getMaxAmendQuantity(entry: OrderEntry): number;
    isCancellation(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderAmendService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderAmendService>;
}

declare class CancelOrReturnItemsComponent {
    protected orderAmendService: OrderAmendService;
    entries: OrderEntry[];
    isConfirmation: boolean;
    form$: Observable<UntypedFormGroup>;
    constructor(orderAmendService: OrderAmendService);
    getControl(form: UntypedFormGroup, entry: OrderEntry): UntypedFormControl;
    setAll(form: UntypedFormGroup): void;
    getItemPrice(entry: OrderEntry): Price;
    getMaxAmendQuantity(entry: OrderEntry): number;
    isCancellation(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CancelOrReturnItemsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CancelOrReturnItemsComponent, "cx-amend-order-items", never, { "entries": { "alias": "entries"; "required": false; }; "isConfirmation": { "alias": "isConfirmation"; "required": false; }; }, {}, never, never, true, never>;
}

declare class AmendOrderItemsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AmendOrderItemsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AmendOrderItemsModule, never, [typeof i1.CommonModule, typeof i2$1.ReactiveFormsModule, typeof i3.I18nModule, typeof i1$1.MediaModule, typeof i1$1.ItemCounterModule, typeof i1$1.FormErrorsModule, typeof CancelOrReturnItemsComponent], [typeof CancelOrReturnItemsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AmendOrderItemsModule>;
}

declare class CancelOrderConfirmationComponent {
    protected orderAmendService: OrderAmendService;
    orderCode: string;
    form$: Observable<UntypedFormGroup>;
    entries$: Observable<OrderEntry[]>;
    constructor(orderAmendService: OrderAmendService);
    submit(form: UntypedFormGroup): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CancelOrderConfirmationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CancelOrderConfirmationComponent, "cx-cancel-order-confirmation", never, {}, {}, never, never, true, never>;
}

declare class CancelOrderConfirmationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CancelOrderConfirmationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CancelOrderConfirmationModule, never, [typeof i1.CommonModule, typeof i2$1.ReactiveFormsModule, typeof AmendOrderItemsModule, typeof AmendOrderActionsModule, typeof CancelOrderConfirmationComponent], [typeof CancelOrderConfirmationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CancelOrderConfirmationModule>;
}

declare class CancelOrderComponent {
    protected orderAmendService: OrderAmendService;
    orderCode: string;
    globalMessageType: typeof GlobalMessageType;
    form$: Observable<UntypedFormGroup>;
    entries$: Observable<OrderEntry[]>;
    constructor(orderAmendService: OrderAmendService);
    static ɵfac: i0.ɵɵFactoryDeclaration<CancelOrderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CancelOrderComponent, "cx-cancel-order", never, {}, {}, never, never, true, never>;
}

declare class CancelOrderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CancelOrderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CancelOrderModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof AmendOrderItemsModule, typeof AmendOrderActionsModule, typeof i1$1.FormErrorsModule, typeof i1$1.MessageComponentModule, typeof i3.FeaturesConfigModule, typeof CancelOrderComponent], [typeof CancelOrderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CancelOrderModule>;
}

declare class OrderCancellationService extends OrderAmendService {
    protected orderDetailsService: OrderDetailsService;
    protected orderHistoryFacade: OrderHistoryFacade;
    protected routing: RoutingService;
    protected globalMessageService: GlobalMessageService;
    amendType: AmendOrderType;
    constructor(orderDetailsService: OrderDetailsService, orderHistoryFacade: OrderHistoryFacade, routing: RoutingService, globalMessageService: GlobalMessageService);
    /**
     * Return cancellable order entries.
     */
    getEntries(): Observable<OrderEntry[]>;
    save(): void;
    private afterSave;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderCancellationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderCancellationService>;
}

declare class OrderCancellationGuard {
    protected orderAmendService: OrderCancellationService;
    protected semanticPathService: SemanticPathService;
    protected router: Router;
    constructor(orderAmendService: OrderCancellationService, semanticPathService: SemanticPathService, router: Router);
    canActivate(): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderCancellationGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderCancellationGuard>;
}

declare class OrderCancellationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderCancellationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderCancellationModule, never, [typeof CancelOrderModule, typeof CancelOrderConfirmationModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderCancellationModule>;
}

declare class OrderReturnService extends OrderAmendService {
    protected orderDetailsService: OrderDetailsService;
    protected returnRequestService: OrderReturnRequestFacade;
    protected routing: RoutingService;
    protected globalMessageService: GlobalMessageService;
    amendType: AmendOrderType;
    constructor(orderDetailsService: OrderDetailsService, returnRequestService: OrderReturnRequestFacade, routing: RoutingService, globalMessageService: GlobalMessageService);
    getEntries(): Observable<OrderEntry[]>;
    save(): void;
    private afterSave;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderReturnService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderReturnService>;
}

declare class OrderReturnGuard {
    protected orderAmendService: OrderReturnService;
    protected semanticPathService: SemanticPathService;
    protected router: Router;
    constructor(orderAmendService: OrderReturnService, semanticPathService: SemanticPathService, router: Router);
    canActivate(): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderReturnGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderReturnGuard>;
}

declare class ReturnOrderComponent {
    protected orderAmendService: OrderAmendService;
    orderCode: string;
    private featureConfigService;
    form$: Observable<UntypedFormGroup>;
    consignments$: Observable<Consignment[]>;
    entries$: Observable<OrderEntry[]>;
    constructor(orderAmendService: OrderAmendService);
    static ɵfac: i0.ɵɵFactoryDeclaration<ReturnOrderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReturnOrderComponent, "cx-return-order", never, {}, {}, never, never, true, never>;
}

declare class ReturnOrderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReturnOrderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ReturnOrderModule, never, [typeof i1.CommonModule, typeof AmendOrderItemsModule, typeof AmendOrderActionsModule, typeof i1$1.FormErrorsModule, typeof ReturnOrderComponent], [typeof ReturnOrderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ReturnOrderModule>;
}

declare class ReturnOrderConfirmationComponent {
    protected orderAmendService: OrderAmendService;
    orderCode: string;
    form$: Observable<UntypedFormGroup>;
    entries$: Observable<OrderEntry[]>;
    constructor(orderAmendService: OrderAmendService);
    submit(form: UntypedFormGroup): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReturnOrderConfirmationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReturnOrderConfirmationComponent, "cx-return-order-confirmation", never, {}, {}, never, never, true, never>;
}

declare class ReturnOrderConfirmationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReturnOrderConfirmationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ReturnOrderConfirmationModule, never, [typeof i1.CommonModule, typeof AmendOrderItemsModule, typeof i3.I18nModule, typeof i2$1.ReactiveFormsModule, typeof AmendOrderActionsModule, typeof ReturnOrderConfirmationComponent], [typeof ReturnOrderConfirmationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ReturnOrderConfirmationModule>;
}

declare class OrderReturnModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderReturnModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderReturnModule, never, [typeof ReturnOrderModule, typeof ReturnOrderConfirmationModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderReturnModule>;
}

declare class OrderConfirmationGuard {
    protected orderFacade: OrderFacade;
    protected router: Router;
    protected semanticPathService: SemanticPathService;
    constructor(orderFacade: OrderFacade, router: Router, semanticPathService: SemanticPathService);
    canActivate(): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderConfirmationGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderConfirmationGuard>;
}

declare class OrderHistoryComponent implements OnDestroy {
    protected routing: RoutingService;
    protected orderHistoryFacade: OrderHistoryFacade;
    protected translation: TranslationService;
    protected replenishmentOrderHistoryFacade: ReplenishmentOrderHistoryFacade;
    constructor(routing: RoutingService, orderHistoryFacade: OrderHistoryFacade, translation: TranslationService, replenishmentOrderHistoryFacade: ReplenishmentOrderHistoryFacade);
    private PAGE_SIZE;
    sortType: string;
    hasPONumber: boolean | undefined;
    orders$: Observable<OrderHistoryList | undefined>;
    setOrderHistoryParams(orders: OrderHistoryList | undefined): void;
    hasReplenishmentOrder$: Observable<boolean>;
    isLoaded$: Observable<boolean>;
    /**
     * When "Order Return" feature is enabled, this component becomes one tab in
     * TabParagraphContainerComponent. This can be read from TabParagraphContainer.
     */
    tabTitleParam$: Observable<number>;
    ngOnDestroy(): void;
    changeSortCode(sortCode: string): void;
    pageChange(page: number): void;
    goToOrderDetail(order: Order): void;
    getQueryParams(order: Order): Params | null;
    getSortLabels(): Observable<{
        byDate: string;
        byOrderNumber: string;
    }>;
    private fetchOrders;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderHistoryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderHistoryComponent, "cx-order-history", never, {}, {}, never, never, true, never>;
}

declare class MyAccountV2OrderHistoryComponent extends OrderHistoryComponent {
    protected service: MyAccountV2OrderHistoryService;
    protected readonly ITEMS_PER_PAGE = 5;
    isLoaded$: BehaviorSubject<boolean>;
    orders$: Observable<OrderHistoryListView | undefined>;
    pageChange(page: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2OrderHistoryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyAccountV2OrderHistoryComponent, "cx-my-account-v2-order-history", never, {}, {}, never, never, true, never>;
}

declare class OrderDetailActionsComponent {
    protected orderDetailsService: OrderDetailsService;
    constructor(orderDetailsService: OrderDetailsService);
    order$: Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDetailActionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderDetailActionsComponent, "cx-order-details-actions", never, {}, {}, never, never, true, never>;
}

declare class OrderDetailBillingComponent {
    protected orderDetailsService: OrderDetailsService;
    protected translationService: TranslationService;
    order$: Observable<Order | undefined>;
    readonly cartOutlets: typeof CartOutlets;
    constructor(orderDetailsService: OrderDetailsService, translationService: TranslationService);
    getPaymentMethodCard(paymentDetails: PaymentDetails): Observable<Card>;
    getBillingAddressCard(paymentDetails: PaymentDetails): Observable<Card>;
    isPaymentInfoCardFull(payment: PaymentDetails): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDetailBillingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderDetailBillingComponent, "cx-order-detail-billing", never, {}, {}, never, never, true, never>;
}

declare class MyAccountV2OrderConsignmentsService {
    getGroupedConsignments(order: Order, pickup: boolean): Consignment[] | undefined;
    getUnconsignedEntries(order: Order, pickup: boolean): OrderEntry[] | undefined;
    protected groupConsignments(consignments: Consignment[] | undefined): Consignment[] | undefined;
    /**
     * complete: 0
     * processing: 1
     * cancel: -1
     */
    protected getStatusGroupKey(status: string): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2OrderConsignmentsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MyAccountV2OrderConsignmentsService>;
}

declare class OrderDetailItemsComponent {
    protected orderDetailsService: OrderDetailsService;
    protected component: CmsComponentData<CmsOrderDetailItemsComponent>;
    protected orderConsignmentsService: MyAccountV2OrderConsignmentsService;
    readonly OrderOutlets: typeof OrderOutlets;
    readonly CartOutlets: typeof CartOutlets;
    readonly abstractOrderType: typeof AbstractOrderType;
    promotionLocation: PromotionLocation;
    pickupConsignments: Consignment[] | undefined;
    deliveryConsignments: Consignment[] | undefined;
    pickupUnconsignedEntries: OrderEntry[] | undefined;
    deliveryUnConsignedEntries: OrderEntry[] | undefined;
    order$: Observable<Order>;
    enableAddToCart$: Observable<boolean | undefined>;
    isOrderLoading$: Observable<boolean>;
    groupCartItems$: Observable<boolean | undefined>;
    constructor(orderDetailsService: OrderDetailsService, component: CmsComponentData<CmsOrderDetailItemsComponent>);
    protected getGroupedConsignments(order: Order, pickup: boolean): Consignment[] | undefined;
    protected getUnconsignedEntries(order: Order, pickup: boolean): OrderEntry[] | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDetailItemsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderDetailItemsComponent, "cx-order-details-items", never, {}, {}, never, never, true, never>;
}

declare class ConsignmentTrackingComponent implements OnInit, OnDestroy {
    protected orderHistoryFacade: OrderHistoryFacade;
    protected launchDialogService: LaunchDialogService;
    protected vcr: ViewContainerRef;
    consignmentStatus: string[];
    element: ElementRef;
    consignment: Consignment;
    orderCode: string;
    consignmentTracking$: Observable<ConsignmentTracking>;
    constructor(orderHistoryFacade: OrderHistoryFacade, launchDialogService: LaunchDialogService, vcr: ViewContainerRef);
    ngOnInit(): void;
    openTrackingDialog(consignment: Consignment): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConsignmentTrackingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConsignmentTrackingComponent, "cx-consignment-tracking", never, { "consignment": { "alias": "consignment"; "required": false; }; "orderCode": { "alias": "orderCode"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TrackingEventsComponent implements OnDestroy, OnInit {
    protected orderHistoryFacade: OrderHistoryFacade;
    protected launchDialogService: LaunchDialogService;
    protected el: ElementRef;
    private subscription;
    tracking$: Observable<ConsignmentTracking>;
    shipDate: Date;
    focusConfig: FocusConfig;
    handleClick(event: UIEvent): void;
    constructor(orderHistoryFacade: OrderHistoryFacade, launchDialogService: LaunchDialogService, el: ElementRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    init(tracking$: Observable<ConsignmentTracking>, shipDate: Date): void;
    close(reason?: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TrackingEventsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TrackingEventsComponent, "cx-tracking-events", never, {}, {}, never, never, true, never>;
}

declare class OrderConsignedEntriesComponent {
    consignments: Consignment[];
    order: Order;
    enableAddToCart: boolean | undefined;
    buyItAgainTranslation: string;
    protected translationService: TranslationService;
    promotionLocation: PromotionLocation;
    readonly OrderOutlets: typeof OrderOutlets;
    readonly CartOutlets: typeof CartOutlets;
    readonly abstractOrderType: typeof AbstractOrderType;
    getStatusText(status: string): rxjs.Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderConsignedEntriesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderConsignedEntriesComponent, "cx-order-consigned-entries", never, { "consignments": { "alias": "consignments"; "required": false; }; "order": { "alias": "order"; "required": false; }; "enableAddToCart": { "alias": "enableAddToCart"; "required": false; }; "buyItAgainTranslation": { "alias": "buyItAgainTranslation"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OrderDetailTotalsComponent implements OnInit {
    protected orderDetailsService: OrderDetailsService;
    constructor(orderDetailsService: OrderDetailsService);
    order$: Observable<any>;
    readonly CartOutlets: typeof CartOutlets;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDetailTotalsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderDetailTotalsComponent, "cx-order-details-totals", never, {}, {}, never, never, true, never>;
}

declare class OrderDetailReorderComponent implements OnInit, OnDestroy {
    protected orderDetailsService: OrderDetailsService;
    protected launchDialogService: LaunchDialogService;
    protected vcr: ViewContainerRef;
    protected productCatalogService: ProductCatalogService;
    constructor(orderDetailsService: OrderDetailsService, launchDialogService: LaunchDialogService, vcr: ViewContainerRef);
    element: ElementRef;
    protected subscription: Subscription;
    order$: Observable<any>;
    disabled$: Observable<boolean>;
    ngOnInit(): void;
    onReorderClick(order: any): void;
    launchDialog(orderCode: string): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDetailReorderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderDetailReorderComponent, "cx-order-details-reorder", never, {}, {}, never, never, true, never>;
}

declare class ReorderDialogComponent {
    protected launchDialogService: LaunchDialogService;
    protected reorderOrderFacade: ReorderOrderFacade;
    protected multiCartFacade: MultiCartFacade;
    iconTypes: typeof ICON_TYPE;
    focusConfig: FocusConfig;
    cartModifications: CartModification[] | undefined;
    loading$: BehaviorSubject<boolean>;
    showDecisionPrompt$: BehaviorSubject<boolean>;
    data$: rxjs.Observable<any>;
    selectFocusUtility: SelectFocusUtility;
    elementRef: ElementRef<any> | null;
    constructor(launchDialogService: LaunchDialogService, reorderOrderFacade: ReorderOrderFacade, multiCartFacade: MultiCartFacade);
    createCartFromOrder(orderCode: string): void;
    recaptureFocus(): void;
    close(reason: string): void;
    get cartValidationStatusCode(): typeof CartValidationStatusCode;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReorderDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReorderDialogComponent, "cx-reorder-dialog", never, {}, {}, never, never, true, never>;
}

declare class MyAccountV2DownloadInvoicesEventListener implements OnDestroy {
    protected subscription: Subscription;
    protected eventService: EventService;
    protected launchDialogService: LaunchDialogService;
    constructor();
    protected onDownloadInvoices(): void;
    protected openDialog(event: DownloadOrderInvoicesEvent): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2DownloadInvoicesEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MyAccountV2DownloadInvoicesEventListener>;
}

declare class MyAccountV2DownloadInvoicesComponent implements AfterViewChecked {
    invoiceComponent: InvoicesListComponent;
    readonly OrderOutlets: typeof OrderOutlets;
    invoiceCount: number | undefined;
    iconTypes: typeof ICON_TYPE;
    focusConfig: FocusConfig;
    protected launchDialogService: LaunchDialogService;
    protected cdr: ChangeDetectorRef;
    ngAfterViewChecked(): void;
    close(reason?: any, _message?: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2DownloadInvoicesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyAccountV2DownloadInvoicesComponent, "cx-my-account-v2-download-invoices", never, {}, {}, never, never, true, never>;
}

declare class MyAccountV2DownloadInvoicesModule {
    protected downloadInvoicesDialogEventListener: MyAccountV2DownloadInvoicesEventListener;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2DownloadInvoicesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MyAccountV2DownloadInvoicesModule, never, [typeof i1.CommonModule, typeof i1$1.KeyboardFocusModule, typeof i1$1.IconModule, typeof i3.I18nModule, typeof i1$1.PaginationModule, typeof i1$1.SortingModule, typeof i1$1.SpinnerModule, typeof i4.PDFInvoicesComponentsModule, typeof MyAccountV2DownloadInvoicesComponent], [typeof MyAccountV2DownloadInvoicesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MyAccountV2DownloadInvoicesModule>;
}

declare class OrderOverviewComponentService {
    shouldShowDeliveryMode(mode: DeliveryMode | undefined): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderOverviewComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderOverviewComponentService>;
}

declare class OrderOverviewComponent {
    protected translation: TranslationService;
    protected orderDetailsService: OrderDetailsService;
    protected component: CmsComponentData<CmsOrderDetailOverviewComponent>;
    protected orderOverviewComponentService: OrderOverviewComponentService;
    protected orderConfig: OrderConfig;
    readonly cartOutlets: typeof CartOutlets;
    readonly orderOutlets: typeof OrderOutlets;
    order$: Observable<any>;
    isOrderLoading$: Observable<boolean>;
    simple$: Observable<boolean | undefined>;
    constructor(translation: TranslationService, orderDetailsService: OrderDetailsService, component: CmsComponentData<CmsOrderDetailOverviewComponent>);
    getReplenishmentCodeCardContent(orderCode: string): Observable<Card>;
    getReplenishmentActiveCardContent(active: boolean): Observable<Card>;
    getReplenishmentStartOnCardContent(isoDate: string | null): Observable<Card>;
    getReplenishmentFrequencyCardContent(frequency: string): Observable<Card>;
    getReplenishmentNextDateCardContent(isoDate: string | null): Observable<Card>;
    getOrderCodeCardContent(orderCode: string): Observable<Card>;
    getOrderCurrentDateCardContent(isoDate: string | null): Observable<Card>;
    getOrderStatusCardContent(status: string): Observable<Card>;
    getPurchaseOrderNumber(poNumber: string): Observable<Card>;
    getMethodOfPaymentCardContent(hasPaymentInfo: PaymentDetails): Observable<Card>;
    getCostCenterCardContent(costCenter: CostCenter): Observable<Card>;
    getAddressCardContent(deliveryAddress: Address): Observable<Card>;
    shouldShowDeliveryMode(mode: DeliveryMode | undefined): boolean;
    getDeliveryModeCardContent(deliveryMode: DeliveryMode): Observable<Card>;
    getPaymentInfoCardContent(payment: PaymentDetails): Observable<Card>;
    isPaymentInfoCardFull(payment: PaymentDetails): boolean;
    getBillingAddressCardContent(billingAddress: Address): Observable<Card>;
    private normalizeFormattedAddress;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderOverviewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderOverviewComponent, "cx-order-overview", never, {}, {}, never, never, true, never>;
}

declare class MyAccountV2OrderDetailsActionsComponent extends OrderDetailActionsComponent implements OnInit {
    order: Order;
    protected eventService: EventService;
    ngOnInit(): void;
    showDialog(order: Order): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2OrderDetailsActionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyAccountV2OrderDetailsActionsComponent, "cx-my-account-v2-order-details-actions", never, {}, {}, never, never, true, never>;
}

declare class MyAccountV2ConsignmentTrackingComponent extends ConsignmentTrackingComponent implements OnInit {
    componentClass: string;
    protected outlet: OutletContextData<any>;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2ConsignmentTrackingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyAccountV2ConsignmentTrackingComponent, "cx-my-account-v2-consignment-tracking", never, {}, {}, never, never, true, never>;
}

declare class OrderAttachmentsComponent {
    protected orderDetailsService: OrderDetailsService;
    protected launchDialogService: LaunchDialogService;
    protected vcr: ViewContainerRef;
    protected destroyRef: DestroyRef;
    element: ElementRef;
    order$: Observable<Order>;
    onOrderAttachmentsClick(orderCode: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderAttachmentsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderAttachmentsComponent, "cx-order-attachments", never, {}, {}, never, never, true, never>;
}

declare class OrderAttachmentsDialogComponent {
    protected config: OrderConfig;
    protected launchDialogService: LaunchDialogService;
    protected orderAttachmentsFacade: OrderAttachmentsFacade;
    protected translation: TranslationService;
    protected cd: ChangeDetectorRef;
    protected destroyRef: DestroyRef;
    globalMessageType: typeof GlobalMessageType;
    iconTypes: typeof ICON_TYPE;
    focusConfig: FocusConfig;
    orderCode$: Observable<string>;
    attachments$: Observable<OrderAttachment[]>;
    loadError: i0.WritableSignal<boolean>;
    attachmentsCount: i0.Signal<number>;
    loadingAttachments: string[];
    erroredAttachments: string[];
    errorCounter: number;
    openOrderAttachment(attachmentId: string, fileName?: string): void;
    previewFile(blob: Blob): void;
    downloadFile(blob: Blob, fileName: string): void;
    onMouseDown(event: MouseEvent, attachmentId: string, fileName?: string): void;
    setAttachmentLoadingState(attachmentId: string, state: boolean): void;
    addErrorMessage(attachmentId: string): void;
    closeErrorMessage(attachmentId: string): void;
    close(reason: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderAttachmentsDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderAttachmentsDialogComponent, "cx-order-attachments-dialog", never, {}, {}, never, never, true, never>;
}

declare class OrderDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderDetailsModule, never, [typeof i1$1.CardModule, typeof i1.CommonModule, typeof i3.I18nModule, typeof i3.FeaturesConfigModule, typeof i1$1.PromotionsModule, typeof i3.UrlModule, typeof i1$1.SpinnerModule, typeof i2.RouterModule, typeof i1$1.OutletModule, typeof i5.AddToCartModule, typeof i1$1.KeyboardFocusModule, typeof i1$1.IconModule, typeof MyAccountV2DownloadInvoicesModule, typeof i7.AbstractOrderContextModule, typeof i1$1.BtnLikeLinkModule, typeof i1$1.MessageComponentModule, typeof OrderOverviewComponent, typeof OrderDetailActionsComponent, typeof OrderDetailItemsComponent, typeof OrderDetailTotalsComponent, typeof OrderDetailBillingComponent, typeof TrackingEventsComponent, typeof ConsignmentTrackingComponent, typeof OrderConsignedEntriesComponent, typeof OrderDetailReorderComponent, typeof ReorderDialogComponent, typeof MyAccountV2OrderDetailsActionsComponent, typeof MyAccountV2ConsignmentTrackingComponent, typeof OrderAttachmentsComponent, typeof OrderAttachmentsDialogComponent], [typeof OrderOverviewComponent, typeof OrderDetailActionsComponent, typeof OrderDetailItemsComponent, typeof OrderDetailTotalsComponent, typeof OrderDetailBillingComponent, typeof TrackingEventsComponent, typeof ConsignmentTrackingComponent, typeof OrderConsignedEntriesComponent, typeof OrderDetailReorderComponent, typeof ReorderDialogComponent, typeof MyAccountV2OrderDetailsActionsComponent, typeof MyAccountV2ConsignmentTrackingComponent, typeof OrderAttachmentsComponent, typeof OrderAttachmentsDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderDetailsModule>;
}

declare const defaultMyAccountV2DownloadInvoicesLayoutConfig: LayoutConfig;

declare enum OrderCriticalStatus {
    CANCELLED = "CANCELLED",
    ERROR = "ERROR",
    REJECTED = "REJECTED"
}

declare class MyAccountV2OrderConsolidatedInformationComponent {
    protected orderConsignmentsService: MyAccountV2OrderConsignmentsService;
    protected criticalStatuses: OrderCriticalStatus[];
    order?: OrderHistoryView;
    protected readonly IMAGE_COUNT = 4;
    getConsignmentsCount(consignments: ConsignmentView[] | undefined): number;
    getOrderEntriesCount(orderEntries: OrderEntry[] | undefined): number;
    isStatusCritical(status: string): boolean;
    getPickupConsignments(consignments: ConsignmentView[]): ConsignmentView[];
    getDeliveryConsignments(consignments: ConsignmentView[]): ConsignmentView[];
    getDeliveryUnconsignedEntries(unconsignedEntries: OrderEntry[]): OrderEntry[];
    getPickupUnconsignedEntries(unconsignedEntries: OrderEntry[]): OrderEntry[];
    getProductImages(entries: OrderEntry[]): Images[];
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2OrderConsolidatedInformationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyAccountV2OrderConsolidatedInformationComponent, "cx-my-account-v2-order-consolidated-information", never, { "order": { "alias": "order"; "required": false; }; }, {}, never, never, true, never>;
}

declare class MyAccountV2ConsignmentEntriesComponent {
    consignments?: ConsignmentView[];
    orderCode?: string;
    getConsignmentNumber(code?: string): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2ConsignmentEntriesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyAccountV2ConsignmentEntriesComponent, "cx-my-account-v2-consignment-entries", never, { "consignments": { "alias": "consignments"; "required": false; }; "orderCode": { "alias": "orderCode"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OrderHistoryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderHistoryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderHistoryModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i2$1.FormsModule, typeof i4$1.NgSelectModule, typeof i1$1.ListNavigationModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof i1$1.SpinnerModule, typeof i1$1.MediaModule, typeof i1$1.BtnLikeLinkModule, typeof OrderHistoryComponent, typeof MyAccountV2OrderHistoryComponent, typeof MyAccountV2OrderConsolidatedInformationComponent, typeof MyAccountV2ConsignmentEntriesComponent], [typeof OrderHistoryComponent, typeof MyAccountV2OrderHistoryComponent, typeof MyAccountV2OrderConsolidatedInformationComponent, typeof MyAccountV2ConsignmentEntriesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderHistoryModule>;
}

declare class ReplenishmentOrderCancellationDialogComponent implements OnInit, OnDestroy {
    protected replenishmentOrderHistoryFacade: ReplenishmentOrderHistoryFacade;
    protected globalMessageService: GlobalMessageService;
    protected launchDialogService: LaunchDialogService;
    protected el: ElementRef;
    private subscription;
    iconTypes: typeof ICON_TYPE;
    replenishmentOrderCode: string;
    focusConfig: FocusConfig;
    handleClick(event: UIEvent): void;
    constructor(replenishmentOrderHistoryFacade: ReplenishmentOrderHistoryFacade, globalMessageService: GlobalMessageService, launchDialogService: LaunchDialogService, el: ElementRef);
    ngOnInit(): void;
    onSuccess(value: boolean): void;
    close(reason: string): void;
    cancelReplenishment(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReplenishmentOrderCancellationDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReplenishmentOrderCancellationDialogComponent, "cx-replenishment-order-cancellation-dialog", never, {}, {}, never, never, true, never>;
}

declare class ReplenishmentOrderCancellationDialogModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReplenishmentOrderCancellationDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ReplenishmentOrderCancellationDialogModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof i1$1.IconModule, typeof i1$1.KeyboardFocusModule, typeof ReplenishmentOrderCancellationDialogComponent], [typeof ReplenishmentOrderCancellationDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ReplenishmentOrderCancellationDialogModule>;
}

declare class ReplenishmentOrderCancellationComponent implements OnDestroy {
    protected replenishmentOrderHistoryFacade: ReplenishmentOrderHistoryFacade;
    protected vcr: ViewContainerRef;
    protected launchDialogService: LaunchDialogService;
    element: ElementRef;
    private subscription;
    replenishmentOrder$: Observable<ReplenishmentOrder>;
    constructor(replenishmentOrderHistoryFacade: ReplenishmentOrderHistoryFacade, vcr: ViewContainerRef, launchDialogService: LaunchDialogService);
    openDialog(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReplenishmentOrderCancellationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReplenishmentOrderCancellationComponent, "cx-replenishment-order-cancellation", never, {}, {}, never, never, true, never>;
}

declare class ReplenishmentOrderDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReplenishmentOrderDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ReplenishmentOrderDetailsModule, never, [typeof i1$1.CardModule, typeof i1.CommonModule, typeof i3.I18nModule, typeof i1$1.PromotionsModule, typeof i3.UrlModule, typeof ReplenishmentOrderCancellationDialogModule, typeof i1$1.SpinnerModule, typeof i1$1.ListNavigationModule, typeof i2.RouterModule, typeof i1$1.BtnLikeLinkModule, typeof ReplenishmentOrderCancellationComponent], [typeof ReplenishmentOrderCancellationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ReplenishmentOrderDetailsModule>;
}

declare class ReplenishmentOrderHistoryComponent implements OnDestroy {
    protected routing: RoutingService;
    protected replenishmentOrderHistoryFacade: ReplenishmentOrderHistoryFacade;
    protected translation: TranslationService;
    protected vcr: ViewContainerRef;
    protected launchDialogService: LaunchDialogService;
    element: ElementRef;
    private subscription;
    private PAGE_SIZE;
    sortType: string;
    replenishmentOrders$: Observable<ReplenishmentOrderList | undefined>;
    isLoaded$: Observable<boolean>;
    constructor(routing: RoutingService, replenishmentOrderHistoryFacade: ReplenishmentOrderHistoryFacade, translation: TranslationService, vcr: ViewContainerRef, launchDialogService: LaunchDialogService);
    changeSortCode(sortCode: string): void;
    pageChange(page: number): void;
    goToOrderDetail(order: ReplenishmentOrder): void;
    getSortLabels(): Observable<{
        byDate: string;
        byReplenishmentNumber: string;
        byNextOrderDate: string;
    }>;
    openDialog(event: Event, replenishmentOrderCode: string): void;
    private fetchReplenishmentOrders;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReplenishmentOrderHistoryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReplenishmentOrderHistoryComponent, "cx-replenishment-order-history", never, {}, {}, never, never, true, never>;
}

declare class ReplenishmentOrderHistoryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReplenishmentOrderHistoryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ReplenishmentOrderHistoryModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i1$1.ListNavigationModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof i1$1.BtnLikeLinkModule, typeof i3.FeaturesConfigModule, typeof ReplenishmentOrderHistoryComponent], [typeof ReplenishmentOrderHistoryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ReplenishmentOrderHistoryModule>;
}

declare class OrderReturnRequestListComponent implements OnDestroy {
    private returnRequestService;
    private translation;
    constructor(returnRequestService: OrderReturnRequestFacade, translation: TranslationService);
    private PAGE_SIZE;
    sortType: string;
    returnRequests$: Observable<ReturnRequestList | undefined>;
    /**
     * When "Order Return" feature is enabled, this component becomes one tab in
     * TabParagraphContainerComponent. This can be read from TabParagraphContainer.
     */
    tabTitleParam$: Observable<number>;
    ngOnDestroy(): void;
    changeSortCode(sortCode: string): void;
    pageChange(page: number): void;
    getSortLabels(): Observable<{
        byDate: string;
        byRMA: string;
    }>;
    private fetchReturnRequests;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderReturnRequestListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderReturnRequestListComponent, "cx-order-return-request-list", never, {}, {}, never, never, true, never>;
}

declare class ReturnRequestListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReturnRequestListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ReturnRequestListModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i1$1.ListNavigationModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof i3.FeaturesConfigModule, typeof OrderReturnRequestListComponent], [typeof OrderReturnRequestListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ReturnRequestListModule>;
}

declare class ReturnRequestService {
    protected routingService: RoutingService;
    protected returnRequestService: OrderReturnRequestFacade;
    protected globalMessageService: GlobalMessageService;
    constructor(routingService: RoutingService, returnRequestService: OrderReturnRequestFacade, globalMessageService: GlobalMessageService);
    get isCancelling$(): Observable<boolean>;
    get isCancelSuccess$(): Observable<boolean>;
    getReturnRequest(): Observable<ReturnRequest>;
    clearReturnRequest(): void;
    cancelReturnRequest(returnRequestCode: string): void;
    cancelSuccess(rma: string): void;
    backToList(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReturnRequestService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ReturnRequestService>;
}

declare class ReturnRequestOverviewComponent implements OnInit, OnDestroy {
    protected returnRequestService: ReturnRequestService;
    constructor(returnRequestService: ReturnRequestService);
    rma: string;
    subscription: Subscription;
    returnRequest$: Observable<ReturnRequest>;
    isCancelling$: Observable<boolean>;
    ngOnInit(): void;
    cancelReturn(returnRequestCode: string): void;
    back(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReturnRequestOverviewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReturnRequestOverviewComponent, "cx-return-request-overview", never, {}, {}, never, never, true, never>;
}

declare class ReturnRequestItemsComponent {
    protected returnRequestService: ReturnRequestService;
    constructor(returnRequestService: ReturnRequestService);
    returnRequest$: Observable<ReturnRequest>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReturnRequestItemsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReturnRequestItemsComponent, "cx-return-request-items", never, {}, {}, never, never, true, never>;
}

declare class ReturnRequestTotalsComponent implements OnDestroy {
    protected returnRequestService: ReturnRequestService;
    constructor(returnRequestService: ReturnRequestService);
    returnRequest$: Observable<ReturnRequest>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReturnRequestTotalsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReturnRequestTotalsComponent, "cx-return-request-totals", never, {}, {}, never, never, true, never>;
}

declare class ReturnRequestDetailModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReturnRequestDetailModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ReturnRequestDetailModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof i1$1.MediaModule, typeof ReturnRequestOverviewComponent, typeof ReturnRequestItemsComponent, typeof ReturnRequestTotalsComponent], [typeof ReturnRequestOverviewComponent, typeof ReturnRequestItemsComponent, typeof ReturnRequestTotalsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ReturnRequestDetailModule>;
}

declare class OrderConfirmationItemsComponent implements OnDestroy {
    protected orderFacade: OrderFacade;
    readonly cartOutlets: typeof CartOutlets;
    readonly abstractOrderType: typeof AbstractOrderType;
    promotionLocation: PromotionLocation;
    order$: Observable<Order | undefined>;
    constructor(orderFacade: OrderFacade);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderConfirmationItemsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderConfirmationItemsComponent, "cx-order-confirmation-items", never, {}, {}, never, never, true, never>;
}

declare class OrderConfirmationThankYouMessageComponent implements OnInit, AfterViewInit, OnDestroy {
    protected orderFacade: OrderFacade;
    protected globalMessageService: GlobalMessageService;
    protected translationService: TranslationService;
    order$: Observable<Order | undefined>;
    isGuestCustomer: boolean;
    orderGuid: string | undefined;
    constructor(orderFacade: OrderFacade, globalMessageService: GlobalMessageService, translationService: TranslationService);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    protected addThankYouMessage(): void;
    protected getThankYouAssistiveMessage(): Observable<[
        Order | undefined,
        string,
        string,
        string
    ]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderConfirmationThankYouMessageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderConfirmationThankYouMessageComponent, "cx-order-confirmation-thank-you-message", never, {}, {}, never, never, true, never>;
}

declare class OrderConfirmationTotalsComponent implements OnDestroy {
    protected orderFacade: OrderFacade;
    readonly cartOutlets: typeof CartOutlets;
    order$: Observable<Order | undefined>;
    constructor(orderFacade: OrderFacade);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderConfirmationTotalsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderConfirmationTotalsComponent, "cx-order-confirmation-totals", never, {}, {}, never, never, true, never>;
}

declare class OrderGuestRegisterFormComponent {
    protected userRegisterFacade: UserRegisterFacade;
    protected routingService: RoutingService;
    protected fb: UntypedFormBuilder;
    private featureConfigService;
    protected authRedirectService: AuthRedirectService;
    protected passwordValidators: (typeof CustomFormValidators.minOneDigitValidator)[];
    guid: string;
    email: string;
    guestRegisterForm: UntypedFormGroup;
    constructor(userRegisterFacade: UserRegisterFacade, routingService: RoutingService, fb: UntypedFormBuilder);
    submit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderGuestRegisterFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderGuestRegisterFormComponent, "cx-guest-register-form", never, { "guid": { "alias": "guid"; "required": false; }; "email": { "alias": "email"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OrderConfirmationShippingComponent implements OnInit, OnDestroy {
    protected orderFacade: OrderFacade;
    protected translationService: TranslationService;
    protected cd: ChangeDetectorRef;
    protected outlet?: OutletContextData<{
        showItemList?: boolean;
        order?: any;
    }> | undefined;
    showItemList: boolean;
    readonly cartOutlets: typeof CartOutlets;
    readonly abstractOrderType: typeof AbstractOrderType;
    entries: OrderEntry[] | undefined;
    order$: Observable<Order | undefined>;
    protected subscription: Subscription;
    constructor(orderFacade: OrderFacade, translationService: TranslationService, cd: ChangeDetectorRef, outlet?: OutletContextData<{
        showItemList?: boolean;
        order?: any;
    }> | undefined);
    ngOnInit(): void;
    getDeliveryAddressCard(deliveryAddress: Address, countryName?: string): Observable<Card>;
    getDeliveryModeCard(deliveryMode: DeliveryMode): Observable<Card>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderConfirmationShippingComponent, [null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderConfirmationShippingComponent, "cx-order-confirmation-shipping", never, { "showItemList": { "alias": "showItemList"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OrderConfirmationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderConfirmationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderConfirmationModule, never, [typeof i1.CommonModule, typeof i1$1.CardModule, typeof i1$1.PwaModule, typeof i1$1.PromotionsModule, typeof i3.I18nModule, typeof i2$1.ReactiveFormsModule, typeof i1$1.FormErrorsModule, typeof i1$1.OutletModule, typeof i1$1.PasswordVisibilityToggleModule, typeof i7.AbstractOrderContextModule, typeof i3.FeaturesConfigModule, typeof i1$1.FormRequiredAsterisksComponent, typeof i1$1.FormRequiredLegendComponent, typeof OrderConfirmationItemsComponent, typeof OrderConfirmationThankYouMessageComponent, typeof OrderConfirmationTotalsComponent, typeof OrderGuestRegisterFormComponent, typeof OrderConfirmationShippingComponent], [typeof OrderConfirmationItemsComponent, typeof OrderConfirmationThankYouMessageComponent, typeof OrderConfirmationTotalsComponent, typeof OrderGuestRegisterFormComponent, typeof OrderConfirmationShippingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderConfirmationModule>;
}

declare class MyAccountV2OrdersComponent implements OnDestroy {
    protected service: MyAccountV2OrderHistoryService;
    protected PAGE_SIZE: number;
    orders$: Observable<OrderHistoryListView | undefined>;
    isLoaded$: BehaviorSubject<boolean>;
    getProduct(order: Order): Product | undefined;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2OrdersComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyAccountV2OrdersComponent, "cx-my-account-v2-orders", never, {}, {}, never, never, true, never>;
}

declare class MyAccountV2OrdersModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2OrdersModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MyAccountV2OrdersModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i2$1.FormsModule, typeof i1$1.SpinnerModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof i1$1.MediaModule, typeof MyAccountV2OrdersComponent], [typeof MyAccountV2OrdersComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MyAccountV2OrdersModule>;
}

declare class OrderComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderComponentsModule, never, [typeof OrderHistoryModule, typeof OrderDetailsModule, typeof ReplenishmentOrderDetailsModule, typeof OrderCancellationModule, typeof OrderReturnModule, typeof ReplenishmentOrderHistoryModule, typeof ReturnRequestListModule, typeof ReturnRequestDetailModule, typeof OrderConfirmationModule, typeof MyAccountV2OrdersModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderComponentsModule>;
}

declare class OrderConfirmationOrderEntriesContext implements GetOrderEntriesContext {
    protected orderFacade: OrderFacade;
    readonly type = OrderEntriesSource.ORDER_CONFIRMATION;
    constructor(orderFacade: OrderFacade);
    getEntries(): Observable<OrderEntry[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderConfirmationOrderEntriesContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderConfirmationOrderEntriesContext>;
}

declare class OrderDetailsOrderEntriesContext implements GetOrderEntriesContext {
    protected orderHistoryFacade: OrderHistoryFacade;
    readonly type = OrderEntriesSource.ORDER_DETAILS;
    constructor(orderHistoryFacade: OrderHistoryFacade);
    getEntries(): Observable<OrderEntry[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDetailsOrderEntriesContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderDetailsOrderEntriesContext>;
}

declare const defaultReplenishmentOrderCancellationLayoutConfig: LayoutConfig;

declare class ReplenishmentOrderDetailsService {
    protected routingService: RoutingService;
    protected replenishmentOrderHistoryFacade: ReplenishmentOrderHistoryFacade;
    protected replenishmentOrderCode$: Observable<any>;
    protected replenishmentOrderLoad$: Observable<string>;
    constructor(routingService: RoutingService, replenishmentOrderHistoryFacade: ReplenishmentOrderHistoryFacade);
    getOrderDetails(): Observable<ReplenishmentOrder>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReplenishmentOrderDetailsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ReplenishmentOrderDetailsService>;
}

export { AmendOrderActionsComponent, AmendOrderActionsModule, AmendOrderItemsModule, AmendOrderType, CancelOrReturnItemsComponent, CancelOrderComponent, CancelOrderConfirmationComponent, CancelOrderConfirmationModule, CancelOrderModule, ConsignmentTrackingComponent, MyAccountV2ConsignmentEntriesComponent, MyAccountV2ConsignmentTrackingComponent, MyAccountV2DownloadInvoicesComponent, MyAccountV2DownloadInvoicesEventListener, MyAccountV2DownloadInvoicesModule, MyAccountV2OrderConsignmentsService, MyAccountV2OrderConsolidatedInformationComponent, MyAccountV2OrderDetailsActionsComponent, MyAccountV2OrderHistoryComponent, MyAccountV2OrdersComponent, MyAccountV2OrdersModule, OrderAmendService, OrderAttachmentsComponent, OrderAttachmentsDialogComponent, OrderCancellationGuard, OrderCancellationModule, OrderCancellationService, OrderComponentsModule, OrderConfirmationGuard, OrderConfirmationItemsComponent, OrderConfirmationModule, OrderConfirmationOrderEntriesContext, OrderConfirmationShippingComponent, OrderConfirmationThankYouMessageComponent, OrderConfirmationTotalsComponent, OrderConsignedEntriesComponent, OrderCriticalStatus, OrderDetailActionsComponent, OrderDetailBillingComponent, OrderDetailItemsComponent, OrderDetailReorderComponent, OrderDetailTotalsComponent, OrderDetailsModule, OrderDetailsOrderEntriesContext, OrderDetailsService, OrderGuestRegisterFormComponent, OrderHistoryComponent, OrderHistoryModule, OrderOverviewComponent, OrderOverviewComponentService, OrderReturnGuard, OrderReturnModule, OrderReturnRequestListComponent, OrderReturnService, ReorderDialogComponent, ReplenishmentOrderCancellationComponent, ReplenishmentOrderCancellationDialogComponent, ReplenishmentOrderCancellationDialogModule, ReplenishmentOrderDetailsModule, ReplenishmentOrderDetailsService, ReplenishmentOrderHistoryComponent, ReplenishmentOrderHistoryModule, ReturnOrderComponent, ReturnOrderConfirmationComponent, ReturnOrderConfirmationModule, ReturnOrderModule, ReturnRequestDetailModule, ReturnRequestItemsComponent, ReturnRequestListModule, ReturnRequestOverviewComponent, ReturnRequestTotalsComponent, TrackingEventsComponent, defaultMyAccountV2DownloadInvoicesLayoutConfig, defaultReplenishmentOrderCancellationLayoutConfig };
