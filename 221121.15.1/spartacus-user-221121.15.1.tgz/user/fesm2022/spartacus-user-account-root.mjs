import * as i0 from '@angular/core';
import { Injectable, NgModule } from '@angular/core';
import * as i1 from '@spartacus/core';
import { LogoutEvent, GlobalMessageType, provideDefaultConfigFactory, facadeFactory, CxEvent } from '@spartacus/core';
import { Subscription } from 'rxjs';
import { LAUNCH_CALLER } from '@spartacus/storefront';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * User account event listener.
 */
class UserAccountEventListener {
    constructor(eventService, globalMessageService) {
        this.eventService = eventService;
        this.globalMessageService = globalMessageService;
        this.subscriptions = new Subscription();
        this.onAuth();
    }
    /**
     * Registers events for the auth events.
     */
    onAuth() {
        this.subscriptions.add(this.eventService.get(LogoutEvent).subscribe(() => {
            this.globalMessageService.add({ key: 'authMessages.signedOutSuccessfully' }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
        }));
    }
    ngOnDestroy() {
        this.subscriptions.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAccountEventListener, deps: [{ token: i1.EventService }, { token: i1.GlobalMessageService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAccountEventListener, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAccountEventListener, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.EventService }, { type: i1.GlobalMessageService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAccountEventModule {
    constructor(_userAccountEventListener) {
        // Intentional empty constructor
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAccountEventModule, deps: [{ token: UserAccountEventListener }], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserAccountEventModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAccountEventModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAccountEventModule, decorators: [{
            type: NgModule,
            args: [{}]
        }], ctorParameters: () => [{ type: UserAccountEventListener }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const USER_ACCOUNT_FEATURE = 'userAccount';
const USER_ACCOUNT_CORE_FEATURE = 'userAccountCore';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
// TODO: Inline this factory when we start releasing Ivy compiled libraries
function defaultUserAccountComponentsConfig() {
    const config = {
        featureModules: {
            [USER_ACCOUNT_FEATURE]: {
                cmsComponents: [
                    'LoginComponent',
                    'ReturningCustomerLoginComponent',
                    'VerifyOTPTokenComponent',
                    'ReturningCustomerRegisterComponent',
                    'MyAccountViewUserComponent',
                    'ReturningCustomerOTPLoginComponent',
                    'RegisterCustomerWithOTPComponent',
                    'ReturningOrganizationUserRegisterComponent',
                ],
            },
            // by default core is bundled together with components
            [USER_ACCOUNT_CORE_FEATURE]: USER_ACCOUNT_FEATURE,
        },
    };
    return config;
}
class UserAccountRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAccountRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserAccountRootModule, imports: [UserAccountEventModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAccountRootModule, providers: [provideDefaultConfigFactory(defaultUserAccountComponentsConfig)], imports: [UserAccountEventModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAccountRootModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [UserAccountEventModule],
                    providers: [provideDefaultConfigFactory(defaultUserAccountComponentsConfig)],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAccountFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAccountFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAccountFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: UserAccountFacade,
            feature: USER_ACCOUNT_CORE_FEATURE,
            methods: ['get', 'getById'],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAccountFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: UserAccountFacade,
                        feature: USER_ACCOUNT_CORE_FEATURE,
                        methods: ['get', 'getById'],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class VerificationTokenFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VerificationTokenFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VerificationTokenFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: VerificationTokenFacade,
            feature: USER_ACCOUNT_CORE_FEATURE,
            methods: ['createVerificationToken'],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VerificationTokenFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: VerificationTokenFacade,
                        feature: USER_ACCOUNT_CORE_FEATURE,
                        methods: ['createVerificationToken'],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
LAUNCH_CALLER['ACCOUNT_VERIFICATION_TOKEN'] =
    'ACCOUNT_VERIFICATION_TOKEN';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var VERIFICATION_TOKEN_DIALOG_ACTION;
(function (VERIFICATION_TOKEN_DIALOG_ACTION) {
    VERIFICATION_TOKEN_DIALOG_ACTION["OK"] = "OK";
})(VERIFICATION_TOKEN_DIALOG_ACTION || (VERIFICATION_TOKEN_DIALOG_ACTION = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAccountEvent extends CxEvent {
}
class UserAccountChangedEvent extends UserAccountEvent {
    static { this.type = 'UserAccountChangedEvent'; }
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/** AUGMENTABLE_TYPES_END */

/**
 * Generated bundle index. Do not edit.
 */

export { USER_ACCOUNT_CORE_FEATURE, USER_ACCOUNT_FEATURE, UserAccountChangedEvent, UserAccountEvent, UserAccountEventListener, UserAccountEventModule, UserAccountFacade, UserAccountRootModule, VERIFICATION_TOKEN_DIALOG_ACTION, VerificationTokenFacade, defaultUserAccountComponentsConfig };
//# sourceMappingURL=spartacus-user-account-root.mjs.map
