import { HttpClient } from '@angular/common/http';
import * as i0 from '@angular/core';
import { inject, Injectable } from '@angular/core';
import { OccEndpointsService, LoggerService, tryNormalizeHttpError } from '@spartacus/core';
import { map, switchMap, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccUserWishlistAdapter {
    constructor() {
        this.http = inject(HttpClient);
        this.occEndpoints = inject(OccEndpointsService);
        this.logger = inject(LoggerService);
    }
    getWishlist(userId) {
        // Step 1: fetch wishlists list to get the default wishlist ID
        const listUrl = this.occEndpoints.buildUrl('getWishlists', {
            urlParams: { userId },
        });
        return this.http
            .get(listUrl)
            .pipe(map((response) => {
            const wishlists = response?.wishlists;
            if (!Array.isArray(wishlists) || wishlists.length === 0) {
                return null;
            }
            return wishlists[0].id ?? null;
        }), switchMap((wishlistId) => {
            if (wishlistId === null) {
                // No real wishlist exists yet.
                // 'default' is only valid for mutations (POST/DELETE), not for GET entries.
                // Return empty wishlist so the UI shows no items.
                return of({ entries: [] });
            }
            // Step 2: fetch entries for the real wishlist
            const entriesUrl = this.occEndpoints.buildUrl('getWishlistEntries', {
                urlParams: { userId, wishlistId },
                queryParams: { pageSize: 1000 },
            });
            return this.http
                .get(entriesUrl)
                .pipe(map((res) => {
                // API may return { wishlistEntries: [...] } or a plain array
                const entries = Array.isArray(res)
                    ? res
                    : (res?.wishlistEntries ?? res?.entries ?? []);
                return { id: wishlistId, entries };
            }), catchError((error) => {
                throw tryNormalizeHttpError(error, this.logger);
            }));
        }), catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    addEntry(userId, wishlistId, productCode) {
        const url = this.occEndpoints.buildUrl('addWishlistEntry', {
            urlParams: { userId, wishlistId },
        });
        return this.http.post(url, { productCode }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    removeEntry(userId, wishlistId, entryId) {
        const url = this.occEndpoints.buildUrl('removeWishlistEntry', {
            urlParams: { userId, wishlistId, entryId },
        });
        return this.http.delete(url).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccUserWishlistAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccUserWishlistAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccUserWishlistAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOccUserWishlistConfig = {
    backend: {
        occ: {
            endpoints: {
                getWishlists: 'users/${userId}/wishlists',
                getWishlistEntries: 'users/${userId}/wishlists/${wishlistId}/entries',
                addWishlistEntry: 'users/${userId}/wishlists/${wishlistId}/entries',
                removeWishlistEntry: 'users/${userId}/wishlists/${wishlistId}/entries/${entryId}',
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OccUserWishlistAdapter, defaultOccUserWishlistConfig };
//# sourceMappingURL=spartacus-user-wishlist-occ.mjs.map
