import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { UserProfileComponentsModule } from '@spartacus/user/profile/components';
import { UserProfileCoreModule } from '@spartacus/user/profile/core';
import { UserProfileOccModule } from '@spartacus/user/profile/occ';
import { CaptchaModule } from '@spartacus/storefront';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserProfileModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserProfileModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserProfileModule, imports: [UserProfileCoreModule,
            UserProfileOccModule,
            UserProfileComponentsModule,
            CaptchaModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserProfileModule, imports: [UserProfileCoreModule,
            UserProfileOccModule,
            UserProfileComponentsModule,
            CaptchaModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserProfileModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        UserProfileCoreModule,
                        UserProfileOccModule,
                        UserProfileComponentsModule,
                        CaptchaModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/*
 * Public API Surface of user profile
 */

/**
 * Generated bundle index. Do not edit.
 */

export { UserProfileModule };
//# sourceMappingURL=spartacus-user-profile.mjs.map
