import * as i0 from '@angular/core';
import { inject, Injectable } from '@angular/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserWishlistAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserWishlistConnector {
    constructor() {
        this.adapter = inject(UserWishlistAdapter);
    }
    getWishlist(userId) {
        return this.adapter.getWishlist(userId);
    }
    addEntry(userId, wishlistId, productCode) {
        return this.adapter.addEntry(userId, wishlistId, productCode);
    }
    removeEntry(userId, wishlistId, entryId) {
        return this.adapter.removeEntry(userId, wishlistId, entryId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserWishlistConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserWishlistConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserWishlistConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { UserWishlistAdapter, UserWishlistConnector };
//# sourceMappingURL=spartacus-user-wishlist-core.mjs.map
