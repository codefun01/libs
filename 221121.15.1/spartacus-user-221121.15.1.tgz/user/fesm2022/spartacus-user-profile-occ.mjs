import * as i1 from '@angular/common/http';
import { HttpHeaders, HttpParams } from '@angular/common/http';
import * as i0 from '@angular/core';
import { inject, Injector, Injectable, NgModule } from '@angular/core';
import * as i2 from '@spartacus/core';
import { LoggerService, tryNormalizeHttpError, InterceptorUtil, USE_CLIENT_TOKEN, USE_CAPTCHA_TOKEN, provideDefaultConfig } from '@spartacus/core';
import { CaptchaApiConfig } from '@spartacus/storefront';
import { USER_PROFILE_SERIALIZER, USER_SIGN_UP_SERIALIZER, USER_PROFILE_NORMALIZER, TITLE_NORMALIZER, UserProfileAdapter } from '@spartacus/user/profile/core';
import { catchError, map } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOccUserProfileConfig = {
    backend: {
        occ: {
            endpoints: {
                userRegister: 'users',
                userForgotPassword: 'forgottenpasswordtokens',
                userRestoreToken: 'passwordRestoreToken',
                userResetPassword: 'resetpassword',
                userUpdateLoginId: 'users/${userId}/login',
                userUpdatePassword: 'users/${userId}/password',
                titles: 'titles',
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const CONTENT_TYPE_JSON_HEADER = { 'Content-Type': 'application/json' };
const CONTENT_TYPE_URLENCODED_HEADER = {
    'Content-Type': 'application/x-www-form-urlencoded',
};
class OccUserProfileAdapter {
    constructor(http, occEndpoints, converter) {
        this.http = http;
        this.occEndpoints = occEndpoints;
        this.converter = converter;
        this.logger = inject(LoggerService);
        this.captchaConfig = inject(CaptchaApiConfig, { optional: true });
        this.injector = inject(Injector, { optional: true });
    }
    update(userId, user) {
        const endpoint = this.occEndpoints.isConfigured('userUpdateProfile')
            ? 'userUpdateProfile'
            : 'user';
        const url = this.occEndpoints.buildUrl(endpoint, { urlParams: { userId } });
        user = this.converter.convert(user, USER_PROFILE_SERIALIZER);
        return this.http.patch(url, user).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    register(user) {
        const url = this.occEndpoints.buildUrl('userRegister');
        let headers = new HttpHeaders({
            ...CONTENT_TYPE_JSON_HEADER,
        });
        headers = InterceptorUtil.createHeader(USE_CLIENT_TOKEN, true, headers);
        headers = this.appendCaptchaToken(headers);
        user = this.converter.convert(user, USER_SIGN_UP_SERIALIZER);
        return this.http.post(url, user, { headers }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), this.converter.pipeable(USER_PROFILE_NORMALIZER));
    }
    registerGuest(guid, password) {
        const url = this.occEndpoints.buildUrl('userRegister');
        let headers = new HttpHeaders({
            ...CONTENT_TYPE_URLENCODED_HEADER,
        });
        headers = InterceptorUtil.createHeader(USE_CLIENT_TOKEN, true, headers);
        headers = this.appendCaptchaToken(headers);
        const httpParams = new HttpParams()
            .set('guid', guid)
            .set('password', password);
        return this.http.post(url, httpParams, { headers }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), this.converter.pipeable(USER_PROFILE_NORMALIZER));
    }
    requestForgotPasswordEmail(userEmailAddress) {
        const url = this.occEndpoints.buildUrl('userRestoreToken');
        const body = { loginId: userEmailAddress };
        let headers = new HttpHeaders(CONTENT_TYPE_JSON_HEADER);
        headers = InterceptorUtil.createHeader(USE_CLIENT_TOKEN, true, headers);
        return this.http.post(url, body, { headers }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    resetPassword(token, newPassword) {
        const url = this.occEndpoints.buildUrl('userResetPassword');
        let headers = new HttpHeaders({
            ...CONTENT_TYPE_JSON_HEADER,
        });
        headers = InterceptorUtil.createHeader(USE_CLIENT_TOKEN, true, headers);
        return this.http.post(url, { token, newPassword }, { headers }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    updateEmail(userId, currentPassword, newUserId) {
        const url = this.occEndpoints.buildUrl('userUpdateLoginId', {
            urlParams: { userId },
        });
        const body = {
            newLoginId: newUserId,
            password: currentPassword,
        };
        const headers = new HttpHeaders(CONTENT_TYPE_JSON_HEADER);
        return this.http.post(url, body, { headers }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    updatePassword(userId, oldPassword, newPassword) {
        const url = this.occEndpoints.buildUrl('userUpdatePassword', {
            urlParams: { userId },
        });
        const body = {
            oldPassword: oldPassword,
            newPassword: newPassword,
        };
        const headers = new HttpHeaders(CONTENT_TYPE_JSON_HEADER);
        return this.http.post(url, body, { headers }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    close(userId) {
        const endpoint = this.occEndpoints.isConfigured('userCloseAccount')
            ? 'userCloseAccount'
            : 'user';
        const url = this.occEndpoints.buildUrl(endpoint, { urlParams: { userId } });
        return this.http.delete(url).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    loadTitles() {
        const url = this.occEndpoints.buildUrl('titles');
        return this.http.get(url).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), map((titleList) => titleList.titles ?? []), this.converter.pipeableMany(TITLE_NORMALIZER));
    }
    appendCaptchaToken(currentHeaders) {
        if (this.injector && this.captchaConfig?.captchaRenderer) {
            const provider = this.injector.get(this.captchaConfig.captchaRenderer);
            const isCaptchaEnabled = provider
                .getCaptchaConfig()
                .subscribe((config) => {
                return config.enabled;
            });
            if (provider?.getToken() && isCaptchaEnabled) {
                return currentHeaders.append(USE_CAPTCHA_TOKEN, provider.getToken());
            }
        }
        return currentHeaders;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccUserProfileAdapter, deps: [{ token: i1.HttpClient }, { token: i2.OccEndpointsService }, { token: i2.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccUserProfileAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccUserProfileAdapter, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: i2.OccEndpointsService }, { type: i2.ConverterService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserProfileOccModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserProfileOccModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserProfileOccModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserProfileOccModule, providers: [
            provideDefaultConfig(defaultOccUserProfileConfig),
            { provide: UserProfileAdapter, useClass: OccUserProfileAdapter },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserProfileOccModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        provideDefaultConfig(defaultOccUserProfileConfig),
                        { provide: UserProfileAdapter, useClass: OccUserProfileAdapter },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OccUserProfileAdapter, UserProfileOccModule, defaultOccUserProfileConfig };
//# sourceMappingURL=spartacus-user-profile-occ.mjs.map
