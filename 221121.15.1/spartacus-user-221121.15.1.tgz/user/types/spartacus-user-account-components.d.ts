import * as i2$1 from '@angular/router';
import { Router, GuardResult, ActivatedRoute } from '@angular/router';
import * as i3 from '@spartacus/core';
import { WindowRef, SemanticPathService, AuthService, GlobalMessageService, AuthConfigService, CsrfStateService, FederatedLoginService, RoutingService, TranslationService } from '@spartacus/core';
import * as rxjs from 'rxjs';
import { Observable, BehaviorSubject } from 'rxjs';
import * as i0 from '@angular/core';
import { ElementRef, OnInit, ChangeDetectorRef } from '@angular/core';
import * as i2 from '@angular/forms';
import { UntypedFormGroup } from '@angular/forms';
import * as i1 from '@angular/common';
import * as i5 from '@spartacus/storefront';
import { LaunchDialogService, FocusConfig } from '@spartacus/storefront';
import * as _spartacus_user_account_root from '@spartacus/user/account/root';
import { User, UserAccountFacade, VerificationTokenFacade, VerificationToken, VerificationTokenCreation, VERIFICATION_TOKEN_DIALOG_ACTION } from '@spartacus/user/account/root';

declare class LoginAsGuestGuard {
    private featureConfigService;
    protected windowRef: WindowRef;
    protected router: Router;
    protected semanticPathService: SemanticPathService;
    protected getPath(): string | undefined;
    canActivate(): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginAsGuestGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoginAsGuestGuard>;
}

declare class LoginFormComponentService {
    protected auth: AuthService;
    protected globalMessage: GlobalMessageService;
    protected winRef: WindowRef;
    protected authConfigService: AuthConfigService;
    private featureConfigService;
    protected csrfStateService: CsrfStateService;
    protected router: Router;
    protected activatedRoute: ActivatedRoute;
    protected federatedLoginService: FederatedLoginService;
    protected readonly customFormValidErrors: string[];
    action?: string;
    method?: string;
    protected busy$: BehaviorSubject<boolean>;
    get csrf(): i3.CSRFResponse;
    isUpdating$: rxjs.Observable<boolean>;
    showResetPassword: boolean;
    form: UntypedFormGroup;
    constructor(auth: AuthService, globalMessage: GlobalMessageService, winRef: WindowRef);
    login(nativeForm?: HTMLFormElement): void;
    handleCustomLoginError(): void;
    protected resolveLoginErrorKey(error: string): string;
    protected onSuccess(isLoggedIn: boolean): void;
    protected initCustomLogin(): void;
    protected setOauthRedirectFlowFlag(): void;
    protected clearOauthRedirectFlowFlag(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginFormComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoginFormComponentService>;
}

declare class LoginFormComponent {
    protected service: LoginFormComponentService;
    loginForm: ElementRef<HTMLElementTagNameMap['form']>;
    style: boolean;
    form: UntypedFormGroup;
    isUpdating$: Observable<boolean>;
    csrf: i3.CSRFResponse;
    action: string | undefined;
    method: string | undefined;
    showResetPassword: boolean;
    constructor(service: LoginFormComponentService);
    onSubmit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoginFormComponent, "cx-login-form", never, {}, {}, never, never, true, never>;
}

declare class LoginFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LoginFormModule, never, [typeof i1.CommonModule, typeof i2.FormsModule, typeof i2.ReactiveFormsModule, typeof i2$1.RouterModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof i5.FormErrorsModule, typeof i5.SpinnerModule, typeof i5.PasswordVisibilityToggleModule, typeof i3.FeaturesConfigModule, typeof i5.FormRequiredAsterisksComponent, typeof i5.FormRequiredLegendComponent, typeof LoginFormComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LoginFormModule>;
}

declare class LoginRegisterComponent implements OnInit {
    protected activatedRoute: ActivatedRoute;
    loginAsGuest: boolean;
    protected routingService: RoutingService | null;
    constructor(activatedRoute: ActivatedRoute);
    ngOnInit(): void;
    navigateTo(cxRoute: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginRegisterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoginRegisterComponent, "cx-login-register", never, {}, {}, never, never, true, never>;
}

declare class LoginRegisterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginRegisterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LoginRegisterModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof i3.UrlModule, typeof i5.PageSlotModule, typeof i3.I18nModule, typeof i5.BtnLikeLinkModule, typeof LoginRegisterComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LoginRegisterModule>;
}

declare class LoginRegisterB2BComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginRegisterB2BComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoginRegisterB2BComponent, "cx-login-register-b2b", never, {}, {}, never, never, true, never>;
}

declare class LoginComponent implements OnInit {
    private auth;
    private userAccount;
    private translation;
    user$: Observable<User | undefined>;
    greeting$: Observable<string | undefined>;
    usingASMClient$: Observable<boolean>;
    constructor(auth: AuthService, userAccount: UserAccountFacade, translation: TranslationService);
    ngOnInit(): void;
    onRootNavBtnAdded($event: MutationRecord, greeting: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoginComponent, "cx-login", never, {}, {}, never, never, true, never>;
}

declare class LoginModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LoginModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof i3.UrlModule, typeof i5.PageSlotModule, typeof i3.I18nModule, typeof i5.DomChangeModule, typeof LoginComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LoginModule>;
}

declare class MyAccountV2UserComponent extends LoginComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2UserComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyAccountV2UserComponent, "cx-my-account-v2-user", never, {}, {}, never, never, true, never>;
}

declare class MyAccountV2UserModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2UserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MyAccountV2UserModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof MyAccountV2UserComponent], [typeof MyAccountV2UserComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MyAccountV2UserModule>;
}

declare class OneTimePasswordLoginFormComponent implements OnInit {
    protected routingService: RoutingService;
    protected verificationTokenFacade: VerificationTokenFacade;
    protected winRef: WindowRef;
    protected busy$: BehaviorSubject<boolean>;
    isUpdating$: Observable<boolean>;
    form: UntypedFormGroup;
    style: boolean;
    ngOnInit(): void;
    protected getStoredLoginState(): {
        loginId: string;
    } | null;
    protected clearStoredLoginState(): void;
    onSubmit(): void;
    protected goToVerificationTokenForm(verificationToken: VerificationToken, verificationTokenCreation: VerificationTokenCreation): void;
    protected onCreateVerificationTokenComplete(): void;
    protected collectDataFromLoginForm(): VerificationTokenCreation;
    static ɵfac: i0.ɵɵFactoryDeclaration<OneTimePasswordLoginFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OneTimePasswordLoginFormComponent, "cx-otp-login-form", never, {}, {}, never, never, true, never>;
}

declare class OneTimePasswordLoginFormModeule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OneTimePasswordLoginFormModeule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OneTimePasswordLoginFormModeule, never, [typeof i1.CommonModule, typeof i2.FormsModule, typeof i2.ReactiveFormsModule, typeof i2$1.RouterModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof i5.FormErrorsModule, typeof i5.SpinnerModule, typeof i5.PasswordVisibilityToggleModule, typeof i3.FeaturesConfigModule, typeof i5.FormRequiredAsterisksComponent, typeof i5.FormRequiredLegendComponent, typeof OneTimePasswordLoginFormComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OneTimePasswordLoginFormModeule>;
}

declare class VerificationTokenFormComponentService {
    protected authConfigService: AuthConfigService;
    private featureConfigService;
    protected auth: AuthService;
    protected csrfStateService: CsrfStateService;
    protected winRef: WindowRef;
    action?: string;
    method?: string;
    get csrf(): i3.CSRFResponse;
    constructor();
    protected globalMessage: GlobalMessageService;
    protected verificationTokenFacade: VerificationTokenFacade;
    protected busy$: BehaviorSubject<boolean>;
    isUpdating$: rxjs.Observable<boolean>;
    form: UntypedFormGroup;
    login(nativeForm?: HTMLFormElement): void;
    displayMessage(key: string, params: Object): void;
    createVerificationToken(loginId: string, password: string, purpose: string): rxjs.Observable<_spartacus_user_account_root.VerificationToken>;
    protected onSuccess(isLoggedIn: boolean): void;
    protected initCustomLogin(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VerificationTokenFormComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VerificationTokenFormComponentService>;
}

declare class VerificationTokenFormComponent implements OnInit {
    constructor();
    private featureConfigService;
    protected service: VerificationTokenFormComponentService;
    protected launchDialogService: LaunchDialogService;
    protected cdr: ChangeDetectorRef;
    protected routingService: RoutingService;
    protected winRef: WindowRef;
    waitTime: number;
    form: UntypedFormGroup;
    isUpdating$: Observable<boolean>;
    style: boolean;
    element: ElementRef;
    resendLink: ElementRef;
    tokenId: string;
    tokenCode: string;
    target: string;
    password: string;
    isResendDisabled: boolean;
    errorStatus: number;
    upToRateLimit: boolean;
    waitTimeForRateLimit: number;
    verificationTokenForm: ElementRef<HTMLElementTagNameMap['form']>;
    csrf: i3.CSRFResponse;
    action: string | undefined;
    method: string | undefined;
    ngOnInit(): void;
    onSubmit(): void;
    resendOTP(): void;
    startWaitTimeInterval(): void;
    openInfoDailog(): void;
    onOpenInfoDailogKeyDown(event: KeyboardEvent): void;
    startRateLimitWaitTimeInterval(): void;
    goBack(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VerificationTokenFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VerificationTokenFormComponent, "cx-verification-token-form", never, {}, {}, never, never, true, never>;
}

declare class VerificationTokenDialogComponent {
    protected launchDialogService: LaunchDialogService;
    VERIFICATION_TOKEN_DIALOG_ACTION: typeof VERIFICATION_TOKEN_DIALOG_ACTION;
    focusConfig: FocusConfig;
    constructor(launchDialogService: LaunchDialogService);
    closeModal(reason: VERIFICATION_TOKEN_DIALOG_ACTION): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VerificationTokenDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VerificationTokenDialogComponent, "cx-verification-token-dialog", never, {}, {}, never, never, true, never>;
}

declare class VerificationTokenFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VerificationTokenFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VerificationTokenFormModule, never, [typeof i1.CommonModule, typeof i2.FormsModule, typeof i5.KeyboardFocusModule, typeof i2.ReactiveFormsModule, typeof i2$1.RouterModule, typeof i3.UrlModule, typeof i5.IconModule, typeof i3.I18nModule, typeof i5.FormErrorsModule, typeof i5.SpinnerModule, typeof i3.FeaturesConfigModule, typeof i5.FormRequiredAsterisksComponent, typeof i5.FormRequiredLegendComponent, typeof VerificationTokenFormComponent, typeof VerificationTokenDialogComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VerificationTokenFormModule>;
}

declare class UserAccountComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAccountComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserAccountComponentsModule, never, [typeof LoginModule, typeof LoginFormModule, typeof VerificationTokenFormModule, typeof LoginRegisterModule, typeof MyAccountV2UserModule, typeof OneTimePasswordLoginFormModeule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserAccountComponentsModule>;
}

export { LoginAsGuestGuard, LoginComponent, LoginFormComponent, LoginFormComponentService, LoginFormModule, LoginModule, LoginRegisterB2BComponent, LoginRegisterComponent, LoginRegisterModule, MyAccountV2UserComponent, MyAccountV2UserModule, OneTimePasswordLoginFormComponent, OneTimePasswordLoginFormModeule, UserAccountComponentsModule, VerificationTokenFormComponent, VerificationTokenFormComponentService, VerificationTokenFormModule };
