import * as i0 from '@angular/core';
import { OnInit, OnDestroy, OnChanges, ViewContainerRef, Injector, AfterViewInit, ChangeDetectorRef, EventEmitter, QueryList, ElementRef, AfterContentChecked, InjectionToken } from '@angular/core';
import * as i2$1 from '@angular/forms';
import { UntypedFormControl, ValidatorFn } from '@angular/forms';
import { ActiveCartFacade, OrderEntry, MultiCartFacade, CartModification } from '@spartacus/cart/base/root';
import * as i2 from '@spartacus/core';
import { StateUtils, UserIdService, LoggerService, WindowRef, ProductService, RoutingService, GlobalMessageService, TranslationService, Config, Product, LanguageService, ImageGroup, EventService, ErrorAction, OccEndpoint, Converter, OccConfig, ConverterService, OccEndpointsService } from '@spartacus/core';
import { OrderHistoryFacade } from '@spartacus/order/root';
import { CommonConfigurator, CommonConfiguratorUtilsService, ConfiguratorRouterExtractorService, ConfiguratorRouter } from '@spartacus/product-configurator/common';
import * as i3 from '@spartacus/storefront';
import { KeyboardFocusService, IntersectionService, ICON_TYPE, DirectionService, FocusConfig, BreakpointService, LaunchDialogService, HamburgerMenuService } from '@spartacus/storefront';
import * as rxjs from 'rxjs';
import { Observable, Subscription, BehaviorSubject } from 'rxjs';
import * as i3$1 from '@ngrx/store';
import { Store, Action, MemoizedSelector } from '@ngrx/store';
import { CheckoutQueryFacade } from '@spartacus/checkout/base/root';
import * as i1 from '@angular/common';
import { Location } from '@angular/common';
import * as i6 from '@ng-select/ng-select';
import * as i6$1 from '@angular/router';
import * as i4 from '@ngrx/effects';
import { HttpClient, HttpContext } from '@angular/common/http';

declare namespace Configurator {
    interface Attribute {
        attrCode?: number;
        name: string;
        label?: string;
        description?: string;
        required?: boolean;
        incomplete?: boolean;
        uiType?: UiType;
        /** Allows to work with a custom variation of an uiType, in order to register a specific component for rendering an attribute.
         * In case a custom variation exist, it is of format <OCC uiType>___<X>, e.g. RADIO_BUTTON___CUSTOM.
         * The normalizers do not change it and just use the first portion of it to find the uiType the SPA business logic
         * is attached to. Per default, if no customization is present, this attribute matches the OCC uiType */
        uiTypeVariation?: string;
        dataType?: DataType;
        quantity?: number;
        values?: Value[];
        groupId?: string;
        selectedSingleValue?: string;
        userInput?: string;
        isLineItem?: boolean;
        maxlength?: number;
        images?: Image[];
        numDecimalPlaces?: number;
        numTotalLength?: number;
        negativeAllowed?: boolean;
        hasNonNavigableConflict?: boolean;
        hasConflicts?: boolean;
        retractTriggered?: boolean;
        attributePriceTotal?: PriceDetails;
        intervalInDomain?: boolean;
        key?: string;
        validationType?: string;
        visible?: boolean;
        domainOnDemand?: boolean;
    }
    interface Value {
        valueCode: string;
        name?: string;
        valueDisplay?: string;
        description?: string;
        selected?: boolean;
        quantity?: number;
        valuePrice?: PriceDetails;
        valuePriceTotal?: PriceDetails;
        productSystemId?: string;
        isCommerceProduct?: boolean;
        images?: Image[];
    }
    interface Group {
        attributes?: Attribute[];
        id: string;
        name?: string;
        description?: string;
        groupType?: GroupType;
        configurable?: boolean;
        complete?: boolean;
        consistent?: boolean;
        subGroups: Group[];
    }
    interface ValueSupplement {
        attributeValueKey: string;
        priceValue: PriceDetails;
        obsoletePriceValue: PriceDetails;
    }
    interface AttributeSupplement {
        attributeUiKey: string;
        valueSupplements: ValueSupplement[];
    }
    interface Configuration {
        configId: string;
        consistent?: boolean;
        complete?: boolean;
        totalNumberOfIssues?: number;
        productCode: string;
        groups: Group[];
        flatGroups: Group[];
        priceSupplements?: AttributeSupplement[];
        priceSummary?: PriceSummary;
        overview?: Overview;
        owner: CommonConfigurator.Owner;
        nextOwner?: CommonConfigurator.Owner;
        isCartEntryUpdateRequired?: boolean;
        interactionState: InteractionState;
        updateType?: UpdateType;
        errorMessages?: string[];
        warningMessages?: string[];
        variants?: Variant[];
        kbKey?: KB;
        pricingEnabled?: boolean;
        hideBasePriceAndSelectedOptions?: boolean;
        immediateConflictResolution?: boolean;
        newConfiguration?: boolean;
        isPricingAsync?: boolean;
    }
    interface ConfigurationWithOverview extends Configuration {
        overview: Overview;
    }
    interface InteractionState {
        currentGroup?: string;
        menuParentGroup?: string;
        groupsVisited?: {
            [id: string]: boolean;
        };
        issueNavigationDone?: boolean;
        isConflictResolutionMode?: boolean;
        showConflictSolverDialog?: boolean;
        newConfiguration?: boolean;
    }
    interface Overview {
        configId: string;
        totalNumberOfIssues?: number;
        numberOfIncompleteCharacteristics?: number;
        numberOfConflicts?: number;
        groups?: GroupOverview[];
        priceSummary?: PriceSummary;
        productCode: string;
        attributeFilters?: OverviewFilter[];
        groupFilters?: string[];
        possibleGroups?: GroupOverview[];
    }
    interface GroupOverview {
        id: string;
        groupDescription?: string;
        attributes?: AttributeOverview[];
        subGroups?: GroupOverview[];
    }
    interface AttributeOverview {
        attribute: string;
        attributeId?: string;
        value: string;
        valueId?: string;
        productCode?: string;
        type?: AttributeOverviewType;
        quantity?: number;
        valuePrice?: PriceDetails;
        valuePriceTotal?: PriceDetails;
    }
    interface PriceSummary {
        basePrice?: PriceDetails;
        currentTotal?: PriceDetails;
        currentTotalSavings?: PriceSavingDetails;
        selectedOptions?: PriceDetails;
    }
    interface PriceDetails {
        currencyIso: string;
        formattedValue?: string;
        value: number;
    }
    interface PriceSavingDetails extends PriceDetails {
        maxQuantity?: number;
        minQuantity?: number;
    }
    interface AddToCartParameters {
        userId: string;
        cartId: string;
        productCode: string;
        quantity: number;
        configId: string;
        owner: CommonConfigurator.Owner;
    }
    interface UpdateConfigurationForCartEntryParameters {
        userId: string;
        cartId: string;
        cartEntryNumber: string;
        configuration: Configurator.Configuration;
    }
    interface Image {
        type?: ImageType;
        format?: ImageFormatType;
        url?: string;
        altText?: string;
        galleryIndex?: number;
    }
    interface Variant {
        productCode: string;
    }
    interface KB {
        kbName?: string;
        kbLogsys?: string;
        kbVersion?: string;
        kbBuildNumber?: string;
    }
    enum GroupType {
        ATTRIBUTE_GROUP = "AttributeGroup",
        SUB_ITEM_GROUP = "SubItemGroup",
        CONFLICT_HEADER_GROUP = "ConflictHeaderGroup",
        CONFLICT_GROUP = "ConflictGroup"
    }
    enum UiType {
        NOT_IMPLEMENTED = "not_implemented",
        RADIOBUTTON = "radioGroup",
        RADIOBUTTON_ADDITIONAL_INPUT = "radioGroup_add",
        CHECKBOX = "checkBox",
        CHECKBOXLIST = "checkBoxList",
        DROPDOWN = "dropdown",
        DROPDOWN_ADDITIONAL_INPUT = "dropdown_add",
        LISTBOX = "listbox",
        LISTBOX_MULTI = "listboxmulti",
        READ_ONLY = "readonly",
        READ_ONLY_SINGLE_SELECTION_IMAGE = "read_only_single_selection_image",
        READ_ONLY_MULTI_SELECTION_IMAGE = "read_only_multi_selection_image",
        STRING = "string",
        NUMERIC = "numeric",
        SAP_DATE = "sap_date",
        AUTO_COMPLETE_CUSTOM = "input_autocomplete",
        MULTI_SELECTION_IMAGE = "multi_selection_image",
        SINGLE_SELECTION_IMAGE = "single_selection_image",
        CHECKBOXLIST_PRODUCT = "checkBoxListProduct",
        DROPDOWN_PRODUCT = "dropdownProduct",
        RADIOBUTTON_PRODUCT = "radioGroupProduct"
    }
    enum ImageFormatType {
        VALUE_IMAGE = "VALUE_IMAGE",
        ATTRIBUTE_IMAGE = "ATTRIBUTE_IMAGE"
    }
    enum ImageType {
        PRIMARY = "PRIMARY",
        GALLERY = "GALLERY"
    }
    enum DataType {
        INPUT_STRING = "String",
        INPUT_NUMBER = "Number",
        USER_SELECTION_QTY_ATTRIBUTE_LEVEL = "UserSelectionWithAttributeQuantity",
        USER_SELECTION_QTY_VALUE_LEVEL = "UserSelectionWithValueQuantity",
        USER_SELECTION_NO_QTY = "UserSelectionWithoutQuantity",
        NOT_IMPLEMENTED = "not_implemented"
    }
    enum UpdateType {
        ATTRIBUTE = "Attribute",
        ATTRIBUTE_QUANTITY = "AttributeQuantity",
        VALUE_QUANTITY = "ValueQuantity"
    }
    enum AttributeOverviewType {
        GENERAL = "general",
        BUNDLE = "bundle"
    }
    enum ValidationType {
        NONE = "NONE",
        NUMERIC = "NUMERIC",
        SAP_DATE = "SAP_DATE"
    }
    enum OverviewFilter {
        VISIBLE = "PRIMARY",
        USER_INPUT = "USER_INPUT",
        PRICE_RELEVANT = "PRICE_RELEVANT"
    }
    const ConflictIdPrefix = "CONFLICT";
    const ConflictHeaderId = "CONFLICT_HEADER";
    const CustomUiTypeIndicator = "___";
    const RetractValueCode = "###RETRACT_VALUE_CODE###";
}

declare const CONFIGURATOR_FEATURE = "productConfigurator";
declare const CONFIGURATOR_DATA = "[Configurator] Configuration Data";
interface StateWithConfigurator {
    [CONFIGURATOR_FEATURE]: ConfiguratorState;
}
interface ConfiguratorState {
    configurations: StateUtils.EntityProcessesLoaderState<Configurator.Configuration>;
}

/**
 * Utility service for the facade layer. Supposed to be accessed by facade services
 */
declare class ConfiguratorUtilsService {
    /**
     * Determines the direct parent group for an attribute group
     * @param {Configurator.Group[]} groups - List of groups where we search for parent
     * @param {Configurator.Group} group - If already part of groups, no further search is needed, and we return the provided parent group
     * @param {Configurator.Group} parentGroup - Optional parent group.
     * @returns {Configurator.Group | undefined} - Parent group. Might be undefined
     */
    getParentGroup(groups: Configurator.Group[], group: Configurator.Group, parentGroup?: Configurator.Group): Configurator.Group | undefined;
    /**
     * Finds group identified by its ID, and ensures that we always get a valid group.
     * If nothing is found in the configuration group list, this methods returns the first group.
     *
     * The exceptional case can happen if e.g. an edit in a conflict was done that
     * resolved the conflict, or if a group vanished due to object dependencies.
     * @param {Configurator.Group[]} groups - List of groups
     * @param {string} groupId - Group id
     * @returns {Configurator.Group} - Group identified by its id, if available. Otherwise first group
     */
    getGroupById(groups: Configurator.Group[], groupId: string): Configurator.Group;
    /**
     * Finds group identified by its ID. If nothing is found, this
     * methods returns undefined
     * @param {Configurator.Group[]} groups - List of groups
     * @param {string} groupId - Group id
     * @returns {Configurator.Group | undefined} - Group identified by its id, if available. Otherwise undefined
     */
    getOptionalGroupById(groups: Configurator.Group[], groupId: string): Configurator.Group | undefined;
    protected getGroupByIdIfPresent(groups: Configurator.Group[], groupId: string): Configurator.Group | undefined;
    protected getGroupFromSubGroups(groups: Configurator.Group[], groupId: string): Configurator.Group | undefined;
    /**
     * Verifies whether the current group has a subgroups.
     *
     * @param {Configurator.Group} group - Current group
     * @return {boolean} - 'True' if the current group has any subgroups, otherwise 'false'
     */
    hasSubGroups(group: Configurator.Group): boolean;
    /**
     * Verifies whether the configuration has been created.
     *
     * @param {Configurator.Configuration} configuration - Configuration
     * @return {boolean} - 'True' if the configuration hass been created, otherwise 'false'
     */
    isConfigurationCreated(configuration?: Configurator.Configuration): boolean;
    /**
     * Creates configuration extract.
     *
     * @param {Configurator.Attribute} changedAttribute - changed configuration
     * @param {Configurator.Configuration} configuration - configuration
     * @param {Configurator.UpdateType} updateType - updated type
     * @return {Configurator.Configuration} - Configuration
     */
    createConfigurationExtract(changedAttribute: Configurator.Attribute, configuration: Configurator.Configuration, updateType?: Configurator.UpdateType): Configurator.Configuration;
    /**
     * Builds group path.
     *
     * @param {string} groupId - Group ID
     * @param { Configurator.Group[]} groupList - List of groups
     * @param { Configurator.Group[]} groupPath - Path of groups
     * @return {boolean} - 'True' if the group has been found, otherwise 'false'
     */
    buildGroupPath(groupId: string, groupList: Configurator.Group[], groupPath: Configurator.Group[]): boolean;
    /**
     * Retrieves the configuration from state, and throws an error in case the configuration is
     * not available
     * @param {StateUtils.ProcessesLoaderState<Configurator.Configuration>} configurationState - Process loader state containing product configuration
     * @returns {Configurator.Configuration} - The actual product configuration
     */
    getConfigurationFromState(configurationState: StateUtils.ProcessesLoaderState<Configurator.Configuration>): Configurator.Configuration;
    protected buildGroupForExtract(group: Configurator.Group): Configurator.Group;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorUtilsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorUtilsService>;
}

declare class ConfiguratorCartService {
    protected store: Store<StateWithConfigurator>;
    protected activeCartService: ActiveCartFacade;
    protected commonConfigUtilsService: CommonConfiguratorUtilsService;
    protected checkoutQueryFacade: CheckoutQueryFacade;
    protected userIdService: UserIdService;
    protected configuratorUtilsService: ConfiguratorUtilsService;
    constructor(store: Store<StateWithConfigurator>, activeCartService: ActiveCartFacade, commonConfigUtilsService: CommonConfiguratorUtilsService, checkoutQueryFacade: CheckoutQueryFacade, userIdService: UserIdService, configuratorUtilsService: ConfiguratorUtilsService);
    /**
     * Reads a configuration that is attached to a cart entry, dispatching the respective action.
     *
     * @param owner Configuration owner
     * @returns Observable of product configurations
     */
    readConfigurationForCartEntry(owner: CommonConfigurator.Owner): Observable<Configurator.Configuration>;
    /**
     * Reads a read-only configuration that is attached to a document entry, dispatching the respective action.
     * The document can be an order, a quote or a saved cart
     *
     * @param owner Configuration owner
     * @returns Observable of product configurations
     */
    readConfigurationForOrderEntry(owner: CommonConfigurator.Owner): Observable<Configurator.Configuration>;
    /**
     * Adds a configuration to the cart, specified by the product code, a configuration ID and configuration owner key.
     *
     * @param productCode - Product code
     * @param configId - Configuration ID
     * @param owner - Configuration owner
     * @param quantity - Quantity
     */
    addToCart(productCode: string, configId: string, owner: CommonConfigurator.Owner, quantity?: number): void;
    /**
     * Updates a cart entry, specified by the configuration.
     * The cart entry number for the entry that owns the configuration can be told
     * from the configuration's owner ID
     *
     * @param configuration - Configuration
     */
    updateCartEntry(configuration: Configurator.Configuration): void;
    /**
     * Can be used to check if the active cart has any product configuration issues.
     *
     * @returns True if and only if there is at least one cart entry with product configuration issues
     */
    activeCartHasIssues(): Observable<boolean>;
    /**
     * Retrieves cart entry by a cart entry number.
     *
     * @param {string} entryNumber - Entry number
     * @returns {Observable<OrderEntry | undefined>} - Cart entry
     */
    getEntry(entryNumber: string): Observable<OrderEntry | undefined>;
    /**
     * Remove all configurations that are linked to cart entries
     */
    removeCartBoundConfigurations(): void;
    protected isConfigurationCreated(configuration: Configurator.Configuration): boolean;
    protected configurationNeedsReading(configurationState: StateUtils.LoaderState<Configurator.Configuration>): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorCartService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorCartService>;
}

declare class ConfiguratorCommonsService {
    protected store: Store<StateWithConfigurator>;
    protected commonConfigUtilsService: CommonConfiguratorUtilsService;
    protected configuratorCartService: ConfiguratorCartService;
    protected activeCartService: ActiveCartFacade;
    protected configuratorUtils: ConfiguratorUtilsService;
    protected logger: LoggerService;
    constructor(store: Store<StateWithConfigurator>, commonConfigUtilsService: CommonConfiguratorUtilsService, configuratorCartService: ConfiguratorCartService, activeCartService: ActiveCartFacade, configuratorUtils: ConfiguratorUtilsService);
    /**
     * Verifies whether there are any pending configuration changes.
     *
     * @param owner - Configuration owner
     *
     * @returns {Observable<boolean>} Returns true if there are any pending changes, otherwise false
     */
    hasPendingChanges(owner: CommonConfigurator.Owner): Observable<boolean>;
    /**
     * Verifies whether the configuration is loading.
     *
     * @param owner - Configuration owner
     *
     * @returns {Observable<boolean>} Returns true if the configuration is loading, otherwise false
     */
    isConfigurationLoading(owner: CommonConfigurator.Owner): Observable<boolean>;
    /**
     * Returns a configuration for an owner. Emits only if there are valid configurations
     * available for the requested owner, does not trigger the re-read or
     * creation of the configuration in case it's not there
     *
     * @param owner - Configuration owner
     *
     * @returns {Observable<Configurator.Configuration>}
     */
    getConfiguration(owner: CommonConfigurator.Owner): Observable<Configurator.Configuration>;
    /**
     * Returns a configuration if it exists or creates a new one.
     * Emits if there is a valid configuration available and triggers
     * the configuration creation or read from backend in case it is not
     * available
     *
     * @param owner - Configuration owner
     * @returns {Observable<Configurator.Configuration>}
     */
    getOrCreateConfiguration(owner: CommonConfigurator.Owner, configIdTemplate?: string): Observable<Configurator.Configuration>;
    /**
     * Updates a configuration, specified by the configuration owner key, group ID and a changed attribute.
     *
     * @param ownerKey - Configuration owner key
     * @param changedAttribute - Changes attribute
     */
    updateConfiguration(ownerKey: string, changedAttribute: Configurator.Attribute, updateType?: Configurator.UpdateType): void;
    /**
     * Returns a configuration with an overview. Emits valid configurations which
     * include the overview aspect.
     * When calling this function it is assumed that the configuration itself is already
     * available (or its loading is triggered). If not, the function will return an empty observable.
     *
     * @param configuration - Configuration
     * @returns Observable of configurations including the overview
     */
    getConfigurationWithOverview(configuration: Configurator.Configuration): Observable<Configurator.Configuration>;
    protected filterNotLoadingAndCreatedConfiguration(loaderState$: Observable<StateUtils.LoaderState<Configurator.Configuration>>): Observable<Configurator.Configuration>;
    /**
     * Updates configuration overview according to group and attribute filters
     *
     * @param configuration - Configuration. Can contain filters in its overview facet
     */
    updateConfigurationOverview(configuration: Configurator.Configuration): void;
    /**
     * Removes a configuration.
     *
     * @param owner - Configuration owner
     */
    removeConfiguration(owner: CommonConfigurator.Owner): void;
    /**
     * Dismisses conflict solver dialog
     *
     * @param owner - Configuration owner
     */
    dismissConflictSolverDialog(owner: CommonConfigurator.Owner): void;
    /**
     * Check if we need to launch conflict solver dialog
     *
     * @param owner - Configuration owner
     */
    checkConflictSolverDialog(owner: CommonConfigurator.Owner): void;
    /**
     * Checks if the configuration contains conflicts that are displayed as conflict groups. Note
     * that in case conflicts are displayed by the conflict solver dialog, they are not taken into
     * account for this method
     *
     * @param owner - Configuration owner
     *
     * @returns {Observable<boolean>} - Returns true if the configuration has conflicts, otherwise false
     */
    hasConflicts(owner: CommonConfigurator.Owner): Observable<boolean>;
    /**
     * Forces the creation of a new default configuration for the given owner
     * @param owner - Configuration owner
     */
    forceNewConfiguration(owner: CommonConfigurator.Owner): void;
    protected getOrCreateConfigurationForProduct(owner: CommonConfigurator.Owner, configIdTemplate?: string): Observable<Configurator.Configuration>;
    protected hasConfigurationOverview(configuration: Configurator.Configuration): boolean;
    /**
     * Removes product bound configurations that is linked to state
     */
    removeProductBoundConfigurations(): void;
    /**
     * Fetches the domain values for the given attribute
     *
     * @param owner Configuration Owner
     * @param group  UI Group the attribute belongs to
     * @param attribute Attribute itself
     */
    readAttributeDomain(owner: CommonConfigurator.Owner, group: Configurator.Group, attribute: Configurator.Attribute): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorCommonsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorCommonsService>;
}

/**
 * Service for handling group statuses
 */
declare class ConfiguratorGroupStatusService {
    protected store: Store<StateWithConfigurator>;
    protected configuratorUtilsService: ConfiguratorUtilsService;
    constructor(store: Store<StateWithConfigurator>, configuratorUtilsService: ConfiguratorUtilsService);
    /**
     * Verifies whether the group has been visited.
     *
     * @param {CommonConfigurator.Owner} owner - Configuration owner
     * @param {string} groupId - Group ID
     * @returns {Observable<boolean>} Has group been visited?
     */
    isGroupVisited(owner: CommonConfigurator.Owner, groupId: string): Observable<boolean>;
    /**
     * Returns the first non-conflict group of the configuration which is not completed
     * and undefined if all are completed.
     *
     * @param {Configurator.Configuration} configuration - Configuration
     *
     * @return {Configurator.Group} - First incomplete group or undefined
     */
    getFirstIncompleteGroup(configuration: Configurator.Configuration): Configurator.Group | undefined;
    /**
     * Determines whether the group has been visited or not.
     *
     * @param {Configurator.Configuration} configuration - Configuration
     * @param {string} groupId - Group ID
     */
    setGroupStatusVisited(configuration: Configurator.Configuration, groupId: string): void;
    protected areGroupsVisited(owner: CommonConfigurator.Owner, groupIds: string[]): Observable<boolean>;
    protected getParentGroupStatusVisited(configuration: Configurator.Configuration, groupId: string, parentGroup: Configurator.Group, visitedGroupIds: string[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorGroupStatusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorGroupStatusService>;
}

/**
 * Service for handling configuration groups
 */
declare class ConfiguratorGroupsService {
    protected store: Store<StateWithConfigurator>;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configuratorUtilsService: ConfiguratorUtilsService;
    protected configuratorGroupStatusService: ConfiguratorGroupStatusService;
    constructor(store: Store<StateWithConfigurator>, configuratorCommonsService: ConfiguratorCommonsService, configuratorUtilsService: ConfiguratorUtilsService, configuratorGroupStatusService: ConfiguratorGroupStatusService);
    /**
     * Returns the current group Id.
     * In case no group Id is being set before returns the first group of the configuration.
     * Return null when configuration contains no groups.
     *
     * @param {CommonConfigurator.Owner} owner configuration owner
     * @returns {Observable<string>} Group ID
     */
    getCurrentGroupId(owner: CommonConfigurator.Owner): Observable<string>;
    /**
     * Return the first conflict group of a configuration or undefined
     * if not present
     *
     * @param {Configurator.Configuration} configuration - Configuration
     * @returns {Configurator.Group} Conflict group
     */
    getFirstConflictGroup(configuration: Configurator.Configuration): Configurator.Group | undefined;
    /**
     * Navigates to the first non-conflict group of the configuration which is not completed.
     * This method assumes that the configuration has incomplete groups,
     * the caller has to verify this prior to calling this method. In case no incomplete group is
     * present, nothing will happen
     *
     * @param {CommonConfigurator.Owner} owner - Configuration owner
     */
    navigateToFirstIncompleteGroup(owner: CommonConfigurator.Owner): void;
    /**
     * Navigates to the first conflict group and sets the conflict header as parent group.
     * This method assumes that the configuration has conflicts,
     * the caller has to verify this prior to calling this method. In case no conflict group
     * is present, nothing will happen
     *
     * @param {CommonConfigurator.Owner} owner Configuration Owner
     */
    navigateToConflictSolver(owner: CommonConfigurator.Owner): void;
    /**
     * Returns the parent group of the subgroup that is displayed in the group menu.
     *
     * @param {CommonConfigurator.Owner} owner - Configuration owner
     * @returns {Observable<Configurator.Group>} Group
     */
    getMenuParentGroup(owner: CommonConfigurator.Owner): Observable<Configurator.Group | undefined>;
    /**
     * Set the parent group, specified by the group ID, which is displayed in the group menu.
     *
     * @param {CommonConfigurator.Owner} owner - Configuration owner
     * @param {string} groupId - Group ID. Can be ommitted, in this case parent group will be cleared, in case we are on root level
     */
    setMenuParentGroup(owner: CommonConfigurator.Owner, groupId?: string): void;
    /**
     * Returns the group that is currently visited.
     *
     * @param {CommonConfigurator.Owner} owner - Configuration owner
     * @return {Observable<Configurator.Group>} Current group
     */
    getCurrentGroup(owner: CommonConfigurator.Owner): Observable<Configurator.Group>;
    /**
     * Retrieves a conflict group for immediate conflict resolution.
     *
     * @param {CommonConfigurator.Owner} owner - Configuration owner
     * @return {Observable<Configurator.Group | undefined} - Conflict group
     */
    getConflictGroupForImmediateConflictResolution(owner: CommonConfigurator.Owner): Observable<Configurator.Group | undefined>;
    /**
     * Determines whether the group has been visited or not.
     *
     * @param {CommonConfigurator.Owner} owner - Owner
     * @param {string} groupId - Group ID
     */
    setGroupStatusVisited(owner: CommonConfigurator.Owner, groupId: string): void;
    /**
     * Navigates to the group, specified by its group ID.
     *
     * @param {Configurator.Configuration}configuration - Configuration
     * @param {string} groupId - Group ID
     * @param {boolean} setStatus - Group status will be set for previous group, default true
     * @param {boolean} conflictResolutionMode - Parameter with default (false). If set to true, we enter the conflict resolution mode, i.e.
     *  if a conflict is solved, the system will navigate to the next conflict present
     */
    navigateToGroup(configuration: Configurator.Configuration, groupId: string, setStatus?: boolean, conflictResolutionMode?: boolean): void;
    /**
     * Returns the group ID of the group that is coming after the current one in a sequential order.
     *
     * @param {CommonConfigurator.Owner} owner - Configuration owner
     * @return {Observable<string> | undefined} ID of next group
     */
    getNextGroupId(owner: CommonConfigurator.Owner): Observable<string | undefined>;
    /**
     * Returns the description of the next group.
     *
     * @param {Configurator.Configuration} configuration - configuration
     * @returns {Observable<string>}  The description of the next group
     */
    getNextGroupDescription(configuration: Configurator.Configuration): Observable<string>;
    protected getDescriptionForGroupId(groupId: string, configuration: Configurator.Configuration): string;
    /**
     * Returns the group ID of the group that is preceding the current one in a sequential order.
     *
     * @param {CommonConfigurator.Owner} owner - Configuration owner
     * @return {Observable<string | undefined >} ID of previous group
     */
    getPreviousGroupId(owner: CommonConfigurator.Owner): Observable<string | undefined>;
    /**
     * Returns the description of the previous group.
     *
     * @param {Configurator.Configuration} configuration - configuration
     * @returns {Observable<string>}  The description of the previous group
     */
    getPreviousGroupDescription(configuration: Configurator.Configuration): Observable<string>;
    /**
     * Verifies whether the group has been visited
     *
     * @param {CommonConfigurator.Owner} owner - Configuration owner
     * @param {string} groupId - Group ID
     * @return {Observable<boolean>} Has been visited?
     */
    isGroupVisited(owner: CommonConfigurator.Owner, groupId: string): Observable<boolean>;
    /**
     * Returns a parent group for the given group.
     *
     * @param {Configurator.Group[]} groups - List of groups where we search for the parent group
     * @param {Configurator.Group} group - Given group
     * @return {Configurator.Group} Parent group or undefined if group is a top-level group
     */
    getParentGroup(groups: Configurator.Group[], group: Configurator.Group): Configurator.Group | undefined;
    /**
     * Verifies whether the given group has sub groups.
     *
     * @param {Configurator.Group} group - Given group
     * @return {boolean} Sub groups available?
     */
    hasSubGroups(group: Configurator.Group): boolean;
    protected isConflictGroupInImmediateConflictResolutionMode(groupType: Configurator.GroupType | undefined, immediateConflictResolution?: boolean): boolean;
    /**
     * Retrieves a group ID of the neighboring group.
     *
     * @param {CommonConfigurator.Owner} owner - Configuration owner
     * @param {number} neighboringIndex - Index of neighboring group
     * @return {Observable<string>} group ID of the neighboring group
     */
    protected getNeighboringGroupId(owner: CommonConfigurator.Owner, neighboringIndex: number): Observable<string | undefined>;
    /**
     * Verifies whether the current group is conflict one.
     *
     * @param {Configurator.GroupType} groupType - Group type
     * @return {boolean} - 'True' if the current group is conflict one, otherwise 'false'.
     */
    isConflictGroupType(groupType: Configurator.GroupType): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorGroupsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorGroupsService>;
}

/**
 * To implement custom solution provide your own implementation and customize services that use ConfiguratorQuantityService
 */
declare class ConfiguratorQuantityService {
    private _quantity;
    /**
     * Sets the configuration quantity.
     *
     * @param quantity
     */
    setQuantity(quantity: number): void;
    /**
     * Retrieves the configuration quantity.
     *
     * @returns {Observable<number>} - Configuration quantity.
     */
    getQuantity(): Observable<number>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorQuantityService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorQuantityService>;
}

declare class ConfiguratorStorefrontUtilsService {
    protected configuratorGroupsService: ConfiguratorGroupsService;
    protected windowRef: WindowRef;
    protected keyboardFocusService: KeyboardFocusService;
    protected productService: ProductService;
    protected routingService: RoutingService;
    /**
     * 'CX' prefix is used to generate an alphanumeric prefix ID.
     */
    protected readonly CX_PREFIX = "cx";
    protected readonly SEPARATOR = "--";
    protected readonly CONFIGURATOR_PREFIX: string;
    /**
     * Height of a CSS box model of an 'add-to-cart' button
     * See _configurator-add-to-cart-button.scss
     */
    protected readonly ADD_TO_CART_BUTTON_HEIGHT = 82;
    protected logger: LoggerService;
    /**
     * Last selected attribute and value.
     * Needed for accessibility of checkboxes for delta rendering
     */
    protected lastSelected?: {
        attributeName: string;
        valueCode: string;
    };
    constructor(configuratorGroupsService: ConfiguratorGroupsService, windowRef: WindowRef, keyboardFocusService: KeyboardFocusService);
    /**
     * Does the configuration belong to a cart entry, or has the group been visited already?
     * In both cases we need to render indications for mandatory attributes.
     * This method emits only once and then stops further emissions.
     *
     * @param {CommonConfigurator.Owner} owner -
     * @param {string} groupId - Group ID
     * @return {Observable<boolean>} - Returns 'Observable<true>' if the cart entry or group are visited, otherwise 'Observable<false>'
     */
    isCartEntryOrGroupVisited(owner: CommonConfigurator.Owner, groupId: string): Observable<boolean>;
    /**
     * Assemble an attribute value with the currently selected values from a checkbox list.
     *
     * @param {UntypedFormControl[]} controlArray - Control array
     * @param {Configurator.Attribute} attribute -  Configuration attribute
     * @return {Configurator.Value[]} - list of configurator values
     */
    assembleValuesForMultiSelectAttributes(controlArray: UntypedFormControl[], attribute: Configurator.Attribute): Configurator.Value[];
    /**
     * Scrolls to the corresponding HTML element.
     *
     * @param {Element | HTMLElement} element - HTML element
     */
    protected scroll(element: Element | HTMLElement): void;
    /**
     * Scrolls to the corresponding configuration element in the HTML tree.
     *
     * @param {string} selector - Selector of the HTML element
     */
    scrollToConfigurationElement(selector: string): void;
    /**
     * Focus the first attribute in the form.
     */
    focusFirstAttribute(): void;
    /**
     * Focus the first active element inside the given host element
     *
     * @param selector - query selector of the host element
     */
    focusFirstActiveElement(selector: string): void;
    protected getFocusableElementById(focusableElements: HTMLElement[], id?: string): HTMLElement | undefined;
    protected getFocusableConflictDescription(focusableElements: HTMLElement[]): HTMLElement | undefined;
    protected getFocusableElementByValueUiKey(focusableElements: HTMLElement[], valueUiKey?: string): HTMLElement | undefined;
    protected getFocusableElementByAttributeId(focusableElements: HTMLElement[], attributeName: string): HTMLElement | undefined;
    protected createAttributeValueUiKey(attributeId: string, valueId: string): string;
    /**
     * Creates unique key for config attribute on the UI
     *
     * @param prefix for key depending on usage (e.g. uiType, label)
     * @param attributeId
     */
    createAttributeUiKey(prefix: string, attributeId: string): string;
    /**
     * Focus a value in the form.
     *
     * @param {Configurator.Attribute} attribute - Attribute
     */
    focusValue(attribute: Configurator.Attribute): void;
    protected focusOnElements(focusableElements: HTMLElement[], attribute: Configurator.Attribute): void;
    protected focusOnElementForConflicting(attribute: Configurator.Attribute, foundFocusableElement: HTMLElement | undefined, focusableElements: HTMLElement[]): HTMLElement | undefined;
    /**
     * Retrieves a unique prefix ID.
     *
     * @param {string | undefined} prefix - prefix that we need to make the ID unique
     * @param {string} groupId - group ID
     * @returns {string} - prefix ID
     */
    getPrefixId(idPrefix: string | undefined, groupId: string): string;
    /**
     * Generates a group ID.
     *
     * @param {string} groupId - group ID
     * @returns {string | undefined} - generated group ID
     */
    createGroupId(groupId?: string): string | undefined;
    /**
     * Generates a unique overview group ID from the local group ID
     * and a prefix that reflects the parent groups in the group hierarchy
     *
     * @param {string} prefix - prefix that we need to make the ID unique
     * @param {string} groupId - group ID
     * @returns {string} - generated group ID
     */
    createOvGroupId(prefix: string, groupId: string): string;
    /**
     * Generates a unique overview menu item ID from the local group ID
     * and a prefix that reflects the parent groups in the group hierarchy
     *
     * @param {string} prefix - prefix that we need to make the ID unique
     * @param {string} groupId - group ID
     * @returns {string} - generated group ID
     */
    createOvMenuItemId(prefix: string, groupId: string): string;
    /**
     * Persist the keyboard focus state for the given key.
     * The focus is stored globally or for the given group.
     *
     * @param {string} key - key
     * @param {string} group? - Group
     */
    setFocus(key?: string, group?: string): void;
    /**
     * Change styling of element
     *
     * @param {string} querySelector - querySelector
     * @param {string} property - CSS property
     * @param {string} value - CSS value
     */
    changeStyling(querySelector: string, property: string, value: string): void;
    /**
     * Removes styling for element
     *
     * @param {string} querySelector - querySelector
     * @param {string} property - CSS property
     */
    removeStyling(querySelector: string, property: string): void;
    /**
     * Get HTML element based on querySelector when running in browser
     *
     * @param querySelector - querySelector
     * @returns selected HTML element
     */
    getElement(querySelector: string): HTMLElement | undefined;
    /**
     * Retrieves a list of HTML elements based on querySelector when running in browser
     *
     * @param {string} querySelector - querySelector
     * @returns {HTMLElement[] | undefined} - List of HTML elements
     */
    getElements(querySelector: string): HTMLElement[] | undefined;
    /**
     * Retrieves a number of pixels that the document is currently scrolled vertically.
     *
     * @returns {number | undefined} - Number of pixels that the document is currently scrolled vertically.
     */
    getVerticallyScrolledPixels(): number | undefined;
    /**
     * Verifies whether the element has a scrollbar.
     *
     * @param {string} querySelector - Element query selector
     * @returns {boolean} - 'True', if the element has a scrollbar, otherwise 'false'
     */
    hasScrollbar(querySelector: string): boolean;
    protected isInViewport(element: HTMLElement | undefined): boolean;
    getHeight(querySelector: string): number;
    /**
     * Retrieves the actual height of the spare viewport.
     *
     * SPA header, variant configuration overview header and "Add to cart" button occupy certain height of the viewport, that's why
     * if SPA header, variant configuration overview header and "Add to cart" button are in the viewport,
     * they will be subtracted from the actual viewport height.
     *
     * @returns {number} - Height of the spare viewport.
     */
    getSpareViewportHeight(): number;
    /**
     * Ensure that the element is always visible.
     *
     * @param {string} querySelector - Element query selector
     * @param {HTMLElement | undefined} element - Element that should be visible within the scrollable element.
     */
    ensureElementVisible(querySelector: string, element: HTMLElement | undefined): void;
    /**
     * Verifies whether a product is a variant product in the display only view.
     *
     * @returns - if `baseProduct` property of the current product is defined
     * and provides the product code of the base product,
     * and the current product is in the display only view
     * then returns `true`, otherwise `false`.
     */
    isDisplayOnlyVariant(): Observable<boolean>;
    /**
     * Set the last selected attribute and value.
     * Needed for accessibility of checkboxes for delta rendering
     *
     * @param attributeName - Attribute name
     * @param valueCode - Value code
     */
    setLastSelected(attributeName: string, valueCode: string): void;
    /**
     * Check if the attribute and value are the last selected.
     *
     * @param attributeName - Attribute name
     * @param valueCode - Value code
     * @returns 'True', if the attribute and value are the last selected, otherwise 'false'
     */
    isLastSelected(attributeName: string, valueCode: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorStorefrontUtilsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorStorefrontUtilsService>;
}

declare class ConfiguratorAddToCartButtonComponent implements OnInit, OnDestroy {
    protected routingService: RoutingService;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configuratorCartService: ConfiguratorCartService;
    protected configuratorGroupsService: ConfiguratorGroupsService;
    protected configRouterExtractorService: ConfiguratorRouterExtractorService;
    protected globalMessageService: GlobalMessageService;
    protected orderHistoryFacade: OrderHistoryFacade;
    protected commonConfiguratorUtilsService: CommonConfiguratorUtilsService;
    protected configUtils: ConfiguratorStorefrontUtilsService;
    protected intersectionService: IntersectionService;
    protected configuratorQuantityService: ConfiguratorQuantityService;
    protected subscription: Subscription;
    protected multiCartFacade: MultiCartFacade;
    protected focusService: KeyboardFocusService;
    protected activeCartFacade: ActiveCartFacade;
    quantityControl: UntypedFormControl;
    iconType: typeof ICON_TYPE;
    addToCartButtonDisabled: boolean;
    container$: Observable<{
        routerData: ConfiguratorRouter.Data;
        configuration: Configurator.Configuration;
        hasPendingChanges: boolean;
    }>;
    constructor(routingService: RoutingService, configuratorCommonsService: ConfiguratorCommonsService, configuratorCartService: ConfiguratorCartService, configuratorGroupsService: ConfiguratorGroupsService, configRouterExtractorService: ConfiguratorRouterExtractorService, globalMessageService: GlobalMessageService, orderHistoryFacade: OrderHistoryFacade, commonConfiguratorUtilsService: CommonConfiguratorUtilsService, configUtils: ConfiguratorStorefrontUtilsService, intersectionService: IntersectionService, configuratorQuantityService: ConfiguratorQuantityService);
    ngOnInit(): void;
    protected navigateToCart(): void;
    protected navigateToOverview(configuratorType: string, owner: CommonConfigurator.Owner, productCode?: string): void;
    protected focusOverviewInTabBar(): void;
    protected displayConfirmationMessage(key: string): void;
    protected isQuoteCartActive(): Observable<boolean>;
    protected getTranslationKeyForAddToCart(isAddToCart: boolean): Observable<string>;
    /**
     * Performs the navigation to the corresponding location (cart or overview pages).
     *
     * @param {string} configuratorType - Configurator type
     * @param {CommonConfigurator.Owner} owner - Owner
     * @param {boolean} isAdd - Is add to cart
     * @param {boolean} isOverview - Is overview page
     * @param {boolean} showMessage - Show message
     */
    performNavigation(configuratorType: string, owner: CommonConfigurator.Owner, isAdd: boolean, isOverview: boolean, showMessage: boolean, productCode?: string): void;
    /**
     * Decides on the resource key for the button. Depending on the business process (owner of the configuration) and the
     * need for a cart update, the text will differ.
     *
     * @param routerData - Reflects the current router state
     * @param configuration - Configuration
     * @param isQuoteActive - Is quote active
     * @returns - The resource key that controls the button description
     */
    getButtonResourceKey(routerData: ConfiguratorRouter.Data, configuration: Configurator.Configuration, isQuoteActive?: boolean | null): string;
    /**
     * Verifies whether it is a cart entry.
     *
     * @param {ConfiguratorRouter.Data} routerData - Reflects the current router state
     * @returns {boolean} - 'true' if it is a cart entry, otherwise 'false'
     */
    isCartEntry(routerData: ConfiguratorRouter.Data): boolean;
    /**
     * Triggers action and navigation, both depending on the context. Might result in an addToCart, updateCartEntry,
     * just a cart navigation or a browser back navigation
     * @param {Configurator.Configuration} configuration - Configuration
     * @param {ConfiguratorRouter.Data} routerData - Reflects the current router state
     */
    onAddToCart(configuration: Configurator.Configuration, routerData: ConfiguratorRouter.Data): void;
    protected onAddToCartForProduct(owner: CommonConfigurator.Owner, configuration: Configurator.Configuration, configuratorType: string, isOverview: boolean, productCode?: string): void;
    protected navigateForProductBound(configWithNextOwner: Configurator.Configuration, configuratorType: string, isOverview: boolean, productCode?: string): void;
    protected onUpdateCart(configuration: Configurator.Configuration, configuratorType: string, owner: CommonConfigurator.Owner, isOverview: boolean, productCode?: string): void;
    leaveConfigurationOverview(): void;
    protected goToOrderDetails(owner: CommonConfigurator.Owner): void;
    protected goToQuoteDetails(owner: CommonConfigurator.Owner): void;
    /**
     * Navigates to the quote that is attached to the saved cart. At the moment we
     * only support saved carts if linked to quotes.
     * @param owner Configuration owner
     */
    protected goToSavedCartDetails(owner: CommonConfigurator.Owner): void;
    extractConfigPrices(configuration: Configurator.Configuration): {
        basePrice: string | undefined;
        selectedOptions: string | undefined;
        totalPrice: string | undefined;
    };
    protected makeAddToCartButtonSticky(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAddToCartButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAddToCartButtonComponent, "cx-configurator-add-to-cart-button", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorAddToCartButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAddToCartButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAddToCartButtonModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.ItemCounterModule, typeof i3.IconModule, typeof ConfiguratorAddToCartButtonComponent], [typeof ConfiguratorAddToCartButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAddToCartButtonModule>;
}

interface AttributeComponentAssignment {
    [componentType: string]: any;
}
interface ConfiguratorAttributeComposition {
    assignment?: AttributeComponentAssignment;
}
declare abstract class ConfiguratorAttributeCompositionConfig {
    productConfigurator?: ConfiguratorAttributeComposition;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeCompositionConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorAttributeCompositionConfig>;
}

declare class ConfiguratorAttributeCompositionContext {
    componentKey: string;
    attribute: Configurator.Attribute;
    owner: CommonConfigurator.Owner;
    group: Configurator.Group;
    language: string;
    expMode: boolean;
    isNavigationToGroupEnabled?: boolean;
    isPricingAsync?: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeCompositionContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorAttributeCompositionContext>;
}

declare class ConfiguratorAttributeCompositionDirective implements OnInit, OnChanges {
    protected vcr: ViewContainerRef;
    protected configuratorAttributeCompositionConfig: ConfiguratorAttributeCompositionConfig;
    context: ConfiguratorAttributeCompositionContext;
    protected lastRenderedAttribute: Configurator.Attribute;
    protected lastRenderedGroupId: string;
    protected logger: LoggerService;
    protected readonly attrComponentAssignment: AttributeComponentAssignment;
    constructor(vcr: ViewContainerRef, configuratorAttributeCompositionConfig: ConfiguratorAttributeCompositionConfig);
    ngOnInit(): void;
    ngOnChanges(): void;
    protected renderComponent(component: any, componentKey: string): void;
    protected getComponentInjector(): Injector;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeCompositionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ConfiguratorAttributeCompositionDirective, "[cxConfiguratorAttributeComponent]", never, { "context": { "alias": "cxConfiguratorAttributeComponent"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ConfiguratorAttributeCompositionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeCompositionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeCompositionModule, never, [typeof i1.CommonModule, typeof ConfiguratorAttributeCompositionDirective], [typeof ConfiguratorAttributeCompositionDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeCompositionModule>;
}

interface ProductConfiguratorUISettingsConfig {
    updateDebounceTime?: {
        quantity?: number;
        input?: number;
        date?: number;
    };
    addRetractOption?: boolean;
    descriptions?: {
        attributeDescriptionLength?: number;
        valueDescriptionLength?: number;
    };
}
declare abstract class ConfiguratorUISettingsConfig {
    productConfigurator?: ProductConfiguratorUISettingsConfig;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorUISettingsConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorUISettingsConfig>;
}

interface ConfiguratorPriceComponentOptions {
    quantity?: number;
    price?: Configurator.PriceDetails;
    priceTotal?: Configurator.PriceDetails;
    isLightedUp?: boolean;
}
declare class ConfiguratorPriceComponent {
    protected directionService: DirectionService;
    formula: ConfiguratorPriceComponentOptions;
    constructor(directionService: DirectionService);
    protected isRTLDirection(): boolean;
    protected removeSign(value: string | undefined, sign: string): string;
    protected addSign(value: string | undefined, sign: string, before: boolean): string;
    protected compileFormattedValue(priceValue: number, formattedValue: string | undefined, isRTL: boolean): string;
    /**
     * Retrieves price.
     *
     * @return {string} - value price formula
     */
    get price(): string;
    /**
     * Retrieves the total price.
     *
     * @return {string} - total price formula
     */
    get priceTotal(): string;
    /**
     * Verifies whether quantity with price should be displayed.
     *
     * @return {boolean} - 'true' if quantity and price should be displayed, otherwise 'false'
     */
    displayQuantityAndPrice(): boolean;
    /**
     * Verifies whether only price should be displayed.
     *
     * @return {boolean} - 'true' if only price should be displayed, otherwise 'false'
     */
    displayPriceOnly(): boolean;
    /**
     * Verifies whether the price formula should be displayed.
     *
     * @return {boolean} - 'true' if price formula should be displayed, otherwise 'false'
     */
    displayFormula(): boolean;
    /**
     * Retrieves formula for quantity with price.
     *
     * @param {string} formattedQuantity- formatted quantity
     * @return {string} - price formula
     */
    quantityWithPrice(formattedQuantity: string | null): string;
    /**
     * Verifies whether the price is lighted up.
     *
     * @return {boolean} - 'true' if price should be lighted up, otherwise 'false'
     */
    isPriceLightedUp(): boolean;
    /**
     * Retrieves the styling for the corresponding element.
     *
     * @return {string} - corresponding style class
     */
    get styleClass(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorPriceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorPriceComponent, "cx-configurator-price", never, { "formula": { "alias": "formula"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Stateful service to react on price changes of the configuration.
 * Hence components using this service must provide it within their declaration, for instance:
 * @Component({ providers: [ConfiguratorAttributePriceChangeService] })
 *
 * getChangedPrices will return an observable that emits whenever the price of a monitored attribute (identified by the provided attribute key) changes.
 * Hence allowing the subscriber to trigger rerendering of the prices on the UI.
 */
declare class ConfiguratorAttributePriceChangeService {
    protected configuratorRouterExtractorService: ConfiguratorRouterExtractorService;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected lastAttributeSupplement: Configurator.AttributeSupplement | undefined;
    /**
     * Retrieves an observable that emits whenever the price of a monitored attribute (identified by the provided attribute key) changes,
     * hence allowing the subscriber to trigger rerendering of the prices on the UI.
     * This ensures that an enclosing UI component will initially render, even if the async pricing request is still running,
     * so that the UI is not blocked. Afterwards a rerender shall only occur if prices change.
     * This all assumes that the enclosing UI component itself gets recreated or rerendered (triggered elsewhere) whenever the attribute itself changes content wise.
     *
     * @param attributeKey key of the attribute for which the prices should be checked for changes
     * @returns observable that emits price of monitored attribute changes and hence there is the need to rerender the enclosing component
     */
    getChangedPrices(attributeKey: string | undefined): Observable<Record<string, Configurator.PriceDetails>>;
    /**
     * Extracts the relevant value prices from the price supplements
     * and stores them within the component.
     * Returns price of a monitored attribute changes.
     *
     * @param config current configuration
     * @param attributeKey key of the attribute for which the prices should be checked for changes
     * @returns observable that emits price of a monitored attribute changes
     */
    protected checkForValuePriceChanges(config: Configurator.Configuration, attributeKey: string | undefined): Record<string, Configurator.PriceDetails> | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributePriceChangeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorAttributePriceChangeService>;
}

/**
 * Service to provide unique keys for elements on the UI and for sending to configurator
 */
declare class ConfiguratorAttributeBaseComponent {
    protected configuratorUISettingsConfig: ConfiguratorUISettingsConfig;
    protected translation: TranslationService;
    /**
     * as the service is stateful any using component shall provide it within the components declaration:
     *
     * @Component({ providers: [ConfiguratorAttributePriceChangeService] })
     *
     * otherwise the service will be null. Hence the service is marked as optional here.
     */
    protected configuratorAttributePriceChangeService: ConfiguratorAttributePriceChangeService | null;
    protected configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService;
    private static SEPERATOR;
    private static PREFIX;
    private static PREFIX_LABEL;
    private static PREFIX_OPTION_PRICE_VALUE;
    private static PREFIX_DDLB_OPTION_PRICE_VALUE;
    protected static MAX_IMAGE_LABEL_CHARACTERS: number;
    listenForPriceChanges: boolean;
    changedPrices$: Observable<Record<string, Configurator.PriceDetails>>;
    protected initPriceChangedEvent(isPricingAsync?: boolean, attributeKey?: string): void;
    /**
     * Creates unique key for config value on the UI
     *
     * @param prefix for key depending on usage (e.g. uiType, label)
     * @param attributeId
     * @param valueId
     */
    createValueUiKey(prefix: string, attributeId: string, valueId: string): string;
    /**
     * Creates unique key for config value to be sent to configurator
     *
     * @param currentAttribute
     * @param value
     */
    createAttributeValueIdForConfigurator(currentAttribute: Configurator.Attribute, value: string): string;
    protected getUiType(attribute: Configurator.Attribute): string;
    /**
     * Creates unique key for config attribute on the UI
     *
     * @param prefix for key depending on usage (e.g. uiType, label)
     * @param attributeId
     */
    createAttributeUiKey(prefix: string, attributeId: string): string;
    /**
     * Creates unique key for config attribute to be sent to configurator
     *
     * @param currentAttribute
     */
    createAttributeIdForConfigurator(currentAttribute: Configurator.Attribute): string;
    /**
     * Creates unique key for attribute 'aria-labelledby'
     *
     * @param prefix
     * @param attributeId
     * @param valueId
     * @param hasQuantity
     */
    createAriaLabelledBy(prefix: string, attributeId: string, valueId?: string, hasQuantity?: boolean): string;
    /**
     * Creates a unique key for focus handling for the given attribute and value
     *
     * @param attributeId
     * @param valueCode
     * @returns focus key
     */
    createFocusId(attributeId: string, valueCode: string): string;
    /**
     * Retrieves label with or without technical name depending whether the expert mode is set or not.
     *
     * @param expMode - Is expert mode set?
     * @param label - value label
     * @param techName - value technical name
     * @param value - Configurator value
     */
    getLabel(expMode: boolean, label: string | undefined, techName: string | undefined, value?: Configurator.Value): string;
    /**
     * Retrieves image label with or without technical name depending whether the expert mode is set or not.
     * If the length of the label is longer than 'MAX_IMAGE_LABEL_CHARACTERS' characters, it will be shortened and ellipsis will be added at the end.
     *
     * @param expMode - Is expert mode set?
     * @param label - value label
     * @param techName - value technical name
     * @param value - Configurator value
     */
    getImageLabel(expMode: boolean, label: string | undefined, techName: string | undefined, value?: Configurator.Value): string;
    /**
     * Fetches the first image for a given value
     *
     * @param value Value
     * @returns Image
     */
    getImage(value: Configurator.Value): Configurator.Image | undefined;
    /**
     * Retrieves a translation key for a value with a price.
     *
     * @param isReadOnly - is attribute a read-only?
     * @returns - translation key for a value with price
     */
    getAriaLabelForValueWithPrice(isReadOnly: boolean): string;
    /**
     * Retrieves a translation key for a value.
     *
     * @param isReadOnly - is attribute a read-only?
     * @returns - translation key for a value with price
     */
    getAriaLabelForValue(isReadOnly: boolean): string;
    /**
     * Retrieves the styling classes for the image element.
     *
     * @param attribute
     * @param value
     * @param styleClass
     * @return - corresponding style classes for the image element
     */
    getImgStyleClasses(attribute: Configurator.Attribute, value: Configurator.Value, styleClass: string): string;
    protected getValuePrice(value: Configurator.Value | undefined): string;
    /**
     * Get code from attribute.
     * The code is not a mandatory attribute (since not available for VC flavour),
     * still it is mandatory in the context of CPQ. Calling this method therefore only
     * makes sense when CPQ is active. In case the method is called in the wrong context, an exception will
     * be thrown
     *
     * @param {Configurator.Attribute} Attribute
     * @returns {number} Attribute code
     */
    protected getAttributeCode(attribute: Configurator.Attribute): number;
    /**
     * Checks if attribute type allows additional values
     *
     * @param attribute Attribute
     * @returns true if attribute type allows to enter additional values
     */
    protected isWithAdditionalValues(attribute: Configurator.Attribute): boolean;
    protected isRequiredErrorMsg(attribute: Configurator.Attribute): boolean;
    protected isUserInput(attribute: Configurator.Attribute): boolean;
    protected isDropDown(attribute: Configurator.Attribute): boolean;
    protected getSelectedValue(attribute: Configurator.Attribute): Configurator.Value | undefined;
    protected isNoValueSelected(attribute: Configurator.Attribute): boolean;
    /**
     * Retrieves the length of the value description.
     *
     * @returns - the length of the value description
     */
    getValueDescriptionLength(): number;
    protected isReadOnly(attribute: Configurator.Attribute): boolean;
    protected isValueDisplayed(attribute: Configurator.Attribute, value: Configurator.Value): boolean;
    /**
     * Creates a text describing the current attribute that can be used as ARIA label.
     * Includes price information. If a total price is available this price will be used,
     * otherwise it falls back to the value price, or if no price is available,
     * no price information will be included in the text.
     *
     * @param attribute the attribute
     * @param value the value
     * @param considerSelectionState - optional, depending on the underlying UI control the screen
     * might announce the selection state on its own, so it is not always desired to include it here.
     * @returns translated text
     */
    protected getAriaLabelGeneric(attribute: Configurator.Attribute, value: Configurator.Value | undefined, considerSelectionState?: boolean): string;
    /**
     * Extract corresponding value price formula parameters.
     * For all non-single selection types types the complete price formula should be displayed at the value level.
     *
     * @param value - Configurator value
     * @return new price formula
     */
    extractValuePriceFormulaParameters(value: Configurator.Value | undefined): ConfiguratorPriceComponentOptions;
    /**
     * Merges the stored value price data into the given value, if available.
     * As the value might be read-only a new object will be returned combining price and value.
     *
     * @param value the value
     * @param changedPrices record of changed prices
     * @returns the new value with price
     */
    enrichValueWithPrice(value: Configurator.Value | undefined, changedPrices: Record<string, Configurator.PriceDetails>): Configurator.Value | undefined;
    /**
     * Checks if the value is the last selected value.
     *
     * @param valueCode code of the value
     * @returns true, only if this value is the last selected value
     */
    isLastSelected(attributeName: string, valueCode: string): boolean;
}

declare class ConfiguratorAttributeFooterComponent extends ConfiguratorAttributeBaseComponent implements OnInit {
    protected configUtils: ConfiguratorStorefrontUtilsService;
    protected attributeComponentContext: ConfiguratorAttributeCompositionContext;
    attribute: Configurator.Attribute;
    owner: CommonConfigurator.Owner;
    groupId: string;
    constructor(configUtils: ConfiguratorStorefrontUtilsService, attributeComponentContext: ConfiguratorAttributeCompositionContext);
    iconType: typeof ICON_TYPE;
    showRequiredMessageForUserInput$: Observable<boolean>;
    ngOnInit(): void;
    protected needsRequiredAttributeErrorMsg(): boolean;
    protected needsDropDownMsg(): boolean;
    /**
     * Checks if attribute is a user input typed attribute with empty value.
     * Method will return false for domain based attributes
     * @param {string} input - user input
     */
    isUserInputEmpty(input?: string): boolean;
    protected needsUserInputMsg(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeFooterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAttributeFooterComponent, "cx-configurator-attribute-footer", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorAttributeFooterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeFooterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeFooterModule, never, [typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof ConfiguratorAttributeFooterComponent], [typeof ConfiguratorAttributeFooterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeFooterModule>;
}

declare class ConfiguratorAttributeHeaderComponent extends ConfiguratorAttributeBaseComponent implements OnInit {
    protected configUtils: ConfiguratorStorefrontUtilsService;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configuratorGroupsService: ConfiguratorGroupsService;
    protected configuratorUiSettings: ConfiguratorUISettingsConfig;
    protected attributeComponentContext: ConfiguratorAttributeCompositionContext;
    attribute: Configurator.Attribute;
    owner: CommonConfigurator.Owner;
    groupId: string;
    groupType: Configurator.GroupType;
    expMode: boolean;
    isNavigationToGroupEnabled: boolean;
    iconTypes: typeof ICON_TYPE;
    showRequiredMessageForDomainAttribute$: Observable<boolean>;
    protected logger: LoggerService;
    protected config: Config;
    constructor(configUtils: ConfiguratorStorefrontUtilsService, configuratorCommonsService: ConfiguratorCommonsService, configuratorGroupsService: ConfiguratorGroupsService, configuratorUiSettings: ConfiguratorUISettingsConfig, attributeComponentContext: ConfiguratorAttributeCompositionContext);
    ngOnInit(): void;
    /**
     * Get message key for the required message. Is different for multi- and single selection values
     *  @return {string} - required message key
     */
    getRequiredMessageKey(): string;
    protected get isMultiSelection(): boolean;
    protected isSingleSelection(): boolean;
    protected isAttributeWithoutErrorMsg(uiType: Configurator.UiType | undefined): boolean;
    protected needsRequiredAttributeErrorMsg(): boolean;
    protected isRequiredAttributeWithoutErrorMsg(): boolean;
    /**
     * Verifies whether the group type is attribute group
     *
     * @return {boolean} - 'true' if the group type is 'attribute group' otherwise 'false'
     */
    isAttributeGroup(): boolean;
    /**
     * Verifies whether the conflict resolution is active.
     *
     * @return {boolean} - 'true' if the conflict resolution is active otherwise 'false'
     */
    isConflictResolutionActive(): boolean;
    /**
     * Retrieves a certain conflict link key depending on the current group type for translation.
     *
     * @return {string} - the conflict link key
     */
    getConflictMessageKey(): string;
    /**
     * Checks if an image is attached
     * @returns True if an only if at least one image exists
     */
    get hasImage(): boolean;
    /**
     * Returns image attached to the attribute (if available)
     * @returns Image
     */
    get image(): Configurator.Image | undefined;
    /**
     * Navigates to the group.
     */
    navigateToGroup(): void;
    /**
     * Scroll to conflicting attribute
     *
     * @protected
     */
    protected scrollToAttribute(name: string): void;
    findConflictGroupId(configuration: Configurator.Configuration, currentAttribute: Configurator.Attribute): string | undefined;
    protected logError(text: string): void;
    protected focusValue(attribute: Configurator.Attribute): void;
    /**
     * The status of the configuration loading is retrieved twice:
     * firstly, wait that the navigation to the corresponding group is started,
     * secondly, wait that the navigation is completed and
     * finally, invoke the callback function
     *
     * @protected
     */
    protected onNavigationCompleted(callback: () => void): void;
    /**
     * Verifies whether the navigation to a conflict group is enabled.
     *
     * @returns {boolean} true only if navigation to conflict groups is enabled.
     */
    isNavigationToConflictEnabled(): boolean;
    /**
     * Retrieves the length of the attribute description.
     *
     * @returns - the length of the attribute description
     */
    getAttributeDescriptionLength(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAttributeHeaderComponent, "cx-configurator-attribute-header", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorShowMoreComponent implements AfterViewInit {
    protected cdRef: ChangeDetectorRef;
    showMore: boolean;
    showHiddenText: boolean;
    textToShow: string;
    textNormalized: string;
    text: string;
    textSize: number;
    productName: string;
    tabIndex: number;
    constructor(cdRef: ChangeDetectorRef);
    ngAfterViewInit(): void;
    toggleShowMore(): void;
    protected normalize(text?: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorShowMoreComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorShowMoreComponent, "cx-configurator-show-more", never, { "text": { "alias": "text"; "required": false; }; "textSize": { "alias": "textSize"; "required": false; }; "productName": { "alias": "productName"; "required": false; }; "tabIndex": { "alias": "tabIndex"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ConfiguratorShowMoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorShowMoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorShowMoreModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof ConfiguratorShowMoreComponent], [typeof ConfiguratorShowMoreComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorShowMoreModule>;
}

declare class ConfiguratorShowOptionsComponent {
    protected configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    attributeComponentContext: ConfiguratorAttributeCompositionContext;
    constructor(configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService);
    /**
     * fires a request to read the attribute domain,
     * so that all options of the attribute become visible on the UI
     */
    showOptions(): void;
    protected focusFirstValue(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorShowOptionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorShowOptionsComponent, "cx-configurator-show-options", never, { "attributeComponentContext": { "alias": "attributeComponentContext"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ConfiguratorShowOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorShowOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorShowOptionsModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof ConfiguratorShowOptionsComponent], [typeof ConfiguratorShowOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorShowOptionsModule>;
}

declare class ConfiguratorAttributeHeaderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeHeaderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeHeaderModule, never, [typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof i6.NgSelectModule, typeof ConfiguratorShowMoreModule, typeof ConfiguratorShowOptionsModule, typeof ConfiguratorAttributeHeaderComponent], [typeof ConfiguratorAttributeHeaderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeHeaderModule>;
}

declare class ConfigFormUpdateEvent {
    changedAttribute: Configurator.Attribute;
    ownerKey: string;
    updateType?: Configurator.UpdateType;
}
interface QuantityUpdateEvent {
    quantity: number;
    valueCode?: string;
}

interface ConfiguratorAttributeQuantityComponentOptions {
    allowZero?: boolean;
    initialQuantity?: number;
    disableQuantityActions$?: Observable<boolean>;
}
declare class ConfiguratorAttributeQuantityComponent implements OnDestroy, OnInit {
    protected config: ConfiguratorUISettingsConfig;
    quantity: UntypedFormControl;
    optionsChangeSub: Subscription;
    quantityChangeSub: Subscription;
    quantityOptions: ConfiguratorAttributeQuantityComponentOptions;
    changeQuantity: EventEmitter<number>;
    constructor(config: ConfiguratorUISettingsConfig);
    ngOnInit(): void;
    protected subscribeToQuantityChange(): Subscription;
    ngOnDestroy(): void;
    onChangeQuantity(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeQuantityComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAttributeQuantityComponent, "cx-configurator-attribute-quantity", never, { "quantityOptions": { "alias": "quantityOptions"; "required": false; }; }, { "changeQuantity": "changeQuantity"; }, never, never, true, never>;
}

interface ConfiguratorAttributeProductCardComponentOptions {
    /** If set to `true`, all action buttons will be disabled.  */
    disableAllButtons?: boolean;
    /** If set to `true`, the remove/deselect button won't be available. Useful for required attributes,
     *  where a deselect/remove of last value shall not be possible.  */
    hideRemoveButton?: boolean;
    fallbackFocusId?: string;
    multiSelect?: boolean;
    productBoundValue: Configurator.Value;
    singleDropdown?: boolean;
    withQuantity?: boolean;
    /**
     * Used to indicate loading state, for example in case a request triggered by parent component to CPQ is currently in progress.
     * Component will react on it and disable all controls that could cause a request.
     * This prevents the user from triggering concurrent requests with potential conflicting content that might cause unexpected behaviour.
     */
    loading$?: Observable<boolean>;
    attributeId: number;
    attributeLabel?: string;
    attributeName: string;
    itemCount: number;
    itemIndex: number;
}
declare class ConfiguratorAttributeProductCardComponent extends ConfiguratorAttributeBaseComponent implements OnInit {
    protected productService: ProductService;
    protected keyBoardFocus: KeyboardFocusService;
    protected translation: TranslationService;
    product$: Observable<Product>;
    loading$: BehaviorSubject<boolean>;
    showDeselectionNotPossible: boolean;
    productCardOptions: ConfiguratorAttributeProductCardComponentOptions;
    handleDeselect: EventEmitter<string>;
    handleQuantity: EventEmitter<QuantityUpdateEvent>;
    handleSelect: EventEmitter<string>;
    constructor(productService: ProductService, keyBoardFocus: KeyboardFocusService, translation: TranslationService);
    iconType: typeof ICON_TYPE;
    ngOnInit(): void;
    get showQuantity(): boolean;
    get focusConfig(): FocusConfig;
    onHandleSelect(): void;
    onHandleDeselect(): void;
    onChangeQuantity(eventObject: any): void;
    /**
     * Verifies whether the product card refers to a selected value
     * @return {boolean} - Selected?
     */
    isProductCardSelected(): boolean;
    /**
     * Checks if price needs to be displayed. This is the
     * case if either value price, quantity or value price total
     * are present
     * @return {boolean} - Price display?
     */
    hasPriceDisplay(): boolean;
    /**
     * Extract corresponding price formula parameters
     *
     *  @return {ConfiguratorPriceComponentOptions} - New price formula
     */
    extractPriceFormulaParameters(): ConfiguratorPriceComponentOptions;
    /**
     *  Extract corresponding quantity parameters
     *
     * @return {ConfiguratorAttributeQuantityComponentOptions} - New quantity options
     */
    extractQuantityParameters(): ConfiguratorAttributeQuantityComponentOptions;
    /**
     * Verifies whether the value code is defined.
     *
     * @param {string} valueCode - Value code
     * @return {boolean} - 'true' if the value code is defined, otherwise 'false'
     */
    isValueCodeDefined(valueCode: string | null | undefined): boolean;
    protected transformToProductType(value: Configurator.Value | undefined): Product;
    protected onHandleQuantity(quantity: number): void;
    showDeselectionNotPossibleMessage(): void;
    getAriaLabelSingleUnselected(product: Product): string;
    getAriaLabelSingleSelected(product: Product): string;
    getAriaLabelSingleSelectedNoButton(product: Product): string;
    getAriaLabelMultiSelected(product: Product): string;
    getAriaLabelMultiUnselected(product: Product): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeProductCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAttributeProductCardComponent, "cx-configurator-attribute-product-card", never, { "productCardOptions": { "alias": "productCardOptions"; "required": false; }; }, { "handleDeselect": "handleDeselect"; "handleQuantity": "handleQuantity"; "handleSelect": "handleSelect"; }, never, never, true, never>;
}

declare class ConfiguratorAttributeQuantityModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeQuantityModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeQuantityModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.ItemCounterModule, typeof i3.KeyboardFocusModule, typeof ConfiguratorAttributeQuantityComponent], [typeof ConfiguratorAttributeQuantityComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeQuantityModule>;
}

declare class ConfiguratorPriceModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorPriceModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorPriceModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof ConfiguratorPriceComponent], [typeof ConfiguratorPriceComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorPriceModule>;
}

declare class ConfiguratorAttributeProductCardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeProductCardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeProductCardModule, never, [typeof i1.CommonModule, typeof ConfiguratorShowMoreModule, typeof ConfiguratorAttributeQuantityModule, typeof i2.I18nModule, typeof i6$1.RouterModule, typeof i2.UrlModule, typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof i3.MediaModule, typeof ConfiguratorPriceModule, typeof i3.KeyboardFocusModule, typeof i3.IconModule, typeof ConfiguratorAttributeProductCardComponent], [typeof ConfiguratorAttributeProductCardComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeProductCardModule>;
}

declare class ConfiguratorAttributeQuantityService {
    /**
     * Checks if the interaction with the quantity control needs
     * to be disabled
     * @param {any} value Selected value
     * @returns {boolean} Quantity actions disabled?
     */
    disableQuantityActions(value: any): boolean;
    /**
     * Checks if the interaction with the quantity control needs for multiselection components
     * to be disabled
     * @param {Configurator.Attribute} attribute Configurator Attribute
     * @returns {boolean} Quantity actions disabled?
     */
    disableQuantityActionsMultiSelection(attribute: Configurator.Attribute): boolean;
    /**
     * Checks if it is supposed to render a quantity control on attribute level
     *
     * @param {Configurator.Attribute} attribute Configurator Attribute
     * @return {boolean} - Display quantity picker on attribute level?
     */
    withQuantityOnAttributeLevel(attribute: Configurator.Attribute): boolean;
    /**
     * Checks if an attribute needs to be equipped with the option to select
     * a quantity
     * @param {Configurator.DataType} dataType Attribute data type
     * @param {Configurator.UiType} uiType Attribute ui type, refers to how an attribute must be rendered
     * @returns  {boolean} Render a quantity component?
     */
    withQuantity(dataType: Configurator.DataType, uiType: Configurator.UiType): boolean;
    /**
     * Checks if the zero quantity is allowed
     *
     * @param {Configurator.Attribute} attribute Configurator Attribute
     * @return {boolean} - true when zero quantity is allowed
     */
    allowZeroValueQuantity(attribute: Configurator.Attribute): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeQuantityService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorAttributeQuantityService>;
}

declare abstract class ConfiguratorAttributeSingleSelectionBaseComponent extends ConfiguratorAttributeBaseComponent {
    protected quantityService: ConfiguratorAttributeQuantityService;
    protected translation: TranslationService;
    protected attributeComponentContext: ConfiguratorAttributeCompositionContext;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService;
    loading$: BehaviorSubject<boolean>;
    attribute: Configurator.Attribute;
    ownerKey: string;
    ownerType: string;
    language: string;
    expMode: boolean;
    showRequiredErrorMessage$: Observable<boolean>;
    constructor(quantityService: ConfiguratorAttributeQuantityService, translation: TranslationService, attributeComponentContext: ConfiguratorAttributeCompositionContext, configuratorCommonsService: ConfiguratorCommonsService, configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService);
    /**
     * Checks if we are supposed to render a quantity control, which
     * can be derived from the attribute meta data
     *
     * @return {boolean} - Display quantity picker?
     */
    get withQuantity(): boolean;
    /**
     * Checks if quantity control should be disabled
     *
     * @return {boolean} - Disable quantity picker?
     */
    get disableQuantityActions(): boolean;
    onSelect(value: string): void;
    onSelectAdditionalValue(event: ConfigFormUpdateEvent): void;
    onHandleQuantity(quantity: number): void;
    onChangeQuantity(eventObject: any, form?: UntypedFormControl): void;
    protected getInitialQuantity(form?: UntypedFormControl): number;
    /**
     *  Extract corresponding quantity parameters
     *
     * @param {FormControl} form - Form control
     * @return {ConfiguratorAttributeQuantityComponentOptions} - New quantity options
     */
    extractQuantityParameters(form?: UntypedFormControl): ConfiguratorAttributeQuantityComponentOptions;
    /**
     * Extract corresponding price formula parameters.
     * For the single-selection attribute types the complete price formula should be displayed at the attribute level.
     *
     * @return {ConfiguratorPriceComponentOptions} - New price formula
     */
    extractPriceFormulaParameters(): ConfiguratorPriceComponentOptions;
    /**
     * Extract corresponding value price formula parameters.
     * For the single-selection attribute types only value price should be displayed at the value level.
     *
     * @param {Configurator.Value} value - Configurator value
     * @return {ConfiguratorPriceComponentOptions} - New price formula
     */
    extractValuePriceFormulaParameters(value?: Configurator.Value): ConfiguratorPriceComponentOptions;
    protected getSelectedValuePrice(): Configurator.PriceDetails | undefined;
    get isAdditionalValueNumeric(): boolean;
    get isAdditionalValueAlphaNumeric(): boolean;
    getAriaLabel(value: Configurator.Value | undefined, attribute: Configurator.Attribute): string;
    getAdditionalValueAriaLabel(): string;
    getAriaLabelWithoutAdditionalValue(value: Configurator.Value | undefined, attribute: Configurator.Attribute): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeSingleSelectionBaseComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ConfiguratorAttributeSingleSelectionBaseComponent, never, never, {}, {}, never, never, true, never>;
}

declare abstract class ConfiguratorAttributeMultiSelectionBaseComponent extends ConfiguratorAttributeBaseComponent {
    protected quantityService: ConfiguratorAttributeQuantityService;
    protected attributeComponentContext: ConfiguratorAttributeCompositionContext;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    loading$: BehaviorSubject<boolean>;
    attribute: Configurator.Attribute;
    ownerKey: string;
    expMode: boolean;
    constructor(quantityService: ConfiguratorAttributeQuantityService, attributeComponentContext: ConfiguratorAttributeCompositionContext, configuratorCommonsService: ConfiguratorCommonsService);
    /**
     * Checks if we are supposed to render a quantity control on attribute level, which
     * can be derived from the attribute meta data
     *
     * @return {boolean} - Display quantity picker on attribute level?
     */
    get withQuantityOnAttributeLevel(): boolean;
    /**
     * Checks if we are supposed to render a quantity control, which
     * can be derived from the attribute meta data
     *
     * @return {boolean} - Display quantity picker?
     */
    get withQuantity(): boolean;
    /**
     * Checks if quantity control should be disabled
     *
     * @return {boolean} - Disable quantity picker?
     */
    get disableQuantityActions(): boolean;
    /**
     *  Extract corresponding quantity parameters
     *
     * @param {number} initialQuantity - Initial quantity
     * @param {boolean} allowZero - Allow zero
     * @return {ConfiguratorAttributeQuantityComponentOptions} - New quantity options
     */
    extractQuantityParameters(initialQuantity?: number, allowZero?: boolean): ConfiguratorAttributeQuantityComponentOptions;
    protected onHandleAttributeQuantity(quantity: number): void;
    /**
     * Extract corresponding price formula parameters.
     * For the multi-selection attribute types only total price of the attribute should be displayed at the attribute level.
     *
     * @return {ConfiguratorPriceComponentOptions} - New price formula
     */
    extractPriceFormulaParameters(): ConfiguratorPriceComponentOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeMultiSelectionBaseComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ConfiguratorAttributeMultiSelectionBaseComponent, never, never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorAttributeCheckBoxListComponent extends ConfiguratorAttributeMultiSelectionBaseComponent implements OnInit {
    protected configUtilsService: ConfiguratorStorefrontUtilsService;
    protected quantityService: ConfiguratorAttributeQuantityService;
    protected attributeComponentContext: ConfiguratorAttributeCompositionContext;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    attributeCheckBoxForms: UntypedFormControl[];
    group: string;
    protected logger: LoggerService;
    constructor(configUtilsService: ConfiguratorStorefrontUtilsService, quantityService: ConfiguratorAttributeQuantityService, attributeComponentContext: ConfiguratorAttributeCompositionContext, configuratorCommonsService: ConfiguratorCommonsService);
    ngOnInit(): void;
    get allowZeroValueQuantity(): boolean;
    onSelect(valueCode?: string): void;
    onChangeValueQuantity(eventObject: any, valueCode: string, formIndex: number): void;
    onChangeQuantity(eventObject: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeCheckBoxListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAttributeCheckBoxListComponent, "cx-configurator-attribute-checkbox-list", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorAttributeCheckboxListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeCheckboxListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeCheckboxListModule, never, [typeof i3.KeyboardFocusModule, typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof i1.CommonModule, typeof i2.I18nModule, typeof ConfiguratorAttributeQuantityModule, typeof ConfiguratorPriceModule, typeof ConfiguratorShowMoreModule, typeof ConfiguratorAttributeCheckBoxListComponent], [typeof ConfiguratorAttributeCheckBoxListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeCheckboxListModule>;
}

declare class ConfiguratorAttributeCheckBoxComponent extends ConfiguratorAttributeBaseComponent implements OnInit {
    protected attributeComponentContext: ConfiguratorAttributeCompositionContext;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    attribute: Configurator.Attribute;
    group: string;
    ownerKey: string;
    expMode: boolean;
    attributeValue: Configurator.Value;
    attributeCheckBoxForm: UntypedFormControl;
    constructor(attributeComponentContext: ConfiguratorAttributeCompositionContext, configuratorCommonsService: ConfiguratorCommonsService);
    ngOnInit(): void;
    /**
     * Fired when a check box has been selected i.e. when a value has been set
     */
    onSelect(valueCode?: string): void;
    protected getValueFromAttribute(): Configurator.Value;
    protected assembleSingleValue(): Configurator.Value[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeCheckBoxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAttributeCheckBoxComponent, "cx-configurator-attribute-checkbox", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorAttributeCheckboxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeCheckboxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeCheckboxModule, never, [typeof i3.KeyboardFocusModule, typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof i1.CommonModule, typeof i2.I18nModule, typeof ConfiguratorPriceModule, typeof ConfiguratorShowMoreModule, typeof ConfiguratorAttributeCheckBoxComponent], [typeof ConfiguratorAttributeCheckBoxComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeCheckboxModule>;
}

declare class ConfiguratorAttributeDropDownComponent extends ConfiguratorAttributeSingleSelectionBaseComponent implements OnInit {
    protected quantityService: ConfiguratorAttributeQuantityService;
    protected translation: TranslationService;
    protected attributeComponentContext: ConfiguratorAttributeCompositionContext;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService;
    attributeDropDownForm: UntypedFormControl;
    group: string;
    protected config: Config;
    constructor(quantityService: ConfiguratorAttributeQuantityService, translation: TranslationService, attributeComponentContext: ConfiguratorAttributeCompositionContext, configuratorCommonsService: ConfiguratorCommonsService, configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService);
    ngOnInit(): void;
    getSelectedValue(): Configurator.Value | undefined;
    /**
     * Retrieves a selected value description.
     *
     * @returns - if a selected value description is defined then it will be returned, otherwise an empty string
     */
    getSelectedValueDescription(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeDropDownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAttributeDropDownComponent, "cx-configurator-attribute-drop-down", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorAttributeInputFieldComponent extends ConfiguratorAttributeBaseComponent implements OnInit, OnDestroy {
    protected config: ConfiguratorUISettingsConfig;
    protected attributeComponentContext: ConfiguratorAttributeCompositionContext;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService;
    attributeInputForm: UntypedFormControl;
    protected sub: Subscription;
    attribute: Configurator.Attribute;
    group: string;
    owner: CommonConfigurator.Owner;
    ownerKey: string;
    ownerType: CommonConfigurator.OwnerType;
    showRequiredErrorMessage$: Observable<boolean>;
    /**
     * Initially, changes to a date control are sent immediately
     * (when using the date picker. Only after any key is pressed, the
     * debounce time kicks in)
     * )
     */
    protected debounceForDateActive: boolean;
    /**
     * In case no config is injected, or when the debounce time is not configured at all,
     * this value will be used as fallback.
     */
    protected readonly FALLBACK_DEBOUNCE_TIME = 500;
    /**
     * In case no config is injected, or if the debounce time for dates is not configured at all,
     * this value will be used as fallback.
     */
    protected readonly FALLBACK_DEBOUNCE_TIME_DATE = 1500;
    constructor(config: ConfiguratorUISettingsConfig, attributeComponentContext: ConfiguratorAttributeCompositionContext, configuratorCommonsService: ConfiguratorCommonsService, configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService);
    ngOnInit(): void;
    onChange(): void;
    ngOnDestroy(): void;
    /**
     * Verifies if the user input has a non-blank value.
     * @returns {boolean} - 'True' if the user input is undefined, empty or contains only blanks, otherwise 'false'.
     */
    get isUserInputEmpty(): boolean;
    /**
     * Checks if the component needs to be marked as required.
     * This is never the case if it is used as sub component for an attribute type which allows an additional value
     * @returns Required?
     */
    get isRequired(): boolean;
    /**
     * Returns the type for the input field. Depending on the UI type, that is text or date.
     */
    get inputType(): string;
    /**
     * Activates a waiting period until date changes are sent. We only
     * want to enable that once the user tries to enter something
     * directly (when using date picker, changes should be sent instantly)
     */
    activateDebounceDate(): void;
    protected isDateBased(attribute: Configurator.Attribute): boolean;
    protected compileShowRequiredErrorMessage(): void;
    protected calculateDebounceTime(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeInputFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAttributeInputFieldComponent, "cx-configurator-attribute-input-field", never, {}, {}, never, never, true, never>;
}

interface ConfiguratorAttributeNumericInterval {
    minValue?: number;
    maxValue?: number;
    minValueIncluded: boolean;
    maxValueIncluded: boolean;
}
/**
 * Provides validation and formatting of numeric input
 */
declare class ConfiguratorAttributeNumericInputFieldService {
    /**
     * Validates numeric input according to settings that are not derived from the locale but from the attribute
     * meta data like the total number of digits and the maximum number of decimal places.
     *
     * @param input Numeric user input, formatted according to session locale
     * @param groupingSeparator Separator for grouping, e.g. ',' for 'en' locale. We allow the grouping separator but
     *   do not check exactly on the position of it in the numerical input. This e.g. is ok: '12,12,12', will be converted
     *   to '121,212' after the next roundtrip
     * @param decimalSeparator  Decimal separator, e.g. '.' for 'en' locale. Must not occur more that 1 time in the input.
     * @param numberTotalPlaces  Total number of places e.g. 10
     * @param numberDecimalPlaces  Number of decimal places e.g. 2
     *  @returns {boolean} Did we see a validation error?
     */
    performValidationAccordingToMetaData(input: string, groupingSeparator: string, decimalSeparator: string, numberTotalPlaces: number, numberDecimalPlaces: number): boolean;
    formatIntervalValue(intervalValue: number, decimalPlaces: number | undefined, locale: string): string;
    /**
     * Parses the value names and returns the intervals.
     *
     * @param values values of the attribute
     * @returns {ConfiguratorAttributeNumericInterval[]} parsed intervals
     */
    getIntervals(values: Configurator.Value[] | undefined): ConfiguratorAttributeNumericInterval[];
    /**
     * Parses the value name and returns the interval structure.
     * Valid interval strings:
     * Standard Interval
     * 5 - 10
     * 5 - <10
     * >5 - 10
     * >5 - <10
     * -10 - -5
     * 1.25 - 1.35
     *
     * Infinite Interval
     * >5
     * >=5
     * <5
     * <=5
     * >-5
     *
     * @param value value which will be parsed
     * @returns {ConfiguratorAttributeNumericInterval} parsed interval
     */
    getInterval(value: Configurator.Value): ConfiguratorAttributeNumericInterval | undefined;
    protected handleSingleOrInfinite(valueName: string, interval: ConfiguratorAttributeNumericInterval): {
        minVal: string;
        maxVal: string;
    };
    protected handleStandardInterval(valueName: string, interval: ConfiguratorAttributeNumericInterval): {
        minVal: string;
        maxVal: string;
    };
    /**
     * Get pattern for the message that is displayed when the validation fails. This message e.g. looks like
     * 'Enter the number in the following format: ##,###,###.##'
     * for the 'en' locale for an attribute with total length of 10 and 2 decimal places.
     *
     * @param decimalPlaces Number of decimal places
     * @param totalLength Total number of digits
     * @param negativeAllowed Do we allow negative input?
     * @param locale  Locale
     *  @returns {string} The pattern that we display in the validation message
     */
    getPatternForValidationMessage(decimalPlaces: number, totalLength: number, negativeAllowed: boolean, locale: string): string;
    /**
     * Returns the validator for the input component that represents numeric input.
     * The validator only allows the grouping separator, the decimal separator, an optional '-' sign,
     * and the digits between 0..9. This validator does not support the scientific notation of
     * attributes.
     *
     * @param locale The locale
     * @param numberDecimalPlaces Number of decimal places
     * @param numberTotalPlaces  Total number of digits
     * @param negativeAllowed: Do we allow negative input?
     * @returns {ValidatorFn} The validator
     */
    getNumberFormatValidator(locale: string, numberDecimalPlaces: number, numberTotalPlaces: number, negativeAllowed: boolean): ValidatorFn;
    protected getValidationErrorsNumericFormat(input: string, locale: string, numberDecimalPlaces: number, numberTotalPlaces: number, negativeAllowed: boolean): {
        [key: string]: any;
    } | null;
    /**
     * Returns the interval validator for the input component that represents numeric input.
     * It becomes active only if intervals are provided (they originate from the attribute's values),
     * and matches the input with the list of intervals.
     * It also becomes active only if the validation for the numeric format itself is fine, in order
     * to avoid multiple validation messages.
     *
     * @param locale The locale
     * @param numberDecimalPlaces Number of decimal places
     * @param numberTotalPlaces  Total number of digits
     * @param negativeAllowed: Do we allow negative input?
     * @returns {ValidatorFn} The validator
     */
    getIntervalValidator(locale: string, numberDecimalPlaces: number, numberTotalPlaces: number, negativeAllowed: boolean, intervals: ConfiguratorAttributeNumericInterval[], currentValue?: string): ValidatorFn;
    protected checkIfPartOfIntervals(input: string, locale: string, intervals: ConfiguratorAttributeNumericInterval[]): boolean;
    protected inputMatchesInterval(input: string, locale: string, interval: ConfiguratorAttributeNumericInterval): boolean;
    protected parseInput(input: string, locale: string): number;
    protected parseInputForSeparators(input: string, groupingSeparator: string, decimalSeparator: string): number;
    protected createValidationError(isError: boolean): {
        [key: string]: any;
    } | null;
    protected createIntervalValidationError(isError: boolean): {
        [key: string]: any;
    } | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeNumericInputFieldService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorAttributeNumericInputFieldService>;
}

declare class DefaultSettings {
    numDecimalPlaces: number;
    numTotalLength: number;
    negativeAllowed: boolean;
}
declare class ConfiguratorAttributeNumericInputFieldComponent extends ConfiguratorAttributeInputFieldComponent implements OnInit, OnDestroy {
    protected configAttributeNumericInputFieldService: ConfiguratorAttributeNumericInputFieldService;
    protected config: ConfiguratorUISettingsConfig;
    protected translation: TranslationService;
    protected attributeComponentContext: ConfiguratorAttributeCompositionContext;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService;
    numericFormatPattern: string;
    locale: string;
    iconType: typeof ICON_TYPE;
    intervals: ConfiguratorAttributeNumericInterval[];
    language: string;
    protected logger: LoggerService;
    constructor(configAttributeNumericInputFieldService: ConfiguratorAttributeNumericInputFieldService, config: ConfiguratorUISettingsConfig, translation: TranslationService, attributeComponentContext: ConfiguratorAttributeCompositionContext, configuratorCommonsService: ConfiguratorCommonsService, configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService);
    /**
     * Do we need to display a validation message
     */
    mustDisplayValidationMessage(): boolean;
    /**
     * Do we need to display a validation message concerning intervals
     */
    mustDisplayIntervalMessage(): boolean;
    ngOnInit(): void;
    protected initializeValidation(): void;
    ngOnDestroy(): void;
    /**
     * Returns a concatenated help text for multiple intervals.
     */
    getHelpTextForInterval(): string;
    /**
     * Returns the combined aria text for attribute and value and the interval help text
     */
    getAriaLabelComplete(): string;
    protected getIntervalText(interval: ConfiguratorAttributeNumericInterval): string;
    protected getTextForPartialInterval(interval: ConfiguratorAttributeNumericInterval, intervalText: string, formattedMinValue: string, formattedMaxValue: string): string;
    protected getTextForRealInterval(formattedMinValue: string, formattedMaxValue: string, intervalText: string, interval: ConfiguratorAttributeNumericInterval): string;
    protected getAdditionalIntervalText(key: string): string;
    protected getInfiniteIntervalText(key: string, value: string): string;
    protected getDefaultSettings(): DefaultSettings;
    protected getInstalledLocale(locale: string): string;
    protected reportMissingLocaleData(lang: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeNumericInputFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAttributeNumericInputFieldComponent, "cx-configurator-attribute-numeric-input-field", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorAttributeNumericInputFieldModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeNumericInputFieldModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeNumericInputFieldModule, never, [typeof i3.KeyboardFocusModule, typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof ConfiguratorAttributeNumericInputFieldComponent], [typeof ConfiguratorAttributeNumericInputFieldComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeNumericInputFieldModule>;
}

declare class ConfiguratorAttributeInputFieldModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeInputFieldModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeInputFieldModule, never, [typeof i3.KeyboardFocusModule, typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof i1.CommonModule, typeof i2.I18nModule, typeof ConfiguratorAttributeInputFieldComponent], [typeof ConfiguratorAttributeInputFieldComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeInputFieldModule>;
}

declare class ConfiguratorAttributeDropDownModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeDropDownModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeDropDownModule, never, [typeof i1.CommonModule, typeof ConfiguratorAttributeQuantityModule, typeof i2$1.FormsModule, typeof i2.I18nModule, typeof i3.KeyboardFocusModule, typeof i6.NgSelectModule, typeof i2$1.ReactiveFormsModule, typeof ConfiguratorPriceModule, typeof ConfiguratorAttributeNumericInputFieldModule, typeof ConfiguratorAttributeInputFieldModule, typeof ConfiguratorShowMoreModule, typeof i2.FeaturesConfigModule, typeof ConfiguratorAttributeDropDownComponent], [typeof ConfiguratorAttributeDropDownComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeDropDownModule>;
}

interface SelectionValue {
    name?: string;
    quantity?: number;
    selected?: boolean;
    valueCode: string;
}
declare class ConfiguratorAttributeMultiSelectionBundleComponent extends ConfiguratorAttributeMultiSelectionBaseComponent implements OnInit {
    preventAction$: BehaviorSubject<boolean>;
    multipleSelectionValues: SelectionValue[];
    ngOnInit(): void;
    /**
     * Initializes selection values and peventAction observable
     */
    protected initialize(): void;
    /**
     * Updates the value dependent on the provided state
     *
     * @param  {any} valueCode - value code to be updated
     * @param  {any} state - selected state
     *
     * @return {ConfigFormUpdateEvent} - form update event
     */
    protected updateMultipleSelectionValues(valueCode: any, state: any): ConfigFormUpdateEvent;
    /**
     * Updates the quantity of the given value
     *
     * @param  eventValue - event value
     *
     * @return {ConfigFormUpdateEvent} - form update event
     */
    protected updateMultipleSelectionValuesQuantity(eventValue: {
        valueCode: string;
        quantity: number;
    }): ConfigFormUpdateEvent | undefined;
    onSelect(eventValue: any): void;
    onDeselect(eventValue: any): void;
    onDeselectAll(): void;
    onChangeValueQuantity(eventValue: any): void;
    onChangeAttributeQuantity(eventObject: any): void;
    /**
     * Extract corresponding price formula parameters
     *
     * @return {ConfiguratorPriceComponentOptions} - New price formula
     */
    extractPriceFormulaParameters(): ConfiguratorPriceComponentOptions;
    /**
     * Extract corresponding product card parameters
     * @param {boolean} disableAllButtons - Prevent all actions, e.g. while loading
     * @param {boolean} hideRemoveButton - hide remove action, e.g. if only value required attribute
     * @param {Configurator.Value} value - Value
     * @param {number} index - index of current value in list of values of attribute
     * @return {ConfiguratorAttributeProductCardComponentOptions} - New product card options
     */
    extractProductCardParameters(disableAllButtons: boolean | null, hideRemoveButton: boolean | null, value: Configurator.Value, index: number): ConfiguratorAttributeProductCardComponentOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeMultiSelectionBundleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAttributeMultiSelectionBundleComponent, "cx-configurator-attribute-multi-selection-bundle", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorAttributeMultiSelectionBundleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeMultiSelectionBundleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeMultiSelectionBundleModule, never, [typeof i1.CommonModule, typeof ConfiguratorAttributeProductCardModule, typeof i2$1.FormsModule, typeof i2.I18nModule, typeof i3.KeyboardFocusModule, typeof i2$1.ReactiveFormsModule, typeof i6$1.RouterModule, typeof i2.UrlModule, typeof ConfiguratorAttributeQuantityModule, typeof ConfiguratorPriceModule, typeof ConfiguratorAttributeMultiSelectionBundleComponent], [typeof ConfiguratorAttributeMultiSelectionBundleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeMultiSelectionBundleModule>;
}

declare class ConfiguratorAttributeMultiSelectionImageComponent extends ConfiguratorAttributeBaseComponent implements OnInit {
    protected configUtilsService: ConfiguratorStorefrontUtilsService;
    protected attributeComponentContext: ConfiguratorAttributeCompositionContext;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    attribute: Configurator.Attribute;
    ownerKey: string;
    expMode: boolean;
    iconTypes: typeof ICON_TYPE;
    protected config: Config;
    constructor(configUtilsService: ConfiguratorStorefrontUtilsService, attributeComponentContext: ConfiguratorAttributeCompositionContext, configuratorCommonsService: ConfiguratorCommonsService);
    attributeCheckBoxForms: UntypedFormControl[];
    ngOnInit(): void;
    /**
     * Fired when a value has been selected
     * @param index Index of selected value
     */
    onSelect(index: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeMultiSelectionImageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAttributeMultiSelectionImageComponent, "cx-configurator-attribute-multi-selection-image", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorAttributeMultiSelectionImageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeMultiSelectionImageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeMultiSelectionImageModule, never, [typeof i3.KeyboardFocusModule, typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof ConfiguratorPriceModule, typeof i3.PopoverModule, typeof ConfiguratorAttributeMultiSelectionImageComponent], [typeof ConfiguratorAttributeMultiSelectionImageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeMultiSelectionImageModule>;
}

declare class ConfiguratorAttributeNotSupportedComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeNotSupportedComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAttributeNotSupportedComponent, "cx-configurator-attribute-not-supported", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorAttributeNotSupportedModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeNotSupportedModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeNotSupportedModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof ConfiguratorAttributeNotSupportedComponent], [typeof ConfiguratorAttributeNotSupportedComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeNotSupportedModule>;
}

declare class ConfiguratorAttributeRadioButtonComponent extends ConfiguratorAttributeSingleSelectionBaseComponent implements OnInit {
    protected quantityService: ConfiguratorAttributeQuantityService;
    protected translation: TranslationService;
    protected attributeComponentContext: ConfiguratorAttributeCompositionContext;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService;
    attributeRadioButtonForm: UntypedFormControl;
    constructor(quantityService: ConfiguratorAttributeQuantityService, translation: TranslationService, attributeComponentContext: ConfiguratorAttributeCompositionContext, configuratorCommonsService: ConfiguratorCommonsService, configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeRadioButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAttributeRadioButtonComponent, "cx-configurator-attribute-radio-button", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorAttributeRadioButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeRadioButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeRadioButtonModule, never, [typeof i1.CommonModule, typeof ConfiguratorAttributeQuantityModule, typeof i2$1.FormsModule, typeof i2.I18nModule, typeof i3.KeyboardFocusModule, typeof i2$1.ReactiveFormsModule, typeof ConfiguratorPriceModule, typeof ConfiguratorAttributeNumericInputFieldModule, typeof ConfiguratorAttributeInputFieldModule, typeof ConfiguratorShowMoreModule, typeof ConfiguratorAttributeRadioButtonComponent], [typeof ConfiguratorAttributeRadioButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeRadioButtonModule>;
}

declare class ConfiguratorAttributeReadOnlyComponent extends ConfiguratorAttributeBaseComponent {
    protected translationService: TranslationService;
    protected attributeComponentContext: ConfiguratorAttributeCompositionContext;
    attribute: Configurator.Attribute;
    group: string;
    expMode: boolean;
    constructor(translationService: TranslationService, attributeComponentContext: ConfiguratorAttributeCompositionContext);
    protected getCurrentValueName(attribute: Configurator.Attribute, value?: Configurator.Value): string;
    getAriaLabel(attribute: Configurator.Attribute, value?: Configurator.Value | undefined): string;
    protected translate(resourceKey: string, valueName: string, attribute: Configurator.Attribute, formattedPrice?: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeReadOnlyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAttributeReadOnlyComponent, "cx-configurator-attribute-read-only", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorAttributeReadOnlyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeReadOnlyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeReadOnlyModule, never, [typeof i3.KeyboardFocusModule, typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof ConfiguratorPriceModule, typeof ConfiguratorShowMoreModule, typeof i1.CommonModule, typeof i2.I18nModule, typeof ConfiguratorAttributeReadOnlyComponent], [typeof ConfiguratorAttributeReadOnlyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeReadOnlyModule>;
}

declare class ConfiguratorAttributeSingleSelectionBundleDropdownComponent extends ConfiguratorAttributeSingleSelectionBaseComponent implements OnInit {
    protected quantityService: ConfiguratorAttributeQuantityService;
    protected translation: TranslationService;
    protected attributeComponentContext: ConfiguratorAttributeCompositionContext;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService;
    readonly RETRACT_VALUE_CODE = "###RETRACT_VALUE_CODE###";
    attributeDropDownForm: UntypedFormControl;
    selectionValue?: Configurator.Value;
    group: string;
    constructor(quantityService: ConfiguratorAttributeQuantityService, translation: TranslationService, attributeComponentContext: ConfiguratorAttributeCompositionContext, configuratorCommonsService: ConfiguratorCommonsService, configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService);
    ngOnInit(): void;
    /**
     * Returns selected value. We assume that when this method is called,
     * a selection has been made before. In case this assumption is false,
     * an error is thrown
     * @returns selected value
     */
    get selectedValue(): Configurator.Value;
    /**
     * Extract corresponding product card parameters
     *
     * @return {ConfiguratorAttributeProductCardComponentOptions} - New product card options
     */
    extractProductCardParameters(): ConfiguratorAttributeProductCardComponentOptions;
    /**
     * Verifies whether a selection value is defined and its value code is not a retract one.
     *
     * @returns {boolean} - 'True' if a selection value is defined and its value code is not a retract one, otherwise 'false'.
     */
    isNotRetractValue(): boolean;
    /**
     * Verifies whether a value code is a retract one.
     *
     * @param {string} valueCode - Value code
     * @returns {boolean} - 'True' if a value code is a retract one, otherwise 'false'.
     */
    isRetractValue(valueCode: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeSingleSelectionBundleDropdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAttributeSingleSelectionBundleDropdownComponent, "cx-configurator-attribute-single-selection-bundle-dropdown", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorAttributeSingleSelectionBundleDropdownModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeSingleSelectionBundleDropdownModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeSingleSelectionBundleDropdownModule, never, [typeof i1.CommonModule, typeof ConfiguratorAttributeProductCardModule, typeof i2$1.FormsModule, typeof i2.I18nModule, typeof i3.KeyboardFocusModule, typeof i6.NgSelectModule, typeof i2$1.ReactiveFormsModule, typeof ConfiguratorAttributeQuantityModule, typeof ConfiguratorPriceModule, typeof ConfiguratorAttributeSingleSelectionBundleDropdownComponent], [typeof ConfiguratorAttributeSingleSelectionBundleDropdownComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeSingleSelectionBundleDropdownModule>;
}

declare class ConfiguratorAttributeSingleSelectionBundleComponent extends ConfiguratorAttributeSingleSelectionBaseComponent {
    /**
     * Extract corresponding product card parameters
     *
     * @param {Configurator.Value} value - Value
     * @param {number} index - index of current value in list of values of attribute
     * @return {ConfiguratorAttributeProductCardComponentOptions} - New product card options
     */
    extractProductCardParameters(value: Configurator.Value, index: number): ConfiguratorAttributeProductCardComponentOptions;
    protected getFocusIdOfNearestValue(currentValue: Configurator.Value): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeSingleSelectionBundleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAttributeSingleSelectionBundleComponent, "cx-configurator-attribute-single-selection-bundle", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorAttributeSingleSelectionBundleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeSingleSelectionBundleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeSingleSelectionBundleModule, never, [typeof i1.CommonModule, typeof ConfiguratorAttributeProductCardModule, typeof ConfiguratorAttributeQuantityModule, typeof i2$1.FormsModule, typeof i2.I18nModule, typeof i3.ItemCounterModule, typeof i3.KeyboardFocusModule, typeof i2$1.ReactiveFormsModule, typeof i6$1.RouterModule, typeof i2.UrlModule, typeof ConfiguratorPriceModule, typeof ConfiguratorAttributeSingleSelectionBundleComponent], [typeof ConfiguratorAttributeSingleSelectionBundleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeSingleSelectionBundleModule>;
}

declare class ConfiguratorAttributeSingleSelectionImageComponent extends ConfiguratorAttributeBaseComponent implements OnInit {
    protected attributeComponentContext: ConfiguratorAttributeCompositionContext;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    attributeRadioButtonForm: UntypedFormControl;
    attribute: Configurator.Attribute;
    ownerKey: string;
    expMode: boolean;
    iconTypes: typeof ICON_TYPE;
    protected config: Config;
    constructor(attributeComponentContext: ConfiguratorAttributeCompositionContext, configuratorCommonsService: ConfiguratorCommonsService);
    ngOnInit(): void;
    /**
     * Submits a value.
     *
     * @param {string} value - Selected value
     */
    onClick(value: string): void;
    extractValuePriceFormulaParameters(value?: Configurator.Value): ConfiguratorPriceComponentOptions;
    getValueDescriptionStyleClasses(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeSingleSelectionImageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorAttributeSingleSelectionImageComponent, "cx-configurator-attribute-single-selection-image", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorAttributeSingleSelectionImageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorAttributeSingleSelectionImageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorAttributeSingleSelectionImageModule, never, [typeof i3.KeyboardFocusModule, typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof ConfiguratorPriceModule, typeof i3.PopoverModule, typeof ConfiguratorAttributeSingleSelectionImageComponent], [typeof ConfiguratorAttributeSingleSelectionImageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorAttributeSingleSelectionImageModule>;
}

interface ProductConfiguratorMessageConfig {
    updateConfigurationMessage?: {
        waitingTime?: number;
    };
}
declare abstract class ConfiguratorMessageConfig {
    productConfigurator?: ProductConfiguratorMessageConfig;
}

interface ProductConfiguratorCoreConfig {
    enableVariantSearch?: boolean;
}
declare abstract class ConfiguratorCoreConfig {
    productConfigurator?: ProductConfiguratorCoreConfig;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorCoreConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorCoreConfig>;
}

declare module '@spartacus/product-configurator/common' {
    interface ProductConfiguratorConfig extends ProductConfiguratorUISettingsConfig, ProductConfiguratorMessageConfig, ConfiguratorAttributeComposition, ProductConfiguratorCoreConfig {
    }
}
declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        CONFLICT_SOLVER = "CONFLICT_SOLVER",
        CONFIGURATOR_OV_FILTER = "CONFIGURATOR_OV_FILTER",
        CONFIGURATOR_RESTART_DIALOG = "CONFIGURATOR_RESTART_DIALOG"
    }
}

declare class ConfiguratorConflictAndErrorMessagesComponent {
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configRouterExtractorService: ConfiguratorRouterExtractorService;
    iconTypes: typeof ICON_TYPE;
    configuration$: Observable<Configurator.Configuration>;
    showWarnings: boolean;
    toggleWarnings(): void;
    showErrors: boolean;
    toggleErrors(): void;
    constructor(configuratorCommonsService: ConfiguratorCommonsService, configRouterExtractorService: ConfiguratorRouterExtractorService);
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorConflictAndErrorMessagesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorConflictAndErrorMessagesComponent, "cx-configuration-conflict-and-error-messages", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorConflictAndErrorMessagesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorConflictAndErrorMessagesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorConflictAndErrorMessagesModule, never, [typeof i1.CommonModule, typeof i6$1.RouterModule, typeof i2.UrlModule, typeof i2.I18nModule, typeof i3.IconModule, typeof ConfiguratorConflictAndErrorMessagesComponent], [typeof ConfiguratorConflictAndErrorMessagesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorConflictAndErrorMessagesModule>;
}

declare class ConfiguratorConflictDescriptionComponent {
    currentGroup: Configurator.Group;
    groupType: typeof Configurator.GroupType;
    iconTypes: typeof ICON_TYPE;
    tabindex: string;
    role: string;
    constructor();
    /**
     * Verifies whether the  conflict description should be displayed for the current group.
     *
     * @param {Configurator.Group} group - Current group
     * @return {boolean} - 'True' if the conflict description should be displayed, otherwise 'false'.
     */
    displayConflictDescription(group: Configurator.Group): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorConflictDescriptionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorConflictDescriptionComponent, "cx-configurator-conflict-description", never, { "currentGroup": { "alias": "currentGroup"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ConfiguratorConflictDescriptionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorConflictDescriptionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorConflictDescriptionModule, never, [typeof i1.CommonModule, typeof i3.IconModule, typeof ConfiguratorConflictDescriptionComponent], [typeof ConfiguratorConflictDescriptionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorConflictDescriptionModule>;
}

declare class ConfiguratorConflictSuggestionComponent {
    currentGroup: Configurator.Group;
    attribute: Configurator.Attribute;
    suggestionNumber: number;
    groupType: typeof Configurator.GroupType;
    tabindex: string;
    role: string;
    constructor();
    /**
     * Verifies whether the conflict suggestion should be displayed for the current group.
     *
     * @param {Configurator.Group} group - Current group
     * @return {boolean} - 'True' if the conflict description should be displayed, otherwise 'false'.
     */
    displayConflictSuggestion(group: Configurator.Group): boolean;
    createSuggestionUiKey(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorConflictSuggestionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorConflictSuggestionComponent, "cx-configurator-conflict-suggestion", never, { "currentGroup": { "alias": "currentGroup"; "required": false; }; "attribute": { "alias": "attribute"; "required": false; }; "suggestionNumber": { "alias": "suggestionNumber"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ConfiguratorConflictSuggestionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorConflictSuggestionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorConflictSuggestionModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof ConfiguratorConflictSuggestionComponent], [typeof ConfiguratorConflictSuggestionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorConflictSuggestionModule>;
}

declare class ConfiguratorExitButtonComponent {
    protected productService: ProductService;
    protected routingService: RoutingService;
    protected configRouterExtractorService: ConfiguratorRouterExtractorService;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected breakpointService: BreakpointService;
    protected windowRef: WindowRef;
    protected location: Location;
    container$: Observable<{
        routerData: ConfiguratorRouter.Data;
        configuration: Configurator.Configuration;
        product: Product | undefined;
    }>;
    constructor(productService: ProductService, routingService: RoutingService, configRouterExtractorService: ConfiguratorRouterExtractorService, configuratorCommonsService: ConfiguratorCommonsService, breakpointService: BreakpointService, windowRef: WindowRef, location: Location);
    protected navigateToCart(): void;
    /**
     * Navigates to the product detail page of the product that is being configured.
     */
    exitConfiguration(): void;
    /**
     * Verifies whether the current screen size equals or is larger than breakpoint `BREAKPOINT.md`.
     *
     * @returns {Observable<boolean>} - If the given breakpoint equals or is larger than`BREAKPOINT.md` returns `true`, otherwise `false`.
     */
    isDesktop(): Observable<boolean>;
    /**
     * Verifies whether the current screen size equals or is smaller than breakpoint `BREAKPOINT.sm`.
     *
     * @returns {Observable<boolean>} - If the given breakpoint equals or is smaller than`BREAKPOINT.sm` returns `true`, otherwise `false`.
     */
    isMobile(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorExitButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorExitButtonComponent, "cx-configurator-exit-button", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorExitButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorExitButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorExitButtonModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof ConfiguratorExitButtonComponent], [typeof ConfiguratorExitButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorExitButtonModule>;
}

declare class ConfiguratorConflictSolverDialogComponent implements OnInit, OnDestroy {
    protected configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected launchDialogService: LaunchDialogService;
    protected focusService: KeyboardFocusService;
    iconTypes: typeof ICON_TYPE;
    uiType: typeof Configurator.UiType;
    focusConfig: FocusConfig;
    protected subscription: Subscription;
    routerData$: Observable<ConfiguratorRouter.Data>;
    conflictGroup$: Observable<Configurator.Group>;
    constructor(configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService, configuratorCommonsService: ConfiguratorCommonsService, launchDialogService: LaunchDialogService, focusService: KeyboardFocusService);
    init(conflictGroup: Observable<Configurator.Group>, routerData: Observable<ConfiguratorRouter.Data>): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    /**
     * Closes a modal with a certain reason.
     * Scrolls to the top of the configuration form.
     * Sets focus to the first attribute.
     *
     * @param {any} reason - Reason
     */
    dismissModal(reason?: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorConflictSolverDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorConflictSolverDialogComponent, "cx-configurator-conflict-solver-dialog", never, {}, {}, never, never, true, never>;
}

type ConflictGroupAndRouterData = {
    conflictGroup?: Configurator.Group;
    routerData: ConfiguratorRouter.Data;
};
declare class ConfiguratorConflictSolverDialogLauncherService implements OnDestroy {
    protected launchDialogService: LaunchDialogService;
    protected configRouterExtractorService: ConfiguratorRouterExtractorService;
    protected configuratorGroupsService: ConfiguratorGroupsService;
    protected subscription: Subscription;
    routerData$: Observable<ConfiguratorRouter.Data>;
    conflictGroupAndRouterData$: Observable<ConflictGroupAndRouterData>;
    constructor(launchDialogService: LaunchDialogService, configRouterExtractorService: ConfiguratorRouterExtractorService, configuratorGroupsService: ConfiguratorGroupsService);
    protected controlDialog(): void;
    protected subscribeToCloseDialog(): void;
    protected openModal(): void;
    protected closeModal(reason?: any): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorConflictSolverDialogLauncherService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorConflictSolverDialogLauncherService>;
}

/**
 * This implementation is OCC specific.
 * Different backend might have completely different need regarding expert mode.
 * To implement custom solution provide your own implementation and customize services that use ConfiguratorExpertModeService
 */
declare class ConfiguratorExpertModeService {
    private _expModeRequested;
    private _expModeActive;
    /**
     * Sets requested expert mode.
     *
     * @param expMode
     */
    setExpModeRequested(expMode: boolean): void;
    /**
     * This function provides the requested expert mode the OCC calls should use, depending
     * on whether there is an active storefront session or not.
     */
    getExpModeRequested(): Observable<boolean>;
    /**
     * Sets requested expert mode.
     *
     * @param expMode
     */
    setExpModeActive(expMode: boolean): void;
    /**
     * This function provides the requested expert mode the OCC calls should use, depending
     * on whether there is an active storefront session or not.
     */
    getExpModeActive(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorExpertModeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorExpertModeService>;
}

declare class ConfiguratorGroupComponent {
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configuratorGroupsService: ConfiguratorGroupsService;
    protected languageService: LanguageService;
    protected configUtils: ConfiguratorStorefrontUtilsService;
    protected configExpertModeService: ConfiguratorExpertModeService;
    protected readonly typePrefix = "AttributeType_";
    group: Configurator.Group;
    owner: CommonConfigurator.Owner;
    isNavigationToGroupEnabled: boolean;
    isPricingAsync?: boolean;
    activeLanguage$: Observable<string>;
    uiType: typeof Configurator.UiType;
    constructor(configuratorCommonsService: ConfiguratorCommonsService, configuratorGroupsService: ConfiguratorGroupsService, languageService: LanguageService, configUtils: ConfiguratorStorefrontUtilsService, configExpertModeService: ConfiguratorExpertModeService);
    /**
     * Updates a configuration, specified by the configuration form update event.
     *
     * @param {ConfigFormUpdateEvent} event - Configuration form update event
     */
    updateConfiguration(event: ConfigFormUpdateEvent): void;
    /**
     * Verifies whether the current group type is conflict one.
     *
     * @param {Configurator.GroupType | undefined} groupType - Group type
     * @return {boolean} - 'True' if the current group is conflict one, otherwise 'false'.
     */
    isConflictGroupType(groupType: Configurator.GroupType | undefined): boolean;
    /**
     * Display group description box only for conflict groups with a given group name (i.e. a conflict description)
     *
     * @param {Configurator.Group} group - Group
     * @returns {boolean} - 'True' if conflict description box should be displayed, otherwise 'false'.
     */
    displayConflictDescription(group: Configurator.Group): boolean;
    /**
     * Generates a group ID.
     *
     * @param {string} groupId - group ID
     * @returns {string | undefined} - generated group ID
     */
    createGroupId(groupId?: string): string | undefined;
    /**
     * Creates unique key for config attribute on the UI
     *
     * @param prefix for key depending on usage (e.g. uiType, label)
     * @param attributeId
     */
    createAttributeUiKey(prefix: string, attributeId: string): string;
    /**
     * Retrieves information whether the expert mode is active.
     *
     * @returns {Observable<boolean> | undefined } - 'True' if the expert mode is active, otherwise 'false'.
     */
    get expMode(): Observable<boolean>;
    getComponentKey(attribute: Configurator.Attribute): string;
    /**
     * track-by function for the *ngFor generating the attribute list of the current group,
     * returning the attribute key.
     *
     * @param _index
     * @param group
     * @returns attribute key
     */
    trackByFn: (_index: number, attribute: Configurator.Attribute) => string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorGroupComponent, "cx-configurator-group", never, { "group": { "alias": "group"; "required": false; }; "owner": { "alias": "owner"; "required": false; }; "isNavigationToGroupEnabled": { "alias": "isNavigationToGroupEnabled"; "required": false; }; "isPricingAsync": { "alias": "isPricingAsync"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ConfiguratorGroupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorGroupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorGroupModule, never, [typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof i1.CommonModule, typeof i2.I18nModule, typeof i6.NgSelectModule, typeof ConfiguratorAttributeNotSupportedModule, typeof ConfiguratorAttributeInputFieldModule, typeof ConfiguratorAttributeFooterModule, typeof ConfiguratorAttributeNumericInputFieldModule, typeof ConfiguratorAttributeHeaderModule, typeof ConfiguratorAttributeRadioButtonModule, typeof ConfiguratorAttributeSingleSelectionBundleModule, typeof ConfiguratorAttributeMultiSelectionBundleModule, typeof ConfiguratorAttributeReadOnlyModule, typeof ConfiguratorAttributeSingleSelectionImageModule, typeof ConfiguratorAttributeSingleSelectionBundleDropdownModule, typeof ConfiguratorAttributeCheckboxModule, typeof ConfiguratorAttributeCheckboxListModule, typeof ConfiguratorAttributeDropDownModule, typeof ConfiguratorAttributeMultiSelectionImageModule, typeof ConfiguratorConflictDescriptionModule, typeof ConfiguratorConflictSuggestionModule, typeof ConfiguratorAttributeCompositionModule, typeof ConfiguratorGroupComponent], [typeof ConfiguratorGroupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorGroupModule>;
}

declare class ConfiguratorConflictSolverDialogModule {
    constructor(_configuratorConflictSolverDialogLauncherService: ConfiguratorConflictSolverDialogLauncherService);
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorConflictSolverDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorConflictSolverDialogModule, never, [typeof i1.CommonModule, typeof i3.IconModule, typeof i2.I18nModule, typeof ConfiguratorGroupModule, typeof i3.KeyboardFocusModule, typeof i2.FeaturesConfigModule, typeof ConfiguratorConflictSolverDialogComponent], [typeof ConfiguratorConflictSolverDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorConflictSolverDialogModule>;
}

declare class ConfiguratorFormComponent implements OnInit, OnDestroy {
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configuratorGroupsService: ConfiguratorGroupsService;
    protected configRouterExtractorService: ConfiguratorRouterExtractorService;
    protected configExpertModeService: ConfiguratorExpertModeService;
    protected launchDialogService: LaunchDialogService;
    protected globalMessageService: GlobalMessageService;
    protected subscription: Subscription;
    protected keyboardFocusService: KeyboardFocusService;
    routerData$: Observable<ConfiguratorRouter.Data>;
    configuration$: Observable<Configurator.Configuration>;
    currentGroup$: Observable<Configurator.Group>;
    constructor(configuratorCommonsService: ConfiguratorCommonsService, configuratorGroupsService: ConfiguratorGroupsService, configRouterExtractorService: ConfiguratorRouterExtractorService, configExpertModeService: ConfiguratorExpertModeService, launchDialogService: LaunchDialogService, globalMessageService: GlobalMessageService);
    ngOnDestroy(): void;
    protected listenForConflictResolution(): void;
    protected displayConflictResolvedMessage(): void;
    ngOnInit(): void;
    /**
     * Verifies whether the navigation to a conflict group is enabled.
     * @param configuration Current configuration
     * @returns {boolean} Returns 'true' if the navigation to a conflict group is enabled, otherwise 'false'.
     */
    isNavigationToGroupEnabled(configuration: Configurator.Configuration): boolean;
    /**
     * Checks if conflict solver dialog is active
     * @param configuration
     * @returns Conflict solver dialog active?
     */
    isDialogActive(configuration: Configurator.Configuration): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorFormComponent, "cx-configurator-form", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorFormModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i6.NgSelectModule, typeof ConfiguratorGroupModule, typeof ConfiguratorFormComponent], [typeof ConfiguratorFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorFormModule>;
}

declare class ConfiguratorGroupMenuService {
    protected windowRef: WindowRef;
    constructor(windowRef: WindowRef);
    /**
     * Retrieves the focused group index.
     *
     * @param {QueryList<ElementRef<HTMLElement>>} groups - List of the groups
     * @returns {number | undefined} - focused group index
     * @protected
     */
    protected getFocusedGroupIndex(groups: QueryList<ElementRef<HTMLElement>>): number | undefined;
    /**
     * Updates the current group index, if the current group index is not equal focused group index.
     * Otherwise the current group index stays unchanged.
     *
     * @param {number} currentGroupIndex - Current group index
     * @param {number} focusedGroupIndex - Focused group index
     * @returns {number} - updated group index
     * @protected
     */
    protected updateCurrentGroupIndex(currentGroupIndex: number, focusedGroupIndex?: number): number;
    /**
     * Focuses the next group.
     *
     * @param {number} currentGroupIndex - Current group index
     * @param {QueryList<ElementRef<HTMLElement>>} groups - List of the groups
     * @protected
     */
    protected focusNextGroup(currentGroupIndex: number, groups: QueryList<ElementRef<HTMLElement>>): void;
    /**
     * Focuses the previous group.
     *
     * @param {number} currentGroupIndex - Current group index
     * @param {QueryList<ElementRef<HTMLElement>>} groups - List of the groups
     * @protected
     */
    protected focusPreviousGroup(currentGroupIndex: number, groups: QueryList<ElementRef<HTMLElement>>): void;
    /**
     * Switches the group on pressing an arrow key.
     *
     * @param {KeyboardEvent} event - keyboard event
     * @param {number} groupIndex - Group index
     * @param {QueryList<ElementRef<HTMLElement>>} groups - List of the groups
     */
    switchGroupOnArrowPress(event: KeyboardEvent, groupIndex: number, groups: QueryList<ElementRef<HTMLElement>>): void;
    /**
     * Verifies whether the first group in the group list is `Back` button.
     *
     * @param {QueryList<ElementRef<HTMLElement>>} groups - List of the groups
     * @returns {boolean} - returns `true` if the first group in the group list is `Back` button, otherwise `false`
     */
    isBackBtnFocused(groups: QueryList<ElementRef<HTMLElement>>): boolean | undefined;
    /**
     * Verifies whether the active group is part of the group list.
     *
     * @param {QueryList<ElementRef<HTMLElement>>} groups - List of the groups
     * @returns {boolean} - returns `true` if the active group is in the group list, otherwise `false`
     */
    isActiveGroupInGroupList(groups: QueryList<ElementRef<HTMLElement>>): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorGroupMenuService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorGroupMenuService>;
}

declare class ConfiguratorGroupMenuComponent {
    protected configCommonsService: ConfiguratorCommonsService;
    protected configuratorGroupsService: ConfiguratorGroupsService;
    protected hamburgerMenuService: HamburgerMenuService;
    protected configRouterExtractorService: ConfiguratorRouterExtractorService;
    protected configUtils: ConfiguratorStorefrontUtilsService;
    protected configGroupMenuService: ConfiguratorGroupMenuService;
    protected directionService: DirectionService;
    protected translation: TranslationService;
    protected configExpertModeService: ConfiguratorExpertModeService;
    groups: QueryList<ElementRef<HTMLElement>>;
    protected breakpointService: BreakpointService;
    routerData$: Observable<ConfiguratorRouter.Data>;
    configuration$: Observable<Configurator.Configuration>;
    currentGroup$: Observable<Configurator.Group>;
    /**
     * Current parent group. Undefined for top level groups
     */
    displayedParentGroup$: Observable<Configurator.Group | undefined>;
    displayedGroups$: Observable<Configurator.Group[]>;
    iconTypes: typeof ICON_TYPE;
    ERROR: string;
    COMPLETE: string;
    WARNING: string;
    ICON: string;
    constructor(configCommonsService: ConfiguratorCommonsService, configuratorGroupsService: ConfiguratorGroupsService, hamburgerMenuService: HamburgerMenuService, configRouterExtractorService: ConfiguratorRouterExtractorService, configUtils: ConfiguratorStorefrontUtilsService, configGroupMenuService: ConfiguratorGroupMenuService, directionService: DirectionService, translation: TranslationService, configExpertModeService: ConfiguratorExpertModeService);
    /**
     * Selects group or navigates to sub-group depending on clicked group
     *
     * @param {Configurator.Group} group - Target Group
     * @param {Configurator.Group} currentGroup - Current group
     */
    click(group: Configurator.Group, currentGroup?: Configurator.Group): void;
    /**
     * Navigate up and set focus if current group information is provided
     *
     * @param {Configurator.Group} currentGroup - Current group
     */
    navigateUp(currentGroup?: Configurator.Group): void;
    /**
     * Retrieves the number of conflicts for the current group.
     *
     * @param {Configurator.Group} group - Current group
     * @return {string} - number of conflicts
     */
    getConflictNumber(group: Configurator.Group): string;
    /**
     * Verifies whether the current group has subgroups.
     *
     * @param {Configurator.Group} group - Current group
     * @return {boolean} - Returns 'true' if the current group has a subgroups, otherwise 'false'.
     */
    hasSubGroups(group: Configurator.Group): boolean;
    /**
     * Retrieves observable of parent group for a group
     * @param group
     * @returns Parent group, undefined in case input group is already on root level
     */
    protected getParentGroup(group: Configurator.Group): Observable<Configurator.Group | undefined>;
    getCondensedParentGroup(parentGroup: Configurator.Group): Observable<Configurator.Group | undefined>;
    condenseGroups(groups: Configurator.Group[]): Configurator.Group[];
    /**
     * Returns true if group has been visited and if the group is not a conflict group.
     *
     * @param {Configurator.Group} group - Current group
     * @param {Configurator.Configuration} configuration - Configuration
     * @return {Observable<boolean>} - true if visited and not a conflict group
     */
    isGroupVisited(group: Configurator.Group, configuration: Configurator.Configuration): Observable<boolean>;
    /**
     * Verifies whether the current group is conflict one.
     *
     * @param {Configurator.GroupType} groupType - Group type
     * @return {boolean} - 'True' if the current group is conflict one, otherwise 'false'.
     */
    isConflictGroupType(groupType: Configurator.GroupType | undefined): boolean;
    /**
     * Returns true if group is conflict header group.
     *
     * @param {Configurator.Group} group - Current group
     *  @return {boolean} - Returns 'true' if the current group is conflict header group, otherwise 'false'.
     */
    isConflictHeader(group: Configurator.Group): boolean;
    /**
     * Returns true if group is conflict group.
     *
     * @param {Configurator.Group} group - Current group
     *  @return {boolean} - Returns 'true' if the current group is conflict group, otherwise 'false'.
     */
    isConflictGroup(group: Configurator.Group): boolean;
    /**
     * Returns group-status style classes dependent on completeness, conflicts, visited status and configurator type.
     *
     * @param {Configurator.Group} group - Current group
     * @param {Configurator.Configuration} configuration - Configuration
     * @return {Observable<boolean>} - true if visited and not a conflict group
     */
    getGroupStatusStyles(group: Configurator.Group, configuration: Configurator.Configuration): Observable<string>;
    protected isLTRDirection(): boolean;
    protected isRTLDirection(): boolean;
    /**
     * Verifies whether the user navigates into a subgroup of the main group menu.
     *
     * @param {KeyboardEvent} event - Keyboard event
     * @returns {boolean} -'true' if the user navigates into the subgroup, otherwise 'false'.
     * @protected
     */
    protected isForwardsNavigation(event: KeyboardEvent): boolean;
    /**
     * Verifies whether the user navigates from a subgroup back to the main group menu.
     *
     * @param {KeyboardEvent} event - Keyboard event
     * @returns {boolean} -'true' if the user navigates back into the main group menu, otherwise 'false'.
     * @protected
     */
    protected isBackNavigation(event: KeyboardEvent): boolean;
    /**
     * Switches the group on pressing an arrow key.
     *
     * @param {KeyboardEvent} event - Keyboard event
     * @param {string} groupIndex - Group index
     * @param {Configurator.Group} targetGroup - Target group
     * @param {Configurator.Group} currentGroup - Current group
     */
    switchGroupOnArrowPress(event: KeyboardEvent, groupIndex: number, targetGroup: Configurator.Group, currentGroup: Configurator.Group): void;
    /**
     * In mobile mode the focus should be set to the first element of the menu ('X') if tab is pressed on the active group menu item.
     * If the focus is currently on the back-button it needs to be checked if the active group is currently in the list of displayed groups.
     * Only if the active group is not in the list of displayed groups, the focus should be set to the first element of the menu ('X') otherwise
     * the focus is set to the active group menu item.
     *
     * @param {KeyboardEvent} event - Keyboard event
     */
    protected handleFocusLoopInMobileMode(event: KeyboardEvent): void;
    /**
     * Persists the keyboard focus state for the given key
     * from the main group menu by back navigation.
     *
     * @param {string} currentGroupId - Current group ID
     */
    setFocusForMainMenu(currentGroupId?: string): void;
    /**
     * Persists the keyboard focus state for the given key
     * from the subgroup menu by forwards navigation.
     *
     * @param {Configurator.Group} group - Group
     * @param {string} currentGroupId - Current group ID
     */
    setFocusForSubGroup(group: Configurator.Group, currentGroupId?: string): void;
    /**
     * Verifies whether the parent group contains a selected group.
     *
     * @param {Configurator.Group} group - Group
     * @param {string} currentGroupId - Current group ID
     * @returns {boolean} - 'true' if the parent group contains a selected group, otherwise 'false'
     */
    containsSelectedGroup(group: Configurator.Group, currentGroupId?: string): boolean;
    /**
     * Retrieves the tab index depending on if the the current group is selected
     * or the parent group contains the selected group.
     *
     * @param {Configurator.Group} group - Group
     * @param {string} currentGroupId - Current group ID
     * @returns {number} - tab index
     */
    getTabIndex(group: Configurator.Group, currentGroupId: string): number;
    /**
     * Verifies whether the current group is selected.
     *
     * @param {string} groupId - group ID
     * @param {string} currentGroupId - Current group ID
     * @returns {boolean} - 'true' if the current group is selected, otherwise 'false'
     */
    isGroupSelected(groupId?: string, currentGroupId?: string): boolean;
    /**
     * Generates a group ID for aria-controls.
     *
     * @param {string} groupId - group ID
     * @returns {string | undefined} - generated group ID
     */
    createAriaControls(groupId?: string): string | undefined;
    /**
     * Generates aria-label for group menu item
     *
     * @param {Configurator.Group} group - group
     * @returns {string | undefined} - generated group ID
     */
    getAriaLabel(group: Configurator.Group): string;
    /**
     * Generates an id for icons.
     *
     * @param {ICON_TYPE} type - icon type
     * @param {string} groupId - group id
     * @returns {string | undefined} - generated icon id
     */
    createIconId(type: ICON_TYPE, groupId?: string): string | undefined;
    /**
     * Generates aria-describedby
     *
     * @param {Configurator.Group} group - Current group
     * @param {Configurator.Configuration} configuration - Configuration
     * @return {Observable<string>} - aria-describedby
     */
    getAriaDescribedby(group: Configurator.Group, configuration: Configurator.Configuration): Observable<string>;
    getGroupMenuTitle(group: Configurator.Group): string | undefined;
    displayMenuItem(group: Configurator.Group): Observable<boolean>;
    /**
     * Checks if conflict solver dialog is active
     * @param configuration
     * @returns Conflict solver dialog active?
     */
    isDialogActive(configuration: Configurator.Configuration): boolean;
    /**
     * track-by function for the *ngFor generating the group menu,
     * returning the group id
     * @param _index
     * @param group
     * @returns groupId
     */
    trackByFn: (_index: number, group: Configurator.Group) => string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorGroupMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorGroupMenuComponent, "cx-configurator-group-menu", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorGroupMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorGroupMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorGroupMenuModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof i3.KeyboardFocusModule, typeof ConfiguratorGroupMenuComponent], [typeof ConfiguratorGroupMenuComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorGroupMenuModule>;
}

declare class ConfiguratorGroupTitleComponent implements OnInit, OnDestroy, AfterContentChecked {
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configuratorGroupsService: ConfiguratorGroupsService;
    protected configRouterExtractorService: ConfiguratorRouterExtractorService;
    protected configExpertModeService: ConfiguratorExpertModeService;
    protected breakpointService: BreakpointService;
    protected configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService;
    protected hamburgerMenuService: HamburgerMenuService;
    ghostStyle: boolean;
    protected subscription: Subscription;
    protected readonly PRE_HEADER = ".PreHeader";
    protected readonly ADD_TO_CART_BUTTON = "cx-configurator-add-to-cart-button";
    protected focusFirstElementInMobileGroupList: boolean;
    displayedGroup$: Observable<Configurator.Group>;
    iconTypes: typeof ICON_TYPE;
    constructor(configuratorCommonsService: ConfiguratorCommonsService, configuratorGroupsService: ConfiguratorGroupsService, configRouterExtractorService: ConfiguratorRouterExtractorService, configExpertModeService: ConfiguratorExpertModeService, breakpointService: BreakpointService, configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService, hamburgerMenuService: HamburgerMenuService);
    ngOnInit(): void;
    ngAfterContentChecked(): void;
    ngOnDestroy(): void;
    getGroupTitle(group: Configurator.Group): string | undefined;
    /**
     * Verifies whether the current screen size equals or is smaller than breakpoint `BREAKPOINT.md`.
     *
     * @returns {Observable<boolean>} - If the given breakpoint equals or is smaller than`BREAKPOINT.md` returns `true`, otherwise `false`.
     */
    isMobile(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorGroupTitleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorGroupTitleComponent, "cx-configurator-group-title", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorGroupTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorGroupTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorGroupTitleModule, never, [typeof i1.CommonModule, typeof i3.HamburgerMenuModule, typeof ConfiguratorGroupTitleComponent], [typeof ConfiguratorGroupTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorGroupTitleModule>;
}

declare class ConfiguratorOverviewAttributeComponent {
    protected breakpointService: BreakpointService;
    attributeOverview: Configurator.AttributeOverview;
    constructor(breakpointService: BreakpointService);
    extractPriceFormulaParameters(): ConfiguratorPriceComponentOptions;
    /**
     * Verifies whether the current screen size equals or is larger than breakpoint `BREAKPOINT.md`.
     *
     * @returns {Observable<boolean>} - If the given breakpoint equals or is larger than`BREAKPOINT.md` returns `true`, otherwise `false`.
     */
    isDesktop(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewAttributeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorOverviewAttributeComponent, "cx-configurator-overview-attribute", never, { "attributeOverview": { "alias": "attributeOverview"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ConfiguratorOverviewAttributeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewAttributeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorOverviewAttributeModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof ConfiguratorPriceModule, typeof ConfiguratorOverviewAttributeComponent], [typeof ConfiguratorOverviewAttributeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorOverviewAttributeModule>;
}

declare class ConfiguratorOverviewBundleAttributeComponent implements OnInit {
    protected productService: ProductService;
    protected translation: TranslationService;
    product$: Observable<Product>;
    attributeOverview: Configurator.AttributeOverview;
    constructor(productService: ProductService, translation: TranslationService);
    ngOnInit(): void;
    /**
     * Returns primary image from product object
     *
     * @param {Product} product
     * @returns {(ImageGroup | ImageGroup[] | undefined)} - primary image. View can handle an undefined image
     */
    getProductPrimaryImage(product: Product): ImageGroup | ImageGroup[] | undefined;
    /**
     * Extract corresponding price formula parameters
     *
     * @return {ConfiguratorPriceComponentOptions} - New price formula
     */
    extractPriceFormulaParameters(): ConfiguratorPriceComponentOptions;
    /**
     * Verifies whether the quantity should be displayed.
     *
     * @return {boolean} - 'true' if the quantity should be displayed, otherwise 'false'
     */
    displayQuantity(): boolean;
    /**
     * Verifies whether the item price should be displayed.
     *
     * @return {boolean} - 'true' if the item price price should be displayed, otherwise 'false'
     */
    displayPrice(): boolean;
    getAriaLabel(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewBundleAttributeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorOverviewBundleAttributeComponent, "cx-configurator-cpq-overview-attribute", never, { "attributeOverview": { "alias": "attributeOverview"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ConfiguratorOverviewBundleAttributeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewBundleAttributeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorOverviewBundleAttributeModule, never, [typeof i1.CommonModule, typeof i3.MediaModule, typeof i2.I18nModule, typeof ConfiguratorPriceModule, typeof ConfiguratorOverviewBundleAttributeComponent], [typeof ConfiguratorOverviewBundleAttributeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorOverviewBundleAttributeModule>;
}

declare class ConfiguratorOverviewFilterComponent implements OnChanges {
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService;
    constructor(configuratorCommonsService: ConfiguratorCommonsService);
    showFilterBar: boolean;
    config: Configurator.ConfigurationWithOverview;
    priceFilter: UntypedFormControl;
    mySelectionsFilter: UntypedFormControl;
    groupFilters: UntypedFormControl[];
    ngOnChanges(): void;
    /**
     * Updates the overview based on the filters currently selected in the UI
     *
     * @param config - current configuration with overview data
     */
    onFilter(config: Configurator.ConfigurationWithOverview): void;
    /**
     * Verifies whether a product is a variant product in the display only view.
     *
     * @returns - if `baseProduct` property of the current product is defined
     * and provides the product code of the base product,
     * and the current product is in the display only view
     * then returns `true`, otherwise `false`.
     */
    isDisplayOnlyVariant(): Observable<boolean>;
    protected extractGroupFilterState(configuration: Configurator.ConfigurationWithOverview): void;
    protected extractAttrFilterState(configuration: Configurator.ConfigurationWithOverview): void;
    protected collectGroupFilters(overview: Configurator.Overview): string[];
    protected collectAttrFilters(): Configurator.OverviewFilter[];
    protected createInputConfig(config: Configurator.ConfigurationWithOverview, attrFilters: Configurator.OverviewFilter[], groupFilers: string[]): Configurator.ConfigurationWithOverview;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorOverviewFilterComponent, "cx-configurator-overview-filter", never, { "showFilterBar": { "alias": "showFilterBar"; "required": false; }; "config": { "alias": "config"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ConfiguratorOverviewFilterBarComponent {
    protected configuratorCommonsService: ConfiguratorCommonsService;
    readonly PREFIX_ID = "cx-overview-filter-applied-";
    readonly FIRST_FILTER_CHECKBOX_ID = "cx-configurator-overview-filter-option-price";
    protected configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService;
    constructor(configuratorCommonsService: ConfiguratorCommonsService);
    config: Configurator.ConfigurationWithOverview;
    iconTypes: typeof ICON_TYPE;
    attributeFilterTypes: typeof Configurator.OverviewFilter;
    /**
     * gets the description for the given group id
     *
     * @param groupId groupId
     * @param config - current configuration with overview data
     */
    getGroupFilterDescription(overview: Configurator.Overview, groupId: string): string;
    /**
     * removes the given attribute filter and updates the configuration overview accordingly
     *
     * @param attrToRemove attribute filter to remove
     * @param config - current configuration with overview data
     */
    onAttrFilterRemove(config: Configurator.ConfigurationWithOverview, attrToRemove: Configurator.OverviewFilter): void;
    /**
     * removes the given group filter and updates the configuration overview accordingly
     *
     * @param groupIdToRemove id of the group to be removed from filtering
     * @param config - current configuration with overview data
     */
    onGroupFilterRemove(config: Configurator.ConfigurationWithOverview, groupIdToRemove: string): void;
    /**
     * Determines the next element to focus on after removing an attribute filter.
     * Return null if removed attribute filter was the last one in the list.
     *
     * @param indexOfRemoved - The index of the attribute filter that has been removed.
     * @param attrFilters - The list of attribute filters.
     * @returns - The next element to focus on, or null if there is none.
     */
    protected getNextElementIdToFocusForAttributeFilter(indexOfRemoved: number, attrFilters: string[]): string | null;
    /**
     * Determines the next element to focus on after removing a group filter.
     * Return id of remove all button if removed group filter was the last one in the list and there are more than one filters (attribute and group combined) left.
     * Return id of first filter checkbox if removed group filter was the last one in the list and only one filter (attribute and group filters conbined) is left.
     *
     * @param indexOfRemoved - The index of the attribute filter that has been removed.
     * @param attrFilters - The list of attribute filters.
     * @param groupFilters - The list of attribute filters.
     * @returns - The next element to focus on
     */
    protected getNextElementIdToFocusForGroupFilter(indexOfRemoved: number, attrFilters: string[], groupFilters: string[]): string;
    /**
     * Focuses the HTML element with the specified ID.
     *
     * This method retrieves the HTML element using the provided ID and calls
     * the `focus` method on it if the element exists.
     *
     * @param elementId - The ID of the HTML element to focus.
     */
    protected focusElementById(elementId: string): void;
    /**
     * check whether the button to remove all filters should be shown
     *
     * @param overview - current configuration overview data
     * @returns - 'true' only if the button to remove all filters should be shown
     */
    isShowRemoveAll(overview: Configurator.Overview): boolean;
    /**
     * removes all filters and updates the configuration overview accordingly
     *
     * @param config - current configuration with overview data
     */
    onRemoveAll(config: Configurator.ConfigurationWithOverview): void;
    protected getInputFilters(overview: Configurator.Overview): [Configurator.OverviewFilter[], string[]];
    protected createInputConfig(config: Configurator.ConfigurationWithOverview, attrFilters: Configurator.OverviewFilter[], groupFilers: string[]): Configurator.ConfigurationWithOverview;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewFilterBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorOverviewFilterBarComponent, "cx-configurator-overview-filter-bar", never, { "config": { "alias": "config"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ConfiguratorOverviewFilterBarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewFilterBarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorOverviewFilterBarModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof ConfiguratorOverviewFilterBarComponent], [typeof ConfiguratorOverviewFilterBarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorOverviewFilterBarModule>;
}

declare class ConfiguratorOverviewFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorOverviewFilterModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof ConfiguratorOverviewFilterBarModule, typeof ConfiguratorOverviewFilterComponent], [typeof ConfiguratorOverviewFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorOverviewFilterModule>;
}

declare class ConfiguratorOverviewFilterButtonComponent {
    protected launchDialogService: LaunchDialogService;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configRouterExtractorService: ConfiguratorRouterExtractorService;
    protected configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService;
    constructor(launchDialogService: LaunchDialogService, configuratorCommonsService: ConfiguratorCommonsService, configRouterExtractorService: ConfiguratorRouterExtractorService);
    filterButton: ElementRef;
    ghostStyle: boolean;
    configurationWithOv$: Observable<Configurator.ConfigurationWithOverview>;
    /**
     * Retrieves the number of filters currently applied to the overview page
     *
     * @param {Configurator.Overview} overview - current configuration overview data
     * @returns {number} - number of applied filters
     */
    getNumFilters(overview: Configurator.Overview): number;
    /**
     * Opens the filter modal
     *
     * @param {Configurator.ConfigurationWithOverview} config - current configuration with overview data
     */
    openFilterModal(config: Configurator.ConfigurationWithOverview): void;
    /**
     * Verifies whether a product is a variant product in the display only view.
     *
     * @returns - if `baseProduct` property of the current product is defined
     * and provides the product code of the base product,
     * and the current product is in the display only view
     * then returns `true`, otherwise `false`.
     */
    isDisplayOnlyVariant(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewFilterButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorOverviewFilterButtonComponent, "cx-configurator-overview-filter-button", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorOverviewFilterButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewFilterButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorOverviewFilterButtonModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof ConfiguratorOverviewFilterBarModule, typeof ConfiguratorOverviewFilterButtonComponent], [typeof ConfiguratorOverviewFilterButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorOverviewFilterButtonModule>;
}

declare class ConfiguratorOverviewFilterDialogComponent {
    protected launchDialogService: LaunchDialogService;
    constructor(launchDialogService: LaunchDialogService);
    config$: rxjs.Observable<any>;
    iconTypes: typeof ICON_TYPE;
    focusConfig: FocusConfig;
    /**
     * closes the filter modal
     */
    closeFilterModal(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewFilterDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorOverviewFilterDialogComponent, "cx-configurator-overview-filter-dialog", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorOverviewFilterDialogModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewFilterDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorOverviewFilterDialogModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof ConfiguratorOverviewFilterModule, typeof i3.KeyboardFocusModule, typeof i2.FeaturesConfigModule, typeof ConfiguratorOverviewFilterDialogComponent], [typeof ConfiguratorOverviewFilterDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorOverviewFilterDialogModule>;
}

declare class ConfiguratorOverviewFormComponent {
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configRouterExtractorService: ConfiguratorRouterExtractorService;
    protected configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService;
    ghostStyle: boolean;
    attributeOverviewType: typeof Configurator.AttributeOverviewType;
    configuration$: Observable<Configurator.Configuration>;
    constructor(configuratorCommonsService: ConfiguratorCommonsService, configRouterExtractorService: ConfiguratorRouterExtractorService, configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService);
    /**
     * Does the configuration contain any selected attribute values?
     * @param {Configurator.Configuration} configuration - Current configuration
     * @returns {boolean} - Any attributes available
     */
    hasAttributes(configuration: Configurator.Configuration): boolean;
    protected hasGroupWithAttributes(groups?: Configurator.GroupOverview[]): boolean;
    /**
     * Verifies whether the next or the previous attributes are same.
     *
     * @param {Configurator.AttributeOverview[]} attributes - Attribute array
     * @param {number} index - Index of the attribute in the array
     * @return {boolean} - 'True' if it is the same attribute, otherwise 'false'
     */
    isSameAttribute(attributes: Configurator.AttributeOverview[], index: number): boolean;
    /**
     * Retrieves the styling for the corresponding element.
     *
     * @param {Configurator.AttributeOverview[]} attributes - Attribute array
     * @param {number} index - Index of the attribute in the array
     * @return {string} - corresponding style class
     */
    getStyleClasses(attributes: Configurator.AttributeOverview[], index: number): string;
    /**
     * Retrieves the styling for the group levels.
     *
     * @param {number} level - Group level. 1 is top level.
     * @param {Configurator.GroupOverview[]} subGroups - subgroups array
     * @return {string} - corresponding style classes
     */
    getGroupLevelStyleClasses(level: number, subGroups: Configurator.GroupOverview[] | undefined): string;
    /**
     * Retrieves a unique prefix ID.
     *
     * @param {string | undefined} prefix - prefix that we need to make the ID unique
     * @param {string} groupId - group ID
     * @returns {string} - prefix ID
     */
    getPrefixId(idPrefix: string | undefined, groupId: string): string;
    /**
     * Retrieves the ids for the overview group headers
     *
     * @param {string} idPrefix - Prefix (reflects the parent groups in the hierarchy)
     * @param {string} groupId - local group id
     * @return {string} - unique group id
     */
    getGroupId(idPrefix: string, groupId: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorOverviewFormComponent, "cx-configurator-overview-form", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorOverviewFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorOverviewFormModule, never, [typeof i1.CommonModule, typeof ConfiguratorOverviewAttributeModule, typeof ConfiguratorOverviewBundleAttributeModule, typeof i2.I18nModule, typeof i2.FeaturesConfigModule, typeof ConfiguratorOverviewFormComponent], [typeof ConfiguratorOverviewFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorOverviewFormModule>;
}

declare class ConfiguratorOverviewMenuComponent implements AfterViewInit {
    protected configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService;
    height: string;
    config: Configurator.ConfigurationWithOverview;
    protected readonly VARIANT_CONFIG_OVERVIEW_NAVIGATION_SLOT = "cx-page-slot.VariantConfigOverviewNavigation";
    protected readonly CX_CONFIGURATOR_OVERVIEW_MENU = "cx-configurator-overview-menu";
    protected readonly CX_MENU_ITEM_BUTTONS = "button.cx-menu-item";
    protected readonly CX_GROUPS = "div.cx-group";
    protected readonly CX_MENU_GROUP = "cx-menu-group";
    protected readonly OV_MENU_ITEM = "-ovMenuItem";
    protected readonly OV_GROUP = "-ovGroup";
    protected readonly ACTIVE_CLASS = "active";
    /**
     * Height of a CSS box model of a menu item
     * See _configurator-overview-menu.scss
     */
    protected readonly MENU_ITEM_HEIGHT = 39.5;
    iconTypes: typeof ICON_TYPE;
    menuItem: HTMLElement | undefined;
    amount: number;
    menuItemsHeight: number;
    styles: readonly [property: string, value: string][];
    constructor(configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService);
    ngAfterViewInit(): void;
    onScroll(): void;
    onResize(): void;
    /**
     *  Retrieves amount of groups and all its subgroups in the overview.
     *
     *  If there are no groups in the overview then zero will be returned.
     *  Otherwise the amount of groups and all its subgroups will be returned.
     *
     * @param {Configurator.Configuration} configuration - Configuration
     * @returns {number} - Amount of groups and all its subgroups
     * @protected
     */
    protected getAmount(configuration: Configurator.Configuration): number;
    protected getAmountOfGroups(amount: number, groups: Configurator.GroupOverview[]): number;
    /**
     * Calculates the total height of existing menu items.
     *
     * @returns {number} - total height of existing menu items
     * @protected
     */
    protected getMenuItemsHeight(): number;
    /**
     * Adjust the styling of VariantConfigOverviewNavigation slot.
     *
     * If the amount is larger than 1 then the styling will be applied.
     * Otherwise the styling will be removed.
     *
     * @protected
     */
    protected adjustStyling(): void;
    /**
     * Retrieves the height of the menu in pixels.
     *
     * If the menu items are rendered, it will be checked whether
     * the height of all menu items equals zero or is larger than the actual height of the spare viewport.
     * If it is a case then the actual height of the spare viewport will be returned, otherwise no height will be returned.
     *
     * @returns {string} - Menu height in pixels
     * @protected
     */
    protected getHeight(): string;
    /**
     * Applies the styling of element according to the passed list of CSS styles.
     *
     * @protected
     */
    protected changeStyling(): void;
    /**
     * Removes the styling of element according to the passed list of CSS styles.
     *
     * @protected
     */
    protected removeStyling(): void;
    protected getMenuItemToHighlight(): HTMLElement | undefined;
    protected highlight(elementToHighlight: HTMLElement | undefined): void;
    protected ensureElementVisible(element: HTMLElement | undefined): void;
    /**
     * Retrieves the styling for the group levels.
     *
     * @param {number} level - Group level. 1 is top level.
     * @return {string} - corresponding style classes
     */
    getGroupLevelStyleClasses(level: number): string;
    /**
     * Navigates to group in OV form
     *
     * @param {string} prefix - Prefix (reflects the parent groups in the hierarchy)
     * @param {string} id - Group id
     */
    navigateToGroup(prefix: string, id: string): void;
    /**
     * Retrieves a unique prefix ID.
     *
     * @param {string | undefined} prefix - prefix that we need to make the ID unique
     * @param {string} groupId - group ID
     * @returns {string} - prefix ID
     */
    getPrefixId(idPrefix: string | undefined, groupId: string): string;
    /**
     * Retrieves the ids for the overview group headers
     *
     * @param {string} idPrefix - Prefix (reflects the parent groups in the hierarchy)
     * @param {string} groupId - local group id
     * @return {string} - unique group id
     */
    getGroupId(idPrefix: string, groupId: string): string;
    /**
     * Retrieves the ids for the overview menu group items
     *
     * @param {string} idPrefix - Prefix (reflects the parent groups in the hierarchy)
     * @param {string} groupId - local group id
     * @return {string} - unique group id
     */
    getMenuItemId(idPrefix: string, groupId: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorOverviewMenuComponent, "cx-configurator-overview-menu", never, { "config": { "alias": "config"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ConfiguratorOverviewMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorOverviewMenuModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof ConfiguratorOverviewMenuComponent], [typeof ConfiguratorOverviewMenuComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorOverviewMenuModule>;
}

declare class ConfiguratorOverviewNotificationBannerComponent {
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configRouterExtractorService: ConfiguratorRouterExtractorService;
    protected commonConfigUtilsService: CommonConfiguratorUtilsService;
    routerData$: Observable<ConfiguratorRouter.Data>;
    configuration$: Observable<Configurator.Configuration>;
    configurationOverview$: Observable<Configurator.Overview | undefined>;
    numberOfIssues$: Observable<number>;
    numberOfConflicts$: Observable<number>;
    skipConflictsOnIssueNavigation$: Observable<boolean>;
    iconTypes: typeof ICON_TYPE;
    constructor(configuratorCommonsService: ConfiguratorCommonsService, configRouterExtractorService: ConfiguratorRouterExtractorService, commonConfigUtilsService: CommonConfiguratorUtilsService);
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewNotificationBannerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorOverviewNotificationBannerComponent, "cx-configurator-overview-notification-banner", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorOverviewNotificationBannerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewNotificationBannerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorOverviewNotificationBannerModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i2.UrlModule, typeof i3.IconModule, typeof i6$1.RouterModule, typeof ConfiguratorOverviewNotificationBannerComponent], [typeof ConfiguratorOverviewNotificationBannerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorOverviewNotificationBannerModule>;
}

declare class ConfiguratorOverviewSidebarComponent {
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configRouterExtractorService: ConfiguratorRouterExtractorService;
    protected configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService;
    ghostStyle: boolean;
    menuTab: ElementRef<HTMLElement>;
    filterTab: ElementRef<HTMLElement>;
    showFilter: boolean;
    constructor(configuratorCommonsService: ConfiguratorCommonsService, configRouterExtractorService: ConfiguratorRouterExtractorService, configuratorStorefrontUtilsService: ConfiguratorStorefrontUtilsService);
    configurationWithOv$: Observable<Configurator.ConfigurationWithOverview>;
    /**
     * Triggers display of the filter view in the overview sidebar
     */
    onFilter(): void;
    /**
     * Triggers display of the menu view in the overview sidebar
     */
    onMenu(): void;
    /**
     * Returns the tabindex for the menu tab.
     *
     * The menu tab is excluded from the tab chain if currently the filter tab content is displayed.
     * @returns tabindex of the menu tab
     */
    getTabIndexForMenuTab(): number;
    /**
     * Returns the tabindex for the filter tab.
     * The filter tab is excluded from the tab chain if currently the menu tab content is displayed.
     * @returns tabindex of the fitler tab
     */
    getTabIndexForFilterTab(): number;
    /**
     * Switches the focus of the tabs on pressing left or right arrow key.
     * @param {KeyboardEvent} event - Keyboard event
     * @param {string} currentTab - Current tab
     */
    switchTabOnArrowPress(event: KeyboardEvent, currentTab: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewSidebarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorOverviewSidebarComponent, "cx-configurator-overview-sidebar", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorOverviewSidebarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorOverviewSidebarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorOverviewSidebarModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof ConfiguratorOverviewFilterModule, typeof ConfiguratorOverviewMenuModule, typeof ConfiguratorOverviewSidebarComponent], [typeof ConfiguratorOverviewSidebarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorOverviewSidebarModule>;
}

declare class ConfiguratorPreviousNextButtonsComponent {
    protected configuratorGroupsService: ConfiguratorGroupsService;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configRouterExtractorService: ConfiguratorRouterExtractorService;
    protected configUtils: ConfiguratorStorefrontUtilsService;
    configuration$: Observable<Configurator.Configuration>;
    constructor(configuratorGroupsService: ConfiguratorGroupsService, configuratorCommonsService: ConfiguratorCommonsService, configRouterExtractorService: ConfiguratorRouterExtractorService, configUtils: ConfiguratorStorefrontUtilsService);
    onPrevious(configuration: Configurator.Configuration): void;
    onNext(configuration: Configurator.Configuration): void;
    getPreviousGroupDescription(configuration: Configurator.Configuration): Observable<string>;
    getNextGroupDescription(configuration: Configurator.Configuration): Observable<string>;
    isFirstGroup(owner: CommonConfigurator.Owner): Observable<boolean>;
    isLastGroup(owner: CommonConfigurator.Owner): Observable<boolean>;
    protected focusFirstAttribute(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorPreviousNextButtonsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorPreviousNextButtonsComponent, "cx-configurator-previous-next-buttons", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorPreviousNextButtonsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorPreviousNextButtonsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorPreviousNextButtonsModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.KeyboardFocusModule, typeof ConfiguratorPreviousNextButtonsComponent], [typeof ConfiguratorPreviousNextButtonsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorPreviousNextButtonsModule>;
}

declare class ConfiguratorPriceSummaryComponent {
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configRouterExtractorService: ConfiguratorRouterExtractorService;
    configuration$: Observable<Configurator.Configuration>;
    constructor(configuratorCommonsService: ConfiguratorCommonsService, configRouterExtractorService: ConfiguratorRouterExtractorService);
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorPriceSummaryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorPriceSummaryComponent, "cx-configurator-price-summary", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorPriceSummaryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorPriceSummaryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorPriceSummaryModule, never, [typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof i1.CommonModule, typeof i2.I18nModule, typeof ConfiguratorPriceSummaryComponent], [typeof ConfiguratorPriceSummaryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorPriceSummaryModule>;
}

declare class ConfiguratorProductTitleComponent {
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configRouterExtractorService: ConfiguratorRouterExtractorService;
    protected productService: ProductService;
    protected configExpertModeService: ConfiguratorExpertModeService;
    ghostStyle: boolean;
    routerData$: Observable<ConfiguratorRouter.Data>;
    configuration$: Observable<Configurator.Configuration>;
    product$: Observable<Product | undefined>;
    protected getProductCode(container: {
        routerData: ConfiguratorRouter.Data;
        configuration: Configurator.Configuration;
    }): string | undefined;
    showMore: boolean;
    iconTypes: typeof ICON_TYPE;
    constructor(configuratorCommonsService: ConfiguratorCommonsService, configRouterExtractorService: ConfiguratorRouterExtractorService, productService: ProductService, configExpertModeService: ConfiguratorExpertModeService);
    triggerDetails(): void;
    get expMode(): Observable<boolean> | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorProductTitleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorProductTitleComponent, "cx-configurator-product-title", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorMainAriaLabelledByDirective implements OnInit, OnDestroy {
    labelledbyId: string;
    protected winRef: WindowRef;
    protected mainEl: HTMLElement | null;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorMainAriaLabelledByDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ConfiguratorMainAriaLabelledByDirective, "[cxConfiguratorMainAriaLabelledBy]", never, { "labelledbyId": { "alias": "cxConfiguratorMainAriaLabelledBy"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ConfiguratorProductTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorProductTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorProductTitleModule, never, [typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof i6.NgSelectModule, typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof i3.MediaModule, typeof ConfiguratorMainAriaLabelledByDirective, typeof ConfiguratorProductTitleComponent], [typeof ConfiguratorProductTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorProductTitleModule>;
}

declare class ConfiguratorTabBarComponent {
    protected configRouterExtractorService: ConfiguratorRouterExtractorService;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    ghostStyle: boolean;
    configTab: ElementRef<HTMLElement>;
    overviewTab: ElementRef<HTMLElement>;
    private static readonly TAB_BAR_QUERY_SELECTOR;
    protected routingService: RoutingService;
    protected configUtils: ConfiguratorStorefrontUtilsService;
    protected focusService: KeyboardFocusService;
    routerData$: Observable<ConfiguratorRouter.Data>;
    configuration$: Observable<Configurator.Configuration>;
    /**
     * Retrieves current page type.
     *
     * @returns - page type
     */
    pageType$: Observable<ConfiguratorRouter.PageType>;
    protected determinePageFromRouterData(routerData: ConfiguratorRouter.Data): ConfiguratorRouter.PageType;
    /**
     * Checks whether the current page is the overview page.
     *
     * @param pageType - Page type
     * @returns Page is overview page?
     */
    isOverviewPage(pageType: ConfiguratorRouter.PageType): boolean;
    /**
     * Navigates to the overview page and sets the focus on the overview element in the tab-bar.
     *
     * @param routerData - Router data
     */
    navigateToOverview(routerData: ConfiguratorRouter.Data): void;
    /**
     * Navigates to the configuration page and sets the focus on the configuration element in the tab-bar.
     *
     * @param routerData - Router data
     */
    navigateToConfiguration(routerData: ConfiguratorRouter.Data): void;
    protected focusOverviewInTabBar(): void;
    protected focusConfigurationInTabBar(): void;
    /**
     * Returns the tabindex for the configuration tab.
     *
     * The configuration tab is excluded from the tab chain if currently the overview page is displayed.
     * @param pageType - Page type
     * @returns tabindex of the configuration tab
     */
    getTabIndexForConfigTab(pageType: ConfiguratorRouter.PageType): number;
    /**
     * Returns the tabindex for the overview tab.
     * The overview tab is excluded from the tab chain if currently the configuration page is displayed.
     * @param pageType
     * @returns tabindex of the overview tab
     */
    getTabIndexForOverviewTab(pageType: ConfiguratorRouter.PageType): number;
    /**
     * Switches the focus of the tabs on pressing left or right arrow key.
     * @param {KeyboardEvent} event - Keyboard event
     * @param {string} currentTab - Current tab
     */
    switchTabOnArrowPress(event: KeyboardEvent, currentTab: string): void;
    constructor(configRouterExtractorService: ConfiguratorRouterExtractorService, configuratorCommonsService: ConfiguratorCommonsService);
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorTabBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorTabBarComponent, "cx-configurator-tab-bar", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorTabBarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorTabBarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorTabBarModule, never, [typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof i3.KeyboardFocusModule, typeof i6.NgSelectModule, typeof i1.CommonModule, typeof i2.I18nModule, typeof i2.UrlModule, typeof i6$1.RouterModule, typeof ConfiguratorTabBarComponent], [typeof ConfiguratorTabBarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorTabBarModule>;
}

declare class ConfiguratorUpdateMessageComponent {
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected configRouterExtractorService: ConfiguratorRouterExtractorService;
    protected config: ConfiguratorMessageConfig;
    hasPendingChanges$: Observable<boolean>;
    constructor(configuratorCommonsService: ConfiguratorCommonsService, configRouterExtractorService: ConfiguratorRouterExtractorService, config: ConfiguratorMessageConfig);
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorUpdateMessageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorUpdateMessageComponent, "cx-configurator-update-message", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorUpdateMessageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorUpdateMessageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorUpdateMessageModule, never, [typeof i1.CommonModule, typeof i3.SpinnerModule, typeof i2.I18nModule, typeof ConfiguratorUpdateMessageComponent], [typeof ConfiguratorUpdateMessageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorUpdateMessageModule>;
}

declare class ConfiguratorVariantCarouselComponent {
    protected productService: ProductService;
    protected translationService: TranslationService;
    protected configuratorRouterExtractorService: ConfiguratorRouterExtractorService;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    configuration$: Observable<Configurator.Configuration>;
    title$: Observable<string | undefined>;
    items$: Observable<Observable<Product | undefined>[]>;
    constructor(productService: ProductService, translationService: TranslationService, configuratorRouterExtractorService: ConfiguratorRouterExtractorService, configuratorCommonsService: ConfiguratorCommonsService);
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorVariantCarouselComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorVariantCarouselComponent, "cx-configurator-variant-carousel", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorVariantCarouselModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorVariantCarouselModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorVariantCarouselModule, never, [typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.CarouselModule, typeof i3.ProductCarouselModule, typeof ConfiguratorVariantCarouselComponent], [typeof ConfiguratorVariantCarouselComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorVariantCarouselModule>;
}

declare class ConfiguratorRestartDialogComponent {
    protected launchDialogService: LaunchDialogService;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected routingService: RoutingService;
    protected productService: ProductService;
    constructor(launchDialogService: LaunchDialogService, configuratorCommonsService: ConfiguratorCommonsService, routingService: RoutingService, productService: ProductService);
    dialogData$: Observable<{
        owner: CommonConfigurator.Owner;
    }>;
    product$: Observable<Product | undefined>;
    iconTypes: typeof ICON_TYPE;
    focusConfig: FocusConfig;
    /**
     * Closes the dialog
     */
    close(): void;
    /**
     * Resume with current configuration
     * @param product owning this configuration
     */
    resume(product: Product): void;
    /**
     * Discards current configuration and requests a new default configuration
     * @param owner owner of the current configuration that will be reused for next configuration
     */
    restart(owner: CommonConfigurator.Owner): void;
    /**
     * Navigates back to product detail page without making a decision
     * @param product owning this configuration
     */
    backToPDP(product: Product): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorRestartDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfiguratorRestartDialogComponent, "cx-configurator-restart-dialog", never, {}, {}, never, never, true, never>;
}

declare class ConfiguratorRestartDialogModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorRestartDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorRestartDialogModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof i3.KeyboardFocusModule, typeof i2.FeaturesConfigModule, typeof ConfiguratorRestartDialogComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorRestartDialogModule>;
}

declare class RulebasedConfiguratorComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RulebasedConfiguratorComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RulebasedConfiguratorComponentsModule, never, [typeof ConfiguratorPriceSummaryModule, typeof ConfiguratorAddToCartButtonModule, typeof ConfiguratorGroupMenuModule, typeof ConfiguratorProductTitleModule, typeof ConfiguratorTabBarModule, typeof ConfiguratorGroupModule, typeof ConfiguratorFormModule, typeof ConfiguratorGroupTitleModule, typeof ConfiguratorUpdateMessageModule, typeof ConfiguratorPreviousNextButtonsModule, typeof ConfiguratorOverviewAttributeModule, typeof ConfiguratorOverviewFormModule, typeof ConfiguratorOverviewMenuModule, typeof ConfiguratorOverviewNotificationBannerModule, typeof ConfiguratorConflictAndErrorMessagesModule, typeof ConfiguratorExitButtonModule, typeof ConfiguratorAttributeCompositionModule, typeof ConfiguratorVariantCarouselModule, typeof ConfiguratorOverviewFilterModule, typeof ConfiguratorOverviewFilterButtonModule, typeof ConfiguratorOverviewFilterDialogModule, typeof ConfiguratorOverviewSidebarModule, typeof ConfiguratorConflictSolverDialogModule, typeof ConfiguratorRestartDialogModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RulebasedConfiguratorComponentsModule>;
}

declare abstract class RulebasedConfiguratorAdapter {
    /**
     * Abstract method used to create a configuration
     *
     * @param productCode Root product code
     * @param forceReset optional - if true, creation of a new default configuration will be enforced, instead of returning a product bound configuration
     */
    abstract createConfiguration(owner: CommonConfigurator.Owner, configIdTemplate?: string, forceReset?: boolean): Observable<Configurator.Configuration>;
    /**
     * Abstract method to read a configuration.
     * If groupId is filled only the attributes of the requested group are returned.
     * For other groups the attributes list will be empty.
     *
     * @param configId configuration id
     * @param groupId group id
     * @param configurationOwner configuration owner
     * @param attributeKey optional - if filled, only the attribute with the given key is returned
     *
     */
    abstract readConfiguration(configId: string, groupId: string, configurationOwner: CommonConfigurator.Owner, attributeKey?: string): Observable<Configurator.Configuration>;
    /**
     * Abstract method to update a configuration
     *
     * @param configuration updated configuration object
     */
    abstract updateConfiguration(configuration: Configurator.Configuration): Observable<Configurator.Configuration>;
    /**
     * Abstract method to update the configuration overview
     *
     * @param configurationOverview Configuration overview with filter options that should be applied
     */
    abstract updateConfigurationOverview(configurationOverview: Configurator.Overview): Observable<Configurator.Overview>;
    /**
     * Abstract method to add a configuration to cart.
     *
     * @param parameters add to cart parameters object
     */
    abstract addToCart(parameters: Configurator.AddToCartParameters): Observable<CartModification>;
    /**
     * Abstract method to read a configuration for a cart entry
     *
     * @param parameters read from cart entry parameters object
     */
    abstract readConfigurationForCartEntry(parameters: CommonConfigurator.ReadConfigurationFromCartEntryParameters): Observable<Configurator.Configuration>;
    /**
     * Abstract method to update a configuration attached to a cart entry
     *
     * @param parameters update cart entry configuration parameters object
     */
    abstract updateConfigurationForCartEntry(parameters: Configurator.UpdateConfigurationForCartEntryParameters): Observable<CartModification>;
    /**
     * Abstract method to read a configuration for an order entry
     *
     * @param parameters Contains attributes that we need to read a configuration attached to an order entry
     * @returns  {Observable<Configurator.Configuration>} Configuration with only the overview aspect provided
     */
    abstract readConfigurationForOrderEntry(parameters: CommonConfigurator.ReadConfigurationFromOrderEntryParameters): Observable<Configurator.Configuration>;
    /**
     * Abstract method to read a configuration price
     *
     * @param configId configuration id
     */
    abstract readPriceSummary(configuration: Configurator.Configuration): Observable<Configurator.Configuration>;
    /**
     * Abstract method to get configuration overview
     *
     * @param configId configuration id
     * @param owner configuration owner
     */
    abstract getConfigurationOverview(configId: string): Observable<Configurator.Overview>;
    /**
     * Abstract method to get the supported configurator type
     *
     */
    abstract getConfiguratorType(): string;
    /**
     * Searches for variants that are matching the configuration identified by its id.
     * Matches will be close to the attribute assignments of the configuration, but
     * don't need to match it 100%
     * @param configId Configuration identifier
     * @returns List of product variants that match the configuration
     */
    abstract searchVariants(configId: string): Observable<Configurator.Variant[]>;
}

declare class RulebasedConfiguratorConnector {
    protected adapters: RulebasedConfiguratorAdapter[];
    protected configUtilsService: CommonConfiguratorUtilsService;
    protected config: ConfiguratorCoreConfig;
    static CONFIGURATOR_ADAPTER_LIST: InjectionToken<RulebasedConfiguratorAdapter[]>;
    constructor(adapters: RulebasedConfiguratorAdapter[], configUtilsService: CommonConfiguratorUtilsService, config: ConfiguratorCoreConfig);
    createConfiguration(owner: CommonConfigurator.Owner, configIdTemplate?: string, forceReset?: boolean): Observable<Configurator.Configuration>;
    readConfiguration(configId: string, groupId: string, configurationOwner: CommonConfigurator.Owner, attributeKey?: string): Observable<Configurator.Configuration>;
    updateConfiguration(configuration: Configurator.Configuration): Observable<Configurator.Configuration>;
    addToCart(parameters: Configurator.AddToCartParameters): Observable<CartModification>;
    readConfigurationForCartEntry(parameters: CommonConfigurator.ReadConfigurationFromCartEntryParameters): Observable<Configurator.Configuration>;
    updateConfigurationForCartEntry(parameters: Configurator.UpdateConfigurationForCartEntryParameters): Observable<CartModification>;
    readConfigurationForOrderEntry(parameters: CommonConfigurator.ReadConfigurationFromOrderEntryParameters): Observable<Configurator.Configuration>;
    readPriceSummary(configuration: Configurator.Configuration): Observable<Configurator.Configuration>;
    getConfigurationOverview(configuration: Configurator.Configuration): Observable<Configurator.Overview>;
    updateConfigurationOverview(configuration: Configurator.Configuration): Observable<Configurator.Overview>;
    searchVariants(configuration: Configurator.Configuration): Observable<Configurator.Variant[]>;
    protected getAdapter(configuratorType: string): RulebasedConfiguratorAdapter;
    protected isAdapterMatching(adapter: RulebasedConfiguratorAdapter, configuratorType: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<RulebasedConfiguratorConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RulebasedConfiguratorConnector>;
}

declare class ConfiguratorRouterListener implements OnDestroy {
    protected configuratorCartService: ConfiguratorCartService;
    protected routingService: RoutingService;
    protected configuratorQuantityService: ConfiguratorQuantityService;
    protected subscription: Subscription;
    constructor(configuratorCartService: ConfiguratorCartService, routingService: RoutingService, configuratorQuantityService: ConfiguratorQuantityService);
    protected observeRouterChanges(): void;
    protected isConfiguratorRelatedRoute(semanticRoute?: string): boolean;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorRouterListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorRouterListener>;
}

declare class ConfiguratorRouterModule {
    constructor(_configuratorRouterListener: ConfiguratorRouterListener);
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorRouterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfiguratorRouterModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfiguratorRouterModule>;
}

declare class ConfiguratorLogoutEventListener implements OnDestroy {
    protected eventService: EventService;
    protected configExpertModeService: ConfiguratorExpertModeService;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    protected subscription: Subscription;
    constructor(eventService: EventService, configExpertModeService: ConfiguratorExpertModeService, configuratorCommonsService: ConfiguratorCommonsService);
    protected onLogout(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorLogoutEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorLogoutEventListener>;
}

declare class ConfiguratorLanguageSetEventListener implements OnDestroy {
    protected subscription: Subscription;
    protected eventService: EventService;
    protected configuratorCommonsService: ConfiguratorCommonsService;
    constructor();
    protected onLanguageSet(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorLanguageSetEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorLanguageSetEventListener>;
}

declare class RulebasedConfiguratorStateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RulebasedConfiguratorStateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RulebasedConfiguratorStateModule, never, [typeof i1.CommonModule, typeof i2.StateModule, typeof i3$1.StoreFeatureModule, typeof i4.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RulebasedConfiguratorStateModule>;
}

/**
 * Exposes the rulebased configurator core entities.
 * Explicit providing of connector because otherwise lazy loading does not work
 */
declare class RulebasedConfiguratorCoreModule {
    constructor(_configuratorLogoutEventListener: ConfiguratorLogoutEventListener, _configuratorLanguageSetEventListener: ConfiguratorLanguageSetEventListener);
    static ɵfac: i0.ɵɵFactoryDeclaration<RulebasedConfiguratorCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RulebasedConfiguratorCoreModule, never, [typeof RulebasedConfiguratorStateModule, typeof ConfiguratorRouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RulebasedConfiguratorCoreModule>;
}

declare const READ_CART_ENTRY_CONFIGURATION = "[Configurator] Read Cart Entry Configuration";
declare const READ_CART_ENTRY_CONFIGURATION_SUCCESS = "[Configurator] Read Cart Entry Configuration Success";
declare const READ_CART_ENTRY_CONFIGURATION_FAIL = "[Configurator] Read Cart Entry Configuration Fail";
declare const READ_ORDER_ENTRY_CONFIGURATION = "[Configurator] Read Order Entry Configuration";
declare const READ_ORDER_ENTRY_CONFIGURATION_SUCCESS = "[Configurator] Read Order Entry Configuration Success";
declare const READ_ORDER_ENTRY_CONFIGURATION_FAIL = "[Configurator] Read Order Entry Configuration Fail";
declare const ADD_TO_CART = "[Configurator] Add to cart";
declare const UPDATE_CART_ENTRY = "[Configurator] Update cart entry";
declare const UPDATE_CART_ENTRY_SUCCESS = "[Configurator] Update cart entry success";
declare const ADD_NEXT_OWNER = "[Configurator] Add next owner";
declare const SET_NEXT_OWNER_CART_ENTRY = "[Configurator] Set next owner cart entry";
declare const REMOVE_CART_BOUND_CONFIGURATIONS = "[Configurator] Remove cart bound configurations";
declare class ReadCartEntryConfiguration extends StateUtils.EntityLoadAction {
    payload: CommonConfigurator.ReadConfigurationFromCartEntryParameters;
    readonly type = "[Configurator] Read Cart Entry Configuration";
    constructor(payload: CommonConfigurator.ReadConfigurationFromCartEntryParameters);
}
declare class ReadCartEntryConfigurationSuccess extends StateUtils.EntitySuccessAction {
    payload: Configurator.Configuration;
    readonly type = "[Configurator] Read Cart Entry Configuration Success";
    constructor(payload: Configurator.Configuration);
}
declare class ReadCartEntryConfigurationFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        ownerKey: string;
        error: any;
    };
    readonly type = "[Configurator] Read Cart Entry Configuration Fail";
    constructor(payload: {
        ownerKey: string;
        error: any;
    });
}
declare class ReadOrderEntryConfiguration extends StateUtils.EntityLoadAction {
    payload: CommonConfigurator.ReadConfigurationFromOrderEntryParameters;
    readonly type = "[Configurator] Read Order Entry Configuration";
    constructor(payload: CommonConfigurator.ReadConfigurationFromOrderEntryParameters);
}
declare class ReadOrderEntryConfigurationSuccess extends StateUtils.EntitySuccessAction {
    payload: Configurator.Configuration;
    readonly type = "[Configurator] Read Order Entry Configuration Success";
    constructor(payload: Configurator.Configuration);
}
declare class ReadOrderEntryConfigurationFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        ownerKey: string;
        error: any;
    };
    readonly type = "[Configurator] Read Order Entry Configuration Fail";
    constructor(payload: {
        ownerKey: string;
        error: any;
    });
}
declare class AddToCart extends StateUtils.EntityProcessesIncrementAction {
    payload: Configurator.AddToCartParameters;
    readonly type = "[Configurator] Add to cart";
    constructor(payload: Configurator.AddToCartParameters);
}
declare class UpdateCartEntry extends StateUtils.EntityProcessesIncrementAction {
    payload: Configurator.UpdateConfigurationForCartEntryParameters;
    readonly type = "[Configurator] Update cart entry";
    constructor(payload: Configurator.UpdateConfigurationForCartEntryParameters);
}
declare class AddNextOwner implements Action {
    payload: {
        ownerKey: string;
        cartEntryNo: string;
    };
    readonly type = "[Configurator] Add next owner";
    constructor(payload: {
        ownerKey: string;
        cartEntryNo: string;
    });
}
declare class RemoveCartBoundConfigurations implements Action {
    readonly type = "[Configurator] Remove cart bound configurations";
    constructor();
}
declare class SetNextOwnerCartEntry extends StateUtils.EntitySuccessAction {
    payload: {
        configuration: Configurator.Configuration;
        cartEntryNo: string;
    };
    readonly type = "[Configurator] Set next owner cart entry";
    constructor(payload: {
        configuration: Configurator.Configuration;
        cartEntryNo: string;
    });
}
type ConfiguratorCartAction = AddNextOwner | SetNextOwnerCartEntry | ReadCartEntryConfiguration | ReadCartEntryConfigurationSuccess | ReadCartEntryConfigurationFail | ReadOrderEntryConfiguration | ReadOrderEntryConfigurationSuccess | ReadOrderEntryConfigurationFail | RemoveCartBoundConfigurations | UpdateCartEntry;

declare const SEARCH_VARIANTS = "[Configurator] Search Variants";
declare const SEARCH_VARIANTS_FAIL = "[Configurator]  Search Variants fail";
declare const SEARCH_VARIANTS_SUCCESS = "[Configurator] Search Variants success";
declare class SearchVariants extends StateUtils.EntityLoadAction {
    payload: Configurator.Configuration;
    readonly type = "[Configurator] Search Variants";
    constructor(payload: Configurator.Configuration);
}
declare class SearchVariantsFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        ownerKey: string;
        error: any;
    };
    readonly type = "[Configurator]  Search Variants fail";
    constructor(payload: {
        ownerKey: string;
        error: any;
    });
}
declare class SearchVariantsSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        ownerKey: string;
        variants: Configurator.Variant[];
    };
    readonly type = "[Configurator] Search Variants success";
    constructor(payload: {
        ownerKey: string;
        variants: Configurator.Variant[];
    });
}
type ConfiguratorVariantAction = SearchVariants | SearchVariantsFail | SearchVariantsSuccess;

declare const CREATE_CONFIGURATION = "[Configurator] Create Configuration";
declare const CREATE_CONFIGURATION_FAIL = "[Configurator] Create Configuration Fail";
declare const CREATE_CONFIGURATION_SUCCESS = "[Configurator] Create Configuration Sucess";
declare const READ_CONFIGURATION = "[Configurator] Read Configuration";
declare const READ_CONFIGURATION_FAIL = "[Configurator] Read Configuration Fail";
declare const READ_CONFIGURATION_SUCCESS = "[Configurator] Read Configuration Sucess";
declare const UPDATE_CONFIGURATION = "[Configurator] Update Configuration";
declare const UPDATE_CONFIGURATION_FAIL = "[Configurator] Update Configuration Fail";
declare const UPDATE_CONFIGURATION_SUCCESS = "[Configurator] Update Configuration Success";
declare const UPDATE_CONFIGURATION_FINALIZE_SUCCESS = "[Configurator] Update Configuration finalize success";
declare const UPDATE_CONFIGURATION_FINALIZE_FAIL = "[Configurator] Update Configuration finalize fail";
declare const CHANGE_GROUP = "[Configurator] Change group";
declare const CHANGE_GROUP_FINALIZE = "[Configurator] Change group finalize";
declare const REMOVE_CONFIGURATION = "[Configurator] Remove configuration";
declare const UPDATE_PRICE_SUMMARY = "[Configurator] Update Configuration Summary Price";
declare const UPDATE_PRICE_SUMMARY_FAIL = "[Configurator] Update Configuration Price Summary fail";
declare const UPDATE_PRICE_SUMMARY_SUCCESS = "[Configurator] Update Configuration Price Summary success";
declare const GET_CONFIGURATION_OVERVIEW = "[Configurator] Get Configuration Overview";
declare const GET_CONFIGURATION_OVERVIEW_FAIL = "[Configurator] Get Configuration Overview fail";
declare const GET_CONFIGURATION_OVERVIEW_SUCCESS = "[Configurator] Get Configuration Overview success";
declare const UPDATE_CONFIGURATION_OVERVIEW = "[Configurator] Update Configuration Overview";
declare const UPDATE_CONFIGURATION_OVERVIEW_FAIL = "[Configurator] Update Configuration Overview fail";
declare const UPDATE_CONFIGURATION_OVERVIEW_SUCCESS = "[Configurator] Update Configuration Overview success";
declare const SET_INTERACTION_STATE = "[Configurator] Set interaction state";
declare const SET_CURRENT_GROUP = "[Configurator] Set current group to State";
declare const SET_MENU_PARENT_GROUP = "[Configurator] Set current parent group for menu to State";
declare const SET_GROUPS_VISITED = "[Configurator] Set groups to visited";
declare const REMOVE_PRODUCT_BOUND_CONFIGURATIONS = "[Configurator] Remove product bound configurations";
declare const DISMISS_CONFLICT_DIALOG = "[Configurator] Dismiss conflict dialog";
declare const CHECK_CONFLICT_DIALOG = "[Configurator] Check conflict dialog";
declare const READ_ATTRIBUTE_DOMAIN = "[Configurator] Read Attribute Domain";
declare class CreateConfiguration extends StateUtils.EntityLoadAction {
    payload: {
        owner: CommonConfigurator.Owner;
        configIdTemplate?: string;
        forceReset?: boolean;
    };
    readonly type = "[Configurator] Create Configuration";
    constructor(payload: {
        owner: CommonConfigurator.Owner;
        configIdTemplate?: string;
        forceReset?: boolean;
    });
}
declare class CreateConfigurationFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        ownerKey: string;
        error: any;
    };
    readonly type = "[Configurator] Create Configuration Fail";
    constructor(payload: {
        ownerKey: string;
        error: any;
    });
}
declare class CreateConfigurationSuccess extends StateUtils.EntitySuccessAction {
    payload: Configurator.Configuration;
    readonly type = "[Configurator] Create Configuration Sucess";
    constructor(payload: Configurator.Configuration);
}
declare class ReadConfiguration extends StateUtils.EntityLoadAction {
    payload: {
        configuration: Configurator.Configuration;
        groupId: string;
    };
    readonly type = "[Configurator] Read Configuration";
    constructor(payload: {
        configuration: Configurator.Configuration;
        groupId: string;
    });
}
declare class ReadConfigurationFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        ownerKey: string;
        error: any;
    };
    readonly type = "[Configurator] Read Configuration Fail";
    constructor(payload: {
        ownerKey: string;
        error: any;
    });
}
declare class ReadConfigurationSuccess extends StateUtils.EntitySuccessAction {
    payload: Configurator.Configuration;
    readonly type = "[Configurator] Read Configuration Sucess";
    constructor(payload: Configurator.Configuration);
}
declare class UpdateConfiguration extends StateUtils.EntityProcessesIncrementAction {
    payload: Configurator.Configuration;
    readonly type = "[Configurator] Update Configuration";
    constructor(payload: Configurator.Configuration);
}
declare class UpdateConfigurationFail extends StateUtils.EntityProcessesDecrementAction implements ErrorAction {
    payload: {
        configuration: Configurator.Configuration;
        error: any;
    };
    error: any;
    readonly type = "[Configurator] Update Configuration Fail";
    constructor(payload: {
        configuration: Configurator.Configuration;
        error: any;
    });
}
declare class UpdateConfigurationSuccess extends StateUtils.EntityProcessesDecrementAction {
    payload: Configurator.Configuration;
    readonly type = "[Configurator] Update Configuration Success";
    constructor(payload: Configurator.Configuration);
}
declare class UpdateConfigurationFinalizeSuccess extends StateUtils.EntitySuccessAction {
    payload: Configurator.Configuration;
    readonly type = "[Configurator] Update Configuration finalize success";
    constructor(payload: Configurator.Configuration);
}
declare class UpdateConfigurationFinalizeFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: Configurator.Configuration;
    readonly type = "[Configurator] Update Configuration finalize fail";
    constructor(payload: Configurator.Configuration);
}
declare class UpdatePriceSummary extends StateUtils.EntityLoadAction {
    payload: Configurator.Configuration;
    readonly type = "[Configurator] Update Configuration Summary Price";
    constructor(payload: Configurator.Configuration);
}
declare class UpdatePriceSummaryFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        ownerKey: string;
        error: any;
    };
    readonly type = "[Configurator] Update Configuration Price Summary fail";
    constructor(payload: {
        ownerKey: string;
        error: any;
    });
}
declare class UpdatePriceSummarySuccess extends StateUtils.EntitySuccessAction {
    payload: Configurator.Configuration;
    readonly type = "[Configurator] Update Configuration Price Summary success";
    constructor(payload: Configurator.Configuration);
}
declare class ChangeGroup extends StateUtils.EntityLoadAction {
    payload: {
        configuration: Configurator.Configuration;
        groupId: string;
        /**
         * Id of parent group. Can be undefined for groups on root level
         */
        parentGroupId?: string;
        conflictResolutionMode?: boolean;
    };
    readonly type = "[Configurator] Change group";
    constructor(payload: {
        configuration: Configurator.Configuration;
        groupId: string;
        /**
         * Id of parent group. Can be undefined for groups on root level
         */
        parentGroupId?: string;
        conflictResolutionMode?: boolean;
    });
}
declare class ChangeGroupFinalize extends StateUtils.EntityLoadAction {
    payload: Configurator.Configuration;
    readonly type = "[Configurator] Change group finalize";
    constructor(payload: Configurator.Configuration);
}
declare class RemoveConfiguration extends StateUtils.EntityLoaderResetAction {
    payload: {
        ownerKey: string | string[];
    };
    readonly type = "[Configurator] Remove configuration";
    constructor(payload: {
        ownerKey: string | string[];
    });
}
declare class GetConfigurationOverview extends StateUtils.EntityLoadAction {
    payload: Configurator.Configuration;
    readonly type = "[Configurator] Get Configuration Overview";
    constructor(payload: Configurator.Configuration);
}
declare class GetConfigurationOverviewFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        ownerKey: string;
        error: any;
    };
    readonly type = "[Configurator] Get Configuration Overview fail";
    constructor(payload: {
        ownerKey: string;
        error: any;
    });
}
declare class GetConfigurationOverviewSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        ownerKey: string;
        overview: Configurator.Overview;
    };
    readonly type = "[Configurator] Get Configuration Overview success";
    constructor(payload: {
        ownerKey: string;
        overview: Configurator.Overview;
    });
}
declare class UpdateConfigurationOverview extends StateUtils.EntityLoadAction {
    payload: Configurator.Configuration;
    readonly type = "[Configurator] Update Configuration Overview";
    constructor(payload: Configurator.Configuration);
}
declare class UpdateConfigurationOverviewFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        ownerKey: string;
        error: any;
    };
    readonly type = "[Configurator] Update Configuration Overview fail";
    constructor(payload: {
        ownerKey: string;
        error: any;
    });
}
declare class UpdateConfigurationOverviewSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        ownerKey: string;
        overview: Configurator.Overview;
    };
    readonly type = "[Configurator] Update Configuration Overview success";
    constructor(payload: {
        ownerKey: string;
        overview: Configurator.Overview;
    });
}
declare class SetInteractionState extends StateUtils.EntitySuccessAction {
    payload: {
        entityKey: string | string[];
        interactionState: Configurator.InteractionState;
    };
    readonly type = "[Configurator] Set interaction state";
    constructor(payload: {
        entityKey: string | string[];
        interactionState: Configurator.InteractionState;
    });
}
declare class SetCurrentGroup extends StateUtils.EntitySuccessAction {
    payload: {
        entityKey: string | string[];
        currentGroup: string;
    };
    readonly type = "[Configurator] Set current group to State";
    constructor(payload: {
        entityKey: string | string[];
        currentGroup: string;
    });
}
declare class SetMenuParentGroup extends StateUtils.EntitySuccessAction {
    payload: {
        entityKey: string | string[];
        /**
         * Id of parent group. Can be undefined for groups on root level
         */
        menuParentGroup?: string;
    };
    readonly type = "[Configurator] Set current parent group for menu to State";
    constructor(payload: {
        entityKey: string | string[];
        /**
         * Id of parent group. Can be undefined for groups on root level
         */
        menuParentGroup?: string;
    });
}
declare class SetGroupsVisited extends StateUtils.EntitySuccessAction {
    payload: {
        entityKey: string;
        visitedGroups: string[];
    };
    readonly type = "[Configurator] Set groups to visited";
    constructor(payload: {
        entityKey: string;
        visitedGroups: string[];
    });
}
declare class RemoveProductBoundConfigurations implements Action {
    readonly type = "[Configurator] Remove product bound configurations";
    constructor();
}
declare class DissmissConflictDialoge extends StateUtils.EntitySuccessAction {
    ownerKey: string;
    readonly type = "[Configurator] Dismiss conflict dialog";
    constructor(ownerKey: string);
}
declare class CheckConflictDialoge extends StateUtils.EntitySuccessAction {
    ownerKey: string;
    readonly type = "[Configurator] Check conflict dialog";
    constructor(ownerKey: string);
}
declare class ReadAttributeDomain extends StateUtils.EntityLoadAction {
    payload: {
        configuration: Configurator.Configuration;
        groupId: string;
        attributeKey: string;
    };
    readonly type = "[Configurator] Read Attribute Domain";
    constructor(payload: {
        configuration: Configurator.Configuration;
        groupId: string;
        attributeKey: string;
    });
}
type ConfiguratorAction = CreateConfiguration | CreateConfigurationFail | CreateConfigurationSuccess | ReadConfiguration | ReadConfigurationFail | ReadConfigurationSuccess | UpdateConfiguration | UpdateConfigurationFail | UpdateConfigurationSuccess | UpdateConfigurationFinalizeFail | UpdateConfigurationFinalizeSuccess | UpdatePriceSummary | UpdatePriceSummaryFail | UpdatePriceSummarySuccess | ChangeGroup | ChangeGroupFinalize | GetConfigurationOverview | GetConfigurationOverviewFail | GetConfigurationOverviewSuccess | UpdateConfigurationOverview | UpdateConfigurationOverviewFail | UpdateConfigurationOverviewSuccess | RemoveConfiguration | SetInteractionState | SetMenuParentGroup | SetCurrentGroup | SetGroupsVisited | RemoveProductBoundConfigurations | CheckConflictDialoge | DissmissConflictDialoge | ReadAttributeDomain;

declare const configuratorGroup_actions_d_ADD_NEXT_OWNER: typeof ADD_NEXT_OWNER;
declare const configuratorGroup_actions_d_ADD_TO_CART: typeof ADD_TO_CART;
type configuratorGroup_actions_d_AddNextOwner = AddNextOwner;
declare const configuratorGroup_actions_d_AddNextOwner: typeof AddNextOwner;
type configuratorGroup_actions_d_AddToCart = AddToCart;
declare const configuratorGroup_actions_d_AddToCart: typeof AddToCart;
declare const configuratorGroup_actions_d_CHANGE_GROUP: typeof CHANGE_GROUP;
declare const configuratorGroup_actions_d_CHANGE_GROUP_FINALIZE: typeof CHANGE_GROUP_FINALIZE;
declare const configuratorGroup_actions_d_CHECK_CONFLICT_DIALOG: typeof CHECK_CONFLICT_DIALOG;
declare const configuratorGroup_actions_d_CREATE_CONFIGURATION: typeof CREATE_CONFIGURATION;
declare const configuratorGroup_actions_d_CREATE_CONFIGURATION_FAIL: typeof CREATE_CONFIGURATION_FAIL;
declare const configuratorGroup_actions_d_CREATE_CONFIGURATION_SUCCESS: typeof CREATE_CONFIGURATION_SUCCESS;
type configuratorGroup_actions_d_ChangeGroup = ChangeGroup;
declare const configuratorGroup_actions_d_ChangeGroup: typeof ChangeGroup;
type configuratorGroup_actions_d_ChangeGroupFinalize = ChangeGroupFinalize;
declare const configuratorGroup_actions_d_ChangeGroupFinalize: typeof ChangeGroupFinalize;
type configuratorGroup_actions_d_CheckConflictDialoge = CheckConflictDialoge;
declare const configuratorGroup_actions_d_CheckConflictDialoge: typeof CheckConflictDialoge;
type configuratorGroup_actions_d_ConfiguratorAction = ConfiguratorAction;
type configuratorGroup_actions_d_ConfiguratorCartAction = ConfiguratorCartAction;
type configuratorGroup_actions_d_ConfiguratorVariantAction = ConfiguratorVariantAction;
type configuratorGroup_actions_d_CreateConfiguration = CreateConfiguration;
declare const configuratorGroup_actions_d_CreateConfiguration: typeof CreateConfiguration;
type configuratorGroup_actions_d_CreateConfigurationFail = CreateConfigurationFail;
declare const configuratorGroup_actions_d_CreateConfigurationFail: typeof CreateConfigurationFail;
type configuratorGroup_actions_d_CreateConfigurationSuccess = CreateConfigurationSuccess;
declare const configuratorGroup_actions_d_CreateConfigurationSuccess: typeof CreateConfigurationSuccess;
declare const configuratorGroup_actions_d_DISMISS_CONFLICT_DIALOG: typeof DISMISS_CONFLICT_DIALOG;
type configuratorGroup_actions_d_DissmissConflictDialoge = DissmissConflictDialoge;
declare const configuratorGroup_actions_d_DissmissConflictDialoge: typeof DissmissConflictDialoge;
declare const configuratorGroup_actions_d_GET_CONFIGURATION_OVERVIEW: typeof GET_CONFIGURATION_OVERVIEW;
declare const configuratorGroup_actions_d_GET_CONFIGURATION_OVERVIEW_FAIL: typeof GET_CONFIGURATION_OVERVIEW_FAIL;
declare const configuratorGroup_actions_d_GET_CONFIGURATION_OVERVIEW_SUCCESS: typeof GET_CONFIGURATION_OVERVIEW_SUCCESS;
type configuratorGroup_actions_d_GetConfigurationOverview = GetConfigurationOverview;
declare const configuratorGroup_actions_d_GetConfigurationOverview: typeof GetConfigurationOverview;
type configuratorGroup_actions_d_GetConfigurationOverviewFail = GetConfigurationOverviewFail;
declare const configuratorGroup_actions_d_GetConfigurationOverviewFail: typeof GetConfigurationOverviewFail;
type configuratorGroup_actions_d_GetConfigurationOverviewSuccess = GetConfigurationOverviewSuccess;
declare const configuratorGroup_actions_d_GetConfigurationOverviewSuccess: typeof GetConfigurationOverviewSuccess;
declare const configuratorGroup_actions_d_READ_ATTRIBUTE_DOMAIN: typeof READ_ATTRIBUTE_DOMAIN;
declare const configuratorGroup_actions_d_READ_CART_ENTRY_CONFIGURATION: typeof READ_CART_ENTRY_CONFIGURATION;
declare const configuratorGroup_actions_d_READ_CART_ENTRY_CONFIGURATION_FAIL: typeof READ_CART_ENTRY_CONFIGURATION_FAIL;
declare const configuratorGroup_actions_d_READ_CART_ENTRY_CONFIGURATION_SUCCESS: typeof READ_CART_ENTRY_CONFIGURATION_SUCCESS;
declare const configuratorGroup_actions_d_READ_CONFIGURATION: typeof READ_CONFIGURATION;
declare const configuratorGroup_actions_d_READ_CONFIGURATION_FAIL: typeof READ_CONFIGURATION_FAIL;
declare const configuratorGroup_actions_d_READ_CONFIGURATION_SUCCESS: typeof READ_CONFIGURATION_SUCCESS;
declare const configuratorGroup_actions_d_READ_ORDER_ENTRY_CONFIGURATION: typeof READ_ORDER_ENTRY_CONFIGURATION;
declare const configuratorGroup_actions_d_READ_ORDER_ENTRY_CONFIGURATION_FAIL: typeof READ_ORDER_ENTRY_CONFIGURATION_FAIL;
declare const configuratorGroup_actions_d_READ_ORDER_ENTRY_CONFIGURATION_SUCCESS: typeof READ_ORDER_ENTRY_CONFIGURATION_SUCCESS;
declare const configuratorGroup_actions_d_REMOVE_CART_BOUND_CONFIGURATIONS: typeof REMOVE_CART_BOUND_CONFIGURATIONS;
declare const configuratorGroup_actions_d_REMOVE_CONFIGURATION: typeof REMOVE_CONFIGURATION;
declare const configuratorGroup_actions_d_REMOVE_PRODUCT_BOUND_CONFIGURATIONS: typeof REMOVE_PRODUCT_BOUND_CONFIGURATIONS;
type configuratorGroup_actions_d_ReadAttributeDomain = ReadAttributeDomain;
declare const configuratorGroup_actions_d_ReadAttributeDomain: typeof ReadAttributeDomain;
type configuratorGroup_actions_d_ReadCartEntryConfiguration = ReadCartEntryConfiguration;
declare const configuratorGroup_actions_d_ReadCartEntryConfiguration: typeof ReadCartEntryConfiguration;
type configuratorGroup_actions_d_ReadCartEntryConfigurationFail = ReadCartEntryConfigurationFail;
declare const configuratorGroup_actions_d_ReadCartEntryConfigurationFail: typeof ReadCartEntryConfigurationFail;
type configuratorGroup_actions_d_ReadCartEntryConfigurationSuccess = ReadCartEntryConfigurationSuccess;
declare const configuratorGroup_actions_d_ReadCartEntryConfigurationSuccess: typeof ReadCartEntryConfigurationSuccess;
type configuratorGroup_actions_d_ReadConfiguration = ReadConfiguration;
declare const configuratorGroup_actions_d_ReadConfiguration: typeof ReadConfiguration;
type configuratorGroup_actions_d_ReadConfigurationFail = ReadConfigurationFail;
declare const configuratorGroup_actions_d_ReadConfigurationFail: typeof ReadConfigurationFail;
type configuratorGroup_actions_d_ReadConfigurationSuccess = ReadConfigurationSuccess;
declare const configuratorGroup_actions_d_ReadConfigurationSuccess: typeof ReadConfigurationSuccess;
type configuratorGroup_actions_d_ReadOrderEntryConfiguration = ReadOrderEntryConfiguration;
declare const configuratorGroup_actions_d_ReadOrderEntryConfiguration: typeof ReadOrderEntryConfiguration;
type configuratorGroup_actions_d_ReadOrderEntryConfigurationFail = ReadOrderEntryConfigurationFail;
declare const configuratorGroup_actions_d_ReadOrderEntryConfigurationFail: typeof ReadOrderEntryConfigurationFail;
type configuratorGroup_actions_d_ReadOrderEntryConfigurationSuccess = ReadOrderEntryConfigurationSuccess;
declare const configuratorGroup_actions_d_ReadOrderEntryConfigurationSuccess: typeof ReadOrderEntryConfigurationSuccess;
type configuratorGroup_actions_d_RemoveCartBoundConfigurations = RemoveCartBoundConfigurations;
declare const configuratorGroup_actions_d_RemoveCartBoundConfigurations: typeof RemoveCartBoundConfigurations;
type configuratorGroup_actions_d_RemoveConfiguration = RemoveConfiguration;
declare const configuratorGroup_actions_d_RemoveConfiguration: typeof RemoveConfiguration;
type configuratorGroup_actions_d_RemoveProductBoundConfigurations = RemoveProductBoundConfigurations;
declare const configuratorGroup_actions_d_RemoveProductBoundConfigurations: typeof RemoveProductBoundConfigurations;
declare const configuratorGroup_actions_d_SEARCH_VARIANTS: typeof SEARCH_VARIANTS;
declare const configuratorGroup_actions_d_SEARCH_VARIANTS_FAIL: typeof SEARCH_VARIANTS_FAIL;
declare const configuratorGroup_actions_d_SEARCH_VARIANTS_SUCCESS: typeof SEARCH_VARIANTS_SUCCESS;
declare const configuratorGroup_actions_d_SET_CURRENT_GROUP: typeof SET_CURRENT_GROUP;
declare const configuratorGroup_actions_d_SET_GROUPS_VISITED: typeof SET_GROUPS_VISITED;
declare const configuratorGroup_actions_d_SET_INTERACTION_STATE: typeof SET_INTERACTION_STATE;
declare const configuratorGroup_actions_d_SET_MENU_PARENT_GROUP: typeof SET_MENU_PARENT_GROUP;
declare const configuratorGroup_actions_d_SET_NEXT_OWNER_CART_ENTRY: typeof SET_NEXT_OWNER_CART_ENTRY;
type configuratorGroup_actions_d_SearchVariants = SearchVariants;
declare const configuratorGroup_actions_d_SearchVariants: typeof SearchVariants;
type configuratorGroup_actions_d_SearchVariantsFail = SearchVariantsFail;
declare const configuratorGroup_actions_d_SearchVariantsFail: typeof SearchVariantsFail;
type configuratorGroup_actions_d_SearchVariantsSuccess = SearchVariantsSuccess;
declare const configuratorGroup_actions_d_SearchVariantsSuccess: typeof SearchVariantsSuccess;
type configuratorGroup_actions_d_SetCurrentGroup = SetCurrentGroup;
declare const configuratorGroup_actions_d_SetCurrentGroup: typeof SetCurrentGroup;
type configuratorGroup_actions_d_SetGroupsVisited = SetGroupsVisited;
declare const configuratorGroup_actions_d_SetGroupsVisited: typeof SetGroupsVisited;
type configuratorGroup_actions_d_SetInteractionState = SetInteractionState;
declare const configuratorGroup_actions_d_SetInteractionState: typeof SetInteractionState;
type configuratorGroup_actions_d_SetMenuParentGroup = SetMenuParentGroup;
declare const configuratorGroup_actions_d_SetMenuParentGroup: typeof SetMenuParentGroup;
type configuratorGroup_actions_d_SetNextOwnerCartEntry = SetNextOwnerCartEntry;
declare const configuratorGroup_actions_d_SetNextOwnerCartEntry: typeof SetNextOwnerCartEntry;
declare const configuratorGroup_actions_d_UPDATE_CART_ENTRY: typeof UPDATE_CART_ENTRY;
declare const configuratorGroup_actions_d_UPDATE_CART_ENTRY_SUCCESS: typeof UPDATE_CART_ENTRY_SUCCESS;
declare const configuratorGroup_actions_d_UPDATE_CONFIGURATION: typeof UPDATE_CONFIGURATION;
declare const configuratorGroup_actions_d_UPDATE_CONFIGURATION_FAIL: typeof UPDATE_CONFIGURATION_FAIL;
declare const configuratorGroup_actions_d_UPDATE_CONFIGURATION_FINALIZE_FAIL: typeof UPDATE_CONFIGURATION_FINALIZE_FAIL;
declare const configuratorGroup_actions_d_UPDATE_CONFIGURATION_FINALIZE_SUCCESS: typeof UPDATE_CONFIGURATION_FINALIZE_SUCCESS;
declare const configuratorGroup_actions_d_UPDATE_CONFIGURATION_OVERVIEW: typeof UPDATE_CONFIGURATION_OVERVIEW;
declare const configuratorGroup_actions_d_UPDATE_CONFIGURATION_OVERVIEW_FAIL: typeof UPDATE_CONFIGURATION_OVERVIEW_FAIL;
declare const configuratorGroup_actions_d_UPDATE_CONFIGURATION_OVERVIEW_SUCCESS: typeof UPDATE_CONFIGURATION_OVERVIEW_SUCCESS;
declare const configuratorGroup_actions_d_UPDATE_CONFIGURATION_SUCCESS: typeof UPDATE_CONFIGURATION_SUCCESS;
declare const configuratorGroup_actions_d_UPDATE_PRICE_SUMMARY: typeof UPDATE_PRICE_SUMMARY;
declare const configuratorGroup_actions_d_UPDATE_PRICE_SUMMARY_FAIL: typeof UPDATE_PRICE_SUMMARY_FAIL;
declare const configuratorGroup_actions_d_UPDATE_PRICE_SUMMARY_SUCCESS: typeof UPDATE_PRICE_SUMMARY_SUCCESS;
type configuratorGroup_actions_d_UpdateCartEntry = UpdateCartEntry;
declare const configuratorGroup_actions_d_UpdateCartEntry: typeof UpdateCartEntry;
type configuratorGroup_actions_d_UpdateConfiguration = UpdateConfiguration;
declare const configuratorGroup_actions_d_UpdateConfiguration: typeof UpdateConfiguration;
type configuratorGroup_actions_d_UpdateConfigurationFail = UpdateConfigurationFail;
declare const configuratorGroup_actions_d_UpdateConfigurationFail: typeof UpdateConfigurationFail;
type configuratorGroup_actions_d_UpdateConfigurationFinalizeFail = UpdateConfigurationFinalizeFail;
declare const configuratorGroup_actions_d_UpdateConfigurationFinalizeFail: typeof UpdateConfigurationFinalizeFail;
type configuratorGroup_actions_d_UpdateConfigurationFinalizeSuccess = UpdateConfigurationFinalizeSuccess;
declare const configuratorGroup_actions_d_UpdateConfigurationFinalizeSuccess: typeof UpdateConfigurationFinalizeSuccess;
type configuratorGroup_actions_d_UpdateConfigurationOverview = UpdateConfigurationOverview;
declare const configuratorGroup_actions_d_UpdateConfigurationOverview: typeof UpdateConfigurationOverview;
type configuratorGroup_actions_d_UpdateConfigurationOverviewFail = UpdateConfigurationOverviewFail;
declare const configuratorGroup_actions_d_UpdateConfigurationOverviewFail: typeof UpdateConfigurationOverviewFail;
type configuratorGroup_actions_d_UpdateConfigurationOverviewSuccess = UpdateConfigurationOverviewSuccess;
declare const configuratorGroup_actions_d_UpdateConfigurationOverviewSuccess: typeof UpdateConfigurationOverviewSuccess;
type configuratorGroup_actions_d_UpdateConfigurationSuccess = UpdateConfigurationSuccess;
declare const configuratorGroup_actions_d_UpdateConfigurationSuccess: typeof UpdateConfigurationSuccess;
type configuratorGroup_actions_d_UpdatePriceSummary = UpdatePriceSummary;
declare const configuratorGroup_actions_d_UpdatePriceSummary: typeof UpdatePriceSummary;
type configuratorGroup_actions_d_UpdatePriceSummaryFail = UpdatePriceSummaryFail;
declare const configuratorGroup_actions_d_UpdatePriceSummaryFail: typeof UpdatePriceSummaryFail;
type configuratorGroup_actions_d_UpdatePriceSummarySuccess = UpdatePriceSummarySuccess;
declare const configuratorGroup_actions_d_UpdatePriceSummarySuccess: typeof UpdatePriceSummarySuccess;
declare namespace configuratorGroup_actions_d {
  export { configuratorGroup_actions_d_ADD_NEXT_OWNER as ADD_NEXT_OWNER, configuratorGroup_actions_d_ADD_TO_CART as ADD_TO_CART, configuratorGroup_actions_d_AddNextOwner as AddNextOwner, configuratorGroup_actions_d_AddToCart as AddToCart, configuratorGroup_actions_d_CHANGE_GROUP as CHANGE_GROUP, configuratorGroup_actions_d_CHANGE_GROUP_FINALIZE as CHANGE_GROUP_FINALIZE, configuratorGroup_actions_d_CHECK_CONFLICT_DIALOG as CHECK_CONFLICT_DIALOG, configuratorGroup_actions_d_CREATE_CONFIGURATION as CREATE_CONFIGURATION, configuratorGroup_actions_d_CREATE_CONFIGURATION_FAIL as CREATE_CONFIGURATION_FAIL, configuratorGroup_actions_d_CREATE_CONFIGURATION_SUCCESS as CREATE_CONFIGURATION_SUCCESS, configuratorGroup_actions_d_ChangeGroup as ChangeGroup, configuratorGroup_actions_d_ChangeGroupFinalize as ChangeGroupFinalize, configuratorGroup_actions_d_CheckConflictDialoge as CheckConflictDialoge, configuratorGroup_actions_d_CreateConfiguration as CreateConfiguration, configuratorGroup_actions_d_CreateConfigurationFail as CreateConfigurationFail, configuratorGroup_actions_d_CreateConfigurationSuccess as CreateConfigurationSuccess, configuratorGroup_actions_d_DISMISS_CONFLICT_DIALOG as DISMISS_CONFLICT_DIALOG, configuratorGroup_actions_d_DissmissConflictDialoge as DissmissConflictDialoge, configuratorGroup_actions_d_GET_CONFIGURATION_OVERVIEW as GET_CONFIGURATION_OVERVIEW, configuratorGroup_actions_d_GET_CONFIGURATION_OVERVIEW_FAIL as GET_CONFIGURATION_OVERVIEW_FAIL, configuratorGroup_actions_d_GET_CONFIGURATION_OVERVIEW_SUCCESS as GET_CONFIGURATION_OVERVIEW_SUCCESS, configuratorGroup_actions_d_GetConfigurationOverview as GetConfigurationOverview, configuratorGroup_actions_d_GetConfigurationOverviewFail as GetConfigurationOverviewFail, configuratorGroup_actions_d_GetConfigurationOverviewSuccess as GetConfigurationOverviewSuccess, configuratorGroup_actions_d_READ_ATTRIBUTE_DOMAIN as READ_ATTRIBUTE_DOMAIN, configuratorGroup_actions_d_READ_CART_ENTRY_CONFIGURATION as READ_CART_ENTRY_CONFIGURATION, configuratorGroup_actions_d_READ_CART_ENTRY_CONFIGURATION_FAIL as READ_CART_ENTRY_CONFIGURATION_FAIL, configuratorGroup_actions_d_READ_CART_ENTRY_CONFIGURATION_SUCCESS as READ_CART_ENTRY_CONFIGURATION_SUCCESS, configuratorGroup_actions_d_READ_CONFIGURATION as READ_CONFIGURATION, configuratorGroup_actions_d_READ_CONFIGURATION_FAIL as READ_CONFIGURATION_FAIL, configuratorGroup_actions_d_READ_CONFIGURATION_SUCCESS as READ_CONFIGURATION_SUCCESS, configuratorGroup_actions_d_READ_ORDER_ENTRY_CONFIGURATION as READ_ORDER_ENTRY_CONFIGURATION, configuratorGroup_actions_d_READ_ORDER_ENTRY_CONFIGURATION_FAIL as READ_ORDER_ENTRY_CONFIGURATION_FAIL, configuratorGroup_actions_d_READ_ORDER_ENTRY_CONFIGURATION_SUCCESS as READ_ORDER_ENTRY_CONFIGURATION_SUCCESS, configuratorGroup_actions_d_REMOVE_CART_BOUND_CONFIGURATIONS as REMOVE_CART_BOUND_CONFIGURATIONS, configuratorGroup_actions_d_REMOVE_CONFIGURATION as REMOVE_CONFIGURATION, configuratorGroup_actions_d_REMOVE_PRODUCT_BOUND_CONFIGURATIONS as REMOVE_PRODUCT_BOUND_CONFIGURATIONS, configuratorGroup_actions_d_ReadAttributeDomain as ReadAttributeDomain, configuratorGroup_actions_d_ReadCartEntryConfiguration as ReadCartEntryConfiguration, configuratorGroup_actions_d_ReadCartEntryConfigurationFail as ReadCartEntryConfigurationFail, configuratorGroup_actions_d_ReadCartEntryConfigurationSuccess as ReadCartEntryConfigurationSuccess, configuratorGroup_actions_d_ReadConfiguration as ReadConfiguration, configuratorGroup_actions_d_ReadConfigurationFail as ReadConfigurationFail, configuratorGroup_actions_d_ReadConfigurationSuccess as ReadConfigurationSuccess, configuratorGroup_actions_d_ReadOrderEntryConfiguration as ReadOrderEntryConfiguration, configuratorGroup_actions_d_ReadOrderEntryConfigurationFail as ReadOrderEntryConfigurationFail, configuratorGroup_actions_d_ReadOrderEntryConfigurationSuccess as ReadOrderEntryConfigurationSuccess, configuratorGroup_actions_d_RemoveCartBoundConfigurations as RemoveCartBoundConfigurations, configuratorGroup_actions_d_RemoveConfiguration as RemoveConfiguration, configuratorGroup_actions_d_RemoveProductBoundConfigurations as RemoveProductBoundConfigurations, configuratorGroup_actions_d_SEARCH_VARIANTS as SEARCH_VARIANTS, configuratorGroup_actions_d_SEARCH_VARIANTS_FAIL as SEARCH_VARIANTS_FAIL, configuratorGroup_actions_d_SEARCH_VARIANTS_SUCCESS as SEARCH_VARIANTS_SUCCESS, configuratorGroup_actions_d_SET_CURRENT_GROUP as SET_CURRENT_GROUP, configuratorGroup_actions_d_SET_GROUPS_VISITED as SET_GROUPS_VISITED, configuratorGroup_actions_d_SET_INTERACTION_STATE as SET_INTERACTION_STATE, configuratorGroup_actions_d_SET_MENU_PARENT_GROUP as SET_MENU_PARENT_GROUP, configuratorGroup_actions_d_SET_NEXT_OWNER_CART_ENTRY as SET_NEXT_OWNER_CART_ENTRY, configuratorGroup_actions_d_SearchVariants as SearchVariants, configuratorGroup_actions_d_SearchVariantsFail as SearchVariantsFail, configuratorGroup_actions_d_SearchVariantsSuccess as SearchVariantsSuccess, configuratorGroup_actions_d_SetCurrentGroup as SetCurrentGroup, configuratorGroup_actions_d_SetGroupsVisited as SetGroupsVisited, configuratorGroup_actions_d_SetInteractionState as SetInteractionState, configuratorGroup_actions_d_SetMenuParentGroup as SetMenuParentGroup, configuratorGroup_actions_d_SetNextOwnerCartEntry as SetNextOwnerCartEntry, configuratorGroup_actions_d_UPDATE_CART_ENTRY as UPDATE_CART_ENTRY, configuratorGroup_actions_d_UPDATE_CART_ENTRY_SUCCESS as UPDATE_CART_ENTRY_SUCCESS, configuratorGroup_actions_d_UPDATE_CONFIGURATION as UPDATE_CONFIGURATION, configuratorGroup_actions_d_UPDATE_CONFIGURATION_FAIL as UPDATE_CONFIGURATION_FAIL, configuratorGroup_actions_d_UPDATE_CONFIGURATION_FINALIZE_FAIL as UPDATE_CONFIGURATION_FINALIZE_FAIL, configuratorGroup_actions_d_UPDATE_CONFIGURATION_FINALIZE_SUCCESS as UPDATE_CONFIGURATION_FINALIZE_SUCCESS, configuratorGroup_actions_d_UPDATE_CONFIGURATION_OVERVIEW as UPDATE_CONFIGURATION_OVERVIEW, configuratorGroup_actions_d_UPDATE_CONFIGURATION_OVERVIEW_FAIL as UPDATE_CONFIGURATION_OVERVIEW_FAIL, configuratorGroup_actions_d_UPDATE_CONFIGURATION_OVERVIEW_SUCCESS as UPDATE_CONFIGURATION_OVERVIEW_SUCCESS, configuratorGroup_actions_d_UPDATE_CONFIGURATION_SUCCESS as UPDATE_CONFIGURATION_SUCCESS, configuratorGroup_actions_d_UPDATE_PRICE_SUMMARY as UPDATE_PRICE_SUMMARY, configuratorGroup_actions_d_UPDATE_PRICE_SUMMARY_FAIL as UPDATE_PRICE_SUMMARY_FAIL, configuratorGroup_actions_d_UPDATE_PRICE_SUMMARY_SUCCESS as UPDATE_PRICE_SUMMARY_SUCCESS, configuratorGroup_actions_d_UpdateCartEntry as UpdateCartEntry, configuratorGroup_actions_d_UpdateConfiguration as UpdateConfiguration, configuratorGroup_actions_d_UpdateConfigurationFail as UpdateConfigurationFail, configuratorGroup_actions_d_UpdateConfigurationFinalizeFail as UpdateConfigurationFinalizeFail, configuratorGroup_actions_d_UpdateConfigurationFinalizeSuccess as UpdateConfigurationFinalizeSuccess, configuratorGroup_actions_d_UpdateConfigurationOverview as UpdateConfigurationOverview, configuratorGroup_actions_d_UpdateConfigurationOverviewFail as UpdateConfigurationOverviewFail, configuratorGroup_actions_d_UpdateConfigurationOverviewSuccess as UpdateConfigurationOverviewSuccess, configuratorGroup_actions_d_UpdateConfigurationSuccess as UpdateConfigurationSuccess, configuratorGroup_actions_d_UpdatePriceSummary as UpdatePriceSummary, configuratorGroup_actions_d_UpdatePriceSummaryFail as UpdatePriceSummaryFail, configuratorGroup_actions_d_UpdatePriceSummarySuccess as UpdatePriceSummarySuccess };
  export type { configuratorGroup_actions_d_ConfiguratorAction as ConfiguratorAction, configuratorGroup_actions_d_ConfiguratorCartAction as ConfiguratorCartAction, configuratorGroup_actions_d_ConfiguratorVariantAction as ConfiguratorVariantAction };
}

/**
 * Service that provides helper methods for the basic configurator effects,
 * in order to enhance them without the need to introduce new effects
 */
declare class ConfiguratorBasicEffectService {
    /**
     * Finds first attribute group with attributes for a configuration (ignores conflict groups per default).
     * If optional parameter 'includeConflicts' is set to true it finds first group with attributes including conflict groups.
     * Throws error if such a group does not exist, as this is an illegal state
     * @param configuration
     * @param includeConflicts (optional) if true it includes also conflict groups in the search
     * @returns Group id
     *
     */
    getFirstGroupWithAttributes(configuration: Configurator.Configuration, includeConflicts?: boolean): string;
    /**
     * Finds first group with attributes in a list of groups. Dependent on 'includeConflicts' parameters it includes conflict groups in the search or it ignores them.
     * @param groups
     * @param includeConflicts set to true in order to include conflict groups in the seach
     * @returns Group id
     */
    protected getFirstGroupWithAttributesForList(groups: Configurator.Group[], includeConflicts: boolean): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfiguratorBasicEffectService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfiguratorBasicEffectService>;
}

declare const getConfigurationsState: MemoizedSelector<StateWithConfigurator, ConfiguratorState>;
declare const getConfigurationState: MemoizedSelector<StateWithConfigurator, StateUtils.EntityLoaderState<Configurator.Configuration>>;
declare const getConfigurationProcessLoaderStateFactory: (code: string) => MemoizedSelector<StateWithConfigurator, StateUtils.ProcessesLoaderState<Configurator.Configuration>>;
declare const hasPendingChanges: (code: string) => MemoizedSelector<StateWithConfigurator, boolean>;
declare const getConfigurationFactory: (code: string) => MemoizedSelector<StateWithConfigurator, Configurator.Configuration>;
declare const getCurrentGroup: (ownerKey: string) => MemoizedSelector<StateWithConfigurator, string | undefined>;
declare const isGroupVisited: (ownerKey: string, groupId: string) => MemoizedSelector<StateWithConfigurator, boolean>;
declare const areGroupsVisited: (ownerKey: string, groupIds: string[]) => MemoizedSelector<StateWithConfigurator, boolean>;

declare const configuratorGroup_selectors_d_areGroupsVisited: typeof areGroupsVisited;
declare const configuratorGroup_selectors_d_getConfigurationFactory: typeof getConfigurationFactory;
declare const configuratorGroup_selectors_d_getConfigurationProcessLoaderStateFactory: typeof getConfigurationProcessLoaderStateFactory;
declare const configuratorGroup_selectors_d_getConfigurationState: typeof getConfigurationState;
declare const configuratorGroup_selectors_d_getConfigurationsState: typeof getConfigurationsState;
declare const configuratorGroup_selectors_d_getCurrentGroup: typeof getCurrentGroup;
declare const configuratorGroup_selectors_d_hasPendingChanges: typeof hasPendingChanges;
declare const configuratorGroup_selectors_d_isGroupVisited: typeof isGroupVisited;
declare namespace configuratorGroup_selectors_d {
  export {
    configuratorGroup_selectors_d_areGroupsVisited as areGroupsVisited,
    configuratorGroup_selectors_d_getConfigurationFactory as getConfigurationFactory,
    configuratorGroup_selectors_d_getConfigurationProcessLoaderStateFactory as getConfigurationProcessLoaderStateFactory,
    configuratorGroup_selectors_d_getConfigurationState as getConfigurationState,
    configuratorGroup_selectors_d_getConfigurationsState as getConfigurationsState,
    configuratorGroup_selectors_d_getCurrentGroup as getCurrentGroup,
    configuratorGroup_selectors_d_hasPendingChanges as hasPendingChanges,
    configuratorGroup_selectors_d_isGroupVisited as isGroupVisited,
  };
}

declare module '@spartacus/core' {
    interface OccEndpoints {
        /**
         * Endpoint for reading a variant configuration attached to a given quote entry
         */
        readVariantConfigurationOverviewForQuoteEntry?: string | OccEndpoint;
        /**
         * Endpoint for reading a variant configuration attached to a given saved cart entry
         */
        readVariantConfigurationOverviewForSavedCartEntry?: string | OccEndpoint;
    }
}

declare namespace OccConfigurator {
    /**
     *
     * An interface representing the variant configuration consumed through OCC.
     */
    interface Configuration {
        /**
         * @member {string} [configId]
         */
        configId: string;
        /**
         * @member {boolean} [complete]
         */
        complete?: boolean;
        /**
         * Configuration is consistent, meaning it does not contain conflicts
         *
         * @member {boolean}
         */
        consistent?: boolean;
        totalNumberOfIssues?: number;
        groups?: Group[];
        rootProduct: string;
        kbKey?: KB;
        pricingEnabled?: boolean;
        hideBasePriceAndSelectedOptions?: boolean;
        immediateConflictResolution?: boolean;
        newConfiguration?: boolean;
    }
    interface KB {
        kbName?: string;
        kbLogsys?: string;
        kbVersion?: string;
        kbBuildNumber?: string;
    }
    interface Prices {
        configId: string;
        attributes?: Supplements[];
        pricingError?: boolean;
        showDeltaPrices?: boolean;
        priceSummary?: PriceSummary;
    }
    interface Supplements {
        csticUiKey: string;
        selectedValues: string[];
        priceSupplements: ValueSupplements[];
    }
    interface ValueSupplements {
        attributeValueKey: string;
        priceValue: PriceDetails;
        obsoletePriceValue: PriceDetails;
    }
    interface PriceSummary {
        basePrice?: PriceDetails;
        currentTotal?: PriceDetails;
        currentTotalSavings?: PriceSavingDetails;
        selectedOptions?: PriceDetails;
    }
    interface PriceDetails {
        currencyIso: string;
        formattedValue?: string;
        value: number;
    }
    interface PriceSavingDetails extends PriceDetails {
        maxQuantity?: number;
        minQuantity?: number;
    }
    interface Group {
        configurable?: boolean;
        complete?: boolean;
        consistent?: boolean;
        attributes?: Attribute[];
        description?: string;
        groupType: GroupType;
        id: string;
        name?: string;
        subGroups?: Group[];
    }
    interface Attribute {
        name: string;
        langDepName?: string;
        longText?: string;
        type?: UiType;
        domainValues?: Value[];
        required?: boolean;
        value?: string;
        key: string;
        formattedValue?: string;
        maxlength?: number;
        images?: Image[];
        typeLength?: number;
        numberScale?: number;
        negativeAllowed?: boolean;
        conflicts?: string[];
        retractTriggered?: boolean;
        intervalInDomain?: boolean;
        retractBlocked?: boolean;
        validationType?: string;
        visible?: boolean;
        domainOnDemand?: boolean;
    }
    interface Value {
        key: string;
        name?: string;
        langDepName?: string;
        longText?: string;
        readonly?: boolean;
        selected?: boolean;
        images?: Image[];
    }
    interface AddToCartParameters {
        userId?: string;
        cartId?: string;
        product?: AddToCartProductData;
        quantity?: number;
        configId?: string;
    }
    interface UpdateConfigurationForCartEntryParameters {
        userId?: string;
        cartId?: string;
        product?: AddToCartProductData;
        quantity?: number;
        configId: string;
        entryNumber: string;
        configurationInfos: ConfigurationInfo[];
    }
    interface ConfigurationInfo {
        configuratorType: string;
    }
    interface AddToCartProductData {
        code?: string;
    }
    interface Overview {
        id: string;
        totalNumberOfIssues?: number;
        numberOfIncompleteCharacteristics?: number;
        numberOfConflicts?: number;
        groups?: GroupOverview[];
        pricing?: PriceSummary;
        productCode: string;
        appliedCsticFilter?: OverviewFilter[];
        groupFilterList?: OverviewFilter[];
    }
    interface OverviewFilter {
        key: string;
        selected?: boolean;
    }
    interface GroupOverview {
        id: string;
        groupDescription?: string;
        characteristicValues?: CharacteristicOverview[];
        subGroups?: GroupOverview[];
    }
    interface CharacteristicOverview {
        characteristic: string;
        characteristicId?: string;
        value: string;
        valueId?: string;
        price?: PriceDetails;
    }
    interface Image {
        imageType: ImageType;
        format: ImageFormatType;
        url?: string;
        altText?: string;
        galleryIndex?: number;
    }
    enum GroupType {
        CSTIC_GROUP = "CSTIC_GROUP",
        INSTANCE = "INSTANCE",
        CONFLICT_HEADER = "CONFLICT_HEADER",
        CONFLICT = "CONFLICT"
    }
    enum UiType {
        STRING = "STRING",
        NUMERIC = "NUMERIC",
        SAP_DATE = "SAP_DATE",
        CHECK_BOX = "CHECK_BOX",
        CHECK_BOX_LIST = "CHECK_BOX_LIST",
        RADIO_BUTTON = "RADIO_BUTTON",
        RADIO_BUTTON_ADDITIONAL_INPUT = "RADIO_BUTTON_ADDITIONAL_INPUT",
        DROPDOWN = "DROPDOWN",
        DROPDOWN_ADDITIONAL_INPUT = "DROPDOWN_ADDITIONAL_INPUT",
        READ_ONLY = "READ_ONLY",
        READ_ONLY_SINGLE_SELECTION_IMAGE = "READ_ONLY_SINGLE_SELECTION_IMAGE",
        READ_ONLY_MULTI_SELECTION_IMAGE = "READ_ONLY_MULTI_SELECTION_IMAGE",
        NOT_IMPLEMENTED = "NOT_IMPLEMENTED",
        SINGLE_SELECTION_IMAGE = "SINGLE_SELECTION_IMAGE",
        MULTI_SELECTION_IMAGE = "MULTI_SELECTION_IMAGE"
    }
    enum PriceType {
        BUY = "BUY"
    }
    enum ImageFormatType {
        VALUE_IMAGE = "VALUE_IMAGE",
        CSTIC_IMAGE = "CSTIC_IMAGE"
    }
    enum ImageType {
        PRIMARY = "PRIMARY",
        GALLERY = "GALLERY"
    }
    enum OverviewFilterEnum {
        VISIBLE = "PRIMARY",
        USER_INPUT = "USER_INPUT",
        PRICE_RELEVANT = "PRICE_RELEVANT"
    }
}

declare class OccConfiguratorVariantAddToCartSerializer implements Converter<Configurator.AddToCartParameters, OccConfigurator.AddToCartParameters> {
    constructor();
    convert(source: Configurator.AddToCartParameters, target?: OccConfigurator.AddToCartParameters): OccConfigurator.AddToCartParameters;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccConfiguratorVariantAddToCartSerializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccConfiguratorVariantAddToCartSerializer>;
}

declare class OccConfiguratorVariantNormalizer implements Converter<OccConfigurator.Configuration, Configurator.Configuration> {
    protected config: OccConfig;
    protected translation: TranslationService;
    protected uiSettingsConfig: ConfiguratorUISettingsConfig;
    constructor(config: OccConfig, translation: TranslationService, uiSettingsConfig: ConfiguratorUISettingsConfig);
    convert(source: OccConfigurator.Configuration, target?: Configurator.Configuration): Configurator.Configuration;
    convertGroup(source: OccConfigurator.Group, groupList: Configurator.Group[], flatGroupList: Configurator.Group[]): void;
    getGroupId(key: string, name: string): string;
    convertAttribute(sourceAttribute: OccConfigurator.Attribute, attributeList: Configurator.Attribute[]): void;
    protected compileUserInput(sourceAttribute: OccConfigurator.Attribute): string | undefined;
    setSelectedSingleValue(attribute: Configurator.Attribute): void;
    protected isRetractValueSelected(sourceAttribute: OccConfigurator.Attribute): boolean;
    protected setRetractValueDisplay(attributeType: Configurator.UiType, value: Configurator.Value): void;
    protected hasSourceAttributeConflicts(sourceAttribute: OccConfigurator.Attribute): boolean;
    protected isSourceAttributeTypeReadOnly(sourceAttribute: OccConfigurator.Attribute): boolean;
    protected isRetractBlocked(sourceAttribute: OccConfigurator.Attribute): boolean;
    protected addRetractValue(sourceAttribute: OccConfigurator.Attribute, values: Configurator.Value[]): void;
    convertValue(occValue: OccConfigurator.Value, values: Configurator.Value[]): void;
    convertImage(occImage: OccConfigurator.Image, images: Configurator.Image[]): void;
    protected getSingleSelectionUiType(coreSourceType: string, uiType: Configurator.UiType): Configurator.UiType;
    protected getMultiSelectionUiType(coreSourceType: string, uiType: Configurator.UiType): Configurator.UiType;
    protected getReadOnlyUiType(sourceAttribute: OccConfigurator.Attribute, coreSourceType: string, uiType: Configurator.UiType): Configurator.UiType;
    protected getInputUiType(coreSourceType: string, uiType: Configurator.UiType): Configurator.UiType;
    convertAttributeType(sourceAttribute: OccConfigurator.Attribute): Configurator.UiType;
    protected determineCoreUiType(sourceType: string): string;
    convertGroupType(groupType: OccConfigurator.GroupType): Configurator.GroupType;
    setGroupDescription(group: Configurator.Group): void;
    convertImageType(imageType: OccConfigurator.ImageType): Configurator.ImageType;
    convertImageFormatType(formatType: OccConfigurator.ImageFormatType): Configurator.ImageFormatType;
    compileAttributeIncomplete(attribute: Configurator.Attribute): void;
    protected compileAttributeIncompleteSingleLevel(attribute: Configurator.Attribute): void;
    protected compileAttributeIncompleteInputTypes(attribute: Configurator.Attribute): void;
    protected compileAttributeIncompleteMultiSelect(attribute: Configurator.Attribute): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccConfiguratorVariantNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccConfiguratorVariantNormalizer>;
}

declare class OccConfiguratorVariantOverviewNormalizer implements Converter<OccConfigurator.Overview, Configurator.Overview> {
    protected translation: TranslationService;
    protected converterService: ConverterService;
    constructor(translation: TranslationService, converterService: ConverterService);
    convert(source: OccConfigurator.Overview, target?: Configurator.Overview): Configurator.Overview;
    convertGroup(source: OccConfigurator.GroupOverview): Configurator.GroupOverview[];
    setGeneralDescription(group: Configurator.GroupOverview): void;
    protected setIssueCounters(target: Configurator.Overview, source: OccConfigurator.Overview): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccConfiguratorVariantOverviewNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccConfiguratorVariantOverviewNormalizer>;
}

declare class OccConfiguratorVariantOverviewSerializer implements Converter<Configurator.Overview, OccConfigurator.Overview> {
    protected converterService: ConverterService;
    constructor(converterService: ConverterService);
    convert(source: Configurator.Overview, target?: OccConfigurator.Overview): OccConfigurator.Overview;
    protected convertAttributeFilters(attributeFilters?: Configurator.OverviewFilter[]): OccConfigurator.OverviewFilter[];
    protected convertGroupFilters(groupFilters?: string[]): OccConfigurator.OverviewFilter[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OccConfiguratorVariantOverviewSerializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccConfiguratorVariantOverviewSerializer>;
}

declare class OccConfiguratorVariantPriceSummaryNormalizer implements Converter<OccConfigurator.Prices, Configurator.PriceSummary> {
    convert(source: OccConfigurator.Prices, target?: Configurator.PriceSummary): Configurator.PriceSummary;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccConfiguratorVariantPriceSummaryNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccConfiguratorVariantPriceSummaryNormalizer>;
}

declare class OccConfiguratorVariantSerializer implements Converter<Configurator.Configuration, OccConfigurator.Configuration> {
    convert(source: Configurator.Configuration, target?: OccConfigurator.Configuration): OccConfigurator.Configuration;
    convertGroup(source: Configurator.Group, occGroups: OccConfigurator.Group[]): void;
    protected isRetractValue(attribute: Configurator.Attribute): boolean;
    protected getRetractedValue(attribute: Configurator.Attribute): string | undefined;
    protected retractValue(attribute: Configurator.Attribute, targetAttribute: OccConfigurator.Attribute): void;
    convertAttribute(attribute: Configurator.Attribute, occAttributes: OccConfigurator.Attribute[]): void;
    convertValue(value: Configurator.Value, values: OccConfigurator.Value[]): void;
    convertCharacteristicType(type: Configurator.UiType): OccConfigurator.UiType;
    protected convertCharacteristicTypeSingleValue(type: Configurator.UiType): OccConfigurator.UiType;
    protected convertCharacteristicTypeMultiValueAndInput(type: Configurator.UiType): OccConfigurator.UiType;
    convertGroupType(groupType: Configurator.GroupType): OccConfigurator.GroupType;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccConfiguratorVariantSerializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccConfiguratorVariantSerializer>;
}

declare class OccConfiguratorVariantUpdateCartEntrySerializer implements Converter<Configurator.UpdateConfigurationForCartEntryParameters, OccConfigurator.UpdateConfigurationForCartEntryParameters> {
    convert(source: Configurator.UpdateConfigurationForCartEntryParameters, target?: OccConfigurator.UpdateConfigurationForCartEntryParameters): OccConfigurator.UpdateConfigurationForCartEntryParameters;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccConfiguratorVariantUpdateCartEntrySerializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccConfiguratorVariantUpdateCartEntrySerializer>;
}

declare class VariantConfiguratorOccAdapter implements RulebasedConfiguratorAdapter {
    protected http: HttpClient;
    protected occEndpointsService: OccEndpointsService;
    protected converterService: ConverterService;
    protected configExpertModeService: ConfiguratorExpertModeService;
    constructor(http: HttpClient, occEndpointsService: OccEndpointsService, converterService: ConverterService, configExpertModeService: ConfiguratorExpertModeService);
    getConfiguratorType(): string;
    protected getExpModeRequested(): boolean;
    protected setExpModeActive(expMode: boolean): void;
    createConfiguration(owner: CommonConfigurator.Owner, configIdTemplate?: string, forceReset?: boolean): Observable<Configurator.Configuration>;
    readConfiguration(configId: string, groupId: string, configurationOwner: CommonConfigurator.Owner, attributeKey?: string): Observable<Configurator.Configuration>;
    updateConfiguration(configuration: Configurator.Configuration): Observable<Configurator.Configuration>;
    addToCart(parameters: Configurator.AddToCartParameters): Observable<CartModification>;
    readConfigurationForCartEntry(parameters: CommonConfigurator.ReadConfigurationFromCartEntryParameters): Observable<Configurator.Configuration>;
    updateConfigurationForCartEntry(parameters: Configurator.UpdateConfigurationForCartEntryParameters): Observable<CartModification>;
    readConfigurationForOrderEntry(parameters: CommonConfigurator.ReadConfigurationFromOrderEntryParameters): Observable<Configurator.Configuration>;
    readPriceSummary(configuration: Configurator.Configuration): Observable<Configurator.Configuration>;
    getConfigurationOverview(configId: string): Observable<Configurator.Overview>;
    updateConfigurationOverview(ovInput: Configurator.Overview): Observable<Configurator.Overview>;
    searchVariants(configId: string): Observable<Configurator.Variant[]>;
    /**
     * Prepares http context indicating that emulated user has to be added to the request in ASM mode
     *
     * The actual calls to the commerce backend will only be changed if the ASM setting
     * userIdHttpHeader:{
     *  enable:true
     * },
     * is active
     * @returns http context indicating that emulated user has to be added to the request in ASM mode
     */
    protected indicateSendUserForAsm(): HttpContext;
    static ɵfac: i0.ɵɵFactoryDeclaration<VariantConfiguratorOccAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VariantConfiguratorOccAdapter>;
}

declare const VARIANT_CONFIGURATOR_NORMALIZER: InjectionToken<Converter<OccConfigurator.Configuration, Configurator.Configuration>>;
declare const VARIANT_CONFIGURATOR_SERIALIZER: InjectionToken<Converter<Configurator.Configuration, OccConfigurator.Configuration>>;
declare const VARIANT_CONFIGURATOR_PRICE_SUMMARY_NORMALIZER: InjectionToken<Converter<OccConfigurator.PriceSummary, Configurator.PriceSummary>>;
declare const VARIANT_CONFIGURATOR_PRICE_NORMALIZER: InjectionToken<Converter<OccConfigurator.PriceSummary, Configurator.Configuration>>;
declare const VARIANT_CONFIGURATOR_ADD_TO_CART_SERIALIZER: InjectionToken<Converter<Configurator.AddToCartParameters, OccConfigurator.AddToCartParameters>>;
declare const VARIANT_CONFIGURATOR_UPDATE_CART_ENTRY_SERIALIZER: InjectionToken<Converter<Configurator.UpdateConfigurationForCartEntryParameters, OccConfigurator.UpdateConfigurationForCartEntryParameters>>;
declare const VARIANT_CONFIGURATOR_OVERVIEW_NORMALIZER: InjectionToken<Converter<OccConfigurator.Overview, Configurator.Overview>>;
declare const VARIANT_CONFIGURATOR_OVERVIEW_SERIALIZER: InjectionToken<Converter<Configurator.Overview, OccConfigurator.Overview>>;

declare class VariantConfiguratorOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VariantConfiguratorOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VariantConfiguratorOccModule, never, [typeof i1.CommonModule, typeof i2.ConfigModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VariantConfiguratorOccModule>;
}

declare class RulebasedConfiguratorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RulebasedConfiguratorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RulebasedConfiguratorModule, never, [typeof VariantConfiguratorOccModule, typeof RulebasedConfiguratorCoreModule, typeof RulebasedConfiguratorComponentsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RulebasedConfiguratorModule>;
}

export { CONFIGURATOR_DATA, CONFIGURATOR_FEATURE, ConfigFormUpdateEvent, Configurator, configuratorGroup_actions_d as ConfiguratorActions, ConfiguratorAddToCartButtonComponent, ConfiguratorAddToCartButtonModule, ConfiguratorAttributeBaseComponent, ConfiguratorAttributeCheckBoxComponent, ConfiguratorAttributeCheckBoxListComponent, ConfiguratorAttributeCheckboxListModule, ConfiguratorAttributeCheckboxModule, ConfiguratorAttributeCompositionConfig, ConfiguratorAttributeCompositionContext, ConfiguratorAttributeCompositionDirective, ConfiguratorAttributeCompositionModule, ConfiguratorAttributeDropDownComponent, ConfiguratorAttributeDropDownModule, ConfiguratorAttributeFooterComponent, ConfiguratorAttributeFooterModule, ConfiguratorAttributeHeaderComponent, ConfiguratorAttributeHeaderModule, ConfiguratorAttributeInputFieldComponent, ConfiguratorAttributeInputFieldModule, ConfiguratorAttributeMultiSelectionBaseComponent, ConfiguratorAttributeMultiSelectionBundleComponent, ConfiguratorAttributeMultiSelectionBundleModule, ConfiguratorAttributeMultiSelectionImageComponent, ConfiguratorAttributeMultiSelectionImageModule, ConfiguratorAttributeNotSupportedComponent, ConfiguratorAttributeNotSupportedModule, ConfiguratorAttributeNumericInputFieldComponent, ConfiguratorAttributeNumericInputFieldModule, ConfiguratorAttributeNumericInputFieldService, ConfiguratorAttributePriceChangeService, ConfiguratorAttributeProductCardComponent, ConfiguratorAttributeProductCardModule, ConfiguratorAttributeQuantityComponent, ConfiguratorAttributeQuantityModule, ConfiguratorAttributeQuantityService, ConfiguratorAttributeRadioButtonComponent, ConfiguratorAttributeRadioButtonModule, ConfiguratorAttributeReadOnlyComponent, ConfiguratorAttributeReadOnlyModule, ConfiguratorAttributeSingleSelectionBaseComponent, ConfiguratorAttributeSingleSelectionBundleComponent, ConfiguratorAttributeSingleSelectionBundleDropdownComponent, ConfiguratorAttributeSingleSelectionBundleDropdownModule, ConfiguratorAttributeSingleSelectionBundleModule, ConfiguratorAttributeSingleSelectionImageComponent, ConfiguratorAttributeSingleSelectionImageModule, ConfiguratorBasicEffectService, ConfiguratorCartService, ConfiguratorCommonsService, ConfiguratorConflictAndErrorMessagesComponent, ConfiguratorConflictAndErrorMessagesModule, ConfiguratorConflictDescriptionComponent, ConfiguratorConflictDescriptionModule, ConfiguratorConflictSolverDialogComponent, ConfiguratorConflictSolverDialogLauncherService, ConfiguratorConflictSolverDialogModule, ConfiguratorConflictSuggestionComponent, ConfiguratorConflictSuggestionModule, ConfiguratorCoreConfig, ConfiguratorExitButtonComponent, ConfiguratorExitButtonModule, ConfiguratorExpertModeService, ConfiguratorFormComponent, ConfiguratorFormModule, ConfiguratorGroupComponent, ConfiguratorGroupMenuComponent, ConfiguratorGroupMenuModule, ConfiguratorGroupModule, ConfiguratorGroupStatusService, ConfiguratorGroupTitleComponent, ConfiguratorGroupTitleModule, ConfiguratorGroupsService, ConfiguratorLanguageSetEventListener, ConfiguratorLogoutEventListener, ConfiguratorMessageConfig, ConfiguratorOverviewAttributeComponent, ConfiguratorOverviewAttributeModule, ConfiguratorOverviewBundleAttributeComponent, ConfiguratorOverviewBundleAttributeModule, ConfiguratorOverviewFilterBarComponent, ConfiguratorOverviewFilterBarModule, ConfiguratorOverviewFilterButtonComponent, ConfiguratorOverviewFilterButtonModule, ConfiguratorOverviewFilterComponent, ConfiguratorOverviewFilterDialogComponent, ConfiguratorOverviewFilterDialogModule, ConfiguratorOverviewFilterModule, ConfiguratorOverviewFormComponent, ConfiguratorOverviewFormModule, ConfiguratorOverviewMenuComponent, ConfiguratorOverviewMenuModule, ConfiguratorOverviewNotificationBannerComponent, ConfiguratorOverviewNotificationBannerModule, ConfiguratorOverviewSidebarComponent, ConfiguratorOverviewSidebarModule, ConfiguratorPreviousNextButtonsComponent, ConfiguratorPreviousNextButtonsModule, ConfiguratorPriceComponent, ConfiguratorPriceModule, ConfiguratorPriceSummaryComponent, ConfiguratorPriceSummaryModule, ConfiguratorProductTitleComponent, ConfiguratorProductTitleModule, ConfiguratorQuantityService, ConfiguratorRestartDialogComponent, ConfiguratorRestartDialogModule, ConfiguratorRouterListener, ConfiguratorRouterModule, configuratorGroup_selectors_d as ConfiguratorSelectors, ConfiguratorShowMoreComponent, ConfiguratorShowMoreModule, ConfiguratorShowOptionsComponent, ConfiguratorShowOptionsModule, ConfiguratorStorefrontUtilsService, ConfiguratorTabBarComponent, ConfiguratorTabBarModule, ConfiguratorUISettingsConfig, ConfiguratorUpdateMessageComponent, ConfiguratorUpdateMessageModule, ConfiguratorUtilsService, ConfiguratorVariantCarouselComponent, ConfiguratorVariantCarouselModule, OccConfigurator, OccConfiguratorVariantAddToCartSerializer, OccConfiguratorVariantNormalizer, OccConfiguratorVariantOverviewNormalizer, OccConfiguratorVariantOverviewSerializer, OccConfiguratorVariantPriceSummaryNormalizer, OccConfiguratorVariantSerializer, OccConfiguratorVariantUpdateCartEntrySerializer, RulebasedConfiguratorAdapter, RulebasedConfiguratorComponentsModule, RulebasedConfiguratorConnector, RulebasedConfiguratorCoreModule, RulebasedConfiguratorModule, VARIANT_CONFIGURATOR_ADD_TO_CART_SERIALIZER, VARIANT_CONFIGURATOR_NORMALIZER, VARIANT_CONFIGURATOR_OVERVIEW_NORMALIZER, VARIANT_CONFIGURATOR_OVERVIEW_SERIALIZER, VARIANT_CONFIGURATOR_PRICE_NORMALIZER, VARIANT_CONFIGURATOR_PRICE_SUMMARY_NORMALIZER, VARIANT_CONFIGURATOR_SERIALIZER, VARIANT_CONFIGURATOR_UPDATE_CART_ENTRY_SERIALIZER, VariantConfiguratorOccAdapter, VariantConfiguratorOccModule };
export type { AttributeComponentAssignment, ConfiguratorAttributeComposition, ConfiguratorAttributeNumericInterval, ConfiguratorAttributeProductCardComponentOptions, ConfiguratorAttributeQuantityComponentOptions, ConfiguratorPriceComponentOptions, ConfiguratorState, QuantityUpdateEvent, StateWithConfigurator };
