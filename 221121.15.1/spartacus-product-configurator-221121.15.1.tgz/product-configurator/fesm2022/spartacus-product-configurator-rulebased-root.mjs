import * as i0 from '@angular/core';
import { Injectable, NgModule } from '@angular/core';
import * as i1$1 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i1$2 from '@spartacus/core';
import { provideDefaultConfig, HttpErrorHandler, HttpResponseStatus, Priority, GlobalMessageType, provideDefaultConfigFactory } from '@spartacus/core';
import * as i2 from '@spartacus/storefront';
import { BREAKPOINT, PAGE_LAYOUT_HANDLER, HamburgerMenuModule, CmsPageGuard, PageLayoutComponent } from '@spartacus/storefront';
import * as i1 from '@spartacus/product-configurator/common';
import { ConfiguratorRouter, CommonConfiguratorModule } from '@spartacus/product-configurator/common';
import { take, map, switchMap } from 'rxjs/operators';
import { CommonModule } from '@angular/common';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CpqConfiguratorPageLayoutHandler {
    static { this.templateName = 'CpqConfigurationTemplate'; }
    static { this.sectionHeaderDisplayOnly = 'headerDisplayOnly'; }
    static { this.sectionNavigationDisplayOnly = 'navigationDisplayOnly'; }
    static { this.sectionHeader = 'header'; }
    static { this.sectionNavigation = 'navigation'; }
    constructor(configuratorRouterExtractorService, breakpointService, layoutConfig, commonConfiguratorUtilsService) {
        this.configuratorRouterExtractorService = configuratorRouterExtractorService;
        this.breakpointService = breakpointService;
        this.layoutConfig = layoutConfig;
        this.commonConfiguratorUtilsService = commonConfiguratorUtilsService;
    }
    handle(slots$, pageTemplate, section) {
        if (pageTemplate === CpqConfiguratorPageLayoutHandler.templateName &&
            section === CpqConfiguratorPageLayoutHandler.sectionHeader) {
            this.compileRouterAndResolution()
                .pipe(take(1))
                .subscribe((cont) => {
                slots$ = slots$.pipe(map((slots) => this.getHeaderSlots(slots, cont)));
            });
        }
        else if (pageTemplate === CpqConfiguratorPageLayoutHandler.templateName &&
            section === CpqConfiguratorPageLayoutHandler.sectionNavigation) {
            this.compileRouterAndResolution()
                .pipe(take(1))
                .subscribe((cont) => {
                slots$ = slots$.pipe(map((slots) => this.getNavigationSlots(slots, cont)));
            });
        }
        return slots$;
    }
    compileRouterAndResolution() {
        return this.configuratorRouterExtractorService.extractRouterData().pipe(switchMap((routerData) => this.breakpointService.isUp(BREAKPOINT.lg).pipe(map((isLargeResolution) => ({
            isLargeResolution: isLargeResolution,
            routerData,
        })))));
    }
    getHeaderSlots(slots, cont) {
        if (cont.routerData.pageType === ConfiguratorRouter.PageType.CONFIGURATION) {
            const extendedSlots = ['PreHeader'];
            extendedSlots.push(...slots);
            return extendedSlots;
        }
        else if (cont.routerData.displayOnly) {
            if (cont.isLargeResolution) {
                return this.commonConfiguratorUtilsService.getSlotsFromLayoutConfiguration(this.layoutConfig, CpqConfiguratorPageLayoutHandler.templateName, CpqConfiguratorPageLayoutHandler.sectionHeaderDisplayOnly, BREAKPOINT.lg);
            }
            else {
                return this.commonConfiguratorUtilsService.getSlotsFromLayoutConfiguration(this.layoutConfig, CpqConfiguratorPageLayoutHandler.templateName, CpqConfiguratorPageLayoutHandler.sectionHeaderDisplayOnly, BREAKPOINT.xs);
            }
        }
        else {
            return slots;
        }
    }
    getNavigationSlots(slots, cont) {
        if (cont.routerData.pageType === ConfiguratorRouter.PageType.OVERVIEW &&
            cont.routerData.displayOnly) {
            if (cont.isLargeResolution) {
                return this.commonConfiguratorUtilsService.getSlotsFromLayoutConfiguration(this.layoutConfig, CpqConfiguratorPageLayoutHandler.templateName, CpqConfiguratorPageLayoutHandler.sectionNavigationDisplayOnly, BREAKPOINT.lg);
            }
            else {
                return this.commonConfiguratorUtilsService.getSlotsFromLayoutConfiguration(this.layoutConfig, CpqConfiguratorPageLayoutHandler.templateName, CpqConfiguratorPageLayoutHandler.sectionNavigationDisplayOnly, BREAKPOINT.xs);
            }
        }
        else {
            return slots;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorPageLayoutHandler, deps: [{ token: i1.ConfiguratorRouterExtractorService }, { token: i2.BreakpointService }, { token: i2.LayoutConfig }, { token: i1.CommonConfiguratorUtilsService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorPageLayoutHandler, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorPageLayoutHandler, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.ConfiguratorRouterExtractorService }, { type: i2.BreakpointService }, { type: i2.LayoutConfig }, { type: i1.CommonConfiguratorUtilsService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 *  Contains the layout configuration for the CPQ configurator pages. This configuration is
 *  optional as of version 4.2, and reduces the components that are rendered in the header section.
 *  It needs to be explicitly imported, otherwise the default configuration
 *  from CpqConfiguratorInteractiveModule is active
 */
class CpqConfiguratorLayoutModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorLayoutModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorLayoutModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorLayoutModule, providers: [
            provideDefaultConfig({
                layoutSlots: {
                    CpqConfigurationTemplate: {
                        header: {
                            lg: {
                                slots: ['SiteLogo', 'CpqConfigExitButton', 'MiniCart'],
                            },
                            xs: {
                                slots: ['SiteLogo', 'CpqConfigExitButton', 'MiniCart'],
                            },
                        },
                        headerDisplayOnly: {
                            lg: {
                                slots: [
                                    'SiteContext',
                                    'SiteLinks',
                                    'SiteLogo',
                                    'SearchBox',
                                    'SiteLogin',
                                    'MiniCart',
                                    'NavigationBar',
                                ],
                            },
                            xs: {
                                slots: ['PreHeader', 'SiteLogo', 'SearchBox', 'MiniCart'],
                            },
                        },
                        navigation: {
                            lg: { slots: [] },
                            slots: ['CpqConfigMenu'],
                        },
                        navigationDisplayOnly: {
                            lg: { slots: [] },
                            xs: {
                                slots: ['SiteLogin', 'NavigationBar', 'SiteContext', 'SiteLinks'],
                            },
                        },
                        lg: {
                            slots: [
                                'CpqConfigHeader',
                                'CpqConfigBanner',
                                'CpqConfigMenu',
                                'CpqConfigContent',
                                'CpqConfigOverviewBanner',
                                'CpqConfigOverviewContent',
                                'CpqConfigBottombar',
                            ],
                        },
                        slots: [
                            'CpqConfigHeader',
                            'CpqConfigBanner',
                            'CpqConfigContent',
                            'CpqConfigOverviewBanner',
                            'CpqConfigOverviewContent',
                            'CpqConfigBottombar',
                        ],
                    },
                },
            }),
            {
                provide: PAGE_LAYOUT_HANDLER,
                useExisting: CpqConfiguratorPageLayoutHandler,
                multi: true,
            },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorLayoutModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        provideDefaultConfig({
                            layoutSlots: {
                                CpqConfigurationTemplate: {
                                    header: {
                                        lg: {
                                            slots: ['SiteLogo', 'CpqConfigExitButton', 'MiniCart'],
                                        },
                                        xs: {
                                            slots: ['SiteLogo', 'CpqConfigExitButton', 'MiniCart'],
                                        },
                                    },
                                    headerDisplayOnly: {
                                        lg: {
                                            slots: [
                                                'SiteContext',
                                                'SiteLinks',
                                                'SiteLogo',
                                                'SearchBox',
                                                'SiteLogin',
                                                'MiniCart',
                                                'NavigationBar',
                                            ],
                                        },
                                        xs: {
                                            slots: ['PreHeader', 'SiteLogo', 'SearchBox', 'MiniCart'],
                                        },
                                    },
                                    navigation: {
                                        lg: { slots: [] },
                                        slots: ['CpqConfigMenu'],
                                    },
                                    navigationDisplayOnly: {
                                        lg: { slots: [] },
                                        xs: {
                                            slots: ['SiteLogin', 'NavigationBar', 'SiteContext', 'SiteLinks'],
                                        },
                                    },
                                    lg: {
                                        slots: [
                                            'CpqConfigHeader',
                                            'CpqConfigBanner',
                                            'CpqConfigMenu',
                                            'CpqConfigContent',
                                            'CpqConfigOverviewBanner',
                                            'CpqConfigOverviewContent',
                                            'CpqConfigBottombar',
                                        ],
                                    },
                                    slots: [
                                        'CpqConfigHeader',
                                        'CpqConfigBanner',
                                        'CpqConfigContent',
                                        'CpqConfigOverviewBanner',
                                        'CpqConfigOverviewContent',
                                        'CpqConfigBottombar',
                                    ],
                                },
                            },
                        }),
                        {
                            provide: PAGE_LAYOUT_HANDLER,
                            useExisting: CpqConfiguratorPageLayoutHandler,
                            multi: true,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultCpqInteractiveRoutingConfig = {
    routing: {
        routes: {
            configureCLOUDCPQCONFIGURATOR: {
                paths: ['configure/cpq/:ownerType/entityKey/:entityKey'],
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Takes care of the interactive configuration process (the user enters new attribute values and navigates through the configuration).
 * Provides routing, assignment of ng components to CMS components and assignment of CMS components to the layout slots
 */
class CpqConfiguratorInteractiveModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorInteractiveModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorInteractiveModule, imports: [i1$1.RouterModule, HamburgerMenuModule,
            CpqConfiguratorLayoutModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorInteractiveModule, providers: [provideDefaultConfig(defaultCpqInteractiveRoutingConfig)], imports: [RouterModule.forChild([
                {
                    // We can neither omit the path nor set to undefined
                    // @ts-ignore
                    path: null,
                    data: {
                        cxRoute: 'configureCLOUDCPQCONFIGURATOR',
                    },
                    component: PageLayoutComponent,
                    canActivate: [CmsPageGuard],
                },
            ]),
            HamburgerMenuModule,
            CpqConfiguratorLayoutModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorInteractiveModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        RouterModule.forChild([
                            {
                                // We can neither omit the path nor set to undefined
                                // @ts-ignore
                                path: null,
                                data: {
                                    cxRoute: 'configureCLOUDCPQCONFIGURATOR',
                                },
                                component: PageLayoutComponent,
                                canActivate: [CmsPageGuard],
                            },
                        ]),
                        HamburgerMenuModule,
                        CpqConfiguratorLayoutModule,
                    ],
                    providers: [provideDefaultConfig(defaultCpqInteractiveRoutingConfig)],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultCpqOverviewRoutingConfig = {
    routing: {
        routes: {
            configureOverviewCLOUDCPQCONFIGURATOR: {
                paths: [
                    'configure-overview/cpq/:ownerType/entityKey/:entityKey/displayOnly/:displayOnly',
                    'configure-overview/cpq/:ownerType/entityKey/:entityKey',
                ],
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Takes care of the configuration overview that visualizes the attribute value assignments that have been done already in a condensed, read-only form.
 * The end-user can switch between the interactive view and this overview.
 * Provides routing, assignment of ng components to CMS components and assignment of CMS components to the layout slots.
 * Some of the ng components on this view (tab bar, price summary and addToCart button) are shared between the interactive view and the overview.
 */
class CpqConfiguratorOverviewModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorOverviewModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorOverviewModule, imports: [i1$1.RouterModule, CpqConfiguratorLayoutModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorOverviewModule, providers: [provideDefaultConfig(defaultCpqOverviewRoutingConfig)], imports: [RouterModule.forChild([
                {
                    // We can neither omit the path nor set to undefined
                    // @ts-ignore
                    path: null,
                    component: PageLayoutComponent,
                    data: {
                        cxRoute: 'configureOverviewCLOUDCPQCONFIGURATOR',
                    },
                    canActivate: [CmsPageGuard],
                },
            ]),
            CpqConfiguratorLayoutModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorOverviewModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        RouterModule.forChild([
                            {
                                // We can neither omit the path nor set to undefined
                                // @ts-ignore
                                path: null,
                                component: PageLayoutComponent,
                                data: {
                                    cxRoute: 'configureOverviewCLOUDCPQCONFIGURATOR',
                                },
                                canActivate: [CmsPageGuard],
                            },
                        ]),
                        CpqConfiguratorLayoutModule,
                    ],
                    providers: [provideDefaultConfig(defaultCpqOverviewRoutingConfig)],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Exposes the CPQ aspects that we need to load eagerly, like page mappings, routing
 * and interceptor related entities
 */
class CpqConfiguratorRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorRootModule, imports: [CpqConfiguratorInteractiveModule, CpqConfiguratorOverviewModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorRootModule, providers: [provideDefaultConfig({ routing: { protected: true } })], imports: [CpqConfiguratorInteractiveModule, CpqConfiguratorOverviewModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CpqConfiguratorRootModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CpqConfiguratorInteractiveModule, CpqConfiguratorOverviewModule],
                    //force early login
                    providers: [provideDefaultConfig({ routing: { protected: true } })],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const PRODUCT_CONFIGURATOR_RULEBASED_FEATURE = 'productConfiguratorRulebased';

class ConfiguratorBadRequestHandler extends HttpErrorHandler {
    constructor(globalMessageService) {
        super(globalMessageService);
        this.globalMessageService = globalMessageService;
        this.responseStatus = HttpResponseStatus.BAD_REQUEST;
    }
    getPriority() {
        return Priority.NORMAL;
    }
    hasMatch(errorResponse) {
        return (super.hasMatch(errorResponse) &&
            this.isRelatedToProductConfigurator(errorResponse));
    }
    handleError(_request, response) {
        this.getIllegalStateErrorsRelatedToProductConfigurator(response).forEach(({ message }) => {
            this.handleIllegalArgumentIssues(message);
        });
    }
    handleIllegalArgumentIssues(message) {
        if (this.isIllegalStateErrorRelatedToMakeToStock(message)) {
            this.globalMessageService.add({
                key: 'configurator.httpHandlers.makeToStockBaseProductIssue',
            }, GlobalMessageType.MSG_TYPE_ERROR);
        }
    }
    isNotEmpty(errors) {
        return errors?.length > 0;
    }
    isIllegalStateErrorRelatedToMakeToStock(message) {
        const discountMask = /base product is defined as 'make-to-stock'/;
        return message.match(discountMask) !== null;
    }
    isIllegalStateErrorRelatedToProductConfigurator(message) {
        return message && this.isIllegalStateErrorRelatedToMakeToStock(message);
    }
    getIllegalStateErrorsRelatedToProductConfigurator(response) {
        return (response?.error?.errors ?? [])
            .filter((error) => error.type === 'IllegalStateError')
            .filter((error) => this.isIllegalStateErrorRelatedToProductConfigurator(error.message));
    }
    isRelatedToProductConfigurator(response) {
        return this.isNotEmpty(this.getIllegalStateErrorsRelatedToProductConfigurator(response));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ConfiguratorBadRequestHandler, deps: [{ token: i1$2.GlobalMessageService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ConfiguratorBadRequestHandler, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ConfiguratorBadRequestHandler, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$2.GlobalMessageService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const cmsComponents = [
    'ConfiguratorForm',
    'ConfiguratorOverviewForm',
    'ConfiguratorOverviewMenu',
    'ConfiguratorUpdateMessage',
    'ConfiguratorAddToCartButton',
    'ConfiguratorMenu',
    'ConfiguratorGroupTitle',
    'ConfiguratorOverviewBanner',
    'ConfiguratorPrevNext',
    'ConfiguratorPriceSummary',
    'ConfiguratorProductTitle',
    'ConfiguratorTabBar',
    'ConfiguratorExitButton',
    'ConfiguratorVariantCarousel',
    'CpqConfiguratorConflictAndErrorMessagesComponent',
    'ConfiguratorOverviewFilterButton',
    'ConfiguratorOverviewFilter',
    'ConfiguratorOverviewSidebar',
];
// TODO: Inline this factory when we start releasing Ivy compiled libraries
function defaultProductConfiguratorRulebasedComponentsConfig() {
    const config = {
        featureModules: {
            [PRODUCT_CONFIGURATOR_RULEBASED_FEATURE]: {
                cmsComponents,
            },
        },
    };
    return config;
}
/**
 * Contains feature module configuration
 */
class RulebasedConfiguratorRootFeatureModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RulebasedConfiguratorRootFeatureModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: RulebasedConfiguratorRootFeatureModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RulebasedConfiguratorRootFeatureModule, providers: [
            provideDefaultConfigFactory(defaultProductConfiguratorRulebasedComponentsConfig),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RulebasedConfiguratorRootFeatureModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    providers: [
                        provideDefaultConfigFactory(defaultProductConfiguratorRulebasedComponentsConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultRulebasedRoutingConfig = {
    routing: {
        routes: {
            configureCPQCONFIGURATOR: {
                paths: ['configure/vc/:ownerType/entityKey/:entityKey'],
            },
            configureCPQCONFIGURATOR_READ_ONLY: {
                paths: [
                    'configure-overview/vc/:ownerType/entityKey/:entityKey/displayOnly/true',
                ],
            },
            configureOverviewCPQCONFIGURATOR: {
                paths: [
                    'configure-overview/vc/:ownerType/entityKey/:entityKey/displayOnly/:displayOnly',
                    'configure-overview/vc/:ownerType/entityKey/:entityKey',
                ],
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Provides the default cx routing configuration for the rulebased configurator
 */
class RulebasedConfiguratorRoutingModule {
    static forRoot() {
        return {
            ngModule: RulebasedConfiguratorRoutingModule,
            providers: [provideDefaultConfig(defaultRulebasedRoutingConfig)],
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RulebasedConfiguratorRoutingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: RulebasedConfiguratorRoutingModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RulebasedConfiguratorRoutingModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RulebasedConfiguratorRoutingModule, decorators: [{
            type: NgModule,
            args: [{}]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 *  Contains the layout configuration for the interactive configuration page. This configuration is
 *  optional as of version 4.2, and reduces the components that are rendered in the header section.
 *  It needs to be explicitly imported, otherwise the default configuration
 *  from VariantConfiguratorInteractiveModule is active
 */
class VariantConfiguratorInteractiveLayoutModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorInteractiveLayoutModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorInteractiveLayoutModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorInteractiveLayoutModule, providers: [
            provideDefaultConfig({
                layoutSlots: {
                    VariantConfigurationTemplate: {
                        header: {
                            lg: {
                                slots: [
                                    'PreHeader',
                                    'SiteLogo',
                                    'VariantConfigExitButton',
                                    'MiniCart',
                                ],
                            },
                            xs: {
                                slots: [
                                    'PreHeader',
                                    'SiteLogo',
                                    'VariantConfigExitButton',
                                    'MiniCart',
                                ],
                            },
                        },
                        navigation: {
                            lg: { slots: [] },
                            slots: ['VariantConfigMenu'],
                        },
                        lg: {
                            slots: [
                                'VariantConfigHeader',
                                'VariantConfigMenu',
                                'VariantConfigContent',
                                'VariantConfigBottombar',
                                'VariantConfigVariantCarousel',
                            ],
                        },
                        slots: [
                            'VariantConfigHeader',
                            'VariantConfigContent',
                            'VariantConfigBottombar',
                            'VariantConfigVariantCarousel',
                        ],
                    },
                },
            }),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorInteractiveLayoutModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        provideDefaultConfig({
                            layoutSlots: {
                                VariantConfigurationTemplate: {
                                    header: {
                                        lg: {
                                            slots: [
                                                'PreHeader',
                                                'SiteLogo',
                                                'VariantConfigExitButton',
                                                'MiniCart',
                                            ],
                                        },
                                        xs: {
                                            slots: [
                                                'PreHeader',
                                                'SiteLogo',
                                                'VariantConfigExitButton',
                                                'MiniCart',
                                            ],
                                        },
                                    },
                                    navigation: {
                                        lg: { slots: [] },
                                        slots: ['VariantConfigMenu'],
                                    },
                                    lg: {
                                        slots: [
                                            'VariantConfigHeader',
                                            'VariantConfigMenu',
                                            'VariantConfigContent',
                                            'VariantConfigBottombar',
                                            'VariantConfigVariantCarousel',
                                        ],
                                    },
                                    slots: [
                                        'VariantConfigHeader',
                                        'VariantConfigContent',
                                        'VariantConfigBottombar',
                                        'VariantConfigVariantCarousel',
                                    ],
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Takes care of the interactive configuration process (the user enters new attribute values and navigates through the configuration).
 * Provides routing, assignment of ng components to CMS components and assignment of CMS components to the layout slots
 */
class VariantConfiguratorInteractiveModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorInteractiveModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorInteractiveModule, imports: [i1$1.RouterModule, HamburgerMenuModule,
            VariantConfiguratorInteractiveLayoutModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorInteractiveModule, imports: [RouterModule.forChild([
                {
                    // We can neither omit the path nor set to undefined
                    // @ts-ignore
                    path: null,
                    data: {
                        cxRoute: 'configureCPQCONFIGURATOR',
                    },
                    component: PageLayoutComponent,
                    canActivate: [CmsPageGuard],
                },
            ]),
            HamburgerMenuModule,
            VariantConfiguratorInteractiveLayoutModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorInteractiveModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        RouterModule.forChild([
                            {
                                // We can neither omit the path nor set to undefined
                                // @ts-ignore
                                path: null,
                                data: {
                                    cxRoute: 'configureCPQCONFIGURATOR',
                                },
                                component: PageLayoutComponent,
                                canActivate: [CmsPageGuard],
                            },
                        ]),
                        HamburgerMenuModule,
                        VariantConfiguratorInteractiveLayoutModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class VariantConfiguratorPageLayoutHandler {
    static { this.templateName = 'VariantConfigurationOverviewTemplate'; }
    static { this.sectionDisplayOnlyName = 'headerDisplayOnly'; }
    constructor(configuratorRouterExtractorService, breakpointService, layoutConfig, commonConfiguratorUtilsService) {
        this.configuratorRouterExtractorService = configuratorRouterExtractorService;
        this.breakpointService = breakpointService;
        this.layoutConfig = layoutConfig;
        this.commonConfiguratorUtilsService = commonConfiguratorUtilsService;
    }
    handle(slots$, pageTemplate, section) {
        if (pageTemplate === VariantConfiguratorPageLayoutHandler.templateName &&
            section === 'header') {
            this.configuratorRouterExtractorService
                .extractRouterData()
                .pipe(take(1))
                .subscribe((routerData) => {
                if (routerData.displayOnly) {
                    slots$ = slots$.pipe(switchMap(() => this.breakpointService.isUp(BREAKPOINT.lg)), map((isLargeResolution) => {
                        if (isLargeResolution) {
                            return this.commonConfiguratorUtilsService.getSlotsFromLayoutConfiguration(this.layoutConfig, VariantConfiguratorPageLayoutHandler.templateName, VariantConfiguratorPageLayoutHandler.sectionDisplayOnlyName, BREAKPOINT.lg);
                        }
                        else {
                            return this.commonConfiguratorUtilsService.getSlotsFromLayoutConfiguration(this.layoutConfig, VariantConfiguratorPageLayoutHandler.templateName, VariantConfiguratorPageLayoutHandler.sectionDisplayOnlyName, BREAKPOINT.xs);
                        }
                    }));
                }
            });
        }
        return slots$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorPageLayoutHandler, deps: [{ token: i1.ConfiguratorRouterExtractorService }, { token: i2.BreakpointService }, { token: i2.LayoutConfig }, { token: i1.CommonConfiguratorUtilsService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorPageLayoutHandler, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorPageLayoutHandler, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.ConfiguratorRouterExtractorService }, { type: i2.BreakpointService }, { type: i2.LayoutConfig }, { type: i1.CommonConfiguratorUtilsService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 *  Contains the layout configuration for the overview configuration page. This configuration is
 *  optional as of version 4.2, and reduces the components that are rendered in the header section.
 *  It needs to be explicitly imported, otherwise the default configuration
 *  from VariantConfiguratorOverviewModule is active
 */
class VariantConfiguratorOverviewLayoutModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorOverviewLayoutModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorOverviewLayoutModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorOverviewLayoutModule, providers: [
            provideDefaultConfig({
                layoutSlots: {
                    VariantConfigurationOverviewTemplate: {
                        header: {
                            slots: ['SiteLogo', 'VariantConfigOverviewExitButton', 'MiniCart'],
                        },
                        headerDisplayOnly: {
                            lg: {
                                slots: [
                                    'SiteContext',
                                    'SiteLinks',
                                    'SiteLogo',
                                    'SearchBox',
                                    'SiteLogin',
                                    'MiniCart',
                                    'NavigationBar',
                                ],
                            },
                            xs: {
                                slots: ['PreHeader', 'SiteLogo', 'SearchBox', 'MiniCart'],
                            },
                        },
                        lg: {
                            slots: [
                                'VariantConfigOverviewHeader',
                                'VariantConfigOverviewBanner',
                                'VariantConfigOverviewNavigation',
                                'VariantConfigOverviewContent',
                                'VariantConfigOverviewBottombar',
                            ],
                        },
                        slots: [
                            'VariantConfigOverviewHeader',
                            'VariantConfigOverviewBanner',
                            'VariantConfigOverviewFilterButton',
                            'VariantConfigOverviewContent',
                            'VariantConfigOverviewBottombar',
                        ],
                    },
                },
            }),
            {
                provide: PAGE_LAYOUT_HANDLER,
                useExisting: VariantConfiguratorPageLayoutHandler,
                multi: true,
            },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorOverviewLayoutModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        provideDefaultConfig({
                            layoutSlots: {
                                VariantConfigurationOverviewTemplate: {
                                    header: {
                                        slots: ['SiteLogo', 'VariantConfigOverviewExitButton', 'MiniCart'],
                                    },
                                    headerDisplayOnly: {
                                        lg: {
                                            slots: [
                                                'SiteContext',
                                                'SiteLinks',
                                                'SiteLogo',
                                                'SearchBox',
                                                'SiteLogin',
                                                'MiniCart',
                                                'NavigationBar',
                                            ],
                                        },
                                        xs: {
                                            slots: ['PreHeader', 'SiteLogo', 'SearchBox', 'MiniCart'],
                                        },
                                    },
                                    lg: {
                                        slots: [
                                            'VariantConfigOverviewHeader',
                                            'VariantConfigOverviewBanner',
                                            'VariantConfigOverviewNavigation',
                                            'VariantConfigOverviewContent',
                                            'VariantConfigOverviewBottombar',
                                        ],
                                    },
                                    slots: [
                                        'VariantConfigOverviewHeader',
                                        'VariantConfigOverviewBanner',
                                        'VariantConfigOverviewFilterButton',
                                        'VariantConfigOverviewContent',
                                        'VariantConfigOverviewBottombar',
                                    ],
                                },
                            },
                        }),
                        {
                            provide: PAGE_LAYOUT_HANDLER,
                            useExisting: VariantConfiguratorPageLayoutHandler,
                            multi: true,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Takes care of the configuration overview that visualizes the attribute value assignments that have been done already in a condensed, read-only form.
 * The end-user can switch between the interactive view and this overview.
 * Provides routing, assignment of ng components to CMS components and assignment of CMS components to the layout slots.
 * Some of the ng components on this view (tab bar, price summary and addToCart button) are shared between the interactive view and the overview.
 */
class VariantConfiguratorOverviewModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorOverviewModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorOverviewModule, imports: [i1$1.RouterModule, VariantConfiguratorOverviewLayoutModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorOverviewModule, imports: [RouterModule.forChild([
                {
                    // We can neither omit the path nor set to undefined
                    // @ts-ignore
                    path: null,
                    component: PageLayoutComponent,
                    data: {
                        cxRoute: 'configureOverviewCPQCONFIGURATOR',
                    },
                    canActivate: [CmsPageGuard],
                },
            ]),
            VariantConfiguratorOverviewLayoutModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: VariantConfiguratorOverviewModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        RouterModule.forChild([
                            {
                                // We can neither omit the path nor set to undefined
                                // @ts-ignore
                                path: null,
                                component: PageLayoutComponent,
                                data: {
                                    cxRoute: 'configureOverviewCPQCONFIGURATOR',
                                },
                                canActivate: [CmsPageGuard],
                            },
                        ]),
                        VariantConfiguratorOverviewLayoutModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Exposes the root modules that we need to load statically. Contains page mappings, route configurations
 * and feature configuration
 */
class RulebasedConfiguratorRootModule {
    static forRoot() {
        return {
            ngModule: RulebasedConfiguratorRootModule,
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RulebasedConfiguratorRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: RulebasedConfiguratorRootModule, imports: [CommonModule,
            CommonConfiguratorModule,
            RulebasedConfiguratorRootFeatureModule,
            VariantConfiguratorInteractiveModule,
            VariantConfiguratorOverviewModule, RulebasedConfiguratorRoutingModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RulebasedConfiguratorRootModule, providers: [
            {
                provide: HttpErrorHandler,
                useExisting: ConfiguratorBadRequestHandler,
                multi: true,
            },
        ], imports: [CommonModule,
            CommonConfiguratorModule,
            RulebasedConfiguratorRootFeatureModule,
            VariantConfiguratorInteractiveModule,
            VariantConfiguratorOverviewModule,
            RulebasedConfiguratorRoutingModule.forRoot()] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RulebasedConfiguratorRootModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        CommonConfiguratorModule,
                        RulebasedConfiguratorRootFeatureModule,
                        VariantConfiguratorInteractiveModule,
                        VariantConfiguratorOverviewModule,
                        RulebasedConfiguratorRoutingModule.forRoot(),
                    ],
                    providers: [
                        {
                            provide: HttpErrorHandler,
                            useExisting: ConfiguratorBadRequestHandler,
                            multi: true,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ConfiguratorBadRequestHandler, CpqConfiguratorInteractiveModule, CpqConfiguratorLayoutModule, CpqConfiguratorOverviewModule, CpqConfiguratorRootModule, PRODUCT_CONFIGURATOR_RULEBASED_FEATURE, RulebasedConfiguratorRootFeatureModule, RulebasedConfiguratorRootModule, RulebasedConfiguratorRoutingModule, VariantConfiguratorInteractiveLayoutModule, VariantConfiguratorInteractiveModule, VariantConfiguratorOverviewLayoutModule, VariantConfiguratorOverviewModule, VariantConfiguratorPageLayoutHandler, defaultProductConfiguratorRulebasedComponentsConfig };
//# sourceMappingURL=spartacus-product-configurator-rulebased-root.mjs.map
