import { HttpClient } from '@angular/common/http';
import { OccEndpointsService, ConverterService, SearchConfig, GeoPoint, PointOfService, Occ, OccEndpoint } from '@spartacus/core';
import { StoreFinderAdapter, StoreFinderSearchPage, StoreCount } from '@spartacus/storefinder/core';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';

declare class OccStoreFinderAdapter implements StoreFinderAdapter {
    protected http: HttpClient;
    protected occEndpointsService: OccEndpointsService;
    protected converterService: ConverterService;
    constructor(http: HttpClient, occEndpointsService: OccEndpointsService, converterService: ConverterService);
    search(query: string, searchConfig: SearchConfig, longitudeLatitude?: GeoPoint, radius?: number): Observable<StoreFinderSearchPage>;
    loadCounts(): Observable<StoreCount[]>;
    load(storeId: string): Observable<PointOfService>;
    protected callOccFindStores(query: string, searchConfig?: SearchConfig, longitudeLatitude?: GeoPoint, radius?: number): Observable<Occ.StoreFinderSearchPage>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccStoreFinderAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccStoreFinderAdapter>;
}

declare module '@spartacus/core' {
    interface OccEndpoints {
        /**
         * Get a store location
         *
         * @member {string} [page]
         */
        store?: string | OccEndpoint;
        /**
         * Get a list of store locations
         *
         * @member {string} [page]
         */
        stores?: string | OccEndpoint;
        /**
         * Gets a store location count per country and regions
         *
         * @member {string} [page]
         */
        storescounts?: string | OccEndpoint;
    }
}

declare class StoreFinderOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StoreFinderOccModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StoreFinderOccModule>;
}

export { OccStoreFinderAdapter, StoreFinderOccModule };
