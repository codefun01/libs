import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    storeFinder: {
        storeFinder: {
            openUntil: string;
            closed: string;
            back: string;
            call: string;
            getDirections: string;
            ariaLabelGetDirections: string;
            ariaLabelCountriesCount: string;
            listView: string;
            mapView: string;
            noStoresFound: string;
            storeHours: string;
            storeFeatures: string;
            storeFinder: string;
            storesFoundTitle: string;
            storesFound: string;
            storesFound_other: string;
            fromStoresFound: string;
            fromStoresFound_other: string;
            findStore: string;
            findStoreBy: string;
            useMyLocation: string;
            viewAllStores: string;
            contactUs: string;
            searchBox: string;
            backToList: string;
            noStoresMessage: string;
            geolocationNotEnabled: string;
            searchNearestStores: string;
            searchBoxLabel: string;
        };
    };
};

declare const de: {
    storeFinder: {
        storeFinder: {
            openUntil: string;
            closed: string;
            back: string;
            call: string;
            getDirections: string;
            ariaLabelGetDirections: string;
            ariaLabelCountriesCount: string;
            listView: string;
            mapView: string;
            noStoresFound: string;
            storeHours: string;
            storeFeatures: string;
            storeFinder: string;
            storesFoundTitle: string;
            storesFound: string;
            storesFound_other: string;
            fromStoresFound: string;
            fromStoresFound_other: string;
            findStore: string;
            findStoreBy: string;
            useMyLocation: string;
            viewAllStores: string;
            contactUs: string;
            searchBox: string;
            backToList: string;
            noStoresMessage: string;
            geolocationNotEnabled: string;
            searchNearestStores: string;
            searchBoxLabel: string;
        };
    };
};

declare const en: {
    storeFinder: {
        storeFinder: {
            openUntil: string;
            closed: string;
            back: string;
            call: string;
            getDirections: string;
            ariaLabelGetDirections: string;
            ariaLabelCountriesCount: string;
            listView: string;
            mapView: string;
            noStoresFound: string;
            storeHours: string;
            storeFeatures: string;
            storeFinder: string;
            storesFoundTitle: string;
            storesFound: string;
            storesFound_other: string;
            fromStoresFound: string;
            fromStoresFound_other: string;
            findStore: string;
            findStoreBy: string;
            useMyLocation: string;
            viewAllStores: string;
            contactUs: string;
            searchBox: string;
            backToList: string;
            noStoresMessage: string;
            geolocationNotEnabled: string;
            searchNearestStores: string;
            searchBoxLabel: string;
        };
    };
};

declare const es: {
    storeFinder: {
        storeFinder: {
            openUntil: string;
            closed: string;
            back: string;
            call: string;
            getDirections: string;
            ariaLabelGetDirections: string;
            ariaLabelCountriesCount: string;
            listView: string;
            mapView: string;
            noStoresFound: string;
            storeHours: string;
            storeFeatures: string;
            storeFinder: string;
            storesFoundTitle: string;
            storesFound: string;
            storesFound_other: string;
            fromStoresFound: string;
            fromStoresFound_other: string;
            findStore: string;
            findStoreBy: string;
            useMyLocation: string;
            viewAllStores: string;
            contactUs: string;
            searchBox: string;
            backToList: string;
            noStoresMessage: string;
            geolocationNotEnabled: string;
            searchNearestStores: string;
            searchBoxLabel: string;
        };
    };
};

declare const es_CO: {
    storeFinder: {
        storeFinder: {
            openUntil: string;
            closed: string;
            back: string;
            call: string;
            getDirections: string;
            ariaLabelGetDirections: string;
            ariaLabelCountriesCount: string;
            listView: string;
            mapView: string;
            noStoresFound: string;
            storeHours: string;
            storeFeatures: string;
            storeFinder: string;
            storesFoundTitle: string;
            storesFound: string;
            storesFound_other: string;
            fromStoresFound: string;
            fromStoresFound_other: string;
            findStore: string;
            findStoreBy: string;
            useMyLocation: string;
            viewAllStores: string;
            contactUs: string;
            searchBox: string;
            backToList: string;
            noStoresMessage: string;
            geolocationNotEnabled: string;
            searchNearestStores: string;
            searchBoxLabel: string;
        };
    };
};

declare const fr: {
    storeFinder: {
        storeFinder: {
            openUntil: string;
            closed: string;
            back: string;
            call: string;
            getDirections: string;
            ariaLabelGetDirections: string;
            ariaLabelCountriesCount: string;
            listView: string;
            mapView: string;
            noStoresFound: string;
            storeHours: string;
            storeFeatures: string;
            storeFinder: string;
            storesFoundTitle: string;
            storesFound: string;
            storesFound_other: string;
            fromStoresFound: string;
            fromStoresFound_other: string;
            findStore: string;
            findStoreBy: string;
            useMyLocation: string;
            viewAllStores: string;
            contactUs: string;
            searchBox: string;
            backToList: string;
            noStoresMessage: string;
            geolocationNotEnabled: string;
            searchNearestStores: string;
            searchBoxLabel: string;
        };
    };
};

declare const hi: {
    storeFinder: {
        storeFinder: {
            openUntil: string;
            closed: string;
            back: string;
            call: string;
            getDirections: string;
            ariaLabelGetDirections: string;
            ariaLabelCountriesCount: string;
            listView: string;
            mapView: string;
            noStoresFound: string;
            storeHours: string;
            storeFeatures: string;
            storeFinder: string;
            storesFoundTitle: string;
            storesFound: string;
            storesFound_other: string;
            fromStoresFound: string;
            fromStoresFound_other: string;
            findStore: string;
            findStoreBy: string;
            useMyLocation: string;
            viewAllStores: string;
            contactUs: string;
            searchBox: string;
            backToList: string;
            noStoresMessage: string;
            geolocationNotEnabled: string;
            searchNearestStores: string;
            searchBoxLabel: string;
        };
    };
};

declare const hu: {
    storeFinder: {
        storeFinder: {
            openUntil: string;
            closed: string;
            back: string;
            call: string;
            getDirections: string;
            ariaLabelGetDirections: string;
            ariaLabelCountriesCount: string;
            listView: string;
            mapView: string;
            noStoresFound: string;
            storeHours: string;
            storeFeatures: string;
            storeFinder: string;
            storesFoundTitle: string;
            storesFound: string;
            storesFound_other: string;
            fromStoresFound: string;
            fromStoresFound_other: string;
            findStore: string;
            findStoreBy: string;
            useMyLocation: string;
            viewAllStores: string;
            contactUs: string;
            searchBox: string;
            backToList: string;
            noStoresMessage: string;
            geolocationNotEnabled: string;
            searchNearestStores: string;
            searchBoxLabel: string;
        };
    };
};

declare const id: {
    storeFinder: {
        storeFinder: {
            openUntil: string;
            closed: string;
            back: string;
            call: string;
            getDirections: string;
            ariaLabelGetDirections: string;
            ariaLabelCountriesCount: string;
            listView: string;
            mapView: string;
            noStoresFound: string;
            storeHours: string;
            storeFeatures: string;
            storeFinder: string;
            storesFoundTitle: string;
            storesFound: string;
            storesFound_other: string;
            fromStoresFound: string;
            fromStoresFound_other: string;
            findStore: string;
            findStoreBy: string;
            useMyLocation: string;
            viewAllStores: string;
            contactUs: string;
            searchBox: string;
            backToList: string;
            noStoresMessage: string;
            geolocationNotEnabled: string;
            searchNearestStores: string;
            searchBoxLabel: string;
        };
    };
};

declare const it: {
    storeFinder: {
        storeFinder: {
            openUntil: string;
            closed: string;
            back: string;
            call: string;
            getDirections: string;
            ariaLabelGetDirections: string;
            ariaLabelCountriesCount: string;
            listView: string;
            mapView: string;
            noStoresFound: string;
            storeHours: string;
            storeFeatures: string;
            storeFinder: string;
            storesFoundTitle: string;
            storesFound: string;
            storesFound_other: string;
            fromStoresFound: string;
            fromStoresFound_other: string;
            findStore: string;
            findStoreBy: string;
            useMyLocation: string;
            viewAllStores: string;
            contactUs: string;
            searchBox: string;
            backToList: string;
            noStoresMessage: string;
            geolocationNotEnabled: string;
            searchNearestStores: string;
            searchBoxLabel: string;
        };
    };
};

declare const ja: {
    storeFinder: {
        storeFinder: {
            openUntil: string;
            closed: string;
            back: string;
            call: string;
            getDirections: string;
            ariaLabelGetDirections: string;
            ariaLabelCountriesCount: string;
            listView: string;
            mapView: string;
            noStoresFound: string;
            storeHours: string;
            storeFeatures: string;
            storeFinder: string;
            storesFoundTitle: string;
            storesFound: string;
            storesFound_other: string;
            fromStoresFound: string;
            fromStoresFound_other: string;
            findStore: string;
            findStoreBy: string;
            useMyLocation: string;
            viewAllStores: string;
            contactUs: string;
            searchBox: string;
            backToList: string;
            noStoresMessage: string;
            geolocationNotEnabled: string;
            searchNearestStores: string;
            searchBoxLabel: string;
        };
    };
};

declare const ko: {
    storeFinder: {
        storeFinder: {
            openUntil: string;
            closed: string;
            back: string;
            call: string;
            getDirections: string;
            ariaLabelGetDirections: string;
            ariaLabelCountriesCount: string;
            listView: string;
            mapView: string;
            noStoresFound: string;
            storeHours: string;
            storeFeatures: string;
            storeFinder: string;
            storesFoundTitle: string;
            storesFound: string;
            storesFound_other: string;
            fromStoresFound: string;
            fromStoresFound_other: string;
            findStore: string;
            findStoreBy: string;
            useMyLocation: string;
            viewAllStores: string;
            contactUs: string;
            searchBox: string;
            backToList: string;
            noStoresMessage: string;
            geolocationNotEnabled: string;
            searchNearestStores: string;
            searchBoxLabel: string;
        };
    };
};

declare const pl: {
    storeFinder: {
        storeFinder: {
            openUntil: string;
            closed: string;
            back: string;
            call: string;
            getDirections: string;
            ariaLabelGetDirections: string;
            ariaLabelCountriesCount: string;
            listView: string;
            mapView: string;
            noStoresFound: string;
            storeHours: string;
            storeFeatures: string;
            storeFinder: string;
            storesFoundTitle: string;
            storesFound: string;
            storesFound_other: string;
            fromStoresFound: string;
            fromStoresFound_other: string;
            findStore: string;
            findStoreBy: string;
            useMyLocation: string;
            viewAllStores: string;
            contactUs: string;
            searchBox: string;
            backToList: string;
            noStoresMessage: string;
            geolocationNotEnabled: string;
            searchNearestStores: string;
            searchBoxLabel: string;
        };
    };
};

declare const pt: {
    storeFinder: {
        storeFinder: {
            openUntil: string;
            closed: string;
            back: string;
            call: string;
            getDirections: string;
            ariaLabelGetDirections: string;
            ariaLabelCountriesCount: string;
            listView: string;
            mapView: string;
            noStoresFound: string;
            storeHours: string;
            storeFeatures: string;
            storeFinder: string;
            storesFoundTitle: string;
            storesFound: string;
            storesFound_other: string;
            fromStoresFound: string;
            fromStoresFound_other: string;
            findStore: string;
            findStoreBy: string;
            useMyLocation: string;
            viewAllStores: string;
            contactUs: string;
            searchBox: string;
            backToList: string;
            noStoresMessage: string;
            geolocationNotEnabled: string;
            searchNearestStores: string;
            searchBoxLabel: string;
        };
    };
};

declare const ru: {
    storeFinder: {
        storeFinder: {
            openUntil: string;
            closed: string;
            back: string;
            call: string;
            getDirections: string;
            ariaLabelGetDirections: string;
            ariaLabelCountriesCount: string;
            listView: string;
            mapView: string;
            noStoresFound: string;
            storeHours: string;
            storeFeatures: string;
            storeFinder: string;
            storesFoundTitle: string;
            storesFound: string;
            storesFound_other: string;
            fromStoresFound: string;
            fromStoresFound_other: string;
            findStore: string;
            findStoreBy: string;
            useMyLocation: string;
            viewAllStores: string;
            contactUs: string;
            searchBox: string;
            backToList: string;
            noStoresMessage: string;
            geolocationNotEnabled: string;
            searchNearestStores: string;
            searchBoxLabel: string;
        };
    };
};

declare const zh: {
    storeFinder: {
        storeFinder: {
            openUntil: string;
            closed: string;
            back: string;
            call: string;
            getDirections: string;
            ariaLabelGetDirections: string;
            ariaLabelCountriesCount: string;
            listView: string;
            mapView: string;
            noStoresFound: string;
            storeHours: string;
            storeFeatures: string;
            storeFinder: string;
            storesFoundTitle: string;
            storesFound: string;
            storesFound_other: string;
            fromStoresFound: string;
            fromStoresFound_other: string;
            findStore: string;
            findStoreBy: string;
            useMyLocation: string;
            viewAllStores: string;
            contactUs: string;
            searchBox: string;
            backToList: string;
            noStoresMessage: string;
            geolocationNotEnabled: string;
            searchNearestStores: string;
            searchBoxLabel: string;
        };
    };
};

declare const zh_TW: {
    storeFinder: {
        storeFinder: {
            openUntil: string;
            closed: string;
            back: string;
            call: string;
            getDirections: string;
            ariaLabelGetDirections: string;
            ariaLabelCountriesCount: string;
            listView: string;
            mapView: string;
            noStoresFound: string;
            storeHours: string;
            storeFeatures: string;
            storeFinder: string;
            storesFoundTitle: string;
            storesFound: string;
            storesFound_other: string;
            fromStoresFound: string;
            fromStoresFound_other: string;
            findStore: string;
            findStoreBy: string;
            useMyLocation: string;
            viewAllStores: string;
            contactUs: string;
            searchBox: string;
            backToList: string;
            noStoresMessage: string;
            geolocationNotEnabled: string;
            searchNearestStores: string;
            searchBoxLabel: string;
        };
    };
};

declare const storeFinderTranslationChunksConfig: TranslationChunksConfig;

export { storeFinderTranslationChunksConfig, cs as storeFinderTranslationsCs, de as storeFinderTranslationsDe, en as storeFinderTranslationsEn, es as storeFinderTranslationsEs, es_CO as storeFinderTranslationsEs_CO, fr as storeFinderTranslationsFr, hi as storeFinderTranslationsHi, hu as storeFinderTranslationsHu, id as storeFinderTranslationsId, it as storeFinderTranslationsIt, ja as storeFinderTranslationsJa, ko as storeFinderTranslationsKo, pl as storeFinderTranslationsPl, pt as storeFinderTranslationsPt, ru as storeFinderTranslationsRu, zh as storeFinderTranslationsZh, zh_TW as storeFinderTranslationsZh_TW };
