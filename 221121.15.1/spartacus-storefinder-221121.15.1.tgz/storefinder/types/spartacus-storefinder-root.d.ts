import { LayoutConfig } from '@spartacus/storefront';
import { RoutingConfig, PointOfService, SearchConfig, GeoPoint, CmsConfig } from '@spartacus/core';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';

declare const GOOGLE_MAPS_DEVELOPMENT_KEY_CONFIG = "cx-development";

declare const defaultStoreFinderLayoutConfig: LayoutConfig;

declare const defaultStoreFinderRoutingConfig: RoutingConfig;

declare enum StoreFinderOutlets {
    PREFERRED_STORE = "cx-pick-up-in-store-make-my-store"
}
interface StoreEntities {
    pointOfServices?: Array<PointOfService>;
}

/**
 * Store the Point of Service a user wants to collect a product from before it is added to the cart.
 */
declare abstract class StoreFinderFacade {
    abstract getStoresLoading(): Observable<boolean>;
    abstract getStoresLoaded(): Observable<boolean>;
    abstract getFindStoresEntities(): Observable<StoreEntities>;
    abstract getViewAllStoresLoading(): Observable<boolean>;
    abstract getViewAllStoresEntities(): Observable<StoreEntities>;
    abstract findStoresAction(queryText: string, searchConfig?: SearchConfig, longitudeLatitude?: GeoPoint, countryIsoCode?: string, useMyLocation?: boolean, radius?: number): void;
    abstract viewAllStores(): void;
    abstract viewStoreById(storeId: string): void;
    abstract callFindStoresAction(routeParams: {
        [key: string]: string;
    }): void;
    /**
     * @deprecated Please use StoreLocationService instead,
     */
    abstract getStoreLatitude(location: PointOfService): number | undefined;
    /**
     * @deprecated Please use StoreLocationService instead,
     */
    abstract getStoreLongitude(location: PointOfService): number | undefined;
    /**
     * @deprecated Please use StoreLocationService instead,
     */
    abstract getDirections(location: PointOfService): string;
    abstract getFindStoreEntityById(): Observable<StoreEntities>;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StoreFinderFacade>;
}

declare const STORE_FINDER_FEATURE = "storeFinder";

declare function defaultStoreFinderComponentsConfig(): CmsConfig;
declare class StoreFinderRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StoreFinderRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StoreFinderRootModule>;
}

export { GOOGLE_MAPS_DEVELOPMENT_KEY_CONFIG, STORE_FINDER_FEATURE, StoreFinderFacade, StoreFinderOutlets, StoreFinderRootModule, defaultStoreFinderComponentsConfig, defaultStoreFinderLayoutConfig, defaultStoreFinderRoutingConfig };
export type { StoreEntities };
