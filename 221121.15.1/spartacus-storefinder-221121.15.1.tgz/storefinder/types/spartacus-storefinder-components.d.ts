import * as i6 from '@spartacus/storefinder/core';
import { StoreFinderService, GoogleMapRendererService, StoreFinderConfig, StoreFinderSearchQuery } from '@spartacus/storefinder/core';
import * as i0 from '@angular/core';
import { OnInit, EventEmitter, OnChanges, ElementRef, SimpleChanges, OnDestroy } from '@angular/core';
import * as i5 from '@spartacus/core';
import { PointOfService, WeekdayOpeningDay, GeoPoint, PaginationModel, SearchConfig, RoutingService } from '@spartacus/core';
import * as i3 from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { StoreFinderOutlets } from '@spartacus/storefinder/root';
import * as i4 from '@spartacus/storefront';
import { ICON_TYPE } from '@spartacus/storefront';
import * as i2 from '@angular/forms';
import { UntypedFormControl } from '@angular/forms';
import * as i1 from '@angular/common';

declare class AbstractStoreItemComponent {
    protected storeFinderService: StoreFinderService;
    location: any;
    constructor(storeFinderService: StoreFinderService);
    getDirections(location: any): string;
    getFormattedStoreAddress(addressParts: string[]): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbstractStoreItemComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AbstractStoreItemComponent, never, never, { "location": { "alias": "location"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ScheduleComponent implements OnInit {
    location: PointOfService;
    weekDays: WeekdayOpeningDay[];
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScheduleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScheduleComponent, "cx-schedule", never, { "location": { "alias": "location"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class StoreFinderGridComponent implements OnInit {
    private storeFinderService;
    private route;
    defaultLocation: GeoPoint;
    country: string;
    region: string;
    locations$: any;
    isLoading$: Observable<boolean>;
    constructor(storeFinderService: StoreFinderService, route: ActivatedRoute);
    ngOnInit(): void;
    protected findStores(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderGridComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreFinderGridComponent, "cx-store-finder-grid", never, {}, {}, never, never, true, never>;
}

declare class StoreFinderHeaderComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreFinderHeaderComponent, "cx-store-finder-header", never, {}, {}, never, never, true, never>;
}

declare class StoreFinderListItemComponent extends AbstractStoreItemComponent {
    protected storeFinderService: StoreFinderService;
    locationIndex: number | null;
    listOrderLabel: any;
    displayDistance: boolean;
    useClickEvent: boolean;
    storeItemClick: EventEmitter<number>;
    readonly StoreFinderOutlets: typeof StoreFinderOutlets;
    constructor(storeFinderService: StoreFinderService);
    handleStoreItemClick(): void;
    onKey(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderListItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreFinderListItemComponent, "cx-store-finder-list-item", never, { "locationIndex": { "alias": "locationIndex"; "required": false; }; "listOrderLabel": { "alias": "listOrderLabel"; "required": false; }; "displayDistance": { "alias": "displayDistance"; "required": false; }; "useClickEvent": { "alias": "useClickEvent"; "required": false; }; }, { "storeItemClick": "storeItemClick"; }, never, never, true, never>;
}

declare class StoreFinderMapComponent implements OnChanges {
    private googleMapRendererService;
    mapElement: ElementRef;
    locations: any[];
    selectedStoreItem: EventEmitter<number>;
    constructor(googleMapRendererService: GoogleMapRendererService);
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Sets the center of the map to the given location
     * @param latitude latitude of the new center
     * @param longitude longitude of the new center
     */
    centerMap(latitude: number, longitude: number): void;
    renderMap(): void;
    private selectStoreItemClickHandle;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderMapComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreFinderMapComponent, "cx-store-finder-map", never, { "locations": { "alias": "locations"; "required": false; }; }, { "selectedStoreItem": "selectedStoreItem"; }, never, never, true, never>;
}

declare class StoreFinderPaginationDetailsComponent {
    pagination: PaginationModel;
    constructor();
    getResultsPerPage(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderPaginationDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreFinderPaginationDetailsComponent, "cx-store-finder-pagination-details", never, { "pagination": { "alias": "pagination"; "required": false; }; }, {}, never, never, true, never>;
}

declare enum LocationDisplayMode {
    LIST_VIEW = "listView",
    MAP_VIEW = "mapView"
}

declare class StoreFinderListComponent {
    private storeFinderService;
    private document;
    locations: any;
    useMylocation: boolean;
    storeMap: StoreFinderMapComponent;
    selectedStore: PointOfService;
    selectedStoreIndex: number;
    isDetailsModeVisible: boolean;
    storeDetails: PointOfService;
    iconTypes: typeof ICON_TYPE;
    displayModes: typeof LocationDisplayMode;
    activeDisplayMode: LocationDisplayMode;
    readonly backButton: i0.Signal<ElementRef<HTMLButtonElement>>;
    private featureConfigService;
    constructor(storeFinderService: StoreFinderService, document: any);
    centerStoreOnMapByIndex(index: number, location: PointOfService): void;
    selectStoreItemList(index: number): void;
    showStoreDetails(location: PointOfService): void;
    hideStoreDetails(): void;
    setDisplayMode(mode: LocationDisplayMode): void;
    isDisplayModeActive(mode: LocationDisplayMode): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreFinderListComponent, "cx-store-finder-list", never, { "locations": { "alias": "locations"; "required": false; }; "useMylocation": { "alias": "useMylocation"; "required": false; }; }, {}, never, never, true, never>;
}

declare class StoreFinderSearchResultComponent implements OnInit, OnDestroy {
    private storeFinderService;
    private route;
    protected config: StoreFinderConfig;
    locations: any;
    subscription: Subscription;
    useMyLocation: boolean;
    countryCode: string;
    searchConfig: SearchConfig;
    radius: number;
    searchQuery: StoreFinderSearchQuery;
    geolocation: GeoPoint;
    locations$: Observable<any>;
    isLoading$: Observable<any>;
    constructor(storeFinderService: StoreFinderService, route: ActivatedRoute, config: StoreFinderConfig);
    ngOnInit(): void;
    ngOnDestroy(): void;
    viewPage(pageNumber: number): void;
    private initialize;
    private parseParameters;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderSearchResultComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreFinderSearchResultComponent, "cx-store-finder-search-result", never, {}, {}, never, never, true, never>;
}

declare class StoreFinderSearchComponent {
    private routingService;
    searchBox: UntypedFormControl;
    iconTypes: typeof ICON_TYPE;
    constructor(routingService: RoutingService);
    findStores(address: string): void;
    viewStoresWithMyLoc(): void;
    onKey(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderSearchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreFinderSearchComponent, "cx-store-finder-search", never, {}, {}, never, never, true, never>;
}

declare class StoreFinderStoreDescriptionComponent extends AbstractStoreItemComponent {
    protected storeFinderService: StoreFinderService;
    location: PointOfService;
    disableMap: boolean;
    constructor(storeFinderService: StoreFinderService);
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderStoreDescriptionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreFinderStoreDescriptionComponent, "cx-store-finder-store-description", never, { "location": { "alias": "location"; "required": false; }; "disableMap": { "alias": "disableMap"; "required": false; }; }, {}, never, never, true, never>;
}

declare class StoreFinderStoresCountComponent implements OnInit {
    private storeFinderService;
    protected routingService: RoutingService;
    locations$: Observable<any>;
    isLoading$: Observable<boolean>;
    constructor(storeFinderService: StoreFinderService);
    ngOnInit(): void;
    navigateToLocation(isoCode: string, event?: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderStoresCountComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreFinderStoresCountComponent, "cx-store-finder-stores-count", never, {}, {}, never, never, true, never>;
}

declare class StoreFinderComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreFinderComponent, "cx-store-finder", never, {}, {}, never, never, true, never>;
}

declare class StoreFinderStoreComponent implements OnInit {
    private storeFinderService;
    private route;
    private routingService;
    location$: Observable<any>;
    isLoading$: Observable<any>;
    iconTypes: typeof ICON_TYPE;
    location: PointOfService;
    disableMap: boolean;
    constructor(storeFinderService: StoreFinderService, route: ActivatedRoute, routingService: RoutingService);
    ngOnInit(): void;
    requestStoresData(): void;
    goBack(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderStoreComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreFinderStoreComponent, "cx-store-finder-store", never, { "location": { "alias": "location"; "required": false; }; "disableMap": { "alias": "disableMap"; "required": false; }; }, {}, never, never, true, never>;
}

declare class StoreFinderComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StoreFinderComponentsModule, never, [typeof i1.CommonModule, typeof i2.ReactiveFormsModule, typeof i3.RouterModule, typeof i4.ListNavigationModule, typeof i4.SpinnerModule, typeof i5.UrlModule, typeof i6.StoreFinderCoreModule, typeof i5.I18nModule, typeof i4.IconModule, typeof i4.OutletModule, typeof i5.FeaturesConfigModule, typeof i4.BtnLikeLinkModule, typeof StoreFinderSearchComponent, typeof StoreFinderListComponent, typeof StoreFinderMapComponent, typeof StoreFinderListItemComponent, typeof StoreFinderStoresCountComponent, typeof StoreFinderGridComponent, typeof StoreFinderStoreDescriptionComponent, typeof ScheduleComponent, typeof StoreFinderHeaderComponent, typeof StoreFinderSearchResultComponent, typeof StoreFinderComponent, typeof StoreFinderPaginationDetailsComponent, typeof StoreFinderStoreComponent], [typeof ScheduleComponent, typeof StoreFinderComponent, typeof StoreFinderGridComponent, typeof StoreFinderHeaderComponent, typeof StoreFinderListItemComponent, typeof StoreFinderMapComponent, typeof StoreFinderPaginationDetailsComponent, typeof StoreFinderSearchComponent, typeof StoreFinderSearchResultComponent, typeof StoreFinderListComponent, typeof StoreFinderStoreDescriptionComponent, typeof StoreFinderStoresCountComponent, typeof StoreFinderStoreComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StoreFinderComponentsModule>;
}

export { AbstractStoreItemComponent, ScheduleComponent, StoreFinderComponent, StoreFinderComponentsModule, StoreFinderGridComponent, StoreFinderHeaderComponent, StoreFinderListComponent, StoreFinderListItemComponent, StoreFinderMapComponent, StoreFinderPaginationDetailsComponent, StoreFinderSearchComponent, StoreFinderSearchResultComponent, StoreFinderStoreComponent, StoreFinderStoreDescriptionComponent, StoreFinderStoresCountComponent };
