import * as i0 from '@angular/core';
import { Injectable, NgModule } from '@angular/core';
import { facadeFactory, provideDefaultConfig, provideDefaultConfigFactory } from '@spartacus/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const GOOGLE_MAPS_DEVELOPMENT_KEY_CONFIG = 'cx-development';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultStoreFinderLayoutConfig = {
    layoutSlots: {
        StoreFinderPageTemplate: {
            slots: ['MiddleContent', 'SideContent'],
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 * SPDX-License-Identifier: Apache-2.0Brea
 */
const defaultStoreFinderRoutingConfig = {
    routing: {
        routes: {
            storeFinder: {
                paths: ['store-finder'],
            },
            storeFinderFind: {
                paths: ['store-finder/find'],
            },
            storeFinderViewAll: {
                paths: ['store-finder/view-all'],
            },
            storeFinderCountry: {
                paths: ['store-finder/country/:country'],
            },
            storeFinderRegion: {
                paths: ['store-finder/country/:country/region/:region'],
            },
            storeFinderStore: {
                paths: [
                    'store-finder/country/:country/region/:region/:store',
                    'store-finder/country/:country/:store',
                ],
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const STORE_FINDER_FEATURE = 'storeFinder';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Store the Point of Service a user wants to collect a product from before it is added to the cart.
 */
class StoreFinderFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: StoreFinderFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: StoreFinderFacade, providedIn: 'root', useFactory: () => facadeFactory({
            // @ts-ignore: Deprecated methods will be removed with next major release
            facade: StoreFinderFacade,
            feature: STORE_FINDER_FEATURE,
            methods: [
                'getStoresLoading',
                'getStoresLoaded',
                'getFindStoresEntities',
                'getViewAllStoresLoading',
                'getViewAllStoresEntities',
                'findStoresAction',
                'viewAllStores',
                'viewStoreById',
                'callFindStoresAction',
                'getFindStoreEntityById',
            ],
            async: true,
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: StoreFinderFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        // @ts-ignore: Deprecated methods will be removed with next major release
                        facade: StoreFinderFacade,
                        feature: STORE_FINDER_FEATURE,
                        methods: [
                            'getStoresLoading',
                            'getStoresLoaded',
                            'getFindStoresEntities',
                            'getViewAllStoresLoading',
                            'getViewAllStoresEntities',
                            'findStoresAction',
                            'viewAllStores',
                            'viewStoreById',
                            'callFindStoresAction',
                            'getFindStoreEntityById',
                        ],
                        async: true,
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var StoreFinderOutlets;
(function (StoreFinderOutlets) {
    StoreFinderOutlets["PREFERRED_STORE"] = "cx-pick-up-in-store-make-my-store";
})(StoreFinderOutlets || (StoreFinderOutlets = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
// TODO: Inline this factory when we start releasing Ivy compiled libraries
function defaultStoreFinderComponentsConfig() {
    const config = {
        featureModules: {
            [STORE_FINDER_FEATURE]: {
                cmsComponents: ['StoreFinderComponent'],
            },
        },
    };
    return config;
}
class StoreFinderRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: StoreFinderRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: StoreFinderRootModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: StoreFinderRootModule, providers: [
            provideDefaultConfig(defaultStoreFinderLayoutConfig),
            provideDefaultConfig(defaultStoreFinderRoutingConfig),
            provideDefaultConfigFactory(defaultStoreFinderComponentsConfig),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: StoreFinderRootModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    providers: [
                        provideDefaultConfig(defaultStoreFinderLayoutConfig),
                        provideDefaultConfig(defaultStoreFinderRoutingConfig),
                        provideDefaultConfigFactory(defaultStoreFinderComponentsConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { GOOGLE_MAPS_DEVELOPMENT_KEY_CONFIG, STORE_FINDER_FEATURE, StoreFinderFacade, StoreFinderOutlets, StoreFinderRootModule, defaultStoreFinderComponentsConfig, defaultStoreFinderLayoutConfig, defaultStoreFinderRoutingConfig };
//# sourceMappingURL=spartacus-storefinder-root.mjs.map
