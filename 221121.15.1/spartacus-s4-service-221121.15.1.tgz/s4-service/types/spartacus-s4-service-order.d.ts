import * as i0 from '@angular/core';
import { OnInit, OnDestroy } from '@angular/core';
import * as i2 from '@spartacus/storefront';
import { OutletContextData, Card } from '@spartacus/storefront';
import * as i1 from '@angular/common';
import * as _spartacus_core from '@spartacus/core';
import { TranslationService, GlobalMessageService, RoutingService, SemanticPathService } from '@spartacus/core';
import * as _spartacus_order_root from '@spartacus/order/root';
import { Order } from '@spartacus/order/root';
import * as _spartacus_s4_service_root from '@spartacus/s4-service/root';
import { CheckoutServiceSchedulePickerService, ServiceDateTime, CancelServiceOrderFacade, RescheduleServiceOrderFacade, S4ServiceDeliveryModeConfig } from '@spartacus/s4-service/root';
import * as rxjs from 'rxjs';
import { Subscription, Observable, Subject } from 'rxjs';
import * as i4 from '@angular/forms';
import { FormBuilder, FormGroup } from '@angular/forms';
import * as i5 from '@angular/router';
import { GuardResult, Router } from '@angular/router';
import { OrderDetailsService, OrderDetailActionsComponent, OrderOverviewComponentService } from '@spartacus/order/components';
import * as _spartacus_cart_base_root from '@spartacus/cart/base/root';
import { CartOutlets, DeliveryMode } from '@spartacus/cart/base/root';

declare class ServiceDetailsCardComponent implements OnInit, OnDestroy {
    protected translationService: TranslationService;
    protected checkoutServiceSchedulePickerService: CheckoutServiceSchedulePickerService;
    protected orderOutlet: OutletContextData<any>;
    protected subscription: Subscription;
    order: Order;
    ngOnInit(): void;
    showServiceDetails(): boolean;
    getServiceDetailsCard(scheduledAt: ServiceDateTime | undefined): Observable<Card>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ServiceDetailsCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ServiceDetailsCardComponent, "cx-card-service-details", never, {}, {}, never, never, true, never>;
}

declare class ServiceDetailsCardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ServiceDetailsCardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ServiceDetailsCardModule, never, [typeof i2.CardModule, typeof i1.CommonModule, typeof _spartacus_core.I18nModule, typeof ServiceDetailsCardComponent], [typeof ServiceDetailsCardComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ServiceDetailsCardModule>;
}

declare class CancelServiceOrderComponent {
    protected orderDetailsService: OrderDetailsService;
    protected cancelServiceOrderFacade: CancelServiceOrderFacade;
    protected fb: FormBuilder;
    protected globalMessageService: GlobalMessageService;
    protected routingService: RoutingService;
    order$: Observable<any>;
    characterLeft: number;
    form: FormGroup;
    cancelServiceOrder(): void;
    protected onError(): void;
    updateCharacterLeft(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CancelServiceOrderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CancelServiceOrderComponent, "cx-cancel-service-order", never, {}, {}, never, never, true, never>;
}

declare class CancelServiceOrderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CancelServiceOrderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CancelServiceOrderModule, never, [typeof i1.CommonModule, typeof _spartacus_core.I18nModule, typeof i2.SpinnerModule, typeof i2.DatePickerModule, typeof i4.ReactiveFormsModule, typeof _spartacus_core.UrlModule, typeof i5.RouterModule, typeof CancelServiceOrderComponent], [typeof CancelServiceOrderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CancelServiceOrderModule>;
}

declare class CancelServiceOrderHeadlineComponent {
    protected orderDetailsService: OrderDetailsService;
    order$: rxjs.Observable<{
        entries: _spartacus_cart_base_root.OrderEntry[];
        appliedOrderPromotions?: _spartacus_cart_base_root.PromotionResult[];
        appliedProductPromotions?: _spartacus_cart_base_root.PromotionResult[];
        appliedVouchers?: _spartacus_cart_base_root.Voucher[];
        calculated?: boolean;
        code?: string;
        consignments?: _spartacus_order_root.Consignment[];
        costCenter?: _spartacus_core.CostCenter;
        created?: Date;
        deliveryAddress?: _spartacus_core.Address;
        deliveryCost?: _spartacus_core.Price;
        deliveryItemsQuantity?: number;
        deliveryMode?: _spartacus_cart_base_root.DeliveryMode;
        deliveryOrderGroups?: _spartacus_cart_base_root.DeliveryOrderEntryGroup[];
        deliveryStatus?: string;
        deliveryStatusDisplay?: string;
        guestCustomer?: boolean;
        guid?: string;
        net?: boolean;
        orderDiscounts?: _spartacus_core.Price;
        orgCustomer?: _spartacus_core.B2BUser;
        orgUnit?: _spartacus_core.B2BUnit;
        paymentInfo?: _spartacus_core.PaymentDetails;
        pickupItemsQuantity?: number;
        pickupOrderGroups?: _spartacus_cart_base_root.PickupOrderEntryGroup[];
        productDiscounts?: _spartacus_core.Price;
        purchaseOrderNumber?: string;
        site?: string;
        status?: string;
        statusDisplay?: string;
        store?: string;
        subTotal?: _spartacus_core.Price;
        totalDiscounts?: _spartacus_core.Price;
        totalItems?: number;
        totalPrice?: _spartacus_core.Price;
        totalPriceWithTax?: _spartacus_core.Price;
        totalTax?: _spartacus_core.Price;
        unconsignedEntries?: _spartacus_cart_base_root.OrderEntry[];
        user?: _spartacus_core.Principal;
        returnable?: boolean;
        cancellable?: boolean;
        sapQuoteCode?: string;
        servicedAt?: _spartacus_s4_service_root.ServiceDateTime;
        serviceCancellable?: _spartacus_s4_service_root.serviceCancellable;
        serviceReschedulable?: boolean;
    }>;
    readonly CartOutlets: typeof CartOutlets;
    static ɵfac: i0.ɵɵFactoryDeclaration<CancelServiceOrderHeadlineComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CancelServiceOrderHeadlineComponent, "cx-cancel-service-order-headline", never, {}, {}, never, never, true, never>;
}

declare class CancelServiceOrderHeadlineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CancelServiceOrderHeadlineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CancelServiceOrderHeadlineModule, never, [typeof i1.CommonModule, typeof i5.RouterModule, typeof _spartacus_core.I18nModule, typeof i2.CardModule, typeof _spartacus_core.UrlModule, typeof i2.PromotionsModule, typeof i2.IconModule, typeof i2.OutletModule, typeof CancelServiceOrderHeadlineComponent], [typeof CancelServiceOrderHeadlineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CancelServiceOrderHeadlineModule>;
}

declare class RescheduleServiceOrderComponent implements OnInit, OnDestroy {
    protected orderDetailsService: OrderDetailsService;
    protected rescheduleServiceOrderFacade: RescheduleServiceOrderFacade;
    protected routingService: RoutingService;
    protected globalMessageService: GlobalMessageService;
    protected fb: FormBuilder;
    protected checkoutServiceSchedulePickerService: CheckoutServiceSchedulePickerService;
    readonly CartOutlets: typeof CartOutlets;
    dateTime: ServiceDateTime;
    order$: Observable<{
        entries: _spartacus_cart_base_root.OrderEntry[];
        appliedOrderPromotions?: _spartacus_cart_base_root.PromotionResult[];
        appliedProductPromotions?: _spartacus_cart_base_root.PromotionResult[];
        appliedVouchers?: _spartacus_cart_base_root.Voucher[];
        calculated?: boolean;
        code?: string;
        consignments?: _spartacus_order_root.Consignment[];
        costCenter?: _spartacus_core.CostCenter;
        created?: Date;
        deliveryAddress?: _spartacus_core.Address;
        deliveryCost?: _spartacus_core.Price;
        deliveryItemsQuantity?: number;
        deliveryMode?: _spartacus_cart_base_root.DeliveryMode;
        deliveryOrderGroups?: _spartacus_cart_base_root.DeliveryOrderEntryGroup[];
        deliveryStatus?: string;
        deliveryStatusDisplay?: string;
        guestCustomer?: boolean;
        guid?: string;
        net?: boolean;
        orderDiscounts?: _spartacus_core.Price;
        orgCustomer?: _spartacus_core.B2BUser;
        orgUnit?: _spartacus_core.B2BUnit;
        paymentInfo?: _spartacus_core.PaymentDetails;
        pickupItemsQuantity?: number;
        pickupOrderGroups?: _spartacus_cart_base_root.PickupOrderEntryGroup[];
        productDiscounts?: _spartacus_core.Price;
        purchaseOrderNumber?: string;
        site?: string;
        status?: string;
        statusDisplay?: string;
        store?: string;
        subTotal?: _spartacus_core.Price;
        totalDiscounts?: _spartacus_core.Price;
        totalItems?: number;
        totalPrice?: _spartacus_core.Price;
        totalPriceWithTax?: _spartacus_core.Price;
        totalTax?: _spartacus_core.Price;
        unconsignedEntries?: _spartacus_cart_base_root.OrderEntry[];
        user?: _spartacus_core.Principal;
        returnable?: boolean;
        cancellable?: boolean;
        sapQuoteCode?: string;
        servicedAt?: ServiceDateTime;
        serviceCancellable?: _spartacus_s4_service_root.serviceCancellable;
        serviceReschedulable?: boolean;
    }>;
    orderCode: string;
    protected subscription: Subject<void>;
    minServiceDate$: Observable<string>;
    scheduleTimes$: Observable<string[]>;
    form: FormGroup;
    ngOnInit(): void;
    initializeForm(order: Order): void;
    setScheduleTime(event: Event): void;
    rescheduleServiceOrder(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RescheduleServiceOrderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RescheduleServiceOrderComponent, "cx-reschedule-service-order", never, {}, {}, never, never, true, never>;
}

declare class RescheduleServiceOrderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RescheduleServiceOrderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RescheduleServiceOrderModule, never, [typeof i1.CommonModule, typeof i2.CardModule, typeof _spartacus_core.I18nModule, typeof i2.OutletModule, typeof _spartacus_core.UrlModule, typeof i5.RouterModule, typeof i2.SpinnerModule, typeof i2.DatePickerModule, typeof i4.ReactiveFormsModule, typeof i2.FormRequiredAsterisksComponent, typeof i2.FormRequiredLegendComponent, typeof RescheduleServiceOrderComponent], [typeof RescheduleServiceOrderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RescheduleServiceOrderModule>;
}

declare class S4ServiceOrderDetailActionsComponent extends OrderDetailActionsComponent implements OnInit {
    protected checkoutServiceSchedulePickerService: CheckoutServiceSchedulePickerService;
    protected globalMessageService: GlobalMessageService;
    /**
     * @deprecated since 221121.1 - Displaying the individual action buttons will depend on their boolean flags from API response.
     */
    displayActions$: Observable<boolean>;
    ngOnInit(): void;
    /**
     * @deprecated since 221121.1 - Displaying the individual action buttons will depend on their boolean flags from API response.
     * Displaying notification for a service not amendable will be carried out by 'displayServiceMessage' instead.
     */
    protected checkServiceStatus(order: Order): boolean;
    protected displayServiceMessage(order: Order): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<S4ServiceOrderDetailActionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<S4ServiceOrderDetailActionsComponent, "cx-s4-service-order-detail-actions", never, {}, {}, never, never, true, never>;
}

declare class S4ServiceOrderDetailActionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<S4ServiceOrderDetailActionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<S4ServiceOrderDetailActionsModule, never, [typeof i1.CommonModule, typeof _spartacus_core.I18nModule, typeof i5.RouterModule, typeof _spartacus_core.UrlModule, typeof i2.BtnLikeLinkModule, typeof S4ServiceOrderDetailActionsComponent], [typeof S4ServiceOrderDetailActionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<S4ServiceOrderDetailActionsModule>;
}

declare class S4ServiceComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<S4ServiceComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<S4ServiceComponentsModule, never, [typeof ServiceDetailsCardModule, typeof CancelServiceOrderModule, typeof CancelServiceOrderHeadlineModule, typeof RescheduleServiceOrderModule, typeof S4ServiceOrderDetailActionsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<S4ServiceComponentsModule>;
}

declare class S4ServiceOrderCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<S4ServiceOrderCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<S4ServiceOrderCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<S4ServiceOrderCoreModule>;
}

declare class S4ServiceOrderOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<S4ServiceOrderOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<S4ServiceOrderOccModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<S4ServiceOrderOccModule>;
}

declare class S4ServiceOrderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<S4ServiceOrderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<S4ServiceOrderModule, never, [typeof S4ServiceComponentsModule, typeof S4ServiceOrderCoreModule, typeof S4ServiceOrderOccModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<S4ServiceOrderModule>;
}

declare class ServiceOrderGuard {
    protected orderDetailsService: OrderDetailsService;
    protected globalMessageService: GlobalMessageService;
    canActivate(): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ServiceOrderGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ServiceOrderGuard>;
}

declare class CancelServiceOrderGuard {
    protected orderDetailsService: OrderDetailsService;
    protected router: Router;
    protected semanticPathService: SemanticPathService;
    canActivate(): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CancelServiceOrderGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CancelServiceOrderGuard>;
}

declare class ServiceOrderOverviewComponentService extends OrderOverviewComponentService {
    protected config: S4ServiceDeliveryModeConfig;
    shouldShowDeliveryMode(mode: DeliveryMode | undefined): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ServiceOrderOverviewComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ServiceOrderOverviewComponentService>;
}

export { CancelServiceOrderComponent, CancelServiceOrderGuard, CancelServiceOrderHeadlineComponent, CancelServiceOrderHeadlineModule, CancelServiceOrderModule, RescheduleServiceOrderComponent, RescheduleServiceOrderModule, S4ServiceComponentsModule, S4ServiceOrderDetailActionsComponent, S4ServiceOrderDetailActionsModule, S4ServiceOrderModule, ServiceDetailsCardComponent, ServiceDetailsCardModule, ServiceOrderGuard, ServiceOrderOverviewComponentService };
