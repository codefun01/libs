import * as i0 from '@angular/core';

declare class S4ServiceModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<S4ServiceModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<S4ServiceModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<S4ServiceModule>;
}

export { S4ServiceModule };
