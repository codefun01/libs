import { OccEndpoint, EventService, CmsConfig, RoutingConfig, QueryState, BaseSiteService, CxDatePipe } from '@spartacus/core';
import { DeliveryMode } from '@spartacus/cart/base/root';
import * as i0 from '@angular/core';
import { OnDestroy } from '@angular/core';
import { Subscription, Observable } from 'rxjs';
import * as i2 from '@angular/router';
import { CheckoutConfig, CheckoutEvent } from '@spartacus/checkout/base/root';
import { Order } from '@spartacus/order/root';

type ServiceDateTime = string;
interface ServiceDetails {
    scheduledAt?: ServiceDateTime;
}
interface ServiceOrderConfig {
    leadDays?: number;
    serviceScheduleTimes?: string[];
}
interface CancellationDetails {
    cancelReason?: string;
    cancellationRequestEntryInputs: CancellationRequestEntryInputs[];
}
interface CancellationRequestEntryInputs {
    orderEntryNumber?: number;
    quantity?: string[];
}
type serviceCancellable = boolean;

declare abstract class ServiceOrderConfiguration {
    serviceOrderConfiguration?: {
        leadDays?: number;
        serviceScheduleTimes?: string[];
    };
}
interface CheckoutServiceOrderOccEndpoints {
    /**
     * Sets the service details for the checkout cart
     */
    setServiceScheduleSlot?: string | OccEndpoint;
}
declare module '@spartacus/order/root' {
    interface Order {
        servicedAt?: ServiceDateTime;
        serviceCancellable?: serviceCancellable;
        serviceReschedulable?: boolean;
    }
}
declare module '@spartacus/checkout/base/root' {
    enum CheckoutStepType {
        SERVICE_DETAILS = "serviceDetails"
    }
    interface CheckoutState {
        servicedAt?: ServiceDateTime;
    }
}
declare abstract class S4ServiceDeliveryModeConfig {
    s4ServiceDeliveryMode?: DeliveryMode;
    static ɵfac: i0.ɵɵFactoryDeclaration<S4ServiceDeliveryModeConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<S4ServiceDeliveryModeConfig>;
}
declare module '@spartacus/core' {
    interface OccEndpoints extends CheckoutServiceOrderOccEndpoints {
    }
    interface BaseStore extends ServiceOrderConfiguration {
    }
}
declare module '@spartacus/core' {
    interface Config extends S4ServiceDeliveryModeConfig {
    }
}

declare class CheckoutServiceDetailsEventListener implements OnDestroy {
    protected eventService: EventService;
    protected subscriptions: Subscription;
    constructor(eventService: EventService);
    protected onServiceDetailsSet(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutServiceDetailsEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutServiceDetailsEventListener>;
}

declare class CheckoutServiceDetailsEventModule {
    constructor(_checkoutServiceDetailsEventListener: CheckoutServiceDetailsEventListener);
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutServiceDetailsEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutServiceDetailsEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutServiceDetailsEventModule>;
}

declare const S4_SERVICE_CMS_COMPONENTS: string[];
declare const S4_SERVICE_ORDER_CMS_COMPONENTS: string[];
declare function defaultS4ServiceComponentsConfig(): CmsConfig;
declare class S4ServiceRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<S4ServiceRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<S4ServiceRootModule, never, [typeof CheckoutServiceDetailsEventModule, typeof i2.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<S4ServiceRootModule>;
}

declare const S4_SERVICE_FEATURE = "s4-service";

declare const defaultServiceOrdersRoutingConfig: RoutingConfig;

declare const defaultServiceDetailsCheckoutConfig: CheckoutConfig;

/**
 * An abstract event for all the service details related events.
 */
declare abstract class CheckoutServiceDetailsEvent extends CheckoutEvent {
}
/**
 * Fired when the service details has been set
 */
declare class CheckoutServiceDetailsSetEvent extends CheckoutServiceDetailsEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutServiceDetailsSetEvent";
    /**
     * scheduled time and date
     */
    scheduledAt?: ServiceDateTime;
}

declare abstract class CheckoutServiceDetailsFacade {
    /**
     * Set service schedule DateTime for the cart
     */
    abstract setServiceScheduleSlot(scheduledAt: ServiceDateTime): Observable<unknown>;
    /**
     * Get the selected scheduled DateTime
     */
    abstract getSelectedServiceDetailsState(): Observable<QueryState<ServiceDateTime | undefined>>;
    /**
     * Get the name of products of type SERVICE in the active cart
     */
    abstract getServiceProducts(): Observable<string[]>;
    /**
     * Return whether cart has service products
     */
    abstract hasServiceItems(): Observable<boolean>;
    /**
     * Return whether cart has deliverable physical products
     */
    abstract hasNonServiceItems(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutServiceDetailsFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutServiceDetailsFacade>;
}

declare class CheckoutServiceSchedulePickerService {
    protected baseSiteService: BaseSiteService;
    protected datePipe: CxDatePipe;
    /**
     * Returns the minimum date for scheduling a service.
     * It is the current date + lead days from the base site configuration.
     */
    getMinDateForService(): Observable<string>;
    /**
     * Returns an array of service schedule times in HH:MM format (24-hour clock).
     * Example: ['08:00', '12:00', '16:00']
     */
    getScheduledServiceTimes(): Observable<string[]>;
    /**
     * Retrieves the Service Order Configuration object with lead days and service schedule times.
     * This method returns an observable since it depends on asynchronous data.
     */
    getServiceOrderConfiguration(): Observable<ServiceOrderConfig | undefined>;
    /**
     * Converts a date and time string into DateTime format including timezone offset.
     * @param date Date in YYYY-MM-DD format. Example: '2024-06-27'
     * @param time Time in HH:MM format (24-hour clock). Example: '14:30'
     * @returns String in DateTime format with timezone offset.
     * Example: 2024-06-27T14:30:00±HH:MM (based on your local timezone offset)
     */
    convertToDateTime(date: string, time: string): string;
    /**
     * Converts a DateTime string with timezone offset into a readable string format.
     * @param dateTime String in DateTime format with timezone offset.
     * Example: 2024-07-11T14:30:00+05:30
     * @returns Readable string format. Example: 11/07/2024, 02:30:00 PM
     */
    convertDateTimeToReadableString(dateTime: string): string;
    /**
     * Converts a string containing both date and time into an object with separate properties - date and time.
     * @param input Date and time in format `MM/DD/YYYY, HH:mm:ss`
     * @returns Object with date and time separately as { date: 'YYYY-MM-DD', time: 'HH:mm' }
     */
    getServiceDetailsFromDateTime(input: string): {
        date: string;
        time: string;
    };
    /**
     * Calculates the difference in hours between a scheduled date of a service and the current date.
     * @param dateTime The dateTime to check in string format.
     * @returns Number representing the difference in hours.
     */
    getHoursFromServiceSchedule(dateTime: string): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutServiceSchedulePickerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutServiceSchedulePickerService>;
}

declare abstract class CancelServiceOrderFacade {
    /**
     * Set service schedule DateTime for the order
     *
     * @param scheduledAt a service date time
     */
    abstract cancelService(orderCode: string, cancellationDetails: CancellationDetails): Observable<unknown>;
    /**
     * Retrieves order's details
     */
    abstract loadOrderDetails(): Observable<Order>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CancelServiceOrderFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CancelServiceOrderFacade>;
}

declare abstract class RescheduleServiceOrderFacade {
    /**
     * Set service schedule DateTime for the order
     *
     * @param scheduledAt a service date time
     */
    abstract rescheduleService(orderCode: string, scheduledAt: ServiceDateTime): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RescheduleServiceOrderFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RescheduleServiceOrderFacade>;
}

export { CancelServiceOrderFacade, CheckoutServiceDetailsEvent, CheckoutServiceDetailsEventListener, CheckoutServiceDetailsEventModule, CheckoutServiceDetailsFacade, CheckoutServiceDetailsSetEvent, CheckoutServiceSchedulePickerService, RescheduleServiceOrderFacade, S4ServiceDeliveryModeConfig, S4ServiceRootModule, S4_SERVICE_CMS_COMPONENTS, S4_SERVICE_FEATURE, S4_SERVICE_ORDER_CMS_COMPONENTS, ServiceOrderConfiguration, defaultS4ServiceComponentsConfig, defaultServiceDetailsCheckoutConfig, defaultServiceOrdersRoutingConfig };
export type { CancellationDetails, CancellationRequestEntryInputs, CheckoutServiceOrderOccEndpoints, ServiceDateTime, ServiceDetails, ServiceOrderConfig, serviceCancellable };
