import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    s4Service: {
        serviceOrderCheckout: {
            serviceDetails: string;
            serviceScheduleHeading: string;
            address: string;
            serviceLocationHeading: string;
            datePickerLabel: string;
            timePickerLabel: string;
            unknownError: string;
            productDeliveryOptions: string;
            serviceDeliveryOption: string;
            productDeliveryMethods: string;
            serviceDeliveryMethod: string;
        };
        cancelService: {
            heading: string;
            cancelReason: string;
            optional: string;
            action: string;
            back: string;
            Submit: string;
            cancelServiceSuccess: string;
            unknownError: string;
            ServiceTime: string;
            ServiceLocation: string;
            ServiceDate: string;
            SubmitRequest: string;
            serviceNotRcancelable: string;
            charactersLeft: string;
            Services: string;
        };
        rescheduleService: {
            actionButtonLabel: string;
            headerLabel: string;
            contentLabel: string;
            datePickerLabel: string;
            timePickerLabel: string;
            backButtonLabel: string;
            submitButtonLabel: string;
            note: string;
            unknownError: string;
            serviceNotReschedulable: string;
            serviceNotAmendable: string;
            rescheduleSuccess: string;
        };
    };
};

declare const de: {
    s4Service: {
        serviceOrderCheckout: {
            serviceDetails: string;
            serviceScheduleHeading: string;
            address: string;
            serviceLocationHeading: string;
            datePickerLabel: string;
            timePickerLabel: string;
            unknownError: string;
            productDeliveryOptions: string;
            serviceDeliveryOption: string;
            productDeliveryMethods: string;
            serviceDeliveryMethod: string;
        };
        cancelService: {
            heading: string;
            cancelReason: string;
            optional: string;
            action: string;
            back: string;
            Submit: string;
            cancelServiceSuccess: string;
            unknownError: string;
            ServiceTime: string;
            ServiceLocation: string;
            ServiceDate: string;
            SubmitRequest: string;
            serviceNotRcancelable: string;
            charactersLeft: string;
            Services: string;
        };
        rescheduleService: {
            actionButtonLabel: string;
            headerLabel: string;
            contentLabel: string;
            datePickerLabel: string;
            timePickerLabel: string;
            backButtonLabel: string;
            submitButtonLabel: string;
            note: string;
            unknownError: string;
            serviceNotReschedulable: string;
            serviceNotAmendable: string;
            rescheduleSuccess: string;
        };
    };
};

declare const en: {
    s4Service: {
        serviceOrderCheckout: {
            serviceDetails: string;
            serviceScheduleHeading: string;
            address: string;
            serviceLocationHeading: string;
            datePickerLabel: string;
            timePickerLabel: string;
            unknownError: string;
            productDeliveryOptions: string;
            serviceDeliveryOption: string;
            productDeliveryMethods: string;
            serviceDeliveryMethod: string;
        };
        cancelService: {
            heading: string;
            cancelReason: string;
            optional: string;
            action: string;
            back: string;
            Submit: string;
            cancelServiceSuccess: string;
            unknownError: string;
            ServiceTime: string;
            ServiceLocation: string;
            ServiceDate: string;
            SubmitRequest: string;
            serviceNotRcancelable: string;
            charactersLeft: string;
            Services: string;
        };
        rescheduleService: {
            actionButtonLabel: string;
            headerLabel: string;
            contentLabel: string;
            datePickerLabel: string;
            timePickerLabel: string;
            backButtonLabel: string;
            submitButtonLabel: string;
            note: string;
            unknownError: string;
            serviceNotReschedulable: string;
            serviceNotAmendable: string;
            rescheduleSuccess: string;
        };
    };
};

declare const es: {
    s4Service: {
        serviceOrderCheckout: {
            serviceDetails: string;
            serviceScheduleHeading: string;
            address: string;
            serviceLocationHeading: string;
            datePickerLabel: string;
            timePickerLabel: string;
            unknownError: string;
            productDeliveryOptions: string;
            serviceDeliveryOption: string;
            productDeliveryMethods: string;
            serviceDeliveryMethod: string;
        };
        cancelService: {
            heading: string;
            cancelReason: string;
            optional: string;
            action: string;
            back: string;
            Submit: string;
            cancelServiceSuccess: string;
            unknownError: string;
            ServiceTime: string;
            ServiceLocation: string;
            ServiceDate: string;
            SubmitRequest: string;
            serviceNotRcancelable: string;
            charactersLeft: string;
            Services: string;
        };
        rescheduleService: {
            actionButtonLabel: string;
            headerLabel: string;
            contentLabel: string;
            datePickerLabel: string;
            timePickerLabel: string;
            backButtonLabel: string;
            submitButtonLabel: string;
            note: string;
            unknownError: string;
            serviceNotReschedulable: string;
            serviceNotAmendable: string;
            rescheduleSuccess: string;
        };
    };
};

declare const es_CO: {
    s4Service: {
        serviceOrderCheckout: {
            serviceDetails: string;
            serviceScheduleHeading: string;
            address: string;
            serviceLocationHeading: string;
            datePickerLabel: string;
            timePickerLabel: string;
            unknownError: string;
            productDeliveryOptions: string;
            serviceDeliveryOption: string;
            productDeliveryMethods: string;
            serviceDeliveryMethod: string;
        };
        cancelService: {
            heading: string;
            cancelReason: string;
            optional: string;
            action: string;
            back: string;
            Submit: string;
            cancelServiceSuccess: string;
            unknownError: string;
            ServiceTime: string;
            ServiceLocation: string;
            ServiceDate: string;
            SubmitRequest: string;
            serviceNotRcancelable: string;
            charactersLeft: string;
            Services: string;
        };
        rescheduleService: {
            actionButtonLabel: string;
            headerLabel: string;
            contentLabel: string;
            datePickerLabel: string;
            timePickerLabel: string;
            backButtonLabel: string;
            submitButtonLabel: string;
            note: string;
            unknownError: string;
            serviceNotReschedulable: string;
            serviceNotAmendable: string;
            rescheduleSuccess: string;
        };
    };
};

declare const fr: {
    s4Service: {
        serviceOrderCheckout: {
            serviceDetails: string;
            serviceScheduleHeading: string;
            address: string;
            serviceLocationHeading: string;
            datePickerLabel: string;
            timePickerLabel: string;
            unknownError: string;
            productDeliveryOptions: string;
            serviceDeliveryOption: string;
            productDeliveryMethods: string;
            serviceDeliveryMethod: string;
        };
        cancelService: {
            heading: string;
            cancelReason: string;
            optional: string;
            action: string;
            back: string;
            Submit: string;
            cancelServiceSuccess: string;
            unknownError: string;
            ServiceTime: string;
            ServiceLocation: string;
            ServiceDate: string;
            SubmitRequest: string;
            serviceNotRcancelable: string;
            charactersLeft: string;
            Services: string;
        };
        rescheduleService: {
            actionButtonLabel: string;
            headerLabel: string;
            contentLabel: string;
            datePickerLabel: string;
            timePickerLabel: string;
            backButtonLabel: string;
            submitButtonLabel: string;
            note: string;
            unknownError: string;
            serviceNotReschedulable: string;
            serviceNotAmendable: string;
            rescheduleSuccess: string;
        };
    };
};

declare const hi: {
    s4Service: {
        serviceOrderCheckout: {
            serviceDetails: string;
            serviceScheduleHeading: string;
            address: string;
            serviceLocationHeading: string;
            datePickerLabel: string;
            timePickerLabel: string;
            unknownError: string;
            productDeliveryOptions: string;
            serviceDeliveryOption: string;
            productDeliveryMethods: string;
            serviceDeliveryMethod: string;
        };
        cancelService: {
            heading: string;
            cancelReason: string;
            optional: string;
            action: string;
            back: string;
            Submit: string;
            cancelServiceSuccess: string;
            unknownError: string;
            ServiceTime: string;
            ServiceLocation: string;
            ServiceDate: string;
            SubmitRequest: string;
            serviceNotRcancelable: string;
            charactersLeft: string;
            Services: string;
        };
        rescheduleService: {
            actionButtonLabel: string;
            headerLabel: string;
            contentLabel: string;
            datePickerLabel: string;
            timePickerLabel: string;
            backButtonLabel: string;
            submitButtonLabel: string;
            note: string;
            unknownError: string;
            serviceNotReschedulable: string;
            serviceNotAmendable: string;
            rescheduleSuccess: string;
        };
    };
};

declare const hu: {
    s4Service: {
        serviceOrderCheckout: {
            serviceDetails: string;
            serviceScheduleHeading: string;
            address: string;
            serviceLocationHeading: string;
            datePickerLabel: string;
            timePickerLabel: string;
            unknownError: string;
            productDeliveryOptions: string;
            serviceDeliveryOption: string;
            productDeliveryMethods: string;
            serviceDeliveryMethod: string;
        };
        cancelService: {
            heading: string;
            cancelReason: string;
            optional: string;
            action: string;
            back: string;
            Submit: string;
            cancelServiceSuccess: string;
            unknownError: string;
            ServiceTime: string;
            ServiceLocation: string;
            ServiceDate: string;
            SubmitRequest: string;
            serviceNotRcancelable: string;
            charactersLeft: string;
            Services: string;
        };
        rescheduleService: {
            actionButtonLabel: string;
            headerLabel: string;
            contentLabel: string;
            datePickerLabel: string;
            timePickerLabel: string;
            backButtonLabel: string;
            submitButtonLabel: string;
            note: string;
            unknownError: string;
            serviceNotReschedulable: string;
            serviceNotAmendable: string;
            rescheduleSuccess: string;
        };
    };
};

declare const id: {
    s4Service: {
        serviceOrderCheckout: {
            serviceDetails: string;
            serviceScheduleHeading: string;
            address: string;
            serviceLocationHeading: string;
            datePickerLabel: string;
            timePickerLabel: string;
            unknownError: string;
            productDeliveryOptions: string;
            serviceDeliveryOption: string;
            productDeliveryMethods: string;
            serviceDeliveryMethod: string;
        };
        cancelService: {
            heading: string;
            cancelReason: string;
            optional: string;
            action: string;
            back: string;
            Submit: string;
            cancelServiceSuccess: string;
            unknownError: string;
            ServiceTime: string;
            ServiceLocation: string;
            ServiceDate: string;
            SubmitRequest: string;
            serviceNotRcancelable: string;
            charactersLeft: string;
            Services: string;
        };
        rescheduleService: {
            actionButtonLabel: string;
            headerLabel: string;
            contentLabel: string;
            datePickerLabel: string;
            timePickerLabel: string;
            backButtonLabel: string;
            submitButtonLabel: string;
            note: string;
            unknownError: string;
            serviceNotReschedulable: string;
            serviceNotAmendable: string;
            rescheduleSuccess: string;
        };
    };
};

declare const it: {
    s4Service: {
        serviceOrderCheckout: {
            serviceDetails: string;
            serviceScheduleHeading: string;
            address: string;
            serviceLocationHeading: string;
            datePickerLabel: string;
            timePickerLabel: string;
            unknownError: string;
            productDeliveryOptions: string;
            serviceDeliveryOption: string;
            productDeliveryMethods: string;
            serviceDeliveryMethod: string;
        };
        cancelService: {
            heading: string;
            cancelReason: string;
            optional: string;
            action: string;
            back: string;
            Submit: string;
            cancelServiceSuccess: string;
            unknownError: string;
            ServiceTime: string;
            ServiceLocation: string;
            ServiceDate: string;
            SubmitRequest: string;
            serviceNotRcancelable: string;
            charactersLeft: string;
            Services: string;
        };
        rescheduleService: {
            actionButtonLabel: string;
            headerLabel: string;
            contentLabel: string;
            datePickerLabel: string;
            timePickerLabel: string;
            backButtonLabel: string;
            submitButtonLabel: string;
            note: string;
            unknownError: string;
            serviceNotReschedulable: string;
            serviceNotAmendable: string;
            rescheduleSuccess: string;
        };
    };
};

declare const ja: {
    s4Service: {
        serviceOrderCheckout: {
            serviceDetails: string;
            serviceScheduleHeading: string;
            address: string;
            serviceLocationHeading: string;
            datePickerLabel: string;
            timePickerLabel: string;
            unknownError: string;
            productDeliveryOptions: string;
            serviceDeliveryOption: string;
            productDeliveryMethods: string;
            serviceDeliveryMethod: string;
        };
        cancelService: {
            heading: string;
            cancelReason: string;
            optional: string;
            action: string;
            back: string;
            Submit: string;
            cancelServiceSuccess: string;
            unknownError: string;
            ServiceTime: string;
            ServiceLocation: string;
            ServiceDate: string;
            SubmitRequest: string;
            serviceNotRcancelable: string;
            charactersLeft: string;
            Services: string;
        };
        rescheduleService: {
            actionButtonLabel: string;
            headerLabel: string;
            contentLabel: string;
            datePickerLabel: string;
            timePickerLabel: string;
            backButtonLabel: string;
            submitButtonLabel: string;
            note: string;
            unknownError: string;
            serviceNotReschedulable: string;
            serviceNotAmendable: string;
            rescheduleSuccess: string;
        };
    };
};

declare const ko: {
    s4Service: {
        serviceOrderCheckout: {
            serviceDetails: string;
            serviceScheduleHeading: string;
            address: string;
            serviceLocationHeading: string;
            datePickerLabel: string;
            timePickerLabel: string;
            unknownError: string;
            productDeliveryOptions: string;
            serviceDeliveryOption: string;
            productDeliveryMethods: string;
            serviceDeliveryMethod: string;
        };
        cancelService: {
            heading: string;
            cancelReason: string;
            optional: string;
            action: string;
            back: string;
            Submit: string;
            cancelServiceSuccess: string;
            unknownError: string;
            ServiceTime: string;
            ServiceLocation: string;
            ServiceDate: string;
            SubmitRequest: string;
            serviceNotRcancelable: string;
            charactersLeft: string;
            Services: string;
        };
        rescheduleService: {
            actionButtonLabel: string;
            headerLabel: string;
            contentLabel: string;
            datePickerLabel: string;
            timePickerLabel: string;
            backButtonLabel: string;
            submitButtonLabel: string;
            note: string;
            unknownError: string;
            serviceNotReschedulable: string;
            serviceNotAmendable: string;
            rescheduleSuccess: string;
        };
    };
};

declare const pl: {
    s4Service: {
        serviceOrderCheckout: {
            serviceDetails: string;
            serviceScheduleHeading: string;
            address: string;
            serviceLocationHeading: string;
            datePickerLabel: string;
            timePickerLabel: string;
            unknownError: string;
            productDeliveryOptions: string;
            serviceDeliveryOption: string;
            productDeliveryMethods: string;
            serviceDeliveryMethod: string;
        };
        cancelService: {
            heading: string;
            cancelReason: string;
            optional: string;
            action: string;
            back: string;
            Submit: string;
            cancelServiceSuccess: string;
            unknownError: string;
            ServiceTime: string;
            ServiceLocation: string;
            ServiceDate: string;
            SubmitRequest: string;
            serviceNotRcancelable: string;
            charactersLeft: string;
            Services: string;
        };
        rescheduleService: {
            actionButtonLabel: string;
            headerLabel: string;
            contentLabel: string;
            datePickerLabel: string;
            timePickerLabel: string;
            backButtonLabel: string;
            submitButtonLabel: string;
            note: string;
            unknownError: string;
            serviceNotReschedulable: string;
            serviceNotAmendable: string;
            rescheduleSuccess: string;
        };
    };
};

declare const pt: {
    s4Service: {
        serviceOrderCheckout: {
            serviceDetails: string;
            serviceScheduleHeading: string;
            address: string;
            serviceLocationHeading: string;
            datePickerLabel: string;
            timePickerLabel: string;
            unknownError: string;
            productDeliveryOptions: string;
            serviceDeliveryOption: string;
            productDeliveryMethods: string;
            serviceDeliveryMethod: string;
        };
        cancelService: {
            heading: string;
            cancelReason: string;
            optional: string;
            action: string;
            back: string;
            Submit: string;
            cancelServiceSuccess: string;
            unknownError: string;
            ServiceTime: string;
            ServiceLocation: string;
            ServiceDate: string;
            SubmitRequest: string;
            serviceNotRcancelable: string;
            charactersLeft: string;
            Services: string;
        };
        rescheduleService: {
            actionButtonLabel: string;
            headerLabel: string;
            contentLabel: string;
            datePickerLabel: string;
            timePickerLabel: string;
            backButtonLabel: string;
            submitButtonLabel: string;
            note: string;
            unknownError: string;
            serviceNotReschedulable: string;
            serviceNotAmendable: string;
            rescheduleSuccess: string;
        };
    };
};

declare const ru: {
    s4Service: {
        serviceOrderCheckout: {
            serviceDetails: string;
            serviceScheduleHeading: string;
            address: string;
            serviceLocationHeading: string;
            datePickerLabel: string;
            timePickerLabel: string;
            unknownError: string;
            productDeliveryOptions: string;
            serviceDeliveryOption: string;
            productDeliveryMethods: string;
            serviceDeliveryMethod: string;
        };
        cancelService: {
            heading: string;
            cancelReason: string;
            optional: string;
            action: string;
            back: string;
            Submit: string;
            cancelServiceSuccess: string;
            unknownError: string;
            ServiceTime: string;
            ServiceLocation: string;
            ServiceDate: string;
            SubmitRequest: string;
            serviceNotRcancelable: string;
            charactersLeft: string;
            Services: string;
        };
        rescheduleService: {
            actionButtonLabel: string;
            headerLabel: string;
            contentLabel: string;
            datePickerLabel: string;
            timePickerLabel: string;
            backButtonLabel: string;
            submitButtonLabel: string;
            note: string;
            unknownError: string;
            serviceNotReschedulable: string;
            serviceNotAmendable: string;
            rescheduleSuccess: string;
        };
    };
};

declare const zh: {
    s4Service: {
        serviceOrderCheckout: {
            serviceDetails: string;
            serviceScheduleHeading: string;
            address: string;
            serviceLocationHeading: string;
            datePickerLabel: string;
            timePickerLabel: string;
            unknownError: string;
            productDeliveryOptions: string;
            serviceDeliveryOption: string;
            productDeliveryMethods: string;
            serviceDeliveryMethod: string;
        };
        cancelService: {
            heading: string;
            cancelReason: string;
            optional: string;
            action: string;
            back: string;
            Submit: string;
            cancelServiceSuccess: string;
            unknownError: string;
            ServiceTime: string;
            ServiceLocation: string;
            ServiceDate: string;
            SubmitRequest: string;
            serviceNotRcancelable: string;
            charactersLeft: string;
            Services: string;
        };
        rescheduleService: {
            actionButtonLabel: string;
            headerLabel: string;
            contentLabel: string;
            datePickerLabel: string;
            timePickerLabel: string;
            backButtonLabel: string;
            submitButtonLabel: string;
            note: string;
            unknownError: string;
            serviceNotReschedulable: string;
            serviceNotAmendable: string;
            rescheduleSuccess: string;
        };
    };
};

declare const zh_TW: {
    s4Service: {
        serviceOrderCheckout: {
            serviceDetails: string;
            serviceScheduleHeading: string;
            address: string;
            serviceLocationHeading: string;
            datePickerLabel: string;
            timePickerLabel: string;
            unknownError: string;
            productDeliveryOptions: string;
            serviceDeliveryOption: string;
            productDeliveryMethods: string;
            serviceDeliveryMethod: string;
        };
        cancelService: {
            heading: string;
            cancelReason: string;
            optional: string;
            action: string;
            back: string;
            Submit: string;
            cancelServiceSuccess: string;
            unknownError: string;
            ServiceTime: string;
            ServiceLocation: string;
            ServiceDate: string;
            SubmitRequest: string;
            serviceNotRcancelable: string;
            charactersLeft: string;
            Services: string;
        };
        rescheduleService: {
            actionButtonLabel: string;
            headerLabel: string;
            contentLabel: string;
            datePickerLabel: string;
            timePickerLabel: string;
            backButtonLabel: string;
            submitButtonLabel: string;
            note: string;
            unknownError: string;
            serviceNotReschedulable: string;
            serviceNotAmendable: string;
            rescheduleSuccess: string;
        };
    };
};

declare const s4ServiceTranslationChunksConfig: TranslationChunksConfig;

export { s4ServiceTranslationChunksConfig, cs as s4ServiceTranslationsCs, de as s4ServiceTranslationsDe, en as s4ServiceTranslationsEn, es as s4ServiceTranslationsEs, es_CO as s4ServiceTranslationsEs_CO, fr as s4ServiceTranslationsFr, hi as s4ServiceTranslationsHi, hu as s4ServiceTranslationsHu, id as s4ServiceTranslationsId, it as s4ServiceTranslationsIt, ja as s4ServiceTranslationsJa, ko as s4ServiceTranslationsKo, pl as s4ServiceTranslationsPl, pt as s4ServiceTranslationsPt, ru as s4ServiceTranslationsRu, zh as s4ServiceTranslationsZh, zh_TW as s4ServiceTranslationsZh_TW };
