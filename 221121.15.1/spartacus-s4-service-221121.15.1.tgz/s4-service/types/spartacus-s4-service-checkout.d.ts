import * as i0 from '@angular/core';
import { OnInit, OnDestroy } from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/storefront';
import { Card } from '@spartacus/storefront';
import * as i3 from '@spartacus/core';
import { TranslationService, UserCostCenterService, GlobalMessageService, UserIdService, CommandService, EventService, Command, QueryState, LoggerService, OccEndpointsService } from '@spartacus/core';
import * as i4 from '@angular/router';
import { ActivatedRoute, ActivatedRouteSnapshot, GuardResult } from '@angular/router';
import { ActiveCartFacade, DeliveryMode } from '@spartacus/cart/base/root';
import { B2BCheckoutReviewSubmitComponent, CheckoutB2BStepsSetGuard } from '@spartacus/checkout/b2b/components';
import { CheckoutPaymentTypeFacade, CheckoutCostCenterFacade } from '@spartacus/checkout/b2b/root';
import { CheckoutStepService, CheckoutDeliveryModeComponent } from '@spartacus/checkout/base/components';
import { CheckoutDeliveryAddressFacade, CheckoutPaymentFacade, CheckoutDeliveryModesFacade, CheckoutStepType, CheckoutStep, CheckoutQueryFacade } from '@spartacus/checkout/base/root';
import { CheckoutServiceDetailsFacade, CheckoutServiceSchedulePickerService, S4ServiceDeliveryModeConfig, ServiceDateTime, ServiceDetails } from '@spartacus/s4-service/root';
import { Observable, Subscription, BehaviorSubject } from 'rxjs';
import * as i4$1 from '@angular/forms';
import { FormBuilder, FormGroup } from '@angular/forms';
import * as dist_cart_types_spartacus_cart_base_root from 'dist/cart/types/spartacus-cart-base-root';
import { HttpClient } from '@angular/common/http';

declare class ServiceCheckoutReviewSubmitComponent extends B2BCheckoutReviewSubmitComponent {
    protected checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade;
    protected checkoutPaymentFacade: CheckoutPaymentFacade;
    protected activeCartFacade: ActiveCartFacade;
    protected translationService: TranslationService;
    protected checkoutStepService: CheckoutStepService;
    protected checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade;
    protected checkoutPaymentTypeFacade: CheckoutPaymentTypeFacade;
    protected checkoutCostCenterFacade: CheckoutCostCenterFacade;
    protected userCostCenterService: UserCostCenterService;
    checkoutStepTypeServiceDetails: CheckoutStepType;
    protected checkoutServiceDetailsFacade: CheckoutServiceDetailsFacade;
    protected checkoutServiceSchedulePickerService: CheckoutServiceSchedulePickerService;
    protected config: S4ServiceDeliveryModeConfig;
    constructor(checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade, checkoutPaymentFacade: CheckoutPaymentFacade, activeCartFacade: ActiveCartFacade, translationService: TranslationService, checkoutStepService: CheckoutStepService, checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade, checkoutPaymentTypeFacade: CheckoutPaymentTypeFacade, checkoutCostCenterFacade: CheckoutCostCenterFacade, userCostCenterService: UserCostCenterService);
    get scheduledAt$(): Observable<string | undefined>;
    protected getCheckoutDeliverySteps(): Array<CheckoutStepType | string>;
    shouldShowDeliveryModeCard(mode: DeliveryMode): boolean;
    getServiceDetailsCard(scheduledAt: ServiceDateTime | undefined | null): Observable<Card>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ServiceCheckoutReviewSubmitComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ServiceCheckoutReviewSubmitComponent, "cx-review-submit", never, {}, {}, never, never, true, never>;
}

declare class ServiceCheckoutReviewSubmitModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ServiceCheckoutReviewSubmitModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ServiceCheckoutReviewSubmitModule, never, [typeof i1.CommonModule, typeof i2.CardModule, typeof i3.I18nModule, typeof i3.UrlModule, typeof i4.RouterModule, typeof i2.PromotionsModule, typeof i2.IconModule, typeof i2.OutletModule, typeof ServiceCheckoutReviewSubmitComponent], [typeof ServiceCheckoutReviewSubmitComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ServiceCheckoutReviewSubmitModule>;
}

declare class CheckoutServiceDetailsComponent implements OnInit, OnDestroy {
    protected activatedRoute: ActivatedRoute;
    protected checkoutStepService: CheckoutStepService;
    protected globalMessageService: GlobalMessageService;
    protected checkoutServiceDetailsFacade: CheckoutServiceDetailsFacade;
    protected fb: FormBuilder;
    protected checkoutServiceSchedulePickerService: CheckoutServiceSchedulePickerService;
    minServiceDate$: Observable<string>;
    scheduleTimes$: Observable<string[]>;
    form: FormGroup;
    protected subscription: Subscription;
    selectedServiceDetails$: Observable<string | undefined>;
    ngOnInit(): void;
    setScheduleTime(event: Event): void;
    get backBtnText(): string;
    protected readonly isSetServiceDetailsHttpErrorSub: BehaviorSubject<boolean>;
    isSetServiceDetailsHttpError$: Observable<boolean>;
    next(): void;
    back(): void;
    protected onSuccess(): void;
    protected onError(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutServiceDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutServiceDetailsComponent, "cx-service-details", never, {}, {}, never, never, true, never>;
}

declare class CheckoutServiceDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutServiceDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutServiceDetailsModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof i2.DatePickerModule, typeof i4$1.ReactiveFormsModule, typeof i2.FormRequiredAsterisksComponent, typeof i2.FormRequiredLegendComponent, typeof CheckoutServiceDetailsComponent], [typeof CheckoutServiceDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutServiceDetailsModule>;
}

declare class ServiceCheckoutDeliveryModeComponent extends CheckoutDeliveryModeComponent {
    protected checkoutServiceDetailsFacade: CheckoutServiceDetailsFacade;
    protected config: S4ServiceDeliveryModeConfig;
    hasServiceProducts$: Observable<boolean>;
    serviceDeliveryConfig: dist_cart_types_spartacus_cart_base_root.DeliveryMode | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ServiceCheckoutDeliveryModeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ServiceCheckoutDeliveryModeComponent, "cx-delivery-mode", never, {}, {}, never, never, true, never>;
}

declare class ServiceCheckoutDeliveryModeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ServiceCheckoutDeliveryModeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ServiceCheckoutDeliveryModeModule, never, [typeof i1.CommonModule, typeof i4$1.ReactiveFormsModule, typeof i3.I18nModule, typeof i2.SpinnerModule, typeof i2.OutletModule, typeof i2.PageComponentModule, typeof i3.FeaturesConfigModule, typeof ServiceCheckoutDeliveryModeComponent], [typeof ServiceCheckoutDeliveryModeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ServiceCheckoutDeliveryModeModule>;
}

declare class S4ServiceCheckoutComponentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<S4ServiceCheckoutComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<S4ServiceCheckoutComponentModule, never, [typeof ServiceCheckoutReviewSubmitModule, typeof CheckoutServiceDetailsModule, typeof ServiceCheckoutDeliveryModeModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<S4ServiceCheckoutComponentModule>;
}

declare class S4ServiceCheckoutCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<S4ServiceCheckoutCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<S4ServiceCheckoutCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<S4ServiceCheckoutCoreModule>;
}

declare class S4ServiceCheckoutOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<S4ServiceCheckoutOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<S4ServiceCheckoutOccModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<S4ServiceCheckoutOccModule>;
}

declare class S4ServiceCheckoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<S4ServiceCheckoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<S4ServiceCheckoutModule, never, [typeof S4ServiceCheckoutComponentModule, typeof S4ServiceCheckoutCoreModule, typeof S4ServiceCheckoutOccModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<S4ServiceCheckoutModule>;
}

declare class CheckoutServiceOrderStepsSetGuard extends CheckoutB2BStepsSetGuard {
    protected checkoutServiceDetailsFacade: CheckoutServiceDetailsFacade;
    protected activeCartFacade: ActiveCartFacade;
    protected config: S4ServiceDeliveryModeConfig;
    canActivate(route: ActivatedRouteSnapshot): Observable<GuardResult>;
    protected isServiceDetailsSet(step: CheckoutStep): Observable<GuardResult>;
    setServiceDeliveryMode(): Observable<unknown>;
    protected isB2BStepSet(step: CheckoutStep, isAccountPayment: boolean): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutServiceOrderStepsSetGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutServiceOrderStepsSetGuard>;
}

declare abstract class CheckoutServiceDetailsAdapter {
    /**
     * Abstract method used to set service details to cart
     *
     * @param userId
     * @param cartId
     * @param scheduledAt : date and time of the service
     */
    abstract setServiceScheduleSlot(userId: string, cartId: string, scheduledAt: ServiceDetails): Observable<unknown>;
}

declare class CheckoutServiceDetailsConnector {
    protected adapter: CheckoutServiceDetailsAdapter;
    setServiceScheduleSlot(userId: string, cartId: string, scheduledAt: ServiceDetails): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutServiceDetailsConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutServiceDetailsConnector>;
}

declare class CheckoutServiceDetailsService implements CheckoutServiceDetailsFacade {
    protected activeCartFacade: ActiveCartFacade;
    protected userIdService: UserIdService;
    protected commandService: CommandService;
    protected serviceDetailsConnector: CheckoutServiceDetailsConnector;
    protected eventService: EventService;
    protected checkoutQueryFacade: CheckoutQueryFacade;
    protected setServiceScheduleSlotCommand: Command<ServiceDateTime>;
    protected checkoutPreconditions(): Observable<[string, string]>;
    setServiceScheduleSlot(scheduledAt: ServiceDateTime): Observable<unknown>;
    getSelectedServiceDetailsState(): Observable<QueryState<ServiceDateTime | undefined>>;
    getServiceProducts(): Observable<string[]>;
    hasNonServiceItems(): Observable<boolean>;
    hasServiceItems(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutServiceDetailsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutServiceDetailsService>;
}

declare class OccCheckoutServiceDetailsAdapter implements CheckoutServiceDetailsAdapter {
    protected http: HttpClient;
    protected logger: LoggerService;
    protected occEndpoints: OccEndpointsService;
    setServiceScheduleSlot(userId: string, cartId: string, scheduledAt: ServiceDetails): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCheckoutServiceDetailsAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCheckoutServiceDetailsAdapter>;
}

export { CheckoutServiceDetailsAdapter, CheckoutServiceDetailsComponent, CheckoutServiceDetailsConnector, CheckoutServiceDetailsModule, CheckoutServiceDetailsService, CheckoutServiceOrderStepsSetGuard, OccCheckoutServiceDetailsAdapter, S4ServiceCheckoutComponentModule, S4ServiceCheckoutCoreModule, S4ServiceCheckoutModule, S4ServiceCheckoutOccModule, ServiceCheckoutDeliveryModeComponent, ServiceCheckoutDeliveryModeModule, ServiceCheckoutReviewSubmitComponent, ServiceCheckoutReviewSubmitModule };
