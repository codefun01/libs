var serviceOrderCheckout$g = {
	serviceDetails: "Detaily služby",
	serviceScheduleHeading: "Plán služby – datum a čas",
	address: "Stejná jako dodací adresa",
	serviceLocationHeading: "Místo služby",
	datePickerLabel: "Datum služby v plánu",
	timePickerLabel: "Čas služby v plánu",
	unknownError: "Došlo k neznámé chybě; obraťte se na podporu.",
	productDeliveryOptions: "Možnosti dodání produktu",
	serviceDeliveryOption: "Možnost poskytnutí služby",
	productDeliveryMethods: "Způsoby dodání produktu",
	serviceDeliveryMethod: "Způsob poskytnutí služby"
};
var cancelService$g = {
	heading: "Následující položky budou zahrnuty do požadavku na zrušení",
	cancelReason: "Důvod zrušení služby",
	optional: "(nepovinné)",
	action: "Zrušit službu",
	back: "Zpět",
	Submit: "Odeslat požadavek",
	cancelServiceSuccess: "Služba byla úspěšně zrušena",
	unknownError: "Došlo k neznámé chybě. Obraťte se na podporu.",
	ServiceTime: "Čas služby",
	ServiceLocation: "Místo služby",
	ServiceDate: "Datum služby",
	SubmitRequest: "Odeslat požadavek",
	serviceNotRcancelable: "Službu nelze zrušit",
	charactersLeft: "zbývá znaků: {{count}}",
	Services: "Služby"
};
var rescheduleService$g = {
	actionButtonLabel: "Přeplánovat službu",
	headerLabel: "Služby",
	contentLabel: "Přeplánování služby – vyberte nový datum a čas",
	datePickerLabel: "Datum služby",
	timePickerLabel: "Čas služby",
	backButtonLabel: "Zpět",
	submitButtonLabel: "Odeslat požadavek",
	note: "Vezměte na vědomí, že požadavek se ve vaší objednávce může projevit až za okamžik.",
	unknownError: "Došlo k neznámé chybě. Obraťte se na podporu.",
	serviceNotReschedulable: "Tuto službu nelze přeplánovat.",
	serviceNotAmendable: "Tuto službu nelze zrušit ani přeplánovat, jakmile zbývá méně než 24 hodin do plánovaného data poskytnutí.",
	rescheduleSuccess: "Datum a čas služby byly úspěšně změněny."
};
var s4Service$g = {
	serviceOrderCheckout: serviceOrderCheckout$g,
	cancelService: cancelService$g,
	rescheduleService: rescheduleService$g
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const cs = {
    s4Service: s4Service$g,
};

var serviceOrderCheckout$f = {
	serviceDetails: "Servicedetails",
	serviceScheduleHeading: "Terminierung des Service - Datum und Uhrzeit",
	address: "Mit Lieferadresse identisch",
	serviceLocationHeading: "Serviceort",
	datePickerLabel: "Servicedatum terminieren",
	timePickerLabel: "Servicezeit terminieren",
	unknownError: "Es ist ein unbekannter Fehler aufgetreten. Wenden Sie sich an den Support.",
	productDeliveryOptions: "Lieferoptionen für Produkte",
	serviceDeliveryOption: "Lieferoption für Services",
	productDeliveryMethods: "Lieferarten für Produkte",
	serviceDeliveryMethod: "Lieferart für Services"
};
var cancelService$f = {
	heading: "Die folgenden Positionen sind in der Stornierungsanfrage enthalten",
	cancelReason: "Grund für Stornierung des Service",
	optional: "(optional)",
	action: "Service stornieren",
	back: "Zurück",
	Submit: "Anfrage senden",
	cancelServiceSuccess: "Der Service wurde erfolgreich storniert",
	unknownError: "Es ist ein unbekannter Fehler aufgetreten. Wenden Sie sich an den Support.",
	ServiceTime: "Servicezeit",
	ServiceLocation: "Serviceort",
	ServiceDate: "Servicedatum",
	SubmitRequest: "Anfrage senden",
	serviceNotRcancelable: "Service kann nicht storniert werden.",
	charactersLeft: "Zeichen übrig: {{count}}",
	Services: "Services"
};
var rescheduleService$f = {
	actionButtonLabel: "Service umterminieren",
	headerLabel: "Services",
	contentLabel: "Umterminierung des Service - Datum und Uhrzeit",
	datePickerLabel: "Servicedatum",
	timePickerLabel: "Servicezeit",
	backButtonLabel: "Zurück",
	submitButtonLabel: "Anfrage senden",
	note: "Bitte beachten Sie, dass es einen Moment dauern kann, bis die Anfrage in Ihrer Bestellung widergespiegelt wird.",
	unknownError: "Es ist ein unbekannter Fehler aufgetreten. Wenden Sie sich an den Support.",
	serviceNotReschedulable: "Der Service kann nicht umterminiert werden.",
	serviceNotAmendable: "Der Service kann nicht mehr storniert oder umterminiert werden, wenn der Zeitraum bis zum geplanten Termin kürzer als 24 Stunden ist.",
	rescheduleSuccess: "Datum und Uhrzeit des Service wurden erfolgreich geändert."
};
var s4Service$f = {
	serviceOrderCheckout: serviceOrderCheckout$f,
	cancelService: cancelService$f,
	rescheduleService: rescheduleService$f
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const de = {
    s4Service: s4Service$f,
};

var serviceOrderCheckout$e = {
	serviceDetails: "Service Details",
	serviceScheduleHeading: "Service Schedule - Date and Time",
	address: "Same as Shipping Address",
	serviceLocationHeading: "Service Location",
	datePickerLabel: "Schedule Service Date",
	timePickerLabel: "Schedule Service Time",
	unknownError: "An unknown error occurred. Please contact support.",
	productDeliveryOptions: "Delivery Options for Products",
	serviceDeliveryOption: "Delivery Option for Services",
	productDeliveryMethods: "Delivery Methods for Products",
	serviceDeliveryMethod: "Delivery Method for Services"
};
var cancelService$e = {
	heading: "The following items will be included in the cancellation request",
	cancelReason: "Reason for  cancelling service",
	optional: "(optional)",
	action: "Cancel Service",
	back: "Back",
	Submit: "Submit Request",
	cancelServiceSuccess: "The service has been cancelled sucessfully",
	unknownError: "An unknown error occurred. Please contact support.",
	ServiceTime: "Service Time",
	ServiceLocation: "Service Location",
	ServiceDate: "Service Date",
	SubmitRequest: "Submit Request",
	serviceNotRcancelable: "Service is not cancelable",
	charactersLeft: "characters left: {{count}}",
	Services: "Services"
};
var rescheduleService$e = {
	actionButtonLabel: "Reschedule Service",
	headerLabel: "Services",
	contentLabel: "Service Reschedule - Choose New Date and Time",
	datePickerLabel: "Service Date",
	timePickerLabel: "Service Time",
	backButtonLabel: "Back",
	submitButtonLabel: "Submit Request",
	note: "Please note that it may take a few moments for your order to reflect the request.",
	unknownError: "An unknown error occurred. Please contact support.",
	serviceNotReschedulable: "The service cannot be rescheduled.",
	serviceNotAmendable: "The service cannot be cancelled or rescheduled less than 24 hours before the scheduled date.",
	rescheduleSuccess: "The service date and time has been changed successfully."
};
var s4Service$e = {
	serviceOrderCheckout: serviceOrderCheckout$e,
	cancelService: cancelService$e,
	rescheduleService: rescheduleService$e
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const en = {
    s4Service: s4Service$e,
};

var serviceOrderCheckout$d = {
	serviceDetails: "Detalles del servicio",
	serviceScheduleHeading: "Horario del servicio: fecha y hora",
	address: "La misma que la dirección de envío",
	serviceLocationHeading: "Ubicación del servicio",
	datePickerLabel: "Programar fecha de servicio",
	timePickerLabel: "Programar hora de servicio",
	unknownError: "Ocurrió un error desconocido. Póngase en contacto con el servicio de soporte.",
	productDeliveryOptions: "Opciones de entrega para productos",
	serviceDeliveryOption: "Opción de entrega para servicios",
	productDeliveryMethods: "Métodos de entrega para productos",
	serviceDeliveryMethod: "Método de entrega para servicios"
};
var cancelService$d = {
	heading: "Los siguientes artículos estarán incluidos en la solicitud de cancelación",
	cancelReason: "Motivo de cancelación del servicio",
	optional: "(opcional)",
	action: "Cancelar servicio",
	back: "Atrás",
	Submit: "Enviar solicitud",
	cancelServiceSuccess: "El servicio ha sido cancelado correctamente",
	unknownError: "Ocurrió un error desconocido. Póngase en contacto con el servicio de soporte.",
	ServiceTime: "Hora del servicio",
	ServiceLocation: "Ubicación del servicio",
	ServiceDate: "Fecha del servicio",
	SubmitRequest: "Enviar solicitud",
	serviceNotRcancelable: "El servicio no se puede cancelar",
	charactersLeft: "caracteres restantes: {{count}}",
	Services: "Servicios"
};
var rescheduleService$d = {
	actionButtonLabel: "Reprogramar servicio",
	headerLabel: "Servicios",
	contentLabel: "Reprogramación del servicio: seleccione fecha y hora nuevamente",
	datePickerLabel: "Fecha del servicio",
	timePickerLabel: "Hora del servicio",
	backButtonLabel: "Atrás",
	submitButtonLabel: "Enviar solicitud",
	note: "Tenga en cuenta que su pedido puede demorar un tiempo en reflejar la solicitud.",
	unknownError: "Ocurrió un error desconocido. Póngase en contacto con el servicio de soporte.",
	serviceNotReschedulable: "No se puede reprogramar el servicio.",
	serviceNotAmendable: "No se puede reprogramar o cancelar el servicio en las 24 horas previas a la fecha programada.",
	rescheduleSuccess: "La fecha y hora del servicio han sido modificadas correctamente."
};
var s4Service$d = {
	serviceOrderCheckout: serviceOrderCheckout$d,
	cancelService: cancelService$d,
	rescheduleService: rescheduleService$d
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const es = {
    s4Service: s4Service$d,
};

var serviceOrderCheckout$c = {
	serviceDetails: "Detalles del servicio",
	serviceScheduleHeading: "Horario del servicio: fecha y hora",
	address: "La misma que la dirección de envío",
	serviceLocationHeading: "Ubicación del servicio",
	datePickerLabel: "Programar fecha de servicio",
	timePickerLabel: "Programar hora de servicio",
	unknownError: "Ocurrió un error desconocido. Póngase en contacto con el servicio de soporte.",
	productDeliveryOptions: "Opciones de entrega para productos",
	serviceDeliveryOption: "Opción de entrega para servicios",
	productDeliveryMethods: "Métodos de entrega para productos",
	serviceDeliveryMethod: "Método de entrega para servicios"
};
var cancelService$c = {
	heading: "Los siguientes artículos estarán incluidos en la solicitud de cancelación",
	cancelReason: "Motivo de cancelación del servicio",
	optional: "(opcional)",
	action: "Cancelar servicio",
	back: "Atrás",
	Submit: "Enviar solicitud",
	cancelServiceSuccess: "El servicio ha sido cancelado correctamente.",
	unknownError: "Ocurrió un error desconocido. Póngase en contacto con el servicio de soporte.",
	ServiceTime: "Hora del servicio",
	ServiceLocation: "Ubicación del servicio",
	ServiceDate: "Fecha del servicio",
	SubmitRequest: "Enviar solicitud",
	serviceNotRcancelable: "El servicio no se puede cancelar",
	charactersLeft: "caracteres restantes: {{count}}",
	Services: "Servicios"
};
var rescheduleService$c = {
	actionButtonLabel: "Reprogramar servicio",
	headerLabel: "Servicios",
	contentLabel: "Reprogramación del servicio: seleccione fecha y hora nuevamente",
	datePickerLabel: "Fecha del servicio",
	timePickerLabel: "Hora del servicio",
	backButtonLabel: "Atrás",
	submitButtonLabel: "Enviar solicitud",
	note: "Tenga en cuenta que su pedido puede demorar un tiempo en reflejar la solicitud.",
	unknownError: "Ocurrió un error desconocido. Póngase en contacto con el servicio de soporte.",
	serviceNotReschedulable: "No se puede reprogramar el servicio.",
	serviceNotAmendable: "No se puede reprogramar o cancelar el servicio en las 24 horas previas a la fecha programada.",
	rescheduleSuccess: "La fecha y hora del servicio han sido modificadas correctamente."
};
var s4Service$c = {
	serviceOrderCheckout: serviceOrderCheckout$c,
	cancelService: cancelService$c,
	rescheduleService: rescheduleService$c
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const es_CO = {
    s4Service: s4Service$c,
};

var serviceOrderCheckout$b = {
	serviceDetails: "Détails du service",
	serviceScheduleHeading: "Planification du service - Date et heure",
	address: "Identique à l'adresse d'expédition",
	serviceLocationHeading: "Lieu du service",
	datePickerLabel: "Planifier la date du service",
	timePickerLabel: "Planifier l'heure du service",
	unknownError: "Une erreur inconnue s'est produite. Veuillez contacter le service d'assistance.",
	productDeliveryOptions: "Options de livraison des produits",
	serviceDeliveryOption: "Options de livraison des services",
	productDeliveryMethods: "Modes de livraison des produits",
	serviceDeliveryMethod: "Mode de livraison des services"
};
var cancelService$b = {
	heading: "Les articles suivants seront inclus dans la demande d'annulation",
	cancelReason: "Motif d'annulation du service",
	optional: "(facultatif)",
	action: "Annuler le service",
	back: "Retour",
	Submit: "Envoyer la demande",
	cancelServiceSuccess: "Le service a été annulé avec succès",
	unknownError: "Une erreur inconnue s'est produite. Veuillez contacter le service d'assistance.",
	ServiceTime: "Heure du service",
	ServiceLocation: "Lieu du service",
	ServiceDate: "Date du service",
	SubmitRequest: "Envoyer la demande",
	serviceNotRcancelable: "Le service ne peut pas être annulé",
	charactersLeft: "Caractères restants : {{count}}",
	Services: "Services"
};
var rescheduleService$b = {
	actionButtonLabel: "Replanifier le service",
	headerLabel: "Services",
	contentLabel: "Replanification du service - Sélectionner une nouvelle date et heure",
	datePickerLabel: "Date du service",
	timePickerLabel: "Heure du service",
	backButtonLabel: "Retour",
	submitButtonLabel: "Envoyer la demande",
	note: "Veuillez noter qu'il peut s'écouler quelques instants avant que votre commande ne reflète la demande.",
	unknownError: "Une erreur inconnue s'est produite. Veuillez contacter le service d'assistance.",
	serviceNotReschedulable: "Le service ne peut pas être replanifié.",
	serviceNotAmendable: "Le service ne peut pas être annulé ou replanifié moins de 24 heures avant la date planifiée.",
	rescheduleSuccess: "La date et l'heure du service ont été modifiées avec succès."
};
var s4Service$b = {
	serviceOrderCheckout: serviceOrderCheckout$b,
	cancelService: cancelService$b,
	rescheduleService: rescheduleService$b
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const fr = {
    s4Service: s4Service$b,
};

var serviceOrderCheckout$a = {
	serviceDetails: "सेवा विवरण",
	serviceScheduleHeading: "सेवा शेड्यूल - दिनांक और समय",
	address: "शिपिंग पते के अनुसार ही",
	serviceLocationHeading: "सेवा स्थान",
	datePickerLabel: "सेवा दिनांक शेड्यूल करें",
	timePickerLabel: "सेवा समय शेड्यूल करें",
	unknownError: "त्रुटि उत्पन्न हुई; सहायता से संपर्क करें",
	productDeliveryOptions: "उत्पाद के लिए वितरण विकल्प",
	serviceDeliveryOption: "सेवा के लिए वितरण विकल्प",
	productDeliveryMethods: "उत्पाद के लिए वितरण विधियां",
	serviceDeliveryMethod: "सेवा के लिए वितरण विधि"
};
var cancelService$a = {
	heading: "निम्न उत्पाद रद्दकरण अनुरोध में शामिल किए जाएंगे",
	cancelReason: "सेवा रद्द करने के लिए कारण",
	optional: "(वैकल्पिक)",
	action: "सेवाओं को रद्द करें",
	back: "वापस जाएं",
	Submit: "अनुरोध सबमिट करें",
	cancelServiceSuccess: "सेवा सफलतापूर्वक रद्द की गई",
	unknownError: "अज्ञात त्रुटि उत्पन्न हुई. सहायता से संपर्क करें",
	ServiceTime: "सेवा समय",
	ServiceLocation: "सेवा स्थान",
	ServiceDate: "सेवा दिनांक",
	SubmitRequest: "अनुरोध सबमिट करें",
	serviceNotRcancelable: "सेवा रद्द करने योग्य नहीं है",
	charactersLeft: "वर्ण बचे हैंः  {{count}}",
	Services: "सेवाएं"
};
var rescheduleService$a = {
	actionButtonLabel: "रीशेड्यूल सेवा",
	headerLabel: "सेवाएं",
	contentLabel: "सेवा रीशेड्यूल की गई - नया दिनांक और समय चुनें",
	datePickerLabel: "सेवा दिनांक",
	timePickerLabel: "सेवा समय",
	backButtonLabel: "वापस जाएं",
	submitButtonLabel: "अनुरोध सबमिट करें",
	note: "कृपया ध्यान रखें कि आपके ऑर्डर पर अनुरोध दर्शाने में कुछ समय लग सकता है.",
	unknownError: "अज्ञात त्रुटि उत्पन्न हुई. सहायता से संपर्क करें.",
	serviceNotReschedulable: "सेवा रीशेड्यूल नहीं की जा सकती.",
	serviceNotAmendable: "शेड्यूल दिनांक से 24 घंटे से कम से पहले सेवा रद्द या रीशेड्यूल नहीं की जा सकती.",
	rescheduleSuccess: "सेवा दिनांक और समय सफलतापूर्वक बदला गया."
};
var s4Service$a = {
	serviceOrderCheckout: serviceOrderCheckout$a,
	cancelService: cancelService$a,
	rescheduleService: rescheduleService$a
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const hi = {
    s4Service: s4Service$a,
};

var serviceOrderCheckout$9 = {
	serviceDetails: "Szolgáltatás adatai",
	serviceScheduleHeading: "Szolgáltatási ütemezés – Dátum és időpont",
	address: "Megegyezik a szállítási címmel",
	serviceLocationHeading: "Szolgáltatási helyszín",
	datePickerLabel: "Szolgáltatás dátumának ütemezése",
	timePickerLabel: "Szolgáltatás időpontjának ütemezése",
	unknownError: "Ismeretlen hiba történt. Forduljon a támogatáshoz.",
	productDeliveryOptions: "Kézbesítési lehetőségek a termékek esetén",
	serviceDeliveryOption: "Kézbesítési lehetőségek a szolgáltatások esetén",
	productDeliveryMethods: "Kézbesítési módok a termékek esetén",
	serviceDeliveryMethod: "Kézbesítési módok a szolgáltatások esetén"
};
var cancelService$9 = {
	heading: "A következő tételek a törlési kérés részét fogják képezni",
	cancelReason: "A szolgáltatás törlésének oka",
	optional: "(opcionális)",
	action: "Szolgáltatás törlése",
	back: "Vissza",
	Submit: "Kérés elküldése",
	cancelServiceSuccess: "A szolgáltatás törlése sikeres",
	unknownError: "Ismeretlen hiba történt. Forduljon a támogatáshoz.",
	ServiceTime: "Szolgáltatási időpont",
	ServiceLocation: "Szolgáltatási helyszín",
	ServiceDate: "Szolgáltatási dátum",
	SubmitRequest: "Kérés elküldése",
	serviceNotRcancelable: "A szolgáltatás nem törölhető",
	charactersLeft: "hátralévő karakterek: {{count}}",
	Services: "Szolgáltatások"
};
var rescheduleService$9 = {
	actionButtonLabel: "Szolgáltatás újraütemezése",
	headerLabel: "Szolgáltatások",
	contentLabel: "Szolgáltatás újraütemezése – Válasszon egy új dátumot és időpontot",
	datePickerLabel: "Szolgáltatási dátum",
	timePickerLabel: "Szolgáltatási időpont",
	backButtonLabel: "Vissza",
	submitButtonLabel: "Kérés elküldése",
	note: "Megjegyzés: eltarthat egy kis ideig, míg a rendelése a kérésnek megfelelően módosul.",
	unknownError: "Ismeretlen hiba történt. Forduljon a támogatáshoz.",
	serviceNotReschedulable: "A szolgáltatás nem ütemezhető újra.",
	serviceNotAmendable: "A szolgáltatás nem törölhető vagy ütemezhető újra az ütemezett dátum előtt kevesebb, mint 24 órával.",
	rescheduleSuccess: "A szolgáltatás dátumának és időpontjának módosítása sikeres."
};
var s4Service$9 = {
	serviceOrderCheckout: serviceOrderCheckout$9,
	cancelService: cancelService$9,
	rescheduleService: rescheduleService$9
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const hu = {
    s4Service: s4Service$9,
};

var serviceOrderCheckout$8 = {
	serviceDetails: "Rincian Layanan",
	serviceScheduleHeading: "Jadwal Layanan - Tanggal dan Waktu",
	address: "Sama Seperti Alamat Pengiriman",
	serviceLocationHeading: "Lokasi Layanan",
	datePickerLabel: "Jadwalkan Tanggal Layanan",
	timePickerLabel: "Jadwalkan Waktu Layanan",
	unknownError: "Terjadi kesalahan yang tidak diketahui. Silakan hubungi bagian dukungan.",
	productDeliveryOptions: "Opsi Pengiriman Produk",
	serviceDeliveryOption: "Opsi Penyediaan Layanan",
	productDeliveryMethods: "Metode Pengiriman Produk",
	serviceDeliveryMethod: "Metode Penyediaan Layanan"
};
var cancelService$8 = {
	heading: "Item berikut akan dimasukkan dalam permintaan pembatalan",
	cancelReason: "Alasan di balik pembatalan layanan",
	optional: "(opsional)",
	action: "Batalkan Layanan",
	back: "Kembali",
	Submit: "Kirimkan Permintaan",
	cancelServiceSuccess: "Layanan telah berhasil dibatalkan",
	unknownError: "Terjadi kesalahan yang tidak diketahui. Silakan hubungi bagian dukungan.",
	ServiceTime: "Waktu Layanan",
	ServiceLocation: "Lokasi Layanan",
	ServiceDate: "Tanggal Layanan",
	SubmitRequest: "Kirimkan Permintaan",
	serviceNotRcancelable: "Layanan tidak dapat dibatalkan",
	charactersLeft: "karakter tersisa: {{count}}",
	Services: "Layanan"
};
var rescheduleService$8 = {
	actionButtonLabel: "Atur Ulang Jadwal Layanan",
	headerLabel: "Layanan",
	contentLabel: "Penjadwalan Ulang Layanan - Pilih Tanggal dan Waktu Baru",
	datePickerLabel: "Tanggal Layanan",
	timePickerLabel: "Waktu Layanan",
	backButtonLabel: "Kembali",
	submitButtonLabel: "Kirimkan Permintaan",
	note: "Harap diperhatikan, butuh sedikit waktu agar permintaan Anda terlihat pada pesanan.",
	unknownError: "Terjadi kesalahan yang tidak diketahui. Silakan hubungi bagian dukungan.",
	serviceNotReschedulable: "Layanan tidak dapat dijadwalkan ulang.",
	serviceNotAmendable: "Layanan tidak dapat dibatalkan atau dijadwalkan ulang jika kurang dari 24 jam sebelum tanggal yang telah ditentukan.",
	rescheduleSuccess: "Tanggal dan waktu layanan telah berhasil diubah."
};
var s4Service$8 = {
	serviceOrderCheckout: serviceOrderCheckout$8,
	cancelService: cancelService$8,
	rescheduleService: rescheduleService$8
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const id = {
    s4Service: s4Service$8,
};

var serviceOrderCheckout$7 = {
	serviceDetails: "Dettagli servizio",
	serviceScheduleHeading: "Pianificazione del servizio - Data e ora",
	address: "Uguale all'indirizzo di spedizione",
	serviceLocationHeading: "Sede di servizio",
	datePickerLabel: "Pianifica data di servizio",
	timePickerLabel: "Pianifica ora di servizio",
	unknownError: "Si è verificato un errore sconosciuto. Contattare il supporto.",
	productDeliveryOptions: "Opzioni di consegna per i prodotti",
	serviceDeliveryOption: "Opzione di consegna per i servizi",
	productDeliveryMethods: "Metodi di consegna per i prodotti",
	serviceDeliveryMethod: "Metodo di consegna per i servizi"
};
var cancelService$7 = {
	heading: "Nella richiesta di annullamento verranno inclusi i seguenti elementi",
	cancelReason: "Motivo dell’annullamento del servizio",
	optional: "(facoltativo)",
	action: "Annulla servizio",
	back: "Indietro",
	Submit: "Invia richiesta",
	cancelServiceSuccess: "Il servizio è stato annullato correttamente",
	unknownError: "Si è verificato un errore sconosciuto. Contattare il supporto.",
	ServiceTime: "Ora del servizio",
	ServiceLocation: "Sede di servizio",
	ServiceDate: "Data del servizio",
	SubmitRequest: "Invia richiesta",
	serviceNotRcancelable: "Il servizio non è annullabile",
	charactersLeft: "caratteri rimanenti: {{count}}",
	Services: "Servizi"
};
var rescheduleService$7 = {
	actionButtonLabel: "Ripianifica servizio",
	headerLabel: "Servizi",
	contentLabel: "Ripianificazione del servizio - Scegli nuova data e ora",
	datePickerLabel: "Data del servizio",
	timePickerLabel: "Ora del servizio",
	backButtonLabel: "Indietro",
	submitButtonLabel: "Invia richiesta",
	note: "Perché l'ordine rispecchi la richiesta potrebbero essere necessari alcuni minuti.",
	unknownError: "Si è verificato un errore sconosciuto. Contattare il supporto.",
	serviceNotReschedulable: "Il servizio non può essere ripianificato.",
	serviceNotAmendable: "Il servizio non può essere annullato o ripianificato meno di 24 ore prima della data pianificata.",
	rescheduleSuccess: "Data e ora del servizio modificate correttamente."
};
var s4Service$7 = {
	serviceOrderCheckout: serviceOrderCheckout$7,
	cancelService: cancelService$7,
	rescheduleService: rescheduleService$7
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const it = {
    s4Service: s4Service$7,
};

var serviceOrderCheckout$6 = {
	serviceDetails: "サービス詳細",
	serviceScheduleHeading: "サービススケジュール - 日付および時刻",
	address: "配送先住所と同じ",
	serviceLocationHeading: "サービス提供地域",
	datePickerLabel: "サービス日付のスケジュール設定",
	timePickerLabel: "サービス時刻のスケジュール設定",
	unknownError: "不明なエラーが発生しました。サポートに連絡してください。",
	productDeliveryOptions: "商品の配送オプション",
	serviceDeliveryOption: "サービスの提供オプション",
	productDeliveryMethods: "商品の配送方法",
	serviceDeliveryMethod: "サービスの提供オプション"
};
var cancelService$6 = {
	heading: "次のアイテムがキャンセル依頼に含まれます",
	cancelReason: "サービスのキャンセル理由",
	optional: "(オプション)",
	action: "サービスをキャンセル",
	back: "戻る",
	Submit: "依頼を送信",
	cancelServiceSuccess: "サービスが正常にキャンセルされました",
	unknownError: "不明なエラーが発生しました。サポートに連絡してください。",
	ServiceTime: "サービス時刻",
	ServiceLocation: "サービス提供地域",
	ServiceDate: "サービス日付",
	SubmitRequest: "依頼を送信",
	serviceNotRcancelable: "サービスはキャンセルできません",
	charactersLeft: "残り文字数: {{count}}",
	Services: "サービス"
};
var rescheduleService$6 = {
	actionButtonLabel: "サービスをリスケジュール",
	headerLabel: "サービス",
	contentLabel: "サービスのリスケジュール - 新しい日付および時刻を選択",
	datePickerLabel: "サービス日付",
	timePickerLabel: "サービス時刻",
	backButtonLabel: "戻る",
	submitButtonLabel: "依頼を送信",
	note: "注文に依頼が反映されるまで少し時間がかかる場合があることに注意してください。",
	unknownError: "不明なエラーが発生しました。サポートに連絡してください。",
	serviceNotReschedulable: "サービスを再スケジュールできません。",
	serviceNotAmendable: "サービスをキャンセルできないか、スケジュールされた日付から 24 時間を切ると再スケジュールできません。",
	rescheduleSuccess: "サービスの日付および時刻が正常に変更されました。"
};
var s4Service$6 = {
	serviceOrderCheckout: serviceOrderCheckout$6,
	cancelService: cancelService$6,
	rescheduleService: rescheduleService$6
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ja = {
    s4Service: s4Service$6,
};

var serviceOrderCheckout$5 = {
	serviceDetails: "서비스 세부사항",
	serviceScheduleHeading: "서비스 예약 - 날짜 및 시간",
	address: "배송 주소와 같음",
	serviceLocationHeading: "서비스 지역",
	datePickerLabel: "서비스 일자 예약",
	timePickerLabel: "서비스 시간 예약",
	unknownError: "알 수 없는 오류가 발생했습니다. 고객 지원팀에 문의하십시오.",
	productDeliveryOptions: "제품의 배송 옵션",
	serviceDeliveryOption: "서비스의 배송 옵션",
	productDeliveryMethods: "제품의 배송 방법",
	serviceDeliveryMethod: "서비스의 배송 방법"
};
var cancelService$5 = {
	heading: "다음 품목이 취소 요청에 포함됩니다.",
	cancelReason: "서비스 취소 사유",
	optional: "(옵션)",
	action: "서비스 취소",
	back: "뒤로",
	Submit: "요청 제출",
	cancelServiceSuccess: "서비스가 취소되었습니다.",
	unknownError: "알 수 없는 오류가 발생했습니다. 고객 지원팀에 문의하십시오.",
	ServiceTime: "서비스 시간",
	ServiceLocation: "서비스 지역",
	ServiceDate: "서비스 날짜",
	SubmitRequest: "요청 제출",
	serviceNotRcancelable: "서비스를 취소할 수 없습니다.",
	charactersLeft: "{{count}}자 남음",
	Services: "서비스"
};
var rescheduleService$5 = {
	actionButtonLabel: "서비스 일정 조정",
	headerLabel: "서비스",
	contentLabel: "서비스 일정 조정 - 새 날짜 및 시간 선택",
	datePickerLabel: "서비스 날짜",
	timePickerLabel: "서비스 시간",
	backButtonLabel: "뒤로",
	submitButtonLabel: "요청 제출",
	note: "주문에 요청을 적용하는 데 시간이 걸릴 수 있습니다.",
	unknownError: "알 수 없는 오류가 발생했습니다. 고객 지원팀에 문의하십시오.",
	serviceNotReschedulable: "서비스 일정을 조정할 수 없습니다.",
	serviceNotAmendable: "서비스 예약 날짜가 24시간보다 적게 남아 있는 경우에는 취소하거나 일정을 조정할 수 없습니다.",
	rescheduleSuccess: "서비스 날짜와 시간이 변경되었습니다."
};
var s4Service$5 = {
	serviceOrderCheckout: serviceOrderCheckout$5,
	cancelService: cancelService$5,
	rescheduleService: rescheduleService$5
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ko = {
    s4Service: s4Service$5,
};

var serviceOrderCheckout$4 = {
	serviceDetails: "Szczegóły usługi",
	serviceScheduleHeading: "Harmonogram usługi - data i czas",
	address: "Taki sam, jak adres dostawy",
	serviceLocationHeading: "Miejsce świadczenia usług",
	datePickerLabel: "Data usługi zgodnie z harmonogramem",
	timePickerLabel: "Czas usługi zgodnie z harmonogramem",
	unknownError: "Wystąpił nieznany błąd. Prosimy o kontakt z działem pomocy.",
	productDeliveryOptions: "Opcje dostawy produktów",
	serviceDeliveryOption: "Opcje dostawy usług",
	productDeliveryMethods: "Formy dostawy produktów",
	serviceDeliveryMethod: "Formy dostawy usług"
};
var cancelService$4 = {
	heading: "Poniższe elementy zostaną uwzględnione we wniosku o anulowanie",
	cancelReason: "Przyczyna anulowania usługi",
	optional: "(opcjonalnie)",
	action: "Anuluj usługę",
	back: "Wstecz",
	Submit: "Prześlij zapytanie",
	cancelServiceSuccess: "Usługa została anulowana",
	unknownError: "Wystąpił nieznany błąd. Prosimy o kontakt z działem pomocy.",
	ServiceTime: "Czas świadczenia usługi",
	ServiceLocation: "Miejsce świadczenia usług",
	ServiceDate: "Data świadczenia usługi",
	SubmitRequest: "Prześlij zapytanie",
	serviceNotRcancelable: "Usługi nie można anulować",
	charactersLeft: "pozostało znaków: {{count}}",
	Services: "Usługi"
};
var rescheduleService$4 = {
	actionButtonLabel: "Zmień harmonogram usługi",
	headerLabel: "Usługi",
	contentLabel: "Zmiana harmonogramu usługi - wybierz nową datę i czas",
	datePickerLabel: "Data świadczenia usługi",
	timePickerLabel: "Czas świadczenia usługi",
	backButtonLabel: "Wstecz",
	submitButtonLabel: "Prześlij zapytanie",
	note: "Pamiętaj, że może minąć kilka chwil, zanim twoje zamówienie zostanie uwzględnione w zgłoszeniu.",
	unknownError: "Wystąpił nieznany błąd. Prosimy o kontakt z działem pomocy.",
	serviceNotReschedulable: "Nie można zmienić harmonogramu usługi.",
	serviceNotAmendable: "Usługi nie można anulować ani zmienić jej harmonogramu na mniej niż 24 godziny przed zaplanowaną datą.",
	rescheduleSuccess: "Data i godzina usługi zostały pomyślnie zmienione."
};
var s4Service$4 = {
	serviceOrderCheckout: serviceOrderCheckout$4,
	cancelService: cancelService$4,
	rescheduleService: rescheduleService$4
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const pl = {
    s4Service: s4Service$4,
};

var serviceOrderCheckout$3 = {
	serviceDetails: "Detalhes do serviço",
	serviceScheduleHeading: "Programação do serviço - Data e hora",
	address: "Igual ao endereço de entrega",
	serviceLocationHeading: "Local de prestação de serviços",
	datePickerLabel: "Programar data do serviço",
	timePickerLabel: "Programar hora do serviço",
	unknownError: "Ocorreu um erro desconhecido. Contate o suporte.",
	productDeliveryOptions: "Opções de entrega para produtos",
	serviceDeliveryOption: "Opção de entrega para serviços",
	productDeliveryMethods: "Métodos de entrega para produtos",
	serviceDeliveryMethod: "Método de entrega para serviços"
};
var cancelService$3 = {
	heading: "O seguintes itens serão incluídos na solicitação de cancelamento",
	cancelReason: "Motivo para cancelamento do serviço",
	optional: "(opcional)",
	action: "Cancelar serviço",
	back: "Voltar",
	Submit: "Enviar solicitação",
	cancelServiceSuccess: "O serviço foi cancelado com êxito",
	unknownError: "Ocorreu um erro desconhecido. Contate o suporte.",
	ServiceTime: "Hora do serviço",
	ServiceLocation: "Local de prestação de serviços",
	ServiceDate: "Data do serviço",
	SubmitRequest: "Enviar solicitação",
	serviceNotRcancelable: "O serviço não pode ser cancelado",
	charactersLeft: "caracteres restantes: {{count}}",
	Services: "Serviços"
};
var rescheduleService$3 = {
	actionButtonLabel: "Reprogramar serviço",
	headerLabel: "Serviços",
	contentLabel: "Reprogramação do serviço - Selecionar nova data e hora",
	datePickerLabel: "Data do serviço",
	timePickerLabel: "Hora do serviço",
	backButtonLabel: "Voltar",
	submitButtonLabel: "Enviar solicitação",
	note: "Considere que pode demorar alguns minutos para que seu pedido reflita a solicitação.",
	unknownError: "Ocorreu um erro desconhecido. Contate o suporte.",
	serviceNotReschedulable: "O serviço não pode ser reprogramado.",
	serviceNotAmendable: "O serviço não pode ser cancelado ou reprogramado em menos de 24 horas antes da data programada.",
	rescheduleSuccess: "A data e hora do serviço foi modificada com êxito."
};
var s4Service$3 = {
	serviceOrderCheckout: serviceOrderCheckout$3,
	cancelService: cancelService$3,
	rescheduleService: rescheduleService$3
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const pt = {
    s4Service: s4Service$3,
};

var serviceOrderCheckout$2 = {
	serviceDetails: "Сведения о сервисе",
	serviceScheduleHeading: "График сервиса - дата и время",
	address: "Совпадает с адресом доставки",
	serviceLocationHeading: "Место сервиса",
	datePickerLabel: "Плановая дата сервиса",
	timePickerLabel: "Плановое время сервиса",
	unknownError: "Произошла ошибка. Обратитесь в службу поддержки.",
	productDeliveryOptions: "Опции доставки для продуктов",
	serviceDeliveryOption: "Опция доставки для сервисов",
	productDeliveryMethods: "Методы доставки для продуктов",
	serviceDeliveryMethod: "Метод доставки для сервисов"
};
var cancelService$2 = {
	heading: "Следующие продукты будут включены в запрос на отмену",
	cancelReason: "Причина отмены сервиса",
	optional: "(необязательно)",
	action: "Отменить сервис",
	back: "Назад",
	Submit: "Отправить запрос",
	cancelServiceSuccess: "Сервис отменен",
	unknownError: "Произошла ошибка. Обратитесь в службу поддержки.",
	ServiceTime: "Время сервиса",
	ServiceLocation: "Место сервиса",
	ServiceDate: "Дата сервиса",
	SubmitRequest: "Отправить запрос",
	serviceNotRcancelable: "Отмена сервиса невозможна",
	charactersLeft: "осталось символов: {{count}}",
	Services: "Сервисы"
};
var rescheduleService$2 = {
	actionButtonLabel: "Перепланировать сервис",
	headerLabel: "Сервисы",
	contentLabel: "Перепланировать сервис - выбрать новую дату и время",
	datePickerLabel: "Дата сервиса",
	timePickerLabel: "Время сервиса",
	backButtonLabel: "Назад",
	submitButtonLabel: "Отправить запрос",
	note: "Обратите внимание, что обработка вашего запроса может занять некоторое время.",
	unknownError: "Произошла ошибка. Обратитесь в службу поддержки.",
	serviceNotReschedulable: "Изменение планирования сервиса невозможно",
	serviceNotAmendable: "Сервис нельзя отменить или перепланировать менее чем за 24 часа до запланированной даты.",
	rescheduleSuccess: "Дата и время сервиса изменены."
};
var s4Service$2 = {
	serviceOrderCheckout: serviceOrderCheckout$2,
	cancelService: cancelService$2,
	rescheduleService: rescheduleService$2
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ru = {
    s4Service: s4Service$2,
};

var serviceOrderCheckout$1 = {
	serviceDetails: "服务详细信息",
	serviceScheduleHeading: "服务计划 - 日期和时间",
	address: "与送货地址相同",
	serviceLocationHeading: "服务地点",
	datePickerLabel: "计划服务日期",
	timePickerLabel: "计划服务时间",
	unknownError: "出现未知错误。请联系支持部门。",
	productDeliveryOptions: "产品的送货选项",
	serviceDeliveryOption: "服务的送货选项",
	productDeliveryMethods: "产品的送货方式",
	serviceDeliveryMethod: "服务的送货方式"
};
var cancelService$1 = {
	heading: "以下商品将包含在取消请求中",
	cancelReason: "取消服务的原因",
	optional: "(可选)",
	action: "取消服务",
	back: "返回",
	Submit: "提交请求",
	cancelServiceSuccess: "服务已成功取消",
	unknownError: "出现未知错误。请联系支持部门。",
	ServiceTime: "服务时间",
	ServiceLocation: "服务地点",
	ServiceDate: "服务日期",
	SubmitRequest: "提交请求",
	serviceNotRcancelable: "服务不可取消",
	charactersLeft: "剩余字符：{{count}}",
	Services: "服务"
};
var rescheduleService$1 = {
	actionButtonLabel: "重新计划服务",
	headerLabel: "服务",
	contentLabel: "服务重新计划 - 选择新日期和时间",
	datePickerLabel: "服务日期",
	timePickerLabel: "服务时间",
	backButtonLabel: "返回",
	submitButtonLabel: "提交请求",
	note: "请注意，您的订单可能需要一段时间才能反映请求。",
	unknownError: "出现未知错误。请联系支持部门。",
	serviceNotReschedulable: "无法重新计划服务。",
	serviceNotAmendable: "在计划日期前 24 小时内，无法取消或重新计划服务。",
	rescheduleSuccess: "服务日期和时间已成功更改。"
};
var s4Service$1 = {
	serviceOrderCheckout: serviceOrderCheckout$1,
	cancelService: cancelService$1,
	rescheduleService: rescheduleService$1
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const zh = {
    s4Service: s4Service$1,
};

var serviceOrderCheckout = {
	serviceDetails: "服務明細",
	serviceScheduleHeading: "服務排程 - 日期和時間",
	address: "與出貨地址相同",
	serviceLocationHeading: "服務地點",
	datePickerLabel: "排程服務日期",
	timePickerLabel: "排程服務時間",
	unknownError: "發生未知錯誤。請聯絡支援團隊。",
	productDeliveryOptions: "產品的交貨選項",
	serviceDeliveryOption: "服務的交貨選項",
	productDeliveryMethods: "產品的交貨方法",
	serviceDeliveryMethod: "服務的交貨方法"
};
var cancelService = {
	heading: "下列項目將包含在取消請求中",
	cancelReason: "取消服務的原因",
	optional: "(選擇性)",
	action: "取消服務",
	back: "返回",
	Submit: "提交請求",
	cancelServiceSuccess: "已成功取消服務",
	unknownError: "發生未知錯誤。請聯絡支援團隊。",
	ServiceTime: "服務時間",
	ServiceLocation: "服務地點",
	ServiceDate: "服務日期",
	SubmitRequest: "提交請求",
	serviceNotRcancelable: "服務無法取消",
	charactersLeft: "剩餘字元：{{count}}",
	Services: "服務"
};
var rescheduleService = {
	actionButtonLabel: "重新排程服務",
	headerLabel: "服務",
	contentLabel: "服務重新排程 - 選擇新日期和時間",
	datePickerLabel: "服務日期",
	timePickerLabel: "服務時間",
	backButtonLabel: "返回",
	submitButtonLabel: "提交請求",
	note: "請注意，需要一段時間訂單才會反映請求。",
	unknownError: "發生未知錯誤。請聯絡支援團隊。",
	serviceNotReschedulable: "無法重新排程服務。",
	serviceNotAmendable: "早於排程日期 24 小時的服務無法取銷或重新排程。",
	rescheduleSuccess: "已成功更改服務日期和時間。"
};
var s4Service = {
	serviceOrderCheckout: serviceOrderCheckout,
	cancelService: cancelService,
	rescheduleService: rescheduleService
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const zh_TW = {
    s4Service,
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const s4ServiceTranslationChunksConfig = {
    s4Service: ['serviceOrderCheckout', 'cancelService', 'rescheduleService'],
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { s4ServiceTranslationChunksConfig, cs as s4ServiceTranslationsCs, de as s4ServiceTranslationsDe, en as s4ServiceTranslationsEn, es as s4ServiceTranslationsEs, es_CO as s4ServiceTranslationsEs_CO, fr as s4ServiceTranslationsFr, hi as s4ServiceTranslationsHi, hu as s4ServiceTranslationsHu, id as s4ServiceTranslationsId, it as s4ServiceTranslationsIt, ja as s4ServiceTranslationsJa, ko as s4ServiceTranslationsKo, pl as s4ServiceTranslationsPl, pt as s4ServiceTranslationsPt, ru as s4ServiceTranslationsRu, zh as s4ServiceTranslationsZh, zh_TW as s4ServiceTranslationsZh_TW };
//# sourceMappingURL=spartacus-s4-service-assets.mjs.map
