import * as i0 from '@angular/core';
import { inject, Optional, Component, Injectable, NgModule, ChangeDetectionStrategy } from '@angular/core';
import { NgIf, AsyncPipe, CommonModule, DatePipe, NgFor } from '@angular/common';
import { TranslationService, ProductTypes, I18nModule, TranslatePipe, UrlModule, provideDefaultConfig, AuthGuard, GlobalMessageService, GlobalMessageType, SemanticPathService, RoutingService, UrlPipe, UserIdService, CxDatePipe, OccEndpointsService, LoggerService, tryNormalizeHttpError } from '@spartacus/core';
import { OrderOverviewComponentService, OrderDetailsService, OrderDetailActionsComponent } from '@spartacus/order/components';
import { OrderOutlets, OrderHistoryFacade } from '@spartacus/order/root';
import { OutletContextData, CardComponent, CardModule, provideOutlet, OutletDirective, PromotionsModule, IconModule, OutletModule, SpinnerModule, DatePickerModule, FormRequiredLegendComponent, FormRequiredAsterisksComponent, DatePickerComponent, BtnLikeLinkDirective, BtnLikeLinkModule } from '@spartacus/storefront';
import { CheckoutServiceSchedulePickerService, S4ServiceDeliveryModeConfig, CancelServiceOrderFacade, RescheduleServiceOrderFacade } from '@spartacus/s4-service/root';
import { Subscription, map, throwError, Subject, takeUntil, combineLatest, tap, catchError } from 'rxjs';
import { RouterModule, Router, RouterLink } from '@angular/router';
import { CartOutlets } from '@spartacus/cart/base/root';
import { map as map$1, mergeMap, switchMap } from 'rxjs/operators';
import * as i1 from '@angular/forms';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ServiceDetailsCardComponent {
    constructor() {
        this.translationService = inject(TranslationService);
        this.checkoutServiceSchedulePickerService = inject(CheckoutServiceSchedulePickerService);
        this.orderOutlet = inject(OutletContextData);
        this.subscription = new Subscription();
    }
    ngOnInit() {
        if (this.orderOutlet?.context$) {
            this.subscription.add(this.orderOutlet.context$.subscribe((context) => (this.order = context?.item)));
        }
    }
    showServiceDetails() {
        let hasService = false;
        //Note: Pick up option is not applicable for Service Products
        const deliveryEntries = this.order.entries?.filter((entry) => entry.deliveryPointOfService === undefined) || [];
        deliveryEntries.forEach((entry) => {
            if (entry.product?.productTypes === ProductTypes.SERVICE) {
                hasService = true;
            }
        });
        return hasService;
    }
    getServiceDetailsCard(scheduledAt) {
        return this.translationService
            .translate('serviceOrderCheckout.serviceDetails')
            .pipe(map((textTitle) => {
            if (scheduledAt) {
                scheduledAt =
                    this.checkoutServiceSchedulePickerService.convertDateTimeToReadableString(scheduledAt);
            }
            return {
                title: textTitle,
                textBold: scheduledAt?.split(',')[0],
                text: [scheduledAt?.split(',')[1].trim() ?? ''],
            };
        }));
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceDetailsCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: ServiceDetailsCardComponent, isStandalone: true, selector: "cx-card-service-details", ngImport: i0, template: "<ng-container *ngIf=\"showServiceDetails()\">\n  <cx-card\n    [content]=\"getServiceDetailsCard(order.servicedAt) | async\"\n  ></cx-card>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CardComponent, selector: "cx-card", inputs: ["border", "editMode", "isDefault", "content", "fitToContainer", "truncateText", "truncateParagraphText", "charactersLimit", "index", "role"], outputs: ["deleteCard", "setDefaultCard", "sendCard", "editCard", "cancelCard"] }, { kind: "pipe", type: AsyncPipe, name: "async" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceDetailsCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-card-service-details', imports: [NgIf, CardComponent, AsyncPipe], template: "<ng-container *ngIf=\"showServiceDetails()\">\n  <cx-card\n    [content]=\"getServiceDetailsCard(order.servicedAt) | async\"\n  ></cx-card>\n</ng-container>\n" }]
        }], propDecorators: { orderOutlet: [{
                type: Optional
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ServiceOrderOverviewComponentService extends OrderOverviewComponentService {
    constructor() {
        super(...arguments);
        this.config = inject(S4ServiceDeliveryModeConfig);
    }
    shouldShowDeliveryMode(mode) {
        return mode?.code === this.config.s4ServiceDeliveryMode?.code
            ? false
            : super.shouldShowDeliveryMode(mode);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceOrderOverviewComponentService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceOrderOverviewComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceOrderOverviewComponentService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ServiceDetailsCardModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceDetailsCardModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: ServiceDetailsCardModule, imports: [CardModule, CommonModule, I18nModule, ServiceDetailsCardComponent], exports: [ServiceDetailsCardComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceDetailsCardModule, providers: [
            ServiceOrderOverviewComponentService,
            {
                provide: OrderOverviewComponentService,
                useExisting: ServiceOrderOverviewComponentService,
            },
            provideOutlet({
                id: OrderOutlets.SERVICE_DETAILS,
                component: ServiceDetailsCardComponent,
            }),
        ], imports: [CardModule, CommonModule, I18nModule, ServiceDetailsCardComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceDetailsCardModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CardModule, CommonModule, I18nModule, ServiceDetailsCardComponent],
                    providers: [
                        ServiceOrderOverviewComponentService,
                        {
                            provide: OrderOverviewComponentService,
                            useExisting: ServiceOrderOverviewComponentService,
                        },
                        provideOutlet({
                            id: OrderOutlets.SERVICE_DETAILS,
                            component: ServiceDetailsCardComponent,
                        }),
                    ],
                    exports: [ServiceDetailsCardComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CancelServiceOrderHeadlineComponent {
    constructor() {
        this.orderDetailsService = inject(OrderDetailsService);
        this.order$ = this.orderDetailsService.getOrderDetails().pipe(map$1((order) => ({
            ...order,
            entries: (order.entries || []).filter((entry) => entry.product && entry.product.productTypes === ProductTypes.SERVICE),
        })));
        this.CartOutlets = CartOutlets;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderHeadlineComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CancelServiceOrderHeadlineComponent, isStandalone: true, selector: "cx-cancel-service-order-headline", ngImport: i0, template: "<p\n  class=\"cx-checkout-title d-none d-lg-block d-xl-block text-center\"\n  [attr.aria-label]=\"'cancelService.heading' | cxTranslate\"\n>\n  {{ 'cancelService.heading' | cxTranslate }}\n</p>\n\n<ng-container *ngIf=\"order$ | async as order\">\n  <div class=\"mt-3 mb-3 service-table\" *ngIf=\"order.entries?.length\">\n    <h3 class=\"service-header\">{{ 'cancelService.Services' | cxTranslate }}</h3>\n    <div class=\"m-4\">\n      <table class=\"table table-bordered border-0\">\n        <thead class=\"thead-padding\">\n          <tr>\n            <th>{{ 'cancelService.ServiceDate' | cxTranslate }}</th>\n            <th>{{ 'cancelService.ServiceTime' | cxTranslate }}</th>\n            <th>{{ 'cancelService.ServiceLocation' | cxTranslate }}</th>\n          </tr>\n        </thead>\n        <tbody class=\"tbody-padding\">\n          <tr class=\"service-row\">\n            <td>{{ order.servicedAt | date: 'MM/dd/yyyy' }}</td>\n            <td>{{ order.servicedAt | date: 'HH:mm' }}</td>\n            <td>{{ order.deliveryAddress?.town }}</td>\n          </tr>\n        </tbody>\n      </table>\n    </div>\n  </div>\n  <ng-container *ngIf=\"order.entries?.length\">\n    <ng-template\n      [cxOutlet]=\"CartOutlets.CART_ITEM_LIST\"\n      [cxOutletContext]=\"{\n        items: order.entries,\n        readonly: true,\n      }\"\n    >\n    </ng-template>\n  </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: OutletDirective, selector: "[cxOutlet]", inputs: ["cxOutlet", "cxOutletContext", "cxOutletDefer", "cxComponentRef"], outputs: ["loaded", "cxComponentRefChange"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: DatePipe, name: "date" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderHeadlineComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-cancel-service-order-headline', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, OutletDirective, AsyncPipe, DatePipe, TranslatePipe], template: "<p\n  class=\"cx-checkout-title d-none d-lg-block d-xl-block text-center\"\n  [attr.aria-label]=\"'cancelService.heading' | cxTranslate\"\n>\n  {{ 'cancelService.heading' | cxTranslate }}\n</p>\n\n<ng-container *ngIf=\"order$ | async as order\">\n  <div class=\"mt-3 mb-3 service-table\" *ngIf=\"order.entries?.length\">\n    <h3 class=\"service-header\">{{ 'cancelService.Services' | cxTranslate }}</h3>\n    <div class=\"m-4\">\n      <table class=\"table table-bordered border-0\">\n        <thead class=\"thead-padding\">\n          <tr>\n            <th>{{ 'cancelService.ServiceDate' | cxTranslate }}</th>\n            <th>{{ 'cancelService.ServiceTime' | cxTranslate }}</th>\n            <th>{{ 'cancelService.ServiceLocation' | cxTranslate }}</th>\n          </tr>\n        </thead>\n        <tbody class=\"tbody-padding\">\n          <tr class=\"service-row\">\n            <td>{{ order.servicedAt | date: 'MM/dd/yyyy' }}</td>\n            <td>{{ order.servicedAt | date: 'HH:mm' }}</td>\n            <td>{{ order.deliveryAddress?.town }}</td>\n          </tr>\n        </tbody>\n      </table>\n    </div>\n  </div>\n  <ng-container *ngIf=\"order.entries?.length\">\n    <ng-template\n      [cxOutlet]=\"CartOutlets.CART_ITEM_LIST\"\n      [cxOutletContext]=\"{\n        items: order.entries,\n        readonly: true,\n      }\"\n    >\n    </ng-template>\n  </ng-container>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CancelServiceOrderHeadlineModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderHeadlineModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderHeadlineModule, imports: [CommonModule,
            RouterModule,
            I18nModule,
            CardModule,
            UrlModule,
            PromotionsModule,
            IconModule,
            OutletModule,
            CancelServiceOrderHeadlineComponent], exports: [CancelServiceOrderHeadlineComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderHeadlineModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    CancelServiceOrderHeadline: {
                        component: CancelServiceOrderHeadlineComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            RouterModule,
            I18nModule,
            CardModule,
            UrlModule,
            PromotionsModule,
            IconModule,
            OutletModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderHeadlineModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        I18nModule,
                        CardModule,
                        UrlModule,
                        PromotionsModule,
                        IconModule,
                        OutletModule,
                        CancelServiceOrderHeadlineComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                CancelServiceOrderHeadline: {
                                    component: CancelServiceOrderHeadlineComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                    ],
                    exports: [CancelServiceOrderHeadlineComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ServiceOrderGuard {
    constructor() {
        this.orderDetailsService = inject(OrderDetailsService);
        this.globalMessageService = inject(GlobalMessageService);
    }
    canActivate() {
        return this.orderDetailsService.getOrderDetails().pipe(map((orderDetails) => {
            if (orderDetails && orderDetails.serviceReschedulable) {
                return true;
            }
            else {
                this.globalMessageService.add({ key: 'rescheduleService.serviceNotReschedulable' }, GlobalMessageType.MSG_TYPE_ERROR);
                return false;
            }
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceOrderGuard, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceOrderGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceOrderGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CancelServiceOrderGuard {
    constructor() {
        this.orderDetailsService = inject(OrderDetailsService);
        this.router = inject(Router);
        this.semanticPathService = inject(SemanticPathService);
    }
    canActivate() {
        return this.orderDetailsService.getOrderDetails().pipe(map((orderDetails) => {
            if (orderDetails &&
                Object.keys(orderDetails).length > 0 &&
                orderDetails.serviceCancellable) {
                return true;
            }
            else {
                return this.router.parseUrl(this.semanticPathService.get('orders') ?? '');
            }
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderGuard, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CancelServiceOrderComponent {
    constructor() {
        this.orderDetailsService = inject(OrderDetailsService);
        this.cancelServiceOrderFacade = inject(CancelServiceOrderFacade);
        this.fb = inject(FormBuilder);
        this.globalMessageService = inject(GlobalMessageService);
        this.routingService = inject(RoutingService);
        this.order$ = this.orderDetailsService.getOrderDetails();
        this.characterLeft = 255;
        this.form = this.fb.group({
            cancelReason: [null, Validators.maxLength(255)],
        });
    }
    cancelServiceOrder() {
        const cancelReason = this.form.get('cancelReason')?.value || '';
        this.order$
            .pipe(mergeMap((order) => {
            if (order) {
                const cancellationDetails = {
                    cancellationRequestEntryInputs: order.entries.map((entry) => ({
                        orderEntryNumber: entry.entryNumber,
                        quantity: entry.quantity,
                    })),
                    cancelReason: cancelReason,
                };
                return this.cancelServiceOrderFacade.cancelService(order.code, cancellationDetails);
            }
            else {
                return throwError(() => new Error('Order details are not available'));
            }
        }), mergeMap(() => this.order$), mergeMap((order) => this.routingService.go({
            cxRoute: 'orderDetails',
            params: { code: order.code },
        })))
            .subscribe({
            next: () => {
                this.globalMessageService.add({ key: 'cancelService.cancelServiceSuccess' }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
            },
            error: () => this.onError(),
        });
    }
    onError() {
        this.globalMessageService.add({ key: 'cancelService.unknownError' }, GlobalMessageType.MSG_TYPE_ERROR);
    }
    updateCharacterLeft() {
        const cancelReason = this.form.get('cancelReason')?.value || '';
        this.characterLeft = 255 - cancelReason.length;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CancelServiceOrderComponent, isStandalone: true, selector: "cx-cancel-service-order", ngImport: i0, template: "<form [formGroup]=\"form\" (ngSubmit)=\"cancelServiceOrder()\">\n  <div class=\"form-group\">\n    <label for=\"reasonTextarea\"\n      >{{ 'cancelService.cancelReason' | cxTranslate }}\n      <span class=\"optional\">{{\n        'cancelService.optional' | cxTranslate\n      }}</span></label\n    >\n    <textarea\n      id=\"reasonTextarea\"\n      class=\"form-control\"\n      formControlName=\"cancelReason\"\n      rows=\"5\"\n      (input)=\"updateCharacterLeft()\"\n    ></textarea>\n    <div class=\"characters-left\">\n      <span>{{\n        'cancelService.charactersLeft' | cxTranslate: { count: characterLeft }\n      }}</span>\n    </div>\n  </div>\n\n  <div class=\"row mt-5\">\n    <div class=\"col-xs-12 col-md-6 col-lg-6\">\n      <button\n        type=\"button\"\n        class=\"btn btn-secondary btn-block back-button\"\n        *ngIf=\"order$ | async as order\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orderDetails',\n            params: order,\n          } | cxUrl\n        \"\n      >\n        {{ 'common.back' | cxTranslate }}\n      </button>\n    </div>\n    <div class=\"col-xs-12 col-md-6 col-lg-6\">\n      <button type=\"submit\" class=\"btn btn-primary btn-block\">\n        {{ 'cancelService.SubmitRequest' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</form>\n", dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-cancel-service-order', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        FormsModule,
                        ReactiveFormsModule,
                        NgIf,
                        RouterLink,
                        AsyncPipe,
                        TranslatePipe,
                        UrlPipe,
                    ], template: "<form [formGroup]=\"form\" (ngSubmit)=\"cancelServiceOrder()\">\n  <div class=\"form-group\">\n    <label for=\"reasonTextarea\"\n      >{{ 'cancelService.cancelReason' | cxTranslate }}\n      <span class=\"optional\">{{\n        'cancelService.optional' | cxTranslate\n      }}</span></label\n    >\n    <textarea\n      id=\"reasonTextarea\"\n      class=\"form-control\"\n      formControlName=\"cancelReason\"\n      rows=\"5\"\n      (input)=\"updateCharacterLeft()\"\n    ></textarea>\n    <div class=\"characters-left\">\n      <span>{{\n        'cancelService.charactersLeft' | cxTranslate: { count: characterLeft }\n      }}</span>\n    </div>\n  </div>\n\n  <div class=\"row mt-5\">\n    <div class=\"col-xs-12 col-md-6 col-lg-6\">\n      <button\n        type=\"button\"\n        class=\"btn btn-secondary btn-block back-button\"\n        *ngIf=\"order$ | async as order\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orderDetails',\n            params: order,\n          } | cxUrl\n        \"\n      >\n        {{ 'common.back' | cxTranslate }}\n      </button>\n    </div>\n    <div class=\"col-xs-12 col-md-6 col-lg-6\">\n      <button type=\"submit\" class=\"btn btn-primary btn-block\">\n        {{ 'cancelService.SubmitRequest' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</form>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CancelServiceOrderModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderModule, imports: [CommonModule,
            I18nModule,
            SpinnerModule,
            DatePickerModule,
            ReactiveFormsModule,
            UrlModule,
            RouterModule,
            CancelServiceOrderComponent], exports: [CancelServiceOrderComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    CancelServiceOrder: {
                        component: CancelServiceOrderComponent,
                        guards: [AuthGuard, CancelServiceOrderGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            SpinnerModule,
            DatePickerModule,
            ReactiveFormsModule,
            UrlModule,
            RouterModule,
            CancelServiceOrderComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        SpinnerModule,
                        DatePickerModule,
                        ReactiveFormsModule,
                        UrlModule,
                        RouterModule,
                        CancelServiceOrderComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                CancelServiceOrder: {
                                    component: CancelServiceOrderComponent,
                                    guards: [AuthGuard, CancelServiceOrderGuard],
                                },
                            },
                        }),
                    ],
                    exports: [CancelServiceOrderComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class RescheduleServiceOrderComponent {
    constructor() {
        this.orderDetailsService = inject(OrderDetailsService);
        this.rescheduleServiceOrderFacade = inject(RescheduleServiceOrderFacade);
        this.routingService = inject(RoutingService);
        this.globalMessageService = inject(GlobalMessageService);
        this.fb = inject(FormBuilder);
        this.checkoutServiceSchedulePickerService = inject(CheckoutServiceSchedulePickerService);
        this.CartOutlets = CartOutlets;
        this.order$ = this.orderDetailsService.getOrderDetails().pipe(map((order) => ({
            ...order,
            entries: (order.entries || []).filter((entry) => entry.product && entry.product.productTypes === ProductTypes.SERVICE),
        })));
        this.subscription = new Subject();
        this.minServiceDate$ = this.checkoutServiceSchedulePickerService.getMinDateForService();
        this.scheduleTimes$ = this.checkoutServiceSchedulePickerService.getScheduledServiceTimes();
        this.form = this.fb.group({
            scheduleDate: [null, Validators.required],
            scheduleTime: [null, Validators.required],
        });
    }
    ngOnInit() {
        this.order$.pipe(takeUntil(this.subscription)).subscribe((orderDetails) => {
            this.orderCode = orderDetails.code || '';
            this.initializeForm(orderDetails);
        });
    }
    initializeForm(order) {
        const servicedAt = order.servicedAt;
        if (servicedAt && servicedAt !== '') {
            const info = this.checkoutServiceSchedulePickerService.getServiceDetailsFromDateTime(servicedAt);
            this.form.patchValue({
                scheduleDate: info.date,
                scheduleTime: info.time,
            });
        }
        else {
            combineLatest([this.minServiceDate$, this.scheduleTimes$]).subscribe(([minDate, scheduleTime]) => {
                this.form.patchValue({
                    scheduleDate: minDate,
                    scheduleTime: scheduleTime[0],
                });
            });
        }
    }
    setScheduleTime(event) {
        const target = event.target;
        const value = target.value;
        this.form.patchValue({
            scheduleTime: value,
        });
    }
    rescheduleServiceOrder() {
        const scheduleDate = this.form?.get('scheduleDate')?.value || '';
        const scheduleTime = this.form?.get('scheduleTime')?.value || '';
        this.dateTime = this.checkoutServiceSchedulePickerService.convertToDateTime(scheduleDate, scheduleTime);
        this.rescheduleServiceOrderFacade
            .rescheduleService(this.orderCode, this.dateTime)
            .subscribe({
            next: () => {
                this.routingService.go({
                    cxRoute: 'orderDetails',
                    params: { code: this.orderCode },
                });
                this.globalMessageService.add({ key: 'rescheduleService.rescheduleSuccess' }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
            },
            error: () => {
                this.globalMessageService.add({ key: 'rescheduleService.unknownError' }, GlobalMessageType.MSG_TYPE_ERROR);
            },
        });
    }
    ngOnDestroy() {
        this.subscription.next();
        this.subscription.complete();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RescheduleServiceOrderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: RescheduleServiceOrderComponent, isStandalone: true, selector: "cx-reschedule-service-order", ngImport: i0, template: "<form [formGroup]=\"form\" (submit)=\"rescheduleServiceOrder()\">\n  <cx-form-required-legend />\n  <div class=\"cx-reschedule-service-form-fields\">\n    <div class=\"cx-section-header d-none d-lg-block d-xl-block\">\n      <h2>{{ 'rescheduleService.headerLabel' | cxTranslate }}</h2>\n    </div>\n\n    <div class=\"cx-section-content\">\n      <p>{{ 'rescheduleService.contentLabel' | cxTranslate }}</p>\n      <div class=\"row\">\n        <label\n          class=\"col-md-6\"\n          [attr.aria-label]=\"'rescheduleService.datePickerLabel' | cxTranslate\"\n        >\n          <span class=\"label-content\">\n            {{ 'rescheduleService.datePickerLabel' | cxTranslate }}\n            <cx-form-required-asterisks />\n          </span>\n          <cx-date-picker\n            [control]=\"$any(form.get('scheduleDate'))\"\n            [min]=\"(minServiceDate$ | async) ?? undefined\"\n            label=\"rescheduleService.datePickerLabel\"\n          />\n        </label>\n\n        <label\n          class=\"col-md-6\"\n          [attr.aria-label]=\"'rescheduleService.timePickerLabel' | cxTranslate\"\n        >\n          <span class=\"label-content\">\n            {{ 'rescheduleService.timePickerLabel' | cxTranslate }}\n            <cx-form-required-asterisks />\n          </span>\n          <select\n            *ngIf=\"scheduleTimes$ | async as scheduleTimes\"\n            class=\"form-control\"\n            formControlName=\"scheduleTime\"\n            (change)=\"setScheduleTime($event)\"\n          >\n            <option\n              *ngFor=\"let time of scheduleTimes\"\n              [value]=\"time\"\n              [selected]=\"form.get('scheduleTime')?.value === time\"\n            >\n              {{ time }}\n            </option>\n          </select>\n        </label>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"cx-reschedule-service-details\">\n    <ng-template\n      *ngIf=\"order$ | async as order\"\n      [cxOutlet]=\"CartOutlets.CART_ITEM_LIST\"\n      [cxOutletContext]=\"{\n        items: order.entries,\n        readonly: true,\n      }\"\n    >\n    </ng-template>\n  </div>\n\n  <div class=\"cx-reschedule-service-actions\">\n    <div class=\"row\">\n      <div class=\"col-sm-12 col-xl-6\">\n        <button\n          type=\"button\"\n          class=\"btn btn-secondary btn-block\"\n          *ngIf=\"order$ | async as order\"\n          [routerLink]=\"\n            {\n              cxRoute: 'orderDetails',\n              params: order,\n            } | cxUrl\n          \"\n          [attr.aria-label]=\"'rescheduleService.backButtonLabel' | cxTranslate\"\n        >\n          {{ 'rescheduleService.backButtonLabel' | cxTranslate }}\n        </button>\n      </div>\n      <div class=\"col-sm-12 col-xl-6\">\n        <button\n          type=\"submit\"\n          class=\"btn btn-primary btn-block\"\n          [disabled]=\"!(form.valid && form.dirty)\"\n          [attr.aria-label]=\"\n            'rescheduleService.submitButtonLabel' | cxTranslate\n          \"\n        >\n          {{ 'rescheduleService.submitButtonLabel' | cxTranslate }}\n        </button>\n      </div>\n      <div class=\"col-12\">\n        <p class=\"text-center\">{{ 'rescheduleService.note' | cxTranslate }}</p>\n      </div>\n    </div>\n  </div>\n</form>\n", dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: DatePickerComponent, selector: "cx-date-picker", inputs: ["control", "min", "max", "required", "label"], outputs: ["update"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: OutletDirective, selector: "[cxOutlet]", inputs: ["cxOutlet", "cxOutletContext", "cxOutletDefer", "cxComponentRef"], outputs: ["loaded", "cxComponentRefChange"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RescheduleServiceOrderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-reschedule-service-order', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredLegendComponent,
                        FormRequiredAsterisksComponent,
                        DatePickerComponent,
                        NgIf,
                        NgFor,
                        OutletDirective,
                        RouterLink,
                        AsyncPipe,
                        TranslatePipe,
                        UrlPipe,
                    ], template: "<form [formGroup]=\"form\" (submit)=\"rescheduleServiceOrder()\">\n  <cx-form-required-legend />\n  <div class=\"cx-reschedule-service-form-fields\">\n    <div class=\"cx-section-header d-none d-lg-block d-xl-block\">\n      <h2>{{ 'rescheduleService.headerLabel' | cxTranslate }}</h2>\n    </div>\n\n    <div class=\"cx-section-content\">\n      <p>{{ 'rescheduleService.contentLabel' | cxTranslate }}</p>\n      <div class=\"row\">\n        <label\n          class=\"col-md-6\"\n          [attr.aria-label]=\"'rescheduleService.datePickerLabel' | cxTranslate\"\n        >\n          <span class=\"label-content\">\n            {{ 'rescheduleService.datePickerLabel' | cxTranslate }}\n            <cx-form-required-asterisks />\n          </span>\n          <cx-date-picker\n            [control]=\"$any(form.get('scheduleDate'))\"\n            [min]=\"(minServiceDate$ | async) ?? undefined\"\n            label=\"rescheduleService.datePickerLabel\"\n          />\n        </label>\n\n        <label\n          class=\"col-md-6\"\n          [attr.aria-label]=\"'rescheduleService.timePickerLabel' | cxTranslate\"\n        >\n          <span class=\"label-content\">\n            {{ 'rescheduleService.timePickerLabel' | cxTranslate }}\n            <cx-form-required-asterisks />\n          </span>\n          <select\n            *ngIf=\"scheduleTimes$ | async as scheduleTimes\"\n            class=\"form-control\"\n            formControlName=\"scheduleTime\"\n            (change)=\"setScheduleTime($event)\"\n          >\n            <option\n              *ngFor=\"let time of scheduleTimes\"\n              [value]=\"time\"\n              [selected]=\"form.get('scheduleTime')?.value === time\"\n            >\n              {{ time }}\n            </option>\n          </select>\n        </label>\n      </div>\n    </div>\n  </div>\n\n  <div class=\"cx-reschedule-service-details\">\n    <ng-template\n      *ngIf=\"order$ | async as order\"\n      [cxOutlet]=\"CartOutlets.CART_ITEM_LIST\"\n      [cxOutletContext]=\"{\n        items: order.entries,\n        readonly: true,\n      }\"\n    >\n    </ng-template>\n  </div>\n\n  <div class=\"cx-reschedule-service-actions\">\n    <div class=\"row\">\n      <div class=\"col-sm-12 col-xl-6\">\n        <button\n          type=\"button\"\n          class=\"btn btn-secondary btn-block\"\n          *ngIf=\"order$ | async as order\"\n          [routerLink]=\"\n            {\n              cxRoute: 'orderDetails',\n              params: order,\n            } | cxUrl\n          \"\n          [attr.aria-label]=\"'rescheduleService.backButtonLabel' | cxTranslate\"\n        >\n          {{ 'rescheduleService.backButtonLabel' | cxTranslate }}\n        </button>\n      </div>\n      <div class=\"col-sm-12 col-xl-6\">\n        <button\n          type=\"submit\"\n          class=\"btn btn-primary btn-block\"\n          [disabled]=\"!(form.valid && form.dirty)\"\n          [attr.aria-label]=\"\n            'rescheduleService.submitButtonLabel' | cxTranslate\n          \"\n        >\n          {{ 'rescheduleService.submitButtonLabel' | cxTranslate }}\n        </button>\n      </div>\n      <div class=\"col-12\">\n        <p class=\"text-center\">{{ 'rescheduleService.note' | cxTranslate }}</p>\n      </div>\n    </div>\n  </div>\n</form>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class RescheduleServiceOrderModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RescheduleServiceOrderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: RescheduleServiceOrderModule, imports: [CommonModule,
            CardModule,
            I18nModule,
            OutletModule,
            UrlModule,
            RouterModule,
            SpinnerModule,
            DatePickerModule,
            ReactiveFormsModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            RescheduleServiceOrderComponent], exports: [RescheduleServiceOrderComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RescheduleServiceOrderModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    RescheduleServiceOrder: {
                        component: RescheduleServiceOrderComponent,
                        guards: [AuthGuard, ServiceOrderGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            CardModule,
            I18nModule,
            OutletModule,
            UrlModule,
            RouterModule,
            SpinnerModule,
            DatePickerModule,
            ReactiveFormsModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            RescheduleServiceOrderComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RescheduleServiceOrderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        CardModule,
                        I18nModule,
                        OutletModule,
                        UrlModule,
                        RouterModule,
                        SpinnerModule,
                        DatePickerModule,
                        ReactiveFormsModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        RescheduleServiceOrderComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                RescheduleServiceOrder: {
                                    component: RescheduleServiceOrderComponent,
                                    guards: [AuthGuard, ServiceOrderGuard],
                                },
                            },
                        }),
                    ],
                    exports: [RescheduleServiceOrderComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class S4ServiceOrderDetailActionsComponent extends OrderDetailActionsComponent {
    constructor() {
        super(...arguments);
        this.checkoutServiceSchedulePickerService = inject(CheckoutServiceSchedulePickerService);
        this.globalMessageService = inject(GlobalMessageService);
        /**
         * @deprecated since 221121.1 - Displaying the individual action buttons will depend on their boolean flags from API response.
         */
        this.displayActions$ = this.order$.pipe(map((order) => this.checkServiceStatus(order)));
    }
    ngOnInit() {
        this.order$.pipe(tap((order) => this.displayServiceMessage(order)));
    }
    /**
     * @deprecated since 221121.1 - Displaying the individual action buttons will depend on their boolean flags from API response.
     * Displaying notification for a service not amendable will be carried out by 'displayServiceMessage' instead.
     */
    checkServiceStatus(order) {
        if (order && order.status === 'CANCELLED') {
            return false;
        }
        else if (order && order.servicedAt) {
            const hoursFromSchedule = this.checkoutServiceSchedulePickerService.getHoursFromServiceSchedule(order.servicedAt);
            if (hoursFromSchedule > 0 && hoursFromSchedule <= 24) {
                this.globalMessageService.add({ key: 'rescheduleService.serviceNotAmendable' }, GlobalMessageType.MSG_TYPE_INFO);
                return false;
            }
            else if (hoursFromSchedule > 24) {
                return true;
            }
        }
        return true;
    }
    displayServiceMessage(order) {
        if (order.status !== 'CANCELLED' && !!order.servicedAt) {
            const hoursFromSchedule = this.checkoutServiceSchedulePickerService.getHoursFromServiceSchedule(order.servicedAt);
            if (hoursFromSchedule > 0 && hoursFromSchedule <= 24) {
                this.globalMessageService.add({ key: 'rescheduleService.serviceNotAmendable' }, GlobalMessageType.MSG_TYPE_INFO);
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderDetailActionsComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: S4ServiceOrderDetailActionsComponent, isStandalone: true, selector: "cx-s4-service-order-detail-actions", usesInheritance: true, ngImport: i0, template: "<ng-container *ngIf=\"order$ | async as order\">\n  <div class=\"cx-order-details-actions row mt-3\">\n    <div class=\"col-12 d-flex justify-content-end\">\n      <span class=\"cx-action-button ml-2\">\n        <a\n          id=\"cancel-items-btn\"\n          *ngIf=\"order.cancellable\"\n          [routerLink]=\"\n            {\n              cxRoute: 'orderCancel',\n              params: order,\n            } | cxUrl\n          \"\n          [attr.aria-label]=\"\n            'myAccountV2OrderDetails.cancelItems' | cxTranslate\n          \"\n          class=\"btn btn-secondary\"\n          cxBtnLikeLink\n        >\n          {{ 'myAccountV2OrderDetails.cancelItems' | cxTranslate }}\n        </a>\n      </span>\n      <span class=\"cx-action-button ml-2\">\n        <a\n          id=\"return-items-btn\"\n          *ngIf=\"order.returnable\"\n          [routerLink]=\"\n            {\n              cxRoute: 'orderReturn',\n              params: order,\n            } | cxUrl\n          \"\n          [attr.aria-label]=\"\n            'myAccountV2OrderDetails.returnItems' | cxTranslate\n          \"\n          class=\"btn btn-secondary\"\n          cxBtnLikeLink\n        >\n          {{ 'myAccountV2OrderDetails.returnItems' | cxTranslate }}\n        </a>\n      </span>\n      <span class=\"cx-action-button cancel-service-btn-container ml-2\">\n        <a\n          id=\"cancel-service-btn\"\n          *ngIf=\"order.serviceCancellable\"\n          [routerLink]=\"\n            {\n              cxRoute: 'cancelServiceDetails',\n              params: order,\n            } | cxUrl\n          \"\n          [attr.aria-label]=\"'cancelService.action' | cxTranslate\"\n          class=\"btn btn-secondary\"\n          cxBtnLikeLink\n        >\n          {{ 'cancelService.action' | cxTranslate }}\n        </a>\n      </span>\n      <span class=\"cx-action-button reschedule-service-btn-container ml-2\">\n        <a\n          id=\"reschedule-service-btn\"\n          *ngIf=\"order.serviceReschedulable\"\n          [routerLink]=\"\n            {\n              cxRoute: 'rescheduleServiceDetails',\n              params: order,\n            } | cxUrl\n          \"\n          [attr.aria-label]=\"\n            'rescheduleService.actionButtonLabel' | cxTranslate\n          \"\n          class=\"btn btn-secondary\"\n          cxBtnLikeLink\n        >\n          {{ 'rescheduleService.actionButtonLabel' | cxTranslate }}\n        </a>\n      </span>\n    </div>\n  </div>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: BtnLikeLinkDirective, selector: "a[cxBtnLikeLink].btn" }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderDetailActionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-s4-service-order-detail-actions', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        BtnLikeLinkDirective,
                        RouterLink,
                        AsyncPipe,
                        TranslatePipe,
                        UrlPipe,
                    ], template: "<ng-container *ngIf=\"order$ | async as order\">\n  <div class=\"cx-order-details-actions row mt-3\">\n    <div class=\"col-12 d-flex justify-content-end\">\n      <span class=\"cx-action-button ml-2\">\n        <a\n          id=\"cancel-items-btn\"\n          *ngIf=\"order.cancellable\"\n          [routerLink]=\"\n            {\n              cxRoute: 'orderCancel',\n              params: order,\n            } | cxUrl\n          \"\n          [attr.aria-label]=\"\n            'myAccountV2OrderDetails.cancelItems' | cxTranslate\n          \"\n          class=\"btn btn-secondary\"\n          cxBtnLikeLink\n        >\n          {{ 'myAccountV2OrderDetails.cancelItems' | cxTranslate }}\n        </a>\n      </span>\n      <span class=\"cx-action-button ml-2\">\n        <a\n          id=\"return-items-btn\"\n          *ngIf=\"order.returnable\"\n          [routerLink]=\"\n            {\n              cxRoute: 'orderReturn',\n              params: order,\n            } | cxUrl\n          \"\n          [attr.aria-label]=\"\n            'myAccountV2OrderDetails.returnItems' | cxTranslate\n          \"\n          class=\"btn btn-secondary\"\n          cxBtnLikeLink\n        >\n          {{ 'myAccountV2OrderDetails.returnItems' | cxTranslate }}\n        </a>\n      </span>\n      <span class=\"cx-action-button cancel-service-btn-container ml-2\">\n        <a\n          id=\"cancel-service-btn\"\n          *ngIf=\"order.serviceCancellable\"\n          [routerLink]=\"\n            {\n              cxRoute: 'cancelServiceDetails',\n              params: order,\n            } | cxUrl\n          \"\n          [attr.aria-label]=\"'cancelService.action' | cxTranslate\"\n          class=\"btn btn-secondary\"\n          cxBtnLikeLink\n        >\n          {{ 'cancelService.action' | cxTranslate }}\n        </a>\n      </span>\n      <span class=\"cx-action-button reschedule-service-btn-container ml-2\">\n        <a\n          id=\"reschedule-service-btn\"\n          *ngIf=\"order.serviceReschedulable\"\n          [routerLink]=\"\n            {\n              cxRoute: 'rescheduleServiceDetails',\n              params: order,\n            } | cxUrl\n          \"\n          [attr.aria-label]=\"\n            'rescheduleService.actionButtonLabel' | cxTranslate\n          \"\n          class=\"btn btn-secondary\"\n          cxBtnLikeLink\n        >\n          {{ 'rescheduleService.actionButtonLabel' | cxTranslate }}\n        </a>\n      </span>\n    </div>\n  </div>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class S4ServiceOrderDetailActionsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderDetailActionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderDetailActionsModule, imports: [CommonModule,
            I18nModule,
            RouterModule,
            UrlModule,
            BtnLikeLinkModule,
            S4ServiceOrderDetailActionsComponent], exports: [S4ServiceOrderDetailActionsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderDetailActionsModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    AccountOrderDetailsActionsComponent: {
                        component: S4ServiceOrderDetailActionsComponent,
                        //guards: inherited from standard config,
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            RouterModule,
            UrlModule,
            BtnLikeLinkModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderDetailActionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        RouterModule,
                        UrlModule,
                        BtnLikeLinkModule,
                        S4ServiceOrderDetailActionsComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                AccountOrderDetailsActionsComponent: {
                                    component: S4ServiceOrderDetailActionsComponent,
                                    //guards: inherited from standard config,
                                },
                            },
                        }),
                    ],
                    exports: [S4ServiceOrderDetailActionsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class S4ServiceComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceComponentsModule, imports: [ServiceDetailsCardModule,
            CancelServiceOrderModule,
            CancelServiceOrderHeadlineModule,
            RescheduleServiceOrderModule,
            S4ServiceOrderDetailActionsModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceComponentsModule, imports: [ServiceDetailsCardModule,
            CancelServiceOrderModule,
            CancelServiceOrderHeadlineModule,
            RescheduleServiceOrderModule,
            S4ServiceOrderDetailActionsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        ServiceDetailsCardModule,
                        CancelServiceOrderModule,
                        CancelServiceOrderHeadlineModule,
                        RescheduleServiceOrderModule,
                        S4ServiceOrderDetailActionsModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CancelServiceOrderAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CancelServiceOrderConnector {
    constructor() {
        this.cancelServiceOrderAdapter = inject(CancelServiceOrderAdapter);
    }
    cancelServiceOrder(userId, code, cancellationDetails) {
        return this.cancelServiceOrderAdapter.cancelServiceOrder(userId, code, cancellationDetails);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class RescheduleServiceOrderAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class RescheduleServiceOrderConnector {
    constructor() {
        this.rescheduleServiceOrderAdapter = inject(RescheduleServiceOrderAdapter);
    }
    rescheduleServiceOrder(userId, code, scheduledAt) {
        return this.rescheduleServiceOrderAdapter.rescheduleServiceOrder(userId, code, scheduledAt);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RescheduleServiceOrderConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RescheduleServiceOrderConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RescheduleServiceOrderConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CancelServiceOrderService {
    constructor() {
        this.cancelServiceOrderConnector = inject(CancelServiceOrderConnector);
        this.orderHistoryFacade = inject(OrderHistoryFacade);
        this.userIdService = inject(UserIdService);
    }
    cancelService(orderCode, cancellationDetails) {
        return this.userIdService.takeUserId().pipe(switchMap((userId) => {
            return this.cancelServiceOrderConnector.cancelServiceOrder(userId, orderCode, cancellationDetails);
        }));
    }
    loadOrderDetails() {
        return this.orderHistoryFacade.getOrderDetails();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CancelServiceOrderService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class RescheduleServiceOrderService {
    constructor() {
        this.rescheduleServiceOrderConnector = inject(RescheduleServiceOrderConnector);
        this.userIdService = inject(UserIdService);
    }
    rescheduleService(orderCode, scheduledAt) {
        return this.userIdService.takeUserId().pipe(switchMap((userId) => {
            return this.rescheduleServiceOrderConnector.rescheduleServiceOrder(userId, orderCode, { scheduledAt });
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RescheduleServiceOrderService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RescheduleServiceOrderService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RescheduleServiceOrderService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class S4ServiceOrderCoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderCoreModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderCoreModule, providers: [
            CxDatePipe,
            CancelServiceOrderService,
            {
                provide: CancelServiceOrderFacade,
                useExisting: CancelServiceOrderService,
            },
            CancelServiceOrderConnector,
            RescheduleServiceOrderService,
            {
                provide: RescheduleServiceOrderFacade,
                useExisting: RescheduleServiceOrderService,
            },
            RescheduleServiceOrderConnector,
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        CxDatePipe,
                        CancelServiceOrderService,
                        {
                            provide: CancelServiceOrderFacade,
                            useExisting: CancelServiceOrderService,
                        },
                        CancelServiceOrderConnector,
                        RescheduleServiceOrderService,
                        {
                            provide: RescheduleServiceOrderFacade,
                            useExisting: RescheduleServiceOrderService,
                        },
                        RescheduleServiceOrderConnector,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const CONTENT_TYPE_JSON_HEADER = { 'Content-Type': 'application/json' };
class OccCancelServiceOrderAdapter {
    constructor() {
        this.http = inject(HttpClient);
        this.occEndpoints = inject(OccEndpointsService);
    }
    cancelServiceOrder(userId, code, cancellationDetails) {
        const url = this.occEndpoints.buildUrl('cancelServiceOrder', {
            urlParams: { userId, code },
        });
        const headers = new HttpHeaders({
            ...CONTENT_TYPE_JSON_HEADER,
        });
        return this.http.post(url, cancellationDetails, { headers });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCancelServiceOrderAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCancelServiceOrderAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCancelServiceOrderAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccRescheduleServiceOrderAdapter {
    constructor() {
        this.http = inject(HttpClient);
        this.logger = inject(LoggerService);
        this.occEndpoints = inject(OccEndpointsService);
    }
    rescheduleServiceOrder(userId, code, scheduledAt) {
        const url = this.occEndpoints.buildUrl('rescheduleService', {
            urlParams: { userId, code },
        });
        const headers = new HttpHeaders({
            'Content-Type': 'application/json',
        });
        return this.http.patch(url, scheduledAt, { headers }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccRescheduleServiceOrderAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccRescheduleServiceOrderAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccRescheduleServiceOrderAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const s4ServiceOccEndpoints = {
    cancelServiceOrder: 'users/${userId}/orders/${code}/serviceOrder/cancellation',
    rescheduleService: 'users/${userId}/orders/${code}/serviceOrder/serviceScheduleSlot',
};
const defaultOccServiceOrderConfig = {
    backend: {
        occ: {
            endpoints: {
                ...s4ServiceOccEndpoints,
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class S4ServiceOrderOccModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderOccModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderOccModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderOccModule, providers: [
            provideDefaultConfig(defaultOccServiceOrderConfig),
            {
                provide: CancelServiceOrderAdapter,
                useClass: OccCancelServiceOrderAdapter,
            },
            {
                provide: RescheduleServiceOrderAdapter,
                useClass: OccRescheduleServiceOrderAdapter,
            },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderOccModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        provideDefaultConfig(defaultOccServiceOrderConfig),
                        {
                            provide: CancelServiceOrderAdapter,
                            useClass: OccCancelServiceOrderAdapter,
                        },
                        {
                            provide: RescheduleServiceOrderAdapter,
                            useClass: OccRescheduleServiceOrderAdapter,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class S4ServiceOrderModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderModule, imports: [S4ServiceComponentsModule,
            S4ServiceOrderCoreModule,
            S4ServiceOrderOccModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderModule, imports: [S4ServiceComponentsModule,
            S4ServiceOrderCoreModule,
            S4ServiceOrderOccModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceOrderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        S4ServiceComponentsModule,
                        S4ServiceOrderCoreModule,
                        S4ServiceOrderOccModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CancelServiceOrderComponent, CancelServiceOrderGuard, CancelServiceOrderHeadlineComponent, CancelServiceOrderHeadlineModule, CancelServiceOrderModule, RescheduleServiceOrderComponent, RescheduleServiceOrderModule, S4ServiceComponentsModule, S4ServiceOrderDetailActionsComponent, S4ServiceOrderDetailActionsModule, S4ServiceOrderModule, ServiceDetailsCardComponent, ServiceDetailsCardModule, ServiceOrderGuard, ServiceOrderOverviewComponentService };
//# sourceMappingURL=spartacus-s4-service-order.mjs.map
