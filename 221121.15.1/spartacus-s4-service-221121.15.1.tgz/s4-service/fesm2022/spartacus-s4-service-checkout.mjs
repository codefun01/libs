import * as i0 from '@angular/core';
import { inject, Injectable, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import * as i4 from '@spartacus/checkout/base/components';
import { CheckoutAuthGuard, CartNotEmptyGuard, CheckoutStepService, CheckoutDeliveryModeComponent, CheckoutStepsSetGuard } from '@spartacus/checkout/base/components';
import * as i2 from '@spartacus/cart/base/root';
import { ActiveCartFacade } from '@spartacus/cart/base/root';
import { CheckoutB2BStepsSetGuard, B2BCheckoutReviewSubmitComponent } from '@spartacus/checkout/b2b/components';
import * as i1 from '@spartacus/checkout/base/root';
import { CheckoutStepType, CheckoutQueryFacade } from '@spartacus/checkout/base/root';
import { CheckoutServiceDetailsFacade, S4ServiceDeliveryModeConfig, CheckoutServiceSchedulePickerService, CheckoutServiceDetailsSetEvent } from '@spartacus/s4-service/root';
import { combineLatest, switchMap, filter, map, of, Subscription, BehaviorSubject, tap, take, catchError } from 'rxjs';
import { NgIf, NgFor, NgSwitch, NgSwitchCase, NgTemplateOutlet, NgClass, AsyncPipe, CommonModule } from '@angular/common';
import { RouterLink, RouterModule, ActivatedRoute } from '@angular/router';
import * as i3 from '@spartacus/core';
import { TranslatePipe, UrlPipe, I18nModule, UrlModule, provideDefaultConfig, GlobalMessageService, GlobalMessageType, FeaturesConfigModule, UserIdService, CommandService, EventService, CommandStrategy, OCC_USER_ID_ANONYMOUS, ProductTypes, CxDatePipe, LoggerService, OccEndpointsService, tryNormalizeHttpError } from '@spartacus/core';
import { CardComponent, IconComponent, OutletDirective, PromotionsComponent, CardModule, PromotionsModule, IconModule, OutletModule, FormRequiredLegendComponent, FormRequiredAsterisksComponent, DatePickerComponent, DatePickerModule, SpinnerComponent, InnerComponentsHostDirective, SpinnerModule, PageComponentModule } from '@spartacus/storefront';
import * as i5 from '@spartacus/checkout/b2b/root';
import { filter as filter$1, map as map$1 } from 'rxjs/operators';
import * as i1$1 from '@angular/forms';
import { FormBuilder, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CheckoutServiceOrderStepsSetGuard extends CheckoutB2BStepsSetGuard {
    constructor() {
        super(...arguments);
        this.checkoutServiceDetailsFacade = inject(CheckoutServiceDetailsFacade);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.config = inject(S4ServiceDeliveryModeConfig);
    }
    canActivate(route) {
        return combineLatest(this.checkoutServiceDetailsFacade.hasServiceItems(), this.checkoutServiceDetailsFacade.hasNonServiceItems()).pipe(switchMap(([hasServiceItems, hasNonServiceItems]) => {
            this.checkoutStepService.disableEnableStep(CheckoutStepType.SERVICE_DETAILS, !hasServiceItems);
            this.checkoutStepService.disableEnableStep(CheckoutStepType.DELIVERY_MODE, !hasNonServiceItems);
            return super.canActivate(route);
        }));
    }
    isServiceDetailsSet(step) {
        return this.checkoutServiceDetailsFacade
            .getSelectedServiceDetailsState()
            .pipe(filter((state) => !state.loading && !state.error), switchMap((selectedServiceDetails) => {
            return this.setServiceDeliveryMode().pipe(map(() => {
                return selectedServiceDetails.data
                    ? true
                    : this.getUrl(step.routeName);
            }));
        }));
    }
    setServiceDeliveryMode() {
        return combineLatest([
            this.checkoutServiceDetailsFacade.hasServiceItems(),
            this.checkoutServiceDetailsFacade.hasNonServiceItems(),
        ]).pipe(switchMap(([hasServiceItems, hasNonServiceItems]) => {
            if (!hasNonServiceItems && hasServiceItems) {
                return this.checkoutDeliveryModesFacade.setDeliveryMode(this.config.s4ServiceDeliveryMode?.code ?? '');
            }
            return of(undefined);
        }));
    }
    isB2BStepSet(step, isAccountPayment) {
        if (step && !step.disabled) {
            switch (step.type[0]) {
                case CheckoutStepType.PAYMENT_TYPE:
                    return this.isPaymentTypeSet(step);
                case CheckoutStepType.DELIVERY_ADDRESS:
                    return this.isDeliveryAddressAndCostCenterSet(step, isAccountPayment);
                case CheckoutStepType.DELIVERY_MODE:
                    return this.isDeliveryModeSet(step);
                case CheckoutStepType.SERVICE_DETAILS:
                    return this.isServiceDetailsSet(step);
                case CheckoutStepType.PAYMENT_DETAILS:
                    return this.isPaymentDetailsSet(step);
                case CheckoutStepType.REVIEW_ORDER:
                    break;
            }
        }
        return of(true);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CheckoutServiceOrderStepsSetGuard, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CheckoutServiceOrderStepsSetGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CheckoutServiceOrderStepsSetGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ServiceCheckoutReviewSubmitComponent extends B2BCheckoutReviewSubmitComponent {
    constructor(checkoutDeliveryAddressFacade, checkoutPaymentFacade, activeCartFacade, translationService, checkoutStepService, checkoutDeliveryModesFacade, checkoutPaymentTypeFacade, checkoutCostCenterFacade, userCostCenterService) {
        super(checkoutDeliveryAddressFacade, checkoutPaymentFacade, activeCartFacade, translationService, checkoutStepService, checkoutDeliveryModesFacade, checkoutPaymentTypeFacade, checkoutCostCenterFacade, userCostCenterService);
        this.checkoutDeliveryAddressFacade = checkoutDeliveryAddressFacade;
        this.checkoutPaymentFacade = checkoutPaymentFacade;
        this.activeCartFacade = activeCartFacade;
        this.translationService = translationService;
        this.checkoutStepService = checkoutStepService;
        this.checkoutDeliveryModesFacade = checkoutDeliveryModesFacade;
        this.checkoutPaymentTypeFacade = checkoutPaymentTypeFacade;
        this.checkoutCostCenterFacade = checkoutCostCenterFacade;
        this.userCostCenterService = userCostCenterService;
        this.checkoutStepTypeServiceDetails = CheckoutStepType.SERVICE_DETAILS;
        this.checkoutServiceDetailsFacade = inject(CheckoutServiceDetailsFacade);
        this.checkoutServiceSchedulePickerService = inject(CheckoutServiceSchedulePickerService);
        this.config = inject(S4ServiceDeliveryModeConfig);
    }
    get scheduledAt$() {
        return this.checkoutServiceDetailsFacade
            .getSelectedServiceDetailsState()
            .pipe(filter$1((state) => !state.loading && !state.error), map$1((state) => {
            return state.data;
        }));
    }
    getCheckoutDeliverySteps() {
        return [
            CheckoutStepType.DELIVERY_ADDRESS,
            CheckoutStepType.DELIVERY_MODE,
            CheckoutStepType.SERVICE_DETAILS,
        ];
    }
    shouldShowDeliveryModeCard(mode) {
        return mode.code !== this.config.s4ServiceDeliveryMode?.code;
    }
    getServiceDetailsCard(scheduledAt) {
        return this.translationService
            .translate('serviceOrderCheckout.serviceDetails')
            .pipe(map$1((textTitle) => {
            if (scheduledAt) {
                scheduledAt =
                    this.checkoutServiceSchedulePickerService.convertDateTimeToReadableString(scheduledAt);
            }
            return {
                title: textTitle,
                textBold: scheduledAt?.split(',')[0] ?? '',
                text: [scheduledAt?.split(',')[1].trim() ?? ''],
            };
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceCheckoutReviewSubmitComponent, deps: [{ token: i1.CheckoutDeliveryAddressFacade }, { token: i1.CheckoutPaymentFacade }, { token: i2.ActiveCartFacade }, { token: i3.TranslationService }, { token: i4.CheckoutStepService }, { token: i1.CheckoutDeliveryModesFacade }, { token: i5.CheckoutPaymentTypeFacade }, { token: i5.CheckoutCostCenterFacade }, { token: i3.UserCostCenterService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: ServiceCheckoutReviewSubmitComponent, isStandalone: true, selector: "cx-review-submit", usesInheritance: true, ngImport: i0, template: "<div class=\"cx-review\">\n  <!-- TITLE -->\n  <h2 class=\"cx-review-title d-none d-lg-block d-xl-block\">\n    {{ 'checkoutReview.review' | cxTranslate }}\n  </h2>\n\n  <div class=\"cx-review-summary row\">\n    <ng-container *ngIf=\"(steps$ | async)?.slice(0, -1) as steps\">\n      <div class=\"col-md-12 col-lg-6 col-xl-6 cx-review-payment-col\">\n        <ng-container *ngFor=\"let step of paymentSteps(steps)\">\n          <ng-container [ngSwitch]=\"step.type[0]\">\n            <ng-container *ngSwitchCase=\"checkoutStepTypePaymentType\">\n              <ng-container\n                *ngTemplateOutlet=\"\n                  summaryCard;\n                  context: {\n                    content: getPoNumberCard(poNumber$ | async),\n                    editRoute: getCheckoutStepUrl(checkoutStepTypePaymentType),\n                    label: 'checkoutReview.editPaymentType',\n                    styleClass: 'cx-review-summary-card',\n                  }\n                \"\n              ></ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypePaymentType\">\n              <ng-container *ngIf=\"paymentType$ | async as paymentType\">\n                <ng-container\n                  *ngTemplateOutlet=\"\n                    summaryCard;\n                    context: {\n                      content: getPaymentTypeCard(paymentType),\n                      editRoute: getCheckoutStepUrl(\n                        checkoutStepTypePaymentType\n                      ),\n                      label: 'checkoutReview.editPaymentType',\n                      styleClass: 'cx-review-summary-card',\n                    }\n                  \"\n                ></ng-container>\n              </ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypePaymentDetails\">\n              <ng-container *ngIf=\"paymentDetails$ | async as paymentDetails\">\n                <ng-container\n                  *ngTemplateOutlet=\"\n                    summaryCard;\n                    context: {\n                      content: getPaymentMethodCard(paymentDetails),\n                      editRoute: getCheckoutStepUrl(\n                        checkoutStepTypePaymentDetails\n                      ),\n                      label: 'checkoutReview.editPaymentDetails',\n                      styleClass:\n                        'cx-review-summary-card cx-review-card-payment',\n                    }\n                  \"\n                ></ng-container>\n              </ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypeDeliveryAddress\">\n              <ng-container *ngIf=\"isAccountPayment$ | async\">\n                <ng-container *ngIf=\"costCenter$ | async as costCenter\">\n                  <ng-container\n                    *ngTemplateOutlet=\"\n                      summaryCard;\n                      context: {\n                        content: getCostCenterCard(costCenter),\n                        editRoute: getCheckoutStepUrl(\n                          checkoutStepTypeDeliveryAddress\n                        ),\n                        label: 'checkoutReview.editDeliveryAddressDetails',\n                        styleClass: 'cx-review-summary-card',\n                      }\n                    \"\n                  ></ng-container>\n                </ng-container>\n              </ng-container>\n            </ng-container>\n          </ng-container>\n        </ng-container>\n      </div>\n      <div class=\"col-md-12 col-lg-6 col-xl-6 cx-review-shipping-col\">\n        <ng-container *ngFor=\"let step of deliverySteps(steps)\">\n          <ng-container [ngSwitch]=\"step.type[0]\">\n            <ng-container *ngSwitchCase=\"checkoutStepTypeDeliveryAddress\">\n              <ng-container *ngIf=\"deliveryAddress$ | async as deliveryAddress\">\n                <ng-container\n                  *ngTemplateOutlet=\"\n                    summaryCard;\n                    context: {\n                      content: getDeliveryAddressCard(deliveryAddress),\n                      editRoute: getCheckoutStepUrl(\n                        checkoutStepTypeDeliveryAddress\n                      ),\n                      label: 'checkoutReview.editDeliveryAddressDetails',\n                      styleClass:\n                        'cx-review-summary-card cx-review-card-address',\n                    }\n                  \"\n                ></ng-container>\n              </ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypeDeliveryMode\">\n              <ng-container *ngTemplateOutlet=\"deliveryMode\"></ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypeServiceDetails\">\n              <ng-container *ngIf=\"scheduledAt$ | async as scheduledAt\">\n                <ng-container\n                  *ngTemplateOutlet=\"\n                    summaryCard;\n                    context: {\n                      content: getServiceDetailsCard(scheduledAt),\n                      editRoute: getCheckoutStepUrl(\n                        checkoutStepTypeServiceDetails\n                      ),\n                      label: 'checkoutReview.editServiceDetails',\n                      styleClass:\n                        'cx-review-summary-card cx-review-service-details',\n                    }\n                  \"\n                ></ng-container>\n              </ng-container>\n            </ng-container>\n          </ng-container>\n        </ng-container>\n      </div>\n    </ng-container>\n  </div>\n  <ng-template\n    #summaryCard\n    let-content=\"content\"\n    let-editRoute=\"editRoute\"\n    let-label=\"label\"\n    let-styleClass=\"styleClass\"\n  >\n    <div [ngClass]=\"styleClass\">\n      <cx-card [content]=\"content | async\"></cx-card>\n      <div class=\"cx-review-summary-edit-step\">\n        <a\n          [attr.title]=\"label | cxTranslate\"\n          [routerLink]=\"{ cxRoute: editRoute } | cxUrl\"\n        >\n          <cx-icon aria-hidden=\"true\" [type]=\"iconTypes.PENCIL\"></cx-icon>\n        </a>\n      </div>\n    </div>\n  </ng-template>\n\n  <!-- DELIVERY MODE SECTION -->\n  <ng-template #deliveryMode>\n    <div class=\"cx-review-summary-card cx-review-card-shipping\">\n      <div *ngIf=\"deliveryMode$ | async as deliveryMode\">\n        <cx-card\n          *ngIf=\"shouldShowDeliveryModeCard(deliveryMode)\"\n          [content]=\"getDeliveryModeCard(deliveryMode) | async\"\n        >\n        </cx-card>\n        <ng-template\n          [cxOutlet]=\"cartOutlets.DELIVERY_MODE\"\n          [cxOutletContext]=\"{\n            item: cart$ | async,\n            readonly: true,\n          }\"\n        >\n        </ng-template>\n      </div>\n\n      <div class=\"cx-review-summary-edit-step\">\n        <a\n          [attr.title]=\"'checkoutReview.editDeliveryMode' | cxTranslate\"\n          [routerLink]=\"\n            { cxRoute: getCheckoutStepUrl(checkoutStepTypeDeliveryMode) }\n              | cxUrl\n          \"\n        >\n          <cx-icon aria-hidden=\"true\" [type]=\"iconTypes.PENCIL\"></cx-icon>\n        </a>\n      </div>\n    </div>\n  </ng-template>\n\n  <!-- CART ITEM SECTION -->\n  <ng-container *ngIf=\"cart$ | async as cart\">\n    <div class=\"cx-review-cart-total d-none d-lg-block d-xl-block\">\n      {{\n        'cartItems.cartTotal'\n          | cxTranslate: { count: cart.deliveryItemsQuantity }\n      }}:\n      {{ cart.totalPrice?.formattedValue }}\n    </div>\n    <div class=\"cx-review-cart-heading d-block d-lg-none d-xl-none\">\n      {{ 'checkoutReview.placeOrder' | cxTranslate }}\n    </div>\n    <div class=\"cx-review-cart-item\" *ngIf=\"entries$ | async as entries\">\n      <cx-promotions\n        [promotions]=\"\n          (cart.appliedOrderPromotions || []).concat(\n            cart.potentialOrderPromotions || []\n          )\n        \"\n      ></cx-promotions>\n\n      <ng-template\n        [cxOutlet]=\"cartOutlets.CART_ITEM_LIST\"\n        [cxOutletContext]=\"{\n          items: entries,\n          readonly: true,\n          promotionLocation: promotionLocation,\n        }\"\n      >\n      </ng-template>\n    </div>\n  </ng-container>\n</div>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: CardComponent, selector: "cx-card", inputs: ["border", "editMode", "isDefault", "content", "fitToContainer", "truncateText", "truncateParagraphText", "charactersLimit", "index", "role"], outputs: ["deleteCard", "setDefaultCard", "sendCard", "editCard", "cancelCard"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "directive", type: OutletDirective, selector: "[cxOutlet]", inputs: ["cxOutlet", "cxOutletContext", "cxOutletDefer", "cxComponentRef"], outputs: ["loaded", "cxComponentRefChange"] }, { kind: "component", type: PromotionsComponent, selector: "cx-promotions", inputs: ["promotions"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceCheckoutReviewSubmitComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-review-submit', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        NgFor,
                        NgSwitch,
                        NgSwitchCase,
                        NgTemplateOutlet,
                        NgClass,
                        CardComponent,
                        RouterLink,
                        IconComponent,
                        OutletDirective,
                        PromotionsComponent,
                        AsyncPipe,
                        TranslatePipe,
                        UrlPipe,
                    ], template: "<div class=\"cx-review\">\n  <!-- TITLE -->\n  <h2 class=\"cx-review-title d-none d-lg-block d-xl-block\">\n    {{ 'checkoutReview.review' | cxTranslate }}\n  </h2>\n\n  <div class=\"cx-review-summary row\">\n    <ng-container *ngIf=\"(steps$ | async)?.slice(0, -1) as steps\">\n      <div class=\"col-md-12 col-lg-6 col-xl-6 cx-review-payment-col\">\n        <ng-container *ngFor=\"let step of paymentSteps(steps)\">\n          <ng-container [ngSwitch]=\"step.type[0]\">\n            <ng-container *ngSwitchCase=\"checkoutStepTypePaymentType\">\n              <ng-container\n                *ngTemplateOutlet=\"\n                  summaryCard;\n                  context: {\n                    content: getPoNumberCard(poNumber$ | async),\n                    editRoute: getCheckoutStepUrl(checkoutStepTypePaymentType),\n                    label: 'checkoutReview.editPaymentType',\n                    styleClass: 'cx-review-summary-card',\n                  }\n                \"\n              ></ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypePaymentType\">\n              <ng-container *ngIf=\"paymentType$ | async as paymentType\">\n                <ng-container\n                  *ngTemplateOutlet=\"\n                    summaryCard;\n                    context: {\n                      content: getPaymentTypeCard(paymentType),\n                      editRoute: getCheckoutStepUrl(\n                        checkoutStepTypePaymentType\n                      ),\n                      label: 'checkoutReview.editPaymentType',\n                      styleClass: 'cx-review-summary-card',\n                    }\n                  \"\n                ></ng-container>\n              </ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypePaymentDetails\">\n              <ng-container *ngIf=\"paymentDetails$ | async as paymentDetails\">\n                <ng-container\n                  *ngTemplateOutlet=\"\n                    summaryCard;\n                    context: {\n                      content: getPaymentMethodCard(paymentDetails),\n                      editRoute: getCheckoutStepUrl(\n                        checkoutStepTypePaymentDetails\n                      ),\n                      label: 'checkoutReview.editPaymentDetails',\n                      styleClass:\n                        'cx-review-summary-card cx-review-card-payment',\n                    }\n                  \"\n                ></ng-container>\n              </ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypeDeliveryAddress\">\n              <ng-container *ngIf=\"isAccountPayment$ | async\">\n                <ng-container *ngIf=\"costCenter$ | async as costCenter\">\n                  <ng-container\n                    *ngTemplateOutlet=\"\n                      summaryCard;\n                      context: {\n                        content: getCostCenterCard(costCenter),\n                        editRoute: getCheckoutStepUrl(\n                          checkoutStepTypeDeliveryAddress\n                        ),\n                        label: 'checkoutReview.editDeliveryAddressDetails',\n                        styleClass: 'cx-review-summary-card',\n                      }\n                    \"\n                  ></ng-container>\n                </ng-container>\n              </ng-container>\n            </ng-container>\n          </ng-container>\n        </ng-container>\n      </div>\n      <div class=\"col-md-12 col-lg-6 col-xl-6 cx-review-shipping-col\">\n        <ng-container *ngFor=\"let step of deliverySteps(steps)\">\n          <ng-container [ngSwitch]=\"step.type[0]\">\n            <ng-container *ngSwitchCase=\"checkoutStepTypeDeliveryAddress\">\n              <ng-container *ngIf=\"deliveryAddress$ | async as deliveryAddress\">\n                <ng-container\n                  *ngTemplateOutlet=\"\n                    summaryCard;\n                    context: {\n                      content: getDeliveryAddressCard(deliveryAddress),\n                      editRoute: getCheckoutStepUrl(\n                        checkoutStepTypeDeliveryAddress\n                      ),\n                      label: 'checkoutReview.editDeliveryAddressDetails',\n                      styleClass:\n                        'cx-review-summary-card cx-review-card-address',\n                    }\n                  \"\n                ></ng-container>\n              </ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypeDeliveryMode\">\n              <ng-container *ngTemplateOutlet=\"deliveryMode\"></ng-container>\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypeServiceDetails\">\n              <ng-container *ngIf=\"scheduledAt$ | async as scheduledAt\">\n                <ng-container\n                  *ngTemplateOutlet=\"\n                    summaryCard;\n                    context: {\n                      content: getServiceDetailsCard(scheduledAt),\n                      editRoute: getCheckoutStepUrl(\n                        checkoutStepTypeServiceDetails\n                      ),\n                      label: 'checkoutReview.editServiceDetails',\n                      styleClass:\n                        'cx-review-summary-card cx-review-service-details',\n                    }\n                  \"\n                ></ng-container>\n              </ng-container>\n            </ng-container>\n          </ng-container>\n        </ng-container>\n      </div>\n    </ng-container>\n  </div>\n  <ng-template\n    #summaryCard\n    let-content=\"content\"\n    let-editRoute=\"editRoute\"\n    let-label=\"label\"\n    let-styleClass=\"styleClass\"\n  >\n    <div [ngClass]=\"styleClass\">\n      <cx-card [content]=\"content | async\"></cx-card>\n      <div class=\"cx-review-summary-edit-step\">\n        <a\n          [attr.title]=\"label | cxTranslate\"\n          [routerLink]=\"{ cxRoute: editRoute } | cxUrl\"\n        >\n          <cx-icon aria-hidden=\"true\" [type]=\"iconTypes.PENCIL\"></cx-icon>\n        </a>\n      </div>\n    </div>\n  </ng-template>\n\n  <!-- DELIVERY MODE SECTION -->\n  <ng-template #deliveryMode>\n    <div class=\"cx-review-summary-card cx-review-card-shipping\">\n      <div *ngIf=\"deliveryMode$ | async as deliveryMode\">\n        <cx-card\n          *ngIf=\"shouldShowDeliveryModeCard(deliveryMode)\"\n          [content]=\"getDeliveryModeCard(deliveryMode) | async\"\n        >\n        </cx-card>\n        <ng-template\n          [cxOutlet]=\"cartOutlets.DELIVERY_MODE\"\n          [cxOutletContext]=\"{\n            item: cart$ | async,\n            readonly: true,\n          }\"\n        >\n        </ng-template>\n      </div>\n\n      <div class=\"cx-review-summary-edit-step\">\n        <a\n          [attr.title]=\"'checkoutReview.editDeliveryMode' | cxTranslate\"\n          [routerLink]=\"\n            { cxRoute: getCheckoutStepUrl(checkoutStepTypeDeliveryMode) }\n              | cxUrl\n          \"\n        >\n          <cx-icon aria-hidden=\"true\" [type]=\"iconTypes.PENCIL\"></cx-icon>\n        </a>\n      </div>\n    </div>\n  </ng-template>\n\n  <!-- CART ITEM SECTION -->\n  <ng-container *ngIf=\"cart$ | async as cart\">\n    <div class=\"cx-review-cart-total d-none d-lg-block d-xl-block\">\n      {{\n        'cartItems.cartTotal'\n          | cxTranslate: { count: cart.deliveryItemsQuantity }\n      }}:\n      {{ cart.totalPrice?.formattedValue }}\n    </div>\n    <div class=\"cx-review-cart-heading d-block d-lg-none d-xl-none\">\n      {{ 'checkoutReview.placeOrder' | cxTranslate }}\n    </div>\n    <div class=\"cx-review-cart-item\" *ngIf=\"entries$ | async as entries\">\n      <cx-promotions\n        [promotions]=\"\n          (cart.appliedOrderPromotions || []).concat(\n            cart.potentialOrderPromotions || []\n          )\n        \"\n      ></cx-promotions>\n\n      <ng-template\n        [cxOutlet]=\"cartOutlets.CART_ITEM_LIST\"\n        [cxOutletContext]=\"{\n          items: entries,\n          readonly: true,\n          promotionLocation: promotionLocation,\n        }\"\n      >\n      </ng-template>\n    </div>\n  </ng-container>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1.CheckoutDeliveryAddressFacade }, { type: i1.CheckoutPaymentFacade }, { type: i2.ActiveCartFacade }, { type: i3.TranslationService }, { type: i4.CheckoutStepService }, { type: i1.CheckoutDeliveryModesFacade }, { type: i5.CheckoutPaymentTypeFacade }, { type: i5.CheckoutCostCenterFacade }, { type: i3.UserCostCenterService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ServiceCheckoutReviewSubmitModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceCheckoutReviewSubmitModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: ServiceCheckoutReviewSubmitModule, imports: [CommonModule,
            CardModule,
            I18nModule,
            UrlModule,
            RouterModule,
            PromotionsModule,
            IconModule,
            OutletModule,
            ServiceCheckoutReviewSubmitComponent], exports: [ServiceCheckoutReviewSubmitComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceCheckoutReviewSubmitModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    CheckoutReviewOrder: {
                        component: ServiceCheckoutReviewSubmitComponent,
                        guards: [CheckoutAuthGuard, CartNotEmptyGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            CardModule,
            I18nModule,
            UrlModule,
            RouterModule,
            PromotionsModule,
            IconModule,
            OutletModule,
            ServiceCheckoutReviewSubmitComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceCheckoutReviewSubmitModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        CardModule,
                        I18nModule,
                        UrlModule,
                        RouterModule,
                        PromotionsModule,
                        IconModule,
                        OutletModule,
                        ServiceCheckoutReviewSubmitComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                CheckoutReviewOrder: {
                                    component: ServiceCheckoutReviewSubmitComponent,
                                    guards: [CheckoutAuthGuard, CartNotEmptyGuard],
                                },
                            },
                        }),
                    ],
                    exports: [ServiceCheckoutReviewSubmitComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CheckoutServiceDetailsComponent {
    constructor() {
        this.activatedRoute = inject(ActivatedRoute);
        this.checkoutStepService = inject(CheckoutStepService);
        this.globalMessageService = inject(GlobalMessageService);
        this.checkoutServiceDetailsFacade = inject(CheckoutServiceDetailsFacade);
        this.fb = inject(FormBuilder);
        this.checkoutServiceSchedulePickerService = inject(CheckoutServiceSchedulePickerService);
        this.minServiceDate$ = this.checkoutServiceSchedulePickerService.getMinDateForService();
        this.scheduleTimes$ = this.checkoutServiceSchedulePickerService.getScheduledServiceTimes();
        this.form = this.fb.group({
            scheduleDate: [null, Validators.required],
            scheduleTime: [null, Validators.required],
        });
        this.subscription = new Subscription();
        this.selectedServiceDetails$ = this.checkoutServiceDetailsFacade
            .getSelectedServiceDetailsState()
            .pipe(filter$1((state) => !state.loading), map$1((state) => state.data));
        this.isSetServiceDetailsHttpErrorSub = new BehaviorSubject(false);
        this.isSetServiceDetailsHttpError$ = this.isSetServiceDetailsHttpErrorSub.asObservable();
    }
    ngOnInit() {
        this.subscription.add(this.selectedServiceDetails$.subscribe((selectedServiceDetails) => {
            if (selectedServiceDetails && selectedServiceDetails !== '') {
                const info = this.checkoutServiceSchedulePickerService.getServiceDetailsFromDateTime(selectedServiceDetails);
                this.form.patchValue({
                    scheduleDate: info.date,
                    scheduleTime: info.time,
                });
            }
            else {
                combineLatest([this.minServiceDate$, this.scheduleTimes$]).subscribe(([minDate, scheduleTime]) => {
                    this.form.patchValue({
                        scheduleDate: minDate,
                        scheduleTime: scheduleTime[0],
                    });
                });
            }
        }));
    }
    setScheduleTime(event) {
        const target = event.target;
        const value = target.value;
        this.form.patchValue({
            scheduleTime: value,
        });
    }
    get backBtnText() {
        return this.checkoutStepService.getBackBntText(this.activatedRoute);
    }
    next() {
        const scheduleDate = this.form?.get('scheduleDate')?.value || '';
        const scheduleTime = this.form?.get('scheduleTime')?.value || '';
        const scheduleDateTime = this.checkoutServiceSchedulePickerService.convertToDateTime(scheduleDate, scheduleTime);
        this.checkoutServiceDetailsFacade
            .setServiceScheduleSlot(scheduleDateTime)
            .subscribe({
            next: () => {
                this.onSuccess();
                this.checkoutStepService.next(this.activatedRoute);
            },
            error: () => this.onError(),
        });
    }
    back() {
        this.checkoutStepService.back(this.activatedRoute);
    }
    onSuccess() {
        this.isSetServiceDetailsHttpErrorSub.next(false);
    }
    onError() {
        this.globalMessageService?.add({ key: 'serviceOrderCheckout.unknownError' }, GlobalMessageType.MSG_TYPE_ERROR);
        this.isSetServiceDetailsHttpErrorSub.next(true);
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CheckoutServiceDetailsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CheckoutServiceDetailsComponent, isStandalone: true, selector: "cx-service-details", ngImport: i0, template: "<h2\n  class=\"cx-checkout-title d-none d-lg-block d-xl-block\"\n  [attr.aria-label]=\"\n    'serviceOrderCheckout.serviceLocationHeading' | cxTranslate\n  \"\n>\n  {{ 'serviceOrderCheckout.serviceLocationHeading' | cxTranslate }}\n</h2>\n<div\n  class=\"cx-service-location-text\"\n  [attr.aria-label]=\"'serviceOrderCheckout.address' | cxTranslate\"\n>\n  {{ 'serviceOrderCheckout.address' | cxTranslate }}\n</div>\n<h2\n  class=\"cx-checkout-title d-none d-lg-block d-xl-block\"\n  [attr.aria-label]=\"\n    'serviceOrderCheckout.serviceScheduleHeading' | cxTranslate\n  \"\n>\n  {{ 'serviceOrderCheckout.serviceScheduleHeading' | cxTranslate }}\n</h2>\n<form [formGroup]=\"this.form\">\n  <cx-form-required-legend />\n  <div class=\"row\">\n    <label\n      class=\"col\"\n      [attr.aria-label]=\"'serviceOrderCheckout.datePickerLabel' | cxTranslate\"\n    >\n      <div>\n        {{ 'serviceOrderCheckout.datePickerLabel' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </div>\n      <div>\n        <cx-date-picker\n          [control]=\"$any(form.get('scheduleDate'))\"\n          [min]=\"(minServiceDate$ | async) ?? undefined\"\n          label=\"serviceOrderCheckout.datePickerLabel\"\n        >\n        </cx-date-picker>\n      </div>\n    </label>\n\n    <label\n      class=\"col\"\n      [attr.aria-label]=\"'serviceOrderCheckout.timePickerLabel' | cxTranslate\"\n    >\n      <div>\n        {{ 'serviceOrderCheckout.timePickerLabel' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </div>\n      <div>\n        <select\n          *ngIf=\"scheduleTimes$ | async as scheduleTimes\"\n          class=\"form-control\"\n          formControlName=\"scheduleTime\"\n          (change)=\"setScheduleTime($event)\"\n        >\n          <option\n            *ngFor=\"let time of scheduleTimes\"\n            [value]=\"time\"\n            [selected]=\"form.get('scheduleTime')?.value === time\"\n          >\n            {{ time }}\n          </option>\n        </select>\n      </div>\n    </label>\n  </div>\n</form>\n\n<div class=\"row cx-checkout-btns\">\n  <section class=\"col-md-12 col-lg-6\">\n    <button\n      class=\"btn btn-block btn-secondary\"\n      [attr.aria-label]=\"backBtnText | cxTranslate\"\n      (click)=\"back()\"\n    >\n      {{ backBtnText | cxTranslate }}\n    </button>\n  </section>\n  <section class=\"col-md-12 col-lg-6\">\n    <button\n      class=\"btn btn-block btn-primary\"\n      [attr.aria-label]=\"'common.continue' | cxTranslate\"\n      [disabled]=\"isSetServiceDetailsHttpError$ | async\"\n      (click)=\"next()\"\n    >\n      {{ 'common.continue' | cxTranslate }}\n    </button>\n  </section>\n</div>\n", dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$1.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1$1.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1$1.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i1$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: DatePickerComponent, selector: "cx-date-picker", inputs: ["control", "min", "max", "required", "label"], outputs: ["update"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CheckoutServiceDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-service-details', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredLegendComponent,
                        FormRequiredAsterisksComponent,
                        DatePickerComponent,
                        NgIf,
                        NgFor,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<h2\n  class=\"cx-checkout-title d-none d-lg-block d-xl-block\"\n  [attr.aria-label]=\"\n    'serviceOrderCheckout.serviceLocationHeading' | cxTranslate\n  \"\n>\n  {{ 'serviceOrderCheckout.serviceLocationHeading' | cxTranslate }}\n</h2>\n<div\n  class=\"cx-service-location-text\"\n  [attr.aria-label]=\"'serviceOrderCheckout.address' | cxTranslate\"\n>\n  {{ 'serviceOrderCheckout.address' | cxTranslate }}\n</div>\n<h2\n  class=\"cx-checkout-title d-none d-lg-block d-xl-block\"\n  [attr.aria-label]=\"\n    'serviceOrderCheckout.serviceScheduleHeading' | cxTranslate\n  \"\n>\n  {{ 'serviceOrderCheckout.serviceScheduleHeading' | cxTranslate }}\n</h2>\n<form [formGroup]=\"this.form\">\n  <cx-form-required-legend />\n  <div class=\"row\">\n    <label\n      class=\"col\"\n      [attr.aria-label]=\"'serviceOrderCheckout.datePickerLabel' | cxTranslate\"\n    >\n      <div>\n        {{ 'serviceOrderCheckout.datePickerLabel' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </div>\n      <div>\n        <cx-date-picker\n          [control]=\"$any(form.get('scheduleDate'))\"\n          [min]=\"(minServiceDate$ | async) ?? undefined\"\n          label=\"serviceOrderCheckout.datePickerLabel\"\n        >\n        </cx-date-picker>\n      </div>\n    </label>\n\n    <label\n      class=\"col\"\n      [attr.aria-label]=\"'serviceOrderCheckout.timePickerLabel' | cxTranslate\"\n    >\n      <div>\n        {{ 'serviceOrderCheckout.timePickerLabel' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </div>\n      <div>\n        <select\n          *ngIf=\"scheduleTimes$ | async as scheduleTimes\"\n          class=\"form-control\"\n          formControlName=\"scheduleTime\"\n          (change)=\"setScheduleTime($event)\"\n        >\n          <option\n            *ngFor=\"let time of scheduleTimes\"\n            [value]=\"time\"\n            [selected]=\"form.get('scheduleTime')?.value === time\"\n          >\n            {{ time }}\n          </option>\n        </select>\n      </div>\n    </label>\n  </div>\n</form>\n\n<div class=\"row cx-checkout-btns\">\n  <section class=\"col-md-12 col-lg-6\">\n    <button\n      class=\"btn btn-block btn-secondary\"\n      [attr.aria-label]=\"backBtnText | cxTranslate\"\n      (click)=\"back()\"\n    >\n      {{ backBtnText | cxTranslate }}\n    </button>\n  </section>\n  <section class=\"col-md-12 col-lg-6\">\n    <button\n      class=\"btn btn-block btn-primary\"\n      [attr.aria-label]=\"'common.continue' | cxTranslate\"\n      [disabled]=\"isSetServiceDetailsHttpError$ | async\"\n      (click)=\"next()\"\n    >\n      {{ 'common.continue' | cxTranslate }}\n    </button>\n  </section>\n</div>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CheckoutServiceDetailsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CheckoutServiceDetailsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CheckoutServiceDetailsModule, imports: [CommonModule,
            I18nModule,
            DatePickerModule,
            ReactiveFormsModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            CheckoutServiceDetailsComponent], exports: [CheckoutServiceDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CheckoutServiceDetailsModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    CheckoutServiceDetails: {
                        component: CheckoutServiceDetailsComponent,
                        guards: [CheckoutAuthGuard, CartNotEmptyGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            DatePickerModule,
            ReactiveFormsModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            CheckoutServiceDetailsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CheckoutServiceDetailsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        DatePickerModule,
                        ReactiveFormsModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        CheckoutServiceDetailsComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                CheckoutServiceDetails: {
                                    component: CheckoutServiceDetailsComponent,
                                    guards: [CheckoutAuthGuard, CartNotEmptyGuard],
                                },
                            },
                        }),
                    ],
                    exports: [CheckoutServiceDetailsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ServiceCheckoutDeliveryModeComponent extends CheckoutDeliveryModeComponent {
    constructor() {
        super(...arguments);
        this.checkoutServiceDetailsFacade = inject(CheckoutServiceDetailsFacade);
        this.config = inject(S4ServiceDeliveryModeConfig);
        this.hasServiceProducts$ = this.checkoutServiceDetailsFacade.hasServiceItems();
        this.serviceDeliveryConfig = this.config.s4ServiceDeliveryMode;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceCheckoutDeliveryModeComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: ServiceCheckoutDeliveryModeComponent, isStandalone: true, selector: "cx-delivery-mode", usesInheritance: true, ngImport: i0, template: "<fieldset role=\"radiogroup\">\n  <ng-container *ngTemplateOutlet=\"displayServiceDelivery\"></ng-container>\n  <legend class=\"cx-checkout-title d-none d-lg-block d-xl-block\">\n    {{ 'serviceOrderCheckout.productDeliveryOptions' | cxTranslate }}\n  </legend>\n  <ng-container\n    *ngIf=\"\n      !(isUpdating$ | async) &&\n        (supportedDeliveryModes$ | async) as supportedDeliveryModes;\n      else loading\n    \"\n  >\n    <div role=\"status\" [attr.aria-label]=\"'common.loaded' | cxTranslate\"></div>\n    <div [formGroup]=\"mode\" class=\"cx-delivery-mode-wrapper\">\n      <div class=\"form-check\" *ngFor=\"let mode of supportedDeliveryModes\">\n        <input\n          [attr.aria-checked]=\"getAriaChecked(mode.code)\"\n          class=\"form-check-input\"\n          type=\"radio\"\n          (change)=\"changeMode(mode.code, $event)\"\n          (click)=\"changeMode(mode.code, $event)\"\n          [value]=\"mode.code\"\n          formControlName=\"deliveryModeId\"\n          id=\"deliveryMode-{{ mode.code }}\"\n          [attr.aria-label]=\"\n            mode.name +\n            ' ' +\n            mode.description +\n            ' ' +\n            mode.deliveryCost?.formattedValue\n          \"\n        />\n        <label\n          class=\"cx-delivery-label form-check-label form-radio-label\"\n          for=\"deliveryMode-{{ mode.code }}\"\n          aria-hidden=\"true\"\n        >\n          <div class=\"cx-delivery-mode\">\n            {{ mode.name }}\n            <span class=\"cx-delivery-mode-description\"\n              >({{ mode.description }})</span\n            >\n          </div>\n          <div class=\"cx-delivery-price\">\n            {{ mode.deliveryCost?.formattedValue }}\n          </div>\n          <div class=\"cx-delivery-details\"></div>\n        </label>\n      </div>\n      <ng-template\n        [cxOutlet]=\"CartOutlets.DELIVERY_MODE\"\n        [cxOutletContext]=\"{\n          item: activeCartFacade.getActive() | async,\n        }\"\n      >\n      </ng-template>\n    </div>\n  </ng-container>\n</fieldset>\n\n<ng-container *ngIf=\"activeCartFacade.hasPickupItems() | async\">\n  <h2 class=\"cx-checkout-title d-none d-lg-block d-xl-block\">\n    {{ 'checkoutMode.deliveryEntries' | cxTranslate }}\n  </h2>\n\n  <ng-template\n    [cxOutlet]=\"CartOutlets.CART_ITEM_LIST\"\n    [cxOutletContext]=\"{\n      items: activeCartFacade.getDeliveryEntries() | async,\n      readonly: true,\n    }\"\n  >\n  </ng-template>\n</ng-container>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\">\n    <cx-spinner></cx-spinner>\n  </div>\n</ng-template>\n\n<ng-container cxInnerComponentsHost></ng-container>\n\n<div class=\"row cx-checkout-btns\">\n  <div class=\"col-md-12 col-lg-6\">\n    <button class=\"btn btn-block btn-secondary\" (click)=\"back()\">\n      {{ backBtnText | cxTranslate }}\n    </button>\n  </div>\n  <div class=\"col-md-12 col-lg-6\">\n    <button\n      class=\"btn btn-block btn-primary\"\n      [disabled]=\"deliveryModeInvalid || (isSetDeliveryModeHttpError$ | async)\"\n      (click)=\"next()\"\n    >\n      {{ 'common.continue' | cxTranslate }}\n    </button>\n  </div>\n</div>\n\n<ng-template #displayDeliveryMode let-content=\"content\">\n  <input\n    [attr.aria-checked]=\"getAriaChecked(content.code)\"\n    class=\"form-check-input\"\n    type=\"radio\"\n    [checked]=\"true\"\n    [value]=\"content.code\"\n    id=\"deliveryMode-{{ content.code }}\"\n    [attr.aria-label]=\"\n      content.name +\n      ' ' +\n      content.description +\n      ' ' +\n      content.deliveryCost?.formattedValue\n    \"\n  />\n  <label\n    class=\"cx-delivery-label form-check-label form-radio-label\"\n    for=\"deliveryMode-{{ content.code }}\"\n    aria-hidden=\"true\"\n  >\n    <div class=\"cx-delivery-mode\">\n      {{ content.name }}\n      <span *ngIf=\"content.description\" class=\"cx-delivery-mode-description\"\n        >({{ content.description }})</span\n      >\n    </div>\n    <div class=\"cx-delivery-price\">\n      {{ content.deliveryCost?.formattedValue }}\n    </div>\n    <div class=\"cx-delivery-details\"></div>\n  </label>\n</ng-template>\n\n<ng-template #displayServiceDelivery>\n  <ng-container *ngIf=\"hasServiceProducts$ | async\">\n    <legend class=\"cx-checkout-title d-none d-lg-block d-xl-block\">\n      {{ 'serviceOrderCheckout.serviceDeliveryOption' | cxTranslate }}\n    </legend>\n    <div class=\"cx-delivery-mode-wrapper\">\n      <div class=\"form-check\">\n        <ng-container\n          *ngTemplateOutlet=\"\n            displayDeliveryMode;\n            context: { content: serviceDeliveryConfig }\n          \"\n        ></ng-container>\n      </div>\n    </div>\n  </ng-container>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$1.RadioControlValueAccessor, selector: "input[type=radio][formControlName],input[type=radio][formControl],input[type=radio][ngModel]", inputs: ["name", "formControlName", "value"] }, { kind: "directive", type: i1$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: OutletDirective, selector: "[cxOutlet]", inputs: ["cxOutlet", "cxOutletContext", "cxOutletDefer", "cxComponentRef"], outputs: ["loaded", "cxComponentRefChange"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "directive", type: InnerComponentsHostDirective, selector: "[cxInnerComponentsHost]" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceCheckoutDeliveryModeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-delivery-mode', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgTemplateOutlet,
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        NgFor,
                        OutletDirective,
                        SpinnerComponent,
                        InnerComponentsHostDirective,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<fieldset role=\"radiogroup\">\n  <ng-container *ngTemplateOutlet=\"displayServiceDelivery\"></ng-container>\n  <legend class=\"cx-checkout-title d-none d-lg-block d-xl-block\">\n    {{ 'serviceOrderCheckout.productDeliveryOptions' | cxTranslate }}\n  </legend>\n  <ng-container\n    *ngIf=\"\n      !(isUpdating$ | async) &&\n        (supportedDeliveryModes$ | async) as supportedDeliveryModes;\n      else loading\n    \"\n  >\n    <div role=\"status\" [attr.aria-label]=\"'common.loaded' | cxTranslate\"></div>\n    <div [formGroup]=\"mode\" class=\"cx-delivery-mode-wrapper\">\n      <div class=\"form-check\" *ngFor=\"let mode of supportedDeliveryModes\">\n        <input\n          [attr.aria-checked]=\"getAriaChecked(mode.code)\"\n          class=\"form-check-input\"\n          type=\"radio\"\n          (change)=\"changeMode(mode.code, $event)\"\n          (click)=\"changeMode(mode.code, $event)\"\n          [value]=\"mode.code\"\n          formControlName=\"deliveryModeId\"\n          id=\"deliveryMode-{{ mode.code }}\"\n          [attr.aria-label]=\"\n            mode.name +\n            ' ' +\n            mode.description +\n            ' ' +\n            mode.deliveryCost?.formattedValue\n          \"\n        />\n        <label\n          class=\"cx-delivery-label form-check-label form-radio-label\"\n          for=\"deliveryMode-{{ mode.code }}\"\n          aria-hidden=\"true\"\n        >\n          <div class=\"cx-delivery-mode\">\n            {{ mode.name }}\n            <span class=\"cx-delivery-mode-description\"\n              >({{ mode.description }})</span\n            >\n          </div>\n          <div class=\"cx-delivery-price\">\n            {{ mode.deliveryCost?.formattedValue }}\n          </div>\n          <div class=\"cx-delivery-details\"></div>\n        </label>\n      </div>\n      <ng-template\n        [cxOutlet]=\"CartOutlets.DELIVERY_MODE\"\n        [cxOutletContext]=\"{\n          item: activeCartFacade.getActive() | async,\n        }\"\n      >\n      </ng-template>\n    </div>\n  </ng-container>\n</fieldset>\n\n<ng-container *ngIf=\"activeCartFacade.hasPickupItems() | async\">\n  <h2 class=\"cx-checkout-title d-none d-lg-block d-xl-block\">\n    {{ 'checkoutMode.deliveryEntries' | cxTranslate }}\n  </h2>\n\n  <ng-template\n    [cxOutlet]=\"CartOutlets.CART_ITEM_LIST\"\n    [cxOutletContext]=\"{\n      items: activeCartFacade.getDeliveryEntries() | async,\n      readonly: true,\n    }\"\n  >\n  </ng-template>\n</ng-container>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\">\n    <cx-spinner></cx-spinner>\n  </div>\n</ng-template>\n\n<ng-container cxInnerComponentsHost></ng-container>\n\n<div class=\"row cx-checkout-btns\">\n  <div class=\"col-md-12 col-lg-6\">\n    <button class=\"btn btn-block btn-secondary\" (click)=\"back()\">\n      {{ backBtnText | cxTranslate }}\n    </button>\n  </div>\n  <div class=\"col-md-12 col-lg-6\">\n    <button\n      class=\"btn btn-block btn-primary\"\n      [disabled]=\"deliveryModeInvalid || (isSetDeliveryModeHttpError$ | async)\"\n      (click)=\"next()\"\n    >\n      {{ 'common.continue' | cxTranslate }}\n    </button>\n  </div>\n</div>\n\n<ng-template #displayDeliveryMode let-content=\"content\">\n  <input\n    [attr.aria-checked]=\"getAriaChecked(content.code)\"\n    class=\"form-check-input\"\n    type=\"radio\"\n    [checked]=\"true\"\n    [value]=\"content.code\"\n    id=\"deliveryMode-{{ content.code }}\"\n    [attr.aria-label]=\"\n      content.name +\n      ' ' +\n      content.description +\n      ' ' +\n      content.deliveryCost?.formattedValue\n    \"\n  />\n  <label\n    class=\"cx-delivery-label form-check-label form-radio-label\"\n    for=\"deliveryMode-{{ content.code }}\"\n    aria-hidden=\"true\"\n  >\n    <div class=\"cx-delivery-mode\">\n      {{ content.name }}\n      <span *ngIf=\"content.description\" class=\"cx-delivery-mode-description\"\n        >({{ content.description }})</span\n      >\n    </div>\n    <div class=\"cx-delivery-price\">\n      {{ content.deliveryCost?.formattedValue }}\n    </div>\n    <div class=\"cx-delivery-details\"></div>\n  </label>\n</ng-template>\n\n<ng-template #displayServiceDelivery>\n  <ng-container *ngIf=\"hasServiceProducts$ | async\">\n    <legend class=\"cx-checkout-title d-none d-lg-block d-xl-block\">\n      {{ 'serviceOrderCheckout.serviceDeliveryOption' | cxTranslate }}\n    </legend>\n    <div class=\"cx-delivery-mode-wrapper\">\n      <div class=\"form-check\">\n        <ng-container\n          *ngTemplateOutlet=\"\n            displayDeliveryMode;\n            context: { content: serviceDeliveryConfig }\n          \"\n        ></ng-container>\n      </div>\n    </div>\n  </ng-container>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ServiceCheckoutDeliveryModeModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceCheckoutDeliveryModeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: ServiceCheckoutDeliveryModeModule, imports: [CommonModule,
            ReactiveFormsModule,
            I18nModule,
            SpinnerModule,
            OutletModule,
            PageComponentModule,
            FeaturesConfigModule,
            ServiceCheckoutDeliveryModeComponent], exports: [ServiceCheckoutDeliveryModeComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceCheckoutDeliveryModeModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    CheckoutDeliveryMode: {
                        component: ServiceCheckoutDeliveryModeComponent,
                    },
                },
            }),
        ], imports: [CommonModule,
            ReactiveFormsModule,
            I18nModule,
            SpinnerModule,
            OutletModule,
            PageComponentModule,
            FeaturesConfigModule,
            ServiceCheckoutDeliveryModeComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ServiceCheckoutDeliveryModeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        I18nModule,
                        SpinnerModule,
                        OutletModule,
                        PageComponentModule,
                        FeaturesConfigModule,
                        ServiceCheckoutDeliveryModeComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                CheckoutDeliveryMode: {
                                    component: ServiceCheckoutDeliveryModeComponent,
                                },
                            },
                        }),
                    ],
                    exports: [ServiceCheckoutDeliveryModeComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class S4ServiceCheckoutComponentModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceCheckoutComponentModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceCheckoutComponentModule, imports: [ServiceCheckoutReviewSubmitModule,
            CheckoutServiceDetailsModule,
            ServiceCheckoutDeliveryModeModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceCheckoutComponentModule, providers: [
            {
                provide: CheckoutStepsSetGuard,
                useExisting: CheckoutServiceOrderStepsSetGuard,
            },
        ], imports: [ServiceCheckoutReviewSubmitModule,
            CheckoutServiceDetailsModule,
            ServiceCheckoutDeliveryModeModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceCheckoutComponentModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        ServiceCheckoutReviewSubmitModule,
                        CheckoutServiceDetailsModule,
                        ServiceCheckoutDeliveryModeModule,
                    ],
                    providers: [
                        {
                            provide: CheckoutStepsSetGuard,
                            useExisting: CheckoutServiceOrderStepsSetGuard,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CheckoutServiceDetailsAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CheckoutServiceDetailsConnector {
    constructor() {
        this.adapter = inject(CheckoutServiceDetailsAdapter);
    }
    setServiceScheduleSlot(userId, cartId, scheduledAt) {
        return this.adapter.setServiceScheduleSlot(userId, cartId, scheduledAt);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CheckoutServiceDetailsConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CheckoutServiceDetailsConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CheckoutServiceDetailsConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CheckoutServiceDetailsService {
    constructor() {
        this.activeCartFacade = inject(ActiveCartFacade);
        this.userIdService = inject(UserIdService);
        this.commandService = inject(CommandService);
        this.serviceDetailsConnector = inject(CheckoutServiceDetailsConnector);
        this.eventService = inject(EventService);
        this.checkoutQueryFacade = inject(CheckoutQueryFacade);
        this.setServiceScheduleSlotCommand = this.commandService.create((scheduledAt) => this.checkoutPreconditions().pipe(switchMap(([userId, cartId]) => this.serviceDetailsConnector
            .setServiceScheduleSlot(userId, cartId, {
            scheduledAt,
        })
            .pipe(tap(() => this.eventService.dispatch({
            userId,
            cartId,
            scheduledAt,
        }, CheckoutServiceDetailsSetEvent))))), {
            strategy: CommandStrategy.CancelPrevious,
        });
    }
    checkoutPreconditions() {
        return combineLatest([
            this.userIdService.takeUserId(),
            this.activeCartFacade.takeActiveCartId(),
            this.activeCartFacade.isGuestCart(),
        ]).pipe(take(1), map(([userId, cartId, isGuestCart]) => {
            if (!userId ||
                !cartId ||
                (userId === OCC_USER_ID_ANONYMOUS && !isGuestCart)) {
                throw new Error('Checkout conditions not met');
            }
            return [userId, cartId];
        }));
    }
    setServiceScheduleSlot(scheduledAt) {
        return this.setServiceScheduleSlotCommand.execute(scheduledAt);
    }
    getSelectedServiceDetailsState() {
        return this.checkoutQueryFacade
            .getCheckoutDetailsState()
            .pipe(map((state) => ({ ...state, data: state.data?.servicedAt })));
    }
    getServiceProducts() {
        return this.activeCartFacade.getEntries().pipe(map((entries) => {
            return entries
                .map((entry) => {
                if (entry.product?.productTypes === ProductTypes.SERVICE) {
                    return entry.product?.code;
                }
                else {
                    return '';
                }
            })
                .filter((name) => name !== '');
        }));
    }
    hasNonServiceItems() {
        //Note: Pick up option is not applicable for Service Products
        return combineLatest([
            this.activeCartFacade.getDeliveryEntries(),
            this.getServiceProducts(),
        ]).pipe(take(1), map(([allEntries, serviceEntries]) => {
            return allEntries.length - serviceEntries.length > 0;
        }));
    }
    hasServiceItems() {
        return this.getServiceProducts().pipe(map((products) => products.length > 0));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CheckoutServiceDetailsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CheckoutServiceDetailsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CheckoutServiceDetailsService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class S4ServiceCheckoutCoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceCheckoutCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceCheckoutCoreModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceCheckoutCoreModule, providers: [
            CheckoutServiceDetailsService,
            {
                provide: CheckoutServiceDetailsFacade,
                useExisting: CheckoutServiceDetailsService,
            },
            CheckoutServiceDetailsConnector,
            CxDatePipe,
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceCheckoutCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        CheckoutServiceDetailsService,
                        {
                            provide: CheckoutServiceDetailsFacade,
                            useExisting: CheckoutServiceDetailsService,
                        },
                        CheckoutServiceDetailsConnector,
                        CxDatePipe,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const CONTENT_TYPE_JSON_HEADER = { 'Content-Type': 'application/json' };
class OccCheckoutServiceDetailsAdapter {
    constructor() {
        this.http = inject(HttpClient);
        this.logger = inject(LoggerService);
        this.occEndpoints = inject(OccEndpointsService);
    }
    setServiceScheduleSlot(userId, cartId, scheduledAt) {
        const url = this.occEndpoints.buildUrl('setServiceScheduleSlot', {
            urlParams: { userId, cartId },
        });
        const headers = new HttpHeaders({
            ...CONTENT_TYPE_JSON_HEADER,
        });
        //check if we need to add serializer and normalizer.
        return this.http.patch(url, scheduledAt, { headers }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCheckoutServiceDetailsAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCheckoutServiceDetailsAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCheckoutServiceDetailsAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultServiceOrderCheckoutDetailsOccEndpoint = {
    getCheckoutDetails: 'users/${userId}/carts/${cartId}?fields=deliveryAddress(FULL),deliveryMode(FULL),paymentInfo(FULL),costCenter(FULL),purchaseOrderNumber,paymentType(FULL),servicedAt',
};
const defaultOccCheckoutServiceOrderConfig = {
    backend: {
        occ: {
            endpoints: {
                ...defaultServiceOrderCheckoutDetailsOccEndpoint,
                setServiceScheduleSlot: 'users/${userId}/carts/${cartId}/serviceOrder/serviceScheduleSlot',
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class S4ServiceCheckoutOccModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceCheckoutOccModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceCheckoutOccModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceCheckoutOccModule, providers: [
            provideDefaultConfig(defaultOccCheckoutServiceOrderConfig),
            {
                provide: CheckoutServiceDetailsAdapter,
                useClass: OccCheckoutServiceDetailsAdapter,
            },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceCheckoutOccModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        provideDefaultConfig(defaultOccCheckoutServiceOrderConfig),
                        {
                            provide: CheckoutServiceDetailsAdapter,
                            useClass: OccCheckoutServiceDetailsAdapter,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class S4ServiceCheckoutModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceCheckoutModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceCheckoutModule, imports: [S4ServiceCheckoutComponentModule,
            S4ServiceCheckoutCoreModule,
            S4ServiceCheckoutOccModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceCheckoutModule, imports: [S4ServiceCheckoutComponentModule,
            S4ServiceCheckoutCoreModule,
            S4ServiceCheckoutOccModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4ServiceCheckoutModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        S4ServiceCheckoutComponentModule,
                        S4ServiceCheckoutCoreModule,
                        S4ServiceCheckoutOccModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CheckoutServiceDetailsAdapter, CheckoutServiceDetailsComponent, CheckoutServiceDetailsConnector, CheckoutServiceDetailsModule, CheckoutServiceDetailsService, CheckoutServiceOrderStepsSetGuard, OccCheckoutServiceDetailsAdapter, S4ServiceCheckoutComponentModule, S4ServiceCheckoutCoreModule, S4ServiceCheckoutModule, S4ServiceCheckoutOccModule, ServiceCheckoutDeliveryModeComponent, ServiceCheckoutDeliveryModeModule, ServiceCheckoutReviewSubmitComponent, ServiceCheckoutReviewSubmitModule };
//# sourceMappingURL=spartacus-s4-service-checkout.mjs.map
