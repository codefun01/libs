import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { LoggerService, OccEndpointsService, tryNormalizeHttpError, provideDefaultConfig } from '@spartacus/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs';
import { SubscriptionAdapter, SubscriptionActionsAdapter, SubscriptionBillingAdapter } from '@spartacus/subscription-billing/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const subscriptionBillingEndpoints = {
    subscriptionList: 'users/${userId}/subscriptions',
    subscriptionByCode: 'users/${userId}/subscriptions/${subscriptionCode}?fields=FULL',
    extensionEffectiveDate: 'users/${userId}/subscriptions/${subscriptionCode}/extensionEffectiveAt',
    extendSubscription: 'users/${userId}/subscriptions/${subscriptionCode}/extension',
    getEffectiveCancellationDate: 'users/${userId}/subscriptions/${subscriptionCode}/cancellationEffectiveAt',
    cancelSubscription: 'users/${userId}/subscriptions/${subscriptionCode}/cancellation',
    withdrawSubscription: 'users/${userId}/subscriptions/${subscriptionCode}/withdrawal',
    reverseCancellation: 'users/${userId}/subscriptions/${subscriptionCode}/cancellationReversal',
    subscriptionBillsList: 'users/${userId}/subscriptionbills?fields=FULL',
    subscriptionBillByCode: 'users/${userId}/subscriptionbills/${billId}?fields=FULL',
};
const defaultOccSubscriptionBillingConfig = {
    backend: {
        occ: {
            endpoints: {
                ...subscriptionBillingEndpoints,
                product: {
                    subscription: 'products/${productCode}?fields=sapPricePlan,sapSubscriptionTerm',
                },
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccSubscriptionAdapter {
    constructor() {
        this.logger = inject(LoggerService);
        this.http = inject(HttpClient);
        this.occEndpoints = inject(OccEndpointsService);
    }
    getSubscriptionByCode(userId, subscriptionCode) {
        const url = this.occEndpoints.buildUrl('subscriptionByCode', {
            urlParams: {
                userId,
                subscriptionCode,
            },
        });
        return this.http.get(url).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    getSubscriptionList(userId, pageSize, currentPage, sort) {
        const url = this.occEndpoints.buildUrl('subscriptionList', {
            urlParams: {
                userId,
            },
            queryParams: {
                pageSize,
                currentPage,
                sort,
            },
        });
        return this.http.get(url).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccSubscriptionAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccSubscriptionAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccSubscriptionAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const CONTENT_TYPE_JSON_HEADER = { 'Content-Type': 'application/json' };
class OccSubscriptionActionsAdapter {
    constructor() {
        this.logger = inject(LoggerService);
        this.http = inject(HttpClient);
        this.occEndpoints = inject(OccEndpointsService);
    }
    cancelSubscription(userId, subscriptionCode, cancellationDetails) {
        const url = this.occEndpoints.buildUrl('cancelSubscription', {
            urlParams: {
                userId,
                subscriptionCode,
            },
        });
        const headers = new HttpHeaders({
            ...CONTENT_TYPE_JSON_HEADER,
        });
        return this.http.post(url, cancellationDetails, { headers }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    getEffectiveCancellationDate(userId, subscriptionCode) {
        const url = this.occEndpoints.buildUrl('getEffectiveCancellationDate', {
            urlParams: {
                userId,
                subscriptionCode,
            },
        });
        return this.http.get(url).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    withdrawSubscription(userId, subscriptionCode, withdrawalData) {
        const url = this.occEndpoints.buildUrl('withdrawSubscription', {
            urlParams: {
                userId,
                subscriptionCode,
            },
        });
        const headers = new HttpHeaders({
            ...CONTENT_TYPE_JSON_HEADER,
        });
        return this.http.post(url, withdrawalData, { headers }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    reverseCancellation(userId, subscriptionCode) {
        const url = this.occEndpoints.buildUrl('reverseCancellation', {
            urlParams: {
                userId,
                subscriptionCode,
            },
        });
        const headers = new HttpHeaders({
            ...CONTENT_TYPE_JSON_HEADER,
        });
        return this.http.post(url, null, { headers }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    getExtensionEffectiveDate(userId, subscriptionCode, durationInMonth, unlimited) {
        const url = this.occEndpoints.buildUrl('extensionEffectiveDate', {
            urlParams: {
                userId,
                subscriptionCode,
            },
        });
        const requestBody = {
            numberOfBillingCycles: durationInMonth,
            unlimited,
        };
        return this.http
            .post(url, requestBody)
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    extendSubscription(userId, subscriptionCode, durationInMonth, unlimited) {
        const url = this.occEndpoints.buildUrl('extendSubscription', {
            urlParams: {
                userId,
                subscriptionCode,
            },
        });
        const requestBody = {
            numberOfBillingCycles: durationInMonth,
            unlimited,
        };
        return this.http.post(url, requestBody).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccSubscriptionActionsAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccSubscriptionActionsAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccSubscriptionActionsAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2025 SAP Spartacus team <spartacus-team@sap.com>
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccSubscriptionBillingAdapter {
    constructor() {
        this.logger = inject(LoggerService);
        this.http = inject(HttpClient);
        this.occEndpoints = inject(OccEndpointsService);
    }
    getSubscriptionBillsList(userId, pageSize, currentPage, sort, filters) {
        const url = this.occEndpoints.buildUrl('subscriptionBillsList', {
            urlParams: {
                userId,
            },
            queryParams: {
                pageSize,
                currentPage,
                sort,
                filters,
            },
        });
        return this.http.get(url).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    getSubscriptionBillByCode(userId, billId) {
        const url = this.occEndpoints.buildUrl('subscriptionBillByCode', {
            urlParams: {
                userId,
                billId,
            },
        });
        return this.http.get(url).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccSubscriptionBillingAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccSubscriptionBillingAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccSubscriptionBillingAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionBillingOccModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: SubscriptionBillingOccModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: SubscriptionBillingOccModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: SubscriptionBillingOccModule, providers: [
            provideDefaultConfig(defaultOccSubscriptionBillingConfig),
            {
                provide: SubscriptionAdapter,
                useClass: OccSubscriptionAdapter,
            },
            {
                provide: SubscriptionActionsAdapter,
                useClass: OccSubscriptionActionsAdapter,
            },
            {
                provide: SubscriptionBillingAdapter,
                useClass: OccSubscriptionBillingAdapter,
            },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: SubscriptionBillingOccModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        provideDefaultConfig(defaultOccSubscriptionBillingConfig),
                        {
                            provide: SubscriptionAdapter,
                            useClass: OccSubscriptionAdapter,
                        },
                        {
                            provide: SubscriptionActionsAdapter,
                            useClass: OccSubscriptionActionsAdapter,
                        },
                        {
                            provide: SubscriptionBillingAdapter,
                            useClass: OccSubscriptionBillingAdapter,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OccSubscriptionActionsAdapter, OccSubscriptionAdapter, OccSubscriptionBillingAdapter, SubscriptionBillingOccModule };
//# sourceMappingURL=spartacus-subscription-billing-occ.mjs.map
