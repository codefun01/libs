import * as i0 from '@angular/core';
import { ElementRef, Renderer2, OnInit, Type, StaticProvider, TemplateRef, ComponentFactory, ModuleWithProviders, RendererFactory2, ComponentRef, ViewContainerRef, ComponentFactoryResolver, Injector, OnDestroy, OnChanges, EmbeddedViewRef, EventEmitter, SimpleChanges, NgModuleRef, ChangeDetectorRef, InjectionToken, AfterViewInit, FactoryProvider, ValueProvider, TrackByFunction, PipeTransform, DestroyRef, QueryList, AfterViewChecked, DoCheck } from '@angular/core';
import * as i3 from '@spartacus/core';
import { WindowRef, GlobalMessageService, GlobalMessageEntities, GlobalMessageType, Applicable, Priority, LoggerService, RoutingService, DeferLoadingStrategy, ConfigInitializerService, FeatureModulesService, CmsComponentMapping, CmsConfig, CMSComponentConfig, CmsComponentChildRoutesConfig, CmsComponent, CxEvent, DynamicAttributeService, EventService, ContentSlotComponentData, CmsService, ContentSlotData, UnifiedInjector, Page, LanguageService, SiteContextConfig, SiteThemeService, CmsActivatedRouteSnapshot, TranslationService, TranslationChunkService, PageContext, SemanticPathService, ProtectedRoutesGuard, RoutingConfigService, PageMetaService, PageMeta, PageRobotsMeta, Image, Config, Product, ProductReviewService, Review, ProductService, ProductScope, ImageGroup, AnonymousConsentsService, CmsBannerCarouselComponent, CmsBannerComponent, CmsLinkComponent, CmsParagraphComponent, CmsPDFDocumentComponent, Translatable, CMSTabParagraphContainer, CmsVideoComponent, Promotion, CmsSiteContextSelectorComponent, ContextServiceMap, SiteContext, SiteTheme, ConsentTemplate, AnonymousConsent, AnonymousConsentsConfig, UserConsentService, AuthService, CustomerCoupon, CustomerCouponService, CustomerCouponSearchResult, PaginationModel, SortModel, ProductInterestSearchResult, ProductInterestEntryRelation, UserInterestsService, NotificationPreference, UserNotificationPreferenceService, PaymentDetails, UserPaymentService, CmsPageTitleComponent, CmsBreadcrumbsComponent, CmsNavigationComponent, Suggestion, SearchboxService, ProductSearchPage, CmsSearchBoxComponent, CmsScrollToTopComponent, ScrollBehavior, CmsProductCarouselComponent, ProductSearchByCodeService, ProductSearchByCategoryService, ProductSearchService, CurrencyService, ActivatedRouterStateSnapshot, Facet, Breadcrumb, FacetValue, CmsProductReferencesComponent, ProductReferenceService, CmsComponentWithChildren, UserIdService, AuthConfigService, ProtectedRoutesService, UrlMatcherFactory, ActivatedRoutesService, Category, Price, CaptchaConfig, SiteAdapter, ScriptLoader, BaseSiteService, Title as Title$1, Address } from '@spartacus/core';
import * as i2$1 from '@angular/router';
import { Route, CanActivateFn, RouterStateSnapshot, GuardResult, UrlSegment, UrlMatchResult, Router, Params, ActivatedRoute, ActivatedRouteSnapshot, UrlTree } from '@angular/router';
import * as i1 from '@angular/common';
import { ViewportScroller } from '@angular/common';
import { DomSanitizer, SafeHtml, Title, Meta, MetaDefinition } from '@angular/platform-browser';
import * as rxjs from 'rxjs';
import { Observable, Subscription, BehaviorSubject, Subject, ReplaySubject } from 'rxjs';
import * as i2 from '@angular/service-worker';
import * as i2$2 from '@angular/forms';
import { UntypedFormControl, AbstractControl, FormGroup, UntypedFormGroup, UntypedFormBuilder, ControlValueAccessor, ValidatorFn, ValidationErrors } from '@angular/forms';
import * as i2$3 from '@ng-select/ng-select';
import { NgSelectComponent } from '@ng-select/ng-select';
import { HttpUrlEncodingCodec } from '@angular/common/http';
import * as i5 from 'ngx-infinite-scroll';
import { ActionsSubject } from '@ngrx/store';

/**
 * The ltr and rtl directions can be used to configure the storefront for a certain direction, both statically
 * or dynamically.
 *
 * The HTML5 "auto" value is not supported in Spartacus, as it's considered to be too fragile for the global
 * direction.
 */
declare enum DirectionMode {
    /**
     * Indicates Left to Right direction.
     */
    LTR = "ltr",
    /**
     * Indicates Right to Left direction.
     */
    RTL = "rtl"
}
/**
 * Contains the configuration mode for language driven directionality. The detect mode is recommended
 * for a multi-site or multi-lingual setup where the active language should dictate the direction mode.
 */
interface Direction {
    /**
     * The default direction mode is used for the direction mode of the overall storefront. The default mode
     * can be used for all languages, but can be further enhanced dynamically by using the language detect mode.
     * The default mode will also be used in detect mode for those languages that are not listed in either
     * `rtlLanguages` or `ltrLanguages`.
     */
    default?: DirectionMode;
    /**
     * If detect is enabled, the direction is driven by the active language. The language is compared to the
     * list of configured `rtlLanguages` vs `ltrLanguages`. If no language is resolved, the default direction
     * mode is used.
     *
     * If no direction can be resolved, the direction is removed.
     */
    detect?: boolean;
    /**
     * The language isoCodes that are used to detect Right to Left languages.
     */
    rtlLanguages?: string[];
    /**
     * The language isoCodes that are used to detect Left to Right languages.
     */
    ltrLanguages?: string[];
}

declare enum ICON_TYPE$1 {
    ACTIVE = "ACTIVE",
    ADDRESS_BOOK = "ADDRESS_BOOK",
    AMEX = "AMEX",
    CARET_DOWN = "CARET_DOWN",
    CARET_LEFT = "CARET_LEFT",
    CARET_RIGHT = "CARET_RIGHT",
    CARET_UP = "CARET_UP",
    CART = "CART",
    CART_PLUS = "CART_PLUS",
    CART_ARROW_DOWN = "CART_ARROW_DOWN",
    CHECK = "CHECK",
    CIRCLE = "CIRCLE",
    CLIPBOARD_LIST = "CLIPBOARD_LIST",
    CLOCK = "CLOCK",
    CLOSE = "CLOSE",
    COLLAPSE = "COLLAPSE",
    CREDIT_CARD = "CREDIT_CARD",
    DINERS_CLUB = "DINERS_CLUB",
    DOWNLOAD = "DOWNLOAD",
    EMPTY_HEART = "EMPTY_HEART",
    ERROR = "ERROR",
    EXPAND = "EXPAND",
    EXPAND_ARROWS = "EXPAND_ARROWS",
    EYE = "EYE",
    EYE_SLASH = "EYE_SLASH",
    FILE = "FILE",
    FILTER = "FILTER",
    GRID = "GRID",
    HEART = "HEART",
    INFO = "INFO",
    LINK_OUT = "LINK_OUT",
    LIST = "LIST",
    MASTER_CARD = "MASTER_CARD",
    OFF = "OFF",
    ON = "ON",
    ORDER = "ORDER",
    PENCIL = "PENCIL",
    RESET = "RESET",
    REPEAT = "REPEAT",
    SEARCH = "SEARCH",
    SEARCH_PLUS = "SEARCH_PLUS",
    SEARCH_MINUS = "SEARCH_MINUS",
    SORT = "SORT",
    SORT_AMOUNT_DOWN = "SORT_AMOUNT_DOWN",
    SORT_AMOUNT_UP = "SORT_AMOUNT_UP",
    SORT_DOWN = "SORT_DOWN",
    STAR = "STAR",
    SUCCESS = "SUCCESS",
    TRASH = "TRASH",
    USER_FRIENDS = "USER_FRIENDS",
    VISA = "VISA",
    WARNING = "WARNING",
    HEADSET = "HEADSET",
    ATTACHMENT = "ATTACHMENT",
    UPLOAD = "UPLOAD",
    USER = "USER",
    USER_PLUS = "USER_PLUS",
    ARROW_LEFT = "ARROW_LEFT",
    ARROW_RIGHT = "ARROW_RIGHT",
    ARROW_DOWN = "ARROW_DOWN",
    ARROW_UP = "ARROW_UP",
    C360_CIRCLE_USER = "C360_CIRCLE_USER",
    C360_INVOICE = "C360_INVOICE",
    HELP = "HELP"
}
declare abstract class IconConfig {
    icon?: IconOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IconConfig>;
}
declare module '@spartacus/core' {
    interface Config extends IconConfig {
    }
}
interface IconOptions {
    /**
     * Each icon type can be configured with a so-called symbol. The symbol will
     * be used to map the icon to an SVG `symbol` (id) or to the style classes of
     * a font based icon. The following configuration would map to a fontawesome
     * icon:
     *
     * icon: {
     *   symbols: {
     *     CART: 'fas fa-shopping-cart'
     *   }
     * }
     */
    symbols?: {
        [ICON_TYPE: string]: string;
    };
    /**
     * Resources are used to map icon types to certain asset, such as an SVG (sprite) image.
     * The resource type (`IconResourceType`) dictates whether an SVG image is used. The URL
     * is used for the SVG xlink reference.
     */
    resources?: IconConfigResource[];
    /**
     * Lists icons that should be flipped for a specific direction.
     */
    flipDirection?: {
        [ICON_TYPE: string]: DirectionMode;
    };
}
interface IconConfigResource {
    type: IconResourceType | string;
    url?: string;
    types?: (ICON_TYPE$1 | string)[];
}
/**
 * Each ICON type can have an companied resource type, such as SVG, LINK (font) or just TEXT.
 * The resources will be automatically loaded in case they're required for the `ICON_TYPE`.
 */
declare enum IconResourceType {
    /**
     * An svg based icon requires an SVG resource that must be loaded,
     * this is typically a sprite svg file.
     */
    SVG = "svg",
    /**
     * A font based ICON might require an additional CSS file to be loaded.
     */
    LINK = "link",
    /**
     * Text based icons will simply add the ICON string to the DOM. Text icons do not need an image
     * or CSS pseudo class (i.e. :before), as the text itself is the icon (i.e. +)
     */
    TEXT = "text"
}

declare class IconLoaderService {
    protected winRef: WindowRef;
    protected iconConfig: IconConfig;
    protected sanitizer: DomSanitizer;
    private loadedResources;
    constructor(winRef: WindowRef, iconConfig: IconConfig, sanitizer: DomSanitizer);
    /**
     * Returns an html fragment which can be added to the DOM in a safe way.
     */
    getHtml(type: ICON_TYPE$1 | string): SafeHtml | undefined;
    /**
     * Return the direction for which the icon should mirror (ltr vs rtl). The icon direction
     * is configurable, but optional, as only a few icons should be flipped for rtl direction.
     */
    getFlipDirection(type: ICON_TYPE$1 | string): DirectionMode | undefined;
    /**
     *
     * Returns the symbol class(es) for the icon type.
     */
    getStyleClasses(iconType: ICON_TYPE$1 | string): string;
    /**
     * Indicates whether the given `ICON_TYPE` is configured for
     * the given `IconResourceType`.
     */
    private isResourceType;
    /**
     * Returns the path to the svg link. The link supports path names
     * as well, if the config a[[s been setup to support a svg file path.
     * Additionally, the icon prefix will be taken into account to prefix the
     * icon IDs in the SVG.
     */
    private getSvgPath;
    /**
     * Loads the resource url (if any) for the given icon.
     * The icon will only be loaded once.
     *
     * NOTE: this is not working when the shadow is used as there's
     * no head element available and the link must be loaded for every
     * web component.
     */
    addLinkResource(iconType: ICON_TYPE$1 | string): void;
    private findResource;
    getSymbol(iconType: ICON_TYPE$1 | string): string | undefined;
    private get config();
    static ɵfac: i0.ɵɵFactoryDeclaration<IconLoaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IconLoaderService>;
}

type ICON_TYPE = ICON_TYPE$1 | string;
/**
 *
 * The icon component can be added in different ways:
 *
 * With the component selector:
 * `<cx-icon type="SEARCH"></cx-icon>`
 *
 * With the attribute selector:
 * `<span cxIcon="STAR"></span>`
 *
 * Additionally, content can be projected to the icon:
 *
 * `<button cxIcon="HAPPY">happy label</button>`
 *
 * The above button would become (based on a TEXT resource type):
 * `<button>😊happy label</button>`
 *
 * While the content is projected, the icon itself doesn't require an
 * additional DOM node which is an advantage over the component selector.
 */
declare class IconComponent {
    protected iconLoader: IconLoaderService;
    protected elementRef: ElementRef<HTMLElement>;
    protected renderer: Renderer2;
    /**
     * The cxIcon directive is bound to the icon type. You can feed the `ICON_TYPE` to
     * accomplish a configurable button in the UI.
     */
    set cxIcon(type: ICON_TYPE);
    /**
     * The type input parameter is bound to the icon type. You can feed the `ICON_TYPE` to
     * accomplish a configurable button in the UI.
     */
    set type(type: ICON_TYPE);
    /**
     * the icon provides an html fragment that is used to add SVG or text based icons.
     */
    icon: SafeHtml | undefined;
    /**
     * The `flip-at-rtl` class is added to the DOM for the style layer to flip the icon in RTL direction.
     */
    flipAtRtl: boolean;
    /**
     * The `flip-at-ltr` class is added to the DOM for the style layer to flip the icon in LTR direction.
     */
    flipAtLtr: boolean;
    /**
     * Maintains the applied style classes so we can remove them when the
     * icon type changes at run time.
     */
    protected styleClasses: string[];
    constructor(iconLoader: IconLoaderService, elementRef: ElementRef<HTMLElement>, renderer: Renderer2);
    protected setIcon(type: ICON_TYPE): void;
    /**
     * The icons supports flipping for some icons to support rtl and ltr directions.
     */
    protected flipIcon(type: ICON_TYPE): void;
    /**
     * Adds the style classes and the link resource (if available).
     */
    protected addStyleClasses(type: ICON_TYPE): void;
    protected get host(): HTMLElement;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IconComponent, "cx-icon,[cxIcon]", never, { "cxIcon": { "alias": "cxIcon"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class IconModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<IconModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<IconModule, never, [typeof i1.CommonModule, typeof IconComponent], [typeof IconComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<IconModule>;
}

declare class GlobalMessageComponent implements OnInit {
    protected globalMessageService: GlobalMessageService;
    iconTypes: typeof ICON_TYPE$1;
    messages$: Observable<GlobalMessageEntities>;
    messageType: typeof GlobalMessageType;
    constructor(globalMessageService: GlobalMessageService);
    ngOnInit(): void;
    clear(type: GlobalMessageType, index: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GlobalMessageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GlobalMessageComponent, "cx-global-message", never, {}, {}, never, never, true, never>;
}

declare class GlobalMessageComponentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GlobalMessageComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GlobalMessageComponentModule, never, [typeof i1.CommonModule, typeof IconModule, typeof i3.I18nModule, typeof GlobalMessageComponent], [typeof GlobalMessageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GlobalMessageComponentModule>;
}

declare enum OutletPosition {
    REPLACE = "replace",
    BEFORE = "before",
    AFTER = "after"
}
declare const AVOID_STACKED_OUTLETS = false;
declare const USE_STACKED_OUTLETS = true;
/**
 * Token for injecting outlet related context to the component rendered in the outlet
 */
declare abstract class OutletContextData<T = any> {
    /**
     * Provides reference of the outlet where component is rendered in
     */
    reference: string;
    /**
     * Provides position of the outlet
     */
    position: OutletPosition;
    /**
     * Provides outlet context
     *
     * WARNING: Avoid using it if you need to read the latest value of the context. This property
     *          is only the initial context value and won't be updated when the new context appears.
     *          Use `context$` observable instead.
     *
     * @deprecated since 3.0 - use `context$` observable instead
     */
    context: T;
    /**
     * Provides outlet context as an observable
     */
    context$: Observable<T>;
}

interface ProvideOutletOptions {
    /**
     *  Unique id of the outlet
     */
    id: string;
    /**
     * Component to be registered for the outlet
     */
    component: Type<any>;
    /**
     * Component's position in the outlet
     */
    position?: OutletPosition;
}
/**
 * Helper function to register a component for an outlet.
 *
 * @param options.id unique id of the outlet
 * @param options.component Component to be registered for the outlet
 * @param options.position Component's position in the outlet (default: `OutletPosition.AFTER`)
 */
declare function provideOutlet(options: ProvideOutletOptions): StaticProvider;

declare class OutletService<T = TemplateRef<any> | ComponentFactory<any>> {
    private templatesRefs;
    /**
     * Adds a template or ComponentFactory, so that UI outlets can be replaced dynamically.
     * The UI position where this template or ComponentFactory is inserted is given by a
     * string reference (called `outlet`) and optional `OutletPosition`. The `OutletPosition`
     * is either before or after, or replaces the entire UI.
     *
     * @param outlet the UI location represented by a string
     * @param template the `TemplateRef` that will be used to insert UI
     * @param position the `OutletPosition` in the UI
     */
    add(outlet: string, template: T, position?: OutletPosition): void;
    /**
     * @param factory The `ComponentFactory` that will be dynamically added to the outlet UI
     */
    add(outlet: string, factory: T, position?: OutletPosition): void;
    /**
     *
     * Returns a single object or multiple objects for the given outlet reference,
     * depending on the `stacked` argument.
     *
     * @param outlet The outlet reference
     * @param position the outlet position, `OutletPosition.before`, `OutletPosition.AFTER` or `OutletPosition.REPLACE`
     * @param stacked Indicates whether an array of outlet components is returned
     */
    get(outlet: string, position?: OutletPosition, stacked?: boolean): T[] | T | undefined;
    remove(outlet: string, position?: OutletPosition, value?: T): void;
    protected removeValueOrAll(store: Map<string, T[]>, outlet: string, value?: T): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OutletService<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OutletService<any>>;
}

interface LaunchConfig {
    [key: string]: LaunchOptions;
}
type LaunchOptions = LaunchOutletDialog | LaunchInlineDialog | LaunchRoute | LaunchInlineRootDialog;
/**
 * Parent type for configurations that render components
 */
interface LaunchDialog {
    component: any;
    /**
     * Can the element be rendered multiple times
     */
    multi?: boolean;
    /**
     * Dialog type is used to apply CSS classes
     */
    dialogType?: DIALOG_TYPE;
}
/**
 * Configuration type to render a component in an outlet.
 * Outlet rendering should only be used for elements that open once and do not close.
 */
interface LaunchOutletDialog extends LaunchDialog {
    /**
     * The outlet to render the element in
     */
    outlet: string;
    /**
     * Default: OutletPosition.BEFORE
     */
    position?: OutletPosition;
}
/**
 * Configuration type to render a component inline (next to the trigger)
 */
interface LaunchInlineDialog extends LaunchDialog {
    inline: boolean;
}
/**
 * Configuration type to render a component directly inside the cx-storefront (storefront selector).
 * Best used for global elements like dialogs.
 */
interface LaunchInlineRootDialog extends LaunchDialog {
    inlineRoot: boolean;
}
/**
 * Configuration type to render as link
 */
interface LaunchRoute {
    /**
     * The route for the url
     */
    cxRoute: string;
    /**
     * The parameters for the route
     */
    params?: {
        [param: string]: any;
    };
}
/**
 * Types of dialog openings supported
 */
declare enum DIALOG_TYPE {
    POPOVER = "POPOVER",
    POPOVER_CENTER = "POPOVER_CENTER",
    POPOVER_CENTER_BACKDROP = "POPOVER_CENTER_BACKDROP",
    DIALOG = "DIALOG",
    SIDEBAR_START = "SIDEBAR_START",
    SIDEBAR_END = "SIDEBAR_END"
}
/**
 * List of available callers
 */
declare enum LAUNCH_CALLER {
    ASM = "ASM",
    SKIP_LINKS = "SKIP_LINKS",
    ANONYMOUS_CONSENT = "ANONYMOUS_CONSENT",
    REPLENISHMENT_ORDER = "REPLENISHMENT_ORDER",
    PLACE_ORDER_SPINNER = "PLACE_ORDER_SPINNER",
    SUGGESTED_ADDRESSES = "SUGGESTED_ADDRESSES",
    COUPON = "COUPON",
    CLAIM_DIALOG = "CLAIM_DIALOG",
    STOCK_NOTIFICATION = "STOCK_NOTIFICATION"
}

declare class LaunchDialogModule {
    static forRoot(): ModuleWithProviders<LaunchDialogModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LaunchDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LaunchDialogModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LaunchDialogModule>;
}

declare abstract class LaunchRenderStrategy implements Applicable {
    protected document: any;
    protected rendererFactory: RendererFactory2;
    protected renderedCallers: Array<{
        caller: LAUNCH_CALLER | string;
        element?: any;
        component?: ComponentRef<any>;
    }>;
    /**
     * Classes to apply to the component when the dialog is a DIALOG
     */
    protected readonly dialogClasses: string[];
    /**
     * Classes to apply to the component when the dialog is a POPOVER
     */
    protected readonly popoverClasses: string[];
    /**
     * Classes to apply to the component when the dialog is a POPOVER_CENTER
     */
    protected readonly popoverCenterClasses: string[];
    /**
     * Classes to apply to the component when the dialog is a POPOVER_CENTER with a backdrop
     */
    protected readonly popoverCenterBackdropClasses: string[];
    /**
     * Classes to apply to the component when the dialog is a SIDEBAR_END
     */
    protected readonly sidebarEndClasses: string[];
    /**
     * Classes to apply to the component when the dialog is a SIDEBAR_START
     */
    protected readonly sidebarStartClasses: string[];
    protected renderer: Renderer2;
    constructor(document: any, rendererFactory: RendererFactory2);
    /**
     * Render method to implement based on the strategy
     *
     * @param config Launch configuration
     */
    abstract render(config: LaunchOptions, caller: LAUNCH_CALLER | string, vcr?: ViewContainerRef): Observable<ComponentRef<any> | undefined> | void;
    /**
     * Determines if the strategy is the right one for the provided configuration
     *
     * @param config
     */
    abstract hasMatch(config: LaunchOptions): boolean;
    /**
     * Determines if element should render
     *
     * @param caller
     * @param config
     */
    protected shouldRender(caller: LAUNCH_CALLER | string, config: LaunchDialog): boolean;
    protected applyClasses(component: ComponentRef<any>, dialogType: DIALOG_TYPE): void;
    /**
     * Method to call when rendered element is destroyed
     * The element will be removed from the list of rendered elements
     *
     * @param caller
     * @param _config optional parameters used in children strategies
     */
    remove(caller: LAUNCH_CALLER | string, config: LaunchOptions): void;
    getPriority(): Priority;
}

declare class InlineRenderStrategy extends LaunchRenderStrategy {
    protected document: any;
    protected rendererFactory: RendererFactory2;
    protected componentFactoryResolver: ComponentFactoryResolver;
    protected logger: LoggerService;
    constructor(document: any, rendererFactory: RendererFactory2, componentFactoryResolver: ComponentFactoryResolver);
    /**
     * Renders the component from the configuration in the view container ref
     *
     * @param config
     * @param caller
     * @param vcr
     */
    render(config: LaunchInlineDialog, caller: LAUNCH_CALLER | string, vcr: ViewContainerRef): Observable<ComponentRef<any>> | void;
    hasMatch(config: LaunchInlineDialog): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<InlineRenderStrategy, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InlineRenderStrategy>;
}

declare class InlineRootRenderStrategy extends LaunchRenderStrategy {
    protected document: any;
    protected rendererFactory: RendererFactory2;
    protected componentFactoryResolver: ComponentFactoryResolver;
    protected injector: Injector;
    constructor(document: any, rendererFactory: RendererFactory2, componentFactoryResolver: ComponentFactoryResolver, injector: Injector);
    get hostComponent(): ComponentRef<any>;
    render(config: LaunchInlineRootDialog, caller: LAUNCH_CALLER | string): Observable<ComponentRef<any>> | void;
    hasMatch(config: LaunchInlineRootDialog): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<InlineRootRenderStrategy, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InlineRootRenderStrategy>;
}

declare class LaunchDialogService {
    protected renderStrategies: LaunchRenderStrategy[];
    protected layoutConfig: LayoutConfig;
    private _dialogClose;
    private _dataSubject;
    protected logger: LoggerService;
    get data$(): Observable<any>;
    constructor(renderStrategies: LaunchRenderStrategy[], layoutConfig: LayoutConfig);
    /**
     * Open the dialog
     *
     * @param caller LAUNCH_CALLER
     * @param openElement button's Element ref
     * @param vcr View Container Ref of the container for inline rendering
     * @param data optional data which could be passed to dialog
     */
    openDialog(caller: LAUNCH_CALLER | string, openElement?: ElementRef, vcr?: ViewContainerRef, data?: any): Observable<any> | undefined;
    /**
     * Render the element based on the strategy from the launch configuration
     *
     * @param caller LAUNCH_CALLER
     * @param vcr View Container Ref of the container for inline rendering
     */
    launch(caller: LAUNCH_CALLER | string, vcr?: ViewContainerRef, data?: any): void | Observable<ComponentRef<any> | undefined>;
    /**
     * Opens dialog and subscribe in the service. Should be used if the trigger component might get destroyed while the component is open.
     *
     * @param caller Launch Caller
     * @param openElement Element to open
     * @param data Data to provide to the rendered element
     */
    openDialogAndSubscribe(caller: LAUNCH_CALLER | string, openElement?: ElementRef, data?: any): void;
    /**
     * Util method to remove element from rendered elements list
     *
     * @param caller LAUNCH_CALLER
     */
    clear(caller: LAUNCH_CALLER | string): void;
    get dialogClose(): Observable<any | undefined>;
    closeDialog(reason: any): void;
    /**
     * Returns the configuration for the caller
     *
     * @param caller LAUNCH_CALLER
     */
    protected findConfiguration(caller: LAUNCH_CALLER | string): LaunchOptions | undefined;
    /**
     * Returns the render strategy based on the configuration
     *
     * @param config Configuration for launch
     */
    protected getStrategy(config: LaunchOptions): LaunchRenderStrategy | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<LaunchDialogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LaunchDialogService>;
}

declare class OutletRefDirective implements OnInit, OnDestroy {
    private tpl;
    private outletService;
    cxOutletRef: string;
    cxOutletPos: OutletPosition;
    constructor(tpl: TemplateRef<any>, outletService: OutletService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OutletRefDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OutletRefDirective, "[cxOutletRef]", never, { "cxOutletRef": { "alias": "cxOutletRef"; "required": false; }; "cxOutletPos": { "alias": "cxOutletPos"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OutletRefModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OutletRefModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OutletRefModule, never, [typeof i1.CommonModule, typeof OutletRefDirective], [typeof OutletRefDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OutletRefModule>;
}

declare class OutletRendererService {
    private outletRefs;
    /**
     * Dynamically render the templates in the specified array
     *
     * @param outlet
     */
    render(outlet: string): void;
    /**
     * Register outlet to be available to render dynamically
     *
     * @param cxOutlet
     * @param context
     */
    register(cxOutlet: string, context: OutletDirective): void;
    /**
     * Returns map of outlets
     *
     */
    getOutletRef(outlet: string): Observable<OutletDirective>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OutletRendererService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OutletRendererService>;
}

declare class OutletRenderStrategy extends LaunchRenderStrategy {
    protected document: any;
    protected rendererFactory: RendererFactory2;
    protected outletService: OutletService<ComponentFactory<any>>;
    protected componentFactoryResolver: ComponentFactoryResolver;
    protected outletRendererService: OutletRendererService;
    constructor(document: any, rendererFactory: RendererFactory2, outletService: OutletService<ComponentFactory<any>>, componentFactoryResolver: ComponentFactoryResolver, outletRendererService: OutletRendererService);
    /**
     * Renders the element in the configured outlet
     *
     * @param config
     * @param caller
     * @param vcr
     */
    render(config: LaunchOutletDialog, caller: LAUNCH_CALLER | string): Observable<ComponentRef<any> | undefined> | void;
    hasMatch(config: LaunchOutletDialog): boolean;
    remove(caller: LAUNCH_CALLER | string, config: LaunchOutletDialog): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OutletRenderStrategy, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OutletRenderStrategy>;
}

declare class RoutingRenderStrategy extends LaunchRenderStrategy {
    protected document: any;
    protected rendererFactory: RendererFactory2;
    protected routingService: RoutingService;
    constructor(document: any, rendererFactory: RendererFactory2, routingService: RoutingService);
    /**
     * Navigates to the route configured for the caller
     */
    render(config: LaunchRoute, _caller: LAUNCH_CALLER | string): void;
    hasMatch(config: LaunchRoute): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<RoutingRenderStrategy, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RoutingRenderStrategy>;
}

/**
 * The `BREAKPOINT` typing defaults to five default screen names:
 * xs, sm, md, lg, xl.
 *
 * The type can be extended to allow for custom screens, such as XLL or `tablet`.
 *
 * While the screen names are fully configurable, other features might have
 * pre-configured layout settings per screen. Page layouts or table configurations,
 * for example, are driven by screen size. In case you change the screen size or
 * introduce new screen names, you might loose out on these configurations.
 */
declare enum BREAKPOINT {
    xs = "xs",
    sm = "sm",
    md = "md",
    lg = "lg",
    xl = "xl"
}
type LayoutSections = 'header' | 'footer' | 'LandingPage2Template' | string;
type SlotConfig = {
    /** The cms page slots are mapped by the `slot.position`. */
    slots?: string[];
    /**
     * The page fold identifies the last expected page slot above-the-fold.
     * It's perfectly fine to specify this by indication, but keep in mind that
     * a more precise indication will gain a more positive impact on performance.
     */
    pageFold?: string;
};
type SlotGroup = {
    /** The page slot configuration for large screens */
    [BREAKPOINT.lg]?: SlotConfig;
    /** The page slot configuration for medium screens */
    [BREAKPOINT.md]?: SlotConfig;
    /** The page slot configuration for small screens */
    [BREAKPOINT.sm]?: SlotConfig;
    /** The page slot configuration for extra small screens */
    [BREAKPOINT.xs]?: SlotConfig;
};
type LayoutSlotConfig = {
    [section in LayoutSections]: SlotConfig | SlotGroup | LayoutSlotConfig;
};
interface BreakPoint {
    /**
     * The minimum screen width.
     */
    min?: number;
    /**
     * The minimum screen width.
     */
    max?: number;
}
/**
 * The `LayoutBreakPoints` can be used to configure the size of a specific screen. The screen
 * are defined by breakpoints, with a min and/or max value. The breakpoint size is in pixels,
 * hence a numeric value is expected.
 */
type LayoutBreakPoints = {
    [t in BREAKPOINT]?: number | BreakPoint;
};
/**
 * The LayoutConfig supports the configuration of page slots by page templates
 * or page sections, such as headers and footers. The configuration also supports
 * adaptive design per breakpoint (not per device type), so that the DOM is (re)rendered
 * por a given breakpoint.
 */
declare abstract class LayoutConfig {
    /**
     * The breakpoint configuration is used to defined various screens. A specific screen name can
     * be used to further configure certain features, such as the overall layout or specific
     * component configurations.
     */
    breakpoints?: LayoutBreakPoints;
    layoutSlots?: LayoutSlotConfig;
    /**
     * Deferred loading is a technique to hold of with the loading / creation
     * of DOM elements which are not not in the initial view port.
     * This technique wil increase performance.
     */
    deferredLoading?: {
        /**
         * The global strategy will be used as a fallback strategy for all DOM creation,
         * but can be overridden by local configuration, i.e. for cms components.
         */
        strategy?: DeferLoadingStrategy;
        /**
         * The intersection margin contains the offset used by the Intersection Observer
         * to observe elements outside the view port.
         *
         * See https://developer.mozilla.org/en-US/docs/Web/API/IntersectionObserver/rootMargin
         */
        intersectionMargin?: string;
    };
    launch?: LaunchConfig;
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LayoutConfig>;
}
declare module '@spartacus/core' {
    interface Config extends LayoutConfig {
    }
}

interface IntersectionOptions {
    deferLoading?: DeferLoadingStrategy;
    /**
     * The root margin effects when an element intersects, an increased
     * margin will faster intersects the element with the view port.
     */
    rootMargin?: string;
    /**
     * Indicate at what percentage of the target's visibility
     * the observer's callback should be executed.
     */
    threshold?: number | number[];
}

type IntersectingCondition = (entry: IntersectionObserverEntry) => boolean;
/**
 * The IntersectionService uses the native IntersectionObserver (v2), which
 * can be used to implement pre-loading and deferred loading of DOM content.
 *
 */
declare class IntersectionService {
    protected config: LayoutConfig;
    protected platformId: Object;
    constructor(config: LayoutConfig);
    /**
     * Returns an Observable that emits only once a boolean value whenever
     * the given element has shown in the view port.
     *
     * The returned observable will only emit the first value. The
     * observable must be cleaned up either way, since the value might never emit; it
     * depends on whether the element appears in the view port.
     *
     * @param element - HTML element
     * @param options - Allows to specify an optional root margin, in order to fire before the element shows up in the viewport
     * @param intersectingCondition - Allows to specify an intersecting condition.
     * If this parameter is not set, then the transition state of the element will be verified whenever the element intersects the view port.
     * @returns Element intersects?
     */
    isIntersected(element: HTMLElement, options?: IntersectionOptions, intersectingCondition?: IntersectingCondition): Observable<boolean>;
    /**
     * Returns an observable that emits for every change of intersection of a given element.
     *
     * @param element - HTML element
     * @param options - Allows to specify an optional root margin, in order to fire before the element shows up in the viewport
     * @param intersectingCondition - Allows to specify an intersecting condition.
     * If this parameter is not set, then the transition state of the element will be verified whenever the element intersects the view port.
     * @returns Element intersects?
     */
    isIntersecting(element: HTMLElement, options?: IntersectionOptions, intersectingCondition?: IntersectingCondition): Observable<boolean>;
    /**
     * Indicates whenever the element intersects the view port. An optional margin
     * is used to intersects before the element shows up in the viewport.
     * A value is emitted each time the element intersects.
     */
    private intersects;
    private createIntersectionObservable;
    private getRootMargin;
    static ɵfac: i0.ɵɵFactoryDeclaration<IntersectionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IntersectionService>;
}

/**
 * The defer loading serivce is used to defer loading of DOM elements
 * until the elements are required for the user experience.
 */
declare class DeferLoaderService {
    private platformId;
    protected config: LayoutConfig;
    protected intersectionService: IntersectionService;
    globalLoadStrategy: DeferLoadingStrategy;
    constructor(platformId: Object, config: LayoutConfig, intersectionService: IntersectionService);
    /**
     * Defer loading till the element intersects the viewport.
     *
     * We evaluate whether we instantly load the element for different reasons:
     * - we run in SSR mode
     * - there's no global strategy given
     * - the global loading strategy is set to INSTANT loading,
     *   and the loading strategy in the given is not set to DEFER
     * - the loading strategy in the given options is set to INSTANT
     */
    load(element: HTMLElement, options?: IntersectionOptions): Observable<boolean>;
    private shouldLoadInstantly;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeferLoaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DeferLoaderService>;
}

declare class OutletDirective<T = any> implements OnDestroy, OnChanges {
    private vcr;
    private templateRef;
    private outletService;
    private deferLoaderService;
    private outletRendererService;
    private renderedTemplate;
    renderedComponents: Map<OutletPosition, (ComponentRef<any> | EmbeddedViewRef<any>)[]>;
    cxOutlet: string;
    /**
     * Context data to be provided to child view of the outlet
     */
    cxOutletContext: T;
    /**
     * Observable with current outlet context
     */
    private readonly outletContext$;
    /**
     * Defers loading options for the the templates of this outlet.
     */
    cxOutletDefer: IntersectionOptions;
    loaded: EventEmitter<boolean>;
    cxComponentRef: ComponentRef<any> | EmbeddedViewRef<any>;
    cxComponentRefChange: EventEmitter<ComponentRef<any> | EmbeddedViewRef<any>>;
    subscription: Subscription;
    constructor(vcr: ViewContainerRef, templateRef: TemplateRef<any>, outletService: OutletService, deferLoaderService: DeferLoaderService, outletRendererService: OutletRendererService);
    /**
     * Renders view for outlet or defers it, depending on the input `cxOutletDefer`
     */
    render(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private deferLoading;
    /**
     * Renders view for outlet
     */
    private build;
    /**
     * Renders view in a given position for outlet
     */
    private buildOutlet;
    /**
     * Renders view based on the given template or component factory
     */
    private create;
    /**
     * Returns injector with OutletContextData that can be injected to the component
     * rendered in the outlet
     */
    private getComponentInjector;
    /**
     * Returns the closest `HtmlElement`, by iterating over the
     * parent nodes of the given element.
     *
     * We avoid traversing the parent _elements_, as this is blocking
     * ie11 implementations. One of the spare exclusions we make to not
     * supporting ie11.
     *
     * @param element
     */
    private getHostElement;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OutletDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OutletDirective<any>, "[cxOutlet]", never, { "cxOutlet": { "alias": "cxOutlet"; "required": false; }; "cxOutletContext": { "alias": "cxOutletContext"; "required": false; }; "cxOutletDefer": { "alias": "cxOutletDefer"; "required": false; }; "cxComponentRef": { "alias": "cxComponentRef"; "required": false; }; }, { "loaded": "loaded"; "cxComponentRefChange": "cxComponentRefChange"; }, never, never, true, never>;
}

declare class OutletModule {
    static forRoot(): ModuleWithProviders<OutletModule>;
    static forChild(): ModuleWithProviders<OutletModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OutletModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OutletModule, never, [typeof i1.CommonModule, typeof OutletDirective], [typeof OutletDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OutletModule>;
}

declare abstract class PWAModuleConfig {
    pwa?: {
        enabled?: boolean;
        addToHomeScreen?: boolean;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<PWAModuleConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PWAModuleConfig>;
}
declare const defaultPWAModuleConfig: PWAModuleConfig;
declare module '@spartacus/core' {
    interface Config extends PWAModuleConfig {
    }
}

declare class AddToHomeScreenService {
    protected config: PWAModuleConfig;
    protected globalMessageService: GlobalMessageService;
    protected winRef: WindowRef;
    protected deferredEvent: any;
    protected canPrompt: BehaviorSubject<boolean>;
    canPrompt$: Observable<boolean>;
    constructor(config: PWAModuleConfig, globalMessageService: GlobalMessageService, winRef: WindowRef);
    init(): void;
    enableAddToHomeScreen(): void;
    disableAddToHomeScreen(): void;
    firePrompt(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddToHomeScreenService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AddToHomeScreenService>;
}

declare abstract class AddToHomeScreenComponent implements OnInit {
    protected addToHomeScreenService: AddToHomeScreenService;
    canPrompt$: Observable<boolean>;
    constructor(addToHomeScreenService: AddToHomeScreenService);
    ngOnInit(): void;
    prompt(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddToHomeScreenComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AddToHomeScreenComponent, never, never, {}, {}, never, never, true, never>;
}

declare class AddToHomeScreenBtnComponent extends AddToHomeScreenComponent {
    protected addToHomeScreenService: AddToHomeScreenService;
    constructor(addToHomeScreenService: AddToHomeScreenService);
    static ɵfac: i0.ɵɵFactoryDeclaration<AddToHomeScreenBtnComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddToHomeScreenBtnComponent, "cx-add-to-home-screen-btn", never, {}, {}, never, ["*"], true, never>;
}

declare class AddToHomeScreenBannerComponent extends AddToHomeScreenComponent {
    protected addToHomeScreenService: AddToHomeScreenService;
    constructor(addToHomeScreenService: AddToHomeScreenService);
    static ɵfac: i0.ɵɵFactoryDeclaration<AddToHomeScreenBannerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddToHomeScreenBannerComponent, "cx-add-to-home-screen-banner", never, {}, {}, never, never, true, never>;
}

declare class PwaModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PwaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PwaModule, never, [typeof i1.CommonModule, typeof i2.ServiceWorkerModule, typeof i3.I18nModule, typeof AddToHomeScreenBtnComponent, typeof AddToHomeScreenBannerComponent], [typeof AddToHomeScreenBtnComponent, typeof AddToHomeScreenBannerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PwaModule>;
}

/**
 * Service responsible for resolving cms config based feature modules.
 */
declare class CmsFeaturesService {
    protected configInitializer: ConfigInitializerService;
    protected featureModules: FeatureModulesService;
    private featureModulesConfig?;
    private componentFeatureMap;
    private featureInstances;
    constructor(configInitializer: ConfigInitializerService, featureModules: FeatureModulesService);
    private initFeatureMap;
    /**
     * Check if there is feature module configuration that covers specified
     * component type
     */
    hasFeatureFor(componentType: string): boolean;
    /**
     * Return full CmsComponent mapping defined in feature module
     */
    getCmsMapping(componentType: string): Observable<CmsComponentMapping | undefined>;
    /**
     * Resolves feature module for provided component type
     *
     * @param componentType
     */
    getModule(componentType: string): NgModuleRef<any> | undefined;
    /**
     * Resolve feature based on feature name, if feature was not yet resolved
     *
     * It will first resolve all module dependencies if defined
     */
    private resolveFeatureInstance;
    /**
     * Create feature instance from feature's moduleRef
     */
    private createFeatureInstance;
    /**
     * Returns configuration provided in feature module
     */
    private resolveFeatureConfiguration;
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsFeaturesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CmsFeaturesService>;
}

/**
 * Service with logic related to resolving component from cms mapping
 */
declare class CmsComponentsService {
    protected config: CmsConfig;
    protected platformId: Object;
    protected featureModules: CmsFeaturesService;
    protected configInitializer: ConfigInitializerService;
    protected missingComponents: string[];
    protected mappings: {
        [componentType: string]: CmsComponentMapping;
    };
    protected staticCmsConfig: CMSComponentConfig | undefined;
    protected mappingResolvers: Map<string, Observable<CmsComponentMapping>>;
    protected logger: LoggerService;
    constructor(config: CmsConfig, platformId: Object, featureModules: CmsFeaturesService, configInitializer: ConfigInitializerService);
    /**
     * Should be called to make sure all component mappings are determined,
     * especially lazy loaded ones.
     *
     * It's recommended way to make sure all other methods of CmsComponentService
     * will be able to work synchronously for asked component types and avoid risk
     * of potential errors that could be thrown otherwise.
     */
    determineMappings(componentTypes: string[]): Observable<string[]>;
    private getFeatureMappingResolver;
    /**
     * Returns the feature module for a cms component.
     * It will only work for cms components provided by feature modules.
     *
     * @param componentType
     */
    getModule(componentType: string): NgModuleRef<any> | undefined;
    /**
     * Return collection of component mapping configuration for specified list of
     * component types.
     *
     * If component mapping can't be determined synchronously, for example, lazy
     * loaded one, it will throw an error.
     *
     * To make sure component mapping is available, determineMappings()
     * should be called and completed first.
     */
    getMapping(componentType: string): CmsComponentMapping;
    /**
     * Checks, if component should be rendered as some components
     * could be disabled for server side renderings
     */
    shouldRender(componentType: string): boolean;
    /**
     * Return DeferLoadingStrategy for component type.
     */
    getDeferLoadingStrategy(componentType: string): DeferLoadingStrategy | undefined;
    /**
     * Get cms driven child routes for components
     */
    getChildRoutes(componentTypes: string[]): CmsComponentChildRoutesConfig;
    /**
     * Returns the static data for the component type.
     */
    getStaticData<T extends CmsComponent = CmsComponent>(componentType: string): T | undefined;
    /**
     * Standardizes the format of `childRoutes` config.
     *
     * Some `childRoutes` configs are simple arrays of Routes (without the notion of the parent route).
     * But some configs can be an object with children routes and their parent defined in separate property.
     */
    protected standardizeChildRoutes(childRoutesConfigs: (Route[] | CmsComponentChildRoutesConfig)[]): CmsComponentChildRoutesConfig;
    /**
     * Get cms driven guards for components
     */
    getGuards(componentTypes: string[]): any[];
    /**
     * Get i18n keys associated with components
     */
    getI18nKeys(componentTypes: string[]): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsComponentsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CmsComponentsService>;
}

declare class PageSlotService {
    protected cmsComponentsService: CmsComponentsService;
    protected platformId: any;
    protected document: Document;
    protected prerenderedSlots: (string | null)[] | undefined;
    constructor(cmsComponentsService: CmsComponentsService, platformId: any, document: Document);
    /**
     * Finds all slots visible in the SSR pre-rendered DOM
     */
    protected resolvePrerenderedSlots(): void;
    /**
     * Indicates if certain slot should be rendered instantly.
     *
     * It's especially useful when transitioning from SSR to CSR application,
     * where we don't want to apply deferring logic to slots that are visible
     * to avoid unnecessary flickering.
     */
    shouldNotDefer(slot: string): boolean;
    /**
     * Returns the defer options for the given component. If the wrapping
     * page slot is prerendered, we would ignore the defer options altogether.
     */
    getComponentDeferOptions(slot: string | undefined, componentType: string): IntersectionOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageSlotService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PageSlotService>;
}

/**
 * Lifecycle events for the creation and removal of CMS components.
 *
 * Triggers when the component is added or removed from the DOM, using
 * sub event `ComponentCreateEvent` and `ComponentDestroyEvent`.
 */
declare abstract class ComponentEvent extends CxEvent {
    /**
     * The component type code.
     */
    typeCode: string;
    /**
     * The unique id for the component instance.
     */
    id: string;
}
/**
 * Indicates that the component is added to the DOM.
 */
declare class ComponentCreateEvent extends ComponentEvent {
    /**
     * Event's type
     */
    static readonly type = "ComponentCreate";
    /**
     * The component host element.
     */
    host: HTMLElement;
}
/**
 * Indicates that the component is removed from the DOM.
 */
declare class ComponentDestroyEvent extends ComponentEvent {
    /**
     * Event's type
     */
    static readonly type = "ComponentDestroy";
}

/**
 * Used to prepare injector for CMS components.
 *
 * Injector will take into account configured providers and provides CmsComponentData
 * for specified component's uid
 */
declare class CmsInjectorService {
    protected cmsComponentsService: CmsComponentsService;
    protected injector: Injector;
    constructor(cmsComponentsService: CmsComponentsService, injector: Injector);
    getInjector(type: string, uid: string, parentInjector?: Injector): Injector;
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsInjectorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CmsInjectorService>;
}

/**
 * ComponentHandler implementations can be used for instantiating and launching
 * different types of CMS mapped components
 */
declare abstract class ComponentHandler implements Applicable {
    /**
     * Returns component resource - an observable stream used to launch and dispose
     * component.
     *
     * Instantiate and launch component by subscribing to launcher.
     * Successful component launch will be followed by emission of ElementRef
     * (and in case of native Angular component, also ComponentRef).
     * Unsubscribing from the launcher will remove and tear down the component.
     *
     * @param componentMapping
     * @param viewContainerRef
     * @param elementInjector
     * @param module
     */
    abstract launcher(componentMapping: CmsComponentMapping, viewContainerRef: ViewContainerRef, elementInjector?: Injector, module?: NgModuleRef<any>): Observable<{
        elementRef: ElementRef;
        componentRef?: ComponentRef<any>;
    }>;
    abstract hasMatch(componentMapping: CmsComponentMapping): boolean;
    abstract getPriority?(): Priority;
}

/**
 * Responsible for obtaining component handler for specified component mapping
 */
declare class ComponentHandlerService {
    protected handlers: ComponentHandler[];
    protected logger: LoggerService;
    constructor(handlers: ComponentHandler[]);
    protected invalidMappings: Set<CmsComponentMapping<any>>;
    /**
     * Get best matching component handler
     *
     * @param componentMapping
     */
    protected resolve(componentMapping: CmsComponentMapping): ComponentHandler | undefined;
    /**
     * Get launcher for specified component mapping
     *
     * @param componentMapping
     * @param viewContainerRef
     * @param elementInjector
     */
    getLauncher(componentMapping: CmsComponentMapping, viewContainerRef: ViewContainerRef, elementInjector?: Injector, module?: NgModuleRef<any>): Observable<{
        elementRef: ElementRef;
        componentRef?: ComponentRef<any>;
    }> | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComponentHandlerService, [{ optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ComponentHandlerService>;
}

/**
 * Directive used to facilitate instantiation of CMS driven dynamic components
 */
declare class ComponentWrapperDirective implements OnInit, OnDestroy {
    protected vcr: ViewContainerRef;
    protected cmsComponentsService: CmsComponentsService;
    protected injector: Injector;
    protected dynamicAttributeService: DynamicAttributeService;
    protected renderer: Renderer2;
    protected componentHandler: ComponentHandlerService;
    protected cmsInjector: CmsInjectorService;
    protected eventService: EventService;
    cxComponentWrapper: ContentSlotComponentData;
    cxComponentRef: EventEmitter<ComponentRef<any>>;
    /**
     * This property in unsafe, i.e.
     * - cmpRef can be set later because of lazy loading or deferred loading
     * - cmpRef can be not set at all if for example, web components are used as cms components
     */
    protected cmpRef?: ComponentRef<any>;
    private launcherResource?;
    constructor(vcr: ViewContainerRef, cmsComponentsService: CmsComponentsService, injector: Injector, dynamicAttributeService: DynamicAttributeService, renderer: Renderer2, componentHandler: ComponentHandlerService, cmsInjector: CmsInjectorService, eventService: EventService);
    ngOnInit(): void;
    private launchComponent;
    /**
     * Dispatch the component event.
     *
     * The event is dispatched during creation and removal of the component.
     */
    protected dispatchEvent(event: Type<ComponentEvent>, elementRef?: ElementRef): void;
    private decorate;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComponentWrapperDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ComponentWrapperDirective, "[cxComponentWrapper]", never, { "cxComponentWrapper": { "alias": "cxComponentWrapper"; "required": false; }; }, { "cxComponentRef": "cxComponentRef"; }, never, never, true, never>;
}

declare abstract class CmsComponentData<T extends CmsComponent> {
    uid: string;
    data$: Observable<T>;
}

declare class InnerComponentsHostDirective implements OnInit, OnDestroy {
    protected data: CmsComponentData<CmsComponent>;
    protected vcr: ViewContainerRef;
    protected cmsComponentsService: CmsComponentsService;
    protected injector: Injector;
    protected dynamicAttributeService: DynamicAttributeService;
    protected renderer: Renderer2;
    protected componentHandler: ComponentHandlerService;
    protected cmsInjector: CmsInjectorService;
    protected eventService: EventService;
    protected innerComponents$: rxjs.Observable<string[]>;
    protected componentWrappers: any[];
    protected subscription?: Subscription;
    constructor(data: CmsComponentData<CmsComponent>, vcr: ViewContainerRef, cmsComponentsService: CmsComponentsService, injector: Injector, dynamicAttributeService: DynamicAttributeService, renderer: Renderer2, componentHandler: ComponentHandlerService, cmsInjector: CmsInjectorService, eventService: EventService);
    ngOnInit(): void;
    protected renderComponents(components: string[]): void;
    protected renderComponent(component: string): void;
    protected clearComponents(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InnerComponentsHostDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<InnerComponentsHostDirective, "[cxInnerComponentsHost]", never, {}, {}, never, never, true, never>;
}

declare class PageComponentModule {
    static forRoot(): ModuleWithProviders<PageComponentModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PageComponentModule, never, [typeof i1.CommonModule, typeof ComponentWrapperDirective, typeof InnerComponentsHostDirective], [typeof ComponentWrapperDirective, typeof InnerComponentsHostDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PageComponentModule>;
}

/**
 * The `PageSlotComponent` is used to render the CMS page slot and it's components.
 *
 * The Page slot host element will be supplemented with css classes so that the layout
 * can be fully controlled by customers:
 * - The page slot _position_ is added as a css class by default.
 * - The `cx-pending` is added for as long as the slot hasn't start loading.
 * - The `page-fold` style class is added for the page slot which is configured as the page fold.
 */
declare class PageSlotComponent implements OnInit, OnDestroy {
    protected cmsService: CmsService;
    protected dynamicAttributeService: DynamicAttributeService;
    protected renderer: Renderer2;
    protected elementRef: ElementRef;
    protected cd: ChangeDetectorRef;
    protected pageSlotService: PageSlotService;
    /**
     * The position represents the unique key for a page slot on a single page, but can
     * be reused cross pages.
     *
     * The position is used to find the CMS components for the page slot. It is also
     * added as an additional CSS class so that layout can be applied.
     */
    set position(value: string | undefined);
    get position(): string | undefined;
    /**
     * Maintains css classes introduced by the host and adds additional classes.
     */
    class: string;
    /**
     * Indicates that the page slot is the last page slot above the fold.
     */
    isPageFold: boolean;
    /**
     * Indicates that the components of the page slot haven't been loaded as long
     * as the isPending state is true.
     */
    isPending: boolean;
    /**
     * Indicates that the page slot doesn't contain any components. This is no
     * longer used in spartacus, but kept for backwards compatibility.
     */
    hasComponents: boolean;
    protected position$: BehaviorSubject<string | undefined>;
    components: ContentSlotComponentData[];
    protected slot$: Observable<ContentSlotData>;
    /** Observes the components for the given page slot. */
    components$: Observable<ContentSlotComponentData[]>;
    protected subscription: Subscription;
    /** Keeps track of the pending components that must be loaded for the page slot */
    private pendingComponentCount;
    /** Tracks the last used position, in case the page slot is used dynamically */
    private lastPosition;
    constructor(cmsService: CmsService, dynamicAttributeService: DynamicAttributeService, renderer: Renderer2, elementRef: ElementRef, cd: ChangeDetectorRef, pageSlotService: PageSlotService);
    ngOnInit(): void;
    protected decorate(slot: ContentSlotData): void;
    /**
     * Sets the pending count for the page slot components. Once all pending components are
     * loaded, the `isPending` flag is updated, so that the associated class can be updated
     */
    protected set pending(count: number);
    protected get pending(): number;
    isLoaded(loadState: boolean): void;
    /**
     * The `DeferLoadingStrategy` indicates whether the component should be
     * rendered instantly or whether it should be deferred.
     */
    getComponentDeferOptions(componentType: string): IntersectionOptions;
    protected isDistinct(old: ContentSlotData, current: ContentSlotData): boolean;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageSlotComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageSlotComponent, "cx-page-slot,[cx-page-slot]", never, { "position": { "alias": "position"; "required": false; }; "class": { "alias": "class"; "required": false; }; "isPageFold": { "alias": "isPageFold"; "required": false; }; "hasComponents": { "alias": "hasComponents"; "required": false; }; }, {}, never, never, true, never>;
}

declare class PageSlotModule {
    constructor(_pageSlot: PageSlotService);
    static ɵfac: i0.ɵɵFactoryDeclaration<PageSlotModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PageSlotModule, never, [typeof i1.CommonModule, typeof OutletModule, typeof PageComponentModule, typeof PageSlotComponent], [typeof PageSlotComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PageSlotModule>;
}

/**
 * The `BreakpointService` resolves the various screen sizes that are used in
 * the storefront. The screen sizes are globally configurable based on your
 * layout requirements. You can adjust the screen sizes by setting the minimum
 * and/or maximum size for a breakpoint, as well as extending the configuration
 * with new screens.
 *
 * By default, the `BreakpointService` is based on the breakpoints from the
 * Bootstrap ui library:
 * - `xs`: < 576px
 * - `sm`: 576px - 767px
 * - `md`: 768px - 991px
 * - `lg`: 992px - 1199px
 * - `xl`: >= 1200px
 */
declare class BreakpointService {
    protected winRef: WindowRef;
    protected layoutConfig: LayoutConfig;
    protected platform: any;
    private _breakpoints;
    breakpoint$: Observable<BREAKPOINT>;
    constructor(winRef: WindowRef, layoutConfig: LayoutConfig, platform: any);
    /**
     * Returns the breakpoints for the storefront layout.
     *
     * The breakpoints are driven by the `LayoutConfig.breakpoints` and sorted based on
     * the given screen size.
     */
    get breakpoints(): BREAKPOINT[];
    /**
     * Returns the _maximum_ size for the breakpoint, given by the `LayoutConfig.breakpoints`
     * configuration.
     */
    getSize(breakpoint: BREAKPOINT): number | null;
    /**
     * Indicates whether the current screen size is smaller than the maximum size of the
     * given breakpoint.
     *
     * If the given breakpoint is `BREAKPOINT.md`, the method returns `true` when the
     * window innerWidth is smaller than the configured size of `BREAKPOINT.md`.
     */
    isDown(breakpoint: BREAKPOINT): Observable<boolean>;
    /**
     * Indicates whether the current screen size is larger than the minimum size of the
     * given breakpoint.
     *
     * If the given breakpoint is `BREAKPOINT.md`, the method returns `true` when the
     * window innerWidth is larger than the configured size of `BREAKPOINT.sm`.
     */
    isUp(breakpoint: BREAKPOINT): Observable<boolean>;
    /**
     * Indicates whether the given breakpoint fits in the current screen size.
     */
    isEqual(breakpoint: BREAKPOINT): Observable<boolean>;
    /**
     * Returns the fallback breakpoint in case no breakpoint can be resolved. This is
     * typically the case when we're on SSR without an actual window.
     *
     * Returns the smallest screen size (mobile first).
     */
    protected get fallbackBreakpoint(): BREAKPOINT;
    /**
     * Resolves the breakpoints and sorts them according to the configured size.
     *
     * The sort order is by small to large screens.
     */
    protected resolveBreakpointsFromConfig(): BREAKPOINT[];
    /**
     * Returns the _maximum_ size for the breakpoint, given by the
     * `LayoutConfig.breakpoints` configuration. We will try to resolve the
     * max size form the current breakpoint, but if this is not available, we
     * resolve it form the next breakpoint
     */
    protected getMaxSize(breakpoint: BREAKPOINT): number | null;
    protected getMinSize(breakpoint: BREAKPOINT): number | null;
    /**
     * Returns a `BREAKPOINT` for the given window size.
     *
     * This method tries to match the closest breakpoint for the given
     * window size. We'll fallback to the `largest` size in case the window
     * is greater than the largest configurable breakpoint.
     *
     * The windowWidth should be smaller than the maximum size of any of the
     * screen sizes defined in the `LayoutConfig.breakpoints`.
     */
    protected getBreakpoint(windowWidth: number): BREAKPOINT;
    /**
     * Helper method to return the breakpoint configuration.
     */
    protected get config(): LayoutBreakPoints;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreakpointService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BreakpointService>;
}

declare const PAGE_LAYOUT_HANDLER: InjectionToken<PageLayoutHandler>;
interface PageLayoutHandler {
    handle(slots: Observable<string[]>, pageTemplate?: string, section?: string, breakpoint?: BREAKPOINT): Observable<string[]>;
}

declare class PageLayoutService implements OnDestroy {
    private cms;
    private config;
    private breakpointService;
    private unifiedInjector;
    protected handlers: PageLayoutHandler[];
    protected subscription: Subscription;
    protected logger: LoggerService;
    constructor(cms: CmsService, config: LayoutConfig, breakpointService: BreakpointService, unifiedInjector: UnifiedInjector);
    private warnLogMessages;
    private logSlots;
    getSlots(section?: string): Observable<string[]>;
    /**
     * Returns an observable with the last page slot above-the-fold
     * for the given pageTemplate / breakpoint.
     *
     * The page fold is configurable in the `LayoutConfig` for each page layout.
     */
    getPageFoldSlot(pageTemplate: string): Observable<string | undefined>;
    private resolveSlots;
    get page$(): Observable<Page>;
    get templateName$(): Observable<string>;
    /**
     * load slots from the layout configuration. The breakpoint is used
     * to load a specific configuration for the given breakpoint. If there's
     * no configuration available for the given breakpoint the default slot
     * configuration is returned.
     */
    protected getSlotConfig(templateUid: string, configAttribute: string, section?: string, breakpoint?: BREAKPOINT): SlotConfig | undefined;
    protected getSlotConfigForSection(templateUid: string, configAttribute: string, section?: string, breakpoint?: BREAKPOINT): SlotConfig | undefined;
    /**
     * Returns a list of slots for a breakpoint specific configuration
     * If there's no specific configuration for the breakpoint,
     * the closest available configuration will be returned.
     */
    protected getResponsiveSlotConfig(layoutSlotConfig: LayoutSlotConfig, configAttribute: string, breakpoint?: BREAKPOINT): SlotConfig;
    /**
     * In order to help developers, we print some detailed log information in
     * case there's no layout configuration available for the given page template
     * or section. Additionally, the slot positions are printed in the console
     * in a format that can be copied / paste to the configuration.
     */
    private logMissingLayoutConfig;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageLayoutService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PageLayoutService>;
}

declare class PageLayoutComponent {
    protected pageLayoutService: PageLayoutService;
    set section(value: string);
    readonly section$: BehaviorSubject<string | undefined>;
    readonly templateName$: Observable<string>;
    readonly layoutName$: Observable<string>;
    readonly slots$: Observable<string[]>;
    readonly pageFoldSlot$: Observable<string | undefined>;
    constructor(pageLayoutService: PageLayoutService);
    static ɵfac: i0.ɵɵFactoryDeclaration<PageLayoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageLayoutComponent, "cx-page-layout", never, { "section": { "alias": "section"; "required": false; }; }, {}, never, ["*"], true, never>;
}

/**
 * Directive that Adds a style class to the host element based on the cms page
 * template. The CMS page template is driven by the CMS structure, which is configurable
 * in the backend.
 *
 * The style class is added to the host element of the directive. The host element is resolved
 * from the `elementRef`, or, in case the directive is used in an `ng-template`, by the
 * `TemplateRef`.
 *
 * An example of the usage is given below:
 *
 * ```html
 * <cx-storefront class="LandingPageTemplate">
 *   <ng-template cxPageTemplateStyle>...</ng-template>
 * <cx-storefront>
 * ```
 *
 * The style class can also be provided by an input:
 *
 * ```html
 * <ng-template [cxPageTemplateStyle]="pageTemplateName">
 * ```
 *
 */
declare class PageTemplateDirective implements OnInit, OnDestroy {
    protected pageLayoutService: PageLayoutService;
    protected elementRef: ElementRef;
    protected templateRef: TemplateRef<HTMLElement>;
    protected cd: ChangeDetectorRef;
    /**
     * Indicates whether this component is driven by an input template or should
     * observe the CMS driven page layout template.
     */
    protected useTemplateFromInput: boolean;
    /**
     * Adds a style class to the host element based on the cms page template, unless
     * the class is given as an input.
     *
     * The host element is either the actual host, or the parent element in case this
     * is used inside an `ng-template`.
     */
    set setTemplate(template: string);
    protected subscription: Subscription;
    /**
     * Holds the current page template, so we can remove previous page templates
     * from the element classList.
     */
    protected currentTemplate: string;
    constructor(pageLayoutService: PageLayoutService, elementRef: ElementRef, templateRef: TemplateRef<HTMLElement>, cd: ChangeDetectorRef);
    ngOnInit(): void;
    /**
     * Adds the page template as a style class to the given element. If any
     * page template was added before, we clean it up.
     *
     * We'll not use hostBinding for the style class, as it will potential drop
     * an existing class name on the host. This is why we need to work with
     * the lower level change detection api.
     */
    protected addStyleClass(template: string, el?: HTMLElement): void;
    /**
     * Cleans up the class host binding, if a template class was assigned before.
     */
    protected clear(el?: HTMLElement): void;
    /**
     * Returns the host element (`HTMLElement`).
     *
     * If the directive is used on an `ng-template`, we take the parent element,
     * to ensure that we're not ending up with a comment.
     */
    protected get host(): HTMLElement;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageTemplateDirective, [null, null, { optional: true; }, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PageTemplateDirective, "[cxPageTemplateStyle]", never, { "setTemplate": { "alias": "cxPageTemplateStyle"; "required": false; }; }, {}, never, never, true, never>;
}

declare class PageLayoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PageLayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PageLayoutModule, never, [typeof i1.CommonModule, typeof OutletModule, typeof PageSlotModule, typeof PageLayoutComponent, typeof PageTemplateDirective], [typeof PageLayoutComponent, typeof PageTemplateDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PageLayoutModule>;
}

declare abstract class SeoConfig {
    seo?: SeoOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<SeoConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SeoConfig>;
}
interface SeoOptions {
    structuredData?: StructuredData;
}
interface StructuredData {
    disableInDevMode?: boolean;
}
declare module '@spartacus/core' {
    interface Config extends SeoConfig {
    }
}

declare const defaultSeoConfig: SeoConfig;

declare class JsonLdScriptFactory {
    protected platformId: string;
    protected winRef: WindowRef;
    protected rendererFactory: RendererFactory2;
    protected config: SeoConfig;
    protected renderer: Renderer2;
    constructor(platformId: string, winRef: WindowRef, rendererFactory: RendererFactory2, config: SeoConfig);
    build(schema: {}[]): void;
    /**
     * Indicates whether json ld data should be generated.
     *
     * This is only required on the server, but can be enabled in dev mode.
     */
    isJsonLdRequired(): boolean;
    /**
     * Creates a json-ld script element. The element is created one, and appended
     * to the html body element.
     *
     * ```html
     * <script id="json-ld" type="application/ld+json">
     * </script>
     * ```
     */
    protected getJsonLdScriptElement(): HTMLScriptElement;
    /**
     * Secure the given json-ld schema by encoding html characters (aka escaping), eg: <script> becomes &lt;script&gt;
     *
     * The given schema is not trusted, as malicious code could be injected (XSS)
     * into the json-ld script.
     */
    escapeHtml(schema: {}): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<JsonLdScriptFactory, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<JsonLdScriptFactory>;
}

/**
 * Low level directive that adds a json-ld script tag to the component.
 * This code bypasses the strict XSS security, as otherwise we're not able
 * to append a script tag with JS inside.
 *
 * This helper directive is actually not used in Spartacus, as Spartacus
 * appends json-ld the data to the document body.
 *
 * This directive can however be used by merchants to write static schema data
 * to the DOM in a save way.
 */
declare class JsonLdDirective {
    protected renderer: Renderer2;
    protected jsonLdScriptFactory: JsonLdScriptFactory;
    protected element: ElementRef;
    /**
     * Writes the schema data to a json-ld script element.
     */
    set cxJsonLd(schema: string | {});
    constructor(renderer: Renderer2, jsonLdScriptFactory: JsonLdScriptFactory, element: ElementRef);
    /**
     * attach the json-ld script tag to DOM with the schema data secured by encoding html tags (aka escaping)
     */
    protected generateJsonLdScript(schema: string | {}): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<JsonLdDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<JsonLdDirective, "[cxJsonLd]", never, { "cxJsonLd": { "alias": "cxJsonLd"; "required": false; }; }, {}, never, never, true, never>;
}

declare class StructuredDataModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<StructuredDataModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StructuredDataModule, never, [typeof i1.CommonModule, typeof JsonLdDirective], [typeof JsonLdDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StructuredDataModule>;
}

declare function initSeoService(injector: Injector): () => void;
declare class SeoModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SeoModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SeoModule, never, [typeof StructuredDataModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SeoModule>;
}

declare enum MOVE_FOCUS {
    NEXT = 1,
    PREV = -1
}
interface BaseFocusConfig {
}
interface VisibleFocusConfig {
    /**
     * When set to true, the `mouse-focus` class is added to the host element,
     * indicating that the element focus should not be made visible.
     */
    disableMouseFocus?: boolean;
}
interface BlockFocusConfig extends VisibleFocusConfig {
    block?: boolean;
}
interface PersistFocusConfig extends BlockFocusConfig {
    /**
     * A key to maintain the focus of an element in case the component is
     * recreated (which often is the case when an `*ngIf` or `*ngFor` is used).
     */
    key?: string;
    /**
     * Optional group identifier that can be used to persist the focus. This allows
     * to have separate persisted focus available when the DOM is partially rebuild.
     */
    group?: string;
    /**
     * Optional CSS selector used to delegate the persisted focus to a descendant
     * of the host element. This is useful when the host is a wrapper component
     * (e.g. `<ng-select>`) and the actual interactive element lives inside it
     * (e.g. `[role="combobox"]`). When the selector matches a descendant, that
     * element receives focus instead of the host. Falls back to the host when
     * no match is found.
     */
    focusTargetSelector?: string;
    /**
     * When `true`, the persisted focus key is cleared after focus has been
     * restored on `ngAfterViewInit`. This prevents the persisted state from
     * leaking across page navigations when the focus restoration would not
     * otherwise re-trigger a `focus` event on the host (for example, when
     * `focusTargetSelector` delegates focus to a descendant).
     */
    clearOnRestore?: boolean;
}
interface EscapeFocusConfig extends PersistFocusConfig {
    focusOnEscape?: boolean;
    /**
     * Force an autofocus in case of double-escape
     */
    focusOnDoubleEscape?: boolean;
}
interface AutoFocusConfig extends EscapeFocusConfig {
    /**
     * Autofocus is enabled by default, and will try to focus an _autofocus_ element.
     * In case the focus is explicitly set to `true`, the first accessible element
     * is focussed in case there is no _autofocus_ element found.
     * If the focus is set to false, autofocus will be disabled completely.
     *
     * If a string value is given, the autofocus will be restored based on the persisted
     * focus group, which is driven by `PersistFocusConfig.key` and `PersistFocusConfig.group`.
     *
     * Defaults to `true`.
     */
    autofocus?: boolean | string;
    /**
     * whenever the focus should be applied based on a specific trigger, you can user
     * the refreshFocus property. This property can be dynamically applied so that the refresh
     * only happens on specific occasions.
     *
     * The refreshFocus token doesn't have a specific format, it acts as a meaning less token that
     * will effect the ngOnChange lifecycle hook of the auto focus logic. Any truthy value will
     * autofocus the element dynamically.
     */
    refreshFocus?: unknown;
}
interface TabFocusConfig extends AutoFocusConfig {
    tab?: boolean | 'scroll' | string;
}
declare enum TrapFocus {
    /**
     * Will trap the focus at the start of the focus group.
     */
    start = "start",
    /**
     * Will trap the focus only at the end of the focus group.
     */
    end = "end",
    /**
     * Will not trap the focus in both directions. This is actually not are
     * a great example of focus trap, but it will give the benefit of keyboard
     * tabbing by arrows. Should only be used with `TrapFocusConfig.trap` and not with `TrapFocusConfig.trapTabOnly`
     */
    both = "both"
}
type TrapFocusType = boolean | TrapFocus.start | TrapFocus.end | TrapFocus.both;
/**
 * The keyboard navigation (tab, shift-tab and up down keys) is _trapped_
 * for the nested focusable elements. This means that the focus can not
 * "leave" the elements. If the last element is focused, the keyboard will
 * navigate to the first element and visa versa.
 *
 * Options:
 * - Use the `trap` property to enable trapping for both Tab/Shift+Tab and Arrow Up/Down keys.
 * - Use the `trapTabOnly` property to trap only Tab/Shift+Tab, preserving the default behavior of the Arrow Up/Down keys.
 */
interface TrapFocusConfig extends TabFocusConfig {
    /** traps the focus for both tab/shift+tab and up/down keys */
    trap?: TrapFocusType;
    /** traps the focus for tab/shift+tab */
    trapTabOnly?: TrapFocusType;
}
interface LockFocusConfig extends TrapFocusConfig {
    /**
     * Indicates that the nested DOM is locked for keyboarding (`TAB`).
     */
    lock?: boolean;
}
interface FocusConfig extends LockFocusConfig {
}

declare abstract class BaseFocusService {
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseFocusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BaseFocusService>;
}

/**
 * Abstract directive that provides a common interface for all focus directives:
 * - Block Focus
 * - Persist Focus
 * - Escape Focus
 * - Auto Focus
 * - Tab Focus
 * - Trap Focus
 * - Lock Focus
 */
declare abstract class BaseFocusDirective implements OnInit, OnChanges {
    protected elementRef: ElementRef<HTMLElement>;
    protected service: BaseFocusService;
    /**
     * Optional configuration for the focus directive drives the behaviour of the keyboard
     * focus directive.
     */
    protected config: BaseFocusConfig;
    /**
     * A default config can be provided for each directive if a specific focus directive
     * is used directly. i.e. `<div cxAutoFocus></div>`
     */
    protected defaultConfig: BaseFocusConfig;
    tabindex: number;
    constructor(elementRef: ElementRef<HTMLElement>, service: BaseFocusService);
    ngOnInit(): void;
    ngOnChanges(_changes: SimpleChanges): void;
    /**
     * Override the (input) config if it undefined or an empty string, with the
     * `defaultConfig`. The `defaultConfig` might be specified for each directive
     * differently. If a specific directive is used (i.e. `cxAutoFocus`), the
     * specific (inherited) defaultConfig will be used.
     */
    protected setDefaultConfiguration(): void;
    /**
     * Helper method to return the host element for the directive
     * given by the `elementRef`.
     */
    protected get host(): HTMLElement;
    /**
     * Force a tabindex on the host element if it is _required_ to make the element
     * focusable. If the element is focusable by nature or by a given tabindex, the
     * `tabindex` is not applied.
     *
     * Buttons, active links, etc. do no need an explicit tabindex to receive focus.
     */
    protected set requiredTabindex(tabindex: number);
    /**
     * Returns true if the host element does not have a tabindex defined
     * and it also doesn't get focus by browsers nature (i.e. button or
     * active link).
     */
    protected get requiresExplicitTabIndex(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseFocusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseFocusDirective, never, never, { "tabindex": { "alias": "tabindex"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Directive implementation that adds a CSS class to the host element
 * when the moused is used to focus an element. As soon as the keyboard
 * is used, the class is removed.
 *
 * This feature must be explicitly enabled with the `disableMouseFocus` config.
 *
 * The appearance of the visual focus depends on the CSS implementation to
 * begin with. Spartacus styles add a blue border around each focusable element.
 * This can be considered annoying by keyboard users, as they won't need such a
 * strong indication of the selected element.
 */
declare class VisibleFocusDirective extends BaseFocusDirective {
    protected defaultConfig: VisibleFocusConfig;
    private featureConfigService;
    protected config: VisibleFocusConfig;
    /** Controls a css class to hide focus visible CSS rules */
    mouseFocus: boolean;
    handleMousedown(): void;
    handleKeydown(event: KeyboardEvent): void;
    /**
     * Indicates whether the configurations setup to disable visual focus.
     */
    protected get shouldFocusVisible(): boolean | undefined;
    /**
     * Indicates whether the event is used to navigate the storefront. Some keyboard events
     * are used by mouse users to fill a form or interact with the OS or browser.
     */
    protected isNavigating(event: KeyboardEvent): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<VisibleFocusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<VisibleFocusDirective, never, never, {}, {}, never, never, true, never>;
}

declare class BlockFocusDirective extends VisibleFocusDirective implements OnInit {
    protected elementRef: ElementRef;
    protected service: BaseFocusService;
    protected defaultConfig: BlockFocusConfig;
    protected config: BlockFocusConfig;
    constructor(elementRef: ElementRef, service: BaseFocusService);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BlockFocusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BlockFocusDirective, never, never, {}, {}, never, never, true, never>;
}

/**
 * Shared service to persist the focus for an element or a group
 * of elements. The persisted element focus can be used to persist
 * the focus for a DOM tree, so that the focus remains after a repaint
 * or reoccurs when a DOM tree is "unlocked".
 */
declare class PersistFocusService extends BaseFocusService {
    protected focus: Map<string, string>;
    get(group?: string | null): string | undefined;
    /**
     * Persist the keyboard focus state for the given key. The focus is stored globally
     * or for the given group.
     */
    set(key: string | undefined, group?: string | null): void;
    /**
     * Clears the persisted keyboard focus state globally or for the given group.
     */
    clear(group?: string): void;
    /**
     * Returns the group for the host element based on the configured group or
     * by the `data-cx-focus-group` attribute stored on the host.
     */
    getPersistenceGroup(host: HTMLElement | undefined | null, config?: PersistFocusConfig): string | null | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<PersistFocusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PersistFocusService>;
}

/**
 * Directive that provides persistence of the focused state. This is useful
 * when a group of focusable elements got refocused or even recreated. That
 * happens often when the DOM is constructed with an `*ngIf` or `*ngFor`.
 *
 * The focus state is based on a configured _key_, which can be passed in the
 * config input, either by using a string primitive or `PersistFocusConfig.key`:
 *
 * ```html
 * <button cxPersistFocus="myKey"></button>
 * <button cxFocus="myKey"></button>
 * <button [cxFocus]="{{key:'myKey'}"></button>
 * ```
 *
 * The focus state can be part of a focus _group_, so that the state is shared
 * and remember for the given group. In order to detect the persistence for a
 * given element, we store the persistence key as a data attribute (`data-cx-focus`):
 *
 * ```html
 * <button data-cx-focus="myKey"></button>
 * ```
 *
 * Other keyboard focus directives can read the key to understand whether the element
 * should retrieve focus.
 *
 */
declare class PersistFocusDirective extends BlockFocusDirective implements OnInit, AfterViewInit {
    protected elementRef: ElementRef;
    protected service: PersistFocusService;
    protected defaultConfig: PersistFocusConfig;
    private persistFeatureConfigService;
    /**
     * The persistence key can be passed directly or through the `FocusConfig.key`.
     * While this could be considered a global key, the likeliness of conflicts
     * is very small since the key is cleared when the focus is changed.
     */
    protected config: PersistFocusConfig;
    /**
     * The persistence key is maintained in an element attribute for other
     * implementations. This is needed to ensure that we can resolve the focus
     * state in case of a repaint.
     */
    attr: string | undefined;
    handleFocus(event?: FocusEvent): void;
    constructor(elementRef: ElementRef, service: PersistFocusService);
    ngOnInit(): void;
    protected setDefaultConfiguration(): void;
    /**
     * Focus the element explicitly if it was focused before.
     *
     * When `PersistFocusConfig.focusTargetSelector` is provided and matches a
     * descendant of the host, that descendant receives focus instead of the
     * host. This supports wrapper components (e.g. `<ng-select>`) where the
     * actual interactive element lives inside the host.
     *
     * When `PersistFocusConfig.clearOnRestore` is `true`, the persisted key is
     * cleared after restoration so the state cannot leak to a fresh instance of
     * the same key on a different route.
     */
    ngAfterViewInit(): void;
    protected get focusTarget(): HTMLElement;
    protected get isPersisted(): boolean;
    /**
     * Returns the key for the host element, which is used to persist the
     * focus state. This is useful in cases where the DOM is rebuild.
     */
    protected get key(): string | undefined;
    /**
     * returns the persistence group (if any) for the focusable elements.
     */
    protected get group(): string | null | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<PersistFocusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PersistFocusDirective, never, never, {}, {}, never, never, true, never>;
}

declare class SelectFocusUtility {
    /**
     * Query selectors used to query focusable child elements of the host element.
     * The selectors are supplemented with `:not([disabled])` and `:not([hidden])`.
     */
    protected focusableSelectors: string[];
    protected focusableSelectorSuffix: string;
    query(host: HTMLElement | null | undefined, selector: string): HTMLElement[];
    findFirstFocusable(host: HTMLElement | null | undefined, config?: AutoFocusConfig): HTMLElement | undefined;
    /**
     * returns all focusable child elements of the host element. The element selectors
     * are build from the `focusableSelectors`.
     *
     * @param host the `HTMLElement` used to query focusable elements
     * @param locked indicates whether inactive (`tabindex="-1"`) focusable elements should be returned
     * @param invisible indicates whether hidden focusable elements should be returned
     */
    findFocusable(host: HTMLElement | null | undefined, locked?: boolean, invisible?: boolean): HTMLElement[];
    /**
     * Indicates whether the element is hidden by CSS. There are various CSS rules and
     * HTML structures which can lead to an hidden or invisible element. An `offsetParent`
     * of null indicates that the element or any of it's decendants is hidden (`display:none`).
     *
     * Oother techniques use the visibility (`visibility: hidden`), opacity (`opacity`) or
     * phyisical location on the element itself or any of it's anchestor elements. Those
     * technique require to work with the _computed styles_, which will cause a performance
     * downgrade. We don't do this in the standard implementaton.
     */
    protected isHidden(el: HTMLElement): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectFocusUtility, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SelectFocusUtility>;
}

declare class EscapeFocusService extends PersistFocusService {
    protected selectFocusUtil: SelectFocusUtility;
    constructor(selectFocusUtil: SelectFocusUtility);
    shouldFocus(config: EscapeFocusConfig): boolean;
    handleEscape(host: HTMLElement, config: EscapeFocusConfig, event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EscapeFocusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EscapeFocusService>;
}

/**
 * Directive to focus the host element whenever the `escape` key is captured.
 * UiEvents bubble up by nature, which is why the `cxEscGroup` can be used
 * on a tree of elements. Each time the escape key is used, the focus will
 * move up in the DOM tree.
 *
 */
declare class EscapeFocusDirective extends PersistFocusDirective implements OnInit {
    protected elementRef: ElementRef;
    protected service: EscapeFocusService;
    protected defaultConfig: EscapeFocusConfig;
    protected config: EscapeFocusConfig;
    esc: EventEmitter<boolean>;
    /**
     * Handles the escape key event.
     * @param event the native keyboard event which contains the escape keydown event
     */
    handleEscape(event: KeyboardEvent): void;
    constructor(elementRef: ElementRef, service: EscapeFocusService);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EscapeFocusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EscapeFocusDirective, never, never, {}, { "esc": "esc"; }, never, never, true, never>;
}

declare class AutoFocusService extends EscapeFocusService {
    /**
     * Returns the first focusable child element of the host element.
     */
    findFirstFocusable(host: HTMLElement | null | undefined, config?: AutoFocusConfig): HTMLElement | undefined | null;
    /**
     * Indicates whether any of the focusable child elements is focused.
     */
    hasPersistedFocus(host: HTMLElement | null | undefined, config: PersistFocusConfig): boolean;
    /**
     * Returns the element that has a persisted focus state.
     *
     * @param host the `HTMLElement` used to query for focusable children
     * @param group the optional group for the persistent state, to separate different focus
     *   groups and remain the persistence
     */
    protected getPersisted(host?: HTMLElement | null, group?: string | null): HTMLElement | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<AutoFocusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AutoFocusService>;
}

/**
 * Directive that focus the first nested _focusable_ element based on state and configuration:
 *
 * 1. focusable element that was left in a focused state (aka _persisted_ focus)
 * 2. focusable element selected by configured CSS selector (i.e. 'button[type=submit]')
 * 3. focusable element marked with the native HTML5 `autofocus` attribute
 * 4. first focusable element
 * 5. the host element, in case the configured CSS selector is `:host`.
 *
 * Example configurations:
 *
 * `<div cxAutoFocus>[...]</div>`
 *
 * `<div [cxAutoFocus]="{autofocus: false}">[...]</div>`
 *
 * `<div [cxAutoFocus]="{autofocus: 'button.active'}">[...]</div>`
 *
 * `<div [cxAutoFocus]="{autofocus: ':host'}">[...]</div>`
 *
 * When your element is added dynamically (ie. by using an *ngIf or after a DOM change), the
 * focus can be refreshed by using the refreshFocus configuration.
 */
declare class AutoFocusDirective extends EscapeFocusDirective implements AfterViewInit, OnChanges {
    protected elementRef: ElementRef;
    protected service: AutoFocusService;
    /** The AutoFocusDirective will be using autofocus by default  */
    protected defaultConfig: AutoFocusConfig;
    protected config: AutoFocusConfig;
    constructor(elementRef: ElementRef, service: AutoFocusService);
    /**
     * Focus the element explicitly if it was focussed before.
     */
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Mimic the focus without setting the actual focus on the host. The first
     * focusable child element will be focussed.
     */
    handleFocus(event?: FocusEvent): void;
    /**
     * Helper function to get the first focusable child element
     */
    protected get hasPersistedFocus(): boolean;
    /**
     * Helper function to indicate whether we should use autofocus for the
     * child elements.
     */
    protected get shouldAutofocus(): boolean;
    /**
     * Helper function to get the first focusable child element.
     *
     * We keep this private to not pollute the API.
     */
    private get firstFocusable();
    static ɵfac: i0.ɵɵFactoryDeclaration<AutoFocusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AutoFocusDirective, never, never, {}, {}, never, never, true, never>;
}

declare class TabFocusService extends AutoFocusService {
    /**
     * Moves to the next (or previous) tab.
     */
    moveTab(host: HTMLElement, config: TabFocusConfig, increment: MOVE_FOCUS, event: KeyboardEvent): void;
    /**
     * builds out virtual slides out of the full scrollable area, to allow
     * for maximum flexibility for the underlying layout without using hardcoded
     * slide sizes.
     */
    protected findNextScrollable(host: HTMLElement, config: TabFocusConfig, increment: MOVE_FOCUS): HTMLElement | undefined;
    protected findNext(host: HTMLElement, config: TabFocusConfig, increment: MOVE_FOCUS): HTMLElement | undefined;
    /**
     * Returns the active focusable child element. If there's no active
     * focusable child element, the first focusable child is returned.
     */
    protected getActiveChild(host: HTMLElement, config: TabFocusConfig): HTMLElement;
    protected getChildren(host: HTMLElement, config: TabFocusConfig): HTMLElement[];
    /**
     * Returns all focusable child elements of the host element.
     *
     * @param host The host element is used to query child focusable elements.
     * @param locked Indicates if locked elements (tabindex=-1) should be returned, defaults to false.
     * @param invisible Indicates if invisible child elements should be returned, defaults to false.
     */
    findFocusable(host: HTMLElement, locked?: boolean, invisible?: boolean): HTMLElement[];
    protected isActive(el: HTMLElement): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabFocusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TabFocusService>;
}

/**
 * Directive to move the focus of ("locked") child elements. This is useful
 * for a nested list of tabs, carousel slides or any group of elements that
 * requires horizontal navigation.
 */
declare class TabFocusDirective extends AutoFocusDirective {
    protected elementRef: ElementRef;
    protected service: TabFocusService;
    /** `tab` defaults to true if the directive `cxTabFocus` is used. */
    protected defaultConfig: TabFocusConfig;
    protected config: TabFocusConfig;
    handleNextTab(event: KeyboardEvent): void;
    handlePreviousTab(event: KeyboardEvent): void;
    constructor(elementRef: ElementRef, service: TabFocusService);
    static ɵfac: i0.ɵɵFactoryDeclaration<TabFocusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TabFocusDirective, never, never, {}, {}, never, never, true, never>;
}

declare class TrapFocusService extends TabFocusService {
    /**
     * Indicates whether any of the child elements of the host are focusable.
     *
     * @param host `HTMLElement` that is used to query the focusable elements.
     */
    hasFocusableChildren(host: HTMLElement): boolean;
    /**
     * Focus the next or previous element of all available focusable elements.
     * The focus is _trapped_ in case there's no next or previous available element.
     * The focus will automatically move the start or end of the list.
     */
    moveFocus(host: HTMLElement, config: TrapFocusConfig, increment: MOVE_FOCUS, event: UIEvent): void;
    protected getTrapStart(trap: TrapFocusType | undefined): boolean;
    protected getTrapEnd(trap: TrapFocusType | undefined): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<TrapFocusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TrapFocusService>;
}

/**
 * Directive that keeps the focus inside the focusable child elements,
 * also known as a _focus trap_.
 */
declare class TrapFocusDirective extends TabFocusDirective implements OnInit {
    protected elementRef: ElementRef;
    protected service: TrapFocusService;
    protected defaultConfig: TrapFocusConfig;
    protected config: TrapFocusConfig;
    handleTrapDown: (event: KeyboardEvent) => void;
    handleTrapUp: (event: KeyboardEvent) => void;
    constructor(elementRef: ElementRef, service: TrapFocusService);
    /**
     * Moves the focus of the element reference up or down, depending on the increment.
     * The focus of the element is trapped to avoid it from going out of the group.
     *
     * @param event UIEvent that is used to get the target element. The event is blocked
     *   from standard execution and further bubbling.
     * @param increment indicates whether the next or previous is focussed.
     */
    protected moveFocus(event: UIEvent, increment: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TrapFocusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TrapFocusDirective, never, never, {}, {}, never, never, true, never>;
}

declare class LockFocusService extends TrapFocusService {
    static ɵfac: i0.ɵɵFactoryDeclaration<LockFocusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LockFocusService>;
}

/**
 * Directive that adds persistence for focussed element in case
 * the elements are being rebuild. This happens often when change
 * detection kicks in because of new data set from the backend.
 */
declare class LockFocusDirective extends TrapFocusDirective implements OnInit, AfterViewInit {
    protected elementRef: ElementRef;
    protected service: LockFocusService;
    protected renderer: Renderer2;
    protected defaultConfig: LockFocusConfig;
    protected config: LockFocusConfig;
    /**
     * Indicates that the host is configured to use locking. This is available as a
     * CSS class `focus-lock`.
     */
    shouldLock: boolean | undefined;
    /**
     * Indicates that the host is locked. This is available as a CSS class `is-locked`.
     */
    isLocked: boolean;
    /**
     * Emits an event when the host is unlocked.
     */
    unlock: EventEmitter<boolean>;
    /**
     * When the user selects enter or space, the focusable childs are
     * unlocked, which means that the tabindex is set to 0.
     */
    handleEnter(event: KeyboardEvent): void;
    /**
     * In case any of the children elements is touched by the mouse,
     * we unlock the group to not break the mouse-experience.
     */
    handleClick(event: UIEvent): void;
    constructor(elementRef: ElementRef, service: LockFocusService, renderer: Renderer2);
    protected lockFocus(): void;
    protected unlockFocus(event?: UIEvent): void;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    handleFocus(event?: FocusEvent): void;
    handleEscape(event: KeyboardEvent): void;
    /**
     * When the handleFocus is called without an actual event, it's coming from Autofocus.
     * In this case we unlock the focusable children in case there's a focusable child that
     * was unlocked before.
     *
     * We keep this private to not polute the API.
     */
    private shouldUnlockAfterAutofocus;
    /**
     * Add the tabindex attribute to the focusable children elements
     */
    protected addTabindexToChildren(i?: number): void;
    /**
     * Utility method, returns all focusable children for the host element.
     *
     * We keep this private to not polute the API.
     */
    private get hasFocusableChildren();
    /**
     * Returns the focusable children of the host element. If the host element
     * is configured to be locked, the query is restricted to child elements
     * with a tabindex !== `-1`.
     *
     * We keep this private to not polute the API.
     */
    private get focusable();
    static ɵfac: i0.ɵɵFactoryDeclaration<LockFocusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<LockFocusDirective, never, never, {}, { "unlock": "unlock"; }, never, never, true, never>;
}

declare class KeyboardFocusService extends LockFocusService {
    static ɵfac: i0.ɵɵFactoryDeclaration<KeyboardFocusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<KeyboardFocusService>;
}

declare class FocusDirective extends LockFocusDirective {
    protected elementRef: ElementRef;
    protected service: KeyboardFocusService;
    protected renderer: Renderer2;
    protected defaultConfig: FocusConfig;
    config: FocusConfig;
    constructor(elementRef: ElementRef, service: KeyboardFocusService, renderer: Renderer2);
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FocusDirective, "[cxFocus]", never, { "config": { "alias": "cxFocus"; "required": false; }; }, {}, never, never, true, never>;
}

interface SkipFocusConfig {
    isEnabled: boolean;
    /**
     * elements selectors that should not be skipped
     * for ex `activeElementSelectors: ['button.cx-hamburger']`
     */
    activeElementSelectors?: string[];
}
/**
 * Directive that removes all visible and focusable elements
 * in a host container from `tab` or `shift-tab` navigation
 * except elements in `activeElementSelectors` config.
 */
declare class SkipFocusDirective implements OnChanges {
    config: SkipFocusConfig;
    protected elementRef: ElementRef<any>;
    protected winRef: WindowRef;
    protected renderer: Renderer2;
    ngOnChanges(): void;
    protected excludeFromFocus(isEnabled: boolean, skipSelectors?: string[]): void;
    protected isElementVisible(element: HTMLElement): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SkipFocusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SkipFocusDirective, "[cxSkipFocus]", never, { "config": { "alias": "cxSkipFocus"; "required": false; }; }, {}, never, never, true, never>;
}

declare class KeyboardFocusModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<KeyboardFocusModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<KeyboardFocusModule, never, [typeof i1.CommonModule, typeof FocusDirective, typeof SkipFocusDirective], [typeof FocusDirective, typeof SkipFocusDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<KeyboardFocusModule>;
}

declare abstract class SkipLinkConfig {
    skipLinks?: SkipLink[];
    static ɵfac: i0.ɵɵFactoryDeclaration<SkipLinkConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SkipLinkConfig>;
}
declare abstract class SkipLink {
    key: string;
    i18nKey: string;
    target?: HTMLElement;
    position?: SkipLinkScrollPosition;
}
declare enum SkipLinkScrollPosition {
    BEFORE = "BEFORE",
    AFTER = "AFTER"
}
declare module '@spartacus/core' {
    interface Config extends SkipLinkConfig {
    }
}

declare class SkipLinkService {
    protected config: SkipLinkConfig;
    protected keyboardFocusService: KeyboardFocusService;
    private skipLinks$;
    constructor(config: SkipLinkConfig, keyboardFocusService: KeyboardFocusService);
    getSkipLinks(): Observable<SkipLink[]>;
    add(key: string, target: HTMLElement): void;
    remove(key: string): void;
    scrollToTarget(scrollTo: string | SkipLink): void;
    protected findSkipLinkByKey(key: string): SkipLink | undefined;
    protected getSkipLinkIndexInArray(key: string): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<SkipLinkService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SkipLinkService>;
}

declare class SkipLinkComponent {
    private skipLinkService;
    skipLinks$: Observable<SkipLink[]>;
    constructor(skipLinkService: SkipLinkService);
    scrollToTarget(skipLink: SkipLink): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SkipLinkComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SkipLinkComponent, "cx-skip-link", never, {}, {}, never, never, true, never>;
}

declare class SkipLinkDirective implements OnInit, OnDestroy {
    protected elementRef: ElementRef<HTMLElement>;
    protected skipLinkService: SkipLinkService;
    cxSkipLink: string;
    constructor(elementRef: ElementRef<HTMLElement>, skipLinkService: SkipLinkService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SkipLinkDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SkipLinkDirective, "[cxSkipLink]", never, { "cxSkipLink": { "alias": "cxSkipLink"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SkipLinkModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SkipLinkModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SkipLinkModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof i3.ConfigModule, typeof KeyboardFocusModule, typeof SkipLinkComponent, typeof SkipLinkDirective], [typeof SkipLinkDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SkipLinkModule>;
}

/**
 * The `DirectionService` can be used to add the direction to the overall storefront or individual elements.
 * By default, the direction is added to the `html` element (i.e. `<html dir="ltr">`). The API of this service
 * does however provide methods to add direction to individual elements if needed.
 *
 * The direction is configurable and allows for language driven direction configuration.
 *
 * To react to the active language, the service subscribes to the active language in the initialize method. This
 * is called from an APP_INITIALIZER method and should only happen once.
 */
declare class DirectionService implements OnDestroy {
    protected configInit: ConfigInitializerService;
    protected languageService: LanguageService;
    protected winRef: WindowRef;
    protected config: Direction | undefined;
    protected startsDetecting: boolean;
    protected subscription: Subscription;
    constructor(configInit: ConfigInitializerService, languageService: LanguageService, winRef: WindowRef);
    /**
     * Initializes the layout direction for the storefront.
     */
    initialize(): Promise<any>;
    /**
     * Observes the _active_ language and set the required direction for the given language.
     * The method is guarded to ensure that the active language is observed only once.
     */
    protected detect(): void;
    /**
     * Sets the direction attribute for the given element. If the direction is undefined, the `dir`
     * attribute is removed.
     */
    setDirection(el: HTMLElement, direction: DirectionMode | undefined): void;
    /**
     * Gets the `DirectionMode` for the given language isoCode. The language isoCode is compared
     * to the configured list of languages(`direction.rtlLanguages` vs `direction.ltrLanguages`).
     *
     * If no language is given, or no language mapping could be found, we fallback to the default
     * `direction.mode`.
     */
    getDirection(language?: string): DirectionMode | undefined;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DirectionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DirectionService>;
}

/**
 * Provides a configuration and APP_INITIALIZER to add the correct (language drive) html direction.
 */
declare class DirectionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DirectionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DirectionModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DirectionModule>;
}

declare class ThemeService implements OnDestroy {
    protected config: SiteContextConfig;
    protected rendererFactory: RendererFactory2;
    protected siteThemeService: SiteThemeService;
    protected rootComponent: ComponentRef<any>;
    protected renderer: Renderer2;
    protected existingTheme: string;
    constructor(config: SiteContextConfig, rendererFactory: RendererFactory2);
    protected subscription: Subscription;
    /**
     * This function is to be called for the root component that is
     * bootstrapped.
     */
    init(rootComponent: ComponentRef<any>): void;
    ngOnDestroy(): void;
    setTheme(theme: string | undefined): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ThemeService>;
}

declare class ThemeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ThemeModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ThemeModule>;
}

declare class LayoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LayoutModule, never, [typeof OutletRefModule, typeof LaunchDialogModule, typeof DirectionModule, typeof ThemeModule], [typeof OutletRefModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LayoutModule>;
}

declare class CmsRouteModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsRouteModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CmsRouteModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CmsRouteModule>;
}

declare class RoutingModule {
    static forRoot(): ModuleWithProviders<RoutingModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RoutingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RoutingModule, never, [typeof i3.RoutingModule, typeof CmsRouteModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RoutingModule>;
}

declare class CmsLcpModule {
    static forRoot(): {
        ngModule: typeof CmsLcpModule;
        providers: i0.ValueProvider[];
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsLcpModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CmsLcpModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CmsLcpModule>;
}

/**
 * Tells whether the component contains LCP (Largest Contentful Paint) element.
 */
declare enum LcpPresence {
    HAS_LCP = "HAS_LCP",
    NO_LCP = "NO_LCP"
}

/**
 * Configuration for recognizing which CMS components are containing
 * the LCP (Largest Contentful Paint) element.
 */
declare abstract class LcpCmsComponentsConfig {
    /**
     * Configuration telling which CMS components contain the LCP (Largest Contentful Paint) element.
     * Thanks to this context, Spartacus can optimize the loading of those components (for example
     * by prioritizing the loading of their main image).
     *
     * If you need more advanced logic to determine whether a CMS component contains
     * the LCP element, you can extend the `CmsLcpService`.
     */
    lcpCmsComponents?: {
        /**
         * If a CMS component ID includes this substring, Spartacus treats it as containing
         * the LCP (Largest Contentful Paint) element. You can append this substring
         * to certain CMS component IDs in your CMS data, so Spartacus will automatically
         * recognize them as containing the LCP element.
         *
         * For example, with a marker "__cxLCP__", an ID like "myComponentID__cxLCP__"
         * will be recognized as containing the LCP element.
         */
        idMarker?: string;
        /**
         * Static list of CMS component IDs containing the LCP (Largest Contentful Paint)
         * element.
         *
         * It's just a static list of component IDs. If you'd like to dynamically mark certain CMS components
         * as containing the LCP element in your CMS, use the sibling config property `idMarker` instead.
         */
        ids?: string[];
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<LcpCmsComponentsConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LcpCmsComponentsConfig>;
}
declare module '@spartacus/core' {
    interface Config extends LcpCmsComponentsConfig {
    }
}

declare class CmsLcpService {
    protected readonly config: LcpCmsComponentsConfig;
    /**
     * Tells whether the given CMS component is marked as containing
     * the LCP (Largest Contentful Paint) element.
     *
     * The list of CMS component IDs can be specified in 2 ways:
     * - statically in the Spartacus configuration `config.lcpCmsComponents.ids`
     * - and dynamically configuring a special marker `config.lcpCmsComponentIdMarker`
     *    (i.e. when the CMS component ID contains a specific marker, for example "__cxLCP__").
     *
     * If a certain component is shared across multiple pages, but it's the LCP only on some of them,
     * you can extend this service to implement custom logic. The following is an example of marking
     * a 'SharedBanner` component as LCP only on the homepage, but not on other pages:
     * ```typescript
     * export class CustomCmsLcpService extends CmsLcpService {
     *   routingService = inject(RoutingService);
     *   getLcpPresence(
     *     componentData: ContentSlotComponentData
     *   ): Observable<LcpPresence> {
     *     return this.routingService.getRouterState().pipe(
     *       switchMap((routerState) => {
     *         const semanticRoute = routerState?.state?.semanticRoute;
     *         if (componentData?.uid === 'SharedBanner') {
     *           return of(
     *             semanticRoute === 'home' ? LcpPresence.HAS_LCP : LcpPresence.NO_LCP
     *           );
     *         }
     *         return super.getLcpPresence(componentData);
     *       })
     *     );
     *   }
     * }
     * ```
     */
    getLcpPresence(componentData: CmsComponent): Observable<LcpPresence>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsLcpService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CmsLcpService>;
}

/**
 * Provides the information whether the given CMS component contains the LCP (Largest Contentful Paint) element,
 * based on the `CmsComponentData` injection token.
 *
 * It's used in the `CmsInjectorService` to provide the `LCP_PRESENCE` at the DOM level of each CMS component.
 */
declare const provideLcpPresenceForCmsComponent: () => FactoryProvider;

/**
 * Replacement for the Angular's deprecated type `CanActivate`.
 */
type CanActivate = {
    canActivate: CanActivateFn;
};
/**
 * Observable that emits a boolean or an UrlTree.
 */
type CanActivateObservable = Observable<GuardResult>;
/**
 * Utility service for running multiple guards and composing their results
 * into a single result observable.
 */
declare class GuardsComposer {
    /**
     * Executes guards, returning an Observable that:
     * - emits `true` if all those guards pass (emit `true`)
     * - emits `false` or `UrlTree` immediately if any those guards fails (returns `false` or `UrlTree`)
     *
     * This is in line with the default Angular behavior.
     */
    canActivate(guards: CanActivate[], route: CmsActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<GuardResult>;
    /**
     * Executes a guard's `canActivate` method with `route` and `state`,
     * returning its result as an Observable.
     *
     * Converts non-Observable results (Promise or static value) into Observable.
     */
    protected canActivateGuard(guard: CanActivate, route: CmsActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<GuardResult>;
    /**
     * Composes the given observables into a single observable that emits a boolean or an UrlTree.
     *
     * The returned composed observable:
     * - emits `true` after all the given observables emit `true`.
     * - emits `false` or `UrlTree` as soon as any of the given observables emit such a value (`false` or `UrlTree`).
     */
    protected composeCanActivateObservables(canActivateObservables: CanActivateObservable[]): CanActivateObservable;
    /**
     * Tells whether the given object has a `canActivate` method.
     */
    protected isCanActivate(guard: any): guard is CanActivate;
    static ɵfac: i0.ɵɵFactoryDeclaration<GuardsComposer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GuardsComposer>;
}

/**
 * Service that executes guards provided via the injection token `BEFORE_CMS_PAGE_GUARD`.
 */
declare class BeforeCmsPageGuardService {
    protected guards: {
        canActivate: i2$1.CanActivateFn;
    }[];
    protected guardsComposer: GuardsComposer;
    /**
     * Executes guards from `BEFORE_CMS_PAGE_GUARD` token, returning an Observable that:
     * - emits `true` if all those guards pass (emit `true`)
     * - emits `false` or `UrlTree` immediately if any those guards fails (returns `false` or `UrlTree`)
     */
    canActivate(route: CmsActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BeforeCmsPageGuardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BeforeCmsPageGuardService>;
}

declare class CmsGuardsService {
    protected cmsComponentsService: CmsComponentsService;
    protected unifiedInjector: UnifiedInjector;
    constructor(cmsComponentsService: CmsComponentsService, unifiedInjector: UnifiedInjector);
    protected guardsComposer: GuardsComposer;
    /**
     * Executes all guards for the given `componentTypes` and returns an Observable that:
     * - emits `true` if all those guards pass (emit `true`)
     * - emits `false` or `UrlTree` immediately if any those guards fails (returns `false` or `UrlTree`)
     */
    cmsPageCanActivate(componentTypes: string[], route: CmsActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsGuardsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CmsGuardsService>;
}

declare class CmsI18nService {
    protected cmsComponentsService: CmsComponentsService;
    protected translation: TranslationService;
    protected translationChunk: TranslationChunkService;
    constructor(cmsComponentsService: CmsComponentsService, translation: TranslationService, translationChunk: TranslationChunkService);
    loadForComponents(componentTypes: string[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsI18nService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CmsI18nService>;
}

declare abstract class CmsRoutesService {
    abstract handleCmsRoutesInGuard(pageContext: PageContext, componentTypes: string[], currentUrl: string, currentPageLabel: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsRoutesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CmsRoutesService>;
}

/**
 * Helper service for `CmsPageGuard`
 */
declare class CmsPageGuardService {
    protected semanticPathService: SemanticPathService;
    protected cmsService: CmsService;
    protected cmsRoutes: CmsRoutesService;
    protected cmsI18n: CmsI18nService;
    protected cmsGuards: CmsGuardsService;
    protected cmsComponentsService: CmsComponentsService;
    protected routing: RoutingService;
    constructor(semanticPathService: SemanticPathService, cmsService: CmsService, cmsRoutes: CmsRoutesService, cmsI18n: CmsI18nService, cmsGuards: CmsGuardsService, cmsComponentsService: CmsComponentsService, routing: RoutingService);
    /**
     * Takes CMS components types in the current CMS page, triggers (configurable) side effects and returns a boolean - whether the route can be activated.
     *
     * Based on `cmsComponents` config for the components in the page:
     * - Evaluates components' guards; if one of them emits false or UrlTree - the route cannot be activated or redirects to the given UrlTree, respectively.
     * - If all components' guards emitted true, then the route can be activated
     * - Then we trigger loading of configured i18n chunks in parallel
     * - And we register the configured children routes of cms components
     *
     * @param pageContext current cms page context
     * @param pageData cms page data
     * @param route activated route snapshot
     * @param state router state snapshot
     *
     * @returns boolean observable - whether the route can be activated
     */
    canActivatePage(pageContext: PageContext, pageData: Page, route: CmsActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<GuardResult>;
    /**
     * Activates the "NOT FOUND" cms page.
     *
     * It loads cms page data for the "NOT FOUND" page and puts it in the state of the the requested page label.
     * Then it processes its CMS components with the method `canActivatePage()` of this service. For more, see its docs.
     */
    canActivateNotFoundPage(pageContext: PageContext, route: CmsActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsPageGuardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CmsPageGuardService>;
}

declare class CmsPageGuard {
    protected routingService: RoutingService;
    protected cmsService: CmsService;
    /** since 2211.24 not used anymore, but called indirectly via {@link BeforeCmsPageGuardService} */
    protected protectedRoutesGuard: ProtectedRoutesGuard;
    protected service: CmsPageGuardService;
    protected routingConfig: RoutingConfigService;
    static guardName: string;
    constructor(routingService: RoutingService, cmsService: CmsService, 
    /** since 2211.24 not used anymore, but called indirectly via {@link BeforeCmsPageGuardService} */
    protectedRoutesGuard: ProtectedRoutesGuard, service: CmsPageGuardService, routingConfig: RoutingConfigService);
    protected beforeCmsPageGuardService: BeforeCmsPageGuardService;
    /**
     * Tries to load the CMS page data for the anticipated route and returns:
     * - `true` - if it can be activated
     * - `false` - if it cannot be activated
     * - `UrlTree` - if user should be redirected to a given `UrlTree`
     *
     * If the route can be activated, it fires additional calculations on the CMS components present on this CMS page,
     * based on their configuration (`cmsComponents` config).
     *
     * For more, see docs of the `CmsPageGuardService.canActivatePage`.
     */
    canActivate(route: CmsActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<GuardResult>;
    /**
     * Returns whether we should reload the CMS page data, even when it was loaded before.
     */
    private shouldReload;
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsPageGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CmsPageGuard>;
}

/**
 * Guards that run on all CMS-driven routes before executing `{@link CmsPageGuard}`'s main logic.
 *
 *  **CAUTION**: Suitable for global guards ONLY! For route-specific guards, configure them under `cmsComponents`:
 * ```ts
 * provideConfig({
 *   cmsComponents: {
 *     [SomeCmsComponentType]: { guards: [MyGuard] }
 *   }
 * })
 * ```
 */
declare const BEFORE_CMS_PAGE_GUARD: InjectionToken<{
    canActivate: CanActivateFn;
}[]>;

/**
 * Default component handler used for dynamically launching cms components implemented
 * as native Angular components.
 */
declare class DefaultComponentHandler implements ComponentHandler {
    hasMatch(componentMapping: CmsComponentMapping): boolean;
    getPriority(): Priority;
    launcher(componentMapping: CmsComponentMapping, viewContainerRef: ViewContainerRef, elementInjector?: Injector, module?: NgModuleRef<any>): Observable<{
        elementRef: ElementRef;
        componentRef?: ComponentRef<any>;
    }>;
    protected getComponentFactory(injector: Injector, component: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<DefaultComponentHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DefaultComponentHandler>;
}

/**
 * Lazy component handler used for launching lazy loaded cms components implemented
 * as native Angular components.
 */
declare class LazyComponentHandler implements ComponentHandler {
    protected defaultHandler: DefaultComponentHandler;
    constructor(defaultHandler: DefaultComponentHandler);
    /**
     * We want to mach dynamic import signature () => import('')
     */
    hasMatch(componentMapping: CmsComponentMapping): boolean;
    private isNotClass;
    getPriority(): Priority;
    launcher(componentMapping: CmsComponentMapping, viewContainerRef: ViewContainerRef, elementInjector?: Injector, module?: NgModuleRef<any>): Observable<{
        elementRef: ElementRef;
        componentRef?: ComponentRef<any>;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LazyComponentHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LazyComponentHandler>;
}

/**
 * Matches the pattern '[ ** / ] marker / :paramName'
 *
 * @param marker phrase that indicates the start of the match
 * @param paramName name of the parameter present after the marker
 * @param precedingParamName name of the parameter for every preceding url segment
 *        i.e. `param` will result in `param0`, `param1`, ...
 */
declare function getSuffixUrlMatcher({ marker, paramName, precedingParamName, }: {
    marker: string;
    paramName: string;
    precedingParamName?: string;
}): {
    (segments: UrlSegment[]): UrlMatchResult | null;
    _suffixRouteConfig: {
        marker: string;
        paramName: string;
        precedingParamName: string;
    };
};

declare class PageMetaLinkService {
    protected winRef: WindowRef;
    protected rendererFactory: RendererFactory2;
    protected document: Document;
    constructor(winRef: WindowRef, rendererFactory: RendererFactory2);
    /**
     * Adds a canonical link element to the document head.
     *
     * If an id is provided, the link will be updated.
     * If no url is provided, the link element will be deleted.
     */
    setCanonicalLink(url: string | undefined): void;
    addPreconnectLink(url: string): void;
    protected get renderer(): Renderer2;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageMetaLinkService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PageMetaLinkService>;
}

declare class SeoMetaService implements OnDestroy {
    protected ngTitle: Title;
    protected ngMeta: Meta;
    protected pageMetaService: PageMetaService;
    protected pageMetaLinkService?: PageMetaLinkService | undefined;
    constructor(ngTitle: Title, ngMeta: Meta, pageMetaService: PageMetaService, pageMetaLinkService?: PageMetaLinkService | undefined);
    private subscription;
    init(): void;
    protected set meta(meta: PageMeta);
    protected set title(title: string | undefined);
    protected set description(value: string | undefined);
    protected set image(imageUrl: string | undefined);
    protected set robots(value: PageRobotsMeta[] | undefined);
    /**
     * Add the canonical Url to the head of the page.
     *
     * If the canonical url already exists the link is removed. This is quite
     * unlikely though, since canonical links are (typically) only added in SSR.
     */
    protected set canonicalUrl(url: string | undefined);
    protected addTag(meta: MetaDefinition): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SeoMetaService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SeoMetaService>;
}

interface Media {
    /**
     * Identify the “default” image URL which is used in case the srcset is not specified.
     * Browsers without srcset support will also fallback to this URl.
     */
    src: string;
    /**
     * The srcset attribute holds a list of image file URLs, along with size descriptions.
     */
    srcset?: string;
    /**
     * Provides alternative information for a media if a user cannot view the visual. It is
     * also used by web crawlers and screen readers.
     */
    alt?: string;
    /**
     * Describes the role of an element in programs that can make use of it, such as screen
     * readers or magnifiers
     */
    role?: string;
    /**
     * The sources holds a list of source element for picture html element
     */
    sources?: PictureHTMLElementSource[];
    /**
     * Specifies the intrinsic width of the image in pixels. Allowed if the parent of `<source>` is a `<picture>`
     */
    width?: number;
    /**
     * Specifies the intrinsic height of the image in pixels. Allowed if the parent of `<source>` is a `<picture>`
     */
    height?: number;
}
/**
 * Contains multiple media for different formats
 */
interface MediaContainer {
    [format: string]: Image;
}
/**
 * Specifies media size information that can be used to generate information for the
 * browser to resolve the right media for the right layout or device.
 */
interface MediaFormatSize {
    /**
     * Specifies the width for a given media format. The media format width is used
     * to align the width of the media with the available size in the layout, so that
     * different media's can be used in a responsive layout.
     */
    width?: number;
}
/**
 * Specifies media queries that can be used to generate information for the
 * browser to resolve the right media for the right layout or device.
 *
 * You can check available queries in official docs
 * https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_media_queries
 */
type PictureElementQueries = string;
interface PictureHTMLElementSource {
    srcset: string;
    media: string;
    width?: number;
    height?: number;
}
/**
 * Indicates how the browser should load the image.
 *
 * While this might not add too much value in some scenarios, as we have other
 * optimizations to defer loading of larger pieces of the DOM, there might be
 * components who haven't implemented other lazy loading techniques. Moreover,
 * a server sides rendered page that lands directly in the browser could benefit
 * enormously from the lazy loading of images.
 */
declare enum ImageLoadingStrategy {
    /**
     * Loads the image immediately, regardless of whether or not the image
     * is currently within the visible viewport (this is the default value).
     */
    EAGER = "eager",
    /**
     * Defers loading the image until it reaches a calculated distance from the viewport,
     * as defined by the browser. The intent is to avoid the network and storage bandwidth
     * needed to handle the image until it's reasonably certain that it will be needed.
     * This generally improves the performance of the content in most typical use cases.
     */
    LAZY = "lazy"
}
/**
 * Indicates the priority of the image fetching.
 * This is used to inform the browser about the relative priority of the image
 * fetching. It can be used to optimize the loading of images based on their
 * importance in the layout or user interaction.
 */
declare enum ImageFetchPriority {
    /**
     * Fetch the image at a high priority relative to other images with the same internal prioritization.
     */
    HIGH = "high",
    /**
     * Fetch the image at a low priority relative to other images with the same internal prioritization.
     */
    LOW = "low",
    /**
     * The browser will decide the priority of the image based on its own heuristics.
     */
    AUTO = "auto"
}

/**
 * Service which generates media URLs. It leverage the MediaContainer and MediaFormats so
 * that URLs and sizes are generated for the same media. This helps to improve performance
 * across difference devices and layouts.
 *
 * Media formats are optional, but highly recommended. The format will help the browser to
 * identify the right media for the right experience.
 *
 * The MediaService will generate absolute URLs in case relative URLs are provided for the Media.
 * The baseUrl is read from the `occConfig.backend.media.baseUrl` or
 * `occConfig.backend.occ.baseUrl`.
 */
declare class MediaService {
    protected config: Config;
    /**
     * The media formats sorted by size. The media format representing the smallest
     * size is sorted on top.
     */
    private _sortedFormats;
    private _sortedPictureFormats;
    private _reversedFormats;
    private readonly featureConfigService;
    protected logger: LoggerService;
    constructor(config: Config);
    getMediaBasedOnHTMLElementType(elementType: 'img' | 'picture', mediaContainer?: MediaContainer | Image, format?: string, alt?: string, role?: string): Media | undefined;
    /**
     * Returns a `Media` object with the main media (`src`) and various media (`src`)
     * for specific formats.
     *
     * This method is used for creating `Media` object that is used in `img` HTML element
     */
    getMedia(mediaContainer?: MediaContainer | Image, format?: string, alt?: string, role?: string): Media | undefined;
    /**
     * Returns a `Media` object with the main media (`src`) and various sources
     * for specific formats for HTML `<picture>` element.
     */
    getMediaForPictureElement(mediaContainer?: MediaContainer | Image, format?: string, alt?: string, role?: string): Media | undefined;
    /**
     * Generates attributes common for `<img>` ang `<picture>`.
     */
    protected getCommonMediaObject(mediaContainer: MediaContainer | Image, format?: string, alt?: string, role?: string): Media;
    /**
     * Returns width and height for Image.
     *
     * Width and height are not coming from CMS so it should be
     * manually added to the Container | Image object
     */
    protected getWidthAndHeight(mediaContainer: MediaContainer | Image, format?: string): {
        width: number | undefined;
        height: number | undefined;
    };
    /**
     * Reads the loading strategy from the `MediaConfig`.
     *
     * Defaults to `ImageLoadingStrategy.EAGER`.
     */
    get loadingStrategy(): ImageLoadingStrategy;
    /**
     * Creates the media formats in a logical sorted order. The map contains the
     * format key and the format size information. We do this only once for performance
     * benefits.
     */
    protected get sortedFormats(): {
        code: string;
        size: MediaFormatSize;
    }[];
    /**
     * Creates the media formats in a logical sorted order. The map contains the
     * format key and the format media query information. We do this only once for performance
     * benefits.
     */
    protected get sortedPictureFormats(): {
        code: string;
        mediaQuery: string;
    }[];
    /**
     * Creates the media formats in a reversed sorted order.
     */
    protected get reversedFormats(): {
        code: string;
        size: MediaFormatSize;
    }[];
    /**
     * Resolves the right media for the given format. The fo
     */
    protected resolveMedia(media: MediaContainer, format?: string): Image;
    /**
     * Validates the format against the given mediaContainer. If there is no format available,
     * or if the mediaContainer doesn't contain a media for the given media, the most optimal
     * format is resolved. If even that is not possible, the first format is returned.
     */
    protected resolveFormat(mediaContainer: MediaContainer, format?: string): string;
    /**
     * Returns the media format code with the best size.
     */
    protected resolveBestFormat(media: MediaContainer | Image): string | undefined;
    /**
     * Returns a set of media for the available media formats. Additionally, the configured media
     * format width is added to the srcset, so that browsers can select the appropriate media.
     *
     * The optional maxFormat indicates that only sources till a certain format should be added
     * to the srcset.
     */
    protected resolveSrcSet(media: MediaContainer | Image, maxFormat?: string): string | undefined;
    /**
     * Resolves the sources for a picture element based on the provided media container and maximum format.
     *
     * This method generates an array of picture element attributes (`srcset` and `media`) by filtering
     * the sorted picture formats up to the specified maximum format. It then maps the corresponding
     * media sources from the provided media container.
     *
     * The method will return an array of picture element attributes suitable for use
     * in a `<picture>` element, or `undefined` if no media is provided.
     */
    protected resolveSources(media: MediaContainer | Image, maxFormat?: string): PictureHTMLElementSource[] | undefined;
    /**
     * Retrieves a list of formats up to and including the specified max format.
     *
     * @template T - A type that extends an object containing a `code` property of type `string`.
     * @param {T[]} formats - An array of format objects, each containing at least a `code` property.
     * @param {string} [maxFormat] - The maximum format code to include in the returned list.
     * @returns {T[]} An array of formats up to and including the specified max format. If `maxFormat` is not found, returns the entire list.
     *
     * This method filters the provided list of formats to include only those up to and including
     * the specified max format. If the `maxFormat` is not found, the entire list of formats is returned.
     */
    protected getFormatsUpToMaxFormat<T extends {
        code: string;
    }>(formats: T[], maxFormat?: string): T[];
    /**
     * Resolves the absolute URL for the given url. In most cases, this URL represents
     * the relative URL on the backend. In that case, we prefix the url with the baseUrl.
     *
     * When we have receive an absolute URL, we return the URL as-is. An absolute URL might also
     * start with double slash, which is used to resolve media cross from http and https.
     */
    protected resolveAbsoluteUrl(url: string): string;
    /**
     * The base URL is either driven by a specific `backend.media.baseUrl`, or by the
     * `backend.occ.baseUrl`.
     *
     * The `backend.media.baseUrl` can be used to load media from a different location.
     *
     * In Commerce Cloud, a different location could mean a different "aspect".
     *
     * Defaults to empty string in case no config is provided.
     */
    getBaseUrl(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<MediaService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MediaService>;
}

declare class MediaPreconnectService {
    protected pageMetaLinkService: PageMetaLinkService;
    protected mediaService: MediaService;
    private featureToggles;
    protected windowRef: WindowRef;
    addPreconnectLink(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MediaPreconnectService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MediaPreconnectService>;
}

interface SchemaBuilder {
    build(): Observable<{}>;
}
interface JsonLdBuilder<T> {
    build(data: T): Observable<{}>;
}

declare class BreadcrumbSchemaBuilder implements SchemaBuilder {
    protected pageMetaService: PageMetaService;
    constructor(pageMetaService: PageMetaService);
    build(): Observable<any>;
    protected collect(pageMeta: PageMeta | null): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbSchemaBuilder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BreadcrumbSchemaBuilder>;
}

/**
 * Provides several standard json-ld builders that contribute
 * to collecting and building json-ld data.
 */
declare class JsonLdBuilderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<JsonLdBuilderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<JsonLdBuilderModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<JsonLdBuilderModule>;
}

/**
 * Builds the basic structured data for the product, see https://schema.org/product.
 * This builder includes data for sku number, name, description, brand and main image.
 */
declare class JsonLdBaseProductBuilder implements JsonLdBuilder<Product> {
    build(product: Product): Observable<any>;
    /**
     * Returns the product sku, name and description.
     */
    private getProductBase;
    /**
     * Returns the image object with the main product image url.
     *
     * If the image is not available, an empty object is returned.
     */
    protected getProductImage(product: Product): {
        image?: string;
    };
    /**
     * Returns the brand object with the product manufacturer.
     *
     * If the brand is not available, an empty object is returned.
     */
    protected getProductBrand(product: Product): {
        brand?: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<JsonLdBaseProductBuilder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<JsonLdBaseProductBuilder>;
}

/**
 * Builds the structured data for the product offer, see https://schema.org/offers.
 * The data includes the price, currency and availability level.
 */
declare class JsonLdProductOfferBuilder implements JsonLdBuilder<Product> {
    build(product: Product): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<JsonLdProductOfferBuilder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<JsonLdProductOfferBuilder>;
}

/**
 * Builds the structured data for the product reviews, see https://schema.org/Review.
 * The data includes the aggregated product rating and the individual reviews.
 */
declare class JsonLdProductReviewBuilder implements JsonLdBuilder<Product> {
    protected reviewService: ProductReviewService;
    protected config: SeoConfig;
    constructor(reviewService: ProductReviewService, config: SeoConfig);
    build(product: Product): Observable<any>;
    protected buildAggregatedReviews(product: Product, reviews: Review[]): any;
    protected buildReviews(review: Review): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<JsonLdProductReviewBuilder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<JsonLdProductReviewBuilder>;
}

declare class CurrentProductService {
    private routingService;
    private productService;
    constructor(routingService: RoutingService, productService: ProductService);
    protected readonly DEFAULT_PRODUCT_SCOPE = ProductScope.DETAILS;
    /**
     * Returns an observable for the current product
     * @returns Product
     * @returns null if product can't be found
     *
     * @param scopes
     */
    getProduct(scopes?: (ProductScope | string)[] | ProductScope | string): Observable<Product | null>;
    protected getCode(): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrentProductService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrentProductService>;
}

/**
 * Adds the minimal structured data for the product, see https://schema.org/product.
 * The actual data collection is delegated to `JsonLdBuilder`s, which can be injected
 * using the `JSONLD_PRODUCT_BUILDER` token.
 */
declare class ProductSchemaBuilder implements SchemaBuilder {
    private currentProduct;
    protected builders: JsonLdBuilder<Product>[];
    constructor(currentProduct: CurrentProductService, builders: JsonLdBuilder<Product>[]);
    build(): Observable<any>;
    protected collect(product: Product): Observable<any>[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductSchemaBuilder, [null, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductSchemaBuilder>;
}

/**
 * Injection token to extend schema builders for adding structural data (json-ld).
 *
 * Some builders (i.e. `JSONLD_PRODUCT_BUILDER`) might have additional
 * lower level builder to further extend the schema.
 */
declare const SCHEMA_BUILDER: InjectionToken<unknown>;
/**
 * Injection token to add specific json-ld builders for product related schemas.
 * See see https://schema.org/product for more information.
 */
declare const JSONLD_PRODUCT_BUILDER: InjectionToken<unknown>;

declare enum PageSection {
    HEADER = "header",
    FOOTER = "footer",
    NAVIGATION = "navigation"
}
interface CmsStructureOptions {
    /**
     * The componentId is used to provide a static configuration of (cms) components.
     */
    componentId?: string;
    /**
     * Page slot position is used to provide the slot configuration.
     */
    pageSlotPosition?: string;
    /**
     * The page template is used to provide the page slot to the given page template.
     */
    pageTemplate?: string;
    /**
     * The section is used to provide the page slot to the given section.
     */
    section?: PageSection | string;
    /**
     * The breakpoint is used to provide the page slot for a specific breakpoint.
     */
    breakpoint?: BREAKPOINT;
}

/**
 * Helper function to simplify the creation of static CMS structure (`CmsStructureConfig`).
 * The helper function leverage the `provideConfig`, and is only providing an easy way to
 * generate the cms structure. The function creates a configuration structure for components,
 * page slot and page template. The following example adds a component to a page slot:
 *
 * ```ts
 * provideCmsStructure({
 *   componentId: 'LoginComponent',
 *   pageSlotPosition: 'SiteLogin'
 * })
 * ```
 *
 * @param options.componentId component identifier is used to provide component structure
 * @param options.pageSlotPosition page slot position is used to provide the slot configuration
 * @param options.pageTemplate the page template is used to provide the page slot to the given page template
 * @param options.section the section is used to provide the page slot to the given section
 * @param options.breakpoint the breakpoint is used to provide the page slot for a specific breakpoint
 */
declare function provideCmsStructure(options: CmsStructureOptions): ValueProvider;

/**
 * The HTML element rendered in the template can be either `<img>` or `<picture>`,
 * depending on the input value of `elementType`, which defaults to `'img'`.
 *
 * In the case of a `<picture>` element, each `<source>` element will contain `srcset` attribute with exactly one URL.
 *
 * If you need multiple URLs per `<source>` (e.g. for different pixel densities),
 * split it into multiple media queries (e.g. with `min-device-pixel-ratio`). See the following example:
 *
 * Instead of:
 *
 * ```html
 * <source media="(min-width: 960px)" srcset="image-1400.jpg 1x, image-2800.jpg 2x">
 * ```
 *
 * Use additional formats and additional media queries, such as:
 *
 * ```html
 * <source media="(min-width: 960px) and (-webkit-min-device-pixel-ratio: 2)" srcset="image-2800.jpg">
 * <source media="(min-width: 960px)" srcset="image-1400.jpg">
 * ```
 */
declare class MediaComponent implements OnChanges {
    protected mediaService: MediaService;
    /**
     * The media container can hold multiple media items, so that
     * a specific media (by format) can be used or multiple media
     * can be provided in a `srcset` so the browser will figure out
     * the best media for the device.
     */
    container: MediaContainer | Image | ImageGroup | ImageGroup[] | undefined;
    /**
     * if a media format is given, a media for the given format will be rendered
     */
    format: string;
    /**
     * A specific alt text for an image, which overrules the alt text
     * from the container data.
     */
    alt: string;
    /**
     * set role of the image if different than what is intended (eg, role="presentation")
     */
    role: string;
    /**
     * Set the loading strategy of the media. Defaults to global loading strategy.
     * Use 'lazy' or 'eager' strategies.
     */
    loading: ImageLoadingStrategy | null;
    /**
     * Provides a hint to the browser about the fetch priority of the image.
     * When set to 'high', the browser may prioritize loading this image earlier,
     * and it will automatically use `loading="eager"` for optimal performance.
     * Valid values are: 'low', 'auto', or 'high'.
     */
    fetchPriority?: ImageFetchPriority | null;
    /**
     * @default 'img'
     */
    elementType: 'img' | 'picture';
    /**
     * Specifies the `sizes` attribute for responsive images.
     *
     * The `sizes` attribute describes the layout width of the image for various viewport sizes.
     * It helps the browser determine which image to download from the `srcset` attribute.
     *
     * - The `sizes` attribute is defined using media queries.
     * - It allows specifying different sizes for various screen widths or other conditions (e.g., device orientation).
     * - The browser uses the value to pick the most appropriate image source from the `srcset`.
     *
     * This input is applicable only when the `elementType` input is set to `'img'`, as the `sizes` attribute
     * is currently added only to the `<img>` HTML element.
     */
    sizesForImgElement: string;
    /**
     * Once the media is loaded, we emit an event.
     */
    loaded: EventEmitter<Boolean>;
    /**
     * The media contains the info for the UI to create the image. This media
     * object might contain more info once other media types (i.e. video) is supported.
     */
    media: Media | undefined;
    /**
     * The `cx-media` component has an `is-initialized` class as long as the
     * media is being initialized.
     */
    isInitialized: boolean;
    /**
     * The `cx-media` component has a `is-loading` class as long as the
     * media is loaded. Wehn the media is loaded, the `is-initialized` class
     * is added.
     */
    isLoading: boolean;
    /**
     * When there's no media provided for the content, or in case an error
     * happened during loading, we add the `is-missing` class. Visual effects
     * can be controlled by CSS.
     */
    isMissing: boolean;
    protected trackByMedia: TrackByFunction<HTMLSourceElement>;
    constructor(mediaService: MediaService);
    ngOnChanges(): void;
    /**
     * Creates the `Media` object
     */
    protected create(): void;
    /**
     * This handler is called from the UI when the image is loaded.
     */
    loadHandler(): void;
    /**
     * Indicates whether the browser should lazy load the image.
     */
    get loadingStrategy(): ImageLoadingStrategy | null;
    /**
     * Whenever an error happens during load, we mark the component
     * with css classes to have a missing media.
     */
    errorHandler(): void;
    protected handleMissing(): void;
    /**
     * If the media has a high fetch priority, we load the image eagerly,
     * no matter what the explicit loading strategy is.
     *
     * It's for convenience to not set explicitly `loading="eager"`,
     * when we already know that the image has a high fetch priority.
     */
    protected get effectiveLoadingStrategy(): ImageLoadingStrategy | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<MediaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MediaComponent, "cx-media", never, { "container": { "alias": "container"; "required": false; }; "format": { "alias": "format"; "required": false; }; "alt": { "alias": "alt"; "required": false; }; "role": { "alias": "role"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "fetchPriority": { "alias": "fetchPriority"; "required": false; }; "elementType": { "alias": "elementType"; "required": false; }; "sizesForImgElement": { "alias": "sizesForImgElement"; "required": false; }; }, { "loaded": "loaded"; }, never, never, true, never>;
}

declare class MediaSourcesPipe implements PipeTransform {
    transform(sizes: string): Pick<HTMLSourceElement, "srcset" | "media">[];
    static ɵfac: i0.ɵɵFactoryDeclaration<MediaSourcesPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<MediaSourcesPipe, "cxMediaSources", true>;
}

declare function mediaPreconnectInitializer(mediaPreconnectService: MediaPreconnectService): () => void;
declare class MediaModule {
    static forRoot(): ModuleWithProviders<MediaModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MediaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MediaModule, never, [typeof i1.CommonModule, typeof i3.FeaturesConfigModule, typeof MediaComponent, typeof MediaSourcesPipe], [typeof MediaComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MediaModule>;
}

declare class MockKeyboardFocusDirective {
    config: FocusConfig;
    static ɵfac: i0.ɵɵFactoryDeclaration<MockKeyboardFocusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MockKeyboardFocusDirective, "[cxFocus]", never, { "config": { "alias": "cxFocus"; "required": false; }; }, {}, never, never, true, never>;
}
declare class KeyboardFocusTestingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<KeyboardFocusTestingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<KeyboardFocusTestingModule, never, [typeof MockKeyboardFocusDirective], [typeof MockKeyboardFocusDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<KeyboardFocusTestingModule>;
}

/**
 * Temporarily removes elements from the tabbing flow and restores them after a tick.
 *
 * This method sets the `tabIndex` of each element in the provided iterable to `-1`
 * and resets it back to `0` using `requestAnimationFrame`. While using `requestAnimationFrame`
 * may seem like a bad code smell, it is justified here as it ensures a natural tabbing flow
 * in cases where determining the next focusable element is complex, such as when directives
 * like `TrapFocusDirective` modify the DOM's focus behavior.
 *
 * This utility is especially useful for scenarios like menus, lists, or carousels where
 * `Tab` navigation is intentionally disabled, but other keyboard keys (e.g., `Arrow` keys)
 * are used for navigation. It helps prevent these elements from disrupting the tab order
 * while allowing other key-based interactions.
 *
 * @param elements - An iterable of `HTMLElement` objects to temporarily remove from tab navigation.
 */
declare const disableTabbingForTick: (elements: Iterable<HTMLElement>) => void;

declare const defaultSkipLinkConfig: SkipLinkConfig;

declare class HamburgerMenuService {
    isExpanded: BehaviorSubject<boolean>;
    constructor(router: Router);
    /**
     * toggles the expand state of the hamburger menu
     */
    toggle(forceCollapse?: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HamburgerMenuService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HamburgerMenuService>;
}

declare enum StorefrontOutlets {
    STOREFRONT = "cx-storefront"
}

declare class StorefrontComponent implements OnInit, OnDestroy {
    private hamburgerMenuService;
    private routingService;
    protected elementRef: ElementRef<HTMLElement>;
    protected keyboardFocusService: KeyboardFocusService;
    navigateSubscription: Subscription;
    focusConfig: FocusConfig;
    skipFocusConfig: SkipFocusConfig;
    isExpanded$: Observable<boolean>;
    readonly StorefrontOutlets: typeof StorefrontOutlets;
    protected destroyRef: DestroyRef;
    protected document: Document | null;
    protected skipLinkService: SkipLinkService | null;
    startNavigating: boolean;
    stopNavigating: boolean;
    tabindex: string;
    child: SkipLinkComponent;
    private keyboardFocusConfig;
    handleEscape(event: KeyboardEvent): void;
    private featureConfig;
    constructor(hamburgerMenuService: HamburgerMenuService, routingService: RoutingService, elementRef: ElementRef<HTMLElement>, keyboardFocusService: KeyboardFocusService);
    ngOnInit(): void;
    collapseMenuIfClickOutside(event: any): void;
    collapseMenu(): void;
    protected trapFocusOnMenuIfExpanded(): void;
    protected focusOnFirstNavigationItem(): void;
    ngOnDestroy(): void;
    protected onNavigation(isNavigating: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StorefrontComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StorefrontComponent, "cx-storefront", never, {}, {}, never, never, true, never>;
}

declare class StorefrontComponentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<StorefrontComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StorefrontComponentModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof GlobalMessageComponentModule, typeof OutletModule, typeof OutletRefModule, typeof PageLayoutModule, typeof PageSlotModule, typeof KeyboardFocusModule, typeof SkipLinkModule, typeof StorefrontComponent], [typeof StorefrontComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StorefrontComponentModule>;
}

declare class BaseStorefrontModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseStorefrontModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BaseStorefrontModule, never, [typeof i3.BaseCoreModule, typeof i2$1.RouterModule, typeof GlobalMessageComponentModule, typeof OutletModule, typeof OutletRefModule, typeof PwaModule, typeof PageLayoutModule, typeof SeoModule, typeof PageComponentModule, typeof PageSlotModule, typeof SkipLinkModule, typeof KeyboardFocusModule, typeof LayoutModule, typeof RoutingModule, typeof MediaModule, typeof OutletModule, typeof CmsLcpModule, typeof StorefrontComponentModule], [typeof LayoutModule, typeof StorefrontComponentModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BaseStorefrontModule>;
}

declare class AnonymousConsentManagementBannerComponent implements OnDestroy {
    protected anonymousConsentsService: AnonymousConsentsService;
    protected vcr: ViewContainerRef;
    protected launchDialogService: LaunchDialogService;
    private subscriptions;
    bannerVisible$: Observable<boolean>;
    constructor(anonymousConsentsService: AnonymousConsentsService, vcr: ViewContainerRef, launchDialogService: LaunchDialogService);
    viewDetails(): void;
    allowAll(): void;
    hideBanner(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnonymousConsentManagementBannerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AnonymousConsentManagementBannerComponent, "cx-anonymous-consent-management-banner", never, {}, {}, never, never, true, never>;
}

declare class AnonymousConsentOpenDialogComponent {
    protected vcr: ViewContainerRef;
    protected anonymousConsentsService: AnonymousConsentsService;
    protected launchDialogService: LaunchDialogService;
    openElement: ElementRef;
    bannerVisible$: Observable<boolean>;
    constructor(vcr: ViewContainerRef, anonymousConsentsService: AnonymousConsentsService, launchDialogService: LaunchDialogService);
    openDialog(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnonymousConsentOpenDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AnonymousConsentOpenDialogComponent, "cx-anonymous-consent-open-dialog", never, {}, {}, never, never, true, never>;
}

declare class AnonymousConsentManagementBannerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AnonymousConsentManagementBannerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AnonymousConsentManagementBannerModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof KeyboardFocusModule, typeof i3.FeaturesConfigModule, typeof AnonymousConsentManagementBannerComponent, typeof AnonymousConsentOpenDialogComponent], [typeof AnonymousConsentManagementBannerComponent, typeof AnonymousConsentOpenDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AnonymousConsentManagementBannerModule>;
}

/**
 * Generic carousel that renders CMS Components.
 */
declare class BannerCarouselComponent {
    private componentData;
    private cmsService;
    private componentData$;
    private items$;
    /**
     * Adds a specific theme for the carousel. The effect can be
     * used in CSS customisations.
     */
    theme: string;
    constructor(componentData: CmsComponentData<CmsBannerCarouselComponent>, cmsService: CmsService);
    /**
     * Returns an Obervable with an Array of Observables. This is done, so that
     * the component UI could consider to lazy load the UI components when they're
     * in the viewpoint.
     */
    getItems(): Observable<Observable<ContentSlotComponentData>[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BannerCarouselComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BannerCarouselComponent, "cx-banner-carousel", never, {}, {}, never, never, true, never>;
}

declare class CarouselService {
    private winRef;
    constructor(winRef: WindowRef);
    /**
     * The number of items per slide is calculated by the help of
     * the item width and the available width of the host element.
     * This appoach makes it possible to place the carousel in different
     * layouts. Instead of using the page breakpoints, the host size is
     * taken into account.
     *
     * Since there's no element resize API available, we use the
     * window `resize` event, so that we can adjust the number of items
     * whenever the window got resized.
     */
    getItemsPerSlide(nativeElement: HTMLElement, itemWidth: string): Observable<number>;
    /**
     * Calculates the number of items per given hostSize.  calculated based on the given
     * intended size in pixels or percentages. The
     *
     * @param availableWidth The available width in pixels for the carousel items.
     * @param itemWidth The width per carousel item, in px or percentage.
     */
    private calculateItems;
    static ɵfac: i0.ɵɵFactoryDeclaration<CarouselService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CarouselService>;
}

/**
 * Generic carousel component that can be used to render any carousel items,
 * such as products, images, banners, or any component. Carousel items are
 * rendered in so-called carousel slides, and the previous/next buttons as well as
 * the indicator-buttons can used to navigate the slides.
 *
 * The component uses an array of Observables (`items$`) as an input, to allow
 * for lazy loading of items.
 *
 * The number of items per slide is calculated with the `itemWidth`, which can given
 * in pixels or percentage.
 *
 * To allow for flexible rendering of items, the rendering is delegated to the
 * given `template`. This allows for maximum flexibility.
 *
 * Hydration is disabled for this component (`ngSkipHydration: 'true'`) due to inconsistencies between
 * client-side rendering (CSR) and server-side rendering (SSR). The differences in rendered output
 * can cause issues during the hydration process, so this component is excluded from Angular hydration.
 */
declare class CarouselComponent implements OnInit, OnChanges {
    protected el: ElementRef;
    protected service: CarouselService;
    keybordEvent: BehaviorSubject<KeyboardEvent | null>;
    /**
     * The title is rendered as the carousel heading.
     */
    title: string | undefined | null;
    /**
     * The items$ represent the carousel items. The items$ are
     * observables so that the items can be loaded on demand.
     */
    items: Observable<any>[];
    set setItems(inputItems: Observable<any>[]);
    /**
     * The template is rendered for each item, so that the actual
     * view can be given by the compoent that uses the `CarouselComponent`.
     */
    template: TemplateRef<any>;
    /**
     * Specifies the minimum size of the carousel item, either in px or %.
     * This value is used for the calculation of numbers per carousel, so that
     * the number of carousel items is dynamic. The calculation uses the `itemWidth`
     * and the host element `clientWidth`, so that the carousel is reusable in
     * different layouts (for example in a 50% grid).
     */
    itemWidth: string;
    /**
     * Indicates whether the visual indicators are used.
     */
    hideIndicators: boolean;
    indicatorIcon: ICON_TYPE$1;
    previousIcon: ICON_TYPE$1;
    nextIcon: ICON_TYPE$1;
    /**
     * Angular's trackBy function for iterating over carousel items.
     *
     * For a given item it should return an unique identifier.
     * If not provided, it will fallback to returning the item directly
     * (like Angular's naive default trackBy).
     *
     * If the returned value is not unique, it may lead to unexpected behavior,
     * such as unwanted destroying and re-creating child templates on items array changes.
     */
    trackByFn: TrackByFunction<any>;
    activeSlide: number;
    size$: Observable<number>;
    protected logger: LoggerService;
    constructor(el: ElementRef, service: CarouselService);
    ngOnInit(): void;
    ngOnChanges(): void;
    /**
     * Prevents default mousedown behavior on navigation buttons when enabled
     * to avoid unwanted blur events (e.g., in Safari when carousel is used inside modals or search boxes).
     */
    onNavigationMouseDown(event: MouseEvent): void;
    /**
     * Handler for the "next" button click.
     */
    onNextClick(event: MouseEvent, size: number): void;
    /**
     * Handler for the "previous" button click.
     */
    onPreviousClick(event: MouseEvent, size: number): void;
    onItemKeydown(event: KeyboardEvent, size: number): void;
    /**
     * Handles Tab key on carousel items. If the carousel items have `ArrowRight`/`ArrowLeft`
     * navigation enabled, it temporarily disables tab navigation for these items.
     * The `cxFocusableCarouselItem` selector is used because it identifies carousel
     * items that have `ArrowRight`/`ArrowLeft` navigation enabled. These items should not
     * use tab navigation according to a11y requirements.
     */
    protected skipTabForCarouselItems(): void;
    /**
     * Focuses the next or previous item in the carousel based on keyboard navigation.
     *
     * This method determines the next focusable carousel item, identified by the
     * `cxFocusableCarouselItem` directive, based on the current focus and the direction
     * given. It adjusts the carousel's active slide if the next focusable item is
     * outside the currently visible items.
     *
     * @param currentItem - The currently focused carousel item.
     * @param direction - The navigation direction (1 for right, -1 for left).
     * @param size - The number of items per slide, used to determine slide change is needed
     */
    protected focusNextPrevItem(currentItem: EventTarget | null, direction: number, size: number): void;
    getSlideNumber(size: number, currentIndex: number): number;
    shareEvent(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CarouselComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CarouselComponent, "cx-carousel", never, { "title": { "alias": "title"; "required": false; }; "setItems": { "alias": "items"; "required": false; }; "template": { "alias": "template"; "required": false; }; "itemWidth": { "alias": "itemWidth"; "required": false; }; "hideIndicators": { "alias": "hideIndicators"; "required": false; }; "indicatorIcon": { "alias": "indicatorIcon"; "required": false; }; "previousIcon": { "alias": "previousIcon"; "required": false; }; "nextIcon": { "alias": "nextIcon"; "required": false; }; "trackByFn": { "alias": "trackByFn"; "required": false; }; }, { "keybordEvent": "keybordEvent"; }, never, never, true, never>;
}

/**
 * Directive to enhance carousel item accessibility by ensuring they can receive focus,
 * enabling keyboard navigation using Arrow keys between carousel items.
 *
 * Upon initialization, the directive verifies if the host element is inherently focusable
 * or if it has an appropriately set tabindex. If an element cannot receive focus and the
 * application is running in development mode, a warning is logged to help identify and
 * correct accessibility issues during development.
 *
 * Usage example:
 * ```
 * <ng-container>
 *   <cx-carousel [template]="thumb">
 *     ...
 *   </cx-carousel>
 * </ng-container>
 *
 * <ng-template #thumb let-item="item">
 *   <cx-media cxFocusableCarouselItem tabindex="0">
 *     ...
 *   </cx-media>
 * </ng-template>
 * ```
 */
declare class FocusableCarouselItemDirective {
    protected logger: LoggerService;
    protected el: ElementRef;
    constructor(logger: LoggerService, el: ElementRef);
    protected canElementReceiveFocus(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusableCarouselItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FocusableCarouselItemDirective, "[cxFocusableCarouselItem]", never, {}, {}, never, never, true, never>;
}

declare class CarouselModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CarouselModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CarouselModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof IconModule, typeof MediaModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof CarouselComponent, typeof FocusableCarouselItemDirective], [typeof CarouselComponent, typeof FocusableCarouselItemDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CarouselModule>;
}

declare class BannerCarouselModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BannerCarouselModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BannerCarouselModule, never, [typeof i1.CommonModule, typeof PageComponentModule, typeof CarouselModule, typeof MediaModule, typeof BannerCarouselComponent], [typeof BannerCarouselComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BannerCarouselModule>;
}

declare class BannerComponent {
    protected component: CmsComponentData<CmsBannerComponent>;
    protected urlService: SemanticPathService;
    protected cmsService: CmsService;
    routerLink: string | any[] | undefined;
    styleClasses: string | undefined;
    data$: Observable<CmsBannerComponent>;
    constructor(component: CmsComponentData<CmsBannerComponent>, urlService: SemanticPathService, cmsService: CmsService);
    /**
     * Returns `_blank` to force opening the link in a new window whenever the
     * `data.external` flag is set to true.
     */
    getTarget(data: CmsBannerComponent): string | null;
    protected setRouterLink(data: CmsBannerComponent): void;
    getImage(data: CmsBannerComponent): Image | ImageGroup | undefined;
    getImageAltText(data: CmsBannerComponent): string | undefined;
    getLinkAriaLabel(data: CmsBannerComponent): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<BannerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BannerComponent, "cx-banner", never, {}, {}, never, never, true, never>;
}

declare class GenericLinkComponentService {
    /**
     * Pattern matching string starting with `http://` or `https://`.
     */
    protected HTTP_PROTOCOL_REGEX: RegExp;
    /**
     * Pattern matching string starting with `mailto:`.
     */
    protected MAILTO_PROTOCOL_REGEX: RegExp;
    /**
     * Pattern matching string starting with `tel:`.
     */
    protected TEL_PROTOCOL_REGEX: RegExp;
    /**
     * Returns true when the @Input `url` is a string starting with `http://`, `https://`, `mailto:`, `tel:`.
     */
    isExternalUrl(url: string | any[]): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<GenericLinkComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GenericLinkComponentService>;
}

interface RouteParts {
    /** Path in the Angular-like array format */
    path?: string[];
    /** Query params */
    queryParams?: Params;
    /** Hash fragment */
    fragment?: string | null;
}
/**
 * This component navigates using [routerLink] attribute when input 'url' is a relative url. Otherwise (when it's absolute), [href] is used.
 */
declare class GenericLinkComponent implements OnChanges {
    protected router: Router;
    protected service: GenericLinkComponentService;
    constructor(router: Router, service: GenericLinkComponentService);
    /**
     * Used to split url into 2 parts:
     * 1. the path
     * 2. query params + hash fragment
     */
    protected readonly URL_SPLIT: RegExp;
    /**
     * Parsed parts of the @Input `url`, when it's a local URL.
     * It should not be used when the `url` is external.
     * @see `url`
     */
    protected routeParts: RouteParts;
    url: string | any[];
    target: string | null;
    id: string;
    class: string;
    style: string | undefined;
    title: string;
    ariaLabel?: string;
    tabindex: 0 | -1;
    isExternalUrl(): boolean;
    get rel(): "noopener" | null;
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * The part with the path of the local url.
     */
    get routerUrl(): string[] | undefined;
    /**
     * The part with the query params of the local url.
     */
    get queryParams(): Params | undefined;
    /**
     * The part with the hash fragment of the local url.
     */
    get fragment(): string | undefined;
    /**
     * Parses the given url and sets the property `urlParts` accordingly.
     */
    protected setUrlParts(url: string | any[]): void;
    /**
     * Parses the given string into 3 parts:
     * - string path (wrapped in an array to be compatible with Angular syntax for the `routerLink`)
     * - query params (as an object)
     * - hash fragment (string)
     */
    protected splitUrl(url?: string): RouteParts;
    /**
     * Prepends a leading slash to the given URL string, in case it doesn't have it.
     */
    protected getAbsoluteUrl(url: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<GenericLinkComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GenericLinkComponent, "cx-generic-link", never, { "url": { "alias": "url"; "required": false; }; "target": { "alias": "target"; "required": false; }; "id": { "alias": "id"; "required": false; }; "class": { "alias": "class"; "required": false; }; "style": { "alias": "style"; "required": false; }; "title": { "alias": "title"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "tabindex": { "alias": "tabindex"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class GenericLinkModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GenericLinkModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GenericLinkModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof GenericLinkComponent], [typeof GenericLinkComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GenericLinkModule>;
}

/**
 * Maps the information about the LCP (Largest Contentful Paint) presence to fetch priority.
 */
declare class LcpPresenceMappingService {
    getFetchPriority(lcpContext: LcpPresence): ImageFetchPriority | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<LcpPresenceMappingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LcpPresenceMappingService>;
}

/**
 * Context provided by the `*cxLcpContext` directive.
 */
interface LcpContextDirectiveTemplateContext {
    $implicit: {
        lcpPresence$: Observable<LcpPresence>;
        fetchPriority$: Observable<ImageFetchPriority | null | undefined>;
    };
}
/**
 * Directive that allows reading the LCP (Largest Contentful Paint) context
 * provided via the `LCP_PRESENCE` injection token by the ancestor component.
 *
 * The knowledge about the containing the LCP (Largest Contentful Paint) element
 * can be used for performance optimizations in some descendant component.
 *
 * @usage
 * ```html
 * <ng-container *cxLcpContext="let lcpContext">
 *   LCP Presence: {{ lcpContext.lcpPresence$ }}
 *
 *   <cx-media [fetchPriority]="lcpContext.fetchPriority$ | async">
 * </ng-container>
 */
declare class LcpContextDirective implements OnInit {
    protected readonly lcpPresence$: Observable<LcpPresence>;
    protected readonly lcpPresenceMappingService: LcpPresenceMappingService;
    /**
     * Convenience observable that maps the LCP presence to the fetch priority
     * for the image element, which can be used directly e.g. in the `<cx-media>` component.
     */
    protected readonly fetchPriority$: Observable<ImageFetchPriority | undefined>;
    protected templateRef: TemplateRef<any>;
    protected viewContainer: ViewContainerRef;
    ngOnInit(): void;
    static ngTemplateContextGuard(_dir: LcpContextDirective, _ctx: unknown): _ctx is LcpContextDirectiveTemplateContext;
    static ɵfac: i0.ɵɵFactoryDeclaration<LcpContextDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<LcpContextDirective, "[cxLcpContext]", never, {}, {}, never, never, true, never>;
}

declare class LcpContextDirectiveModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LcpContextDirectiveModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LcpContextDirectiveModule, never, [typeof LcpContextDirective], [typeof LcpContextDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LcpContextDirectiveModule>;
}

declare class BannerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BannerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BannerModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof GenericLinkModule, typeof MediaModule, typeof i3.FeaturesConfigModule, typeof LcpContextDirectiveModule, typeof BannerComponent], [typeof BannerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BannerModule>;
}

declare class LinkComponent implements OnDestroy, OnInit {
    protected component: CmsComponentData<CmsLinkComponent>;
    styleClasses: string | undefined;
    data$: Observable<CmsLinkComponent>;
    protected subscriptions: Subscription;
    constructor(component: CmsComponentData<CmsLinkComponent>);
    ngOnInit(): void;
    /**
     * Returns `_blank` to force opening the link in a new window whenever the
     * `data.target` flag is set to `true`.
     */
    getTarget(data: CmsLinkComponent): string | null;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LinkComponent, "cx-link", never, {}, {}, never, never, true, never>;
}

declare class LinkModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LinkModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof GenericLinkModule, typeof LinkComponent], [typeof LinkComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LinkModule>;
}

declare class ParagraphComponent {
    component: CmsComponentData<CmsParagraphComponent>;
    protected router: Router;
    protected sanitizer: DomSanitizer;
    handleClick(event: Event): void;
    constructor(component: CmsComponentData<CmsParagraphComponent>, router: Router);
    bypassSecurityTrustHtml(html?: string): SafeHtml;
    static ɵfac: i0.ɵɵFactoryDeclaration<ParagraphComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ParagraphComponent, "cx-paragraph", never, {}, {}, never, never, true, never>;
}

declare class SupplementHashAnchorsPipe implements PipeTransform {
    protected renderer: Renderer2;
    protected winRef: WindowRef;
    constructor(renderer: Renderer2, winRef: WindowRef);
    protected getPath(anchorId: string): string;
    transform(html?: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SupplementHashAnchorsPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SupplementHashAnchorsPipe, "cxSupplementHashAnchors", true>;
}

declare class SupplementHashAnchorsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SupplementHashAnchorsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SupplementHashAnchorsModule, never, [typeof SupplementHashAnchorsPipe], [typeof SupplementHashAnchorsPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SupplementHashAnchorsModule>;
}

declare class CmsParagraphModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CmsParagraphModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CmsParagraphModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof SupplementHashAnchorsModule, typeof ParagraphComponent], [typeof ParagraphComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CmsParagraphModule>;
}

declare class PDFComponent {
    protected component: CmsComponentData<CmsPDFDocumentComponent>;
    protected mediaService: MediaService;
    url?: string;
    data$: Observable<CmsPDFDocumentComponent>;
    constructor(component: CmsComponentData<CmsPDFDocumentComponent>, mediaService: MediaService);
    addPdfExtension(title?: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PDFComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PDFComponent, "cx-pdf", never, {}, {}, never, never, true, never>;
}

declare class PDFModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PDFModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PDFModule, never, [typeof i1.CommonModule, typeof IconModule, typeof i3.I18nModule, typeof PDFComponent], [typeof PDFComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PDFModule>;
}

interface Tab {
    /**
     * Name the tab with an i18n key.
     */
    headerKey?: string;
    /**
     * Params passed down to the translation function
     */
    headerParams?: Record<string, any>;
    /**
     * Name the tab with a string.
     */
    header?: string;
    /**
     * Content to display in tab panel when open.
     */
    content?: TemplateRef<any>;
    /**
     * Identifies the index of the tab to set attributes by.
     */
    id?: number;
    /**
     * Disables the tabindex on the border element so that the border
     * of the tab can no longer be focused.
     */
    disableBorderFocus?: boolean;
}
interface TabConfig {
    /**
     * Translatable key to set aria-label of tablist.
     */
    label?: Translatable | string;
    /**
     * Use this to set the tab mode. Defaults to 'TAB' when not set.
     */
    mode?: TAB_MODE;
    /**
     * Breakpoint to switch responsively between 'TAB' and 'ACCORDIAN' modes.
     * Uses 'ACCORDIAN' mode when under the breakpoint and 'TAB' mode when over it.
     * Set this to use responsive modes.
     */
    breakpoint?: BREAKPOINT;
    /**
     * The indexes of tabs to have open initially.
     */
    openTabs?: number[];
    /**
     * Restricts the direction keys that can be used to navigate between tabs.
     * When enabled, tab mode can only use left/right arrow keys and accordian mode up/down.
     */
    restrictDirectionKeys?: boolean;
}
declare enum TAB_MODE {
    TAB = "TAB",
    ACCORDIAN = "ACCORDIAN"
}

declare class TabParagraphContainerComponent implements AfterViewInit, OnInit {
    componentData: CmsComponentData<CMSTabParagraphContainer>;
    protected cmsService: CmsService;
    protected winRef: WindowRef;
    protected cdr: ChangeDetectorRef;
    /**
     * @deprecated This method will be removed.
     */
    activeTabNum: number;
    /**
     * @deprecated This method will be removed.
     */
    ariaLabel: string;
    /**
     * @deprecated This method will be removed.
     */
    children: QueryList<ComponentWrapperDirective>;
    tabRefs: QueryList<TemplateRef<any>>;
    /**
     * @deprecated This method will be removed.
     */
    tabTitleParams: (Observable<any> | null)[];
    tabConfig$: BehaviorSubject<TabConfig>;
    /**
     * Map with key as the component uid and value as the observable of the title parameters.
     */
    protected tabTitleParams$: BehaviorSubject<Map<string, Observable<any> | null>>;
    constructor(componentData: CmsComponentData<CMSTabParagraphContainer>, cmsService: CmsService, winRef: WindowRef);
    components$: Observable<any[]>;
    tabs$: Observable<Tab[]>;
    /**
     * @deprecated This method will be removed.
     */
    select(tabNum: number, event?: MouseEvent): void;
    /**
     * @deprecated This method will be removed.
     */
    ngOnInit(): void;
    ngAfterViewInit(): void;
    tabCompLoaded(componentRef: any, componentId?: string): void;
    protected getTitleParams(children: QueryList<ComponentWrapperDirective>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabParagraphContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabParagraphContainerComponent, "cx-tab-paragraph-container", never, {}, {}, never, never, true, never>;
}

declare class TabPanelComponent {
    TAB_MODE: typeof TAB_MODE;
    /**
     * Tab object to display content and set attributes to.
     */
    tab: Tab;
    /**
     * In which layout to set the component (ie. Tab or Accordian).
     * Defaults to "Tab" mode.
     */
    mode: TAB_MODE;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabPanelComponent, "cx-tab-panel", never, { "tab": { "alias": "tab"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TabPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TabPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TabPanelModule, never, [typeof i1.CommonModule, typeof PageComponentModule, typeof OutletModule, typeof i3.I18nModule, typeof KeyboardFocusModule, typeof TabPanelComponent], [typeof TabPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TabPanelModule>;
}

declare class TabComponent implements OnInit, AfterViewInit, OnDestroy {
    /**
     * If you have nested templates that are subject to complex changes,
     * it can be better to use this property instead with an Observable
     * to set Tabs.
     *
     * Note: You should NOT set the `tabs` property if using this.
     */
    tabs$: Observable<Tab[] | any>;
    tabs: Tab[] | any;
    config: TabConfig | any;
    disabled: boolean;
    readonly TAB_MODE: typeof TAB_MODE;
    protected breakpointService: BreakpointService;
    protected translationService: TranslationService;
    protected cd: ChangeDetectorRef;
    tabHeaders: QueryList<any>;
    openTabs$: BehaviorSubject<number[]>;
    mode$: Observable<TAB_MODE>;
    protected subscriptions: Subscription;
    constructor();
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /**
     * Tab selection works differently depending on the given mode.
     *
     * Modes:
     * - Tab: Closes all other tabs and opens the given tab.
     * - Accordian: Toggles the given tab open or closed.
     */
    select(tabNum: number, mode: TAB_MODE): void;
    /**
     * Focuses the given tab according to the number.
     */
    focus(tabNum: number): void;
    /**
     * Calls select or focus methods depending on the tab mode.
     */
    selectOrFocus(tabNum: number, mode: TAB_MODE, event: KeyboardEvent): void;
    /**
     * Handles keydown events made on tabs.
     *
     * Keys:
     * - ArrowUp / ArrowLeft: Select or focus the previous tab.
     * - ArrowRight / ArrowDown: Select or focus the next tab.
     * - Home: Select or focus the first tab.
     * - End: Select or focus the last tab.
     */
    handleKeydownEvent(tabNum: number, tabs: Tab[], mode: TAB_MODE, event: KeyboardEvent): void;
    protected shouldRestrictKeys(mode: TAB_MODE, event: KeyboardEvent): boolean;
    /**
     * Indicates whether a tab is open (in the open tabs array).
     */
    isOpen(tabNum: number): boolean;
    /**
     * Inverts the state of the given tab between open and closed.
     */
    toggleTab(tabNum: number): void;
    /**
     * Returns index 0 if the tab is already open,
     * no tabs are open and its the first tab (ie. 0),
     * or in 'ACCORDIAN' mode.
     * Otherwise returns -1.
     */
    getTabIndex(tabNum: number, mode: TAB_MODE): number;
    getTitle(mode: TAB_MODE, index: number): string | null;
    protected getOpenTabs(): number[];
    /**
     * Returns the mode specified by the config.
     * If unspecified mode, return 'TAB' or 'ACCORDIAN' modes responsively using the specified breakpoint in the config.
     * If unspecified breakpoint, return 'TAB' mode by default.
     */
    protected getMode(): Observable<TAB_MODE>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabComponent, "cx-tab", never, { "tabs$": { "alias": "tabs$"; "required": false; }; "tabs": { "alias": "tabs"; "required": false; }; "config": { "alias": "config"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TabModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TabModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TabModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof TabPanelModule, typeof TabComponent], [typeof TabComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TabModule>;
}

declare class TabParagraphContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TabParagraphContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TabParagraphContainerModule, never, [typeof i1.CommonModule, typeof PageComponentModule, typeof OutletModule, typeof i3.I18nModule, typeof TabModule, typeof i3.FeaturesConfigModule, typeof TabParagraphContainerComponent], [typeof TabParagraphContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TabParagraphContainerModule>;
}

declare class VideoComponent {
    protected component: CmsComponentData<CmsVideoComponent>;
    protected mediaService: MediaService;
    protected urlService: SemanticPathService;
    protected cmsService: CmsService;
    protected cd: ChangeDetectorRef;
    styleClasses: string | undefined;
    source: string | undefined;
    thumbnail: Media | undefined;
    routerLink: string | any[] | undefined;
    autoPlay: boolean;
    loop: boolean;
    mute: string | undefined;
    data$: Observable<CmsVideoComponent>;
    constructor(component: CmsComponentData<CmsVideoComponent>, mediaService: MediaService, urlService: SemanticPathService, cmsService: CmsService, cd: ChangeDetectorRef);
    protected setMedia(data: CmsVideoComponent): void;
    protected setControls(data: CmsVideoComponent): void;
    protected setRouting(data: CmsVideoComponent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VideoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VideoComponent, "cx-video", never, {}, {}, never, never, true, never>;
}

declare class SpinnerComponent {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<SpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SpinnerComponent, "cx-spinner", never, {}, {}, never, never, true, never>;
}

declare class SpinnerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SpinnerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SpinnerModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof SpinnerComponent], [typeof SpinnerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SpinnerModule>;
}

declare class VideoModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VideoModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VideoModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof GenericLinkModule, typeof MediaModule, typeof i3.I18nModule, typeof SpinnerModule, typeof VideoComponent], [typeof VideoComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VideoModule>;
}

declare const fontawesomeIconConfig: IconConfig;

declare class MockIconComponent {
    cxIcon: any;
    type: any;
    static ɵfac: i0.ɵɵFactoryDeclaration<MockIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MockIconComponent, "cx-icon,[cxIcon]", never, { "cxIcon": { "alias": "cxIcon"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
declare class MockIconLoaderService {
    getFlipDirection(): void;
    getHtml(): void;
    getStyleClasses(): void;
    addStyleClasses(): void;
    addLinkResource(): void;
}
declare class IconTestingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<IconTestingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<IconTestingModule, never, [typeof MockIconComponent], [typeof MockIconComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<IconTestingModule>;
}

declare class AtMessageDirective {
    protected elementRef: ElementRef<HTMLElement>;
    protected templateRef: TemplateRef<HTMLElement>;
    protected globalMessageService: GlobalMessageService;
    /**
     * Usage [cxAtMessage]="'translatableKey' | cxTranslate"
     */
    cxAtMessage: string | string[] | undefined;
    constructor(elementRef: ElementRef<HTMLElement>, templateRef: TemplateRef<HTMLElement>, globalMessageService: GlobalMessageService);
    protected get host(): HTMLElement;
    /**
     * Emit assistive global meesage to improve screen reader vocalization.
     * @param event
     */
    handleClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AtMessageDirective, [null, { optional: true; }, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AtMessageDirective, "[cxAtMessage]", never, { "cxAtMessage": { "alias": "cxAtMessage"; "required": false; }; }, {}, never, never, true, never>;
}

declare class AtMessageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AtMessageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AtMessageModule, never, [typeof AtMessageDirective], [typeof AtMessageDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AtMessageModule>;
}

declare class MessageComponent implements AfterViewInit {
    text: string;
    actionButtonText: string;
    actionButtonMessage: string;
    accordionText: string;
    showBody: boolean;
    isVisibleCloseButton: boolean;
    type: GlobalMessageType;
    closeMessage: EventEmitter<void>;
    buttonAction: EventEmitter<void>;
    iconTypes: typeof ICON_TYPE$1;
    messageContainer: ElementRef;
    constructor();
    get getCssClassesForMessage(): Record<string, boolean>;
    get getIconType(): ICON_TYPE$1;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MessageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MessageComponent, "cx-message", never, { "text": { "alias": "text"; "required": false; }; "actionButtonText": { "alias": "actionButtonText"; "required": false; }; "actionButtonMessage": { "alias": "actionButtonMessage"; "required": false; }; "accordionText": { "alias": "accordionText"; "required": false; }; "showBody": { "alias": "showBody"; "required": false; }; "isVisibleCloseButton": { "alias": "isVisibleCloseButton"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, { "closeMessage": "closeMessage"; "buttonAction": "buttonAction"; }, never, ["*"], true, never>;
}

declare class MessageComponentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MessageComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MessageComponentModule, never, [typeof AtMessageModule, typeof i1.CommonModule, typeof i3.I18nModule, typeof IconModule, typeof i3.FeaturesConfigModule, typeof MessageComponent], [typeof MessageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MessageComponentModule>;
}

declare class PromotionsComponent {
    promotions: Promotion[];
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<PromotionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PromotionsComponent, "cx-promotions", never, { "promotions": { "alias": "promotions"; "required": false; }; }, {}, never, never, true, never>;
}

declare class PromotionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PromotionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PromotionsModule, never, [typeof i1.CommonModule, typeof PromotionsComponent], [typeof PromotionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PromotionsModule>;
}

declare enum SiteContextType {
    LANGUAGE = "LANGUAGE",
    CURRENCY = "CURRENCY"
}

declare class LanguageCurrencyComponent {
    readonly siteContextType: typeof SiteContextType;
    static ɵfac: i0.ɵɵFactoryDeclaration<LanguageCurrencyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LanguageCurrencyComponent, "cx-language-currency-selector", never, {}, {}, never, never, true, never>;
}

declare class SiteContextComponentService {
    protected componentData: CmsComponentData<CmsSiteContextSelectorComponent>;
    private contextServiceMap;
    protected injector: Injector;
    constructor(componentData: CmsComponentData<CmsSiteContextSelectorComponent>, contextServiceMap: ContextServiceMap, injector: Injector);
    getItems(context?: SiteContextType): Observable<any>;
    getActiveItem(context?: SiteContextType): Observable<string>;
    getLabel(context?: SiteContextType): Observable<any>;
    setActive(value: string, context?: SiteContextType): void;
    protected getService(context?: SiteContextType): Observable<SiteContext<any>>;
    protected getContext(context?: SiteContextType): Observable<string | undefined>;
    protected getInjectedService(context: string): SiteContext<any>;
    protected getOptionLabel(item: any, context?: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteContextComponentService, [{ optional: true; }, null, null]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SiteContextComponentService>;
}

declare class SiteContextSelectorComponent {
    private componentService;
    /**
     * @deprecated since 2011.21 removed unused property
     */
    siteContextService: SiteContext<any>;
    iconTypes: typeof ICON_TYPE$1;
    /**
     * the context type can be set as an input. If the context is
     * not given, the context will be loaded from the backend.
     */
    context: SiteContextType;
    protected translationService: TranslationService;
    constructor(componentService: SiteContextComponentService);
    get items$(): Observable<any>;
    get activeItem$(): Observable<string>;
    set active(value: string);
    get label$(): Observable<any>;
    ariaLabel$(label: string, index: number, length: number): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteContextSelectorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SiteContextSelectorComponent, "cx-site-context-selector", never, { "context": { "alias": "context"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SiteContextSelectorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteContextSelectorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SiteContextSelectorModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof i3.SiteContextModule, typeof IconModule, typeof SiteContextSelectorComponent, typeof LanguageCurrencyComponent, typeof i3.I18nModule], [typeof SiteContextSelectorComponent, typeof LanguageCurrencyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SiteContextSelectorModule>;
}

declare class SiteThemeSwitcherComponentService {
    protected siteThemeService: SiteThemeService;
    getItems(): Observable<SiteTheme[]>;
    getActiveItem(): Observable<string>;
    setActive(value: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteThemeSwitcherComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SiteThemeSwitcherComponentService>;
}

/**
 * Component for switching themes.
 */
declare class SiteThemeSwitcherComponent {
    readonly translationService: TranslationService;
    iconTypes: typeof ICON_TYPE$1;
    constructor();
    protected themeSwitcherComponentService: SiteThemeSwitcherComponentService;
    get items$(): Observable<Array<SiteTheme>>;
    get activeItem$(): Observable<string>;
    set activeItem(value: string);
    ariaLabel$(theme: SiteTheme, index: number, length: number): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteThemeSwitcherComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SiteThemeSwitcherComponent, "cx-site-theme-switcher", never, {}, {}, never, never, true, never>;
}

declare class SiteThemeSwitcherModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SiteThemeSwitcherModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SiteThemeSwitcherModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof IconModule, typeof i3.SiteThemeModule, typeof SiteThemeSwitcherComponent], [typeof SiteThemeSwitcherComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SiteThemeSwitcherModule>;
}

declare class ConsentManagementFormComponent implements OnInit, OnChanges, AfterViewChecked {
    consentGiven: boolean;
    consentTemplate: ConsentTemplate;
    requiredConsents: string[];
    consent: AnonymousConsent | null;
    disabled: boolean;
    showMandatory: boolean;
    consentChanged: EventEmitter<{
        given: boolean;
        template: ConsentTemplate;
    }>;
    checkboxInput: ElementRef<HTMLInputElement>;
    private hadFocus;
    private document;
    private featureConfigService;
    constructor();
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewChecked(): void;
    onConsentChange(): void;
    isRequired(templateId: string | undefined): boolean;
    protected updateConsentGiven(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConsentManagementFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConsentManagementFormComponent, "cx-consent-management-form", never, { "consentTemplate": { "alias": "consentTemplate"; "required": false; }; "requiredConsents": { "alias": "requiredConsents"; "required": false; }; "consent": { "alias": "consent"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "showMandatory": { "alias": "showMandatory"; "required": false; }; }, { "consentChanged": "consentChanged"; }, never, never, true, never>;
}

declare class ConsentManagementComponentService {
    protected anonymousConsentsConfig?: AnonymousConsentsConfig | undefined;
    constructor(anonymousConsentsConfig?: AnonymousConsentsConfig | undefined);
    /**
     * Returns the list of mandatory consents
     * @param _templateList - list of all active consents. This parameter is not needed in core
     * implementation. But is needed in CDC implementation to fetch only the required consents
     * from this list
     * @returns array of consent IDs
     */
    getRequiredConsents(_templateList: ConsentTemplate[]): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ConsentManagementComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConsentManagementComponentService>;
}

declare class ConsentManagementComponent implements OnInit, OnDestroy {
    protected userConsentService: UserConsentService;
    protected globalMessageService: GlobalMessageService;
    protected anonymousConsentsConfig: AnonymousConsentsConfig;
    protected anonymousConsentsService: AnonymousConsentsService;
    protected authService: AuthService;
    protected consentManagementComponentService?: ConsentManagementComponentService | undefined;
    private subscriptions;
    private allConsentsLoading;
    templateList$: Observable<ConsentTemplate[]>;
    loading$: Observable<boolean>;
    requiredConsents: string[];
    get allConsentsLoading$(): Observable<boolean>;
    constructor(userConsentService: UserConsentService, globalMessageService: GlobalMessageService, anonymousConsentsConfig: AnonymousConsentsConfig, anonymousConsentsService: AnonymousConsentsService, authService: AuthService, consentManagementComponentService?: ConsentManagementComponentService | undefined);
    ngOnInit(): void;
    private consentListInit;
    private hideAnonymousConsents;
    private giveConsentInit;
    private withdrawConsentInit;
    private consentsExists;
    onConsentChange({ given, template, }: {
        given: boolean;
        template: ConsentTemplate;
    }): void;
    private onConsentGivenSuccess;
    private onConsentWithdrawnSuccess;
    rejectAll(templates?: ConsentTemplate[]): void;
    private setupWithdrawalStream;
    allowAll(templates?: ConsentTemplate[]): void;
    private setupGiveStream;
    trackByTemplateId(_index: number, item: ConsentTemplate): string;
    private isRequiredConsent;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConsentManagementComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConsentManagementComponent, "cx-consent-management", never, {}, {}, never, never, true, never>;
}

declare class ConsentManagementModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConsentManagementModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConsentManagementModule, never, [typeof i1.CommonModule, typeof i2$2.FormsModule, typeof i2$2.ReactiveFormsModule, typeof SpinnerModule, typeof i3.I18nModule, typeof IconModule, typeof i3.FeaturesConfigModule, typeof ConsentManagementComponent, typeof ConsentManagementFormComponent], [typeof ConsentManagementComponent, typeof ConsentManagementFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConsentManagementModule>;
}

/**
 * Directive used for making links styled as a buttons (using .btn class)
 * act as a real buttons a11y wise (meaning making them reactive to both
 * enter and spacebar clicks).
 *
 * Note: This is done as a11y optimization for old button like link compoennts
 * and shouldn't be used other than for those. Whenever you find yourself in a need
 * to be using this consider it as a good 'code smell' for using BUttons instead of links.
 */
declare class BtnLikeLinkDirective {
    handleKeydown(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BtnLikeLinkDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BtnLikeLinkDirective, "a[cxBtnLikeLink].btn", never, {}, {}, never, never, true, never>;
}

declare class BtnLikeLinkModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BtnLikeLinkModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BtnLikeLinkModule, never, [typeof i1.CommonModule, typeof BtnLikeLinkDirective], [typeof BtnLikeLinkDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BtnLikeLinkModule>;
}

/**
 * Custom Directive used to enable clients to track (react to) Host's Element DOM changes.
 *
 * Whenever the mutation (Host's element DOM subthree change) is detected it will trigger the
 * _cxDomChange_ Output allowing clients to react to the Host's element DOM changes.
 *
 * Optional _cxDomChangeTargetSelector_ Input enables clients to be more specifixc when reacting to
 * the Host's element DOM changes by allowing them to specify css selector (relative to Host Element)
 * that narrows down the number of _cxDomChange_ Output executions to be triggered only when
 * _cxDomChangeTargetSelector_ Input relevant elements changes are detected.
 */
declare class DomChangeDirective implements OnDestroy {
    protected changes: MutationObserver;
    /**
     * Optional Css Selector Input filtering DOM mutations to those targeting only elements described via provided selector
     */
    cxDomChangeTargetSelector?: string;
    cxDomChange: EventEmitter<MutationRecord>;
    protected elementRef: ElementRef;
    constructor();
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DomChangeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DomChangeDirective, "[cxDomChange]", never, { "cxDomChangeTargetSelector": { "alias": "cxDomChangeTargetSelector"; "required": false; }; }, { "cxDomChange": "cxDomChange"; }, never, never, true, never>;
}

declare class DomChangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DomChangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DomChangeModule, never, [typeof i1.CommonModule, typeof DomChangeDirective], [typeof DomChangeDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DomChangeModule>;
}

declare class TruncationTooltipDirective implements OnInit, OnDestroy {
    private el;
    private renderer;
    private document;
    private tooltipEl;
    ngOnInit(): void;
    show(): void;
    hide(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TruncationTooltipDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TruncationTooltipDirective, "[cxTruncationTooltip]", never, {}, {}, never, never, true, never>;
}

declare class TruncationTooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TruncationTooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TruncationTooltipModule, never, [typeof TruncationTooltipDirective], [typeof TruncationTooltipDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TruncationTooltipModule>;
}

declare const defaultLayoutConfig: LayoutConfig;

/**
 * The direction config provides an easy way to configure "ltr" versus "rtl" direction
 * for the storefront. The direction can be configured to detect the direction by language.
 *
 * The following configuration detects rtl languages by isoCode for Arabic and Hebrew:
 *
 * ```typescript
 * direction: {
 *   detect: true,
 *   default: DirectionMode.LTR,
 *   rtlLanguages: ['ar', 'he']
 * }
 * ```
 */
declare abstract class DirectionConfig {
    direction?: Direction;
    static ɵfac: i0.ɵɵFactoryDeclaration<DirectionConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DirectionConfig>;
}
declare module '@spartacus/core' {
    interface Config extends DirectionConfig {
    }
}

declare class HamburgerMenuComponent {
    private hamburgerMenuService;
    constructor(hamburgerMenuService: HamburgerMenuService);
    toggle(): void;
    get isExpanded(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<HamburgerMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HamburgerMenuComponent, "cx-hamburger-menu", never, {}, {}, never, never, true, never>;
}

declare class HamburgerMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<HamburgerMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HamburgerMenuModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof HamburgerMenuComponent], [typeof HamburgerMenuComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HamburgerMenuModule>;
}

declare class MyCouponsComponentService {
    protected routingService: RoutingService;
    protected translation: TranslationService;
    sortLabels: Observable<{
        byStartDateAsc: string;
        byStartDateDesc: string;
        byEndDateAsc: string;
        byEndDateDesc: string;
    }>;
    protected readonly RELEVANCE = ":relevance";
    protected readonly CUSTOMER_COUPON_CODE = ":customerCouponCode:";
    constructor(routingService: RoutingService, translation: TranslationService);
    launchSearchPage(coupon: CustomerCoupon): void;
    private buildSearchParam;
    getSortLabels(): Observable<{
        byStartDateAsc: string;
        byStartDateDesc: string;
        byEndDateAsc: string;
        byEndDateDesc: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyCouponsComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MyCouponsComponentService>;
}

declare class MyCouponsComponent implements OnInit, OnDestroy {
    protected couponService: CustomerCouponService;
    protected myCouponsComponentService: MyCouponsComponentService;
    couponResult$: Observable<CustomerCouponSearchResult>;
    couponsLoading$: Observable<boolean>;
    couponSubscriptionLoading$: Observable<boolean>;
    iconTypes: typeof ICON_TYPE$1;
    private subscriptions;
    private PAGE_SIZE;
    private sortMapping;
    sort: string;
    sortOptions: {
        code: string;
        selected: boolean;
    }[];
    pagination: PaginationModel;
    sortLabels: Observable<{
        byStartDateAsc: string;
        byStartDateDesc: string;
        byEndDateAsc: string;
        byEndDateDesc: string;
    }>;
    protected launchDialogService: LaunchDialogService;
    constructor(couponService: CustomerCouponService, myCouponsComponentService: MyCouponsComponentService);
    ngOnInit(): void;
    getHashStr(): string;
    private subscriptionFail;
    sortChange(sort: string): void;
    pageChange(page: number): void;
    notificationChange({ couponId, notification, }: {
        couponId: string;
        notification: boolean;
    }): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyCouponsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyCouponsComponent, "cx-my-coupons", never, {}, {}, never, never, true, never>;
}

/**
 * Renders translated form errors for a given form control, based on its `errors` property.
 *
 * The translation key consists of the optional input `prefix`
 * concatenated with the error key.
 *
 * And the translation params object consist of the error details
 * (if only it's an object) merged with the optional input object `translationParams`.
 */
declare class FormErrorsComponent implements DoCheck {
    protected ChangeDetectionRef: ChangeDetectorRef;
    protected elementRef: ElementRef<any> | null;
    protected ariaLiveToken: string | null;
    constructor(ChangeDetectionRef: ChangeDetectorRef);
    _control: UntypedFormControl | AbstractControl;
    /**
     * Emits an array of errors, each represented by a tuple:
     * the error key and error details.
     */
    errorsDetails$: Observable<Array<[string, string | boolean]>>;
    /**
     * Prefix prepended to the translation key.
     */
    prefix: string;
    /**
     * Fallback prefix prepended to the translation key.
     */
    fallbackPrefix: string;
    /**
     * Translation params to enrich the error details object.
     */
    translationParams: {
        [key: string]: string | null;
    };
    set control(control: AbstractControl | UntypedFormControl | null);
    get control(): UntypedFormControl | AbstractControl;
    private previousTouchedState;
    ngDoCheck(): void;
    /**
     * Returns translation params composed of
     * the argument `errorDetails` (if only is an object) merged with
     * the component input object `translationParams`.
     *
     * In case of a conflicting object key, the value from
     * `translationParams` takes precedence.
     */
    getTranslationParams(errorDetails?: any): object;
    get invalid(): boolean;
    get dirty(): boolean;
    get touched(): boolean;
    get hidden(): boolean;
    role: null;
    ariaLive: string;
    atomic: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormErrorsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormErrorsComponent, "cx-form-errors", never, { "prefix": { "alias": "prefix"; "required": false; }; "fallbackPrefix": { "alias": "fallbackPrefix"; "required": false; }; "translationParams": { "alias": "translationParams"; "required": false; }; "control": { "alias": "control"; "required": false; }; }, {}, never, never, true, never>;
}

declare class FormErrorsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FormErrorsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FormErrorsModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof i3.FeaturesConfigModule, typeof FormErrorsComponent], [typeof FormErrorsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FormErrorsModule>;
}

/**
 * Renders translated form required asteriks component.
 */
declare class FormRequiredAsterisksComponent {
    /**
     * Component Title translation (defaulted to common.required)
     */
    titleTranslation?: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormRequiredAsterisksComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormRequiredAsterisksComponent, "cx-form-required-asterisks", never, { "titleTranslation": { "alias": "titleTranslation"; "required": false; }; }, {}, never, never, true, never>;
}

type PopoverPosition = 'auto' | 'top' | 'bottom' | 'left' | 'right' | 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right' | 'left-top' | 'left-bottom' | 'right-top' | 'right-bottom';
type PopoverPositionArray = PopoverPosition | Array<PopoverPosition> | string;
declare enum PopoverEvent {
    INSIDE_CLICK = "insideClick",
    OUTSIDE_CLICK = "outsideClick",
    ESCAPE_KEYDOWN = "escapeKeydown",
    CLOSE_BUTTON_CLICK = "closeButtonClick",
    CLOSE_BUTTON_KEYDOWN = "closeButtonKeydown",
    ROUTE_CHANGE = "routeChange",
    OPEN = "open",
    OPEN_BY_KEYBOARD = "openByKeyboard"
}
interface PopoverOptions {
    /**
     * The preferred placement of the popover. Default popover position is 'top'.
     *
     *  Allowed popover positions: 'auto', 'top', 'bottom', 'left', 'right',
     * 'top-left', 'top-right', 'bottom-left', 'bottom-right',
     * 'left-top', 'left-bottom', 'right-top', 'right-bottom'.
     */
    placement?: PopoverPosition;
    /**
     * Flag used to define if popover should look for the best placement
     * in case if there is not enough space in viewport for preferred position.
     *
     * By default this property is set to `true`.
     *
     * Value of this flag is omitted if preferred position is set to `auto`.
     */
    autoPositioning?: boolean;
    /**
     * Flag used to prevent firing popover open function.
     */
    disable?: boolean;
    /**
     * Custom class name passed to popover component.
     *
     * If this property is not set the default popover class is `cx-popover`.
     */
    class?: string;
    /**
     * Flag used to hide close button in popover component.
     */
    displayCloseButton?: boolean;
    /**
     * Append popover component into 'body' selector.
     */
    appendToBody?: boolean;
    /**
     * Flag indicates if popover should be re-positioned on scroll event.
     */
    positionOnScroll?: boolean;
}

interface UIPositionRectangle {
    bottom: number;
    height: number;
    left: number;
    right: number;
    top: number;
    width: number;
}
declare class PositioningService {
    protected winRef: WindowRef;
    constructor(winRef: WindowRef);
    protected get allowedPlacements(): Array<PopoverPositionArray>;
    protected get placementSeparator(): RegExp;
    protected get window(): Window | undefined;
    protected get document(): Document;
    protected getAllStyles(element: HTMLElement): CSSStyleDeclaration | undefined;
    protected getPositionStyleProperty(element: HTMLElement): string | undefined;
    protected isStaticPositioned(element: HTMLElement): boolean;
    protected offsetParent(element: HTMLElement): HTMLElement;
    protected position(element: HTMLElement, round?: boolean): UIPositionRectangle;
    protected offset(element: HTMLElement, round?: boolean): UIPositionRectangle;
    protected _positionElements(hostElement: HTMLElement, targetElement: HTMLElement, placement: string, appendToBody?: boolean): boolean;
    positionElements(hostElement: HTMLElement, targetElement: HTMLElement, placement: string | PopoverPosition | PopoverPositionArray, appendToBody?: boolean): PopoverPosition;
    getPositioningClass(position?: PopoverPosition, autoPositioning?: boolean): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PositioningService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PositioningService>;
}

declare class PopoverComponent implements OnInit, OnDestroy, AfterViewChecked {
    protected positioningService: PositioningService;
    protected winRef: WindowRef;
    protected changeDetectionRef: ChangeDetectorRef;
    protected renderer: Renderer2;
    protected router: Router;
    /**
     * String or template to be rendered inside popover wrapper component.
     */
    content: string | TemplateRef<any>;
    /**
     * Element which triggers displaying popover component.
     * This property is needed to calculate valid position for popover.
     */
    triggerElement: ElementRef;
    /**
     * Current initiated popover instance.
     */
    popoverInstance: ComponentRef<PopoverComponent>;
    /**
     * Flag which informs positioning service if popover component
     * should be appended to body. Otherwise popover is displayed right after
     * trigger element in DOM.
     */
    appendToBody?: boolean;
    /**
     * The preferred placement of the popover. Default popover position is 'top'.
     *
     * Allowed popover positions: 'auto', 'top', 'bottom', 'left', 'right',
     * 'top-left', 'top-right', 'bottom-left', 'bottom-right',
     * 'left-top', 'left-bottom', 'right-top', 'right-bottom'.
     */
    position?: PopoverPosition;
    /**
     * Flag used to define if popover should look for the best placement
     * in case if there is not enough space in viewport for preferred position.
     *
     * By default this property is set to `true`.
     *
     * Value of this flag is omitted if preferred position is set to `auto`.
     */
    autoPositioning?: boolean;
    /**
     * Custom class name passed to popover component.
     *
     * If this property is not set the default popover class is `cx-popover`.
     */
    customClass?: string;
    /**
     * Flag used to show/hide close button in popover component.
     */
    displayCloseButton?: boolean;
    /**
     * After popover component is initialized position needs to be changing dynamically
     * in case if any viewport changes happened.
     */
    resizeSub: Subscription;
    /**
     * After popover component is initialized popover should be closed in case
     * if current route has been changed.
     */
    routeChangeSub: Subscription;
    /**
     * Class name generated by positioning service indicating position of popover.
     */
    popoverClass: PopoverPosition;
    /**
     * Configuration for a11y improvements.
     */
    focusConfig: FocusConfig;
    /**
     * Flag indicates if popover should be re-positioned on scroll event.
     */
    positionOnScroll?: boolean;
    /**
     * Icon types for close button icon.
     */
    iconTypes: typeof ICON_TYPE$1;
    /**
     * Subject which emits specific type of `PopoverEvent`.
     */
    eventSubject: Subject<PopoverEvent>;
    /**
     * Scroll event unlistener.
     */
    scrollEventUnlistener: () => void;
    /**
     * Binding class name property.
     */
    baseClass: string;
    /**
     * Listens for click inside popover component wrapper.
     */
    insideClick(): void;
    /**
     * Listens for every document click and ignores clicks
     * inside component.
     */
    outsideClick(event: MouseEvent): void;
    /**
     * Listens for `escape` keydown event.
     */
    escapeKeydown(): void;
    protected isClickedOnPopover(event: MouseEvent): any;
    protected isClickedOnDirective(event: MouseEvent): any;
    /**
     * Emits close event trigger.
     */
    close(event: MouseEvent | KeyboardEvent | Event): void;
    /**
     * Method uses `Renderer2` service to listen window scroll event.
     *
     * Registered only if property `positionOnScroll` is set to `true`.
     */
    triggerScrollEvent(): void;
    /**
     * Method uses positioning service calculation and based on that
     * updates class name for popover component instance.
     */
    positionPopover(): void;
    ngOnInit(): void;
    /**
     * indicates if passed content is a TemplateRef or string.
     */
    isTemplate(content: string | TemplateRef<any>): content is TemplateRef<any>;
    isString(content: string | TemplateRef<any>): content is string;
    ngAfterViewChecked(): void;
    ngOnDestroy(): void;
    constructor(positioningService: PositioningService, winRef: WindowRef, changeDetectionRef: ChangeDetectorRef, renderer: Renderer2, router: Router);
    static ɵfac: i0.ɵɵFactoryDeclaration<PopoverComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PopoverComponent, "cx-popover", never, {}, {}, never, never, true, never>;
}

declare class PopoverService {
    /**
     * For a11y improvements method returns different `FocusConfig`
     * based on which event popover was triggered.
     */
    getFocusConfig(event: PopoverEvent, appendToBody: boolean): FocusConfig;
    setFocusOnElement(element: ElementRef): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PopoverService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PopoverService>;
}

/**
 * Directive to bind popover with any DOM element.
 */
declare class PopoverDirective implements OnInit {
    protected element: ElementRef;
    protected viewContainer: ViewContainerRef;
    protected componentFactoryResolver: ComponentFactoryResolver;
    protected renderer: Renderer2;
    protected changeDetectorRef: ChangeDetectorRef;
    protected popoverService: PopoverService;
    protected winRef: WindowRef;
    /**
     * Template or string to be rendered inside popover wrapper component.
     */
    cxPopover: string | TemplateRef<any>;
    /**
     * Options set for popover component.
     */
    cxPopoverOptions?: PopoverOptions;
    /**
     * An event emitted when the popover is opened.
     */
    openPopover: EventEmitter<void>;
    /**
     * An event emitted when the popover is closed.
     */
    closePopover: EventEmitter<void>;
    /**
     * Flag used to inform about current state of popover component.
     * Popover is closed by default, so value is set to false.
     */
    isOpen: boolean;
    /**
     * Popover component instance.
     */
    popoverContainer: ComponentRef<PopoverComponent>;
    /**
     * Configuration for a11y improvements.
     */
    focusConfig: FocusConfig;
    /**
     * Subject which emits specific type of `PopoverEvent`.
     */
    eventSubject: Subject<PopoverEvent>;
    /**
     * Listen events fired on element binded to popover directive.
     *
     * Based on event type some a11y improvements can be made.
     * For example if popover was opened by `space` or `enter` key
     * dedicated `FocusConfig` can be set to autofocus first
     * focusable element in popover container.
     */
    handlePress(event: KeyboardEvent): void;
    handleTab(): void;
    handleEscape(): void;
    handleClick(event: MouseEvent): void;
    protected openTriggerEvents: PopoverEvent[];
    protected focusPopoverTriggerEvents: PopoverEvent[];
    protected closeTriggerEvents: PopoverEvent[];
    protected focusDirectiveTriggerEvents: PopoverEvent[];
    /**
     * Method performs open action for popover component.
     */
    open(event: PopoverEvent): void;
    /**
     * Method performs close action for popover component.
     */
    close(): void;
    /**
     * Method subscribes for events emitted by popover component
     * and based on event performs specific action.
     */
    handlePopoverEvents(): void;
    /**
     * Method creates instance and pass parameters to popover component.
     */
    renderPopover(): void;
    ngOnInit(): void;
    constructor(element: ElementRef, viewContainer: ViewContainerRef, componentFactoryResolver: ComponentFactoryResolver, renderer: Renderer2, changeDetectorRef: ChangeDetectorRef, popoverService: PopoverService, winRef: WindowRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<PopoverDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PopoverDirective, "[cxPopover]", never, { "cxPopover": { "alias": "cxPopover"; "required": false; }; "cxPopoverOptions": { "alias": "cxPopoverOptions"; "required": false; }; }, { "openPopover": "openPopover"; "closePopover": "closePopover"; }, never, never, true, never>;
}

declare class PopoverModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PopoverModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PopoverModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof KeyboardFocusModule, typeof IconModule, typeof i3.I18nModule, typeof PopoverDirective, typeof PopoverComponent], [typeof PopoverDirective, typeof PopoverComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PopoverModule>;
}

declare class TruncateTextPopoverComponent {
    /**
     * String to be rendered inside popover wrapper component.
     */
    content: string;
    /**
     * The maximum length of the characters after which the text will be truncated
     */
    charactersLimit: number;
    customClass?: string;
    get isTruncated(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<TruncateTextPopoverComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TruncateTextPopoverComponent, "cx-truncate-text-popover", never, { "content": { "alias": "content"; "required": false; }; "charactersLimit": { "alias": "charactersLimit"; "required": false; }; "customClass": { "alias": "customClass"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TruncatePipe implements PipeTransform {
    /**
     * example usage {{ exampleString | cxTruncate: [1, ''] }}
     */
    transform(value: string, args?: [number, string?]): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TruncatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<TruncatePipe, "cxTruncate", true>;
}

declare class TruncateTextPopoverModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TruncateTextPopoverModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TruncateTextPopoverModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof PopoverModule, typeof TruncateTextPopoverComponent, typeof TruncatePipe], [typeof TruncateTextPopoverComponent, typeof TruncatePipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TruncateTextPopoverModule>;
}

interface CardAction {
    event: string;
    name: string;
}
interface CardLinkAction {
    link: string;
    name: string;
    ariaLabel?: string;
    target?: string;
}
interface Card {
    header?: string;
    title?: string;
    textBold?: string;
    text?: Array<string>;
    paragraphs?: Array<{
        title?: string;
        text?: Array<string>;
    }>;
    img?: string;
    imgLabel?: string;
    actions?: Array<CardAction | CardLinkAction>;
    deleteMsg?: string;
    label?: string;
    role?: string;
    customClass?: string;
}
declare class CardComponent implements OnInit {
    iconTypes: typeof ICON_TYPE$1;
    deleteCard: EventEmitter<number>;
    setDefaultCard: EventEmitter<number>;
    sendCard: EventEmitter<number>;
    editCard: EventEmitter<number>;
    cancelCard: EventEmitter<number>;
    border: boolean;
    editMode: boolean;
    isDefault: boolean;
    content: Card | null;
    fitToContainer: boolean;
    truncateText: boolean;
    truncateParagraphText: boolean;
    charactersLimit: number;
    index: number;
    role?: string;
    setEditMode(): void;
    cancelEdit(): void;
    delete(): void;
    setDefault(): void;
    send(): void;
    edit(): void;
    isCardAction(action: CardAction | CardLinkAction): action is CardAction;
    isCardLinkAction(action: CardAction | CardLinkAction): action is CardLinkAction;
    trackByIndex(index: number): number;
    constructor();
    ngOnInit(): void;
    protected get isHeaderVisible(): boolean;
    /**
     * ariaDescribedBy: Computes the value for the 'aria-describedby' attribute.
     * If `content` has a `title`, it returns a string including the title and container IDs, with index if available.
     * If no title, it returns only the container ID with the index if available.
     *
     * @returns {string} The 'aria-describedby' value.
     */
    protected get ariaDescribedBy(): string;
    /**
     * getLabel: Computes a label string by concatenating the provided prefix with the index.
     * If the index is greater than or equal to 0, it appends the index to the prefix; otherwise, it just returns the prefix.
     *
     * @param {string} prefix - The string to prefix to the label.
     * @returns {string} The computed label, including the index if it's available.
     */
    protected getLabel(prefix: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardComponent, "cx-card", never, { "border": { "alias": "border"; "required": false; }; "editMode": { "alias": "editMode"; "required": false; }; "isDefault": { "alias": "isDefault"; "required": false; }; "content": { "alias": "content"; "required": false; }; "fitToContainer": { "alias": "fitToContainer"; "required": false; }; "truncateText": { "alias": "truncateText"; "required": false; }; "truncateParagraphText": { "alias": "truncateParagraphText"; "required": false; }; "charactersLimit": { "alias": "charactersLimit"; "required": false; }; "index": { "alias": "index"; "required": false; }; "role": { "alias": "role"; "required": false; }; }, { "deleteCard": "deleteCard"; "setDefaultCard": "setDefaultCard"; "sendCard": "sendCard"; "editCard": "editCard"; "cancelCard": "cancelCard"; }, never, ["[label_container_bottom]"], true, never>;
}

declare class CardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CardModule, never, [typeof i1.CommonModule, typeof AtMessageModule, typeof i3.I18nModule, typeof IconModule, typeof TruncateTextPopoverModule, typeof KeyboardFocusModule, typeof i3.FeaturesConfigModule, typeof GenericLinkModule, typeof CardComponent], [typeof CardComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CardModule>;
}

/**
 * Represents a page item for a pagination system. This is used
 * to store the model of each page.
 */
interface PaginationItem {
    label?: string;
    type?: PaginationItemType;
    /** The number is used when the type is {@link PaginationItemType.PAGE} */
    number?: number;
}
/**
 * The item type is used to add semantic structure to the
 * PaginationItem, so that the UI understands the usage.
 */
declare enum PaginationItemType {
    GAP = "gap",
    FIRST = "first",
    LAST = "last",
    PREVIOUS = "previous",
    NEXT = "next",
    START = "start",
    END = "end",
    PAGE = "page"
}
interface PaginationOptions {
    /**
     * The range of direct accessible pages in the pagination.
     *
     * `« 4 (5) 6 »`
     *
     * Defaults to 3.
     */
    rangeCount?: number;
    /** Adds a link to skip to the start of the pages, defaults to false. */
    addStart?: boolean;
    /** A link to skip to the end of the pages, defaults to false. */
    addEnd?: boolean;
    /** A link to the previous page, defaults to false. */
    addPrevious?: boolean;
    /** A link to the previous page, defaults to false. */
    addNext?: boolean;
    navigationPosition?: PaginationNavigationPosition;
    /** A link to the first page can be added in case it is not included already, defaults to false. */
    addFirst?: boolean;
    /** A link to the last page can be added in case it is not included already, defaults to false. */
    addLast?: boolean;
    /**
     * Adds a gap before and after the pages. to visualize hidden pages. Defaults to false.
     *
     * `1 ...  4 (5) 6 ... 18`
     *
     * Defaults to false.
     */
    addDots?: boolean;
    /**
     * If the page dots only represents a single page, we rather add the page
     * as this would take the same amount of space. Some UX might want to use
     * the dots for consistency reasons, which why this option is configurable.
     *
     * This typically happens on the 4th page (in case the range is 3):
     * Instead of having:
     *
     *  `1 ...  3 (4) 5`
     *
     * we'd have
     *
     * `1 2 3 (4) 5`.
     *
     * Defaults to false.
     */
    substituteDotsForSingularPage?: boolean;
    /** Custom label for the start link, defaults to `«`. */
    startLabel?: string;
    /** Custom label for the previous link, defaults to `‹`. */
    previousLabel?: string;
    /** Custom label for the next link, defaults to `›`. */
    nextLabel?: string;
    /** Custom label for the end link, defaults to `»`. */
    endLabel?: string;
    /** Custom label for the dots, defaults to `...`. */
    dotsLabel?: string;
}
declare enum PaginationNavigationPosition {
    ASIDE = "aside",
    BEFORE = "before",
    AFTER = "after"
}

declare abstract class PaginationConfig {
    pagination?: PaginationOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<PaginationConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PaginationConfig>;
}
declare module '@spartacus/core' {
    interface Config extends PaginationConfig {
    }
}

/**
 * Builds a pagination structures based on a pageCount and current page number.
 * There are various {@link PaginationConfig} options which can be used to configure
 * the behavior of the build. Alternatively, CSS can be used to further customize
 * the pagination.
 *
 * Examples:
 * The full blown pagination items contain the follow elements:
 *
 * `« ‹ 1 ... 4 (5) 6 ... 9 › »`
 *
 * This includes pagination items to the following pages:
 * - start page
 * - previous page
 * - first page
 * - page range
 * - last page
 * - next page
 * - end page
 *
 * All of those links are configurable, including the size of the page range.
 * The current page will always be centered in the page range to provide direct access
 * to the previous and next page.
 */
declare class PaginationBuilder {
    protected paginationConfig: PaginationConfig;
    constructor(paginationConfig: PaginationConfig);
    /**
     * Builds a list of `PaginationItem`. The give pageCount and current are used
     * to build out the full pagination. There are various {@link PaginationConfig} options
     * which can be used to configure the behavior of the build. Alternatively, CSS
     * can be used to further specialize visibility of the pagination.
     *
     * @param pageCount The total number of pages
     * @param current The current page number, 0-index based
     * @returns An array of `PaginationItem`
     */
    paginate(pageCount: number, current: number): PaginationItem[];
    /**
     * Returns the current page with surrounding pages (based on the `config.rangeCount`).
     * The current page is always centered to provide direct access to the previous and next page.
     *
     * @param pages The list of page items that is used to amend
     * @param pageCount The total number of pages
     * @param current The current page number, 0-index based
     */
    protected addPages(pages: PaginationItem[], pageCount: number, current: number): void;
    /**
     * Adds dots before and after the given pages, if configured (defaults to true).
     * If the dots only represent a single page, the page number is added instead of
     * the dots, unless the configuration requires dots always.
     *
     * @param pages The list of page items that is used to amend
     * @param pageCount The total number of pages
     */
    protected addDots(pages: PaginationItem[], pageCount: number): void;
    /**
     * Helper method for addDots() whether to add the first gap.
     */
    protected addFirstGapToDots(pages: PaginationItem[]): ({
        label: string | undefined;
        type: PaginationItemType;
    } & {
        number: number;
    })[];
    /**
     * Helper method for addDots() whether to add the last gap.
     */
    protected addLastGapToDots(pages: PaginationItem[], pageCount: number): ({
        label: string | undefined;
        type: PaginationItemType;
    } & {
        number: number;
    })[];
    /**
     * Add links to the first and last page, if configured to do so.
     *
     * @param pages The list of page items that is used to amend
     * @param pageCount The total number of pages
     *
     */
    protected addFirstLast(pages: PaginationItem[], pageCount: number): void;
    /**
     * Add links to the start, previous, next and last page, if configured to do so.
     * The order of the links can be configured by using the {@link PaginationConfig},
     * using the `PaginationNavigationPosition` (`BEFORE` or `AFTER`).
     * The `PaginationNavigationPosition` allows for 3 flavours:
     *
     * - by default the pagination starts with start and previous and ends with the next and end links
     * - BEFORE – all navigation links are added in the front of the pagination list
     * - AFTER – all navigation links are pushed to the end of the pagination list
     *
     * @param pages The list of page items that is used to amend
     * @param pageCount The total number of pages
     * @param current The current page number, 0-index based
     *
     */
    protected addNavigation(pages: PaginationItem[], pageCount: number, current: number): void;
    /**
     * Returns the start and previous links, if applicable.
     */
    protected getBeforeLinks(current: number): PaginationItem[];
    /**
     * Returns the next and end links, if applicable.
     */
    protected getAfterLinks(pageCount: number, current: number): PaginationItem[];
    /**
     * Resolves the first page of the range we need to build.
     * This is the page that is leading up to the range of the
     * current page.
     *
     * @param pageCount The total number of pages.
     * @param current The current page number, 0-index based.
     */
    protected getStartOfRange(pageCount: number, current: number): number | null;
    /**
     * Returns the pagination configuration. The configuration is driven by the
     * (default) application configuration.
     *
     * The default application is limited to adding the start and end link:
     * ```ts
     *   addStart: true,
     *   addEnd: true
     * ```
     *
     * The application configuration is however merged into the following static configuration:
     * ```ts
     * {
     *   rangeCount: 3,
     *   dotsLabel: '...',
     *   startLabel: '«',
     *   previousLabel: '‹',
     *   nextLabel: '›',
     *   endLabel: '»'
     * }
     * ```
     */
    protected get config(): PaginationOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<PaginationBuilder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PaginationBuilder>;
}

/**
 * The `PaginationComponent` is a generic component that is used for
 * all lists in Spartacus that require pagination. The component supports
 * all common features, which can be configured or hidden by CSS.
 */
declare class PaginationComponent {
    private paginationBuilder;
    private activatedRoute;
    /** The (optional) pageRoute used for the anchor links created in the pagination   */
    pageRoute: string;
    /** The (optional) query parameter which is added to the page route.  */
    queryParam: string;
    /**
     * Whenever there's a default page specified, the routing logic
     * will omit the page number in routeLink or parameters.
     */
    defaultPage: number | undefined;
    private _pagination;
    get pagination(): PaginationModel;
    set pagination(value: PaginationModel | undefined);
    /**
     * If more than one pagination is present on a page, a unique id should be set for each instance.
     * This ensures the focus can be preserved after navigating to a different page.
     */
    paginationID: string;
    viewPageEvent: EventEmitter<number>;
    pages: PaginationItem[];
    translationService: TranslationService;
    constructor(paginationBuilder: PaginationBuilder, activatedRoute: ActivatedRoute);
    protected render(pagination: PaginationModel): void;
    /**
     * Format aria-label based on pagination item type.
     *
     * @param item PaginationItem
     * @returns Observable
     */
    getAriaLabel$(item: PaginationItem): Observable<string>;
    /**
     * Indicates whether the given item is the current item.
     *
     * @param item PaginationItem
     * @returns boolean
     */
    isCurrent(item: PaginationItem): boolean;
    /**
     * Indicates whether the pagination item is inactive. This is used
     * to disabled a link or set the tabindex to `-1`.
     *
     * Defaults to true
     *
     * @param item PaginationItem
     * @returns returns -1 in case of a disabled
     */
    isInactive(item: PaginationItem): boolean;
    getQueryParams(item: PaginationItem): Params;
    pageChange(page: PaginationItem): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PaginationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PaginationComponent, "cx-pagination", never, { "pageRoute": { "alias": "pageRoute"; "required": false; }; "queryParam": { "alias": "queryParam"; "required": false; }; "defaultPage": { "alias": "defaultPage"; "required": false; }; "pagination": { "alias": "pagination"; "required": false; }; "paginationID": { "alias": "paginationID"; "required": false; }; }, { "viewPageEvent": "viewPageEvent"; }, never, never, true, never>;
}

declare class PaginationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PaginationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PaginationModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof i3.I18nModule, typeof i3.FeaturesConfigModule, typeof KeyboardFocusModule, typeof PaginationComponent], [typeof PaginationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PaginationModule>;
}

declare class NgSelectA11yDirective implements AfterViewInit {
    private renderer;
    private elementRef;
    /**
     * Use directive to bind aria attribute to inner element of ng-select
     * Angular component for accessibility compliance. If ng-select controls itself
     * ariaControls is not needed, instead bind a specific id to the <ng-select> element.
     */
    cxNgSelectA11y: {
        ariaLabel?: string;
        ariaControls?: string;
    };
    protected translationService: TranslationService;
    protected domSanitizer: DomSanitizer;
    protected selectComponent: NgSelectComponent;
    protected destroyRef: DestroyRef;
    private featureConfigService;
    protected platformId: Object;
    protected selectObserver: MutationObserver | null;
    protected breakpointService: BreakpointService | null;
    /**
     * When we inside a combo box using JAWS screen reader and press escape key
     * an escape keyboard event doesn't get fired, instead an AltLeft is fired.
     */
    onKeyUp(event: KeyboardEvent): void;
    onEscape(): void;
    /**
     * Keystrokes inside ng-select are dropdown navigation, not form filling,
     * so the focus outline must remain visible. `VisibleFocusDirective` treats
     * any `<input>` keystroke as form filling and adds a `mouse-focus` class
     * (which hides the outline) when the dropdown was opened with a mouse.
     * We defer to a microtask so this runs after the bubbled keydown has
     * reached `VisibleFocusDirective`, then clear the class on the closest
     * ancestor that has it.
     */
    onKeyDown(): void;
    constructor(renderer: Renderer2, elementRef: ElementRef);
    ngAfterViewInit(): void;
    vocalizeItemCount(): void;
    protected createItemCountSpan(): any;
    setInputValue(inputCombobox: HTMLElement): void;
    /**
     * Hides the input value from the screen reader and provides it as part of the aria-label instead.
     * This improves the screen reader output on mobile devices.
     */
    appendValueToAriaLabel(_changes: any, observer: MutationObserver, divCombobox: HTMLElement): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgSelectA11yDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgSelectA11yDirective, "[cxNgSelectA11y]", never, { "cxNgSelectA11y": { "alias": "cxNgSelectA11y"; "required": false; }; }, {}, never, never, true, never>;
}

declare class NgSelectA11yModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NgSelectA11yModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NgSelectA11yModule, never, [typeof NgSelectA11yDirective], [typeof NgSelectA11yDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NgSelectA11yModule>;
}

declare class SortingComponent {
    ngSelectComponent: i0.Signal<NgSelectComponent>;
    sortOptions: SortModel[] | undefined;
    ariaControls: string;
    ariaLabel: string | undefined;
    selectedOption: string | undefined;
    placeholder: string;
    sortLabels: {
        [code: string]: string;
    } | null;
    sortListEvent: EventEmitter<string>;
    private featureConfigService;
    constructor();
    sortList(sortCode: string): void;
    get selectedLabel(): string | undefined;
    protected focusCombobox(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SortingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SortingComponent, "cx-sorting", never, { "sortOptions": { "alias": "sortOptions"; "required": false; }; "ariaControls": { "alias": "ariaControls"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "selectedOption": { "alias": "selectedOption"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "sortLabels": { "alias": "sortLabels"; "required": false; }; }, { "sortListEvent": "sortListEvent"; }, never, never, true, never>;
}

declare class SortingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SortingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SortingModule, never, [typeof i1.CommonModule, typeof i2$3.NgSelectModule, typeof i2$2.FormsModule, typeof NgSelectA11yModule, typeof i3.I18nModule, typeof SortingComponent], [typeof SortingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SortingModule>;
}

declare class TotalComponent {
    private _pagination;
    get pagination(): PaginationModel;
    set pagination(paginationModel: PaginationModel | undefined);
    /**
     * Current page, starting form page 0
     * */
    get currentPage(): number;
    get pageSize(): number;
    get totalResults(): number;
    get fromItem(): number;
    get toItem(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<TotalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TotalComponent, "cx-total", never, { "pagination": { "alias": "pagination"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TotalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TotalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TotalModule, never, [typeof i1.CommonModule, typeof i2$2.FormsModule, typeof i3.I18nModule, typeof TotalComponent], [typeof TotalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TotalModule>;
}

declare class ListNavigationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ListNavigationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ListNavigationModule, never, [typeof i1.CommonModule, typeof i2$3.NgSelectModule, typeof i2$2.FormsModule, typeof i2$2.ReactiveFormsModule, typeof IconModule, typeof PaginationModule, typeof SortingModule, typeof TotalModule], [typeof SortingComponent, typeof PaginationComponent, typeof TotalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ListNavigationModule>;
}

declare class CouponCardComponent {
    protected myCouponsComponentService: MyCouponsComponentService;
    protected launchDialogService: LaunchDialogService;
    protected vcr: ViewContainerRef;
    coupon: CustomerCoupon;
    couponSubscriptionLoading$: Observable<boolean>;
    notificationChanged: EventEmitter<{
        couponId: string;
        notification: boolean;
    }>;
    element: ElementRef;
    constructor(myCouponsComponentService: MyCouponsComponentService, launchDialogService: LaunchDialogService, vcr: ViewContainerRef);
    onSubscriptionChange(): void;
    readMore(): void;
    findProducts(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CouponCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CouponCardComponent, "cx-coupon-card", never, { "coupon": { "alias": "coupon"; "required": false; }; "couponSubscriptionLoading$": { "alias": "couponSubscriptionLoading$"; "required": false; }; }, { "notificationChanged": "notificationChanged"; }, never, never, true, never>;
}

declare class CouponDialogComponent implements OnDestroy, OnInit {
    protected launchDialogService: LaunchDialogService;
    protected el: ElementRef;
    private subscription;
    iconTypes: typeof ICON_TYPE$1;
    coupon: CustomerCoupon;
    focusConfig: FocusConfig;
    handleClick(event: UIEvent): void;
    constructor(launchDialogService: LaunchDialogService, el: ElementRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    close(reason?: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CouponDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CouponDialogComponent, "cx-coupon-dialog", never, {}, {}, never, never, true, never>;
}

declare class CouponClaimComponent implements OnInit, OnDestroy {
    protected couponService: CustomerCouponService;
    protected routingService: RoutingService;
    protected messageService: GlobalMessageService;
    subscription: Subscription;
    constructor(couponService: CustomerCouponService, routingService: RoutingService, messageService: GlobalMessageService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CouponClaimComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CouponClaimComponent, "cx-coupon-claim", never, {}, {}, never, never, true, never>;
}

declare class ClaimDialogComponent implements OnDestroy, OnInit {
    private subscription;
    iconTypes: typeof ICON_TYPE$1;
    protected pageSize: number;
    couponCode: string;
    focusConfig: FocusConfig;
    form: FormGroup;
    protected couponService: CustomerCouponService;
    protected routingService: RoutingService;
    protected messageService: GlobalMessageService;
    protected launchDialogService: LaunchDialogService;
    ngOnInit(): void;
    onSubmit(): void;
    ngOnDestroy(): void;
    close(reason?: any): void;
    cancelEdit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClaimDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClaimDialogComponent, "cx-claim-dialog", never, {}, {}, never, never, true, never>;
}

declare class MyCouponsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MyCouponsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MyCouponsModule, never, [typeof i1.CommonModule, typeof i2$2.ReactiveFormsModule, typeof FormErrorsModule, typeof FormRequiredAsterisksComponent, typeof CardModule, typeof SpinnerModule, typeof i3.I18nModule, typeof i2$1.RouterModule, typeof i3.UrlModule, typeof IconModule, typeof ListNavigationModule, typeof i2$1.RouterModule, typeof KeyboardFocusModule, typeof i3.FeaturesConfigModule, typeof MyCouponsComponent, typeof CouponCardComponent, typeof CouponDialogComponent, typeof CouponClaimComponent, typeof ClaimDialogComponent], [typeof MyCouponsComponent, typeof CouponClaimComponent, typeof ClaimDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MyCouponsModule>;
}

interface ProductInterestSearchResultUI extends ProductInterestSearchResult {
    results?: (ProductInterestEntryRelation & {
        product$?: Observable<Product | undefined>;
    })[];
}
declare class MyInterestsComponent implements OnInit, OnDestroy {
    private productInterestService;
    private translationService;
    private productService;
    private globalMessageService;
    private DEFAULT_PAGE_SIZE;
    private sortMapping;
    private sortChanged;
    sort: string;
    sortOptions: {
        code: string;
        selected: boolean;
    }[];
    pagination: PaginationModel;
    interests$: Observable<ProductInterestSearchResultUI>;
    isRemoveDisabled$: Observable<boolean>;
    getInterestsloading$: Observable<boolean>;
    sortLabels: Observable<{
        byNameAsc: string;
        byNameDesc: string;
    }>;
    constructor(productInterestService: UserInterestsService, translationService: TranslationService, productService: ProductService, globalMessageService: GlobalMessageService);
    ngOnInit(): void;
    private getSortLabels;
    private getProduct;
    removeInterest(relation: ProductInterestEntryRelation & {
        product$?: Observable<Product | undefined>;
    }): void;
    sortChange(sort: string): void;
    pageChange(page: number): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyInterestsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyInterestsComponent, "cx-my-interests", never, {}, {}, never, never, true, never>;
}

declare class MyInterestsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MyInterestsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MyInterestsModule, never, [typeof AtMessageModule, typeof i1.CommonModule, typeof i3.I18nModule, typeof ListNavigationModule, typeof i3.I18nModule, typeof i3.UrlModule, typeof MediaModule, typeof SpinnerModule, typeof i2$1.RouterModule, typeof i3.FeaturesConfigModule, typeof MyInterestsComponent], [typeof MyInterestsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MyInterestsModule>;
}

declare class NotificationPreferenceComponent implements OnInit {
    private notificationPreferenceService;
    preferences$: Observable<NotificationPreference[]>;
    isLoading$: Observable<boolean>;
    protected preferences: NotificationPreference[];
    constructor(notificationPreferenceService: UserNotificationPreferenceService);
    ngOnInit(): void;
    updatePreference(preference: NotificationPreference): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationPreferenceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NotificationPreferenceComponent, "cx-notification-preference", never, {}, {}, never, never, true, never>;
}

declare class NotificationPreferenceModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationPreferenceModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NotificationPreferenceModule, never, [typeof i1.CommonModule, typeof SpinnerModule, typeof i3.I18nModule, typeof i3.FeaturesConfigModule, typeof i2$1.RouterModule, typeof NotificationPreferenceComponent], [typeof NotificationPreferenceComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NotificationPreferenceModule>;
}

declare class PaymentMethodsComponent implements OnInit {
    private userPaymentService;
    private translation;
    protected globalMessageService?: GlobalMessageService | undefined;
    paymentMethods$: Observable<PaymentDetails[]>;
    editCard: string | undefined;
    iconTypes: typeof ICON_TYPE$1;
    loading$: Observable<boolean>;
    constructor(userPaymentService: UserPaymentService, translation: TranslationService, globalMessageService?: GlobalMessageService | undefined);
    ngOnInit(): void;
    getCardContent({ defaultPayment, accountHolderName, expiryMonth, expiryYear, cardNumber, cardType, }: PaymentDetails): Observable<Card>;
    deletePaymentMethod(paymentMethod: PaymentDetails): void;
    setEdit(paymentMethod: PaymentDetails): void;
    cancelCard(): void;
    setDefaultPaymentMethod(paymentMethod: PaymentDetails): void;
    getCardIcon(code: string): string;
    getCardIconLabel(code: string | undefined): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PaymentMethodsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PaymentMethodsComponent, "cx-payment-methods", never, {}, {}, never, never, true, never>;
}

/**
 * Renders translated form required asteriks component.
 */
declare class FormRequiredLegendComponent {
    /**
     * Form Legend translation (defaulted to 'formLegend.required')
     */
    formLegendTranslation?: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormRequiredLegendComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormRequiredLegendComponent, "cx-form-required-legend", never, { "formLegendTranslation": { "alias": "formLegendTranslation"; "required": false; }; }, {}, never, never, true, never>;
}

declare class PaymentMethodsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PaymentMethodsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PaymentMethodsModule, never, [typeof i1.CommonModule, typeof CardModule, typeof SpinnerModule, typeof i3.I18nModule, typeof i3.FeaturesConfigModule, typeof FormRequiredLegendComponent, typeof PaymentMethodsComponent], [typeof PaymentMethodsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PaymentMethodsModule>;
}

declare class PageTitleComponent implements OnInit, AfterViewInit {
    component: CmsComponentData<CmsPageTitleComponent>;
    protected pageMetaService: PageMetaService;
    title$: Observable<string>;
    lastestTitle$: Observable<string>;
    constructor(component: CmsComponentData<CmsPageTitleComponent>, pageMetaService: PageMetaService);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    private setTitle;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageTitleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageTitleComponent, "cx-page-title", never, {}, {}, never, never, true, never>;
}

declare class BreadcrumbComponent extends PageTitleComponent implements OnInit {
    component: CmsComponentData<CmsBreadcrumbsComponent>;
    protected pageMetaService: PageMetaService;
    private translation;
    crumbs$: Observable<any[]>;
    protected router: Router;
    ariaLive$: Observable<boolean>;
    constructor(component: CmsComponentData<CmsBreadcrumbsComponent>, pageMetaService: PageMetaService, translation: TranslationService);
    ngOnInit(): void;
    private setCrumbs;
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbComponent, "cx-breadcrumb", never, {}, {}, never, never, true, never>;
}

declare class BreadcrumbModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BreadcrumbModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof i3.PageMetaModule, typeof i3.I18nModule, typeof i3.FeaturesConfigModule, typeof BreadcrumbComponent], [typeof BreadcrumbComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BreadcrumbModule>;
}

interface NavigationNode {
    title?: string;
    /** The url or route (parts) */
    url?: string | string[];
    target?: string | boolean;
    children?: Array<NavigationNode>;
    /**
     * Style classes can be added to the navigation nodes to enhance the UX.
     * The style classes are typically derived from the (CMS) backend and should
     * match an existing CSS selector.
     *
     * The styleClasses can contain a "list" of space separated style classes.
     */
    styleClasses?: string;
    /**
     * Style rules can be added to the navigation nodes to enhance the UX.
     * The style attributes are typically derived from the (CMS) backend.
     *
     * The styleAttributes can contain a "list" of semicolon separated style rules.
     */
    styleAttributes?: string;
}

declare class NavigationService {
    protected cmsService: CmsService;
    protected semanticPathService: SemanticPathService;
    constructor(cmsService: CmsService, semanticPathService: SemanticPathService);
    createNavigation(data$: Observable<CmsNavigationComponent>): Observable<NavigationNode>;
    /**
     * returns an observable with the `NavigationNode` for the given `CmsNavigationComponent`.
     * This function will load the navigation underlying entries and children if they haven't been
     * loaded so far.
     */
    getNavigationNode(data$: Observable<CmsNavigationComponent>): Observable<NavigationNode>;
    /**
     * Loads all navigation entry items' type and id. Dispatch action to load all these items
     * @param nodeData
     * @param root
     * @param itemsList
     */
    private loadNavigationEntryItems;
    /**
     * Create a new node tree for the view
     * @param nodeData
     * @param items
     */
    private populateNavigationNode;
    /**
     * The node link is driven by the first entry.
     */
    private populateLink;
    /**
     *
     * Gets the URL or link to a related item (category),
     * also taking into account content pages (contentPageLabelOrId)
     * and product pages (productCode)
     */
    protected getLink(item: any): string | string[] | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavigationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NavigationService>;
}

declare class CategoryNavigationComponent {
    protected componentData: CmsComponentData<CmsNavigationComponent>;
    protected service: NavigationService;
    node$: Observable<NavigationNode>;
    data$: Observable<CmsNavigationComponent>;
    constructor(componentData: CmsComponentData<CmsNavigationComponent>, service: NavigationService);
    static ɵfac: i0.ɵɵFactoryDeclaration<CategoryNavigationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CategoryNavigationComponent, "cx-category-navigation", never, {}, {}, never, never, true, never>;
}

declare class NavigationComponent {
    protected componentData: CmsComponentData<CmsNavigationComponent>;
    protected service: NavigationService;
    node$: Observable<NavigationNode>;
    name$: Observable<string | undefined>;
    styleClass$: Observable<string | undefined>;
    constructor(componentData: CmsComponentData<CmsNavigationComponent>, service: NavigationService);
    static ɵfac: i0.ɵɵFactoryDeclaration<NavigationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NavigationComponent, "cx-navigation", never, {}, {}, never, never, true, never>;
}

declare class NavigationUIComponent implements OnInit, OnDestroy {
    private router;
    private renderer;
    private elemRef;
    protected hamburgerMenuService: HamburgerMenuService;
    protected winRef: WindowRef;
    /**
     * The navigation node to render.
     */
    node: NavigationNode | null;
    /**
     * The number of child nodes that must be wrapped.
     */
    wrapAfter: number;
    /**
     * Flag indicates whether to reset the state of menu navigation (ie. Collapse all submenus) when the menu is closed.
     */
    resetMenuOnClose: boolean | undefined;
    /**
     * Include non intractable node titles within the tabbing order.
     */
    focusableNodeTitles: boolean;
    navAriaLabel: string | null | undefined;
    /**
     * the icon type that will be used for navigation nodes
     * with children.
     */
    iconType: typeof ICON_TYPE$1;
    /**
     * Indicates whether the navigation should support flyout.
     * If flyout is set to true, the
     * nested child navigation nodes will only appear on hover or focus.
     */
    flyout: boolean;
    isOpen: boolean;
    private openNodes;
    private subscriptions;
    private resize;
    protected arrowControls: Subject<KeyboardEvent>;
    onResize(): void;
    onArrow(e: KeyboardEvent): void;
    protected breakpointService: BreakpointService;
    isDesktop$: rxjs.Observable<boolean>;
    private featureConfigService;
    constructor(router: Router, renderer: Renderer2, elemRef: ElementRef, hamburgerMenuService: HamburgerMenuService, winRef: WindowRef);
    /**
     * During initialization of this component, we will check the resetMenuOnClose flag and attach a menu reset listener if needed.
     */
    ngOnInit(): void;
    /**
     * This method performs the action of resetting the menu (close all sub menus and return to main options)
     * when the menu is closed.
     */
    resetOnMenuCollapse(): void;
    closeIfClickedTheSameLink(navNode: NavigationNode): void;
    /**
     * This method performs the actions required to reset the state of the menu and reset any visual components.
     */
    reinitializeMenu(): void;
    protected ariaCollapseNodes(): void;
    toggleOpen(event: UIEvent): void;
    /**
     * Opens dropdown and starts keyboard navigation
     */
    onSpace(event: UIEvent): void;
    /**
     * Subscribes to arrow keys and enables navigation between dropdown items
     */
    setupArrowControls(): void;
    /**
     * Focuses on the first focusable element in the dropdown
     */
    focusOnNode(event: UIEvent): void;
    back(): void;
    clear(): void;
    onMouseEnter(event: MouseEvent): void;
    getTotalDepth(node: NavigationNode, depth?: number): number;
    getColumnCount(length: number): number;
    focusAfterPreviousClicked(event: MouseEvent): Document;
    ngOnDestroy(): void;
    private alignWrapperToRightIfStickOut;
    private alignWrappersToRightIfStickOut;
    private updateClasses;
    /**
     * Restores default tabbing order for non flyout navigation.
     */
    getTabIndex(node: NavigationNode, depth: number): 0 | -1;
    transformIntoValidID(string: string): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavigationUIComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NavigationUIComponent, "cx-navigation-ui", never, { "node": { "alias": "node"; "required": false; }; "wrapAfter": { "alias": "wrapAfter"; "required": false; }; "resetMenuOnClose": { "alias": "resetMenuOnClose"; "required": false; }; "focusableNodeTitles": { "alias": "focusableNodeTitles"; "required": false; }; "navAriaLabel": { "alias": "navAriaLabel"; "required": false; }; "flyout": { "alias": "flyout"; "required": false; }; "isOpen": { "alias": "isOpen"; "required": false; }; }, {}, never, never, true, never>;
}

declare class NavigationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NavigationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NavigationModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof IconModule, typeof GenericLinkModule, typeof i3.I18nModule, typeof i3.FeaturesConfigModule, typeof NavigationComponent, typeof NavigationUIComponent], [typeof NavigationComponent, typeof NavigationUIComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NavigationModule>;
}

declare class CategoryNavigationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CategoryNavigationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CategoryNavigationModule, never, [typeof i1.CommonModule, typeof NavigationModule, typeof i3.I18nModule, typeof CategoryNavigationComponent], [typeof CategoryNavigationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CategoryNavigationModule>;
}

declare class FooterNavigationComponent {
    protected componentData: CmsComponentData<CmsNavigationComponent>;
    protected service: NavigationService;
    node$: Observable<NavigationNode>;
    styleClass$: Observable<string | undefined>;
    constructor(componentData: CmsComponentData<CmsNavigationComponent>, service: NavigationService);
    static ɵfac: i0.ɵɵFactoryDeclaration<FooterNavigationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FooterNavigationComponent, "cx-footer-navigation", never, {}, {}, never, never, true, never>;
}

declare class FooterNavigationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FooterNavigationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FooterNavigationModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof NavigationModule, typeof GenericLinkModule, typeof i3.I18nModule, typeof FooterNavigationComponent], [typeof FooterNavigationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FooterNavigationModule>;
}

declare class PageTitleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PageTitleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PageTitleModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof i3.PageMetaModule, typeof PageTitleComponent], [typeof PageTitleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PageTitleModule>;
}

declare class HighlightPipe implements PipeTransform {
    transform(text: string, match?: string, caseSensitive?: boolean): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<HighlightPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<HighlightPipe, "cxHighlight", true>;
}

/**
 * Indicates that the user chose a suggestion
 */
declare class SearchBoxSuggestionSelectedEvent extends CxEvent {
    /**
     * Event's type
     */
    static readonly type = "SearchBoxSuggestionSelectedEvent";
    freeText: string;
    selectedSuggestion: string;
    searchSuggestions: (Suggestion | string)[];
}
/**
 * Indicates that the user chose a product suggestion
 */
declare class SearchBoxProductSelectedEvent extends CxEvent {
    /**
     * Event's type
     */
    static readonly type = "SearchBoxProductSelectedEvent";
    freeText: string;
    productCode: string;
}

interface SearchBoxConfig {
    displaySuggestions?: boolean | string;
    displayProducts?: boolean | string;
    displayProductImages?: boolean | string;
    maxProducts?: number;
    maxSuggestions?: number;
    minCharactersBeforeRequest?: number;
    recentSearches?: boolean | string;
    maxRecentSearches?: number;
    trendingSearches?: boolean | string;
    maxTrendingSearches?: number;
}
interface SearchResults {
    message?: string;
    products?: any[];
    suggestions?: string[];
    recentSearches?: string[];
}

declare class SearchBoxComponentService {
    searchService: SearchboxService;
    protected routingService: RoutingService;
    protected translationService: TranslationService;
    protected winRef: WindowRef;
    protected eventService: EventService;
    chosenWord: ReplaySubject<string>;
    sharedEvent: ReplaySubject<KeyboardEvent>;
    searchCompleted: BehaviorSubject<boolean>;
    protected enableRecentSearches: boolean;
    protected enableTrendingSearches: boolean;
    private currentQueryLength;
    private hasKeywordRedirect;
    constructor(searchService: SearchboxService, routingService: RoutingService, translationService: TranslationService, winRef: WindowRef, eventService: EventService);
    /**
     * Executes the search for products and suggestions,
     * unless the configuration is setup to not search for
     * products or suggestions.
     */
    search(query: string, config: SearchBoxConfig): void;
    /**
     * Check if search operations are complete based on actual completion flags
     */
    private checkSearchCompletion;
    /**
     * Returns an observable with the SearchResults. When there's any
     * result, the body tag will get a classname, so that specific style
     * rules can be applied.
     */
    getResults(config: SearchBoxConfig): Observable<SearchResults>;
    /**
     * Clears the searchbox results, so that old values are
     * no longer emited upon next search.
     */
    clearResults(): void;
    hasBodyClass(className: string): boolean;
    toggleBodyClass(className: string, add?: boolean): void;
    /**
     * Dispatches a searchbox event for product selected
     *
     * @param eventData data for the "SearchBoxProductSelectedEvent"
     */
    dispatchProductSelectedEvent(eventData: SearchBoxProductSelectedEvent): void;
    /**
     * Dispatches a searchbox event for suggestion selected
     *
     * @param eventData data for the "SearchBoxSuggestionSelectedEvent"
     */
    dispatchSuggestionSelectedEvent(eventData: SearchBoxSuggestionSelectedEvent): void;
    /**
     * For search results model, it returns true when:
     * * there is any product OR
     * * the is any search suggestion OR
     * * there is a message.
     *
     * Otherwise it returns false.
     */
    protected hasResults(results: SearchResults): boolean;
    /**
     * Emits product search results in case when the config property `displayProducts` is true.
     * Otherwise it emits an empty object.
     */
    protected getProductResults(config: SearchBoxConfig): Observable<ProductSearchPage>;
    /**
     * Loads suggestions from the backend. In case there's no suggestion
     * available, we try to get an exact match suggestion.
     */
    protected getProductSuggestions(config: SearchBoxConfig): Observable<string[]>;
    /**
     * Whenever there is at least 1 product, we simulate
     * a suggestion to provide easy access to the search result page
     */
    protected getExactSuggestion(config: SearchBoxConfig): Observable<string | undefined>;
    /**
     * Emits a 'no match' message, in case the product search results and search suggestions are empty.
     * Otherwise it emits null.
     */
    protected getSearchMessage(config: SearchBoxConfig): Observable<string | undefined>;
    /**
     * Navigates to the search result page with a given query
     * after waiting for all search operations to complete
     */
    launchSearchPage(query: string): void;
    private fetchTranslation;
    changeSelectedWord(selectedWord: string): void;
    shareEvent($event: KeyboardEvent): void;
    setTrendingSearches(enabled?: boolean): void;
    setRecentSearches(enabled?: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchBoxComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SearchBoxComponentService>;
}

declare enum SearchBoxOutlets {
    RECENT_SEARCHES = "SearchBoxOutlets.RECENT_SEARCHES",
    RECENT_SEARCHES_HEADER = "SearchBoxOutlets.RECENT_SEARCHES_HEADER",
    TRENDING_SEARCHES = "SearchBoxOutlets.TRENDING_SEARCHES"
}

declare class SearchBoxComponent implements OnInit, OnDestroy {
    protected searchBoxComponentService: SearchBoxComponentService;
    protected componentData: CmsComponentData<CmsSearchBoxComponent>;
    protected winRef: WindowRef;
    protected routingService: RoutingService;
    private elementRef;
    private renderer;
    private readonly featureConfigService;
    readonly searchBoxOutlets: typeof SearchBoxOutlets;
    config: SearchBoxConfig;
    /**
     * Sets the search box input field
     */
    set queryText(value: string);
    get searchBoxV2(): boolean;
    /**
     * Listener for clickout out of searchInput and searchPanel
     * */
    clickout(event: UIEvent): void;
    /**
     * Search input element reference.
     */
    searchInputEl: any;
    searchButton: ElementRef<HTMLElement>;
    onEscape(): void;
    iconTypes: typeof ICON_TYPE$1;
    searchBoxActive: boolean;
    /**
     * In some occasions we need to ignore the close event,
     * for example when we click inside the search result section.
     */
    private ignoreCloseEvent;
    chosenWord: string;
    /**
     * Tracks whether the search box currently has a non-empty query.
     * Used with searchBoxRecentSearchesRemoval to decide if results should be rendered.
     */
    protected hasQuery: boolean;
    /**
     * Whether the results panel should be visible for the current state.
     * When searchBoxRecentSearchesRemoval is disabled, matches develop behavior.
     */
    isResultsPanelVisible(): boolean;
    protected getAriaControls(): string | null;
    /**
     * Cached flag indicating if the current viewport is mobile (BREAKPOINT.sm and below).
     * Used to vary behavior between mobile and desktop.
     */
    protected isMobileState: boolean | null;
    private readonly searchBoxRecentSearchesRemovalEnabled;
    /**
     * Returns true when the current results represent a \"no results\" state.
     * Used to hide recent searches when there are no suggestions or products.
     */
    isNoResults(result: SearchResults | null | undefined): boolean;
    protected subscriptions: Subscription;
    get isMobile(): Observable<boolean> | undefined;
    protected breakpointService: BreakpointService;
    protected changeDetectorRef: ChangeDetectorRef;
    constructor(searchBoxComponentService: SearchBoxComponentService, componentData: CmsComponentData<CmsSearchBoxComponent>, winRef: WindowRef, routingService: RoutingService);
    /**
     * Returns the SearchBox configuration. The configuration is driven by multiple
     * layers: default configuration, (optional) backend configuration and (optional)
     * input configuration.
     */
    protected config$: Observable<SearchBoxConfig>;
    results$: Observable<SearchResults>;
    items$: Observable<any>;
    ngOnInit(): void;
    /**
     * The Searchbox should not be focusable while not visible.
     */
    getTabIndex(isMobile: boolean | null): number;
    /**
     * Closes the searchBox and opens the search result page.
     */
    search(query: string): void;
    /**
     * Opens the type-ahead searchBox
     */
    open(): void;
    /**
     * Dispatch UI events for Suggestion selected
     *
     * @param eventData the data for the event
     */
    dispatchSuggestionEvent(eventData: SearchBoxSuggestionSelectedEvent): void;
    /**
     * Dispatch UI events for Product selected
     *
     * @param eventData the data for the event
     */
    dispatchProductEvent(eventData: SearchBoxProductSelectedEvent): void;
    /**
     * Blur handler for the search input and suggestion links.
     * Uses feature-specific logic when searchBoxRecentSearchesRemoval is enabled.
     */
    onSearchBlur(event: FocusEvent): void;
    /**
     * Handles blur event on the search input
     * Prevents closing if the blur is caused by clicking the clear recent searches button
     */
    protected handleInputBlur(event: FocusEvent): void;
    /**
     * Closes the type-ahead searchBox.
     */
    close(force?: boolean): void;
    softClose(): void;
    protected blurSearchBox(): void;
    private isSearchBoxFocused;
    protected checkOuterResults(): void;
    /**
     * Especially in mobile we do not want the search icon
     * to focus the input again when it's already open.
     * */
    avoidReopen(event: UIEvent): void;
    protected getResultElements(): HTMLElement[];
    private getGroupElements;
    protected getFocusedElement(): HTMLElement;
    updateChosenWord(chosenWord: string): void;
    protected getFocusedIndex(): number;
    protected getFocusedGroupIndex(): number;
    protected propagateEvent(event: KeyboardEvent): void;
    protected handleKeyboardEvent(event: KeyboardEvent): void;
    focusPreviousChild(event: UIEvent): void;
    focusNextChild(event: UIEvent): void;
    focusPreviousGroup(event: UIEvent): void;
    focusNextGroup(event: UIEvent): void;
    carouselEventPropagator(event: KeyboardEvent | null): void;
    /**
     * Opens the PLP with the given query.
     *
     * TODO: if there's a single product match, we could open the PDP.
     */
    launchSearchResult(query: string): void;
    /**
     * Handler for Enter key from the input. Mirrors the previous template inline calls
     * but checks if the query matches a category suggestion and clears input if so.
     */
    onEnter(value: string): void;
    /**
     * Disables closing the search result list.
     */
    disableClose(): void;
    preventDefault(ev: UIEvent): void;
    /**
     * Clears the search box input field
     */
    clear(el: HTMLInputElement): void;
    /**
     * Component cleanup
     */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchBoxComponent, [null, { optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchBoxComponent, "cx-searchbox", never, { "config": { "alias": "config"; "required": false; }; "queryText": { "alias": "queryText"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SearchBoxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchBoxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SearchBoxModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof MediaModule, typeof IconModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof OutletModule, typeof i3.FeaturesConfigModule, typeof CarouselModule, typeof KeyboardFocusModule, typeof SearchBoxComponent, typeof HighlightPipe], [typeof SearchBoxComponent, typeof HighlightPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SearchBoxModule>;
}

declare class ScrollToTopComponent implements OnInit {
    protected winRef: WindowRef;
    protected componentData: CmsComponentData<CmsScrollToTopComponent>;
    protected selectFocusUtility: SelectFocusUtility;
    iconTypes: typeof ICON_TYPE$1;
    display: boolean | undefined;
    protected window: Window | undefined;
    protected scrollBehavior: ScrollBehavior;
    protected displayThreshold: number;
    protected triggedByKeypress: boolean;
    button: ElementRef;
    constructor(winRef: WindowRef, componentData: CmsComponentData<CmsScrollToTopComponent>, selectFocusUtility: SelectFocusUtility);
    ngOnInit(): void;
    onScroll(): void;
    /**
     * Scroll back to the top of the page, and recognize if triggerd by keyboard.
     */
    scrollToTop(event?: MouseEvent): void;
    onFocusOut(): void;
    /**
     * After scrolling to top, pressing Tab should focus first focusable element within body.
     */
    protected onTab(event: Event): void;
    protected setConfig(): void;
    /**
     * This methods decides when the ScrollToTop button should be displayed.
     */
    protected switchDisplay(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollToTopComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScrollToTopComponent, "cx-scroll-to-top", never, {}, {}, never, never, true, never>;
}

declare class ScrollToTopModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ScrollToTopModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ScrollToTopModule, never, [typeof i1.CommonModule, typeof IconModule, typeof i3.I18nModule, typeof ScrollToTopComponent], [typeof ScrollToTopComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ScrollToTopModule>;
}

declare class MyAccountV2NavigationComponent extends NavigationComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2NavigationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyAccountV2NavigationComponent, "cx-my-account-v2-navigation", never, {}, {}, never, never, true, never>;
}

declare class MyAccountV2NavigationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2NavigationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MyAccountV2NavigationModule, never, [typeof i1.CommonModule, typeof NavigationModule, typeof i3.I18nModule, typeof MyAccountV2NavigationComponent], [typeof MyAccountV2NavigationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MyAccountV2NavigationModule>;
}

declare class MyAccountV2Module {
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2Module, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MyAccountV2Module, never, [typeof MyAccountV2NavigationModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MyAccountV2Module>;
}

declare class MyAccountV2ConsentManagementFormComponent extends ConsentManagementFormComponent implements OnInit {
    consentApprovedTime: string;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2ConsentManagementFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyAccountV2ConsentManagementFormComponent, "cx-my-account-v2-consent-management-form", never, {}, {}, never, never, true, never>;
}

declare class MyAccountV2ConsentManagementComponent extends ConsentManagementComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2ConsentManagementComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyAccountV2ConsentManagementComponent, "cx-my-account-v2-consent-management", never, {}, {}, never, never, true, never>;
}

declare class MyAccountV2ConsentManagementModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2ConsentManagementModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MyAccountV2ConsentManagementModule, never, [typeof i1.CommonModule, typeof i2$2.FormsModule, typeof i2$2.ReactiveFormsModule, typeof SpinnerModule, typeof i3.I18nModule, typeof IconModule, typeof i3.FeaturesConfigModule, typeof MyAccountV2ConsentManagementComponent, typeof MyAccountV2ConsentManagementFormComponent], [typeof MyAccountV2ConsentManagementComponent, typeof MyAccountV2ConsentManagementFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MyAccountV2ConsentManagementModule>;
}

declare class MyAccountV2NotificationPreferenceComponent extends NotificationPreferenceComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2NotificationPreferenceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyAccountV2NotificationPreferenceComponent, "cx-my-account-v2-notification-preference", never, {}, {}, never, never, true, never>;
}

declare class MyAccountV2NotificationPreferenceModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2NotificationPreferenceModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MyAccountV2NotificationPreferenceModule, never, [typeof i1.CommonModule, typeof SpinnerModule, typeof i3.I18nModule, typeof i2$1.RouterModule, typeof i3.FeaturesConfigModule, typeof MyAccountV2NotificationPreferenceComponent], [typeof MyAccountV2NotificationPreferenceComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MyAccountV2NotificationPreferenceModule>;
}

declare const USE_MY_ACCOUNT_V2_NOTIFICATION_PREFERENCE: InjectionToken<boolean>;
declare const USE_MY_ACCOUNT_V2_CONSENT: InjectionToken<boolean>;

interface ProductCarouselItem {
    title?: string;
    media?: {
        container: any;
        format?: string;
    };
    price?: any;
    route?: any[];
}

declare class ProductCarouselService {
    protected productService: ProductService;
    protected semanticPathService: SemanticPathService;
    constructor(productService: ProductService, semanticPathService: SemanticPathService);
    /**
     * Loads the product data and converts it `CarouselItem`.
     */
    loadProduct(code: string): Observable<ProductCarouselItem>;
    /**
     * Converts the product to a generic CarouselItem
     */
    private convertProduct;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductCarouselService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductCarouselService>;
}

declare class ProductCarouselComponent {
    protected componentData: CmsComponentData<CmsProductCarouselComponent>;
    protected productService: ProductService;
    protected productSearchByCodeService: ProductSearchByCodeService;
    protected productSearchByCategoryService: ProductSearchByCategoryService;
    protected readonly PRODUCT_SCOPE: ProductScope[];
    protected readonly PRODUCT_SCOPE_ITEM: ProductScope[];
    private componentData$;
    /**
     * returns an Observable string for the title.
     */
    title$: Observable<string | undefined>;
    /**
     * Observable that holds an Array of Observables. This is done, so that
     * the component UI could consider to lazy load the UI components when they're
     * in the viewpoint.
     * If the inner component mapping exists (e.g. ProductAddToCartComponent), we aim to leverage the full scope;
     * otherwise, we prefer to minimize the scope for better performance.
     */
    items$: Observable<Observable<Product | undefined>[]>;
    trackByFn: TrackByFunction<Product>;
    constructor(componentData: CmsComponentData<CmsProductCarouselComponent>, productService: ProductService);
    handleCategoryCodes(data: CmsProductCarouselComponent): Observable<CmsProductCarouselComponent>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductCarouselComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductCarouselComponent, "cx-product-carousel", never, {}, {}, never, never, true, never>;
}

declare abstract class ViewConfig {
    view?: {
        /**
         * Configurations related to the view of the application
         */
        defaultPageSize?: number;
        infiniteScroll?: {
            active?: boolean;
            productLimit?: number;
            showMoreButton?: boolean;
        };
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ViewConfig>;
}
declare module '@spartacus/core' {
    interface Config extends ViewConfig {
    }
}

/**
 * Contains specific route parameters for the product listing page.
 */
interface ProductListRouteParams {
    /**
     * The query parameter which used to query the backend API.
     */
    query?: string;
    /**
     * The category code which is used to query the backend API.
     */
    categoryCode?: string;
    /**
     * The brand code is actually a category code,  which is used to
     * query the backend API.
     */
    brandCode?: string;
}
/**
 * Contains search related data for querying the backend API.
 */
interface SearchCriteria {
    /**
     * Contains the search text that is used to query the backend API.
     */
    query?: string;
    /**
     * The current page of the search result.
     */
    currentPage?: number;
    /**
     * The number of items in the search results.
     */
    pageSize?: number;
    /**
     * The sort code that is used to sort the items in the search result.
     */
    sortCode?: string;
}

/**
 * The `ProductListComponentService` is used to search products. The service is used
 * on the Product Listing Page, for listing products and the facet navigation.
 *
 * The service exposes the product search results based on the category and search
 * route parameters. The route parameters are used to query products by the help of
 * the `ProductSearchService`.
 */
declare class ProductListComponentService {
    protected productSearchService: ProductSearchService;
    protected routing: RoutingService;
    protected activatedRoute: ActivatedRoute;
    protected currencyService: CurrencyService;
    protected languageService: LanguageService;
    protected router: Router;
    protected config: ViewConfig;
    protected readonly RELEVANCE_ALLCATEGORIES = ":relevance:allCategories:";
    constructor(productSearchService: ProductSearchService, routing: RoutingService, activatedRoute: ActivatedRoute, currencyService: CurrencyService, languageService: LanguageService, router: Router, config: ViewConfig);
    /**
     * Emits the search results for the current search query.
     *
     * The `searchResults$` is _not_ concerned with querying, it only observes the
     * `productSearchService.getResults()`
     */
    protected searchResults$: Observable<ProductSearchPage>;
    /**
     * Observes the route and performs a search on each route change.
     *
     * Context changes, such as language and currencies are also taken
     * into account, so that the search is performed again.
     */
    protected searchByRouting$: Observable<ActivatedRouterStateSnapshot>;
    /**
     * Search only if the previous search criteria does NOT match the new one.
     * This prevents repeating product search calls for queries that already have loaded data.
     */
    protected searchIfCriteriaHasChanged(criteria: SearchCriteria): void;
    /**
     * This stream is used for the Product Listing and Product Facets.
     *
     * It not only emits search results, but also performs a search on every change
     * of the route (i.e. route params or query params).
     *
     * When a user leaves the PLP route, the PLP component unsubscribes from this stream
     * so no longer the search is performed on route change.
     */
    readonly model$: Observable<ProductSearchPage>;
    /**
     * Expose the `SearchCriteria`. The search criteria are driven by the route parameters.
     *
     * This search route configuration is not yet configurable
     * (see https://github.com/SAP/spartacus/issues/7191).
     */
    protected getCriteriaFromRoute(routeParams: ProductListRouteParams, queryParams: SearchCriteria): SearchCriteria;
    /**
     * Resolves the search query from the given `ProductListRouteParams`.
     */
    protected getQueryFromRouteParams({ query, categoryCode, brandCode, }: ProductListRouteParams): string | undefined;
    /**
     * Performs a search based on the given search criteria.
     *
     * The search is delegated to the `ProductSearchService`.
     */
    protected search(criteria: SearchCriteria): void;
    /**
     * Get items from a given page without using navigation
     */
    getPageItems(pageNumber: number): void;
    /**
     * Sort the search results by the given sort code.
     */
    sort(sortCode: string): void;
    /**
     * Routes to the next product listing page, using the given `queryParams`. The
     * `queryParams` support sorting, pagination and querying.
     *
     * The `queryParams` are delegated to the Angular router `NavigationExtras`.
     */
    protected route(queryParams: SearchCriteria): void;
    /**
     * The site context is used to update the search query in case of a
     * changing context. The context will typically influence the search data.
     *
     * We keep this private for now, as we're likely refactoring this in the next
     * major version.
     */
    private get siteContext();
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductListComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductListComponentService>;
}

declare enum ViewModes {
    Grid = "grid",
    List = "list"
}
declare class ProductViewComponent {
    iconTypes: typeof ICON_TYPE$1;
    mode: ViewModes;
    modeChange: EventEmitter<ViewModes>;
    get buttonClass(): string;
    /**
     *   Display icons inversely to allow users
     *   to see the view they will navigate to
     */
    get viewMode(): ICON_TYPE$1.GRID | ICON_TYPE$1.LIST;
    changeMode(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductViewComponent, "cx-product-view", never, { "mode": { "alias": "mode"; "required": false; }; }, { "modeChange": "modeChange"; }, never, never, true, never>;
}

declare class ProductListComponent implements OnInit, OnDestroy {
    private pageLayoutService;
    private productListComponentService;
    private globalMessageService;
    scrollConfig: ViewConfig;
    private subscription;
    isInfiniteScroll: boolean | undefined;
    model$: Observable<ProductSearchPage>;
    viewMode$: BehaviorSubject<ViewModes>;
    ViewModes: typeof ViewModes;
    constructor(pageLayoutService: PageLayoutService, productListComponentService: ProductListComponentService, globalMessageService: GlobalMessageService, scrollConfig: ViewConfig);
    ngOnInit(): void;
    sortList(sortCode: string): void;
    setViewMode(mode: ViewModes): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductListComponent, "cx-product-list", never, {}, {}, never, never, true, never>;
}

declare class ProductScrollComponent implements OnDestroy {
    private productListComponentService;
    private ref;
    private subscription;
    set setConfig(inputConfig: ViewConfig);
    model: ProductSearchPage;
    set setModel(inputModel: ProductSearchPage);
    inputViewMode: ViewModes;
    set setViewMode(inputViewMode: ViewModes);
    viewMode: ViewModes;
    productLimit: number | undefined;
    maxProducts: number | undefined;
    ViewModes: typeof ViewModes;
    appendProducts: boolean;
    resetList: boolean;
    isMaxProducts: boolean;
    isLastPage: boolean;
    isEmpty: boolean;
    constructor(productListComponentService: ProductListComponentService, ref: ChangeDetectorRef);
    scrollPage(pageNumber: number): void;
    loadNextPage(pageNumber: number): void;
    scrollToTop(): void;
    private setComponentConfigurations;
    private infiniteScrollOperations;
    private resetListOnViewModeChange;
    private setConditions;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductScrollComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductScrollComponent, "cx-product-scroll", never, { "setConfig": { "alias": "scrollConfig"; "required": false; }; "setModel": { "alias": "model"; "required": false; }; "setViewMode": { "alias": "inputViewMode"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Context for `ProductListItemComponent`.
 */
declare abstract class ProductListItemContext {
    readonly product$: Observable<Product>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductListItemContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductListItemContext>;
}

/**
 * Context source for `ProductListItemComponent`.
 *
 * `ProductListItemContext` should be injected instead in child components.
 */
declare class ProductListItemContextSource extends ProductListItemContext {
    readonly product$: ReplaySubject<Product>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductListItemContextSource, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductListItemContextSource>;
}

/**
 * UI model that holds the full list of facet and active facets for
 * the product list.
 */
interface FacetList {
    facets: Facet[];
    activeFacets?: Breadcrumb[];
}
interface FacetCollapseState {
    /**
     * Indicates whether the facet is toggled to expand or collapse the facet values.
     * Whether the toggle results in an expanded or collapsed state, depends on the
     * experience, which is controlled in CSS.
     */
    toggled?: FacetGroupCollapsedState;
    /**
     * The top number of facet values that will be visible.
     */
    topVisible?: number;
    /**
     * The max number of facet values which will be visible. This includes
     * the top visible number.
     */
    maxVisible?: number;
}
declare enum FacetGroupCollapsedState {
    EXPANDED = "EXPANDED",
    COLLAPSED = "COLLAPSED"
}

/**
 * Provides access to all the facets and active facets for the Product Listing Page.
 */
declare class ProductFacetService {
    protected routing: RoutingService;
    protected productListComponentService: ProductListComponentService;
    constructor(routing: RoutingService, productListComponentService: ProductListComponentService);
    protected readonly routeState$: Observable<ActivatedRouterStateSnapshot>;
    /**
     * Returns the search results for the current page.
     */
    protected readonly searchResult$: Observable<ProductSearchPage>;
    /**
     * Observes the facets and active facets for the given page. The facet data
     * is provided in a `FacetList`.
     */
    readonly facetList$: Observable<FacetList>;
    /**
     * Filters the current result by verifying if the result is related to the page.
     * This is done to avoid a combination of the next page and the current search results.
     */
    protected filterForPage(state: ActivatedRouterStateSnapshot, page: ProductSearchPage): boolean;
    /**
     * Filter breadcrumbs which are not actively selected but coming from
     * the route navigation.
     *
     * The breadcrumbs might include the active category page code, which is not actively
     * selected by the user.
     */
    protected filterBreadcrumbs(breadcrumbs: Breadcrumb[], params: Params): Breadcrumb[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductFacetService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductFacetService>;
}

/**
 * Provides access to the facets as well as their UI state. The UI state
 * represents user related changes on the facets, such as expanding or
 * collapsing a facet group or expanding the number of _visible_ facet values.
 */
declare class FacetService {
    protected productFacetService: ProductFacetService;
    /**
     * An internal map where we keep the UI state of the facets.
     */
    protected facetState: Map<string, BehaviorSubject<FacetCollapseState>>;
    protected readonly codec: HttpUrlEncodingCodec;
    constructor(productFacetService: ProductFacetService);
    /**
     * Observes the facets for the given page and configures the initial UI state.
     *
     * Facets are configured on each emission so that we keep the facet UI state.
     * This is mainly done to keep the state during usage of the facet, but also
     * benefitial when the facets are rebuild while using them.
     */
    facetList$: Observable<FacetList>;
    /**
     * Returns the observed UI state for the facet.
     *
     * The state is initialized using the `initialize` method.
     */
    getState(facet: Facet): Observable<FacetCollapseState>;
    /**
     * Returns the UI state for the facet.
     *
     * The state is initialized using the `initialize` method.
     */
    protected getStateSnapshot(facet: Facet): FacetCollapseState;
    /**
     * Toggles the facet expanded state. If the expanded state becomes false,
     * the visible values will decrease to the top values only.
     *
     * If the optional value argument is provided the expanded state will be set
     * to this value, regardless of the current `expanded` state.
     */
    toggle(facet: Facet, isExpanded: boolean): void;
    /**
     * Increases the visible values to the maximum values of the facet.
     */
    increaseVisibleValues(facet: Facet): void;
    /**
     * Decreases the visible values to the topValueCount.
     *
     * The topValueCount defaults to 6, but can be controlled in
     * the backend as well.
     */
    decreaseVisibleValues(facet: Facet): void;
    /**
     * Persists the facet state and initializes the default values for the top
     * and max visible values.
     */
    protected initialize(facet: Facet): void;
    /**
     * Updates the state of the facet in the local facet map.
     */
    protected updateState(facet: Facet, property: FacetCollapseState): void;
    protected hasState(facet: Facet): boolean;
    getLinkParams(query: string): {
        [key: string]: string;
    };
    protected decodeUriComponentSafe(query: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FacetService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FacetService>;
}

/**
 * Active facets render the applied facet values as a list of focusable buttons
 * which can be used to remove the applied facet value.
 */
declare class ActiveFacetsComponent {
    protected facetService: FacetService;
    role: string;
    labelledby: string;
    /** Active facets which are applied to the product results. */
    facetList$: Observable<FacetList>;
    /** Configurable icon which is used for the active facet close button */
    closeIcon: ICON_TYPE$1;
    constructor(facetService: FacetService);
    getLinkParams(facet: Breadcrumb): {
        [key: string]: string;
    };
    /**
     * The focus key is used to persist the focus on the facet when the DOM is being
     * recreated. We only apply the focus key for the given _active_ facet when there
     * the original facets is not available. This happens for non multi-valued facets.
     *
     * With this approach, the we keep the focus, either at the facet list or on the
     * active facets.
     */
    getFocusKey(facetList: FacetList, facet: Breadcrumb): string | undefined;
    /**
     * Purpose of this function is to allow keyboard users to click on a filter they
     * wish to remove by pressing spacebar. Event not handled natively by <a> elements.
     *
     * @param event spacebar keydown
     */
    removeFilterWithSpacebar(event?: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActiveFacetsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActiveFacetsComponent, "cx-active-facets", never, { "closeIcon": { "alias": "closeIcon"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ActiveFacetsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ActiveFacetsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ActiveFacetsModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof i3.I18nModule, typeof IconModule, typeof KeyboardFocusModule, typeof ActiveFacetsComponent], [typeof ActiveFacetsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ActiveFacetsModule>;
}

declare class FacetComponent implements AfterViewInit {
    protected facetService: FacetService;
    protected elementRef: ElementRef<HTMLElement>;
    protected cd: ChangeDetectorRef;
    protected _facet: Facet;
    state$: Observable<FacetCollapseState>;
    /** configurable icon that is used to collapse the facet group  */
    expandIcon: ICON_TYPE$1;
    collapseIcon: ICON_TYPE$1;
    isMultiSelect: boolean;
    values: QueryList<ElementRef<HTMLElement>>;
    keyboardFocus: FocusDirective;
    facetHeader: ElementRef<HTMLElement>;
    set facet(value: Facet);
    get facet(): Facet;
    constructor(facetService: FacetService, elementRef: ElementRef<HTMLElement>, cd: ChangeDetectorRef);
    ngAfterViewInit(): void;
    /**
     * @deprecated: Header will no longer be used in favour of TabComponent headers.
     *
     * Handles clicking the heading of the facet group, which means toggling
     * the visibility of the group (collapse / expand) and optionally focusing
     * the group.
     */
    toggleGroup(event: UIEvent): void;
    get isExpanded(): boolean;
    openLink(event: KeyboardEvent): void;
    /**
     * Increases the number of visible values for the facet. This is delegated
     * to `facetService.increaseVisibleValues`.
     */
    increaseVisibleValues(): void;
    /**
     * Decreases the number of visible values for the facet. This is delegated
     * to `facetService.decreaseVisibleValues`.
     */
    decreaseVisibleValues(): void;
    getLinkParams(value: FacetValue): {
        [key: string]: string;
    };
    onKeydown(event: KeyboardEvent): void;
    /**
     * We temporarily disable tabbing for the facet values.
     * This is to use proper keyboard navigation keys(ArrowUp/ArrowDown) for navigating through the facet values.
     */
    protected onTabNavigation(): void;
    onArrowDown(event: Event, targetIndex: number): void;
    onArrowUp(event: Event, targetIndex: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FacetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FacetComponent, "cx-facet", never, { "expandIcon": { "alias": "expandIcon"; "required": false; }; "collapseIcon": { "alias": "collapseIcon"; "required": false; }; "facet": { "alias": "facet"; "required": false; }; }, {}, never, never, true, never>;
}

declare class FacetListComponent implements OnInit, OnDestroy, AfterViewInit {
    protected facetService: FacetService;
    protected elementRef: ElementRef;
    protected renderer: Renderer2;
    protected subscriptions: Subscription;
    private _isDialog;
    backToResultsBtn: ElementRef<HTMLButtonElement>;
    /**
     * Indicates that the facet navigation is rendered in dialog.
     */
    set isDialog(value: boolean);
    get isDialog(): boolean;
    /** Emits when the list must close */
    closeList: EventEmitter<any>;
    /** The list of all facet and values related to the products in the list */
    facetList$: Observable<FacetList>;
    iconTypes: typeof ICON_TYPE$1;
    dialogFocusConfig: FocusConfig;
    tabConfig: TabConfig;
    tabs$: BehaviorSubject<Tab[]>;
    facetsRef: QueryList<TemplateRef<any>>;
    handleClick(): void;
    focusService: KeyboardFocusService | null;
    constructor(facetService: FacetService, elementRef: ElementRef, renderer: Renderer2);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    updateTabs(): void;
    /**
     * Toggles the facet group in case it is not expanded.
     */
    expandFacetGroup(facet: Facet, ref: FacetComponent): void;
    /**
     * Indicates that the facet group has been expanded.
     */
    isExpanded(facet: Facet): Observable<boolean>;
    /**
     * Indicates that the facet group has been collapsed.
     */
    isCollapsed(facet: Facet): Observable<boolean>;
    close(event?: boolean): void;
    block(event?: MouseEvent): void;
    protected enableFocusHandlingOnFacetListChanges(): void;
    protected handleDialogFocus(facets: Facet[]): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FacetListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FacetListComponent, "cx-facet-list", never, { "isDialog": { "alias": "isDialog"; "required": false; }; }, { "closeList": "closeList"; }, never, never, true, never>;
}

declare class FacetModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FacetModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FacetModule, never, [typeof AtMessageModule, typeof i1.CommonModule, typeof i3.I18nModule, typeof IconModule, typeof KeyboardFocusModule, typeof i2$1.RouterModule, typeof i3.UrlModule, typeof i3.FeaturesConfigModule, typeof FacetComponent], [typeof FacetComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FacetModule>;
}

declare class FacetListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FacetListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FacetListModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof IconModule, typeof FacetModule, typeof KeyboardFocusModule, typeof i3.FeaturesConfigModule, typeof TabModule, typeof FacetListComponent], [typeof FacetListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FacetListModule>;
}

declare class ProductFacetNavigationComponent {
    protected breakpointService: BreakpointService;
    iconTypes: typeof ICON_TYPE$1;
    /**
     * We delay the removal of DOM so that animations can finish playing before the
     * DOM is removed. Removing the DOM, as hidding is not enough to stop elements
     * to be focused.
     */
    protected CLOSE_DELAY: number;
    /**
     * Used to open the facet navigation in a dialog. The usage of the dialog depends
     * on the availability of the trigger element, which is driven by CSS.
     *
     * The reference is also used to refocus the trigger after the dialog is closed.
     */
    trigger: ElementRef<HTMLElement>;
    protected open$: BehaviorSubject<boolean>;
    /**
     * Emits the open state that indicates whether the facet list should be rendered.
     * This is either done instantly, or after the user triggers this by using the trigger
     * button. This driven by the visiibility of the trigger, so that the CSS drives
     * the behaviour. This can differ per breakpoint.
     *
     * There's a configurable delay for the closed state, so that the DOM is not removed
     * before some CSS animations are done.
     */
    isOpen$: Observable<boolean>;
    /**
     * Emits the active state that indicates whether the facet list is activated. Activation
     * is related to the css, so that a animation or transition can visualize opening/closing
     * the list (i.e. dialog).
     */
    isActive$: Observable<boolean>;
    constructor(breakpointService: BreakpointService);
    launch(): void;
    close(): void;
    /**
     * Indicates that the facet navigation should be open explicitely by a trigger.
     * This is fully controlled by CSS, where the trigger button can be hidden
     * (display:none) for certain screen sizes.
     */
    get hasTrigger(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductFacetNavigationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductFacetNavigationComponent, "cx-product-facet-navigation", never, {}, {}, never, never, true, never>;
}

declare class ProductFacetNavigationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductFacetNavigationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductFacetNavigationModule, never, [typeof i1.CommonModule, typeof FacetListModule, typeof ActiveFacetsModule, typeof IconModule, typeof i3.I18nModule, typeof i3.ConfigModule, typeof ProductFacetNavigationComponent], [typeof ProductFacetNavigationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductFacetNavigationModule>;
}

declare enum ProductDetailOutlets {
    INTRO = "PDP.INTRO",
    PRICE = "PDP.PRICE",
    SHARE = "PDP.SHARE",
    SUMMARY = "PDP.SUMMARY"
}
declare enum ProductListOutlets {
    ITEM_ACTIONS = "cx-product-list-item.actions",
    ITEM_DETAILS = "cx-product-list-item.details"
}

declare class ProductListService {
    shouldHideAddToCartButton(product: any): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductListService>;
}

declare class ProductGridItemComponent implements OnChanges {
    protected productListItemContextSource: ProductListItemContextSource;
    protected productListService: ProductListService;
    hideAddToCartButton: boolean;
    readonly ProductListOutlets: typeof ProductListOutlets;
    /**
     * The product item to be displayed in the grid.
     */
    product: any;
    /**
     * The index of the item in the product grid.
     */
    itemIndex?: number;
    constructor(productListItemContextSource: ProductListItemContextSource);
    ngOnChanges(changes?: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductGridItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductGridItemComponent, "cx-product-grid-item", never, { "product": { "alias": "product"; "required": false; }; "itemIndex": { "alias": "itemIndex"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ProductListItemComponent implements OnChanges {
    protected productListItemContextSource: ProductListItemContextSource;
    protected productListService: ProductListService;
    hideAddToCartButton: boolean;
    readonly ProductListOutlets: typeof ProductListOutlets;
    summaryMaxLength: number;
    /**
     * The product item to be displayed in the list.
     */
    product: any;
    /**
     * The index of the item in the product list.
     */
    itemIndex?: number;
    constructor(productListItemContextSource: ProductListItemContextSource);
    ngOnChanges(changes?: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductListItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductListItemComponent, "cx-product-list-item", never, { "product": { "alias": "product"; "required": false; }; "itemIndex": { "alias": "itemIndex"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Provides a UI to manage the count of the quantity, typically by using
 * increase and decrease functionality. The item counter expects an input `FormControl`
 * so that the state of the control can be managed outside of this component.
 */
declare class ItemCounterComponent implements OnInit, OnDestroy {
    /**
     * Holds the value of the counter, the state of the `FormControl`
     * can be managed outside of the item counter.
     */
    control: UntypedFormControl;
    /**
     * This can be used in case an item has a minmum order quantity.
     * @default 1
     */
    min: number;
    /**
     * This can be used in case an item has a maximum order quantity.
     */
    max: number;
    /**
     * The step is used to increment the count. It is supposed to be a
     * positive integer or float.
     * @default 1
     */
    step: number;
    /**
     * Indicates that the input can be manually set to zero,
     * despite the fact that the input controls will be limited to
     * the minimum. The zero value can be used to remove an item.
     */
    allowZero: boolean;
    /**
     * ID of the element associated with the number input,
     * so it gets narrated by a screen reader
     */
    ariaDescribedById: string;
    /**
     * In readonly mode the item counter will only be shown as a label,
     * the form controls are not rendered.
     * Please not that readonly is different from the `disabled` form state.
     * @default false
     */
    readonly: boolean;
    private input;
    /**
     * Subscription responsible for auto-correcting control's value when it's invalid.
     */
    private sub;
    ngOnInit(): void;
    ngOnDestroy(): void;
    /**
     * Updates the form control value with the input value.
     * It is used to improve keyboard controls of the component.
     */
    updateValue(): void;
    increment(): void;
    decrement(): void;
    /**
     * Validate that the given value is in between
     * the `min` and `max` value. If the value is out
     * of  the min/max range, it will be altered.
     * If `allowZero` is set to true, the 0 value is ignored.
     *
     */
    private getValidCount;
    static ɵfac: i0.ɵɵFactoryDeclaration<ItemCounterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ItemCounterComponent, "cx-item-counter", never, { "control": { "alias": "control"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "step": { "alias": "step"; "required": false; }; "allowZero": { "alias": "allowZero"; "required": false; }; "ariaDescribedById": { "alias": "ariaDescribedById"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ItemCounterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ItemCounterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ItemCounterModule, never, [typeof i1.CommonModule, typeof i2$2.ReactiveFormsModule, typeof i3.I18nModule, typeof KeyboardFocusModule, typeof i3.FeaturesConfigModule, typeof ItemCounterComponent], [typeof ItemCounterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ItemCounterModule>;
}

/**
 * Star rating component can be used to view existing ratings as well
 * as create new ratings. The component can be used for any ratings.
 */
declare class StarRatingComponent {
    protected initialRate: number;
    icon: ICON_TYPE$1;
    /**
     * The rating component can be used in disabled mode,
     * so that the interaction is not provided.
     *
     * Defaults to true.
     */
    disabled: boolean;
    /**
     * The rating is used to color the rating stars. It can have a
     * precise number. The rating number is used for a CSS custom property
     * (AKA css variable) value. The actually coloring is done in CSS.
     */
    rating: number;
    /**
     * Emits the given rating when the user clicks on a star.
     */
    change: EventEmitter<number>;
    setRate(value: number): void;
    reset(): void;
    saveRate(rating: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StarRatingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StarRatingComponent, "cx-star-rating", never, { "disabled": { "alias": "disabled"; "required": false; }; "rating": { "alias": "rating"; "required": false; }; }, { "change": "change"; }, never, never, true, never>;
}

declare class StarRatingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<StarRatingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StarRatingModule, never, [typeof i1.CommonModule, typeof IconModule, typeof i3.I18nModule, typeof StarRatingComponent], [typeof StarRatingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StarRatingModule>;
}

declare class ProductListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductListModule, never, [typeof AtMessageModule, typeof i1.CommonModule, typeof i3.I18nModule, typeof IconModule, typeof i5.InfiniteScrollModule, typeof ItemCounterModule, typeof ListNavigationModule, typeof MediaModule, typeof OutletModule, typeof PageComponentModule, typeof i2$1.RouterModule, typeof SpinnerModule, typeof StarRatingModule, typeof i3.UrlModule, typeof i3.FeaturesConfigModule, typeof LcpContextDirectiveModule, typeof ProductListComponent, typeof ProductListItemComponent, typeof ProductGridItemComponent, typeof ProductViewComponent, typeof ProductScrollComponent], [typeof ProductListComponent, typeof ProductListItemComponent, typeof ProductGridItemComponent, typeof ProductViewComponent, typeof ProductScrollComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductListModule>;
}

declare class ProductCarouselItemComponent implements OnChanges {
    protected productListItemContextSource: ProductListItemContextSource;
    /**
     * The product item to be displayed in the carousel.
     */
    item: Product;
    /**
     * The index of the item in the carousel.
     */
    itemIndex: number;
    constructor(productListItemContextSource: ProductListItemContextSource);
    ngOnChanges(changes?: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductCarouselItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductCarouselItemComponent, "cx-product-carousel-item", never, { "item": { "alias": "item"; "required": false; }; "itemIndex": { "alias": "itemIndex"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Allows for observing the events of user reaching the horizontal scroll position
 * start or end.
 * Moreover, it exposes methods for scrolling left and right programmatically.
 *
 * @usage
 * ```html
 * <ng-container
 *   cxHorizontalScrollingPosition
 *   #cxHorizontalScrollingPosition="cxHorizontalScrollingPosition"
 *   [scrollingArea]="scrollingArea"
 *   [scrollingAreaStart]="scrollingAreaStart"
 *   [scrollingAreaEnd]="scrollingAreaEnd">
 *
 *   <button
 *     (click)="cxHorizontalScrollingPosition.scrollBackward()"
 *     [disabled]="cxHorizontalScrollingPosition._isScrollStart$ | async">
 *     (Icon arrow backward)
 *   </button>
 *
 *   <div #scrollingArea>
 *     <div #scrollingAreaStart></div>
 *     <div *ngFor="let item of items" class="item">{{ item }}</div>
 *     <div #scrollingAreaEnd></div>
 *   </div>
 *
 *   <button
 *     (click)="cxHorizontalScrollingPosition.scrollForward()"
 *     [disabled]="cxHorizontalScrollingPosition._isScrollEnd$ | async">
 *     (Icon arrow forward)
 *   </button>
 * </ng-container>
 */
declare class HorizontalScrollingPositionDirective implements OnDestroy, OnChanges {
    protected logger: LoggerService;
    protected windowRef: WindowRef;
    protected windowResizeSubscription: Subscription | undefined;
    protected _scrollingAreaWidth$: BehaviorSubject<number>;
    /**
     * Width of the scrolling area, debounced every 300ms in case of continuous resizing.
     */
    readonly scrollingAreaWidth$: Observable<number>;
    /**
     * The scrolling area is the element that contains all of those in the following order:
     * - the dummy item at the start of the scrolling area (`scrollingAreaStart`),
     * - the list of items to scroll through,
     * - the dummy item at the end of the scrolling area (`scrollingAreaEnd`).
     *
     * It is used to scroll the carousel items horizontally and to detect when the user
     * scrolls to the start or end of the carousel.
     */
    scrollingArea: HTMLElement | undefined;
    /**
     * Dummy element to detect when the user scrolls to the start of the carousel.
     */
    scrollingAreaStart: HTMLElement | undefined;
    /**
     * Dummy element to detect when the user scrolls to the end of the carousel.
     */
    scrollingAreaEnd: HTMLElement | undefined;
    protected readonly _isScrollStart$: BehaviorSubject<boolean>;
    /**
     * Tells whether the start of the scrolling area is visible.
     */
    readonly isScrollStart$: Observable<boolean>;
    protected readonly _isScrollEnd$: BehaviorSubject<boolean>;
    /**
     * Tells whether the end of the scrolling area is visible.
     */
    readonly isScrollEnd$: Observable<boolean>;
    /**
     * Tells whether the carousel needs scrolling
     * (i.e. whether the all items are visible in the scrollable area).
     */
    readonly isScrollNeeded$: Observable<boolean>;
    /**
     * When the scrolling area is appearing (or disappearing),
     * it subscribes (or unsubscribes) to the scrolling position.
     */
    ngOnChanges(): void;
    ngOnDestroy(): void;
    /**
     * Scrolls the carousel forward by a width of the carousel's visible area.
     */
    scrollForward(options?: {
        distance?: number;
        behavior?: 'auto' | 'instant' | 'smooth';
    }): void;
    /**
     * Scrolls the carousel backward by a width of the carousel's visible area.
     */
    scrollBackward(options?: {
        distance?: number;
        behavior?: 'auto' | 'instant' | 'smooth';
    }): void;
    /**
     * Intersection Observer used to detect when the scrolling area start or end
     * is visible in the viewport.
     * It is used to enable/disable the backward or forward scroll buttons accordingly.
     */
    protected scrollingAreaIntersectionObserver: IntersectionObserver | undefined;
    /**
     * Resize Observer used to observe the width of the scrolling area.
     * It is used to emit the width of the scrolling area when it changes.
     */
    protected scrollingAreaResizeObserver: ResizeObserver | undefined;
    /**
     * Starts observing the width of the scrolling area and
     * whether the user has scrolled to the start or end of the carousel.
     */
    protected subscribeScrollingArea(): void;
    /**
     * Stops observing the width of the scrolling area and
     * whether the user has scrolled to the start or end of the carousel.
     */
    protected unsubscribeScrollingArea(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HorizontalScrollingPositionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HorizontalScrollingPositionDirective, "[cxHorizontalScrollingPosition]", ["cxHorizontalScrollingPosition"], { "scrollingArea": { "alias": "scrollingArea"; "required": false; }; "scrollingAreaStart": { "alias": "scrollingAreaStart"; "required": false; }; "scrollingAreaEnd": { "alias": "scrollingAreaEnd"; "required": false; }; }, {}, never, never, true, never>;
}

declare class HorizontalScrollingPositionDirectiveModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<HorizontalScrollingPositionDirectiveModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HorizontalScrollingPositionDirectiveModule, never, [typeof HorizontalScrollingPositionDirective], [typeof HorizontalScrollingPositionDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HorizontalScrollingPositionDirectiveModule>;
}

/**
 * Context passed to the `template` for each carousel item.
 */
interface CarouselScrollingTemplateContext<Item> {
    item: Item;
    itemIndex: number;
}
/**
 * Generic carousel component that can be used to render any carousel items,
 * such as products, images, banners, or any component. Carousel items are
 * rendered in a horizontal list which can be scrolled horizontally with
 * a touch screen or touch pad or the forward/backward buttons a the edges
 * of the carousel.
 *
 * The component uses an array of Observables (`items$`) as an input, to allow
 * for lazy loading of items.
 *
 * To allow for flexible rendering of items, the rendering is delegated to the
 * given `template`. This allows for maximum flexibility.
 */
declare class CarouselScrollingComponent<Item = any> implements OnInit {
    protected logger: LoggerService;
    protected el: ElementRef<any>;
    /**
     * The title is rendered as the carousel heading.
     */
    title: string | undefined | null;
    /**
     * The items represent the carousel items. The items are
     * observables so that the items can be loaded on demand.
     */
    items: Observable<Item>[];
    /**
     * The template rendered for each carousel item
     */
    template: TemplateRef<CarouselScrollingTemplateContext<Item>>;
    previousIcon: ICON_TYPE$1;
    nextIcon: ICON_TYPE$1;
    /**
     * Angular's trackBy function for iterating over carousel items.
     *
     * For a given item it should return an unique identifier.
     * If not provided, it will fallback to returning the item directly
     * (like Angular's naive default trackBy).
     *
     * If the returned value is not unique, it may lead to unexpected behavior,
     * such as unwanted destroying and re-creating child templates on items array changes.
     */
    trackByFn: TrackByFunction<any>;
    ngOnInit(): void;
    onItemKeydown(event: KeyboardEvent): void;
    /**
     * Handles Tab key on carousel items. If the carousel items have `ArrowRight`/`ArrowLeft`
     * navigation enabled, it temporarily disables tab navigation for these items.
     * The `cxFocusableCarouselItem` selector is used because it identifies carousel
     * items that have `ArrowRight`/`ArrowLeft` navigation enabled. These items should not
     * use tab navigation according to a11y requirements.
     */
    protected skipTabForCarouselItems(): void;
    /**
     * Focuses the next or previous item in the carousel based on keyboard navigation.
     *
     * This method determines the next focusable carousel item, identified by the
     * `cxFocusableCarouselItem` directive, based on the current focus and the direction
     * given. It adjusts the carousel's active slide if the next focusable item is
     * outside the currently visible items.
     *
     * @param currentItem - The currently focused carousel item.
     * @param direction - The navigation direction (1 for right, -1 for left).
     * @param size - The number of items per slide, used to determine slide change is needed
     */
    protected focusNextPrevItem(currentItem: EventTarget | null, direction: number): void;
    /**
     * When a carousel item receives focus (e.g. via keyboard navigation),
     * but it's only partially visible in the viewport (not fully scrolled into),
     * this method ensures the item is scrolled into view.
     */
    onItemFocusIn(event: FocusEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CarouselScrollingComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CarouselScrollingComponent<any>, "cx-carousel-scrolling", never, { "title": { "alias": "title"; "required": false; }; "items": { "alias": "items"; "required": false; }; "template": { "alias": "template"; "required": false; }; "previousIcon": { "alias": "previousIcon"; "required": false; }; "nextIcon": { "alias": "nextIcon"; "required": false; }; "trackByFn": { "alias": "trackByFn"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CarouselScrollingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CarouselScrollingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CarouselScrollingModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof IconModule, typeof MediaModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof HorizontalScrollingPositionDirectiveModule, typeof CarouselScrollingComponent], [typeof CarouselScrollingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CarouselScrollingModule>;
}

declare class ProductCarouselModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductCarouselModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductCarouselModule, never, [typeof i1.CommonModule, typeof CarouselModule, typeof CarouselScrollingModule, typeof MediaModule, typeof i2$1.RouterModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof PageComponentModule, typeof i3.FeaturesConfigModule, typeof LcpContextDirectiveModule, typeof ProductCarouselComponent, typeof ProductCarouselItemComponent], [typeof ProductCarouselComponent, typeof ProductCarouselItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductCarouselModule>;
}

declare class ProductReferencesComponent {
    protected cmsComponentData: CmsComponentData<CmsProductReferencesComponent>;
    protected currentProductService: CurrentProductService;
    protected productReferenceService: ProductReferenceService;
    constructor(cmsComponentData: CmsComponentData<CmsProductReferencesComponent>, currentProductService: CurrentProductService, productReferenceService: ProductReferenceService);
    protected get componentData$(): Observable<CmsProductReferencesComponent>;
    /**
     * Returns an Observable String for the product code
     */
    protected get productCode$(): Observable<string>;
    /**
     * Returns an Observable String for the title
     */
    get title$(): Observable<string | undefined>;
    /**
     * Observable with an Array of Observables. This is done so that
     * the component UI could consider to lazy load the UI components when they're
     * in the viewpoint.
     */
    items$: Observable<Observable<Product | undefined>[]>;
    /**
     * Returns an observable for product references
     */
    private getProductReferences;
    trackByFn: TrackByFunction<Product>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductReferencesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductReferencesComponent, "cx-product-references", never, {}, {}, never, never, true, never>;
}

declare class ProductReferencesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductReferencesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductReferencesModule, never, [typeof i1.CommonModule, typeof CarouselModule, typeof CarouselScrollingModule, typeof MediaModule, typeof i2$1.RouterModule, typeof i3.UrlModule, typeof i3.FeaturesConfigModule, typeof ProductReferencesComponent], [typeof ProductReferencesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductReferencesModule>;
}

declare const defaultViewConfig: ViewConfig;

declare class ProductImagesComponent {
    protected currentProductService: CurrentProductService;
    protected mainMediaContainer: BehaviorSubject<any>;
    protected product$: Observable<Product>;
    thumbs$: Observable<any[]>;
    mainImage$: Observable<any>;
    constructor(currentProductService: CurrentProductService);
    openImage(item: any): void;
    isActive(thumbnail: ImageGroup): Observable<boolean>;
    /** find the index of the main media in the list of media */
    getActive(thumbs: any[]): Observable<number>;
    /**
     * Return an array of CarouselItems for the product thumbnails.
     * In case there are less then 2 thumbs, we return null.
     */
    private createThumbs;
    trackByFn: TrackByFunction<Product>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductImagesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductImagesComponent, "cx-product-images", never, {}, {}, never, never, true, never>;
}

declare class ProductImagesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductImagesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductImagesModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof MediaModule, typeof OutletModule, typeof CarouselModule, typeof CarouselScrollingModule, typeof LcpContextDirectiveModule, typeof ProductImagesComponent], [typeof ProductImagesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductImagesModule>;
}

declare class ProductIntroComponent {
    protected currentProductService: CurrentProductService;
    protected translationService: TranslationService;
    protected winRef: WindowRef;
    protected eventService: EventService;
    product$: Observable<Product | null>;
    /**
     * Observable that checks the reviews component availability on the page.
     *
     * @deprecated This observable controlled whether we should show reviews based
     * on the review component's existence. Instead, we are now using the "product.averageRating"
     * to check whether reviews should exist. This observable with therefore be removed.
     */
    areReviewsAvailable$: Observable<boolean>;
    protected reviewsComponentId: string;
    protected reviewsTranslationKey: string;
    constructor(currentProductService: CurrentProductService, translationService: TranslationService, winRef: WindowRef, eventService: EventService);
    /**
     * Scroll to views component on page and click "Reviews" tab
     */
    showReviews(): void;
    /**
     * Get Reviews Component if exists on page
     */
    protected getReviewsComponent(): HTMLElement | null;
    /**
     * Get Tabs Component if exists on page
     */
    private getTabsComponent;
    /**
     * Click to activate tab if not already active
     *
     * @param tab tab to click if needed
     */
    private clickTabIfInactive;
    /**
     * Get Tab by label if exists on page
     *
     * @param label label of searched tab
     * @param tabsComponent component containing tabs
     */
    private getTabByLabel;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductIntroComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductIntroComponent, "cx-product-intro", never, {}, {}, never, never, true, never>;
}

declare class ProductIntroModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductIntroModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductIntroModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof StarRatingModule, typeof i3.FeaturesConfigModule, typeof ProductIntroComponent], [typeof ProductIntroComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductIntroModule>;
}

declare class ProductSummaryComponent {
    protected currentProductService: CurrentProductService;
    outlets: typeof ProductDetailOutlets;
    product$: Observable<Product | null>;
    protected getProduct(): Observable<Product | null>;
    constructor(currentProductService: CurrentProductService);
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductSummaryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductSummaryComponent, "cx-product-summary", never, {}, {}, never, never, true, never>;
}

declare class ProductSummaryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductSummaryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductSummaryModule, never, [typeof i1.CommonModule, typeof OutletModule, typeof i3.I18nModule, typeof PromotionsModule, typeof i3.FeaturesConfigModule, typeof ProductSummaryComponent], [typeof ProductSummaryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductSummaryModule>;
}

declare class ProductAttributesComponent {
    protected currentProductService: CurrentProductService;
    product$: Observable<Product | null>;
    constructor(currentProductService: CurrentProductService);
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductAttributesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductAttributesComponent, "cx-product-attributes", never, {}, {}, never, never, true, never>;
}

declare class ProductAttributesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductAttributesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductAttributesModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof ProductAttributesComponent], [typeof ProductAttributesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductAttributesModule>;
}

declare class ProductDetailsTabComponent implements OnInit {
    protected currentProductService: CurrentProductService;
    protected componentData: CmsComponentData<CmsComponentWithChildren>;
    protected cmsService: CmsService;
    product$: Observable<Product | null>;
    constructor(currentProductService: CurrentProductService, componentData: CmsComponentData<CmsComponentWithChildren>, cmsService: CmsService);
    children$: Observable<any[]>;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductDetailsTabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductDetailsTabComponent, "cx-product-details-tab", never, {}, {}, never, never, true, never>;
}

declare class ProductDetailsTabModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductDetailsTabModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductDetailsTabModule, never, [typeof i1.CommonModule, typeof PageComponentModule, typeof OutletModule, typeof ProductDetailsTabComponent], [typeof ProductDetailsTabComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductDetailsTabModule>;
}

declare class ProductReviewsComponent {
    protected reviewService: ProductReviewService;
    protected currentProductService: CurrentProductService;
    private fb;
    protected cd: ChangeDetectorRef;
    titleInput: ElementRef;
    writeReviewButton: ElementRef;
    reviewItems: QueryList<ElementRef<HTMLElement>>;
    maxLengthReviewTitle: number;
    maxLengthReviewComment: number;
    maxLengthReviewerName: number;
    isWritingReview: boolean;
    initialMaxListItems: number;
    maxListItems: number;
    reviewForm: UntypedFormGroup;
    private featureConfigService;
    product$: Observable<Product | null>;
    reviews$: Observable<Review[]>;
    constructor(reviewService: ProductReviewService, currentProductService: CurrentProductService, fb: UntypedFormBuilder, cd: ChangeDetectorRef);
    initiateWriteReview(): void;
    cancelWriteReview(): void;
    setRating(rating: number): void;
    submitReview(product: Product): void;
    addReview(product: Product): void;
    focusNextReview(event: UIEvent, currentIndex: number): void;
    focusPreviousReview(event: UIEvent, currentIndex: number): void;
    private resetReviewForm;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductReviewsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductReviewsComponent, "cx-product-reviews", never, { "maxLengthReviewTitle": { "alias": "maxLengthReviewTitle"; "required": false; }; "maxLengthReviewComment": { "alias": "maxLengthReviewComment"; "required": false; }; "maxLengthReviewerName": { "alias": "maxLengthReviewerName"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Wraps the provided input text in a Read More / Read Less component, truncating input to maxLength
 * and adding "Read More" link. Clicking "Read More" reveals full text with a "Read Less"
 * option to collapse it back.
 */
declare class ReadMoreComponent implements OnChanges {
    readMoreI18nKey?: string | Translatable;
    readLessI18nKey?: string | Translatable;
    maxLength: number;
    text: string | undefined;
    showReadMore: boolean;
    isCollapsed: boolean;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadMoreComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadMoreComponent, "cx-read-more", never, { "readMoreI18nKey": { "alias": "readMoreI18nKey"; "required": false; }; "readLessI18nKey": { "alias": "readLessI18nKey"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "text": { "alias": "text"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ProductReviewsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductReviewsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductReviewsModule, never, [typeof i1.CommonModule, typeof i2$2.ReactiveFormsModule, typeof i2$2.FormsModule, typeof i3.I18nModule, typeof StarRatingModule, typeof FormErrorsModule, typeof i3.FeaturesConfigModule, typeof FormRequiredAsterisksComponent, typeof FormRequiredLegendComponent, typeof ReadMoreComponent, typeof ProductReviewsComponent], [typeof ProductReviewsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductReviewsModule>;
}

declare class ProductTabsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductTabsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductTabsModule, never, [typeof ProductAttributesModule, typeof ProductDetailsTabModule, typeof ProductReviewsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductTabsModule>;
}

declare class StockNotificationDialogComponent implements OnInit, OnDestroy {
    private interestsService;
    protected launchDialogService: LaunchDialogService;
    protected el: ElementRef;
    private subscription;
    subscribeSuccess$: Observable<boolean>;
    enabledPrefs: NotificationPreference[];
    focusConfig: FocusConfig;
    handleClick(event: UIEvent): void;
    constructor(interestsService: UserInterestsService, launchDialogService: LaunchDialogService, el: ElementRef);
    close(reason?: any): void;
    ngOnInit(): void;
    init(subscribeSuccess$: Observable<boolean>, enabledPrefs: NotificationPreference[]): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StockNotificationDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StockNotificationDialogComponent, "cx-stock-notification-dialog", never, {}, {}, never, never, true, never>;
}

declare class StockNotificationComponent implements OnInit, OnDestroy {
    private currentProductService;
    private globalMessageService;
    private translationService;
    private interestsService;
    private notificationPrefService;
    private userIdService;
    protected launchDialogService: LaunchDialogService;
    protected vcr: ViewContainerRef;
    hasProductInterests$: Observable<boolean>;
    prefsEnabled$: Observable<boolean>;
    outOfStock$: Observable<boolean>;
    isRemoveInterestLoading$: Observable<boolean>;
    anonymous: boolean;
    private enabledPrefs;
    private productCode;
    private subscribeSuccess$;
    private subscriptions;
    element: ElementRef;
    constructor(currentProductService: CurrentProductService, globalMessageService: GlobalMessageService, translationService: TranslationService, interestsService: UserInterestsService, notificationPrefService: UserNotificationPreferenceService, userIdService: UserIdService, launchDialogService: LaunchDialogService, vcr: ViewContainerRef);
    ngOnInit(): void;
    subscribe(): void;
    unsubscribe(): void;
    private onInterestRemovingSuccess;
    private onInterestAddingError;
    private openDialog;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StockNotificationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StockNotificationComponent, "cx-stock-notification", never, {}, {}, never, never, true, never>;
}

declare class StockNotificationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<StockNotificationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StockNotificationModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof i3.I18nModule, typeof SpinnerModule, typeof i3.UrlModule, typeof KeyboardFocusModule, typeof i3.FeaturesConfigModule, typeof StockNotificationComponent, typeof StockNotificationDialogComponent], [typeof StockNotificationComponent, typeof StockNotificationDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StockNotificationModule>;
}

/**
 * This module enables to quickly switch from Resource Owner Password Flow
 * to Implicit Flow or Authorization Code Flow. The `login` route in this case will be
 * responsible for initalizing the redirect to OAuth server to login.
 *
 * Instead of manually invoking OAuth redirect you only have to redirect to `login` page.
 */
declare class LoginRouteModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginRouteModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LoginRouteModule, never, [typeof PageLayoutModule, typeof i2$1.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LoginRouteModule>;
}

/**
 * Guards the _login_ route.
 *
 * Takes care of routing the user to a auth server login page (if implicit or code flow is used).
 * In case of Resource Owner Password Flow just renders the page as normal CMS page.
 */
declare class LoginGuard {
    protected authService: AuthService;
    protected authConfigService: AuthConfigService;
    protected cmsPageGuard: CmsPageGuard;
    constructor(authService: AuthService, authConfigService: AuthConfigService, cmsPageGuard: CmsPageGuard);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<GuardResult>;
    protected shouldRenderCMSPage(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoginGuard>;
}

/**
 * Guards the _logout_ route.
 *
 * Takes care of routing the user to a logout page (if available) or redirects to
 * the homepage. If the homepage is protected, the user is redirected
 * to the login route instead.
 */
declare class LogoutGuard {
    protected auth: AuthService;
    protected cms: CmsService;
    protected semanticPathService: SemanticPathService;
    protected protectedRoutes: ProtectedRoutesService;
    protected router: Router;
    constructor(auth: AuthService, cms: CmsService, semanticPathService: SemanticPathService, protectedRoutes: ProtectedRoutesService, router: Router);
    canActivate(): Observable<GuardResult>;
    protected logout(): Promise<any>;
    /**
     * Whenever there is no specific "logout" page configured in the CMS,
     * we redirect after the user is logged out.
     *
     * The user gets redirected to the homepage, unless the homepage is protected
     * (in case of a closed shop). We'll redirect to the login page instead.
     */
    protected getRedirectUrl(): UrlTree;
    static ɵfac: i0.ɵɵFactoryDeclaration<LogoutGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LogoutGuard>;
}

declare class LogoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LogoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LogoutModule, never, [typeof PageLayoutModule, typeof i2$1.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LogoutModule>;
}

declare class UserComponentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserComponentModule, never, [typeof LogoutModule, typeof LoginRouteModule, typeof i2$2.ReactiveFormsModule, typeof i2$1.RouterModule, typeof i3.UrlModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserComponentModule>;
}

declare const IS_GUEST_USER_CHECKOUT_KEY = "isGuestUserCheckout";

declare class ProductDetailsPageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductDetailsPageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductDetailsPageModule, never, [typeof i2$1.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductDetailsPageModule>;
}

/**
 * Injection token with url matcher factory for PDP.
 * The provided url matcher matches both:
 * - the configured `paths` from routing config and
 * - custom pattern  `** / p / :productCode`
 *
 * If the this matcher doesn't fit the requirements, it can be replaced with the DEFAULT_URL_MATCHER
 * or additional matchers can be added for a specific route.
 *
 * Note: Matchers will "match" a route, but do not contribute to the creation of the route, nor do they guard routes.
 */
declare const PRODUCT_DETAILS_URL_MATCHER: InjectionToken<UrlMatcherFactory>;

declare class ProductListingPageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductListingPageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductListingPageModule, never, [typeof i2$1.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductListingPageModule>;
}

/**
 * Injection token with url matcher factory for PLP.
 * The provided url matcher matches both:
 * - the configured `paths` from routing config and
 * - custom pattern  `** / c / :categoryCode`
 *
 * If the this matcher doesn't fit the requirements, it can be replaced with the DEFAULT_URL_MATCHER
 * or additional matchers can be added for a specific route.
 *
 * Note: Matchers will "match" a route, but do not contribute to the creation of the route, nor do they guard routes.
 */
declare const PRODUCT_LISTING_URL_MATCHER: InjectionToken<UrlMatcherFactory>;

type ContextToken = string | symbol;

/**
 * Resolves the context for the specific route, based on the property `data.cxContext`
 * defined in the Angular Route.
 */
declare class RoutingContextService {
    protected activatedRoutesService: ActivatedRoutesService;
    protected injector: UnifiedInjector;
    constructor(activatedRoutesService: ActivatedRoutesService, injector: UnifiedInjector);
    /**
     * Combined context token mapping consisting of all mappings defined in currently
     * Activated Angular Routes.
     *
     * The context token mapping is read from each Route's property `data.cxContext`.
     */
    protected readonly contextTokenMapping$: Observable<Record<ContextToken, any>>;
    /**
     * Returns the merged context token mapping, consisting of mappings
     * defined in all Activated Angular Routes.
     */
    protected getRoutesContextTokenMapping(routes: ActivatedRouteSnapshot[]): Record<ContextToken, any>;
    /**
     * Resolves the specified `contextToken` from `cxContext` data parameter of the activated Angular Routes.
     * @param contextToken
     *
     * @returns instance from the root injector if defined, otherwise `undefined`.
     */
    get<T>(contextToken: ContextToken): Observable<T | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RoutingContextService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RoutingContextService>;
}

/**
 * Generic service for resolving the context for the UI components.
 */
declare class ContextService {
    protected routingContextService: RoutingContextService;
    constructor(routingContextService: RoutingContextService);
    /**
     * Returns the context for the given token.
     */
    get<T>(contextToken: ContextToken): Observable<T | undefined>;
    /**
     * Resolves the context for the given token.
     */
    protected resolveContext<T>(contextToken: ContextToken): Observable<T | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContextService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ContextService>;
}

/**
 * Indicates that a user navigated to an arbitrary page.
 */
declare class NavigationEvent extends CxEvent {
    /**
     * Event's type
     */
    static readonly type = "NavigationEvent";
    /**
     * The page's context
     */
    context: PageContext;
    /**
     * The route's semantic name
     */
    semanticRoute?: string;
    /**
     * The current URL
     */
    url: string;
    /**
     * The current URL's params
     */
    params: Params;
}

/**
 * Indicates that a user visited an arbitrary page.
 */
declare abstract class PageEvent extends CxEvent {
    /**
     * `NavigationEvent`'s payload
     */
    navigation: NavigationEvent;
}

/**
 * Indicates that a user visited a home page.
 */
declare class HomePageEvent extends PageEvent {
    /** event's type */
    static readonly type = "HomePageEvent";
}

declare class HomePageEventBuilder {
    protected eventService: EventService;
    constructor(eventService: EventService);
    protected register(): void;
    protected buildHomePageEvent(): Observable<HomePageEvent>;
    static ɵfac: i0.ɵɵFactoryDeclaration<HomePageEventBuilder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HomePageEventBuilder>;
}

declare class HomePageEventModule {
    constructor(_homePageEventBuilder: HomePageEventBuilder);
    static ɵfac: i0.ɵɵFactoryDeclaration<HomePageEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HomePageEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HomePageEventModule>;
}

/**
 * A builder for the NavigationEvent
 */
declare class NavigationEventBuilder {
    protected actions: ActionsSubject;
    protected eventService: EventService;
    constructor(actions: ActionsSubject, eventService: EventService);
    /**
     * Registers events
     */
    protected register(): void;
    /**
     * Builds the navigation events
     */
    protected buildNavigationEvent(): Observable<NavigationEvent>;
    private getNavigatedEvent;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavigationEventBuilder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NavigationEventBuilder>;
}

declare class NavigationEventModule {
    constructor(_navigationEventBuilder: NavigationEventBuilder);
    static ɵfac: i0.ɵɵFactoryDeclaration<NavigationEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NavigationEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NavigationEventModule>;
}

/**
 * Indicates that a user visited a product details page.
 */
declare class ProductDetailsPageEvent extends PageEvent {
    /** event's type */
    static readonly type = "ProductDetailsPageEvent";
    categories?: Category[];
    code?: string;
    name?: string;
    price?: Price;
}
/**
 * Indicates that a user visited a category page.
 */
declare class CategoryPageResultsEvent extends PageEvent {
    /** event's type */
    static readonly type = "CategoryPageResultsEvent";
    categoryCode: string;
    categoryName?: string;
    numberOfResults: Number;
}
/**
 * Indicates that the a user visited the search results page,
 * and that the search results have been retrieved.
 */
declare class SearchPageResultsEvent extends PageEvent {
    /** event's type */
    static readonly type = "SearchPageResultsEvent";
    searchTerm: string;
    numberOfResults: Number;
}

declare class ProductPageEventBuilder {
    protected eventService: EventService;
    protected productService: ProductService;
    protected productSearchService: ProductSearchService;
    constructor(eventService: EventService, productService: ProductService, productSearchService: ProductSearchService);
    protected register(): void;
    protected buildProductDetailsPageEvent(): Observable<ProductDetailsPageEvent>;
    protected buildCategoryResultsPageEvent(): Observable<CategoryPageResultsEvent>;
    protected buildSearchPageResultsEvent(): Observable<SearchPageResultsEvent>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductPageEventBuilder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductPageEventBuilder>;
}

declare class ProductPageEventModule {
    constructor(_productPageEventBuilder: ProductPageEventBuilder);
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductPageEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductPageEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductPageEventModule>;
}

/**
 * Provides configuration specific to Media, such as images. This is used to optimize
 * rendering of the media, SEO and performance.
 */
declare abstract class MediaConfig {
    /**
     * Config properties related to media component
     */
    media?: {
        /**
         * Picture element configuration holds the media queries assigned to
         * a format.
         * The order of formats matters.
         * <source> elements in <picture> will be sorted based on this order.
         * This is necessary because the browser evaluates each
         * <source> element in order and uses the first one that matches.
         */
        pictureElementFormats?: {
            [format: string]: {
                mediaQueries?: PictureElementQueries;
            };
        };
        /**
         * Used to specify the order of formats.
         * <source> elements in <picture> will be sorted based on this order.
         * This is necessary because the browser evaluates each
         * <source> element in order and uses the first one that matches.
         *
         * @example
         * ['mobile', 'tablet', 'desktop']
         */
        pictureFormatsOrder?: string[];
    };
    /**
     * Media _format_ configuration holds the size of the media's assigned to
     * a format.
     */
    mediaFormats?: {
        /**
         * Represents the media format code, that is the key to distinguish different
         * media in a container.
         */
        [format: string]: MediaFormatSize;
    };
    /**
     * Indicates how the browser should load the image. There's only one
     * global strategy for all media cross media in Spartacus.
     *
     * See https://developer.mozilla.org/en-US/docs/Web/HTML/Element/img for more
     * information.
     *
     * If the `lazy` strategy is in place, the `loading="lazy"` attribute is added to the
     * img element.
     */
    imageLoadingStrategy?: ImageLoadingStrategy;
    static ɵfac: i0.ɵɵFactoryDeclaration<MediaConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MediaConfig>;
}
declare module '@spartacus/core' {
    interface Config extends MediaConfig {
    }
}

declare const mediaConfig: MediaConfig;

/**
 * The layout configuration is used to define the overall layout of the storefront.
 * The configuration includes the following aspects:
 * - breakpoint layout (AKA screen layout)
 * - Page sections slot configuration (i.e. header vs footer)
 * - page template slot configuration (i.e. landing page template vs PDP page template)
 * - deferred loading configuration
 *
 * The page slot configurations is directly related to the data in the backend. If you use the
 * Spartacus sample-data, you will have an aligned setup. However, if you introduce custom page
 * templates and/or slots, you most likely need to further adjust or replace this configuration.
 *
 *@deprecated Use `layoutConfigFactory` and `provideConfigFactory(layoutConfigFactory)` instead.
 */
declare const layoutConfig: LayoutConfig;
/**
 * Factory for layout configuration.
 */
declare function layoutConfigFactory(): LayoutConfig;

declare const defaultCmsContentProviders: ValueProvider[];

declare abstract class OnNavigateConfig {
    enableResetViewOnNavigate?: {
        active?: boolean;
        ignoreQueryString?: boolean;
        ignoreRoutes?: string[];
        /**
         * When set, finds the element with the tag name matching this string
         * to return focus to on navigation.
         *
         * Uses hostComponent when unset.
         */
        selectedHostElement?: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<OnNavigateConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OnNavigateConfig>;
}
declare module '@spartacus/core' {
    interface Config extends OnNavigateConfig {
    }
}

declare const defaultOnNavigateConfig: OnNavigateConfig;

declare class OnNavigateService {
    protected config: OnNavigateConfig;
    protected router: Router;
    protected viewportScroller: ViewportScroller;
    protected injector: Injector;
    protected readonly routerConfiguration: i2$1.ExtraOptions;
    protected subscription: Subscription;
    get hostComponent(): ComponentRef<any>;
    get selectedHostElement(): HTMLElement | undefined;
    constructor(config: OnNavigateConfig, router: Router, viewportScroller: ViewportScroller, injector: Injector);
    /**
     * Reads configuration and enables features based on flags set.
     */
    initializeWithConfig(): void;
    /**
     * Resets view back to the original position when performing a back navigation and to the top when performing a front navigation
     * and sets the focus back to the top of the page before skiplinks for any type of navigation
     * @param enable Enable or disable this feature
     */
    setResetViewOnNavigate(enable: boolean): void;
    /**
     * Focus on selectedHostElement if set in config.
     * Otherwise, focuses on hostComponent.
     */
    protected focusOnHostElement(): void;
    /**
     * Scrolls to a specified position or anchor based on the current route and configuration.
     * @param currentRoute The current route containing scroll information.
     * @param position The target scroll position as [x, y] coordinates, or null.
     */
    private scrollToPosition;
    /**
     * Verifies if the current route is a child route from the given ignore config route
     *
     * @param route
     * @returns boolean whether the route is a child route
     */
    private isChildRoute;
    /**
     * Verifies if the previous and current route are the same without the query string
     *
     * @param previousRoute
     * @param currentRoute
     * @returns boolean depending on the previous and current route are equal without the query strings
     */
    private isPathEqual;
    /**
     * Verifies if router event is a navigation end event
     * @private
     */
    private isNavigationEnd;
    static ɵfac: i0.ɵɵFactoryDeclaration<OnNavigateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OnNavigateService>;
}

declare class AppRoutingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AppRoutingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AppRoutingModule, never, [typeof i2$1.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AppRoutingModule>;
}
declare function onNavigateFactory(onNavigateService: OnNavigateService): () => void;

declare class AnonymousConsentDialogComponent implements OnInit, OnDestroy {
    protected config: AnonymousConsentsConfig;
    protected anonymousConsentsService: AnonymousConsentsService;
    protected el: ElementRef;
    protected launchDialogService: LaunchDialogService;
    protected winRef: WindowRef;
    private subscriptions;
    showLegalDescription: boolean | undefined;
    iconTypes: typeof ICON_TYPE$1;
    requiredConsents: string[];
    loading$: Observable<boolean>;
    templates$: Observable<ConsentTemplate[]>;
    consents$: Observable<AnonymousConsent[]>;
    focusConfig: FocusConfig;
    /**
     * We store the selected input when making a selection to restore the focus to
     * this element after closing the message dialog.
     */
    selectedInput: HTMLElement;
    globalMessageService: GlobalMessageService | null;
    globalMessageType: typeof GlobalMessageType;
    message$: Subject<{
        type: GlobalMessageType;
        key: string;
    } | null>;
    handleClick(event: UIEvent): void;
    constructor(config: AnonymousConsentsConfig, anonymousConsentsService: AnonymousConsentsService, el: ElementRef, launchDialogService: LaunchDialogService);
    ngOnInit(): void;
    close(reason?: any): void;
    rejectAll(): void;
    allowAll(): void;
    private isRequiredConsent;
    onConsentChange({ given, template, }: {
        given: boolean;
        template: ConsentTemplate;
    }): void;
    getCorrespondingConsent(template: ConsentTemplate, consents?: AnonymousConsent[]): AnonymousConsent | null;
    protected onConsentGivenSuccess(): void;
    protected onConsentWithdrawnSuccess(): void;
    closeMessage(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnonymousConsentDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AnonymousConsentDialogComponent, "cx-anonymous-consent-dialog", never, {}, {}, never, never, true, never>;
}

declare class AnonymousConsentsDialogModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AnonymousConsentsDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AnonymousConsentsDialogModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof IconModule, typeof SpinnerModule, typeof ConsentManagementModule, typeof KeyboardFocusModule, typeof i3.FeaturesConfigModule, typeof MessageComponentModule, typeof AnonymousConsentDialogComponent], [typeof AnonymousConsentDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AnonymousConsentsDialogModule>;
}

/**
 * Service that provides the placeholder and input pattern for date pickers. This is
 * used in Spartacus to support browser that won't support the native html5 date picker
 * using `<input type="date">`.
 *
 * While the placeholder is configurable, you should be aware that the placeholder format
 * defaults to `yyyy-mm-dd` to align with Safaris limited support of ISO 8601.
 * Another consideration is the support of date formats in the backend. In case you change
 * this format, you might need to serialize the date to the supported date format in the
 * backend.
 *
 */
declare class DatePickerService {
    get placeholder(): string;
    /**
     * The default date pattern is based on the placeholder string;
     */
    get pattern(): string;
    /**
     * Validates if the string based date value is a valid date.
     */
    isValidFormat(date: string, pattern?: string): boolean;
    /**
     * Since Safari doesn't support proper date formats (ISO 8601), we need to do this
     * ourselves. We cannot rely on `new Date('2020-1-1')`. This will fail, only
     * `new Date('2020-01-01')` works.
     */
    getDate(value: string): Date | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatePickerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DatePickerService>;
}

/**
 * Component that adds a date control. While the native date picker works in most
 * modern browsers, some browsers need more guidance (placeholder), validation and
 * date conversion.
 *
 * The data picker supports (optional) min and max form controls, so that you can
 * limit the start and/or end date.
 *
 * Most of the implementation is done in the `DatePickerFallbackDirective`.
 */
declare class DatePickerComponent {
    protected service: DatePickerService;
    constructor(service: DatePickerService);
    control: UntypedFormControl;
    min?: string;
    max?: string;
    required?: boolean;
    label?: string;
    update: EventEmitter<void>;
    change(): void;
    get placeholder(): string;
    get pattern(): string;
    /**
     * Only returns the date if we have a valid format. We do this to avoid
     * loads of console errors coming from the datePipe while the user is typing
     * (in those browsers where the date picker isn't supported).
     */
    getDate(date?: string): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatePickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DatePickerComponent, "cx-date-picker", never, { "control": { "alias": "control"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "required": { "alias": "required"; "required": false; }; "label": { "alias": "label"; "required": false; }; }, { "update": "update"; }, never, never, true, never>;
}

declare class DatePickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DatePickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DatePickerModule, never, [typeof i1.CommonModule, typeof i2$2.ReactiveFormsModule, typeof FormErrorsModule, typeof i3.I18nModule, typeof i3.FeaturesConfigModule, typeof DatePickerComponent], [typeof DatePickerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DatePickerModule>;
}

/**
 * Component that adds a file upload control.
 */
declare class FileUploadComponent implements ControlValueAccessor {
    /**
     * Allowed file types. It's setting attribute used for OS window for choosing files.
     */
    accept?: string | string[];
    /**
     * Allows selecting multiple files.
     */
    multiple?: boolean;
    /**
     * Use custom button html passed from parent.
     */
    customButton: any;
    update: EventEmitter<FileList | null>;
    protected fileInput: ElementRef<HTMLInputElement>;
    selectFile($event: Event): void;
    removeFile(): void;
    get selectedFiles(): File[] | undefined;
    protected onChangeCallback: Function;
    protected onTouchedCallback: Function;
    registerOnChange(callback: Function): void;
    registerOnTouched(callback: Function): void;
    setDisabledState(disabled: boolean): void;
    writeValue(value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileUploadComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileUploadComponent, "cx-file-upload", never, { "accept": { "alias": "accept"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; }, { "update": "update"; }, ["customButton"], ["*"], true, never>;
}

declare class FileUploadModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FileUploadModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FileUploadModule, never, [typeof i1.CommonModule, typeof i2$2.ReactiveFormsModule, typeof FormErrorsModule, typeof i3.I18nModule, typeof KeyboardFocusModule, typeof FileUploadComponent], [typeof FileUploadComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FileUploadModule>;
}

declare abstract class FormConfig {
    form?: {
        passwordVisibilityToggle: boolean;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<FormConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormConfig>;
}
declare module '@spartacus/core' {
    interface Config extends FormConfig {
    }
}

/**
 * Directive to bind a PasswordVisibilityToggleDirective to a password input field. This
 * toggle while alternate the appearance of the input between dots and plain text.
 */
declare class PasswordVisibilityToggleDirective implements AfterViewInit {
    protected winRef: WindowRef;
    protected config: FormConfig;
    protected elementRef: ElementRef;
    protected viewContainerRef: ViewContainerRef;
    protected changeDetectorRef: ChangeDetectorRef;
    protected inputWrapper: HTMLElement | null;
    constructor(winRef: WindowRef, config: FormConfig, elementRef: ElementRef, viewContainerRef: ViewContainerRef, changeDetectorRef: ChangeDetectorRef);
    ngAfterViewInit(): void;
    protected insertComponent(): void;
    /**
     * We need to wrap the input element in a div to be able to position the toggle button in the right place.
     */
    protected wrapInput(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PasswordVisibilityToggleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PasswordVisibilityToggleDirective, "[cxPasswordVisibilitySwitch][type=\"password\"]", never, {}, {}, never, never, true, never>;
}

interface PasswordInputState {
    icon: ICON_TYPE$1;
    inputType: string;
    ariaLabel: string;
}

declare class PasswordVisibilityToggleComponent {
    protected showState: PasswordInputState;
    protected hideState: PasswordInputState;
    inputElement: HTMLInputElement;
    state: PasswordInputState;
    /**
     * Toggle the visibility of the text of the input field.
     */
    toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PasswordVisibilityToggleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PasswordVisibilityToggleComponent, "cx-password-visibility-toggle", never, { "inputElement": { "alias": "inputElement"; "required": false; }; }, {}, never, never, true, never>;
}

declare class PasswordVisibilityToggleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PasswordVisibilityToggleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PasswordVisibilityToggleModule, never, [typeof i1.CommonModule, typeof IconModule, typeof i3.I18nModule, typeof PasswordVisibilityToggleDirective, typeof PasswordVisibilityToggleComponent], [typeof PasswordVisibilityToggleDirective, typeof PasswordVisibilityToggleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PasswordVisibilityToggleModule>;
}

declare const defaultPaginationConfig: PaginationConfig;

declare class ProgressButtonComponent {
    ariaLabel: string;
    class: string;
    disabled: boolean;
    loading: boolean;
    clickEvent: EventEmitter<void>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProgressButtonComponent, "cx-progress-button", never, { "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "class": { "alias": "class"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; }, { "clickEvent": "clickEvent"; }, never, ["*"], true, never>;
}

declare class ProgressButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProgressButtonModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof ProgressButtonComponent], [typeof ProgressButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProgressButtonModule>;
}

/**
 * Maintains the visibility state of the View Component.
 *
 */
interface SplitViewState {
    hidden?: boolean;
}

/**
 * Supposed to be injected in the split view component, so that the split view state
 * is maintained for a single split view.
 */
declare class SplitViewService {
    /**
     * Newly added views are hidden by default, unless it is the first view of the split view.
     * The default hide mode can be overridden.
     */
    defaultHideMode: boolean;
    protected splitViewCount: number;
    protected _views$: BehaviorSubject<SplitViewState[]>;
    /**
     * Adds a view to the list of views. The view is initialized with the `SplitViewState`
     * state. If no state is provided, the state is created with the hidden property. The hidden
     * property is provided by the `defaultHideMode`, unless it's the first view (position: 0).
     */
    add(position: number, initialState?: SplitViewState): void;
    /**
     * The split view is based on a number of views that can be used next to each other.
     * When the number changes (i.e. if the screen goes from wide to small), the visibility state
     * of the views should be updated.
     */
    updateSplitView(splitViewCount: number): void;
    /**
     * Returns an observable with the active view number. The active view number
     * represents the last visible view.
     */
    getActiveView(): Observable<number>;
    /**
     * Returns an observable with the SplitViewState for the given view position.
     */
    getViewState(position: number): Observable<SplitViewState>;
    /**
     * Removes a view from the list of views.
     *
     * Removing a view is different from hiding a view. Removing a view is typically done
     * when a component is destroyed.
     *
     * When the view is removed, the SplitViewState is updated to reflect that new organization
     * of views.
     */
    remove(position: number): void;
    /**
     * Returns the next view position. This is useful for views that do not want to be bothered
     * with controlling view numbers.
     */
    get nextPosition(): number;
    /**
     * Toggles the visibility of the views based on the given view position. If the view
     * is already visible, we close the view and active the former view. Unless the hide flag
     * is used, to force the view.
     *
     * The view state of other views in the split view are updated as well.
     *
     * @param position The zero-based position number of the view.
     * @param forceHide The (optional) hide state for the view position.
     */
    toggle(position: number, forceHide?: boolean): void;
    /**
     * Updates the hidden state of all the views.
     */
    protected updateState(position?: number, hide?: boolean): void;
    /**
     * Returns the active view count for the list of views.
     */
    protected getActive(views: SplitViewState[]): number;
    /**
     * Utility method that resolves all views from the subject.
     */
    protected get views(): SplitViewState[];
    static ɵfac: i0.ɵɵFactoryDeclaration<SplitViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SplitViewService>;
}

/**
 * The split-view component supports an unlimited number of nested views. The component
 * is a host to those view components and doesn't add any restrictions to it's content;
 * content is projected as-is.
 *
 * ```html
 * <cx-split-view>
 *   <cx-view></cx-view>
 *   <cx-view></cx-view>
 *   <any-wrapper>
 *     <cx-view></cx-view>
 *   </any-wrapper>
 * </cx-split-view>
 * ```
 *
 * The split view component is only concerned with tracking the underlying _visible_
 * view components, so that the `lastVisibleView` can be updated accordingly. The actual
 * visibility of views is controlled by CSS. To allow for maximum flexibility, the CSS
 * implementation is using CSS variables. The `lastVisibleView` is bind to the
 * `--cx-active-view` on the host, so that all descendants views will inherit the
 * property conveniently.
 */
declare class SplitViewComponent implements OnInit, OnDestroy {
    protected splitService: SplitViewService;
    protected breakpointService: BreakpointService;
    protected elementRef: ElementRef;
    private subscription;
    /**
     * Sets the default hide mode for views. This mode is useful in case views are dynamically being created,
     * for example when they are created by router components.
     *
     * The mode defaults to true, unless this is the first view; the first view is never hidden.
     */
    set hideMode(mode: boolean);
    /**
     * Indicates the last visible view in the range of views that is visible. This
     * is bind to a css variable `--cx-active-view` so that the experience
     * can be fully controlled by css.
     */
    lastVisibleView: number;
    constructor(splitService: SplitViewService, breakpointService: BreakpointService, elementRef: ElementRef);
    ngOnInit(): void;
    /**
     * Returns the maximum number of views per split-view. The number is based on the
     * CSS custom property `--cx-max-views`.
     */
    protected get splitViewCount(): number;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SplitViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SplitViewComponent, "cx-split-view", never, { "hideMode": { "alias": "hideMode"; "required": false; }; }, {}, never, ["*"], true, never>;
}

/**
 * The view component is part of the `SplitViewComponent`. The view
 * contains the navigable content that should be split up. It maintains
 * a view position and allows to show or hide the view.
 *
 * The ViewComponent interacts with the `SplitViewService` for handing over the
 * view state, so that the overarching `SplitViewComponent` can manage the
 * overall experience.
 */
declare class ViewComponent implements OnInit, OnDestroy {
    protected splitService: SplitViewService;
    protected elementRef: ElementRef;
    protected cd: ChangeDetectorRef;
    protected _hidden: boolean | undefined;
    position: string;
    /**
     * The disappeared flag is added to the
     */
    disappeared: boolean | undefined;
    /**
     * The hidden input is used to set the initial visible state of the view.
     * The hidden state defaults to false.
     *
     * The hidden input supports 2-way binding, see `hiddenChange` property.
     */
    set hidden(hidden: boolean);
    /**
     * An update of the view visibility is emitted to the hiddenChange output.
     */
    hiddenChange: EventEmitter<any>;
    viewTitle?: string;
    protected globalMessageService: GlobalMessageService;
    protected subscription: Subscription;
    constructor(splitService: SplitViewService, elementRef: ElementRef, cd: ChangeDetectorRef);
    ngOnInit(): void;
    /**
     * Toggles the visibility of the view.
     *
     * An optional force flag can be used to explicitly show or hide view component.
     */
    toggle(force?: boolean): void;
    /**
     * Returns the position for the view.
     *
     * The position is either taken from the input `position` or generated by the `SplitService`.
     */
    protected get viewPosition(): number;
    /**
     * Returns the duration in milliseconds. The duration is based on the CSS custom property
     * `--cx-transition-duration`. Defaults to 300 milliseconds.
     */
    protected get duration(): number;
    protected onViewChangeShowAssistiveMessage(): void;
    /**
     * The view is removed from the `SplitService` so that the view no longer
     * plays a role in the overall split view.
     */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewComponent, "cx-view", never, { "position": { "alias": "position"; "required": false; }; "hidden": { "alias": "hidden"; "required": false; }; "viewTitle": { "alias": "viewTitle"; "required": false; }; }, { "hiddenChange": "hiddenChange"; }, never, ["*"], true, never>;
}

/**
 * The split-view component supports an unlimited number of nested views. Nested views are rendered
 * next to each other. The views can be rendered next to each other, but the max number of visible
 * views can be limisted as well. This is configurable in the CSS layer, so that the max number of views
 * per split-view can be different for each component.
 *
 * The basic structure of the split-view component is shown below:
 *
 *
 * ```
 * <cx-split-view>
 * </cx-split-view>
 * ```
 *
 * The UX pattern used for the split-view is driven by an initial view, which gets splitted into
 * more views as soon as the user starts interacting with the initial and subsequantial views.
 * The views can be driven by routes, which means that you can navigate through the splitted views
 * by using the browser history as well as share or bookmark splitted views.
 *
 * The UI is implemented in the style layer, with only a few generic style rules. Most of the split
 * view style is driven by CSS properties, so that alternative split-view styles can be introduced
 * per page or component.
 *
 * The max number of views per split-view on mobile is limited to 1 by default, where as on tablet
 * (and higher) it is set to 2. Spartacus has a pretty narrow layout, which is why 2 is maximum,
 * but customers could alter the layout to bring in more views in the same split-view at the time.
 *
 */
declare class SplitViewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SplitViewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SplitViewModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof SplitViewComponent, typeof ViewComponent], [typeof SplitViewComponent, typeof ViewComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SplitViewModule>;
}

/**
 * Contains the table data and structure for the `TableComponent`.
 */
interface Table<T = any> {
    /**
     * The table structure provides details about the headers of the table.
     */
    structure: TableStructure;
    /**
     * The data that is listed in the table component.
     */
    data: T[];
    /**
     * The pagination component is used to paginate through the data.
     */
    pagination?: PaginationModel;
    /**
     * The sort options for the table.
     */
    sorts?: any[];
}
interface TableStructureConfiguration {
    /**
     * Provide the bare structure of the table.
     */
    cells?: string[];
    /**
     * Global table structure options.
     */
    options?: TableOptions;
}
interface TableOptions {
    /**
     * Default pagination for the table that is used for the initial load of the table data.
     */
    pagination?: PaginationModel;
    /**
     * The layout for the table component can be used for horizontal, vertical and vertical stacked
     * table layouts.
     */
    layout?: TableLayout;
    /**
     * Global component to render table header _content_ (`<th>...</th>`). A specific component per
     * field can be configured alternatively.
     *
     * If no component is available, the table component will render a static label or use the
     * configured i18n label.
     */
    headerComponent?: Type<any>;
    /**
     * Global component to render table cell _content_ (`<td>...</td>`). A specific component per
     * field can be configured alternatively.
     *
     * If no component is available, the table content will render as-is.
     */
    dataComponent?: Type<any>;
    cells?: {
        [fieldKey: string]: TableFieldOptions;
    };
}
/**
 * Layout orientation for the table configuration.
 */
declare enum TableLayout {
    /**
     * Renders the table vertically, with a heading on top of the table.
     *
     * Vertical layout is most common and the default layout.
     */
    VERTICAL = 1,
    /**
     * Stacks items in a tables by generating a `tbody` for each item.
     */
    VERTICAL_STACKED = 2,
    /**
     * Horizontal oriented table layout renders the table headers in the first column of the table.
     */
    HORIZONTAL = 3
}
interface TableFieldOptions {
    /**
     * Optional label to add static or localized headers. If the label is not present, the
     * field key is mapped to a i18n property.
     */
    label?: string | TableHeader;
    /**
     * Indicates wether the cell is linkable.
     *
     * If the cells is linkable, an anchor link can be generated in the table data element.
     */
    linkable?: boolean;
    /**
     * Component to render table header _content_ (`<th>...</th>`) for the table field.
     *
     * If no component is configured, the global table component for the header will be used
     * instead.
     */
    headerComponent?: Type<any>;
    /**
     * Component to render table data _content_ (`<td>...</td>`) for the table field.
     *
     * If no component is configured, the global table component for the cell data will be used
     * instead.
     */
    dataComponent?: Type<any>;
}
/**
 * The TableStructure holds the header structure of the table.
 */
interface TableStructure extends TableStructureConfiguration {
    /**
     * The table type is a mandatory property. The type is used to identify the table
     * configuration and is used to generate a unique outlet reference.
     */
    type: string;
}
/**
 * Provides the core table structure, typically being used to render table columns.
 */
interface TableHeader {
    /**
     * The header key is used to:
     * - generate a unique class on each table row
     * - generate a template for each table header cell and data cell
     * - translate the key using the translate module
     *   (fallback in case there is no label available)
     */
    i18nKey?: string;
}
interface TableHeaderOutletContext {
    _type: string;
    _field: string;
    _options?: TableOptions;
    /**
     * The i18nRoot is used to build localized table headers. The i18nRoot
     * is used as a prefix for the `_field`. Table header labels wil use the
     * following locales:
     *
     * `[i18nRoot].[_field]`
     */
    _i18nRoot?: string;
}
interface TableDataOutletContext extends TableHeaderOutletContext {
    [property: string]: any;
}

/**
 * The `TableConfig` provides a table configurations for specific table types. You can define
 * an all-screen table structure as well as a breakpoint specific table structure. The various
 * table structures are merged from small to large screen configurations, depending on the users
 * screen size.
 *
 * The `table.type` is used as a key to distinguish the various table configurations in the application.
 */
declare abstract class TableConfig {
    table?: {
        [tableType: string]: ResponsiveTableConfiguration;
    };
    tableOptions?: {
        /**
         * Global component to render table header _content_ (`<th>...</th>`). A specific component
         * can be configured alternatively per table or table field.
         */
        headerComponent?: Type<any>;
        /**
         * Global component to render table cell _content_ (`<td>...</td>`). A specific component per
         * field can be configured alternatively.
         *
         * If no component is available, the table content will render as-is.
         */
        dataComponent?: Type<any>;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<TableConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TableConfig>;
}
/**
 * Helper configuration to introduce breakpoint specific table configuration.
 */
interface ResponsiveTableConfiguration extends TableStructureConfiguration {
    /** The table configurations for all screens */
    [BREAKPOINT.xl]?: TableStructureConfiguration;
    /** The table configurations for large screens and smaller */
    [BREAKPOINT.lg]?: TableStructureConfiguration;
    /** The table configurations for medium screens and smaller */
    [BREAKPOINT.md]?: TableStructureConfiguration;
    /** The table configurations for small screens and smaller */
    [BREAKPOINT.sm]?: TableStructureConfiguration;
    /** The table configurations for extra small screens */
    [BREAKPOINT.xs]?: TableStructureConfiguration;
}
declare module '@spartacus/core' {
    interface Config extends TableConfig {
    }
}

declare const defaultTableConfig: TableConfig;

declare class TableDataCellComponent {
    protected outlet: OutletContextData<TableHeaderOutletContext>;
    constructor(outlet: OutletContextData<TableHeaderOutletContext>);
    get value(): string;
    protected get model(): any;
    protected get field(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TableDataCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TableDataCellComponent, "cx-table-data-cell", never, {}, {}, never, never, true, never>;
}

declare class TableDataCellModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TableDataCellModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TableDataCellModule, never, [typeof i1.CommonModule, typeof TableDataCellComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TableDataCellModule>;
}

declare class TableHeaderCellComponent {
    protected outlet: OutletContextData<TableHeaderOutletContext>;
    constructor(outlet: OutletContextData<TableHeaderOutletContext>);
    /**
     * Returns the static label for the given field, if available.
     */
    get header(): string | undefined;
    /**
     * Returns the localized label for the given field.
     *
     * The localized label is either driven by the configured `label.i18nKey`
     * or concatenated by the table `type` and field `key`:
     *
     * `[tableType].[fieldKey]`
     *
     * The localized header can be translated with the `cxTranslate` pipe or `TranslationService`.
     */
    get localizedHeader(): string;
    protected get fieldOptions(): TableFieldOptions | undefined;
    protected get field(): string;
    protected get type(): string;
    protected get i18nRoot(): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<TableHeaderCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TableHeaderCellComponent, "cx-table-header-cell", never, {}, {}, never, never, true, never>;
}

declare class TableHeaderCellModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TableHeaderCellModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TableHeaderCellModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof TableHeaderCellComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TableHeaderCellModule>;
}

/**
 * The table renderer service adds a component for each table cells (th and td)
 * based on a fine grained configuration. Each table type can configure both global
 * components for headers and cells as well as individual components for field
 * specific cells.
 *
 * The components are added to the outlet slots for the corresponding cells. The table
 * structure and data is added to the outlet context.
 */
declare class TableRendererService {
    protected outletService: OutletService;
    protected componentFactoryResolver: ComponentFactoryResolver;
    protected config: TableConfig;
    protected outletRefs: Map<any, any>;
    constructor(outletService: OutletService, componentFactoryResolver: ComponentFactoryResolver, config: TableConfig);
    /**
     * Adds the configured table component for the header and data.
     */
    add(structure: TableStructure): void;
    protected render(outletRef: string, renderer: Type<any>): void;
    /**
     * Returns the header render component for the given field.
     */
    protected getHeaderRenderer(structure: TableStructure, field: string): Type<any> | undefined;
    /**
     * Returns the data render component for the given field.
     */
    protected getDataRenderer(structure: TableStructure, field: string): Type<any> | undefined;
    /**
     * Returns the header (th) outlet reference for the given field.
     *
     * The outlet reference is generated as:
     * `table.[tableType].header.[field]`
     */
    getHeaderOutletRef(type: string, field: string): string;
    /**
     * Returns the header (th) outlet context for the given field.
     */
    getHeaderOutletContext(type: string, options: TableOptions | undefined, i18nRoot: string, field: string): TableHeaderOutletContext;
    /**
     * Returns the data (td) outlet reference for the given field.
     *
     * The field is generated as:
     * `table.[tableType].data.[tableField]`
     */
    getDataOutletRef(type: string, field: string): string;
    /**
     * Returns the data (td) outlet context for the given field.
     */
    getDataOutletContext(type: string, options: TableOptions | undefined, i18nRoot: string, field: string, data: any): TableDataOutletContext;
    static ɵfac: i0.ɵɵFactoryDeclaration<TableRendererService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TableRendererService>;
}

/**
 * The table component provides a generic table DOM structure, with 3 layout types:
 * horizontal, vertical and _stacked vertical_ layout. The layout is driven by the
 * table structure.
 *
 * The implementation is fairly "dumb" and only renders string based content for TH
 * and TD elements. The actual cell rendering is delegated to a (configurable) cell
 * component. Additionally, each cell is registered as an outlet, so that customizations
 * can be done by both outlet templates and components.
 *
 * The outlet references are concatenated from the table `type` and header `key`. The
 * following snippet shows an outlet generated for a table header, for the table type
 * "cost-center" with a header key "name":
 *
 * ```
 * <th>
 *   <template cxOutlet="table.cost-center.header.name">
 *   </template>
 * </th>
 * ```
 *
 * Similarly, the data cells (`<td>`) are generated with the outlet template reference
 * `table.cost-center.data.name`.
 */
declare class TableComponent<T> {
    protected rendererService: TableRendererService;
    tableType: string;
    horizontalLayout: boolean;
    verticalLayout: boolean;
    verticalStackedLayout: boolean;
    private featureConfigService;
    private _structure;
    set structure(structure: TableStructure);
    get structure(): TableStructure;
    data: T[];
    /**
     * The i18nRoot is passed into the table cell context, so that
     * cell components can concatenate the i18n root and label.
     */
    i18nRoot: string;
    /**
     * Provides a mechanism to compare a matching value for each item.
     *
     * The `property` refers to the dataset.value property, and the value tot the
     * matching property value.
     */
    currentItem: {
        value: any;
        property: string;
    };
    launch: EventEmitter<any>;
    constructor(rendererService: TableRendererService);
    init(): void;
    launchItem(item: any): void;
    /**
     * Indicates whether the given item is the current item.
     *
     * The current item is driven by the `currentItem`, that holds a
     * property and value to compare.
     */
    isCurrentItem(item: any): boolean;
    /**
     * Returns the header (th) outlet reference for the given field.
     */
    getHeaderOutletRef(field: string): string;
    /**
     * Returns the header (th) outlet context for the given field.
     */
    getHeaderOutletContext(field: string): TableHeaderOutletContext;
    /**
     * Returns the data (td) outlet reference for the given field.
     */
    getDataOutletRef(field: string): string;
    /**
     * Returns the data (td) outlet context for the given field.
     */
    getDataOutletContext(field: string, data: any): TableDataOutletContext;
    trackData: (_i: number, item: any) => any;
    /**
     * Generates the table type into the UI in devMode, so that developers
     * can easily get the notion of the table type.
     */
    protected addTableDebugInfo(): void;
    /**
     * Helper method to return the deeply nested orientation configuration.
     */
    private get layout();
    /**
     * Helper method to return the deeply nested type.
     */
    private get type();
    private get options();
    static ɵfac: i0.ɵɵFactoryDeclaration<TableComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TableComponent<any>, "cx-table", never, { "structure": { "alias": "structure"; "required": false; }; "data": { "alias": "data"; "required": false; }; "i18nRoot": { "alias": "i18nRoot"; "required": false; }; "currentItem": { "alias": "currentItem"; "required": false; }; }, { "launch": "launch"; }, never, never, true, never>;
}

/**
 * The TableModule provides a table component that is driven by (responsible) configuration.
 */
declare class TableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TableModule, never, [typeof i1.CommonModule, typeof OutletModule, typeof TableHeaderCellModule, typeof TableDataCellModule, typeof TableComponent], [typeof TableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TableModule>;
}

/**
 * Responsive table service.
 *
 * The `TableService` is used to build a `TableStructure` by configuration. The configuration
 * allows for breakpoint specific configuration, so that the table can differentiate for
 * various screen sizes.
 *
 * While there are some global options, the configuration is mainly driven by the table _type_.
 *
 * If there is no table configuration for the given type found, a table header structure
 * is generated based on the actual data (if available) or randomly by generating 5 random headers.
 */
declare class TableService {
    protected breakpointService: BreakpointService;
    protected config: TableConfig;
    protected logger: LoggerService;
    constructor(breakpointService: BreakpointService, config: TableConfig);
    /**
     * Builds the table structure.
     *
     * @param tableType The table type is used  to find the specific table configuration.
     * @param defaultStructure (optional) Default table structure that contains fallback options. More specific options are merged with the default structure.
     * @param data$ (optional) The actual data can be passed in to generate the table structure based on actual data.
     */
    buildStructure(tableType: string, defaultStructure?: ResponsiveTableConfiguration): Observable<TableStructure>;
    /**
     * Returns the table structure by configuration. The configuration can be
     * breakpoint-driven, which means that an alternative header structure can
     * be created per screen size.
     *
     * The breakpoint is resolved by teh `BreakpointService`.
     */
    protected buildStructureFromConfig(type: string, defaultStructure?: ResponsiveTableConfiguration): Observable<TableStructure>;
    /**
     * Finds all applicable table configuration for the given type and breakpoint.
     * The default table configuration is merged with all relevant breakpoint
     * configurations.
     *
     * This allows to have some default configurations that apply to all screens, and
     * add configuration options for some screens.
     */
    protected getTableConfig(type: string, breakpoint: BREAKPOINT, defaultStructure?: ResponsiveTableConfiguration): TableStructureConfiguration | null;
    /**
     * Generates the table structure by the help of the first data row.
     */
    protected buildStructureFromData(type: string, data$: Observable<any>): Observable<TableStructure>;
    /**
     * As a last resort, the table structure is randomly created. The random structure
     * contains 5 headers, so that some of the unknown data is visualized.
     */
    protected buildRandomStructure(type: string): Observable<TableStructure>;
    /**
     * Finds all the breakpoints can contribute to the table configuration, from small
     * to current.
     *
     * For example, if the current breakpoint is `MD`, this returns `[XS, SM, MD]`.
     */
    protected findRelevantBreakpoints(breakpoint: BREAKPOINT): BREAKPOINT[];
    /**
     * Indicates if the there is a configuration for the table available.
     */
    protected hasTableConfig(tableType: string): boolean;
    /**
     * Logs a message in the console to increase developer experience.
     *
     * The message is only logged in dev mode.
     */
    private logWarning;
    static ɵfac: i0.ɵɵFactoryDeclaration<TableService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TableService>;
}

interface RenderParams {
    element?: HTMLElement | string;
    publicKey?: string;
}

interface CaptchaRenderer {
    /**
     * Renders captcha widget
     *
     * @RenderParams parameters required by a provider, includes html element to append CAPTCHA UI element.
     * @returns Observable for the key returned by a provider once user validated
     */
    renderCaptcha(params: RenderParams): Observable<string>;
    /**
     * @returns Observable for the backend request to retrieve commerce cloud
     * captcha configuration (such as public key and whether captca is enabled)
     * */
    getCaptchaConfig(): Observable<CaptchaConfig>;
    /**
     * @returns captcha token
     */
    getToken(): string;
}

declare abstract class CaptchaApiConfig {
    captchaRenderer?: Type<CaptchaRenderer>;
    apiUrl?: string;
    fields?: {
        [key: string]: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<CaptchaApiConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CaptchaApiConfig>;
}
declare module '@spartacus/core' {
    interface Config extends CaptchaApiConfig {
    }
}

declare class CaptchaComponent implements AfterViewInit, OnDestroy {
    protected config: CaptchaApiConfig;
    protected injector: Injector;
    confirmed: EventEmitter<boolean>;
    captchaRef: ElementRef;
    protected subscription: Subscription;
    constructor(config: CaptchaApiConfig, injector: Injector);
    /**
     * Add fields from CaptchaApiConfig. Call backend to get captcha
     * config.
     */
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaptchaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaptchaComponent, "cx-captcha", never, {}, { "confirmed": "confirmed"; }, never, never, true, never>;
}

declare class CaptchaModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CaptchaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CaptchaModule, never, [typeof i1.CommonModule, typeof i2$2.ReactiveFormsModule, typeof FormErrorsModule, typeof CaptchaComponent], [typeof CaptchaComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CaptchaModule>;
}

declare abstract class CaptchaService implements CaptchaRenderer, OnDestroy {
    protected adapter: SiteAdapter;
    protected apiConfig: CaptchaApiConfig;
    protected languageService: LanguageService;
    protected scriptLoader: ScriptLoader;
    protected baseSiteService: BaseSiteService;
    protected rendererFactory: RendererFactory2;
    protected token: string;
    protected subscription: Subscription;
    protected captchaConfigSubject$: ReplaySubject<CaptchaConfig>;
    protected captchaConfig: CaptchaConfig;
    protected renderer: i0.Renderer2;
    constructor(adapter: SiteAdapter, apiConfig: CaptchaApiConfig, languageService: LanguageService, scriptLoader: ScriptLoader, baseSiteService: BaseSiteService);
    /**
     * Retrieve captcha configuration from the backend, and if enabled
     * call @function loadScript with active language
     */
    initialize(): void;
    fetchCaptchaConfigFromServer(): Observable<CaptchaConfig>;
    getCaptchaConfig(): Observable<CaptchaConfig>;
    /**
     * Trigger rendering function configured in CaptchaApiConfig
     * @param {HTMLElement} elem - HTML element to render captcha widget within.
     */
    abstract renderCaptcha(renderParams: RenderParams): Observable<string>;
    ngOnDestroy(): void;
    getToken(): string;
    /**
     * Load external resource if needed with dependencies to be added to <head>.
     * @param - Language and configuration read from server
     */
    loadResource(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaptchaService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CaptchaService>;
}

declare class FilesFormValidators {
    CONVERT_TO_MB: number;
    extenstionRegEx: RegExp;
    /**
     * Checks max size of file
     *
     * @param {number} maxSize Max size [MB]
     * @returns Uses 'tooLarge' validator error with maxSize property
     * @memberOf FilesFormValidators
     */
    maxSize(maxSize?: number): ValidatorFn;
    /**
     * Checks maximum entries
     *
     * @param {number} maxEntries Max number of entries
     * @returns Uses 'tooManyEntries' validator error with maxEntries property
     * @memberOf FilesFormValidators
     */
    maxEntries(maxEntries?: number): ValidatorFn;
    /**
     * Checks allowed types
     *
     * @param {Array<string>} allowedTypes Allowed types of files
     * @returns Uses 'notParsable' validator error with allowedTypes property
     * @memberOf FilesFormValidators
     */
    allowedTypes(allowedTypes?: Array<string>): ValidatorFn;
    protected getExtension(filename?: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilesFormValidators, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FilesFormValidators>;
}

interface MessageEvent {
    author?: string;
    rightAlign?: boolean;
    createdAt?: string;
    text?: string;
    attachments?: Array<Attachment>;
    code?: string;
    /**
     * {@link MessageEventBoundItem} this message is currently bound to.
     */
    item?: MessageEventBoundItem;
}
interface Attachment {
    filename?: string;
    id?: string;
}
interface MessagingConfigs {
    attachmentRestrictions?: AttachmentRestrictions;
    charactersLimit?: number;
    newMessagePlaceHolder?: string;
    enableFileUploadOption?: boolean;
    dateFormat?: string;
    displayAddMessageSection?: Observable<boolean>;
    /**
     * List of possible {@link MessageEventBoundItem} this message can be bound to. When given, the {@link MessagingComponent} will render a
     * drop down list box to select an item.
     */
    itemList$?: Observable<Array<MessageEventBoundItem>>;
    /**
     * The id of the {@link MessageEventBoundItem} that should be pre-selected on the UI when adding a new message.
     */
    defaultItemId?: string;
    sendBtnIsNotPrimary?: boolean;
}
interface AttachmentRestrictions {
    maxSize?: number;
    maxEntries?: number;
    allowedTypes?: Array<string>;
}
/**
 * A message can be bound to an item.
 * For example consider the {@link MessagingComponent} to be embedded in a component representing a document, such as
 * Cart, Order or Quote. A message added in context of a document, can either apply to the whole document (header message)
 * or to a specific line item (item message). In the later case one can provide the name of the line item,
 * typically the product name, as well as an id, typically the entry number. So the {@link MessagingComponent} can render a link
 * in front of the message with the given name as link text.
 * When clicking the link an itemClicked event will be emitted, with the item data as payload. The encapsulating component
 * could for example trigger a navigation to the corresponding line item using the event data.
 */
interface MessageEventBoundItem {
    id: string;
    name: string;
}

declare class MessagingComponent implements OnInit, AfterViewChecked {
    protected windowRef: WindowRef;
    protected filesFormValidators: FilesFormValidators;
    fileUploadComponent?: FileUploadComponent;
    messageEvents$: Observable<Array<MessageEvent>>;
    scrollToInput?: boolean;
    messagingConfigs?: MessagingConfigs;
    send: EventEmitter<{
        files: File | undefined;
        message: string;
        itemId?: string;
    }>;
    itemClicked: EventEmitter<{
        item: MessageEventBoundItem;
    }>;
    downloadAttachment: EventEmitter<{
        messageCode: string | undefined;
        attachmentId: string | undefined;
        fileName: string | undefined;
    }>;
    iconTypes: typeof ICON_TYPE$1;
    form: UntypedFormGroup;
    MAX_INPUT_CHARACTERS: number;
    MAX_SIZE: number;
    MAX_ENTRIES: number;
    dateFormat: string;
    updatedScrollHeight: number;
    scrollOnceOnLoad: boolean;
    get inputCharacterLeft(): number;
    get maxSize(): number;
    get maxEntries(): number;
    get allowedTypes(): Array<string>;
    constructor(windowRef: WindowRef, filesFormValidators: FilesFormValidators);
    ngOnInit(): void;
    ngAfterViewChecked(): void;
    onSend(): void;
    resetForm(): void;
    triggerDownload(messageCode: string | undefined, attachmentId: string | undefined, fileName: string | undefined): void;
    protected buildForm(): void;
    focusNextChild(event: UIEvent): void;
    focusPreviousChild(event: UIEvent): void;
    /**
     * A message can be linked to an item. In this case the item name will be prefixed to the message text.
     *
     * @param {MessageEvent} message message
     * @returns {string | undefined} message text prefixed with item name, in case its given.
     */
    getMessageText(message: MessageEvent): string | undefined;
    onItemClicked(item: MessageEventBoundItem): void;
    protected observeScroll(): void;
    protected scrollToBottom(element: Element, previousScrollHeight: number): void;
    protected heightChanged(previousScrollHeight: number): boolean;
    protected scrollOnLoad(): void;
    private getResultElements;
    private getFocusedIndex;
    private getFocusedElement;
    static ɵfac: i0.ɵɵFactoryDeclaration<MessagingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MessagingComponent, "cx-messaging", never, { "messageEvents$": { "alias": "messageEvents$"; "required": false; }; "scrollToInput": { "alias": "scrollToInput"; "required": false; }; "messagingConfigs": { "alias": "messagingConfigs"; "required": false; }; }, { "send": "send"; "itemClicked": "itemClicked"; "downloadAttachment": "downloadAttachment"; }, never, never, true, never>;
}

declare class AvatarComponent {
    message: MessageEvent;
    iconTypes: typeof ICON_TYPE$1;
    getInitials(author: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AvatarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AvatarComponent, "cx-avatar", never, { "message": { "alias": "message"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ChatMessagingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ChatMessagingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ChatMessagingModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof IconModule, typeof i2$2.FormsModule, typeof i2$2.ReactiveFormsModule, typeof FileUploadModule, typeof FormErrorsModule, typeof AvatarComponent, typeof MessagingComponent], [typeof AvatarComponent, typeof MessagingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ChatMessagingModule>;
}

/**
 * Tells whether the component contains LCP (Largest Contentful Paint) element in its sub-tree.
 *
 * It's provided on DOM level by an ancestor component (likely a CMS component)
 *
 * A descendant component can use this context for possible performance optimizations
 * related to LCP (Largest Contentful Paint) element.
 *
 * Note: It's also provided in root injector with default fallback value of `LcpPresence.NO_LCP`,
 * to avoid errors when no ancestor component provides it.
 */
declare const LCP_PRESENCE: InjectionToken<Observable<LcpPresence>>;

/**
 * Directive that provides the information whether the template contains
 * the LCP (Largest Contentful Paint) element.
 *
 * For CMS components, it's already defined by the `[cxComponentWrapper]` directive,
 * based on the dynamic CMS component data.
 */
declare class ProvideLcpPresenceDirective implements OnChanges {
    cxProvideLcpPresence?: LcpPresence | null;
    protected _lcpPresence$: ReplaySubject<LcpPresence>;
    ngOnChanges(): void;
    protected lcpPresence$: Observable<LcpPresence>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProvideLcpPresenceDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ProvideLcpPresenceDirective, "[cxProvideLcpPresence]", never, { "cxProvideLcpPresence": { "alias": "cxProvideLcpPresence"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ProvideLcpPresenceDirectiveModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProvideLcpPresenceDirectiveModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProvideLcpPresenceDirectiveModule, never, [typeof ProvideLcpPresenceDirective], [typeof ProvideLcpPresenceDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProvideLcpPresenceDirectiveModule>;
}

interface CsvFileValidationErrors {
    tooLarge?: {
        maxSize: number;
    };
    tooManyEntries?: {
        maxEntries: number;
    };
    empty?: boolean;
    notParsable?: boolean;
}

interface ExportFileOptions {
    /**
     * File name for exported file.
     */
    fileName: string;
    /**
     * Extension for exported file.
     */
    extension: string;
    /**
     * Mime/type for exported file.
     */
    type: string;
}

declare class FileDownloadService {
    /**
     * Triggers the browser downloading of the file from the given URL.
     *
     * @param {string} url URL to file.
     * @param {string} [fileName] The optional parameter for defining filename
     * (including the extension) when saving the file.
     */
    download(url: string, fileName?: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileDownloadService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileDownloadService>;
}

declare class ExportCsvFileService {
    protected fileDownloadService: FileDownloadService;
    constructor(fileDownloadService: FileDownloadService);
    /**
     * Converts array of objects into CSV data structure.
     *
     * @param objectsArray Array of objects which should be converted to CSV.
     * @param separator Separator for CSV data.
     * @returns Processed string ready to be saved into file.
     */
    protected convert(objectsArray: string[][], separator: string): string;
    /**
     * Creates and download CSV file.
     *
     * @param objectsArray Array of objects which should be converted to CSV.
     * @param separator Separator for CSV data.
     * @param fileOptions Exported file options.
     */
    download(objectsArray: string[][], separator: string, fileOptions: ExportFileOptions): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExportCsvFileService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ExportCsvFileService>;
}

declare class FileReaderService {
    /**
     * Load text file
     *
     * @param file text file to extract the data
     * @returns Observable from file reader
     */
    loadTextFile(file: File): Observable<string | ProgressEvent<FileReader>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileReaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileReaderService>;
}

declare class ImportCsvFileService {
    protected fileReaderService: FileReaderService;
    constructor(fileReaderService: FileReaderService);
    /**
     * Load CSV file.
     *
     * @param file File we want to load as CSV.
     * @param separator Separator for CSV data.
     * @return {Observable<string[][]>} Imported file
     */
    loadFile(file: File, separator: string): Observable<string[][]>;
    /**
     * Combined csv validation
     *
     * @param file File we want to load as CSV.
     * @param separator Separator for CSV data.
     * @param isDataParsable (optional) Callback for verify that structure type is proper.
     * @param maxEntries (optional) Limitation for maximum entries count.
     * @return {Observable<CsvFileValidationErrors | null>} Result of validation
     */
    validateFile(file: File, { separator, isDataParsable, maxEntries, }: {
        separator: string;
        isDataParsable?: (data: string[][]) => boolean;
        maxEntries?: number;
    }): Observable<CsvFileValidationErrors | null>;
    /**
     * Processes the CSV data
     *
     * @param csvString raw extracted data from CSV
     * @param separator for csv data
     * @param ignoreHeader (optional) flag allows for ignore headers row while reading
     * @returns {string[][]} Parsed file
     */
    protected parse(csvString: string, separator: string, ignoreHeader?: boolean): string[][];
    protected validateEmpty(data: string, errors: ValidationErrors): void;
    protected validateTooManyEntries(data: string[][], errors: ValidationErrors, maxEntries?: number): void;
    protected validateNotParsable(data: string[][], errors: ValidationErrors, isDataParsable?: (data: string[][]) => boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImportCsvFileService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ImportCsvFileService>;
}

declare class CustomFormValidators {
    /**
     * Checks control's value with predefined email regexp
     *
     * NOTE: Use it as a control validator
     *
     * @static
     * @param {AbstractControl} control
     * @returns {(ValidationErrors | null)} Uses 'cxInvalidEmail' validator error
     * @memberof CustomFormValidators
     */
    static emailValidator(control: AbstractControl): ValidationErrors | null;
    static securePasswordValidator(control: AbstractControl): ValidationErrors | null;
    /**
     * Checks control's value with predefined  at least one upper case character regexp
     *
     * NOTE: Use it as a control validator
     *
     * @static
     * @param {AbstractControl} control
     * @returns {(ValidationErrors | null)} Uses 'cxMinOneUpperCaseCharacter' validator error
     * @memberof CustomFormValidators
     */
    static minOneUpperCaseCharacterValidator(control: AbstractControl): ValidationErrors | null;
    /**
     * Checks control's value with predefined  at least one upper case character regexp
     *
     * NOTE: Use it as a control validator
     *
     * @static
     * @param {AbstractControl} control
     * @returns {(ValidationErrors | null)} Uses 'cxMinOneDigit' validator error
     * @memberof CustomFormValidators
     */
    static minOneDigitValidator(control: AbstractControl): ValidationErrors | null;
    /**
     * Checks control's value with predefined  at least one upper case character regexp
     *
     * NOTE: Use it as a control validator
     *
     * @static
     * @param {AbstractControl} control
     * @returns {(ValidationErrors | null)} Uses 'cxMinOneSpecialCharacter' validator error
     * @memberof CustomFormValidators
     */
    static minOneSpecialCharacterValidator(control: AbstractControl): ValidationErrors | null;
    /**
     * Checks control's value with predefined  at least one upper case character regexp
     *
     * NOTE: Use it as a control validator
     *
     * @static
     * @param {AbstractControl} control
     * @returns {(ValidationErrors | null)} Uses 'cxMinSixCharactersLength' validator error
     * @memberof CustomFormValidators
     */
    static minSixCharactersLengthValidator(control: AbstractControl): ValidationErrors | null;
    /**
     * Checks control's value with predefined  at least one upper case character regexp
     *
     * NOTE: Use it as a control validator
     *
     * @static
     * @param {AbstractControl} control
     * @returns {(ValidationErrors | null)} Uses 'cxMinEightCharactersLength' validator error
     * @memberof CustomFormValidators
     */
    static minEightCharactersLengthValidator(control: AbstractControl): ValidationErrors | null;
    static maxCharactersLengthValidator(control: AbstractControl): ValidationErrors | null;
    /**
     * Validates that the control's value does not contain consecutive identical characters.
     *
     * NOTE: Use this as a control validator.
     *
     * @static
     * @param {AbstractControl} control The form control to validate.
     * @returns {(ValidationErrors | null)} Returns an error object with the key 'cxNoConsecutiveCharacters'
     * if the value contains consecutive characters, or null if the validation passes.
     * @memberof CustomFormValidators
     */
    static noConsecutiveCharacters(control: AbstractControl): ValidationErrors | null;
    /**
     * Pack of predefined password validators:
     * - at least one upper case character
     * - at least one digit
     * - at least one special character
     * - at least six characters length
     *
     * @memberof CustomFormValidators
     */
    static passwordValidators: (typeof CustomFormValidators.minOneDigitValidator)[];
    static securePasswordValidators: (typeof CustomFormValidators.minOneDigitValidator)[];
    /**
     * Checks if control's value is between 1 and 5
     *
     * NOTE: Use it as a control validator
     *
     * @static
     * @param {AbstractControl} control
     * @returns {(ValidationErrors | null)} Uses 'cxStarRatingEmpty' validator error
     * @memberof CustomFormValidators
     */
    static starRatingEmpty(control: AbstractControl): ValidationErrors | null;
    /**
     * Checks if two password controls match
     *
     * NOTE: Use it as a form validator and pass password control names as parameters
     *
     * @static
     * @param {string} password First password control name
     * @param {string} passwordConfirmation Second password control name
     * @returns Uses 'cxPasswordsMustMatch' validator error
     * @memberof CustomFormValidators
     */
    static passwordsMustMatch(password: string, passwordConfirmation: string): any;
    /**
     * Checks if two password controls don't match
     *
     * NOTE: Use it as a form validator and pass password control names as parameters
     *
     * @static
     * @param {string} password First password control name
     * @param {string} passwordConfirmation Second password control name
     * @returns Uses 'cxPasswordsCannotMatch' validator error
     * @memberof CustomFormValidators
     */
    static passwordsCannotMatch(password: string, passwordConfirmation: string): any;
    /**
     * Checks if two email controls match
     *
     * NOTE: Use it as a form validator and pass email control names as parameters
     *
     * @static
     * @param {string} email First email control name
     * @param {string} emailConfirmation Second email control name
     * @returns Uses 'cxEmailsMustMatch' validator error
     * @memberof CustomFormValidators
     */
    static emailsMustMatch(email: string, emailConfirmation: string): any;
    /**
     * Checks if control's value is euqal or greater than 0
     *
     * NOTE: Use it as a control validator
     *
     * @static
     * @param {AbstractControl} control
     * @returns {(ValidationErrors | null)} Uses 'cxNegativeAmount' validator error
     * @memberof CustomFormValidators
     */
    static mustBePositive(control: AbstractControl): ValidationErrors | null;
    /**
     * Checks if control's value ends with a legal letter, digit, or character.
     *
     * NOTE: Use it as a control validator
     *
     * @static
     * @param {AbstractControl} control
     * @returns {(ValidationErrors | null)} Uses 'cxMustEndWithLegalCharacter' validator error
     * @memberof CustomFormValidators
     */
    static mustEndWithLegalCharacter(control: AbstractControl): ValidationErrors | null;
    /**
     * Checks if control's value does not contain any special characters
     *
     * NOTE: Use it as a control validator
     *
     * @static
     * @param {AbstractControl} control
     * @returns {(ValidationErrors | null)} Uses 'cxContainsSpecialCharacters' validator error
     * @memberof CustomFormValidators
     */
    static noSpecialCharacters(control: AbstractControl): ValidationErrors | null;
    /**
     * Checks if control's value passes pattern
     *
     * NOTE: Use it as a control validator
     *
     * @static
     * @param {(date: string) => boolean} isValidFormat Pattern verification function
     * @returns {(control: AbstractControl): ValidationErrors | null} Uses 'pattern' validator error
     * @memberof CustomFormValidators
     */
    static patternValidation(isValidFormat: (date: string) => boolean): ValidatorFn;
    /**
     * Checks if two email controls match
     *
     * NOTE: Use it as a form validator and pass dates for range
     *
     * @static
     * @param {string} startDateKey First date control name
     * @param {string} endDateKey Second date control name
     * @param {(value: string) => Date} getDate Converting function
     * @returns Uses 'min' and 'max validator error
     * @memberof CustomFormValidators
     */
    static dateRange(startDateKey: string, endDateKey: string, getDate: (value: string) => Date | undefined): (_: UntypedFormGroup) => ValidationErrors | null;
}
/**
 * Generic function for validators, which checks if two passed controls match.
 *
 * @param formGroup
 * @param firstControlName First control to check
 * @param secondControlName Second control to check
 * @param errorName Error which will be returned by validator
 * @param cannotMatch Reverse check
 */
declare function controlsMustMatch(formGroup: UntypedFormGroup, firstControlName: string, secondControlName: string, errorName: string, cannotMatch?: boolean): void;

declare const titleScores: {
    [code: string]: number;
};
declare function sortTitles(title1: Title$1, title2: Title$1): number;

/**
 * Utils for Angular forms
 */
declare namespace FormUtils {
    /**
     * Calls the native Angular method `#updateValueAndValidity` for the given from control
     * and all its descendants (in case when it's `FormGroup` or `FormArray`).
     *
     * In particular it's useful for triggering re-emission of observables
     * `valueChanges` and `statusChanges` for all descendant form controls.
     *
     * _Note: Dropping this function may be considered, when it's implemented natively
     * by Angular. See https://github.com/angular/angular/issues/6170_
     *
     * @param control form control
     * @param options additional options
     * * `emitEvent`: When true or not given (the default), the `statusChanges` and
     * `valueChanges` observables emit the latest status and value. When false,
     * it doesn't trigger observables emission.
     */
    function deepUpdateValueAndValidity(control: AbstractControl, options?: {
        emitEvent?: boolean;
    }): void;
}

/**
 * Get strings for phone and mobile numbers
 */
declare function getAddressNumbers(address: Address, textPhone: string, textMobile: string): string | undefined;

export { AVOID_STACKED_OUTLETS, ActiveFacetsComponent, ActiveFacetsModule, AddToHomeScreenBannerComponent, AddToHomeScreenBtnComponent, AddToHomeScreenComponent, AddToHomeScreenService, AnonymousConsentDialogComponent, AnonymousConsentManagementBannerComponent, AnonymousConsentManagementBannerModule, AnonymousConsentOpenDialogComponent, AnonymousConsentsDialogModule, AppRoutingModule, AtMessageDirective, AtMessageModule, AvatarComponent, BEFORE_CMS_PAGE_GUARD, BREAKPOINT, BannerCarouselComponent, BannerCarouselModule, BannerComponent, BannerModule, BaseStorefrontModule, BeforeCmsPageGuardService, BreadcrumbComponent, BreadcrumbModule, BreadcrumbSchemaBuilder, BreakpointService, BtnLikeLinkDirective, BtnLikeLinkModule, CaptchaApiConfig, CaptchaComponent, CaptchaModule, CaptchaService, CardComponent, CardModule, CarouselComponent, CarouselModule, CarouselScrollingComponent, CarouselScrollingModule, CarouselService, CategoryNavigationComponent, CategoryNavigationModule, CategoryPageResultsEvent, ChatMessagingModule, ClaimDialogComponent, CmsComponentData, CmsComponentsService, CmsFeaturesService, CmsGuardsService, CmsI18nService, CmsInjectorService, CmsLcpModule, CmsLcpService, CmsPageGuard, CmsPageGuardService, CmsParagraphModule, CmsRouteModule, CmsRoutesService, ComponentCreateEvent, ComponentDestroyEvent, ComponentEvent, ComponentHandler, ComponentHandlerService, ComponentWrapperDirective, ConsentManagementComponent, ConsentManagementComponentService, ConsentManagementFormComponent, ConsentManagementModule, ContextService, CouponCardComponent, CouponClaimComponent, CouponDialogComponent, CurrentProductService, CustomFormValidators, DIALOG_TYPE, DatePickerComponent, DatePickerModule, DatePickerService, DefaultComponentHandler, DeferLoaderService, DirectionConfig, DirectionMode, DirectionModule, DirectionService, DomChangeDirective, DomChangeModule, ExportCsvFileService, FacetComponent, FacetGroupCollapsedState, FacetListComponent, FacetListModule, FacetModule, FacetService, FileDownloadService, FileReaderService, FileUploadComponent, FileUploadModule, FilesFormValidators, FocusDirective, FocusableCarouselItemDirective, FooterNavigationComponent, FooterNavigationModule, FormConfig, FormErrorsComponent, FormErrorsModule, FormRequiredAsterisksComponent, FormRequiredLegendComponent, FormUtils, GenericLinkComponent, GenericLinkComponentService, GenericLinkModule, GlobalMessageComponent, GlobalMessageComponentModule, HamburgerMenuComponent, HamburgerMenuModule, HamburgerMenuService, HighlightPipe, HomePageEvent, HomePageEventBuilder, HomePageEventModule, HorizontalScrollingPositionDirective, HorizontalScrollingPositionDirectiveModule, ICON_TYPE$1 as ICON_TYPE, IS_GUEST_USER_CHECKOUT_KEY, IconComponent, IconConfig, IconLoaderService, IconModule, IconResourceType, IconTestingModule, ImageFetchPriority, ImageLoadingStrategy, ImportCsvFileService, InlineRenderStrategy, InlineRootRenderStrategy, InnerComponentsHostDirective, IntersectionService, ItemCounterComponent, ItemCounterModule, JSONLD_PRODUCT_BUILDER, JsonLdBaseProductBuilder, JsonLdBuilderModule, JsonLdDirective, JsonLdProductOfferBuilder, JsonLdProductReviewBuilder, JsonLdScriptFactory, KeyboardFocusModule, KeyboardFocusService, KeyboardFocusTestingModule, LAUNCH_CALLER, LCP_PRESENCE, LanguageCurrencyComponent, LaunchDialogModule, LaunchDialogService, LaunchRenderStrategy, LayoutConfig, LayoutModule, LazyComponentHandler, LcpCmsComponentsConfig, LcpContextDirective, LcpContextDirectiveModule, LcpPresence, LcpPresenceMappingService, LinkComponent, LinkModule, ListNavigationModule, LoginGuard, LoginRouteModule, LogoutGuard, LogoutModule, MediaComponent, MediaConfig, MediaModule, MediaPreconnectService, MediaService, MediaSourcesPipe, MessageComponent, MessageComponentModule, MessagingComponent, MockIconComponent, MockIconLoaderService, MockKeyboardFocusDirective, MyAccountV2ConsentManagementComponent, MyAccountV2ConsentManagementFormComponent, MyAccountV2ConsentManagementModule, MyAccountV2Module, MyAccountV2NavigationComponent, MyAccountV2NavigationModule, MyAccountV2NotificationPreferenceComponent, MyAccountV2NotificationPreferenceModule, MyCouponsComponent, MyCouponsComponentService, MyCouponsModule, MyInterestsComponent, MyInterestsModule, NavigationComponent, NavigationEvent, NavigationEventBuilder, NavigationEventModule, NavigationModule, NavigationService, NavigationUIComponent, NgSelectA11yDirective, NgSelectA11yModule, NotificationPreferenceComponent, NotificationPreferenceModule, OnNavigateConfig, OnNavigateService, OutletContextData, OutletDirective, OutletModule, OutletPosition, OutletRefDirective, OutletRefModule, OutletRenderStrategy, OutletRendererService, OutletService, PAGE_LAYOUT_HANDLER, PDFComponent, PDFModule, PRODUCT_DETAILS_URL_MATCHER, PRODUCT_LISTING_URL_MATCHER, PWAModuleConfig, PageComponentModule, PageEvent, PageLayoutComponent, PageLayoutModule, PageLayoutService, PageMetaLinkService, PageSection, PageSlotComponent, PageSlotModule, PageSlotService, PageTemplateDirective, PageTitleComponent, PageTitleModule, PaginationBuilder, PaginationComponent, PaginationConfig, PaginationItemType, PaginationModule, PaginationNavigationPosition, ParagraphComponent, PasswordVisibilityToggleComponent, PasswordVisibilityToggleDirective, PasswordVisibilityToggleModule, PaymentMethodsComponent, PaymentMethodsModule, PopoverComponent, PopoverDirective, PopoverEvent, PopoverModule, PopoverService, PositioningService, ProductAttributesComponent, ProductAttributesModule, ProductCarouselComponent, ProductCarouselItemComponent, ProductCarouselModule, ProductCarouselService, ProductDetailOutlets, ProductDetailsPageEvent, ProductDetailsPageModule, ProductDetailsTabComponent, ProductDetailsTabModule, ProductFacetNavigationComponent, ProductFacetNavigationModule, ProductFacetService, ProductGridItemComponent, ProductImagesComponent, ProductImagesModule, ProductIntroComponent, ProductIntroModule, ProductListComponent, ProductListComponentService, ProductListItemComponent, ProductListItemContext, ProductListItemContextSource, ProductListModule, ProductListOutlets, ProductListingPageModule, ProductPageEventBuilder, ProductPageEventModule, ProductReferencesComponent, ProductReferencesModule, ProductReviewsComponent, ProductReviewsModule, ProductSchemaBuilder, ProductScrollComponent, ProductSummaryComponent, ProductSummaryModule, ProductTabsModule, ProductViewComponent, ProgressButtonComponent, ProgressButtonModule, PromotionsComponent, PromotionsModule, ProvideLcpPresenceDirective, ProvideLcpPresenceDirectiveModule, PwaModule, ReadMoreComponent, RoutingContextService, RoutingModule, RoutingRenderStrategy, SCHEMA_BUILDER, ScrollToTopComponent, ScrollToTopModule, SearchBoxComponent, SearchBoxComponentService, SearchBoxModule, SearchBoxOutlets, SearchBoxProductSelectedEvent, SearchBoxSuggestionSelectedEvent, SearchPageResultsEvent, SelectFocusUtility, SeoConfig, SeoMetaService, SeoModule, SiteContextComponentService, SiteContextSelectorComponent, SiteContextSelectorModule, SiteContextType, SiteThemeSwitcherComponent, SiteThemeSwitcherModule, SkipFocusDirective, SkipLink, SkipLinkComponent, SkipLinkConfig, SkipLinkDirective, SkipLinkModule, SkipLinkScrollPosition, SkipLinkService, SortingComponent, SortingModule, SpinnerComponent, SpinnerModule, SplitViewComponent, SplitViewModule, SplitViewService, StarRatingComponent, StarRatingModule, StockNotificationComponent, StockNotificationDialogComponent, StockNotificationModule, StorefrontComponent, StorefrontComponentModule, StorefrontOutlets, StructuredDataModule, SupplementHashAnchorsModule, SupplementHashAnchorsPipe, TAB_MODE, TabComponent, TabModule, TabPanelComponent, TabPanelModule, TabParagraphContainerComponent, TabParagraphContainerModule, TableComponent, TableConfig, TableDataCellComponent, TableDataCellModule, TableHeaderCellComponent, TableHeaderCellModule, TableLayout, TableModule, TableRendererService, TableService, ThemeModule, ThemeService, TotalComponent, TotalModule, TrapFocus, TruncatePipe, TruncateTextPopoverComponent, TruncateTextPopoverModule, TruncationTooltipDirective, TruncationTooltipModule, USE_MY_ACCOUNT_V2_CONSENT, USE_MY_ACCOUNT_V2_NOTIFICATION_PREFERENCE, USE_STACKED_OUTLETS, UserComponentModule, VideoComponent, VideoModule, ViewComponent, ViewConfig, ViewModes, controlsMustMatch, defaultCmsContentProviders, defaultLayoutConfig, defaultOnNavigateConfig, defaultPWAModuleConfig, defaultPaginationConfig, defaultSeoConfig, defaultSkipLinkConfig, defaultTableConfig, defaultViewConfig, disableTabbingForTick, fontawesomeIconConfig, getAddressNumbers, getSuffixUrlMatcher, initSeoService, layoutConfig, layoutConfigFactory, mediaConfig, mediaPreconnectInitializer, onNavigateFactory, provideCmsStructure, provideLcpPresenceForCmsComponent, provideOutlet, sortTitles, titleScores };
export type { Attachment, AttachmentRestrictions, BreakPoint, CaptchaRenderer, Card, CardAction, CardLinkAction, CarouselScrollingTemplateContext, CmsStructureOptions, CsvFileValidationErrors, Direction, ExportFileOptions, FacetCollapseState, FacetList, FocusConfig, IconConfigResource, IconOptions, IntersectionOptions, JsonLdBuilder, LaunchConfig, LaunchDialog, LaunchInlineDialog, LaunchInlineRootDialog, LaunchOptions, LaunchOutletDialog, LaunchRoute, LayoutBreakPoints, LayoutSections, LayoutSlotConfig, Media, MediaContainer, MediaFormatSize, MessageEvent, MessageEventBoundItem, MessagingConfigs, NavigationNode, PageLayoutHandler, PaginationItem, PaginationOptions, PasswordInputState, PictureElementQueries, PictureHTMLElementSource, PopoverOptions, PopoverPosition, PopoverPositionArray, ProductCarouselItem, ProductListRouteParams, ProvideOutletOptions, RenderParams, ResponsiveTableConfiguration, SchemaBuilder, SearchBoxConfig, SearchCriteria, SearchResults, SeoOptions, SkipFocusConfig, SlotConfig, SlotGroup, SplitViewState, StructuredData, Tab, TabConfig, Table, TableDataOutletContext, TableFieldOptions, TableHeader, TableHeaderOutletContext, TableOptions, TableStructure, TableStructureConfiguration, TrapFocusType, UIPositionRectangle };
