import * as fs from 'fs';
import * as i0 from '@angular/core';
import { isDevMode, InjectionToken, inject, Injectable, NgModule } from '@angular/core';
import { formatWithOptions } from 'node:util';
import { randomUUID } from 'crypto';
import { formatWithOptions as formatWithOptions$1 } from 'util';
import { LoggerService, SERVER_REQUEST_ORIGIN, SERVER_REQUEST_URL, MULTI_ERROR_HANDLER, CmsPageNotFoundOutboundHttpError, HttpResponseStatus, TEST_CONFIG, TEST_CONFIG_COOKIE_NAME } from '@spartacus/core';
import { INITIAL_CONFIG } from '@angular/platform-server';
import { CommonEngine } from '@angular/ssr/node';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Default options to be used for formatting log messages in NodeJS (in both prod and dev mode).
 *
 * They are meant to be passed to `inspect()` or `formatWithOptions()` functions from the `node:util` module
 * for logging purposes.
 */
const DEFAULT_LOGGER_INSPECT_OPTIONS = {
    /**
     * Prevent the depth of the logged object to be limited to 2 (which is a NodeJS default).
     * Otherwise, the object's properties at nested levels higher than 2 would not be visible in the logs.
     * e.g. `{ a: { b: { c: { d: 'e' } } } }` would be presented as `{ a: { b: { c: [Object] } } }` in the logs.
     *
     * The value 10 was chosen arbitrarily. It can be adjusted in the future, if needed.
     */
    depth: 10,
};
/**
 * Options to be used for formatting log messages in NodeJS only in PRODUCTION mode.
 *
 * They are meant to be passed to `inspect()` or `formatWithOptions()` functions from the `node:util` module
 * for logging purposes.
 */
const PRODUCTION_LOGGER_INSPECT_OPTIONS = {
    /**
     * When converting an object into a string, we don't want separate properties
     * to be placed in separate lines of the output string, no matter how wide the output string would be.
     *
     * Otherwise, separate lines of the output string could be interpreted incorrectly
     * as separate log entries, by external monitoring tools (e.g. Kibana).
     */
    breakLength: Infinity,
};
/**
 * Options to be used for formatting log messages in NodeJS.
 *
 * They are meant to be passed to `inspect()` or `formatWithOptions()` functions from the `node:util` module
 * for logging purposes.
 *
 * - In dev mode, it's optimized for human-readable output (multi-line output).
 * - In prod mode, it's optimized for machine-readable output (single-line output)
 */
function getLoggerInspectOptions() {
    return {
        ...DEFAULT_LOGGER_INSPECT_OPTIONS,
        ...(isDevMode() ? {} : PRODUCTION_LOGGER_INSPECT_OPTIONS),
    };
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Error thrown when the traceparent header has an invalid format.
 */
class InvalidTraceparentFormatError extends Error {
    constructor() {
        super('Traceparent header has invalid format.');
    }
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Error thrown when the traceparent header has an invalid length.
 * @param traceparentLength The length of the traceparent header.
 */
class InvalidTraceparentLengthError extends Error {
    constructor(traceparentLength) {
        super(`Traceparent header has invalid length: ${traceparentLength}. Expected 55 characters.`);
    }
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const HEXDIGLC = '[0-9a-f]'; // https://www.w3.org/TR/trace-context/#traceparent-header-field-values
const VERSION = HEXDIGLC + '{2}'; // 2 HEXDIGLC
const TRACE_ID = HEXDIGLC + '{32}'; // 32 HEXDIGLC
const PARENT_ID = HEXDIGLC + '{16}'; // 16 HEXDIGLC
const TRACE_FLAGS = HEXDIGLC + '{2}'; // 2 HEXDIGLC
const TRACEPARENT = [VERSION, TRACE_ID, PARENT_ID, TRACE_FLAGS].join('-'); // separated by dashes
const traceparentPattern = new RegExp('^' + TRACEPARENT + '$');
/**
 * Maps traceparent header to object with properties version, traceId, spanId and traceFlags.
 * Since `traceparent` header may be not attached to the request, the function returns undefined if the header is not provided.
 * If the header is provided but has invalid format or length, the function throws an error.
 *
 * @param traceparent
 * @returns Params of the traceparent header.
 *
 * @see https://www.w3.org/TR/trace-context/#traceparent-header-field-values
 */
function parseTraceparent(traceparent) {
    if (typeof traceparent !== 'string') {
        return undefined;
    }
    if (traceparent.length !== 55) {
        throw new InvalidTraceparentLengthError(traceparent.length);
    }
    if (!traceparentPattern.test(traceparent)) {
        throw new InvalidTraceparentFormatError();
    }
    const [version, traceId, parentId, traceFlags] = traceparent.split('-');
    return { version, traceId, parentId, traceFlags };
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Returns the request context from the request object.
 * @param request - the request object
 * @returns the context of the request
 */
const getRequestContext = (request) => {
    return request.res?.locals?.cx?.request;
};
/**
 * Prepares and updates a request with the context object, which is used to enrich the logs.
 * It contains the random request's UUID, time of receiving the context and the W3C Trace Context (if available).
 * The trace context is parsed from the `traceparent` header, which is specified in
 * the "W3C TraceContext" document. See https://www.w3.org/TR/trace-context/#traceparent-header
 * for more details.
 * @param request - the request object
 * @param logger - the ExpressServerLogger object. It is used to log the error if occurred during parsing traceparent header
 * @returns the context of the request and error if occurred during parsing traceparent header
 */
const preprocessRequestForLogger = (request, logger) => {
    const requestContext = {
        ...createInitialRequestContext(),
        traceContext: getTraceContext(request, logger),
    };
    setRequestContext(request, requestContext);
};
/**
 * Updates the request object with the request context.
 * @param request - the request object
 * @param context - the context of the request
 */
const setRequestContext = (request, context) => {
    if (request.res) {
        request.res.locals = {
            ...request.res.locals,
            cx: {
                ...request.res.locals.cx,
                request: context,
            },
        };
    }
};
/**
 * Creates the initial request context to the request object.
 * @param request - the request object
 * @returns object with a randomly generated UUID and the current time
 */
const createInitialRequestContext = () => {
    const requestContext = {
        uuid: randomUUID(),
        timeReceived: new Date().toISOString(),
    };
    return requestContext;
};
/**
 * Parses the `traceparent` header and returns an object with the W3C TraceContext.
 * In case when the `traceparent` header is absent or invalid, `undefined` value is returned.
 * @param request - the request object
 * @param logger - the logger object
 *
 */
const getTraceContext = (request, logger) => {
    try {
        return parseTraceparent(request.get('traceparent')) ?? undefined;
    }
    catch (e) {
        const error = e instanceof Error
            ? e
            : new Error('Unexpected error during parsing traceparent header');
        logger.error(error.message, { request });
    }
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 *
 * Default logger used in SSR (ExpressJS) to enhance logs visible e.g. in monitoring tools e.g. Kibana.
 * It outputs a JSON with properties "message" and "context",
 * which contains a "timestamp" and details of the "request" ("url", "uuid", "timeReceived")
 *
 * The output "context" JSON will contain also a property "traceContext"
 * with "traceId", "parentId", "version" and "traceFlags",
 * if only the given request has the special header "traceparent" (specifed in
 * the "W3C TraceContext" document. See https://www.w3.org/TR/trace-context/#traceparent-header ).
 */
class DefaultExpressServerLogger {
    log(message, context) {
        /* eslint-disable-next-line no-console */
        console.log(this.stringifyWithContext(message, context));
    }
    warn(message, context) {
        /* eslint-disable-next-line no-console */
        console.warn(this.stringifyWithContext(message, context));
    }
    error(message, context) {
        /* eslint-disable-next-line no-console */
        console.error(this.stringifyWithContext(message, context));
    }
    info(message, context) {
        /* eslint-disable-next-line no-console */
        console.info(this.stringifyWithContext(message, context));
    }
    debug(message, context) {
        /* eslint-disable-next-line no-console */
        console.debug(this.stringifyWithContext(message, context));
    }
    /**
     * Converts a message and an ExpressServerLoggerContext object into a single JSON string containing both pieces of information, which can be used for logging purposes.
     *
     * In prod mode, it prints a single line stringified JSON that can be easily parsed by
     * monitoring tools e.g. Kibana.
     *
     * In dev mode, it prints human readable multi-line stringified JSON with indentation.
     *
     * @protected
     * @param message - The message to be included in the log entry.
     * @param context - The context object associated with the log entry.
     * @returns A JSON string containing both the message and context information, suitable for logging.
     */
    stringifyWithContext(message, context) {
        const logObject = { message, context: this.mapContext(context) };
        if (isDevMode()) {
            // In dev mode, we want a *human-readable* string representation of the log object
            // that can be printed in the console.
            return formatWithOptions(getLoggerInspectOptions(), logObject);
        }
        // In prod mode, we want a *single-line* JSON which is machine-readable - easy to parse for monitoring tools.
        // The monitoring tools can then decide how to display in their UI the JSON's properties.
        return JSON.stringify(logObject, 
        /**
         * Replaces Error instances with their stringified representation.
         */
        (_key, value) => {
            return value instanceof Error ? this.stringifyError(value) : value;
        });
    }
    /**
     * Map the context for the ExpressServerLogger
     *
     * @protected
     * @param context - The logging context object to be mapped
     * @returns - The mapped context with timestamp and request (if available)
     */
    mapContext(context) {
        const timestamp = new Date().toISOString();
        const outputContext = { timestamp, ...context };
        if (context.request) {
            Object.assign(outputContext, {
                request: this.mapRequest(context.request),
            });
        }
        return outputContext;
    }
    /**
     * Maps a Request object into a JavaScript object with specific properties.
     *
     * @protected
     * @param request - An Express Request object.
     * @returns - A mapped request object. By default, it contains only "url", a random "uuid" and "timeReceived" of the request.
     */
    mapRequest(request) {
        return {
            url: request.originalUrl,
            ...getRequestContext(request),
        };
    }
    /**
     * Converts an Error object into a detailed string (with message, stack, cause, etc.).
     *
     * Otherwise, the Error instance would not be visible in the logs after passing through `JSON.stringify()`.
     * For more, see https://stackoverflow.com/a/50738205/11734692
     */
    stringifyError(error) {
        return formatWithOptions(getLoggerInspectOptions(), error);
    }
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Injection token for ExpressServerLogger used for log message in server side rendering.
 * EXPRESS_SERVER_LOGGER is used to provide proper logger to LoggerService instance.
 *
 * Spartacus is providing one type of server logger:
 * - DefaultExpressServerLogger - default implementation used for logging contextual messages in SSR.
 *
 */
const EXPRESS_SERVER_LOGGER = new InjectionToken('EXPRESS_SERVER_LOGGER');

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Represents an injection token for the Request object of ExpressJS in server-side rendering.
 * This token is used to provide the request object to components and services.
 * It's a replacement for the `REQUEST` token from `@nguniversal/express-engine` that was removed only in Angular 17. Now this token is provided by Spartacus.
 */
const REQUEST = new InjectionToken('REQUEST');
/**
 * Represents an injection token for the Response object of ExpressJS in server-side rendering.
 * This token is used to provide the response object to components and services.
 * It's a replacement for the `RESPONSE` token from `@nguniversal/express-engine` that was removed only in Angular 17. Now this token is provided by Spartacus.
 */
const RESPONSE = new InjectionToken('RESPONSE');

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Custom `LoggerService` used in ExpressJS.
 *
 * It converts the input arguments to a final string message similar as the native `console`
 * does (using the native function `format` from `node:util`) and passes this message
 * to a concrete server logger, used in ExpressJS.
 *
 * Besides the message, it also passes the current `request` of ExpressJS as an additional
 * context to the concrete server logger.
 */
class ExpressLoggerService {
    constructor() {
        this.request = inject(REQUEST);
        this.serverLogger = inject(EXPRESS_SERVER_LOGGER);
    }
    log(...args) {
        this.serverLogger.log(this.formatLogMessage(...args), {
            request: this.request,
        });
    }
    warn(...args) {
        this.serverLogger.warn(this.formatLogMessage(...args), {
            request: this.request,
        });
    }
    error(...args) {
        this.serverLogger.error(this.formatLogMessage(...args), {
            request: this.request,
        });
    }
    info(...args) {
        this.serverLogger.info(this.formatLogMessage(...args), {
            request: this.request,
        });
    }
    debug(...args) {
        this.serverLogger.debug(this.formatLogMessage(...args), {
            request: this.request,
        });
    }
    formatLogMessage(message, ...optionalParams) {
        return formatWithOptions$1(getLoggerInspectOptions(), message, ...optionalParams);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ExpressLoggerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ExpressLoggerService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ExpressLoggerService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Custom `LoggerService` used in pre-rendering in the server environment.
 *
 * It simply forwards the arguments to the native `console` methods.
 */
class PrerenderingLoggerService extends LoggerService {
    log(...args) {
        /* eslint-disable-next-line no-console */
        console.log(...args);
    }
    warn(...args) {
        /* eslint-disable-next-line no-console */
        console.warn(...args);
    }
    error(...args) {
        /* eslint-disable-next-line no-console */
        console.error(...args);
    }
    info(...args) {
        /* eslint-disable-next-line no-console */
        console.info(...args);
    }
    debug(...args) {
        /* eslint-disable-next-line no-console */
        console.debug(...args);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PrerenderingLoggerService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PrerenderingLoggerService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PrerenderingLoggerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const serverLoggerServiceFactory = () => {
    const isExpress = inject(REQUEST, { optional: true }) !== null;
    return isExpress
        ? inject(ExpressLoggerService)
        : inject(PrerenderingLoggerService);
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Helper function that maps optimization options to primitive values.
 * This is useful for logging and monitoring purposes.
 *
 * @param value optimization options that should be logged
 * @returns options containing only primitive values that are easier to read by developers and monitoring tools
 */
const getLoggableSsrOptimizationOptions = (value) => {
    const newValue = { ...value };
    Object.keys(value).forEach((key) => {
        if (isClassInstance(newValue[key])) {
            newValue[key] = newValue[key].constructor?.name;
        }
        if (typeof newValue[key] === 'function') {
            newValue[key] = newValue[key].toString();
        }
    });
    return newValue;
};
/**
 * Checks if the given value is a class instance,
 * but not a plain Object.
 *
 * @private
 */
const isClassInstance = (value) => {
    return typeof value === 'object' && value.constructor !== Object;
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * It keeps track of the used cache size and helps making sure that adding new entries
 * doesn't cause exceeding the cache size limit.
 */
class RenderingCacheSizeManager {
    constructor(options) {
        this.options = options;
        /**
         * The total size of the used cache in bytes.
         * This value will change as we add or remove entries from the cache.
         */
        this.usedSize = 0;
        /**
         * The maximum size of the cache in bytes, configured in the SSR options.
         */
        this.CACHE_SIZE_LIMIT = this.options?.cacheSizeMemory ?? 0;
        this.validateOptions();
    }
    /**
     * Validates the `SsrOptimizationOptions` needed for this class to work properly.
     * In case of invalid options, it will log an error using the configured logger.
     */
    validateOptions() {
        if (typeof this.options?.cacheEntrySizeCalculator?.calculateSize !==
            'function') {
            this.options?.logger?.error?.('Invalid SSR config `options.cacheEntrySizeCalculator`! It should be an object with the `calculateSize()` method.', {});
        }
        if (typeof this.options?.cacheSizeMemory !== 'number' ||
            this.options?.cacheSizeMemory <= 0) {
            this.options?.logger?.error?.('Invalid SSR config `options.cacheSizeMemory`! It should be a number greater than 0.', {});
        }
    }
    /**
     * Calculates the size of the entry using the calculator provided in the options.
     */
    calculateEntrySize(entry) {
        return this.options?.cacheEntrySizeCalculator?.calculateSize(entry) ?? 0;
    }
    /**
     * Tells whether there's enough space for the given entry size.
     */
    hasSpaceForEntrySize(entrySize) {
        return entrySize <= this.CACHE_SIZE_LIMIT - this.usedSize;
    }
    /**
     * Tells whether the entry is too large to ever fit in the cache
     * (i.e. this single entry is larger than the total possible cache size).
     */
    isEntryLargerThanCacheLimit(entrySize) {
        return entrySize > this.CACHE_SIZE_LIMIT;
    }
    /**
     * Adds the size of the entry to the total tracked used size.
     */
    trackEntrySize(entrySize) {
        this.usedSize += entrySize;
        // This should never happen. MAX_SAFE_INTEGER is 7.9 Petabytes, but in reality NodeJS pods have only some Gigabytes of memory.
        // It's a safe guard in case of some bug.
        if (this.usedSize > Number.MAX_SAFE_INTEGER) {
            this.options?.logger?.error?.('RenderingCacheSizeManager: the used size is greater than the MAX_SAFE_INTEGER value! This should never happen!', {});
            this.usedSize = Number.MAX_SAFE_INTEGER;
        }
    }
    /**
     * Subtracts the size of the entry from the total tracked used size.
     */
    untrackEntrySize(entrySize) {
        this.usedSize = this.usedSize - entrySize;
        // This should never happen. It's a safe guard in case of some bug.
        if (this.usedSize < 0) {
            this.options?.logger?.error?.('RenderingCacheSizeManager: the used size is negative! This should never happen!', {});
            this.usedSize = 0; // clear the used size to avoid negative values
        }
    }
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class RenderingCache {
    constructor(options) {
        this.options = options;
        this.renders = new Map();
    }
    get sizeManager() {
        if (!this._sizeManager) {
            this._sizeManager = new RenderingCacheSizeManager(this.options);
        }
        return this._sizeManager;
    }
    setAsRendering(key) {
        // Release the size of any previous entry for this key before overwriting
        // it with the placeholder. Otherwise the previous entry's `_size` is
        // orphaned in `sizeManager.usedSize` (the placeholder has no `_size`),
        // and a later `store()` for the same key won't be able to recover it.
        this.clear(key);
        this.renders.set(key, { rendering: true });
    }
    isRendering(key) {
        return !!this.renders.get(key)?.rendering;
    }
    /**
     * Store the entry, respecting the cache limit.
     */
    store(key, err, html) {
        const entry = { err, html };
        if (this.options?.ttl) {
            entry.time = Date.now();
        }
        // Remove old entry for the key, releasing its tracked size. The entry
        // may exist for the key, because we've previously called `store()` for
        // it (e.g. on a TTL-driven re-render) or `setAsRendering()`. Going
        // through `clear()` ensures `sizeManager.untrackEntrySize()` is called
        // for the previous `_size`; a plain `renders.delete()` would leak it.
        this.clear(key);
        if (!this.options?.shouldCacheRenderingResult?.({
            options: this.options,
            entry,
        })) {
            return;
        }
        this.storeUsingMemoryLimit(key, entry);
    }
    /**
     * Store the entry, respecting the bytes limit.
     *
     * If needed, removes oldest entries until there's enough space for the new entry.
     */
    storeUsingMemoryLimit(key, entry) {
        const entrySize = this.sizeManager.calculateEntrySize(entry);
        if (this.sizeManager.isEntryLargerThanCacheLimit(entrySize)) {
            return;
        }
        this.clearOldestEntriesForSize(entrySize);
        entry._size = entrySize;
        this.renders.set(key, entry);
        this.sizeManager.trackEntrySize(entrySize);
    }
    /**
     * Clear oldest entries until there's enough space for the new entry.
     */
    clearOldestEntriesForSize(requiredSize) {
        while (!this.sizeManager.hasSpaceForEntrySize(requiredSize) &&
            this.renders.size > 0) {
            const oldestKey = this.renders.keys().next().value;
            if (oldestKey === undefined) {
                // Still not enough space, but no more entries to clear.
                // In practice this case should never happen, because initially we checked `isEntryLargerThanCacheLimit` -
                // we validated whether the new entry's size is not bigger than the total cache size limit.
                break;
            }
            this.clear(oldestKey);
        }
    }
    get(key) {
        return this.renders.get(key);
    }
    clear(key) {
        const entry = this.renders.get(key);
        this.renders.delete(key);
        this.sizeManager.untrackEntrySize(entry?._size ?? 0);
    }
    isReady(key) {
        const entry = this.renders.get(key);
        const isRenderPresent = entry?.html || entry?.err;
        return isRenderPresent && this.isFresh(key);
    }
    isFresh(key) {
        if (!this.options?.ttl) {
            return true;
        }
        return Date.now() - (this.renders.get(key)?.time ?? 0) < this.options?.ttl;
    }
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
function getRequestOrigin(req) {
    // If express is resolving and trusting X-Forwarded-Host, we want to take it
    // into an account to properly generate request origin.
    const trustProxyFn = req.app.get('trust proxy fn');
    let forwardedHost = req.get('X-Forwarded-Host');
    if (forwardedHost && trustProxyFn(req.connection.remoteAddress, 0)) {
        if (forwardedHost.indexOf(',') !== -1) {
            // Note: X-Forwarded-Host is normally only ever a
            //       single value, but this is to be safe.
            forwardedHost = forwardedHost
                .substring(0, forwardedHost.indexOf(','))
                .trimRight();
        }
        return `${req.protocol}://${forwardedHost}`;
    }
    else {
        return `${req.protocol}://${req.get('host')}`;
    }
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
function getRequestUrl(req) {
    return getRequestOrigin(req) + req.originalUrl;
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Default implementation of the cache entry size calculator.
 *
 * For HTML string, it returns the size of the string in bytes, assuming 2 bytes per each character
 * (an upper-bound estimation assuming V8 is using `SeqTwoByteString` for string cache entries).
 *
 * For error object, it only roughly approximates the size - it sums sizes of the `name`, `message` and `stack` string properties.
 *
 * **CAUTION**: the error object can be potentially anything and can have more properties (not necessarily strings),
 *          so it's prone to under-estimation!
 *          It's not recommended to cache error objects.
 */
class DefaultCacheEntrySizeCalculator {
    calculateSize(entry) {
        // entry should have either `html` or `err` property
        if (entry.html) {
            return this.calculateHtmlSize(entry.html);
        }
        if (entry.err) {
            return this.calculateErrorSize(entry.err);
        }
        return 0;
    }
    /**
     * Calculates the size of the rendered HTML.
     */
    calculateHtmlSize(html) {
        return this.getStringSize(html);
    }
    /**
     * Roughly approximates the size of the error, by calculating the size of 3 string properties:
     * - name
     * - message
     * - stack
     */
    calculateErrorSize(error) {
        let size = 0;
        const properties = ['name', 'message', 'stack'];
        properties.forEach((property) => {
            if (error?.[property]) {
                size += this.getStringSize(error[property]);
            }
        });
        return size;
    }
    /**
     * Returns string size in bytes for NodeJS V8 engine.
     * Uses 2 bytes per character as an upper-bound estimate.
     *
     * V8 can use either one or two bytes per character, but for Spartacus SSR
     * it consistently uses two-byte-per-character strings (`SeqTwoByteString`)
     * which was verified through heap snapshots and memory measurements.
     *
     * For more on V8's `SeqTwoByteString`, see https://github.com/v8/v8/blob/c865b8257a/src/objects/string.h#L921-L923
     */
    getStringSize(str) {
        return 2 * str.length;
    }
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultAlwaysCsrOptions = {
    excludedUrls: ['cx-preview'],
};
const hasExcludedParams = (request, excludedParams) => {
    const params = request.query
        ? Object.getOwnPropertyNames(request.query)
        : [];
    if (!excludedParams) {
        return false;
    }
    return excludedParams.some((excludedParam) => params.some((param) => excludedParam === param));
};
const hasExcludedUrl = (request, excludedUrls) => {
    return request.url && excludedUrls
        ? excludedUrls.some((url) => request.url.search(url) > -1)
        : false;
};
const shouldFallbackToCsr = (request, { excludedParams, excludedUrls }) => {
    return (hasExcludedParams(request, excludedParams) ||
        hasExcludedUrl(request, excludedUrls));
};
/**
 * Creates a rendering strategy resolver function with the specified options.
 *
 * @function
 * @param  options - The options to configure the rendering strategy resolver.
 * @param [options.excludedUrls] - An optional array of URLs for which server-side rendering (SSR) should be disabled.
 * @param [options.excludedParams] - An optional array of Query parameters for which SSR should be disabled.
 * @returns A rendering strategy resolver function that takes a Request object
 * as a parameter and returns the rendering strategy to be applied for the request, which can be either
 * `RenderingStrategy.ALWAYS_CSR` or `RenderingStrategy.DEFAULT`.
 */
const defaultRenderingStrategyResolver = (options) => (request) => {
    if (hasExcludedUrl(request, defaultAlwaysCsrOptions.excludedUrls)) {
        return RenderingStrategy.ALWAYS_CSR;
    }
    return shouldFallbackToCsr(request, options)
        ? RenderingStrategy.ALWAYS_CSR
        : RenderingStrategy.DEFAULT;
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultRenderingStrategyResolverOptions = {
    excludedUrls: ['checkout', 'my-account', 'punchout', 'opf'],
    excludedParams: ['asm'],
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var RenderingStrategy;
(function (RenderingStrategy) {
    RenderingStrategy[RenderingStrategy["ALWAYS_CSR"] = -1] = "ALWAYS_CSR";
    RenderingStrategy[RenderingStrategy["DEFAULT"] = 0] = "DEFAULT";
    RenderingStrategy[RenderingStrategy["ALWAYS_SSR"] = 1] = "ALWAYS_SSR";
})(RenderingStrategy || (RenderingStrategy = {}));
/**
 * Returns the full url for the given SSR Request.
 */
const getDefaultRenderKey = getRequestUrl;
const defaultSsrOptimizationOptions = {
    cache: false,
    cacheSizeMemory: 800_000_000,
    cacheEntrySizeCalculator: new DefaultCacheEntrySizeCalculator(),
    ttl: undefined,
    concurrency: 10,
    timeout: 3_000,
    forcedSsrTimeout: 60_000,
    maxRenderTime: 300_000,
    reuseCurrentRendering: true,
    renderingStrategyResolver: defaultRenderingStrategyResolver(defaultRenderingStrategyResolverOptions),
    logger: new DefaultExpressServerLogger(),
    shouldCacheRenderingResult: ({ entry: { err } }) => !err,
    renderKeyResolver: getDefaultRenderKey,
    ssrFeatureToggles: {},
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * The rendered pages are kept in memory to be served on next request. If the `cache` is set to `false`, the
 * response is evicted as soon as the first successful response is successfully returned.
 */
class OptimizedSsrEngine {
    get engineInstance() {
        return this.renderResponse.bind(this);
    }
    constructor(expressEngine, ssrOptions) {
        this.expressEngine = expressEngine;
        this.ssrOptions = ssrOptions;
        this.currentConcurrency = 0;
        this.templateCache = new Map();
        /**
         * When the config `reuseCurrentRendering` is enabled, we want perform
         * only one render for one rendering key and reuse the html result
         * for all the pending requests for the same rendering key.
         * Therefore we need to store the callbacks for all the pending requests
         * and invoke them with the html after the render completes.
         *
         * This Map should be used only when `reuseCurrentRendering` config is enabled.
         * It's indexed by the rendering keys.
         */
        this.renderCallbacks = new Map();
        this.ssrOptions = ssrOptions
            ? {
                ...defaultSsrOptimizationOptions,
                // overrides the default options
                ...ssrOptions,
                // merge feature toggles
                ssrFeatureToggles: {
                    ...defaultSsrOptimizationOptions.ssrFeatureToggles,
                    ...ssrOptions.ssrFeatureToggles,
                },
            }
            : undefined;
        if (!this.ssrOptions?.logger) {
            throw new Error('`SsrOptimizationOptions.logger` is not defined');
        }
        this.logger = this.ssrOptions?.logger;
        this.renderingCache = new RenderingCache(this.ssrOptions);
        this.logOptions();
    }
    logOptions() {
        if (!this.ssrOptions) {
            return;
        }
        const loggableSsrOptions = getLoggableSsrOptimizationOptions(this.ssrOptions);
        this.logger.log(`[spartacus] SSR optimization engine initialized`, {
            options: loggableSsrOptions,
        });
    }
    /**
     * When SSR page can not be returned in time, we're returning index.html of
     * the CSR application.
     * The CSR application is returned with the "Cache-Control: no-store" response-header. This notifies external cache systems to not use the CSR application for the subsequent request.
     */
    fallbackToCsr(response, filePath, callback) {
        response.set('Cache-Control', 'no-store');
        callback(undefined, this.getDocument(filePath));
    }
    getRenderingKey(request) {
        return this.ssrOptions?.renderKeyResolver
            ? this.ssrOptions.renderKeyResolver(request)
            : getDefaultRenderKey(request);
    }
    getRenderingStrategy(request) {
        return this.ssrOptions?.renderingStrategyResolver
            ? this.ssrOptions.renderingStrategyResolver(request)
            : RenderingStrategy.DEFAULT;
    }
    /**
     * When returns true, the server side rendering should be performed.
     * When returns false, the CSR fallback should be returned.
     *
     * We should not render, when there is already
     * a pending rendering for the same rendering key
     * (unless the `reuseCurrentRendering` config option is enabled)
     * OR when the concurrency limit is exceeded.
     */
    shouldRender(request) {
        const renderingKey = this.getRenderingKey(request);
        const concurrencyLimitExceeded = this.isConcurrencyLimitExceeded(renderingKey);
        const fallBack = this.renderingCache.isRendering(renderingKey) &&
            !this.ssrOptions?.reuseCurrentRendering;
        if (fallBack) {
            this.logger.log(`CSR fallback: rendering in progress (${request?.originalUrl})`, { request });
        }
        else if (concurrencyLimitExceeded) {
            this.logger.log(`CSR fallback: Concurrency limit exceeded (${this.ssrOptions?.concurrency})`, { request });
        }
        return ((!fallBack &&
            !concurrencyLimitExceeded &&
            this.getRenderingStrategy(request) !== RenderingStrategy.ALWAYS_CSR) ||
            this.getRenderingStrategy(request) === RenderingStrategy.ALWAYS_SSR);
    }
    /**
     * Checks for the concurrency limit
     *
     * @returns true if rendering this request would exceed the concurrency limit
     */
    isConcurrencyLimitExceeded(renderingKey) {
        // If we can reuse a pending render for this request, we don't take up a new concurrency slot.
        // In that case we don't exceed the concurrency limit even if the `currentConcurrency`
        // already reaches the limit.
        if (this.ssrOptions?.reuseCurrentRendering &&
            this.renderingCache.isRendering(renderingKey)) {
            return false;
        }
        return this.ssrOptions?.concurrency
            ? this.currentConcurrency >= this.ssrOptions.concurrency
            : false;
    }
    /**
     * Returns true, when the `timeout` option has been configured to non-zero value OR
     * when the rendering strategy for the given request is ALWAYS_SSR.
     * Otherwise, it returns false.
     */
    shouldTimeout(request) {
        return (!!this.ssrOptions?.timeout ||
            this.getRenderingStrategy(request) === RenderingStrategy.ALWAYS_SSR);
    }
    /**
     * Returns the timeout value.
     *
     * In case of the rendering strategy ALWAYS_SSR, it returns the config `forcedSsrTimeout`.
     * Otherwise, it returns the config `timeout`.
     */
    getTimeout(request) {
        return this.getRenderingStrategy(request) === RenderingStrategy.ALWAYS_SSR
            ? (this.ssrOptions?.forcedSsrTimeout ?? 60000)
            : (this.ssrOptions?.timeout ?? 0);
    }
    /**
     * If there is an available cached response for this rendering key,
     * it invokes the given render callback with the response and returns true.
     *
     * Otherwise, it returns false.
     */
    returnCachedRender(request, callback) {
        const key = this.getRenderingKey(request);
        if (this.renderingCache.isReady(key)) {
            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            const cached = this.renderingCache.get(key);
            callback(cached.err, cached.html);
            if (!this.ssrOptions?.cache) {
                // we drop cached rendering if caching is disabled
                this.renderingCache.clear(key);
            }
            return true;
        }
        return false;
    }
    /**
     * Handles the request and invokes the given `callback` with the result html / error.
     *
     * The result might be ether:
     * - a CSR fallback with a basic `index.html` content
     * - a result rendered by the original Angular Universal express engine
     * - a result from the in-memory cache (which was previously rendered by Angular Universal express engine).
     */
    renderResponse(filePath, options, callback) {
        preprocessRequestForLogger(options.req, this.logger);
        const request = options.req;
        const response = options.req.res;
        if (this.returnCachedRender(request, callback)) {
            this.logger.log(`Render from cache (${request?.originalUrl})`, {
                request,
            });
            return;
        }
        if (!this.shouldRender(request)) {
            this.fallbackToCsr(response, filePath, callback);
            return;
        }
        let requestTimeout;
        if (this.shouldTimeout(request)) {
            // establish timeout for rendering
            const timeout = this.getTimeout(request);
            requestTimeout = setTimeout(() => {
                requestTimeout = undefined;
                this.fallbackToCsr(response, filePath, callback);
                this.logger.log(`SSR rendering exceeded timeout ${timeout}, fallbacking to CSR for ${request?.originalUrl}`, { request });
            }, timeout);
        }
        else {
            // Here we respond with the fallback to CSR, but we don't `return`.
            // We let the actual rendering task to happen in the background
            // to eventually store the rendered result in the cache.
            this.fallbackToCsr(response, filePath, callback);
        }
        const renderingKey = this.getRenderingKey(request);
        const renderCallback = (err, html) => {
            if (requestTimeout) {
                // if request is still waiting for render, return it
                clearTimeout(requestTimeout);
                callback(err, html);
                this.logForRenderResult(err, html, request);
                // store the render only if caching is enabled
                if (this.ssrOptions?.cache) {
                    this.renderingCache.store(renderingKey, err, html);
                }
                else {
                    this.renderingCache.clear(renderingKey);
                }
            }
            else {
                // store the render for future use
                this.renderingCache.store(renderingKey, err, html);
            }
        };
        this.handleRender({
            filePath,
            options,
            renderCallback,
            request,
        });
    }
    /** Retrieve the document from the cache or the filesystem */
    getDocument(filePath) {
        let doc = this.templateCache.get(filePath);
        if (!doc) {
            doc = fs.readFileSync(filePath, 'utf-8');
            this.templateCache.set(filePath, doc);
        }
        return doc;
    }
    /**
     * Delegates the render to the original _Angular Universal express engine_.
     *
     * In case when the config `reuseCurrentRendering` is enabled and **if there is already a pending
     * render task for the same rendering key**, it doesn't delegate a new render to Angular Universal.
     * Instead, it waits for the current rendering to complete and then reuse the result for all waiting requests.
     */
    handleRender({ filePath, options, renderCallback, request, }) {
        if (!this.ssrOptions?.reuseCurrentRendering) {
            this.startRender({
                filePath,
                options,
                renderCallback,
                request,
            });
            return;
        }
        const renderingKey = this.getRenderingKey(request);
        if (!this.renderCallbacks.has(renderingKey)) {
            this.renderCallbacks.set(renderingKey, []);
        }
        this.renderCallbacks.get(renderingKey)?.push(renderCallback);
        if (!this.renderingCache.isRendering(renderingKey)) {
            this.startRender({
                filePath,
                options,
                request,
                renderCallback: (err, html) => {
                    // Share the result of the render with all awaiting requests for the same key:
                    // Note: we access the Map at the moment of the render finished (don't store value in a local variable),
                    //       because in the meantime something might have deleted the value (i.e. when `maxRenderTime` passed).
                    this.renderCallbacks
                        .get(renderingKey)
                        ?.forEach((cb) => cb(err, html)); // pass the shared result to all waiting rendering callbacks
                    this.renderCallbacks.delete(renderingKey);
                },
            });
        }
        this.logger.log(`Request is waiting for the SSR rendering to complete (${request?.originalUrl})`, { request });
    }
    /**
     * Delegates the render to the original _Angular Universal express engine_.
     *
     * There is no way to abort the running render of Angular Universal.
     * So if the render doesn't complete in the configured `maxRenderTime`,
     * we just consider the render task as hanging (note: it's a potential memory leak!).
     * Later on, even if the render completes somewhen in the future, we will ignore
     * its result.
     */
    startRender({ filePath, options, renderCallback, request, }) {
        const renderingKey = this.getRenderingKey(request);
        // Setting the timeout for hanging renders that might not ever finish due to various reasons.
        // After the configured `maxRenderTime` passes, we consider the rendering task as hanging,
        // and release the concurrency slot and forget all callbacks waiting for the render's result.
        let maxRenderTimeout = setTimeout(() => {
            this.renderingCache.clear(renderingKey);
            maxRenderTimeout = undefined;
            this.currentConcurrency--;
            if (this.ssrOptions?.reuseCurrentRendering) {
                this.renderCallbacks.delete(renderingKey);
            }
            this.logger.log(`Rendering of ${request?.originalUrl} was not able to complete. This might cause memory leaks!`, { request });
        }, this.ssrOptions?.maxRenderTime ?? 300000); // 300000ms == 5 minutes
        this.logger.log(`Rendering started (${request?.originalUrl})`, { request });
        this.renderingCache.setAsRendering(renderingKey);
        this.currentConcurrency++;
        options = {
            ...options,
            providers: [
                {
                    provide: EXPRESS_SERVER_LOGGER,
                    useValue: this.logger,
                },
                ...(options?.providers ?? []),
            ],
        };
        this.expressEngine(filePath, options, (err, html) => {
            if (!maxRenderTimeout) {
                // ignore this render's result because it exceeded maxRenderTimeout
                this.logger.log(`Rendering of ${request.originalUrl} completed after the specified maxRenderTime, therefore it was ignored.`, { request });
                return;
            }
            clearTimeout(maxRenderTimeout);
            this.logger.log(`Rendering completed (${request?.originalUrl})`, {
                request,
            });
            this.currentConcurrency--;
            renderCallback(err, html);
        });
    }
    /**
     * Logs the result of the render.
     */
    logForRenderResult(err, html, request) {
        if (html) {
            this.logger.log(`Request is resolved with the SSR rendering result (${request?.originalUrl})`, { request });
        }
        if (err) {
            this.logger.error(`Request is resolved with the SSR rendering error (${request?.originalUrl})`, { request, error: err });
        }
    }
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Propagates the given error object to the higher layer in the server.
 *
 * It's meant to propagate errors for example to ExpressJS layer when using SSR
 * or to a Prerendering Worker when using Server Prerendering.
 * Currently, it's provided OOTB only in SSR (not prerendering), in the `CxCommonEngine` class.
 *
 * Note: We need it until Angular implements a proper propagation of async errors
 * from an app to the the higher layer in the server.
 * For more, see the Angular issue https://github.com/angular/angular/issues/33642
 */
const PROPAGATE_ERROR_TO_SERVER = new InjectionToken('PROPAGATE_ERROR_TO_SERVER');

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Propagates the given error object to the higher layer in the server.
 *
 * It's meant to propagate errors for example to ExpressJS layer when using SSR
 * or to a Prerendering Worker when using Server Prerendering.
 * Currently, it's provided OOTB only in SSR (not prerendering), in the `CxCommonEngine` class.
 *
 * Note: We need it until Angular implements a proper propagation of async errors
 * from an app to the the higher layer in the server.
 * For more, see the Angular issue https://github.com/angular/angular/issues/33642
 *
 * Intended to be used as part of a multi-error handler strategy.
 *
 * @see MultiErrorHandler
 */
class PropagatingToServerErrorHandler {
    constructor() {
        this.propagateErrorToServer = inject(PROPAGATE_ERROR_TO_SERVER, {
            optional: true,
        }) ?? (() => { }); // fallback to noop, if not provided
    }
    handleError(error) {
        this.propagateErrorToServer(error);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PropagatingToServerErrorHandler, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PropagatingToServerErrorHandler, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PropagatingToServerErrorHandler, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Returns a factory function which resolves the server request origin.
 */
function serverRequestOriginFactory(options) {
    return () => {
        const serverRequestOrigin = inject(SERVER_REQUEST_ORIGIN, {
            optional: true,
            skipSelf: true,
        });
        // usually prerendering mode, but can be SSR
        if (options?.serverRequestOrigin) {
            return options.serverRequestOrigin;
        }
        // SSR mode, from express engine
        if (serverRequestOrigin) {
            return serverRequestOrigin;
        }
        throw new Error(`The request origin is not set. 
    If you are using the default environment variable, please specify it when initiating the process.
    
    E.g.
    > SERVER_REQUEST_ORIGIN=https://my.domain.com yarn prerender
    > SERVER_REQUEST_ORIGIN=http://localhost:4200 yarn serve:ssr
    
    
    Alternatively, you can pass it as an argument to provideServer
    function, but beware it will be used for server-side rendering as well.
    
    E.g.
    @NgModule({
      // ...
      providers: [
        provideServer({
          serverRequestOrigin: 'https://my.domain.com',
        }),
      ],
    })
    export class AppServerModule {}`);
    };
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Returns a factory function which resolves the server request URL.
 */
function serverRequestUrlFactory(options) {
    return () => {
        const platformConfig = inject(INITIAL_CONFIG);
        const serverRequestOrigin = inject(SERVER_REQUEST_ORIGIN);
        const serverRequestUrl = inject(SERVER_REQUEST_URL, {
            optional: true,
            skipSelf: true,
        });
        // SSR mode
        if (serverRequestUrl) {
            // should override the automatically recognized origin
            if (options?.serverRequestOrigin) {
                return serverRequestUrl.replace(serverRequestOrigin, options.serverRequestOrigin);
            }
            return serverRequestUrl;
        }
        // prerendering mode (no express server)
        // platformConfig.url may be a full URL (e.g. 'http://ng-localhost/')
        // in newer Angular versions, so we need to extract just the path.
        const url = platformConfig.url ?? '/';
        try {
            const parsedUrl = new URL(url);
            return serverRequestOrigin + parsedUrl.pathname;
        }
        catch {
            // If it's already a relative path, just concatenate
            return serverRequestOrigin + url;
        }
    };
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Returns the providers used for SSR and pre-rendering processes.
 */
function provideServer(options) {
    return [
        {
            provide: SERVER_REQUEST_ORIGIN,
            useFactory: serverRequestOriginFactory(options),
        },
        {
            provide: SERVER_REQUEST_URL,
            useFactory: serverRequestUrlFactory(options),
        },
        {
            provide: LoggerService,
            useFactory: serverLoggerServiceFactory,
        },
        {
            provide: MULTI_ERROR_HANDLER,
            useExisting: PropagatingToServerErrorHandler,
            multi: true,
        },
    ];
}
/**
 * Returns Spartacus providers to be passed to the Angular express engine (in SSR)
 *
 * @param options
 */
function getServerRequestProviders() {
    return [
        {
            provide: SERVER_REQUEST_ORIGIN,
            useFactory: getRequestOrigin,
            deps: [REQUEST],
        },
        {
            provide: SERVER_REQUEST_URL,
            useFactory: getRequestUrl,
            deps: [REQUEST],
        },
    ];
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * The wrapper over the standard ngExpressEngine, that provides tokens for Spartacus
 * @param ngExpressEngine
 */
class NgExpressEngineDecorator {
    /**
     * Returns the higher order ngExpressEngine with provided tokens for Spartacus
     *
     * @param ngExpressEngine
     */
    static get(ngExpressEngine, optimizationOptions) {
        return decorateExpressEngine(ngExpressEngine, optimizationOptions);
    }
}
function decorateExpressEngine(ngExpressEngine, optimizationOptions = defaultSsrOptimizationOptions) {
    return function (setupOptions) {
        const engineInstance = ngExpressEngine({
            ...setupOptions,
            providers: [
                // add spartacus related providers
                ...getServerRequestProviders(),
                ...(setupOptions.providers ?? []),
            ],
        });
        // apply optimization wrapper if optimization options were defined
        return optimizationOptions
            ? new OptimizedSsrEngine(engineInstance, optimizationOptions)
                .engineInstance
            : engineInstance;
    };
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * The Spartacus extension of the Angular's `CommonEngine`. It is able to handle the propagated server responses caught during server-side rendering of a Spartacus app.
 * For reference, see Angular's source code: https://github.com/angular/angular-cli/blob/6cf866225ab09f8b4b3803c000b632bed8448ce4/packages/angular/ssr/src/common-engine.ts#L56
 *
 * @extends {CommonEngine}
 */
class CxCommonEngine extends CommonEngine {
    constructor(options) {
        super(options);
    }
    /**
     * @override
     * Renders for the given options.
     * If an error is populated from the rendered applications
     * (via `PROPAGATE_ERROR_TO_SERVER` callback), then such an error
     * will be thrown and the result promise rejected - but only AFTER the rendering is complete.
     * In other words, at first an error occurs and it's captured, then we wait until the rendering completes
     * and ONLY then we reject the promise with the payload being the encountered error.
     *
     * Note: if more errors are captured during the rendering, only the first one will be used
     *       as the payload of the rejected promise, others won't.
     *
     * @param {CommonEngineRenderOptions} options - The options to render.
     * @returns {Promise<string>} Promise which resolves with the rendered HTML as a string
     *                            OR rejects with the error, if any is propagated from the rendered app.
     */
    async render(options) {
        let error;
        return super
            .render({
            ...options,
            providers: [
                {
                    provide: PROPAGATE_ERROR_TO_SERVER,
                    useFactory: () => {
                        return (propagatedError) => {
                            // We're interested only the first propagated error, so we use `??=` instead of `=`:
                            error ??= propagatedError;
                        };
                    },
                },
                ...(options.providers ?? []),
            ],
        })
            .then((html) => {
            if (error) {
                throw error;
            }
            return html;
        });
    }
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * @license
 * The MIT License
 * Copyright (c) 2010-2023 Google LLC. http://angular.io/license
 *
 * See:
 * - https://github.com/angular/universal/blob/e798d256de5e4377b704e63d993dc56ea35df97d/modules/express-engine/src/main.ts
 */
function getReqResProviders(req, res) {
    const providers = [
        {
            provide: REQUEST,
            useValue: req,
        },
    ];
    if (res) {
        providers.push({
            provide: RESPONSE,
            useValue: res,
        });
    }
    return providers;
}
/**
 * This is an express engine for handling Angular Applications
 *
 * Function `ngExpressEngine` was originally present in Angular for a long time and was removed in version Angular 17.
 * However, it is needed in Spartacus for backward compatibility reasons.
 * Therefore, we have copied the code from the Angular repository and included it in our Spartacus repository to avoid larger refactors.
 *
 * @license
 * The MIT License
 * Copyright (c) 2010-2023 Google LLC. http://angular.io/license
 *
 * See:
 * - https://github.com/angular/universal/blob/e798d256de5e4377b704e63d993dc56ea35df97d/modules/express-engine/src/main.ts
 */
function ngExpressEngine(setupOptions) {
    const engine = new CxCommonEngine({
        bootstrap: setupOptions.bootstrap,
        providers: setupOptions.providers,
        enablePerformanceProfiler: setupOptions.enablePerformanceProfiler,
        allowedHosts: setupOptions.allowedHosts,
    });
    return function (filePath, options, callback) {
        try {
            const renderOptions = { ...options };
            if (!setupOptions.bootstrap && !renderOptions.bootstrap) {
                throw new Error('You must pass in a NgModule to be bootstrapped');
            }
            const { req } = renderOptions;
            const res = renderOptions.res ?? req.res;
            renderOptions.url =
                renderOptions.url ??
                    `${req.protocol}://${req.get('host') || ''}${req.baseUrl}${req.url}`;
            renderOptions.documentFilePath =
                renderOptions.documentFilePath ?? filePath;
            renderOptions.providers = [
                ...(renderOptions.providers ?? []),
                getReqResProviders(req, res),
            ];
            renderOptions.publicPath =
                renderOptions.publicPath ??
                    setupOptions.publicPath ??
                    options.settings?.views;
            renderOptions.inlineCriticalCss =
                renderOptions.inlineCriticalCss ?? setupOptions.inlineCriticalCss;
            engine
                .render(renderOptions)
                .then((html) => callback(null, html))
                .catch(callback);
        }
        catch (err) {
            err instanceof Error && callback(err);
        }
    };
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Returns default handlers which results in a fallback to client side rendering.
 * - If cms page not found, the document content is sent to the client with the appropriate 404 status code.
 * - For rest of errors, the document content is sent to the client with the appropriate status 500 code.
 *
 * @param documentContent The document content to be sent to the client.
 * @returns The error request handler.
 */
const defaultExpressErrorHandlers = (documentContent) => (err, _req, res, _next) => {
    if (!res.headersSent) {
        res.set('Cache-Control', 'no-store');
        const statusCode = err instanceof CmsPageNotFoundOutboundHttpError
            ? HttpResponseStatus.NOT_FOUND
            : HttpResponseStatus.INTERNAL_SERVER_ERROR;
        res.status(statusCode).send(documentContent);
    }
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
function getCookie(cookie, name) {
    const regExp = new RegExp('(?:^|;\\s*)' + name + '=([^;]*)', 'g');
    const result = regExp.exec(cookie);
    return (result && decodeURIComponent(result[1])) || '';
}
function parseConfigJSON(config) {
    try {
        return JSON.parse(decodeURIComponent(config));
    }
    catch (_) {
        return {};
    }
}
/**
 * A counterpart of the `TestConfigModule` from `@spartacus/core`,
 * but for the Server platform.
 * @see {@link TestConfigModule}
 *
 * - It uses the cookie from the REQUEST object (but not from `document.cookie`).
 * - The `TestConfigModule` must be imported in the app module anyway.
 *
 * CAUTION: DON'T USE IT IN PRODUCTION! IT HASN'T BEEN REVIEWED FOR SECURITY ISSUES.
 */
class TestConfigServerModule {
    static forRoot() {
        return {
            ngModule: TestConfigServerModule,
            providers: [
                {
                    provide: TEST_CONFIG,
                    useFactory: () => {
                        const cookieName = inject(TEST_CONFIG_COOKIE_NAME);
                        const request = inject(REQUEST, { optional: true });
                        if (request && cookieName) {
                            const cookie = request.get('Cookie') ?? '';
                            const config = getCookie(cookie, cookieName);
                            return parseConfigJSON(config);
                        }
                        return {};
                    },
                },
            ],
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: TestConfigServerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: TestConfigServerModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: TestConfigServerModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: TestConfigServerModule, decorators: [{
            type: NgModule,
            args: [{}]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CxCommonEngine, DefaultCacheEntrySizeCalculator, DefaultExpressServerLogger, EXPRESS_SERVER_LOGGER, ExpressLoggerService, NgExpressEngineDecorator, OptimizedSsrEngine, PROPAGATE_ERROR_TO_SERVER, PrerenderingLoggerService, PropagatingToServerErrorHandler, REQUEST, RESPONSE, RenderingCache, RenderingCacheSizeManager, RenderingStrategy, TestConfigServerModule, defaultExpressErrorHandlers, defaultRenderingStrategyResolver, defaultRenderingStrategyResolverOptions, defaultSsrOptimizationOptions, getDefaultRenderKey, getLoggerInspectOptions, getRequestContext, getServerRequestProviders, ngExpressEngine, provideServer, serverLoggerServiceFactory };
//# sourceMappingURL=spartacus-setup-ssr.mjs.map
