import { OccConfig } from '@spartacus/core';

declare const defaultB2bOccConfig: OccConfig;

export { defaultB2bOccConfig };
