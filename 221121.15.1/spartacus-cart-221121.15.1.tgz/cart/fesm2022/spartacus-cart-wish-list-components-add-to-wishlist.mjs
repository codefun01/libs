import { NgIf, AsyncPipe, CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { ViewChild, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { RouterLink, RouterModule } from '@angular/router';
import * as i3 from '@spartacus/core';
import { isNotNullable, useFeatureStyles, FeatureDirective, TranslatePipe, UrlPipe, I18nModule, UrlModule, FeaturesConfigModule, provideDefaultConfig } from '@spartacus/core';
import * as i2 from '@spartacus/storefront';
import { ICON_TYPE, AtMessageDirective, IconComponent, BtnLikeLinkDirective, IconModule, AtMessageModule, BtnLikeLinkModule } from '@spartacus/storefront';
import { filter, tap, map, take } from 'rxjs/operators';
import * as i1 from '@spartacus/cart/wish-list/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AddToWishListComponent {
    constructor(wishListFacade, currentProductService, authService) {
        this.wishListFacade = wishListFacade;
        this.currentProductService = currentProductService;
        this.authService = authService;
        this.product$ = this.currentProductService.getProduct().pipe(filter(isNotNullable), tap((product) => this.setStockInfo(product)));
        this.userLoggedIn$ = this.authService.isUserLoggedIn().pipe(tap((isLogin) => {
            if (isLogin) {
                this.wishListEntries$ = this.getWishListEntries();
                this.loading$ = this.wishListFacade.getWishListLoading();
            }
        }));
        this.hasStock = false;
        this.iconTypes = ICON_TYPE;
        useFeatureStyles('a11yAddToWishListBtnMargin');
    }
    add(product) {
        if (product.code) {
            this.wishListFacade.addEntry(product.code);
            this.restoreFocus();
        }
    }
    remove(entry) {
        this.wishListFacade.removeEntry(entry);
        this.restoreFocus();
    }
    getProductInWishList(product, entries) {
        const item = entries.find((entry) => entry.product?.code === product.code);
        return item;
    }
    setStockInfo(product) {
        this.hasStock = Boolean(product.stock && product.stock.stockLevelStatus !== 'outOfStock');
    }
    getWishListEntries() {
        return this.wishListFacade.getWishList().pipe(filter((wishlist) => Boolean(wishlist)), map((wishList) => wishList.entries ?? []));
    }
    /**
     * When disabling the button, the focus gets lost unexpecedly.
     * This method makes sure that it is restored after.
     */
    restoreFocus() {
        this.loading$
            .pipe(filter((isLoading) => !isLoading), take(1))
            .subscribe(() => {
            this.removeFromWishlistButton?.nativeElement.focus() ||
                this.addToWishlistButton?.nativeElement.focus();
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AddToWishListComponent, deps: [{ token: i1.WishListFacade }, { token: i2.CurrentProductService }, { token: i3.AuthService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: AddToWishListComponent, isStandalone: true, selector: "cx-add-to-wishlist", viewQueries: [{ propertyName: "addToWishlistButton", first: true, predicate: ["addToWishlistButton"], descendants: true }, { propertyName: "removeFromWishlistButton", first: true, predicate: ["removeFromWishlistButton"], descendants: true }], ngImport: i0, template: "<ng-container *ngIf=\"product$ | async as product\">\n  <ng-container *ngIf=\"userLoggedIn$ | async; else loginPrompt\">\n    <ng-container *ngIf=\"wishListEntries$ | async as entries\">\n      <ng-container *ngIf=\"hasStock\">\n        <!-- TODO: (CXSPA-7603) - Remove feature flag next major release. -->\n        <ng-container *cxFeature=\"'a11yLinkBtnsToTertiaryBtns'\">\n          <div\n            *ngIf=\"\n              getProductInWishList(product, entries) as entry;\n              else addItem\n            \"\n          >\n            <button\n              #removeFromWishlistButton\n              class=\"btn btn-tertiary button-remove\"\n              (click)=\"remove(entry)\"\n              [disabled]=\"loading$ | async\"\n              [cxAtMessage]=\"'addToWishList.removedFromWishList' | cxTranslate\"\n            >\n              <cx-icon aria-hidden=\"true\" [type]=\"iconTypes.HEART\"></cx-icon>\n              <span class=\"button-text\">{{\n                'addToWishList.remove' | cxTranslate\n              }}</span>\n            </button>\n          </div>\n          <ng-template #addItem>\n            <button\n              #addToWishlistButton\n              class=\"btn btn-tertiary button-add\"\n              (click)=\"add(product)\"\n              [disabled]=\"loading$ | async\"\n              [cxAtMessage]=\"'addToWishList.addedToWishList' | cxTranslate\"\n            >\n              <cx-icon\n                aria-hidden=\"true\"\n                [type]=\"iconTypes.EMPTY_HEART\"\n              ></cx-icon>\n              <span class=\"button-text\">{{\n                'addToWishList.add' | cxTranslate\n              }}</span>\n            </button>\n          </ng-template>\n        </ng-container>\n        <ng-container *cxFeature=\"'!a11yLinkBtnsToTertiaryBtns'\"\n          ><div\n            *ngIf=\"\n              getProductInWishList(product, entries) as entry;\n              else addItem\n            \"\n          >\n            <button\n              class=\"btn btn-link button-remove cx-action-link\"\n              (click)=\"remove(entry)\"\n              [disabled]=\"loading$ | async\"\n              [cxAtMessage]=\"'addToWishList.removedFromWishList' | cxTranslate\"\n            >\n              <cx-icon aria-hidden=\"true\" [type]=\"iconTypes.HEART\"></cx-icon>\n              <span class=\"button-text\">{{\n                'addToWishList.remove' | cxTranslate\n              }}</span>\n            </button>\n          </div>\n          <ng-template #addItem>\n            <button\n              class=\"btn btn-link button-add cx-action-link\"\n              (click)=\"add(product)\"\n              [disabled]=\"loading$ | async\"\n              [cxAtMessage]=\"'addToWishList.addedToWishList' | cxTranslate\"\n            >\n              <cx-icon\n                aria-hidden=\"true\"\n                [type]=\"iconTypes.EMPTY_HEART\"\n              ></cx-icon>\n              <span class=\"button-text\">{{\n                'addToWishList.add' | cxTranslate\n              }}</span>\n            </button>\n          </ng-template>\n        </ng-container>\n      </ng-container>\n    </ng-container>\n  </ng-container>\n</ng-container>\n\n<ng-template #loginPrompt>\n  <ng-container *ngIf=\"hasStock\">\n    <a\n      class=\"btn btn-link button-add-link cx-action-link\"\n      [routerLink]=\"{ cxRoute: 'login' } | cxUrl\"\n      cxBtnLikeLink\n    >\n      <cx-icon aria-hidden=\"true\" [type]=\"iconTypes.EMPTY_HEART\"></cx-icon>\n      <span class=\"button-text\">{{\n        'addToWishList.anonymous' | cxTranslate\n      }}</span>\n    </a>\n  </ng-container>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: AtMessageDirective, selector: "[cxAtMessage]", inputs: ["cxAtMessage"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "directive", type: BtnLikeLinkDirective, selector: "a[cxBtnLikeLink].btn" }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: FeatureDirective, selector: "[cxFeature]", inputs: ["cxFeature"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AddToWishListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-add-to-wishlist', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        AtMessageDirective,
                        IconComponent,
                        BtnLikeLinkDirective,
                        RouterLink,
                        AsyncPipe,
                        TranslatePipe,
                        UrlPipe,
                        FeatureDirective,
                    ], template: "<ng-container *ngIf=\"product$ | async as product\">\n  <ng-container *ngIf=\"userLoggedIn$ | async; else loginPrompt\">\n    <ng-container *ngIf=\"wishListEntries$ | async as entries\">\n      <ng-container *ngIf=\"hasStock\">\n        <!-- TODO: (CXSPA-7603) - Remove feature flag next major release. -->\n        <ng-container *cxFeature=\"'a11yLinkBtnsToTertiaryBtns'\">\n          <div\n            *ngIf=\"\n              getProductInWishList(product, entries) as entry;\n              else addItem\n            \"\n          >\n            <button\n              #removeFromWishlistButton\n              class=\"btn btn-tertiary button-remove\"\n              (click)=\"remove(entry)\"\n              [disabled]=\"loading$ | async\"\n              [cxAtMessage]=\"'addToWishList.removedFromWishList' | cxTranslate\"\n            >\n              <cx-icon aria-hidden=\"true\" [type]=\"iconTypes.HEART\"></cx-icon>\n              <span class=\"button-text\">{{\n                'addToWishList.remove' | cxTranslate\n              }}</span>\n            </button>\n          </div>\n          <ng-template #addItem>\n            <button\n              #addToWishlistButton\n              class=\"btn btn-tertiary button-add\"\n              (click)=\"add(product)\"\n              [disabled]=\"loading$ | async\"\n              [cxAtMessage]=\"'addToWishList.addedToWishList' | cxTranslate\"\n            >\n              <cx-icon\n                aria-hidden=\"true\"\n                [type]=\"iconTypes.EMPTY_HEART\"\n              ></cx-icon>\n              <span class=\"button-text\">{{\n                'addToWishList.add' | cxTranslate\n              }}</span>\n            </button>\n          </ng-template>\n        </ng-container>\n        <ng-container *cxFeature=\"'!a11yLinkBtnsToTertiaryBtns'\"\n          ><div\n            *ngIf=\"\n              getProductInWishList(product, entries) as entry;\n              else addItem\n            \"\n          >\n            <button\n              class=\"btn btn-link button-remove cx-action-link\"\n              (click)=\"remove(entry)\"\n              [disabled]=\"loading$ | async\"\n              [cxAtMessage]=\"'addToWishList.removedFromWishList' | cxTranslate\"\n            >\n              <cx-icon aria-hidden=\"true\" [type]=\"iconTypes.HEART\"></cx-icon>\n              <span class=\"button-text\">{{\n                'addToWishList.remove' | cxTranslate\n              }}</span>\n            </button>\n          </div>\n          <ng-template #addItem>\n            <button\n              class=\"btn btn-link button-add cx-action-link\"\n              (click)=\"add(product)\"\n              [disabled]=\"loading$ | async\"\n              [cxAtMessage]=\"'addToWishList.addedToWishList' | cxTranslate\"\n            >\n              <cx-icon\n                aria-hidden=\"true\"\n                [type]=\"iconTypes.EMPTY_HEART\"\n              ></cx-icon>\n              <span class=\"button-text\">{{\n                'addToWishList.add' | cxTranslate\n              }}</span>\n            </button>\n          </ng-template>\n        </ng-container>\n      </ng-container>\n    </ng-container>\n  </ng-container>\n</ng-container>\n\n<ng-template #loginPrompt>\n  <ng-container *ngIf=\"hasStock\">\n    <a\n      class=\"btn btn-link button-add-link cx-action-link\"\n      [routerLink]=\"{ cxRoute: 'login' } | cxUrl\"\n      cxBtnLikeLink\n    >\n      <cx-icon aria-hidden=\"true\" [type]=\"iconTypes.EMPTY_HEART\"></cx-icon>\n      <span class=\"button-text\">{{\n        'addToWishList.anonymous' | cxTranslate\n      }}</span>\n    </a>\n  </ng-container>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1.WishListFacade }, { type: i2.CurrentProductService }, { type: i3.AuthService }], propDecorators: { addToWishlistButton: [{
                type: ViewChild,
                args: ['addToWishlistButton']
            }], removeFromWishlistButton: [{
                type: ViewChild,
                args: ['removeFromWishlistButton']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AddToWishListModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AddToWishListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: AddToWishListModule, imports: [CommonModule,
            I18nModule,
            IconModule,
            RouterModule,
            UrlModule,
            AtMessageModule,
            FeaturesConfigModule,
            BtnLikeLinkModule,
            AddToWishListComponent], exports: [AddToWishListComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AddToWishListModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    AddToWishListComponent: {
                        component: AddToWishListComponent,
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            IconModule,
            RouterModule,
            UrlModule,
            AtMessageModule,
            FeaturesConfigModule,
            BtnLikeLinkModule,
            AddToWishListComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AddToWishListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        IconModule,
                        RouterModule,
                        UrlModule,
                        AtMessageModule,
                        FeaturesConfigModule,
                        BtnLikeLinkModule,
                        AddToWishListComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                AddToWishListComponent: {
                                    component: AddToWishListComponent,
                                },
                            },
                        }),
                    ],
                    exports: [AddToWishListComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AddToWishListComponent, AddToWishListModule };
//# sourceMappingURL=spartacus-cart-wish-list-components-add-to-wishlist.mjs.map
