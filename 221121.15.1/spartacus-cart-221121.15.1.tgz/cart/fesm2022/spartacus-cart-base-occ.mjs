import * as i0 from '@angular/core';
import { Injectable, inject, NgModule } from '@angular/core';
import { ORDER_ENTRY_PROMOTIONS_NORMALIZER, CART_MODIFICATION_NORMALIZER, CART_VOUCHER_NORMALIZER, CART_NORMALIZER } from '@spartacus/cart/base/root';
import * as i2 from '@spartacus/core';
import { PRODUCT_NORMALIZER, LoggerService, OccEndpointsService, ConverterService, tryNormalizeHttpError, backOff, isServerError, InterceptorUtil, USE_CLIENT_TOKEN, FeatureToggles, OCC_USER_ID_ANONYMOUS, OCC_CART_ID_CURRENT, provideDefaultConfigFactory } from '@spartacus/core';
import * as i1 from '@angular/common/http';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { CART_ACCESS_CODE_NORMALIZER, CART_GUEST_USER_NORMALIZER, CART_VALIDATION_NORMALIZER, CartAdapter, CartEntryAdapter, CartVoucherAdapter, CartValidationAdapter, CartAccessCodeAdapter, CartGuestUserAdapter } from '@spartacus/cart/base/core';
import { catchError } from 'rxjs';
import { catchError as catchError$1, map } from 'rxjs/operators';
import { CommonModule } from '@angular/common';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccCartNormalizer {
    constructor(converter) {
        this.converter = converter;
    }
    convert(source, target) {
        if (target === undefined) {
            target = { ...source };
        }
        this.removeDuplicatePromotions(source, target);
        this.handleQuoteCode(source, target);
        if (source.entries) {
            target.entries = source.entries.map((entry) => ({
                ...entry,
                product: this.converter.convert(entry.product, PRODUCT_NORMALIZER),
                promotions: this.converter.convert({ item: entry, promotions: target?.appliedProductPromotions }, ORDER_ENTRY_PROMOTIONS_NORMALIZER),
            }));
        }
        return target;
    }
    handleQuoteCode(source, target) {
        if (source.sapQuote) {
            target.quoteCode = source.sapQuote.code;
            target.quotePurchaseOrderNumber = source.sapQuote.sapPurchaseOrderNumber;
        }
    }
    /**
     * Remove all duplicate promotions
     */
    removeDuplicatePromotions(source, target) {
        if (source && source.potentialOrderPromotions) {
            target.potentialOrderPromotions = this.removeDuplicateItems(source.potentialOrderPromotions);
        }
        if (source && source.potentialProductPromotions) {
            target.potentialProductPromotions = this.removeDuplicateItems(source.potentialProductPromotions);
        }
        if (source && source.appliedOrderPromotions) {
            target.appliedOrderPromotions = this.removeDuplicateItems(source.appliedOrderPromotions);
        }
        if (source && source.appliedProductPromotions) {
            target.appliedProductPromotions = this.removeDuplicateItems(source.appliedProductPromotions);
        }
    }
    removeDuplicateItems(itemList) {
        return itemList.filter((p, i, a) => {
            const b = a.map((el) => JSON.stringify(el));
            return i === b.indexOf(JSON.stringify(p));
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartNormalizer, deps: [{ token: i2.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartNormalizer, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartNormalizer, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i2.ConverterService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OrderEntryPromotionsNormalizer {
    convert(source, target) {
        target = this.getProductPromotion(source.item, source.promotions);
        return target;
    }
    /**
     * Get consumed promotions for the given order entry
     *
     * @param item
     * @param promotions
     * @returns consumed promotions for this entry
     */
    getProductPromotion(item, promotions) {
        const entryPromotions = [];
        promotions?.forEach((promotion) => {
            if (promotion.description && promotion.consumedEntries) {
                for (const consumedEntry of promotion.consumedEntries) {
                    if (this.isConsumedByEntry(consumedEntry, item)) {
                        entryPromotions.push(promotion);
                    }
                }
            }
        });
        return entryPromotions;
    }
    isConsumedByEntry(consumedEntry, entry) {
        const consumedEntryNumber = consumedEntry.orderEntryNumber;
        if (entry && entry.entries && entry.entries.length > 0) {
            for (const subEntry of entry.entries) {
                if (subEntry.entryNumber === consumedEntryNumber) {
                    return true;
                }
            }
            return false;
        }
        else {
            return consumedEntryNumber === entry?.entryNumber;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OrderEntryPromotionsNormalizer, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OrderEntryPromotionsNormalizer, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OrderEntryPromotionsNormalizer, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccCartAccessCodeAdapter {
    constructor() {
        this.logger = inject(LoggerService);
        this.http = inject(HttpClient);
        this.occEndpointsService = inject(OccEndpointsService);
        this.converterService = inject(ConverterService);
    }
    getCartAccessCode(userId, cartId) {
        return this.http
            .post(this.getCartAccessCodeEndpoint(userId, cartId), null)
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({
            shouldRetry: isServerError,
            maxTries: 2,
        }), this.converterService.pipeable(CART_ACCESS_CODE_NORMALIZER));
    }
    getCartAccessCodeEndpoint(userId, cartId) {
        return this.occEndpointsService.buildUrl('cartAccessCode', {
            urlParams: {
                userId,
                cartId,
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartAccessCodeAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartAccessCodeAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartAccessCodeAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccCartEntryAdapter {
    constructor(http, occEndpointsService, converterService) {
        this.http = http;
        this.occEndpointsService = occEndpointsService;
        this.converterService = converterService;
    }
    add(userId, cartId, productCode, quantity = 1, pickupStore) {
        const url = this.occEndpointsService.buildUrl('addEntries', {
            urlParams: { userId, cartId, quantity },
        });
        // Handle b2b case where the x-www-form-urlencoded is still used
        if (url.includes(`quantity=${quantity}`)) {
            const httpHeaders = new HttpHeaders({
                'Content-Type': 'application/x-www-form-urlencoded',
            });
            return this.http
                .post(url, {}, { headers: httpHeaders, params: { code: productCode } })
                .pipe(this.converterService.pipeable(CART_MODIFICATION_NORMALIZER));
        }
        const toAdd = {
            quantity,
            product: { code: productCode },
            ...(pickupStore && { deliveryPointOfService: { name: pickupStore } }),
        };
        const headers = new HttpHeaders({
            'Content-Type': 'application/json',
        });
        return this.http
            .post(url, toAdd, { headers })
            .pipe(this.converterService.pipeable(CART_MODIFICATION_NORMALIZER));
    }
    update(userId, cartId, entryNumber, qty, pickupStore, pickupToDelivery = false) {
        const headers = new HttpHeaders({
            'Content-Type': 'application/json',
        });
        const url = this.occEndpointsService.buildUrl('updateEntries', {
            urlParams: {
                userId,
                cartId,
                entryNumber,
            },
        });
        // switch from pickup to delivery mode
        if (pickupStore === undefined && pickupToDelivery) {
            return this.http
                .put(url, { quantity: qty }, { headers })
                .pipe(this.converterService.pipeable(CART_MODIFICATION_NORMALIZER));
        }
        let params = {};
        if (pickupStore) {
            params = {
                deliveryPointOfService: {
                    name: pickupStore,
                },
            };
        }
        return this.http
            .patch(url, { quantity: qty, ...params }, { headers })
            .pipe(this.converterService.pipeable(CART_MODIFICATION_NORMALIZER));
    }
    remove(userId, cartId, entryNumber) {
        const headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded',
        });
        const url = this.occEndpointsService.buildUrl('removeEntries', {
            urlParams: {
                userId,
                cartId,
                entryNumber,
            },
        });
        return this.http.delete(url, { headers });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartEntryAdapter, deps: [{ token: i1.HttpClient }, { token: i2.OccEndpointsService }, { token: i2.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartEntryAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartEntryAdapter, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: i2.OccEndpointsService }, { type: i2.ConverterService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const CONTENT_TYPE_JSON_HEADER = { 'Content-Type': 'application/json' };
class OccCartGuestUserAdapter {
    constructor() {
        this.logger = inject(LoggerService);
        this.http = inject(HttpClient);
        this.occEndpointsService = inject(OccEndpointsService);
        this.converterService = inject(ConverterService);
    }
    getRequestHeaders() {
        return InterceptorUtil.createHeader(USE_CLIENT_TOKEN, true, new HttpHeaders({
            ...CONTENT_TYPE_JSON_HEADER,
        }));
    }
    createCartGuestUser(userId, cartId, guestUserDetails) {
        return this.http
            .post(this.getCartGuestUserEndpoint(userId, cartId), guestUserDetails, { headers: this.getRequestHeaders() })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({
            shouldRetry: isServerError,
            maxTries: 2,
        }), this.converterService.pipeable(CART_GUEST_USER_NORMALIZER));
    }
    updateCartGuestUser(userId, cartId, guestUserDetails) {
        return this.http
            .patch(this.getCartGuestUserEndpoint(userId, cartId), guestUserDetails, { headers: this.getRequestHeaders() })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({
            shouldRetry: isServerError,
            maxTries: 2,
        }), this.converterService.pipeable(CART_GUEST_USER_NORMALIZER));
    }
    getCartGuestUserEndpoint(userId, cartId) {
        return this.occEndpointsService.buildUrl('cartGuestUser', {
            urlParams: {
                userId,
                cartId,
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartGuestUserAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartGuestUserAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartGuestUserAdapter, decorators: [{
            type: Injectable
        }] });

class OccCartValidationAdapter {
    constructor(http, occEndpoints, converter) {
        this.http = http;
        this.occEndpoints = occEndpoints;
        this.converter = converter;
        this.logger = inject(LoggerService);
    }
    validate(cartId, userId) {
        const url = this.occEndpoints.buildUrl('validate', {
            urlParams: { cartId, userId },
        });
        return this.http.post(url, null).pipe(catchError$1((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), this.converter.pipeable(CART_VALIDATION_NORMALIZER));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartValidationAdapter, deps: [{ token: i1.HttpClient }, { token: i2.OccEndpointsService }, { token: i2.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartValidationAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartValidationAdapter, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: i2.OccEndpointsService }, { type: i2.ConverterService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccCartVoucherAdapter {
    constructor(http, occEndpoints, converter) {
        this.http = http;
        this.occEndpoints = occEndpoints;
        this.converter = converter;
        this.logger = inject(LoggerService);
        this.featureToggles = inject(FeatureToggles);
    }
    getCartVoucherEndpoint(userId, cartId) {
        return this.occEndpoints.buildUrl('cartVoucher', {
            urlParams: { userId, cartId },
        });
    }
    getRemoveCartVoucherEndpoint(userId, cartId) {
        return this.occEndpoints.buildUrl('cartRemoveVoucher', {
            urlParams: { userId, cartId },
        });
    }
    getHeaders(userId) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/json',
        });
        if (userId === OCC_USER_ID_ANONYMOUS) {
            headers = InterceptorUtil.createHeader(USE_CLIENT_TOKEN, true, headers);
        }
        return headers;
    }
    add(userId, cartId, voucherId) {
        const url = this.getCartVoucherEndpoint(userId, cartId);
        const toAdd = JSON.stringify({});
        const params = new HttpParams().set('voucherId', voucherId);
        const headers = this.getHeaders(userId);
        return this.http.post(url, toAdd, { headers, params }).pipe(catchError$1((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), this.converter.pipeable(CART_VOUCHER_NORMALIZER));
    }
    remove(userId, cartId, voucherId) {
        const headers = this.getHeaders(userId);
        if (this.featureToggles.enableRemoveVoucherEndpoint) {
            const removeVoucherUrl = this.getRemoveCartVoucherEndpoint(userId, cartId);
            const body = { voucherId };
            return this.http.post(removeVoucherUrl, body, { headers }).pipe(catchError$1((error) => {
                throw tryNormalizeHttpError(error, this.logger);
            }));
        }
        const url = this.getCartVoucherEndpoint(userId, cartId) +
            '/' +
            encodeURIComponent(voucherId);
        return this.http.delete(url, { headers }).pipe(catchError$1((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartVoucherAdapter, deps: [{ token: i1.HttpClient }, { token: i2.OccEndpointsService }, { token: i2.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartVoucherAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartVoucherAdapter, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: i2.OccEndpointsService }, { type: i2.ConverterService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccCartAdapter {
    constructor(http, occEndpointsService, converterService) {
        this.http = http;
        this.occEndpointsService = occEndpointsService;
        this.converterService = converterService;
    }
    loadAll(userId) {
        return this.http
            .get(this.occEndpointsService.buildUrl('carts', { urlParams: { userId } }))
            .pipe(map((cartList) => cartList.carts ?? []), this.converterService.pipeableMany(CART_NORMALIZER));
    }
    load(userId, cartId) {
        if (cartId === OCC_CART_ID_CURRENT) {
            return this.loadAll(userId).pipe(map((carts) => carts.find((cart) => cart['saveTime'] === undefined)));
        }
        else {
            return this.http
                .get(this.occEndpointsService.buildUrl('cart', {
                urlParams: { userId, cartId },
            }))
                .pipe(this.converterService.pipeable(CART_NORMALIZER));
        }
    }
    create(userId, oldCartId, toMergeCartGuid) {
        const toAdd = JSON.stringify({});
        const params = {};
        if (oldCartId) {
            params['oldCartId'] = oldCartId;
        }
        if (toMergeCartGuid) {
            params['toMergeCartGuid'] = toMergeCartGuid;
        }
        return this.http
            .post(this.occEndpointsService.buildUrl('createCart', {
            urlParams: { userId },
            queryParams: params,
        }), toAdd)
            .pipe(this.converterService.pipeable(CART_NORMALIZER));
    }
    delete(userId, cartId) {
        let headers = new HttpHeaders();
        if (userId === OCC_USER_ID_ANONYMOUS) {
            headers = InterceptorUtil.createHeader(USE_CLIENT_TOKEN, true, headers);
        }
        return this.http.delete(this.occEndpointsService.buildUrl('deleteCart', {
            urlParams: { userId, cartId },
        }), { headers });
    }
    save(userId, cartId, saveCartName, saveCartDescription) {
        const endpoint = this.occEndpointsService.buildUrl('saveCart', {
            urlParams: {
                userId,
                cartId,
                saveCartName,
                saveCartDescription,
            },
        });
        let httpParams = new HttpParams();
        httpParams = httpParams
            .set('saveCartName', saveCartName)
            .set('saveCartDescription', saveCartDescription);
        return this.http.patch(endpoint, httpParams).pipe(map((cartResponse) => cartResponse.savedCartData), this.converterService.pipeable(CART_NORMALIZER));
    }
    addEmail(userId, cartId, email) {
        let headers = new HttpHeaders({
            'Content-Type': 'application/x-www-form-urlencoded',
        });
        headers = InterceptorUtil.createHeader(USE_CLIENT_TOKEN, true, headers);
        const httpParams = new HttpParams().set('email', email);
        const url = this.occEndpointsService.buildUrl('addEmail', {
            urlParams: {
                userId,
                cartId,
            },
        });
        return this.http.put(url, httpParams, { headers });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartAdapter, deps: [{ token: i1.HttpClient }, { token: i2.OccEndpointsService }, { token: i2.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccCartAdapter, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: i2.OccEndpointsService }, { type: i2.ConverterService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
function defaultOccCartConfigFactory() {
    return {
        backend: {
            occ: {
                endpoints: {
                    /* eslint-disable max-len */
                    carts: 'users/${userId}/carts?fields=carts(DEFAULT,potentialProductPromotions,appliedProductPromotions,potentialOrderPromotions,appliedOrderPromotions,entries(totalPrice(formattedValue),product(images(FULL),stock(FULL)),basePrice(formattedValue,value),updateable),totalPrice(formattedValue),totalItems,totalPriceWithTax(formattedValue),totalDiscounts(value,formattedValue),subTotal(formattedValue),totalUnitCount,deliveryItemsQuantity,deliveryCost(formattedValue),totalTax(formattedValue, value),pickupItemsQuantity,net,appliedVouchers,productDiscounts(formattedValue),user,saveTime,name,description)',
                    cart: 'users/${userId}/carts/${cartId}?fields=DEFAULT,potentialProductPromotions,appliedProductPromotions,potentialOrderPromotions,appliedOrderPromotions,entries(totalPrice(formattedValue),product(images(FULL),stock(FULL)),basePrice(formattedValue,value),updateable),totalPrice(formattedValue),totalItems,totalPriceWithTax(formattedValue),totalDiscounts(value,formattedValue),subTotal(formattedValue),totalUnitCount,deliveryItemsQuantity,deliveryCost(formattedValue),totalTax(formattedValue, value),pickupItemsQuantity,net,appliedVouchers,productDiscounts(formattedValue),user,saveTime,name,description',
                    createCart: 'users/${userId}/carts?fields=DEFAULT,potentialProductPromotions,appliedProductPromotions,potentialOrderPromotions,appliedOrderPromotions,entries(totalPrice(formattedValue),product(images(FULL),stock(FULL)),basePrice(formattedValue,value),updateable),totalPrice(formattedValue),totalItems,totalPriceWithTax(formattedValue),totalDiscounts(value,formattedValue),subTotal(formattedValue),totalUnitCount,deliveryItemsQuantity,deliveryCost(formattedValue),totalTax(formattedValue, value),pickupItemsQuantity,net,appliedVouchers,productDiscounts(formattedValue),user',
                    addEntries: 'users/${userId}/carts/${cartId}/entries',
                    updateEntries: 'users/${userId}/carts/${cartId}/entries/${entryNumber}',
                    removeEntries: 'users/${userId}/carts/${cartId}/entries/${entryNumber}',
                    addEmail: 'users/${userId}/carts/${cartId}/email',
                    deleteCart: 'users/${userId}/carts/${cartId}',
                    cartVoucher: 'users/${userId}/carts/${cartId}/vouchers',
                    cartRemoveVoucher: 'users/${userId}/carts/${cartId}/removeVoucher',
                    saveCart: '/users/${userId}/carts/${cartId}/save',
                    validate: 'users/${userId}/carts/${cartId}/validate?fields=DEFAULT',
                    cartAccessCode: 'users/${userId}/carts/${cartId}/accessCode',
                    cartGuestUser: 'users/${userId}/carts/${cartId}/guestuser',
                    /* eslint-enable */
                },
            },
        },
    };
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CartBaseOccModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CartBaseOccModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CartBaseOccModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CartBaseOccModule, providers: [
            provideDefaultConfigFactory(defaultOccCartConfigFactory),
            {
                provide: CartAdapter,
                useClass: OccCartAdapter,
            },
            {
                provide: CART_NORMALIZER,
                useExisting: OccCartNormalizer,
                multi: true,
            },
            {
                provide: ORDER_ENTRY_PROMOTIONS_NORMALIZER,
                useExisting: OrderEntryPromotionsNormalizer,
                multi: true,
            },
            {
                provide: CartEntryAdapter,
                useClass: OccCartEntryAdapter,
            },
            {
                provide: CartVoucherAdapter,
                useClass: OccCartVoucherAdapter,
            },
            {
                provide: CartValidationAdapter,
                useClass: OccCartValidationAdapter,
            },
            {
                provide: CartAccessCodeAdapter,
                useClass: OccCartAccessCodeAdapter,
            },
            {
                provide: CartGuestUserAdapter,
                useClass: OccCartGuestUserAdapter,
            },
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CartBaseOccModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [
                        provideDefaultConfigFactory(defaultOccCartConfigFactory),
                        {
                            provide: CartAdapter,
                            useClass: OccCartAdapter,
                        },
                        {
                            provide: CART_NORMALIZER,
                            useExisting: OccCartNormalizer,
                            multi: true,
                        },
                        {
                            provide: ORDER_ENTRY_PROMOTIONS_NORMALIZER,
                            useExisting: OrderEntryPromotionsNormalizer,
                            multi: true,
                        },
                        {
                            provide: CartEntryAdapter,
                            useClass: OccCartEntryAdapter,
                        },
                        {
                            provide: CartVoucherAdapter,
                            useClass: OccCartVoucherAdapter,
                        },
                        {
                            provide: CartValidationAdapter,
                            useClass: OccCartValidationAdapter,
                        },
                        {
                            provide: CartAccessCodeAdapter,
                            useClass: OccCartAccessCodeAdapter,
                        },
                        {
                            provide: CartGuestUserAdapter,
                            useClass: OccCartGuestUserAdapter,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CartBaseOccModule, OccCartAccessCodeAdapter, OccCartAdapter, OccCartEntryAdapter, OccCartGuestUserAdapter, OccCartNormalizer, OccCartValidationAdapter, OccCartVoucherAdapter, OrderEntryPromotionsNormalizer };
//# sourceMappingURL=spartacus-cart-base-occ.mjs.map
