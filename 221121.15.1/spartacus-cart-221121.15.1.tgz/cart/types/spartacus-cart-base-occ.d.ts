import { Cart, PromotionResult, PromotionOrderEntryConsumed, CartModification, CartGuestUser, CartModificationList } from '@spartacus/cart/base/root';
import { Converter, Occ, ConverterService, LoggerService, OccEndpointsService, OccEndpoint } from '@spartacus/core';
import * as i0 from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CartAccessCodeAdapter, CartEntryAdapter, CartGuestUserAdapter, CartValidationAdapter, CartVoucherAdapter, CartAdapter } from '@spartacus/cart/base/core';
import { Observable } from 'rxjs';
import * as i1 from '@angular/common';

declare class OccCartNormalizer implements Converter<Occ.Cart, Cart> {
    private converter;
    constructor(converter: ConverterService);
    convert(source: Occ.Cart, target?: Cart): Cart;
    protected handleQuoteCode(source: Occ.Cart, target: Cart): void;
    /**
     * Remove all duplicate promotions
     */
    private removeDuplicatePromotions;
    private removeDuplicateItems;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCartNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCartNormalizer>;
}

declare class OrderEntryPromotionsNormalizer implements Converter<{
    item?: Occ.OrderEntry;
    promotions?: PromotionResult[];
}, PromotionResult[]> {
    convert(source: {
        item?: Occ.OrderEntry;
        promotions?: PromotionResult[];
    }, target?: PromotionResult[]): PromotionResult[];
    /**
     * Get consumed promotions for the given order entry
     *
     * @param item
     * @param promotions
     * @returns consumed promotions for this entry
     */
    getProductPromotion(item?: Occ.OrderEntry, promotions?: PromotionResult[]): PromotionResult[];
    protected isConsumedByEntry(consumedEntry: PromotionOrderEntryConsumed, entry: any): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderEntryPromotionsNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderEntryPromotionsNormalizer>;
}

declare class OccCartAccessCodeAdapter implements CartAccessCodeAdapter {
    protected logger: LoggerService;
    protected http: HttpClient;
    protected occEndpointsService: OccEndpointsService;
    protected converterService: ConverterService;
    getCartAccessCode(userId: string, cartId: string): Observable<string | undefined>;
    protected getCartAccessCodeEndpoint(userId: string, cartId: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCartAccessCodeAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCartAccessCodeAdapter>;
}

declare class OccCartEntryAdapter implements CartEntryAdapter {
    protected http: HttpClient;
    protected occEndpointsService: OccEndpointsService;
    protected converterService: ConverterService;
    constructor(http: HttpClient, occEndpointsService: OccEndpointsService, converterService: ConverterService);
    add(userId: string, cartId: string, productCode: string, quantity?: number, pickupStore?: string): Observable<CartModification>;
    update(userId: string, cartId: string, entryNumber: string, qty?: number, pickupStore?: string, pickupToDelivery?: boolean): Observable<CartModification>;
    remove(userId: string, cartId: string, entryNumber: string): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCartEntryAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCartEntryAdapter>;
}

declare class OccCartGuestUserAdapter implements CartGuestUserAdapter {
    protected logger: LoggerService;
    protected http: HttpClient;
    protected occEndpointsService: OccEndpointsService;
    protected converterService: ConverterService;
    protected getRequestHeaders(): HttpHeaders;
    createCartGuestUser(userId: string, cartId: string, guestUserDetails?: CartGuestUser): Observable<CartGuestUser>;
    updateCartGuestUser(userId: string, cartId: string, guestUserDetails: CartGuestUser): Observable<CartGuestUser>;
    protected getCartGuestUserEndpoint(userId: string, cartId: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCartGuestUserAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCartGuestUserAdapter>;
}

declare class OccCartValidationAdapter implements CartValidationAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    validate(cartId: string, userId: string): Observable<CartModificationList>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCartValidationAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCartValidationAdapter>;
}

declare class OccCartVoucherAdapter implements CartVoucherAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    private featureToggles;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    protected getCartVoucherEndpoint(userId: string, cartId: string): string;
    protected getRemoveCartVoucherEndpoint(userId: string, cartId: string): string;
    protected getHeaders(userId: string): HttpHeaders;
    add(userId: string, cartId: string, voucherId: string): Observable<{}>;
    remove(userId: string, cartId: string, voucherId: string): Observable<{}>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCartVoucherAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCartVoucherAdapter>;
}

declare class OccCartAdapter implements CartAdapter {
    protected http: HttpClient;
    protected occEndpointsService: OccEndpointsService;
    protected converterService: ConverterService;
    constructor(http: HttpClient, occEndpointsService: OccEndpointsService, converterService: ConverterService);
    loadAll(userId: string): Observable<Cart[]>;
    load(userId: string, cartId: string): Observable<Cart | undefined>;
    create(userId: string, oldCartId?: string, toMergeCartGuid?: string): Observable<Cart>;
    delete(userId: string, cartId: string): Observable<{}>;
    save(userId: string, cartId: string, saveCartName: string, saveCartDescription: string): Observable<Cart>;
    addEmail(userId: string, cartId: string, email: string): Observable<{}>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCartAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCartAdapter>;
}

declare class CartBaseOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CartBaseOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartBaseOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartBaseOccModule>;
}

interface CartOccEndpoints {
    /**
     * Get all carts
     *
     * @member {string} [carts]
     */
    carts?: string | OccEndpoint;
    /**
     * Get a cart with a given identifier
     *
     * @member {string} [cart]
     */
    cart?: string | OccEndpoint;
    /**
     * Creates or restore a cart for a user
     *
     * @member {string} [createCart]
     */
    createCart?: string | OccEndpoint;
    /**
     * Deletes a cart with a given cart id
     *
     * @member {string} [deleteCart]
     */
    deleteCart?: string | OccEndpoint;
    /**
     * Adds a product to the cart
     *
     * @member {string} [addEntries]
     */
    addEntries?: string | OccEndpoint;
    /**
     * Update quantity and store the details of a cart entry
     *
     * @member {string} [updateEntries]
     */
    updateEntries?: string | OccEndpoint;
    /**
     * Deletes cart entry
     *
     * @member {string} [removeEntries]
     */
    removeEntries?: string | OccEndpoint;
    /**
     * Assign email to cart
     *
     * @member {string} [addEmail]
     */
    addEmail?: string | OccEndpoint;
    /**
     * Explicitly saves a cart
     *
     * @member {string}
     */
    saveCart?: string | OccEndpoint;
    /**
     * Endpoint for cart voucher
     *
     * @member {string}
     */
    cartVoucher?: string | OccEndpoint;
    /**
     * Endpoint for removing cart voucher
     *
     * @member {string}
     */
    cartRemoveVoucher?: string | OccEndpoint;
    /**
     * Get cart validation results
     */
    validate?: string | OccEndpoint;
    /**
     * Generates an access code for a cart
     */
    cartAccessCode?: string | OccEndpoint;
    /**
     * Creates a guest user, and assigns the user to the cart
     */
    cartGuestUser?: string | OccEndpoint;
}
declare module '@spartacus/core' {
    interface OccEndpoints extends CartOccEndpoints {
    }
}

export { CartBaseOccModule, OccCartAccessCodeAdapter, OccCartAdapter, OccCartEntryAdapter, OccCartGuestUserAdapter, OccCartNormalizer, OccCartValidationAdapter, OccCartVoucherAdapter, OrderEntryPromotionsNormalizer };
export type { CartOccEndpoints };
