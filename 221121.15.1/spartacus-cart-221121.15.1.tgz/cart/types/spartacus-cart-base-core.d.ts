import * as i0 from '@angular/core';
import { OnDestroy, InjectionToken } from '@angular/core';
import * as i3 from '@ngrx/store';
import { ActionsSubject, Store, MetaReducer, Action, MemoizedSelector } from '@ngrx/store';
import { ActiveCartFacade, Cart, CartPageEvent, CartModification, CartGuestUser, CartModificationList, MultiCartFacade, OrderEntry, CartAccessCodeFacade, CartGuestUserFacade, CartValidationFacade, CartVoucherFacade, CartType, SelectiveCartFacade, CartConfig, ProductImportInfo } from '@spartacus/cart/base/root';
import * as i2 from '@spartacus/core';
import { EventService, StateEventService, ActionToEventMapping, StateUtils, StatePersistenceService, SiteContextParamsService, ConfigInitializerService, Config, Converter, UserIdService, WindowRef, User, QueryService, CommandService, Command, RoutingService, StateWithProcess, BaseSiteService, SemanticPathService, GlobalMessageService, ErrorAction, LoggerService, ErrorModel } from '@spartacus/core';
import { Observable, Subscription } from 'rxjs';
import * as i1 from '@angular/common';
import * as i4 from '@ngrx/effects';
import { UserProfileFacade } from '@spartacus/user/profile/root';
import { Router, GuardResult } from '@angular/router';

/**
 * Registers events for the active cart
 */
declare class CartEventBuilder {
    protected actionsSubject: ActionsSubject;
    protected event: EventService;
    protected activeCartService: ActiveCartFacade;
    protected stateEventService: StateEventService;
    constructor(actionsSubject: ActionsSubject, event: EventService, activeCartService: ActiveCartFacade, stateEventService: StateEventService);
    /**
     * Registers events for the active cart
     */
    protected register(): void;
    /**
     * Register events for adding entry to the active cart
     */
    protected registerAddEntry(): void;
    protected registerRemoveEntry(): void;
    protected registerUpdateEntry(): void;
    protected registerMergeCartSuccess(): void;
    protected registerCreateCart(): void;
    /**
     * Registers delete cart events
     */
    protected registerDeleteCart(): void;
    protected registerAddCartVoucher(): void;
    protected registerRemoveCartVoucher(): void;
    /**
     * Registers a stream of target events mapped from the source actions that contain the cart id equal to the active cart id.
     *
     * @param mapping mapping declaration - from `action` string type to `event` class type
     *   (an with optional `factory` function - by default `action.payload` will be assigned to the properties of the event instance).
     */
    protected registerMapped<T>(mapping: ActionToEventMapping<T>): () => void;
    /**
     * Returns a stream of actions only of a given type(s)
     *
     * @param actionType type(s) of actions
     */
    protected getAction(actionType: string | string[]): Observable<{
        type: string;
        payload?: any;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartEventBuilder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartEventBuilder>;
}

declare class CartEventModule {
    constructor(_CartEventBuilder: CartEventBuilder);
    static ɵfac: i0.ɵɵFactoryDeclaration<CartEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartEventModule>;
}

declare class MultiCartStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiCartStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MultiCartStoreModule, never, [typeof i1.CommonModule, typeof i2.StateModule, typeof i3.StoreFeatureModule, typeof i4.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MultiCartStoreModule>;
}

declare const MULTI_CART_FEATURE = "cart";
declare const MULTI_CART_DATA = "[Multi Cart] Multi Cart Data";
/**
 * Add voucher process const
 */
declare const ADD_VOUCHER_PROCESS_ID = "addVoucher";
interface StateWithMultiCart {
    [MULTI_CART_FEATURE]: MultiCartState;
}
interface MultiCartState {
    carts: StateUtils.EntityProcessesLoaderState<Cart | undefined>;
    index: {
        [cartType: string]: string;
    };
}

declare class MultiCartStatePersistenceService implements OnDestroy {
    protected statePersistenceService: StatePersistenceService;
    protected store: Store<StateWithMultiCart>;
    protected siteContextParamsService: SiteContextParamsService;
    protected subscription: Subscription;
    constructor(statePersistenceService: StatePersistenceService, store: Store<StateWithMultiCart>, siteContextParamsService: SiteContextParamsService);
    initSync(): void;
    protected getCartState(): Observable<{
        active: string;
    }>;
    protected onRead(state: {
        active: string;
    } | undefined): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiCartStatePersistenceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MultiCartStatePersistenceService>;
}

declare function cartStatePersistenceFactory(cartStatePersistenceService: MultiCartStatePersistenceService, configInit: ConfigInitializerService): () => Promise<Config>;
/**
 * Before `MultiCartStatePersistenceService` restores the active cart id `ActiveCartService`
 * will use `current` cart instead of the one saved in browser. This meta reducer
 * sets the value on store initialization to undefined cart which holds active cart loading
 * until the data from storage is restored.
 */
declare function uninitializeActiveCartMetaReducerFactory(): MetaReducer<any>;
/**
 * Complimentary module for cart to store cart id in browser storage.
 * This makes it possible to work on the same anonymous cart even after page refresh.
 */
declare class CartPersistenceModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CartPersistenceModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartPersistenceModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartPersistenceModule>;
}

declare class CartPageEventBuilder {
    protected eventService: EventService;
    constructor(eventService: EventService);
    protected register(): void;
    protected buildCartPageEvent(): Observable<CartPageEvent>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartPageEventBuilder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartPageEventBuilder>;
}

declare class CartPageEventModule {
    constructor(_cartPageEventBuilder: CartPageEventBuilder);
    static ɵfac: i0.ɵɵFactoryDeclaration<CartPageEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartPageEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartPageEventModule>;
}

declare class CartBaseCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CartBaseCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartBaseCoreModule, never, [typeof CartEventModule, typeof MultiCartStoreModule, typeof CartPersistenceModule, typeof CartPageEventModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartBaseCoreModule>;
}

declare abstract class CartAccessCodeAdapter {
    /**
     * Abstract method used to generate access code for a specific cart id.
     *
     * @param {string} userId
     * @param {string} cartId
     *
     */
    abstract getCartAccessCode(userId: string, cartId: string): Observable<string | undefined>;
}

declare class CartAccessCodeConnector {
    protected adapter: CartAccessCodeAdapter;
    getCartAccessCode(userId: string, cartId: string): Observable<string | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartAccessCodeConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartAccessCodeConnector>;
}

declare const CART_ACCESS_CODE_NORMALIZER: InjectionToken<Converter<any, string>>;

declare abstract class CartAdapter {
    /**
     * Abstract method used to load all carts
     *
     * @param userId
     */
    abstract loadAll(userId: string): Observable<Cart[]>;
    /**
     * Abstract method used to load cart
     *
     * @param userId
     * @param cartId
     */
    abstract load(userId: string, cartId: string): Observable<Cart | undefined>;
    /**
     * Abstract method used to create cart. If toMergeCartGuid is specified, cart will be merged with existing one
     *
     * @param userId
     * @param oldCartId
     * @param toMergeCartGuid
     */
    abstract create(userId: string, oldCartId?: string, toMergeCartGuid?: string): Observable<Cart>;
    /**
     * Abstract method used to delete cart
     *
     * @param userId
     * @param cartId
     */
    abstract delete(userId: string, cartId: string): Observable<{}>;
    /**
     *
     * Abstract method used to save a cart or update a saved cart
     */
    abstract save(userId: string, cartId: string, saveCartName?: string, saveCartDescription?: string): Observable<Cart>;
    /**
     * Abstract method to assign an email to the cart. This step is required to make a guest checkout
     * @param userId
     * @param cartId
     * @param email
     */
    abstract addEmail(userId: string, cartId: string, email: string): Observable<{}>;
}

declare class CartConnector {
    protected adapter: CartAdapter;
    constructor(adapter: CartAdapter);
    loadAll(userId: string): Observable<Cart[]>;
    load(userId: string, cartId: string): Observable<Cart | undefined>;
    create(userId: string, oldCartId?: string, toMergeCartGuid?: string): Observable<Cart>;
    delete(userId: string, cartId: string): Observable<{}>;
    save(userId: string, cartId: string, saveCartName?: string, saveCartDescription?: string): Observable<Cart>;
    addEmail(userId: string, cartId: string, email: string): Observable<{}>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartConnector>;
}

declare abstract class CartEntryAdapter {
    /**
     * Abstract method used to add entry to cart
     *
     * @param userId
     * @param cartId
     * @param productCode
     * @param quantity
     * @param pickupStore
     */
    abstract add(userId: string, cartId: string, productCode: string, quantity?: number, pickupStore?: string): Observable<CartModification>;
    /**
     * Abstract method used to update entry in cart
     * @param userId
     * @param cartId
     * @param entryNumber
     * @param qty
     * @param pickupStore
     */
    abstract update(userId: string, cartId: string, entryNumber: string, qty?: number, pickupStore?: string, pickupToDelivery?: boolean): Observable<CartModification>;
    /**
     * Abstract method used to remove entry from cart
     *
     * @param userId
     * @param cartId
     * @param entryNumber
     */
    abstract remove(userId: string, cartId: string, entryNumber: string): Observable<any>;
}

declare class CartEntryConnector {
    protected adapter: CartEntryAdapter;
    constructor(adapter: CartEntryAdapter);
    add(userId: string, cartId: string, productCode: string, quantity?: number, pickupStore?: string): Observable<CartModification>;
    update(userId: string, cartId: string, entryNumber: string, qty?: number, pickupStore?: string, pickupToDelivery?: boolean): Observable<CartModification>;
    remove(userId: string, cartId: string, entryNumber: string): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartEntryConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartEntryConnector>;
}

declare abstract class CartGuestUserAdapter {
    /**
     * Abstract method used to create a guest user, and assigns the user to the cart.
     *
     * @param {string} userId
     * @param {string} cartId
     * @param {CartGuestUser} guestUserDetails
     *
     */
    abstract createCartGuestUser(userId: string, cartId: string, guestUserDetails?: CartGuestUser): Observable<CartGuestUser>;
    /**
     * Abstract method used to update a guest user, and assigns the user to the cart.
     *
     * @param {string} userId
     * @param {string} cartId
     * @param {CartGuestUser} guestUserDetails
     *
     */
    abstract updateCartGuestUser(userId: string, cartId: string, guestUserDetails: CartGuestUser): Observable<CartGuestUser>;
}

declare class CartGuestUserConnector {
    protected adapter: CartGuestUserAdapter;
    createCartGuestUser(userId: string, cartId: string, guestUserDetails?: CartGuestUser): Observable<CartGuestUser>;
    updateCartGuestUser(userId: string, cartId: string, guestUserDetails: CartGuestUser): Observable<CartGuestUser>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartGuestUserConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartGuestUserConnector>;
}

declare const CART_GUEST_USER_NORMALIZER: InjectionToken<Converter<any, CartGuestUser>>;

declare const CART_VALIDATION_NORMALIZER: InjectionToken<Converter<any, CartModificationList>>;

declare abstract class CartValidationAdapter {
    abstract validate(cartId: string, userId: string): Observable<CartModificationList>;
}

declare class CartValidationConnector {
    protected adapter: CartValidationAdapter;
    constructor(adapter: CartValidationAdapter);
    validate(cartId: string, userId: string): Observable<CartModificationList>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartValidationConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartValidationConnector>;
}

declare abstract class CartVoucherAdapter {
    /**
     * Abstract method used to apply voucher to cart
     *
     * @param userId
     * @param cartId
     * @param voucherId
     */
    abstract add(userId: string, cartId: string, voucherId: string): Observable<{}>;
    /**
     * Abstract method used to remove voucher from cart
     *
     * @param userId
     * @param cartId
     * @param voucherId
     */
    abstract remove(userId: string, cartId: string, voucherId: string): Observable<{}>;
}

declare class CartVoucherConnector {
    protected adapter: CartVoucherAdapter;
    constructor(adapter: CartVoucherAdapter);
    add(userId: string, cartId: string, voucherId: string): Observable<{}>;
    remove(userId: string, cartId: string, voucherId: string): Observable<{}>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartVoucherConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartVoucherConnector>;
}

declare class ActiveCartService implements ActiveCartFacade, OnDestroy {
    protected multiCartFacade: MultiCartFacade;
    protected userIdService: UserIdService;
    protected winRef: WindowRef;
    protected activeCart$: Observable<Cart>;
    protected subscription: Subscription;
    protected activeCartId$: Observable<string>;
    protected cartEntity$: Observable<StateUtils.ProcessesLoaderState<Cart | undefined>>;
    protected shouldLoadCartOnCodeFlow: boolean;
    constructor(multiCartFacade: MultiCartFacade, userIdService: UserIdService, winRef: WindowRef);
    protected initActiveCart(): void;
    protected detectUserChange(): void;
    /**
     * Returns active cart
     */
    getActive(): Observable<Cart>;
    /**
     * Waits for the cart to be stable before returning the active cart.
     */
    takeActive(): Observable<Cart>;
    /**
     * Returns active cart id
     */
    getActiveCartId(): Observable<string>;
    /**
     * Waits for the cart to be stable before returning the active cart's ID.
     */
    takeActiveCartId(): Observable<string>;
    /**
     * Returns cart entries
     */
    getEntries(): Observable<OrderEntry[]>;
    /**
     * Returns last cart entry for provided product code.
     * Needed to cover processes where multiple entries can share the same product code
     * (e.g. promotions or configurable products)
     *
     * @param productCode
     */
    getLastEntry(productCode: string): Observable<OrderEntry | undefined>;
    /**
     * Returns cart loading state
     */
    getLoading(): Observable<boolean>;
    /**
     * Returns true when cart is stable (not loading and not pending processes on cart)
     */
    isStable(): Observable<boolean>;
    /**
     * Loads cart in every case except anonymous user and current cart combination
     */
    protected load(cartId: string, userId: string): void;
    /**
     * Loads cart upon login, whenever there's an existing cart, merge it into the current user cart
     * cartId will be defined (not '', null, undefined)
     */
    protected loadOrMerge(cartId: string, userId: string, previousUserId: string): void;
    /**
     * Temporary method to merge guest cart with user cart because of backend limitation
     * This is for an edge case
     */
    protected guestCartMerge(cartId: string): void;
    /**
     * Adds entries from guest cart to user cart
     */
    protected addEntriesGuestMerge(cartEntries: OrderEntry[]): void;
    protected isCartCreating(cartState: StateUtils.ProcessesLoaderState<Cart | undefined>, cartId: string): boolean | undefined;
    /**
     * Check if user is just logged in with code flow
     */
    protected isLoggedInWithCodeFlow(): boolean;
    private checkInitLoad;
    requireLoadedCart(forGuestMerge?: boolean): Observable<Cart>;
    /**
     * Add entry to active cart
     *
     * @param productCode
     * @param quantity
     * @param pickupStore
     */
    addEntry(productCode: string, quantity: number, pickupStore?: string): void;
    /**
     * Remove entry
     *
     * @param entry
     */
    removeEntry(entry: OrderEntry): void;
    /**
     * Update entry
     *
     * @param entryNumber
     * @param quantity
     * @param pickupStore
     * @param pickupToDelivery
     */
    updateEntry(entryNumber: number, quantity?: number, pickupStore?: string, pickupToDelivery?: boolean): void;
    /**
     * Returns cart entry
     *
     * @param productCode
     */
    getEntry(productCode: string): Observable<OrderEntry | undefined>;
    /**
     * Assign email to cart
     *
     * @param email
     */
    addEmail(email: string): void;
    /**
     * Get assigned user to cart
     */
    getAssignedUser(): Observable<User>;
    /**
     * Returns observable of true for guest cart
     */
    isGuestCart(cart?: Cart): Observable<boolean>;
    protected isCartUserGuest(cart: Cart): boolean;
    /**
     * Add multiple entries to a cart
     *
     * @param cartEntries : list of entries to add (OrderEntry[])
     */
    addEntries(cartEntries: OrderEntry[]): void;
    /**
     * Reloads active cart
     */
    reloadActiveCart(): void;
    hasPickupItems(): Observable<boolean>;
    hasDeliveryItems(): Observable<boolean>;
    getPickupEntries(): Observable<OrderEntry[]>;
    getDeliveryEntries(): Observable<OrderEntry[]>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActiveCartService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ActiveCartService>;
}

declare class CartAccessCodeService implements CartAccessCodeFacade {
    protected queryService: QueryService;
    protected commandService: CommandService;
    protected cartAccessCodeConnector: CartAccessCodeConnector;
    protected getCartAccessCodeCommand: Command<{
        userId: string;
        cartId: string;
    }, string | undefined>;
    getCartAccessCode(userId: string, cartId: string): Observable<string | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartAccessCodeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartAccessCodeService>;
}

declare class CartGuestUserService implements CartGuestUserFacade {
    protected queryService: QueryService;
    protected commandService: CommandService;
    protected cartGuestUserConnector: CartGuestUserConnector;
    protected createCartGuestUserCommand: Command<{
        userId: string;
        cartId: string;
        guestUserDetails?: CartGuestUser;
    }, CartGuestUser>;
    protected updateCartGuestUserCommand: Command<{
        userId: string;
        cartId: string;
        guestUserDetails: CartGuestUser;
    }, CartGuestUser>;
    createCartGuestUser(userId: string, cartId: string, guestUserDetails?: CartGuestUser): Observable<CartGuestUser>;
    updateCartGuestUser(userId: string, cartId: string, guestUserDetails: CartGuestUser): Observable<CartGuestUser>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartGuestUserService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartGuestUserService>;
}

declare class CartValidationStateService implements OnDestroy {
    protected routingService: RoutingService;
    protected NAVIGATION_SKIPS: number;
    protected navigationIdCount: number;
    protected subscription: Subscription;
    cartValidationResult$: Observable<CartModification[]>;
    constructor(routingService: RoutingService);
    protected checkForValidationResultClear$: Observable<[i2.RouterState, CartModification[]]>;
    ngOnDestroy(): void;
    protected setInitialState(): void;
    updateValidationResultAndRoutingId(cartModification: CartModification[]): void;
    protected setNavigationIdStep(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartValidationStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartValidationStateService>;
}

declare class CartValidationService implements CartValidationFacade {
    protected cartValidationConnector: CartValidationConnector;
    protected command: CommandService;
    protected userIdService: UserIdService;
    protected activeCartFacade: ActiveCartFacade;
    protected cartValidationStateService: CartValidationStateService;
    protected validateCartCommand: Command<void, CartModificationList>;
    constructor(cartValidationConnector: CartValidationConnector, command: CommandService, userIdService: UserIdService, activeCartFacade: ActiveCartFacade, cartValidationStateService: CartValidationStateService);
    /**
     * Validates cart and returns cart modification list.
     */
    validateCart(): Observable<CartModificationList>;
    /**
     * Returns cart modification results
     */
    getValidationResults(): Observable<CartModification[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartValidationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartValidationService>;
}

declare class CartVoucherService implements CartVoucherFacade {
    protected store: Store<StateWithProcess<void>>;
    protected activeCartFacade: ActiveCartFacade;
    protected userIdService: UserIdService;
    constructor(store: Store<StateWithProcess<void>>, activeCartFacade: ActiveCartFacade, userIdService: UserIdService);
    addVoucher(voucherId: string, cartId?: string): void;
    removeVoucher(voucherId: string, cartId?: string): void;
    /**
     * Get add voucher process error flag
     */
    getAddVoucherResultError(): Observable<boolean>;
    /**
     * Get add voucher process success flag
     */
    getAddVoucherResultSuccess(): Observable<boolean>;
    /**
     * Get add voucher process loading flag
     */
    getAddVoucherResultLoading(): Observable<boolean>;
    /**
     * Reset add voucher process
     */
    resetAddVoucherProcessingState(): void;
    private combineUserAndCartId;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartVoucherService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartVoucherService>;
}

declare class MultiCartService implements MultiCartFacade {
    protected store: Store<StateWithMultiCart>;
    protected userIdService: UserIdService;
    private featureConfigService;
    protected windowRef: WindowRef;
    constructor(store: Store<StateWithMultiCart>, userIdService: UserIdService);
    /**
     * Returns cart from store as an observable
     *
     * @param cartId
     */
    getCart(cartId: string): Observable<Cart>;
    /**
     * Returns a list of carts from store as an observable
     *
     */
    getCarts(): Observable<Cart[]>;
    /**
     * Returns cart entity from store (cart with loading, error, success flags) as an observable
     *
     * @param cartId
     */
    getCartEntity(cartId: string): Observable<StateUtils.ProcessesLoaderState<Cart | undefined>>;
    /**
     * Returns true when there are no operations on that in progress and it is not currently loading
     *
     * @param cartId
     */
    isStable(cartId: string): Observable<boolean>;
    /**
     * Simple random temp cart id generator
     */
    protected generateTempCartId(): string;
    /**
     * Create or merge cart
     *
     * @param params Object with userId, oldCartId, toMergeCartGuid and extraData
     */
    createCart({ userId, oldCartId, toMergeCartGuid, extraData, }: {
        userId: string;
        oldCartId?: string;
        toMergeCartGuid?: string;
        extraData?: {
            active?: boolean;
        };
    }): Observable<Cart>;
    /**
     * Merge provided cart to current user cart
     *
     * @param params Object with userId, cartId and extraData
     */
    mergeToCurrentCart({ userId, cartId, extraData, }: {
        userId: string;
        cartId: string;
        extraData?: {
            active?: boolean;
        };
    }): void;
    /**
     * Load cart
     *
     * @param params Object with userId, cartId and extraData
     */
    loadCart({ cartId, userId, extraData, }: {
        cartId: string;
        userId: string;
        extraData?: any;
    }): void;
    /**
     * Get cart entries as an observable
     * @param cartId
     */
    getEntries(cartId: string): Observable<OrderEntry[]>;
    /**
     * Get last entry for specific product code from cart.
     * Needed to cover processes where multiple entries can share the same product code
     * (e.g. promotions or configurable products)
     *
     * @param cartId
     * @param productCode
     */
    getLastEntry(cartId: string, productCode: string): Observable<OrderEntry | undefined>;
    /**
     * Add entry to cart
     *
     * @param userId
     * @param cartId
     * @param productCode
     * @param quantity
     * @param pickupStore
     */
    addEntry(userId: string, cartId: string, productCode: string, quantity: number, pickupStore?: string): void;
    /**
     * Add multiple entries to cart
     *
     * @param userId
     * @param cartId
     * @param products Array with items (productCode and quantity)
     */
    addEntries(userId: string, cartId: string, products: Array<{
        productCode: string;
        quantity: number;
    }>): void;
    /**
     * Remove entry from cart
     *
     * @param userId
     * @param cartId
     * @param entryNumber
     */
    removeEntry(userId: string, cartId: string, entryNumber: number): void;
    /**
     * Update entry in cart. For quantity = 0 it removes entry
     *
     * @param userId
     * @param cartId
     * @param entryNumber
     * @param quantity
     * @param pickupStore
     * @param pickupToDelivery
     */
    updateEntry(userId: string, cartId: string, entryNumber: number, quantity?: number, pickupStore?: string, pickupToDelivery?: boolean): void;
    /**
     * Get first entry from cart matching the specified product code
     *
     * @param cartId
     * @param productCode
     */
    getEntry(cartId: string, productCode: string): Observable<OrderEntry | undefined>;
    /**
     * Assign email to the cart
     *
     * @param cartId
     * @param userId
     * @param email
     */
    assignEmail(cartId: string, userId: string, email: string): void;
    removeCart(cartId: string): void;
    /**
     * Delete cart
     *
     * @param cartId
     * @param userId
     */
    deleteCart(cartId: string, userId: string): void;
    /**
     * Reloads the cart with specified id.
     *
     * @param cartId
     * @param extraData
     */
    reloadCart(cartId: string, extraData?: {
        active: boolean;
    }): void;
    /**
     * Get the cart id based on cart type
     *
     * @param cartType
     */
    getCartIdByType(cartType: CartType): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiCartService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MultiCartService>;
}

declare class SelectiveCartService implements SelectiveCartFacade {
    protected userProfileFacade: UserProfileFacade;
    protected multiCartFacade: MultiCartFacade;
    protected baseSiteService: BaseSiteService;
    protected userIdService: UserIdService;
    protected selectiveCart$: Observable<Cart>;
    constructor(userProfileFacade: UserProfileFacade, multiCartFacade: MultiCartFacade, baseSiteService: BaseSiteService, userIdService: UserIdService);
    /**
     * Initialize the stream when first call this function
     */
    getCart(): Observable<Cart>;
    getEntries(): Observable<OrderEntry[]>;
    isStable(): Observable<boolean>;
    addEntry(productCode: string, quantity: number): void;
    removeEntry(entry: OrderEntry): void;
    updateEntry(entryNumber: number, quantity: number): void;
    getEntry(productCode: string): Observable<OrderEntry | undefined>;
    protected getSelectiveCartId(): Observable<string>;
    private getSelectiveIdWithUserId;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectiveCartService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SelectiveCartService>;
}

declare class CartConfigService {
    protected config: CartConfig;
    constructor(config: CartConfig);
    isSelectiveCartEnabled(): boolean;
    isCartValidationEnabled(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartConfigService>;
}

declare class CartValidationGuard {
    protected cartValidationService: CartValidationFacade;
    protected semanticPathService: SemanticPathService;
    protected router: Router;
    protected globalMessageService: GlobalMessageService;
    protected activeCartService: ActiveCartFacade;
    protected cartValidationStateService: CartValidationStateService;
    protected cartConfigService: CartConfigService;
    constructor(cartValidationService: CartValidationFacade, semanticPathService: SemanticPathService, router: Router, globalMessageService: GlobalMessageService, activeCartService: ActiveCartFacade, cartValidationStateService: CartValidationStateService, cartConfigService: CartConfigService);
    protected GLOBAL_MESSAGE_TIMEOUT: number;
    canActivate(): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartValidationGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartValidationGuard>;
}

declare const CART_ADD_ENTRY = "[Cart-entry] Add Entry";
declare const CART_ADD_ENTRY_SUCCESS = "[Cart-entry] Add Entry Success";
declare const CART_ADD_ENTRY_FAIL = "[Cart-entry] Add Entry Fail";
declare const CART_REMOVE_ENTRY = "[Cart-entry] Remove Entry";
declare const CART_REMOVE_ENTRY_SUCCESS = "[Cart-entry] Remove Entry Success";
declare const CART_REMOVE_ENTRY_FAIL = "[Cart-entry] Remove Entry Fail";
declare const CART_UPDATE_ENTRY = "[Cart-entry] Update Entry";
declare const CART_UPDATE_ENTRY_SUCCESS = "[Cart-entry] Update Entry Success";
declare const CART_UPDATE_ENTRY_FAIL = "[Cart-entry] Update Entry Fail";
declare class CartAddEntry extends StateUtils.EntityProcessesIncrementAction {
    payload: {
        cartId: string;
        userId: string;
        productCode: string;
        quantity: number;
        pickupStore?: string;
    };
    readonly type = "[Cart-entry] Add Entry";
    constructor(payload: {
        cartId: string;
        userId: string;
        productCode: string;
        quantity: number;
        pickupStore?: string;
    });
}
declare class CartAddEntrySuccess extends StateUtils.EntityProcessesDecrementAction {
    payload: {
        userId: string;
        cartId: string;
        productCode: string;
        quantity: number;
        pickupStore?: string;
        deliveryModeChanged?: boolean;
        entry?: OrderEntry;
        quantityAdded?: number;
        statusCode?: string;
        statusMessage?: string;
    };
    readonly type = "[Cart-entry] Add Entry Success";
    constructor(payload: {
        userId: string;
        cartId: string;
        productCode: string;
        quantity: number;
        pickupStore?: string;
        deliveryModeChanged?: boolean;
        entry?: OrderEntry;
        quantityAdded?: number;
        statusCode?: string;
        statusMessage?: string;
    });
}
declare class CartAddEntryFail extends StateUtils.EntityProcessesDecrementAction implements ErrorAction {
    payload: {
        error: any;
        userId: string;
        cartId: string;
        productCode: string;
        quantity: number;
        pickupStore?: string;
    };
    error: any;
    readonly type = "[Cart-entry] Add Entry Fail";
    constructor(payload: {
        error: any;
        userId: string;
        cartId: string;
        productCode: string;
        quantity: number;
        pickupStore?: string;
    });
}
declare class CartRemoveEntry extends StateUtils.EntityProcessesIncrementAction {
    payload: {
        cartId: string;
        userId: string;
        entryNumber: string;
    };
    readonly type = "[Cart-entry] Remove Entry";
    constructor(payload: {
        cartId: string;
        userId: string;
        entryNumber: string;
    });
}
declare class CartRemoveEntrySuccess extends StateUtils.EntityProcessesDecrementAction {
    payload: {
        userId: string;
        cartId: string;
        entryNumber: string;
    };
    readonly type = "[Cart-entry] Remove Entry Success";
    constructor(payload: {
        userId: string;
        cartId: string;
        entryNumber: string;
    });
}
declare class CartRemoveEntryFail extends StateUtils.EntityProcessesDecrementAction implements ErrorAction {
    payload: {
        error: any;
        cartId: string;
        userId: string;
        entryNumber: string;
    };
    error: any;
    readonly type = "[Cart-entry] Remove Entry Fail";
    constructor(payload: {
        error: any;
        cartId: string;
        userId: string;
        entryNumber: string;
    });
}
declare class CartUpdateEntry extends StateUtils.EntityProcessesIncrementAction {
    payload: {
        userId: string;
        cartId: string;
        entryNumber: string;
        quantity?: number;
        pickupStore?: string;
        pickupToDelivery?: boolean;
    };
    readonly type = "[Cart-entry] Update Entry";
    constructor(payload: {
        userId: string;
        cartId: string;
        entryNumber: string;
        quantity?: number;
        pickupStore?: string;
        pickupToDelivery?: boolean;
    });
}
declare class CartUpdateEntrySuccess extends StateUtils.EntityProcessesDecrementAction {
    payload: {
        userId: string;
        cartId: string;
        entryNumber: string;
        quantity?: number;
        pickupStore?: string;
        pickupToDelivery?: boolean;
    };
    readonly type = "[Cart-entry] Update Entry Success";
    constructor(payload: {
        userId: string;
        cartId: string;
        entryNumber: string;
        quantity?: number;
        pickupStore?: string;
        pickupToDelivery?: boolean;
    });
}
declare class CartUpdateEntryFail extends StateUtils.EntityProcessesDecrementAction implements ErrorAction {
    payload: {
        error: any;
        userId: string;
        cartId: string;
        entryNumber: string;
        quantity?: number;
        pickupStore?: string;
        pickupToDelivery?: boolean;
    };
    error: any;
    readonly type = "[Cart-entry] Update Entry Fail";
    constructor(payload: {
        error: any;
        userId: string;
        cartId: string;
        entryNumber: string;
        quantity?: number;
        pickupStore?: string;
        pickupToDelivery?: boolean;
    });
}
type CartEntryAction = CartAddEntry | CartAddEntrySuccess | CartAddEntryFail | CartRemoveEntry | CartRemoveEntrySuccess | CartRemoveEntryFail | CartUpdateEntry | CartUpdateEntrySuccess | CartUpdateEntryFail;

declare const CART_ADD_VOUCHER = "[Cart-voucher] Add Cart Vouchers";
declare const CART_ADD_VOUCHER_FAIL = "[Cart-voucher] Add Cart Voucher Fail";
declare const CART_ADD_VOUCHER_SUCCESS = "[Cart-voucher] Add Cart Voucher Success";
declare const CART_RESET_ADD_VOUCHER = "[Cart-voucher] Reset Add Cart Voucher";
declare const CART_REMOVE_VOUCHER = "[Cart-voucher] Remove Cart Voucher";
declare const CART_REMOVE_VOUCHER_FAIL = "[Cart-voucher] Remove Cart Voucher Fail";
declare const CART_REMOVE_VOUCHER_SUCCESS = "[Cart-voucher] Remove Cart Voucher Success";
declare class CartAddVoucher extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        cartId: string;
        voucherId: string;
    };
    readonly type = "[Cart-voucher] Add Cart Vouchers";
    constructor(payload: {
        userId: string;
        cartId: string;
        voucherId: string;
    });
}
declare class CartAddVoucherFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        userId: string;
        cartId: string;
        voucherId: string;
        error: any;
    };
    readonly type = "[Cart-voucher] Add Cart Voucher Fail";
    constructor(payload: {
        userId: string;
        cartId: string;
        voucherId: string;
        error: any;
    });
}
declare class CartAddVoucherSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        userId: string;
        cartId: string;
        voucherId: string;
    };
    readonly type = "[Cart-voucher] Add Cart Voucher Success";
    constructor(payload: {
        userId: string;
        cartId: string;
        voucherId: string;
    });
}
/**
 * Resets add voucher process
 */
declare class CartResetAddVoucher extends StateUtils.EntityLoaderResetAction {
    readonly type = "[Cart-voucher] Reset Add Cart Voucher";
    constructor();
}
declare class CartRemoveVoucher extends StateUtils.EntityProcessesIncrementAction {
    payload: {
        userId: string;
        cartId: string;
        voucherId: string;
    };
    readonly type = "[Cart-voucher] Remove Cart Voucher";
    constructor(payload: {
        userId: string;
        cartId: string;
        voucherId: string;
    });
}
declare class CartRemoveVoucherFail extends StateUtils.EntityProcessesDecrementAction implements ErrorAction {
    payload: {
        error: any;
        cartId: string;
        userId: string;
        voucherId: string;
    };
    error: any;
    readonly type = "[Cart-voucher] Remove Cart Voucher Fail";
    constructor(payload: {
        error: any;
        cartId: string;
        userId: string;
        voucherId: string;
    });
}
declare class CartRemoveVoucherSuccess extends StateUtils.EntityProcessesDecrementAction {
    payload: {
        userId: string;
        cartId: string;
        voucherId: string;
    };
    readonly type = "[Cart-voucher] Remove Cart Voucher Success";
    constructor(payload: {
        userId: string;
        cartId: string;
        voucherId: string;
    });
}
type CartVoucherAction = CartAddVoucher | CartAddVoucherFail | CartAddVoucherSuccess | CartResetAddVoucher | CartRemoveVoucher | CartRemoveVoucherFail | CartRemoveVoucherSuccess;

declare const CREATE_CART = "[Cart] Create Cart";
declare const CREATE_CART_FAIL = "[Cart] Create Cart Fail";
declare const CREATE_CART_SUCCESS = "[Cart] Create Cart Success";
declare const LOAD_CART = "[Cart] Load Cart";
declare const LOAD_CART_FAIL = "[Cart] Load Cart Fail";
declare const LOAD_CART_SUCCESS = "[Cart] Load Cart Success";
declare const LOAD_CARTS_SUCCESS = "[Cart] Load Carts Success";
declare const ADD_EMAIL_TO_CART = "[Cart] Add Email to Cart";
declare const ADD_EMAIL_TO_CART_FAIL = "[Cart] Add Email to Cart Fail";
declare const ADD_EMAIL_TO_CART_SUCCESS = "[Cart] Add Email to Cart Success";
declare const MERGE_CART = "[Cart] Merge Cart";
declare const MERGE_CART_SUCCESS = "[Cart] Merge Cart Success";
declare const MERGE_CART_ABORT = "[Cart] Merge Cart Abort";
declare const RESET_CART_DETAILS = "[Cart] Reset Cart Details";
declare const RESET_CART_DETAILS_BY_IDS = "[Cart] Reset Cart Details By Ids";
declare const REMOVE_CART = "[Cart] Remove Cart";
declare const DELETE_CART = "[Cart] Delete Cart";
declare const DELETE_CART_SUCCESS = "[Cart] Delete Cart Success";
declare const DELETE_CART_FAIL = "[Cart] Delete Cart Fail";
interface CreateCartPayload {
    userId: string;
    /** Used as a unique key in ngrx carts store (we don't know cartId at that time) */
    tempCartId: string;
    extraData?: {
        active?: boolean;
    };
    /** Anonymous cart which should be merged to new cart */
    oldCartId?: string;
    /** Cart to which should we merge (not passing this will create new cart) */
    toMergeCartGuid?: string;
}
declare class CreateCart extends StateUtils.EntityLoadAction {
    payload: CreateCartPayload;
    readonly type = "[Cart] Create Cart";
    constructor(payload: CreateCartPayload);
}
interface CreateCartFailPayload extends CreateCartPayload {
    error: any;
}
declare class CreateCartFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: CreateCartFailPayload;
    readonly type = "[Cart] Create Cart Fail";
    constructor(payload: CreateCartFailPayload);
}
interface CreateCartSuccessPayload extends CreateCartPayload {
    cart: Cart;
    cartId: string;
}
declare class CreateCartSuccess extends StateUtils.EntitySuccessAction {
    payload: CreateCartSuccessPayload;
    readonly type = "[Cart] Create Cart Success";
    constructor(payload: CreateCartSuccessPayload);
}
declare class AddEmailToCart extends StateUtils.EntityProcessesIncrementAction {
    payload: {
        userId: string;
        cartId: string;
        email: string;
    };
    readonly type = "[Cart] Add Email to Cart";
    constructor(payload: {
        userId: string;
        cartId: string;
        email: string;
    });
}
declare class AddEmailToCartFail extends StateUtils.EntityProcessesDecrementAction implements ErrorAction {
    payload: {
        userId: string;
        cartId: string;
        error: any;
        email: string;
    };
    error: any;
    readonly type = "[Cart] Add Email to Cart Fail";
    constructor(payload: {
        userId: string;
        cartId: string;
        error: any;
        email: string;
    });
}
declare class AddEmailToCartSuccess extends StateUtils.EntityProcessesDecrementAction {
    payload: {
        userId: string;
        cartId: string;
        email: string;
    };
    readonly type = "[Cart] Add Email to Cart Success";
    constructor(payload: {
        userId: string;
        cartId: string;
        email: string;
    });
}
interface LoadCartPayload {
    userId: string;
    cartId: string;
    extraData?: {
        active?: boolean;
    };
}
declare class LoadCart extends StateUtils.EntityLoadAction {
    payload: LoadCartPayload;
    readonly type = "[Cart] Load Cart";
    constructor(payload: LoadCartPayload);
}
interface LoadCartFailPayload extends LoadCartPayload {
    error: any;
}
declare class LoadCartFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: LoadCartFailPayload;
    readonly type = "[Cart] Load Cart Fail";
    constructor(payload: LoadCartFailPayload);
}
interface LoadCartSuccessPayload extends LoadCartPayload {
    cart: Cart;
}
declare class LoadCartSuccess extends StateUtils.EntitySuccessAction {
    payload: LoadCartSuccessPayload;
    readonly type = "[Cart] Load Cart Success";
    constructor(payload: LoadCartSuccessPayload);
}
declare class LoadCartsSuccess extends StateUtils.EntitySuccessAction {
    payload: Cart[];
    readonly type = "[Cart] Load Carts Success";
    constructor(payload: Cart[]);
}
interface MergeCartPayload {
    cartId: string;
    userId: string;
    extraData?: {
        active?: boolean;
    };
    /**
     * MergeCart actions triggers CreateCart which requires this parameter, so that's why it is required.
     */
    tempCartId: string;
}
/**
 * @deprecated since 221121.1
 * Use the new MergeCartAndIncrementProcessesCount instead.
 * @see MergeCartAndIncrementProcessesCount
 */
declare class MergeCart implements Action {
    payload: MergeCartPayload;
    readonly type = "[Cart] Merge Cart";
    constructor(payload: MergeCartPayload);
}
/**
 * Initialize the merge cart.
 * Comparing to the previous implementation of MergeCart, MergeCartAndIncrementProcessesCount increments in addition processesCount to mark cart as busy and prevent premature cart loading.
 */
declare class MergeCartAndIncrementProcessesCount extends StateUtils.EntityProcessesIncrementAction {
    payload: MergeCartPayload;
    readonly type = "[Cart] Merge Cart";
    constructor(payload: MergeCartPayload);
}
interface MergeCartSuccessPayload extends MergeCartPayload {
    /**
     * Previous cart id which was merged with new/user cart.
     * Needed to know which obsolete entity should be removed.
     */
    oldCartId: string;
}
declare class MergeCartSuccess extends StateUtils.EntityRemoveAction {
    payload: MergeCartSuccessPayload;
    readonly type = "[Cart] Merge Cart Success";
    constructor(payload: MergeCartSuccessPayload);
}
interface MergeCartAbortPayload {
    cartId: string;
    error?: Object;
}
declare class MergeCartAbort extends StateUtils.EntityProcessesDecrementAction implements ErrorAction {
    payload: MergeCartAbortPayload;
    readonly type = "[Cart] Merge Cart Abort";
    error: any;
    constructor(payload: MergeCartAbortPayload);
}
/**
 * On site context change we want to keep current list of entities, but we want to clear the value and flags.
 * With ProcessesLoaderResetAction we run it on every entity of this type.
 */
declare class ResetCartDetails extends StateUtils.ProcessesLoaderResetAction {
    readonly type = "[Cart] Reset Cart Details";
    constructor();
}
/**
 * On site context change we want to clear value and flags only for selected carts.
 */
declare class ResetCartDetailsByIds extends StateUtils.EntityProcessesLoaderResetAction {
    payload: {
        cartIds: string[];
    };
    readonly type = "[Cart] Reset Cart Details By Ids";
    constructor(payload: {
        cartIds: string[];
    });
}
/**
 * Used for cleaning cart in local state, when we get information that it no longer exists in the backend.
 * For removing particular cart in both places use DeleteCart actions.
 */
declare class RemoveCart extends StateUtils.EntityRemoveAction {
    payload: {
        cartId: string;
    };
    readonly type = "[Cart] Remove Cart";
    constructor(payload: {
        cartId: string;
    });
}
declare class DeleteCart implements Action {
    payload: {
        userId: string;
        cartId: string;
    };
    readonly type = "[Cart] Delete Cart";
    constructor(payload: {
        userId: string;
        cartId: string;
    });
}
declare class DeleteCartSuccess extends StateUtils.EntityRemoveAction {
    payload: {
        userId: string;
        cartId: string;
    };
    readonly type = "[Cart] Delete Cart Success";
    constructor(payload: {
        userId: string;
        cartId: string;
    });
}
declare class DeleteCartFail implements ErrorAction {
    payload: {
        userId: string;
        cartId: string;
        error: any;
    };
    error: any;
    readonly type = "[Cart] Delete Cart Fail";
    constructor(payload: {
        userId: string;
        cartId: string;
        error: any;
    });
}
type CartAction = CreateCart | CreateCartFail | CreateCartSuccess | LoadCart | LoadCartFail | LoadCartSuccess | LoadCartsSuccess | MergeCart | MergeCartSuccess | ResetCartDetails | ResetCartDetailsByIds | AddEmailToCart | AddEmailToCartFail | AddEmailToCartSuccess | DeleteCart | DeleteCartSuccess | DeleteCartFail | RemoveCart;

declare const CART_PROCESSES_INCREMENT = "[Cart] Cart Processes Increment";
declare const CART_PROCESSES_DECREMENT = "[Cart] Cart Processes Decrement";
declare const SET_ACTIVE_CART_ID = "[Cart] Set Active Cart Id";
declare const CLEAR_CART_STATE = "[Cart] Clear Cart State";
declare const SET_CART_TYPE_INDEX = "[Cart] Set cart type index";
declare const SET_CART_DATA = "[Cart] Set cart data";
/**
 * Increases process counter on cart entities
 * All actions that cause computations on cart should extend EntityProcessesIncrementAction instead of dispatching this action.
 */
declare class CartProcessesIncrement extends StateUtils.EntityProcessesIncrementAction {
    payload: string;
    readonly type = "[Cart] Cart Processes Increment";
    constructor(payload: string);
}
/**
 * Decrement process counter on cart entities
 * All actions that cause computations on cart should extend EntityProcessesDecrementAction instead of dispatching this action.
 */
declare class CartProcessesDecrement extends StateUtils.EntityProcessesDecrementAction {
    payload: string;
    readonly type = "[Cart] Cart Processes Decrement";
    constructor(payload: string);
}
/**
 * Only sets active cart property with id of active cart. Then services take care of loading that cart.
 */
declare class SetActiveCartId implements Action {
    payload: string;
    readonly type = "[Cart] Set Active Cart Id";
    constructor(payload: string);
}
/**
 * Clear whole cart store state: all entities + reset rest of the cart state.
 */
declare class ClearCartState extends StateUtils.EntityRemoveAllAction {
    readonly type = "[Cart] Clear Cart State";
    constructor();
}
declare class SetCartTypeIndex implements Action {
    payload: {
        cartType: CartType;
        cartId: string | undefined;
    };
    readonly type = "[Cart] Set cart type index";
    constructor(payload: {
        cartType: CartType;
        cartId: string | undefined;
    });
}
declare class SetCartData extends StateUtils.EntitySuccessAction {
    payload: {
        cart: Cart;
        cartId: string;
    };
    readonly type = "[Cart] Set cart data";
    constructor(payload: {
        cart: Cart;
        cartId: string;
    });
}
type MultiCartActions = CartProcessesIncrement | CartProcessesDecrement | SetActiveCartId | ClearCartState | SetCartTypeIndex | SetCartData;

declare const cartGroup_actions_d_ADD_EMAIL_TO_CART: typeof ADD_EMAIL_TO_CART;
declare const cartGroup_actions_d_ADD_EMAIL_TO_CART_FAIL: typeof ADD_EMAIL_TO_CART_FAIL;
declare const cartGroup_actions_d_ADD_EMAIL_TO_CART_SUCCESS: typeof ADD_EMAIL_TO_CART_SUCCESS;
type cartGroup_actions_d_AddEmailToCart = AddEmailToCart;
declare const cartGroup_actions_d_AddEmailToCart: typeof AddEmailToCart;
type cartGroup_actions_d_AddEmailToCartFail = AddEmailToCartFail;
declare const cartGroup_actions_d_AddEmailToCartFail: typeof AddEmailToCartFail;
type cartGroup_actions_d_AddEmailToCartSuccess = AddEmailToCartSuccess;
declare const cartGroup_actions_d_AddEmailToCartSuccess: typeof AddEmailToCartSuccess;
declare const cartGroup_actions_d_CART_ADD_ENTRY: typeof CART_ADD_ENTRY;
declare const cartGroup_actions_d_CART_ADD_ENTRY_FAIL: typeof CART_ADD_ENTRY_FAIL;
declare const cartGroup_actions_d_CART_ADD_ENTRY_SUCCESS: typeof CART_ADD_ENTRY_SUCCESS;
declare const cartGroup_actions_d_CART_ADD_VOUCHER: typeof CART_ADD_VOUCHER;
declare const cartGroup_actions_d_CART_ADD_VOUCHER_FAIL: typeof CART_ADD_VOUCHER_FAIL;
declare const cartGroup_actions_d_CART_ADD_VOUCHER_SUCCESS: typeof CART_ADD_VOUCHER_SUCCESS;
declare const cartGroup_actions_d_CART_PROCESSES_DECREMENT: typeof CART_PROCESSES_DECREMENT;
declare const cartGroup_actions_d_CART_PROCESSES_INCREMENT: typeof CART_PROCESSES_INCREMENT;
declare const cartGroup_actions_d_CART_REMOVE_ENTRY: typeof CART_REMOVE_ENTRY;
declare const cartGroup_actions_d_CART_REMOVE_ENTRY_FAIL: typeof CART_REMOVE_ENTRY_FAIL;
declare const cartGroup_actions_d_CART_REMOVE_ENTRY_SUCCESS: typeof CART_REMOVE_ENTRY_SUCCESS;
declare const cartGroup_actions_d_CART_REMOVE_VOUCHER: typeof CART_REMOVE_VOUCHER;
declare const cartGroup_actions_d_CART_REMOVE_VOUCHER_FAIL: typeof CART_REMOVE_VOUCHER_FAIL;
declare const cartGroup_actions_d_CART_REMOVE_VOUCHER_SUCCESS: typeof CART_REMOVE_VOUCHER_SUCCESS;
declare const cartGroup_actions_d_CART_RESET_ADD_VOUCHER: typeof CART_RESET_ADD_VOUCHER;
declare const cartGroup_actions_d_CART_UPDATE_ENTRY: typeof CART_UPDATE_ENTRY;
declare const cartGroup_actions_d_CART_UPDATE_ENTRY_FAIL: typeof CART_UPDATE_ENTRY_FAIL;
declare const cartGroup_actions_d_CART_UPDATE_ENTRY_SUCCESS: typeof CART_UPDATE_ENTRY_SUCCESS;
declare const cartGroup_actions_d_CLEAR_CART_STATE: typeof CLEAR_CART_STATE;
declare const cartGroup_actions_d_CREATE_CART: typeof CREATE_CART;
declare const cartGroup_actions_d_CREATE_CART_FAIL: typeof CREATE_CART_FAIL;
declare const cartGroup_actions_d_CREATE_CART_SUCCESS: typeof CREATE_CART_SUCCESS;
type cartGroup_actions_d_CartAction = CartAction;
type cartGroup_actions_d_CartAddEntry = CartAddEntry;
declare const cartGroup_actions_d_CartAddEntry: typeof CartAddEntry;
type cartGroup_actions_d_CartAddEntryFail = CartAddEntryFail;
declare const cartGroup_actions_d_CartAddEntryFail: typeof CartAddEntryFail;
type cartGroup_actions_d_CartAddEntrySuccess = CartAddEntrySuccess;
declare const cartGroup_actions_d_CartAddEntrySuccess: typeof CartAddEntrySuccess;
type cartGroup_actions_d_CartAddVoucher = CartAddVoucher;
declare const cartGroup_actions_d_CartAddVoucher: typeof CartAddVoucher;
type cartGroup_actions_d_CartAddVoucherFail = CartAddVoucherFail;
declare const cartGroup_actions_d_CartAddVoucherFail: typeof CartAddVoucherFail;
type cartGroup_actions_d_CartAddVoucherSuccess = CartAddVoucherSuccess;
declare const cartGroup_actions_d_CartAddVoucherSuccess: typeof CartAddVoucherSuccess;
type cartGroup_actions_d_CartEntryAction = CartEntryAction;
type cartGroup_actions_d_CartProcessesDecrement = CartProcessesDecrement;
declare const cartGroup_actions_d_CartProcessesDecrement: typeof CartProcessesDecrement;
type cartGroup_actions_d_CartProcessesIncrement = CartProcessesIncrement;
declare const cartGroup_actions_d_CartProcessesIncrement: typeof CartProcessesIncrement;
type cartGroup_actions_d_CartRemoveEntry = CartRemoveEntry;
declare const cartGroup_actions_d_CartRemoveEntry: typeof CartRemoveEntry;
type cartGroup_actions_d_CartRemoveEntryFail = CartRemoveEntryFail;
declare const cartGroup_actions_d_CartRemoveEntryFail: typeof CartRemoveEntryFail;
type cartGroup_actions_d_CartRemoveEntrySuccess = CartRemoveEntrySuccess;
declare const cartGroup_actions_d_CartRemoveEntrySuccess: typeof CartRemoveEntrySuccess;
type cartGroup_actions_d_CartRemoveVoucher = CartRemoveVoucher;
declare const cartGroup_actions_d_CartRemoveVoucher: typeof CartRemoveVoucher;
type cartGroup_actions_d_CartRemoveVoucherFail = CartRemoveVoucherFail;
declare const cartGroup_actions_d_CartRemoveVoucherFail: typeof CartRemoveVoucherFail;
type cartGroup_actions_d_CartRemoveVoucherSuccess = CartRemoveVoucherSuccess;
declare const cartGroup_actions_d_CartRemoveVoucherSuccess: typeof CartRemoveVoucherSuccess;
type cartGroup_actions_d_CartResetAddVoucher = CartResetAddVoucher;
declare const cartGroup_actions_d_CartResetAddVoucher: typeof CartResetAddVoucher;
type cartGroup_actions_d_CartUpdateEntry = CartUpdateEntry;
declare const cartGroup_actions_d_CartUpdateEntry: typeof CartUpdateEntry;
type cartGroup_actions_d_CartUpdateEntryFail = CartUpdateEntryFail;
declare const cartGroup_actions_d_CartUpdateEntryFail: typeof CartUpdateEntryFail;
type cartGroup_actions_d_CartUpdateEntrySuccess = CartUpdateEntrySuccess;
declare const cartGroup_actions_d_CartUpdateEntrySuccess: typeof CartUpdateEntrySuccess;
type cartGroup_actions_d_CartVoucherAction = CartVoucherAction;
type cartGroup_actions_d_ClearCartState = ClearCartState;
declare const cartGroup_actions_d_ClearCartState: typeof ClearCartState;
type cartGroup_actions_d_CreateCart = CreateCart;
declare const cartGroup_actions_d_CreateCart: typeof CreateCart;
type cartGroup_actions_d_CreateCartFail = CreateCartFail;
declare const cartGroup_actions_d_CreateCartFail: typeof CreateCartFail;
type cartGroup_actions_d_CreateCartSuccess = CreateCartSuccess;
declare const cartGroup_actions_d_CreateCartSuccess: typeof CreateCartSuccess;
declare const cartGroup_actions_d_DELETE_CART: typeof DELETE_CART;
declare const cartGroup_actions_d_DELETE_CART_FAIL: typeof DELETE_CART_FAIL;
declare const cartGroup_actions_d_DELETE_CART_SUCCESS: typeof DELETE_CART_SUCCESS;
type cartGroup_actions_d_DeleteCart = DeleteCart;
declare const cartGroup_actions_d_DeleteCart: typeof DeleteCart;
type cartGroup_actions_d_DeleteCartFail = DeleteCartFail;
declare const cartGroup_actions_d_DeleteCartFail: typeof DeleteCartFail;
type cartGroup_actions_d_DeleteCartSuccess = DeleteCartSuccess;
declare const cartGroup_actions_d_DeleteCartSuccess: typeof DeleteCartSuccess;
declare const cartGroup_actions_d_LOAD_CART: typeof LOAD_CART;
declare const cartGroup_actions_d_LOAD_CARTS_SUCCESS: typeof LOAD_CARTS_SUCCESS;
declare const cartGroup_actions_d_LOAD_CART_FAIL: typeof LOAD_CART_FAIL;
declare const cartGroup_actions_d_LOAD_CART_SUCCESS: typeof LOAD_CART_SUCCESS;
type cartGroup_actions_d_LoadCart = LoadCart;
declare const cartGroup_actions_d_LoadCart: typeof LoadCart;
type cartGroup_actions_d_LoadCartFail = LoadCartFail;
declare const cartGroup_actions_d_LoadCartFail: typeof LoadCartFail;
type cartGroup_actions_d_LoadCartSuccess = LoadCartSuccess;
declare const cartGroup_actions_d_LoadCartSuccess: typeof LoadCartSuccess;
type cartGroup_actions_d_LoadCartsSuccess = LoadCartsSuccess;
declare const cartGroup_actions_d_LoadCartsSuccess: typeof LoadCartsSuccess;
declare const cartGroup_actions_d_MERGE_CART: typeof MERGE_CART;
declare const cartGroup_actions_d_MERGE_CART_ABORT: typeof MERGE_CART_ABORT;
declare const cartGroup_actions_d_MERGE_CART_SUCCESS: typeof MERGE_CART_SUCCESS;
type cartGroup_actions_d_MergeCart = MergeCart;
declare const cartGroup_actions_d_MergeCart: typeof MergeCart;
type cartGroup_actions_d_MergeCartAbort = MergeCartAbort;
declare const cartGroup_actions_d_MergeCartAbort: typeof MergeCartAbort;
type cartGroup_actions_d_MergeCartAbortPayload = MergeCartAbortPayload;
type cartGroup_actions_d_MergeCartAndIncrementProcessesCount = MergeCartAndIncrementProcessesCount;
declare const cartGroup_actions_d_MergeCartAndIncrementProcessesCount: typeof MergeCartAndIncrementProcessesCount;
type cartGroup_actions_d_MergeCartSuccess = MergeCartSuccess;
declare const cartGroup_actions_d_MergeCartSuccess: typeof MergeCartSuccess;
type cartGroup_actions_d_MultiCartActions = MultiCartActions;
declare const cartGroup_actions_d_REMOVE_CART: typeof REMOVE_CART;
declare const cartGroup_actions_d_RESET_CART_DETAILS: typeof RESET_CART_DETAILS;
declare const cartGroup_actions_d_RESET_CART_DETAILS_BY_IDS: typeof RESET_CART_DETAILS_BY_IDS;
type cartGroup_actions_d_RemoveCart = RemoveCart;
declare const cartGroup_actions_d_RemoveCart: typeof RemoveCart;
type cartGroup_actions_d_ResetCartDetails = ResetCartDetails;
declare const cartGroup_actions_d_ResetCartDetails: typeof ResetCartDetails;
type cartGroup_actions_d_ResetCartDetailsByIds = ResetCartDetailsByIds;
declare const cartGroup_actions_d_ResetCartDetailsByIds: typeof ResetCartDetailsByIds;
declare const cartGroup_actions_d_SET_ACTIVE_CART_ID: typeof SET_ACTIVE_CART_ID;
declare const cartGroup_actions_d_SET_CART_DATA: typeof SET_CART_DATA;
declare const cartGroup_actions_d_SET_CART_TYPE_INDEX: typeof SET_CART_TYPE_INDEX;
type cartGroup_actions_d_SetActiveCartId = SetActiveCartId;
declare const cartGroup_actions_d_SetActiveCartId: typeof SetActiveCartId;
type cartGroup_actions_d_SetCartData = SetCartData;
declare const cartGroup_actions_d_SetCartData: typeof SetCartData;
type cartGroup_actions_d_SetCartTypeIndex = SetCartTypeIndex;
declare const cartGroup_actions_d_SetCartTypeIndex: typeof SetCartTypeIndex;
declare namespace cartGroup_actions_d {
  export { cartGroup_actions_d_ADD_EMAIL_TO_CART as ADD_EMAIL_TO_CART, cartGroup_actions_d_ADD_EMAIL_TO_CART_FAIL as ADD_EMAIL_TO_CART_FAIL, cartGroup_actions_d_ADD_EMAIL_TO_CART_SUCCESS as ADD_EMAIL_TO_CART_SUCCESS, cartGroup_actions_d_AddEmailToCart as AddEmailToCart, cartGroup_actions_d_AddEmailToCartFail as AddEmailToCartFail, cartGroup_actions_d_AddEmailToCartSuccess as AddEmailToCartSuccess, cartGroup_actions_d_CART_ADD_ENTRY as CART_ADD_ENTRY, cartGroup_actions_d_CART_ADD_ENTRY_FAIL as CART_ADD_ENTRY_FAIL, cartGroup_actions_d_CART_ADD_ENTRY_SUCCESS as CART_ADD_ENTRY_SUCCESS, cartGroup_actions_d_CART_ADD_VOUCHER as CART_ADD_VOUCHER, cartGroup_actions_d_CART_ADD_VOUCHER_FAIL as CART_ADD_VOUCHER_FAIL, cartGroup_actions_d_CART_ADD_VOUCHER_SUCCESS as CART_ADD_VOUCHER_SUCCESS, cartGroup_actions_d_CART_PROCESSES_DECREMENT as CART_PROCESSES_DECREMENT, cartGroup_actions_d_CART_PROCESSES_INCREMENT as CART_PROCESSES_INCREMENT, cartGroup_actions_d_CART_REMOVE_ENTRY as CART_REMOVE_ENTRY, cartGroup_actions_d_CART_REMOVE_ENTRY_FAIL as CART_REMOVE_ENTRY_FAIL, cartGroup_actions_d_CART_REMOVE_ENTRY_SUCCESS as CART_REMOVE_ENTRY_SUCCESS, cartGroup_actions_d_CART_REMOVE_VOUCHER as CART_REMOVE_VOUCHER, cartGroup_actions_d_CART_REMOVE_VOUCHER_FAIL as CART_REMOVE_VOUCHER_FAIL, cartGroup_actions_d_CART_REMOVE_VOUCHER_SUCCESS as CART_REMOVE_VOUCHER_SUCCESS, cartGroup_actions_d_CART_RESET_ADD_VOUCHER as CART_RESET_ADD_VOUCHER, cartGroup_actions_d_CART_UPDATE_ENTRY as CART_UPDATE_ENTRY, cartGroup_actions_d_CART_UPDATE_ENTRY_FAIL as CART_UPDATE_ENTRY_FAIL, cartGroup_actions_d_CART_UPDATE_ENTRY_SUCCESS as CART_UPDATE_ENTRY_SUCCESS, cartGroup_actions_d_CLEAR_CART_STATE as CLEAR_CART_STATE, cartGroup_actions_d_CREATE_CART as CREATE_CART, cartGroup_actions_d_CREATE_CART_FAIL as CREATE_CART_FAIL, cartGroup_actions_d_CREATE_CART_SUCCESS as CREATE_CART_SUCCESS, cartGroup_actions_d_CartAddEntry as CartAddEntry, cartGroup_actions_d_CartAddEntryFail as CartAddEntryFail, cartGroup_actions_d_CartAddEntrySuccess as CartAddEntrySuccess, cartGroup_actions_d_CartAddVoucher as CartAddVoucher, cartGroup_actions_d_CartAddVoucherFail as CartAddVoucherFail, cartGroup_actions_d_CartAddVoucherSuccess as CartAddVoucherSuccess, cartGroup_actions_d_CartProcessesDecrement as CartProcessesDecrement, cartGroup_actions_d_CartProcessesIncrement as CartProcessesIncrement, cartGroup_actions_d_CartRemoveEntry as CartRemoveEntry, cartGroup_actions_d_CartRemoveEntryFail as CartRemoveEntryFail, cartGroup_actions_d_CartRemoveEntrySuccess as CartRemoveEntrySuccess, cartGroup_actions_d_CartRemoveVoucher as CartRemoveVoucher, cartGroup_actions_d_CartRemoveVoucherFail as CartRemoveVoucherFail, cartGroup_actions_d_CartRemoveVoucherSuccess as CartRemoveVoucherSuccess, cartGroup_actions_d_CartResetAddVoucher as CartResetAddVoucher, cartGroup_actions_d_CartUpdateEntry as CartUpdateEntry, cartGroup_actions_d_CartUpdateEntryFail as CartUpdateEntryFail, cartGroup_actions_d_CartUpdateEntrySuccess as CartUpdateEntrySuccess, cartGroup_actions_d_ClearCartState as ClearCartState, cartGroup_actions_d_CreateCart as CreateCart, cartGroup_actions_d_CreateCartFail as CreateCartFail, cartGroup_actions_d_CreateCartSuccess as CreateCartSuccess, cartGroup_actions_d_DELETE_CART as DELETE_CART, cartGroup_actions_d_DELETE_CART_FAIL as DELETE_CART_FAIL, cartGroup_actions_d_DELETE_CART_SUCCESS as DELETE_CART_SUCCESS, cartGroup_actions_d_DeleteCart as DeleteCart, cartGroup_actions_d_DeleteCartFail as DeleteCartFail, cartGroup_actions_d_DeleteCartSuccess as DeleteCartSuccess, cartGroup_actions_d_LOAD_CART as LOAD_CART, cartGroup_actions_d_LOAD_CARTS_SUCCESS as LOAD_CARTS_SUCCESS, cartGroup_actions_d_LOAD_CART_FAIL as LOAD_CART_FAIL, cartGroup_actions_d_LOAD_CART_SUCCESS as LOAD_CART_SUCCESS, cartGroup_actions_d_LoadCart as LoadCart, cartGroup_actions_d_LoadCartFail as LoadCartFail, cartGroup_actions_d_LoadCartSuccess as LoadCartSuccess, cartGroup_actions_d_LoadCartsSuccess as LoadCartsSuccess, cartGroup_actions_d_MERGE_CART as MERGE_CART, cartGroup_actions_d_MERGE_CART_ABORT as MERGE_CART_ABORT, cartGroup_actions_d_MERGE_CART_SUCCESS as MERGE_CART_SUCCESS, cartGroup_actions_d_MergeCart as MergeCart, cartGroup_actions_d_MergeCartAbort as MergeCartAbort, cartGroup_actions_d_MergeCartAndIncrementProcessesCount as MergeCartAndIncrementProcessesCount, cartGroup_actions_d_MergeCartSuccess as MergeCartSuccess, cartGroup_actions_d_REMOVE_CART as REMOVE_CART, cartGroup_actions_d_RESET_CART_DETAILS as RESET_CART_DETAILS, cartGroup_actions_d_RESET_CART_DETAILS_BY_IDS as RESET_CART_DETAILS_BY_IDS, cartGroup_actions_d_RemoveCart as RemoveCart, cartGroup_actions_d_ResetCartDetails as ResetCartDetails, cartGroup_actions_d_ResetCartDetailsByIds as ResetCartDetailsByIds, cartGroup_actions_d_SET_ACTIVE_CART_ID as SET_ACTIVE_CART_ID, cartGroup_actions_d_SET_CART_DATA as SET_CART_DATA, cartGroup_actions_d_SET_CART_TYPE_INDEX as SET_CART_TYPE_INDEX, cartGroup_actions_d_SetActiveCartId as SetActiveCartId, cartGroup_actions_d_SetCartData as SetCartData, cartGroup_actions_d_SetCartTypeIndex as SetCartTypeIndex };
  export type { cartGroup_actions_d_CartAction as CartAction, cartGroup_actions_d_CartEntryAction as CartEntryAction, cartGroup_actions_d_CartVoucherAction as CartVoucherAction, cartGroup_actions_d_MergeCartAbortPayload as MergeCartAbortPayload, cartGroup_actions_d_MultiCartActions as MultiCartActions };
}

declare class ProductImportInfoService {
    protected actionsSubject: ActionsSubject;
    protected logger: LoggerService;
    protected constructor(actionsSubject: ActionsSubject);
    /**
     * Get emission of add entry results from actions subject
     *
     * @param {string} cartId
     * @returns {Observable<ProductImportInfo>}
     */
    getResults(cartId: string): Observable<ProductImportInfo>;
    /**
     * Map actions to summary messages
     *
     * @param {CartActions.CartAddEntrySuccess | CartActions.CartAddEntryFail} action
     * @returns ProductImportInfo
     */
    protected mapMessages(action: CartAddEntrySuccess | CartAddEntryFail): ProductImportInfo;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductImportInfoService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductImportInfoService>;
}

declare class MultiCartEffectsService {
    /**
     * Verifies if cart is the active cart or saved cart and returns the appropriate cart type
     * @param action
     * @returns cart type
     */
    getActiveCartTypeOnLoadSuccess(action: LoadCartSuccess): SetCartTypeIndex | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiCartEffectsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MultiCartEffectsService>;
}

declare const getMultiCartState: MemoizedSelector<StateWithMultiCart, MultiCartState>;
declare const getMultiCartEntities: MemoizedSelector<StateWithMultiCart, StateUtils.EntityProcessesLoaderState<Cart | undefined>>;
declare const getCartEntitySelectorFactory: (cartId: string) => MemoizedSelector<StateWithMultiCart, StateUtils.ProcessesLoaderState<Cart | undefined>>;
declare const getCartSelectorFactory: (cartId: string) => MemoizedSelector<StateWithMultiCart, Cart>;
declare const getCartIsStableSelectorFactory: (cartId: string) => MemoizedSelector<StateWithMultiCart, boolean>;
declare const getCartHasPendingProcessesSelectorFactory: (cartId: string) => MemoizedSelector<StateWithMultiCart, boolean>;
declare const getCartEntriesSelectorFactory: (cartId: string) => MemoizedSelector<StateWithMultiCart, OrderEntry[]>;
declare const getCartEntrySelectorFactory: (cartId: string, productCode: string) => MemoizedSelector<StateWithMultiCart, OrderEntry | undefined>;
declare const getCartsSelectorFactory: MemoizedSelector<StateWithMultiCart, Cart[]>;
declare const getCartTypeIndex: MemoizedSelector<StateWithMultiCart, {
    [cartType: string]: string;
}>;
declare const getCartIdByTypeFactory: (type: string) => MemoizedSelector<StateWithMultiCart, string>;

declare const multiCartGroup_selectors_d_getCartEntitySelectorFactory: typeof getCartEntitySelectorFactory;
declare const multiCartGroup_selectors_d_getCartEntriesSelectorFactory: typeof getCartEntriesSelectorFactory;
declare const multiCartGroup_selectors_d_getCartEntrySelectorFactory: typeof getCartEntrySelectorFactory;
declare const multiCartGroup_selectors_d_getCartHasPendingProcessesSelectorFactory: typeof getCartHasPendingProcessesSelectorFactory;
declare const multiCartGroup_selectors_d_getCartIdByTypeFactory: typeof getCartIdByTypeFactory;
declare const multiCartGroup_selectors_d_getCartIsStableSelectorFactory: typeof getCartIsStableSelectorFactory;
declare const multiCartGroup_selectors_d_getCartSelectorFactory: typeof getCartSelectorFactory;
declare const multiCartGroup_selectors_d_getCartTypeIndex: typeof getCartTypeIndex;
declare const multiCartGroup_selectors_d_getCartsSelectorFactory: typeof getCartsSelectorFactory;
declare const multiCartGroup_selectors_d_getMultiCartEntities: typeof getMultiCartEntities;
declare const multiCartGroup_selectors_d_getMultiCartState: typeof getMultiCartState;
declare namespace multiCartGroup_selectors_d {
  export {
    multiCartGroup_selectors_d_getCartEntitySelectorFactory as getCartEntitySelectorFactory,
    multiCartGroup_selectors_d_getCartEntriesSelectorFactory as getCartEntriesSelectorFactory,
    multiCartGroup_selectors_d_getCartEntrySelectorFactory as getCartEntrySelectorFactory,
    multiCartGroup_selectors_d_getCartHasPendingProcessesSelectorFactory as getCartHasPendingProcessesSelectorFactory,
    multiCartGroup_selectors_d_getCartIdByTypeFactory as getCartIdByTypeFactory,
    multiCartGroup_selectors_d_getCartIsStableSelectorFactory as getCartIsStableSelectorFactory,
    multiCartGroup_selectors_d_getCartSelectorFactory as getCartSelectorFactory,
    multiCartGroup_selectors_d_getCartTypeIndex as getCartTypeIndex,
    multiCartGroup_selectors_d_getCartsSelectorFactory as getCartsSelectorFactory,
    multiCartGroup_selectors_d_getMultiCartEntities as getMultiCartEntities,
    multiCartGroup_selectors_d_getMultiCartState as getMultiCartState,
  };
}

/**
 * Extract cart identifier for current user. Anonymous calls use `guid` and for logged users `code` is used.
 */
declare function getCartIdByUserId(cart?: Cart, userId?: string): string;
/**
 * Check if cart is selective (save for later) based on id.
 */
declare function isSelectiveCart(cartId?: string): boolean;
/**
 * Check if the returned error is of type notFound.
 *
 * We additionally check if the cart is not a selective cart.
 * For selective cart this error can happen only when extension is disabled.
 * It should never happen, because in that case, selective cart should also be disabled in our configuration.
 * However if that happens we want to handle these errors silently.
 */
declare function isCartNotFoundError(error: ErrorModel): boolean;
declare function voucherExceededError(error: ErrorModel): boolean;
declare function voucherInvalidError(error: ErrorModel): boolean;
declare function isVoucherError(error: ErrorModel): boolean;
declare function isCartError(error: ErrorModel): boolean;
/**
 * What is a temporary cart?
 * - frontend only cart entity!
 * - can be identified in store by `temp-` prefix with some unique id (multiple carts can be created at the same time eg. active cart, wishlist)
 *
 * Why we need temporary carts?
 * - to have information about cart creation process (meta flags: loading, error - for showing loader, error message)
 * - to know if there is currently a cart creation process in progress (eg. so, we don't create more than one active cart at the same time)
 * - cart identifiers are created in the backend, so those are only known after cart is created
 *
 * Temporary cart life cycle
 * - create cart method invoked
 * - new `temp-${uuid}` cart is created with `loading=true` state
 * - backend returns created cart
 * - normal cart entity is saved under correct id (eg. for logged user under cart `code` key)
 * - temporary cart value is set to backend response (anyone observing this cart can read code/guid from it and switch selector to normal cart)
 * - in next tick temporary cart is removed
 */
declare function isTempCartId(cartId: string): boolean;
/**
 * Indicates if given cart is empty.
 * Returns true is cart is undefined, null or is an empty object.
 */
declare function isEmpty(cart?: Cart): boolean;
/**
 * Indicates if given string is matching email pattern
 */
declare function isEmail(str?: string): boolean;
/**
 * Indicates if a given user is logged in on account different than preceding user account
 */
declare function isJustLoggedIn(userId: string, previousUserId: string): boolean;

export { ADD_VOUCHER_PROCESS_ID, ActiveCartService, CART_ACCESS_CODE_NORMALIZER, CART_GUEST_USER_NORMALIZER, CART_VALIDATION_NORMALIZER, CartAccessCodeAdapter, CartAccessCodeConnector, CartAccessCodeService, cartGroup_actions_d as CartActions, CartAdapter, CartBaseCoreModule, CartConfigService, CartConnector, CartEntryAdapter, CartEntryConnector, CartEventBuilder, CartEventModule, CartGuestUserAdapter, CartGuestUserConnector, CartGuestUserService, CartPageEventBuilder, CartPageEventModule, CartPersistenceModule, CartValidationAdapter, CartValidationConnector, CartValidationGuard, CartValidationService, CartValidationStateService, CartVoucherAdapter, CartVoucherConnector, CartVoucherService, MULTI_CART_DATA, MULTI_CART_FEATURE, MultiCartEffectsService, multiCartGroup_selectors_d as MultiCartSelectors, MultiCartService, MultiCartStatePersistenceService, ProductImportInfoService, SelectiveCartService, cartStatePersistenceFactory, getCartIdByUserId, isCartError, isCartNotFoundError, isEmail, isEmpty, isJustLoggedIn, isSelectiveCart, isTempCartId, isVoucherError, uninitializeActiveCartMetaReducerFactory, voucherExceededError, voucherInvalidError };
export type { MultiCartState, StateWithMultiCart };
