import * as i0 from '@angular/core';
import { OnDestroy, ElementRef, InjectionToken } from '@angular/core';
import { Promotion, Price, Currency, CostCenter, Address, PointOfService, Product, PaymentDetails, Principal, StateUtils, EventService, CxEvent, User, Converter } from '@spartacus/core';
import { Observable, Subscription } from 'rxjs';
import * as i2 from '@angular/router';
import { PageEvent } from '@spartacus/storefront';
import { UntypedFormControl } from '@angular/forms';

interface PromotionResult {
    consumedEntries?: PromotionOrderEntryConsumed[];
    description?: string;
    promotion?: Promotion;
}
declare enum PromotionLocation {
    ActiveCart = "CART",
    Checkout = "CHECKOUT",
    Order = "ORDER",
    SaveForLater = "SAVE_FOR_LATER",
    SavedCart = "SAVED_CART"
}
interface Voucher {
    appliedValue?: Price;
    code?: string;
    currency?: Currency;
    description?: string;
    freeShipping?: boolean;
    name?: string;
    value?: number;
    valueFormatted?: string;
    valueString?: string;
    voucherCode?: string;
}
interface DeliveryOrderEntryGroup {
    deliveryAddress?: Address;
    entries?: OrderEntry[];
    quantity?: number;
    totalPriceWithTax?: Price;
}
interface PaymentType {
    code?: string;
    displayName?: string;
}
interface SaveCartResult {
    savedCartData?: Cart;
}
interface Cart {
    appliedOrderPromotions?: PromotionResult[];
    appliedProductPromotions?: PromotionResult[];
    appliedVouchers?: Voucher[];
    calculated?: boolean;
    code?: string;
    costCenter?: CostCenter;
    deliveryAddress?: Address;
    deliveryCost?: Price;
    deliveryItemsQuantity?: number;
    deliveryMode?: DeliveryMode;
    deliveryOrderGroups?: DeliveryOrderEntryGroup[];
    description?: string;
    entries?: OrderEntry[];
    expirationTime?: Date;
    guid?: string;
    name?: string;
    net?: boolean;
    orderDiscounts?: Price;
    paymentInfo?: PaymentDetails;
    paymentType?: PaymentType;
    paymentAddress?: Address;
    sapBillingAddress?: Address;
    pickupItemsQuantity?: number;
    pickupOrderGroups?: PickupOrderEntryGroup[];
    potentialOrderPromotions?: PromotionResult[];
    potentialProductPromotions?: PromotionResult[];
    productDiscounts?: Price;
    purchaseOrderNumber?: string;
    saveTime?: Date;
    savedBy?: Principal;
    site?: string;
    store?: string;
    subTotal?: Price;
    totalDiscounts?: Price;
    totalItems?: number;
    totalPrice?: Price;
    totalPriceWithTax?: Price;
    totalTax?: Price;
    totalUnitCount?: number;
    user?: Principal;
    quoteCode?: string;
    quotePurchaseOrderNumber?: string;
}
interface CartModification {
    deliveryModeChanged?: boolean;
    entry?: OrderEntry;
    quantity?: number;
    quantityAdded?: number;
    statusCode?: string;
    statusMessage?: string;
}
interface CartItemComponentOptions {
    isSaveForLater?: boolean;
    optionalBtn?: any;
    displayAddToCart?: boolean;
    addToCartString?: string;
    cartType?: CartType;
    disableItemLink?: boolean;
}
/**
 * A key that identifies an 'abstract order', that in OO terms can be understood
 * as a common super class of cart, saved cart, order and quote.
 *
 * The attribute `id` is absent for the Cart type, because there exists only one active cart
 * which can be identified as the `current` one.
 * For the other types (SavedCart, Order and Quote) the attribute `id` is mandatory
 * in order to identify the abstract order.
 */
type AbstractOrderKey = {
    type: AbstractOrderType.CART;
} | {
    type: AbstractOrderType.ORDER;
    id: string;
} | {
    type: AbstractOrderType.QUOTE;
    id: string;
} | {
    type: AbstractOrderType.SAVED_CART;
    id: string;
};
/**
 * The possible types of 'abstract orders'.
 */
declare enum AbstractOrderType {
    /**
     * Active cart
     */
    CART = "Cart",
    ORDER = "Order",
    QUOTE = "Quote",
    SAVED_CART = "SavedCart"
}
interface OrderEntry {
    orderCode?: string;
    basePrice?: Price;
    deliveryMode?: DeliveryMode;
    deliveryPointOfService?: PointOfService;
    entryNumber?: number;
    product?: Product;
    quantity?: number;
    totalPrice?: Price;
    updateable?: boolean;
    returnedItemsPrice?: Price;
    returnableQuantity?: number;
    cancelledItemsPrice?: Price;
    cancellableQuantity?: number;
    promotions?: PromotionResult[];
}
interface PickupOrderEntryGroup {
    deliveryPointOfService?: PointOfService;
    distance?: number;
    entries?: OrderEntry[];
    quantity?: number;
    totalPriceWithTax?: Price;
}
interface PromotionOrderEntryConsumed {
    adjustedUnitPrice?: number;
    code?: string;
    orderEntryNumber?: number;
    quantity?: number;
}
interface ConsignmentEntry {
    orderEntry?: OrderEntry;
    quantity?: number;
    shippedQuantity?: number;
}
interface DeliveryMode {
    code?: string;
    deliveryCost?: Price;
    description?: string;
    name?: string;
}
declare enum CartType {
    ACTIVE = "Active",
    WISH_LIST = "WishList",
    SELECTIVE = "Selective",
    NEW_CREATED = "NewCreated"
}
interface CartModificationList {
    cartModifications?: CartModification[];
}
declare enum CartValidationStatusCode {
    NO_STOCK = "noStock",
    LOW_STOCK = "lowStock",
    REVIEW_CONFIGURATION = "reviewConfiguration",
    PRICING_ERROR = "pricingError",
    UNRESOLVABLE_ISSUES = "unresolvableIssues"
}

declare abstract class MultiCartFacade {
    /**
     * Returns cart from store as an observable
     *
     * @param cartId
     */
    abstract getCart(cartId: string): Observable<Cart>;
    /**
     * Returns a list of carts from store as an observable
     *
     */
    abstract getCarts(): Observable<Cart[]>;
    /**
     * Returns cart entity from store (cart with loading, error, success flags) as an observable
     *
     * @param cartId
     */
    abstract getCartEntity(cartId: string): Observable<StateUtils.ProcessesLoaderState<Cart | undefined>>;
    /**
     * Returns true when there are no operations on that in progress and it is not currently loading
     *
     * @param cartId
     */
    abstract isStable(cartId: string): Observable<boolean>;
    /**
     * Create or merge cart
     *
     * @param params Object with userId, oldCartId, toMergeCartGuid and extraData
     */
    abstract createCart({ userId, oldCartId, toMergeCartGuid, extraData, }: {
        userId: string;
        oldCartId?: string;
        toMergeCartGuid?: string;
        extraData?: {
            active?: boolean;
        };
    }): Observable<Cart>;
    /**
     * Merge provided cart to current user cart
     *
     * @param params Object with userId, cartId and extraData
     */
    abstract mergeToCurrentCart({ userId, cartId, extraData, }: {
        userId: string;
        cartId: string;
        extraData?: {
            active?: boolean;
        };
    }): void;
    /**
     * Load cart
     *
     * @param params Object with userId, cartId and extraData
     */
    abstract loadCart({ cartId, userId, extraData, }: {
        cartId: string;
        userId: string;
        extraData?: any;
    }): void;
    /**
     * Get cart entries as an observable
     * @param cartId
     */
    abstract getEntries(cartId: string): Observable<OrderEntry[]>;
    /**
     * Get last entry for specific product code from cart.
     * Needed to cover processes where multiple entries can share the same product code
     * (e.g. promotions or configurable products)
     *
     * @param cartId
     * @param productCode
     */
    abstract getLastEntry(cartId: string, productCode: string): Observable<OrderEntry | undefined>;
    /**
     * Add entry to cart
     *
     * @param userId
     * @param cartId
     * @param productCode
     * @param quantity
     * @param pickupStore
     */
    abstract addEntry(userId: string, cartId: string, productCode: string, quantity: number, pickupStore?: string): void;
    /**
     * Add multiple entries to cart
     *
     * @param userId
     * @param cartId
     * @param products Array with items (productCode and quantity)
     */
    abstract addEntries(userId: string, cartId: string, products: Array<{
        productCode: string;
        quantity: number;
    }>): void;
    /**
     * Remove entry from cart
     *
     * @param userId
     * @param cartId
     * @param entryNumber
     */
    abstract removeEntry(userId: string, cartId: string, entryNumber: number): void;
    /**
     * Update entry in cart. For quantity = 0 it removes entry
     *
     * @param userId
     * @param cartId
     * @param entryNumber
     * @param quantity
     */
    abstract updateEntry(userId: string, cartId: string, entryNumber: number, quantity?: number, pickupStore?: string, pickupToDelivery?: boolean): void;
    /**
     * Get first entry from cart matching the specified product code
     *
     * @param cartId
     * @param productCode
     */
    abstract getEntry(cartId: string, productCode: string): Observable<OrderEntry | undefined>;
    /**
     * Assign email to the cart
     *
     * @param cartId
     * @param userId
     * @param email
     */
    abstract assignEmail(cartId: string, userId: string, email: string): void;
    /**
     * Remove cart
     *
     * Removes the cart from the state.
     * To remove a cart from the state and back-end, please use `DeleteCart` action.
     *
     * @param cartId
     */
    abstract removeCart(cartId: string): void;
    /**
     * Delete cart
     *
     * @param cartId
     * @param userId
     */
    abstract deleteCart(cartId: string, userId: string): void;
    /**
     * Reloads the cart with specified id.
     *
     * @param cartId
     * @param extraData
     */
    abstract reloadCart(cartId: string, extraData?: {
        active: boolean;
    }): void;
    /**
     * Get the cart id based on cart type
     *
     * @param cartType
     */
    abstract getCartIdByType(cartType: CartType): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiCartFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MultiCartFacade>;
}

declare class MultiCartEventListener implements OnDestroy {
    protected eventService: EventService;
    protected multiCartFacade: MultiCartFacade;
    protected subscriptions: Subscription;
    constructor(eventService: EventService, multiCartFacade: MultiCartFacade);
    /**
     * Registers events for the cart base actions.
     */
    protected onCartBaseAction(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiCartEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MultiCartEventListener>;
}

declare class CartBaseEventModule {
    constructor(_multiCartEventListener: MultiCartEventListener);
    static ɵfac: i0.ɵɵFactoryDeclaration<CartBaseEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartBaseEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartBaseEventModule>;
}

declare function defaultCartComponentsConfig(): {
    featureModules: {
        cartBase: {
            cmsComponents: string[];
        };
        miniCart: {
            cmsComponents: string[];
        };
        addToCart: {
            cmsComponents: string[];
        };
        cartBaseCore: string;
    };
};
declare class CartBaseRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CartBaseRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartBaseRootModule, never, [typeof CartBaseEventModule, typeof i2.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartBaseRootModule>;
}

declare abstract class CartConfig {
    cart?: {
        selectiveCart?: {
            enabled?: boolean;
        };
        validation?: {
            enabled?: boolean;
        };
        showRealTimeStockInPDP?: {
            enabled?: boolean;
        };
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<CartConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartConfig>;
}
declare module '@spartacus/core' {
    interface Config extends CartConfig {
    }
}

declare enum OrderEntriesSource {
    ACTIVE_CART = "ACTIVE_CART",
    NEW_SAVED_CART = "NEW_SAVED_CART",
    QUICK_ORDER = "QUICK_ORDER",
    SAVED_CART = "SAVED_CART",
    ORDER_CONFIRMATION = "ORDER_CONFIRMATION",
    ORDER_DETAILS = "ORDER_DETAILS",
    UNIT_ORDER_DETAILS = "UNIT_ORDER_DETAILS"
}

type ProductData = {
    productCode: string;
    quantity: number;
};
declare enum ProductImportStatus {
    SUCCESS = "success",
    LOW_STOCK = "lowStock",
    NO_STOCK = "noStock",
    UNKNOWN_IDENTIFIER = "unknownIdentifier",
    UNKNOWN_ERROR = "unknownError",
    LIMIT_EXCEEDED = "limitExceeded"
}
interface ProductImportInfo {
    productCode: string;
    statusCode: ProductImportStatus;
    productName?: string;
    quantity?: number;
    quantityAdded?: number;
}
interface ProductImportSummary {
    loading: boolean;
    cartName: string | undefined;
    count: number;
    total: number;
    successesCount: number;
    warningMessages: ProductImportInfo[];
    errorMessages: ProductImportInfo[];
}

/**
 * An interface for context which determinate import products destination
 */
interface AddOrderEntriesContext {
    /**
     * Designates the type of cart that we handle in the context.
     * It allows for recognize used service in better way than instanceof - will works also with overridden services.
     */
    readonly type: OrderEntriesSource;
    /**
     * Process products data to import destination.
     *
     * @param { ProductData[] } products
     * @param {{ name: string; description: string }} [savedCartInfo] information necessary to create new saved cart
     * @returns {Observable<ProductImportInfo>} information for summary
     */
    addEntries(products: ProductData[], savedCartInfo?: {
        name: string;
        description: string;
    }): Observable<ProductImportInfo>;
}

/**
 * An interface for context which determinate export products source
 */
interface GetOrderEntriesContext {
    /**
     * Retrieve order entries from context source for export action.
     *
     * @returns {Observable<OrderEntry[]>}
     */
    getEntries(): Observable<OrderEntry[]>;
}

declare const ORDER_ENTRIES_CONTEXT: unique symbol;
type OrderEntriesContext = Partial<AddOrderEntriesContext & GetOrderEntriesContext>;

/**
 * Indicates that a user visited a cart page.
 */
declare class CartPageEvent extends PageEvent {
    /** event's type */
    static readonly type = "CartPageEvent";
}

/**
 * Base cart event. Most cart events should have these properties.
 */
declare abstract class CartEvent extends CxEvent {
    /**
     * Usually set via `getCartIdByUserId()` util method,
     * It is an abstraction over the different properties
     * used for anonymous and logged-in users' carts:
     * - `code` for logged-in users
     * - `guid` for anonymous users
     */
    cartId: string;
    /**
     * All carts have the `code` property assigned to them,
     * regardless of whether they are anonymous or logged-in.
     * In case of logged-in users, the `cartCode` and `cartId` are the same.
     */
    cartCode: string;
    /**
     * User ID.
     */
    userId: string;
}
declare class CreateCartEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type = "CreateCartEvent";
}
declare class CreateCartSuccessEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type = "CreateCartSuccessEvent";
}
declare class CreateCartFailEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type = "CreateCartFailEvent";
    error: any;
}
declare class CartAddEntryEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type = "CartAddEntryEvent";
    productCode: string;
    quantity: number;
}
declare class CartAddEntrySuccessEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type = "CartAddEntrySuccessEvent";
    productCode: string;
    quantity: number;
    entry?: OrderEntry;
    quantityAdded?: number;
    deliveryModeChanged?: boolean;
}
declare class CartAddEntryFailEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type = "CartAddEntryFailEvent";
    productCode: string;
    quantity: number;
    error?: unknown;
}
declare class CartRemoveEntryFailEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type = "CartRemoveEntryFailEvent";
    entry: OrderEntry;
}
declare class CartRemoveEntrySuccessEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type = "CartRemoveEntrySuccessEvent";
    entry: OrderEntry;
}
declare class CartUpdateEntrySuccessEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type = "CartUpdateEntrySuccessEvent";
    quantity: number;
    entry: OrderEntry;
}
declare class CartUpdateEntryFailEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type = "CartUpdateEntryFailEvent";
    quantity: number;
    entry: OrderEntry;
}
declare class CartUiEventAddToCart extends CxEvent {
    /**
     * Event's type
     */
    static readonly type = "CartUiEventAddToCart";
    productCode: string;
    quantity: number;
    numberOfEntriesBeforeAdd: number;
    pickupStoreName?: string;
    /**
     * Since the event can be used to open a dialog, we need to know which element triggered it.
     * This way we can refocus on it after the dialog is closed.
     */
    triggerElementRef?: ElementRef;
}
/**
 * Fired when the cart has been successfully merged.
 */
declare class MergeCartSuccessEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type = "MergeCartSuccessEvent";
    /**
     * MergeCart actions triggers CreateCart which requires this parameter, so that's why it is required.
     */
    tempCartId: string;
    /**
     * Previous cart id which was merged with new/user cart.
     * Needed to know which obsolete entity should be removed.
     */
    oldCartId?: string;
    /** Extra data */
    extraData?: {
        active?: boolean;
    };
}
/**
 * Triggers the loading of the cart.
 */
declare class LoadCartEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type = "LoadCartEvent";
}
/** Removes the cart. */
declare class RemoveCartEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type = "RemoveCartEvent";
}
/**
 * Fired when the cart has been deleted.
 */
declare class DeleteCartEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type = "DeleteCartEvent";
}
declare class DeleteCartSuccessEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type = "DeleteCartSuccessEvent";
}
declare class DeleteCartFailEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type = "DeleteCartFailEvent";
}
declare class AddCartVoucherEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type: string;
    voucherId: string;
}
declare class AddCartVoucherSuccessEvent extends AddCartVoucherEvent {
    /**
     * Event's type
     */
    static readonly type = "AddCartVoucherSuccessEvent";
}
declare class AddCartVoucherFailEvent extends AddCartVoucherEvent {
    /**
     * Event's type
     */
    static readonly type = "AddCartVoucherFailEvent";
    error: unknown;
}
declare class RemoveCartVoucherEvent extends CartEvent {
    /**
     * Event's type
     */
    static readonly type: string;
    voucherId: string;
}
declare class RemoveCartVoucherSuccessEvent extends RemoveCartVoucherEvent {
    /**
     * Event's type
     */
    static readonly type: string;
}
declare class RemoveCartVoucherFailEvent extends RemoveCartVoucherEvent {
    /**
     * Event's type
     */
    static readonly type = "RemoveCartVoucherFailEvent";
    error: unknown;
}

declare abstract class ActiveCartFacade {
    /**
     * Returns active cart
     */
    abstract getActive(): Observable<Cart>;
    /**
     * Waits for the cart to be stable before returning the active cart.
     */
    abstract takeActive(): Observable<Cart>;
    /**
     * Returns active cart id
     */
    abstract getActiveCartId(): Observable<string>;
    /**
     * Waits for the cart to be stable before returning the active cart's ID.
     */
    abstract takeActiveCartId(): Observable<string>;
    /**
     * Returns cart entries
     */
    abstract getEntries(): Observable<OrderEntry[]>;
    /**
     * Returns last cart entry for provided product code.
     * Needed to cover processes where multiple entries can share the same product code
     * (e.g. promotions or configurable products)
     *
     * @param productCode
     */
    abstract getLastEntry(productCode: string): Observable<OrderEntry | undefined>;
    /**
     * Returns cart loading state
     */
    abstract getLoading(): Observable<boolean>;
    /**
     * Returns true when cart is stable (not loading and not pending processes on cart)
     */
    abstract isStable(): Observable<boolean>;
    /**
     * Add entry to active cart
     *
     * @param productCode
     * @param quantity
     * @param pickupStore
     */
    abstract addEntry(productCode: string, quantity: number, pickupStore?: string): void;
    /**
     * Remove entry
     *
     * @param entry
     */
    abstract removeEntry(entry: OrderEntry): void;
    /**
     * Update entry
     *
     * @param entryNumber
     * @param quantity
     * @param pickupStore
     * @param pickupToDelivery
     */
    abstract updateEntry(entryNumber: number, quantity: number, pickupStore?: string, pickupToDelivery?: boolean): void;
    /**
     * Returns cart entry
     *
     * @param productCode
     */
    abstract getEntry(productCode: string): Observable<OrderEntry | undefined>;
    /**
     * Assign email to cart
     *
     * @param email
     */
    abstract addEmail(email: string): void;
    /**
     * Get assigned user to cart
     */
    abstract getAssignedUser(): Observable<User>;
    /**
     * Returns observable of true for guest cart
     */
    abstract isGuestCart(cart?: Cart): Observable<boolean>;
    /**
     * Add multiple entries to a cart
     *
     * @param cartEntries : list of entries to add (OrderEntry[])
     */
    abstract addEntries(cartEntries: OrderEntry[]): void;
    abstract requireLoadedCart(forGuestMerge?: boolean): Observable<Cart>;
    abstract reloadActiveCart(): void;
    /**
     * Return whether cart has pickup items
     */
    abstract hasPickupItems(): Observable<boolean>;
    /**
     * Return whether cart has delivery items
     */
    abstract hasDeliveryItems(): Observable<boolean>;
    /**
     * Return cart's pickup entries
     */
    abstract getPickupEntries(): Observable<OrderEntry[]>;
    /**
     * Return cart's delivery entries
     */
    abstract getDeliveryEntries(): Observable<OrderEntry[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActiveCartFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ActiveCartFacade>;
}

declare abstract class CartAccessCodeFacade {
    /**
     * Generates an access code for a specified cart.
     */
    abstract getCartAccessCode(userId: string, cartId: string): Observable<string | undefined | any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartAccessCodeFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartAccessCodeFacade>;
}

declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        CLEAR_CART = "CLEAR_CART",
        ADDED_TO_CART = "ADDED_TO_CART"
    }
}

interface CartGuestUser {
    email?: string;
}

/**
 * Context for `CartItemComponent`.
 */
declare abstract class CartItemContext {
    readonly compact$: Observable<boolean>;
    readonly readonly$: Observable<boolean>;
    readonly item$: Observable<OrderEntry>;
    readonly quantityControl$: Observable<UntypedFormControl>;
    readonly location$: Observable<PromotionLocation>;
    readonly options$: Observable<CartItemComponentOptions>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartItemContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartItemContext>;
}

/**
 * Identifiers of outlets inside the cart details view.
 */
declare enum CartOutlets {
    ITEM = "cx-cart-item",
    LIST_ITEM = "cx-cart-item-list-row",
    ITEM_DETAILS = "cx-cart-item.details",
    ITEM_CONFIGURATOR_ISSUES = "cx-configurator-issues-notification",
    ITEM_BUNDLE_DETAILS = "cx-cart-item.bundle-details",
    ITEM_DELIVERY_DETAILS = "cx-cart-item.delivery-details",
    ORDER_SUMMARY = "cx-order-summary",
    CART_ITEM_LIST = "cx-cart-item-list",
    ADD_TO_CART_CONTAINER = "cx-add-to-cart-container",
    PICKUP_INFO = "cx-pickup-info",
    ADD_TO_CART_PICKUP_OPTION = "cx-add-to-cart-pickup-option",
    DELIVERY_MODE = "cx-delivery-mode",
    ORDER_OVERVIEW = "cx-order-overview",
    CPQ_QUOTE_MODULE = "cx-cpq-quote",
    CPQ_QUOTE_HEADING = "cx-cpq-quote-heading",
    CPQ_QUOTE = "cx-cpq-quote-offer",
    SUBSCRIPTION_PRICE_HEADING = "cx-subscription-cart-price-heading",
    SUBSCRIPTION_PRICE_BODY = "cx-subscription-cart-price-body",
    ORDER_DETAILS_AFTER_PAYMENT_METHOD = "cx-order-details-payment-method-details"
}

declare abstract class CartGuestUserFacade {
    /**
     * Creates guest user and assigns user to the cart.
     */
    abstract createCartGuestUser(userId: string, cartId: string, guestUserDetails?: CartGuestUser): Observable<CartGuestUser>;
    /**
     * Updates guest user details.
     */
    abstract updateCartGuestUser(userId: string, cartId: string, guestUserDetails: CartGuestUser): Observable<CartGuestUser>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartGuestUserFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartGuestUserFacade>;
}

declare abstract class CartValidationFacade {
    /**
     * Validates cart, and returns cart modification list.
     */
    abstract validateCart(): Observable<CartModificationList>;
    /**
     * Returns cart modification results
     */
    abstract getValidationResults(): Observable<CartModification[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartValidationFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartValidationFacade>;
}

declare abstract class CartVoucherFacade {
    abstract addVoucher(voucherId: string, cartId?: string): void;
    abstract removeVoucher(voucherId: string, cartId?: string): void;
    /**
     * Get add voucher process error flag
     */
    abstract getAddVoucherResultError(): Observable<boolean>;
    /**
     * Get add voucher process success flag
     */
    abstract getAddVoucherResultSuccess(): Observable<boolean>;
    /**
     * Get add voucher process loading flag
     */
    abstract getAddVoucherResultLoading(): Observable<boolean>;
    /**
     * Reset add voucher process
     */
    abstract resetAddVoucherProcessingState(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartVoucherFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CartVoucherFacade>;
}

declare abstract class SelectiveCartFacade {
    abstract getCart(): Observable<Cart>;
    abstract getEntries(): Observable<OrderEntry[]>;
    /**
     * Returns true when selective cart is stable (not loading and not pending processes on cart)
     */
    abstract isStable(): Observable<boolean>;
    abstract addEntry(productCode: string, quantity: number): void;
    abstract removeEntry(entry: OrderEntry): void;
    abstract updateEntry(entryNumber: number, quantity: number): void;
    abstract getEntry(productCode: string): Observable<OrderEntry | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectiveCartFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SelectiveCartFacade>;
}

declare const CART_BASE_FEATURE = "cartBase";
declare const CART_BASE_CORE_FEATURE = "cartBaseCore";
declare const MINI_CART_FEATURE = "miniCart";
declare const ADD_TO_CART_FEATURE = "addToCart";

declare const ActiveCartOrderEntriesContextToken: InjectionToken<unknown>;

declare const CART_NORMALIZER: InjectionToken<Converter<any, Cart>>;
declare const ORDER_ENTRY_PROMOTIONS_NORMALIZER: InjectionToken<Converter<any, PromotionResult[]>>;
declare const CART_MODIFICATION_NORMALIZER: InjectionToken<Converter<any, CartModification>>;
declare const SAVE_CART_NORMALIZER: InjectionToken<Converter<any, SaveCartResult>>;
declare const CART_VOUCHER_NORMALIZER: InjectionToken<Converter<any, Voucher>>;

export { ADD_TO_CART_FEATURE, AbstractOrderType, ActiveCartFacade, ActiveCartOrderEntriesContextToken, AddCartVoucherEvent, AddCartVoucherFailEvent, AddCartVoucherSuccessEvent, CART_BASE_CORE_FEATURE, CART_BASE_FEATURE, CART_MODIFICATION_NORMALIZER, CART_NORMALIZER, CART_VOUCHER_NORMALIZER, CartAccessCodeFacade, CartAddEntryEvent, CartAddEntryFailEvent, CartAddEntrySuccessEvent, CartBaseEventModule, CartBaseRootModule, CartConfig, CartEvent, CartGuestUserFacade, CartItemContext, CartOutlets, CartPageEvent, CartRemoveEntryFailEvent, CartRemoveEntrySuccessEvent, CartType, CartUiEventAddToCart, CartUpdateEntryFailEvent, CartUpdateEntrySuccessEvent, CartValidationFacade, CartValidationStatusCode, CartVoucherFacade, CreateCartEvent, CreateCartFailEvent, CreateCartSuccessEvent, DeleteCartEvent, DeleteCartFailEvent, DeleteCartSuccessEvent, LoadCartEvent, MINI_CART_FEATURE, MergeCartSuccessEvent, MultiCartEventListener, MultiCartFacade, ORDER_ENTRIES_CONTEXT, ORDER_ENTRY_PROMOTIONS_NORMALIZER, OrderEntriesSource, ProductImportStatus, PromotionLocation, RemoveCartEvent, RemoveCartVoucherEvent, RemoveCartVoucherFailEvent, RemoveCartVoucherSuccessEvent, SAVE_CART_NORMALIZER, SelectiveCartFacade, defaultCartComponentsConfig };
export type { AbstractOrderKey, AddOrderEntriesContext, Cart, CartGuestUser, CartItemComponentOptions, CartModification, CartModificationList, ConsignmentEntry, DeliveryMode, DeliveryOrderEntryGroup, GetOrderEntriesContext, OrderEntriesContext, OrderEntry, PaymentType, PickupOrderEntryGroup, ProductData, ProductImportInfo, ProductImportSummary, PromotionOrderEntryConsumed, PromotionResult, SaveCartResult, Voucher };
