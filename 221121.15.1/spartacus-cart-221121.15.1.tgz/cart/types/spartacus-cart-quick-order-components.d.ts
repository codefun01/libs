import * as i0 from '@angular/core';
import { OnInit, OnDestroy, ChangeDetectorRef, ElementRef } from '@angular/core';
import * as i2 from '@angular/forms';
import { UntypedFormBuilder, UntypedFormGroup, UntypedFormControl } from '@angular/forms';
import { ActiveCartFacade, Cart, AddOrderEntriesContext, GetOrderEntriesContext, OrderEntriesSource, OrderEntry, ProductData, ProductImportInfo } from '@spartacus/cart/base/root';
import * as i3 from '@spartacus/core';
import { EventService, GlobalMessageService, ProductConnector, LoggerService, Product, Config, WindowRef, GlobalMessageType } from '@spartacus/core';
import { Observable, Subscription, BehaviorSubject } from 'rxjs';
import * as i1 from '@angular/common';
import * as i1$1 from '@spartacus/storefront';
import { ICON_TYPE, CmsComponentData } from '@spartacus/storefront';
import { HttpErrorResponse } from '@angular/common/http';
import { QuickOrderFacade, QuickOrderAddEntryEvent } from '@spartacus/cart/quick-order/root';
import * as i5 from '@angular/router';
import { CmsQuickOrderComponent, QuickOrderStatePersistenceService } from '@spartacus/cart/quick-order/core';

declare class CartQuickOrderFormComponent implements OnInit, OnDestroy {
    protected activeCartService: ActiveCartFacade;
    protected eventService: EventService;
    protected formBuilder: UntypedFormBuilder;
    protected globalMessageService: GlobalMessageService;
    quickOrderForm: UntypedFormGroup;
    cartIsLoading$: Observable<boolean>;
    cart$: Observable<Cart>;
    min: number;
    protected subscription: Subscription;
    protected cartEventsSubscription: Subscription;
    protected minQuantityValue: number;
    private featureConfigService;
    constructor(activeCartService: ActiveCartFacade, eventService: EventService, formBuilder: UntypedFormBuilder, globalMessageService: GlobalMessageService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    applyQuickOrder(): void;
    protected buildForm(): void;
    protected watchQuantityChange(): void;
    protected watchAddEntrySuccessEvent(): void;
    protected getValidCount(value: number): number;
    protected resetForm(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartQuickOrderFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CartQuickOrderFormComponent, "cx-cart-quick-order-form", never, {}, {}, never, never, true, never>;
}

declare class CartQuickOrderFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CartQuickOrderFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartQuickOrderFormModule, never, [typeof i1.CommonModule, typeof i2.ReactiveFormsModule, typeof i3.I18nModule, typeof i1$1.FormErrorsModule, typeof i3.FeaturesConfigModule, typeof i1$1.FormRequiredAsterisksComponent, typeof i1$1.FormRequiredLegendComponent, typeof CartQuickOrderFormComponent], [typeof CartQuickOrderFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartQuickOrderFormModule>;
}

declare class QuickOrderOrderEntriesContext implements AddOrderEntriesContext, GetOrderEntriesContext {
    protected quickOrderService: QuickOrderFacade;
    protected productConnector: ProductConnector;
    readonly type = OrderEntriesSource.QUICK_ORDER;
    protected logger: LoggerService;
    constructor(quickOrderService: QuickOrderFacade, productConnector: ProductConnector);
    getEntries(): Observable<OrderEntry[]>;
    addEntries(productsData: ProductData[]): Observable<ProductImportInfo>;
    protected handleResults(product: Product, productData: ProductData): ProductImportInfo;
    protected handleErrors(response: HttpErrorResponse, productCode: string): ProductImportInfo;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuickOrderOrderEntriesContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuickOrderOrderEntriesContext>;
}

declare class QuickOrderFormComponent implements OnInit, OnDestroy {
    config: Config;
    protected cd: ChangeDetectorRef;
    protected quickOrderService: QuickOrderFacade;
    protected winRef: WindowRef;
    form: UntypedFormGroup;
    iconTypes: typeof ICON_TYPE;
    isSearching: boolean;
    noResults: boolean;
    results: Product[];
    limit: number;
    quickOrderInput: ElementRef;
    protected subscription: Subscription;
    protected searchSubscription: Subscription;
    private featureToggles;
    constructor(config: Config, cd: ChangeDetectorRef, quickOrderService: QuickOrderFacade, winRef: WindowRef);
    ngOnInit(): void;
    onBlur(event: UIEvent): void;
    clear(event?: Event): void;
    add(product: Product, event: Event): void;
    addProduct(event: Event): void;
    focusNextChild(event: UIEvent): void;
    focusPreviousChild(event: UIEvent): void;
    isResultsBoxOpen(): boolean;
    canAddProduct(): Observable<boolean>;
    open(): void;
    protected getResultElements(): HTMLElement[];
    protected blurSuggestionBox(event: UIEvent): void;
    protected getFocusedElement(): HTMLElement | any;
    protected getFocusedIndex(): number;
    protected isSuggestionFocused(): boolean;
    protected toggleBodyClass(className: string, add?: boolean): void;
    protected buildForm(): void;
    protected isEmpty(string?: string): boolean;
    protected watchQueryChange(): Subscription;
    protected searchProducts(query: string): void;
    protected clearResults(): void;
    protected close(): void;
    protected resetSearchSubscription(): void;
    protected watchProductAdd(): Subscription;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuickOrderFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuickOrderFormComponent, "cx-quick-order-form", never, { "limit": { "alias": "limit"; "required": false; }; }, {}, never, never, true, never>;
}

declare class QuickOrderComponent implements OnInit, OnDestroy {
    protected activeCartService: ActiveCartFacade;
    protected component: CmsComponentData<CmsQuickOrderComponent>;
    protected globalMessageService: GlobalMessageService;
    protected quickOrderService: QuickOrderFacade;
    protected quickOrderStatePersistenceService: QuickOrderStatePersistenceService;
    cartId$: Observable<string>;
    entries$: Observable<OrderEntry[]>;
    quickOrderListLimit$: Observable<number | undefined>;
    isCartStable$: Observable<boolean>;
    globalMessageType: typeof GlobalMessageType;
    listLimitReached$: Observable<boolean>;
    quickOrderForm: QuickOrderFormComponent;
    protected cartErrors$: BehaviorSubject<QuickOrderAddEntryEvent[]>;
    protected cartWarnings$: BehaviorSubject<QuickOrderAddEntryEvent[]>;
    protected cartSuccesses$: BehaviorSubject<OrderEntry[]>;
    protected showAddToCartInformation$: BehaviorSubject<boolean>;
    protected nonPurchasableProductError$: BehaviorSubject<Product | null>;
    constructor(activeCartService: ActiveCartFacade, component: CmsComponentData<CmsQuickOrderComponent>, globalMessageService: GlobalMessageService, quickOrderService: QuickOrderFacade, quickOrderStatePersistenceService: QuickOrderStatePersistenceService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    get errors$(): Observable<QuickOrderAddEntryEvent[]>;
    get warnings$(): Observable<QuickOrderAddEntryEvent[]>;
    get successes$(): Observable<OrderEntry[]>;
    get nonPurchasableError$(): Observable<Product | null>;
    get addToCartInformation$(): Observable<boolean>;
    get softDeletedEntries$(): Observable<Record<string, OrderEntry>>;
    clear(): void;
    addToCart(orderEntries: OrderEntry[]): void;
    clearErrors(): void;
    clearWarnings(): void;
    clearSuccesses(): void;
    clearAddToCartInformation(): void;
    undoDeletion(entry: OrderEntry): void;
    clearDeletion(entry: OrderEntry): void;
    clearNonPurchasableError(): void;
    canAddProduct(): Observable<boolean>;
    protected extractErrors(errors: QuickOrderAddEntryEvent[]): void;
    protected extractWarnings(errors: QuickOrderAddEntryEvent[]): void;
    protected extractSuccesses(errors: QuickOrderAddEntryEvent[], entries: OrderEntry[]): void;
    protected clearStatuses(): void;
    protected showAddedToCartSuccessMessage(): void;
    protected setErrors(errors: QuickOrderAddEntryEvent[]): void;
    protected setWarnings(warnings: QuickOrderAddEntryEvent[]): void;
    protected setSuccesses(entries: OrderEntry[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuickOrderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuickOrderComponent, "cx-quick-order", never, {}, {}, never, never, true, never>;
}

declare class QuickOrderItemComponent implements OnInit, OnDestroy {
    protected cd: ChangeDetectorRef;
    protected quickOrderService: QuickOrderFacade;
    quantityControl: UntypedFormControl;
    get entry(): OrderEntry;
    set entry(value: OrderEntry);
    index: number;
    loading: boolean;
    protected _entry: OrderEntry;
    protected subscription: Subscription;
    constructor(cd: ChangeDetectorRef, quickOrderService: QuickOrderFacade);
    ngOnInit(): void;
    removeEntry(): void;
    protected watchProductAdd(): Subscription;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuickOrderItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuickOrderItemComponent, "[cx-quick-order-item], cx-quick-order-item", never, { "entry": { "alias": "entry"; "required": false; }; "index": { "alias": "index"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; }, {}, never, never, true, never>;
}

declare class QuickOrderTableComponent {
    entries: OrderEntry[];
    loading: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuickOrderTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QuickOrderTableComponent, "cx-quick-order-table", never, { "entries": { "alias": "entries"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; }, {}, never, never, true, never>;
}

declare class QuickOrderListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuickOrderListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuickOrderListModule, never, [typeof i1$1.AtMessageModule, typeof i1.CommonModule, typeof i1$1.FormErrorsModule, typeof i3.I18nModule, typeof i1$1.IconModule, typeof i1$1.ItemCounterModule, typeof i1$1.MediaModule, typeof i1$1.MessageComponentModule, typeof i1$1.ProgressButtonModule, typeof i2.ReactiveFormsModule, typeof i5.RouterModule, typeof i3.UrlModule, typeof i3.FeaturesConfigModule, typeof QuickOrderComponent, typeof QuickOrderFormComponent, typeof QuickOrderItemComponent, typeof QuickOrderTableComponent], [typeof QuickOrderComponent, typeof QuickOrderFormComponent, typeof QuickOrderItemComponent, typeof QuickOrderTableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuickOrderListModule>;
}

declare class QuickOrderComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuickOrderComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuickOrderComponentsModule, never, [typeof i5.RouterModule, typeof QuickOrderListModule, typeof CartQuickOrderFormModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuickOrderComponentsModule>;
}

export { CartQuickOrderFormComponent, CartQuickOrderFormModule, QuickOrderComponent, QuickOrderComponentsModule, QuickOrderFormComponent, QuickOrderItemComponent, QuickOrderListModule, QuickOrderOrderEntriesContext, QuickOrderTableComponent };
