import { NgIf, NgFor, AsyncPipe, CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Optional, Component, NgModule, Injectable } from '@angular/core';
import * as i2 from '@spartacus/core';
import { TranslatePipe, CxDatePipe, UrlModule, I18nModule, ProductCatalogService } from '@spartacus/core';
import { EMPTY } from 'rxjs';
import * as i1 from '@spartacus/cart/base/root';
import { CartOutlets } from '@spartacus/cart/base/root';
import { IconModule, provideOutlet, OutletPosition } from '@spartacus/storefront';
import { PDFInvoicesComponentsModule } from '@spartacus/pdf-invoices/components';
import { RequestedDeliveryDateComponentsModule } from '@spartacus/requested-delivery-date/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ScheduleLinesComponent {
    constructor(cartItemContext, translationService, datePipe) {
        this.cartItemContext = cartItemContext;
        this.translationService = translationService;
        this.datePipe = datePipe;
        this.orderEntry$ = this.cartItemContext?.item$ ?? EMPTY;
    }
    /**
     * Verifies whether the Schedule Line infos have any entries.
     * Only in this case we want to display the schedule line summary
     *
     * @param {OrderEntry} item - Cart item
     * @returns {boolean} - whether the Schedule Line information is present for the order
     */
    hasScheduleLines(item) {
        const scheduleLines = item.scheduleLines;
        return scheduleLines != null && scheduleLines.length > 0;
    }
    getScheduleLineInfoId(index) {
        return 'cx-schedule-line-info-' + index.toString();
    }
    getLongDate(date) {
        if (!date) {
            return '';
        }
        return this.datePipe.transform(date);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ScheduleLinesComponent, deps: [{ token: i1.CartItemContext, optional: true }, { token: i2.TranslationService }, { token: i2.CxDatePipe }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: ScheduleLinesComponent, isStandalone: true, selector: "cx-schedule-lines", providers: [CxDatePipe], ngImport: i0, template: "<ng-container *ngIf=\"orderEntry$ | async as orderEntry\">\n  <ng-container *ngIf=\"hasScheduleLines(orderEntry)\">\n    <div class=\"cx-code\">\n      <div\n        *ngFor=\"let scheduleLine of orderEntry.scheduleLines; let i = index\"\n        class=\"cx-schedule-line-info\"\n        attr.aria-describedby=\"{{ getScheduleLineInfoId(i) }}\"\n      >\n        <div id=\"{{ getScheduleLineInfoId(i) }}\" class=\"cx-visually-hidden\">\n          {{\n            's4omScheduleLines.a11y.scheduleLineEntryInfo'\n              | cxTranslate\n                : {\n                    quantity: scheduleLine.confirmedQuantity,\n                    date: getLongDate(scheduleLine.confirmedAt),\n                  }\n          }}\n        </div>\n        <div class=\"cx-value\" aria-hidden=\"true\">\n          {{ scheduleLine?.confirmedAt | cxDate: 'M/d/yyyy' }}\n        </div>\n        <div class=\"cx-label\" aria-hidden=\"true\">\n          {{ 's4omScheduleLines.quantity' | cxTranslate }}\n        </div>\n        <div class=\"cx-value\" aria-hidden=\"true\">\n          {{ scheduleLine?.confirmedQuantity }}\n        </div>\n      </div>\n    </div>\n  </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: CxDatePipe, name: "cxDate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ScheduleLinesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-schedule-lines', providers: [CxDatePipe], imports: [NgIf, NgFor, AsyncPipe, TranslatePipe, CxDatePipe], template: "<ng-container *ngIf=\"orderEntry$ | async as orderEntry\">\n  <ng-container *ngIf=\"hasScheduleLines(orderEntry)\">\n    <div class=\"cx-code\">\n      <div\n        *ngFor=\"let scheduleLine of orderEntry.scheduleLines; let i = index\"\n        class=\"cx-schedule-line-info\"\n        attr.aria-describedby=\"{{ getScheduleLineInfoId(i) }}\"\n      >\n        <div id=\"{{ getScheduleLineInfoId(i) }}\" class=\"cx-visually-hidden\">\n          {{\n            's4omScheduleLines.a11y.scheduleLineEntryInfo'\n              | cxTranslate\n                : {\n                    quantity: scheduleLine.confirmedQuantity,\n                    date: getLongDate(scheduleLine.confirmedAt),\n                  }\n          }}\n        </div>\n        <div class=\"cx-value\" aria-hidden=\"true\">\n          {{ scheduleLine?.confirmedAt | cxDate: 'M/d/yyyy' }}\n        </div>\n        <div class=\"cx-label\" aria-hidden=\"true\">\n          {{ 's4omScheduleLines.quantity' | cxTranslate }}\n        </div>\n        <div class=\"cx-value\" aria-hidden=\"true\">\n          {{ scheduleLine?.confirmedQuantity }}\n        </div>\n      </div>\n    </div>\n  </ng-container>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: i1.CartItemContext, decorators: [{
                    type: Optional
                }] }, { type: i2.TranslationService }, { type: i2.CxDatePipe }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ScheduleLinesModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ScheduleLinesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: ScheduleLinesModule, imports: [CommonModule,
            UrlModule,
            I18nModule,
            IconModule,
            ScheduleLinesComponent], exports: [ScheduleLinesComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ScheduleLinesModule, imports: [CommonModule,
            UrlModule,
            I18nModule,
            IconModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ScheduleLinesModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        UrlModule,
                        I18nModule,
                        IconModule,
                        ScheduleLinesComponent,
                    ],
                    exports: [ScheduleLinesComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const S4OM_FEATURE = 'S4HANA-Order-Management';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class S4omProductCatalogService extends ProductCatalogService {
    constructor() {
        super(...arguments);
        this.PRODUCT_NOT_IN_CATALOGUE_STOCK_LEVEL_STATUS = 'notOrderable';
    }
    /**
     * Returns whether product is present in commerce product catalog.
     * Product will have specific stock level status set if fetched from S4 but not present in sap commerce.
     *
     * @param product product to check
     * @return true if product is present in catalog, false otherwise
     */
    isProductInCatalog(product) {
        if (!product) {
            return false;
        }
        const stockLevelStatus = product?.stock?.stockLevelStatus;
        if (!stockLevelStatus) {
            return true;
        }
        return (stockLevelStatus !== this.PRODUCT_NOT_IN_CATALOGUE_STOCK_LEVEL_STATUS);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4omProductCatalogService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4omProductCatalogService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4omProductCatalogService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class S4omRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4omRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: S4omRootModule, imports: [ScheduleLinesModule,
            RequestedDeliveryDateComponentsModule, //Adding dependency with Requested Delivery Date so that the library gets installed along with S4OM
            PDFInvoicesComponentsModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4omRootModule, providers: [
            provideOutlet({
                id: CartOutlets.ITEM_DETAILS,
                position: OutletPosition.AFTER,
                component: ScheduleLinesComponent,
            }),
            {
                provide: ProductCatalogService,
                useExisting: S4omProductCatalogService,
            },
        ], imports: [ScheduleLinesModule,
            RequestedDeliveryDateComponentsModule, //Adding dependency with Requested Delivery Date so that the library gets installed along with S4OM
            PDFInvoicesComponentsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: S4omRootModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        ScheduleLinesModule,
                        RequestedDeliveryDateComponentsModule, //Adding dependency with Requested Delivery Date so that the library gets installed along with S4OM
                        PDFInvoicesComponentsModule, //Adding dependency with PDF Invoices so that the library gets installed along with S4OM
                    ],
                    providers: [
                        provideOutlet({
                            id: CartOutlets.ITEM_DETAILS,
                            position: OutletPosition.AFTER,
                            component: ScheduleLinesComponent,
                        }),
                        {
                            provide: ProductCatalogService,
                            useExisting: S4omProductCatalogService,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { S4OM_FEATURE, S4omProductCatalogService, S4omRootModule, ScheduleLinesComponent, ScheduleLinesModule };
//# sourceMappingURL=spartacus-s4om-root.mjs.map
