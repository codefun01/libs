import { OpfApiEndpoint } from '@spartacus/opf/base/root';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare module '@spartacus/opf/base/root' {
    interface OpfApiEndpoints {
        /**
         * Endpoint to get CTA (Call To Action) Scripts
         */
        getCtaScripts?: string | OpfApiEndpoint;
    }
}

declare class OpfApiCtaModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfApiCtaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfApiCtaModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfApiCtaModule>;
}

export { OpfApiCtaModule };
