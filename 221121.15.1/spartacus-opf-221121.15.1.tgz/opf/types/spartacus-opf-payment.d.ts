import * as i0 from '@angular/core';
import * as i1 from '@spartacus/opf/payment/core';
import * as i2 from '@spartacus/opf/payment/opf-api';
import * as i3 from '@spartacus/opf/payment/occ';

declare class OpfPaymentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfPaymentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfPaymentModule, never, [typeof i1.OpfPaymentCoreModule, typeof i2.OpfApiPaymentModule, typeof i3.OpfPaymentOccModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfPaymentModule>;
}

export { OpfPaymentModule };
