import { TranslationChunksConfig } from '@spartacus/core';

declare const en: {
    opfGiftCard: {
        opfGiftCard: {
            title: string;
            giftCardPayment: string;
            haveGiftCard: string;
            addGiftCard: string;
            cardNumber: string;
            pin: string;
            proceedPayment: string;
            apply: string;
            remove: string;
            appliedSuccessfully: string;
            removedSuccessfully: string;
            currentBalance: string;
            balanceAfterPurchase: string;
            errors: {
                placeOrderFailed: string;
            };
            common: {
                formErrors: {
                    labeled: {
                        required: string;
                        minlength: string;
                        maxlength: string;
                    };
                    required: string;
                    minlength: string;
                    maxlength: string;
                };
            };
        };
    };
};

declare const opfGiftCardTranslationChunksConfig: TranslationChunksConfig;

declare const opfGiftCardTranslations: {
    en: {
        opfGiftCard: {
            opfGiftCard: {
                title: string;
                giftCardPayment: string;
                haveGiftCard: string;
                addGiftCard: string;
                cardNumber: string;
                pin: string;
                proceedPayment: string;
                apply: string;
                remove: string;
                appliedSuccessfully: string;
                removedSuccessfully: string;
                currentBalance: string;
                balanceAfterPurchase: string;
                errors: {
                    placeOrderFailed: string;
                };
                common: {
                    formErrors: {
                        labeled: {
                            required: string;
                            minlength: string;
                            maxlength: string;
                        };
                        required: string;
                        minlength: string;
                        maxlength: string;
                    };
                };
            };
        };
    };
};

export { opfGiftCardTranslationChunksConfig, opfGiftCardTranslations, en as opfGiftCardTranslationsEn };
