import { Occ, Address, PaymentDetails, Converter } from '@spartacus/core';
import { Order } from '@spartacus/order/root';
import * as i0 from '@angular/core';

interface OpfOccOrder extends Omit<Occ.Order, 'paymentInfo'> {
    sapBillingAddress: Address;
    paymentInfo: Omit<PaymentDetails, 'billingAddress'>;
}

declare class OpfOccOrderNormalizer implements Converter<OpfOccOrder, Order> {
    convert(source: OpfOccOrder, target?: Order): Order;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfOccOrderNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfOccOrderNormalizer>;
}

declare class OpfOrderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfOrderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfOrderModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfOrderModule>;
}

export { OpfOccOrderNormalizer, OpfOrderModule };
