import { OccConfig, OccEndpoint, CmsConfig } from '@spartacus/core';
import { CheckoutConfig } from '@spartacus/checkout/base/root';
import * as i0 from '@angular/core';
import { Observable } from 'rxjs';

declare const defaultOccOpfCheckoutConfig: OccConfig;

declare const defaultOpfCheckoutConfig: CheckoutConfig;

declare const OPF_CHECKOUT_FEATURE = "opfCheckout";

declare module '@spartacus/cart/base/root' {
    enum CartOutlets {
        OPF_CHECKOUT_PICKUP_ITEMS = "cx-opf-checkout-pickup-items"
    }
}

declare module '@spartacus/core' {
    interface OccEndpoints {
        cartUserEmail?: string | OccEndpoint;
    }
}

declare const OPF_PAYMENT_AND_REVIEW_SEMANTIC_ROUTE = "opfCheckoutPaymentAndReview";
declare const OPF_EXPLICIT_TERMS_AND_CONDITIONS_COMPONENT = "OpfExplicitTermsAndConditionsComponent";
declare const OPF_CHECKOUT_FLOW_NAME = "OPF";
interface CartUserEmailResponse {
    sapCustomerEmail: string;
}

declare enum OpfCheckoutOutlets {
    OPF_CHECKOUT_BEFORE_PAYMENT_OPTIONS = "cx-opf-checkout-before-payment-options",
    OPF_CHECKOUT_BEFORE_SAVED_PAYMENT_OPTIONS = "cx-opf-checkout-before-saved-payment-options",
    ORDER_DETAILS_AFTER_PAYMENT_OPTIONS = "cx-opf-after-payment-options"
}

declare const CHECKOUT_OPF_CMS_COMPONENTS: string[];
declare function defaultOpfCheckoutComponentsConfig(): CmsConfig;
declare class OpfCheckoutRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCheckoutRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCheckoutRootModule>;
}

declare abstract class OpfCheckoutAdapter {
    /**
     * Abstract method to retrieve the email associated with a specific cart for a given user.
     * Implementations of this method should handle fetching the cart user's email from an API or service.
     *
     * @abstract
     * @param {string} userId - The unique identifier of the user.
     * @param {string} cartId - The unique identifier of the cart.
     * @returns {Observable<CartUserEmailResponse>} - An observable containing the cart user email response.
     */
    abstract getCartUserEmail(userId: string, cartId: string): Observable<CartUserEmailResponse>;
}

declare class OpfCheckoutConnector {
    protected adapter: OpfCheckoutAdapter;
    /**
     * Retrieves the email associated with a specific cart for a given user.
     * Delegates the request to the underlying adapter.
     *
     * @param {string} userId - The unique identifier of the user.
     * @param {string} cartId - The unique identifier of the cart.
     * @returns {Observable<CartUserEmailResponse>} - An observable containing the cart user email response.
     */
    getCartUserEmail(userId: string, cartId: string): Observable<CartUserEmailResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfCheckoutConnector>;
}

declare class OpfCartUserEmailCheckerService {
    protected opfCheckoutConnector: OpfCheckoutConnector;
    /**
     * Checks if the user associated with a cart has an email.
     *
     * @param {string} userId - The unique identifier of the user.
     * @param {string} cartId - The unique identifier of the cart.
     * @returns {Observable<boolean>} - An observable that emits `true` if the user has an email assigned, otherwise `false`.
     */
    isCartUserHasEmail(userId: string, cartId: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCartUserEmailCheckerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfCartUserEmailCheckerService>;
}

export { CHECKOUT_OPF_CMS_COMPONENTS, OPF_CHECKOUT_FEATURE, OPF_CHECKOUT_FLOW_NAME, OPF_EXPLICIT_TERMS_AND_CONDITIONS_COMPONENT, OPF_PAYMENT_AND_REVIEW_SEMANTIC_ROUTE, OpfCartUserEmailCheckerService, OpfCheckoutOutlets, OpfCheckoutRootModule, defaultOccOpfCheckoutConfig, defaultOpfCheckoutComponentsConfig, defaultOpfCheckoutConfig };
export type { CartUserEmailResponse };
