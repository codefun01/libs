import * as i0 from '@angular/core';
import * as i1 from '@spartacus/opf/quick-buy/components';
import * as i2 from '@spartacus/opf/quick-buy/core';
import * as i3 from '@spartacus/opf/quick-buy/opf-api';

declare class OpfQuickBuyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfQuickBuyModule, never, [typeof i1.OpfQuickBuyComponentsModule, typeof i2.OpfQuickBuyCoreModule, typeof i3.OpfApiQuickBuyModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfQuickBuyModule>;
}

export { OpfQuickBuyModule };
