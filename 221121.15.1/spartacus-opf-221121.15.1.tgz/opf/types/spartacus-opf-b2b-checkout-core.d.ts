import { ActiveCartFacade, PaymentType } from '@spartacus/cart/base/root';
import { CheckoutPaymentTypeFacade, B2BPaymentTypeEnum } from '@spartacus/checkout/b2b/root';
import { CheckoutQueryFacade } from '@spartacus/checkout/base/root';
import { UserIdService, QueryService, CommandService, EventService, Command, QueryState } from '@spartacus/core';
import { Observable } from 'rxjs';
import { OpfPaymentFacade } from '@spartacus/opf/payment/root';
import * as i0 from '@angular/core';

declare class OpfB2bCheckoutPaymentTypeService implements CheckoutPaymentTypeFacade {
    protected activeCartFacade: ActiveCartFacade;
    protected userIdService: UserIdService;
    protected queryService: QueryService;
    protected commandService: CommandService;
    protected eventService: EventService;
    protected checkoutQueryFacade: CheckoutQueryFacade;
    protected opfPaymentFacade: OpfPaymentFacade;
    protected setPaymentTypeCommand: Command<{
        paymentTypeCode: string;
        purchaseOrderNumber?: string;
    }>;
    constructor(activeCartFacade: ActiveCartFacade, userIdService: UserIdService, queryService: QueryService, commandService: CommandService, eventService: EventService, checkoutQueryFacade: CheckoutQueryFacade);
    protected checkoutPreconditions(): Observable<[string, string]>;
    getPaymentTypesState(): Observable<QueryState<PaymentType[] | undefined>>;
    getPaymentTypes(): Observable<PaymentType[]>;
    setPaymentType(paymentTypeCode: B2BPaymentTypeEnum, purchaseOrderNumber?: string): Observable<unknown>;
    getSelectedPaymentTypeState(): Observable<QueryState<PaymentType | undefined>>;
    isAccountPayment(): Observable<boolean>;
    getPurchaseOrderNumberState(): Observable<QueryState<string | undefined>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfB2bCheckoutPaymentTypeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfB2bCheckoutPaymentTypeService>;
}

declare class OpfB2bCheckoutCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfB2bCheckoutCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfB2bCheckoutCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfB2bCheckoutCoreModule>;
}

export { OpfB2bCheckoutCoreModule, OpfB2bCheckoutPaymentTypeService };
