import * as i0 from '@angular/core';
import { OnInit, ElementRef, ChangeDetectorRef } from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/core';
import { TranslationService } from '@spartacus/core';
import * as i3 from '@spartacus/storefront';
import { LaunchDialogService, FocusConfig, LayoutConfig } from '@spartacus/storefront';
import * as rxjs from 'rxjs';
import { Observable } from 'rxjs';
import { OpfErrorDialogOptions } from '@spartacus/opf/base/root';

declare class OpfErrorModalService {
    protected translationService: TranslationService;
    getMessageAndConfirmTranslations(dialogOptions: OpfErrorDialogOptions): rxjs.Observable<{
        message: string;
        confirm: string;
    }>;
    protected getLabelTranslation(defaultKey: string, labelString?: string, labelKey?: string, labelReplacements?: any): rxjs.Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfErrorModalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfErrorModalService>;
}

declare class OpfErrorModalComponent implements OnInit {
    protected launchDialogService: LaunchDialogService;
    protected el: ElementRef<any>;
    protected cd: ChangeDetectorRef;
    protected opfErrorModalService: OpfErrorModalService;
    focusConfig: FocusConfig;
    opfErrorDialogOptions$: Observable<{
        message: string;
        confirm: string;
    }>;
    handleClick(event: UIEvent): void;
    protected initialize(): void;
    constructor();
    ngOnInit(): void;
    dismissModal(reason?: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfErrorModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfErrorModalComponent, "cx-opf-error-modal", never, {}, {}, never, never, true, never>;
}

declare class OpfErrorModalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfErrorModalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfErrorModalModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.KeyboardFocusModule, typeof OpfErrorModalComponent], [typeof OpfErrorModalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfErrorModalModule>;
}

declare class OpfBaseComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfBaseComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfBaseComponentsModule, never, [typeof OpfErrorModalModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfBaseComponentsModule>;
}

declare const defaultOpfErrorModalLayoutConfig: LayoutConfig;

export { OpfBaseComponentsModule, OpfErrorModalComponent, OpfErrorModalModule, OpfErrorModalService, defaultOpfErrorModalLayoutConfig };
