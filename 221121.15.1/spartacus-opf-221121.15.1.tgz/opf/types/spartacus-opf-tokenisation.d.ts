import * as i0 from '@angular/core';
import * as i1 from '@spartacus/opf/tokenisation/components';
import * as i2 from '@spartacus/opf/tokenisation/core';
import * as i3 from '@spartacus/opf/tokenisation/root';

declare class OpfTokenisationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfTokenisationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfTokenisationModule, never, [typeof i1.OpfTokenisationComponentsModule, typeof i2.OpfTokenisationCoreModule, typeof i3.OpfTokenisationRootModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfTokenisationModule>;
}

export { OpfTokenisationModule };
