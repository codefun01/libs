import { OpfApiEndpoint } from '@spartacus/opf/base/root';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare module '@spartacus/opf/base/root' {
    interface OpfApiEndpoints {
        /**
         * Endpoint to verify a response from PSP for Full Page Redirect
         * and iFrame integration patterns.
         */
        verifyPayment?: string | OpfApiEndpoint;
        /**
         * Endpoint to submit payment for Hosted Fields pattern.
         */
        submitPayment?: string | OpfApiEndpoint;
        /**
         * Endpoint to submit-complete payment for Hosted Fields pattern.
         */
        submitCompletePayment?: string | OpfApiEndpoint;
        /**
         * Endpoint to fetch dynamic script for Hosted Fields pattern and PageRedirection sub-pattern.
         */
        getAfterRedirectScripts?: string | OpfApiEndpoint;
        /**
         * Endpoint to initiate payment provider.
         */
        initiatePayment?: string | OpfApiEndpoint;
        /**
         * Endpoint to update an existing payment transaction/session.
         */
        updatePaymentTransaction?: string | OpfApiEndpoint;
    }
}

declare class OpfApiPaymentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfApiPaymentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfApiPaymentModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfApiPaymentModule>;
}

export { OpfApiPaymentModule };
