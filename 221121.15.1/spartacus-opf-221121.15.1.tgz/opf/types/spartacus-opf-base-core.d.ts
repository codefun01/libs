import { OpfActiveConfigurationsQuery, OpfActiveConfigurationsResponse, OpfBaseFacade, OpfConfig, OpfApiConfig } from '@spartacus/opf/base/root';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import * as _spartacus_core from '@spartacus/core';
import { QueryService, CommandService, QueryState, BaseSiteService, DynamicAttributes, Converter } from '@spartacus/core';
import { HttpParamsOptions, HttpParams } from '@angular/common/http';

declare abstract class OpfBaseAdapter {
    /**
     * Abstract method used to get payment active configurations
     */
    abstract getActiveConfigurations(query?: OpfActiveConfigurationsQuery): Observable<OpfActiveConfigurationsResponse>;
}

declare class OpfBaseConnector {
    protected adapter: OpfBaseAdapter;
    getActiveConfigurations(query?: OpfActiveConfigurationsQuery): Observable<OpfActiveConfigurationsResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfBaseConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfBaseConnector>;
}

declare class OpfBaseService implements OpfBaseFacade {
    protected queryService: QueryService;
    protected commandService: CommandService;
    protected opfBaseConnector: OpfBaseConnector;
    protected activeConfigurationsQuery: (query?: OpfActiveConfigurationsQuery) => _spartacus_core.Query<OpfActiveConfigurationsResponse, []>;
    getActiveConfigurationsState(query?: OpfActiveConfigurationsQuery): Observable<QueryState<OpfActiveConfigurationsResponse | undefined>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfBaseService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfBaseService>;
}

declare class OpfBaseCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfBaseCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfBaseCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfBaseCoreModule>;
}

declare class OpfEndpointsService {
    protected opfConfig: OpfConfig;
    protected opfApiConfig: OpfApiConfig;
    protected baseSiteService: BaseSiteService;
    private _activeBaseSite;
    protected initialize(): void;
    constructor();
    buildUrl(endpoint: string, attributes?: DynamicAttributes): string;
    private getEndpointFromContext;
    private getBaseEndpoint;
    protected getHttpParamsFromQueryParams(queryParams: any, options: HttpParamsOptions): HttpParams;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfEndpointsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfEndpointsService>;
}

declare const OPF_ACTIVE_CONFIGURATIONS_NORMALIZER: InjectionToken<Converter<any, OpfActiveConfigurationsResponse>>;

export { OPF_ACTIVE_CONFIGURATIONS_NORMALIZER, OpfBaseAdapter, OpfBaseConnector, OpfBaseCoreModule, OpfBaseService, OpfEndpointsService };
