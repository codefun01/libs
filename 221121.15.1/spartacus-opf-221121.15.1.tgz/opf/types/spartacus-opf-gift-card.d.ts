import * as i0 from '@angular/core';
import { OnInit, OnDestroy, DestroyRef, ViewContainerRef, ComponentRef } from '@angular/core';
import * as i2 from '@spartacus/opf/gift-card/core';
import * as i3 from '@spartacus/opf/gift-card/occ';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { Cart, ActiveCartFacade, CartOutlets } from '@spartacus/cart/base/root';
import { Price, GlobalMessageService, HttpErrorModel, RoutingService, TranslationService } from '@spartacus/core';
import { OutletContextData, LaunchDialogService, Card } from '@spartacus/storefront';
import { Observable, Subscription, BehaviorSubject } from 'rxjs';
import { OpfPaymentEventsService } from '@spartacus/opf/payment/root';
import { OpfActiveConfiguration, OpfMetadataStoreService } from '@spartacus/opf/base/root';
import { OrderFacade, Order } from '@spartacus/order/root';
import { OrderDetailsService } from '@spartacus/order/components';

declare class OpfGiftCardComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfGiftCardComponentsModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfGiftCardComponentsModule>;
}

interface OpfGiftCards {
    id: string;
    maskedNumber: string;
    balance: Price;
    appliedAmount: Price;
    remainingBalance: Price;
}
interface OpfGiftCardSummary {
    totalBalance: Price;
    totalAppliedAmount: Price;
    totalRemainingBalance: Price;
    giftCardsCoverFullAmount: boolean;
}
interface OpfGiftCardBalanceRequest {
    number: string;
    securityCode: string;
}
type OpfGiftCardResponse = OpfGiftCards;

declare module '@spartacus/cart/base/root' {
    interface Cart {
        opfGiftCards?: OpfGiftCards[];
        opfGiftCardSummary?: OpfGiftCardSummary;
        availableOperations?: CartAvailableOperation[];
    }
}
declare module '@spartacus/order/root' {
    interface Order {
        opfGiftCardSummary?: OpfGiftCardSummary;
    }
}
interface CartAvailableOperation {
    key: string;
    value: {
        available?: boolean;
        name?: string;
    };
}

declare abstract class OpfGiftCardFacade {
    /**
     * Get gift card payment configuration from active configurations.
     * Filters by providerType: "STORED_VALUE_PAYMENT".
     *
     * @returns Observable of gift card configuration or undefined if not found
     */
    abstract getGiftCardConfiguration(): Observable<OpfActiveConfiguration | undefined>;
    /**
     * Check whether gift card payment is enabled in the active configuration.
     *
     * @returns Observable<boolean> emitting `true` when a STORED_VALUE_PAYMENT config exists
     */
    abstract isGiftCardEnabled(): Observable<boolean>;
    /**
     * Check whether applied gift cards fully cover the cart total.
     *
     * @param cart$ Observable of the active cart
     * @returns Observable<boolean>
     */
    abstract isGiftCardCoveredTotalAmount(cart$: Observable<Cart>): Observable<boolean>;
    /**
     * Apply a gift card to the active cart.
     *
     * @param request Gift card balance request with card number and security code
     * @returns Observable of the applied gift card response
     */
    abstract applyGiftCard(request: OpfGiftCardBalanceRequest): Observable<OpfGiftCardResponse>;
    /**
     * Remove a previously applied gift card from the active cart.
     *
     * @param giftCardId The ID of the gift card to remove
     */
    abstract removeGiftCard(giftCardId: string): Observable<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfGiftCardFacade>;
}

declare class OpfGiftCardApplyComponent implements OnInit, OnDestroy {
    protected outlet?: OutletContextData | undefined;
    protected globalMessageService: GlobalMessageService;
    protected activeCartFacade: ActiveCartFacade;
    protected giftCardFacade: OpfGiftCardFacade;
    protected formBuilder: UntypedFormBuilder;
    protected opfPaymentEventsService: OpfPaymentEventsService;
    protected opfMetadataStoreService: OpfMetadataStoreService;
    protected destroyRef: DestroyRef;
    private featureToggles;
    protected subscription: Subscription;
    giftCardForm: UntypedFormGroup;
    protected showGiftCardForm: i0.WritableSignal<boolean>;
    protected loadingSubject: BehaviorSubject<boolean>;
    protected loading$: Observable<boolean>;
    protected cart$: Observable<Cart>;
    isBillingAddressPresent$: Observable<void>;
    protected appliedGiftCards$: Observable<OpfGiftCards[]>;
    protected buildForm(): void;
    constructor(outlet?: OutletContextData | undefined);
    addGiftCard(): void;
    protected handleGiftCardError(error: HttpErrorModel): void;
    toggleGiftCardForm(): void;
    protected resetForm(): void;
    isGiftCardEnabled$: Observable<boolean>;
    isAddGiftCard$: Observable<boolean>;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardApplyComponent, [{ optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfGiftCardApplyComponent, "cx-opf-gift-card-apply", never, {}, {}, never, never, true, never>;
}

declare class OpfGiftCardApplyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardApplyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfGiftCardApplyModule, never, [typeof OpfGiftCardApplyComponent], [typeof OpfGiftCardApplyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfGiftCardApplyModule>;
}

declare class OpfGiftCardCheckoutPlaceOrderComponent implements OnInit, OnDestroy {
    cart$: Observable<Cart>;
    protected activeCartFacade: ActiveCartFacade;
    protected globalMessageService: GlobalMessageService;
    protected opfPaymentEventsService: OpfPaymentEventsService;
    protected orderFacade: OrderFacade;
    protected routingService: RoutingService;
    protected launchDialogService: LaunchDialogService;
    protected vcr: ViewContainerRef;
    ngOnInit(): void;
    termsAndConditionsChecked: boolean;
    placedOrder: void | Observable<ComponentRef<any> | undefined>;
    protected isPlacingOrder: boolean;
    placeOrderWithGiftCard(): void;
    protected onPlaceOrderError(): void;
    protected stopPlaceOrderSpinner(): void;
    onSuccess(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardCheckoutPlaceOrderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfGiftCardCheckoutPlaceOrderComponent, "cx-opf-gift-card-checkout-place-order", never, {}, {}, never, never, true, never>;
}

declare class OpfGiftCardCheckoutOrderSummaryComponent implements OnInit {
    protected activeCartFacade: ActiveCartFacade;
    cart$: Observable<Cart>;
    readonly cartOutlets: typeof CartOutlets;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardCheckoutOrderSummaryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfGiftCardCheckoutOrderSummaryComponent, "cx-opf-gift-card-checkout-order-summary", never, {}, {}, never, never, true, never>;
}

declare class OpfGiftCardCheckoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardCheckoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfGiftCardCheckoutModule, never, [typeof OpfGiftCardCheckoutPlaceOrderComponent, typeof OpfGiftCardCheckoutOrderSummaryComponent], [typeof OpfGiftCardCheckoutPlaceOrderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfGiftCardCheckoutModule>;
}

declare class OpfGiftCardOrderDetailBillingComponent implements OnInit, OnDestroy {
    protected orderOutlet?: OutletContextData | undefined;
    protected translationService: TranslationService;
    protected destroyRef: DestroyRef;
    private featureToggles;
    protected subscription: Subscription;
    order: Order;
    constructor(orderOutlet?: OutletContextData | undefined);
    protected routingService: RoutingService;
    ngOnInit(): void;
    isOrderDetailsPage$: Observable<boolean>;
    getPaymentMethodCardContent(): Observable<Card>;
    get isGiftCardPayment(): boolean;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardOrderDetailBillingComponent, [{ optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfGiftCardOrderDetailBillingComponent, "cx-opf-gift-card-order-detail-billing", never, { "order": { "alias": "order"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OpfGiftCardOrderDetailTotalsComponent implements OnInit {
    protected activeCartFacade: ActiveCartFacade;
    protected orderDetailsService: OrderDetailsService;
    cartOutlets: typeof CartOutlets;
    order$: Observable<any>;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardOrderDetailTotalsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfGiftCardOrderDetailTotalsComponent, "cx-opf-gift-card-order-detail-totals", never, {}, {}, never, never, true, never>;
}

declare class OpfGiftCardPaymentMethodDetailComponent implements OnInit, OnDestroy {
    protected orderOutlet?: OutletContextData | undefined;
    protected translationService: TranslationService;
    protected destroyRef: DestroyRef;
    private featureToggles;
    protected subscription: Subscription;
    order: Order;
    protected routingService: RoutingService;
    constructor(orderOutlet?: OutletContextData | undefined);
    ngOnInit(): void;
    getPaymentMethodCardContent(): Observable<Card>;
    get isGiftCardPayment(): boolean;
    get isPaymentMethodDetailsInfoPresent(): boolean;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardPaymentMethodDetailComponent, [{ optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfGiftCardPaymentMethodDetailComponent, "cx-opf-gift-card-payment-method-detail", never, { "order": { "alias": "order"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OpfGiftCardOrderDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardOrderDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfGiftCardOrderDetailsModule, never, [typeof OpfGiftCardOrderDetailBillingComponent, typeof OpfGiftCardOrderDetailTotalsComponent, typeof OpfGiftCardPaymentMethodDetailComponent], [typeof OpfGiftCardOrderDetailBillingComponent, typeof OpfGiftCardOrderDetailTotalsComponent, typeof OpfGiftCardPaymentMethodDetailComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfGiftCardOrderDetailsModule>;
}

declare class OpfGiftCardOrderConfirmationTotalsComponent implements OnDestroy {
    protected orderFacade: OrderFacade;
    readonly cartOutlets: typeof CartOutlets;
    order$: Observable<Order | undefined>;
    constructor();
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardOrderConfirmationTotalsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfGiftCardOrderConfirmationTotalsComponent, "cx-opf-gift-card-order-confirmation-totals", never, {}, {}, never, never, true, never>;
}

declare class OpfGiftCardOrderConfirmationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardOrderConfirmationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfGiftCardOrderConfirmationModule, never, [typeof OpfGiftCardOrderConfirmationTotalsComponent], [typeof OpfGiftCardOrderConfirmationTotalsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfGiftCardOrderConfirmationModule>;
}

declare class OpfGiftCardRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfGiftCardRootModule, never, [typeof OpfGiftCardApplyModule, typeof OpfGiftCardCheckoutModule, typeof OpfGiftCardOrderDetailsModule, typeof OpfGiftCardOrderConfirmationModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfGiftCardRootModule>;
}

declare class OpfGiftCardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfGiftCardModule, never, [typeof OpfGiftCardComponentsModule, typeof i2.OpfGiftCardCoreModule, typeof i3.OpfGiftCardOccModule, typeof OpfGiftCardRootModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfGiftCardModule>;
}

export { OpfGiftCardModule };
