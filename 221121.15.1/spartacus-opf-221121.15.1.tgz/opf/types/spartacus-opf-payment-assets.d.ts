import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    opfPayment: {
        opfPayment: {
            errors: {
                proceedPayment: string;
                cancelPayment: string;
                cardExpired: string;
                insufficientFunds: string;
                invalidCreditCard: string;
                unknown: string;
                cardReportedLost: string;
            };
        };
    };
};

declare const de: {
    opfPayment: {
        opfPayment: {
            errors: {
                proceedPayment: string;
                cancelPayment: string;
                cardExpired: string;
                insufficientFunds: string;
                invalidCreditCard: string;
                unknown: string;
                cardReportedLost: string;
            };
        };
    };
};

declare const en: {
    opfPayment: {
        opfPayment: {
            errors: {
                proceedPayment: string;
                cancelPayment: string;
                cardExpired: string;
                insufficientFunds: string;
                invalidCreditCard: string;
                unknown: string;
                cardReportedLost: string;
            };
        };
    };
};

declare const es: {
    opfPayment: {
        opfPayment: {
            errors: {
                proceedPayment: string;
                cancelPayment: string;
                cardExpired: string;
                insufficientFunds: string;
                invalidCreditCard: string;
                unknown: string;
                cardReportedLost: string;
            };
        };
    };
};

declare const es_CO: {
    opfPayment: {
        opfPayment: {
            errors: {
                proceedPayment: string;
                cancelPayment: string;
                cardExpired: string;
                insufficientFunds: string;
                invalidCreditCard: string;
                unknown: string;
                cardReportedLost: string;
            };
        };
    };
};

declare const fr: {
    opfPayment: {
        opfPayment: {
            errors: {
                proceedPayment: string;
                cancelPayment: string;
                cardExpired: string;
                insufficientFunds: string;
                invalidCreditCard: string;
                unknown: string;
                cardReportedLost: string;
            };
        };
    };
};

declare const hi: {
    opfPayment: {
        opfPayment: {
            errors: {
                proceedPayment: string;
                cancelPayment: string;
                cardExpired: string;
                insufficientFunds: string;
                invalidCreditCard: string;
                unknown: string;
                cardReportedLost: string;
            };
        };
    };
};

declare const hu: {
    opfPayment: {
        opfPayment: {
            errors: {
                proceedPayment: string;
                cancelPayment: string;
                cardExpired: string;
                insufficientFunds: string;
                invalidCreditCard: string;
                unknown: string;
                cardReportedLost: string;
            };
        };
    };
};

declare const id: {
    opfPayment: {
        opfPayment: {
            errors: {
                proceedPayment: string;
                cancelPayment: string;
                cardExpired: string;
                insufficientFunds: string;
                invalidCreditCard: string;
                unknown: string;
                cardReportedLost: string;
            };
        };
    };
};

declare const it: {
    opfPayment: {
        opfPayment: {
            errors: {
                proceedPayment: string;
                cancelPayment: string;
                cardExpired: string;
                insufficientFunds: string;
                invalidCreditCard: string;
                unknown: string;
                cardReportedLost: string;
            };
        };
    };
};

declare const ja: {
    opfPayment: {
        opfPayment: {
            errors: {
                proceedPayment: string;
                cancelPayment: string;
                cardExpired: string;
                insufficientFunds: string;
                invalidCreditCard: string;
                unknown: string;
                cardReportedLost: string;
            };
        };
    };
};

declare const ko: {
    opfPayment: {
        opfPayment: {
            errors: {
                proceedPayment: string;
                cancelPayment: string;
                cardExpired: string;
                insufficientFunds: string;
                invalidCreditCard: string;
                unknown: string;
                cardReportedLost: string;
            };
        };
    };
};

declare const pl: {
    opfPayment: {
        opfPayment: {
            errors: {
                proceedPayment: string;
                cancelPayment: string;
                cardExpired: string;
                insufficientFunds: string;
                invalidCreditCard: string;
                unknown: string;
                cardReportedLost: string;
            };
        };
    };
};

declare const pt: {
    opfPayment: {
        opfPayment: {
            errors: {
                proceedPayment: string;
                cancelPayment: string;
                cardExpired: string;
                insufficientFunds: string;
                invalidCreditCard: string;
                unknown: string;
                cardReportedLost: string;
            };
        };
    };
};

declare const ru: {
    opfPayment: {
        opfPayment: {
            errors: {
                proceedPayment: string;
                cancelPayment: string;
                cardExpired: string;
                insufficientFunds: string;
                invalidCreditCard: string;
                unknown: string;
                cardReportedLost: string;
            };
        };
    };
};

declare const zh: {
    opfPayment: {
        opfPayment: {
            errors: {
                proceedPayment: string;
                cancelPayment: string;
                cardExpired: string;
                insufficientFunds: string;
                invalidCreditCard: string;
                unknown: string;
                cardReportedLost: string;
            };
        };
    };
};

declare const zh_TW: {
    opfPayment: {
        opfPayment: {
            errors: {
                proceedPayment: string;
                cancelPayment: string;
                cardExpired: string;
                insufficientFunds: string;
                invalidCreditCard: string;
                unknown: string;
                cardReportedLost: string;
            };
        };
    };
};

declare const opfPaymentTranslationChunksConfig: TranslationChunksConfig;

export { opfPaymentTranslationChunksConfig, cs as opfPaymentTranslationsCs, de as opfPaymentTranslationsDe, en as opfPaymentTranslationsEn, es as opfPaymentTranslationsEs, es_CO as opfPaymentTranslationsEs_CO, fr as opfPaymentTranslationsFr, hi as opfPaymentTranslationsHi, hu as opfPaymentTranslationsHu, id as opfPaymentTranslationsId, it as opfPaymentTranslationsIt, ja as opfPaymentTranslationsJa, ko as opfPaymentTranslationsKo, pl as opfPaymentTranslationsPl, pt as opfPaymentTranslationsPt, ru as opfPaymentTranslationsRu, zh as opfPaymentTranslationsZh, zh_TW as opfPaymentTranslationsZh_TW };
