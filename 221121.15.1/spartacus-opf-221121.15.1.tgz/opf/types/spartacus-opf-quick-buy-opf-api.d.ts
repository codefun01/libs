import { OpfApiEndpoint } from '@spartacus/opf/base/root';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare module '@spartacus/opf/base/root' {
    interface OpfApiEndpoints {
        /**
         * Endpoint to get ApplePay Web Session for QuickBuy functionality
         */
        getApplePayWebSession?: string | OpfApiEndpoint;
    }
}

declare class OpfApiQuickBuyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfApiQuickBuyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfApiQuickBuyModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfApiQuickBuyModule>;
}

export { OpfApiQuickBuyModule };
