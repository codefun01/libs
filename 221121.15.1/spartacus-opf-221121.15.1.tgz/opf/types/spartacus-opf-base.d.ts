import * as i0 from '@angular/core';
import * as i1 from '@spartacus/opf/base/opf-api';
import * as i2 from '@spartacus/opf/base/core';
import * as i3 from '@spartacus/opf/base/components';

declare class OpfBaseModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfBaseModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfBaseModule, never, [typeof i1.OpfApiBaseModule, typeof i2.OpfBaseCoreModule, typeof i3.OpfBaseComponentsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfBaseModule>;
}

export { OpfBaseModule };
