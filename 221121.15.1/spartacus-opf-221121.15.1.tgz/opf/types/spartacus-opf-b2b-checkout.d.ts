import * as i0 from '@angular/core';
import * as i1 from '@spartacus/opf/b2b-checkout/core';
import * as i2 from '@spartacus/opf/b2b-checkout/components';

declare class OpfB2bCheckoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfB2bCheckoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfB2bCheckoutModule, never, [typeof i1.OpfB2bCheckoutCoreModule, typeof i2.OpfB2bCheckoutComponentsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfB2bCheckoutModule>;
}

export { OpfB2bCheckoutModule };
