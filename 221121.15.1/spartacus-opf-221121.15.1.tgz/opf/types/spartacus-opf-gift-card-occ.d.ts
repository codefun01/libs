import * as i0 from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { LoggerService, OccEndpointsService, OccConfig, OccEndpoint } from '@spartacus/core';
import { OpfGiftCardBalanceRequest, OpfGiftCardResponse } from '@spartacus/opf/gift-card/root';
import { Observable } from 'rxjs';
import { OccCartAdapter } from '@spartacus/cart/base/occ';

declare class OpfGiftCardOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfGiftCardOccModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfGiftCardOccModule>;
}

declare class OccOpfGiftCardAdapter extends OccCartAdapter {
    protected logger: LoggerService;
    protected occEndpoints: OccEndpointsService;
    protected http: HttpClient;
    headers: HttpHeaders;
    applyGiftCard(userId: string, cartId: string, request: OpfGiftCardBalanceRequest): Observable<OpfGiftCardResponse>;
    removeGiftCard(userId: string, cartId: string, giftCardId: string): Observable<void>;
    protected getApplyGiftCardEndpoint(userId: string, cartId: string): string;
    protected getRemoveGiftCardEndpoint(userId: string, cartId: string, giftCardId: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOpfGiftCardAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOpfGiftCardAdapter>;
}

declare const defaultGiftCardOccEndpointsConfig: OccConfig;

interface OccOpfGiftCardEndpoints {
    /**
     * Endpoint for applying gift card and getting balance
     */
    applyGiftCard?: string | OccEndpoint;
    /**
     * Endpoint for removing a gift card
     */
    removeGiftCard?: string | OccEndpoint;
}
declare module '@spartacus/core' {
    interface OccEndpoints extends OccOpfGiftCardEndpoints {
    }
}

export { OccOpfGiftCardAdapter, OpfGiftCardOccModule, defaultGiftCardOccEndpointsConfig };
export type { OccOpfGiftCardEndpoints };
