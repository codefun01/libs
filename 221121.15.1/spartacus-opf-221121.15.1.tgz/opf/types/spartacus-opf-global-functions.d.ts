import * as i0 from '@angular/core';
import * as i1 from '@spartacus/opf/global-functions/core';

declare class OpfGlobalFunctionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGlobalFunctionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfGlobalFunctionsModule, never, [typeof i1.OpfGlobalFunctionsCoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfGlobalFunctionsModule>;
}

export { OpfGlobalFunctionsModule };
