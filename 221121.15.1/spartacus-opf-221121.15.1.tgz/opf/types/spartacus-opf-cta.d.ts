import * as i0 from '@angular/core';
import * as i1 from '@spartacus/opf/cta/core';
import * as i2 from '@spartacus/opf/cta/opf-api';
import * as i3 from '@spartacus/opf/cta/components';

declare class OpfCtaModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCtaModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCtaModule, never, [typeof i1.OpfCtaCoreModule, typeof i2.OpfApiCtaModule, typeof i3.OpfCtaComponentsModule], [typeof i3.OpfCtaComponentsModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCtaModule>;
}

export { OpfCtaModule };
