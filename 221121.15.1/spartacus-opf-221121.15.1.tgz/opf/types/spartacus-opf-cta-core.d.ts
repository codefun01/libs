import { OpfCtaScriptsRequest, OpfCtaScriptsResponse, OpfCtaFacade, OpfCtaScriptsLocation } from '@spartacus/opf/cta/root';
import { Observable, Subject, Subscription } from 'rxjs';
import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import { CommandService, Command, WindowRef, EventService, CurrencyService, LanguageService, Converter } from '@spartacus/core';
import { ActiveCartFacade } from '@spartacus/cart/base/root';
import { OpfKeyValueMap } from '@spartacus/opf/base/root';
import { OpfGlobalFunctionsFacade } from '@spartacus/opf/global-functions/root';
import { CurrentProductService } from '@spartacus/storefront';
import { OrderFacade, OrderHistoryFacade, Order } from '@spartacus/order/root';

declare abstract class OpfCtaAdapter {
    /**
     * Abstract method used to get CTA scripts list
     */
    abstract getCtaScripts(opfCtaScriptsRequest: OpfCtaScriptsRequest): Observable<OpfCtaScriptsResponse>;
}

declare class OpfCtaConnector {
    protected adapter: OpfCtaAdapter;
    getCtaScripts(opfCtaScriptsRequest: OpfCtaScriptsRequest): Observable<OpfCtaScriptsResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCtaConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfCtaConnector>;
}

declare class OpfCtaService implements OpfCtaFacade {
    protected commandService: CommandService;
    protected opfCtaConnector: OpfCtaConnector;
    protected _readyForScriptEvent: Subject<string>;
    readyForScriptEvent$: Observable<string>;
    protected ctaScriptsCommand: Command<{
        opfCtaScriptsRequest: OpfCtaScriptsRequest;
    }, OpfCtaScriptsResponse>;
    getCtaScripts(opfCtaScriptsRequest: OpfCtaScriptsRequest): Observable<OpfCtaScriptsResponse>;
    emitScriptReadyEvent(scriptIdentifier: string): void;
    listenScriptReadyEvent(): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCtaService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfCtaService>;
}

declare class OpfCtaCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCtaCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCtaCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCtaCoreModule>;
}

declare class OpfDynamicCtaService {
    protected globalFunctionsFacade: OpfGlobalFunctionsFacade;
    protected winRef: WindowRef;
    protected eventService: EventService;
    protected currencyService: CurrencyService;
    protected languageService: LanguageService;
    protected activeCartFacade: ActiveCartFacade;
    protected opfCtaFacade: OpfCtaFacade;
    protected currentProductService: CurrentProductService;
    protected subList: Array<Subscription>;
    protected isOnsiteMessagingInit: boolean;
    protected scriptIdentifiers: Array<string>;
    protected isCartPage: boolean;
    fillCtaRequestforCartPage(scriptLocation: OpfCtaScriptsLocation, paymentAccountIds: number[]): Observable<OpfCtaScriptsRequest>;
    fillCtaRequestforProductPage(scriptLocation: OpfCtaScriptsLocation, paymentAccountIds: number[]): Observable<OpfCtaScriptsRequest>;
    protected fillAdditionalData(): Observable<Array<OpfKeyValueMap>>;
    initiateEvents(): void;
    stopEvents(): void;
    protected getNewScriptIdentifier(): string;
    registerScriptReadyEvent(): void;
    protected listenScriptReadyEvent(): void;
    protected dispatchCartEvents(scriptIdentifiers: Array<string>): void;
    protected dispatchProductEvents(scriptIdentifiers: Array<string>, quantity?: number): void;
    protected productChangedListener(): void;
    protected cartChangedListener(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfDynamicCtaService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfDynamicCtaService>;
}

declare class OpfStaticCtaService {
    protected orderDetailsService: OrderFacade;
    protected orderHistoryService: OrderHistoryFacade;
    fillCtaRequestforPagesWithOrder(scriptLocation: OpfCtaScriptsLocation): Observable<OpfCtaScriptsRequest>;
    protected getOrderDetails(scriptsLocation: OpfCtaScriptsLocation): Observable<Order>;
    protected getProductItems(order: Order): {
        productId: string;
        quantity: number;
    }[] | [];
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfStaticCtaService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfStaticCtaService>;
}

declare const OPF_CTA_SCRIPTS_NORMALIZER: InjectionToken<Converter<any, OpfCtaScriptsResponse>>;

export { OPF_CTA_SCRIPTS_NORMALIZER, OpfCtaAdapter, OpfCtaConnector, OpfCtaCoreModule, OpfCtaService, OpfDynamicCtaService, OpfStaticCtaService };
