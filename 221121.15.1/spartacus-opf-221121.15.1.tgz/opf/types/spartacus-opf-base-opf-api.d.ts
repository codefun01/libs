import { OpfApiEndpoint } from '@spartacus/opf/base/root';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare module '@spartacus/opf/base/root' {
    interface OpfApiEndpoints {
        /**
         * Endpoint to get active payment configurations
         */
        getActiveConfigurations?: string | OpfApiEndpoint;
    }
}

declare class OpfApiBaseModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfApiBaseModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfApiBaseModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfApiBaseModule>;
}

export { OpfApiBaseModule };
