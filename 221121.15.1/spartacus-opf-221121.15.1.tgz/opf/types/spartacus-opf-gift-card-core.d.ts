import * as i0 from '@angular/core';
import { OpfGiftCardBalanceRequest, OpfGiftCardResponse, OpfGiftCardFacade } from '@spartacus/opf/gift-card/root';
import { Observable } from 'rxjs';
import { ActiveCartFacade, Cart } from '@spartacus/cart/base/root';
import { OpfBaseFacade, OpfActiveConfiguration } from '@spartacus/opf/base/root';
import { UserIdService } from '@spartacus/core';

declare class OpfGiftCardCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfGiftCardCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfGiftCardCoreModule>;
}

declare abstract class OpfGiftCardAdapter {
    /**
     * Apply gift card and get balance
     */
    abstract applyGiftCard(userId: string, cartId: string, opfGiftCardBalanceRequest: OpfGiftCardBalanceRequest): Observable<OpfGiftCardResponse>;
    /**
     * Remove a previously applied gift card
     */
    abstract removeGiftCard(userId: string, cartId: string, giftCardId: string): Observable<void>;
}

declare class OpfGiftCardConnector {
    protected adapter: OpfGiftCardAdapter;
    applyGiftCard(userId: string, cartId: string, opfGiftCardBalanceRequest: OpfGiftCardBalanceRequest): Observable<OpfGiftCardResponse>;
    removeGiftCard(userId: string, cartId: string, giftCardId: string): Observable<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfGiftCardConnector>;
}

declare class OpfGiftCardService implements OpfGiftCardFacade {
    protected opfBaseFacade: OpfBaseFacade;
    protected opfGiftCardConnector: OpfGiftCardConnector;
    protected activeCartFacade: ActiveCartFacade;
    protected userIdService: UserIdService;
    /**
     * Get gift card payment configuration from active configurations.
     * Filters by providerType: "STORED_VALUE_PAYMENT".
     *
     * @returns Observable of gift card configuration or undefined if not found
     */
    getGiftCardConfiguration(): Observable<OpfActiveConfiguration | undefined>;
    isGiftCardEnabled(): Observable<boolean>;
    isGiftCardCoveredTotalAmount(cart$: Observable<Cart>): Observable<boolean>;
    /**
     * Apply a gift card to the active cart.
     *
     * @param request Gift card balance request with card number and security code
     * @returns Observable of the applied gift card response
     */
    applyGiftCard(request: OpfGiftCardBalanceRequest): Observable<OpfGiftCardResponse>;
    /**
     * Remove a previously applied gift card from the active cart.
     *
     * @param giftCardId The ID of the gift card to remove
     */
    removeGiftCard(giftCardId: string): Observable<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfGiftCardService>;
}

export { OpfGiftCardAdapter, OpfGiftCardConnector, OpfGiftCardCoreModule, OpfGiftCardService };
