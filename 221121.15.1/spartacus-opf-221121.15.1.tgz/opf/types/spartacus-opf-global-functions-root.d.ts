import * as i0 from '@angular/core';
import { ViewContainerRef } from '@angular/core';
import { OpfKeyValueMap } from '@spartacus/opf/base/root';
import { OccConfig } from '@spartacus/core';

declare enum OpfGlobalFunctionsDomain {
    CHECKOUT = "checkout",
    GLOBAL = "global",
    REDIRECT = "redirect"
}
interface OpfRegisterGlobalFunctionsInput {
    paymentSessionId: string;
    vcr?: ViewContainerRef;
    paramsMap?: Array<OpfKeyValueMap>;
    domain: OpfGlobalFunctionsDomain;
}

declare abstract class OpfGlobalFunctionsFacade {
    /**
     * Abstract method to register global functions used in Hosted-Fields pattern.
     * Optional vcr ViewcontainerRef param is used to display an overlayed loader spinner.
     *
     * @param {string} paymentSessionId
     * @param {ViewContainerRef} vcr
     */
    abstract registerGlobalFunctions(gfInput: OpfRegisterGlobalFunctionsInput): void;
    /**
     * Abstract method to remove global functions used in Hosted-Fields pattern
     */
    abstract unregisterGlobalFunctions(domain: OpfGlobalFunctionsDomain): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGlobalFunctionsFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfGlobalFunctionsFacade>;
}

declare const OPF_GLOBAL_FUNCTIONS_FEATURE = "opfGlobalFunctions";

declare class OpfGlobalFunctionsRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGlobalFunctionsRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfGlobalFunctionsRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfGlobalFunctionsRootModule>;
}

declare const defaultOccOpfCartConfig: OccConfig;

export { OPF_GLOBAL_FUNCTIONS_FEATURE, OpfGlobalFunctionsDomain, OpfGlobalFunctionsFacade, OpfGlobalFunctionsRootModule, defaultOccOpfCartConfig };
export type { OpfRegisterGlobalFunctionsInput };
