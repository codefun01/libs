import * as i0 from '@angular/core';
import { Observable } from 'rxjs';
import { UserPaymentService } from '@spartacus/core';
import { OpfTokenisationFacade, OpfPaymentDetails } from '@spartacus/opf/tokenisation/root';

/**
 * OPF Tokenisation Adapter
 *
 * Reserved for OPF-specific HTTP operations related to payment tokenisation.
 * Currently unused as all payment operations are delegated to the core UserPaymentService to avoid code duplication.
 * However, this adapter serves as a placeholder for any future OPF-specific tokenisation logic that may arise as the feature evolves.
 *
 */
declare class OpfTokenisationAdapter {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfTokenisationAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfTokenisationAdapter>;
}

/**
 * OPF Tokenisation Connector
 *
 * Central connector for OPF payment tokenisation operations.
 * Acts as an intermediary between the service layer and adapters.
 *
 * Currently delegates all payment operations to core UserPaymentService to avoid code duplication.
 * Can be extended to integrate OPF-specific adapters as needed.
 *
 */
declare class OpfTokenisationConnector {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfTokenisationConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfTokenisationConnector>;
}

declare class OpfTokenisationService implements OpfTokenisationFacade {
    protected userPaymentService: UserPaymentService;
    /**
     * Returns all user's payment methods
     */
    getPaymentMethods(): Observable<OpfPaymentDetails[]>;
    /**
     * Returns a loading flag for payment methods
     */
    getPaymentMethodsLoading(): Observable<boolean>;
    /**
     * Loads all user's payment methods
     */
    loadPaymentMethods(): void;
    /**
     * Deletes the payment method
     *
     * @param paymentMethodId a payment method ID
     */
    deletePaymentMethod(paymentMethodId: string): void;
    /**
     * Sets the payment as a default one
     * @param paymentMethodId a payment method ID
     */
    setPaymentMethodAsDefault(paymentMethodId: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfTokenisationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfTokenisationService>;
}

declare class OpfTokenisationCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfTokenisationCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfTokenisationCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfTokenisationCoreModule>;
}

export { OpfTokenisationAdapter, OpfTokenisationConnector, OpfTokenisationCoreModule, OpfTokenisationService };
