import { CheckoutConfig } from '@spartacus/checkout/base/root';
import { OccConfig, CmsConfig } from '@spartacus/core';
import * as i0 from '@angular/core';

declare const defaultOpfB2bCheckoutConfig: CheckoutConfig;

declare const defaultOpfB2bCheckoutOccEndpointsConfig: OccConfig;

declare const OPF_B2B_CHECKOUT_FEATURE = "opfB2bCheckout";

declare const OPF_B2B_CHECKOUT_CMS_COMPONENTS: string[];
declare function defaultOpfB2bCheckoutComponentsConfig(): CmsConfig;
declare class OpfB2bCheckoutRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfB2bCheckoutRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfB2bCheckoutRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfB2bCheckoutRootModule>;
}

export { OPF_B2B_CHECKOUT_CMS_COMPONENTS, OPF_B2B_CHECKOUT_FEATURE, OpfB2bCheckoutRootModule, defaultOpfB2bCheckoutComponentsConfig, defaultOpfB2bCheckoutConfig, defaultOpfB2bCheckoutOccEndpointsConfig };
