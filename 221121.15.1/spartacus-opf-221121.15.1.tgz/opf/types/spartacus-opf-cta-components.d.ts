import * as i0 from '@angular/core';
import { AfterViewInit } from '@angular/core';
import * as i1 from '@angular/common';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { CmsService, WindowRef } from '@spartacus/core';
import * as _spartacus_opf_base_root from '@spartacus/opf/base/root';
import { OpfBaseFacade, OpfResourceLoaderService, OpfDynamicScript } from '@spartacus/opf/base/root';
import * as rxjs from 'rxjs';
import { Observable } from 'rxjs';
import { OpfCtaFacade, OpfCtaScriptsRequest, OpfCtaScriptsLocation } from '@spartacus/opf/cta/root';
import { OpfDynamicCtaService, OpfStaticCtaService } from '@spartacus/opf/cta/core';

declare class OpfCtaScriptsService {
    protected opfBaseFacade: OpfBaseFacade;
    protected opfCtaFacade: OpfCtaFacade;
    protected opfResourceLoaderService: OpfResourceLoaderService;
    protected cmsService: CmsService;
    protected opfDynamicCtaService: OpfDynamicCtaService;
    protected opfStaticCtaService: OpfStaticCtaService;
    loadAndRunScript(script: OpfDynamicScript): Promise<OpfDynamicScript | undefined>;
    getCtaHtmlList(): Observable<OpfDynamicScript[]>;
    protected fetchCtaScripts(opfCtaScriptsRequest: OpfCtaScriptsRequest): Observable<OpfDynamicScript[]>;
    protected fillCtaScriptRequest(): Observable<OpfCtaScriptsRequest>;
    protected fillRequestForTargetPage(scriptsLocation: OpfCtaScriptsLocation | undefined, paymentAccountIds: number[]): Observable<OpfCtaScriptsRequest>;
    getQuickBuyCtaHtmlList(): Observable<OpfDynamicScript[]>;
    protected fillQuickBuyCtaScriptRequest(): Observable<OpfCtaScriptsRequest>;
    protected getQuickBuyScriptLocation(): Observable<OpfCtaScriptsLocation | undefined>;
    protected getScriptLocation(): Observable<OpfCtaScriptsLocation | undefined>;
    protected getPaymentAccountIds(): Observable<number[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCtaScriptsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfCtaScriptsService>;
}

declare class OpfCtaElementComponent implements AfterViewInit {
    protected sanitizer: DomSanitizer;
    protected opfCtaScriptsService: OpfCtaScriptsService;
    protected windowRef: WindowRef;
    ctaScriptHtml: OpfDynamicScript;
    ngAfterViewInit(): void;
    renderHtml(html: string): SafeHtml;
    protected removeScriptTags(html: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCtaElementComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfCtaElementComponent, "cx-opf-cta-element", never, { "ctaScriptHtml": { "alias": "ctaScriptHtml"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OpfCtaElementModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCtaElementModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCtaElementModule, never, [typeof i1.CommonModule, typeof OpfCtaElementComponent], [typeof OpfCtaElementComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCtaElementModule>;
}

declare class OpfCtaScriptsComponent {
    protected opfCtaScriptService: OpfCtaScriptsService;
    ctaHtmls$: rxjs.Observable<_spartacus_opf_base_root.OpfDynamicScript[] | never[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCtaScriptsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfCtaScriptsComponent, "cx-opf-cta-scripts", never, {}, {}, never, never, true, never>;
}

declare class OpfCtaScriptsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCtaScriptsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCtaScriptsModule, never, [typeof i1.CommonModule, typeof OpfCtaElementModule, typeof OpfCtaScriptsComponent], [typeof OpfCtaScriptsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCtaScriptsModule>;
}

declare class OpfCtaQuickBuyButtonsComponent {
    protected opfCtaScriptService: OpfCtaScriptsService;
    ctaHtmls$: rxjs.Observable<_spartacus_opf_base_root.OpfDynamicScript[] | never[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCtaQuickBuyButtonsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfCtaQuickBuyButtonsComponent, "cx-opf-cta-quick-buy-buttons", never, {}, {}, never, never, true, never>;
}

declare class OpfCtaQuickBuyButtonsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCtaQuickBuyButtonsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCtaQuickBuyButtonsModule, never, [typeof OpfCtaQuickBuyButtonsComponent], [typeof OpfCtaQuickBuyButtonsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCtaQuickBuyButtonsModule>;
}

declare class OpfCtaComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCtaComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCtaComponentsModule, never, [typeof OpfCtaScriptsModule, typeof OpfCtaElementModule, typeof OpfCtaQuickBuyButtonsModule], [typeof OpfCtaScriptsModule, typeof OpfCtaElementModule, typeof OpfCtaQuickBuyButtonsModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCtaComponentsModule>;
}

export { OpfCtaComponentsModule, OpfCtaElementComponent, OpfCtaElementModule, OpfCtaQuickBuyButtonsComponent, OpfCtaQuickBuyButtonsModule, OpfCtaScriptsComponent, OpfCtaScriptsModule, OpfCtaScriptsService };
