import * as i0 from '@angular/core';
import * as i1 from '@spartacus/opf/checkout/components';

declare class OpfCheckoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCheckoutModule, never, [typeof i1.OpfCheckoutComponentsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCheckoutModule>;
}

export { OpfCheckoutModule };
