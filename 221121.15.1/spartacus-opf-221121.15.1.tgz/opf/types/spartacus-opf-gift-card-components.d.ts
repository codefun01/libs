import * as i0 from '@angular/core';

declare class OpfGiftCardComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGiftCardComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfGiftCardComponentsModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfGiftCardComponentsModule>;
}

export { OpfGiftCardComponentsModule };
