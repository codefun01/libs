import { OccEndpoint } from '@spartacus/core';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

interface OccOpfPaymentEndpoints {
    /**
     * Sets the payment option for the checkout cart
     */
    setCartPaymentOption?: string | OccEndpoint;
}
declare module '@spartacus/core' {
    interface OccEndpoints extends OccOpfPaymentEndpoints {
    }
}

declare class OpfPaymentOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfPaymentOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfPaymentOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfPaymentOccModule>;
}

export { OpfPaymentOccModule };
export type { OccOpfPaymentEndpoints };
