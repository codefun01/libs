import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    opfCheckout: {
        opfCheckout: {
            tabs: {
                paymentType: string;
                shipping: string;
                deliveryMethod: string;
                paymentAndReview: string;
                review: string;
            };
            paymentAndReviewTitle: string;
            billingAddress: string;
            paymentOption: string;
            paymentMethod: string;
            noPaymentMethod: string;
            editCardDefaultLabel: string;
            editPaymentMethod: string;
            poNumber: string;
            noPoNumber: string;
            editPoNumber: string;
            costCenter: string;
            editCostCenter: string;
            termsAndConditions: string;
            closeTermsAndConditionsAlert: string;
            itemsToBeShipped: string;
            proceedPayment: string;
            defaultPaymentInfoMessage: string;
            proceedPaymentButtonLabel: string;
            retryPayment: string;
            checkTermsAndConditionsExplicit: string;
            checkTermsAndConditionsImplicit: string;
            errors: {
                loadActiveConfigurations: string;
                noActiveConfigurations: string;
                updateBillingAddress: string;
            };
        };
    };
};

declare const de: {
    opfCheckout: {
        opfCheckout: {
            tabs: {
                paymentType: string;
                shipping: string;
                deliveryMethod: string;
                paymentAndReview: string;
                review: string;
            };
            paymentAndReviewTitle: string;
            billingAddress: string;
            paymentOption: string;
            paymentMethod: string;
            noPaymentMethod: string;
            editCardDefaultLabel: string;
            editPaymentMethod: string;
            poNumber: string;
            noPoNumber: string;
            editPoNumber: string;
            costCenter: string;
            editCostCenter: string;
            termsAndConditions: string;
            closeTermsAndConditionsAlert: string;
            itemsToBeShipped: string;
            proceedPayment: string;
            defaultPaymentInfoMessage: string;
            proceedPaymentButtonLabel: string;
            retryPayment: string;
            checkTermsAndConditionsExplicit: string;
            checkTermsAndConditionsImplicit: string;
            errors: {
                loadActiveConfigurations: string;
                noActiveConfigurations: string;
                updateBillingAddress: string;
            };
        };
    };
};

declare const en: {
    opfCheckout: {
        opfCheckout: {
            tabs: {
                paymentType: string;
                shipping: string;
                deliveryMethod: string;
                paymentAndReview: string;
                review: string;
            };
            paymentAndReviewTitle: string;
            billingAddress: string;
            paymentOption: string;
            paymentMethod: string;
            noPaymentMethod: string;
            editCardDefaultLabel: string;
            editPaymentMethod: string;
            poNumber: string;
            noPoNumber: string;
            editPoNumber: string;
            costCenter: string;
            editCostCenter: string;
            termsAndConditions: string;
            closeTermsAndConditionsAlert: string;
            itemsToBeShipped: string;
            proceedPayment: string;
            defaultPaymentInfoMessage: string;
            proceedPaymentButtonLabel: string;
            retryPayment: string;
            checkTermsAndConditionsExplicit: string;
            checkTermsAndConditionsImplicit: string;
            termsAndConditionsDisclaimer: string;
            savedPaymentHeading: string;
            newPaymentHeading: string;
            cards: string;
            errors: {
                loadActiveConfigurations: string;
                noActiveConfigurations: string;
                updateBillingAddress: string;
                noBillingAddress: string;
            };
        };
    };
};

declare const es: {
    opfCheckout: {
        opfCheckout: {
            tabs: {
                paymentType: string;
                shipping: string;
                deliveryMethod: string;
                paymentAndReview: string;
                review: string;
            };
            paymentAndReviewTitle: string;
            billingAddress: string;
            paymentOption: string;
            paymentMethod: string;
            noPaymentMethod: string;
            editCardDefaultLabel: string;
            editPaymentMethod: string;
            poNumber: string;
            noPoNumber: string;
            editPoNumber: string;
            costCenter: string;
            editCostCenter: string;
            termsAndConditions: string;
            closeTermsAndConditionsAlert: string;
            itemsToBeShipped: string;
            proceedPayment: string;
            defaultPaymentInfoMessage: string;
            proceedPaymentButtonLabel: string;
            retryPayment: string;
            checkTermsAndConditionsExplicit: string;
            checkTermsAndConditionsImplicit: string;
            errors: {
                loadActiveConfigurations: string;
                noActiveConfigurations: string;
                updateBillingAddress: string;
            };
        };
    };
};

declare const es_CO: {
    opfCheckout: {
        opfCheckout: {
            tabs: {
                paymentType: string;
                shipping: string;
                deliveryMethod: string;
                paymentAndReview: string;
                review: string;
            };
            paymentAndReviewTitle: string;
            billingAddress: string;
            paymentOption: string;
            paymentMethod: string;
            noPaymentMethod: string;
            editCardDefaultLabel: string;
            editPaymentMethod: string;
            poNumber: string;
            noPoNumber: string;
            editPoNumber: string;
            costCenter: string;
            editCostCenter: string;
            termsAndConditions: string;
            closeTermsAndConditionsAlert: string;
            itemsToBeShipped: string;
            proceedPayment: string;
            defaultPaymentInfoMessage: string;
            proceedPaymentButtonLabel: string;
            retryPayment: string;
            checkTermsAndConditionsExplicit: string;
            checkTermsAndConditionsImplicit: string;
            errors: {
                loadActiveConfigurations: string;
                noActiveConfigurations: string;
                updateBillingAddress: string;
            };
        };
    };
};

declare const fr: {
    opfCheckout: {
        opfCheckout: {
            tabs: {
                paymentType: string;
                shipping: string;
                deliveryMethod: string;
                paymentAndReview: string;
                review: string;
            };
            paymentAndReviewTitle: string;
            billingAddress: string;
            paymentOption: string;
            paymentMethod: string;
            noPaymentMethod: string;
            editCardDefaultLabel: string;
            editPaymentMethod: string;
            poNumber: string;
            noPoNumber: string;
            editPoNumber: string;
            costCenter: string;
            editCostCenter: string;
            termsAndConditions: string;
            closeTermsAndConditionsAlert: string;
            itemsToBeShipped: string;
            proceedPayment: string;
            defaultPaymentInfoMessage: string;
            proceedPaymentButtonLabel: string;
            retryPayment: string;
            checkTermsAndConditionsExplicit: string;
            checkTermsAndConditionsImplicit: string;
            errors: {
                loadActiveConfigurations: string;
                noActiveConfigurations: string;
                updateBillingAddress: string;
            };
        };
    };
};

declare const hi: {
    opfCheckout: {
        opfCheckout: {
            tabs: {
                paymentType: string;
                shipping: string;
                deliveryMethod: string;
                paymentAndReview: string;
                review: string;
            };
            paymentAndReviewTitle: string;
            billingAddress: string;
            paymentOption: string;
            paymentMethod: string;
            noPaymentMethod: string;
            editCardDefaultLabel: string;
            editPaymentMethod: string;
            poNumber: string;
            noPoNumber: string;
            editPoNumber: string;
            costCenter: string;
            editCostCenter: string;
            termsAndConditions: string;
            closeTermsAndConditionsAlert: string;
            itemsToBeShipped: string;
            proceedPayment: string;
            defaultPaymentInfoMessage: string;
            proceedPaymentButtonLabel: string;
            retryPayment: string;
            checkTermsAndConditionsExplicit: string;
            checkTermsAndConditionsImplicit: string;
            errors: {
                loadActiveConfigurations: string;
                noActiveConfigurations: string;
                updateBillingAddress: string;
            };
        };
    };
};

declare const hu: {
    opfCheckout: {
        opfCheckout: {
            tabs: {
                paymentType: string;
                shipping: string;
                deliveryMethod: string;
                paymentAndReview: string;
                review: string;
            };
            paymentAndReviewTitle: string;
            billingAddress: string;
            paymentOption: string;
            paymentMethod: string;
            noPaymentMethod: string;
            editCardDefaultLabel: string;
            editPaymentMethod: string;
            poNumber: string;
            noPoNumber: string;
            editPoNumber: string;
            costCenter: string;
            editCostCenter: string;
            termsAndConditions: string;
            closeTermsAndConditionsAlert: string;
            itemsToBeShipped: string;
            proceedPayment: string;
            defaultPaymentInfoMessage: string;
            proceedPaymentButtonLabel: string;
            retryPayment: string;
            checkTermsAndConditionsExplicit: string;
            checkTermsAndConditionsImplicit: string;
            errors: {
                loadActiveConfigurations: string;
                noActiveConfigurations: string;
                updateBillingAddress: string;
            };
        };
    };
};

declare const id: {
    opfCheckout: {
        opfCheckout: {
            tabs: {
                paymentType: string;
                shipping: string;
                deliveryMethod: string;
                paymentAndReview: string;
                review: string;
            };
            paymentAndReviewTitle: string;
            billingAddress: string;
            paymentOption: string;
            paymentMethod: string;
            noPaymentMethod: string;
            editCardDefaultLabel: string;
            editPaymentMethod: string;
            poNumber: string;
            noPoNumber: string;
            editPoNumber: string;
            costCenter: string;
            editCostCenter: string;
            termsAndConditions: string;
            closeTermsAndConditionsAlert: string;
            itemsToBeShipped: string;
            proceedPayment: string;
            defaultPaymentInfoMessage: string;
            proceedPaymentButtonLabel: string;
            retryPayment: string;
            checkTermsAndConditionsExplicit: string;
            checkTermsAndConditionsImplicit: string;
            errors: {
                loadActiveConfigurations: string;
                noActiveConfigurations: string;
                updateBillingAddress: string;
            };
        };
    };
};

declare const it: {
    opfCheckout: {
        opfCheckout: {
            tabs: {
                paymentType: string;
                shipping: string;
                deliveryMethod: string;
                paymentAndReview: string;
                review: string;
            };
            paymentAndReviewTitle: string;
            billingAddress: string;
            paymentOption: string;
            paymentMethod: string;
            noPaymentMethod: string;
            editCardDefaultLabel: string;
            editPaymentMethod: string;
            poNumber: string;
            noPoNumber: string;
            editPoNumber: string;
            costCenter: string;
            editCostCenter: string;
            termsAndConditions: string;
            closeTermsAndConditionsAlert: string;
            itemsToBeShipped: string;
            proceedPayment: string;
            defaultPaymentInfoMessage: string;
            proceedPaymentButtonLabel: string;
            retryPayment: string;
            checkTermsAndConditionsExplicit: string;
            checkTermsAndConditionsImplicit: string;
            errors: {
                loadActiveConfigurations: string;
                noActiveConfigurations: string;
                updateBillingAddress: string;
            };
        };
    };
};

declare const ja: {
    opfCheckout: {
        opfCheckout: {
            tabs: {
                paymentType: string;
                shipping: string;
                deliveryMethod: string;
                paymentAndReview: string;
                review: string;
            };
            paymentAndReviewTitle: string;
            billingAddress: string;
            paymentOption: string;
            paymentMethod: string;
            noPaymentMethod: string;
            editCardDefaultLabel: string;
            editPaymentMethod: string;
            poNumber: string;
            noPoNumber: string;
            editPoNumber: string;
            costCenter: string;
            editCostCenter: string;
            termsAndConditions: string;
            closeTermsAndConditionsAlert: string;
            itemsToBeShipped: string;
            proceedPayment: string;
            defaultPaymentInfoMessage: string;
            proceedPaymentButtonLabel: string;
            retryPayment: string;
            checkTermsAndConditionsExplicit: string;
            checkTermsAndConditionsImplicit: string;
            errors: {
                loadActiveConfigurations: string;
                noActiveConfigurations: string;
                updateBillingAddress: string;
            };
        };
    };
};

declare const ko: {
    opfCheckout: {
        opfCheckout: {
            tabs: {
                paymentType: string;
                shipping: string;
                deliveryMethod: string;
                paymentAndReview: string;
                review: string;
            };
            paymentAndReviewTitle: string;
            billingAddress: string;
            paymentOption: string;
            paymentMethod: string;
            noPaymentMethod: string;
            editCardDefaultLabel: string;
            editPaymentMethod: string;
            poNumber: string;
            noPoNumber: string;
            editPoNumber: string;
            costCenter: string;
            editCostCenter: string;
            termsAndConditions: string;
            closeTermsAndConditionsAlert: string;
            itemsToBeShipped: string;
            proceedPayment: string;
            defaultPaymentInfoMessage: string;
            proceedPaymentButtonLabel: string;
            retryPayment: string;
            checkTermsAndConditionsExplicit: string;
            checkTermsAndConditionsImplicit: string;
            errors: {
                loadActiveConfigurations: string;
                noActiveConfigurations: string;
                updateBillingAddress: string;
            };
        };
    };
};

declare const pl: {
    opfCheckout: {
        opfCheckout: {
            tabs: {
                paymentType: string;
                shipping: string;
                deliveryMethod: string;
                paymentAndReview: string;
                review: string;
            };
            paymentAndReviewTitle: string;
            billingAddress: string;
            paymentOption: string;
            paymentMethod: string;
            noPaymentMethod: string;
            editCardDefaultLabel: string;
            editPaymentMethod: string;
            poNumber: string;
            noPoNumber: string;
            editPoNumber: string;
            costCenter: string;
            editCostCenter: string;
            termsAndConditions: string;
            closeTermsAndConditionsAlert: string;
            itemsToBeShipped: string;
            proceedPayment: string;
            defaultPaymentInfoMessage: string;
            proceedPaymentButtonLabel: string;
            retryPayment: string;
            checkTermsAndConditionsExplicit: string;
            checkTermsAndConditionsImplicit: string;
            errors: {
                loadActiveConfigurations: string;
                noActiveConfigurations: string;
                updateBillingAddress: string;
            };
        };
    };
};

declare const pt: {
    opfCheckout: {
        opfCheckout: {
            tabs: {
                paymentType: string;
                shipping: string;
                deliveryMethod: string;
                paymentAndReview: string;
                review: string;
            };
            paymentAndReviewTitle: string;
            billingAddress: string;
            paymentOption: string;
            paymentMethod: string;
            noPaymentMethod: string;
            editCardDefaultLabel: string;
            editPaymentMethod: string;
            poNumber: string;
            noPoNumber: string;
            editPoNumber: string;
            costCenter: string;
            editCostCenter: string;
            termsAndConditions: string;
            closeTermsAndConditionsAlert: string;
            itemsToBeShipped: string;
            proceedPayment: string;
            defaultPaymentInfoMessage: string;
            proceedPaymentButtonLabel: string;
            retryPayment: string;
            checkTermsAndConditionsExplicit: string;
            checkTermsAndConditionsImplicit: string;
            errors: {
                loadActiveConfigurations: string;
                noActiveConfigurations: string;
                updateBillingAddress: string;
            };
        };
    };
};

declare const ru: {
    opfCheckout: {
        opfCheckout: {
            tabs: {
                paymentType: string;
                shipping: string;
                deliveryMethod: string;
                paymentAndReview: string;
                review: string;
            };
            paymentAndReviewTitle: string;
            billingAddress: string;
            paymentOption: string;
            paymentMethod: string;
            noPaymentMethod: string;
            editCardDefaultLabel: string;
            editPaymentMethod: string;
            poNumber: string;
            noPoNumber: string;
            editPoNumber: string;
            costCenter: string;
            editCostCenter: string;
            termsAndConditions: string;
            closeTermsAndConditionsAlert: string;
            itemsToBeShipped: string;
            proceedPayment: string;
            defaultPaymentInfoMessage: string;
            proceedPaymentButtonLabel: string;
            retryPayment: string;
            checkTermsAndConditionsExplicit: string;
            checkTermsAndConditionsImplicit: string;
            errors: {
                loadActiveConfigurations: string;
                noActiveConfigurations: string;
                updateBillingAddress: string;
            };
        };
    };
};

declare const zh: {
    opfCheckout: {
        opfCheckout: {
            tabs: {
                paymentType: string;
                shipping: string;
                deliveryMethod: string;
                paymentAndReview: string;
                review: string;
            };
            paymentAndReviewTitle: string;
            billingAddress: string;
            paymentOption: string;
            paymentMethod: string;
            noPaymentMethod: string;
            editCardDefaultLabel: string;
            editPaymentMethod: string;
            poNumber: string;
            noPoNumber: string;
            editPoNumber: string;
            costCenter: string;
            editCostCenter: string;
            termsAndConditions: string;
            closeTermsAndConditionsAlert: string;
            itemsToBeShipped: string;
            proceedPayment: string;
            defaultPaymentInfoMessage: string;
            proceedPaymentButtonLabel: string;
            retryPayment: string;
            checkTermsAndConditionsExplicit: string;
            checkTermsAndConditionsImplicit: string;
            errors: {
                loadActiveConfigurations: string;
                noActiveConfigurations: string;
                updateBillingAddress: string;
            };
        };
    };
};

declare const zh_TW: {
    opfCheckout: {
        opfCheckout: {
            tabs: {
                paymentType: string;
                shipping: string;
                deliveryMethod: string;
                paymentAndReview: string;
                review: string;
            };
            paymentAndReviewTitle: string;
            billingAddress: string;
            paymentOption: string;
            paymentMethod: string;
            noPaymentMethod: string;
            editCardDefaultLabel: string;
            editPaymentMethod: string;
            poNumber: string;
            noPoNumber: string;
            editPoNumber: string;
            costCenter: string;
            editCostCenter: string;
            termsAndConditions: string;
            closeTermsAndConditionsAlert: string;
            itemsToBeShipped: string;
            proceedPayment: string;
            defaultPaymentInfoMessage: string;
            proceedPaymentButtonLabel: string;
            retryPayment: string;
            checkTermsAndConditionsExplicit: string;
            checkTermsAndConditionsImplicit: string;
            errors: {
                loadActiveConfigurations: string;
                noActiveConfigurations: string;
                updateBillingAddress: string;
            };
        };
    };
};

declare const opfCheckoutTranslationChunksConfig: TranslationChunksConfig;

export { opfCheckoutTranslationChunksConfig, cs as opfCheckoutTranslationsCs, de as opfCheckoutTranslationsDe, en as opfCheckoutTranslationsEn, es as opfCheckoutTranslationsEs, es_CO as opfCheckoutTranslationsEs_CO, fr as opfCheckoutTranslationsFr, hi as opfCheckoutTranslationsHi, hu as opfCheckoutTranslationsHu, id as opfCheckoutTranslationsId, it as opfCheckoutTranslationsIt, ja as opfCheckoutTranslationsJa, ko as opfCheckoutTranslationsKo, pl as opfCheckoutTranslationsPl, pt as opfCheckoutTranslationsPt, ru as opfCheckoutTranslationsRu, zh as opfCheckoutTranslationsZh, zh_TW as opfCheckoutTranslationsZh_TW };
