import { ApplePaySessionVerificationRequest, ApplePaySessionVerificationResponse, OpfQuickBuyFacade, OpfQuickBuyDeliveryType, OpfQuickBuyDeliveryInfo, OpfQuickBuyLocation } from '@spartacus/opf/quick-buy/root';
import * as rxjs from 'rxjs';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import { CartAccessCodeFacade, ActiveCartFacade, CartGuestUserFacade, MultiCartFacade, DeliveryMode, Cart, CartGuestUser } from '@spartacus/cart/base/root';
import { CommandService, UserIdService, LoggerService, Command, BaseSiteService, RoutingService, UserAddressService, AuthService, Address, Converter } from '@spartacus/core';
import { CheckoutDeliveryModesFacade, CheckoutDeliveryAddressFacade, CheckoutBillingAddressFacade } from '@spartacus/checkout/base/root';
import { OpfGlobalMessageService } from '@spartacus/opf/base/root';

declare abstract class OpfQuickBuyAdapter {
    /**
     * Abstract method used to request an ApplePay session, used by QuickBuy functionality
     */
    abstract getApplePayWebSession(applePayRequest: ApplePaySessionVerificationRequest, otpKey: string): Observable<ApplePaySessionVerificationResponse>;
}

declare class OpfQuickBuyConnector {
    protected adapter: OpfQuickBuyAdapter;
    getApplePayWebSession(applePayWebRequest: ApplePaySessionVerificationRequest, accessCode: string): Observable<ApplePaySessionVerificationResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfQuickBuyConnector>;
}

declare class OpfQuickBuyService implements OpfQuickBuyFacade {
    protected commandService: CommandService;
    protected opfQuickBuyConnector: OpfQuickBuyConnector;
    protected cartAccessCodeFacade: CartAccessCodeFacade;
    protected activeCartFacade: ActiveCartFacade;
    protected userIdService: UserIdService;
    protected logger: LoggerService;
    protected applePaySessionCommand: Command<{
        applePayWebSessionRequest: ApplePaySessionVerificationRequest;
    }, ApplePaySessionVerificationResponse>;
    getApplePayWebSession(applePayWebSessionRequest: ApplePaySessionVerificationRequest): rxjs.Observable<ApplePaySessionVerificationResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfQuickBuyService>;
}

declare class OpfQuickBuyCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfQuickBuyCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfQuickBuyCoreModule>;
}

declare class OpfQuickBuyTransactionService {
    protected baseSiteService: BaseSiteService;
    protected activeCartFacade: ActiveCartFacade;
    protected routingService: RoutingService;
    protected checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade;
    protected checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade;
    protected checkoutBillingAddressFacade: CheckoutBillingAddressFacade;
    protected userAddressService: UserAddressService;
    protected opfGlobalMessageService: OpfGlobalMessageService;
    protected cartGuestUserFacade: CartGuestUserFacade;
    protected authService: AuthService;
    protected userIdService: UserIdService;
    protected multiCartFacade: MultiCartFacade;
    getTransactionDeliveryType(): Observable<OpfQuickBuyDeliveryType>;
    getTransactionDeliveryInfo(): Observable<OpfQuickBuyDeliveryInfo>;
    getTransactionLocationContext(): Observable<OpfQuickBuyLocation>;
    getMerchantName(): Observable<string>;
    checkStableCart(): Observable<boolean>;
    getSupportedDeliveryModes(): Observable<DeliveryMode[]>;
    setDeliveryAddress(address: Address): Observable<string>;
    setBillingAddress(address: Address): Observable<boolean>;
    getDeliveryAddress(): Observable<Address | undefined>;
    getCurrentCart(): Observable<Cart>;
    getCurrentCartId(): Observable<string>;
    getCurrentCartTotalPrice(): Observable<number | undefined>;
    setDeliveryMode(mode: string): Observable<DeliveryMode | undefined>;
    getSelectedDeliveryMode(): Observable<DeliveryMode | undefined>;
    deleteUserAddresses(addrIds: string[]): void;
    createCartGuestUser(): Observable<boolean>;
    protected updateCartGuestUser(cartGuestUser: CartGuestUser): Observable<boolean>;
    updateCartGuestUserEmail(email: string): Observable<boolean>;
    handleCartGuestUser(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyTransactionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfQuickBuyTransactionService>;
}

declare const OPF_APPLE_PAY_WEB_SESSION_NORMALIZER: InjectionToken<Converter<any, ApplePaySessionVerificationResponse>>;

export { OPF_APPLE_PAY_WEB_SESSION_NORMALIZER, OpfQuickBuyAdapter, OpfQuickBuyConnector, OpfQuickBuyCoreModule, OpfQuickBuyService, OpfQuickBuyTransactionService };
