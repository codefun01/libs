import { WindowRef, UserIdService, RoutingService, Address } from '@spartacus/core';
import { OpfRegisterGlobalFunctionsInput, OpfGlobalFunctionsFacade, OpfGlobalFunctionsDomain } from '@spartacus/opf/global-functions/root';
import { OpfPaymentFacade, OpfPaymentMerchantCallback, OpfPaymentMethod, OpfPaymentUpdateConfig, OpfPaymentSessionData, OpfPaymentGlobalMethods, OpfPaymentEventsService, OpfPaymentConfig, OpfPaymentVerificationPayload, OpfPaymentVerificationResponse } from '@spartacus/opf/payment/root';
import * as i0 from '@angular/core';
import { NgZone, ViewContainerRef, ComponentRef } from '@angular/core';
import { ActiveCartFacade, CartAccessCodeFacade, MultiCartFacade, Cart, DeliveryMode } from '@spartacus/cart/base/root';
import { OpfMetadataStoreService, OpfKeyValueMap, OpfErrorDialogOptions } from '@spartacus/opf/base/root';
import { LaunchDialogService } from '@spartacus/storefront';
import { Observable } from 'rxjs';
import { OpfCtaFacade } from '@spartacus/opf/cta/root';
import { OpfQuickBuyTransactionService } from '@spartacus/opf/quick-buy/core';

type OpfSharedPaymentSubmitOptions = {
    /** @deprecated Property no longer used. Cart ID is currently derived from the OTP access code header. */
    cartId?: string;
    additionalData: Array<OpfKeyValueMap>;
    submitSuccess: OpfPaymentMerchantCallback;
    submitPending: OpfPaymentMerchantCallback;
    submitFailure: OpfPaymentMerchantCallback;
    submitCancel?: OpfPaymentMerchantCallback;
    paymentMethod: OpfPaymentMethod;
    paymentSessionId?: string;
    savePaymentMethod?: boolean;
};
type OpfSharedPaymentSubmitCompleteOptions = {
    /** @deprecated Property no longer used. Cart ID is currently derived from the OTP access code header. */
    cartId?: string;
    additionalData: Array<OpfKeyValueMap>;
    submitSuccess: OpfPaymentMerchantCallback;
    submitPending: OpfPaymentMerchantCallback;
    submitFailure: OpfPaymentMerchantCallback;
    submitCancel?: OpfPaymentMerchantCallback;
    paymentSessionId?: string;
};
declare class OpfGlobalFunctionsSharedService {
    static readonly PAYMENT_SESSION_ID_REQUIRED_ERROR = "paymentSessionId is required";
    static readonly UPDATE_PAYMENT_TRANSACTION_RETRY_COUNT = 2;
    static readonly UPDATE_PAYMENT_TRANSACTION_RETRY_DELAY = 300;
    protected winRef: WindowRef;
    protected ngZone: NgZone;
    protected opfPaymentFacade: OpfPaymentFacade;
    protected launchDialogService: LaunchDialogService;
    protected opfMetadataStoreService: OpfMetadataStoreService;
    protected activeCartFacade: ActiveCartFacade;
    protected userIdService: UserIdService;
    protected cartAccessCodeFacade: CartAccessCodeFacade;
    resolvePaymentSessionId(paymentSessionId?: string): string | undefined;
    requirePaymentSessionId(paymentSessionId?: string): string;
    submit(options: OpfSharedPaymentSubmitOptions, paymentSessionId?: string, vcr?: ViewContainerRef): Promise<boolean>;
    submitComplete(options: OpfSharedPaymentSubmitCompleteOptions, paymentSessionId?: string, vcr?: ViewContainerRef): Promise<boolean>;
    runSubmitComplete(additionalData: Array<OpfKeyValueMap>, callbacks: {
        onSuccess: OpfPaymentMerchantCallback;
        onPending: OpfPaymentMerchantCallback;
        onFailure: OpfPaymentMerchantCallback;
        onCancel?: OpfPaymentMerchantCallback;
    }, paymentSessionId: string, returnPath?: string | undefined, vcr?: ViewContainerRef): Promise<boolean>;
    updatePaymentTransaction(updatePaymentConfig: OpfPaymentUpdateConfig): Promise<OpfPaymentSessionData>;
    startLoaderSpinner(vcr: ViewContainerRef): void | Observable<ComponentRef<any> | undefined>;
    stopLoaderSpinner(overlayedSpinner: void | Observable<ComponentRef<any> | undefined>): void;
    protected executeUpdatePaymentTransaction(updatePaymentConfig: OpfPaymentUpdateConfig): Promise<OpfPaymentSessionData>;
    protected updatePaymentTransactionWithCart(userId: string, cartId: string | undefined, updatePaymentConfig: OpfPaymentUpdateConfig): Observable<OpfPaymentSessionData>;
    extractOtpKey(response: unknown): string | undefined;
    protected buildAndUpdatePaymentConfig(updatePaymentConfig: OpfPaymentUpdateConfig, otpKey: string): Observable<OpfPaymentSessionData>;
    protected createUpdatePaymentTransactionError(error: unknown): Error;
    protected extractErrorMessage(error: unknown): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGlobalFunctionsSharedService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfGlobalFunctionsSharedService>;
}

declare class OpfGlobalFunctionsSharedRegistrationsService {
    protected sharedService: OpfGlobalFunctionsSharedService;
    registerSubmit(container: OpfPaymentGlobalMethods, paymentSessionId?: string, vcr?: ViewContainerRef): void;
    registerSubmitComplete(container: OpfPaymentGlobalMethods, paymentSessionId?: string, vcr?: ViewContainerRef): void;
    registerUpdatePaymentTransaction(container: OpfPaymentGlobalMethods, updatePaymentTransaction: (updatePaymentConfig: OpfPaymentUpdateConfig) => Promise<OpfPaymentSessionData>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGlobalFunctionsSharedRegistrationsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfGlobalFunctionsSharedRegistrationsService>;
}

declare class OpfGlobalFunctionsCheckoutDomainService {
    protected winRef: WindowRef;
    protected ngZone: NgZone;
    protected launchDialogService: LaunchDialogService;
    protected opfMetadataStoreService: OpfMetadataStoreService;
    protected opfPaymentEventsService: OpfPaymentEventsService;
    protected routingService: RoutingService;
    protected sharedService: OpfGlobalFunctionsSharedService;
    protected loaderSpinnerCpntRef: void | Observable<ComponentRef<any> | undefined>;
    startLoadIndicator(vcr?: ViewContainerRef): void;
    stopLoadIndicator(): void;
    throwPaymentError(vcr?: ViewContainerRef, opfErrorDialogOptions?: OpfErrorDialogOptions): void;
    reinitiatePaymentForm(paymentOptionId?: number): Promise<boolean>;
    handle3DSRedirect(threeDsURL: string, paymentSessionId?: string): Promise<void>;
    updatePaymentTransaction(updatePaymentConfig: OpfPaymentUpdateConfig): Promise<OpfPaymentSessionData>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGlobalFunctionsCheckoutDomainService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfGlobalFunctionsCheckoutDomainService>;
}

declare class OpfGlobalFunctionsCheckoutDomainRegistrationsService {
    protected domainService: OpfGlobalFunctionsCheckoutDomainService;
    protected sharedRegistrationsService: OpfGlobalFunctionsSharedRegistrationsService;
    registerAll(container: OpfPaymentGlobalMethods, { paymentSessionId, vcr }: OpfRegisterGlobalFunctionsInput): void;
    protected registerStartLoadIndicator(container: OpfPaymentGlobalMethods, vcr?: ViewContainerRef): void;
    protected registerStopLoadIndicator(container: OpfPaymentGlobalMethods): void;
    protected registerThrowPaymentError(container: OpfPaymentGlobalMethods, vcr?: ViewContainerRef): void;
    protected registerReinitiatePaymentForm(container: OpfPaymentGlobalMethods): void;
    protected registerHandle3DSRedirect(container: OpfPaymentGlobalMethods, paymentSessionId?: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGlobalFunctionsCheckoutDomainRegistrationsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfGlobalFunctionsCheckoutDomainRegistrationsService>;
}

declare class OpfGlobalFunctionsGlobalDomainService {
    protected winRef: WindowRef;
    protected ngZone: NgZone;
    protected opfPaymentFacade: OpfPaymentFacade;
    protected launchDialogService: LaunchDialogService;
    protected opfCtaFacade: OpfCtaFacade;
    protected opfMetadataStoreService: OpfMetadataStoreService;
    protected activeCartFacade: ActiveCartFacade;
    protected multiCartFacade: MultiCartFacade;
    protected userIdService: UserIdService;
    protected cartAccessCodeFacade: CartAccessCodeFacade;
    protected routingService: RoutingService;
    protected opfQuickBuyTransactionService: OpfQuickBuyTransactionService;
    protected sharedService: OpfGlobalFunctionsSharedService;
    protected globalLoaderSpinnerCpntRef: void | Observable<ComponentRef<any> | undefined>;
    scriptReady(scriptIdentifier: string): void;
    getCart(cartId?: string): Promise<Cart | undefined>;
    startLoadIndicatorGlobal(): void;
    stopLoadIndicatorGlobal(): void;
    throwPaymentErrorGlobal(opfErrorDialogOptions?: OpfErrorDialogOptions): void;
    initiatePayment(configurationIdOrPaymentConfig: string | number | OpfPaymentConfig): Promise<OpfPaymentSessionData>;
    verifyPayment(paymentSessionId: string, paymentVerificationPayload: OpfPaymentVerificationPayload): Promise<OpfPaymentVerificationResponse>;
    updatePaymentTransaction(updatePaymentConfig: OpfPaymentUpdateConfig): Promise<OpfPaymentSessionData>;
    updateCartGuestUserEmail(email: string): Promise<boolean>;
    createCartGuestUser(): Promise<boolean>;
    setBillingAddress(address: Address): Promise<unknown>;
    setDeliveryAddress(address: Address): Promise<string>;
    getBillingAddress(): Promise<Address | undefined>;
    getDeliveryAddress(): Promise<Address | undefined>;
    setDeliveryMode(mode: string): Promise<DeliveryMode | undefined>;
    getDeliveryMode(): Promise<DeliveryMode | undefined>;
    deleteAddress(addressId: string): Promise<void>;
    protected normalizePaymentConfig(configurationIdOrPaymentConfig: string | number | OpfPaymentConfig): OpfPaymentConfig;
    protected initiatePaymentWithCart(userId: string, cartId: string | undefined, paymentConfig: OpfPaymentConfig): Observable<OpfPaymentSessionData>;
    protected buildAndInitiatePaymentConfig(paymentConfig: OpfPaymentConfig, otpKey: string): Observable<OpfPaymentSessionData>;
    protected reloadCartAndWaitForStable(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGlobalFunctionsGlobalDomainService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfGlobalFunctionsGlobalDomainService>;
}

declare class OpfGlobalFunctionsGlobalDomainRegistrationsService {
    protected domainService: OpfGlobalFunctionsGlobalDomainService;
    protected sharedRegistrationsService: OpfGlobalFunctionsSharedRegistrationsService;
    registerAll(container: OpfPaymentGlobalMethods, { paymentSessionId, vcr }: OpfRegisterGlobalFunctionsInput): void;
    protected registerCtaScriptReady(container: OpfPaymentGlobalMethods): void;
    protected registerGetCart(container: OpfPaymentGlobalMethods): void;
    protected registerStartLoadIndicatorGlobal(container: OpfPaymentGlobalMethods): void;
    protected registerStopLoadIndicatorGlobal(container: OpfPaymentGlobalMethods): void;
    protected registerThrowPaymentErrorGlobal(container: OpfPaymentGlobalMethods): void;
    protected registerInitiatePayment(container: OpfPaymentGlobalMethods): void;
    protected registerVerifyPayment(container: OpfPaymentGlobalMethods): void;
    protected registerUpdateCartGuestUserEmail(container: OpfPaymentGlobalMethods): void;
    protected registerCreateCartGuestUser(container: OpfPaymentGlobalMethods): void;
    protected registerSetBillingAddress(container: OpfPaymentGlobalMethods): void;
    protected registerSetDeliveryAddress(container: OpfPaymentGlobalMethods): void;
    protected registerGetBillingAddress(container: OpfPaymentGlobalMethods): void;
    protected registerGetDeliveryAddress(container: OpfPaymentGlobalMethods): void;
    protected registerSetDeliveryMode(container: OpfPaymentGlobalMethods): void;
    protected registerGetDeliveryMode(container: OpfPaymentGlobalMethods): void;
    protected registerDeleteAddress(container: OpfPaymentGlobalMethods): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGlobalFunctionsGlobalDomainRegistrationsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfGlobalFunctionsGlobalDomainRegistrationsService>;
}

declare class OpfGlobalFunctionsRedirectDomainService {
    protected sharedService: OpfGlobalFunctionsSharedService;
    getRedirectParams(paramsMap?: Array<OpfKeyValueMap>): {
        key: string;
        value: string;
    }[];
    submitCompleteRedirect(additionalData: Array<OpfKeyValueMap>, callbacks: {
        onSuccess: OpfPaymentMerchantCallback;
        onPending: OpfPaymentMerchantCallback;
        onFailure: OpfPaymentMerchantCallback;
        onCancel?: OpfPaymentMerchantCallback;
    }, paymentSessionId: string, vcr?: ViewContainerRef): Promise<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGlobalFunctionsRedirectDomainService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfGlobalFunctionsRedirectDomainService>;
}

declare class OpfGlobalFunctionsRedirectDomainRegistrationsService {
    protected domainService: OpfGlobalFunctionsRedirectDomainService;
    registerAll(container: OpfPaymentGlobalMethods, { paymentSessionId, vcr, paramsMap }: OpfRegisterGlobalFunctionsInput): void;
    protected registerGetRedirectParams(container: OpfPaymentGlobalMethods, paramsMap?: Array<OpfKeyValueMap>): void;
    protected registerSubmitCompleteRedirect(container: OpfPaymentGlobalMethods, paymentSessionId: string, vcr?: ViewContainerRef): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGlobalFunctionsRedirectDomainRegistrationsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfGlobalFunctionsRedirectDomainRegistrationsService>;
}

declare class OpfGlobalFunctionsService implements OpfGlobalFunctionsFacade {
    protected winRef: WindowRef;
    protected checkoutDomain: OpfGlobalFunctionsCheckoutDomainRegistrationsService;
    protected redirectDomain: OpfGlobalFunctionsRedirectDomainRegistrationsService;
    protected globalDomain: OpfGlobalFunctionsGlobalDomainRegistrationsService;
    registerGlobalFunctions({ domain, paymentSessionId, vcr, paramsMap, }: OpfRegisterGlobalFunctionsInput): void;
    protected getContainer(domain: OpfGlobalFunctionsDomain): OpfPaymentGlobalMethods;
    unregisterGlobalFunctions(domain: OpfGlobalFunctionsDomain): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGlobalFunctionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfGlobalFunctionsService>;
}

declare class OpfGlobalFunctionsCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGlobalFunctionsCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfGlobalFunctionsCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfGlobalFunctionsCoreModule>;
}

export { OpfGlobalFunctionsCoreModule, OpfGlobalFunctionsService };
