import { Observable, Subscription, BehaviorSubject } from 'rxjs';
import * as i3 from '@spartacus/core';
import { PaymentDetails, CardType, Address, TranslationService, GlobalMessageService, CmsConfig, UserPaymentService } from '@spartacus/core';
import { OpfPaymentMethodDetails } from '@spartacus/opf/payment/root';
import * as i0 from '@angular/core';
import { OnInit, OnDestroy } from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/storefront';
import { ICON_TYPE, Card, OutletContextData } from '@spartacus/storefront';
import { OpfMetadataStoreService } from '@spartacus/opf/base/root';
import { CheckoutPaymentFacade } from '@spartacus/checkout/base/root';

/**
 * OPF Tokenisation payment details model.
 * Re-exports core PaymentDetails for use within OPF tokenisation library.
 * This provides a single import point and allows future customization if needed.
 */
type OpfPaymentDetails = PaymentDetails;
interface OpfSetDefaultPaymentPayload {
    id: string;
    accountHolderName?: string;
    cardType?: CardType;
    cardNumber?: string;
    startMonth?: string;
    startYear?: string;
    expiryMonth?: string;
    expiryYear?: string;
    issueNumber?: string;
    subscriptionId?: string;
    saved?: boolean;
    defaultPayment: true;
    billingAddress?: Address;
    sapPaymentMethod?: OpfPaymentMethodDetails;
}

/**
 * Context data passed to saved cards toggle and payment method components via outlet.
 */
interface OpfSavedCardsToggleContext {
    savedPaymentHeading?: string | null;
    savedCardsHeading?: string | null;
    newPaymentHeadingKey?: string;
    selectedPaymentId?: number;
    savedCardsId?: number;
    hasSavedCards?: boolean;
    disabled?: boolean | null;
    savedCardsSelected?: () => void;
    showSavedCardsList?: boolean;
}
/**
 * Context data passed to new payments heading component via outlet.
 * Allows customization of the heading text displayed above the new payment method form.
 */
interface OpfNewPaymentsHeadingContext {
    newPaymentHeading?: string | null;
    hasSavedCards?: boolean;
}

declare abstract class OpfTokenisationFacade {
    /**
     * Returns all user's payment methods
     */
    abstract getPaymentMethods(): Observable<OpfPaymentDetails[]>;
    /**
     * Returns a loading flag for payment methods
     */
    abstract getPaymentMethodsLoading(): Observable<boolean>;
    /**
     * Loads all user's payment methods
     */
    abstract loadPaymentMethods(): void;
    /**
     * Deletes the payment method
     *
     * @param paymentMethodId a payment method ID
     */
    abstract deletePaymentMethod(paymentMethodId: string): void;
    /**
     * Sets the payment as a default one
     * @param paymentMethodId a payment method ID
     */
    abstract setPaymentMethodAsDefault(paymentMethodId: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfTokenisationFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfTokenisationFacade>;
}

declare const OPF_TOKENISATION_FEATURE = "opfTokenisation";

declare class OpfTokenisationAccountPaymentMethodsComponent implements OnInit {
    paymentMethods$: Observable<PaymentDetails[]>;
    editCard: string | undefined;
    loading$: Observable<boolean>;
    showDeleteDialog: boolean;
    paymentMethodToDelete: PaymentDetails | undefined;
    showHeader: boolean;
    protected autoDefaultRequested: boolean;
    iconTypes: typeof ICON_TYPE;
    protected tokenisationFacade: OpfTokenisationFacade;
    protected translation: TranslationService;
    protected globalMessageService: GlobalMessageService | null;
    ngOnInit(): void;
    getCardContent(paymentMethod: PaymentDetails): Observable<Card>;
    isCardExpired(paymentMethod: PaymentDetails): boolean;
    deletePaymentMethod(paymentMethod: PaymentDetails): void;
    confirmDeletePaymentMethod(): void;
    closeDeleteDialog(): void;
    setEdit(paymentMethod: PaymentDetails): void;
    cancelCard(): void;
    setDefaultPaymentMethod(paymentMethod: PaymentDetails): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfTokenisationAccountPaymentMethodsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfTokenisationAccountPaymentMethodsComponent, "cx-opf-tokenisation-account-payment-methods", never, { "showHeader": { "alias": "showHeader"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OpfTokenisationAccountPaymentMethodsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfTokenisationAccountPaymentMethodsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfTokenisationAccountPaymentMethodsModule, never, [typeof i1.CommonModule, typeof i2.CardModule, typeof i2.SpinnerModule, typeof i3.I18nModule, typeof i3.FeaturesConfigModule, typeof i2.FormRequiredLegendComponent, typeof OpfTokenisationAccountPaymentMethodsComponent], [typeof OpfTokenisationAccountPaymentMethodsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfTokenisationAccountPaymentMethodsModule>;
}

declare function defaultOpfTokenisationCmsComponentsConfig(): CmsConfig;
declare class OpfTokenisationRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfTokenisationRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfTokenisationRootModule, never, [typeof OpfTokenisationAccountPaymentMethodsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfTokenisationRootModule>;
}

declare class OpfTokenisationNewPaymentsHeadingComponent {
    protected outletContextData: OutletContextData<OpfNewPaymentsHeadingContext> | null;
    protected userPaymentService: UserPaymentService;
    readonly context$: Observable<OpfNewPaymentsHeadingContext>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfTokenisationNewPaymentsHeadingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfTokenisationNewPaymentsHeadingComponent, "cx-opf-tokenisation-new-payments-heading", never, {}, {}, never, never, true, never>;
}

declare const SAVED_CARDS_ID = -1;
/**
 * Manages saved cards selection state and payment method transitions.
 * Reactively triggers deletion of saved payment details when the user
 * switches from saved cards to an active payment provider.
 */
declare class OpfTokenisationSavedCardsService implements OnDestroy {
    protected checkoutPaymentFacade: CheckoutPaymentFacade;
    protected opfMetadataStoreService: OpfMetadataStoreService;
    protected subscription: Subscription;
    /**
     * Tracks whether a card was selected from the saved cards list.
     * Used to distinguish between "just selecting saved cards" vs "selecting a card for payment"
     */
    protected cardSelected$: BehaviorSubject<boolean>;
    /**
     * Persists the ID of the last saved card the user selected for payment.
     * Survives component destruction so selection is retained when navigating back.
     */
    readonly selectedPaymentMethodId$: BehaviorSubject<string | undefined>;
    constructor();
    /**
     * Marks saved cards as the selected payment option
     * by writing SAVED_CARDS_ID to the metadata store.
     */
    selectSavedCards(): void;
    /**
     * Marks that a specific card has been selected from the saved cards list
     * and persists its ID so it can be restored after navigation.
     */
    markCardAsSelected(id?: string): void;
    /**
     * Clears the persisted selected card ID.
     * Call this when the user fully leaves saved-cards mode.
     */
    clearSelectedPaymentMethodId(): void;
    /**
     * Returns whether saved cards are currently selected
     * based on the metadata store value.
     */
    areSavedCardsSelected(): boolean;
    /**
     * Determines if user is transitioning away from saved cards to a specific payment method.
     * Checks that:
     * - Previous payment was SAVED_CARDS_ID
     * - Current payment is not SAVED_CARDS_ID
     * - Current payment is defined
     * - A card was actually selected from saved cards list
     */
    private isTransitioningFromSavedCardsWithCardSelected;
    /**
     * Watches the metadata store for transitions from SAVED_CARDS_ID
     * to any other payment option. When detected and a card was previously selected,
     * deletes the saved payment details from the backend.
     */
    protected listenForPaymentTransitions(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfTokenisationSavedCardsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfTokenisationSavedCardsService>;
}

declare class OpfTokenisationSavedCardsToggleComponent {
    protected outletContextData: OutletContextData<OpfSavedCardsToggleContext> | null;
    protected savedCardsService: OpfTokenisationSavedCardsService | null;
    protected opfMetadataStoreService: OpfMetadataStoreService;
    protected userPaymentService: UserPaymentService;
    iconTypes: typeof ICON_TYPE;
    readonly SAVED_CARDS_ID = -1;
    readonly context$: Observable<{
        hasSavedCards: boolean;
        savedPaymentHeading?: string | null;
        savedCardsHeading?: string | null;
        newPaymentHeadingKey?: string;
        selectedPaymentId?: number;
        savedCardsId?: number;
        disabled?: boolean | null;
        savedCardsSelected?: () => void;
        showSavedCardsList?: boolean;
    }>;
    /**
     * Whether the saved cards radio should be checked.
     * Reads selectedPaymentOptionId from the metadata store reactively.
     */
    readonly isSavedCardsChecked$: Observable<boolean>;
    onSavedCardsSelected(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfTokenisationSavedCardsToggleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfTokenisationSavedCardsToggleComponent, "cx-opf-tokenisation-saved-cards-toggle", never, {}, {}, never, never, true, never>;
}

export { OPF_TOKENISATION_FEATURE, OpfTokenisationFacade, OpfTokenisationNewPaymentsHeadingComponent, OpfTokenisationRootModule, OpfTokenisationSavedCardsService, OpfTokenisationSavedCardsToggleComponent, SAVED_CARDS_ID, defaultOpfTokenisationCmsComponentsConfig };
export type { OpfNewPaymentsHeadingContext, OpfPaymentDetails, OpfSavedCardsToggleContext, OpfSetDefaultPaymentPayload };
