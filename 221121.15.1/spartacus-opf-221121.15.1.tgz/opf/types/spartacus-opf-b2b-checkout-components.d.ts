import * as i0 from '@angular/core';
import { OnInit, AfterViewInit, OnDestroy, DestroyRef, ElementRef } from '@angular/core';
import * as i1 from '@angular/common';
import * as i4 from '@spartacus/core';
import { UserIdService, GlobalMessageService, CmsService, CostCenter, Page } from '@spartacus/core';
import * as i3 from '@spartacus/storefront';
import { Card } from '@spartacus/storefront';
import * as i3$1 from '@spartacus/opf/checkout/components';
import { OpfCheckoutPaymentAndReviewComponent } from '@spartacus/opf/checkout/components';
import * as i5 from '@angular/forms';
import { FormBuilder, FormGroup } from '@angular/forms';
import * as i2 from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import * as _spartacus_cart_base_root from '@spartacus/cart/base/root';
import { ActiveCartFacade, PaymentType } from '@spartacus/cart/base/root';
import { CheckoutPaymentTypeFacade, CheckoutCostCenterFacade } from '@spartacus/checkout/b2b/root';
import * as i6 from '@spartacus/checkout/base/components';
import { CheckoutStepService, CheckoutPlaceOrderComponent, CheckoutReviewSubmitComponent } from '@spartacus/checkout/base/components';
import * as _spartacus_opf_base_root from '@spartacus/opf/base/root';
import { OpfMetadataStoreService, OpfActiveConfiguration, OpfBaseFacade } from '@spartacus/opf/base/root';
import { OpfPaymentFacade } from '@spartacus/opf/payment/root';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
import { CheckoutStepType } from '@spartacus/checkout/base/root';
import * as i6$1 from '@spartacus/user/profile/components';
import * as i3$2 from '@spartacus/checkout/b2b/components';
import { CheckoutCostCenterComponent, B2BCheckoutDeliveryAddressComponent } from '@spartacus/checkout/b2b/components';

declare class OpfB2bCheckoutPaymentTypeComponent implements OnInit, AfterViewInit, OnDestroy {
    protected opfPaymentFacade: OpfPaymentFacade;
    protected userIdService: UserIdService;
    protected activeCartFacade: ActiveCartFacade;
    protected checkoutPaymentTypeFacade: CheckoutPaymentTypeFacade;
    protected checkoutStepService: CheckoutStepService;
    protected activatedRoute: ActivatedRoute;
    protected globalMessageService: GlobalMessageService;
    protected opfMetadataStoreService: OpfMetadataStoreService;
    protected fb: FormBuilder;
    protected destroyRef: DestroyRef;
    private featureToggles;
    protected poNumberInputElement: ElementRef<HTMLInputElement>;
    protected isUpdating$: BehaviorSubject<boolean>;
    protected form: FormGroup;
    cartPoNumber$: Observable<string | undefined>;
    protected subscription: Subscription;
    protected poNumberValue: string | undefined;
    protected selectedPaymentOption: string | undefined;
    constructor();
    protected updatePoNumberField(): void;
    protected adaptCheckoutSteps(paymentType: string | undefined): void;
    getCartPoNumber(): Observable<string | undefined>;
    next(): void;
    back(): void;
    getSelectedPaymentOption(): Observable<string | undefined>;
    setPaymentOption(paymentOption: string, poNumber?: string): Observable<unknown>;
    handlePaymentChange(payment: OpfActiveConfiguration): void;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfB2bCheckoutPaymentTypeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfB2bCheckoutPaymentTypeComponent, "cx-opf-b2b-checkout-payment-type", never, {}, {}, never, never, true, never>;
}

declare class OpfB2bCheckoutPaymentTypeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfB2bCheckoutPaymentTypeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfB2bCheckoutPaymentTypeModule, never, [typeof i1.CommonModule, typeof i4.I18nModule, typeof i3.SpinnerModule, typeof i4.FeaturesConfigModule, typeof i3$1.OpfCheckoutPaymentsModule, typeof i5.ReactiveFormsModule, typeof OpfB2bCheckoutPaymentTypeComponent], [typeof OpfB2bCheckoutPaymentTypeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfB2bCheckoutPaymentTypeModule>;
}

declare class OpfB2bCheckoutPlaceOrderComponent extends CheckoutPlaceOrderComponent implements OnInit {
    isDisabled?: boolean;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfB2bCheckoutPlaceOrderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfB2bCheckoutPlaceOrderComponent, "cx-opf-b2b-checkout-place-order", never, { "isDisabled": { "alias": "isDisabled"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OpfB2bCheckoutPlaceOrderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfB2bCheckoutPlaceOrderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfB2bCheckoutPlaceOrderModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i3.SpinnerModule, typeof i4.I18nModule, typeof i4.UrlModule, typeof i4.FeaturesConfigModule, typeof i3.AtMessageModule, typeof i5.ReactiveFormsModule, typeof i3.FormErrorsModule, typeof i3.FormRequiredAsterisksComponent, typeof i3.FormRequiredLegendComponent, typeof i6.CheckoutPlaceOrderModule, typeof OpfB2bCheckoutPlaceOrderComponent], [typeof OpfB2bCheckoutPlaceOrderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfB2bCheckoutPlaceOrderModule>;
}

declare class OpfB2bCheckoutReviewComponent extends CheckoutReviewSubmitComponent implements OnInit {
    protected fb: FormBuilder;
    protected opfMetadataStoreService: OpfMetadataStoreService;
    protected cmsService: CmsService;
    protected checkoutPaymentTypeFacade: CheckoutPaymentTypeFacade;
    protected opfBaseFacade: OpfBaseFacade;
    protected checkoutCostCenterFacade: CheckoutCostCenterFacade;
    protected defaultTermsAndConditionsFieldValue: boolean;
    checkoutStepTypePaymentType: CheckoutStepType;
    explicitTermsAndConditions$: Observable<boolean | undefined>;
    checkoutSubmitForm: i5.FormGroup<{
        termsAndConditions: i5.FormControl<boolean | null>;
    }>;
    get termsAndConditionInvalid(): boolean;
    get termsAndConditionsFieldValue(): boolean;
    get paymentType$(): Observable<PaymentType | undefined>;
    poNumber$: Observable<string | undefined>;
    costCenter$: Observable<CostCenter | undefined>;
    getCostCenterCard(costCenter?: CostCenter | null): Observable<Card>;
    getPoNumberCard(poNumber?: string | null): Observable<Card>;
    protected isCmsComponentInPage(cmsComponentUid: string, page: Page): boolean;
    protected updateTermsAndConditionsState(): void;
    toggleTermsAndConditions(): void;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfB2bCheckoutReviewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfB2bCheckoutReviewComponent, "cx-opf-b2b-checkout-review", never, {}, {}, never, never, true, never>;
}

declare class OpfB2bCheckoutReviewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfB2bCheckoutReviewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfB2bCheckoutReviewModule, never, [typeof i1.CommonModule, typeof i5.ReactiveFormsModule, typeof i2.RouterModule, typeof i4.I18nModule, typeof i4.UrlModule, typeof i3$1.OpfCheckoutReviewCardModule, typeof i3$1.OpfCheckoutTermsAndConditionsAlertModule, typeof i3$1.OpfCheckoutBillingAddressFormModule, typeof i3$1.OpfCheckoutPaymentsModule, typeof i3$1.OpfCheckoutReviewCartDetailsModule, typeof OpfB2bCheckoutPlaceOrderModule, typeof i6.CheckoutPlaceOrderModule, typeof OpfB2bCheckoutReviewComponent], [typeof OpfB2bCheckoutReviewComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfB2bCheckoutReviewModule>;
}

declare class OpfB2bCheckoutPaymentAndReviewComponent extends OpfCheckoutPaymentAndReviewComponent implements OnInit {
    checkoutStepTypePaymentType: CheckoutStepType;
    paymentType$: Observable<_spartacus_cart_base_root.PaymentType | undefined>;
    poNumber$: Observable<string | undefined>;
    getPoNumberCard(poNumber?: string | null): Observable<Card>;
    getSelectedPayment$: Observable<i4.QueryState<_spartacus_opf_base_root.OpfActiveConfigurationsResponse | undefined>>;
    getSelectedPaymentId$: Observable<number | undefined>;
    getPaymentMethodNameCard(methodName?: string): Observable<Card>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfB2bCheckoutPaymentAndReviewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfB2bCheckoutPaymentAndReviewComponent, "cx-opf-b2b-checkout-payment-and-review", never, {}, {}, never, never, true, never>;
}

declare class OpfB2bCheckoutPaymentAndReviewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfB2bCheckoutPaymentAndReviewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfB2bCheckoutPaymentAndReviewModule, never, [typeof i1.CommonModule, typeof i4.I18nModule, typeof i3$1.OpfCheckoutPaymentsModule, typeof i4.UrlModule, typeof i5.ReactiveFormsModule, typeof i2.RouterModule, typeof i3$1.OpfCheckoutBillingAddressFormModule, typeof i6$1.AddressFormModule, typeof i3.OutletModule, typeof i3.PromotionsModule, typeof i3.IconModule, typeof i3.CardModule, typeof i3$1.OpfCheckoutTermsAndConditionsAlertModule, typeof i3$1.OpfCheckoutPaymentWrapperModule, typeof i3$1.OpfCheckoutReviewCardModule, typeof i3$1.OpfCheckoutReviewCartDetailsModule, typeof OpfB2bCheckoutPaymentAndReviewComponent], [typeof OpfB2bCheckoutPaymentAndReviewComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfB2bCheckoutPaymentAndReviewModule>;
}

declare class OpfB2bCheckoutCostCenterComponent extends CheckoutCostCenterComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfB2bCheckoutCostCenterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfB2bCheckoutCostCenterComponent, "cx-opf-b2b-checkout-cost-center", never, {}, {}, never, never, true, never>;
}

declare class OpfB2bCheckoutCostCenterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfB2bCheckoutCostCenterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfB2bCheckoutCostCenterModule, never, [typeof i1.CommonModule, typeof i4.I18nModule, typeof i3$2.CheckoutCostCenterModule, typeof OpfB2bCheckoutCostCenterComponent], [typeof OpfB2bCheckoutCostCenterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfB2bCheckoutCostCenterModule>;
}

declare class OpfB2bCheckoutDeliveryAddressComponent extends B2BCheckoutDeliveryAddressComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfB2bCheckoutDeliveryAddressComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfB2bCheckoutDeliveryAddressComponent, "cx-opf-b2b-checkout-delivery-address", never, {}, {}, never, never, true, never>;
}

declare class OpfB2bCheckoutDeliveryAddressModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfB2bCheckoutDeliveryAddressModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfB2bCheckoutDeliveryAddressModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i6$1.AddressFormModule, typeof i3.CardModule, typeof i3.SpinnerModule, typeof i4.I18nModule, typeof i4.FeaturesConfigModule, typeof OpfB2bCheckoutCostCenterModule, typeof OpfB2bCheckoutDeliveryAddressComponent], [typeof OpfB2bCheckoutDeliveryAddressComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfB2bCheckoutDeliveryAddressModule>;
}

declare class OpfB2bCheckoutComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfB2bCheckoutComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfB2bCheckoutComponentsModule, never, [typeof OpfB2bCheckoutPaymentTypeModule, typeof OpfB2bCheckoutReviewModule, typeof OpfB2bCheckoutPaymentAndReviewModule, typeof OpfB2bCheckoutDeliveryAddressModule, typeof OpfB2bCheckoutCostCenterModule, typeof OpfB2bCheckoutPlaceOrderModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfB2bCheckoutComponentsModule>;
}

export { OpfB2bCheckoutComponentsModule, OpfB2bCheckoutCostCenterComponent, OpfB2bCheckoutCostCenterModule, OpfB2bCheckoutDeliveryAddressComponent, OpfB2bCheckoutDeliveryAddressModule, OpfB2bCheckoutPaymentAndReviewComponent, OpfB2bCheckoutPaymentAndReviewModule, OpfB2bCheckoutPaymentTypeComponent, OpfB2bCheckoutPaymentTypeModule, OpfB2bCheckoutPlaceOrderComponent, OpfB2bCheckoutPlaceOrderModule, OpfB2bCheckoutReviewComponent, OpfB2bCheckoutReviewModule };
