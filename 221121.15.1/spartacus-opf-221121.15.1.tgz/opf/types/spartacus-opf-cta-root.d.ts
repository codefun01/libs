import { Observable } from 'rxjs';
import { OpfDynamicScript } from '@spartacus/opf/base/root';
import * as i0 from '@angular/core';
import { CmsConfig } from '@spartacus/core';

type OpfCtaAdditionalDataKey = 'divisionId' | 'experienceId' | 'currency' | 'fulfillmentLocationId' | 'locale' | 'scriptIdentifier';
interface OpfCtaScriptsRequest {
    paymentAccountIds?: Array<number>;
    cartId?: string;
    ctaProductItems?: Array<OpfCtaProductItem>;
    scriptLocations?: Array<OpfCtaScriptsLocation>;
    additionalData?: Array<{
        key: OpfCtaAdditionalDataKey;
        value: string;
    }>;
}
interface OpfCtaProductItem {
    productId: string;
    quantity: number;
    fulfillmentLocationId?: string;
}
declare enum OpfCtaScriptsLocation {
    CART_MESSAGING = "CART_MESSAGING",
    PDP_MESSAGING = "PDP_MESSAGING",
    CART_QUICK_BUY = "CART_QUICK_BUY",
    PDP_QUICK_BUY = "PDP_QUICK_BUY",
    ORDER_CONFIRMATION_PAYMENT_GUIDE = "ORDER_CONFIRMATION_PAYMENT_GUIDE",
    ORDER_HISTORY_PAYMENT_GUIDE = "ORDER_HISTORY_PAYMENT_GUIDE"
}
declare enum OpfCtaCmsPageLocation {
    ORDER_CONFIRMATION_PAGE = "orderConfirmationPage",
    ORDER_PAGE = "order",
    PDP_PAGE = "productDetails",
    CART_PAGE = "cartPage"
}
interface OpfCtaScriptsResponse {
    value: Array<OpfCtaScript>;
}
interface OpfCtaScript {
    paymentAccountId: number;
    dynamicScript: OpfDynamicScript;
}
declare enum OpfCtaEvent {
    OPF_CART_CHANGED = "opfCartChanged",
    OPF_PRODUCT_AMOUNT_CHANGED = "opfProductAmountChanged"
}
declare const OpfCtaDynamicLocations: Array<OpfCtaScriptsLocation>;

declare abstract class OpfCtaFacade {
    /**
     * Get call-to-action scripts
     */
    abstract getCtaScripts(opfCtaScriptsRequest: OpfCtaScriptsRequest): Observable<OpfCtaScriptsResponse>;
    abstract listenScriptReadyEvent(): Observable<string>;
    abstract emitScriptReadyEvent(scriptIdentifier: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCtaFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfCtaFacade>;
}

declare const OPF_CTA_FEATURE = "opfCta";

declare function defaultOpfCtaCmsComponentsConfig(): CmsConfig;
declare class OpfCtaRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCtaRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCtaRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCtaRootModule>;
}

export { OPF_CTA_FEATURE, OpfCtaCmsPageLocation, OpfCtaDynamicLocations, OpfCtaEvent, OpfCtaFacade, OpfCtaRootModule, OpfCtaScriptsLocation, defaultOpfCtaCmsComponentsConfig };
export type { OpfCtaAdditionalDataKey, OpfCtaProductItem, OpfCtaScript, OpfCtaScriptsRequest, OpfCtaScriptsResponse };
