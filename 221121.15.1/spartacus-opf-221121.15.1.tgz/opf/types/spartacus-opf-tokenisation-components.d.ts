import * as i0 from '@angular/core';

declare class OpfTokenisationComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfTokenisationComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfTokenisationComponentsModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfTokenisationComponentsModule>;
}

export { OpfTokenisationComponentsModule };
