import * as i0 from '@angular/core';
import { OnInit, OnDestroy, ViewContainerRef, ChangeDetectorRef, DestroyRef, ElementRef, PipeTransform, TemplateRef, EventEmitter } from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/core';
import { UserIdService, RoutingService, GlobalMessageService, WindowRef, HttpErrorModel, LanguageService, CurrencyService, UserPaymentService, UserAddressService, Address, Country, TranslationService, QueryState, PaginationModel, CmsService, Page, SemanticPathService } from '@spartacus/core';
import * as i3 from '@spartacus/storefront';
import { ICON_TYPE, Card } from '@spartacus/storefront';
import * as rxjs from 'rxjs';
import { BehaviorSubject, Observable, Subscription, Subject } from 'rxjs';
import * as _spartacus_opf_payment_root from '@spartacus/opf/payment/root';
import { OpfPaymentFacade, OpfPaymentRenderMethodEvent, OpfPaymentSessionData, OpfPaymentConfig, OpfPaymentBrowserInfo, OpfPaymentEventsService, OpfPaymentRenderPattern } from '@spartacus/opf/payment/root';
import { DomSanitizer, SafeHtml, SafeResourceUrl } from '@angular/platform-browser';
import { ActiveCartFacade, CartAccessCodeFacade, Cart, PromotionLocation, CartOutlets, CartGuestUserFacade, MultiCartFacade } from '@spartacus/cart/base/root';
import * as _spartacus_opf_base_root from '@spartacus/opf/base/root';
import { OpfResourceLoaderService, OpfMetadataStoreService, OpfConfig, OpfBaseFacade, OpfActiveConfigurationsResponse, OpfActiveConfiguration, OpfMetadataModel, OpfActiveConfigurationsPagination } from '@spartacus/opf/base/root';
import { OpfGlobalFunctionsFacade } from '@spartacus/opf/global-functions/root';
import { OrderFacade } from '@spartacus/order/root';
import { CheckoutDeliveryAddressFacade, CheckoutBillingAddressFacade, CheckoutPaymentFacade, CheckoutDeliveryModesFacade } from '@spartacus/checkout/base/root';
import { OpfCheckoutOutlets } from '@spartacus/opf/checkout/root';
import * as i3$1 from '@angular/forms';
import { UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import * as i2$1 from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import * as i4 from '@ng-select/ng-select';
import * as i6 from '@spartacus/user/profile/components';
import { CheckoutStepService, CheckoutReviewSubmitComponent } from '@spartacus/checkout/base/components';
import { CheckoutPaymentTypeFacade } from '@spartacus/checkout/b2b/root';

declare class OpfCheckoutPaymentWrapperService {
    protected opfPaymentFacade: OpfPaymentFacade;
    protected opfResourceLoaderService: OpfResourceLoaderService;
    protected userIdService: UserIdService;
    protected activeCartService: ActiveCartFacade;
    protected routingService: RoutingService;
    protected globalMessageService: GlobalMessageService;
    protected orderFacade: OrderFacade;
    protected opfMetadataStoreService: OpfMetadataStoreService;
    protected cartAccessCodeFacade: CartAccessCodeFacade;
    protected winRef: WindowRef;
    private readonly featureConfigService;
    protected lastPaymentOptionId?: number;
    protected readonly isUpdatePaymentTransactionFeatureEnabled = "opfCheckoutUseUpdatePaymentTransaction";
    protected renderPaymentMethodEvent$: BehaviorSubject<OpfPaymentRenderMethodEvent>;
    protected executeScriptFromHtml(html: string): void;
    getRenderPaymentMethodEvent(): Observable<OpfPaymentRenderMethodEvent>;
    removePaymentProviderResources(): void;
    initiatePayment(paymentOptionId: number): Observable<OpfPaymentSessionData | Error>;
    protected storePaymentSessionId(paymentOptionConfig: OpfPaymentSessionData, useUpdatePaymentTransaction?: boolean, paymentConfigurationId?: string): void;
    protected getOrCreatePaymentSessionId(paymentConfig: {
        otpKey?: string;
        config?: OpfPaymentConfig;
    }): Observable<string>;
    protected getStoredPaymentSessionId(paymentConfigurationId?: string): string | undefined;
    protected updatePaymentSessionMetadata(paymentSessionId?: string, paymentConfigurationId?: string): void;
    reloadPaymentMode(): void;
    /**
     * Render payment option covering the three patterns: IFRAME, FULL_PAGE, HOSTED_FIELDS.
     * Context to explain this method logic:
     * All three patterns can contains `dynamicScript` value.
     * IFRAME and FULL_PAGE patterns can also have `destination` value.
     * if `dynamicScript` and `destination` are present in same config, dynamicScript takes precendence.
     * @param config
     * @returns : none, OpfPaymentRenderMethodEvent gets emitted
     */
    renderPaymentGateway(config: OpfPaymentSessionData): void;
    protected handlePaymentInitiationError(err: HttpErrorModel): Observable<Error>;
    protected handlePaymentAlreadyDoneError(): Observable<Error>;
    protected onPlaceOrderSuccess(): void;
    protected onPlaceOrderError(): void;
    protected handleGeneralPaymentError(): Observable<Error>;
    protected showErrorMessage(errorMessage: string): void;
    protected getPaymentInitiationConfig(otpKey: string, paymentOptionId: number, browserInfo?: OpfPaymentBrowserInfo): {
        otpKey: string;
        config: {
            browserInfo: OpfPaymentBrowserInfo | undefined;
            configurationId: string;
            resultURL: string;
            cancelURL: string;
        };
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutPaymentWrapperService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfCheckoutPaymentWrapperService>;
}

declare class OpfCheckoutPaymentWrapperComponent implements OnInit, OnDestroy {
    protected service: OpfCheckoutPaymentWrapperService;
    protected sanitizer: DomSanitizer;
    protected globalFunctionsService: OpfGlobalFunctionsFacade;
    protected opfPaymentEventsService: OpfPaymentEventsService;
    protected languageService: LanguageService;
    protected currencyService: CurrencyService;
    protected activeCartService: ActiveCartFacade;
    protected vcr: ViewContainerRef;
    protected cdr: ChangeDetectorRef;
    protected opfConfig: OpfConfig;
    protected destroyRef: DestroyRef;
    private featureToggles;
    protected isPaymentDataReady: boolean;
    protected readonly PAYMENT_IFRAME_NAME = "cx-payment-iframe";
    selectedPaymentId: number;
    formElement: ElementRef<HTMLFormElement>;
    renderPaymentMethodEvent$: rxjs.Observable<_spartacus_opf_payment_root.OpfPaymentRenderMethodEvent>;
    RENDER_PATTERN: typeof OpfPaymentRenderPattern;
    sub: Subscription;
    bypassSecurityTrustHtml(html: string): SafeHtml;
    bypassSecurityTrustResourceUrl(url: string): SafeResourceUrl;
    getIframeSandbox(paymentOptionId?: number): string | undefined;
    ngOnInit(): void;
    ngOnDestroy(): void;
    retryInitiatePayment(): void;
    protected submitFormToIframe(): void;
    protected listenForReinitiatePaymentEvent(): void;
    protected listenForSiteContextChanges(): void;
    protected handleReinitiatePayment(paymentOptionId?: number): void;
    protected initiatePaymentMode(paymentOptionId?: number): void;
    protected isHostedFields(paymentSessionData: OpfPaymentSessionData | Error): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutPaymentWrapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfCheckoutPaymentWrapperComponent, "cx-opf-checkout-payment-wrapper", never, { "selectedPaymentId": { "alias": "selectedPaymentId"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OpfCheckoutPaymentWrapperModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutPaymentWrapperModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCheckoutPaymentWrapperModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.SpinnerModule, typeof OpfCheckoutPaymentWrapperComponent], [typeof OpfCheckoutPaymentWrapperComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCheckoutPaymentWrapperModule>;
}

declare class OpfCheckoutBillingAddressFormService {
    protected checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade;
    protected checkoutBillingAddressFacade: CheckoutBillingAddressFacade;
    protected userPaymentService: UserPaymentService;
    protected checkoutPaymentService: CheckoutPaymentFacade;
    protected activeCartService: ActiveCartFacade;
    protected globalMessageService: GlobalMessageService;
    protected opfCheckoutPaymentWrapperService: OpfCheckoutPaymentWrapperService;
    protected userAddressService: UserAddressService;
    protected _noDefaultAddressFoundForPickupMode$: Subject<void>;
    protected readonly _$billingAddressSub: BehaviorSubject<Address | undefined>;
    protected readonly _$isLoadingAddress: BehaviorSubject<boolean>;
    protected readonly _$isSameAsDelivery: BehaviorSubject<boolean>;
    protected billingAddressId: string | undefined;
    billingAddress$: Observable<Address | undefined>;
    isLoadingAddress$: Observable<boolean>;
    isSameAsDelivery$: Observable<boolean>;
    protected readonly _$paymentOptionsDisabled: BehaviorSubject<boolean>;
    paymentOptionsDisabled$: Observable<boolean>;
    protected opfPaymentEventsService: OpfPaymentEventsService;
    get pickupNoDefaultAddress$(): Observable<void>;
    setPaymentOptionsDisabled(value: boolean): void;
    protected handleNoDefaultAddress(): void;
    getCountries(): Observable<Country[]>;
    setDefaultBillingAddress(): void;
    getAddresses(): void;
    setDeliveryAddressAsPaymentAddress(): void;
    setBillingAddress(address: Address): Observable<Address | undefined>;
    get isSameAsDeliveryValue(): boolean;
    setIsSameAsDeliveryValue(value: boolean): void;
    protected getDeliveryAddress(): Observable<Address | undefined>;
    protected getPaymentAddress(): Observable<Address | undefined>;
    protected getAddressWithId(address: Address): Address;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutBillingAddressFormService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfCheckoutBillingAddressFormService>;
}

declare class OpfCheckoutBillingAddressFormComponent implements OnInit, OnDestroy {
    protected service: OpfCheckoutBillingAddressFormService;
    protected userAddressService: UserAddressService;
    protected activeCartFacade: ActiveCartFacade;
    protected checkoutStepService: CheckoutStepService;
    protected activatedRoute: ActivatedRoute;
    protected destroyRef: DestroyRef;
    private featureToggles;
    protected cart: Cart | null;
    iconTypes: typeof ICON_TYPE;
    subscription: Subscription;
    billingAddress$: Observable<Address | undefined>;
    isLoadingAddress$: Observable<boolean>;
    isSameAsDelivery$: Observable<boolean>;
    isEditBillingAddress: boolean;
    isAddingBillingAddressInProgress: boolean;
    countries$: Observable<Country[]>;
    ngOnInit(): void;
    cancelAndHideForm(): void;
    back(): void;
    onBackToAddress(): void;
    editCustomBillingAddress(): void;
    toggleSameAsDeliveryAddress(event: Event): void;
    getAddressData(billingAddress: Address | undefined | null): Address;
    onSubmitAddress(address: Address): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutBillingAddressFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfCheckoutBillingAddressFormComponent, "cx-opf-checkout-billing-address-form", never, {}, {}, never, never, true, never>;
}

declare class GetAddressCardContent implements PipeTransform {
    transform(address: Address): Card;
    protected getTownLine(address: Address): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<GetAddressCardContent, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<GetAddressCardContent, "cxGetAddressCardContent", true>;
}

declare class OpfCheckoutBillingAddressFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutBillingAddressFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCheckoutBillingAddressFormModule, never, [typeof i3.NgSelectA11yModule, typeof i1.CommonModule, typeof i3$1.ReactiveFormsModule, typeof i4.NgSelectModule, typeof i3.CardModule, typeof i2.I18nModule, typeof i3.IconModule, typeof i3.FormErrorsModule, typeof i3.SpinnerModule, typeof i6.AddressFormModule, typeof OpfCheckoutBillingAddressFormComponent, typeof GetAddressCardContent], [typeof OpfCheckoutBillingAddressFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCheckoutBillingAddressFormModule>;
}

declare class OpfCheckoutTermsAndConditionsAlertComponent implements OnInit {
    protected opfMetadataStoreService: OpfMetadataStoreService;
    protected opfCheckoutBillingAddressFormService: OpfCheckoutBillingAddressFormService;
    iconTypes: typeof ICON_TYPE;
    protected paymentDisabled$: rxjs.Observable<boolean>;
    /**
     * Defines if alert could be dismissed or not
     */
    isDismissible: boolean;
    isVisible: boolean;
    /**
     * Explicit Terms and Conditions (isExplicit true) requires user to accept T&C to see and select payments options.
     * Implicit Terms and Conditions (isExplicit false) only displays the T&C message without checkbox, payment options are always enabled.
     */
    isExplicit: boolean | undefined | null;
    close(): void;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutTermsAndConditionsAlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfCheckoutTermsAndConditionsAlertComponent, "cx-opf-checkout-terms-and-conditions-alert", never, { "isDismissible": { "alias": "isDismissible"; "required": false; }; "isVisible": { "alias": "isVisible"; "required": false; }; "isExplicit": { "alias": "isExplicit"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OpfCheckoutTermsAndConditionsAlertModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutTermsAndConditionsAlertModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCheckoutTermsAndConditionsAlertModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof OpfCheckoutTermsAndConditionsAlertComponent], [typeof OpfCheckoutTermsAndConditionsAlertComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCheckoutTermsAndConditionsAlertModule>;
}

declare class OpfCheckoutPaymentsComponent implements OnInit, OnDestroy {
    protected opfBaseService: OpfBaseFacade;
    protected opfConfig: OpfConfig;
    protected translation: TranslationService;
    protected opfMetadataStoreService: OpfMetadataStoreService;
    protected globalMessageService: GlobalMessageService;
    protected opfCheckoutBillingAddressFormService: OpfCheckoutBillingAddressFormService;
    protected opfPaymentEventsService: OpfPaymentEventsService;
    protected userPaymentService: UserPaymentService;
    protected destroyRef: DestroyRef;
    private featureToggles;
    protected subscription: Subscription;
    protected paginationIndex: number;
    isHeadingDisplayed?: boolean | undefined;
    headingTranslationKey?: string;
    isPaymentRenderBelow?: boolean | undefined;
    isPaymentInfoMessageEnabled?: boolean | undefined;
    elementsPerPage?: number;
    disabled: boolean;
    explicitTermsAndConditions: boolean | null | undefined;
    onlyPaymentWrapperMode?: boolean | undefined;
    showBeforePaymentOptionsOutlet?: boolean | undefined;
    customPaymentTemplate?: TemplateRef<any>;
    hideOnlyOnePaymentProviderLabel?: boolean | undefined;
    forceRadioInputsView?: boolean | undefined;
    forceDefaultPaymentOptionInputSelection?: boolean | undefined;
    renderPaymentWrapper?: boolean | undefined;
    noRenderPaymentWrapperMessage?: string;
    readonly opfCheckoutOutlets: typeof OpfCheckoutOutlets;
    protected outletContext$: Subject<any>;
    selectedPaymentId?: number;
    isOnlyOnePaymentOptionAvailable: boolean;
    activeConfigurations$: Observable<QueryState<OpfActiveConfigurationsResponse | undefined>>;
    iconTypes: typeof ICON_TYPE;
    paymentChange: EventEmitter<OpfActiveConfiguration>;
    selectedPaymentProviderName: EventEmitter<string>;
    protected paginationModel: PaginationModel | undefined;
    protected paymentDisabled$: Observable<boolean>;
    protected isStateEmpty(state: QueryState<OpfActiveConfigurationsResponse | undefined>): boolean;
    protected handleDefaultPaymentOptionInputSelection(state: QueryState<OpfActiveConfigurationsResponse | undefined>): void;
    protected checkIfOnlyOnePaymentOptionAvailable(state: QueryState<OpfActiveConfigurationsResponse | undefined>): boolean;
    getActiveConfigurations(): Observable<QueryState<OpfActiveConfigurationsResponse | undefined>>;
    updateActiveConfiguration(): void;
    getPaymentInfoMessage(paymentId: number | undefined): Observable<string>;
    get isPaymentInfoMessageVisible(): boolean;
    /**
     * Method pre-selects (based on terms and conditions state)
     * previously selected payment option ID by customer.
     */
    protected preselectPaymentOption(): void;
    protected shouldResolvePreselection(state: OpfMetadataModel, isPreselected: boolean): boolean;
    protected displayError(errorKey: string): void;
    protected emitOutletContext(): void;
    onSavedCardsSelected(): void;
    changePayment(payment: OpfActiveConfiguration): void;
    getPaginationModel(pagination?: OpfActiveConfigurationsPagination): PaginationModel;
    pageChange(page: number): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutPaymentsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfCheckoutPaymentsComponent, "cx-opf-checkout-payments", never, { "isHeadingDisplayed": { "alias": "isHeadingDisplayed"; "required": false; }; "headingTranslationKey": { "alias": "headingTranslationKey"; "required": false; }; "isPaymentRenderBelow": { "alias": "isPaymentRenderBelow"; "required": false; }; "isPaymentInfoMessageEnabled": { "alias": "isPaymentInfoMessageEnabled"; "required": false; }; "elementsPerPage": { "alias": "elementsPerPage"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "explicitTermsAndConditions": { "alias": "explicitTermsAndConditions"; "required": false; }; "onlyPaymentWrapperMode": { "alias": "onlyPaymentWrapperMode"; "required": false; }; "showBeforePaymentOptionsOutlet": { "alias": "showBeforePaymentOptionsOutlet"; "required": false; }; "customPaymentTemplate": { "alias": "customPaymentTemplate"; "required": false; }; "hideOnlyOnePaymentProviderLabel": { "alias": "hideOnlyOnePaymentProviderLabel"; "required": false; }; "forceRadioInputsView": { "alias": "forceRadioInputsView"; "required": false; }; "forceDefaultPaymentOptionInputSelection": { "alias": "forceDefaultPaymentOptionInputSelection"; "required": false; }; "renderPaymentWrapper": { "alias": "renderPaymentWrapper"; "required": false; }; "noRenderPaymentWrapperMessage": { "alias": "noRenderPaymentWrapperMessage"; "required": false; }; }, { "paymentChange": "paymentChange"; "selectedPaymentProviderName": "selectedPaymentProviderName"; }, never, ["*"], true, never>;
}

declare class OpfCheckoutPaymentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutPaymentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCheckoutPaymentsModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.SpinnerModule, typeof i3.PaginationModule, typeof i3.IconModule, typeof OpfCheckoutPaymentWrapperModule, typeof OpfCheckoutTermsAndConditionsAlertModule, typeof OpfCheckoutPaymentsComponent], [typeof OpfCheckoutPaymentsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCheckoutPaymentsModule>;
}

interface OpfCheckoutReviewCardEditConfig {
    route?: string;
    ariaLabelKey?: string;
}

declare class OpfCheckoutReviewCardComponent {
    cardContent$: Observable<Card | null | undefined>;
    editConfig: OpfCheckoutReviewCardEditConfig;
    iconTypes: typeof ICON_TYPE;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutReviewCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfCheckoutReviewCardComponent, "cx-opf-checkout-review-card", never, { "cardContent$": { "alias": "cardContent$"; "required": false; }; "editConfig": { "alias": "editConfig"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OpfCheckoutReviewCardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutReviewCardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCheckoutReviewCardModule, never, [typeof i1.CommonModule, typeof i2$1.RouterModule, typeof i2.I18nModule, typeof i3.CardModule, typeof i3.IconModule, typeof i2.UrlModule, typeof OpfCheckoutReviewCardComponent], [typeof OpfCheckoutReviewCardComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCheckoutReviewCardModule>;
}

declare class OpfCheckoutReviewCartDetailsComponent extends CheckoutReviewSubmitComponent {
    cart: Cart | null;
    entries: any[] | null;
    isAddressCardVisible: boolean;
    readonly promotionLocation: PromotionLocation;
    cartOutlets: typeof CartOutlets;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutReviewCartDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfCheckoutReviewCartDetailsComponent, "cx-opf-checkout-review-cart-details", never, { "cart": { "alias": "cart"; "required": false; }; "entries": { "alias": "entries"; "required": false; }; "isAddressCardVisible": { "alias": "isAddressCardVisible"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OpfCheckoutReviewCartDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutReviewCartDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCheckoutReviewCartDetailsModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i2.UrlModule, typeof i3.PromotionsModule, typeof i3.OutletModule, typeof OpfCheckoutReviewCardModule, typeof OpfCheckoutReviewCartDetailsComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCheckoutReviewCartDetailsModule>;
}

declare class OpfCheckoutPaymentAndReviewComponent extends CheckoutReviewSubmitComponent implements OnInit {
    protected fb: UntypedFormBuilder;
    protected opfMetadataStoreService: OpfMetadataStoreService;
    protected cmsService: CmsService;
    protected checkoutPaymentTypeFacade: CheckoutPaymentTypeFacade;
    protected opfBaseFacade: OpfBaseFacade;
    protected checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade;
    protected activeCartFacade: ActiveCartFacade;
    protected opfCheckoutBillingAddressFormService: OpfCheckoutBillingAddressFormService;
    protected defaultTermsAndConditionsFieldValue: boolean;
    protected selectedPaymentProviderName$: BehaviorSubject<string | null | undefined>;
    readonly opfCheckoutOutlets: typeof OpfCheckoutOutlets;
    paymentOptionsDisabled$: Observable<boolean>;
    explicitTermsAndConditions$: Observable<boolean | undefined>;
    checkoutSubmitForm: UntypedFormGroup;
    get termsAndConditionInvalid(): boolean;
    get termsAndConditionsFieldValue(): boolean;
    getSelectedPayment$: Observable<i2.QueryState<_spartacus_opf_base_root.OpfActiveConfigurationsResponse | undefined>>;
    getSelectedPaymentId$: Observable<number | undefined>;
    protected isCmsComponentInPage(cmsComponentUid: string, page: Page): boolean;
    protected updateTermsAndConditionsState(): void;
    toggleTermsAndConditions(): void;
    onPaymentProviderSelected(providerName: string): void;
    setPickupDeliveryMode(): void;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutPaymentAndReviewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfCheckoutPaymentAndReviewComponent, "cx-opf-checkout-payment-and-review", never, {}, {}, never, never, true, never>;
}

declare class OpfCheckoutPaymentAndReviewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutPaymentAndReviewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCheckoutPaymentAndReviewModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof OpfCheckoutPaymentsModule, typeof i2.UrlModule, typeof i3$1.ReactiveFormsModule, typeof i2$1.RouterModule, typeof OpfCheckoutBillingAddressFormModule, typeof i6.AddressFormModule, typeof i3.OutletModule, typeof i3.PromotionsModule, typeof i3.IconModule, typeof i3.CardModule, typeof OpfCheckoutTermsAndConditionsAlertModule, typeof OpfCheckoutPaymentWrapperModule, typeof OpfCheckoutReviewCardModule, typeof OpfCheckoutReviewCartDetailsModule, typeof OpfCheckoutPaymentAndReviewComponent], [typeof OpfCheckoutPaymentAndReviewComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCheckoutPaymentAndReviewModule>;
}

declare class OpfCheckoutEmailUpdateComponent {
    protected cartGuestUserFacade: CartGuestUserFacade;
    protected multiCartFacade: MultiCartFacade;
    protected userIdService: UserIdService;
    protected router: RoutingService;
    protected semanticPathService: SemanticPathService;
    protected activeCartFacade: ActiveCartFacade;
    checkoutLoginForm: UntypedFormGroup;
    onSubmit(): void;
    protected updateCartGuestUserEmail(email: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutEmailUpdateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfCheckoutEmailUpdateComponent, "cx-opf-checkout-email-update", never, {}, {}, never, never, true, never>;
}

declare class OpfCheckoutEmailUpdateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutEmailUpdateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCheckoutEmailUpdateModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3$1.FormsModule, typeof i3$1.ReactiveFormsModule, typeof i3.FormErrorsModule, typeof OpfCheckoutEmailUpdateComponent], [typeof OpfCheckoutEmailUpdateComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCheckoutEmailUpdateModule>;
}

declare class OpfCheckoutComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfCheckoutComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfCheckoutComponentsModule, never, [typeof OpfCheckoutPaymentAndReviewModule, typeof OpfCheckoutPaymentsModule, typeof OpfCheckoutBillingAddressFormModule, typeof OpfCheckoutPaymentWrapperModule, typeof OpfCheckoutReviewCardModule, typeof OpfCheckoutEmailUpdateModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfCheckoutComponentsModule>;
}

export { GetAddressCardContent, OpfCheckoutBillingAddressFormComponent, OpfCheckoutBillingAddressFormModule, OpfCheckoutBillingAddressFormService, OpfCheckoutComponentsModule, OpfCheckoutEmailUpdateComponent, OpfCheckoutEmailUpdateModule, OpfCheckoutPaymentAndReviewComponent, OpfCheckoutPaymentAndReviewModule, OpfCheckoutPaymentWrapperComponent, OpfCheckoutPaymentWrapperModule, OpfCheckoutPaymentWrapperService, OpfCheckoutPaymentsComponent, OpfCheckoutPaymentsModule, OpfCheckoutReviewCardComponent, OpfCheckoutReviewCardModule, OpfCheckoutReviewCartDetailsComponent, OpfCheckoutReviewCartDetailsModule, OpfCheckoutTermsAndConditionsAlertComponent, OpfCheckoutTermsAndConditionsAlertModule };
export type { OpfCheckoutReviewCardEditConfig };
