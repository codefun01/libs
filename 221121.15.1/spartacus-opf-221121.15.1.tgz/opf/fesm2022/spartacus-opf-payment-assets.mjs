var opfPayment$w = {
	errors: {
		proceedPayment: "Momentálně nemůžeme zpracovat tento způsob platby. Opakujte později nebo vyberte jiný způsob platby.",
		cancelPayment: "Zrušili jste platbu. Chcete-li pokračovat v objednávce, zkuste to znovu, nebo si vyberte jiný způsob platby.",
		cardExpired: "Platnost karty vypršela.",
		insufficientFunds: "Nedostatečné prostředky.",
		invalidCreditCard: "Neplatná karta. Zkontrolujte údaje karty.",
		unknown: "Došlo k neznámé chybě při načítání platby. Obraťte se na podporu.",
		cardReportedLost: "Karta byla nahlášena jako ztracená."
	}
};
var opfPayment$x = {
	opfPayment: opfPayment$w
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const cs = {
    opfPayment: opfPayment$x,
};

var opfPayment$u = {
	errors: {
		proceedPayment: "Zurzeit ist es nicht möglich, mit dieser Zahlungsart fortzufahren. Versuchen Sie es später erneut, oder wählen Sie eine andere Zahlungsoption aus.",
		cancelPayment: "Sie haben Ihre Zahlung abgebrochen. Um mit der Bestellung fortzufahren, versuchen Sie es erneut, oder wählen Sie eine andere Zahlungsoption aus.",
		cardExpired: "Karte ist abgelaufen.",
		insufficientFunds: "Unzureichende Deckung.",
		invalidCreditCard: "Ungültige Kreditkarte. Überprüfen Sie Ihre Kartendetails.",
		unknown: "Beim Abrufen der Zahlung ist ein unbekannter Fehler aufgetreten. Bitte wenden Sie sich an den Support.",
		cardReportedLost: "Karte ist als verloren gemeldet."
	}
};
var opfPayment$v = {
	opfPayment: opfPayment$u
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const de = {
    opfPayment: opfPayment$v,
};

var opfPayment$s = {
	errors: {
		proceedPayment: "We are unable to proceed with this payment method at this time. Please try again later or choose a different payment option.",
		cancelPayment: "You have cancelled your payment. To proceed with the order, try again, or choose a different payment option.",
		cardExpired: "Card is expired.",
		insufficientFunds: "Insufficient funds.",
		invalidCreditCard: "Invalid credit card.  Please review card details.",
		unknown: "Unknown error occurred while fetching payment. Please contact support",
		cardReportedLost: "Card is reported lost."
	}
};
var opfPayment$t = {
	opfPayment: opfPayment$s
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const en = {
    opfPayment: opfPayment$t,
};

var opfPayment$q = {
	errors: {
		proceedPayment: "No es posible continuar con este método de pago en este momento. Inténtelo de nuevo más tarde o seleccione una opción de pago diferente.",
		cancelPayment: "Canceló su pago. Para continuar con el pedido, inténtelo de nuevo o seleccione una opción de pago diferente.",
		cardExpired: "La tarjeta ha vencido.",
		insufficientFunds: "Fondos insuficientes.",
		invalidCreditCard: "Tarjeta de crédito no válida. Revise los detalles de la tarjeta.",
		unknown: "Ocurrió un error desconocido al obtener el pago. Póngase en contacto con el servicio de soporte",
		cardReportedLost: "La tarjeta se denunció como perdida."
	}
};
var opfPayment$r = {
	opfPayment: opfPayment$q
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const es = {
    opfPayment: opfPayment$r,
};

var opfPayment$o = {
	errors: {
		proceedPayment: "No es posible continuar con este método de pago en este momento. Inténtelo de nuevo más tarde o seleccione una opción de pago diferente.",
		cancelPayment: "Canceló su pago. Para continuar con el pedido, inténtelo de nuevo o seleccione una opción de pago diferente.",
		cardExpired: "La tarjeta está vencida.",
		insufficientFunds: "Fondos insuficientes.",
		invalidCreditCard: "Tarjeta de crédito no válida. Revise los detalles de la tarjeta.",
		unknown: "Ocurrió un error desconocido al obtener el pago. Póngase en contacto con el servicio de soporte",
		cardReportedLost: "La tarjeta se denunció como perdida."
	}
};
var opfPayment$p = {
	opfPayment: opfPayment$o
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const es_CO = {
    opfPayment: opfPayment$p,
};

var opfPayment$m = {
	errors: {
		proceedPayment: "Nous ne pouvons pas utiliser ce mode de paiement pour le moment. Veuillez réessayer ultérieurement ou choisir une autre option de paiement.",
		cancelPayment: "Vous avez annulé votre paiement. Pour poursuivre la commande, réessayez ou choisissez une autre option de paiement.",
		cardExpired: "La carte est expirée.",
		insufficientFunds: "Fonds insuffisants.",
		invalidCreditCard: "Carte de crédit non valide. Veuillez vérifier les détails de la carte.",
		unknown: "Une erreur inconnue s'est produite lors de la récupération du paiement. Veuillez contacter le service d'assistance.",
		cardReportedLost: "La carte a été déclarée perdue."
	}
};
var opfPayment$n = {
	opfPayment: opfPayment$m
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const fr = {
    opfPayment: opfPayment$n,
};

var opfPayment$k = {
	errors: {
		proceedPayment: "इस समय हम इस भुगतान विधि के साथ आगे बढ़ने में असमर्थ हैं. कृपया बाद में फिर को कोशिश करें या कोई अन्य भुगतान विधि चुनें.",
		cancelPayment: "आपने अपना भुगतान रद्द किया.  ऑर्डर के साथ आगे बढ़ने के लिए, फिर से कोशिश करें, या कोई अन्य भुगतान विकल्प चुनें.",
		cardExpired: "कार्ड समाप्त हो गया है.",
		insufficientFunds: "अपर्याप्त निधियाँ",
		invalidCreditCard: "अमान्य क्रेडिट कार्ड. कृपया कार्ड विवरण की समीक्षा करें.",
		unknown: "भुगतान प्राप्त करते समय अज्ञात त्रुटि उत्पन्न हुई. कृपया सहायता से संपर्क करें",
		cardReportedLost: "कार्ड गुम होने की रिपोर्ट की गई है."
	}
};
var opfPayment$l = {
	opfPayment: opfPayment$k
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const hi = {
    opfPayment: opfPayment$l,
};

var opfPayment$i = {
	errors: {
		proceedPayment: "Jelenleg nem tudjuk feldolgozni ezt a fizetési lehetőséget. Próbálja újra később, vagy válasszon egy másik fizetési lehetőséget.",
		cancelPayment: "Törölte a fizetést. A rendelés folytatásához próbálja újra vagy válasszon egy másik fizetési lehetőséget.",
		cardExpired: "A kártya lejárt.",
		insufficientFunds: "Nincs elég fedezet.",
		invalidCreditCard: "Érvénytelen hitelkártya. Ellenőrizze a kártyaadatokat.",
		unknown: "Ismeretlen hiba történt a fizetés lekérésekor. Forduljon a támogatáshoz.",
		cardReportedLost: "A kártyát elveszettként jelentették."
	}
};
var opfPayment$j = {
	opfPayment: opfPayment$i
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const hu = {
    opfPayment: opfPayment$j,
};

var opfPayment$g = {
	errors: {
		proceedPayment: "Saat ini kami tidak dapat melanjutkan dengan metode pembayaran ini. Silakan coba lagi nanti atau pilih opsi pembayaran lain.",
		cancelPayment: "Pembayaran telah Anda batalkan. Untuk melanjutkan pemesanan, coba lagi atau pilih opsi pembayaran lain.",
		cardExpired: "Kartu telah kedaluwarsa.",
		insufficientFunds: "Dana tidak mencukupi.",
		invalidCreditCard: "Kartu kredit tidak valid. Silakan tinjau rincian kartu.",
		unknown: "Terjadi kesalahan yang tidak dikenal saat mengambil rincian pembayaran. Silakan hubungi bagian dukungan",
		cardReportedLost: "Kartu dilaporkan hilang."
	}
};
var opfPayment$h = {
	opfPayment: opfPayment$g
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const id = {
    opfPayment: opfPayment$h,
};

var opfPayment$e = {
	errors: {
		proceedPayment: "Al momento non è possibile procedere con questo metodo di pagamento. Riprovare più tardi o scegliere un'opzione di pagamento diversa.",
		cancelPayment: "Il pagamento è stato annullato. Per procedere con l'ordine, riprovare o scegliere un'opzione di pagamento diversa.",
		cardExpired: "Carta di credito scaduta.",
		insufficientFunds: "Fondi insufficienti.",
		invalidCreditCard: "Carta di credito non valida. Rivedere i dettagli della carta.",
		unknown: "Errore sconosciuto durante il recupero del pagamento. Contattare il supporto.",
		cardReportedLost: "La carta è segnalata come smarrita. "
	}
};
var opfPayment$f = {
	opfPayment: opfPayment$e
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const it = {
    opfPayment: opfPayment$f,
};

var opfPayment$c = {
	errors: {
		proceedPayment: "現時点ではこの支払方法を続行できません。後でもう一度実行するか、別の支払方法を選択してください。",
		cancelPayment: "支払をキャンセルしました。この注文を続行するには、もう一度実行するか、別の支払方法を選択してください。",
		cardExpired: "カードが有効期限切れです。",
		insufficientFunds: "金額が不足しています。",
		invalidCreditCard: "クレジットカードが無効です。カードの詳細を確認してください。",
		unknown: "支払のフェッチ中に不明なエラーが発生しました。サポートに連絡してください",
		cardReportedLost: "カードの紛失が報告されています。"
	}
};
var opfPayment$d = {
	opfPayment: opfPayment$c
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ja = {
    opfPayment: opfPayment$d,
};

var opfPayment$a = {
	errors: {
		proceedPayment: "현재 이 지불 방법으로 진행할 수 없습니다. 나중에 다시 시도하거나 다른 지불 옵션을 선택하십시오.",
		cancelPayment: "지불을 취소했습니다. 주문을 계속하려면  나중에 다시 시도하거나 다른 지불 옵션을 선택하십시오.",
		cardExpired: "만료된 카드입니다.",
		insufficientFunds: "자금이 부족합니다.",
		invalidCreditCard: "유효하지 않은 신용카드입니다. 카드 세부사항을 검토하십시오.",
		unknown: "지불 기능을 불러오는 동안 알 수 없는 오류가 발생했습니다.",
		cardReportedLost: "분실 신고된 카드입니다."
	}
};
var opfPayment$b = {
	opfPayment: opfPayment$a
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ko = {
    opfPayment: opfPayment$b,
};

var opfPayment$8 = {
	errors: {
		proceedPayment: "W tej chwili nie możemy dokonać płatności tą metodą. Spróbuj ponownie później lub wybierz inną opcję płatności.",
		cancelPayment: "Płatność została anulowana. Aby kontynuować realizację zamówienia, spróbuj ponownie lub wybierz inną opcję płatności.",
		cardExpired: "Karta kredytowa wygasła.",
		insufficientFunds: "Niewystarczające środki finansowe.",
		invalidCreditCard: "Nieprawidłowa karta kredytowa. Sprawdź dane karty.",
		unknown: "Podczas pobierania płatności wystąpił nieznany błąd. Prosimy o kontakt z obsługą klienta",
		cardReportedLost: "Karta została zgłoszona jako utracona."
	}
};
var opfPayment$9 = {
	opfPayment: opfPayment$8
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const pl = {
    opfPayment: opfPayment$9,
};

var opfPayment$6 = {
	errors: {
		proceedPayment: "Não é possível continuar com esta forma de pagamento de momento. Tente novamente mais tarde ou selecione uma opção de pagamento diferente.",
		cancelPayment: "Você cancelou seu pagamento. Para continuar com o pedido, tente novamente ou selecione uma opção de pagamento diferente.",
		cardExpired: "O cartão está expirado.",
		insufficientFunds: "Fundos insuficientes.",
		invalidCreditCard: "Cartão de crédito inválido. Revise os detalhes do cartão.",
		unknown: "Ocorreu um erro desconhecido ao obter o pagamento. Contate o suporte",
		cardReportedLost: "O cartão está reportado como perdido."
	}
};
var opfPayment$7 = {
	opfPayment: opfPayment$6
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const pt = {
    opfPayment: opfPayment$7,
};

var opfPayment$4 = {
	errors: {
		proceedPayment: "На данный момент мы не можем продолжить с этим методом оплаты. Повторите попытку позже или выберите другой метод оплаты.",
		cancelPayment: "Вы отменили оплату. Чтобы продолжить оформление заказа, попробуйте еще раз или выберите другую опцию оплаты.",
		cardExpired: "Срок действия карты истек.",
		insufficientFunds: "Недостаточно средств.",
		invalidCreditCard: "Недействительная кредитная карта. Проверьте данные карты.",
		unknown: "Неизвестная ошибка при получении оплаты. Обратитесь в службу поддержки.",
		cardReportedLost: "По этой карте есть заявление об утере."
	}
};
var opfPayment$5 = {
	opfPayment: opfPayment$4
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ru = {
    opfPayment: opfPayment$5,
};

var opfPayment$2 = {
	errors: {
		proceedPayment: "我们此时无法继续使用此付款方式。请稍后重试或选择其他付款选项。",
		cancelPayment: "您已取消付款。要继续支付订单，请重试或选择其他付款选项。",
		cardExpired: "卡已过期。",
		insufficientFunds: "余额不足。",
		invalidCreditCard: "信用卡无效。请查看信用卡详情。",
		unknown: "获取付款时出现未知错误。请联系支持部门",
		cardReportedLost: "卡已报失。"
	}
};
var opfPayment$3 = {
	opfPayment: opfPayment$2
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const zh = {
    opfPayment: opfPayment$3,
};

var opfPayment = {
	errors: {
		proceedPayment: "系統目前無法繼續此付款方法。請稍後再試一次貨選擇不同付款選項。",
		cancelPayment: "您已取消付款。若要繼續訂單，請再試一次貨選擇不同付款選項。",
		cardExpired: "卡片已到期。",
		insufficientFunds: "資金不足。",
		invalidCreditCard: "信用卡無效，請審查卡片明細。",
		unknown: "取得付款時發生未知錯誤。請聯絡支援團隊",
		cardReportedLost: "卡片已掛失。"
	}
};
var opfPayment$1 = {
	opfPayment: opfPayment
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const zh_TW = {
    opfPayment: opfPayment$1,
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const opfPaymentTranslationChunksConfig = {
    opfPayment: ['opfPayment'],
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { opfPaymentTranslationChunksConfig, cs as opfPaymentTranslationsCs, de as opfPaymentTranslationsDe, en as opfPaymentTranslationsEn, es as opfPaymentTranslationsEs, es_CO as opfPaymentTranslationsEs_CO, fr as opfPaymentTranslationsFr, hi as opfPaymentTranslationsHi, hu as opfPaymentTranslationsHu, id as opfPaymentTranslationsId, it as opfPaymentTranslationsIt, ja as opfPaymentTranslationsJa, ko as opfPaymentTranslationsKo, pl as opfPaymentTranslationsPl, pt as opfPaymentTranslationsPt, ru as opfPaymentTranslationsRu, zh as opfPaymentTranslationsZh, zh_TW as opfPaymentTranslationsZh_TW };
//# sourceMappingURL=spartacus-opf-payment-assets.mjs.map
