var opfGiftCard = {
	title: "Gift Card:",
	giftCardPayment: "Gift Card",
	haveGiftCard: "Have a gift card?",
	addGiftCard: "Add Gift Card",
	cardNumber: "Card Number",
	pin: "Pin",
	proceedPayment: "Place Order",
	apply: "Apply",
	remove: "Remove",
	appliedSuccessfully: "Gift card applied.",
	removedSuccessfully: "Gift card removed.",
	currentBalance: "Current Balance",
	balanceAfterPurchase: "Balance After Purchase",
	errors: {
		placeOrderFailed: "Gift Card Payment failed. We cannot proceed with the checkout."
	},
	common: {
		formErrors: {
			labeled: {
				required: "{{label}} is required.",
				minlength: "{{label}} must be at least {{requiredLength}} characters.",
				maxlength: "{{label}} cannot be more than {{requiredLength}} characters."
			},
			required: "This field is required.",
			minlength: "This field must be at least {{requiredLength}} characters.",
			maxlength: "This field cannot be more than {{requiredLength}} characters."
		}
	}
};
var opfGiftCard$1 = {
	opfGiftCard: opfGiftCard
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const en = {
    opfGiftCard: opfGiftCard$1,
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const opfGiftCardTranslationChunksConfig = {
    opfGiftCard: ['opfGiftCard'],
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const opfGiftCardTranslations = {
    en: en,
};

/**
 * Generated bundle index. Do not edit.
 */

export { opfGiftCardTranslationChunksConfig, opfGiftCardTranslations, en as opfGiftCardTranslationsEn };
//# sourceMappingURL=spartacus-opf-gift-card-assets.mjs.map
