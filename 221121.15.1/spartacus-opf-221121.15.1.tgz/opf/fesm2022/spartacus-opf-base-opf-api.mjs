import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { ConverterService, LoggerService, tryNormalizeHttpError, provideDefaultConfig } from '@spartacus/core';
import { OpfEndpointsService, OPF_ACTIVE_CONFIGURATIONS_NORMALIZER, OpfBaseAdapter } from '@spartacus/opf/base/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { OpfConfig, OpfMetadataStatePersistanceService, OPF_CC_PUBLIC_KEY_HEADER } from '@spartacus/opf/base/root';
import { catchError } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfApiBaseAdapter {
    constructor() {
        this.http = inject(HttpClient);
        this.converter = inject(ConverterService);
        this.opfEndpointsService = inject(OpfEndpointsService);
        this.config = inject(OpfConfig);
        this.opfMetadataStatePersistanceService = inject(OpfMetadataStatePersistanceService);
        this.logger = inject(LoggerService);
        this.headerWithNoLanguage = {
            accept: 'application/json',
            'Content-Type': 'application/json',
        };
        this.header = {
            ...this.headerWithNoLanguage,
            'Accept-Language': this.opfMetadataStatePersistanceService.getActiveLanguage(),
        };
        this.headerWithContentLanguage = {
            ...this.headerWithNoLanguage,
            'Content-Language': this.opfMetadataStatePersistanceService.getActiveLanguage(),
        };
    }
    getActiveConfigurations(query) {
        const headers = new HttpHeaders(this.header).set(OPF_CC_PUBLIC_KEY_HEADER, this.config.opf?.commerceCloudPublicKey || '');
        return this.http
            .get(this.getActiveConfigurationsEndpoint(query), {
            headers,
        })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), this.converter.pipeable(OPF_ACTIVE_CONFIGURATIONS_NORMALIZER));
    }
    getActiveConfigurationsEndpoint(query) {
        return this.opfEndpointsService.buildUrl('getActiveConfigurations', {
            queryParams: query,
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfApiBaseAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfApiBaseAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfApiBaseAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOpfApiBaseConfig = {
    backend: {
        opfApi: {
            endpoints: {
                getActiveConfigurations: 'active-configurations',
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfApiBaseModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfApiBaseModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfApiBaseModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfApiBaseModule, providers: [
            provideDefaultConfig(defaultOpfApiBaseConfig),
            {
                provide: OpfBaseAdapter,
                useClass: OpfApiBaseAdapter,
            },
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfApiBaseModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [
                        provideDefaultConfig(defaultOpfApiBaseConfig),
                        {
                            provide: OpfBaseAdapter,
                            useClass: OpfApiBaseAdapter,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfApiBaseModule };
//# sourceMappingURL=spartacus-opf-base-opf-api.mjs.map
