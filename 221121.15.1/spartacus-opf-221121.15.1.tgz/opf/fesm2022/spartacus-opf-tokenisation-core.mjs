import * as i0 from '@angular/core';
import { Injectable, inject, NgModule } from '@angular/core';
import { UserPaymentService } from '@spartacus/core';
import { OpfTokenisationFacade } from '@spartacus/opf/tokenisation/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * OPF Tokenisation Adapter
 *
 * Reserved for OPF-specific HTTP operations related to payment tokenisation.
 * Currently unused as all payment operations are delegated to the core UserPaymentService to avoid code duplication.
 * However, this adapter serves as a placeholder for any future OPF-specific tokenisation logic that may arise as the feature evolves.
 *
 */
class OpfTokenisationAdapter {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfTokenisationAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfTokenisationAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfTokenisationAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * OPF Tokenisation Connector
 *
 * Central connector for OPF payment tokenisation operations.
 * Acts as an intermediary between the service layer and adapters.
 *
 * Currently delegates all payment operations to core UserPaymentService to avoid code duplication.
 * Can be extended to integrate OPF-specific adapters as needed.
 *
 */
class OpfTokenisationConnector {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfTokenisationConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfTokenisationConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfTokenisationConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfTokenisationService {
    constructor() {
        this.userPaymentService = inject(UserPaymentService);
    }
    /**
     * Returns all user's payment methods
     */
    getPaymentMethods() {
        return this.userPaymentService.getPaymentMethods();
    }
    /**
     * Returns a loading flag for payment methods
     */
    getPaymentMethodsLoading() {
        return this.userPaymentService.getPaymentMethodsLoading();
    }
    /**
     * Loads all user's payment methods
     */
    loadPaymentMethods() {
        this.userPaymentService.loadPaymentMethods();
    }
    /**
     * Deletes the payment method
     *
     * @param paymentMethodId a payment method ID
     */
    deletePaymentMethod(paymentMethodId) {
        this.userPaymentService.deletePaymentMethod(paymentMethodId);
    }
    /**
     * Sets the payment as a default one
     * @param paymentMethodId a payment method ID
     */
    setPaymentMethodAsDefault(paymentMethodId) {
        this.userPaymentService.setPaymentMethodAsDefault(paymentMethodId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfTokenisationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfTokenisationService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfTokenisationService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

const facadeProviders = [
    OpfTokenisationService,
    {
        provide: OpfTokenisationFacade,
        useExisting: OpfTokenisationService,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfTokenisationCoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfTokenisationCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfTokenisationCoreModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfTokenisationCoreModule, providers: [...facadeProviders, OpfTokenisationConnector] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfTokenisationCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    providers: [...facadeProviders, OpfTokenisationConnector],
                }]
        }] });

"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * OPF Tokenisation Converters/Normalizers
 *
 * This file defines InjectionTokens for OCC data converters used to normalize
 * raw API responses into typed application models.
 *
 * Currently unused as tokenisation delegates to core UserPaymentService
 * which already provides normalized PaymentDetails[] which we use as OpfPaymentDetails[].
 *
 * Reserved for future OPF-specific data converters.
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfTokenisationAdapter, OpfTokenisationConnector, OpfTokenisationCoreModule, OpfTokenisationService };
//# sourceMappingURL=spartacus-opf-tokenisation-core.mjs.map
