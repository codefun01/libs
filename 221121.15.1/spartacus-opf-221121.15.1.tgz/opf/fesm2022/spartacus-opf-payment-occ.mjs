import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { LoggerService, OccEndpointsService, ConverterService, tryNormalizeHttpError, backOff, isJaloError, provideDefaultConfig } from '@spartacus/core';
import { OpfPaymentOccAdapter } from '@spartacus/opf/payment/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CART_NORMALIZER } from '@spartacus/cart/base/root';
import { catchError } from 'rxjs/operators';
import { CommonModule } from '@angular/common';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccOpfPaymentAdapter {
    constructor() {
        this.logger = inject(LoggerService);
        this.occEndpoints = inject(OccEndpointsService);
        this.http = inject(HttpClient);
        this.converter = inject(ConverterService);
    }
    setCartPaymentOption(userId, cartId, sapPaymentOptionId, purchaseOrderNumber) {
        const CONTENT_TYPE_JSON_HEADER = { 'Content-Type': 'application/json' };
        const headers = new HttpHeaders({
            ...CONTENT_TYPE_JSON_HEADER,
        });
        return this.http
            .put(this.getSetCartPaymentOptionEndpoint(userId, cartId), JSON.stringify({
            sapPaymentOptionId: sapPaymentOptionId,
            purchaseOrderNumber: purchaseOrderNumber,
        }), { headers })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({ shouldRetry: isJaloError }), this.converter.pipeable(CART_NORMALIZER));
    }
    getSetCartPaymentOptionEndpoint(userId, cartId) {
        return this.occEndpoints.buildUrl('setCartPaymentOption', {
            urlParams: {
                userId,
                cartId,
            },
            queryParams: {
                fields: 'DEFAULT',
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccOpfPaymentAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccOpfPaymentAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccOpfPaymentAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOccOpfPaymentConfig = {
    backend: {
        occ: {
            endpoints: {
                setCartPaymentOption: 'users/${userId}/carts/${cartId}/paymentOption',
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfPaymentOccModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentOccModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentOccModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentOccModule, providers: [
            provideDefaultConfig(defaultOccOpfPaymentConfig),
            {
                provide: OpfPaymentOccAdapter,
                useClass: OccOpfPaymentAdapter,
            },
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentOccModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [
                        provideDefaultConfig(defaultOccOpfPaymentConfig),
                        {
                            provide: OpfPaymentOccAdapter,
                            useClass: OccOpfPaymentAdapter,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfPaymentOccModule };
//# sourceMappingURL=spartacus-opf-payment-occ.mjs.map
