import '@spartacus/opf/base/root';
import '@spartacus/opf/payment/root';
import * as i0 from '@angular/core';
import { Injectable, NgModule } from '@angular/core';
import { Config, facadeFactory, provideDefaultConfigFactory, provideDefaultConfig } from '@spartacus/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_QUICK_BUY_DEFAULT_MERCHANT_NAME = 'Store';
const OPF_QUICK_BUY_ADDRESS_FIELD_PLACEHOLDER = '[FIELD_NOT_SET]';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var ApplePayEvent;
(function (ApplePayEvent) {
    ApplePayEvent["VALIDATE_MERCHANT"] = "validatemerchant";
    ApplePayEvent["CANCEL"] = "cancel";
    ApplePayEvent["PAYMENT_METHOD_SELECTED"] = "paymentmethodselected";
    ApplePayEvent["SHIPPING_CONTACT_SELECTED"] = "shippingcontactselected";
    ApplePayEvent["SHIPPING_METHOD_SELECTED"] = "shippingmethodselected";
    ApplePayEvent["PAYMENT_AUTHORIZED"] = "paymentauthorized";
})(ApplePayEvent || (ApplePayEvent = {}));
var ApplePayShippingType;
(function (ApplePayShippingType) {
    ApplePayShippingType["SHIPPING"] = "shipping";
    ApplePayShippingType["DELIVERY"] = "delivery";
    ApplePayShippingType["STORE_PICKUP"] = "storePickup";
    ApplePayShippingType["SERVICE_PICKUP"] = "servicePickup";
})(ApplePayShippingType || (ApplePayShippingType = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var OpfQuickBuyLocation;
(function (OpfQuickBuyLocation) {
    OpfQuickBuyLocation["CART"] = "CART";
    OpfQuickBuyLocation["PRODUCT"] = "PRODUCT";
})(OpfQuickBuyLocation || (OpfQuickBuyLocation = {}));
var OpfQuickBuyDeliveryType;
(function (OpfQuickBuyDeliveryType) {
    OpfQuickBuyDeliveryType["SHIPPING"] = "SHIPPING";
    OpfQuickBuyDeliveryType["PICKUP"] = "PICKUP";
})(OpfQuickBuyDeliveryType || (OpfQuickBuyDeliveryType = {}));
var OpfQuickBuyProviderType;
(function (OpfQuickBuyProviderType) {
    OpfQuickBuyProviderType["APPLE_PAY"] = "APPLE_PAY";
    OpfQuickBuyProviderType["GOOGLE_PAY"] = "GOOGLE_PAY";
})(OpfQuickBuyProviderType || (OpfQuickBuyProviderType = {}));
const OPF_GOOGLE_PAY_PROVIDER_NAME = 'googlePay';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOpfQuickBuyConfig = {
    providers: {
        googlePay: {
            resourceUrl: 'https://pay.google.com/gp/p/js/pay.js',
            environment: 'TEST',
            paymentRequest: {
                apiVersion: 2,
                apiVersionMinor: 0,
                merchantInfo: {
                    merchantId: '',
                    merchantName: OPF_QUICK_BUY_DEFAULT_MERCHANT_NAME,
                },
                emailRequired: true,
                shippingAddressRequired: true,
                shippingOptionRequired: true,
                shippingAddressParameters: {
                    phoneNumberRequired: false,
                },
                callbackIntents: [
                    'PAYMENT_AUTHORIZATION',
                    'SHIPPING_ADDRESS',
                    'SHIPPING_OPTION',
                ],
            },
            cardParameters: {
                allowedAuthMethods: ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
                allowedCardNetworks: [
                    'AMEX',
                    'DISCOVER',
                    'INTERAC',
                    'JCB',
                    'MASTERCARD',
                    'VISA',
                ],
                billingAddressRequired: true,
                billingAddressParameters: {
                    format: 'FULL',
                },
            },
        },
        applePay: {
            resourceUrl: 'https://applepay.cdn-apple.com/jsapi/1.latest/apple-pay-sdk.js',
            cardParameters: {
                shippingMethods: [],
                merchantCapabilities: ['supports3DS'],
                supportedNetworks: ['visa', 'masterCard', 'amex', 'discover'],
                requiredShippingContactFields: ['email', 'name', 'postalAddress'],
                requiredBillingContactFields: ['email', 'name', 'postalAddress'],
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyConfig {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyConfig, providedIn: 'root', useExisting: Config }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useExisting: Config,
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_QUICK_BUY_FEATURE = 'opfQuickBuy';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: OpfQuickBuyFacade,
            feature: OPF_QUICK_BUY_FEATURE,
            methods: ['getApplePayWebSession'],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: OpfQuickBuyFacade,
                        feature: OPF_QUICK_BUY_FEATURE,
                        methods: ['getApplePayWebSession'],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
function defaultOpfQuickBuyCmsComponentsConfig() {
    const config = {
        featureModules: {
            [OPF_QUICK_BUY_FEATURE]: {
                cmsComponents: ['OpfQuickBuyButtonsComponent'],
            },
        },
    };
    return config;
}
class OpfQuickBuyRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyRootModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyRootModule, providers: [
            provideDefaultConfigFactory(defaultOpfQuickBuyCmsComponentsConfig),
            provideDefaultConfig(defaultOpfQuickBuyConfig),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyRootModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        provideDefaultConfigFactory(defaultOpfQuickBuyCmsComponentsConfig),
                        provideDefaultConfig(defaultOpfQuickBuyConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ApplePayEvent, ApplePayShippingType, OPF_GOOGLE_PAY_PROVIDER_NAME, OPF_QUICK_BUY_ADDRESS_FIELD_PLACEHOLDER, OPF_QUICK_BUY_DEFAULT_MERCHANT_NAME, OPF_QUICK_BUY_FEATURE, OpfQuickBuyConfig, OpfQuickBuyDeliveryType, OpfQuickBuyFacade, OpfQuickBuyLocation, OpfQuickBuyProviderType, OpfQuickBuyRootModule, defaultOpfQuickBuyCmsComponentsConfig, defaultOpfQuickBuyConfig };
//# sourceMappingURL=spartacus-opf-quick-buy-root.mjs.map
