import * as i0 from '@angular/core';
import { inject, Injectable, NgModule, InjectionToken } from '@angular/core';
import { QueryService, CommandService, BaseSiteService, StringTemplate, HttpParamsURIEncoder } from '@spartacus/core';
import { OpfBaseFacade, OpfConfig, OpfApiConfig } from '@spartacus/opf/base/root';
import { HttpParams } from '@angular/common/http';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfBaseAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfBaseConnector {
    constructor() {
        this.adapter = inject(OpfBaseAdapter);
    }
    getActiveConfigurations(query) {
        return this.adapter.getActiveConfigurations(query);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfBaseConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfBaseConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfBaseConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfBaseService {
    constructor() {
        this.queryService = inject(QueryService);
        this.commandService = inject(CommandService);
        this.opfBaseConnector = inject(OpfBaseConnector);
        this.activeConfigurationsQuery = (query) => this.queryService.create(() => this.opfBaseConnector.getActiveConfigurations(query));
    }
    getActiveConfigurationsState(query) {
        return this.activeConfigurationsQuery(query).getState();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfBaseService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfBaseService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfBaseService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const facadeProviders = [
    OpfBaseService,
    {
        provide: OpfBaseFacade,
        useExisting: OpfBaseService,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfBaseCoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfBaseCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfBaseCoreModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfBaseCoreModule, providers: [...facadeProviders, OpfBaseConnector] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfBaseCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    providers: [...facadeProviders, OpfBaseConnector],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfEndpointsService {
    initialize() {
        if (this.baseSiteService) {
            this.baseSiteService
                .getActive()
                .subscribe((value) => (this._activeBaseSite = value));
        }
    }
    constructor() {
        this.opfConfig = inject(OpfConfig);
        this.opfApiConfig = inject(OpfApiConfig);
        this.baseSiteService = inject(BaseSiteService);
        this.initialize();
    }
    buildUrl(endpoint, attributes) {
        const baseUrl = this.getBaseEndpoint();
        let opfEndpoint = this.getEndpointFromContext(endpoint);
        if (attributes) {
            const { urlParams, queryParams } = attributes;
            if (urlParams && opfEndpoint) {
                opfEndpoint = StringTemplate.resolve(opfEndpoint, urlParams, true);
            }
            if (queryParams) {
                let httpParamsOptions = { encoder: new HttpParamsURIEncoder() };
                if (opfEndpoint.includes('?')) {
                    let queryParamsFromEndpoint;
                    [opfEndpoint, queryParamsFromEndpoint] = opfEndpoint.split('?');
                    httpParamsOptions = {
                        ...httpParamsOptions,
                        ...{ fromString: queryParamsFromEndpoint },
                    };
                }
                const httpParams = this.getHttpParamsFromQueryParams(queryParams, httpParamsOptions);
                const params = httpParams.toString();
                if (params.length) {
                    opfEndpoint += '?' + params;
                }
            }
        }
        return `${baseUrl}/${this._activeBaseSite}/${opfEndpoint}`;
    }
    getEndpointFromContext(endpoint) {
        const endpointsConfig = this.opfApiConfig.backend?.opfApi?.endpoints;
        if (!endpointsConfig) {
            return '';
        }
        const endpointConfig = endpointsConfig[endpoint];
        return endpointConfig;
    }
    getBaseEndpoint() {
        if (this.opfConfig && this.opfConfig.opf && this.opfConfig.opf.opfBaseUrl) {
            return this.opfConfig.opf.opfBaseUrl;
        }
        return '';
    }
    getHttpParamsFromQueryParams(queryParams, options) {
        let httpParams = new HttpParams(options);
        Object.keys(queryParams).forEach((key) => {
            const value = queryParams[key];
            if (value !== undefined) {
                if (value === null) {
                    httpParams = httpParams.delete(key);
                }
                else {
                    httpParams = httpParams.set(key, value);
                }
            }
        });
        return httpParams;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfEndpointsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfEndpointsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfEndpointsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_ACTIVE_CONFIGURATIONS_NORMALIZER = new InjectionToken('OpfActiveConfigurationsNormalizer');

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OPF_ACTIVE_CONFIGURATIONS_NORMALIZER, OpfBaseAdapter, OpfBaseConnector, OpfBaseCoreModule, OpfBaseService, OpfEndpointsService };
//# sourceMappingURL=spartacus-opf-base-core.mjs.map
