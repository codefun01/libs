import * as i0 from '@angular/core';
import { Injectable, NgModule } from '@angular/core';
import { facadeFactory, provideDefaultConfig } from '@spartacus/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_GLOBAL_FUNCTIONS_FEATURE = 'opfGlobalFunctions';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGlobalFunctionsFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: OpfGlobalFunctionsFacade,
            feature: OPF_GLOBAL_FUNCTIONS_FEATURE,
            methods: ['registerGlobalFunctions', 'unregisterGlobalFunctions'],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: OpfGlobalFunctionsFacade,
                        feature: OPF_GLOBAL_FUNCTIONS_FEATURE,
                        methods: ['registerGlobalFunctions', 'unregisterGlobalFunctions'],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var OpfGlobalFunctionsDomain;
(function (OpfGlobalFunctionsDomain) {
    OpfGlobalFunctionsDomain["CHECKOUT"] = "checkout";
    OpfGlobalFunctionsDomain["GLOBAL"] = "global";
    OpfGlobalFunctionsDomain["REDIRECT"] = "redirect";
})(OpfGlobalFunctionsDomain || (OpfGlobalFunctionsDomain = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const opfCartEndpoints = {
    cart: 'users/${userId}/carts/${cartId}?fields=DEFAULT,potentialProductPromotions,appliedProductPromotions,potentialOrderPromotions,appliedOrderPromotions,entries(totalPrice(formattedValue),product(images(FULL),stock(FULL)),basePrice(formattedValue,value),updateable),totalPrice(formattedValue),totalItems,totalPriceWithTax(formattedValue),totalDiscounts(value,formattedValue),subTotal(formattedValue),totalUnitCount,deliveryItemsQuantity,deliveryCost(formattedValue),totalTax(formattedValue, value),pickupItemsQuantity,net,appliedVouchers,productDiscounts(formattedValue),user,saveTime,name,description,deliveryAddress(FULL),deliveryMode(FULL),paymentInfo(FULL),sapBillingAddress(FULL)',
};
const defaultOccOpfCartConfig = {
    backend: {
        occ: {
            endpoints: {
                ...opfCartEndpoints,
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGlobalFunctionsRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsRootModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsRootModule, providers: [provideDefaultConfig(defaultOccOpfCartConfig)] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsRootModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [provideDefaultConfig(defaultOccOpfCartConfig)],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OPF_GLOBAL_FUNCTIONS_FEATURE, OpfGlobalFunctionsDomain, OpfGlobalFunctionsFacade, OpfGlobalFunctionsRootModule, defaultOccOpfCartConfig };
//# sourceMappingURL=spartacus-opf-global-functions-root.mjs.map
