var opfCheckout$w = {
	tabs: {
		paymentType: "Způsob platby",
		shipping: "Dodací adresa",
		deliveryMethod: "Způsob dodání",
		paymentAndReview: "Platba a kontrola",
		review: "Zkontrolovat objednávku"
	},
	paymentAndReviewTitle: "Platba a kontrola",
	billingAddress: "Fakturační adresa",
	paymentOption: "Možnost platby",
	paymentMethod: "Způsob platby",
	noPaymentMethod: "Nebyl vybrán způsob platby",
	editCardDefaultLabel: "Upravit",
	editPaymentMethod: "Upravit způsob platby",
	poNumber: "Číslo objednávky",
	noPoNumber: "Nic",
	editPoNumber: "Upravit číslo objednávky",
	costCenter: "Nákladové středisko",
	editCostCenter: "Upravit nákladové středisko",
	termsAndConditions: "Obchodní podmínky",
	closeTermsAndConditionsAlert: "Zavřít upozornění",
	itemsToBeShipped: "Položky k odeslání",
	proceedPayment: "Objednat",
	defaultPaymentInfoMessage: "Chystáte se provést platbu. V závislosti na zvolené možnosti budete buď přesměrováni na zabezpečenou externí stránku, nebo dokončíte proces přímo na této stránce",
	proceedPaymentButtonLabel: "Zadáním objednávky se otevře externí stránka",
	retryPayment: "Chcete-li pokračovat, zkuste to znovu.",
	checkTermsAndConditionsExplicit: "Aby se vám zobrazily možnosti platby, musíte odsouhlasit Obchodní podmínky.",
	checkTermsAndConditionsImplicit: "Odesláním objednávky vyjadřujete souhlas s Obchodními podmínkami.",
	errors: {
		loadActiveConfigurations: "Momentálně nemůžeme načíst možnosti platby. Zkuste to znovu později.",
		noActiveConfigurations: "Momentálně nejsou k dispozici žádné možnosti platby. Zkuste to později znovu nebo kontaktujte podporu.",
		updateBillingAddress: "Adresu nebylo možné aktualizovat. Zkontrolujte, zda jsou údaje o adrese správné a zda je vaše zařízení připojeno k internetu. Pokud problém přetrvává, bude možná nutné vyprázdnit košík a znovu zahájit proces kontroly a potvrzení."
	}
};
var opfCheckout$x = {
	opfCheckout: opfCheckout$w
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const cs = {
    opfCheckout: opfCheckout$x,
};

var opfCheckout$u = {
	tabs: {
		paymentType: "Zahlungsart",
		shipping: "Lieferadresse",
		deliveryMethod: "Lieferart",
		paymentAndReview: "Zahlung und Prüfung",
		review: "Bestellung prüfen"
	},
	paymentAndReviewTitle: "Zahlung und Prüfung",
	billingAddress: "Rechnungsadresse",
	paymentOption: "Zahlungsoption",
	paymentMethod: "Zahlungsart",
	noPaymentMethod: "Keine Zahlungsart ausgewählt",
	editCardDefaultLabel: "Bearbeiten",
	editPaymentMethod: "Zahlungsart bearbeiten",
	poNumber: "Bestellnummer",
	noPoNumber: "Keine",
	editPoNumber: "Bestellnummer bearbeiten",
	costCenter: "Kostenstelle",
	editCostCenter: "Kostenstelle bearbeiten",
	termsAndConditions: "Allgemeine Geschäftsbedingungen",
	closeTermsAndConditionsAlert: "Warnung schließen",
	itemsToBeShipped: "Zu versendende Positionen",
	proceedPayment: "Bestellung erteilen",
	defaultPaymentInfoMessage: "Sie snd dabei, eine Zahlung vorzunehmen. Abhängig von der ausgewählten Option werden Sie entweder auf eine sichere externe Seite weitergeleitet oder schließen den Vorgang direkt auf dieser Seite ab.",
	proceedPaymentButtonLabel: "Bestellung aufgeben, öffnet externe Seite",
	retryPayment: "Noch einmal versuchen, um fortzufahren",
	checkTermsAndConditionsExplicit: "Sie müssen den allgemeinen Geschäftsbedingungen zustimmen, um die verfügbaren Zahlungsoptionen anzeigen zu können.",
	checkTermsAndConditionsImplicit: "Indem Sie die Bestellung abschicken, stimmen Sie unseren allgemeinen Geschäftsbedingungen zu.",
	errors: {
		loadActiveConfigurations: "Die Zahlungsoptionen können zurzeit nicht geladen werden. Bitte versuchen Sie es später erneut.",
		noActiveConfigurations: "Zurzeit sind keine Zahlungsoptionen verfügbar. Bitte versuchen Sie es später erneut, oder wenden Sie sich an den Support.",
		updateBillingAddress: "Die Adresse konnte nicht aktualisiert werden. Prüfen Sie, ob die Adressinformationen korrekt sind und Ihr Gerät mit dem Internet verbunden ist. Wenn das Problem weiterhin auftritt, müssen Sie möglicherweise Ihren Warenkorb löschen und erneut zur Kasse gehen. "
	}
};
var opfCheckout$v = {
	opfCheckout: opfCheckout$u
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const de = {
    opfCheckout: opfCheckout$v,
};

var opfCheckout$s = {
	tabs: {
		paymentType: "Method of payment",
		shipping: "Shipping Address",
		deliveryMethod: "Delivery Method",
		paymentAndReview: "Payment & Review",
		review: "Review Order"
	},
	paymentAndReviewTitle: "Payment and review",
	billingAddress: "Billing Address",
	paymentOption: "Payment option",
	paymentMethod: "Payment method",
	noPaymentMethod: "No payment method selected",
	editCardDefaultLabel: "Edit",
	editPaymentMethod: "Edit payment method",
	poNumber: "Purchase Order Number",
	noPoNumber: "None",
	editPoNumber: "Edit purchase order number",
	costCenter: "Cost Center",
	editCostCenter: "Edit Cost Center",
	termsAndConditions: "Terms & Conditions",
	closeTermsAndConditionsAlert: "Close alert",
	itemsToBeShipped: "Items to be shipped",
	proceedPayment: "Place Order",
	defaultPaymentInfoMessage: "You are about to make a payment. Depending on the option selected, you will either be redirected to a secure external page or complete the process directly within this page",
	proceedPaymentButtonLabel: "Place Order, opens external page",
	retryPayment: "Retry to Continue",
	checkTermsAndConditionsExplicit: "You must agree Terms & Conditions to see available payment options.",
	checkTermsAndConditionsImplicit: "By submitting the order, you are agreeing to our Terms & Conditions.",
	termsAndConditionsDisclaimer: "Terms and conditions are not accepted.",
	savedPaymentHeading: "Saved Payment Options",
	newPaymentHeading: "New Payment Options",
	cards: "Cards",
	errors: {
		loadActiveConfigurations: "We are unable to load payment options at this time. Please try again later.",
		noActiveConfigurations: "There are no payment options available at this time. Please try again later or contact support.",
		updateBillingAddress: "The address could not be updated. Please check that the address information is correct and that your device is connected to the internet. If the problem persists, you may need to clear your cart and start the checkout again.",
		noBillingAddress: "Billing address is required"
	}
};
var opfCheckout$t = {
	opfCheckout: opfCheckout$s
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const en = {
    opfCheckout: opfCheckout$t,
};

var opfCheckout$q = {
	tabs: {
		paymentType: "Método de pago",
		shipping: "Dirección de envío",
		deliveryMethod: "Método de entrega",
		paymentAndReview: "Pago y revisión",
		review: "Revisar pedido"
	},
	paymentAndReviewTitle: "Pago y revisión",
	billingAddress: "Dirección de facturación",
	paymentOption: "Opción de pago",
	paymentMethod: "Método de pago",
	noPaymentMethod: "No hay métodos de pago seleccionados",
	editCardDefaultLabel: "Tratar",
	editPaymentMethod: "Editar método de pago",
	poNumber: "Número de pedido de compra",
	noPoNumber: "Ninguno",
	editPoNumber: "Tratar número de pedido de compra",
	costCenter: "Centro de costes",
	editCostCenter: "Tratar centro de costes",
	termsAndConditions: "Términos y condiciones",
	closeTermsAndConditionsAlert: "Alerta de cierre",
	itemsToBeShipped: "Artículos para enviar",
	proceedPayment: "Realizar pedido",
	defaultPaymentInfoMessage: "Está por realizar un pago. Según la opción seleccionada, será redirigido a una página externa segura o deberá completar el proceso directamente dentro de esta página",
	proceedPaymentButtonLabel: "Realizar el pedido abre la página externa",
	retryPayment: "Reintentar para continuar",
	checkTermsAndConditionsExplicit: "Debe aceptar los Términos y Condiciones para ver las opciones de pago disponibles.",
	checkTermsAndConditionsImplicit: "Al enviar el pedido, acepta nuestros Términos y Condiciones.",
	errors: {
		loadActiveConfigurations: "No podemos cargar las opciones de pago en este momento. Inténtelo de nuevo más tarde.",
		noActiveConfigurations: "No hay opciones de pago disponibles en este momento. Vuelva a intentarlo más tarde o póngase en contacto con soporte técnico.",
		updateBillingAddress: "No se ha podido actualizar la dirección. Verifique que la información de la dirección es correcta y que su dispositivo está conectado a Internet. Si el problema persiste, es posible que tenga que vaciar el carrito y volver a iniciar el proceso de pago."
	}
};
var opfCheckout$r = {
	opfCheckout: opfCheckout$q
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const es = {
    opfCheckout: opfCheckout$r,
};

var opfCheckout$o = {
	tabs: {
		paymentType: "Método de pago",
		shipping: "Dirección de envío",
		deliveryMethod: "Método de entrega",
		paymentAndReview: "Pago y revisión",
		review: "Revisar pedido"
	},
	paymentAndReviewTitle: "Pago y revisión",
	billingAddress: "Dirección de facturación",
	paymentOption: "Opción de pago",
	paymentMethod: "Método de pago",
	noPaymentMethod: "No hay métodos de pago seleccionados",
	editCardDefaultLabel: "Editar",
	editPaymentMethod: "Editar método de pago",
	poNumber: "Número de pedido de compra",
	noPoNumber: "Ninguno",
	editPoNumber: "Editar número de pedido de compra",
	costCenter: "Centro de costos",
	editCostCenter: "Editar centro de costos",
	termsAndConditions: "Términos y condiciones",
	closeTermsAndConditionsAlert: "Alerta de cierre",
	itemsToBeShipped: "Artículos para enviar",
	proceedPayment: "Realizar pedido",
	defaultPaymentInfoMessage: "Está por realizar un pago. Según la opción seleccionada, será redirigido a una página externa segura o deberá completar el proceso directamente dentro de esta página",
	proceedPaymentButtonLabel: "Realizar el pedido abre la página externa",
	retryPayment: "Reintentar para continuar",
	checkTermsAndConditionsExplicit: "Debe aceptar los Términos y Condiciones para ver las opciones de pago disponibles.",
	checkTermsAndConditionsImplicit: "Al enviar el pedido, acepta nuestros Términos y Condiciones.",
	errors: {
		loadActiveConfigurations: "No podemos cargar las opciones de pago en este momento. Inténtelo de nuevo más tarde.",
		noActiveConfigurations: "No hay opciones de pago disponibles en este momento. Vuelva a intentarlo más tarde o póngase en contacto con soporte técnico.",
		updateBillingAddress: "No se ha podido actualizar la dirección. Verifique que la información de la dirección es correcta y que su dispositivo está conectado a Internet. Si el problema persiste, es posible que tenga que vaciar el carrito y volver a iniciar el proceso de pago."
	}
};
var opfCheckout$p = {
	opfCheckout: opfCheckout$o
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const es_CO = {
    opfCheckout: opfCheckout$p,
};

var opfCheckout$m = {
	tabs: {
		paymentType: "Mode de paiement",
		shipping: "Adresse d'expédition",
		deliveryMethod: "Mode de livraison",
		paymentAndReview: "Paiement et vérification",
		review: "Vérifier la commande"
	},
	paymentAndReviewTitle: "Paiement et vérification",
	billingAddress: "Adresse de facturation",
	paymentOption: "Option de paiement",
	paymentMethod: "Mode de paiement",
	noPaymentMethod: "Aucun mode de paiement sélectionné",
	editCardDefaultLabel: "Modifier",
	editPaymentMethod: "Modifier le mode de paiement",
	poNumber: "Numéro de commande d'achat",
	noPoNumber: "Aucun(e)",
	editPoNumber: "Modifier le numéro de commande d'achat",
	costCenter: "Centre de coûts",
	editCostCenter: "Modifier le centre de coûts",
	termsAndConditions: "Conditions générales",
	closeTermsAndConditionsAlert: "Fermer l'alerte",
	itemsToBeShipped: "Articles à expédier",
	proceedPayment: "Passer la commande",
	defaultPaymentInfoMessage: "Vous êtes sur le point de payer. Selon l'option sélectionnée, vous serez redirigé vers une page externe sécurisée ou vous effectuerez le processus directement sur cette page.",
	proceedPaymentButtonLabel: "Passer une commande ouvre une page externe",
	retryPayment: "Réessayer pour continuer",
	checkTermsAndConditionsExplicit: "Vous devez accepter les conditions générales pour voir les options de paiement disponibles.",
	checkTermsAndConditionsImplicit: "En soumettant la commande, vous acceptez nos conditions générales.",
	errors: {
		loadActiveConfigurations: "Nous ne sommes pas en mesure de charger les options de paiement pour le moment. Veuillez réessayer ultérieurement.",
		noActiveConfigurations: "Il n'y a pas d'options de paiement disponibles pour le moment. Veuillez réessayer ultérieurement ou contacter l'assistance.",
		updateBillingAddress: "L'adresse n'a pas pu être mise à jour. Veuillez vérifier que les informations relatives à l'adresse sont correctes et que votre appareil est connecté à Internet. Si le problème persiste, il se peut que vous deviez vider votre panier et recommencer la validation de la commande."
	}
};
var opfCheckout$n = {
	opfCheckout: opfCheckout$m
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const fr = {
    opfCheckout: opfCheckout$n,
};

var opfCheckout$k = {
	tabs: {
		paymentType: "भुगतान की विधि",
		shipping: "शिपिंग पता",
		deliveryMethod: "वितरण विधि",
		paymentAndReview: "भुगतान और समीक्षा",
		review: "ऑर्डर की समीक्षा करें"
	},
	paymentAndReviewTitle: "भुगतान और समीक्षा",
	billingAddress: "बिलिंग पता",
	paymentOption: "भुगतान विकल्प",
	paymentMethod: "भुगतान विधि",
	noPaymentMethod: "कोई भुगतान विधि चयनित नहीं है",
	editCardDefaultLabel: "संपादित करें",
	editPaymentMethod: "भुगतान विधि संपादित करें",
	poNumber: "क्रय ऑर्डर संख्या",
	noPoNumber: "कोई नहीं",
	editPoNumber: "क्रय ऑर्डर संख्या संपादित करें",
	costCenter: "लागत केंद्र",
	editCostCenter: "लागत केंद्र संपादित करें",
	termsAndConditions: "नियम और शर्तें",
	closeTermsAndConditionsAlert: "अलर्ट बंद करें",
	itemsToBeShipped: "शिप किए जाने वाले आइटम",
	proceedPayment: "ऑर्डर दें",
	defaultPaymentInfoMessage: "आप भुगतान करने वाले हैं. चयनित विकल्प के आधार पर, आपको या तो सुरक्षित बाहरी पृष्ठ पर पुनर्निर्देशित किया जाएगा या इस पृष्ठ के अंतर्गत प्रत्यक्ष रूप से प्रक्रिया पूर्ण करें",
	proceedPaymentButtonLabel: "ऑर्डर दें, बाहरी पृष्ठ खोलें",
	retryPayment: "जारी रखने के लिए फिर से कोशिश करें",
	checkTermsAndConditionsExplicit: "उपलब्ध भुगतान विकल्प देखने के लिए आपको नियम और शर्तों पर सहमत होना होगा.",
	checkTermsAndConditionsImplicit: "ऑर्डर सबमिट करके, आप हमारे नियम और शर्तों पर सहमत हैं.",
	errors: {
		loadActiveConfigurations: "इस समय हम भुगतान विकल्प लोड करने में असमर्थ हैं. कृपया बाद में फिर को कोशिश करें.",
		noActiveConfigurations: "इस समय कोई भुगतान विकल्प उपलब्ध नहीं हैं. कृपया बाद में फिर को कोशिश करें या सहायता से संपर्क करें.",
		updateBillingAddress: "पता अपडेट नहीं किया जा सका. कृपया जांचें कि पता जानकारी सही है और आपका उपकरण इंटरनेट से जुड़ा हुआ है. यदि समस्या रहती है, आपको अपनी कार्ट साफ करने की और फिर से चेकआउट प्रारंभ करने की आवश्यकता है."
	}
};
var opfCheckout$l = {
	opfCheckout: opfCheckout$k
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const hi = {
    opfCheckout: opfCheckout$l,
};

var opfCheckout$i = {
	tabs: {
		paymentType: "Fizetési mód",
		shipping: "Szállítási cím",
		deliveryMethod: "Kézbesítési mód",
		paymentAndReview: "Fizetés és ellenőrzés",
		review: "Rendelés áttekintése"
	},
	paymentAndReviewTitle: "Fizetés és ellenőrzés",
	billingAddress: "Számlázási cím",
	paymentOption: "Fizetési lehetőség",
	paymentMethod: "Fizetési mód",
	noPaymentMethod: "Nincs kiválasztva fizetési mód",
	editCardDefaultLabel: "Szerkesztés",
	editPaymentMethod: "Fizetési mód szerkesztése",
	poNumber: "Megrendelés száma",
	noPoNumber: "Nincs",
	editPoNumber: "Megrendelés számának szerkesztése",
	costCenter: "Költséghely",
	editCostCenter: "Költséghely szerkesztése",
	termsAndConditions: "Használati feltételek",
	closeTermsAndConditionsAlert: "Riasztás bezárása",
	itemsToBeShipped: "Szállítandó tételek",
	proceedPayment: "Rendelés leadása",
	defaultPaymentInfoMessage: "Egy fizetés végrehajtására készül. A kiválasztott beállítástól függően átirányítjuk egy biztonságos külső oldalra, vagy közvetlenül ezen az oldalon fejezheti be a folyamatot.",
	proceedPaymentButtonLabel: "Rendelés leadása, külső oldal megnyitása",
	retryPayment: "A folytatáshoz próbálja újra",
	checkTermsAndConditionsExplicit: "A rendelkezésre álló fizetési lehetőségek megtekintéséhez el kell fogadnia a használati feltételeket",
	checkTermsAndConditionsImplicit: "A rendelés elküldésével elfogadja a használati feltételeinket.",
	errors: {
		loadActiveConfigurations: "Jelenleg nem tudjuk betölteni a fizetési lehetőségeket. Próbálja újra később.",
		noActiveConfigurations: "Jelenleg nincsenek rendelkezésre álló fizetési lehetőségek. Próbálja újra később, vagy vegye fel a kapcsolatot a támogatással.",
		updateBillingAddress: "Nem sikerült frissíteni a címet. Ellenőrizze, hogy a címadatok helyesek-e és hogy az eszköze csatlakozik-e az internethez. Ha a probléma továbbra is fennáll, előfordulhat, hogy ki kell ürítenie a kosarát, és újra kell indítania a fizetési folyamatot."
	}
};
var opfCheckout$j = {
	opfCheckout: opfCheckout$i
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const hu = {
    opfCheckout: opfCheckout$j,
};

var opfCheckout$g = {
	tabs: {
		paymentType: "Metode pembayaran",
		shipping: "Alamat Pengiriman",
		deliveryMethod: "Metode Pengiriman",
		paymentAndReview: "Pembayaran & Peninjauan",
		review: "Tinjau Pesanan"
	},
	paymentAndReviewTitle: "Pembayaran dan peninjauan",
	billingAddress: "Alamat Penagihan",
	paymentOption: "Opsi pembayaran",
	paymentMethod: "Metode pembayaran",
	noPaymentMethod: "Tidak ada metode pembayaran yang dipilih",
	editCardDefaultLabel: "Edit",
	editPaymentMethod: "Edit metode pembayaran",
	poNumber: "Nomor Pesanan Pembelian",
	noPoNumber: "Tidak Ada",
	editPoNumber: "Edit nomor pesanan pembelian",
	costCenter: "Pusat Biaya",
	editCostCenter: "Edit Pusat Biaya",
	termsAndConditions: "Syarat & Ketentuan",
	closeTermsAndConditionsAlert: "Tutup peringatan",
	itemsToBeShipped: "Item yang akan dikirim",
	proceedPayment: "Lakukan Pemesanan",
	defaultPaymentInfoMessage: "Anda akan melakukan pembayaran. Bergantung pada opsi yang dipilih, Anda akan diarahkan ke halaman eksternal yang aman atau diminta melengkapi proses melalui halaman ini secara langsung",
	proceedPaymentButtonLabel: "Buat Pesanan, membuka halaman eksternal",
	retryPayment: "Coba Lagi untuk Melanjutkan",
	checkTermsAndConditionsExplicit: "Anda harus menyetujui Syarat & Ketentuan untuk melihat opsi pembayaran yang tersedia.",
	checkTermsAndConditionsImplicit: "Dengan menyelesaikan pemesanan, Anda menyetujui Syarat & Ketentuan kami.",
	errors: {
		loadActiveConfigurations: "Saat ini kami tidak dapat memuat opsi pembayaran. Silakan coba lagi nanti.",
		noActiveConfigurations: "Saat ini tidak ada opsi pembayaran yang tersedia. Silakan coba lagi nanti atau hubungi bagian dukungan.",
		updateBillingAddress: "Alamat tidak dapat diperbarui. Silakan pastikan bahwa informasi alamat Anda sudah benar dan perangkat Anda terhubung ke internet. Jika masalah berlanjut, Anda mungkin perlu mengosongkan keranjang belanja dan memulai proses pembayaran lagi."
	}
};
var opfCheckout$h = {
	opfCheckout: opfCheckout$g
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const id = {
    opfCheckout: opfCheckout$h,
};

var opfCheckout$e = {
	tabs: {
		paymentType: "Metodo di pagamento",
		shipping: "Indirizzo di spedizione",
		deliveryMethod: "Metodo di consegna",
		paymentAndReview: "Pagamento e recensione",
		review: "Rivedi l'ordine"
	},
	paymentAndReviewTitle: "Pagamento e recensione",
	billingAddress: "Indirizzo di fatturazione",
	paymentOption: "Opzioni di pagamento",
	paymentMethod: "Metodo di pagamento",
	noPaymentMethod: "Nessun metodo di pagamento selezionato",
	editCardDefaultLabel: "Modifica",
	editPaymentMethod: "Modifica metodo di pagamento",
	poNumber: "Numero ordine acquisto",
	noPoNumber: "Nessuno",
	editPoNumber: "Modifica numero ordine acquisto",
	costCenter: "Centro di costo",
	editCostCenter: "Modifica centro di costo",
	termsAndConditions: "Termini e condizioni",
	closeTermsAndConditionsAlert: "Chiudi avviso",
	itemsToBeShipped: "Articoli da spedire",
	proceedPayment: "Effettua l'ordine",
	defaultPaymentInfoMessage: "Si sta per effettuare un pagamento. A seconda dell'opzione selezionata, si verrà reindirizzati a una pagina esterna sicura o si completerà il processo direttamente all'interno di questa pagina",
	proceedPaymentButtonLabel: "Effettua l'ordine, apre una pagina esterna",
	retryPayment: "Riprova per continuare",
	checkTermsAndConditionsExplicit: "Per visualizzare le opzioni di pagamento è necessario accettare i Termini e Condizioni.",
	checkTermsAndConditionsImplicit: "Con l'invio dell'ordine si accettano i nostri Termini e Condizioni",
	errors: {
		loadActiveConfigurations: "Al momento non è possibile caricare le opzioni di pagamento. Riprovare più tardi.",
		noActiveConfigurations: "Al momento non sono disponibili opzioni di pagamento. Riprovare più tardi o contattare il supporto.",
		updateBillingAddress: "Non è stato possibile aggiornare l'indirizzo. Verificare che le informazioni di indirizzo siano corrette e che il dispositivo sia connesso a Internet. Se il problema persiste, potrebbe essere necessario svuotare il carrello e iniziare nuovamente il check-out."
	}
};
var opfCheckout$f = {
	opfCheckout: opfCheckout$e
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const it = {
    opfCheckout: opfCheckout$f,
};

var opfCheckout$c = {
	tabs: {
		paymentType: "支払の方法",
		shipping: "配送先住所",
		deliveryMethod: "配送方法",
		paymentAndReview: "支払およびレビュー",
		review: "注文のレビュー"
	},
	paymentAndReviewTitle: "支払およびレビュー",
	billingAddress: "請求先住所",
	paymentOption: "支払オプション",
	paymentMethod: "支払方法",
	noPaymentMethod: "選択済みの支払方法がありません",
	editCardDefaultLabel: "編集",
	editPaymentMethod: "支払方法の編集",
	poNumber: "発注書番号",
	noPoNumber: "なし",
	editPoNumber: "発注書番号の編集",
	costCenter: "原価センタ",
	editCostCenter: "原価センタの編集",
	termsAndConditions: "利用条件",
	closeTermsAndConditionsAlert: "アラートを閉じる",
	itemsToBeShipped: "配送対象アイテム",
	proceedPayment: "ご注文",
	defaultPaymentInfoMessage: "支払を実行しようとしています。選択されたオプションに応じて、セキュアな外部ページにリダイレクトされるか、またはこのページ内で直接処理を完了するかのどちらかになります",
	proceedPaymentButtonLabel: "注文を行うと、外部ページが開きます",
	retryPayment: "再試行して続行",
	checkTermsAndConditionsExplicit: "利用可能な支払オプションを表示するには、利用条件に同意する必要があります。",
	checkTermsAndConditionsImplicit: "注文を送信することで、利用条件に同意したことになります。",
	errors: {
		loadActiveConfigurations: "現時点では支払オプションをロードできません。後でもう一度実行してください。",
		noActiveConfigurations: "現在点では利用可能な支払オプションがありません。後でもう一度実行するか、サポートに連絡してください。",
		updateBillingAddress: "アドレスを更新できませんでした。住所情報が正しく、デバイスがインターネットに接続されていることを確認してください。問題が解決しない場合は、カートをクリアしてチェックアウトをもう一度開始する必要がある可能性があります。"
	}
};
var opfCheckout$d = {
	opfCheckout: opfCheckout$c
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ja = {
    opfCheckout: opfCheckout$d,
};

var opfCheckout$a = {
	tabs: {
		paymentType: "지불 방법",
		shipping: "배송 주소",
		deliveryMethod: "배송 방법",
		paymentAndReview: "지불 및 검토",
		review: "주문 검토"
	},
	paymentAndReviewTitle: "지불 및 검토",
	billingAddress: "청구 주소",
	paymentOption: "지불 옵션",
	paymentMethod: "지불 방법",
	noPaymentMethod: "지불 방법이 선택되지 않음",
	editCardDefaultLabel: "편집",
	editPaymentMethod: "지불 방법 편집",
	poNumber: "구매 오더 번호",
	noPoNumber: "없음",
	editPoNumber: "구매 오더 번호 편집",
	costCenter: "코스트 센터",
	editCostCenter: "코스트 센터 편집",
	termsAndConditions: "사용 약관",
	closeTermsAndConditionsAlert: "경고 종료",
	itemsToBeShipped: "배송할 품목",
	proceedPayment: "주문",
	defaultPaymentInfoMessage: "결제하려고 합니다. 선택하신 옵션에 따라 보안 외부 페이지로 이동하거나 이 페이지에서 직접 결제를 완료하게 됩니다.",
	proceedPaymentButtonLabel: "주문, 외부 페이지가 열림",
	retryPayment: "계속하기 위해 재시도",
	checkTermsAndConditionsExplicit: "사용할 수 있는 지불 옵션을 보려면 사용 약관에 동의해야 합니다.",
	checkTermsAndConditionsImplicit: "주문서를 제출하면 사용 약관에 동의하는 것입니다.",
	errors: {
		loadActiveConfigurations: "현재 지불 옵션을 로드할 수 없습니다. 나중에 다시 시도하십시오.",
		noActiveConfigurations: "현재 사용할 수 있는 지불 옵션이 없습니다. 나중에 다시 시도하거나 지원팀에 문의하십시오.",
		updateBillingAddress: "주소를 업데이트할 수 없습니다. 주소 정보가 올바르고 장치가 인터넷에 연결되어 있는지 확인하십시오. 문제가 계속되면 장바구니를 지우고 다시 체크아웃을 시작해야 할 수 있습니다."
	}
};
var opfCheckout$b = {
	opfCheckout: opfCheckout$a
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ko = {
    opfCheckout: opfCheckout$b,
};

var opfCheckout$8 = {
	tabs: {
		paymentType: "Forma płatności",
		shipping: "Adres wysyłki",
		deliveryMethod: "Metoda dostawy",
		paymentAndReview: "Płatność i przegląd",
		review: "Przejrzyj zamówienie"
	},
	paymentAndReviewTitle: "Płatność i przegląd",
	billingAddress: "Adres na fakturze",
	paymentOption: "Opcja płatności",
	paymentMethod: "Forma płatności",
	noPaymentMethod: "Nie wybrano formy płatności",
	editCardDefaultLabel: "Edytuj",
	editPaymentMethod: "Edytuj formę płatności",
	poNumber: "Numer zamówienia",
	noPoNumber: "Brak",
	editPoNumber: "Edytuj numer zamówienia",
	costCenter: "Miejsce powstawania kosztów",
	editCostCenter: "Edytuj miejsce powstawania kosztów",
	termsAndConditions: "Warunki",
	closeTermsAndConditionsAlert: "Zamknij alert",
	itemsToBeShipped: "Pozycje do wysłania",
	proceedPayment: "Złóż zamówienie",
	defaultPaymentInfoMessage: "Przechodzisz do płatności. W zależności od wyboru, system przekieruje Cię na bezpieczną stronę zewnętrzną lub umożliwi zakończenie transakcji na tej stronie",
	proceedPaymentButtonLabel: "Przejdź do zamówienia – otwiera się strona zewnętrzna",
	retryPayment: "Ponów próbę, aby kontynuować",
	checkTermsAndConditionsExplicit: "Musisz zaakceptować Warunki, aby zobaczyć dostępne opcje płatności.",
	checkTermsAndConditionsImplicit: "Złożenie zamówienia jest równoznaczne z akceptacją naszych Warunków.",
	errors: {
		loadActiveConfigurations: "W tej chwili nie możemy załadować opcji płatności. Spróbuj ponownie później.",
		noActiveConfigurations: "Obecnie żadne opcje płatności nie są dostępne. Spróbuj ponownie później lub skontaktuj się z działem pomocy.",
		updateBillingAddress: "Nie można zaktualizować adresu. Sprawdź, czy dane adresowe są prawidłowe i czy urządzenie jest połączone z Internetem. Jeśli problem nadal występuje, może być konieczne wyczyszczenie koszyka i ponowne rozpoczęcie realizacji zakupu."
	}
};
var opfCheckout$9 = {
	opfCheckout: opfCheckout$8
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const pl = {
    opfCheckout: opfCheckout$9,
};

var opfCheckout$6 = {
	tabs: {
		paymentType: "Forma de pagamento",
		shipping: "Endereço de entrega",
		deliveryMethod: "Método de entrega",
		paymentAndReview: "Pagamento e revisão",
		review: "Revisar pedido"
	},
	paymentAndReviewTitle: "Pagamento e revisão",
	billingAddress: "Endereço de faturamento",
	paymentOption: "Opção de pagamento",
	paymentMethod: "Forma de pagamento",
	noPaymentMethod: "Nenhuma forma de pagamento selecionada",
	editCardDefaultLabel: "Editar",
	editPaymentMethod: "Editar forma de pagamento",
	poNumber: "Número do pedido",
	noPoNumber: "Nenhum",
	editPoNumber: "Editar número do pedido",
	costCenter: "Centro de custo",
	editCostCenter: "Editar centro de custo",
	termsAndConditions: "Termos e Condições",
	closeTermsAndConditionsAlert: "Fechar alerta",
	itemsToBeShipped: "Itens a serem enviados",
	proceedPayment: "Fazer pedido",
	defaultPaymentInfoMessage: "Você está prestes a efetuar um pagamento. Em função da opção selecionada, você será redirecionado para uma página externa segura ou concluir o processo diretamente nessa página",
	proceedPaymentButtonLabel: "Fazer pedido, abre página externa",
	retryPayment: "Tentar novamente para continuar",
	checkTermsAndConditionsExplicit: "Você deve concordar com os Termos e Condições para ver as opções de pagamento disponíveis.",
	checkTermsAndConditionsImplicit: "Ao enviar o pedido, você está concordando com nossos Termos e Condições.",
	errors: {
		loadActiveConfigurations: "No momento, não é possível carregar as opções de pagamento. Tente novamente mais tarde.",
		noActiveConfigurations: "Não existem opções de pagamento disponíveis no momento. Tente novamente mais tarde ou contate o suporte.",
		updateBillingAddress: "Não foi possível atualizar o endereço. Verifique se as informações de endereço estão corretas e se seu dispositivo está conectado à Internet. Se o problema persistir, poderá ser necessário limpar o carrinho e iniciar o check-out novamente."
	}
};
var opfCheckout$7 = {
	opfCheckout: opfCheckout$6
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const pt = {
    opfCheckout: opfCheckout$7,
};

var opfCheckout$4 = {
	tabs: {
		paymentType: "Метод оплаты",
		shipping: "Адрес доставки",
		deliveryMethod: "Метод доставки",
		paymentAndReview: "Оплата и проверка",
		review: "Проверить заказ"
	},
	paymentAndReviewTitle: "Оплата и проверка",
	billingAddress: "Адрес выставления счета",
	paymentOption: "Опция оплаты",
	paymentMethod: "Метод оплаты",
	noPaymentMethod: "Метод оплаты не выбран",
	editCardDefaultLabel: "Редактировать",
	editPaymentMethod: "Редактировать метод оплаты",
	poNumber: "Номер заказа на покупку",
	noPoNumber: "Нет",
	editPoNumber: "Редактировать номер заказа на покупку",
	costCenter: "МВЗ",
	editCostCenter: "Редактировать МВЗ",
	termsAndConditions: "Условия",
	closeTermsAndConditionsAlert: "Закрыть предупреждение",
	itemsToBeShipped: "Позиции для доставки",
	proceedPayment: "Разместить заказ",
	defaultPaymentInfoMessage: "Будет выполнена оплата. В зависимости от выбранных опций вы будете перенаправлены на безопасную внешнюю страницу или выполните оплату на этой странице.",
	proceedPaymentButtonLabel: "Разместить заказ, открывается внешняя страница",
	retryPayment: "Повторить попытку, чтобы продолжить",
	checkTermsAndConditionsExplicit: "Вы должны выразить согласие с условиями, чтобы увидеть опции оплаты.",
	checkTermsAndConditionsImplicit: "Отправляя заказ, вы соглашаетесь с условиями.",
	errors: {
		loadActiveConfigurations: "Не удалось загрузить опции оплаты. Повторите попытку позже.",
		noActiveConfigurations: "Опции оплаты сейчас недоступны. Повторите попытку позже или обратитесь в службу поддержки.",
		updateBillingAddress: "Не удалось обновить адрес. Проверьте правильность информации об адресе и подключение вашего устройства к интернету. Если проблема сохраняется, возможно, вам придется очистить корзину и начать оформление заказа заново."
	}
};
var opfCheckout$5 = {
	opfCheckout: opfCheckout$4
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ru = {
    opfCheckout: opfCheckout$5,
};

var opfCheckout$2 = {
	tabs: {
		paymentType: "付款方式",
		shipping: "发货地址",
		deliveryMethod: "送货方式",
		paymentAndReview: "付款和检查",
		review: "评价订单"
	},
	paymentAndReviewTitle: "付款和检查",
	billingAddress: "账单地址",
	paymentOption: "付款选项",
	paymentMethod: "付款方式",
	noPaymentMethod: "未选择付款方式",
	editCardDefaultLabel: "编辑",
	editPaymentMethod: "编辑付款方式",
	poNumber: "订购单编号",
	noPoNumber: "无",
	editPoNumber: "编辑订购单编号",
	costCenter: "成本中心",
	editCostCenter: "编辑成本中心",
	termsAndConditions: "条款和条件",
	closeTermsAndConditionsAlert: "关闭警报",
	itemsToBeShipped: "待发货商品",
	proceedPayment: "下达订单",
	defaultPaymentInfoMessage: "即将进行支付。根据所选选项，您将可能定向到安全的外部页面，也可能直接在此页面中完成流程",
	proceedPaymentButtonLabel: "下单并打开外部页面",
	retryPayment: "重试以继续",
	checkTermsAndConditionsExplicit: "必须同意“条款和条件”才能查看可用付款选项。",
	checkTermsAndConditionsImplicit: "提交订单即表示您同意我们的“条款和条件”。",
	errors: {
		loadActiveConfigurations: "我们此时无法加载付款选项。请稍后重试。",
		noActiveConfigurations: "此时没有可用的付款选项。请稍后重试或联系支持部门。",
		updateBillingAddress: "无法更新地址。请检查地址信息是否正确，以及设备是否连接到互联网。如果问题仍存在，您可能需要清空购物车并重新开始结账。"
	}
};
var opfCheckout$3 = {
	opfCheckout: opfCheckout$2
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const zh = {
    opfCheckout: opfCheckout$3,
};

var opfCheckout = {
	tabs: {
		paymentType: "付款方法",
		shipping: "出貨地址",
		deliveryMethod: "交貨方法",
		paymentAndReview: "付款和審查",
		review: "評論訂單"
	},
	paymentAndReviewTitle: "付款和審查",
	billingAddress: "帳單寄送地址",
	paymentOption: "付款選項",
	paymentMethod: "付款方法",
	noPaymentMethod: "未選擇付款方法",
	editCardDefaultLabel: "編輯",
	editPaymentMethod: "編輯付款方法",
	poNumber: "採購單號碼",
	noPoNumber: "無",
	editPoNumber: "編輯採購單號碼",
	costCenter: "成本中心",
	editCostCenter: "編輯成本中心",
	termsAndConditions: "條款和條件",
	closeTermsAndConditionsAlert: "關閉警示",
	itemsToBeShipped: "待運送項目",
	proceedPayment: "下單",
	defaultPaymentInfoMessage: "您即將進行付款。系統根據所選選項而定，將您重新導向至安全的外部頁面，或直接在此頁面中完成流程",
	proceedPaymentButtonLabel: "下單，開啟外部頁面",
	retryPayment: "重試以繼續",
	checkTermsAndConditionsExplicit: "您必須同意條款和條件，才能查看可用付款選項。",
	checkTermsAndConditionsImplicit: "提交訂單後，您即同意我們的條款和條件。",
	errors: {
		loadActiveConfigurations: "系統目前無法載入付款選項，請稍後再試一次。",
		noActiveConfigurations: "目前沒有付款選項。請稍後再試一次或聯絡支援團隊。",
		updateBillingAddress: "無法更新地址。請檢查弟子資訊正確，且您的裝置已連線至網路。若問題仍存在，則必須清除購物車接著再次開始結帳。"
	}
};
var opfCheckout$1 = {
	opfCheckout: opfCheckout
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const zh_TW = {
    opfCheckout: opfCheckout$1,
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const opfCheckoutTranslationChunksConfig = {
    opfCheckout: ['opfCheckout'],
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { opfCheckoutTranslationChunksConfig, cs as opfCheckoutTranslationsCs, de as opfCheckoutTranslationsDe, en as opfCheckoutTranslationsEn, es as opfCheckoutTranslationsEs, es_CO as opfCheckoutTranslationsEs_CO, fr as opfCheckoutTranslationsFr, hi as opfCheckoutTranslationsHi, hu as opfCheckoutTranslationsHu, id as opfCheckoutTranslationsId, it as opfCheckoutTranslationsIt, ja as opfCheckoutTranslationsJa, ko as opfCheckoutTranslationsKo, pl as opfCheckoutTranslationsPl, pt as opfCheckoutTranslationsPt, ru as opfCheckoutTranslationsRu, zh as opfCheckoutTranslationsZh, zh_TW as opfCheckoutTranslationsZh_TW };
//# sourceMappingURL=spartacus-opf-checkout-assets.mjs.map
