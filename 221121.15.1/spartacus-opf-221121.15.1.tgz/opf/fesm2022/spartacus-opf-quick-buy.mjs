import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { OpfQuickBuyComponentsModule } from '@spartacus/opf/quick-buy/components';
import { OpfQuickBuyCoreModule } from '@spartacus/opf/quick-buy/core';
import { OpfApiQuickBuyModule } from '@spartacus/opf/quick-buy/opf-api';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyModule, imports: [OpfQuickBuyComponentsModule,
            OpfQuickBuyCoreModule,
            OpfApiQuickBuyModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyModule, imports: [OpfQuickBuyComponentsModule,
            OpfQuickBuyCoreModule,
            OpfApiQuickBuyModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        OpfQuickBuyComponentsModule,
                        OpfQuickBuyCoreModule,
                        OpfApiQuickBuyModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfQuickBuyModule };
//# sourceMappingURL=spartacus-opf-quick-buy.mjs.map
