import * as i0 from '@angular/core';
import { Injectable, NgModule } from '@angular/core';
import { ORDER_NORMALIZER } from '@spartacus/order/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfOccOrderNormalizer {
    convert(source, target) {
        if (target === undefined) {
            target = { ...source };
        }
        if (source.sapBillingAddress && !target.paymentInfo?.billingAddress) {
            target.paymentInfo = {
                ...target.paymentInfo,
                billingAddress: source.sapBillingAddress,
            };
        }
        return target;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfOccOrderNormalizer, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfOccOrderNormalizer, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfOccOrderNormalizer, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfOrderModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfOrderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfOrderModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfOrderModule, providers: [
            {
                provide: ORDER_NORMALIZER,
                useExisting: OpfOccOrderNormalizer,
                multi: true,
            },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfOrderModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        {
                            provide: ORDER_NORMALIZER,
                            useExisting: OpfOccOrderNormalizer,
                            multi: true,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfOccOrderNormalizer, OpfOrderModule };
//# sourceMappingURL=spartacus-opf-order.mjs.map
