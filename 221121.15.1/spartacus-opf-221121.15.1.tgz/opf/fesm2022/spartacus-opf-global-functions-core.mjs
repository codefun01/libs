import * as i0 from '@angular/core';
import { inject, NgZone, Injectable, NgModule } from '@angular/core';
import { WindowRef, UserIdService, RoutingService, provideDefaultConfig } from '@spartacus/core';
import { OpfGlobalFunctionsDomain, OpfGlobalFunctionsFacade } from '@spartacus/opf/global-functions/root';
import { ActiveCartFacade, CartAccessCodeFacade, MultiCartFacade } from '@spartacus/cart/base/root';
import { OpfMetadataStoreService, defaultOpfErrorDialogOptions, OpfPage } from '@spartacus/opf/base/root';
import { getBrowserInfo } from '@spartacus/opf/payment/core';
import { OpfPaymentFacade, OpfPaymentChannel, OpfPaymentEventsService } from '@spartacus/opf/payment/root';
import { LaunchDialogService, LAUNCH_CALLER, DIALOG_TYPE, SpinnerComponent } from '@spartacus/storefront';
import { lastValueFrom, combineLatest, throwError } from 'rxjs';
import { last, finalize, take, switchMap, map, filter, retry, skip } from 'rxjs/operators';
import { OpfCtaFacade } from '@spartacus/opf/cta/root';
import { OpfQuickBuyTransactionService } from '@spartacus/opf/quick-buy/core';
import { OpfErrorModalComponent } from '@spartacus/opf/base/components';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGlobalFunctionsSharedService {
    constructor() {
        this.winRef = inject(WindowRef);
        this.ngZone = inject(NgZone);
        this.opfPaymentFacade = inject(OpfPaymentFacade);
        this.launchDialogService = inject(LaunchDialogService);
        this.opfMetadataStoreService = inject(OpfMetadataStoreService);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.userIdService = inject(UserIdService);
        this.cartAccessCodeFacade = inject(CartAccessCodeFacade);
    }
    static { this.PAYMENT_SESSION_ID_REQUIRED_ERROR = 'paymentSessionId is required'; }
    static { this.UPDATE_PAYMENT_TRANSACTION_RETRY_COUNT = 2; }
    static { this.UPDATE_PAYMENT_TRANSACTION_RETRY_DELAY = 300; }
    resolvePaymentSessionId(paymentSessionId) {
        return (paymentSessionId ??
            this.opfMetadataStoreService.opfMetadataState.value?.opfPaymentSessionId);
    }
    requirePaymentSessionId(paymentSessionId) {
        const finalPaymentSessionId = this.resolvePaymentSessionId(paymentSessionId);
        if (!finalPaymentSessionId) {
            throw new Error(OpfGlobalFunctionsSharedService.PAYMENT_SESSION_ID_REQUIRED_ERROR);
        }
        return finalPaymentSessionId;
    }
    submit(options, paymentSessionId, vcr) {
        return this.ngZone.run(() => {
            const finalPaymentSessionId = this.requirePaymentSessionId(options.paymentSessionId ?? paymentSessionId);
            let overlayedSpinner;
            if (vcr) {
                overlayedSpinner = this.startLoaderSpinner(vcr);
            }
            const { submitSuccess = () => {
                // this is intentional
            }, submitPending = () => {
                // this is intentional
            }, submitFailure = () => {
                // this is intentional
            }, submitCancel = () => {
                // this is intentional
            }, paymentMethod, savePaymentMethod, } = options;
            const callbacks = {
                onSuccess: submitSuccess,
                onPending: submitPending,
                onFailure: submitFailure,
                onCancel: submitCancel,
            };
            return lastValueFrom(this.opfPaymentFacade
                .submitPayment({
                additionalData: options.additionalData,
                paymentSessionId: finalPaymentSessionId,
                callbacks,
                paymentMethod,
                returnPath: undefined,
                savePaymentMethod,
            })
                .pipe(last(() => true, true), finalize(() => {
                if (overlayedSpinner) {
                    this.stopLoaderSpinner(overlayedSpinner);
                }
            })));
        });
    }
    submitComplete(options, paymentSessionId, vcr) {
        return this.ngZone.run(() => {
            const finalPaymentSessionId = this.requirePaymentSessionId(options.paymentSessionId ?? paymentSessionId);
            const { submitSuccess = () => {
                // this is intentional
            }, submitPending = () => {
                // this is intentional
            }, submitFailure = () => {
                // this is intentional
            }, submitCancel = () => {
                // this is intentional
            }, } = options;
            return this.runSubmitComplete(options.additionalData, {
                onSuccess: submitSuccess,
                onPending: submitPending,
                onFailure: submitFailure,
                onCancel: submitCancel,
            }, finalPaymentSessionId, undefined, vcr);
        });
    }
    runSubmitComplete(additionalData, callbacks, paymentSessionId, returnPath, vcr) {
        return this.ngZone.run(() => {
            let overlayedSpinner;
            if (vcr) {
                overlayedSpinner = this.startLoaderSpinner(vcr);
            }
            return lastValueFrom(this.opfPaymentFacade
                .submitCompletePayment({
                additionalData,
                paymentSessionId,
                callbacks,
                returnPath,
            })
                .pipe(finalize(() => {
                if (overlayedSpinner) {
                    this.stopLoaderSpinner(overlayedSpinner);
                }
            })));
        });
    }
    updatePaymentTransaction(updatePaymentConfig) {
        return this.ngZone.run(() => {
            return this.executeUpdatePaymentTransaction({
                ...updatePaymentConfig,
                paymentSessionId: updatePaymentConfig?.paymentSessionId ?? '',
            })
                .then((sessionData) => sessionData)
                .catch((error) => {
                throw this.createUpdatePaymentTransactionError(error);
            });
        });
    }
    startLoaderSpinner(vcr) {
        return this.launchDialogService.launch(LAUNCH_CALLER.PLACE_ORDER_SPINNER, vcr);
    }
    stopLoaderSpinner(overlayedSpinner) {
        if (!overlayedSpinner) {
            return;
        }
        overlayedSpinner
            .subscribe((component) => {
            this.launchDialogService.clear(LAUNCH_CALLER.PLACE_ORDER_SPINNER);
            if (component) {
                component.destroy();
            }
        })
            .unsubscribe();
    }
    executeUpdatePaymentTransaction(updatePaymentConfig) {
        const cartId$ = this.activeCartFacade.getActiveCartId().pipe(take(1));
        const userId$ = this.userIdService.getUserId().pipe(take(1));
        return lastValueFrom(combineLatest([userId$, cartId$]).pipe(switchMap(([userId, cartId]) => this.updatePaymentTransactionWithCart(userId, cartId, updatePaymentConfig))));
    }
    updatePaymentTransactionWithCart(userId, cartId, updatePaymentConfig) {
        if (!cartId) {
            return throwError(() => new Error('Cart ID is required. No active cart found.'));
        }
        return this.cartAccessCodeFacade.getCartAccessCode(userId, cartId).pipe(map((response) => this.extractOtpKey(response)), filter(Boolean), switchMap((otpKey) => this.buildAndUpdatePaymentConfig(updatePaymentConfig, otpKey)), take(1));
    }
    extractOtpKey(response) {
        return typeof response === 'string'
            ? response
            : (response?.accessCode ??
                response);
    }
    buildAndUpdatePaymentConfig(updatePaymentConfig, otpKey) {
        const paymentConfig = updatePaymentConfig.config ?? {};
        const configWithDefaults = {
            ...paymentConfig,
            channel: paymentConfig.channel ?? OpfPaymentChannel.BROWSER,
            browserInfo: paymentConfig.browserInfo ?? getBrowserInfo(this.winRef.nativeWindow),
        };
        return this.opfPaymentFacade
            .updatePaymentTransaction({
            ...updatePaymentConfig,
            otpKey: updatePaymentConfig.otpKey ?? otpKey,
            config: configWithDefaults,
        })
            .pipe(retry({
            count: OpfGlobalFunctionsSharedService.UPDATE_PAYMENT_TRANSACTION_RETRY_COUNT,
            delay: OpfGlobalFunctionsSharedService.UPDATE_PAYMENT_TRANSACTION_RETRY_DELAY,
        }));
    }
    createUpdatePaymentTransactionError(error) {
        const message = this.extractErrorMessage(error);
        return new Error(message
            ? `Failed to update payment transaction: ${message}`
            : 'Failed to update payment transaction');
    }
    extractErrorMessage(error) {
        if (!error) {
            return undefined;
        }
        const errorObj = error;
        return errorObj?.details?.[0]?.message || errorObj?.message;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsSharedService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsSharedService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsSharedService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGlobalFunctionsSharedRegistrationsService {
    constructor() {
        this.sharedService = inject(OpfGlobalFunctionsSharedService);
    }
    registerSubmit(container, paymentSessionId, vcr) {
        container.submit = (options) => this.sharedService.submit(options, paymentSessionId, vcr);
    }
    registerSubmitComplete(container, paymentSessionId, vcr) {
        container.submitComplete = (options) => this.sharedService.submitComplete(options, paymentSessionId, vcr);
    }
    registerUpdatePaymentTransaction(container, updatePaymentTransaction) {
        container.updatePaymentTransaction = updatePaymentTransaction;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsSharedRegistrationsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsSharedRegistrationsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsSharedRegistrationsService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGlobalFunctionsCheckoutDomainService {
    constructor() {
        this.winRef = inject(WindowRef);
        this.ngZone = inject(NgZone);
        this.launchDialogService = inject(LaunchDialogService);
        this.opfMetadataStoreService = inject(OpfMetadataStoreService);
        this.opfPaymentEventsService = inject(OpfPaymentEventsService);
        this.routingService = inject(RoutingService);
        this.sharedService = inject(OpfGlobalFunctionsSharedService);
    }
    startLoadIndicator(vcr) {
        if (!vcr) {
            return;
        }
        this.ngZone.run(() => {
            if (this.loaderSpinnerCpntRef) {
                this.sharedService.stopLoaderSpinner(this.loaderSpinnerCpntRef);
            }
            this.loaderSpinnerCpntRef = this.sharedService.startLoaderSpinner(vcr);
        });
    }
    stopLoadIndicator() {
        this.ngZone.run(() => {
            this.sharedService.stopLoaderSpinner(this.loaderSpinnerCpntRef);
        });
    }
    throwPaymentError(vcr, opfErrorDialogOptions = defaultOpfErrorDialogOptions) {
        if (!vcr) {
            return;
        }
        this.ngZone.run(() => {
            const dialog = this.launchDialogService.openDialog(LAUNCH_CALLER.OPF_ERROR, undefined, vcr, opfErrorDialogOptions);
            if (dialog) {
                dialog.pipe(take(1)).subscribe();
            }
        });
    }
    reinitiatePaymentForm(paymentOptionId) {
        return this.ngZone.run(() => {
            this.opfPaymentEventsService.emitReinitiatePaymentEvent(paymentOptionId);
            return Promise.resolve(true);
        });
    }
    handle3DSRedirect(threeDsURL, paymentSessionId) {
        return this.ngZone.run(() => {
            const finalPaymentSessionId = this.sharedService.requirePaymentSessionId(paymentSessionId);
            if (!threeDsURL) {
                return Promise.reject(new Error('threeDsURL is required'));
            }
            const returnPath = this.routingService.getFullUrl({
                cxRoute: OpfPage.RESULT_PAGE,
            });
            this.opfMetadataStoreService.updateOpfMetadata({
                opfPaymentSessionId: finalPaymentSessionId,
                is3DSRedirect: true,
                opf3DSRedirectReturnPath: returnPath,
            });
            if (this.winRef.nativeWindow) {
                this.winRef.nativeWindow.location.href = threeDsURL;
            }
            return Promise.resolve();
        });
    }
    updatePaymentTransaction(updatePaymentConfig) {
        return this.sharedService.updatePaymentTransaction(updatePaymentConfig);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsCheckoutDomainService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsCheckoutDomainService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsCheckoutDomainService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGlobalFunctionsCheckoutDomainRegistrationsService {
    constructor() {
        this.domainService = inject(OpfGlobalFunctionsCheckoutDomainService);
        this.sharedRegistrationsService = inject(OpfGlobalFunctionsSharedRegistrationsService);
    }
    registerAll(container, { paymentSessionId, vcr }) {
        this.sharedRegistrationsService.registerSubmit(container, paymentSessionId, vcr);
        this.sharedRegistrationsService.registerSubmitComplete(container, paymentSessionId, vcr);
        this.registerThrowPaymentError(container, vcr);
        this.registerStartLoadIndicator(container, vcr);
        this.registerStopLoadIndicator(container);
        this.registerReinitiatePaymentForm(container);
        this.registerHandle3DSRedirect(container, paymentSessionId);
        this.sharedRegistrationsService.registerUpdatePaymentTransaction(container, (updatePaymentConfig) => this.domainService.updatePaymentTransaction(updatePaymentConfig));
    }
    registerStartLoadIndicator(container, vcr) {
        container.startLoadIndicator = () => this.domainService.startLoadIndicator(vcr);
    }
    registerStopLoadIndicator(container) {
        container.stopLoadIndicator = () => this.domainService.stopLoadIndicator();
    }
    registerThrowPaymentError(container, vcr) {
        container.throwPaymentError = (opfErrorDialogOptions) => this.domainService.throwPaymentError(vcr, opfErrorDialogOptions);
    }
    registerReinitiatePaymentForm(container) {
        container.reinitiatePaymentForm = (paymentOptionId) => this.domainService.reinitiatePaymentForm(paymentOptionId);
    }
    registerHandle3DSRedirect(container, paymentSessionId) {
        container.handle3DSRedirect = (threeDsURL) => this.domainService.handle3DSRedirect(threeDsURL, paymentSessionId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsCheckoutDomainRegistrationsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsCheckoutDomainRegistrationsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsCheckoutDomainRegistrationsService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGlobalFunctionsGlobalDomainService {
    constructor() {
        this.winRef = inject(WindowRef);
        this.ngZone = inject(NgZone);
        this.opfPaymentFacade = inject(OpfPaymentFacade);
        this.launchDialogService = inject(LaunchDialogService);
        this.opfCtaFacade = inject(OpfCtaFacade);
        this.opfMetadataStoreService = inject(OpfMetadataStoreService);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.multiCartFacade = inject(MultiCartFacade);
        this.userIdService = inject(UserIdService);
        this.cartAccessCodeFacade = inject(CartAccessCodeFacade);
        this.routingService = inject(RoutingService);
        this.opfQuickBuyTransactionService = inject(OpfQuickBuyTransactionService);
        this.sharedService = inject(OpfGlobalFunctionsSharedService);
    }
    scriptReady(scriptIdentifier) {
        this.ngZone.run(() => {
            this.opfCtaFacade.emitScriptReadyEvent(scriptIdentifier);
        });
    }
    getCart(cartId) {
        return this.ngZone.run(() => {
            if (cartId) {
                this.multiCartFacade.reloadCart(cartId);
                return lastValueFrom(this.multiCartFacade.getCart(cartId).pipe(take(1)));
            }
            return lastValueFrom(this.reloadCartAndWaitForStable().pipe(switchMap(() => this.activeCartFacade.takeActive()), take(1)));
        });
    }
    startLoadIndicatorGlobal() {
        this.ngZone.run(() => {
            if (this.globalLoaderSpinnerCpntRef) {
                this.sharedService.stopLoaderSpinner(this.globalLoaderSpinnerCpntRef);
            }
            const result = this.launchDialogService.launch(LAUNCH_CALLER.PLACE_ORDER_SPINNER);
            if (result) {
                this.globalLoaderSpinnerCpntRef = result;
            }
        });
    }
    stopLoadIndicatorGlobal() {
        this.ngZone.run(() => {
            this.sharedService.stopLoaderSpinner(this.globalLoaderSpinnerCpntRef);
            this.globalLoaderSpinnerCpntRef = undefined;
        });
    }
    throwPaymentErrorGlobal(opfErrorDialogOptions = defaultOpfErrorDialogOptions) {
        this.ngZone.run(() => {
            const dialog = this.launchDialogService.openDialog(LAUNCH_CALLER.OPF_ERROR, undefined, undefined, opfErrorDialogOptions);
            if (dialog) {
                dialog.pipe(take(1)).subscribe();
            }
        });
    }
    initiatePayment(configurationIdOrPaymentConfig) {
        return this.ngZone.run(() => {
            const paymentConfig = this.normalizePaymentConfig(configurationIdOrPaymentConfig);
            if (!paymentConfig.configurationId) {
                return Promise.reject(new Error('configurationId is required'));
            }
            const cartId$ = this.activeCartFacade.getActiveCartId().pipe(take(1));
            const userId$ = this.userIdService.getUserId().pipe(take(1));
            return lastValueFrom(combineLatest([userId$, cartId$]).pipe(switchMap(([userId, cartId]) => this.initiatePaymentWithCart(userId, cartId, paymentConfig))));
        });
    }
    verifyPayment(paymentSessionId, paymentVerificationPayload) {
        return this.ngZone.run(() => {
            return lastValueFrom(this.opfPaymentFacade
                .verifyPayment(paymentSessionId, paymentVerificationPayload)
                .pipe(take(1)));
        });
    }
    updatePaymentTransaction(updatePaymentConfig) {
        return this.sharedService.updatePaymentTransaction(updatePaymentConfig);
    }
    updateCartGuestUserEmail(email) {
        return this.ngZone.run(() => {
            return lastValueFrom(this.opfQuickBuyTransactionService
                .updateCartGuestUserEmail(email)
                .pipe(take(1)));
        });
    }
    createCartGuestUser() {
        return this.ngZone.run(() => {
            return lastValueFrom(this.opfQuickBuyTransactionService.createCartGuestUser().pipe(take(1)));
        });
    }
    setBillingAddress(address) {
        return this.ngZone.run(() => {
            return lastValueFrom(this.opfQuickBuyTransactionService
                .setBillingAddress(address)
                .pipe(switchMap(() => this.reloadCartAndWaitForStable())));
        });
    }
    setDeliveryAddress(address) {
        return this.ngZone.run(() => {
            return lastValueFrom(this.opfQuickBuyTransactionService.setDeliveryAddress(address));
        });
    }
    getBillingAddress() {
        return this.ngZone.run(() => {
            return lastValueFrom(this.reloadCartAndWaitForStable().pipe(switchMap(() => this.activeCartFacade.takeActive()), map((cart) => cart?.sapBillingAddress), take(1)));
        });
    }
    getDeliveryAddress() {
        return this.ngZone.run(() => {
            return lastValueFrom(this.reloadCartAndWaitForStable().pipe(switchMap(() => this.activeCartFacade.takeActive()), map((cart) => cart?.deliveryAddress), take(1)));
        });
    }
    setDeliveryMode(mode) {
        return this.ngZone.run(() => {
            return lastValueFrom(this.opfQuickBuyTransactionService.setDeliveryMode(mode).pipe(take(1)));
        });
    }
    getDeliveryMode() {
        return this.ngZone.run(() => {
            return lastValueFrom(this.reloadCartAndWaitForStable().pipe(switchMap(() => this.activeCartFacade.takeActive()), map((cart) => cart?.deliveryMode), take(1)));
        });
    }
    deleteAddress(addressId) {
        return this.ngZone.run(() => {
            return new Promise((resolve) => {
                this.opfQuickBuyTransactionService.deleteUserAddresses([addressId]);
                resolve();
            });
        });
    }
    normalizePaymentConfig(configurationIdOrPaymentConfig) {
        return typeof configurationIdOrPaymentConfig === 'string' ||
            typeof configurationIdOrPaymentConfig === 'number'
            ? { configurationId: String(configurationIdOrPaymentConfig) }
            : configurationIdOrPaymentConfig;
    }
    initiatePaymentWithCart(userId, cartId, paymentConfig) {
        if (!cartId) {
            return throwError(() => new Error('Cart ID is required. No active cart found.'));
        }
        return this.cartAccessCodeFacade.getCartAccessCode(userId, cartId).pipe(map((response) => this.sharedService.extractOtpKey(response)), filter(Boolean), switchMap((otpKey) => this.buildAndInitiatePaymentConfig(paymentConfig, otpKey)), take(1));
    }
    buildAndInitiatePaymentConfig(paymentConfig, otpKey) {
        const configWithDefaults = {
            ...paymentConfig,
            channel: paymentConfig.channel ?? OpfPaymentChannel.BROWSER,
            browserInfo: paymentConfig.browserInfo ?? getBrowserInfo(this.winRef.nativeWindow),
            resultURL: paymentConfig.resultURL ??
                this.routingService.getFullUrl({ cxRoute: OpfPage.RESULT_PAGE }),
            cancelURL: paymentConfig.cancelURL ??
                this.routingService.getFullUrl({ cxRoute: OpfPage.CANCEL_PAGE }),
        };
        const fullConfig = {
            otpKey,
            config: configWithDefaults,
        };
        return this.opfPaymentFacade.initiatePayment(fullConfig);
    }
    reloadCartAndWaitForStable() {
        this.activeCartFacade.reloadActiveCart();
        return this.activeCartFacade.isStable().pipe(skip(1), filter((isStable) => isStable), take(1));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsGlobalDomainService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsGlobalDomainService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsGlobalDomainService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGlobalFunctionsGlobalDomainRegistrationsService {
    constructor() {
        this.domainService = inject(OpfGlobalFunctionsGlobalDomainService);
        this.sharedRegistrationsService = inject(OpfGlobalFunctionsSharedRegistrationsService);
    }
    registerAll(container, { paymentSessionId, vcr }) {
        this.registerCtaScriptReady(container);
        this.registerGetCart(container);
        this.registerSetBillingAddress(container);
        this.registerGetBillingAddress(container);
        this.registerSetDeliveryAddress(container);
        this.registerGetDeliveryAddress(container);
        this.registerSetDeliveryMode(container);
        this.registerGetDeliveryMode(container);
        this.registerDeleteAddress(container);
        this.registerUpdateCartGuestUserEmail(container);
        this.registerCreateCartGuestUser(container);
        this.registerStartLoadIndicatorGlobal(container);
        this.registerStopLoadIndicatorGlobal(container);
        this.registerThrowPaymentErrorGlobal(container);
        this.registerInitiatePayment(container);
        this.sharedRegistrationsService.registerUpdatePaymentTransaction(container, (updatePaymentConfig) => this.domainService.updatePaymentTransaction(updatePaymentConfig));
        this.registerVerifyPayment(container);
        this.sharedRegistrationsService.registerSubmit(container, paymentSessionId, vcr);
        this.sharedRegistrationsService.registerSubmitComplete(container, paymentSessionId, vcr);
    }
    registerCtaScriptReady(container) {
        container.scriptReady = (scriptIdentifier) => this.domainService.scriptReady(scriptIdentifier);
    }
    registerGetCart(container) {
        container.getCart = (cartId) => this.domainService.getCart(cartId);
    }
    registerStartLoadIndicatorGlobal(container) {
        container.startLoadIndicator = () => this.domainService.startLoadIndicatorGlobal();
    }
    registerStopLoadIndicatorGlobal(container) {
        container.stopLoadIndicator = () => this.domainService.stopLoadIndicatorGlobal();
    }
    registerThrowPaymentErrorGlobal(container) {
        container.throwPaymentError = (opfErrorDialogOptions) => this.domainService.throwPaymentErrorGlobal(opfErrorDialogOptions);
    }
    registerInitiatePayment(container) {
        container.initiatePayment = (configurationIdOrPaymentConfig) => this.domainService.initiatePayment(configurationIdOrPaymentConfig);
    }
    registerVerifyPayment(container) {
        container.verifyPayment = (paymentSessionId, paymentVerificationPayload) => this.domainService.verifyPayment(paymentSessionId, paymentVerificationPayload);
    }
    registerUpdateCartGuestUserEmail(container) {
        container.updateCartGuestUserEmail = (email) => this.domainService.updateCartGuestUserEmail(email);
    }
    registerCreateCartGuestUser(container) {
        container.createCartGuestUser = () => this.domainService.createCartGuestUser();
    }
    registerSetBillingAddress(container) {
        container.setBillingAddress = (address) => this.domainService.setBillingAddress(address);
    }
    registerSetDeliveryAddress(container) {
        container.setDeliveryAddress = (address) => this.domainService.setDeliveryAddress(address);
    }
    registerGetBillingAddress(container) {
        container.getBillingAddress = () => this.domainService.getBillingAddress();
    }
    registerGetDeliveryAddress(container) {
        container.getDeliveryAddress = () => this.domainService.getDeliveryAddress();
    }
    registerSetDeliveryMode(container) {
        container.setDeliveryMode = (mode) => this.domainService.setDeliveryMode(mode);
    }
    registerGetDeliveryMode(container) {
        container.getDeliveryMode = () => this.domainService.getDeliveryMode();
    }
    registerDeleteAddress(container) {
        container.deleteAddress = (addressId) => this.domainService.deleteAddress(addressId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsGlobalDomainRegistrationsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsGlobalDomainRegistrationsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsGlobalDomainRegistrationsService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGlobalFunctionsRedirectDomainService {
    constructor() {
        this.sharedService = inject(OpfGlobalFunctionsSharedService);
    }
    getRedirectParams(paramsMap = []) {
        return paramsMap.map((p) => {
            return { key: p.key, value: p.value };
        });
    }
    submitCompleteRedirect(additionalData, callbacks, paymentSessionId, vcr) {
        return this.sharedService.runSubmitComplete(additionalData, callbacks, paymentSessionId, OpfPage.CHECKOUT_REVIEW_PAGE, vcr);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsRedirectDomainService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsRedirectDomainService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsRedirectDomainService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGlobalFunctionsRedirectDomainRegistrationsService {
    constructor() {
        this.domainService = inject(OpfGlobalFunctionsRedirectDomainService);
    }
    registerAll(container, { paymentSessionId, vcr, paramsMap }) {
        if (!paymentSessionId) {
            return;
        }
        this.registerSubmitCompleteRedirect(container, paymentSessionId, vcr);
        this.registerGetRedirectParams(container, paramsMap ?? []);
    }
    registerGetRedirectParams(container, paramsMap = []) {
        container.getRedirectParams = () => this.domainService.getRedirectParams(paramsMap);
    }
    registerSubmitCompleteRedirect(container, paymentSessionId, vcr) {
        container.submitCompleteRedirect = ({ additionalData, submitSuccess = () => {
            // this is intentional
        }, submitPending = () => {
            // this is intentional
        }, submitFailure = () => {
            // this is intentional
        }, submitCancel = () => {
            // this is intentional
        }, }) => {
            return this.domainService.submitCompleteRedirect(additionalData, {
                onSuccess: submitSuccess,
                onPending: submitPending,
                onFailure: submitFailure,
                onCancel: submitCancel,
            }, paymentSessionId, vcr);
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsRedirectDomainRegistrationsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsRedirectDomainRegistrationsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsRedirectDomainRegistrationsService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGlobalFunctionsService {
    constructor() {
        this.winRef = inject(WindowRef);
        this.checkoutDomain = inject(OpfGlobalFunctionsCheckoutDomainRegistrationsService);
        this.redirectDomain = inject(OpfGlobalFunctionsRedirectDomainRegistrationsService);
        this.globalDomain = inject(OpfGlobalFunctionsGlobalDomainRegistrationsService);
    }
    registerGlobalFunctions({ domain, paymentSessionId, vcr, paramsMap, }) {
        // SSR not supported
        if (!this.winRef.isBrowser()) {
            return;
        }
        const container = this.getContainer(domain);
        switch (domain) {
            case OpfGlobalFunctionsDomain.CHECKOUT:
                this.checkoutDomain.registerAll(container, {
                    domain,
                    paymentSessionId,
                    vcr,
                    paramsMap,
                });
                break;
            case OpfGlobalFunctionsDomain.REDIRECT:
                this.redirectDomain.registerAll(container, {
                    domain,
                    paymentSessionId,
                    vcr,
                    paramsMap,
                });
                break;
            case OpfGlobalFunctionsDomain.GLOBAL:
                this.globalDomain.registerAll(container, {
                    domain,
                    paymentSessionId,
                    vcr,
                    paramsMap,
                });
                break;
            default:
                break;
        }
    }
    getContainer(domain) {
        const window = this.winRef.nativeWindow;
        if (!window) {
            return {};
        }
        if (!window.Opf?.payments?.[domain]) {
            window.Opf = window?.Opf ?? {};
            window.Opf.payments = window.Opf.payments ?? {};
            window.Opf.payments[domain] = {};
        }
        return window.Opf.payments[domain];
    }
    unregisterGlobalFunctions(domain) {
        // SSR not supported
        if (!this.winRef.isBrowser()) {
            return;
        }
        const window = this.winRef.nativeWindow;
        if (!window?.Opf?.payments) {
            return;
        }
        if (window.Opf.payments[domain]) {
            window.Opf.payments[domain] = undefined;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultGlobalSpinnerLayoutConfig = {
    launch: {
        PLACE_ORDER_SPINNER: {
            inlineRoot: true,
            component: SpinnerComponent,
            dialogType: DIALOG_TYPE.POPOVER_CENTER_BACKDROP,
        },
        OPF_ERROR: {
            inlineRoot: true,
            component: OpfErrorModalComponent,
            dialogType: DIALOG_TYPE.POPOVER_CENTER_BACKDROP,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const facadeProviders = [
    OpfGlobalFunctionsSharedService,
    OpfGlobalFunctionsSharedRegistrationsService,
    OpfGlobalFunctionsCheckoutDomainService,
    OpfGlobalFunctionsCheckoutDomainRegistrationsService,
    OpfGlobalFunctionsGlobalDomainService,
    OpfGlobalFunctionsGlobalDomainRegistrationsService,
    OpfGlobalFunctionsRedirectDomainService,
    OpfGlobalFunctionsRedirectDomainRegistrationsService,
    OpfGlobalFunctionsService,
    {
        provide: OpfGlobalFunctionsFacade,
        useExisting: OpfGlobalFunctionsService,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGlobalFunctionsCoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsCoreModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsCoreModule, providers: [
            ...facadeProviders,
            provideDefaultConfig(defaultGlobalSpinnerLayoutConfig),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    providers: [
                        ...facadeProviders,
                        provideDefaultConfig(defaultGlobalSpinnerLayoutConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfGlobalFunctionsCoreModule, OpfGlobalFunctionsService };
//# sourceMappingURL=spartacus-opf-global-functions-core.mjs.map
