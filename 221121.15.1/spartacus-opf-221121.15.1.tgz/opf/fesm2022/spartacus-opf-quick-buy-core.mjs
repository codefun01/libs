import * as i0 from '@angular/core';
import { inject, Injectable, NgModule, InjectionToken } from '@angular/core';
import { CartAccessCodeFacade, ActiveCartFacade, CartGuestUserFacade, MultiCartFacade } from '@spartacus/cart/base/root';
import { CommandService, UserIdService, LoggerService, tryNormalizeHttpError, backOff, DEFAULT_AUTHORIZATION_ERROR_RETRIES_COUNT, isAuthorizationError, BaseSiteService, RoutingService, UserAddressService, AuthService } from '@spartacus/core';
import { combineLatest, filter, switchMap, take, concatMap, catchError, of } from 'rxjs';
import { OpfQuickBuyFacade, OpfQuickBuyDeliveryType, OPF_QUICK_BUY_DEFAULT_MERCHANT_NAME } from '@spartacus/opf/quick-buy/root';
import { CheckoutDeliveryModesFacade, CheckoutDeliveryAddressFacade, CheckoutBillingAddressFacade } from '@spartacus/checkout/base/root';
import { OpfGlobalMessageService } from '@spartacus/opf/base/root';
import { take as take$1, map, filter as filter$1, switchMap as switchMap$1, tap } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyConnector {
    constructor() {
        this.adapter = inject(OpfQuickBuyAdapter);
    }
    getApplePayWebSession(applePayWebRequest, accessCode) {
        return this.adapter.getApplePayWebSession(applePayWebRequest, accessCode);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyService {
    constructor() {
        this.commandService = inject(CommandService);
        this.opfQuickBuyConnector = inject(OpfQuickBuyConnector);
        this.cartAccessCodeFacade = inject(CartAccessCodeFacade);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.userIdService = inject(UserIdService);
        this.logger = inject(LoggerService);
        this.applePaySessionCommand = this.commandService.create((payload) => {
            return combineLatest([
                this.userIdService.getUserId(),
                this.activeCartFacade.getActiveCartId(),
            ]).pipe(filter(([userId, activeCartId]) => !!activeCartId && !!userId), switchMap(([userId, activeCartId]) => {
                return this.cartAccessCodeFacade.getCartAccessCode(userId, activeCartId);
            }), filter((response) => Boolean(response?.accessCode)), take(1), concatMap(({ accessCode: accessCode }) => {
                return this.opfQuickBuyConnector.getApplePayWebSession(payload.applePayWebSessionRequest, accessCode);
            }), catchError((error) => {
                throw tryNormalizeHttpError(error, this.logger);
            }), backOff({
                shouldRetry: isAuthorizationError,
                maxTries: DEFAULT_AUTHORIZATION_ERROR_RETRIES_COUNT,
            }));
        });
    }
    getApplePayWebSession(applePayWebSessionRequest) {
        return this.applePaySessionCommand.execute({ applePayWebSessionRequest });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const facadeProviders = [
    OpfQuickBuyService,
    {
        provide: OpfQuickBuyFacade,
        useExisting: OpfQuickBuyService,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyCoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyCoreModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyCoreModule, providers: [...facadeProviders, OpfQuickBuyConnector] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    providers: [...facadeProviders, OpfQuickBuyConnector],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyTransactionService {
    constructor() {
        this.baseSiteService = inject(BaseSiteService);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.routingService = inject(RoutingService);
        this.checkoutDeliveryModesFacade = inject(CheckoutDeliveryModesFacade);
        this.checkoutDeliveryAddressFacade = inject(CheckoutDeliveryAddressFacade);
        this.checkoutBillingAddressFacade = inject(CheckoutBillingAddressFacade);
        this.userAddressService = inject(UserAddressService);
        this.opfGlobalMessageService = inject(OpfGlobalMessageService);
        this.cartGuestUserFacade = inject(CartGuestUserFacade);
        this.authService = inject(AuthService);
        this.userIdService = inject(UserIdService);
        this.multiCartFacade = inject(MultiCartFacade);
    }
    getTransactionDeliveryType() {
        return this.activeCartFacade.hasDeliveryItems().pipe(take$1(1), map((hasDeliveryItems) => hasDeliveryItems
            ? OpfQuickBuyDeliveryType.SHIPPING
            : OpfQuickBuyDeliveryType.PICKUP));
    }
    getTransactionDeliveryInfo() {
        const deliveryTypeObservable = this.getTransactionDeliveryType().pipe(map((deliveryType) => {
            return {
                type: deliveryType,
            };
        }));
        return deliveryTypeObservable.pipe(take$1(1));
    }
    getTransactionLocationContext() {
        return this.routingService.getRouterState().pipe(take$1(1), map((routerState) => routerState?.state?.semanticRoute?.toLocaleUpperCase()));
    }
    getMerchantName() {
        return this.baseSiteService.get().pipe(take$1(1), map((baseSite) => baseSite?.name ?? OPF_QUICK_BUY_DEFAULT_MERCHANT_NAME));
    }
    checkStableCart() {
        return this.activeCartFacade.isStable().pipe(filter$1((isStable) => !!isStable), take$1(1));
    }
    getSupportedDeliveryModes() {
        return this.checkoutDeliveryModesFacade.getSupportedDeliveryModes();
    }
    setDeliveryAddress(address) {
        this.opfGlobalMessageService.disableGlobalMessage([
            'addressForm.userAddressAddSuccess',
        ]);
        return this.checkoutDeliveryAddressFacade.createAndSetAddress(address).pipe(switchMap$1(() => this.checkStableCart()), switchMap$1(() => this.getDeliveryAddress().pipe(map((addr) => addr?.id ?? ''))));
    }
    setBillingAddress(address) {
        return this.checkoutBillingAddressFacade
            .setBillingAddress(address)
            .pipe(switchMap$1(() => this.checkStableCart()));
    }
    getDeliveryAddress() {
        return this.checkoutDeliveryAddressFacade.getDeliveryAddressState().pipe(filter$1((state) => !state.loading), take$1(1), map((state) => {
            return state.data;
        }));
    }
    getCurrentCart() {
        return this.activeCartFacade.takeActive();
    }
    getCurrentCartId() {
        return this.activeCartFacade.takeActiveCartId();
    }
    getCurrentCartTotalPrice() {
        return this.activeCartFacade
            .takeActive()
            .pipe(map((cart) => cart.totalPrice?.value));
    }
    setDeliveryMode(mode) {
        return this.checkoutDeliveryModesFacade.setDeliveryMode(mode).pipe(switchMap$1(() => this.checkoutDeliveryModesFacade.getSelectedDeliveryModeState()), filter$1((state) => !state.error && !state.loading), take$1(1), map((state) => state.data));
    }
    getSelectedDeliveryMode() {
        return this.checkoutDeliveryModesFacade.getSelectedDeliveryModeState().pipe(filter$1((state) => !state.error && !state.loading), take$1(1), map((state) => state.data));
    }
    deleteUserAddresses(addrIds) {
        this.authService
            .isUserLoggedIn()
            .pipe(take$1(1))
            .subscribe((isUserLoggedIn) => {
            if (isUserLoggedIn) {
                this.opfGlobalMessageService.disableGlobalMessage([
                    'addressForm.userAddressDeleteSuccess',
                ]);
                addrIds.forEach((addrId) => {
                    this.userAddressService.deleteUserAddress(addrId);
                });
            }
        });
    }
    createCartGuestUser() {
        return combineLatest([
            this.userIdService.takeUserId(),
            this.activeCartFacade.takeActiveCartId(),
        ]).pipe(take$1(1), switchMap$1(([userId, cartId]) => {
            return this.cartGuestUserFacade
                .createCartGuestUser(userId, cartId)
                .pipe(tap(() => this.multiCartFacade.reloadCart(cartId)), map(() => true));
        }));
    }
    updateCartGuestUser(cartGuestUser) {
        return combineLatest([
            this.userIdService.takeUserId(),
            this.activeCartFacade.takeActiveCartId(),
        ]).pipe(take$1(1), switchMap$1(([userId, cartId]) => {
            return this.cartGuestUserFacade
                .updateCartGuestUser(userId, cartId, cartGuestUser)
                .pipe(tap(() => this.multiCartFacade.reloadCart(cartId)), map(() => true));
        }));
    }
    updateCartGuestUserEmail(email) {
        return this.activeCartFacade.isGuestCart().pipe(take$1(1), switchMap$1((isGuestCart) => {
            return isGuestCart && email
                ? this.updateCartGuestUser({ email })
                : of(false);
        }));
    }
    handleCartGuestUser() {
        return combineLatest([
            this.authService.isUserLoggedIn(),
            this.activeCartFacade.isGuestCart(),
        ]).pipe(take$1(1), switchMap$1(([isUserLoggedIn, isGuestCart]) => {
            if (isUserLoggedIn || isGuestCart) {
                return of(true);
            }
            return this.createCartGuestUser();
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyTransactionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyTransactionService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyTransactionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_APPLE_PAY_WEB_SESSION_NORMALIZER = new InjectionToken('OpfApplePayWebSession');

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OPF_APPLE_PAY_WEB_SESSION_NORMALIZER, OpfQuickBuyAdapter, OpfQuickBuyConnector, OpfQuickBuyCoreModule, OpfQuickBuyService, OpfQuickBuyTransactionService };
//# sourceMappingURL=spartacus-opf-quick-buy-core.mjs.map
