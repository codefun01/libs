import * as i0 from '@angular/core';
import { inject, Injectable, ElementRef, ChangeDetectorRef, HostListener, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { LaunchDialogService, FocusDirective, DIALOG_TYPE, KeyboardFocusModule } from '@spartacus/storefront';
import { NgIf, AsyncPipe, CommonModule } from '@angular/common';
import { combineLatest, of, timer } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import { TranslationService, I18nModule, provideDefaultConfig } from '@spartacus/core';
import { defaultOpfErrorDialogOptions } from '@spartacus/opf/base/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfErrorModalService {
    constructor() {
        this.translationService = inject(TranslationService);
    }
    getMessageAndConfirmTranslations(dialogOptions) {
        return combineLatest([
            this.getLabelTranslation(defaultOpfErrorDialogOptions.messageKey, dialogOptions.messageString, dialogOptions.messageKey, dialogOptions.messageReplacements),
            this.getLabelTranslation(defaultOpfErrorDialogOptions.confirmKey, dialogOptions.confirmString, dialogOptions.confirmKey, dialogOptions.confirmReplacements),
        ]).pipe(map((labelArray) => {
            return { message: labelArray[0], confirm: labelArray[1] };
        }));
    }
    getLabelTranslation(defaultKey, labelString, labelKey, labelReplacements) {
        const defaultLabel$ = this.translationService.translate(defaultKey);
        if (labelString) {
            return of(labelString);
        }
        else if (labelKey) {
            const labelFromKey$ = this.translationService
                .translate(labelKey)
                .pipe(switchMap((val) => (val ? of(val) : defaultLabel$)));
            if (labelReplacements) {
                return this.translationService
                    .translate(labelKey, labelReplacements)
                    .pipe(switchMap((val) => (val ? of(val) : labelFromKey$)));
            }
            else {
                return labelFromKey$;
            }
        }
        else {
            return defaultLabel$;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfErrorModalService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfErrorModalService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfErrorModalService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfErrorModalComponent {
    handleClick(event) {
        if (event.target.tagName === this.el.nativeElement.tagName) {
            this.dismissModal('Backdrop click');
        }
    }
    initialize() {
        // Mechanism needed to trigger the cpnt life cycle hooks.
        timer(1).subscribe({
            complete: () => {
                this.cd.markForCheck();
            },
        });
    }
    constructor() {
        this.launchDialogService = inject(LaunchDialogService);
        this.el = inject(ElementRef);
        this.cd = inject(ChangeDetectorRef);
        this.opfErrorModalService = inject(OpfErrorModalService);
        this.focusConfig = {
            trap: true,
            block: true,
            autofocus: 'button',
            focusOnEscape: true,
        };
        this.initialize();
    }
    ngOnInit() {
        this.opfErrorDialogOptions$ = this.launchDialogService.data$.pipe(switchMap((data) => {
            return this.opfErrorModalService.getMessageAndConfirmTranslations(data);
        }));
    }
    dismissModal(reason) {
        this.launchDialogService.closeDialog(reason);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfErrorModalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: OpfErrorModalComponent, isStandalone: true, selector: "cx-opf-error-modal", host: { listeners: { "click": "handleClick($event)" } }, ngImport: i0, template: "<ng-container>\n  <div\n    [cxFocus]=\"focusConfig\"\n    class=\"modal-dialog modal-dialog-centered cx-opf-error-modal\"\n    (esc)=\"dismissModal('Escape click')\"\n  >\n    <div\n      class=\"modal-content cx-opf-error-modal-container\"\n      *ngIf=\"opfErrorDialogOptions$ | async as opfErrorDialogOptions\"\n    >\n      <div class=\"modal-body\">\n        <p class=\"cx-confirmation\">\n          {{ opfErrorDialogOptions?.message }}\n        </p>\n      </div>\n      <div class=\"cx-opf-error-modal-footer cx-modal-footer\">\n        <button class=\"btn btn-primary\" (click)=\"dismissModal('Cancel')\">\n          {{ opfErrorDialogOptions?.confirm }}\n        </button>\n      </div>\n    </div>\n  </div>\n</ng-container>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfErrorModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-error-modal', changeDetection: ChangeDetectionStrategy.OnPush, imports: [FocusDirective, NgIf, AsyncPipe], template: "<ng-container>\n  <div\n    [cxFocus]=\"focusConfig\"\n    class=\"modal-dialog modal-dialog-centered cx-opf-error-modal\"\n    (esc)=\"dismissModal('Escape click')\"\n  >\n    <div\n      class=\"modal-content cx-opf-error-modal-container\"\n      *ngIf=\"opfErrorDialogOptions$ | async as opfErrorDialogOptions\"\n    >\n      <div class=\"modal-body\">\n        <p class=\"cx-confirmation\">\n          {{ opfErrorDialogOptions?.message }}\n        </p>\n      </div>\n      <div class=\"cx-opf-error-modal-footer cx-modal-footer\">\n        <button class=\"btn btn-primary\" (click)=\"dismissModal('Cancel')\">\n          {{ opfErrorDialogOptions?.confirm }}\n        </button>\n      </div>\n    </div>\n  </div>\n</ng-container>\n" }]
        }], ctorParameters: () => [], propDecorators: { handleClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOpfErrorModalLayoutConfig = {
    launch: {
        OPF_ERROR: {
            inline: true,
            component: OpfErrorModalComponent,
            dialogType: DIALOG_TYPE.POPOVER_CENTER_BACKDROP,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfErrorModalModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfErrorModalModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfErrorModalModule, imports: [CommonModule,
            I18nModule,
            KeyboardFocusModule,
            OpfErrorModalComponent], exports: [OpfErrorModalComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfErrorModalModule, providers: [provideDefaultConfig(defaultOpfErrorModalLayoutConfig)], imports: [CommonModule,
            I18nModule,
            KeyboardFocusModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfErrorModalModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [provideDefaultConfig(defaultOpfErrorModalLayoutConfig)],
                    exports: [OpfErrorModalComponent],
                    imports: [
                        CommonModule,
                        I18nModule,
                        KeyboardFocusModule,
                        OpfErrorModalComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfBaseComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfBaseComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfBaseComponentsModule, imports: [OpfErrorModalModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfBaseComponentsModule, imports: [OpfErrorModalModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfBaseComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OpfErrorModalModule],
                    providers: [],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfBaseComponentsModule, OpfErrorModalComponent, OpfErrorModalModule, OpfErrorModalService, defaultOpfErrorModalLayoutConfig };
//# sourceMappingURL=spartacus-opf-base-components.mjs.map
