import * as i0 from '@angular/core';
import { Injectable, inject, ViewContainerRef, Component, NgModule, DestroyRef, Optional } from '@angular/core';
import { facadeFactory, RoutingService, GlobalMessageService, WindowRef, RoutingConfigService, GlobalMessageType, FeatureConfigService, TranslationService, FeatureToggles, provideDefaultConfig, provideLocationInitializerFactory } from '@spartacus/core';
import { Subject, BehaviorSubject, of, throwError, from, Subscription, filter as filter$1, map as map$1 } from 'rxjs';
import * as i1$1 from '@angular/router';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { OpfMetadataStoreService, OpfResourceLoaderService, OpfPage, OpfHtmlContentMode } from '@spartacus/opf/base/root';
import { map, concatMap, take, filter, tap, finalize } from 'rxjs/operators';
import * as i1 from '@spartacus/storefront';
import { SpinnerComponent, SpinnerModule, OutletContextData, CardComponent, OutletModule, CardModule, provideOutlet, OutletPosition } from '@spartacus/storefront';
import { OpfGlobalFunctionsFacade, OpfGlobalFunctionsDomain } from '@spartacus/opf/global-functions/root';
import { OrderFacade } from '@spartacus/order/root';
import { CommonModule, NgIf, AsyncPipe } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { OpfCheckoutOutlets } from '@spartacus/opf/checkout/root';
import { CartOutlets } from '@spartacus/cart/base/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOpfPaymentRoutingConfig = {
    routing: {
        routes: {
            paymentVerificationResult: {
                paths: ['opf/payment-verification-redirect/result'],
            },
            paymentVerificationCancel: {
                paths: ['opf/payment-verification-redirect/cancel'],
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_PAYMENT_FEATURE = 'opfPayment';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfPaymentFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: OpfPaymentFacade,
            feature: OPF_PAYMENT_FEATURE,
            methods: [
                'verifyPayment',
                'submitPayment',
                'submitCompletePayment',
                'getAfterRedirectScripts',
                'initiatePayment',
                'updatePaymentTransaction',
                'setCartPaymentOption',
            ],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: OpfPaymentFacade,
                        feature: OPF_PAYMENT_FEATURE,
                        methods: [
                            'verifyPayment',
                            'submitPayment',
                            'submitCompletePayment',
                            'getAfterRedirectScripts',
                            'initiatePayment',
                            'updatePaymentTransaction',
                            'setCartPaymentOption',
                        ],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const opfDefaultPaymentError = {
    statusText: 'Payment Error',
    message: 'opfPayment.errors.proceedPayment',
    status: -1,
    type: '',
};
var OpfPaymentErrorType;
(function (OpfPaymentErrorType) {
    OpfPaymentErrorType["EXPIRED"] = "EXPIRED";
    OpfPaymentErrorType["INSUFFICIENT_FUNDS"] = "INSUFFICIENT_FUNDS";
    OpfPaymentErrorType["CREDIT_LIMIT"] = "CREDIT_LIMIT";
    OpfPaymentErrorType["INVALID_CARD"] = "INVALID_CARD";
    OpfPaymentErrorType["INVALID_CVV"] = "INVALID_CVV";
    OpfPaymentErrorType["LOST_CARD"] = "LOST_CARD";
    OpfPaymentErrorType["PAYMENT_REJECTED"] = "PAYMENT_REJECTED";
    OpfPaymentErrorType["PAYMENT_CANCELLED"] = "PAYMENT_CANCELLED";
    OpfPaymentErrorType["STATUS_NOT_RECOGNIZED"] = "STATUS_NOT_RECOGNIZED";
})(OpfPaymentErrorType || (OpfPaymentErrorType = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var OpfPaymentVerificationResult;
(function (OpfPaymentVerificationResult) {
    OpfPaymentVerificationResult["AUTHORIZED"] = "AUTHORIZED";
    OpfPaymentVerificationResult["UNAUTHORIZED"] = "UNAUTHORIZED";
    OpfPaymentVerificationResult["CANCELLED"] = "CANCELLED";
    OpfPaymentVerificationResult["DELAYED"] = "DELAYED";
})(OpfPaymentVerificationResult || (OpfPaymentVerificationResult = {}));
var OpfPaymentVerificationUrlInput;
(function (OpfPaymentVerificationUrlInput) {
    OpfPaymentVerificationUrlInput["OPF_AFTER_REDIRECT_SCRIPT_FLAG"] = "opfAfterRedirectScriptFlag";
    OpfPaymentVerificationUrlInput["OPF_PAYMENT_SESSION_ID"] = "opfPaymentSessionId";
})(OpfPaymentVerificationUrlInput || (OpfPaymentVerificationUrlInput = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var OpfPaymentChannel;
(function (OpfPaymentChannel) {
    OpfPaymentChannel["BROWSER"] = "BROWSER";
})(OpfPaymentChannel || (OpfPaymentChannel = {}));
var OpfPaymentSubmitStatus;
(function (OpfPaymentSubmitStatus) {
    OpfPaymentSubmitStatus["REJECTED"] = "REJECTED";
    OpfPaymentSubmitStatus["ACCEPTED"] = "ACCEPTED";
    OpfPaymentSubmitStatus["PENDING"] = "PENDING";
    OpfPaymentSubmitStatus["DELAYED"] = "DELAYED";
    OpfPaymentSubmitStatus["CANCELLED"] = "CANCELLED";
})(OpfPaymentSubmitStatus || (OpfPaymentSubmitStatus = {}));
var OpfPaymentMethod;
(function (OpfPaymentMethod) {
    OpfPaymentMethod["CREDIT_CARD"] = "CREDIT_CARD";
})(OpfPaymentMethod || (OpfPaymentMethod = {}));
var OpfPaymentRenderPattern;
(function (OpfPaymentRenderPattern) {
    OpfPaymentRenderPattern["IFRAME"] = "IFRAME";
    OpfPaymentRenderPattern["FULL_PAGE"] = "FULL_PAGE";
    OpfPaymentRenderPattern["HOSTED_FIELDS"] = "HOSTED_FIELDS";
})(OpfPaymentRenderPattern || (OpfPaymentRenderPattern = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfPaymentEventsService {
    constructor() {
        this.reinitiatePaymentEvent = new Subject();
        this.reinitiatePaymentEvent$ = this.reinitiatePaymentEvent.asObservable();
        this.isGiftCardCoveredTotalAmountEvent = new BehaviorSubject(false);
        this.isGiftCardCoveredTotalAmountEvent$ = this.isGiftCardCoveredTotalAmountEvent.asObservable();
    }
    /**
     * Emits an event to re-initiate payment form
     * @param paymentOptionId Optional payment option ID to use for re-initiation
     */
    emitReinitiatePaymentEvent(paymentOptionId) {
        this.reinitiatePaymentEvent.next(paymentOptionId);
    }
    /**
     * Emits an event to indicate if the gift card covers the total amount
     * @param isCovered Boolean indicating if the gift card covers the total amount
     */
    emitIsGiftCardCoveredTotalAmountEvent(isCovered) {
        this.isGiftCardCoveredTotalAmountEvent.next(isCovered);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentEventsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentEventsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentEventsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_PAYMENT_VERIFICATION_QUERY_SEARCH_KEY = 'opfPaymentVerificationQuerySearch';
class OpfPaymentVerificationService {
    constructor() {
        this.orderFacade = inject(OrderFacade);
        this.routingService = inject(RoutingService);
        this.globalMessageService = inject(GlobalMessageService);
        this.opfPaymentFacade = inject(OpfPaymentFacade);
        this.opfMetadataStoreService = inject(OpfMetadataStoreService);
        this.opfResourceLoaderService = inject(OpfResourceLoaderService);
        this.globalFunctionsService = inject(OpfGlobalFunctionsFacade);
        this.winRef = inject(WindowRef);
        this.routingConfigService = inject(RoutingConfigService);
        this.opfDefaultPaymentError = {
            statusText: 'Payment Verification Error',
            message: 'opfPayment.errors.proceedPayment',
            status: -1,
        };
    }
    getParamsMap(params) {
        return params
            ? Object.entries(params).map((pair) => {
                return { key: pair[0], value: pair[1] };
            })
            : [];
    }
    /**
     * Stores the redirect query string before OAuth bootstrap mutates `location.search`.
     */
    captureRedirectQueryString() {
        if (!this.winRef.isBrowser()) {
            return;
        }
        const pathname = this.winRef.location.pathname ?? '';
        const isRedirectUrl = [OpfPage.RESULT_PAGE, OpfPage.CANCEL_PAGE].some((routeName) => (this.routingConfigService.getRouteConfig(routeName)?.paths ?? []).some((path) => pathname.endsWith(path.startsWith('/') ? path : `/${path}`)));
        if (!isRedirectUrl) {
            return;
        }
        const search = this.winRef.location.search ?? '';
        if (search) {
            this.winRef.sessionStorage?.setItem(OPF_PAYMENT_VERIFICATION_QUERY_SEARCH_KEY, search);
        }
    }
    findInParamsMap(key, list) {
        return list.find((pair) => pair.key === key)?.value ?? undefined;
    }
    goToPage(cxRoute) {
        this.routingService.go({ cxRoute });
    }
    clearPaymentSessionForReinitiation() {
        this.opfMetadataStoreService.updateOpfMetadata({
            opfPaymentSessionId: undefined,
            opfPaymentSessionConfigurationId: undefined,
        });
    }
    verifyResultUrl(route) {
        let paramsMap;
        const is3DSRedirect = this.check3DSRedirectState();
        const redirectQueryParams$ = this.winRef.isBrowser()
            ? of(this.getParamsMap(this.getRedirectQueryParams()))
            : route.queryParams.pipe(map((params) => this.getParamsMap(params)));
        return route?.routeConfig?.data?.cxRoute === OpfPage.RESULT_PAGE
            ? redirectQueryParams$.pipe(concatMap((parsedParamsMap) => {
                paramsMap = parsedParamsMap;
                if (is3DSRedirect) {
                    const storedState = this.get3DSRedirectState();
                    if (storedState?.paymentSessionId) {
                        return of(storedState.paymentSessionId);
                    }
                }
                return this.getPaymentSessionId(paramsMap);
            }), concatMap((paymentSessionId) => {
                if (!paymentSessionId) {
                    return throwError(() => this.opfDefaultPaymentError);
                }
                return of({
                    paymentSessionId,
                    paramsMap: paramsMap.filter((param) => param.key !==
                        OpfPaymentVerificationUrlInput.OPF_PAYMENT_SESSION_ID),
                    afterRedirectScriptFlag: this.findInParamsMap(OpfPaymentVerificationUrlInput.OPF_AFTER_REDIRECT_SCRIPT_FLAG, paramsMap),
                    is3DSRedirect,
                });
            }))
            : throwError(() => ({
                ...this.opfDefaultPaymentError,
                message: 'opfPayment.errors.cancelPayment',
            }));
    }
    getRedirectQueryParams() {
        const captured = this.winRef.sessionStorage?.getItem(OPF_PAYMENT_VERIFICATION_QUERY_SEARCH_KEY);
        if (captured) {
            this.winRef.sessionStorage?.removeItem(OPF_PAYMENT_VERIFICATION_QUERY_SEARCH_KEY);
        }
        const search = captured ?? this.winRef.location.search ?? '';
        if (!search) {
            return {};
        }
        const query = search.startsWith('?') ? search.slice(1) : search;
        const params = {};
        new URLSearchParams(query).forEach((value, key) => {
            params[key] = value;
        });
        return params;
    }
    getPaymentSessionId(paramMap) {
        if (paramMap?.length) {
            const paymentSessionId = this.findInParamsMap(OpfPaymentVerificationUrlInput.OPF_PAYMENT_SESSION_ID, paramMap);
            return paymentSessionId
                ? of(paymentSessionId)
                : this.getPaymentSessionIdFromStorage();
        }
        return this.getPaymentSessionIdFromStorage();
    }
    getPaymentSessionIdFromStorage() {
        return this.opfMetadataStoreService.getOpfMetadataState().pipe(take(1), map((opfMetaData) => opfMetaData?.opfPaymentSessionId));
    }
    placeOrder() {
        return this.orderFacade.placePaymentAuthorizedOrder(true);
    }
    verifyPayment(paymentSessionId, responseMap) {
        return this.opfPaymentFacade
            .verifyPayment(paymentSessionId, {
            responseMap: [...responseMap],
        })
            .pipe(concatMap((response) => this.isPaymentSuccessful(response)));
    }
    isPaymentSuccessful(response) {
        if (response.result === OpfPaymentVerificationResult.AUTHORIZED ||
            response.result === OpfPaymentVerificationResult.DELAYED) {
            return of(true);
        }
        else if (response.result === OpfPaymentVerificationResult.CANCELLED) {
            return throwError(() => ({
                ...this.opfDefaultPaymentError,
                message: 'opfPayment.errors.cancelPayment',
            }));
        }
        else {
            return throwError(() => this.opfDefaultPaymentError);
        }
    }
    displayError(error) {
        this.globalMessageService.add({
            key: error?.message && error?.status === -1
                ? error.message
                : 'opfPayment.errors.proceedPayment',
        }, GlobalMessageType.MSG_TYPE_ERROR);
    }
    checkIfProcessingCartIdExist() {
        this.opfMetadataStoreService
            .getOpfMetadataState()
            .pipe(take(1), filter((state) => state.isPaymentInProgress === false))
            .subscribe(() => {
            this.goToPage(OpfPage.CART_PAGE);
            this.globalMessageService.add({
                key: 'httpHandlers.cartNotFound',
            }, GlobalMessageType.MSG_TYPE_ERROR);
        });
    }
    runHostedPagePattern(paymentSessionId, paramsMap) {
        return this.verifyPayment(paymentSessionId, paramsMap).pipe(concatMap(() => {
            return this.placeOrder();
        }), map((order) => !!order), tap((success) => {
            if (success) {
                this.goToPage(OpfPage.CONFIRMATION_PAGE);
            }
        }));
    }
    runHostedFieldsPattern(paymentSessionId, vcr, paramsMap) {
        this.globalFunctionsService.registerGlobalFunctions({
            domain: OpfGlobalFunctionsDomain.REDIRECT,
            paymentSessionId,
            vcr,
            paramsMap,
        });
        return this.opfPaymentFacade.getAfterRedirectScripts(paymentSessionId).pipe(concatMap((response) => {
            if (!response?.afterRedirectScript) {
                return throwError(() => this.opfDefaultPaymentError);
            }
            return from(this.renderAfterRedirectScripts(response.afterRedirectScript));
        }));
    }
    renderAfterRedirectScripts(script) {
        const html = script?.html;
        return new Promise((resolve) => {
            this.opfResourceLoaderService
                .loadResources(script.jsUrls, script.cssUrls, undefined, script)
                .then(() => {
                if (html && script?.htmlContentMode !== OpfHtmlContentMode.SEPARATE) {
                    this.opfResourceLoaderService.executeScriptFromHtml(html);
                    resolve(true);
                }
                else if (html) {
                    resolve(true);
                }
                else {
                    resolve(false);
                }
            })
                .catch(() => {
                resolve(false);
            });
        });
    }
    removeResourcesAndGlobalFunctions() {
        this.globalFunctionsService.unregisterGlobalFunctions(OpfGlobalFunctionsDomain.REDIRECT);
        this.opfResourceLoaderService.clearAllResources();
    }
    check3DSRedirectState() {
        const metadata = this.opfMetadataStoreService.opfMetadataState?.value;
        return metadata?.is3DSRedirect === true;
    }
    get3DSRedirectState() {
        const metadata = this.opfMetadataStoreService.opfMetadataState?.value;
        if (!metadata?.is3DSRedirect || !metadata?.opfPaymentSessionId) {
            return null;
        }
        return {
            paymentSessionId: metadata.opfPaymentSessionId,
            returnPath: metadata.opf3DSRedirectReturnPath ?? '',
        };
    }
    clear3DSRedirectState() {
        this.opfMetadataStoreService.updateOpfMetadata({
            is3DSRedirect: false,
            opf3DSRedirectReturnPath: undefined,
        });
    }
    run3DSRedirectPattern(paymentSessionId, paramsMap, vcr) {
        const storedState = this.get3DSRedirectState();
        this.globalFunctionsService.registerGlobalFunctions({
            domain: OpfGlobalFunctionsDomain.CHECKOUT,
            paymentSessionId,
            vcr,
        });
        return this.opfPaymentFacade
            .submitCompletePayment({
            paymentSessionId,
            additionalData: paramsMap,
            callbacks: {
                onSuccess: () => { },
                onPending: () => { },
                onFailure: () => { },
            },
            returnPath: storedState?.returnPath,
        })
            .pipe(finalize(() => {
            this.clear3DSRedirectState();
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentVerificationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentVerificationService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentVerificationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });
function captureOpfPaymentVerificationQueryFactory() {
    const service = inject(OpfPaymentVerificationService);
    return () => service.captureRedirectQueryString();
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfPaymentVerificationComponent {
    constructor() {
        this.route = inject(ActivatedRoute);
        this.opfPaymentVerificationService = inject(OpfPaymentVerificationService);
        this.vcr = inject(ViewContainerRef);
        this.winRef = inject(WindowRef);
        this.featureConfigService = inject(FeatureConfigService);
        this.isHostedFieldPattern = false;
    }
    ngOnInit() {
        this.breakOutOfIframeIfNeeded();
        const checkProcessingCartOnErrorOnly = this.featureConfigService.isEnabled('opfPaymentVerificationCheckProcessingCartOnErrorOnly');
        if (!checkProcessingCartOnErrorOnly) {
            this.opfPaymentVerificationService.checkIfProcessingCartIdExist();
        }
        this.subscription = this.opfPaymentVerificationService
            .verifyResultUrl(this.route)
            .pipe(concatMap(({ paymentSessionId, paramsMap: paramsMap, afterRedirectScriptFlag, is3DSRedirect, }) => this.runPaymentPattern({
            paymentSessionId,
            paramsMap,
            afterRedirectScriptFlag,
            is3DSRedirect,
        })))
            .subscribe({
            error: (error) => {
                if (checkProcessingCartOnErrorOnly) {
                    this.opfPaymentVerificationService.checkIfProcessingCartIdExist();
                }
                this.onError(error);
            },
            next: (success) => {
                if (!success) {
                    this.onError(undefined);
                }
            },
        });
    }
    /**
     * Ensures the verification page is displayed in the top-level window.
     * Some PSPs render verification/success pages inside an iframe; in such cases
     * we reload the current URL in the top window to preserve full-page UX.
     *
     * Reference: https://docs.saferpay.com/home/integration-guide/general-information/iframe-integration-and-css
     */
    breakOutOfIframeIfNeeded() {
        if (this.winRef?.nativeWindow?.top &&
            this.winRef.nativeWindow.top.location !==
                this.winRef.nativeWindow.location) {
            this.winRef.nativeWindow.top.location.href =
                this.winRef.nativeWindow.document.location.href;
        }
    }
    runPaymentPattern({ paymentSessionId, paramsMap, afterRedirectScriptFlag, is3DSRedirect, }) {
        // Handle 3DS redirect return
        if (is3DSRedirect) {
            this.isHostedFieldPattern = true;
            return this.opfPaymentVerificationService.run3DSRedirectPattern(paymentSessionId, paramsMap, this.vcr);
        }
        if (afterRedirectScriptFlag === 'true') {
            this.isHostedFieldPattern = true;
            return this.opfPaymentVerificationService.runHostedFieldsPattern(paymentSessionId, this.vcr, paramsMap);
        }
        else {
            return this.opfPaymentVerificationService.runHostedPagePattern(paymentSessionId, paramsMap);
        }
    }
    onError(error) {
        this.opfPaymentVerificationService.displayError(error);
        this.opfPaymentVerificationService.clearPaymentSessionForReinitiation();
        this.opfPaymentVerificationService.goToPage(OpfPage.CHECKOUT_REVIEW_PAGE);
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
        if (this.isHostedFieldPattern) {
            this.opfPaymentVerificationService.removeResourcesAndGlobalFunctions();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentVerificationComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: OpfPaymentVerificationComponent, isStandalone: true, selector: "cx-opf-verify-payment", ngImport: i0, template: "<div class=\"cx-spinner\">\n  <cx-spinner></cx-spinner>\n</div>\n", dependencies: [{ kind: "component", type: SpinnerComponent, selector: "cx-spinner" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentVerificationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-verify-payment', imports: [SpinnerComponent], template: "<div class=\"cx-spinner\">\n  <cx-spinner></cx-spinner>\n</div>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfPaymentVerificationModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentVerificationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentVerificationModule, imports: [CommonModule, SpinnerModule, OpfPaymentVerificationComponent], exports: [OpfPaymentVerificationComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentVerificationModule, imports: [CommonModule, SpinnerModule, OpfPaymentVerificationComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentVerificationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, SpinnerModule, OpfPaymentVerificationComponent],
                    exports: [OpfPaymentVerificationComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfPaymentMethodDetailsComponent {
    constructor() {
        this.translationService = inject(TranslationService);
        this.destroyRef = inject(DestroyRef);
        this.featureToggles = inject(FeatureToggles);
        this.orderOutlet = inject(OutletContextData);
        this.opfCheckoutOutlets = OpfCheckoutOutlets;
        this.subscription = new Subscription();
    }
    ngOnInit() {
        if (this.orderOutlet?.context$) {
            if (this.featureToggles.opfUseDestroyRef) {
                this.orderOutlet.context$
                    .pipe(takeUntilDestroyed(this.destroyRef))
                    .subscribe((context) => (this.order = context?.item));
            }
            else {
                this.subscription.add(this.orderOutlet.context$.subscribe((context) => (this.order = context?.item)));
            }
        }
    }
    getPaymentMethodDetailsCardContent(paymentMethodDetails) {
        return this.translationService.translate('opfCheckout.paymentOption').pipe(filter$1(() => Boolean(paymentMethodDetails?.name)), map$1((translatedTitle) => {
            return {
                title: translatedTitle,
                text: [paymentMethodDetails?.name],
            };
        }));
    }
    isPaymentMethodDetailsInfoPresent(order) {
        return Boolean(order?.paymentInfo?.sapPaymentMethod?.name);
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentMethodDetailsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: OpfPaymentMethodDetailsComponent, isStandalone: true, selector: "cx-opf-payment-method-details", ngImport: i0, template: "<ng-container *ngIf=\"isPaymentMethodDetailsInfoPresent(order)\">\n  <cx-card\n    *ngIf=\"order.paymentInfo\"\n    [content]=\"\n      getPaymentMethodDetailsCardContent(order.paymentInfo.sapPaymentMethod)\n        | async\n    \"\n  ></cx-card>\n</ng-container>\n<ng-template\n  [cxOutlet]=\"opfCheckoutOutlets.ORDER_DETAILS_AFTER_PAYMENT_OPTIONS\"\n  [cxOutletContext]=\"order\"\n>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CardComponent, selector: "cx-card", inputs: ["border", "editMode", "isDefault", "content", "fitToContainer", "truncateText", "truncateParagraphText", "charactersLimit", "index", "role"], outputs: ["deleteCard", "setDefaultCard", "sendCard", "editCard", "cancelCard"] }, { kind: "ngmodule", type: OutletModule }, { kind: "directive", type: i1.OutletDirective, selector: "[cxOutlet]", inputs: ["cxOutlet", "cxOutletContext", "cxOutletDefer", "cxComponentRef"], outputs: ["loaded", "cxComponentRefChange"] }, { kind: "pipe", type: AsyncPipe, name: "async" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentMethodDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-payment-method-details', imports: [NgIf, CardComponent, AsyncPipe, OutletModule], template: "<ng-container *ngIf=\"isPaymentMethodDetailsInfoPresent(order)\">\n  <cx-card\n    *ngIf=\"order.paymentInfo\"\n    [content]=\"\n      getPaymentMethodDetailsCardContent(order.paymentInfo.sapPaymentMethod)\n        | async\n    \"\n  ></cx-card>\n</ng-container>\n<ng-template\n  [cxOutlet]=\"opfCheckoutOutlets.ORDER_DETAILS_AFTER_PAYMENT_OPTIONS\"\n  [cxOutletContext]=\"order\"\n>\n</ng-template>\n" }]
        }], propDecorators: { orderOutlet: [{
                type: Optional
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfPaymentMethodDetailsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentMethodDetailsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentMethodDetailsModule, imports: [CommonModule, CardModule, OpfPaymentMethodDetailsComponent], exports: [OpfPaymentMethodDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentMethodDetailsModule, providers: [
            provideOutlet({
                id: CartOutlets.ORDER_OVERVIEW,
                position: OutletPosition.BEFORE,
                component: OpfPaymentMethodDetailsComponent,
            }),
        ], imports: [CommonModule, CardModule, OpfPaymentMethodDetailsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentMethodDetailsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, CardModule, OpfPaymentMethodDetailsComponent],
                    exports: [OpfPaymentMethodDetailsComponent],
                    providers: [
                        provideOutlet({
                            id: CartOutlets.ORDER_OVERVIEW,
                            position: OutletPosition.BEFORE,
                            component: OpfPaymentMethodDetailsComponent,
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfPaymentRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentRootModule, imports: [OpfPaymentMethodDetailsModule, i1$1.RouterModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentRootModule, providers: [
            provideDefaultConfig(defaultOpfPaymentRoutingConfig),
            provideLocationInitializerFactory(() => {
                // convert incorrect type `() => void` to `() => Promise<void>`
                const locationInitializer = captureOpfPaymentVerificationQueryFactory();
                return () => Promise.resolve(locationInitializer());
            }),
        ], imports: [OpfPaymentMethodDetailsModule,
            RouterModule.forChild([
                {
                    // @ts-ignore
                    path: null,
                    component: OpfPaymentVerificationComponent,
                    data: {
                        cxRoute: 'paymentVerificationResult',
                    },
                },
                {
                    // @ts-ignore
                    path: null,
                    component: OpfPaymentVerificationComponent,
                    data: {
                        cxRoute: 'paymentVerificationCancel',
                    },
                },
            ])] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentRootModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        OpfPaymentMethodDetailsModule,
                        RouterModule.forChild([
                            {
                                // @ts-ignore
                                path: null,
                                component: OpfPaymentVerificationComponent,
                                data: {
                                    cxRoute: 'paymentVerificationResult',
                                },
                            },
                            {
                                // @ts-ignore
                                path: null,
                                component: OpfPaymentVerificationComponent,
                                data: {
                                    cxRoute: 'paymentVerificationCancel',
                                },
                            },
                        ]),
                    ],
                    providers: [
                        provideDefaultConfig(defaultOpfPaymentRoutingConfig),
                        provideLocationInitializerFactory(() => {
                            // convert incorrect type `() => void` to `() => Promise<void>`
                            const locationInitializer = captureOpfPaymentVerificationQueryFactory();
                            return () => Promise.resolve(locationInitializer());
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OPF_PAYMENT_FEATURE, OpfPaymentChannel, OpfPaymentErrorType, OpfPaymentEventsService, OpfPaymentFacade, OpfPaymentMethod, OpfPaymentMethodDetailsComponent, OpfPaymentMethodDetailsModule, OpfPaymentRenderPattern, OpfPaymentRootModule, OpfPaymentSubmitStatus, OpfPaymentVerificationComponent, OpfPaymentVerificationModule, OpfPaymentVerificationResult, OpfPaymentVerificationService, OpfPaymentVerificationUrlInput, captureOpfPaymentVerificationQueryFactory, defaultOpfPaymentRoutingConfig, opfDefaultPaymentError };
//# sourceMappingURL=spartacus-opf-payment-root.mjs.map
