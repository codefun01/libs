import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { LoggerService, OccEndpointsService, tryNormalizeHttpError, backOff, isJaloError, provideDefaultConfig } from '@spartacus/core';
import { OccCartAdapter } from '@spartacus/cart/base/occ';
import { catchError } from 'rxjs/operators';
import { OpfGiftCardAdapter } from '@spartacus/opf/gift-card/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccOpfGiftCardAdapter extends OccCartAdapter {
    constructor() {
        super(...arguments);
        this.logger = inject(LoggerService);
        this.occEndpoints = inject(OccEndpointsService);
        this.http = inject(HttpClient);
        this.headers = new HttpHeaders({
            'Content-Type': 'application/json',
        });
    }
    applyGiftCard(userId, cartId, request) {
        return this.http
            .post(this.getApplyGiftCardEndpoint(userId, cartId), request, { headers: this.headers })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({ shouldRetry: isJaloError }));
    }
    removeGiftCard(userId, cartId, giftCardId) {
        const url = this.getRemoveGiftCardEndpoint(userId, cartId, giftCardId);
        return this.http.delete(url).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({ shouldRetry: isJaloError }));
    }
    getApplyGiftCardEndpoint(userId, cartId) {
        return this.occEndpoints.buildUrl('applyGiftCard', {
            urlParams: { userId, cartId },
        });
    }
    getRemoveGiftCardEndpoint(userId, cartId, giftCardId) {
        return this.occEndpoints.buildUrl('removeGiftCard', {
            urlParams: { userId, cartId, giftCardId },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccOpfGiftCardAdapter, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccOpfGiftCardAdapter, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccOpfGiftCardAdapter, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultGiftCardOccEndpointsConfig = {
    backend: {
        occ: {
            endpoints: {
                applyGiftCard: 'users/${userId}/carts/${cartId}/giftCards',
                removeGiftCard: 'users/${userId}/carts/${cartId}/giftCards/${giftCardId}',
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardOccModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGiftCardOccModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfGiftCardOccModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGiftCardOccModule, providers: [
            {
                provide: OpfGiftCardAdapter,
                useClass: OccOpfGiftCardAdapter,
            },
            provideDefaultConfig(defaultGiftCardOccEndpointsConfig),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGiftCardOccModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        {
                            provide: OpfGiftCardAdapter,
                            useClass: OccOpfGiftCardAdapter,
                        },
                        provideDefaultConfig(defaultGiftCardOccEndpointsConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OccOpfGiftCardAdapter, OpfGiftCardOccModule, defaultGiftCardOccEndpointsConfig };
//# sourceMappingURL=spartacus-opf-gift-card-occ.mjs.map
