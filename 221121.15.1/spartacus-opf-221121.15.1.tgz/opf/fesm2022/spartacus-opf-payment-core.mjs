import * as i0 from '@angular/core';
import { InjectionToken, inject, Injectable, NgModule } from '@angular/core';
import { GlobalMessageService, RoutingService, GlobalMessageType, HttpResponseStatus, WindowRef, UserIdService, backOff, DEFAULT_AUTHORIZATION_ERROR_RETRIES_COUNT, isAuthorizationError, QueryService, CommandService } from '@spartacus/core';
import { CartAccessCodeFacade, ActiveCartFacade } from '@spartacus/cart/base/root';
import { OrderFacade } from '@spartacus/order/root';
import { throwError, from, EMPTY, combineLatest, of } from 'rxjs';
import { concatMap, tap, map, catchError, switchMap } from 'rxjs/operators';
import { opfDefaultPaymentError, OpfPaymentErrorType, OpfPaymentChannel, OpfPaymentMethod, OpfPaymentSubmitStatus, OpfPaymentFacade } from '@spartacus/opf/payment/root';
import { OpfGlobalFunctionsFacade } from '@spartacus/opf/global-functions/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_PAYMENT_CONFIG_SERIALIZER = new InjectionToken('OpfPaymentConfigSerializer');

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfPaymentAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Connector that facilitates communication between Spartacus Storefront and the OPF Commerce Cloud Adapter.
 * Handles payment session management, payment request submission, and payment flow orchestration
 * including redirects and verification processes required by the OPF payment system.
 */
class OpfPaymentConnector {
    constructor() {
        this.adapter = inject(OpfPaymentAdapter);
    }
    verifyPayment(paymentSessionId, payload) {
        return this.adapter.verifyPayment(paymentSessionId, payload);
    }
    submitPayment(submitRequest, otpKey, paymentSessionId) {
        return this.adapter.submitPayment(submitRequest, otpKey, paymentSessionId);
    }
    submitCompletePayment(submitCompleteRequest, otpKey, paymentSessionId) {
        return this.adapter.submitCompletePayment(submitCompleteRequest, otpKey, paymentSessionId);
    }
    getAfterRedirectScripts(paymentSessionId) {
        return this.adapter.getAfterRedirectScripts(paymentSessionId);
    }
    initiatePayment(paymentConfig) {
        return this.adapter.initiatePayment(paymentConfig);
    }
    updatePaymentTransaction(updatePaymentConfig) {
        return this.adapter.updatePaymentTransaction(updatePaymentConfig);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfPaymentOccAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * This connector communicates with the OCC layer
 * to perform payment-related operations for a cart in SAP Commerce.
 * It acts as a bridge between Spartacus frontend and the backend OCC API
 * specifically for setting payment options on a cart.
 */
class OpfPaymentOccConnector {
    constructor() {
        this.adapter = inject(OpfPaymentOccAdapter);
    }
    setCartPaymentOption(userId, cartId, sapPaymentOptionId, purchaseOrderNumber) {
        return this.adapter.setCartPaymentOption(userId, cartId, sapPaymentOptionId, purchaseOrderNumber);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentOccConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentOccConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentOccConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfPaymentErrorHandlerService {
    constructor() {
        this.globalMessageService = inject(GlobalMessageService);
        this.routingService = inject(RoutingService);
    }
    displayError(error) {
        this.globalMessageService.add({
            key: error?.message ? error.message : opfDefaultPaymentError.message,
        }, GlobalMessageType.MSG_TYPE_ERROR);
    }
    handleBadRequestError(errorType) {
        let message = opfDefaultPaymentError.message;
        switch (errorType) {
            case OpfPaymentErrorType.EXPIRED:
                message = 'opfPayment.errors.cardExpired';
                break;
            case OpfPaymentErrorType.INSUFFICIENT_FUNDS:
            case OpfPaymentErrorType.CREDIT_LIMIT:
                message = 'opfPayment.errors.insufficientFunds';
                break;
            case OpfPaymentErrorType.INVALID_CARD:
            case OpfPaymentErrorType.INVALID_CVV:
                message = 'opfPayment.errors.invalidCreditCard';
                break;
            case OpfPaymentErrorType.LOST_CARD:
                message = 'opfPayment.errors.cardReportedLost';
                break;
        }
        return message;
    }
    handlePaymentError(error, returnPath, onFailureCallback) {
        let message = opfDefaultPaymentError.message;
        if (error?.status === HttpResponseStatus.BAD_REQUEST) {
            message = this.handleBadRequestError(error?.type);
        }
        else {
            if (error?.type === OpfPaymentErrorType.PAYMENT_CANCELLED) {
                message = 'opfPayment.errors.cancelPayment';
            }
        }
        this.displayError(error ? { ...error, message } : undefined);
        if (onFailureCallback) {
            onFailureCallback(error);
        }
        if (returnPath?.length) {
            this.routingService.go({ cxRoute: returnPath });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentErrorHandlerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentErrorHandlerService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentErrorHandlerService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
function getBrowserInfo(nativeWindow) {
    return {
        acceptHeader: 'application/json',
        colorDepth: nativeWindow?.screen?.colorDepth,
        javaEnabled: false,
        javaScriptEnabled: true,
        language: nativeWindow?.navigator?.language,
        screenHeight: nativeWindow?.screen?.height,
        screenWidth: nativeWindow?.screen?.width,
        userAgent: nativeWindow?.navigator?.userAgent,
        originUrl: nativeWindow?.location?.origin,
        timeZoneOffset: new Date().getTimezoneOffset(),
    };
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfPaymentHostedFieldsService {
    constructor() {
        this.opfPaymentConnector = inject(OpfPaymentConnector);
        this.winRef = inject(WindowRef);
        this.cartAccessCodeFacade = inject(CartAccessCodeFacade);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.userIdService = inject(UserIdService);
        this.routingService = inject(RoutingService);
        this.orderFacade = inject(OrderFacade);
        this.globalMessageService = inject(GlobalMessageService);
        this.opfPaymentErrorHandlerService = inject(OpfPaymentErrorHandlerService);
        this.globalFunctionsFacade = inject(OpfGlobalFunctionsFacade);
    }
    submitPayment(submitInput) {
        const { paymentMethod, additionalData, paymentSessionId, returnPath, encryptedToken, savePaymentMethod, } = submitInput;
        const submitRequest = {
            paymentMethod,
            additionalData,
            channel: OpfPaymentChannel.BROWSER,
            browserInfo: getBrowserInfo(this.winRef.nativeWindow),
            savePaymentMethod,
        };
        if (paymentMethod !== OpfPaymentMethod.CREDIT_CARD) {
            submitRequest.encryptedToken = '';
        }
        if (encryptedToken) {
            submitRequest.encryptedToken = encryptedToken;
        }
        return this.getCartAccessCode(submitRequest).pipe(concatMap(([request, { accessCode: otpKey }]) => this.opfPaymentConnector.submitPayment(request, otpKey, paymentSessionId)), concatMap((response) => this.paymentResponseHandler(response, submitInput.callbacks)), tap((order) => {
            if (order) {
                this.routingService.go({ cxRoute: 'orderConfirmation' });
            }
        }), map((order) => (order ? true : false)), catchError((error) => {
            this.opfPaymentErrorHandlerService.handlePaymentError(error, returnPath, submitInput?.callbacks?.onFailure);
            return throwError(() => error);
        }), backOff({
            /**
             * We should retry this sequence only if the error is an authorization error.
             * It means that `accessCode` (OTP signature) is not valid or expired and we need to refresh it.
             */
            shouldRetry: isAuthorizationError,
            maxTries: DEFAULT_AUTHORIZATION_ERROR_RETRIES_COUNT,
        }));
    }
    submitCompletePayment(submitCompleteInput) {
        const { additionalData, paymentSessionId, returnPath } = submitCompleteInput;
        const submitCompleteRequest = {
            additionalData,
            paymentSessionId,
        };
        return this.getCartAccessCode(submitCompleteRequest).pipe(concatMap(([request, { accessCode: otpKey }]) => this.opfPaymentConnector.submitCompletePayment(request, otpKey, paymentSessionId)), concatMap((response) => this.paymentResponseHandler(response, submitCompleteInput.callbacks)), tap((order) => {
            if (order) {
                this.routingService.go({ cxRoute: 'orderConfirmation' });
            }
        }), map((order) => (order ? true : false)), catchError((error) => {
            this.opfPaymentErrorHandlerService.handlePaymentError(error, returnPath, submitCompleteInput?.callbacks?.onFailure);
            return throwError(() => error);
        }), backOff({
            /**
             * We should retry this sequence only if the error is an authorization error.
             * It means that `accessCode` (OTP signature) is not valid or expired and we need to refresh it.
             */
            shouldRetry: isAuthorizationError,
            maxTries: DEFAULT_AUTHORIZATION_ERROR_RETRIES_COUNT,
        }));
    }
    paymentResponseHandler(response, callbacks) {
        if (response.status === OpfPaymentSubmitStatus.ACCEPTED ||
            response.status === OpfPaymentSubmitStatus.DELAYED) {
            return from(Promise.resolve(callbacks.onSuccess(response))).pipe(concatMap(() => this.orderFacade.placePaymentAuthorizedOrder(true)));
        }
        else if (callbacks?.onCancel &&
            response.status === OpfPaymentSubmitStatus.CANCELLED) {
            return from(Promise.resolve(callbacks.onCancel(response))).pipe(concatMap(() => EMPTY));
        }
        else if (response.status === OpfPaymentSubmitStatus.PENDING) {
            return from(Promise.resolve(callbacks.onPending(response))).pipe(concatMap(() => EMPTY));
        }
        else if (response.status === OpfPaymentSubmitStatus.REJECTED) {
            return from(Promise.resolve(callbacks.onFailure(response))).pipe(concatMap(() => throwError(() => ({
                ...opfDefaultPaymentError,
                type: OpfPaymentErrorType.PAYMENT_REJECTED,
            }))));
        }
        else {
            return from(Promise.resolve(callbacks.onFailure(response))).pipe(concatMap(() => throwError(() => ({
                ...opfDefaultPaymentError,
                type: OpfPaymentErrorType.STATUS_NOT_RECOGNIZED,
            }))));
        }
    }
    getCartAccessCode(submitRequest) {
        return combineLatest([
            this.userIdService.takeUserId(),
            this.activeCartFacade.takeActiveCartId(),
        ]).pipe(switchMap(([userId, activeCartId]) => {
            return combineLatest([
                of(submitRequest),
                this.cartAccessCodeFacade.getCartAccessCode(userId, activeCartId),
            ]);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentHostedFieldsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentHostedFieldsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentHostedFieldsService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfPaymentService {
    constructor() {
        this.queryService = inject(QueryService);
        this.commandService = inject(CommandService);
        this.opfPaymentConnector = inject(OpfPaymentConnector);
        this.opfPaymentOccConnector = inject(OpfPaymentOccConnector);
        this.opfPaymentHostedFieldsService = inject(OpfPaymentHostedFieldsService);
        this.verifyPaymentCommand = this.commandService.create((payload) => this.opfPaymentConnector.verifyPayment(payload.paymentSessionId, payload.paymentVerificationPayload));
        this.submitPaymentCommand = this.commandService.create((payload) => {
            return this.opfPaymentHostedFieldsService.submitPayment(payload.submitInput);
        });
        this.submitCompletePaymentCommand = this.commandService.create((payload) => {
            return this.opfPaymentHostedFieldsService.submitCompletePayment(payload.submitCompleteInput);
        });
        this.getAfterRedirectScriptsCommand = this.commandService.create((payload) => {
            return this.opfPaymentConnector.getAfterRedirectScripts(payload.paymentSessionId);
        });
        this.initiatePaymentCommand = this.commandService.create((payload) => this.opfPaymentConnector.initiatePayment(payload.paymentConfig));
        this.updatePaymentTransactionCommand = this.commandService.create((payload) => this.opfPaymentConnector.updatePaymentTransaction(payload.updatePaymentConfig));
        this.setCartPaymentOptionCommand = this.commandService.create((payload) => this.opfPaymentOccConnector.setCartPaymentOption(payload.userId, payload.cartId, payload.sapPaymentOptionId, payload.purchaseOrderNumber));
    }
    verifyPayment(paymentSessionId, paymentVerificationPayload) {
        return this.verifyPaymentCommand.execute({
            paymentSessionId,
            paymentVerificationPayload,
        });
    }
    submitPayment(submitInput) {
        return this.submitPaymentCommand.execute({
            submitInput,
        });
    }
    submitCompletePayment(submitCompleteInput) {
        return this.submitCompletePaymentCommand.execute({ submitCompleteInput });
    }
    getAfterRedirectScripts(paymentSessionId) {
        return this.getAfterRedirectScriptsCommand.execute({ paymentSessionId });
    }
    initiatePayment(paymentConfig) {
        return this.initiatePaymentCommand.execute({ paymentConfig });
    }
    updatePaymentTransaction(updatePaymentConfig) {
        return this.updatePaymentTransactionCommand.execute({
            updatePaymentConfig,
        });
    }
    setCartPaymentOption(userId, cartId, sapPaymentOptionId, purchaseOrderNumber) {
        return this.setCartPaymentOptionCommand.execute({
            userId,
            cartId,
            sapPaymentOptionId,
            purchaseOrderNumber,
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const facadeProviders = [
    OpfPaymentService,
    OpfPaymentHostedFieldsService,
    {
        provide: OpfPaymentFacade,
        useExisting: OpfPaymentService,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfPaymentCoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentCoreModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentCoreModule, providers: [...facadeProviders, OpfPaymentConnector, OpfPaymentOccConnector] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfPaymentCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    providers: [...facadeProviders, OpfPaymentConnector, OpfPaymentOccConnector],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_PAYMENT_VERIFICATION_NORMALIZER = new InjectionToken('OpfPaymentVerificationNormalizer');
const OPF_PAYMENT_SUBMIT_NORMALIZER = new InjectionToken('OpfPaymentSubmitNormalizer');
const OPF_PAYMENT_SUBMIT_COMPLETE_NORMALIZER = new InjectionToken('OpfPaymentSubmitCompleteNormalizer');
const OPF_AFTER_REDIRECT_SCRIPTS_NORMALIZER = new InjectionToken('OpfAfterRedirectScriptsNormalizer');

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OPF_AFTER_REDIRECT_SCRIPTS_NORMALIZER, OPF_PAYMENT_CONFIG_SERIALIZER, OPF_PAYMENT_SUBMIT_COMPLETE_NORMALIZER, OPF_PAYMENT_SUBMIT_NORMALIZER, OPF_PAYMENT_VERIFICATION_NORMALIZER, OpfPaymentAdapter, OpfPaymentConnector, OpfPaymentCoreModule, OpfPaymentErrorHandlerService, OpfPaymentHostedFieldsService, OpfPaymentOccAdapter, OpfPaymentOccConnector, OpfPaymentService, getBrowserInfo };
//# sourceMappingURL=spartacus-opf-payment-core.mjs.map
