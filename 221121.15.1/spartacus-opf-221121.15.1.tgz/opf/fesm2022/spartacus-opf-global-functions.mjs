import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { OpfGlobalFunctionsCoreModule } from '@spartacus/opf/global-functions/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGlobalFunctionsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsModule, imports: [OpfGlobalFunctionsCoreModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsModule, imports: [OpfGlobalFunctionsCoreModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGlobalFunctionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OpfGlobalFunctionsCoreModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfGlobalFunctionsModule };
//# sourceMappingURL=spartacus-opf-global-functions.mjs.map
