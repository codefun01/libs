import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { ConverterService, LoggerService, tryNormalizeHttpError, backOff, isServerError, provideDefaultConfig } from '@spartacus/core';
import { OPF_CTA_SCRIPTS_NORMALIZER, OpfCtaAdapter } from '@spartacus/opf/cta/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { OpfEndpointsService } from '@spartacus/opf/base/core';
import { OpfMetadataStatePersistanceService, OpfConfig, OPF_CC_PUBLIC_KEY_HEADER } from '@spartacus/opf/base/root';
import { catchError } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfApiCtaAdapter {
    constructor() {
        this.http = inject(HttpClient);
        this.converter = inject(ConverterService);
        this.opfEndpointsService = inject(OpfEndpointsService);
        this.opfMetadataStatePersistanceService = inject(OpfMetadataStatePersistanceService);
        this.config = inject(OpfConfig);
        this.logger = inject(LoggerService);
        this.headerWithNoLanguage = {
            accept: 'application/json',
            'Content-Type': 'application/json',
        };
        this.header = {
            ...this.headerWithNoLanguage,
            'Accept-Language': this.opfMetadataStatePersistanceService.getActiveLanguage(),
        };
        this.headerWithContentLanguage = {
            ...this.headerWithNoLanguage,
            'Content-Language': this.opfMetadataStatePersistanceService.getActiveLanguage(),
        };
    }
    getCtaScripts(opfCtaScriptsRequest) {
        const headers = new HttpHeaders(this.header).set(OPF_CC_PUBLIC_KEY_HEADER, this.config.opf?.commerceCloudPublicKey || '');
        const url = this.getCtaScriptsEndpoint();
        return this.http
            .post(url, opfCtaScriptsRequest, { headers })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({
            shouldRetry: isServerError,
            maxTries: 2,
        }), this.converter.pipeable(OPF_CTA_SCRIPTS_NORMALIZER));
    }
    getCtaScriptsEndpoint() {
        return this.opfEndpointsService.buildUrl('getCtaScripts');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfApiCtaAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfApiCtaAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfApiCtaAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOpfApiCtaConfig = {
    backend: {
        opfApi: {
            endpoints: {
                getCtaScripts: 'payments/cta-scripts-rendering',
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfApiCtaModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfApiCtaModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfApiCtaModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfApiCtaModule, providers: [
            provideDefaultConfig(defaultOpfApiCtaConfig),
            {
                provide: OpfCtaAdapter,
                useClass: OpfApiCtaAdapter,
            },
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfApiCtaModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [
                        provideDefaultConfig(defaultOpfApiCtaConfig),
                        {
                            provide: OpfCtaAdapter,
                            useClass: OpfApiCtaAdapter,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfApiCtaModule };
//# sourceMappingURL=spartacus-opf-cta-opf-api.mjs.map
