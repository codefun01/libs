import * as i0 from '@angular/core';
import { inject, Injectable, Input, ChangeDetectionStrategy, Component, NgModule, ChangeDetectorRef, ViewChild } from '@angular/core';
import { NgIf, AsyncPipe, CommonModule } from '@angular/common';
import { WindowRef, AuthService, UserIdService, provideDefaultConfig } from '@spartacus/core';
import { OpfQuickBuyTransactionService } from '@spartacus/opf/quick-buy/core';
import { ApplePayEvent, ApplePayShippingType, OpfQuickBuyFacade, OpfQuickBuyConfig, OpfQuickBuyDeliveryType, OPF_QUICK_BUY_DEFAULT_MERCHANT_NAME, OpfQuickBuyLocation, OpfQuickBuyProviderType, OPF_GOOGLE_PAY_PROVIDER_NAME, OPF_QUICK_BUY_ADDRESS_FIELD_PLACEHOLDER } from '@spartacus/opf/quick-buy/root';
import { CurrentProductService } from '@spartacus/storefront';
import { take, switchMap, catchError, finalize, map, tap } from 'rxjs/operators';
import { of, from, Observable, throwError, forkJoin, lastValueFrom, BehaviorSubject } from 'rxjs';
import { OpfPaymentErrorType, OpfPaymentFacade } from '@spartacus/opf/payment/root';
import { OpfBaseFacade, OpfPaymentProviderType, OpfResourceLoaderService } from '@spartacus/opf/base/root';
import { CartGuestUserFacade, ActiveCartFacade, MultiCartFacade } from '@spartacus/cart/base/root';
import { CheckoutConfig } from '@spartacus/checkout/base/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/// <reference types="@types/applepayjs" />
/**
 * Wrapper of the native `ApplePaySession` API.
 *
 * It can tell whether the native `ApplePaySession` is supported,
 * create a new instance of `ApplePaySession` object (for starting a new payment process),
 * or expose some of the static constants of the native `ApplePaySession` API.
 */
class ApplePaySessionWrapperService {
    initialize() {
        // @ts-ignore
        this.applePaySession = this.getApplePaySession();
        if (this.applePaySession) {
            this.isDeviceSupported = this.applePaySession.canMakePayments();
        }
    }
    constructor() {
        this.winRef = inject(WindowRef);
        this.isDeviceSupported = false;
        this.applePayApiVersion = 3;
        this.initialize();
    }
    getApplePaySession() {
        const window = this.winRef.nativeWindow;
        if (!window['ApplePaySession']) {
            return undefined;
        }
        return window['ApplePaySession'];
    }
    get statusSuccess() {
        return this.isDeviceSupported ? this.applePaySession.STATUS_SUCCESS : 1;
    }
    get statusFailure() {
        return this.isDeviceSupported ? this.applePaySession.STATUS_FAILURE : 1;
    }
    isApplePaySupported(merchantIdentifier) {
        return this.isDeviceSupported &&
            this.supportsVersion(this.applePayApiVersion)
            ? this.canMakePaymentsWithActiveCard(merchantIdentifier)
            : of(false);
    }
    supportsVersion(version) {
        try {
            return (this.isDeviceSupported && this.applePaySession.supportsVersion(version));
        }
        catch (err) {
            return false;
        }
    }
    canMakePayments() {
        try {
            return this.isDeviceSupported && this.applePaySession.canMakePayments();
        }
        catch (err) {
            return false;
        }
    }
    canMakePaymentsWithActiveCard(merchantId) {
        return this.isDeviceSupported
            ? from(this.applePaySession.canMakePaymentsWithActiveCard(merchantId))
            : of(false);
    }
    /**
     * Creates and returns a new instance of `ApplePaySession` object (for a new payment process).
     */
    createSession(paymentRequest) {
        return this.isDeviceSupported
            ? new this.applePaySession(this.applePayApiVersion, paymentRequest)
            : undefined;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ApplePaySessionWrapperService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ApplePaySessionWrapperService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ApplePaySessionWrapperService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/// <reference types="@types/applepayjs" />
/**
 * Orchestrates a payment process using the native `ApplePaySession` API.
 */
class ApplePaySessionOrchestrator {
    constructor() {
        this.applePaySessionWrapperService = inject(ApplePaySessionWrapperService);
    }
    /**
     * Starts a new payment process using the native `ApplePaySession` API
     *
     * It creates a new `ApplePaySession` instance and binds the provided
     * handlers (callbacks) for the `ApplePaySession` instance events.
     *
     * It returns an Observable that:
     * a) emits the payment result. Then the observable is immediately completed.
     * b) OR emits an RxJS error if any error occurs during the process
     *    (e.g. a merchant validation fails, the user cancels the payment, etc.)
     */
    start(config) {
        return new Observable((observer) => {
            let session;
            try {
                session = this.applePaySessionWrapperService.createSession(config.request);
            }
            catch (err) {
                observer.error(err);
                return;
            }
            const handleUnspecifiedError = (error) => {
                session.abort();
                observer.error(error);
            };
            session.addEventListener(ApplePayEvent.VALIDATE_MERCHANT, (event) => {
                config
                    .onValidateMerchant(event)
                    .pipe(take(1))
                    .subscribe({
                    next: (merchantSession) => {
                        session.completeMerchantValidation(merchantSession);
                    },
                    error: handleUnspecifiedError,
                });
            });
            session.addEventListener(ApplePayEvent.CANCEL, () => {
                observer.error({ type: OpfPaymentErrorType.PAYMENT_CANCELLED });
            });
            if (config.onPaymentMethodSelected) {
                session.addEventListener(ApplePayEvent.PAYMENT_METHOD_SELECTED, (event) => {
                    config
                        .onPaymentMethodSelected(event)
                        .pipe(take(1))
                        .subscribe({
                        next: (paymentMethodUpdate) => {
                            session.completePaymentMethodSelection(paymentMethodUpdate);
                        },
                        error: handleUnspecifiedError,
                    });
                });
            }
            if (config.onShippingContactSelected &&
                !this.isShippingTypePickup(config)) {
                session.addEventListener(ApplePayEvent.SHIPPING_CONTACT_SELECTED, (event) => {
                    config
                        .onShippingContactSelected(event)
                        .pipe(take(1))
                        .subscribe({
                        next: (shippingContactUpdate) => {
                            session.completeShippingContactSelection(shippingContactUpdate);
                        },
                        error: handleUnspecifiedError,
                    });
                });
            }
            if (config.onShippingMethodSelected &&
                !this.isShippingTypePickup(config)) {
                session.addEventListener(ApplePayEvent.SHIPPING_METHOD_SELECTED, (event) => {
                    config
                        .onShippingMethodSelected(event)
                        .pipe(take(1))
                        .subscribe({
                        next: (shippingMethodUpdate) => {
                            session.completeShippingMethodSelection(shippingMethodUpdate);
                        },
                        error: handleUnspecifiedError,
                    });
                });
            }
            session.addEventListener(ApplePayEvent.PAYMENT_AUTHORIZED, (event) => {
                config
                    .onPaymentAuthorized(event)
                    .pipe(take(1))
                    .subscribe({
                    next: (authResult) => {
                        session.completePayment(authResult);
                        if (!authResult?.errors?.length) {
                            observer.next(authResult);
                            observer.complete();
                        }
                        else {
                            handleUnspecifiedError({
                                message: authResult?.errors[0]?.message,
                            });
                        }
                    },
                    error: handleUnspecifiedError,
                });
            });
            session.begin();
        });
    }
    isShippingTypePickup(config) {
        return config.request.shippingType === ApplePayShippingType.STORE_PICKUP;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ApplePaySessionOrchestrator, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ApplePaySessionOrchestrator, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ApplePaySessionOrchestrator, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/// <reference types="@types/applepayjs" />
class ApplePayService {
    constructor() {
        this.opfPaymentFacade = inject(OpfPaymentFacade);
        this.applePaySessionWrapperService = inject(ApplePaySessionWrapperService);
        this.applePaySessionOrchestrator = inject(ApplePaySessionOrchestrator);
        this.winRef = inject(WindowRef);
        this.opfQuickBuyTransactionService = inject(OpfQuickBuyTransactionService);
        this.opfQuickBuyFacade = inject(OpfQuickBuyFacade);
        this.opfQuickBuyConfig = inject(OpfQuickBuyConfig);
        this.paymentInProgress = false;
        this.defaultApplePayCardParameters = this.applePayProviderConfig.cardParameters;
        this.initialTransactionDetails = {
            context: OpfQuickBuyLocation.PRODUCT,
            product: undefined,
            cart: undefined,
            quantity: 0,
            addressIds: [],
            total: {
                label: OPF_QUICK_BUY_DEFAULT_MERCHANT_NAME,
                amount: '',
                currency: '',
            },
            deliveryInfo: {
                type: OpfQuickBuyDeliveryType.SHIPPING,
                pickupDetails: undefined,
            },
        };
        this.transactionDetails = this.initialTransactionDetails;
    }
    // default config guarantees providers.applePay is always present
    get applePayProviderConfig() {
        return this.opfQuickBuyConfig.providers
            ?.applePay;
    }
    initTransactionDetails(transactionInput) {
        this.transactionDetails = {
            ...this.initialTransactionDetails,
            addressIds: [],
        };
        if (transactionInput?.cart) {
            this.transactionDetails = {
                ...this.transactionDetails,
                context: OpfQuickBuyLocation.CART,
                cart: transactionInput.cart,
                total: {
                    amount: `${transactionInput.cart.totalPrice?.value}`,
                    label: `${transactionInput.cart.code}`,
                    currency: transactionInput.cart?.totalPrice?.currencyIso,
                },
            };
        }
        if (transactionInput?.product && transactionInput?.quantity) {
            const productPrice = transactionInput.product.price?.value;
            const totalPrice = productPrice * transactionInput.quantity;
            this.transactionDetails = {
                ...this.transactionDetails,
                context: OpfQuickBuyLocation.PRODUCT,
                product: transactionInput.product,
                quantity: transactionInput.quantity,
                total: {
                    amount: totalPrice.toString(),
                    label: `${transactionInput.product?.name}${transactionInput.quantity > 1
                        ? ` x ${transactionInput.quantity}`
                        : ''}`,
                    currency: transactionInput.product?.price?.currencyIso,
                },
            };
        }
        return this.transactionDetails;
    }
    start(transactionInput) {
        if (this.paymentInProgress) {
            return throwError(() => new Error('Apple Pay is already in progress'));
        }
        this.paymentInProgress = true;
        return this.setApplePayRequestConfig(transactionInput).pipe(switchMap((request) => {
            return this.applePaySessionOrchestrator.start({
                request,
                onValidateMerchant: (event) => this.handleValidation(event),
                onShippingContactSelected: (event) => this.handleShippingContactSelected(event),
                onPaymentMethodSelected: (event) => this.handlePaymentMethodSelected(event),
                onShippingMethodSelected: (event) => this.handleShippingMethodSelected(event),
                onPaymentAuthorized: (event) => this.handlePaymentAuthorized(event),
            });
        }), take(1), catchError((error) => throwError(() => error)), finalize(() => {
            this.deleteUserAddresses();
            this.paymentInProgress = false;
        }));
    }
    isApplePaySupported(merchantId) {
        return this.applePaySessionWrapperService.isApplePaySupported(merchantId);
    }
    deleteUserAddresses() {
        if (this.transactionDetails.addressIds.length) {
            this.opfQuickBuyTransactionService.deleteUserAddresses([
                ...this.transactionDetails.addressIds,
            ]);
            this.transactionDetails.addressIds = [];
        }
    }
    handleValidation(event) {
        return this.validateOpfAppleSession(event);
    }
    setApplePayRequestConfig(transactionInput) {
        this.transactionDetails = this.initTransactionDetails(transactionInput);
        const countryCode = transactionInput?.countryCode || '';
        const initialRequest = {
            ...this.defaultApplePayCardParameters,
            currencyCode: this.transactionDetails.total.currency,
            total: {
                amount: this.transactionDetails.total.amount,
                label: this.transactionDetails.total.label,
            },
            countryCode,
        };
        return forkJoin({
            deliveryInfo: this.opfQuickBuyTransactionService.getTransactionDeliveryInfo(),
            merchantName: this.opfQuickBuyTransactionService.getMerchantName(),
        }).pipe(switchMap(({ deliveryInfo, merchantName }) => {
            this.transactionDetails.total.label = merchantName;
            initialRequest.total.label = merchantName;
            this.transactionDetails.deliveryInfo = deliveryInfo;
            return of(undefined);
        }), map((opfQuickBuyDeliveryInfo) => {
            if (!opfQuickBuyDeliveryInfo) {
                return initialRequest;
            }
            this.transactionDetails.deliveryInfo = opfQuickBuyDeliveryInfo;
            return initialRequest;
        }));
    }
    validateOpfAppleSession(event) {
        return this.opfQuickBuyTransactionService.handleCartGuestUser().pipe(switchMap(() => {
            const verificationRequest = {
                validationUrl: event.validationURL,
                initiative: 'web',
                initiativeContext: (this.winRef?.nativeWindow).location
                    ?.hostname,
            };
            return this.verifyApplePaySession(verificationRequest);
        }));
    }
    convertAppleToOpfAddress(addr, partial = false) {
        const ADDRESS_FIELD_PLACEHOLDER = '[FIELD_NOT_SET]';
        return {
            firstName: partial ? ADDRESS_FIELD_PLACEHOLDER : addr?.givenName,
            lastName: partial ? ADDRESS_FIELD_PLACEHOLDER : addr?.familyName,
            line1: partial ? ADDRESS_FIELD_PLACEHOLDER : addr?.addressLines?.[0],
            line2: addr?.addressLines?.[1],
            email: addr?.emailAddress,
            town: addr?.locality,
            district: addr?.administrativeArea,
            postalCode: addr?.postalCode,
            phone: addr?.phoneNumber,
            country: {
                isocode: addr?.countryCode,
                name: addr?.country,
            },
            defaultAddress: false,
        };
    }
    handleShippingContactSelected(_event) {
        const partialAddress = this.convertAppleToOpfAddress(_event.shippingContact, true);
        const result = this.updateApplePayForm({ ...this.transactionDetails.total });
        return this.opfQuickBuyTransactionService
            .setDeliveryAddress(partialAddress)
            .pipe(tap((addrId) => {
            this.recordDeliveryAddress(addrId);
        }), switchMap(() => this.opfQuickBuyTransactionService.getSupportedDeliveryModes()), take(1), map((modes) => {
            if (!modes.length) {
                return of({
                    ...result,
                    errors: [
                        this.getApplePayFormWithError('No shipment methods available for this delivery address'),
                    ],
                });
            }
            const newShippingMethods = modes.map((mode) => {
                return {
                    identifier: mode.code,
                    label: mode.name,
                    amount: (mode.deliveryCost?.value).toFixed(2),
                    detail: mode.description ?? mode.name,
                };
            });
            result.newShippingMethods = newShippingMethods;
            return result;
        }), switchMap(() => {
            return this.opfQuickBuyTransactionService.getCurrentCartTotalPrice();
        }), switchMap((price) => {
            if (!price) {
                return throwError(() => new Error('Total Price not available'));
            }
            this.transactionDetails.total.amount = price.toString();
            result.newTotal.amount = price.toString();
            return of(result);
        }));
    }
    handlePaymentMethodSelected(_event) {
        const result = this.updateApplePayForm({ ...this.transactionDetails.total });
        return of(result);
    }
    handleShippingMethodSelected(_event) {
        const result = this.updateApplePayForm({ ...this.transactionDetails.total });
        return this.opfQuickBuyTransactionService
            .setDeliveryMode(_event.shippingMethod.identifier)
            .pipe(switchMap(() => this.opfQuickBuyTransactionService.getCurrentCart()), take(1), switchMap((cart) => {
            if (!cart?.totalPrice?.value) {
                return throwError(() => new Error('Total Price not available'));
            }
            result.newTotal.amount = cart.totalPrice.value.toString();
            this.transactionDetails.total.amount =
                cart.totalPrice.value.toString();
            return of(result);
        }));
    }
    handlePaymentAuthorized(event) {
        const result = {
            status: this.applePaySessionWrapperService.statusSuccess,
        };
        let orderSuccess;
        return this.placeOrderAfterPayment(event.payment).pipe(map((success) => {
            orderSuccess = success;
            return orderSuccess
                ? result
                : {
                    ...result,
                    status: this.applePaySessionWrapperService.statusFailure,
                };
        }), catchError((error) => {
            return of({
                ...result,
                status: this.applePaySessionWrapperService.statusFailure,
                errors: [
                    this.getApplePayFormWithError(error?.message ?? 'Payment error'),
                ],
            });
        }));
    }
    verifyApplePaySession(request) {
        return this.opfQuickBuyFacade.getApplePayWebSession(request);
    }
    recordDeliveryAddress(addrId) {
        if (!this.transactionDetails.addressIds?.includes(addrId)) {
            this.transactionDetails.addressIds?.push(addrId);
        }
    }
    placeOrderAfterPayment(applePayPayment) {
        if (!applePayPayment) {
            return of(false);
        }
        const { shippingContact, billingContact } = applePayPayment;
        if (!billingContact) {
            throw new Error('Error: empty billingContact');
        }
        if (this.transactionDetails.deliveryInfo?.type ===
            OpfQuickBuyDeliveryType.SHIPPING &&
            !shippingContact) {
            throw new Error('Error: empty shippingContact');
        }
        const deliveryTypeHandlingObservable = this.transactionDetails.deliveryInfo?.type ===
            OpfQuickBuyDeliveryType.PICKUP
            ? this.opfQuickBuyTransactionService
                .setDeliveryMode(OpfQuickBuyDeliveryType.PICKUP.toLocaleLowerCase())
                .pipe(switchMap(() => {
                return this.opfQuickBuyTransactionService.setBillingAddress(this.convertAppleToOpfAddress(billingContact));
            }))
            : this.opfQuickBuyTransactionService
                .setDeliveryAddress(this.convertAppleToOpfAddress(shippingContact))
                .pipe(tap((addrId) => {
                this.recordDeliveryAddress(addrId);
            }), switchMap(() => {
                return this.opfQuickBuyTransactionService.setBillingAddress(this.convertAppleToOpfAddress(billingContact));
            }));
        return deliveryTypeHandlingObservable.pipe(switchMap(() => {
            return shippingContact?.emailAddress
                ? this.opfQuickBuyTransactionService.updateCartGuestUserEmail(shippingContact.emailAddress)
                : of(true);
        }), switchMap(() => {
            const encryptedToken = btoa(JSON.stringify(applePayPayment.token.paymentData));
            return this.opfPaymentFacade.submitPayment({
                additionalData: [],
                paymentSessionId: '',
                callbacks: {
                    onSuccess: () => { },
                    onPending: () => { },
                    onFailure: () => { },
                },
                paymentMethod: OpfQuickBuyProviderType.APPLE_PAY,
                encryptedToken,
            });
        }));
    }
    updateApplePayForm(total) {
        return {
            newTotal: {
                amount: total.amount,
                label: total.label,
            },
        };
    }
    getApplePayFormWithError(message, code = 'unknown') {
        return {
            code,
            message,
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ApplePayService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ApplePayService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ApplePayService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ApplePayComponent {
    constructor() {
        this.applePayService = inject(ApplePayService);
        this.currentProductService = inject(CurrentProductService);
        this.opfQuickBuyTransactionService = inject(OpfQuickBuyTransactionService);
    }
    ngOnInit() {
        const activeConfigurations = Array.isArray(this.activeConfiguration)
            ? this.activeConfiguration
            : [this.activeConfiguration];
        this.applePayDigitalWallet = activeConfigurations
            ?.flatMap((config) => config.digitalWalletQuickBuy || [])
            .find((digitalWallet) => digitalWallet.provider === OpfQuickBuyProviderType.APPLE_PAY &&
            digitalWallet.enabled);
        if (!this.applePayDigitalWallet?.merchantId ||
            !this.applePayDigitalWallet?.countryCode) {
            return;
        }
        this.isApplePaySupported$ = this.applePayService.isApplePaySupported(this.applePayDigitalWallet.merchantId);
    }
    initActiveCartTransaction() {
        return this.opfQuickBuyTransactionService.getCurrentCart().pipe(take(1), switchMap((cart) => {
            return this.applePayService.start({
                cart: cart,
                countryCode: this.applePayDigitalWallet?.countryCode,
            });
        }));
    }
    initTransaction() {
        this.opfQuickBuyTransactionService
            .getTransactionLocationContext()
            .pipe(take(1), switchMap(() => {
            return this.initActiveCartTransaction();
        }))
            .subscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ApplePayComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: ApplePayComponent, isStandalone: true, selector: "cx-opf-apple-pay", inputs: { activeConfiguration: "activeConfiguration" }, ngImport: i0, template: "<ng-container *ngIf=\"isApplePaySupported$ | async\">\n  <div (click)=\"initTransaction()\" class=\"apple-pay-button\"></div>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ApplePayComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-apple-pay', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, AsyncPipe], template: "<ng-container *ngIf=\"isApplePaySupported$ | async\">\n  <div (click)=\"initTransaction()\" class=\"apple-pay-button\"></div>\n</ng-container>\n" }]
        }], propDecorators: { activeConfiguration: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfApplePayModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfApplePayModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfApplePayModule, imports: [CommonModule, ApplePayComponent], exports: [ApplePayComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfApplePayModule, imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfApplePayModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, ApplePayComponent],
                    exports: [ApplePayComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyButtonsService {
    constructor() {
        this.opfBaseFacade = inject(OpfBaseFacade);
        this.checkoutConfig = inject(CheckoutConfig);
        this.authService = inject(AuthService);
        this.userIdService = inject(UserIdService);
        this.cartGuestUserFacade = inject(CartGuestUserFacade);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.multiCartFacade = inject(MultiCartFacade);
    }
    getPaymentGatewayConfiguration() {
        return this.opfBaseFacade
            .getActiveConfigurationsState()
            .pipe(map((config) => (config?.data?.value || []).filter((item) => item?.providerType === OpfPaymentProviderType.PAYMENT_GATEWAY)));
    }
    getQuickBuyProviderConfig(provider, activeConfiguration) {
        const configs = this.normalizeConfigurations(activeConfiguration);
        return configs
            ?.flatMap((config) => config?.digitalWalletQuickBuy ?? [])
            .find((item) => item.provider === provider && item.enabled);
    }
    isQuickBuyProviderEnabled(provider, activeConfiguration) {
        return !!this.getQuickBuyProviderConfig(provider, activeConfiguration);
    }
    getActiveConfigurationForProvider(provider, activeConfiguration) {
        const configs = this.normalizeConfigurations(activeConfiguration);
        return configs?.find((config) => config?.digitalWalletQuickBuy?.some((item) => item.provider === provider && item.enabled));
    }
    /**
     * Normalizes ActiveConfiguration to always return an array.
     * Returns empty array if configurations are null/undefined.
     */
    normalizeConfigurations(activeConfiguration) {
        if (!activeConfiguration) {
            return undefined;
        }
        return Array.isArray(activeConfiguration)
            ? activeConfiguration
            : [activeConfiguration];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyButtonsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyButtonsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyButtonsService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/// <reference types="@types/googlepay" />
class OpfGooglePayService {
    constructor() {
        this.opfResourceLoaderService = inject(OpfResourceLoaderService);
        this.currentProductService = inject(CurrentProductService);
        this.opfPaymentFacade = inject(OpfPaymentFacade);
        this.opfQuickBuyTransactionService = inject(OpfQuickBuyTransactionService);
        this.opfQuickBuyButtonsService = inject(OpfQuickBuyButtonsService);
        this.opfQuickBuyConfig = inject(OpfQuickBuyConfig);
        this.googlePaymentClientOptions = {
            environment: this.googlePayProviderConfig.environment,
        };
        this.initialGooglePaymentRequest = this.googlePayProviderConfig
            .paymentRequest;
        this.defaultGooglePayCardParameters = this.googlePayProviderConfig.cardParameters;
        this.initialTransactionInfo = {
            totalPrice: '0.00',
            totalPriceStatus: 'ESTIMATED',
            currencyCode: 'USD',
        };
        this.initialTransactionDetails = {
            context: OpfQuickBuyLocation.PRODUCT,
            product: undefined,
            cart: undefined,
            quantity: 0,
            deliveryInfo: {
                type: OpfQuickBuyDeliveryType.SHIPPING,
                pickupDetails: undefined,
            },
            addressIds: [],
            total: {
                label: '',
                amount: '',
                currency: '',
            },
        };
        this.googlePaymentRequest = this.initialGooglePaymentRequest;
        this.transactionDetails = this.initialTransactionDetails;
    }
    // default config guarantees providers.googlePay is always present
    get googlePayProviderConfig() {
        return this.opfQuickBuyConfig.providers
            ?.googlePay;
    }
    updateGooglePaymentClient() {
        this.googlePaymentClient = new google.payments.api.PaymentsClient(this.googlePaymentClientOptions);
    }
    setGooglePaymentRequestConfig(deliveryType, merchantName) {
        if (deliveryType === OpfQuickBuyDeliveryType.PICKUP) {
            this.googlePaymentClientOptions = {
                ...this.googlePaymentClientOptions,
                paymentDataCallbacks: {
                    onPaymentAuthorized: this.handlePaymentCallbacks().onPaymentAuthorized,
                },
            };
            this.googlePaymentRequest = {
                ...this.initialGooglePaymentRequest,
                shippingAddressRequired: false,
                shippingOptionRequired: false,
                callbackIntents: ['PAYMENT_AUTHORIZATION'],
            };
        }
        else {
            this.googlePaymentClientOptions = {
                ...this.googlePaymentClientOptions,
                paymentDataCallbacks: this.handlePaymentCallbacks(),
            };
            this.googlePaymentRequest = this.initialGooglePaymentRequest;
        }
        this.googlePaymentRequest.merchantInfo.merchantName = merchantName;
        this.updateGooglePaymentClient();
    }
    loadResources() {
        const opfGooglePayConfig = this.opfQuickBuyConfig?.providers?.[OPF_GOOGLE_PAY_PROVIDER_NAME];
        if (!opfGooglePayConfig?.resourceUrl?.length) {
            return Promise.reject('Config not found');
        }
        return this.opfResourceLoaderService.loadResources([
            {
                url: opfGooglePayConfig.resourceUrl,
            },
        ]);
    }
    initClient(activeConfiguration) {
        const activeConfigurations = Array.isArray(activeConfiguration)
            ? activeConfiguration
            : [activeConfiguration];
        const googlePayGateway = this.opfQuickBuyButtonsService.getActiveConfigurationForProvider(OpfQuickBuyProviderType.GOOGLE_PAY, activeConfigurations);
        if (googlePayGateway) {
            this.setAllowedPaymentMethodsConfig(googlePayGateway);
        }
        this.updateGooglePaymentClient();
    }
    getClient() {
        return this.googlePaymentClient;
    }
    isReadyToPay() {
        return this.googlePaymentClient.isReadyToPay(this.googlePaymentRequest);
    }
    updateTransactionInfo(transactionInfo) {
        this.googlePaymentRequest.transactionInfo = transactionInfo;
    }
    getShippingOptionParameters() {
        return this.opfQuickBuyTransactionService.getSupportedDeliveryModes().pipe(take(1), map((modes) => {
            return {
                defaultSelectedOptionId: modes[0]?.code,
                shippingOptions: modes?.map((mode) => ({
                    id: mode?.code,
                    label: mode?.name,
                    description: mode?.description,
                })),
            };
        }));
    }
    getNewTransactionInfo(cart) {
        let transactionInfo;
        const priceInfo = cart?.totalPriceWithTax;
        if (priceInfo && priceInfo.value && priceInfo.currencyIso) {
            transactionInfo = {
                totalPrice: priceInfo.value.toString(),
                currencyCode: priceInfo.currencyIso.toString(),
                totalPriceStatus: 'FINAL',
            };
        }
        return transactionInfo;
    }
    setDeliveryAddress(address) {
        const deliveryAddress = this.convertAddress(address);
        if (this.transactionDetails?.deliveryInfo?.type ===
            OpfQuickBuyDeliveryType.SHIPPING) {
            return this.opfQuickBuyTransactionService
                .setDeliveryAddress(deliveryAddress)
                .pipe(tap((addressId) => {
                this.associateAddressId(addressId);
            }));
        }
        else {
            return of(OpfQuickBuyDeliveryType.PICKUP);
        }
    }
    setBillingAddress(address) {
        return this.opfQuickBuyTransactionService.setBillingAddress(this.convertAddress(address));
    }
    setDeliveryMode(mode, type) {
        if (type === OpfQuickBuyDeliveryType.PICKUP) {
            mode = OpfQuickBuyDeliveryType.PICKUP.toLocaleLowerCase();
        }
        if (!mode && type === OpfQuickBuyDeliveryType.SHIPPING) {
            return of(undefined);
        }
        return mode && this.verifyShippingOption(mode)
            ? this.opfQuickBuyTransactionService.setDeliveryMode(mode)
            : of(undefined);
    }
    convertAddress(address) {
        let convertedAddress = {
            firstName: OPF_QUICK_BUY_ADDRESS_FIELD_PLACEHOLDER,
            lastName: OPF_QUICK_BUY_ADDRESS_FIELD_PLACEHOLDER,
            country: {
                isocode: address?.countryCode,
            },
            town: address?.locality,
            district: address?.administrativeArea,
            postalCode: address?.postalCode,
            line1: address?.address1 || OPF_QUICK_BUY_ADDRESS_FIELD_PLACEHOLDER,
            line2: `${address?.address2} ${address?.address3}`,
        };
        if (address?.name) {
            convertedAddress = {
                ...convertedAddress,
                ...this.getFirstAndLastName(address?.name),
            };
        }
        return convertedAddress;
    }
    handleActiveCartTransaction() {
        this.transactionDetails.context = OpfQuickBuyLocation.CART;
        return this.opfQuickBuyTransactionService.handleCartGuestUser().pipe(switchMap(() => {
            return forkJoin({
                deliveryInfo: this.opfQuickBuyTransactionService.getTransactionDeliveryInfo(),
                merchantName: this.opfQuickBuyTransactionService.getMerchantName(),
            }).pipe(switchMap(({ deliveryInfo, merchantName }) => {
                this.transactionDetails.deliveryInfo = deliveryInfo;
                this.setGooglePaymentRequestConfig(deliveryInfo.type, merchantName);
                return this.setDeliveryMode(undefined, deliveryInfo.type).pipe(switchMap(() => this.opfQuickBuyTransactionService.getCurrentCart().pipe(take(1), tap((cart) => {
                    this.transactionDetails.cart = cart;
                    this.updateTransactionInfo({
                        totalPrice: `${cart.totalPrice?.value}`,
                        currencyCode: cart.totalPrice?.currencyIso ||
                            this.initialTransactionInfo.currencyCode,
                        totalPriceStatus: this.initialTransactionInfo.totalPriceStatus,
                    });
                }))));
            }));
        }));
    }
    initTransaction() {
        this.transactionDetails = {
            ...this.initialTransactionDetails,
            addressIds: [],
        };
        this.opfQuickBuyTransactionService
            .getTransactionLocationContext()
            .pipe(switchMap((context) => {
            this.transactionDetails.context = context;
            return this.handleActiveCartTransaction();
        }))
            .subscribe(() => {
            this.googlePaymentClient
                .loadPaymentData(this.googlePaymentRequest)
                .catch((err) => {
                // If err.statusCode === 'CANCELED' it means that customer closed popup
                if (err.statusCode === 'CANCELED') {
                    this.deleteAssociatedAddresses();
                }
            });
        });
    }
    renderPaymentButton(container) {
        container.nativeElement.appendChild(this.getClient().createButton({
            onClick: () => this.initTransaction(),
            buttonSizeMode: 'fill',
        }));
    }
    handlePaymentCallbacks() {
        return {
            onPaymentAuthorized: (paymentDataResponse) => {
                return lastValueFrom(this.setDeliveryAddress(paymentDataResponse.shippingAddress).pipe(switchMap(() => this.setBillingAddress(paymentDataResponse.paymentMethodData.info?.billingAddress)), switchMap(() => {
                    return paymentDataResponse?.email
                        ? this.opfQuickBuyTransactionService.updateCartGuestUserEmail(paymentDataResponse.email)
                        : of(true);
                }), switchMap(() => {
                    const encryptedToken = btoa(paymentDataResponse.paymentMethodData.tokenizationData.token);
                    return this.opfPaymentFacade.submitPayment({
                        additionalData: [],
                        paymentSessionId: '',
                        callbacks: {
                            onSuccess: () => { },
                            onPending: () => { },
                            onFailure: () => { },
                        },
                        paymentMethod: OpfQuickBuyProviderType.GOOGLE_PAY,
                        encryptedToken,
                    });
                }), catchError(() => {
                    return of(false);
                }))).then((isSuccess) => {
                    this.deleteAssociatedAddresses();
                    return { transactionState: isSuccess ? 'SUCCESS' : 'ERROR' };
                });
            },
            onPaymentDataChanged: (intermediatePaymentData) => {
                return lastValueFrom(this.setDeliveryAddress(intermediatePaymentData.shippingAddress).pipe(switchMap(() => this.getShippingOptionParameters()), switchMap((shippingOptions) => {
                    const selectedMode = this.verifyShippingOption(intermediatePaymentData.shippingOptionData?.id) ?? shippingOptions?.defaultSelectedOptionId;
                    return this.setDeliveryMode(selectedMode).pipe(switchMap(() => forkJoin([
                        this.opfQuickBuyTransactionService.getCurrentCart(),
                        this.opfQuickBuyTransactionService.getSelectedDeliveryMode(),
                    ])), switchMap(([cart, mode]) => {
                        const paymentDataRequestUpdate = {
                            newShippingOptionParameters: shippingOptions,
                            newTransactionInfo: this.getNewTransactionInfo(cart),
                        };
                        if (paymentDataRequestUpdate.newShippingOptionParameters
                            ?.defaultSelectedOptionId) {
                            paymentDataRequestUpdate.newShippingOptionParameters.defaultSelectedOptionId =
                                mode?.code;
                        }
                        return of(paymentDataRequestUpdate);
                    }));
                })));
            },
        };
    }
    verifyShippingOption(mode) {
        return mode === 'shipping_option_unselected' ? undefined : mode;
    }
    associateAddressId(addressId) {
        if (!this.isAddressIdAssociated(addressId)) {
            this.transactionDetails.addressIds.push(addressId);
        }
    }
    isAddressIdAssociated(addressId) {
        return this.transactionDetails.addressIds.includes(addressId);
    }
    resetAssociatedAddresses() {
        this.transactionDetails.addressIds = [];
    }
    deleteAssociatedAddresses() {
        if (this.transactionDetails.addressIds?.length) {
            this.opfQuickBuyTransactionService.deleteUserAddresses(this.transactionDetails.addressIds);
            this.resetAssociatedAddresses();
        }
    }
    getFirstAndLastName(name) {
        const firstName = name?.split(' ')[0];
        const lastName = name?.substring(firstName?.length) || firstName;
        return {
            firstName,
            lastName,
        };
    }
    setAllowedPaymentMethodsConfig(activeConfiguration) {
        const googlePayConfig = this.opfQuickBuyButtonsService.getQuickBuyProviderConfig(OpfQuickBuyProviderType.GOOGLE_PAY, [activeConfiguration]);
        this.googlePaymentRequest.allowedPaymentMethods = [
            {
                parameters: {
                    ...this.defaultGooglePayCardParameters,
                },
                tokenizationSpecification: {
                    parameters: {
                        gateway: String(googlePayConfig?.googlePayGateway),
                        gatewayMerchantId: String(activeConfiguration.merchantId),
                    },
                    type: activeConfiguration.providerType,
                },
                type: 'CARD',
            },
        ];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGooglePayService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGooglePayService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGooglePayService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGooglePayComponent {
    constructor() {
        this.opfGooglePayService = inject(OpfGooglePayService);
        this.changeDetectionRef = inject(ChangeDetectorRef);
        this.isReadyToPayState$ = new BehaviorSubject(false);
    }
    ngOnInit() {
        const activeConfigurations = Array.isArray(this.activeConfiguration)
            ? this.activeConfiguration
            : [this.activeConfiguration];
        this.opfGooglePayService.loadResources().then(() => {
            this.opfGooglePayService.initClient(activeConfigurations);
            this.opfGooglePayService.isReadyToPay().then((response) => {
                this.isReadyToPayState$.next(!!response?.result);
                this.changeDetectionRef.detectChanges();
                if (response.result && this.googlePayButtonContainer) {
                    this.opfGooglePayService.renderPaymentButton(this.googlePayButtonContainer);
                }
            });
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGooglePayComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: OpfGooglePayComponent, isStandalone: true, selector: "cx-opf-google-pay", inputs: { activeConfiguration: "activeConfiguration" }, viewQueries: [{ propertyName: "googlePayButtonContainer", first: true, predicate: ["googlePayButtonContainer"], descendants: true }], ngImport: i0, template: "<ng-container *ngIf=\"isReadyToPayState$ | async as isReadyToPay\">\n  <div\n    *ngIf=\"isReadyToPay\"\n    class=\"cx-opf-google-pay-button\"\n    #googlePayButtonContainer\n  ></div>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGooglePayComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-google-pay', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, AsyncPipe], template: "<ng-container *ngIf=\"isReadyToPayState$ | async as isReadyToPay\">\n  <div\n    *ngIf=\"isReadyToPay\"\n    class=\"cx-opf-google-pay-button\"\n    #googlePayButtonContainer\n  ></div>\n</ng-container>\n" }]
        }], propDecorators: { activeConfiguration: [{
                type: Input
            }], googlePayButtonContainer: [{
                type: ViewChild,
                args: ['googlePayButtonContainer']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGooglePayModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGooglePayModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfGooglePayModule, imports: [CommonModule, OpfGooglePayComponent], exports: [OpfGooglePayComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGooglePayModule, providers: [OpfGooglePayService], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfGooglePayModule, decorators: [{
            type: NgModule,
            args: [{
                    exports: [OpfGooglePayComponent],
                    imports: [CommonModule, OpfGooglePayComponent],
                    providers: [OpfGooglePayService],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyButtonsComponent {
    constructor() {
        this.opfQuickBuyButtonsService = inject(OpfQuickBuyButtonsService);
        this.PAYMENT_METHODS = OpfQuickBuyProviderType;
    }
    ngOnInit() {
        this.paymentGatewayConfig$ =
            this.opfQuickBuyButtonsService.getPaymentGatewayConfiguration();
    }
    isPaymentMethodEnabled(provider, activeConfiguration) {
        return this.opfQuickBuyButtonsService.isQuickBuyProviderEnabled(provider, activeConfiguration);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyButtonsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: OpfQuickBuyButtonsComponent, isStandalone: true, selector: "cx-opf-quick-buy-buttons", ngImport: i0, template: "<ng-container *ngIf=\"paymentGatewayConfig$ | async as paymentGatewayConfig\">\n  <cx-opf-apple-pay\n    *ngIf=\"\n      isPaymentMethodEnabled(PAYMENT_METHODS.APPLE_PAY, paymentGatewayConfig)\n    \"\n    [activeConfiguration]=\"paymentGatewayConfig\"\n  ></cx-opf-apple-pay>\n</ng-container>\n\n<div class=\"cx-opf-quick-buy-buttons-fixed-space\">\n  <ng-container *ngIf=\"paymentGatewayConfig$ | async as paymentGatewayConfig\">\n    <cx-opf-google-pay\n      *ngIf=\"\n        isPaymentMethodEnabled(PAYMENT_METHODS.GOOGLE_PAY, paymentGatewayConfig)\n      \"\n      [activeConfiguration]=\"paymentGatewayConfig\"\n    ></cx-opf-google-pay>\n  </ng-container>\n</div>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: ApplePayComponent, selector: "cx-opf-apple-pay", inputs: ["activeConfiguration"] }, { kind: "component", type: OpfGooglePayComponent, selector: "cx-opf-google-pay", inputs: ["activeConfiguration"] }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyButtonsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-quick-buy-buttons', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, ApplePayComponent, OpfGooglePayComponent, AsyncPipe], template: "<ng-container *ngIf=\"paymentGatewayConfig$ | async as paymentGatewayConfig\">\n  <cx-opf-apple-pay\n    *ngIf=\"\n      isPaymentMethodEnabled(PAYMENT_METHODS.APPLE_PAY, paymentGatewayConfig)\n    \"\n    [activeConfiguration]=\"paymentGatewayConfig\"\n  ></cx-opf-apple-pay>\n</ng-container>\n\n<div class=\"cx-opf-quick-buy-buttons-fixed-space\">\n  <ng-container *ngIf=\"paymentGatewayConfig$ | async as paymentGatewayConfig\">\n    <cx-opf-google-pay\n      *ngIf=\"\n        isPaymentMethodEnabled(PAYMENT_METHODS.GOOGLE_PAY, paymentGatewayConfig)\n      \"\n      [activeConfiguration]=\"paymentGatewayConfig\"\n    ></cx-opf-google-pay>\n  </ng-container>\n</div>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyButtonsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyButtonsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyButtonsModule, imports: [CommonModule,
            OpfApplePayModule,
            OpfGooglePayModule,
            OpfQuickBuyButtonsComponent], exports: [OpfQuickBuyButtonsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyButtonsModule, providers: [
            OpfQuickBuyButtonsService,
            provideDefaultConfig({
                cmsComponents: {
                    OpfQuickBuyButtonsComponent: {
                        component: OpfQuickBuyButtonsComponent,
                    },
                },
            }),
        ], imports: [CommonModule,
            OpfApplePayModule,
            OpfGooglePayModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyButtonsModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        OpfQuickBuyButtonsService,
                        provideDefaultConfig({
                            cmsComponents: {
                                OpfQuickBuyButtonsComponent: {
                                    component: OpfQuickBuyButtonsComponent,
                                },
                            },
                        }),
                    ],
                    exports: [OpfQuickBuyButtonsComponent],
                    imports: [
                        CommonModule,
                        OpfApplePayModule,
                        OpfGooglePayModule,
                        OpfQuickBuyButtonsComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyComponentsModule, imports: [OpfQuickBuyButtonsModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyComponentsModule, imports: [OpfQuickBuyButtonsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfQuickBuyComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OpfQuickBuyButtonsModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfQuickBuyComponentsModule };
//# sourceMappingURL=spartacus-opf-quick-buy-components.mjs.map
