import * as i5 from '@spartacus/checkout/b2b/root';
import * as i3 from '@spartacus/checkout/base/root';
import { CheckoutStepType } from '@spartacus/checkout/base/root';
import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import * as i2 from '@spartacus/core';
import { LoggerService, provideDefaultConfig, provideDefaultConfigFactory } from '@spartacus/core';
import { CheckoutB2BStepsSetGuard } from '@spartacus/checkout/b2b/components';
import * as i1 from '@spartacus/checkout/base/components';
import { CheckoutStepsSetGuard, CheckoutFlowOrchestratorService } from '@spartacus/checkout/base/components';
import { OPF_CHECKOUT_FLOW_NAME } from '@spartacus/opf/checkout/root';
import { combineLatest, tap, take, switchMap, of, map, filter } from 'rxjs';
import * as i4 from '@angular/router';
import * as i6 from '@spartacus/cart/base/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const opfB2bCheckoutSteps = [
    {
        id: 'opfPaymentType',
        name: 'opfCheckout.tabs.paymentType',
        routeName: 'opfCheckoutPaymentType',
        type: [CheckoutStepType.PAYMENT_TYPE],
    },
    {
        id: 'opfDeliveryAddress',
        name: 'opfCheckout.tabs.shipping',
        routeName: 'opfCheckoutDeliveryAddress',
        type: [CheckoutStepType.DELIVERY_ADDRESS],
    },
    {
        id: 'deliveryMode',
        name: 'opfCheckout.tabs.deliveryMethod',
        routeName: 'checkoutDeliveryMode',
        type: [CheckoutStepType.DELIVERY_MODE],
    },
    {
        id: 'opfPaymentAndReview',
        name: 'opfCheckout.tabs.paymentAndReview',
        routeName: 'opfCheckoutPaymentAndReview',
        type: [CheckoutStepType.PAYMENT_DETAILS],
    },
    {
        id: 'opfReview',
        name: 'opfCheckout.tabs.review',
        routeName: 'opfCheckoutReview',
        type: [CheckoutStepType.REVIEW_ORDER],
    },
];
const defaultOpfB2bCheckoutConfig = {
    checkout: {
        flows: {
            OPF: {
                steps: opfB2bCheckoutSteps,
                guest: false,
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const orderEndpoints = {
    placePaymentAuthorizedOrder: 'orgUsers/${userId}/orders?fields=FULL',
};
const defaultOpfB2bCheckoutOccEndpointsConfig = {
    backend: {
        occ: {
            endpoints: {
                ...orderEndpoints,
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_B2B_CHECKOUT_FEATURE = 'opfB2bCheckout';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfB2bCheckoutStepsSetGuard extends CheckoutStepsSetGuard {
    constructor(checkoutStepService, routingConfigService, checkoutDeliveryAddressFacade, checkoutPaymentFacade, checkoutDeliveryModesFacade, router, checkoutPaymentTypeFacade, checkoutCostCenterFacade, activeCartFacade) {
        super(checkoutStepService, routingConfigService, checkoutDeliveryAddressFacade, checkoutPaymentFacade, checkoutDeliveryModesFacade, router, activeCartFacade);
        this.checkoutStepService = checkoutStepService;
        this.routingConfigService = routingConfigService;
        this.checkoutDeliveryAddressFacade = checkoutDeliveryAddressFacade;
        this.checkoutPaymentFacade = checkoutPaymentFacade;
        this.checkoutDeliveryModesFacade = checkoutDeliveryModesFacade;
        this.router = router;
        this.checkoutPaymentTypeFacade = checkoutPaymentTypeFacade;
        this.checkoutCostCenterFacade = checkoutCostCenterFacade;
        this.activeCartFacade = activeCartFacade;
        this.logger = inject(LoggerService);
        this.checkoutFlowOrchestratorService = inject(CheckoutFlowOrchestratorService);
    }
    canActivate(route) {
        let currentIndex = -1;
        const currentRouteUrl = '/' + route.url.join('/');
        return combineLatest([
            this.checkoutStepService.steps$,
            this.checkoutPaymentTypeFacade.isAccountPayment(),
            this.isOpfCheckoutFlow(),
        ]).pipe(tap(([, isAccount, isOpf]) => {
            this.checkoutStepService.disableEnableStep(CheckoutStepType.PAYMENT_DETAILS, isAccount);
            if (isOpf) {
                this.checkoutStepService.disableEnableStep(CheckoutStepType.REVIEW_ORDER, !isAccount);
            }
        }), take(1), switchMap(([steps, isAccount]) => {
            currentIndex = steps.findIndex((step) => {
                const stepRouteUrl = `/${this.routingConfigService.getRouteConfig(step.routeName)?.paths?.[0]}`;
                return stepRouteUrl === currentRouteUrl;
            });
            // get current step
            let currentStep;
            if (currentIndex >= 0) {
                currentStep = steps[currentIndex];
            }
            if (currentStep) {
                return this.isB2BStepSet(steps[currentIndex - 1], isAccount);
            }
            else {
                return of(this.getUrl('checkout'));
            }
        }));
    }
    isOpfCheckoutFlow() {
        return this.checkoutFlowOrchestratorService
            .getPaymentProvider()
            .pipe(map((provider) => provider === OPF_CHECKOUT_FLOW_NAME));
    }
    isB2BStepSet(step, isAccountPayment) {
        if (step && !step.disabled) {
            switch (step.type[0]) {
                case CheckoutStepType.PAYMENT_TYPE: {
                    return this.isPaymentTypeSet(step);
                }
                case CheckoutStepType.DELIVERY_ADDRESS: {
                    return this.isDeliveryAddressAndCostCenterSet(step, isAccountPayment);
                }
                case CheckoutStepType.DELIVERY_MODE: {
                    return this.isDeliveryModeSet(step);
                }
                case CheckoutStepType.PAYMENT_DETAILS: {
                    return this.isPaymentDetailsSet(step);
                }
                case CheckoutStepType.REVIEW_ORDER: {
                    break;
                }
            }
        }
        return of(true);
    }
    isPaymentTypeSet(step) {
        return this.checkoutPaymentTypeFacade.getSelectedPaymentTypeState().pipe(filter((state) => !state.loading), map((state) => state.data), map((paymentType) => {
            if (paymentType) {
                return true;
            }
            else {
                return this.getUrl(step.routeName);
            }
        }));
    }
    // CXSPA-11111: Methods should not contain selector parameters
    isDeliveryAddressAndCostCenterSet(step, isAccountPayment) {
        return combineLatest([
            this.checkoutDeliveryAddressFacade.getDeliveryAddressState().pipe(filter((state) => !state.loading), map((state) => state.data)),
            this.checkoutCostCenterFacade.getCostCenterState().pipe(filter((state) => !state.loading), map((state) => state.data)),
        ]).pipe(map(([deliveryAddress, costCenter]) => {
            if (isAccountPayment) {
                if (deliveryAddress &&
                    Object.keys(deliveryAddress).length &&
                    !!costCenter) {
                    return true;
                }
                else {
                    return this.getUrl(step.routeName);
                }
            }
            else if (deliveryAddress && Object.keys(deliveryAddress).length) {
                return true;
            }
            else {
                return this.getUrl(step.routeName);
            }
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfB2bCheckoutStepsSetGuard, deps: [{ token: i1.CheckoutStepService }, { token: i2.RoutingConfigService }, { token: i3.CheckoutDeliveryAddressFacade }, { token: i3.CheckoutPaymentFacade }, { token: i3.CheckoutDeliveryModesFacade }, { token: i4.Router }, { token: i5.CheckoutPaymentTypeFacade }, { token: i5.CheckoutCostCenterFacade }, { token: i6.ActiveCartFacade }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfB2bCheckoutStepsSetGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfB2bCheckoutStepsSetGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.CheckoutStepService }, { type: i2.RoutingConfigService }, { type: i3.CheckoutDeliveryAddressFacade }, { type: i3.CheckoutPaymentFacade }, { type: i3.CheckoutDeliveryModesFacade }, { type: i4.Router }, { type: i5.CheckoutPaymentTypeFacade }, { type: i5.CheckoutCostCenterFacade }, { type: i6.ActiveCartFacade }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_B2B_CHECKOUT_CMS_COMPONENTS = [
    'OpfCheckoutPaymentType',
    'OpfCheckoutDeliveryAddress',
    'OpfCheckoutReview',
    'OpfB2bCheckoutPaymentAndReview',
];
function defaultOpfB2bCheckoutComponentsConfig() {
    const config = {
        featureModules: {
            [OPF_B2B_CHECKOUT_FEATURE]: {
                cmsComponents: OPF_B2B_CHECKOUT_CMS_COMPONENTS,
            },
        },
    };
    return config;
}
class OpfB2bCheckoutRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfB2bCheckoutRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfB2bCheckoutRootModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfB2bCheckoutRootModule, providers: [
            {
                provide: CheckoutB2BStepsSetGuard,
                useClass: OpfB2bCheckoutStepsSetGuard,
            },
            provideDefaultConfig(defaultOpfB2bCheckoutConfig),
            provideDefaultConfig(defaultOpfB2bCheckoutOccEndpointsConfig),
            provideDefaultConfigFactory(defaultOpfB2bCheckoutComponentsConfig),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfB2bCheckoutRootModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        {
                            provide: CheckoutB2BStepsSetGuard,
                            useClass: OpfB2bCheckoutStepsSetGuard,
                        },
                        provideDefaultConfig(defaultOpfB2bCheckoutConfig),
                        provideDefaultConfig(defaultOpfB2bCheckoutOccEndpointsConfig),
                        provideDefaultConfigFactory(defaultOpfB2bCheckoutComponentsConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OPF_B2B_CHECKOUT_CMS_COMPONENTS, OPF_B2B_CHECKOUT_FEATURE, OpfB2bCheckoutRootModule, defaultOpfB2bCheckoutComponentsConfig, defaultOpfB2bCheckoutConfig, defaultOpfB2bCheckoutOccEndpointsConfig };
//# sourceMappingURL=spartacus-opf-b2b-checkout-root.mjs.map
