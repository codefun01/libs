import * as i0 from '@angular/core';
import { inject, Injectable, Input, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { NgIf, CommonModule, NgFor, AsyncPipe } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';
import { CmsService, WindowRef, provideDefaultConfig } from '@spartacus/core';
import { throwError, of } from 'rxjs';
import { concatMap, tap, finalize, take, map, filter, catchError } from 'rxjs/operators';
import { OpfBaseFacade, OpfResourceLoaderService, OpfHtmlContentMode } from '@spartacus/opf/base/root';
import { OpfCtaFacade, OpfCtaDynamicLocations, OpfCtaScriptsLocation, OpfCtaCmsPageLocation } from '@spartacus/opf/cta/root';
import { OpfDynamicCtaService, OpfStaticCtaService } from '@spartacus/opf/cta/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCtaScriptsService {
    constructor() {
        this.opfBaseFacade = inject(OpfBaseFacade);
        this.opfCtaFacade = inject(OpfCtaFacade);
        this.opfResourceLoaderService = inject(OpfResourceLoaderService);
        this.cmsService = inject(CmsService);
        this.opfDynamicCtaService = inject(OpfDynamicCtaService);
        this.opfStaticCtaService = inject(OpfStaticCtaService);
    }
    loadAndRunScript(script) {
        const html = script?.html;
        return new Promise((resolve) => {
            this.opfResourceLoaderService
                .loadResources(script.jsUrls, script.cssUrls, undefined, script)
                .then(() => {
                if (html &&
                    script?.htmlContentMode !== OpfHtmlContentMode.SEPARATE) {
                    this.opfResourceLoaderService.executeScriptFromHtml(html);
                    resolve(script);
                }
                else if (html) {
                    resolve(script);
                }
                else {
                    resolve(undefined);
                }
            })
                .catch(() => {
                resolve(undefined);
            });
        });
    }
    getCtaHtmlList() {
        let isDynamicCtaLocation = false;
        return this.fillCtaScriptRequest().pipe(concatMap((opfCtaScriptsRequest) => {
            isDynamicCtaLocation =
                !!opfCtaScriptsRequest?.scriptLocations?.length &&
                    !!opfCtaScriptsRequest?.scriptLocations.find((location) => OpfCtaDynamicLocations.includes(location));
            isDynamicCtaLocation &&
                this.opfDynamicCtaService.registerScriptReadyEvent();
            return this.fetchCtaScripts(opfCtaScriptsRequest);
        }), tap((scriptsResponse) => {
            isDynamicCtaLocation &&
                !!scriptsResponse.length &&
                this.opfDynamicCtaService.initiateEvents();
        }), finalize(() => {
            this.opfResourceLoaderService.clearAllResources();
            isDynamicCtaLocation && this.opfDynamicCtaService.stopEvents();
        }));
    }
    fetchCtaScripts(opfCtaScriptsRequest) {
        return this.opfCtaFacade.getCtaScripts(opfCtaScriptsRequest).pipe(concatMap((opfCtaScriptsResponse) => {
            if (!opfCtaScriptsResponse?.value?.length) {
                return throwError(() => 'Invalid CTA Scripts Response');
            }
            const dynamicScripts = opfCtaScriptsResponse.value.map((ctaScript) => ctaScript.dynamicScript);
            return of(dynamicScripts);
        }), take(1));
    }
    fillCtaScriptRequest() {
        let paymentAccountIds;
        return this.getPaymentAccountIds().pipe(concatMap((accIds) => {
            paymentAccountIds = accIds;
            return this.getScriptLocation();
        }), concatMap((scriptsLocation) => {
            return this.fillRequestForTargetPage(scriptsLocation, paymentAccountIds);
        }));
    }
    fillRequestForTargetPage(scriptsLocation, paymentAccountIds) {
        if (!scriptsLocation) {
            return throwError(() => 'Invalid Script Location');
        }
        const locationToFunctionMap = {
            [OpfCtaScriptsLocation.ORDER_HISTORY_PAYMENT_GUIDE]: () => this.opfStaticCtaService.fillCtaRequestforPagesWithOrder(scriptsLocation),
            [OpfCtaScriptsLocation.ORDER_CONFIRMATION_PAYMENT_GUIDE]: () => this.opfStaticCtaService.fillCtaRequestforPagesWithOrder(scriptsLocation),
            [OpfCtaScriptsLocation.CART_MESSAGING]: () => this.opfDynamicCtaService.fillCtaRequestforCartPage(scriptsLocation, paymentAccountIds),
            [OpfCtaScriptsLocation.PDP_MESSAGING]: () => this.opfDynamicCtaService.fillCtaRequestforProductPage(scriptsLocation, paymentAccountIds),
            [OpfCtaScriptsLocation.CART_QUICK_BUY]: () => this.opfDynamicCtaService.fillCtaRequestforCartPage(scriptsLocation, paymentAccountIds),
            [OpfCtaScriptsLocation.PDP_QUICK_BUY]: () => this.opfDynamicCtaService.fillCtaRequestforProductPage(scriptsLocation, paymentAccountIds),
        };
        const selectedFunction = locationToFunctionMap[scriptsLocation];
        return selectedFunction();
    }
    getQuickBuyCtaHtmlList() {
        let isDynamicCtaLocation = false;
        return this.fillQuickBuyCtaScriptRequest().pipe(concatMap((opfCtaScriptsRequest) => {
            isDynamicCtaLocation =
                !!opfCtaScriptsRequest?.scriptLocations?.length &&
                    !!opfCtaScriptsRequest?.scriptLocations.find((location) => OpfCtaDynamicLocations.includes(location));
            isDynamicCtaLocation &&
                this.opfDynamicCtaService.registerScriptReadyEvent();
            return this.fetchCtaScripts(opfCtaScriptsRequest);
        }), tap((scriptsResponse) => {
            isDynamicCtaLocation &&
                !!scriptsResponse.length &&
                this.opfDynamicCtaService.initiateEvents();
        }), finalize(() => {
            this.opfResourceLoaderService.clearAllResources();
            isDynamicCtaLocation && this.opfDynamicCtaService.stopEvents();
        }));
    }
    fillQuickBuyCtaScriptRequest() {
        let paymentAccountIds;
        return this.getPaymentAccountIds().pipe(concatMap((accIds) => {
            paymentAccountIds = accIds;
            return this.getQuickBuyScriptLocation();
        }), concatMap((scriptsLocation) => {
            return this.fillRequestForTargetPage(scriptsLocation, paymentAccountIds);
        }));
    }
    getQuickBuyScriptLocation() {
        const cmsToCtaLocationMap = {
            [OpfCtaCmsPageLocation.CART_PAGE]: OpfCtaScriptsLocation.CART_QUICK_BUY,
            [OpfCtaCmsPageLocation.PDP_PAGE]: OpfCtaScriptsLocation.PDP_QUICK_BUY,
        };
        return this.cmsService.getCurrentPage().pipe(take(1), map((page) => page.pageId
            ? cmsToCtaLocationMap[page.pageId]
            : undefined));
    }
    getScriptLocation() {
        const cmsToCtaLocationMap = {
            [OpfCtaCmsPageLocation.ORDER_PAGE]: OpfCtaScriptsLocation.ORDER_HISTORY_PAYMENT_GUIDE,
            [OpfCtaCmsPageLocation.ORDER_CONFIRMATION_PAGE]: OpfCtaScriptsLocation.ORDER_CONFIRMATION_PAYMENT_GUIDE,
            [OpfCtaCmsPageLocation.PDP_PAGE]: OpfCtaScriptsLocation.PDP_MESSAGING,
            [OpfCtaCmsPageLocation.CART_PAGE]: OpfCtaScriptsLocation.CART_MESSAGING,
        };
        return this.cmsService.getCurrentPage().pipe(take(1), map((page) => page.pageId
            ? cmsToCtaLocationMap[page.pageId]
            : undefined));
    }
    getPaymentAccountIds() {
        return this.opfBaseFacade.getActiveConfigurationsState().pipe(filter((state) => !state.loading && !state.error && Boolean(state.data?.value?.length)), map((state) => state.data?.value?.map((val) => val.id)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaScriptsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaScriptsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaScriptsService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCtaElementComponent {
    constructor() {
        this.sanitizer = inject(DomSanitizer);
        this.opfCtaScriptsService = inject(OpfCtaScriptsService);
        this.windowRef = inject(WindowRef);
    }
    ngAfterViewInit() {
        this.opfCtaScriptsService.loadAndRunScript(this.ctaScriptHtml);
    }
    renderHtml(html) {
        // Display sanitized html in SSR for security concerns
        return this.windowRef.isBrowser()
            ? this.sanitizer.bypassSecurityTrustHtml(this.removeScriptTags(html))
            : html;
    }
    // Removing script tags on FE until BE fix: CXSPA-8572
    removeScriptTags(html) {
        const element = new DOMParser().parseFromString(html, 'text/html');
        Array.from(element.getElementsByTagName('script')).forEach((script) => {
            html = html.replace(script.outerHTML, '');
        });
        return html;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaElementComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: OpfCtaElementComponent, isStandalone: true, selector: "cx-opf-cta-element", inputs: { ctaScriptHtml: "ctaScriptHtml" }, ngImport: i0, template: "<div\n  *ngIf=\"ctaScriptHtml && ctaScriptHtml.html\"\n  [innerHTML]=\"renderHtml(ctaScriptHtml.html)\"\n></div>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaElementComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-cta-element', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf], template: "<div\n  *ngIf=\"ctaScriptHtml && ctaScriptHtml.html\"\n  [innerHTML]=\"renderHtml(ctaScriptHtml.html)\"\n></div>\n" }]
        }], propDecorators: { ctaScriptHtml: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCtaElementModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaElementModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaElementModule, imports: [CommonModule, OpfCtaElementComponent], exports: [OpfCtaElementComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaElementModule, imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaElementModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, OpfCtaElementComponent],
                    exports: [OpfCtaElementComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCtaQuickBuyButtonsComponent {
    constructor() {
        this.opfCtaScriptService = inject(OpfCtaScriptsService);
        this.ctaHtmls$ = this.opfCtaScriptService.getQuickBuyCtaHtmlList().pipe(catchError(() => {
            return of([]);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaQuickBuyButtonsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: OpfCtaQuickBuyButtonsComponent, isStandalone: true, selector: "cx-opf-cta-quick-buy-buttons", ngImport: i0, template: "<ng-container *ngIf=\"ctaHtmls$ | async as ctaHtmls\">\n  <ng-container *ngIf=\"ctaHtmls?.length\">\n    <cx-opf-cta-element\n      *ngFor=\"let ctaHtml of ctaHtmls\"\n      [ctaScriptHtml]=\"ctaHtml\"\n    ></cx-opf-cta-element>\n  </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: OpfCtaElementComponent, selector: "cx-opf-cta-element", inputs: ["ctaScriptHtml"] }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaQuickBuyButtonsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-cta-quick-buy-buttons', changeDetection: ChangeDetectionStrategy.OnPush, standalone: true, imports: [NgIf, NgFor, AsyncPipe, OpfCtaElementComponent], template: "<ng-container *ngIf=\"ctaHtmls$ | async as ctaHtmls\">\n  <ng-container *ngIf=\"ctaHtmls?.length\">\n    <cx-opf-cta-element\n      *ngFor=\"let ctaHtml of ctaHtmls\"\n      [ctaScriptHtml]=\"ctaHtml\"\n    ></cx-opf-cta-element>\n  </ng-container>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCtaQuickBuyButtonsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaQuickBuyButtonsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaQuickBuyButtonsModule, imports: [OpfCtaQuickBuyButtonsComponent], exports: [OpfCtaQuickBuyButtonsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaQuickBuyButtonsModule, providers: [
            OpfCtaScriptsService,
            OpfDynamicCtaService,
            OpfStaticCtaService,
            provideDefaultConfig({
                cmsComponents: {
                    OpfCtaQuickBuyButtons: {
                        component: OpfCtaQuickBuyButtonsComponent,
                    },
                },
            }),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaQuickBuyButtonsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OpfCtaQuickBuyButtonsComponent],
                    providers: [
                        OpfCtaScriptsService,
                        OpfDynamicCtaService,
                        OpfStaticCtaService,
                        provideDefaultConfig({
                            cmsComponents: {
                                OpfCtaQuickBuyButtons: {
                                    component: OpfCtaQuickBuyButtonsComponent,
                                },
                            },
                        }),
                    ],
                    exports: [OpfCtaQuickBuyButtonsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCtaScriptsComponent {
    constructor() {
        this.opfCtaScriptService = inject(OpfCtaScriptsService);
        this.ctaHtmls$ = this.opfCtaScriptService.getCtaHtmlList().pipe(catchError(() => {
            return of([]);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaScriptsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: OpfCtaScriptsComponent, isStandalone: true, selector: "cx-opf-cta-scripts", ngImport: i0, template: "<ng-container *ngIf=\"ctaHtmls$ | async as ctaHtmls\">\n  <ng-container *ngIf=\"ctaHtmls?.length\">\n    <cx-opf-cta-element\n      *ngFor=\"let ctaHtml of ctaHtmls\"\n      [ctaScriptHtml]=\"ctaHtml\"\n    ></cx-opf-cta-element>\n  </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: OpfCtaElementComponent, selector: "cx-opf-cta-element", inputs: ["ctaScriptHtml"] }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaScriptsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-cta-scripts', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, NgFor, OpfCtaElementComponent, AsyncPipe], template: "<ng-container *ngIf=\"ctaHtmls$ | async as ctaHtmls\">\n  <ng-container *ngIf=\"ctaHtmls?.length\">\n    <cx-opf-cta-element\n      *ngFor=\"let ctaHtml of ctaHtmls\"\n      [ctaScriptHtml]=\"ctaHtml\"\n    ></cx-opf-cta-element>\n  </ng-container>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCtaScriptsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaScriptsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaScriptsModule, imports: [CommonModule, OpfCtaElementModule, OpfCtaScriptsComponent], exports: [OpfCtaScriptsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaScriptsModule, providers: [
            OpfCtaScriptsService,
            OpfDynamicCtaService,
            OpfStaticCtaService,
            provideDefaultConfig({
                cmsComponents: {
                    OpfCtaScriptsComponent: {
                        component: OpfCtaScriptsComponent,
                    },
                },
            }),
        ], imports: [CommonModule, OpfCtaElementModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaScriptsModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        OpfCtaScriptsService,
                        OpfDynamicCtaService,
                        OpfStaticCtaService,
                        provideDefaultConfig({
                            cmsComponents: {
                                OpfCtaScriptsComponent: {
                                    component: OpfCtaScriptsComponent,
                                },
                            },
                        }),
                    ],
                    exports: [OpfCtaScriptsComponent],
                    imports: [CommonModule, OpfCtaElementModule, OpfCtaScriptsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCtaComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaComponentsModule, imports: [OpfCtaScriptsModule,
            OpfCtaElementModule,
            OpfCtaQuickBuyButtonsModule], exports: [OpfCtaScriptsModule,
            OpfCtaElementModule,
            OpfCtaQuickBuyButtonsModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaComponentsModule, imports: [OpfCtaScriptsModule,
            OpfCtaElementModule,
            OpfCtaQuickBuyButtonsModule, OpfCtaScriptsModule,
            OpfCtaElementModule,
            OpfCtaQuickBuyButtonsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OpfCtaComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        OpfCtaScriptsModule,
                        OpfCtaElementModule,
                        OpfCtaQuickBuyButtonsModule,
                    ],
                    exports: [
                        OpfCtaScriptsModule,
                        OpfCtaElementModule,
                        OpfCtaQuickBuyButtonsModule,
                    ],
                    providers: [],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfCtaComponentsModule, OpfCtaElementComponent, OpfCtaElementModule, OpfCtaQuickBuyButtonsComponent, OpfCtaQuickBuyButtonsModule, OpfCtaScriptsComponent, OpfCtaScriptsModule, OpfCtaScriptsService };
//# sourceMappingURL=spartacus-opf-cta-components.mjs.map
