import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { PDFInvoicesComponentsModule } from '@spartacus/pdf-invoices/components';
import { PDFInvoicesCoreModule } from '@spartacus/pdf-invoices/core';
import { PDFInvoicesOccModule } from '@spartacus/pdf-invoices/occ';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PDFInvoicesModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PDFInvoicesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: PDFInvoicesModule, imports: [PDFInvoicesComponentsModule,
            PDFInvoicesCoreModule,
            PDFInvoicesOccModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PDFInvoicesModule, imports: [PDFInvoicesComponentsModule,
            PDFInvoicesCoreModule,
            PDFInvoicesOccModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PDFInvoicesModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        PDFInvoicesComponentsModule,
                        PDFInvoicesCoreModule,
                        PDFInvoicesOccModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/*
 * Public API Surface of pdf-invoices
 */

/**
 * Generated bundle index. Do not edit.
 */

export { PDFInvoicesModule };
//# sourceMappingURL=spartacus-pdf-invoices.mjs.map
