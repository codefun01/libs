"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAppComponent = updateAppComponent;
var ts_morph_1 = require("ts-morph");
var shared_1 = require("../../shared");
/**
 * Updates src/app/app.component.ts to be a standalone component:
 * - Removes `standalone: false`
 * - Adds `imports: [StorefrontComponent]`
 * - Adds import for StorefrontComponent from @spartacus/storefront
 */
function updateAppComponent() {
    return function (tree, context) {
        var _a;
        var appComponentPath = 'src/app/app.component.ts';
        if (!tree.exists(appComponentPath)) {
            throw new Error("File ".concat(appComponentPath, " not found"));
        }
        context.logger.info('⏳ Updating app.component.ts to standalone...');
        var content = (_a = tree.read(appComponentPath)) === null || _a === void 0 ? void 0 : _a.toString('utf-8');
        if (!content) {
            throw new Error("Could not read ".concat(appComponentPath));
        }
        var project = new ts_morph_1.Project({ useInMemoryFileSystem: true });
        var sourceFile = project.createSourceFile(appComponentPath, content, {
            overwrite: true,
        });
        (0, shared_1.createImports)(sourceFile, [
            {
                moduleSpecifier: shared_1.SPARTACUS_STOREFRONTLIB,
                namedImports: [shared_1.STOREFRONT_COMPONENT_CLASS],
            },
        ]);
        var configObject = getComponentDecoratorConfig(sourceFile);
        removeStandaloneProperty(configObject);
        addOrUpdateImportsProperty(configObject);
        (0, shared_1.formatFile)(sourceFile);
        tree.overwrite(appComponentPath, sourceFile.getFullText());
        context.logger.info('✅ Updated app.component.ts to standalone');
        return tree;
    };
}
function getComponentDecoratorConfig(sourceFile) {
    var classDeclaration = sourceFile.getClass('AppComponent');
    if (!classDeclaration) {
        throw new Error('Could not find AppComponent class');
    }
    var decorator = classDeclaration.getDecorator('Component');
    if (!decorator) {
        throw new Error('Could not find @Component decorator');
    }
    var decoratorArgs = decorator.getArguments();
    if (decoratorArgs.length === 0) {
        throw new Error('@Component decorator has no arguments');
    }
    var configObject = decoratorArgs[0];
    if (!configObject.isKind(ts_morph_1.SyntaxKind.ObjectLiteralExpression)) {
        throw new Error('@Component decorator argument is not an object');
    }
    return configObject;
}
function removeStandaloneProperty(configObject) {
    var standaloneProp = configObject.getProperty('standalone');
    if (standaloneProp) {
        standaloneProp.remove();
    }
}
function addOrUpdateImportsProperty(configObject) {
    var importsProp = configObject.getProperty('imports');
    if (!importsProp) {
        configObject.addPropertyAssignment({
            name: 'imports',
            initializer: "[".concat(shared_1.STOREFRONT_COMPONENT_CLASS, "]"),
        });
        return;
    }
    if (!importsProp.isKind(ts_morph_1.SyntaxKind.PropertyAssignment)) {
        return;
    }
    var initializer = importsProp.getInitializer();
    if (!(initializer === null || initializer === void 0 ? void 0 : initializer.isKind(ts_morph_1.SyntaxKind.ArrayLiteralExpression))) {
        return;
    }
    addElementIfMissing(initializer);
}
function addElementIfMissing(initializer) {
    var elements = initializer.getElements();
    var hasStorefrontComponent = elements.some(function (el) {
        return el.isKind(ts_morph_1.SyntaxKind.Identifier) &&
            el.getText() === shared_1.STOREFRONT_COMPONENT_CLASS;
    });
    if (!hasStorefrontComponent) {
        initializer.addElement(shared_1.STOREFRONT_COMPONENT_CLASS);
    }
}
//# sourceMappingURL=update-app-component.js.map