import { Rule } from '@angular-devkit/schematics';
/**
 * Updates src/main.ts to use bootstrapApplication instead of bootstrapModule:
 * - Replaces platformBrowser import with bootstrapApplication
 * - Adds imports for appConfig and AppComponent
 * - Replaces platformBrowser().bootstrapModule(AppModule) with bootstrapApplication(AppComponent, appConfig)
 */
export declare function updateMainTs(): Rule;
