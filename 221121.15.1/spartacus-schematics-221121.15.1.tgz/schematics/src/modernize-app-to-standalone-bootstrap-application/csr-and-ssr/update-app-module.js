"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAppModule = updateAppModule;
var ts_morph_1 = require("ts-morph");
var shared_1 = require("../../shared");
/**
 * Updates src/app/app.module.ts:
 * - Removes `bootstrap: [AppComponent]`
 * - Removes `declarations: [AppComponent]`
 * - Removes predefined providers (provideBrowserGlobalErrorListeners, provideZoneChangeDetection, provideHttpClient)
 * - Removes BrowserModule from imports
 */
function updateAppModule() {
    return function (tree, context) {
        var _a;
        var appModulePath = 'src/app/app.module.ts';
        if (!tree.exists(appModulePath)) {
            throw new Error("File ".concat(appModulePath, " not found"));
        }
        context.logger.info('⏳ Updating app.module.ts...');
        var content = (_a = tree.read(appModulePath)) === null || _a === void 0 ? void 0 : _a.toString('utf-8');
        if (!content) {
            throw new Error("Could not read ".concat(appModulePath));
        }
        var project = new ts_morph_1.Project({ useInMemoryFileSystem: true });
        var sourceFile = project.createSourceFile(appModulePath, content, {
            overwrite: true,
        });
        // Find the @NgModule decorator
        var classDeclaration = sourceFile.getClass('AppModule');
        if (!classDeclaration) {
            throw new Error('Could not find AppModule class');
        }
        var decorator = classDeclaration.getDecorator('NgModule');
        if (!decorator) {
            throw new Error('Could not find @NgModule decorator');
        }
        var decoratorArgs = decorator.getArguments();
        if (decoratorArgs.length === 0) {
            throw new Error('@NgModule decorator has no arguments');
        }
        var configObject = decoratorArgs[0];
        if (!configObject.isKind(ts_morph_1.SyntaxKind.ObjectLiteralExpression)) {
            throw new Error('@NgModule decorator argument is not an object');
        }
        removeBootstrapArray(configObject);
        removeDeclarationsArray(configObject);
        removePredefinedProviders(configObject);
        removeBrowserModule(configObject, sourceFile);
        (0, shared_1.formatFile)(sourceFile);
        tree.overwrite(appModulePath, sourceFile.getFullText());
        context.logger.info('✅ Updated app.module.ts');
        return tree;
    };
}
function removeBootstrapArray(configObject) {
    var bootstrapProp = configObject.getProperty('bootstrap');
    if (bootstrapProp) {
        bootstrapProp.remove();
    }
}
function removeDeclarationsArray(configObject) {
    var declarationsProp = configObject.getProperty('declarations');
    if (declarationsProp) {
        declarationsProp.remove();
    }
}
function removePredefinedProviders(configObject) {
    var PROVIDERS_TO_REMOVE = [
        'provideBrowserGlobalErrorListeners',
        'provideZoneChangeDetection',
        'provideHttpClient',
    ];
    var providersProp = configObject.getProperty('providers');
    if (!providersProp || !providersProp.isKind(ts_morph_1.SyntaxKind.PropertyAssignment)) {
        return;
    }
    var initializer = providersProp.getInitializer();
    if (!(initializer === null || initializer === void 0 ? void 0 : initializer.isKind(ts_morph_1.SyntaxKind.ArrayLiteralExpression))) {
        return;
    }
    // Iterate backwards to avoid index shifting when removing elements
    var elements = initializer.getElements();
    for (var i = elements.length - 1; i >= 0; i--) {
        var element = elements[i];
        if (!element.isKind(ts_morph_1.SyntaxKind.CallExpression)) {
            continue;
        }
        var expression = element.getExpression();
        if (!expression.isKind(ts_morph_1.SyntaxKind.Identifier)) {
            continue;
        }
        var functionName = expression.getText();
        if (PROVIDERS_TO_REMOVE.includes(functionName)) {
            initializer.removeElement(i);
        }
    }
    // If providers array is now empty, remove the property
    if (initializer.getElements().length === 0) {
        providersProp.remove();
    }
}
function removeBrowserModule(configObject, sourceFile) {
    var importsProp = configObject.getProperty('imports');
    if (importsProp && importsProp.isKind(ts_morph_1.SyntaxKind.PropertyAssignment)) {
        var initializer = importsProp.getInitializer();
        if (initializer === null || initializer === void 0 ? void 0 : initializer.isKind(ts_morph_1.SyntaxKind.ArrayLiteralExpression)) {
            // Iterate backwards to avoid index shifting when removing elements
            var elements = initializer.getElements();
            for (var i = elements.length - 1; i >= 0; i--) {
                var element = elements[i];
                if (element.isKind(ts_morph_1.SyntaxKind.Identifier) &&
                    element.getText() === 'BrowserModule') {
                    initializer.removeElement(i);
                }
            }
        }
    }
    // Remove BrowserModule import if no longer used
    var browserModuleImport = sourceFile.getImportDeclaration('@angular/platform-browser');
    if (browserModuleImport) {
        var namedImports = browserModuleImport.getNamedImports();
        var browserModuleNamedImport = namedImports.find(function (ni) { return ni.getName() === 'BrowserModule'; });
        if (browserModuleNamedImport) {
            browserModuleNamedImport.remove();
            // If no more named imports, remove the entire import declaration
            if (browserModuleImport.getNamedImports().length === 0) {
                browserModuleImport.remove();
            }
        }
    }
}
//# sourceMappingURL=update-app-module.js.map