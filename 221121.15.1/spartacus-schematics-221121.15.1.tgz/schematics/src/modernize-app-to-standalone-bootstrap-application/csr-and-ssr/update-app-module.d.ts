import { Rule } from '@angular-devkit/schematics';
/**
 * Updates src/app/app.module.ts:
 * - Removes `bootstrap: [AppComponent]`
 * - Removes `declarations: [AppComponent]`
 * - Removes predefined providers (provideBrowserGlobalErrorListeners, provideZoneChangeDetection, provideHttpClient)
 * - Removes BrowserModule from imports
 */
export declare function updateAppModule(): Rule;
