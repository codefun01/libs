import { Rule } from '@angular-devkit/schematics';
/**
 * Updates angular.json to remove standalone: false from schematics configuration:
 * - Removes standalone: false from @schematics/angular:component
 * - Removes standalone: false from @schematics/angular:directive
 * - Removes standalone: false from @schematics/angular:pipe
 */
export declare function updateAngularJson(): Rule;
