import { Rule } from '@angular-devkit/schematics';
/**
 * Creates src/app/app.config.ts with ApplicationConfig including:
 * - provideBrowserGlobalErrorListeners()
 * - provideZoneChangeDetection({ eventCoalescing: true })
 * - provideHttpClient(withFetch(), withInterceptorsFromDi())
 * - importProvidersFrom(AppModule)
 */
export declare function createAppConfig(): Rule;
