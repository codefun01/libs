import { Rule } from '@angular-devkit/schematics';
/**
 * Updates src/app/app.component.ts to be a standalone component:
 * - Removes `standalone: false`
 * - Adds `imports: [StorefrontComponent]`
 * - Adds import for StorefrontComponent from @spartacus/storefront
 */
export declare function updateAppComponent(): Rule;
