"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateMainTs = updateMainTs;
var ts_morph_1 = require("ts-morph");
var shared_1 = require("../../shared");
/**
 * Updates src/main.ts to use bootstrapApplication instead of bootstrapModule:
 * - Replaces platformBrowser import with bootstrapApplication
 * - Adds imports for appConfig and AppComponent
 * - Replaces platformBrowser().bootstrapModule(AppModule) with bootstrapApplication(AppComponent, appConfig)
 */
function updateMainTs() {
    return function (tree, context) {
        var _a;
        var mainTsPath = 'src/main.ts';
        if (!tree.exists(mainTsPath)) {
            throw new Error("File ".concat(mainTsPath, " not found"));
        }
        context.logger.info('⏳ Updating main.ts...');
        var content = (_a = tree.read(mainTsPath)) === null || _a === void 0 ? void 0 : _a.toString('utf-8');
        if (!content) {
            throw new Error("Could not read ".concat(mainTsPath));
        }
        var project = new ts_morph_1.Project({ useInMemoryFileSystem: true });
        var sourceFile = project.createSourceFile(mainTsPath, content, {
            overwrite: true,
        });
        (0, shared_1.removeImportUsingTsMorph)(sourceFile, {
            importName: 'platformBrowser',
            importPath: '@angular/platform-browser',
        });
        // Remove AppModule import (from ./app/app.module)
        var appModuleImport = sourceFile.getImportDeclaration('./app/app.module');
        if (appModuleImport) {
            appModuleImport.remove();
        }
        (0, shared_1.createImports)(sourceFile, [
            {
                namedImports: ['bootstrapApplication'],
                moduleSpecifier: '@angular/platform-browser',
            },
            {
                moduleSpecifier: './app/app.config',
                namedImports: ['appConfig'],
            },
            {
                moduleSpecifier: './app/app.component',
                namedImports: ['AppComponent'],
            },
        ]);
        replaceBootstrapModuleWithBootstrapApplication(sourceFile);
        (0, shared_1.formatFile)(sourceFile);
        tree.overwrite(mainTsPath, sourceFile.getFullText());
        context.logger.info('✅ Updated main.ts');
        return tree;
    };
}
function replaceBootstrapModuleWithBootstrapApplication(sourceFile) {
    // Find and replace platformBrowser().bootstrapModule(AppModule) with bootstrapApplication(AppComponent, appConfig)
    var expressionStatements = sourceFile.getDescendantsOfKind(ts_morph_1.SyntaxKind.ExpressionStatement);
    for (var _i = 0, expressionStatements_1 = expressionStatements; _i < expressionStatements_1.length; _i++) {
        var stmt = expressionStatements_1[_i];
        // Find all CallExpression nodes in this statement
        var callExpressions = stmt.getDescendantsOfKind(ts_morph_1.SyntaxKind.CallExpression);
        for (var _a = 0, callExpressions_1 = callExpressions; _a < callExpressions_1.length; _a++) {
            var callExpr = callExpressions_1[_a];
            var callExprExpression = callExpr.getExpression();
            if (callExprExpression.getKind() === ts_morph_1.SyntaxKind.PropertyAccessExpression) {
                var propAccess = callExprExpression.asKind(ts_morph_1.SyntaxKind.PropertyAccessExpression);
                if (propAccess &&
                    propAccess.getName() === 'bootstrapModule' &&
                    propAccess.getExpression().getText() === 'platformBrowser()') {
                    // Replace this call expression with bootstrapApplication(AppComponent, appConfig)
                    callExpr.replaceWithText('bootstrapApplication(AppComponent, appConfig)');
                    break;
                }
            }
        }
    }
}
//# sourceMappingURL=update-main-ts.js.map