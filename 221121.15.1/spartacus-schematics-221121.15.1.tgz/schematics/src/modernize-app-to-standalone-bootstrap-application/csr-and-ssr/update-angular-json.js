"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAngularJson = updateAngularJson;
var workspace_utils_1 = require("../../shared/utils/workspace-utils");
/**
 * Updates angular.json to remove standalone: false from schematics configuration:
 * - Removes standalone: false from @schematics/angular:component
 * - Removes standalone: false from @schematics/angular:directive
 * - Removes standalone: false from @schematics/angular:pipe
 */
function updateAngularJson() {
    return function (tree, context) {
        context.logger.info('⏳ Updating angular.json...');
        var _a = (0, workspace_utils_1.getWorkspace)(tree), workspace = _a.workspace, path = _a.path;
        // Update schematics configuration at root level
        if (workspace.schematics) {
            removeStandaloneFalse(workspace.schematics);
        }
        // Update schematics configuration in each project
        if (workspace.projects) {
            for (var _i = 0, _b = Object.keys(workspace.projects); _i < _b.length; _i++) {
                var projectName = _b[_i];
                var project = workspace.projects[projectName];
                if (project.schematics) {
                    removeStandaloneFalse(project.schematics);
                }
            }
        }
        tree.overwrite(path, JSON.stringify(workspace, null, 2));
        context.logger.info('✅ Updated angular.json');
        return tree;
    };
}
/**
 * Removes standalone: false from component, directive, and pipe schematics
 */
function removeStandaloneFalse(schematics) {
    var schematicsToUpdate = [
        '@schematics/angular:component',
        '@schematics/angular:directive',
        '@schematics/angular:pipe',
    ];
    for (var _i = 0, schematicsToUpdate_1 = schematicsToUpdate; _i < schematicsToUpdate_1.length; _i++) {
        var schematicName = schematicsToUpdate_1[_i];
        if (schematics[schematicName]) {
            delete schematics[schematicName].standalone;
        }
    }
}
//# sourceMappingURL=update-angular-json.js.map