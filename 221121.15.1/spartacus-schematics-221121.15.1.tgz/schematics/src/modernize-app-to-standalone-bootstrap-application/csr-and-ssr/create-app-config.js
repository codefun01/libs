"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAppConfig = createAppConfig;
/**
 * Creates src/app/app.config.ts with ApplicationConfig including:
 * - provideBrowserGlobalErrorListeners()
 * - provideZoneChangeDetection({ eventCoalescing: true })
 * - provideHttpClient(withFetch(), withInterceptorsFromDi())
 * - importProvidersFrom(AppModule)
 */
function createAppConfig() {
    return function (tree, context) {
        var appConfigPath = 'src/app/app.config.ts';
        if (tree.exists(appConfigPath)) {
            context.logger.warn("\u26A0\uFE0F File ".concat(appConfigPath, " already exists, skipping creation"));
            return tree;
        }
        context.logger.info('⏳ Creating app.config.ts...');
        var appConfigContent = "\nimport {\n  ApplicationConfig,\n  importProvidersFrom,\n  provideBrowserGlobalErrorListeners,\n  provideZoneChangeDetection\n} from '@angular/core';\nimport {\n  provideHttpClient,\n  withFetch,\n  withInterceptorsFromDi,\n} from '@angular/common/http';\nimport { AppModule } from './app.module';\n\nexport const appConfig: ApplicationConfig = {\n  providers: [\n    provideBrowserGlobalErrorListeners(),\n    provideZoneChangeDetection({ eventCoalescing: true }),\n    provideHttpClient(withFetch(), withInterceptorsFromDi()),\n    importProvidersFrom(AppModule),\n  ],\n};\n";
        tree.create(appConfigPath, appConfigContent);
        context.logger.info('✅ Created app.config.ts');
        return tree;
    };
}
//# sourceMappingURL=create-app-config.js.map