"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrate = migrate;
var schematics_1 = require("@angular-devkit/schematics");
var package_utils_1 = require("../shared/utils/package-utils");
var create_app_config_1 = require("./csr-and-ssr/create-app-config");
var update_angular_json_1 = require("./csr-and-ssr/update-angular-json");
var update_app_component_1 = require("./csr-and-ssr/update-app-component");
var update_app_module_1 = require("./csr-and-ssr/update-app-module");
var update_main_ts_1 = require("./csr-and-ssr/update-main-ts");
var fallback_advice_to_follow_docs_1 = require("./fallback-advice-to-follow-docs");
var create_app_config_server_1 = require("./ssr/create-app-config-server");
var move_hydration_config_1 = require("./ssr/move-hydration-config");
var update_app_module_server_1 = require("./ssr/update-app-module-server");
var update_main_server_ts_1 = require("./ssr/update-main-server-ts");
var update_server_ts_1 = require("./ssr/update-server-ts");
/**
 * Migration schematic to modernize Angular apps to use standalone bootstrapApplication API.
 *
 * This migration automates the process of converting from:
 * - `platformBrowser().bootstrapModule(AppModule)` to `bootstrapApplication(AppComponent, appConfig)`
 */
function migrate() {
    return function (tree, _context) {
        return (0, schematics_1.chain)(__spreadArray([
            // Common transformations for both CSR and SSR apps
            (0, fallback_advice_to_follow_docs_1.withFallbackDocsForStandaloneBootstrap)((0, update_app_component_1.updateAppComponent)()),
            (0, fallback_advice_to_follow_docs_1.withFallbackDocsForStandaloneBootstrap)((0, update_app_module_1.updateAppModule)()),
            (0, fallback_advice_to_follow_docs_1.withFallbackDocsForStandaloneBootstrap)((0, create_app_config_1.createAppConfig)()),
            (0, fallback_advice_to_follow_docs_1.withFallbackDocsForStandaloneBootstrap)((0, update_main_ts_1.updateMainTs)()),
            (0, fallback_advice_to_follow_docs_1.withFallbackDocsForStandaloneBootstrap)((0, update_angular_json_1.updateAngularJson)())
        ], ((0, package_utils_1.isSsrUsed)(tree)
            ? [
                (0, fallback_advice_to_follow_docs_1.withFallbackDocsForStandaloneBootstrap)((0, move_hydration_config_1.moveHydrationConfig)()),
                (0, fallback_advice_to_follow_docs_1.withFallbackDocsForStandaloneBootstrap)((0, create_app_config_server_1.createAppConfigServer)()),
                (0, fallback_advice_to_follow_docs_1.withFallbackDocsForStandaloneBootstrap)((0, update_app_module_server_1.updateAppModuleServer)()),
                (0, fallback_advice_to_follow_docs_1.withFallbackDocsForStandaloneBootstrap)((0, update_main_server_ts_1.updateMainServerTs)()),
                (0, fallback_advice_to_follow_docs_1.withFallbackDocsForStandaloneBootstrap)((0, update_server_ts_1.updateServerTs)()),
            ]
            : []), true));
    };
}
//# sourceMappingURL=index.js.map