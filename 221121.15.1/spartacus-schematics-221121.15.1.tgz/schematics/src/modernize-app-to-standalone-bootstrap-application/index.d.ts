import { Rule } from '@angular-devkit/schematics';
/**
 * Migration schematic to modernize Angular apps to use standalone bootstrapApplication API.
 *
 * This migration automates the process of converting from:
 * - `platformBrowser().bootstrapModule(AppModule)` to `bootstrapApplication(AppComponent, appConfig)`
 */
export declare function migrate(): Rule;
