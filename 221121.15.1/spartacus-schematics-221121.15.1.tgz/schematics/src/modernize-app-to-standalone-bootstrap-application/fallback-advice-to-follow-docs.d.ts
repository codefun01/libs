import { Rule, SchematicContext } from '@angular-devkit/schematics';
/**
 * URL where to find the manual migration steps.
 */
export declare const DOCS_URL_FOR_MODERNIZING_STANDALONE_BOOTSTRAP = "https://help.sap.com/docs/SAP_COMMERCE_COMPOSABLE_STOREFRONT/10a8bc7f635b4e3db6f6bb7880e58a7d/f33df55121a1426eacb600ca1246203d.html";
/**
 * Prints an error message and a link to the manual migration steps.
 */
export declare function printErrorWithDocsForStandaloneBootstrap(message: string, context: SchematicContext): void;
/**
 * If the wrapped Rule throws an error, it logs the error and prints a link to manual migration docs.
 */
export declare function withFallbackDocsForStandaloneBootstrap(rule: Rule): Rule;
