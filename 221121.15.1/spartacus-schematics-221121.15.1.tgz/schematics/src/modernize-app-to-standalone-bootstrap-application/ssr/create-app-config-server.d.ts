import { Rule } from '@angular-devkit/schematics';
/**
 * Creates src/app/app.config.server.ts with server configuration:
 * - Imports appConfig from app.config
 * - Adds provideServerRendering()
 * - Uses mergeApplicationConfig to combine configs
 * - Imports AppServerModule providers
 */
export declare function createAppConfigServer(): Rule;
