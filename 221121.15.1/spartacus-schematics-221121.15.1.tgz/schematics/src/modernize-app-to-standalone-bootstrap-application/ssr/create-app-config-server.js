"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAppConfigServer = createAppConfigServer;
/**
 * Creates src/app/app.config.server.ts with server configuration:
 * - Imports appConfig from app.config
 * - Adds provideServerRendering()
 * - Uses mergeApplicationConfig to combine configs
 * - Imports AppServerModule providers
 */
function createAppConfigServer() {
    return function (tree, context) {
        var appConfigServerPath = 'src/app/app.config.server.ts';
        if (tree.exists(appConfigServerPath)) {
            context.logger.warn("\u26A0\uFE0F File ".concat(appConfigServerPath, " already exists, skipping creation"));
            return tree;
        }
        context.logger.info('⏳ Creating app.config.server.ts...');
        var appConfigServerContent = "import { mergeApplicationConfig, ApplicationConfig, importProvidersFrom } from '@angular/core';\nimport { provideServerRendering } from '@angular/platform-server';\nimport { appConfig } from './app.config';\nimport { AppServerModule } from './app.module.server';\n\nconst serverConfig: ApplicationConfig = {\n  providers: [\n    provideServerRendering(),\n    importProvidersFrom(AppServerModule),\n  ],\n};\n\nexport const config = mergeApplicationConfig(appConfig, serverConfig);\n";
        tree.create(appConfigServerPath, appConfigServerContent);
        context.logger.info('✅ Created app.config.server.ts');
        return tree;
    };
}
//# sourceMappingURL=create-app-config-server.js.map