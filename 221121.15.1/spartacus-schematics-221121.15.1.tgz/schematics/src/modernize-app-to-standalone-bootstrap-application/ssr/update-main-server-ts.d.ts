import { Rule } from '@angular-devkit/schematics';
/**
 * Updates src/main.server.ts:
 * - Removes `export { AppServerModule as default }`
 * - Adds imports for BootstrapContext, bootstrapApplication, AppComponent, config
 * - Exports bootstrap function
 */
export declare function updateMainServerTs(): Rule;
