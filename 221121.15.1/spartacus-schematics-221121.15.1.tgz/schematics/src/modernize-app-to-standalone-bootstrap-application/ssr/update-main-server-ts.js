"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateMainServerTs = updateMainServerTs;
var ts_morph_1 = require("ts-morph");
var shared_1 = require("../../shared");
/**
 * Updates src/main.server.ts:
 * - Removes `export { AppServerModule as default }`
 * - Adds imports for BootstrapContext, bootstrapApplication, AppComponent, config
 * - Exports bootstrap function
 */
function updateMainServerTs() {
    return function (tree, context) {
        var _a;
        var mainServerPath = 'src/main.server.ts';
        if (!tree.exists(mainServerPath)) {
            context.logger.warn("\u26A0\uFE0F File ".concat(mainServerPath, " not found, skipping"));
            return tree;
        }
        context.logger.info('⏳ Updating main.server.ts...');
        var content = (_a = tree.read(mainServerPath)) === null || _a === void 0 ? void 0 : _a.toString('utf-8');
        if (!content) {
            throw new Error("Could not read ".concat(mainServerPath));
        }
        var project = new ts_morph_1.Project({ useInMemoryFileSystem: true });
        var sourceFile = project.createSourceFile(mainServerPath, content, {
            overwrite: true,
        });
        removeAppServerModuleDefaultExport(sourceFile);
        removeAppServerModuleImport(sourceFile);
        addBootstrapFunctionExport(sourceFile);
        (0, shared_1.formatFile)(sourceFile);
        tree.overwrite(mainServerPath, sourceFile.getFullText());
        context.logger.info('✅ Updated main.server.ts');
        return tree;
    };
}
function removeAppServerModuleDefaultExport(sourceFile) {
    var _a;
    // Remove the export { AppServerModule as default } or export default AppServerModule
    var exportDeclarations = sourceFile.getExportDeclarations();
    for (var _i = 0, exportDeclarations_1 = exportDeclarations; _i < exportDeclarations_1.length; _i++) {
        var exportDecl = exportDeclarations_1[_i];
        var moduleSpecifier = (_a = exportDecl.getModuleSpecifier()) === null || _a === void 0 ? void 0 : _a.getText();
        if (moduleSpecifier === null || moduleSpecifier === void 0 ? void 0 : moduleSpecifier.includes('app.module.server')) {
            exportDecl.remove();
        }
    }
    // Also check for export assignments
    var exportAssignments = sourceFile.getDescendantsOfKind(ts_morph_1.SyntaxKind.ExportAssignment);
    for (var _b = 0, exportAssignments_1 = exportAssignments; _b < exportAssignments_1.length; _b++) {
        var exportAssignment = exportAssignments_1[_b];
        exportAssignment.remove();
    }
}
function removeAppServerModuleImport(sourceFile) {
    // Remove AppServerModule import
    var appServerModuleImport = sourceFile.getImportDeclaration('./app/app.module.server');
    if (appServerModuleImport) {
        appServerModuleImport.remove();
    }
}
function addBootstrapFunctionExport(sourceFile) {
    (0, shared_1.createImports)(sourceFile, [
        {
            moduleSpecifier: '@angular/platform-browser',
            namedImports: ['BootstrapContext', 'bootstrapApplication'],
        },
        {
            moduleSpecifier: './app/app.component',
            namedImports: ['AppComponent'],
        },
        {
            moduleSpecifier: './app/app.config.server',
            namedImports: ['config'],
        },
    ]);
    // Add bootstrap function export
    var bootstrapFunction = "\nconst bootstrap = (context: BootstrapContext) =>\n  bootstrapApplication(AppComponent, config, context);\n\nexport default bootstrap;\n";
    sourceFile.addStatements(bootstrapFunction);
}
//# sourceMappingURL=update-main-server-ts.js.map