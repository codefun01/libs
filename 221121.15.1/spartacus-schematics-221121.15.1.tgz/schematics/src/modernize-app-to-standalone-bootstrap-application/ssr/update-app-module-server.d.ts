import { Rule } from '@angular-devkit/schematics';
/**
 * Updates src/app/app.module.server.ts:
 * - Removes `imports: [AppModule]`
 * - Removes `bootstrap: [AppComponent]`
 */
export declare function updateAppModuleServer(): Rule;
