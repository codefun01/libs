import { Rule } from '@angular-devkit/schematics';
/**
 * Updates src/server.ts:
 * - Renames import from AppServerModule to bootstrap
 * - Updates ngExpressEngine({ bootstrap: AppServerModule }) to use bootstrap
 */
export declare function updateServerTs(): Rule;
