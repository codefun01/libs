"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAppModuleServer = updateAppModuleServer;
var ts_morph_1 = require("ts-morph");
var shared_1 = require("../../shared");
/**
 * Updates src/app/app.module.server.ts:
 * - Removes `imports: [AppModule]`
 * - Removes `bootstrap: [AppComponent]`
 */
function updateAppModuleServer() {
    return function (tree, context) {
        var _a;
        var appModuleServerPath = 'src/app/app.module.server.ts';
        if (!tree.exists(appModuleServerPath)) {
            context.logger.warn("\u26A0\uFE0F File ".concat(appModuleServerPath, " not found, skipping"));
            return tree;
        }
        context.logger.info('⏳ Updating app.module.server.ts...');
        var content = (_a = tree.read(appModuleServerPath)) === null || _a === void 0 ? void 0 : _a.toString('utf-8');
        if (!content) {
            throw new Error("Could not read ".concat(appModuleServerPath));
        }
        var project = new ts_morph_1.Project({ useInMemoryFileSystem: true });
        var sourceFile = project.createSourceFile(appModuleServerPath, content, {
            overwrite: true,
        });
        // Find the @NgModule decorator
        var classDeclaration = sourceFile.getClass('AppServerModule');
        if (!classDeclaration) {
            throw new Error('Could not find AppServerModule class');
        }
        var decorator = classDeclaration.getDecorator('NgModule');
        if (!decorator) {
            throw new Error('Could not find @NgModule decorator');
        }
        var decoratorArgs = decorator.getArguments();
        if (decoratorArgs.length === 0) {
            throw new Error('@NgModule decorator has no arguments');
        }
        var configObject = decoratorArgs[0];
        if (!configObject.isKind(ts_morph_1.SyntaxKind.ObjectLiteralExpression)) {
            throw new Error('@NgModule decorator argument is not an object');
        }
        removeAppModuleAndServerModuleFromImports(configObject);
        removeBootstrapArray(configObject);
        (0, shared_1.removeImportUsingTsMorph)(sourceFile, {
            importPath: 'src/app/app.module',
            importName: 'AppModule',
        });
        (0, shared_1.removeImportUsingTsMorph)(sourceFile, {
            importPath: '@angular/platform-server',
            importName: 'ServerModule',
        });
        (0, shared_1.formatFile)(sourceFile);
        tree.overwrite(appModuleServerPath, sourceFile.getFullText());
        context.logger.info('✅ Updated app.module.server.ts');
        return tree;
    };
}
function removeAppModuleAndServerModuleFromImports(configObject) {
    // Remove specific elements from imports array (AppModule and ServerModule)
    var importsProp = configObject.getProperty('imports');
    if (importsProp && importsProp.isKind(ts_morph_1.SyntaxKind.PropertyAssignment)) {
        var initializer = importsProp.getInitializer();
        if (initializer && initializer.isKind(ts_morph_1.SyntaxKind.ArrayLiteralExpression)) {
            var elements = initializer.getElements();
            // Iterate backwards to safely remove elements
            for (var i = elements.length - 1; i >= 0; i--) {
                var element = elements[i];
                var text = element.getText();
                if (text === 'AppModule' || text === 'ServerModule') {
                    initializer.removeElement(i);
                }
            }
        }
    }
}
function removeBootstrapArray(configObject) {
    // Remove bootstrap property
    var bootstrapProp = configObject.getProperty('bootstrap');
    if (bootstrapProp) {
        bootstrapProp.remove();
    }
}
//# sourceMappingURL=update-app-module-server.js.map