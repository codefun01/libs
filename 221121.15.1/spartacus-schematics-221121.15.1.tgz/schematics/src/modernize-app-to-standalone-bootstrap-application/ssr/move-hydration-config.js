"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.moveHydrationConfig = moveHydrationConfig;
var ts_morph_1 = require("ts-morph");
var get_app_config_providers_1 = require("../../add-ssr/get-app-config-providers");
var shared_1 = require("../../shared");
/**
 * Moves provideClientHydration from app.module.ts to app.config.ts
 * This is needed for SSR applications
 */
function moveHydrationConfig() {
    return function (tree, context) {
        var _a;
        var appModulePath = 'src/app/app.module.ts';
        var appConfigPath = 'src/app/app.config.ts';
        if (!tree.exists(appModulePath)) {
            throw new Error("File ".concat(appModulePath, " not found"));
        }
        if (!tree.exists(appConfigPath)) {
            throw new Error("File ".concat(appConfigPath, " not found"));
        }
        context.logger.info('⏳ Moving hydration config from app.module.ts to app.config.ts...');
        // Read app.module.ts
        var appModuleContent = (_a = tree.read(appModulePath)) === null || _a === void 0 ? void 0 : _a.toString('utf-8');
        if (!appModuleContent) {
            throw new Error("Could not read ".concat(appModulePath));
        }
        var project = new ts_morph_1.Project({ useInMemoryFileSystem: true });
        var appModuleSource = project.createSourceFile(appModulePath, appModuleContent, { overwrite: true });
        var hydrationCallExpression = findAndRemoveHydrationConfigInAppModule(appModuleSource, appModulePath, tree);
        // If we found hydration config, move it to app.config.ts
        if (hydrationCallExpression) {
            addHydrationConfigToAppConfig(appConfigPath, hydrationCallExpression, tree, project);
            context.logger.info('✅ Moved hydration config to app.config.ts');
        }
        else {
            context.logger.info('ℹ️ No hydration config found in app.module.ts, skipping');
        }
        return tree;
    };
}
/**
 * Finds and removes provideClientHydration in app.module.ts
 * Returns the removed expression as string, or null if not found
 */
function findAndRemoveHydrationConfigInAppModule(appModuleSource, appModulePath, tree) {
    var classDeclaration = appModuleSource.getClass('AppModule');
    if (!classDeclaration) {
        return null;
    }
    var decorator = classDeclaration.getDecorator('NgModule');
    if (!decorator) {
        return null;
    }
    var decoratorArgs = decorator.getArguments();
    if (decoratorArgs.length === 0) {
        return null;
    }
    var configObject = decoratorArgs[0];
    if (!configObject.isKind(ts_morph_1.SyntaxKind.ObjectLiteralExpression)) {
        return null;
    }
    var providersProp = configObject.getProperty('providers');
    if (!providersProp || !providersProp.isKind(ts_morph_1.SyntaxKind.PropertyAssignment)) {
        return null;
    }
    var initializer = providersProp.getInitializer();
    if (!(initializer === null || initializer === void 0 ? void 0 : initializer.isKind(ts_morph_1.SyntaxKind.ArrayLiteralExpression))) {
        return null;
    }
    return findAndRemoveHydrationElement(initializer, providersProp, appModuleSource, appModulePath, tree);
}
function findAndRemoveHydrationElement(providersArray, providersProp, appModuleSource, appModulePath, tree) {
    var hydrationElementIndex = findHydrationElementIndex(providersArray);
    if (hydrationElementIndex === -1) {
        return null;
    }
    var hydrationElement = providersArray.getElements()[hydrationElementIndex];
    var hydrationCallExpression = hydrationElement.getText();
    providersArray.removeElement(hydrationElementIndex);
    removeProvidersPropertyIfEmpty(providersArray, providersProp);
    (0, shared_1.formatFile)(appModuleSource);
    tree.overwrite(appModulePath, appModuleSource.getFullText());
    return hydrationCallExpression;
}
function findHydrationElementIndex(providersArray) {
    return providersArray.getElements().findIndex(function (element) {
        if (!element.isKind(ts_morph_1.SyntaxKind.CallExpression)) {
            return false;
        }
        var expression = element.getExpression();
        return (expression.isKind(ts_morph_1.SyntaxKind.Identifier) &&
            expression.getText() === 'provideClientHydration');
    });
}
function removeProvidersPropertyIfEmpty(providersArray, providersProp) {
    if (providersArray.getElements().length === 0) {
        providersProp.remove();
    }
}
function addHydrationConfigToAppConfig(appConfigPath, hydrationCallExpression, tree, project) {
    var appConfigContent = tree.readText(appConfigPath);
    if (!appConfigContent) {
        throw new Error("Could not read ".concat(appConfigPath));
    }
    var appConfigSource = project.createSourceFile(appConfigPath, appConfigContent, { overwrite: true });
    (0, shared_1.createImports)(appConfigSource, [
        {
            moduleSpecifier: '@angular/platform-browser',
            namedImports: [
                'provideClientHydration',
                'withEventReplay',
                'withNoHttpTransferCache',
            ],
        },
    ]);
    // Add hydration config to app.config.ts providers
    var providersArray = (0, get_app_config_providers_1.getAppConfigProviders)(appConfigSource);
    if (providersArray) {
        // Add at the beginning of the providers array
        providersArray.insertElement(0, hydrationCallExpression);
    }
    (0, shared_1.formatFile)(appConfigSource);
    tree.overwrite(appConfigPath, appConfigSource.getFullText());
}
//# sourceMappingURL=move-hydration-config.js.map