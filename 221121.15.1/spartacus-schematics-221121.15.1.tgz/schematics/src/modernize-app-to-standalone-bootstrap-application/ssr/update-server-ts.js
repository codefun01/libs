"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateServerTs = updateServerTs;
var ts_morph_1 = require("ts-morph");
var shared_1 = require("../../shared");
/**
 * Updates src/server.ts:
 * - Renames import from AppServerModule to bootstrap
 * - Updates ngExpressEngine({ bootstrap: AppServerModule }) to use bootstrap
 */
function updateServerTs() {
    return function (tree, context) {
        var _a;
        var serverTsPath = 'src/server.ts';
        if (!tree.exists(serverTsPath)) {
            context.logger.warn("\u26A0\uFE0F File ".concat(serverTsPath, " not found, skipping"));
            return tree;
        }
        context.logger.info('⏳ Updating server.ts...');
        var content = (_a = tree.read(serverTsPath)) === null || _a === void 0 ? void 0 : _a.toString('utf-8');
        if (!content) {
            throw new Error("Could not read ".concat(serverTsPath));
        }
        var project = new ts_morph_1.Project({ useInMemoryFileSystem: true });
        var sourceFile = project.createSourceFile(serverTsPath, content, {
            overwrite: true,
        });
        renameDefaultImportFromAppServerModuleToBootstrap(sourceFile);
        renameReferencesOfAppServerModuleToBootstrap(sourceFile);
        (0, shared_1.formatFile)(sourceFile);
        tree.overwrite(serverTsPath, sourceFile.getFullText());
        context.logger.info('✅ Updated server.ts');
        return tree;
    };
}
function renameDefaultImportFromAppServerModuleToBootstrap(sourceFile) {
    // Find and update the import from main.server
    var mainServerImport = sourceFile.getImportDeclaration('./main.server');
    if (mainServerImport) {
        var defaultImport = mainServerImport.getDefaultImport();
        if (defaultImport) {
            // Rename AppServerModule to bootstrap
            var currentName = defaultImport.getText();
            if (currentName === 'AppServerModule') {
                defaultImport.rename('bootstrap');
            }
        }
        else {
            // If no default import exists, add it
            mainServerImport.setDefaultImport('bootstrap');
        }
        // Remove named imports if any (AppServerModule)
        var namedImports = mainServerImport.getNamedImports();
        for (var _i = 0, namedImports_1 = namedImports; _i < namedImports_1.length; _i++) {
            var namedImport = namedImports_1[_i];
            if (namedImport.getName() === 'AppServerModule') {
                namedImport.remove();
            }
        }
    }
}
function renameReferencesOfAppServerModuleToBootstrap(sourceFile) {
    // Update any references to AppServerModule to bootstrap
    var identifiers = sourceFile.getDescendantsOfKind(ts_morph_1.SyntaxKind.Identifier);
    for (var _i = 0, identifiers_1 = identifiers; _i < identifiers_1.length; _i++) {
        var identifier = identifiers_1[_i];
        if (identifier.getText() === 'AppServerModule') {
            identifier.replaceWithText('bootstrap');
        }
    }
}
//# sourceMappingURL=update-server-ts.js.map