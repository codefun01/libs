import { Rule } from '@angular-devkit/schematics';
/**
 * Moves provideClientHydration from app.module.ts to app.config.ts
 * This is needed for SSR applications
 */
export declare function moveHydrationConfig(): Rule;
