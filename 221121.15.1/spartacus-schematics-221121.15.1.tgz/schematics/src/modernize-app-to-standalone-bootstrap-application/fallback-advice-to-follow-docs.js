"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.DOCS_URL_FOR_MODERNIZING_STANDALONE_BOOTSTRAP = void 0;
exports.printErrorWithDocsForStandaloneBootstrap = printErrorWithDocsForStandaloneBootstrap;
exports.withFallbackDocsForStandaloneBootstrap = withFallbackDocsForStandaloneBootstrap;
/**
 * URL where to find the manual migration steps.
 */
exports.DOCS_URL_FOR_MODERNIZING_STANDALONE_BOOTSTRAP = 'https://help.sap.com/docs/SAP_COMMERCE_COMPOSABLE_STOREFRONT/10a8bc7f635b4e3db6f6bb7880e58a7d/f33df55121a1426eacb600ca1246203d.html';
var FALLBACK_ADVICE_TO_FOLLOW_DOCS = "Could not complete this step automatically. To complete the migration, please follow the manual steps: ".concat(exports.DOCS_URL_FOR_MODERNIZING_STANDALONE_BOOTSTRAP);
/**
 * Prints an error message and a link to the manual migration steps.
 */
function printErrorWithDocsForStandaloneBootstrap(message, context) {
    context.logger.error("\u26A0\uFE0F ".concat(message));
    context.logger.error(FALLBACK_ADVICE_TO_FOLLOW_DOCS);
}
/**
 * If the wrapped Rule throws an error, it logs the error and prints a link to manual migration docs.
 */
function withFallbackDocsForStandaloneBootstrap(rule) {
    return function (tree, context) {
        try {
            return rule(tree, context);
        }
        catch (error) {
            printErrorWithDocsForStandaloneBootstrap(error instanceof Error ? error.message : 'Unknown error', context);
            return tree;
        }
    };
}
//# sourceMappingURL=fallback-advice-to-follow-docs.js.map