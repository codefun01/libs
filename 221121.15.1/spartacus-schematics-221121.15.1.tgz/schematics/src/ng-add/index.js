"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
var schematics_1 = require("@angular-devkit/schematics");
function default_1(options) {
    return function (host, context) {
        return (0, schematics_1.chain)([
            (0, schematics_1.schematic)('add-spartacus', options),
            options.ssr ? (0, schematics_1.schematic)('add-ssr', options) : (0, schematics_1.noop)(),
        ])(host, context);
    };
}
//# sourceMappingURL=index.js.map