import { Rule } from '@angular-devkit/schematics';
/**
 * Modernizes an application migrated from Angular v2211.32 to v2211.36
 * to align with new Angular 19 standards.
 */
export declare function migrate(): Rule;
