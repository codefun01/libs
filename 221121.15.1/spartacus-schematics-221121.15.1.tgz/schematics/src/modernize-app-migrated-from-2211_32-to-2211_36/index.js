"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrate = migrate;
var schematics_1 = require("@angular-devkit/schematics");
var package_utils_1 = require("../shared/utils/package-utils");
var move_assets_to_public_1 = require("./csr-and-ssr/move-assets-to-public");
var move_favicon_to_public_1 = require("./csr-and-ssr/move-favicon-to-public");
var update_angular_json_1 = require("./csr-and-ssr/update-angular-json");
var update_i18n_lazy_loading_config_1 = require("./csr-and-ssr/update-i18n-lazy-loading-config");
var update_main_ts_1 = require("./csr-and-ssr/update-main-ts");
var update_ts_config_1 = require("./csr-and-ssr/update-ts-config");
var fallback_advice_to_follow_docs_1 = require("./fallback-advice-to-follow-docs");
var update_angular_json_for_ssr_1 = require("./ssr/update-angular-json-for-ssr");
var update_server_ts_1 = require("./ssr/update-server-ts");
var update_ts_config_app_1 = require("./ssr/update-ts-config-app");
/**
 * Modernizes an application migrated from Angular v2211.32 to v2211.36
 * to align with new Angular 19 standards.
 */
function migrate() {
    return function (tree, _context) {
        return (0, schematics_1.chain)(__spreadArray([
            (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_2211_32_To_2211_36)((0, update_angular_json_1.updateAngularJson)()),
            (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_2211_32_To_2211_36)((0, update_ts_config_1.updateTsConfig)()),
            (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_2211_32_To_2211_36)((0, move_assets_to_public_1.moveAssetsToPublic)()),
            (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_2211_32_To_2211_36)((0, move_favicon_to_public_1.moveFaviconToPublic)()),
            (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_2211_32_To_2211_36)((0, update_main_ts_1.updateMainTs)()),
            (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_2211_32_To_2211_36)((0, update_i18n_lazy_loading_config_1.updateI18nLazyLoadingConfig)())
        ], ((0, package_utils_1.isSsrUsed)(tree)
            ? [
                (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_2211_32_To_2211_36)((0, update_server_ts_1.updateServerTs)()),
                (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_2211_32_To_2211_36)((0, update_angular_json_for_ssr_1.updateAngularJsonForSsr)()),
                (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_2211_32_To_2211_36)((0, update_ts_config_app_1.updateTsConfigApp)()),
            ]
            : []), true));
    };
}
//# sourceMappingURL=index.js.map