"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateTsConfigApp = updateTsConfigApp;
var jsonc_parser_1 = require("jsonc-parser");
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Updates the `tsconfig.app.json` to adapt to the new Angular v19 standards.
 *
 * It updates the path in the "files" array from `server.ts` to `src/server.ts`.
 */
function updateTsConfigApp() {
    return function (tree, context) {
        var tsconfigAppPath = 'tsconfig.app.json';
        context.logger.info("\n\u23F3 Updating ".concat(tsconfigAppPath, "..."));
        if (!tree.exists(tsconfigAppPath)) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("".concat(tsconfigAppPath, " file not found"), context);
            return;
        }
        var tsConfigContent = tree.read(tsconfigAppPath);
        if (!tsConfigContent) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("Failed to read ".concat(tsconfigAppPath, " file"), context);
            return;
        }
        var tsConfig = (0, jsonc_parser_1.parse)(tsConfigContent.toString());
        var oldPath = 'server.ts';
        var newPath = 'src/server.ts';
        context.logger.info("  \u21B3 Updating path in \"files\" array from \"".concat(oldPath, "\" to \"").concat(newPath, "\""));
        if (Array.isArray(tsConfig.files)) {
            var serverTsIndex = tsConfig.files.indexOf(oldPath);
            if (serverTsIndex !== -1) {
                tsConfig.files[serverTsIndex] = newPath;
            }
            else {
                (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("Path \"".concat(oldPath, "\" not found in \"files\" array"), context);
                return;
            }
        }
        else {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("\"files\" array not found in ".concat(tsconfigAppPath), context);
            return;
        }
        var JSON_INDENT = 2;
        tree.overwrite(tsconfigAppPath, JSON.stringify(tsConfig, null, JSON_INDENT));
        context.logger.info("\u2705 Updated ".concat(tsconfigAppPath));
    };
}
//# sourceMappingURL=update-ts-config-app.js.map