import { Rule } from '@angular-devkit/schematics';
/**
 * Updates the `tsconfig.app.json` to adapt to the new Angular v19 standards.
 *
 * It updates the path in the "files" array from `server.ts` to `src/server.ts`.
 */
export declare function updateTsConfigApp(): Rule;
