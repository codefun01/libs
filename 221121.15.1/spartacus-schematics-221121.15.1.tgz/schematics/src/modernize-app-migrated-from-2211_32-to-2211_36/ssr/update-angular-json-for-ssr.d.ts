import { Rule } from '@angular-devkit/schematics';
/**
 * Updates the Angular configuration related to SSR for new Angular v19 standards.
 *
 * It updates the "ssr.entry" path in the "build" target,
 * to use the new path with the `src/server.ts` file,
 * instead of `server.ts`.
 */
export declare function updateAngularJsonForSsr(): Rule;
