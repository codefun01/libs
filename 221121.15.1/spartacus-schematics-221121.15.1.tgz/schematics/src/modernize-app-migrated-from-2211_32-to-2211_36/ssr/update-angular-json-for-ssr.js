"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAngularJsonForSsr = updateAngularJsonForSsr;
var workspace_utils_1 = require("../../shared/utils/workspace-utils");
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Updates the Angular configuration related to SSR for new Angular v19 standards.
 *
 * It updates the "ssr.entry" path in the "build" target,
 * to use the new path with the `src/server.ts` file,
 * instead of `server.ts`.
 */
function updateAngularJsonForSsr() {
    return function (tree, context) {
        var _a, _b, _c;
        context.logger.info('\n⏳ Updating angular.json for SSR...');
        var _d = (0, workspace_utils_1.getWorkspace)(tree), workspace = _d.workspace, path = _d.path;
        var project = workspace.projects[Object.keys(workspace.projects)[0]];
        if (!project) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)('No project found in workspace', context);
            return;
        }
        var buildTarget = (_a = project.architect) === null || _a === void 0 ? void 0 : _a.build;
        if (!buildTarget) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)('No build target found in project configuration', context);
            return;
        }
        var oldEntryPath = buildTarget.options.ssr.entry;
        var newEntryPath = 'src/server.ts';
        context.logger.info("  \u21B3 Updating \"ssr.entry\" path in build target from \"".concat(oldEntryPath, "\" to \"").concat(newEntryPath, "\""));
        if ((_c = (_b = buildTarget.options) === null || _b === void 0 ? void 0 : _b.ssr) === null || _c === void 0 ? void 0 : _c.entry) {
            buildTarget.options.ssr.entry = newEntryPath;
        }
        else {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)('No "ssr.entry" path found in build target', context);
            return;
        }
        var JSON_INDENT = 2;
        tree.overwrite(path, JSON.stringify(workspace, null, JSON_INDENT));
        context.logger.info('✅ Updated angular.json for SSR');
    };
}
//# sourceMappingURL=update-angular-json-for-ssr.js.map