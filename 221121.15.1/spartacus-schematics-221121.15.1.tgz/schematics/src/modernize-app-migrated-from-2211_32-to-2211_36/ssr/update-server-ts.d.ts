import { Rule } from '@angular-devkit/schematics';
/**
 * Moves the `server.ts` file to the `src/` folder and updates the implementation,
 * to adapt to the new Angular v19 standards.
 *
 * 1. Moves the `server.ts` file to the `src/` folder.
 * 2. Updates the import path from `./src/main.server` to `./main.server`.
 */
export declare function updateServerTs(): Rule;
