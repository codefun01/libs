"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateServerTs = updateServerTs;
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Moves the `server.ts` file to the `src/` folder and updates the implementation,
 * to adapt to the new Angular v19 standards.
 *
 * 1. Moves the `server.ts` file to the `src/` folder.
 * 2. Updates the import path from `./src/main.server` to `./main.server`.
 */
function updateServerTs() {
    return function (tree, context) {
        var ServerTsPaths;
        (function (ServerTsPaths) {
            ServerTsPaths["OLD"] = "server.ts";
            ServerTsPaths["NEW"] = "src/server.ts";
        })(ServerTsPaths || (ServerTsPaths = {}));
        context.logger.info("\n\u23F3 Moving \"".concat(ServerTsPaths.OLD, "\" to \"").concat(ServerTsPaths.NEW, "\" and relative import paths..."));
        if (!tree.exists(ServerTsPaths.OLD)) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("".concat(ServerTsPaths.OLD, " file not found"), context);
            return;
        }
        var content = tree.read(ServerTsPaths.OLD);
        if (!content) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("Failed to read ".concat(ServerTsPaths.OLD, " file"), context);
            return;
        }
        var serverTs = content.toString();
        context.logger.info('  ↳ Updating relative import path from "./src/main.server" to "./main.server"');
        serverTs = serverTs.replace(/from ['"]\.\/src\/main\.server['"];/, "from './main.server';");
        context.logger.info("  \u21B3 Moving the file \"".concat(ServerTsPaths.OLD, "\" to \"").concat(ServerTsPaths.NEW, "\" with the updated content"));
        tree.create(ServerTsPaths.NEW, serverTs);
        tree.delete(ServerTsPaths.OLD);
        context.logger.info("\u2705 Moved and updated ".concat(ServerTsPaths.OLD, " to ").concat(ServerTsPaths.NEW));
    };
}
//# sourceMappingURL=update-server-ts.js.map