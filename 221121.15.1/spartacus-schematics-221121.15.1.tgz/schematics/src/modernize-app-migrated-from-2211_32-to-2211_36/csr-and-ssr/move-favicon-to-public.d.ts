import { Rule } from '@angular-devkit/schematics';
/**
 * Moves the `favicon.ico` file from the `src/` folder to the `public/` folder,
 * to adapt to the new Angular v19 standards.
 */
export declare function moveFaviconToPublic(): Rule;
