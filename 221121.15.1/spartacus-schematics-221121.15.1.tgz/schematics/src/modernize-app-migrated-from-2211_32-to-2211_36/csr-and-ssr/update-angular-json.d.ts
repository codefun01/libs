import { Rule } from '@angular-devkit/schematics';
/**
 * Updates the Angular configuration file to new Angular v19 standards.
 *
 * It updates the "assets" property for the "build" and "test" targets,
 * to use the new path with the `public/` folder,
 * instead of `src/assets` and `src/favicon.ico`.
 */
export declare function updateAngularJson(): Rule;
