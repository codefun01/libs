"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateTsConfig = updateTsConfig;
var jsonc_parser_1 = require("jsonc-parser");
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * It updates the "compilerOptions" in the `tsconfig.json` file,
 * to adapt to the new Angular v19 standards.
 *
 * 1. Adds `"isolatedModules": true`
 * 2. Removes `"sourceMap"`, `"declaration"`, `"useDefineForClassFields"`, `"lib"`, `"moduleResolution"`
 */
function updateTsConfig() {
    return function (tree, context) {
        var tsconfigPath = 'tsconfig.json';
        context.logger.info("\n\u23F3 Updating ".concat(tsconfigPath, "..."));
        if (!tree.exists(tsconfigPath)) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("".concat(tsconfigPath, " file not found"), context);
            return;
        }
        var tsConfigContent = tree.read(tsconfigPath);
        if (!tsConfigContent) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("Failed to read ".concat(tsconfigPath, " file"), context);
            return;
        }
        var tsConfig = (0, jsonc_parser_1.parse)(tsConfigContent.toString());
        if (!tsConfig.compilerOptions) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("No compilerOptions found in ".concat(tsconfigPath), context);
            return;
        }
        context.logger.info('  ↳ Adding `"isolatedModules": true` to "compilerOptions"');
        tsConfig.compilerOptions.isolatedModules = true;
        context.logger.info('  ↳ Removing "sourceMap", "declaration", "useDefineForClassFields", "lib", "moduleResolution" from "compilerOptions"');
        delete tsConfig.compilerOptions.sourceMap;
        delete tsConfig.compilerOptions.declaration;
        delete tsConfig.compilerOptions.useDefineForClassFields;
        delete tsConfig.compilerOptions.lib;
        delete tsConfig.compilerOptions.moduleResolution;
        context.logger.info('  ↳ Updating "moduleResolution" to "bundler" in "compilerOptions"');
        tsConfig.compilerOptions.moduleResolution = 'bundler';
        var JSON_INDENT = 2;
        tree.overwrite(tsconfigPath, JSON.stringify(tsConfig, null, JSON_INDENT));
        context.logger.info("\u2705 Updated ".concat(tsconfigPath));
    };
}
//# sourceMappingURL=update-ts-config.js.map