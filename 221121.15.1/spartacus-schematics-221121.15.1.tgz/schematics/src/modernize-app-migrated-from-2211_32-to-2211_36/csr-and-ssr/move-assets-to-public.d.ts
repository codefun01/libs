import { Rule } from '@angular-devkit/schematics';
/**
 * Moves the `src/assets/` folder to the root and renames it to `public/`,
 * to adapt to the new Angular v19 standards.
 */
export declare function moveAssetsToPublic(): Rule;
