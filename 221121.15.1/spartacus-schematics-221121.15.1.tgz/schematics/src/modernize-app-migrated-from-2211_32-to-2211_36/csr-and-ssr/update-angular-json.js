"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAngularJson = updateAngularJson;
var workspace_utils_1 = require("../../shared/utils/workspace-utils");
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Updates the Angular configuration file to new Angular v19 standards.
 *
 * It updates the "assets" property for the "build" and "test" targets,
 * to use the new path with the `public/` folder,
 * instead of `src/assets` and `src/favicon.ico`.
 */
function updateAngularJson() {
    return function (tree, context) {
        var _a, _b, _c, _d;
        context.logger.info('\n⏳ Updating angular.json assets configuration...');
        var _e = (0, workspace_utils_1.getWorkspace)(tree), workspace = _e.workspace, path = _e.path;
        var project = workspace.projects[Object.keys(workspace.projects)[0]];
        if (!project) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)('No project found in workspace', context);
            return;
        }
        var buildTarget = (_a = project.architect) === null || _a === void 0 ? void 0 : _a.build;
        var testTarget = (_b = project.architect) === null || _b === void 0 ? void 0 : _b.test;
        if (!buildTarget) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)('Could not find "build" target in project configuration', context);
            return;
        }
        var oldAssets = [
            'src/favicon.ico',
            'src/assets',
        ];
        var newAssets = [
            { glob: '**/*', input: 'public' },
        ];
        context.logger.info("  \u21B3 Removing \"assets\" configuration for ".concat(oldAssets
            .map(function (x) { return "\"".concat(x, "\""); })
            .join(', ')));
        context.logger.info('  ↳ Adding "assets" configuration: `{ glob: "**/*", input: "public" }`');
        if (Array.isArray((_c = buildTarget.options) === null || _c === void 0 ? void 0 : _c.assets)) {
            buildTarget.options.assets = buildTarget.options.assets.filter(function (asset) { return !oldAssets.includes(asset); });
            // Add the new public assets config
            buildTarget.options.assets = __spreadArray(__spreadArray([], newAssets, true), buildTarget.options.assets, true);
        }
        else {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)('Could not find "assets" array in "build" target configuration', context);
        }
        // Update config for "test" target
        if (Array.isArray((_d = testTarget === null || testTarget === void 0 ? void 0 : testTarget.options) === null || _d === void 0 ? void 0 : _d.assets)) {
            testTarget.options.assets = testTarget.options.assets.filter(function (asset) { return !oldAssets.includes(asset); });
            // Add the new public assets config
            testTarget.options.assets = __spreadArray(__spreadArray([], newAssets, true), testTarget.options.assets, true);
        }
        else {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)('Could not find "assets" array in "test" target configuration', context);
        }
        var JSON_INDENT = 2;
        tree.overwrite(path, JSON.stringify(workspace, null, JSON_INDENT));
        context.logger.info('✅ Updated angular.json assets configuration');
    };
}
//# sourceMappingURL=update-angular-json.js.map