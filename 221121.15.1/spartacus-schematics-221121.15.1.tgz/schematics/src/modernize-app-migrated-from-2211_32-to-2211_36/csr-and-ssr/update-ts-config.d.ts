import { Rule } from '@angular-devkit/schematics';
/**
 * It updates the "compilerOptions" in the `tsconfig.json` file,
 * to adapt to the new Angular v19 standards.
 *
 * 1. Adds `"isolatedModules": true`
 * 2. Removes `"sourceMap"`, `"declaration"`, `"useDefineForClassFields"`, `"lib"`, `"moduleResolution"`
 */
export declare function updateTsConfig(): Rule;
