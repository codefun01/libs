"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.moveFaviconToPublic = moveFaviconToPublic;
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Moves the `favicon.ico` file from the `src/` folder to the `public/` folder,
 * to adapt to the new Angular v19 standards.
 */
function moveFaviconToPublic() {
    return function (tree, context) {
        var fileName = 'favicon.ico';
        var oldDir = 'src';
        var oldPath = "".concat(oldDir, "/").concat(fileName);
        var newDir = 'public';
        var newPath = "".concat(newDir, "/").concat(fileName);
        context.logger.info("\n\u23F3 Moving ".concat(fileName, " from \"").concat(oldDir, "/\" to \"").concat(newDir, "/\"..."));
        if (!tree.exists(oldPath)) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("Favicon not found at ".concat(oldPath), context);
            return;
        }
        var content = tree.read(oldPath);
        if (content) {
            tree.create(newPath, content);
            tree.delete(oldPath);
        }
        else {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("Failed to read ".concat(oldPath, " file"), context);
            return;
        }
        context.logger.info("\u2705 Moved ".concat(fileName, " from \"").concat(oldDir, "/\" to \"").concat(newDir, "/\""));
    };
}
//# sourceMappingURL=move-favicon-to-public.js.map