import { Rule } from '@angular-devkit/schematics';
/**
 * Updates the i18n lazy loading config to use the new path with the `public/` folder,
 * instead of `../../assets`, because of moving the assets folder with respect to the new Angular v19 standards.
 *
 * It checks whether the config for i18n lazy loading is present.
 * If it is, it updates the path from `../../assets` to `../../../public`.
 * Otherwise, no changes are made.
 */
export declare function updateI18nLazyLoadingConfig(): Rule;
