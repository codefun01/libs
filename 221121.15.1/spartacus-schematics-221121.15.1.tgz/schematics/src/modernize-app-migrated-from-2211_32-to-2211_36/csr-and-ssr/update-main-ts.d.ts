import { Rule } from '@angular-devkit/schematics';
/**
 * Updates `src/main.ts` to include a config object with `ngZoneEventCoalescing: true` in the `bootstrapModule()` call,
 * to adapt to the new Angular v19 standards.
 */
export declare function updateMainTs(): Rule;
