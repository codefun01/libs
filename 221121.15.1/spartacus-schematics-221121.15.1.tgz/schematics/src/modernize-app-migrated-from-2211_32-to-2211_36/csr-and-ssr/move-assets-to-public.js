"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.moveAssetsToPublic = moveAssetsToPublic;
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Moves the `src/assets/` folder to the root and renames it to `public/`,
 * to adapt to the new Angular v19 standards.
 */
function moveAssetsToPublic() {
    return function (tree, context) {
        var AssetsDirs;
        (function (AssetsDirs) {
            AssetsDirs["OLD"] = "src/assets";
            AssetsDirs["NEW"] = "public";
        })(AssetsDirs || (AssetsDirs = {}));
        context.logger.info("\n\u23F3 Moving assets folder from \"".concat(AssetsDirs.OLD, "/\" to \"").concat(AssetsDirs.NEW, "/\"..."));
        var sourceDir = tree.getDir(AssetsDirs.OLD);
        if (!sourceDir.subfiles.length && !sourceDir.subdirs.length) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("Assets folder not found or empty at ".concat(AssetsDirs.OLD), context);
            return;
        }
        try {
            tree.getDir(AssetsDirs.OLD).visit(function (filePath) {
                var relativeFilePath = filePath.replace("".concat(AssetsDirs.OLD, "/"), '');
                context.logger.info("  \u21B3 Moving file \"".concat(filePath, "\""));
                var content = tree.read(filePath);
                if (content) {
                    tree.create("".concat(AssetsDirs.NEW, "/").concat(relativeFilePath), content);
                }
                else {
                    (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("Failed to read ".concat(filePath, " file"), context);
                }
            });
        }
        catch (error) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("Error moving assets file from \"".concat(AssetsDirs.OLD, "\" to \"").concat(AssetsDirs.NEW, "\". Error: ").concat(error), context);
        }
        context.logger.info("  \u21B3 Deleting old \"".concat(AssetsDirs.OLD, "/\" directory"));
        try {
            tree.delete(AssetsDirs.OLD);
        }
        catch (error) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("Error deleting old assets directory \"".concat(AssetsDirs.OLD, "\". Error: ").concat(error), context);
        }
        context.logger.info("\u2705 Moved assets folder from \"".concat(AssetsDirs.OLD, "/\" to \"").concat(AssetsDirs.NEW, "/\""));
    };
}
//# sourceMappingURL=move-assets-to-public.js.map