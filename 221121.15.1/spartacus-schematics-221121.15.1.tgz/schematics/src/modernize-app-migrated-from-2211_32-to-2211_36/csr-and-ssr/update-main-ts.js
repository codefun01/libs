"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateMainTs = updateMainTs;
var ts = __importStar(require("typescript"));
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Updates `src/main.ts` to include a config object with `ngZoneEventCoalescing: true` in the `bootstrapModule()` call,
 * to adapt to the new Angular v19 standards.
 */
function updateMainTs() {
    return function (tree, context) {
        var mainTsPath = 'src/main.ts';
        context.logger.info("\n\u23F3 Updating ".concat(mainTsPath, "..."));
        if (!tree.exists(mainTsPath)) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("".concat(mainTsPath, " file not found"), context);
            return;
        }
        var content = tree.read(mainTsPath);
        if (!content) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("Failed to read ".concat(mainTsPath, " file"), context);
            return;
        }
        var originalContent = content.toString();
        context.logger.info('  ↳ Updating `bootstrapModule()` call to include `ngZoneEventCoalescing: true`');
        var updatedContent = updateBootstrapCall(originalContent);
        if (updatedContent === originalContent) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)('Could not update `bootstrapModule()` call to include `ngZoneEventCoalescing: true`', context);
            return;
        }
        tree.overwrite(mainTsPath, updatedContent);
        context.logger.info("\u2705 Updated ".concat(mainTsPath));
    };
}
/**
 * Updates the `bootstrapModule()` call to include a config object with `ngZoneEventCoalescing: true`.
 */
function updateBootstrapCall(content) {
    var sourceFile = ts.createSourceFile('', content, ts.ScriptTarget.Latest, true);
    /**
     * Visits the node and checks if it's a method call to `bootstrapModule()`.
     * If it is, it updates the options to include `ngZoneEventCoalescing: true`.
     *
     * @returns { updated: boolean } - tells whether the update was performed
     */
    function visit(node) {
        if (ts.isCallExpression(node) &&
            ts.isPropertyAccessExpression(node.expression) &&
            node.expression.name.text === 'bootstrapModule') {
            var options = node.arguments[1];
            var ngZoneOption = "{ ngZoneEventCoalescing: true }";
            if (!options) {
                // No options - insert new ones
                var start = node.arguments[0].getEnd();
                content = "".concat(content.slice(0, start), ", ").concat(ngZoneOption).concat(content.slice(start));
                return { updated: true };
            }
            if (ts.isObjectLiteralExpression(options)) {
                // Find ngZoneEventCoalescing property if it exists
                var existingProperty = options.properties.find(function (prop) {
                    return ts.isPropertyAssignment(prop) &&
                        prop.name.getText() === 'ngZoneEventCoalescing';
                });
                if (!existingProperty) {
                    // Add to other existing options
                    var start = options.getStart() + 1; // After {
                    content = "".concat(content.slice(0, start), "ngZoneEventCoalescing: true,").concat(content.slice(start));
                }
                else {
                    // Update existing property
                    var valueStart = existingProperty.initializer.getStart();
                    var valueEnd = existingProperty.initializer.getEnd();
                    content = "".concat(content.slice(0, valueStart), "true").concat(content.slice(valueEnd));
                }
                return { updated: true };
            }
        }
        for (var _i = 0, _a = node.getChildren(); _i < _a.length; _i++) {
            var child = _a[_i];
            // short-circuit and early return if the update has been already performed in one of the children nodes
            if (visit(child).updated) {
                return { updated: true };
            }
        }
        return { updated: false };
    }
    visit(sourceFile);
    return content;
}
//# sourceMappingURL=update-main-ts.js.map