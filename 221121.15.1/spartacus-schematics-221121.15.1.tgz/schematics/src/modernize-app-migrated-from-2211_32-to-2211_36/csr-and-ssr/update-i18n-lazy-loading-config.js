"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateI18nLazyLoadingConfig = updateI18nLazyLoadingConfig;
var ts = __importStar(require("typescript"));
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Updates the i18n lazy loading config to use the new path with the `public/` folder,
 * instead of `../../assets`, because of moving the assets folder with respect to the new Angular v19 standards.
 *
 * It checks whether the config for i18n lazy loading is present.
 * If it is, it updates the path from `../../assets` to `../../../public`.
 * Otherwise, no changes are made.
 */
function updateI18nLazyLoadingConfig() {
    return function (tree, context) {
        var configurationModulePath = 'src/app/spartacus/spartacus-configuration.module.ts';
        context.logger.info("\n\u23F3 Updating config for i18n lazy loading in \"".concat(configurationModulePath, "\", if needed..."));
        if (!tree.exists(configurationModulePath)) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("".concat(configurationModulePath, " file not found"), context);
            return;
        }
        var content = tree.read(configurationModulePath);
        if (!content) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_2211_32_To_2211_36)("Failed to read ".concat(configurationModulePath, " file"), context);
            return;
        }
        var updatedContent = content.toString();
        context.logger.info('    ↳ Checking if app has a config for i18n lazy loading...');
        if (!hasConfigForLazyLoadingI18n(updatedContent)) {
            context.logger.info('      ↳ No.');
            context.logger.info("\u2705 Updating config for i18n lazy loading in \"".concat(configurationModulePath, "\" was not needed"));
            return;
        }
        context.logger.info('      ↳ Updating the path from "../../assets" to "../../../public"');
        updatedContent = updateDynamicImportPath(updatedContent);
        tree.overwrite(configurationModulePath, updatedContent);
        context.logger.info('✅ Updated config for i18n lazy loading');
    };
}
/**
 * Checks if the content has a config for lazy loaded i18n.
 *
 * It looks for an object literal with the following structure:
 * ```
 * {
 *   i18n: {
 *     backend: {
 *       loader: ...
 *     }
 *   }
 * }
 */
function hasConfigForLazyLoadingI18n(content) {
    var sourceFile = ts.createSourceFile('', content, ts.ScriptTarget.Latest, true);
    var objectLiterals = findObjectLiterals(sourceFile);
    return objectLiterals.some(isConfigForLazyLoadingI18n);
}
/**
 * Checks if the given node is a config for lazy loaded i18n.
 *
 * It looks for an object literal with the following structure:
 * ```
 * {
 *   i18n: {
 *     backend: {
 *       loader: ...
 *     }
 *   }
 * }
 * ```
 */
function isConfigForLazyLoadingI18n(node) {
    // Expecting syntax: `i18n: { ... }`
    var i18nProp = node.properties.find(function (prop) {
        return ts.isPropertyAssignment(prop) &&
            ts.isIdentifier(prop.name) &&
            prop.name.text === 'i18n';
    });
    if (!i18nProp || !ts.isObjectLiteralExpression(i18nProp.initializer)) {
        return false;
    }
    // Expecting syntax: `backend: { ... }`
    var backendProp = i18nProp.initializer.properties.find(function (prop) {
        return ts.isPropertyAssignment(prop) &&
            ts.isIdentifier(prop.name) &&
            prop.name.text === 'backend';
    });
    if (!backendProp || !ts.isObjectLiteralExpression(backendProp.initializer)) {
        return false;
    }
    // Expecting one of the following syntaxes:
    // - `loader: (lang: string, chunkName: string) => { ... }`
    // - `loader(lang: string, chunkName: string) { ... }`
    return backendProp.initializer.properties.some(function (prop) {
        if (!ts.isPropertyAssignment(prop) && !ts.isMethodDeclaration(prop)) {
            return false;
        }
        var name = prop.name;
        return ((ts.isIdentifier(name) || ts.isStringLiteral(name)) &&
            name.text === 'loader');
    });
}
/**
 * Returns all object literals in the given node.
 */
function findObjectLiterals(node) {
    var objects = [];
    if (ts.isObjectLiteralExpression(node)) {
        objects.push(node);
    }
    ts.forEachChild(node, function (child) {
        objects.push.apply(objects, findObjectLiterals(child));
    });
    return objects;
}
/**
 * Updates the path of dynamic imports by replacing `../../assets` with `../../../public`.
 */
function updateDynamicImportPath(content) {
    var sourceFile = ts.createSourceFile('', content, ts.ScriptTarget.Latest, true);
    var ImportPathPrefixes;
    (function (ImportPathPrefixes) {
        ImportPathPrefixes["OLD"] = "../../assets/";
        ImportPathPrefixes["NEW"] = "../../../public/";
    })(ImportPathPrefixes || (ImportPathPrefixes = {}));
    function visitor(node) {
        // Expect syntax: import(    )
        if (!isDynamicImport(node)) {
            ts.forEachChild(node, visitor);
            return;
        }
        // Expect syntax: import( ` ... ` )
        var argument = node.arguments[0];
        if (!ts.isTemplateLiteral(argument)) {
            ts.forEachChild(node, visitor);
            return;
        }
        // Expect syntax: import( `... <old path part> ...` )
        var importPath = content.substring(argument.getStart(), argument.getEnd());
        if (!importPath.includes(ImportPathPrefixes.OLD)) {
            ts.forEachChild(node, visitor);
            return;
        }
        // Update the path
        var updatedPath = importPath.replace(ImportPathPrefixes.OLD, ImportPathPrefixes.NEW);
        content =
            content.slice(0, argument.getStart()) +
                updatedPath +
                content.slice(argument.getEnd());
        ts.forEachChild(node, visitor);
    }
    visitor(sourceFile);
    return content;
}
function isDynamicImport(node) {
    return (ts.isCallExpression(node) &&
        node.expression.kind === ts.SyntaxKind.ImportKeyword);
}
//# sourceMappingURL=update-i18n-lazy-loading-config.js.map