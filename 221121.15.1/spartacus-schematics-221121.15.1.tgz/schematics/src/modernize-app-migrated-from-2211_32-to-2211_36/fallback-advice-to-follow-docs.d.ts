import { Rule, SchematicContext } from '@angular-devkit/schematics';
/**
 * URL where to find the manual migration steps.
 */
export declare const DOCS_URL_FOR_MODERNIZING_APPS_MIGRATED_FROM_2211_32_TO_2211_36 = "https://help.sap.com/docs/SAP_COMMERCE_COMPOSABLE_STOREFRONT/10a8bc7f635b4e3db6f6bb7880e58a7d/9bb7dd061da14cfc9c5e3f36388c77e4.html";
/**
 * Prints an error message and a link to the manual migration steps.
 */
export declare function printErrorWithDocsForMigrated_2211_32_To_2211_36(message: string, context: SchematicContext): void;
/**
 * If the wrapped Rule throws an error, it logs the error and prints a link to manual migration docs.
 */
export declare function withFallbackDocsForMigrated_2211_32_To_2211_36(rule: Rule): Rule;
