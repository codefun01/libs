"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAppConfigServerProviders = getAppConfigServerProviders;
var get_providers_array_from_named_object_1 = require("./get-providers-array-from-named-object");
/**
 * Helper function to get the providers array from app.config.server.ts
 */
function getAppConfigServerProviders(sourceFile) {
    return (0, get_providers_array_from_named_object_1.getProvidersFromNamedObject)(sourceFile, 'serverConfig');
}
//# sourceMappingURL=get-app-config-server-providers.js.map