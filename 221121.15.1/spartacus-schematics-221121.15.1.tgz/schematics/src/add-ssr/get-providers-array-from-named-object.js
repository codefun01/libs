"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getProvidersFromNamedObject = getProvidersFromNamedObject;
var ts_morph_1 = require("ts-morph");
/**
 * Helper function to get the providers array from a variable declaration
 * in a TypeScript source file.
 *
 * @param sourceFile The source file to search in
 * @param variableName The name of the variable to find (e.g., 'appConfig', 'serverConfig')
 * @returns The providers array node if found, undefined otherwise
 */
function getProvidersFromNamedObject(sourceFile, variableName) {
    var variableStatements = sourceFile.getVariableStatements();
    for (var _i = 0, variableStatements_1 = variableStatements; _i < variableStatements_1.length; _i++) {
        var statement = variableStatements_1[_i];
        var declarations = statement.getDeclarations();
        for (var _a = 0, declarations_1 = declarations; _a < declarations_1.length; _a++) {
            var declaration = declarations_1[_a];
            if (declaration.getName() !== variableName) {
                continue;
            }
            var initializer = declaration.getInitializer();
            if (initializer && ts_morph_1.Node.isObjectLiteralExpression(initializer)) {
                return extractProvidersArray(initializer);
            }
        }
    }
    return undefined;
}
/**
 * Extracts the providers array from an object literal expression.
 */
function extractProvidersArray(initializer) {
    var providersProperty = initializer.getProperty('providers');
    if (!providersProperty || !ts_morph_1.Node.isPropertyAssignment(providersProperty)) {
        return undefined;
    }
    var providersArray = providersProperty.getInitializer();
    if (providersArray && ts_morph_1.Node.isArrayLiteralExpression(providersArray)) {
        return providersArray;
    }
    return undefined;
}
//# sourceMappingURL=get-providers-array-from-named-object.js.map