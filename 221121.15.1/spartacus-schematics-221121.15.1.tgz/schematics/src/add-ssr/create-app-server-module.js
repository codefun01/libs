"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAppServerModule = createAppServerModule;
var schematics_1 = require("@angular-devkit/schematics");
var constants_1 = require("../shared/constants");
var program_1 = require("../shared/utils/program");
var project_tsconfig_paths_1 = require("../shared/utils/project-tsconfig-paths");
/**
 * Creates app.module.server.ts file if it doesn't exist (for SSR standalone apps).
 */
function createAppServerModule(options) {
    return function (tree, context) {
        if (options.debug) {
            context.logger.info("\u231B\uFE0F Checking if ".concat(constants_1.ANGULAR_SERVER_MODULE, " needs to be created..."));
        }
        var project = options.project;
        var buildPaths = (0, project_tsconfig_paths_1.getProjectTsConfigPaths)(tree, project).buildPaths;
        var basePath = process.cwd();
        var appSourceFiles = (0, program_1.createProgram)(tree, basePath, buildPaths[0]).appSourceFiles;
        // Check if app.module.server.ts already exists
        var appServerModuleExists = appSourceFiles.some(function (sourceFile) {
            return sourceFile.getFilePath().includes(constants_1.ANGULAR_SERVER_MODULE);
        });
        if (!appServerModuleExists) {
            context.logger.info("\u270F\uFE0F Creating app.module.server.ts for SSR standalone application...");
            // Find the app directory
            var appDir_1 = null;
            tree.visit(function (filePath) {
                if (filePath.endsWith("/".concat(constants_1.APP_COMPONENT))) {
                    appDir_1 = filePath.substring(0, filePath.lastIndexOf('/'));
                }
            });
            if (!appDir_1) {
                throw new schematics_1.SchematicsException('Could not find app directory');
            }
            var appServerModulePath = "".concat(appDir_1, "/").concat(constants_1.ANGULAR_SERVER_MODULE);
            var appServerModuleContent = "\nimport { NgModule } from '@angular/core';\n\n@NgModule({})\nexport class AppServerModule {}\n";
            tree.create(appServerModulePath, appServerModuleContent);
            context.logger.info("\u2705 Created ".concat(appServerModulePath));
        }
        else {
            context.logger.info("\u2705 ".concat(constants_1.ANGULAR_SERVER_MODULE, " already exists"));
        }
        if (options.debug) {
            context.logger.info("\u2705 App server module check complete.");
        }
        return tree;
    };
}
//# sourceMappingURL=create-app-server-module.js.map