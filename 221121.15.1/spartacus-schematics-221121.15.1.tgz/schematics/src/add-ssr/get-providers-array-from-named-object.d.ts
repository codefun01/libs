import { ArrayLiteralExpression, SourceFile } from 'ts-morph';
/**
 * Helper function to get the providers array from a variable declaration
 * in a TypeScript source file.
 *
 * @param sourceFile The source file to search in
 * @param variableName The name of the variable to find (e.g., 'appConfig', 'serverConfig')
 * @returns The providers array node if found, undefined otherwise
 */
export declare function getProvidersFromNamedObject(sourceFile: SourceFile, variableName: string): ArrayLiteralExpression | undefined;
