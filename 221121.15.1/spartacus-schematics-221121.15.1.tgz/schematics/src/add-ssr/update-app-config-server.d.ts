import { Rule } from '@angular-devkit/schematics';
import { Schema as SpartacusOptions } from '../add-spartacus/schema';
/**
 * Updates app.config.server.ts for SSR standalone apps:
 * - Adds importProvidersFrom(AppServerModule) to providers
 * - Removes withRoutes(serverRoutes) from provideServerRendering
 */
export declare function updateAppConfigServer(options: SpartacusOptions): Rule;
