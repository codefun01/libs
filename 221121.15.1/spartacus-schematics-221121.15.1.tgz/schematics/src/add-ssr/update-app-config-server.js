"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAppConfigServer = updateAppConfigServer;
var ts_morph_1 = require("ts-morph");
var shared_1 = require("../shared");
var constants_1 = require("../shared/constants");
var import_utils_1 = require("../shared/utils/import-utils");
var program_1 = require("../shared/utils/program");
var project_tsconfig_paths_1 = require("../shared/utils/project-tsconfig-paths");
var get_app_config_server_providers_1 = require("./get-app-config-server-providers");
/**
 * Updates app.config.server.ts for SSR standalone apps:
 * - Adds importProvidersFrom(AppServerModule) to providers
 * - Removes withRoutes(serverRoutes) from provideServerRendering
 */
function updateAppConfigServer(options) {
    return function (tree, context) {
        if (options.debug) {
            context.logger.info("\u231B\uFE0F Updating ".concat(constants_1.APP_CONFIG_SERVER, "..."));
        }
        var buildPaths = (0, project_tsconfig_paths_1.getProjectTsConfigPaths)(tree, options.project).buildPaths;
        var basePath = process.cwd();
        for (var _i = 0, buildPaths_1 = buildPaths; _i < buildPaths_1.length; _i++) {
            var tsconfigPath = buildPaths_1[_i];
            var appSourceFiles = (0, program_1.createProgram)(tree, basePath, tsconfigPath).appSourceFiles;
            var serverConfigFile = appSourceFiles.find(function (file) {
                return file.getFilePath().includes(constants_1.APP_CONFIG_SERVER);
            });
            if (serverConfigFile) {
                removeProvideServerRenderingWithRoutes(serverConfigFile);
                addImportProvidersFromAppServerModule(serverConfigFile);
                (0, program_1.formatFile)(serverConfigFile);
                tree.overwrite(serverConfigFile.getFilePath(), serverConfigFile.getFullText());
                context.logger.info("\u2705 Updated ".concat(constants_1.APP_CONFIG_SERVER));
                break;
            }
        }
        if (options.debug) {
            context.logger.info("\u2705 App config server update complete.");
        }
        return tree;
    };
}
/**
 * Adds `importProvidersFrom(AppServerModule)` to providers array.
 * And adds import:
 * ```
 * import { AppServerModule } from './app.module.server';
 * ```
 */
function addImportProvidersFromAppServerModule(sourceFile) {
    // Add imports for AppServerModule and importProvidersFrom
    (0, import_utils_1.createImports)(sourceFile, [
        {
            moduleSpecifier: './app.module.server',
            namedImports: ['AppServerModule'],
        },
        {
            moduleSpecifier: '@angular/core',
            namedImports: ['importProvidersFrom'],
        },
    ]);
    // Add importProvidersFrom(AppServerModule) to providers array
    var providersArray = (0, get_app_config_server_providers_1.getAppConfigServerProviders)(sourceFile);
    if (providersArray && ts_morph_1.Node.isArrayLiteralExpression(providersArray)) {
        var providerContent_1 = 'importProvidersFrom(AppServerModule)';
        var elements = providersArray.getElements();
        var alreadyExists = elements.some(function (element) { return element.getText() === providerContent_1; });
        if (!alreadyExists) {
            providersArray.addElement(providerContent_1);
        }
    }
}
/**
 * Removes `withRoutes(serverRoutes)` from app.config.server.ts:
 * And removes imports
 * ```
 * import { serverRoutes } from './app.routes.server';
 * import { withRoutes } from '@angular/ssr';
 * ```
 */
function removeProvideServerRenderingWithRoutes(sourceFile) {
    // Remove unused imports
    (0, shared_1.removeImportUsingTsMorph)(sourceFile, {
        importPath: './app.routes.server',
        importName: 'serverRoutes',
    });
    (0, shared_1.removeImportUsingTsMorph)(sourceFile, {
        importPath: '@angular/ssr',
        importName: 'withRoutes',
    });
    // Remove withRoutes argument from provideServerRendering
    var providersArray = (0, get_app_config_server_providers_1.getAppConfigServerProviders)(sourceFile);
    if (providersArray && ts_morph_1.Node.isArrayLiteralExpression(providersArray)) {
        var elements = providersArray.getElements();
        elements.forEach(function (element) {
            if (ts_morph_1.Node.isCallExpression(element)) {
                var expression = element.getExpression();
                if (expression.getText() === 'provideServerRendering') {
                    // Remove withRoutes argument if present
                    var args = element.getArguments();
                    var withRoutesIndex = args.findIndex(function (arg) {
                        return ts_morph_1.Node.isCallExpression(arg) &&
                            arg.getExpression().getText() === 'withRoutes';
                    });
                    if (withRoutesIndex !== -1) {
                        element.removeArgument(withRoutesIndex);
                    }
                }
            }
        });
    }
}
//# sourceMappingURL=update-app-config-server.js.map