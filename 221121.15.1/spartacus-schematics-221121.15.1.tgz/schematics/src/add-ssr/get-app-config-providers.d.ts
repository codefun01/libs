import { ArrayLiteralExpression, SourceFile } from 'ts-morph';
/**
 * Helper function to get the providers array from app.config.ts
 */
export declare function getAppConfigProviders(sourceFile: SourceFile): ArrayLiteralExpression | undefined;
