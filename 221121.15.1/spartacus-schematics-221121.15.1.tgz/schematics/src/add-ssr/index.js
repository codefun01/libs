"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.modifyAppServerModuleFile = modifyAppServerModuleFile;
exports.addSSR = addSSR;
var core_1 = require("@angular-devkit/core");
var schematics_1 = require("@angular-devkit/schematics");
var ast_utils_1 = require("@schematics/angular/utility/ast-utils");
var dependencies_1 = require("@schematics/angular/utility/dependencies");
var dependencies_json_1 = __importDefault(require("../dependencies.json"));
var shared_1 = require("../shared");
var constants_1 = require("../shared/constants");
var libs_constants_1 = require("../shared/libs-constants");
var file_utils_1 = require("../shared/utils/file-utils");
var html_utils_1 = require("../shared/utils/html-utils");
var lib_utils_1 = require("../shared/utils/lib-utils");
var module_file_utils_1 = require("../shared/utils/module-file-utils");
var package_utils_1 = require("../shared/utils/package-utils");
var create_app_server_module_1 = require("./create-app-server-module");
var update_app_config_in_ssr_1 = require("./update-app-config-in-ssr");
var update_app_config_server_1 = require("./update-app-config-server");
var DEPENDENCY_NAMES = ['@angular/platform-server', constants_1.ANGULAR_SSR];
function modifyAppServerModuleFile() {
    return function (tree, context) {
        var appServerModulePath = (0, file_utils_1.getPathResultsForFile)(tree, constants_1.ANGULAR_SERVER_MODULE, '/src')[0];
        if (!appServerModulePath) {
            throw new schematics_1.SchematicsException("Project file \"".concat(constants_1.ANGULAR_SERVER_MODULE, "\" not found."));
        }
        var importChange = (0, ast_utils_1.insertImport)((0, file_utils_1.getTsSourceFile)(tree, appServerModulePath), appServerModulePath, "provideServer", "@spartacus/setup/ssr", false);
        var providerChanges = (0, module_file_utils_1.addToModuleProviders)(tree, appServerModulePath, "\n     ...provideServer({\n        serverRequestOrigin: process.env['SERVER_REQUEST_ORIGIN'],\n      }),");
        var changes = __spreadArray([importChange], providerChanges, true);
        (0, file_utils_1.commitChanges)(tree, appServerModulePath, changes);
        context.logger.log('info', "\u2705\uFE0F Modified app.module.server.ts file.");
        return tree;
    };
}
function modifyIndexHtmlFile(options) {
    return function (tree) {
        var buffer = tree.read("src/".concat(constants_1.INDEX_HTML));
        if (buffer) {
            var indexContent = buffer.toString();
            if (!indexContent.includes('<meta name="occ-backend-base-url"')) {
                var projectIndexHtmlPath_1 = (0, file_utils_1.getIndexHtmlPath)(tree);
                var baseUrl = options.baseUrl || 'OCC_BACKEND_BASE_URL_VALUE';
                var metaTags = [
                    "<meta name=\"occ-backend-base-url\" content=\"".concat(baseUrl, "\" />"),
                ];
                metaTags.forEach(function (metaTag) {
                    (0, html_utils_1.appendHtmlElementToHead)(tree, projectIndexHtmlPath_1, metaTag);
                });
            }
        }
        return tree;
    };
}
function provideServerFile(options) {
    return (0, schematics_1.apply)((0, schematics_1.url)('./files'), [
        (0, schematics_1.template)(__assign(__assign(__assign({}, core_1.strings), options), { typescriptExt: 'ts', browserDistDirectory: "dist/".concat(options.project, "/browser") })),
        (0, schematics_1.move)('./src'),
    ]);
}
function prepareDependencies() {
    var spartacusVersion = (0, package_utils_1.getPrefixedSpartacusSchematicsVersion)();
    var spartacusDependencies = [];
    spartacusDependencies.push({
        type: dependencies_1.NodeDependencyType.Default,
        version: spartacusVersion,
        name: libs_constants_1.SPARTACUS_SETUP,
    });
    var thirdPartyDependencies = [];
    for (var _i = 0, DEPENDENCY_NAMES_1 = DEPENDENCY_NAMES; _i < DEPENDENCY_NAMES_1.length; _i++) {
        var dependencyName = DEPENDENCY_NAMES_1[_i];
        thirdPartyDependencies.push({
            type: dependencies_1.NodeDependencyType.Default,
            version: dependencies_json_1.default.storefrontapp[dependencyName],
            name: dependencyName,
        });
    }
    return spartacusDependencies.concat(thirdPartyDependencies);
}
/**
 * Adds `build:ssr` script to `package.json` as it's required for CCv2 build - process fails when script is missing.
 *
 * TODO: CXSPA-6466 Can be removed if Model T adjust their build process to not require this script.
 */
function addBuildSsrScript(spartacusOptions) {
    return function (tree, context) {
        if (spartacusOptions.debug) {
            context.logger.info("\u231B\uFE0F Adding \"build:ssr\" script to \"package.json\"... (CCv2 purposes)");
        }
        var pkgPath = '/package.json';
        var pkg = tree.readJson(pkgPath);
        if (pkg === null) {
            throw new schematics_1.SchematicsException('Could not find package.json');
        }
        pkg.scripts = __assign(__assign({}, pkg.scripts), { 'build:ssr': 'ng build' });
        tree.overwrite(pkgPath, JSON.stringify(pkg, null, 2));
    };
}
/**
 * Fixes the configuration for SSR and Prerendering to be able to work with Spartacus.
 */
function disableSsrAndPrerenderingInAngularJson(spartacusOptions) {
    return (0, schematics_1.chain)([
        disablePrerenderingForNgBuild(spartacusOptions),
        addNoSsrConfigurationToNgBuild(spartacusOptions),
        useNoSsrConfigurationInNgServe(spartacusOptions),
    ]);
}
/**
 * In angular.json: set "prerender: false" in "options" of the "build" architect section
 */
function disablePrerenderingForNgBuild(spartacusOptions) {
    return function (tree, context) {
        var _a;
        if (spartacusOptions.debug) {
            context.logger.info("\u231B\uFE0F Disabling Prerendering by default for \"ng build\"...");
        }
        var _b = (0, shared_1.getWorkspace)(tree), path = _b.path, angularJson = _b.workspace;
        var projectName = (0, shared_1.getDefaultProjectNameFromWorkspace)(tree);
        var project = angularJson.projects[projectName];
        var architect = project.architect;
        var build = architect === null || architect === void 0 ? void 0 : architect.build;
        var options = build === null || build === void 0 ? void 0 : build.options;
        var updatedAngularJson = __assign(__assign({}, angularJson), { projects: __assign(__assign({}, angularJson.projects), (_a = {}, _a[projectName] = __assign(__assign({}, project), { architect: __assign(__assign({}, architect), { build: __assign(__assign({}, build), { options: __assign(__assign({}, options), { prerender: false }) }) }) }), _a)) });
        tree.overwrite(path, JSON.stringify(updatedAngularJson, null, 2));
        if (spartacusOptions.debug) {
            context.logger.info("\u2705 Disabling Prerendering by default for \"ng build\" complete.");
        }
        return tree;
    };
}
/**
 * In angular.json: add new "configuration" section named "noSsr" to "build" architect section
 */
function addNoSsrConfigurationToNgBuild(spartacusOptions) {
    return function (tree, context) {
        var _a;
        if (spartacusOptions.debug) {
            context.logger.info("\u231B\uFE0F Adding \"noSsr\" configuration to \"ng build\"...");
        }
        var _b = (0, shared_1.getWorkspace)(tree), path = _b.path, angularJson = _b.workspace;
        var projectName = (0, shared_1.getDefaultProjectNameFromWorkspace)(tree);
        var project = angularJson.projects[projectName];
        var architect = project.architect;
        var build = architect === null || architect === void 0 ? void 0 : architect.build;
        var configurations = build === null || build === void 0 ? void 0 : build.configurations;
        var noSsrConfiguration = {
            ssr: false,
            prerender: false,
        };
        var updatedAngularJson = __assign(__assign({}, angularJson), { projects: __assign(__assign({}, angularJson.projects), (_a = {}, _a[projectName] = __assign(__assign({}, project), { architect: __assign(__assign({}, architect), { build: __assign(__assign({}, build), { configurations: __assign(__assign({}, configurations), { noSsr: noSsrConfiguration }) }) }) }), _a)) });
        tree.overwrite(path, JSON.stringify(updatedAngularJson, null, 2));
        if (spartacusOptions.debug) {
            context.logger.info("\u2705 Adding \"noSsr\" configuration to \"ng build\" complete.");
        }
        return tree;
    };
}
/**
 * In angular.json: use "noSsr" configuration in "serve" architect section
 */
function useNoSsrConfigurationInNgServe(spartacusOptions) {
    return function (tree, context) {
        var _a;
        if (spartacusOptions.debug) {
            context.logger.info("\u231B\uFE0F Using \"noSsr\" configuration in \"ng serve\"...");
        }
        var _b = (0, shared_1.getWorkspace)(tree), path = _b.path, angularJson = _b.workspace;
        var projectName = (0, shared_1.getDefaultProjectNameFromWorkspace)(tree);
        var project = angularJson.projects[projectName];
        var architect = project.architect;
        var serve = architect === null || architect === void 0 ? void 0 : architect.serve;
        var configurations = serve === null || serve === void 0 ? void 0 : serve.configurations;
        var production = configurations === null || configurations === void 0 ? void 0 : configurations.production;
        var development = configurations === null || configurations === void 0 ? void 0 : configurations.development;
        var updatedAngularJson = __assign(__assign({}, angularJson), { projects: __assign(__assign({}, angularJson.projects), (_a = {}, _a[projectName] = __assign(__assign({}, project), { architect: __assign(__assign({}, architect), { serve: __assign(__assign({}, serve), { configurations: __assign(__assign({}, configurations), { production: __assign(__assign({}, production), { buildTarget: "".concat(production === null || production === void 0 ? void 0 : production.buildTarget, ",noSsr") }), development: __assign(__assign({}, development), { buildTarget: "".concat(development === null || development === void 0 ? void 0 : development.buildTarget, ",noSsr") }) }) }) }) }), _a)) });
        tree.overwrite(path, JSON.stringify(updatedAngularJson, null, 2));
        if (spartacusOptions.debug) {
            context.logger.info("\u2705 Using \"noSsr\" configuration in \"ng serve\" complete.");
        }
        return tree;
    };
}
/**
 * Removes the "outputMode" option from the "build" target in angular.json.
 *
 * This could be removed when we migrate to new SSR API.
 */
function removeOutputModeSupportedOnlyInNewSsrApi(spartacusOptions) {
    return function (tree, context) {
        var _a;
        if (spartacusOptions.debug) {
            context.logger.info("\u231B\uFE0F Removing \"outputMode\" supported only in new SSR API...");
        }
        var _b = (0, shared_1.getWorkspace)(tree), path = _b.path, angularJson = _b.workspace;
        var projectName = (0, shared_1.getDefaultProjectNameFromWorkspace)(tree);
        var project = angularJson.projects[projectName];
        var architect = project.architect;
        var build = architect === null || architect === void 0 ? void 0 : architect.build;
        var options = build === null || build === void 0 ? void 0 : build.options;
        var updatedAngularJson = __assign(__assign({}, angularJson), { projects: __assign(__assign({}, angularJson.projects), (_a = {}, _a[projectName] = __assign(__assign({}, project), { architect: __assign(__assign({}, architect), { build: __assign(__assign({}, build), { options: __assign(__assign({}, options), { outputMode: undefined }) }) }) }), _a)) });
        tree.overwrite(path, JSON.stringify(updatedAngularJson, null, 2));
        if (spartacusOptions.debug) {
            context.logger.info("\u2705 Removed \"outputMode\" option");
        }
        return tree;
    };
}
/**
 * Removes the `app.routes.server.ts` file.
 * That file is not supported by Spartacus SSR.
 */
function removeServerRoutesFile(spartacusOptions) {
    return function (tree, context) {
        var serverRoutesPath = (0, file_utils_1.getPathResultsForFile)(tree, constants_1.APP_ROUTES_SERVER, '/src')[0];
        if (serverRoutesPath) {
            tree.delete(serverRoutesPath);
            if (spartacusOptions.debug) {
                context.logger.info("\u2705 Deleted ".concat(serverRoutesPath));
            }
        }
        return tree;
    };
}
function addSSR(options) {
    return function (tree, context) {
        var serverTemplate = provideServerFile(options);
        var packageJson = (0, package_utils_1.readPackageJson)(tree);
        return (0, schematics_1.chain)([
            (0, lib_utils_1.addPackageJsonDependencies)(prepareDependencies(), packageJson),
            (0, schematics_1.externalSchematic)(constants_1.ANGULAR_SSR, 'ng-add', {
                project: options.project,
            }),
            removeOutputModeSupportedOnlyInNewSsrApi(options),
            removeServerRoutesFile(options),
            addBuildSsrScript(options),
            (0, create_app_server_module_1.createAppServerModule)(options),
            (0, update_app_config_server_1.updateAppConfigServer)(options),
            modifyAppServerModuleFile(),
            modifyIndexHtmlFile(options),
            (0, update_app_config_in_ssr_1.updateAppConfigInSsr)(options),
            (0, schematics_1.branchAndMerge)((0, schematics_1.chain)([(0, schematics_1.mergeWith)(serverTemplate, schematics_1.MergeStrategy.Overwrite)]), schematics_1.MergeStrategy.Overwrite),
            disableSsrAndPrerenderingInAngularJson(options),
            (0, lib_utils_1.installPackageJsonDependencies)(),
        ])(tree, context);
    };
}
//# sourceMappingURL=index.js.map