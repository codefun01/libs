import { Rule } from '@angular-devkit/schematics';
import { Schema as SpartacusOptions } from '../add-spartacus/schema';
/**
 * Creates app.module.server.ts file if it doesn't exist (for SSR standalone apps).
 */
export declare function createAppServerModule(options: SpartacusOptions): Rule;
