import { Node, SourceFile } from 'ts-morph';
/**
 * Helper function to get the providers array from app.config.server.ts
 */
export declare function getAppConfigServerProviders(sourceFile: SourceFile): Node | undefined;
