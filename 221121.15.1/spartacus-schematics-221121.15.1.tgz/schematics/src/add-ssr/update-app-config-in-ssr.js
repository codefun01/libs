"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAppConfigInSsr = updateAppConfigInSsr;
var ts_morph_1 = require("ts-morph");
var constants_1 = require("../shared/constants");
var import_utils_1 = require("../shared/utils/import-utils");
var program_1 = require("../shared/utils/program");
var project_tsconfig_paths_1 = require("../shared/utils/project-tsconfig-paths");
var get_app_config_providers_1 = require("./get-app-config-providers");
/**
 * Updates app.config.ts
 */
function updateAppConfigInSsr(options) {
    return function (tree, context) {
        if (options.debug) {
            context.logger.info("\u231B\uFE0F Updating ".concat(constants_1.APP_CONFIG, "..."));
        }
        var buildPaths = (0, project_tsconfig_paths_1.getProjectTsConfigPaths)(tree, options.project).buildPaths;
        var basePath = process.cwd();
        for (var _i = 0, buildPaths_1 = buildPaths; _i < buildPaths_1.length; _i++) {
            var tsconfigPath = buildPaths_1[_i];
            var appSourceFiles = (0, program_1.createProgram)(tree, basePath, tsconfigPath).appSourceFiles;
            var sourceFile = appSourceFiles.find(function (file) {
                return file.getFilePath().includes(constants_1.APP_CONFIG);
            });
            if (sourceFile) {
                addWithNoHttpTransferCacheToAppConfig(sourceFile);
                (0, program_1.formatFile)(sourceFile);
                tree.overwrite(sourceFile.getFilePath(), sourceFile.getFullText());
                if (options.debug) {
                    context.logger.info("\u2705 Updated ".concat(constants_1.APP_CONFIG));
                }
            }
        }
        return tree;
    };
}
/**
 * Http Transfer Cache is temporarily disabled; https://jira.tools.sap/browse/CXSPA-10430
 */
function addWithNoHttpTransferCacheToAppConfig(sourceFile) {
    (0, import_utils_1.createImports)(sourceFile, [
        {
            moduleSpecifier: '@angular/platform-browser',
            namedImports: [
                'provideClientHydration',
                'withNoHttpTransferCache',
                'withEventReplay',
            ],
        },
    ]);
    var providersArray = (0, get_app_config_providers_1.getAppConfigProviders)(sourceFile);
    if (!providersArray || !ts_morph_1.Node.isArrayLiteralExpression(providersArray)) {
        return;
    }
    // Find existing provideClientHydration call
    var existingHydrationCall = findProvideClientHydrationCall(providersArray);
    if (existingHydrationCall) {
        // Update existing call to ensure it has both arguments
        ensureHydrationArguments(existingHydrationCall);
    }
    else {
        // Add new provideClientHydration call
        addProvideClientHydrationCall(providersArray);
    }
}
/**
 * Find existing provideClientHydration call in the providers array
 */
function findProvideClientHydrationCall(providersArray) {
    if (!ts_morph_1.Node.isArrayLiteralExpression(providersArray)) {
        return undefined;
    }
    for (var _i = 0, _a = providersArray.getElements(); _i < _a.length; _i++) {
        var element = _a[_i];
        if (ts_morph_1.Node.isCallExpression(element)) {
            var expression = element.getExpression();
            if (ts_morph_1.Node.isIdentifier(expression) &&
                expression.getText() === 'provideClientHydration') {
                return element;
            }
        }
    }
    return undefined;
}
/**
 * Ensure provideClientHydration has withEventReplay() and withNoHttpTransferCache()
 */
function ensureHydrationArguments(callExpression) {
    var args = callExpression.getArguments();
    var argTexts = args.map(function (arg) { return arg.getText(); });
    var hasEventReplay = argTexts.some(function (arg) {
        return arg.includes('withEventReplay');
    });
    var hasNoHttpTransferCache = argTexts.some(function (arg) {
        return arg.includes('withNoHttpTransferCache');
    });
    var newArgs = [];
    if (!hasEventReplay) {
        newArgs.push('withEventReplay()');
    }
    if (!hasNoHttpTransferCache) {
        newArgs.push('withNoHttpTransferCache()');
    }
    if (newArgs.length > 0) {
        // Add the missing arguments
        if (args.length === 0) {
            callExpression.insertArguments(0, newArgs);
        }
        else {
            callExpression.addArguments(newArgs);
        }
    }
}
/**
 * Add provideClientHydration(withEventReplay(), withNoHttpTransferCache()) to providers
 */
function addProvideClientHydrationCall(providersArray) {
    if (!ts_morph_1.Node.isArrayLiteralExpression(providersArray)) {
        return;
    }
    providersArray.addElement('provideClientHydration(withEventReplay(), withNoHttpTransferCache())');
}
//# sourceMappingURL=update-app-config-in-ssr.js.map