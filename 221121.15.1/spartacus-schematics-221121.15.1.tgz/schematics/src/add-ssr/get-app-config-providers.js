"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAppConfigProviders = getAppConfigProviders;
var get_providers_array_from_named_object_1 = require("./get-providers-array-from-named-object");
/**
 * Helper function to get the providers array from app.config.ts
 */
function getAppConfigProviders(sourceFile) {
    return (0, get_providers_array_from_named_object_1.getProvidersFromNamedObject)(sourceFile, 'appConfig');
}
//# sourceMappingURL=get-app-config-providers.js.map