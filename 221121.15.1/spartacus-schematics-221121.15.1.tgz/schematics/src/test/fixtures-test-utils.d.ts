import { UnitTestTree } from '@angular-devkit/schematics/testing';
/**
 * Loads all fixture files from the given directory into a schematic test runner `tree`.
 */
export declare function loadFixturesIntoTree({ tree, fixturesDir, }: {
    tree: UnitTestTree;
    fixturesDir: string;
}): void;
