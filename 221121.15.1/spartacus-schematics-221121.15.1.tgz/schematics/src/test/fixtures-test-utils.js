"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadFixturesIntoTree = loadFixturesIntoTree;
var fs_1 = require("fs");
var path_1 = require("path");
/**
 * The extension of the fixture files.
 */
var FIXTURE_FILE_EXTENSION = '.fixture';
/**
 * Loads all fixture files from the given directory into a schematic test runner `tree`.
 */
function loadFixturesIntoTree(_a) {
    var tree = _a.tree, fixturesDir = _a.fixturesDir;
    function addFilesToTree(dir) {
        var dirEntries = (0, fs_1.readdirSync)(dir, { withFileTypes: true });
        for (var _i = 0, dirEntries_1 = dirEntries; _i < dirEntries_1.length; _i++) {
            var dirEntry = dirEntries_1[_i];
            var fullPath = (0, path_1.join)(dir, dirEntry.name);
            if (dirEntry.isDirectory()) {
                addFilesToTree(fullPath);
                continue;
            }
            if (dirEntry.isFile() && dirEntry.name.endsWith(FIXTURE_FILE_EXTENSION)) {
                var content = (0, fs_1.readFileSync)(fullPath, 'utf-8');
                var relativePath = fullPath.slice(fixturesDir.length);
                var targetPath = (0, path_1.join)('/', relativePath.replace(FIXTURE_FILE_EXTENSION, ''));
                tree.create(targetPath, content);
            }
        }
    }
    addFilesToTree(fixturesDir);
}
//# sourceMappingURL=fixtures-test-utils.js.map