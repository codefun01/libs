"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addStorefrontComponentToAppComponent = addStorefrontComponentToAppComponent;
var constants_1 = require("../shared/constants");
var libs_constants_1 = require("../shared/libs-constants");
var import_utils_1 = require("../shared/utils/import-utils");
var program_1 = require("../shared/utils/program");
var project_tsconfig_paths_1 = require("../shared/utils/project-tsconfig-paths");
var add_imports_to_component_decorator_1 = require("./add-imports-to-component-decorator");
/**
 * Adds StorefrontComponent to app.component.ts imports array.
 */
function addStorefrontComponentToAppComponent(options) {
    return function (tree, context) {
        if (options.debug) {
            context.logger.info("\u231B\uFE0F Adding StorefrontComponent to ".concat(constants_1.APP_COMPONENT, " imports..."));
        }
        var buildPaths = (0, project_tsconfig_paths_1.getProjectTsConfigPaths)(tree, options.project).buildPaths;
        var basePath = process.cwd();
        for (var _i = 0, buildPaths_1 = buildPaths; _i < buildPaths_1.length; _i++) {
            var tsconfigPath = buildPaths_1[_i];
            var appSourceFiles = (0, program_1.createProgram)(tree, basePath, tsconfigPath).appSourceFiles;
            for (var _a = 0, appSourceFiles_1 = appSourceFiles; _a < appSourceFiles_1.length; _a++) {
                var sourceFile = appSourceFiles_1[_a];
                if (sourceFile.getFilePath().includes(constants_1.APP_COMPONENT)) {
                    // Add import for StorefrontComponent
                    (0, import_utils_1.createImports)(sourceFile, [
                        {
                            moduleSpecifier: libs_constants_1.SPARTACUS_STOREFRONTLIB,
                            namedImports: ['StorefrontComponent'],
                        },
                    ]);
                    // Add StorefrontComponent to @Component imports array
                    (0, add_imports_to_component_decorator_1.addImportsToComponentDecorator)(sourceFile, 'StorefrontComponent', {
                        removeOldImports: true,
                    });
                    // Save changes to tree
                    (0, program_1.formatFile)(sourceFile);
                    tree.overwrite(sourceFile.getFilePath(), sourceFile.getFullText());
                    context.logger.info("\u2705 Added StorefrontComponent to ".concat(constants_1.APP_COMPONENT, " imports"));
                    break;
                }
            }
        }
        if (options.debug) {
            context.logger.info("\u2705 App component update complete.");
        }
        return tree;
    };
}
//# sourceMappingURL=add-storefront-component-to-app-component.js.map