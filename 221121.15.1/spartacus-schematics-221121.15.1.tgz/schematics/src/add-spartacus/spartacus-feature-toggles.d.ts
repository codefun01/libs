import { Rule } from '@angular-devkit/schematics';
import { Schema as SpartacusOptions } from './schema';
export declare function addFeatureToggles(options: SpartacusOptions): Rule;
