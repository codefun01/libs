import { SourceFile } from 'ts-morph';
/**
 * Helper function to add imports to a Component decorator.
 */
export declare function addImportsToComponentDecorator(sourceFile: SourceFile, value: string, options?: {
    removeOldImports?: boolean;
}): void;
