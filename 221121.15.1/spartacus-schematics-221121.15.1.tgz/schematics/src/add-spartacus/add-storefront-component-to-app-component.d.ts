import { Rule } from '@angular-devkit/schematics';
import { Schema as SpartacusOptions } from './schema';
/**
 * Adds StorefrontComponent to app.component.ts imports array.
 */
export declare function addStorefrontComponentToAppComponent(options: SpartacusOptions): Rule;
