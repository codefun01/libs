"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAppModule = updateAppModule;
var schematics_1 = require("@angular-devkit/schematics");
var constants_1 = require("../shared/constants");
var libs_constants_1 = require("../shared/libs-constants");
var new_module_utils_1 = require("../shared/utils/new-module-utils");
var program_1 = require("../shared/utils/program");
var project_tsconfig_paths_1 = require("../shared/utils/project-tsconfig-paths");
/**
 * Updates AppModule to import AppRoutingModule from Spartacus.
 */
function updateAppModule(options) {
    return function (tree, context) {
        if (options.debug) {
            context.logger.info("\u231B\uFE0F Updating AppModule...");
        }
        var buildPaths = (0, project_tsconfig_paths_1.getProjectTsConfigPaths)(tree, options.project).buildPaths;
        if (!buildPaths.length) {
            throw new schematics_1.SchematicsException('Could not find any tsconfig file. Cannot configure AppModule.');
        }
        var basePath = process.cwd();
        for (var _i = 0, buildPaths_1 = buildPaths; _i < buildPaths_1.length; _i++) {
            var tsconfigPath = buildPaths_1[_i];
            var appSourceFiles = (0, program_1.createProgram)(tree, basePath, tsconfigPath).appSourceFiles;
            for (var _a = 0, appSourceFiles_1 = appSourceFiles; _a < appSourceFiles_1.length; _a++) {
                var sourceFile = appSourceFiles_1[_a];
                if (sourceFile.getFilePath().includes(constants_1.APP_MODULE)) {
                    addAppRoutingModuleImport(tree, context, sourceFile);
                    (0, program_1.formatFile)(sourceFile);
                    tree.overwrite(sourceFile.getFilePath(), sourceFile.getFullText());
                    break;
                }
            }
        }
        if (options.debug) {
            context.logger.info("\u2705 AppModule update complete.");
        }
        return tree;
    };
}
/**
 * Adds `import { AppRoutingModule } from "@spartacus/storefront"` to the given app.module sourceFile.
 *
 * If a local file with the same module name `AppRoutingModule` already exists in the project,
 * it will be removed first, and later the `AppRoutingModule` from `@spartacus/storefront` will be imported.
 *
 * Note: Since v17 Angular `ng new` command by default creates a local `AppRoutingModule` file in the project.
 *       So we have to replace it.
 *
 * See Angular enabling routing by default in v17: https://github.com/angular/angular-cli/commit/1a6a139aaf8d5a6947b399bbbd48bbfd9e52372c
 */
function addAppRoutingModuleImport(tree, context, sourceFile) {
    context.logger.info("\u231B\uFE0F Removing from AppModule's imports array a local AppRoutingModule, if exists");
    // remove import of AppRoutingModule (NgModule import and module path import), if exists
    var removedImport = (0, new_module_utils_1.removeModuleImport)(sourceFile, {
        importPath: constants_1.APP_ROUTING_MODULE_LOCAL_PATH,
        content: constants_1.APP_ROUTING_MODULE,
    });
    context.logger.info(removedImport
        ? "\u2705 Removed from AppModule's imports array a local AppRoutingModule"
        : "\u2705 No local AppRoutingModule found in AppModule's imports array");
    context.logger.info("\u231B\uFE0F Deleting a local file \"".concat(constants_1.APP_ROUTING_MODULE_LOCAL_FILENAME, "\", if exists"));
    // delete local file of AppRoutingModule, if exists
    var deletedFile;
    tree.visit(function (filePath) {
        if (filePath.endsWith(constants_1.APP_ROUTING_MODULE_LOCAL_FILENAME)) {
            tree.delete(filePath);
            context.logger.info("\u2705 Deleted a local file: ".concat(filePath));
            deletedFile = filePath;
        }
    });
    if (!deletedFile) {
        context.logger.info("\u2705 No local file found with the path \"".concat(constants_1.APP_ROUTING_MODULE_LOCAL_FILENAME, "\""));
    }
    context.logger.info("\u231B\uFE0F Importing AppRoutingModule of Spartacus in AppModule");
    // add import of AppRoutingModule from Spartacus
    (0, new_module_utils_1.addModuleImport)(sourceFile, {
        order: 2,
        import: {
            moduleSpecifier: libs_constants_1.SPARTACUS_STOREFRONTLIB,
            namedImports: [constants_1.APP_ROUTING_MODULE],
        },
        content: constants_1.APP_ROUTING_MODULE,
    });
    context.logger.info("\u2705 Imported AppRoutingModule of Spartacus in AppModule");
}
//# sourceMappingURL=update-app-module.js.map