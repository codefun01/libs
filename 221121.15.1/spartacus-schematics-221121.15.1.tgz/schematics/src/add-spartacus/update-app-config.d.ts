import { Rule } from '@angular-devkit/schematics';
import { Schema as SpartacusOptions } from '../add-spartacus/schema';
/**
 * Updates app.config.ts
 */
export declare function updateAppConfig(options: SpartacusOptions): Rule;
