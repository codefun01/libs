import { Rule } from '@angular-devkit/schematics';
import { Schema as SpartacusOptions } from './schema';
/**
 * Updates AppModule to import AppRoutingModule from Spartacus.
 */
export declare function updateAppModule(options: SpartacusOptions): Rule;
