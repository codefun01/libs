"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.addFeatureToggles = addFeatureToggles;
var schematics_1 = require("@angular-devkit/schematics");
var shared_1 = require("../shared");
function addFeatureToggles(options) {
    return function (tree, context) {
        if (options.debug) {
            context.logger.info("\u231B\uFE0F Adding Feature Toggles...");
        }
        var buildPaths = (0, shared_1.getProjectTsConfigPaths)(tree, options.project).buildPaths;
        if (!buildPaths.length) {
            throw new schematics_1.SchematicsException("Could not find any tsconfig file. Can't find ".concat(shared_1.SPARTACUS_FEATURES_NG_MODULE, "."));
        }
        var basePath = process.cwd();
        for (var _i = 0, buildPaths_1 = buildPaths; _i < buildPaths_1.length; _i++) {
            var tsconfigPath = buildPaths_1[_i];
            var spartacusFeaturesModule = (0, shared_1.getSpartacusFeaturesModule)(tree, basePath, tsconfigPath);
            if (spartacusFeaturesModule) {
                _addFeatureToggles(spartacusFeaturesModule);
                break;
            }
        }
        if (options.debug) {
            context.logger.info("\u2705 Feature Toggles added.");
        }
        return tree;
    };
}
/**
 * Creates and adds a spartacus feature toggles with all of them enabled.
 */
function _addFeatureToggles(sourceFile) {
    var featureTogglesProvider = createFeatureTogglesProvider();
    (0, shared_1.addModuleProvider)(sourceFile, {
        import: [
            {
                moduleSpecifier: shared_1.SPARTACUS_CORE,
                namedImports: [shared_1.PROVIDE_FEATURE_TOGGLES_FUNCTION],
            },
        ],
        content: featureTogglesProvider,
    });
    (0, shared_1.saveAndFormat)(sourceFile);
}
/**
 * Returns a provider for all existing feature toggles with value `true`.
 */
function createFeatureTogglesProvider() {
    var defaultFeatureToggles = getDefaultFeatureToggles();
    //for each key in `defaultFeatureToggles` map it to a key with value true
    var featureTogglesAllEnabled = Object.keys(defaultFeatureToggles).reduce(function (acc, key) {
        var _a;
        return (__assign(__assign({}, acc), (_a = {}, _a[key] = true, _a)));
    }, {});
    var featureTogglesString = JSON.stringify(featureTogglesAllEnabled, null, 2);
    return "provideFeatureToggles(".concat(featureTogglesString, ")");
}
/**
 * Retrieves Spartacus core library's default feature toggles.
 *
 * Note: A TypeScript file is copied to the schematics project in a pre-build step,
 * from the core project, to prevent a runtime dependency on `@spartacus/core`.
 * This file is then compiled into JavaScript and included with the schematics
 * project's distribution, used at runtime.
 *
 * Due to the lazy nature of the NodeJS `require()` function, the TypeScript
 * file may not appear in the schematics project's source code.
 *
 * For more, see the script `copy-feature-toggles` in the schematics's `package.json`.
 */
function getDefaultFeatureToggles() {
    var defaultFeatureToggles = require(shared_1.FEATURE_TOGGLES_COPIED_FROM_CORE_LIB_PATH).defaultFeatureToggles;
    return defaultFeatureToggles;
}
//# sourceMappingURL=spartacus-feature-toggles.js.map