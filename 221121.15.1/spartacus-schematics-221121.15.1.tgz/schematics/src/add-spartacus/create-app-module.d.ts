import { Rule } from '@angular-devkit/schematics';
import { Schema as SpartacusOptions } from './schema';
/**
 * Creates app.module.ts file if it doesn't exist (for standalone apps).
 */
export declare function createAppModule(options: SpartacusOptions): Rule;
