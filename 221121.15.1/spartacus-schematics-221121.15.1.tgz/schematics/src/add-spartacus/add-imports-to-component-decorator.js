"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.addImportsToComponentDecorator = addImportsToComponentDecorator;
var ts_morph_1 = require("ts-morph");
var shared_1 = require("../shared");
/**
 * Helper function to add imports to a Component decorator.
 */
function addImportsToComponentDecorator(sourceFile, value, options) {
    if (options === void 0) { options = {}; }
    var _a = options.removeOldImports, removeOldImports = _a === void 0 ? true : _a;
    var classes = sourceFile.getClasses();
    for (var _i = 0, classes_1 = classes; _i < classes_1.length; _i++) {
        var classDeclaration = classes_1[_i];
        var decorator = classDeclaration.getDecorator('Component');
        if (!decorator) {
            continue;
        }
        var args = decorator.getArguments();
        if (args.length > 0 && ts_morph_1.Node.isObjectLiteralExpression(args[0])) {
            processComponentDecorator(args[0], value, { removeOldImports: removeOldImports });
        }
    }
    (0, shared_1.formatFile)(sourceFile);
}
/**
 * Processes the Component decorator's object literal to add imports.
 */
function processComponentDecorator(objLiteral, value, options) {
    var propertyName = 'imports';
    var importsProperty = objLiteral
        .getProperties()
        .find(function (prop) {
        return ts_morph_1.Node.isPropertyAssignment(prop) && prop.getName() === propertyName;
    });
    if (importsProperty && ts_morph_1.Node.isPropertyAssignment(importsProperty)) {
        updateImportsProperty(importsProperty, value, options);
    }
    else {
        objLiteral.addPropertyAssignment({
            name: propertyName,
            initializer: "[".concat(value, "]"),
        });
    }
}
/**
 * Updates an existing imports property with the new value.
 */
function updateImportsProperty(importsProperty, value, options) {
    if (options.removeOldImports) {
        importsProperty.setInitializer("[".concat(value, "]"));
        return;
    }
    var currentInitializer = importsProperty.getInitializer();
    if (currentInitializer && ts_morph_1.Node.isArrayLiteralExpression(currentInitializer)) {
        var existingElements = currentInitializer
            .getElements()
            .map(function (el) { return el.getText(); });
        var newImports = __spreadArray(__spreadArray([], existingElements, true), [value], false);
        importsProperty.setInitializer("[".concat(newImports.join(', '), "]"));
    }
    else {
        importsProperty.setInitializer("[".concat(value, "]"));
    }
}
//# sourceMappingURL=add-imports-to-component-decorator.js.map