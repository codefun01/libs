"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAppConfig = updateAppConfig;
var ts_morph_1 = require("ts-morph");
var get_app_config_providers_1 = require("../add-ssr/get-app-config-providers");
var constants_1 = require("../shared/constants");
var import_utils_1 = require("../shared/utils/import-utils");
var program_1 = require("../shared/utils/program");
var project_tsconfig_paths_1 = require("../shared/utils/project-tsconfig-paths");
/**
 * Updates app.config.ts
 */
function updateAppConfig(options) {
    return function (tree, context) {
        if (options.debug) {
            context.logger.info("\u231B\uFE0F Updating ".concat(constants_1.APP_CONFIG, "..."));
        }
        var buildPaths = (0, project_tsconfig_paths_1.getProjectTsConfigPaths)(tree, options.project).buildPaths;
        var basePath = process.cwd();
        for (var _i = 0, buildPaths_1 = buildPaths; _i < buildPaths_1.length; _i++) {
            var tsconfigPath = buildPaths_1[_i];
            var appSourceFiles = (0, program_1.createProgram)(tree, basePath, tsconfigPath).appSourceFiles;
            var sourceFile = appSourceFiles.find(function (file) {
                return file.getFilePath().includes(constants_1.APP_CONFIG);
            });
            if (sourceFile) {
                addProvideHttpClient(sourceFile);
                addImportProvidersFromAppModule(sourceFile);
                (0, program_1.formatFile)(sourceFile);
                tree.overwrite(sourceFile.getFilePath(), sourceFile.getFullText());
                if (options.debug) {
                    context.logger.info("\u2705 Updated ".concat(constants_1.APP_CONFIG));
                }
            }
        }
        return tree;
    };
}
/**
 * Adds `importProvidersFrom(AppModule)` to providers array.
 * And adds import:
 * ```
 * import { AppModule } from './app.module';
 * ```
 */
function addImportProvidersFromAppModule(sourceFile) {
    // Add imports for AppModule and importProvidersFrom
    (0, import_utils_1.createImports)(sourceFile, [
        {
            moduleSpecifier: './app.module',
            namedImports: ['AppModule'],
        },
        {
            moduleSpecifier: '@angular/core',
            namedImports: ['importProvidersFrom'],
        },
    ]);
    // Add importProvidersFrom(AppModule) to providers array
    var providersArray = (0, get_app_config_providers_1.getAppConfigProviders)(sourceFile);
    if (providersArray && ts_morph_1.Node.isArrayLiteralExpression(providersArray)) {
        var providerContent_1 = 'importProvidersFrom(AppModule)';
        var elements = providersArray.getElements();
        var alreadyExists = elements.some(function (element) { return element.getText() === providerContent_1; });
        if (!alreadyExists) {
            providersArray.addElement(providerContent_1);
        }
    }
}
function addProvideHttpClient(sourceFile) {
    // Add imports for provideHttpClient, withFetch, withInterceptorsFromDi
    (0, import_utils_1.createImports)(sourceFile, [
        {
            moduleSpecifier: constants_1.ANGULAR_HTTP,
            namedImports: [
                'provideHttpClient',
                'withFetch',
                'withInterceptorsFromDi',
            ],
        },
    ]);
    // Add provideHttpClient(withFetch(), withInterceptorsFromDi()) to providers array
    var providersArray = (0, get_app_config_providers_1.getAppConfigProviders)(sourceFile);
    if (providersArray && ts_morph_1.Node.isArrayLiteralExpression(providersArray)) {
        var providerContent_2 = 'provideHttpClient(withFetch(), withInterceptorsFromDi())';
        var elements = providersArray.getElements();
        var alreadyExists = elements.some(function (element) { return element.getText() === providerContent_2; });
        if (!alreadyExists) {
            providersArray.addElement(providerContent_2);
        }
    }
}
//# sourceMappingURL=update-app-config.js.map