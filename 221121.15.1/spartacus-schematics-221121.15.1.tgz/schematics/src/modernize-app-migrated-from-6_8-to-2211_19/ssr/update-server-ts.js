"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateServerTs = updateServerTs;
var add_imports_to_server_ts_1 = require("./update-server-ts/add-imports-to-server-ts");
var remove_imports_from_server_ts_1 = require("./update-server-ts/remove-imports-from-server-ts");
var remove_reexport_from_server_ts_1 = require("./update-server-ts/remove-reexport-from-server-ts");
var remove_webpack_from_server_ts_1 = require("./update-server-ts/remove-webpack-from-server-ts");
var update_variables_in_server_ts_1 = require("./update-server-ts/update-variables-in-server-ts");
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Updates `server.ts` file for new Angular v17 standards.
 *
 * Modernizes imports, configures new paths for `index.html` file,
 * removes Webpack-specific code, and removes obsolete export.
 */
function updateServerTs() {
    return function (tree, context) {
        var serverTsPath = 'server.ts';
        context.logger.info("\n\u23F3 Updating ".concat(serverTsPath, " implementation..."));
        if (!tree.exists(serverTsPath)) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("".concat(serverTsPath, " file not found"), context);
            return;
        }
        var content = tree.read(serverTsPath);
        if (!content) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("Failed to read ".concat(serverTsPath, " file"), context);
            return;
        }
        var updatedContent = content.toString();
        updatedContent = (0, remove_imports_from_server_ts_1.removeImportsFromServerTs)(updatedContent, context);
        updatedContent = (0, add_imports_to_server_ts_1.addImportsToServerTs)(updatedContent, context);
        updatedContent = (0, update_variables_in_server_ts_1.updateVariablesInServerTs)(updatedContent, context);
        updatedContent = (0, remove_webpack_from_server_ts_1.removeWebpackFromServerTs)(updatedContent, context);
        updatedContent = (0, remove_reexport_from_server_ts_1.removeReexportFromServerTs)(updatedContent, context);
        tree.overwrite(serverTsPath, updatedContent);
        context.logger.info("\u2705 Updated ".concat(serverTsPath, " implementation"));
    };
}
//# sourceMappingURL=update-server-ts.js.map