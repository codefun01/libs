import { Rule } from '@angular-devkit/schematics';
/**
 * Renames `app.server.module.ts` to `app.module.server.ts`
 * to align with new Angular v17 standards.
 */
export declare function renameAppServerModule(): Rule;
