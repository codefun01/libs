import { Rule } from '@angular-devkit/schematics';
/**
 * Updates the Angular configuration related to SSR for new Angular v17 standards.
 *
 * 1. In the section `architect > build > options` it adds 3 new options with values:
 *    `"server": "src/main.server.ts"`,
 *    `"prerender": false`,
 *     `"ssr": { "entry": "server.ts" }`
 *
 * 2. In the section `architect > build > configurations` it adds a new property with object value
 *    `"noSsr": { "ssr": false, "prerender": false }`
 *
 * 3. In the section `architect > serve > configurations` it adds the ending `,noSsr` (with the preceding comma)
 *    at the end of the string values in subsections
 *    `... > production > buildTarget` and
 *    `... > development > buildTarget`
 *
 * 4. It removes the whole 3 sections `architect > server`, `architect > serve-ssr` and `architect > prerender`
 *    (because their responsibilities are now handled just by the single new Angular `application` builder)
 */
export declare function updateAngularJsonForSsr(): Rule;
