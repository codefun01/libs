"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.renameAppServerModule = renameAppServerModule;
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Renames `app.server.module.ts` to `app.module.server.ts`
 * to align with new Angular v17 standards.
 */
function renameAppServerModule() {
    return function (tree, context) {
        var AppServerModulePaths;
        (function (AppServerModulePaths) {
            AppServerModulePaths["old"] = "src/app/app.server.module.ts";
            AppServerModulePaths["new"] = "src/app/app.module.server.ts";
        })(AppServerModulePaths || (AppServerModulePaths = {}));
        context.logger.info("\n\u23F3 Renaming ".concat(AppServerModulePaths.old, " to ").concat(AppServerModulePaths.new, "..."));
        if (!tree.exists(AppServerModulePaths.old)) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("".concat(AppServerModulePaths.old, " file not found"), context);
            return;
        }
        var content = tree.read(AppServerModulePaths.old);
        if (!content) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("Failed to read ".concat(AppServerModulePaths.old, " file"), context);
            return;
        }
        tree.create(AppServerModulePaths.new, content.toString());
        tree.delete(AppServerModulePaths.old);
        context.logger.info("\u2705 Renamed ".concat(AppServerModulePaths.old, " to ").concat(AppServerModulePaths.new));
    };
}
//# sourceMappingURL=rename-app-server-module.js.map