"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addImportsToServerTs = addImportsToServerTs;
var ast_utils_1 = require("@schematics/angular/utility/ast-utils");
var change_1 = require("@schematics/angular/utility/change");
var file_utils_1 = require("../../../shared/utils/file-utils");
/**
 * Adds new imports to server.ts file, to align with Angular v17 standards.
 *
 * ```diff
 * + import { APP_BASE_HREF } from '@angular/common';
 * + import {
 * +   NgExpressEngineDecorator,
 * +   ngExpressEngine as engine,
 * + } from '@spartacus/setup/ssr';
 * + import express from 'express';
 * + import { dirname, join, resolve } from 'node:path';
 * + import { fileURLToPath } from 'node:url';
 * + import AppServerModule from './src/main.server';
```
 */
function addImportsToServerTs(updatedContent, context) {
    var sourceFile = (0, file_utils_1.parseTsFileContent)(updatedContent);
    // List of new imports to add
    var importsToAdd = [
        {
            importPath: 'express',
            symbolName: 'express',
            isDefault: true,
        },
        {
            importPath: 'node:path',
            symbolName: 'dirname',
        },
        {
            importPath: 'node:path',
            symbolName: 'join',
        },
        {
            importPath: 'node:path',
            symbolName: 'resolve',
        },
        {
            importPath: 'node:url',
            symbolName: 'fileURLToPath',
        },
        {
            importPath: './src/main.server',
            symbolName: 'AppServerModule',
            isDefault: true,
        },
    ];
    context.logger.info('  ↳ Adding new imports');
    var importAdditionChanges = importsToAdd.map(function (imp) {
        context.logger.info("    \u21B3 Importing \"".concat(imp.symbolName ? imp.symbolName + ' from ' : '').concat(imp.importPath, "\""));
        return (0, ast_utils_1.insertImport)(sourceFile, '', imp.symbolName, imp.importPath, imp.isDefault, imp.asName);
    });
    importAdditionChanges.forEach(function (change) {
        if (change instanceof change_1.InsertChange) {
            var start = change.pos;
            updatedContent =
                updatedContent.slice(0, start) +
                    change.toAdd +
                    updatedContent.slice(start);
        }
    });
    return updatedContent;
}
//# sourceMappingURL=add-imports-to-server-ts.js.map