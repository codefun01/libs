import { SchematicContext } from '@angular-devkit/schematics';
/**
 * Adds new imports to server.ts file, to align with Angular v17 standards.
 *
 * ```diff
 * + import { APP_BASE_HREF } from '@angular/common';
 * + import {
 * +   NgExpressEngineDecorator,
 * +   ngExpressEngine as engine,
 * + } from '@spartacus/setup/ssr';
 * + import express from 'express';
 * + import { dirname, join, resolve } from 'node:path';
 * + import { fileURLToPath } from 'node:url';
 * + import AppServerModule from './src/main.server';
```
 */
export declare function addImportsToServerTs(updatedContent: string, context: SchematicContext): string;
