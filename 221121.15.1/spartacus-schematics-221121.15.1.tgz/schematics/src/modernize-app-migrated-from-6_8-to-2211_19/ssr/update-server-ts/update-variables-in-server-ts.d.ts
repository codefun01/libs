import { SchematicContext } from '@angular-devkit/schematics';
/**
 * Updates variables and method calls in server.ts file.
 */
export declare function updateVariablesInServerTs(updatedContent: string, context: SchematicContext): string;
