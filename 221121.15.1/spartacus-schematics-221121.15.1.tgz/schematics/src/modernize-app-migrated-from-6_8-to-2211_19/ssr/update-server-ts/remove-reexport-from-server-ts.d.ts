import { SchematicContext } from '@angular-devkit/schematics';
/**
 * Removes the re-export of the path `./src/main.server`.
 *
 *   ```diff
 *   - export * from './src/main.server';
 *   ```
 */
export declare function removeReexportFromServerTs(fileContent: string, context: SchematicContext): string;
