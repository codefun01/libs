import { SchematicContext } from '@angular-devkit/schematics';
/**
 * Removes the Webpack-specific code and comments from the server.ts file.
 */
export declare function removeWebpackFromServerTs(updatedContent: string, context: SchematicContext): string;
