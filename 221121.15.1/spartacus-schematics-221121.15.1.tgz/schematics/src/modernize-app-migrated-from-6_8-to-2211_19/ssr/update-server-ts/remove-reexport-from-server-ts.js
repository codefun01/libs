"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeReexportFromServerTs = removeReexportFromServerTs;
var ast_utils_1 = require("@schematics/angular/utility/ast-utils");
var file_utils_1 = require("../../../shared/utils/file-utils");
var typescript_1 = __importDefault(require("typescript"));
var fallback_advice_to_follow_docs_1 = require("../../fallback-advice-to-follow-docs");
/**
 * Removes the re-export of the path `./src/main.server`.
 *
 *   ```diff
 *   - export * from './src/main.server';
 *   ```
 */
function removeReexportFromServerTs(fileContent, context) {
    var sourceFile = (0, file_utils_1.parseTsFileContent)(fileContent);
    var nodes = (0, ast_utils_1.findNodes)(sourceFile, typescript_1.default.SyntaxKind.ExportDeclaration);
    var reexportPath = './src/main.server';
    context.logger.info("  \u21B3 Removing the re-export of the path \"".concat(reexportPath, "\""));
    var exportNode = nodes.find(function (node) {
        if (!typescript_1.default.isExportDeclaration(node)) {
            return false;
        }
        var moduleSpecifier = node.moduleSpecifier;
        if (!moduleSpecifier) {
            return false;
        }
        return (typescript_1.default.isStringLiteral(moduleSpecifier) &&
            moduleSpecifier.text === reexportPath);
    });
    if (!exportNode) {
        (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("Could not remove the re-export of the path ".concat(reexportPath), context);
        return fileContent;
    }
    var start = exportNode.getFullStart();
    var end = exportNode.getEnd();
    return fileContent.slice(0, start) + fileContent.slice(end);
}
//# sourceMappingURL=remove-reexport-from-server-ts.js.map