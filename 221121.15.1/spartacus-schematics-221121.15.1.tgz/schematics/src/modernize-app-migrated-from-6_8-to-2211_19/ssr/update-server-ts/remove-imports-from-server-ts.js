"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeImportsFromServerTs = removeImportsFromServerTs;
var file_utils_1 = require("../../../shared/utils/file-utils");
/**
 * Removes imports from server.ts file, to align with Angular v17 standards.
 *
 * ```diff
 * - import 'zone.js/node';
 *
 * - import { ngExpressEngine as engine } from - '@spartacus/setup/ssr';
 * - import { NgExpressEngineDecorator } from - '@spartacus/setup/ssr';
 * - import * as express from 'express';
 * - import { join } from 'path';
 *
 * - import { AppServerModule } from './src/main.- server';
 * - import { APP_BASE_HREF } from '@angular/common';
 * - import { existsSync } from 'fs';
 * ```
 */
function removeImportsFromServerTs(updatedContent, context) {
    var importsToRemove = [
        { importPath: 'zone.js/node' },
        { symbolName: 'express', importPath: 'express' },
        { symbolName: 'join', importPath: 'path' },
        { symbolName: 'AppServerModule', importPath: './src/main.server' },
        { symbolName: 'existsSync', importPath: 'fs' },
    ];
    context.logger.info('  ↳ Removing old imports');
    importsToRemove.forEach(function (importToRemove) {
        context.logger.info("    \u21B3 Removing import of \"".concat(importToRemove.symbolName ? importToRemove.symbolName + ' from ' : '').concat(importToRemove.importPath, "\""));
        updatedContent = (0, file_utils_1.removeImportFromContent)(updatedContent, importToRemove);
    });
    return updatedContent;
}
//# sourceMappingURL=remove-imports-from-server-ts.js.map