"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeWebpackFromServerTs = removeWebpackFromServerTs;
var ast_utils_1 = require("@schematics/angular/utility/ast-utils");
var file_utils_1 = require("../../../shared/utils/file-utils");
var variable_utils_1 = require("../../../shared/utils/variable-utils");
var typescript_1 = __importDefault(require("typescript"));
var fallback_advice_to_follow_docs_1 = require("../../fallback-advice-to-follow-docs");
/**
 * Removes the Webpack-specific comments.
 *
 *   ```diff
 *   - // Webpack will replace 'require' with '__webpack_require__'
 *   - // '__non_webpack_require__' is a proxy to Node 'require'
 *   - // The below code is to ensure that the server is run only when not requiring the bundle.
 */
function removeWebpackSpecificComments(fileContent, context) {
    context.logger.info('  ↳ Removing Webpack-specific code comments //');
    return fileContent
        .replace(/\/\/ Webpack will replace 'require' with '__webpack_require__'\n/, '')
        .replace(/\/\/ '__non_webpack_require__' is a proxy to Node 'require'\n/, '')
        .replace(/\/\/ The below code is to ensure that the server is run only when not requiring the bundle\.\n/, '');
}
/**
 * Removes the Webpack-specific code and replaces with a simple `run()` call.
 *
 *   ```diff
 *   - declare const __non_webpack_require__: NodeRequire;
 *   - const mainModule = __non_webpack_require__.main;
 *   - const moduleFilename = (mainModule && mainModule.- filename) || '';
 *   - if (moduleFilename === __filename || moduleFilename.- includes('iisnode')) {
 *   -   run();
 *   - }
 *   + run();
 *   ```
 */
function removeWebpackSpecificCode(fileContent, context) {
    var updatedContent = fileContent;
    context.logger.info('  ↳ Removing Webpack-specific code');
    context.logger.info('    ↳ Removing const "__non_webpack_require__"');
    updatedContent = (0, variable_utils_1.removeVariableDeclaration)({
        fileContent: updatedContent,
        variableName: '__non_webpack_require__',
    });
    context.logger.info('    ↳ Removing const "mainModule"');
    updatedContent = (0, variable_utils_1.removeVariableDeclaration)({
        fileContent: updatedContent,
        variableName: 'mainModule',
    });
    context.logger.info('    ↳ Removing const "moduleFilename"');
    updatedContent = (0, variable_utils_1.removeVariableDeclaration)({
        fileContent: updatedContent,
        variableName: 'moduleFilename',
    });
    context.logger.info('    ↳ Removing "if" statement wrapping the "run()" call');
    var sourceFile = (0, file_utils_1.parseTsFileContent)(updatedContent);
    var ifNodes = (0, ast_utils_1.findNodes)(sourceFile, typescript_1.default.SyntaxKind.IfStatement);
    var ifNode = ifNodes.find(function (node) {
        if (!typescript_1.default.isIfStatement(node)) {
            return false;
        }
        var condition = node.expression;
        return (condition.getText().includes('moduleFilename === __filename') &&
            condition.getText().includes("moduleFilename.includes('iisnode')"));
    });
    if (ifNode) {
        var start = ifNode.getFullStart();
        var end = ifNode.getEnd();
        updatedContent = updatedContent.slice(0, start) + updatedContent.slice(end);
    }
    else {
        (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)('Could not remove the Webpack-specific `if` block', context);
        return updatedContent;
    }
    context.logger.info('    ↳ Adding standalone "run()" call');
    return (updatedContent +
        "\nrun();\n");
}
/**
 * Removes the Webpack-specific code and comments from the server.ts file.
 */
function removeWebpackFromServerTs(updatedContent, context) {
    updatedContent = removeWebpackSpecificComments(updatedContent, context);
    updatedContent = removeWebpackSpecificCode(updatedContent, context);
    return updatedContent;
}
//# sourceMappingURL=remove-webpack-from-server-ts.js.map