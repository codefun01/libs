import { Rule } from '@angular-devkit/schematics';
/**
 * Updates `main.server.ts` file for new Angular v17 standards.
 *
 * 1. Changes the the export path of the `AppServerModule` from `./app/app.server.module'` to `./app/app.module.server'`.
 * 2. Exports `AppServerModule` using `as default`.
 */
export declare function updateMainServerTs(): Rule;
