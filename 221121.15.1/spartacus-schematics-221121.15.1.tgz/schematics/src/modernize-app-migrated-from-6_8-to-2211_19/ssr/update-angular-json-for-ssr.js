"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAngularJsonForSsr = updateAngularJsonForSsr;
var workspace_utils_1 = require("../../shared/utils/workspace-utils");
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Updates the Angular configuration related to SSR for new Angular v17 standards.
 *
 * 1. In the section `architect > build > options` it adds 3 new options with values:
 *    `"server": "src/main.server.ts"`,
 *    `"prerender": false`,
 *     `"ssr": { "entry": "server.ts" }`
 *
 * 2. In the section `architect > build > configurations` it adds a new property with object value
 *    `"noSsr": { "ssr": false, "prerender": false }`
 *
 * 3. In the section `architect > serve > configurations` it adds the ending `,noSsr` (with the preceding comma)
 *    at the end of the string values in subsections
 *    `... > production > buildTarget` and
 *    `... > development > buildTarget`
 *
 * 4. It removes the whole 3 sections `architect > server`, `architect > serve-ssr` and `architect > prerender`
 *    (because their responsibilities are now handled just by the single new Angular `application` builder)
 */
function updateAngularJsonForSsr() {
    return function (tree, context) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
        context.logger.info('\n⏳ Updating angular.json for SSR...');
        var _l = (0, workspace_utils_1.getWorkspace)(tree), workspace = _l.workspace, path = _l.path;
        var firstProjectKey = Object.keys(workspace.projects)[0];
        var project = workspace.projects[firstProjectKey];
        if (!project) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)('No project found for SSR migration', context);
            return;
        }
        if (!((_a = project.architect) === null || _a === void 0 ? void 0 : _a.build)) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)('No build target found in project configuration', context);
            return;
        }
        context.logger.info('  ↳ Updating build target with SSR options: "server: "src/main.server.ts", "prerender": false, "ssr": { "entry": "server.ts" }');
        project.architect.build = __assign(__assign({}, project.architect.build), { options: __assign(__assign({}, project.architect.build.options), { server: 'src/main.server.ts', prerender: false, ssr: { entry: 'server.ts' } }), configurations: __assign(__assign({}, project.architect.build.configurations), { noSsr: { ssr: false, prerender: false } }) });
        context.logger.info('  ↳ Updating "outputPath" if it ends with /browser');
        var buildOptions = (_c = (_b = project.architect) === null || _b === void 0 ? void 0 : _b.build) === null || _c === void 0 ? void 0 : _c.options;
        if (typeof buildOptions.outputPath === 'string' &&
            buildOptions.outputPath.endsWith('/browser')) {
            buildOptions.outputPath = buildOptions.outputPath.replace(/\/browser$/, '');
        }
        else {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)('Could not update "outputPath" in angular.json', context);
            return;
        }
        context.logger.info('  ↳ Updating "serve" configurations with `,noSsr`');
        var serveConfigs = (_e = (_d = project.architect) === null || _d === void 0 ? void 0 : _d.serve) === null || _e === void 0 ? void 0 : _e.configurations;
        if (serveConfigs) {
            project.architect.serve = __assign(__assign({}, project.architect.serve), { configurations: __assign(__assign({}, serveConfigs), { production: __assign(__assign({}, serveConfigs.production), { buildTarget: "".concat((_f = serveConfigs.production) === null || _f === void 0 ? void 0 : _f.buildTarget, ",noSsr") }), development: __assign(__assign({}, serveConfigs.development), { buildTarget: "".concat((_g = serveConfigs.development) === null || _g === void 0 ? void 0 : _g.buildTarget, ",noSsr") }) }) });
        }
        else {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)('Could not update "serve" configurations in angular.json', context);
            return;
        }
        context.logger.info('  ↳ Removing obsolete "architect" targets: "server", "serve-ssr", "prerender"');
        (_h = project.architect) === null || _h === void 0 ? true : delete _h.server;
        (_j = project.architect) === null || _j === void 0 ? true : delete _j['serve-ssr'];
        (_k = project.architect) === null || _k === void 0 ? true : delete _k.prerender;
        var JSON_INDENT = 2;
        tree.overwrite(path, JSON.stringify(workspace, null, JSON_INDENT));
        context.logger.info('✅ Updated angular.json for SSR');
    };
}
//# sourceMappingURL=update-angular-json-for-ssr.js.map