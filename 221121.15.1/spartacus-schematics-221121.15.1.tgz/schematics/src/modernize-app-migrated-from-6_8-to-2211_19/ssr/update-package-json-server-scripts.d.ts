import { Rule } from '@angular-devkit/schematics';
/**
 * Updates `package.json` scripts related to SSR to align with new Angular v17 standards.
 *
 * 1. Removes properties `"dev:ssr"` and `"prerender"`
 * 2. Changes value of the property `"build:ssr"` to `"ng build"`
 * 3. Renames the property `"serve:ssr"` to `"serve:ssr:YOUR-APP-NAME"` and change its value to `"node dist/YOUR-APP-NAME/server/server.mjs"`
 * ```
 */
export declare function updatePackageJsonServerScripts(): Rule;
