"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeTsConfigServer = removeTsConfigServer;
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Removes the `tsconfig.server.json` file from the project,
 * to align with the new Angular v17 standards.
 */
function removeTsConfigServer() {
    return function (tree, context) {
        var tsconfigServerPath = 'tsconfig.server.json';
        context.logger.info("\n\u23F3 Removing ".concat(tsconfigServerPath, "..."));
        if (!tree.exists(tsconfigServerPath)) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("".concat(tsconfigServerPath, " file not found"), context);
            return;
        }
        tree.delete(tsconfigServerPath);
        context.logger.info("\u2705 Removed ".concat(tsconfigServerPath));
    };
}
//# sourceMappingURL=remove-ts-config-server.js.map