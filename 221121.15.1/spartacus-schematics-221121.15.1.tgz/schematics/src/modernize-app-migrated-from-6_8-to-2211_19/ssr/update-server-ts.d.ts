import { Rule } from '@angular-devkit/schematics';
/**
 * Updates `server.ts` file for new Angular v17 standards.
 *
 * Modernizes imports, configures new paths for `index.html` file,
 * removes Webpack-specific code, and removes obsolete export.
 */
export declare function updateServerTs(): Rule;
