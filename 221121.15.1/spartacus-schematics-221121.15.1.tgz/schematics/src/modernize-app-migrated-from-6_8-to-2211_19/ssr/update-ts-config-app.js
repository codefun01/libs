"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateTsConfigApp = updateTsConfigApp;
var jsonc_parser_1 = require("jsonc-parser");
var array_utils_1 = require("../../shared/utils/array-utils");
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Updates `tsconfig.app.json` to align with new Angular v17 standards.
 *
 * 1. Adds 1 new item to the array in the property `"types"`: `"node"`
 * 2. Adds 2 new items to the in the `"files"` array: `"src/main.server.ts"` , `"server.ts"`
 */
function updateTsConfigApp() {
    return function (tree, context) {
        var _a;
        var tsconfigAppPath = 'tsconfig.app.json';
        context.logger.info("\n\u23F3 Updating ".concat(tsconfigAppPath, " configuration..."));
        if (!tree.exists(tsconfigAppPath)) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("".concat(tsconfigAppPath, " file not found"), context);
            return;
        }
        var tsConfigAppContent = tree.read(tsconfigAppPath);
        if (!tsConfigAppContent) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("Failed to read ".concat(tsconfigAppPath, " file"), context);
            return;
        }
        var tsConfigApp = (0, jsonc_parser_1.parse)(tsConfigAppContent.toString());
        context.logger.info('  ↳ Adding "node" to "types" array');
        tsConfigApp.compilerOptions = __assign(__assign({}, tsConfigApp.compilerOptions), { types: (0, array_utils_1.mergeArraysWithoutDuplicates)((_a = tsConfigApp.compilerOptions) === null || _a === void 0 ? void 0 : _a.types, [
                'node',
            ]) });
        var serverFiles = ['src/main.server.ts', 'server.ts'];
        context.logger.info("  \u21B3 Adding ".concat(serverFiles
            .map(function (x) { return "\"".concat(x, "\""); })
            .join(', '), " to \"files\" array"));
        tsConfigApp.files = (0, array_utils_1.mergeArraysWithoutDuplicates)(tsConfigApp.files, serverFiles);
        var JSON_INDENT = 2;
        tree.overwrite(tsconfigAppPath, JSON.stringify(tsConfigApp, null, JSON_INDENT));
        context.logger.info("\u2705 Updated ".concat(tsconfigAppPath, " configuration"));
    };
}
//# sourceMappingURL=update-ts-config-app.js.map