"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateMainServerTs = updateMainServerTs;
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Updates `main.server.ts` file for new Angular v17 standards.
 *
 * 1. Changes the the export path of the `AppServerModule` from `./app/app.server.module'` to `./app/app.module.server'`.
 * 2. Exports `AppServerModule` using `as default`.
 */
function updateMainServerTs() {
    return function (tree, context) {
        var mainServerPath = 'src/main.server.ts';
        context.logger.info("\n\u23F3 Updating ".concat(mainServerPath, "..."));
        if (!tree.exists(mainServerPath)) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("".concat(mainServerPath, " file not found"), context);
            return;
        }
        var mainServerContent = tree.read(mainServerPath);
        if (!mainServerContent) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("Failed to read ".concat(mainServerPath, " file"), context);
            return;
        }
        context.logger.info('  ↳ Updating export path of "AppServerModule"');
        var expectedPattern = /export \{ AppServerModule \} from ['"]\.\/app\/app\.server\.module['"];/;
        var newPattern = "export { AppServerModule as default } from './app/app.module.server';";
        var updatedContent = mainServerContent.toString();
        if (!expectedPattern.test(updatedContent)) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("".concat(mainServerPath, " does not contain the expected export"), context);
            return;
        }
        updatedContent = updatedContent.replace(expectedPattern, newPattern);
        tree.overwrite(mainServerPath, updatedContent);
        context.logger.info("\u2705 Updated ".concat(mainServerPath));
    };
}
//# sourceMappingURL=update-main-server-ts.js.map