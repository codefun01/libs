import { Rule } from '@angular-devkit/schematics';
/**
 * Updates `tsconfig.app.json` to align with new Angular v17 standards.
 *
 * 1. Adds 1 new item to the array in the property `"types"`: `"node"`
 * 2. Adds 2 new items to the in the `"files"` array: `"src/main.server.ts"` , `"server.ts"`
 */
export declare function updateTsConfigApp(): Rule;
