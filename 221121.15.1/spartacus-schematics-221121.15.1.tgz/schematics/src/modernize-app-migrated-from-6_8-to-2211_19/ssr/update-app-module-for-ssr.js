"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAppModuleForSsr = updateAppModuleForSsr;
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
function updateAppModuleForSsr() {
    return function (tree, context) {
        var appModulePath = 'src/app/app.module.ts';
        context.logger.info("\n\u23F3 Updating ".concat(appModulePath, " for SSR..."));
        if (!tree.exists(appModulePath)) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("Could not find ".concat(appModulePath), context);
            return;
        }
        var content = tree.read(appModulePath);
        if (!content) {
            return;
        }
        var updatedContent = content.toString();
        context.logger.info('  ↳ Removing "withServerTransition()" call from the "BrowserModule" import');
        updatedContent = updatedContent.replace(/BrowserModule\.withServerTransition\(\s*{\s*appId:\s*['"]serverApp['"]\s*}\s*\)/, 'BrowserModule');
        tree.overwrite(appModulePath, updatedContent);
        context.logger.info("\u2705 Updated ".concat(appModulePath, " for SSR"));
    };
}
//# sourceMappingURL=update-app-module-for-ssr.js.map