"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updatePackageJsonServerScripts = updatePackageJsonServerScripts;
var workspace_utils_1 = require("../../shared/utils/workspace-utils");
var jsonc_parser_1 = require("jsonc-parser");
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Updates `package.json` scripts related to SSR to align with new Angular v17 standards.
 *
 * 1. Removes properties `"dev:ssr"` and `"prerender"`
 * 2. Changes value of the property `"build:ssr"` to `"ng build"`
 * 3. Renames the property `"serve:ssr"` to `"serve:ssr:YOUR-APP-NAME"` and change its value to `"node dist/YOUR-APP-NAME/server/server.mjs"`
 * ```
 */
function updatePackageJsonServerScripts() {
    return function (tree, context) {
        var packageJsonPath = 'package.json';
        context.logger.info("\n\u23F3 Updating ".concat(packageJsonPath, " scripts..."));
        if (!tree.exists(packageJsonPath)) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("".concat(packageJsonPath, " file not found"), context);
            return;
        }
        // Get app name from workspace
        var workspace = (0, workspace_utils_1.getWorkspace)(tree).workspace;
        var projectName = Object.keys(workspace.projects)[0];
        if (!projectName) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)('No project found in workspace', context);
            return;
        }
        var content = tree.read(packageJsonPath);
        if (!content) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("Failed to read ".concat(packageJsonPath, " file"), context);
            return;
        }
        var packageJson = (0, jsonc_parser_1.parse)(content.toString());
        if (!packageJson.scripts) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("No scripts section found in ".concat(packageJsonPath), context);
            return;
        }
        context.logger.info('  ↳ Removing "dev:ssr" script');
        delete packageJson.scripts['dev:ssr'];
        context.logger.info('  ↳ Removing "prerender" script');
        delete packageJson.scripts['prerender'];
        context.logger.info('  ↳ Removing "serve:ssr" script');
        delete packageJson.scripts['serve:ssr'];
        context.logger.info('  ↳ Updating "build:ssr" script');
        packageJson.scripts['build:ssr'] = 'ng build';
        context.logger.info("  \u21B3 Adding \"serve:ssr:".concat(projectName, "\" script"));
        packageJson.scripts["serve:ssr:".concat(projectName)] =
            "node dist/".concat(projectName, "/server/server.mjs");
        var JSON_INDENT = 2;
        tree.overwrite(packageJsonPath, JSON.stringify(packageJson, null, JSON_INDENT));
        context.logger.info("\u2705 Updated ".concat(packageJsonPath, " scripts"));
    };
}
//# sourceMappingURL=update-package-json-server-scripts.js.map