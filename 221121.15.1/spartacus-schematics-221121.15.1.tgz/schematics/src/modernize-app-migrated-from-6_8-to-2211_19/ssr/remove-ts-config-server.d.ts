import { Rule } from '@angular-devkit/schematics';
/**
 * Removes the `tsconfig.server.json` file from the project,
 * to align with the new Angular v17 standards.
 */
export declare function removeTsConfigServer(): Rule;
