import { Rule } from '@angular-devkit/schematics';
/**
 * Modernizes an application to use new Angular v17 standards.
 */
export declare function migrate(): Rule;
