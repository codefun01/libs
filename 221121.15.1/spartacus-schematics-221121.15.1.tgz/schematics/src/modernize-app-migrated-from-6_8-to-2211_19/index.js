"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrate = migrate;
var schematics_1 = require("@angular-devkit/schematics");
var update_angular_json_for_application_builder_1 = require("./csr-and-ssr/update-angular-json-for-application-builder");
var update_ts_config_1 = require("./csr-and-ssr/update-ts-config");
var update_angular_json_for_ssr_1 = require("./ssr/update-angular-json-for-ssr");
var update_ts_config_app_1 = require("./ssr/update-ts-config-app");
var rename_app_server_module_1 = require("./ssr/rename-app-server-module");
var update_main_server_ts_1 = require("./ssr/update-main-server-ts");
var update_server_ts_1 = require("./ssr/update-server-ts");
var update_app_module_1 = require("./csr-and-ssr/update-app-module");
var update_package_json_server_scripts_1 = require("./ssr/update-package-json-server-scripts");
var remove_ts_config_server_1 = require("./ssr/remove-ts-config-server");
var fallback_advice_to_follow_docs_1 = require("./fallback-advice-to-follow-docs");
var update_app_module_for_ssr_1 = require("./ssr/update-app-module-for-ssr");
var package_utils_1 = require("../shared/utils/package-utils");
/**
 * Modernizes an application to use new Angular v17 standards.
 */
function migrate() {
    return function (tree) {
        return (0, schematics_1.chain)(__spreadArray([
            (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_6_8_To_2211_19)((0, update_angular_json_for_application_builder_1.updateAngularJsonForApplicationBuilder)()),
            (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_6_8_To_2211_19)((0, update_ts_config_1.updateTsConfig)()),
            (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_6_8_To_2211_19)((0, update_app_module_1.updateAppModule)())
        ], ((0, package_utils_1.isUsingLegacyServerBuilder)(tree)
            ? [
                (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_6_8_To_2211_19)((0, update_angular_json_for_ssr_1.updateAngularJsonForSsr)()),
                (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_6_8_To_2211_19)((0, update_package_json_server_scripts_1.updatePackageJsonServerScripts)()),
                (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_6_8_To_2211_19)((0, update_ts_config_app_1.updateTsConfigApp)()),
                (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_6_8_To_2211_19)((0, remove_ts_config_server_1.removeTsConfigServer)()),
                (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_6_8_To_2211_19)((0, rename_app_server_module_1.renameAppServerModule)()),
                (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_6_8_To_2211_19)((0, update_main_server_ts_1.updateMainServerTs)()),
                (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_6_8_To_2211_19)((0, update_server_ts_1.updateServerTs)()),
                (0, fallback_advice_to_follow_docs_1.withFallbackDocsForMigrated_6_8_To_2211_19)((0, update_app_module_for_ssr_1.updateAppModuleForSsr)()),
            ]
            : []), true));
    };
}
//# sourceMappingURL=index.js.map