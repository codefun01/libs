import { Rule } from '@angular-devkit/schematics';
/**
 * Updates the Angular configuration file to new Angular v17 standards.
 *
 * Configures the new Angular application builder:
 * '@angular-devkit/build-angular:application',
 * updates output paths, and removes obsolete build options.
 */
export declare function updateAngularJsonForApplicationBuilder(): Rule;
