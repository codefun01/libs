import { Rule } from '@angular-devkit/schematics';
/**
 * Updates `app.module.ts` file for new Angular v17 standards.
 *
 * Removes `HttpClientModule` in favor of `provideHttpClient()`,
 * with using `withFetch` and `withInterceptorsFromDi()`,
 * and removes the obsolete method `BrowserModule.withServerTransition()`.
 */
export declare function updateAppModule(): Rule;
