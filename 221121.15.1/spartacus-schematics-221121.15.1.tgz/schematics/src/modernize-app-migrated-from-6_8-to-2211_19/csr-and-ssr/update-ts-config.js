"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateTsConfig = updateTsConfig;
var jsonc_parser_1 = require("jsonc-parser");
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Updates the `tsconfig.json` file for new Angular v17 standards.
 *
 * 1. Removes the properties `"baseUrl"`, `"forceConsistentCasingInFileNames"`, `"downlevelIteration"`,
 * 2. Adds `"skipLibCheck": true`, `"esModuleInterop": true`
 */
function updateTsConfig() {
    return function (tree, context) {
        var tsconfigPath = 'tsconfig.json';
        context.logger.info("\n\u23F3 Updating ".concat(tsconfigPath, "..."));
        if (!tree.exists(tsconfigPath)) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("".concat(tsconfigPath, " file not found"), context);
            return;
        }
        var tsConfigContent = tree.read(tsconfigPath);
        if (!tsConfigContent) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("Failed to read ".concat(tsconfigPath, " file"), context);
            return;
        }
        var tsConfig = (0, jsonc_parser_1.parse)(tsConfigContent.toString());
        if (!tsConfig.compilerOptions) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("No compilerOptions found in ".concat(tsconfigPath), context);
            return;
        }
        context.logger.info('  ↳ Removing "baseUrl" from compilerOptions');
        delete tsConfig.compilerOptions.baseUrl;
        context.logger.info('  ↳ Removing "forceConsistentCasingInFileNames" from compilerOptions');
        delete tsConfig.compilerOptions.forceConsistentCasingInFileNames;
        context.logger.info('  ↳ Removing "downlevelIteration" from compilerOptions');
        delete tsConfig.compilerOptions.downlevelIteration;
        context.logger.info('  ↳ Adding "skipLibCheck": true to compilerOptions');
        tsConfig.compilerOptions.skipLibCheck = true;
        context.logger.info('  ↳ Adding "esModuleInterop": true to compilerOptions');
        tsConfig.compilerOptions.esModuleInterop = true;
        delete tsConfig.compilerOptions.baseUrl;
        delete tsConfig.compilerOptions.forceConsistentCasingInFileNames;
        delete tsConfig.compilerOptions.downlevelIteration;
        tsConfig.compilerOptions.skipLibCheck = true;
        tsConfig.compilerOptions.esModuleInterop = true;
        var JSON_INDENT = 2;
        tree.overwrite(tsconfigPath, JSON.stringify(tsConfig, null, JSON_INDENT));
        context.logger.info("\u2705 Updated ".concat(tsconfigPath));
    };
}
//# sourceMappingURL=update-ts-config.js.map