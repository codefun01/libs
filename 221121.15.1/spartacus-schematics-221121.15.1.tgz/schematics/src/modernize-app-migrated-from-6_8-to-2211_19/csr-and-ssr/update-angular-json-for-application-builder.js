"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAngularJsonForApplicationBuilder = updateAngularJsonForApplicationBuilder;
var workspace_utils_1 = require("../../shared/utils/workspace-utils");
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Updates the Angular configuration file to new Angular v17 standards.
 *
 * Configures the new Angular application builder:
 * '@angular-devkit/build-angular:application',
 * updates output paths, and removes obsolete build options.
 */
function updateAngularJsonForApplicationBuilder() {
    return function (tree, context) {
        var _a, _b;
        context.logger.info('\n⏳ Updating angular.json for application builder...');
        var _c = (0, workspace_utils_1.getWorkspace)(tree), workspace = _c.workspace, path = _c.path;
        var project = workspace.projects[Object.keys(workspace.projects)[0]];
        if (!project) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)('No project found in workspace', context);
            return;
        }
        var buildTarget = (_a = project.architect) === null || _a === void 0 ? void 0 : _a.build;
        if (!buildTarget) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)('No build target found in project configuration', context);
            return;
        }
        var newBuilder = '@angular-devkit/build-angular:application';
        context.logger.info("  \u21B3 Updating builder to \"".concat(newBuilder, "\" from \"").concat(buildTarget.builder, "\""));
        buildTarget.builder = newBuilder;
        context.logger.info('  ↳ Renaming "main" to "browser" in build options');
        var options = buildTarget.options;
        if (options === null || options === void 0 ? void 0 : options.main) {
            options.browser = options.main;
            delete options.main;
        }
        else {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)('Could not rename "main" to "browser" in angular.json', context);
            return;
        }
        context.logger.info('  ↳ Removing obsolete build options from "development" configuration');
        var devConfig = (_b = buildTarget.configurations) === null || _b === void 0 ? void 0 : _b.development;
        if (devConfig) {
            delete devConfig.buildOptimizer;
            delete devConfig.vendorChunk;
            delete devConfig.namedChunks;
        }
        else {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)('Could not update "development" configuration in angular.json', context);
            return;
        }
        context.logger.info('✅ Updated angular.json for application builder');
        var JSON_INDENT = 2;
        tree.overwrite(path, JSON.stringify(workspace, null, JSON_INDENT));
    };
}
//# sourceMappingURL=update-angular-json-for-application-builder.js.map