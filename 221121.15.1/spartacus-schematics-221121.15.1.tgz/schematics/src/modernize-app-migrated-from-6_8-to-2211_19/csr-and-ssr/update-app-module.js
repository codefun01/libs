"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAppModule = updateAppModule;
var shared_1 = require("../../shared");
var fallback_advice_to_follow_docs_1 = require("../fallback-advice-to-follow-docs");
/**
 * Updates `app.module.ts` file for new Angular v17 standards.
 *
 * Removes `HttpClientModule` in favor of `provideHttpClient()`,
 * with using `withFetch` and `withInterceptorsFromDi()`,
 * and removes the obsolete method `BrowserModule.withServerTransition()`.
 */
function updateAppModule() {
    return function (tree, context) {
        var appModulePath = 'src/app/app.module.ts';
        context.logger.info("\n\u23F3 Updating ".concat(appModulePath, "..."));
        if (!tree.exists(appModulePath)) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("No ".concat(appModulePath, " found"), context);
            return;
        }
        var content = tree.read(appModulePath);
        if (!content) {
            (0, fallback_advice_to_follow_docs_1.printErrorWithDocsForMigrated_6_8_To_2211_19)("Could not read content of ".concat(appModulePath), context);
            return;
        }
        var updatedContent = content.toString();
        context.logger.info('  ↳ Removing import of HttpClientModule from @angular/common/http');
        updatedContent = (0, shared_1.removeImportFromContent)(updatedContent, {
            symbolName: 'HttpClientModule',
            importPath: '@angular/common/http',
        });
        context.logger.info('  ↳ Removing usage of HttpClientModule');
        updatedContent = updatedContent.replace(/HttpClientModule,?\s*/g, '');
        context.logger.info('  ↳ Adding provideHttpClient to NgModule providers');
        if (!updatedContent.includes('provideHttpClient')) {
            updatedContent = updatedContent.replace(/providers:\s*\[/, 'providers: [\n    provideHttpClient(withFetch(), withInterceptorsFromDi()),');
            context.logger.info('  ↳ Adding imports of provideHttpClient, withFetch, withInterceptorsFromDi from @angular/common/http');
            var httpImport = "import { provideHttpClient, withFetch, withInterceptorsFromDi } from '@angular/common/http';\n";
            if (updatedContent.includes('import {')) {
                updatedContent = updatedContent.replace(/import {/, "".concat(httpImport, "import {"));
            }
        }
        tree.overwrite(appModulePath, updatedContent);
        context.logger.info("\u2705 Updated ".concat(appModulePath));
    };
}
//# sourceMappingURL=update-app-module.js.map