import { Rule } from '@angular-devkit/schematics';
/**
 * Updates the `tsconfig.json` file for new Angular v17 standards.
 *
 * 1. Removes the properties `"baseUrl"`, `"forceConsistentCasingInFileNames"`, `"downlevelIteration"`,
 * 2. Adds `"skipLibCheck": true`, `"esModuleInterop": true`
 */
export declare function updateTsConfig(): Rule;
