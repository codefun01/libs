import { Rule, SchematicContext } from '@angular-devkit/schematics';
/**
 * URL where to find the manual migration steps.
 */
export declare const DOCS_URL_FOR_MODERNIZING_APPS_MIGRATED_FROM_6_8_TO_2211_19 = "https://help.sap.com/docs/SAP_COMMERCE_COMPOSABLE_STOREFRONT/10a8bc7f635b4e3db6f6bb7880e58a7d/525dd86b812544249e78d73f67f3e6ed.html";
/**
 * Prints an error message and a link to the manual migration steps.
 */
export declare function printErrorWithDocsForMigrated_6_8_To_2211_19(message: string, context: SchematicContext): void;
/**
 * If the wrapped Rule throws an error, it logs the error and prints a link to manual migration docs.
 */
export declare function withFallbackDocsForMigrated_6_8_To_2211_19(rule: Rule): Rule;
