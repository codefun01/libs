"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.DOCS_URL_FOR_MODERNIZING_APPS_MIGRATED_FROM_6_8_TO_2211_19 = void 0;
exports.printErrorWithDocsForMigrated_6_8_To_2211_19 = printErrorWithDocsForMigrated_6_8_To_2211_19;
exports.withFallbackDocsForMigrated_6_8_To_2211_19 = withFallbackDocsForMigrated_6_8_To_2211_19;
/**
 * URL where to find the manual migration steps.
 */
exports.DOCS_URL_FOR_MODERNIZING_APPS_MIGRATED_FROM_6_8_TO_2211_19 = 'https://help.sap.com/docs/SAP_COMMERCE_COMPOSABLE_STOREFRONT/10a8bc7f635b4e3db6f6bb7880e58a7d/525dd86b812544249e78d73f67f3e6ed.html';
var FALLBACK_ADVICE_TO_FOLLOW_DOCS = "Could not complete this step automatically. To complete the migration, please follow the manual steps: ".concat(exports.DOCS_URL_FOR_MODERNIZING_APPS_MIGRATED_FROM_6_8_TO_2211_19);
/**
 * Prints an error message and a link to the manual migration steps.
 */
function printErrorWithDocsForMigrated_6_8_To_2211_19(message, context) {
    context.logger.error("\u26A0\uFE0F ".concat(message));
    context.logger.error(FALLBACK_ADVICE_TO_FOLLOW_DOCS);
}
/**
 * If the wrapped Rule throws an error, it logs the error and prints a link to manual migration docs.
 */
function withFallbackDocsForMigrated_6_8_To_2211_19(rule) {
    return function (tree, context) {
        try {
            return rule(tree, context);
        }
        catch (error) {
            printErrorWithDocsForMigrated_6_8_To_2211_19(error instanceof Error ? error.message : 'Unknown error', context);
            return tree;
        }
    };
}
//# sourceMappingURL=fallback-advice-to-follow-docs.js.map