"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.featureSchematicConfigMapping = exports.featureRootModuleMapping = exports.featureFeatureModuleMapping = exports.libraryFeatureMapping = exports.SCHEMATICS_CONFIGS = void 0;
exports.generateMappings = generateMappings;
exports.getKeyByMappingValue = getKeyByMappingValue;
exports.getKeyByMappingValueOrThrow = getKeyByMappingValueOrThrow;
exports.getSchematicsConfigByFeatureOrThrow = getSchematicsConfigByFeatureOrThrow;
var asm_schematics_config_1 = require("./lib-configs/asm-schematics-config");
var cart_schematics_config_1 = require("./lib-configs/cart-schematics-config");
var cdc_schematics_config_1 = require("./lib-configs/integration-libs/cdc-schematics-config");
var lib_configs_1 = require("./lib-configs");
var checkout_schematics_config_1 = require("./lib-configs/checkout-schematics-config");
var opf_schematics_config_1 = require("./lib-configs/integration-libs/opf-schematics-config");
var organization_schematics_config_1 = require("./lib-configs/organization-schematics-config");
var product_schematics_config_1 = require("./lib-configs/product-schematics-config");
var product_configurator_schematics_config_1 = require("./lib-configs/product-configurator-schematics-config");
var product_multi_dimensional_schematics_config_1 = require("./lib-configs/product-multi-dimensional-schematics-config");
var tracking_schematics_config_1 = require("./lib-configs/tracking-schematics-config");
var user_schematics_config_1 = require("./lib-configs/user-schematics-config");
var cds_schematics_config_1 = require("./lib-configs/integration-libs/cds-schematics-config");
var cpq_quote_schematics_config_1 = require("./lib-configs/integration-libs/cpq-quote-schematics-config");
var customer_ticketing_schematics_config_1 = require("./lib-configs/customer-ticketing-schematics-config");
var digital_payments_schematics_config_1 = require("./lib-configs/integration-libs/digital-payments-schematics-config");
var epd_schematics_config_1 = require("./lib-configs/integration-libs/epd-schematics-config");
var estimated_delivery_date_schematics_config_1 = require("./lib-configs/estimated-delivery-date-schematics-config");
var order_schematics_config_1 = require("./lib-configs/order-schematics-config");
var pdf_invoices_schematics_config_1 = require("./lib-configs/pdf-invoices-schematics-config");
var pickup_in_store_schematics_config_1 = require("./lib-configs/pickup-in-store-schematics-config");
var qualtrics_schematics_config_1 = require("./lib-configs/qualtrics-schematics-config");
var requested_delivery_date_schematics_config_1 = require("./lib-configs/requested-delivery-date-schematics-config");
var s4om_schematics_config_1 = require("./lib-configs/integration-libs/s4om-schematics-config");
var segment_refs_schematics_config_1 = require("./lib-configs/integration-libs/segment-refs-schematics-config");
var smartedit_schematics_config_1 = require("./lib-configs/smartedit-schematics-config");
var storefinder_schematics_config_1 = require("./lib-configs/storefinder-schematics-config");
var schematics_1 = require("@angular-devkit/schematics");
/**
 * A list of all schematics feature configurations.
 * _Must_ be updated when adding a new schematics
 * library or a feature.
 */
exports.SCHEMATICS_CONFIGS = [
    // feature libraries start
    asm_schematics_config_1.ASM_SCHEMATICS_CONFIG,
    asm_schematics_config_1.ASM_CUSTOMER_360_SCHEMATICS_CONFIG,
    cart_schematics_config_1.CART_BASE_SCHEMATICS_CONFIG,
    cart_schematics_config_1.CART_IMPORT_EXPORT_SCHEMATICS_CONFIG,
    cart_schematics_config_1.CART_QUICK_ORDER_SCHEMATICS_CONFIG,
    cart_schematics_config_1.CART_WISHLIST_SCHEMATICS_CONFIG,
    cart_schematics_config_1.CART_SAVED_CART_SCHEMATICS_CONFIG,
    checkout_schematics_config_1.CHECKOUT_BASE_SCHEMATICS_CONFIG,
    checkout_schematics_config_1.CHECKOUT_B2B_SCHEMATICS_CONFIG,
    checkout_schematics_config_1.CHECKOUT_SCHEDULED_REPLENISHMENT_SCHEMATICS_CONFIG,
    lib_configs_1.QUOTE_SCHEMATICS_CONFIG,
    order_schematics_config_1.ORDER_SCHEMATICS_CONFIG,
    lib_configs_1.ORDER_DOCUMENT_FLOW_SCHEMATICS_CONFIG,
    organization_schematics_config_1.ORGANIZATION_ADMINISTRATION_SCHEMATICS_CONFIG,
    organization_schematics_config_1.ORGANIZATION_ORDER_APPROVAL_SCHEMATICS_CONFIG,
    organization_schematics_config_1.ORGANIZATION_USER_REGISTRATION_SCHEMATICS_CONFIG,
    organization_schematics_config_1.ORGANIZATION_UNIT_ORDER_SCHEMATICS_CONFIG,
    organization_schematics_config_1.ORGANIZATION_ACCOUNT_SUMMARY_SCHEMATICS_CONFIG,
    pickup_in_store_schematics_config_1.PICKUP_IN_STORE_SCHEMATICS_CONFIG,
    product_configurator_schematics_config_1.PRODUCT_CONFIGURATOR_TEXTFIELD_SCHEMATICS_CONFIG,
    product_configurator_schematics_config_1.PRODUCT_CONFIGURATOR_RULEBASED_SCHEMATICS_CONFIG,
    product_configurator_schematics_config_1.PRODUCT_CONFIGURATOR_CPQ_SCHEMATICS_CONFIG,
    product_schematics_config_1.PRODUCT_BULK_PRICING_SCHEMATICS_CONFIG,
    product_schematics_config_1.PRODUCT_IMAGE_ZOOM_SCHEMATICS_CONFIG,
    product_schematics_config_1.PRODUCT_VARIANTS_SCHEMATICS_CONFIG,
    product_multi_dimensional_schematics_config_1.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_SCHEMATICS_CONFIG,
    product_multi_dimensional_schematics_config_1.PRODUCT_MULTI_DIMENSIONAL_LIST_SCHEMATICS_CONFIG,
    product_schematics_config_1.PRODUCT_FUTURE_STOCK_SCHEMATICS_CONFIG,
    pdf_invoices_schematics_config_1.PDF_INVOICES_SCHEMATICS_CONFIG,
    qualtrics_schematics_config_1.QUALTRICS_SCHEMATICS_CONFIG,
    requested_delivery_date_schematics_config_1.REQUESTED_DELIVERY_DATE_SCHEMATICS_CONFIG,
    estimated_delivery_date_schematics_config_1.ESTIMATED_DELIVERY_DATE_SCHEMATICS_CONFIG,
    smartedit_schematics_config_1.SMARTEDIT_SCHEMATICS_CONFIG,
    storefinder_schematics_config_1.STOREFINDER_SCHEMATICS_CONFIG,
    tracking_schematics_config_1.TRACKING_PERSONALIZATION_SCHEMATICS_CONFIG,
    tracking_schematics_config_1.TRACKING_GTM_SCHEMATICS_CONFIG,
    tracking_schematics_config_1.TRACKING_AEP_SCHEMATICS_CONFIG,
    user_schematics_config_1.USER_ACCOUNT_SCHEMATICS_CONFIG,
    user_schematics_config_1.USER_PROFILE_SCHEMATICS_CONFIG,
    customer_ticketing_schematics_config_1.CUSTOMER_TICKETING_SCHEMATICS_CONFIG,
    lib_configs_1.SUBSCRIPTION_BILLING_SCHEMATICS_CONFIG,
    // integration libraries start
    cdc_schematics_config_1.CDC_SCHEMATICS_CONFIG,
    cdc_schematics_config_1.CDC_B2B_SCHEMATICS_CONFIG,
    lib_configs_1.CDP_SCHEMATICS_CONFIG,
    cds_schematics_config_1.CDS_SCHEMATICS_CONFIG,
    digital_payments_schematics_config_1.DIGITAL_PAYMENTS_SCHEMATICS_CONFIG,
    epd_schematics_config_1.EPD_SCHEMATICS_CONFIG,
    lib_configs_1.OPPS_SCHEMATICS_CONFIG,
    lib_configs_1.OMF_SCHEMATICS_CONFIG,
    s4om_schematics_config_1.S4OM_SCHEMATICS_CONFIG,
    opf_schematics_config_1.OPF_BASE_SCHEMATICS_CONFIG,
    opf_schematics_config_1.OPF_CHECKOUT_SCHEMATICS_CONFIG,
    opf_schematics_config_1.OPF_B2B_CHECKOUT_SCHEMATICS_CONFIG,
    opf_schematics_config_1.OPF_PAYMENT_SCHEMATICS_CONFIG,
    opf_schematics_config_1.OPF_CTA_SCHEMATICS_CONFIG,
    opf_schematics_config_1.OPF_GLOBAL_FUNCTIONS_SCHEMATICS_CONFIG,
    opf_schematics_config_1.OPF_QUICK_BUY_SCHEMATICS_CONFIG,
    opf_schematics_config_1.OPF_GIFT_CARD_SCHEMATICS_CONFIG,
    opf_schematics_config_1.OPF_TOKENISATION_SCHEMATICS_CONFIG,
    lib_configs_1.S4_SERVICE_SCHEMATICS_CONFIG,
    segment_refs_schematics_config_1.SEGMENT_REFS_SCHEMATICS_CONFIG,
    cpq_quote_schematics_config_1.CPQ_QUOTE_SCHEMATICS_CONFIG,
    lib_configs_1.PUNCHOUT_SCHEMATICS_CONFIG,
];
/**
 * Maps sub-features to their parent feature.
 */
/**
 * Mapping of features to Spartacus library.
 *
 * E.g.:
 *
 * {
 * ...,
 *  '@spartacus/checkout': ['Checkout', 'Checkout-B2B', 'Checkout-Scheduled-Replenishment'],
 * ...
 * }
 */
exports.libraryFeatureMapping = (_a = generateMappings(), _a.libraryFeatureMapping), 
/**
 * Mapping of feature-modules to the Spartacus library.
 *
 * E.g.:
 *
 * {
 * ...,
 * 'Checkout': ['CheckoutModule'],
 * 'Checkout-B2B': ['CheckoutB2BModule'],
 * 'Checkout-Scheduled-Replenishment': ['CheckoutScheduledReplenishmentModule'],
 * ...
 * }
 */
exports.featureFeatureModuleMapping = _a.featureFeatureModuleMapping, 
/**
 * Mapping of root feature-modules to the Spartacus library.
 *
 * E.g.:
 *
 * {
 * ...,
 * 'Checkout': ['CheckoutRootModule'],
 * 'Checkout-B2B': ['CheckoutB2BRootModule'],
 * 'Checkout-Scheduled-Replenishment': ['CheckoutScheduledReplenishmentRootModule'],
 * ...
 * }
 */
exports.featureRootModuleMapping = _a.featureRootModuleMapping, 
/**
 * Mapping of schematics configurations to the Spartacus features.
 *
 * E.g.:
 *
 * {
 * ...,
 * 'Checkout': [CHECKOUT_BASE_SCHEMATICS_CONFIG],
 * 'Checkout-B2B': [CHECKOUT_B2B_SCHEMATICS_CONFIG],
 * ...
 * }
 */
exports.featureSchematicConfigMapping = _a.featureSchematicConfigMapping;
/**
 * Generates mappings.
 */
function generateMappings() {
    var featureMapping = new Map();
    var featureModuleMapping = new Map();
    var rootModuleMapping = new Map();
    var configMapping = new Map();
    for (var _i = 0, SCHEMATICS_CONFIGS_1 = exports.SCHEMATICS_CONFIGS; _i < SCHEMATICS_CONFIGS_1.length; _i++) {
        var featureConfig = SCHEMATICS_CONFIGS_1[_i];
        populateFeatureMapping(featureMapping, featureConfig);
        populateFeatureModuleMapping(featureModuleMapping, featureConfig);
        populateRootModulesMapping(rootModuleMapping, featureConfig);
        populateConfigMapping(configMapping, featureConfig);
    }
    return {
        libraryFeatureMapping: featureMapping,
        featureFeatureModuleMapping: featureModuleMapping,
        featureRootModuleMapping: rootModuleMapping,
        featureSchematicConfigMapping: configMapping,
    };
}
function populateFeatureMapping(mapping, featureConfig) {
    var _a;
    var feature = featureConfig.library.mainScope;
    var featureName = featureConfig.library.featureName;
    var existingMapping = (_a = mapping.get(feature)) !== null && _a !== void 0 ? _a : [];
    // avoid adding duplicates
    if (existingMapping.includes(featureName)) {
        return;
    }
    mapping.set(feature, __spreadArray(__spreadArray([], existingMapping, true), [featureName], false));
}
function populateFeatureModuleMapping(mapping, featureConfig) {
    var _a;
    var feature = featureConfig.library.featureName;
    var existingMapping = (_a = mapping.get(feature)) !== null && _a !== void 0 ? _a : [];
    var featureModules = []
        .concat(featureConfig.featureModule)
        .map(function (fm) { return fm.name; });
    // avoid adding duplicates
    if (existingMapping.some(function (existing) { return featureModules.includes(existing); })) {
        return;
    }
    mapping.set(feature, __spreadArray(__spreadArray([], existingMapping, true), featureModules, true));
}
function populateRootModulesMapping(mapping, featureConfig) {
    var _a, _b;
    var feature = featureConfig.library.featureName;
    var existingMapping = (_a = mapping.get(feature)) !== null && _a !== void 0 ? _a : [];
    var rooModules = []
        .concat((_b = featureConfig.rootModule) !== null && _b !== void 0 ? _b : [])
        .map(function (rm) { return rm.name; });
    // avoid adding duplicates
    if (existingMapping.some(function (existing) { return rooModules.includes(existing); })) {
        return;
    }
    mapping.set(feature, __spreadArray(__spreadArray([], existingMapping, true), rooModules, true));
}
function populateConfigMapping(mapping, featureConfig) {
    mapping.set(featureConfig.library.featureName, featureConfig);
}
/**
 * Based on the given value,
 * it returns the key of the given object.
 */
function getKeyByMappingValue(mapping, value) {
    try {
        return getKeyByMappingValueOrThrow(mapping, value);
    }
    catch (e) {
        if (e instanceof schematics_1.SchematicsException) {
            return undefined;
        }
    }
    return undefined;
}
/**
 * Based on the given value,
 * it returns the key of the given object.
 */
function getKeyByMappingValueOrThrow(mapping, value) {
    var _a;
    for (var _i = 0, _b = Array.from(mapping.keys()); _i < _b.length; _i++) {
        var key = _b[_i];
        if (((_a = mapping.get(key)) !== null && _a !== void 0 ? _a : []).includes(value)) {
            return key;
        }
    }
    throw new schematics_1.SchematicsException("Value ".concat(value, " not found in the given map."));
}
/**
 * Returns the schematics config
 * for the given feature.
 */
function getSchematicsConfigByFeatureOrThrow(feature) {
    var featureConfig = exports.featureSchematicConfigMapping.get(feature);
    if (!featureConfig) {
        throw new schematics_1.SchematicsException("Config not found for the given feature '".concat(feature, "'"));
    }
    return featureConfig;
}
//# sourceMappingURL=schematics-config-mappings.js.map