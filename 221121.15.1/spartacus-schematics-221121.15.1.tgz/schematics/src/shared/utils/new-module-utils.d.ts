import { Rule } from '@angular-devkit/schematics';
import { ArrayLiteralExpression, CallExpression, Expression, SourceFile } from 'ts-morph';
export type ModuleProperty = 'imports' | 'exports' | 'declarations' | 'providers';
export interface Import {
    moduleSpecifier: string;
    namedImports: string[];
}
export declare function ensureModuleExists(options: {
    /** module's name */
    name: string;
    /** path where to create the module */
    path: string;
    /** project name */
    project: string;
    /** the declaring module */
    module: string;
}): Rule;
/**
 * Adds the given Module (import, content) to the `imports` array
 * of the NgModule in the given source file.
 *
 * If `order` param is provided, the Module will be added at the specified array's index.
 *
 * Moreover, it adds the JS import of this Module in the source file.
 */
export declare function addModuleImport(sourceFile: SourceFile, insertOptions: {
    import: Import | Import[];
    content: string;
    order?: number;
}, createIfMissing?: boolean): Expression | undefined;
export declare function addModuleExport(sourceFile: SourceFile, insertOptions: {
    import: Import | Import[];
    content: string;
    order?: number;
}, createIfMissing?: boolean): Expression | undefined;
export declare function addModuleProvider(sourceFile: SourceFile, insertOptions: {
    import: Import | Import[];
    content: string;
    order?: number;
}, createIfMissing?: boolean): Expression | undefined;
/**
 * Removes the given Module (importPath, content) from the `imports` array
 * of the NgModule in the given source file.
 *
 * Moreover, it removes the JS import of this Module from the source file.
 */
export declare function removeModuleImport(sourceFile: SourceFile, removeOptions: {
    importPath: string;
    content: string;
}): Expression | undefined;
export declare function getModule(sourceFile: SourceFile): CallExpression | undefined;
export declare function getModulePropertyInitializer(source: SourceFile, propertyName: ModuleProperty, createIfMissing?: boolean): ArrayLiteralExpression | undefined;
