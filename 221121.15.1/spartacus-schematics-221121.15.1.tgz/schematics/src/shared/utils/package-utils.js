"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createSpartacusDependencies = createSpartacusDependencies;
exports.createDependencies = createDependencies;
exports.mapPackageToNodeDependencies = mapPackageToNodeDependencies;
exports.cleanSemverVersion = cleanSemverVersion;
exports.getMajorVersionNumber = getMajorVersionNumber;
exports.getSpartacusSchematicsVersion = getSpartacusSchematicsVersion;
exports.getPrefixedSpartacusSchematicsVersion = getPrefixedSpartacusSchematicsVersion;
exports.getSpartacusCurrentFeatureLevel = getSpartacusCurrentFeatureLevel;
exports.isUsingLegacyServerBuilder = isUsingLegacyServerBuilder;
exports.isSsrUsed = isSsrUsed;
exports.getServerTsPathForApplicationBuilder = getServerTsPathForApplicationBuilder;
exports.prepareSpartacusDependencies = prepareSpartacusDependencies;
exports.prepare3rdPartyDependencies = prepare3rdPartyDependencies;
exports.updatePackageJsonDependencies = updatePackageJsonDependencies;
exports.readPackageJson = readPackageJson;
var schematics_1 = require("@angular-devkit/schematics");
var dependencies_1 = require("@schematics/angular/utility/dependencies");
var path_1 = require("path");
var semver_1 = __importDefault(require("semver"));
var package_json_1 = require("../../../package.json");
var dependencies_json_1 = __importDefault(require("../../dependencies.json"));
var constants_1 = require("../constants");
var libs_constants_1 = require("../libs-constants");
var file_utils_1 = require("./file-utils");
var lib_utils_1 = require("./lib-utils");
var workspace_utils_1 = require("./workspace-utils");
var DEV_DEPENDENCIES_KEYWORDS = [
    'schematics',
    'parse5',
    'typescript',
    '@angular-devkit/core',
    '@angular/compiler',
    'jsonc-parser',
];
function createSpartacusDependencies(dependencyObject) {
    var spartacusVersion = getPrefixedSpartacusSchematicsVersion();
    return createDependencies(dependencyObject, {
        skipScopes: libs_constants_1.CORE_SPARTACUS_SCOPES,
        onlyIncludeScopes: libs_constants_1.FEATURES_LIBS_SKIP_SCOPES,
        version: spartacusVersion,
    });
}
function createDependencies(dependencyObject, options) {
    var _a;
    if (options === void 0) { options = {
        skipScopes: libs_constants_1.FEATURES_LIBS_SKIP_SCOPES,
    }; }
    var dependencies = [];
    var _loop_1 = function (dependencyName) {
        if (!dependencyObject.hasOwnProperty(dependencyName)) {
            return "continue";
        }
        if (options.skipScopes.some(function (scope) { return dependencyName.startsWith(scope); })) {
            return "continue";
        }
        if (
        // if `onlyIncludeScopes` is not defined, always include the dependency
        !options.onlyIncludeScopes ||
            // if defined, check if the current dependency is in the given array
            options.onlyIncludeScopes.some(function (scope) {
                return dependencyName.startsWith(scope);
            })) {
            dependencies.push(mapPackageToNodeDependencies(dependencyName, (_a = options.version) !== null && _a !== void 0 ? _a : dependencyObject[dependencyName], options.overwrite));
        }
    };
    for (var dependencyName in dependencyObject) {
        _loop_1(dependencyName);
    }
    return dependencies;
}
function mapPackageToNodeDependencies(packageName, pkgVersion, overwrite) {
    if (overwrite === void 0) { overwrite = false; }
    var type = DEV_DEPENDENCIES_KEYWORDS.some(function (keyword) {
        return packageName.includes(keyword);
    })
        ? dependencies_1.NodeDependencyType.Dev
        : dependencies_1.NodeDependencyType.Default;
    return {
        type: type,
        overwrite: overwrite,
        name: packageName,
        version: pkgVersion,
    };
}
function cleanSemverVersion(versionString) {
    if (isNaN(Number(versionString.charAt(0)))) {
        return versionString.substring(1, versionString.length);
    }
    return versionString;
}
function getMajorVersionNumber(versionString) {
    var cleanVersion = cleanSemverVersion(versionString);
    return Number(cleanVersion.charAt(0));
}
function getSpartacusSchematicsVersion() {
    return package_json_1.version;
}
function getPrefixedSpartacusSchematicsVersion() {
    return "~".concat(getSpartacusSchematicsVersion());
}
function getSpartacusCurrentFeatureLevel() {
    return package_json_1.version.split('.').slice(0, 2).join('.');
}
/**
 * Tells whether the app is using SSR with legacy configuration
 * (not using Application Builder, but the old Server Builder)
 */
function isUsingLegacyServerBuilder(tree) {
    var _a, _b;
    var projectName = (0, workspace_utils_1.getDefaultProjectNameFromWorkspace)(tree);
    var angularJson = (0, workspace_utils_1.getWorkspace)(tree).workspace;
    var isServerConfiguration = !!((_b = (_a = angularJson === null || angularJson === void 0 ? void 0 : angularJson.projects[projectName]) === null || _a === void 0 ? void 0 : _a.architect) === null || _b === void 0 ? void 0 : _b['server']);
    var serverFileLocation = (0, file_utils_1.getServerTsPath)(tree);
    if (!serverFileLocation) {
        return false;
    }
    var serverBuffer = tree.read(serverFileLocation);
    var serverFileBuffer = serverBuffer === null || serverBuffer === void 0 ? void 0 : serverBuffer.toString(constants_1.UTF_8);
    var isServerSideAvailable = serverFileBuffer && !!serverFileBuffer.length;
    return !!(isServerConfiguration && isServerSideAvailable);
}
/**
 * Checks if Server-Side Rendering (SSR) is configured and used with the new Angular application builder.
 *
 * @param tree - The file tree to check for SSR configuration
 * @returns true if SSR is configured and the server file exists, false otherwise
 */
function isSsrUsed(tree) {
    var _a, _b, _c;
    var projectName = (0, workspace_utils_1.getDefaultProjectNameFromWorkspace)(tree);
    var angularJson = (0, workspace_utils_1.getWorkspace)(tree).workspace;
    var architect = angularJson.projects[projectName]
        .architect;
    var builderType = (_a = architect === null || architect === void 0 ? void 0 : architect.build) === null || _a === void 0 ? void 0 : _a.builder;
    var buildOptions = (_b = architect === null || architect === void 0 ? void 0 : architect.build) === null || _b === void 0 ? void 0 : _b.options;
    if (typeof builderType !== 'string' ||
        ![
            // legacy builder used for Angular <19 projects
            '@angular-devkit/build-angular:application',
            // new builder applied in apps by Angular 21 migration schematics (and in fresh apps)
            '@angular/build:application',
        ].includes(builderType)) {
        return false;
    }
    // Check if SSR is configured in build options
    var hasSSRConfig = (buildOptions === null || buildOptions === void 0 ? void 0 : buildOptions.server) && ((_c = buildOptions === null || buildOptions === void 0 ? void 0 : buildOptions.ssr) === null || _c === void 0 ? void 0 : _c.entry);
    if (!hasSSRConfig) {
        return false;
    }
    var serverFileLocation = getServerTsPathForApplicationBuilder(tree);
    if (!serverFileLocation) {
        return false;
    }
    var serverBuffer = tree.read(serverFileLocation);
    var serverFileBuffer = serverBuffer === null || serverBuffer === void 0 ? void 0 : serverBuffer.toString(constants_1.UTF_8);
    return Boolean(serverFileBuffer === null || serverFileBuffer === void 0 ? void 0 : serverFileBuffer.length);
}
/**
 * Gets the path to the server.ts file for applications using the Angular application builder.
 * Looks up the configured server entry point in angular.json and verifies it exists.
 *
 * @param tree - The file tree to check for the server file
 * @returns The normalized path to the server.ts file if found, null otherwise
 */
function getServerTsPathForApplicationBuilder(tree) {
    var _a, _b;
    var projectName = (0, workspace_utils_1.getDefaultProjectNameFromWorkspace)(tree);
    var angularJson = (0, workspace_utils_1.getWorkspace)(tree).workspace;
    var architect = angularJson.projects[projectName]
        .architect;
    var buildOptions = (_a = architect === null || architect === void 0 ? void 0 : architect.build) === null || _a === void 0 ? void 0 : _a.options;
    // Get server file path from SSR configuration
    if ((_b = buildOptions === null || buildOptions === void 0 ? void 0 : buildOptions.ssr) === null || _b === void 0 ? void 0 : _b.entry) {
        var configuredPath = (0, path_1.normalize)(buildOptions.ssr.entry);
        if (tree.exists(configuredPath)) {
            return configuredPath;
        }
    }
    return null;
}
function prepareSpartacusDependencies() {
    var spartacusVersion = getPrefixedSpartacusSchematicsVersion();
    var spartacusDependencies = [
        {
            type: dependencies_1.NodeDependencyType.Default,
            version: spartacusVersion,
            name: libs_constants_1.SPARTACUS_CORE,
        },
        {
            type: dependencies_1.NodeDependencyType.Default,
            version: spartacusVersion,
            name: libs_constants_1.SPARTACUS_STOREFRONTLIB,
        },
        {
            type: dependencies_1.NodeDependencyType.Default,
            version: spartacusVersion,
            name: libs_constants_1.SPARTACUS_ASSETS,
        },
        {
            type: dependencies_1.NodeDependencyType.Default,
            version: spartacusVersion,
            name: libs_constants_1.SPARTACUS_STYLES,
        },
    ];
    return spartacusDependencies;
}
function prepare3rdPartyDependencies() {
    var thirdPartyDependencies = createDependencies(__assign(__assign(__assign(__assign(__assign({}, dependencies_json_1.default[libs_constants_1.SPARTACUS_CORE]), dependencies_json_1.default[libs_constants_1.SPARTACUS_STOREFRONTLIB]), dependencies_json_1.default[libs_constants_1.SPARTACUS_STYLES]), dependencies_json_1.default[libs_constants_1.SPARTACUS_ASSETS]), dependencies_json_1.default[libs_constants_1.SPARTACUS_SCHEMATICS]));
    return thirdPartyDependencies;
}
function updatePackageJsonDependencies(dependencies, packageJson) {
    return function (tree, context) {
        var dependenciesToAdd = [];
        for (var _i = 0, dependencies_2 = dependencies; _i < dependencies_2.length; _i++) {
            var dependency = dependencies_2[_i];
            var currentVersion = getCurrentDependencyVersion(dependency, packageJson);
            if (!currentVersion) {
                dependenciesToAdd.push(dependency);
                continue;
            }
            if (semver_1.default.satisfies(currentVersion, dependency.version)) {
                continue;
            }
            var versionToUpdate = semver_1.default.parse(cleanSemverVersion(dependency.version));
            if (!versionToUpdate || semver_1.default.eq(versionToUpdate, currentVersion)) {
                continue;
            }
            (0, dependencies_1.addPackageJsonDependency)(tree, __assign(__assign({}, dependency), { overwrite: true }));
            var change = semver_1.default.gt(versionToUpdate, currentVersion)
                ? 'Upgrading'
                : 'Downgrading';
            context.logger.info("\uD83E\uDE79 ".concat(change, " '").concat(dependency.name, "' to ").concat(dependency.version, " (was ").concat(currentVersion.raw, ")"));
        }
        return (0, lib_utils_1.addPackageJsonDependencies)(dependenciesToAdd, packageJson);
    };
}
function getCurrentDependencyVersion(dependency, packageJson) {
    if (!(0, lib_utils_1.dependencyExists)(dependency, packageJson)) {
        return null;
    }
    var dependencies = packageJson[dependency.type];
    var currentVersion = dependencies[dependency.name];
    return semver_1.default.parse(cleanSemverVersion(currentVersion));
}
/**
 * Reads and parses the package.json file from the root of the project.
 *
 * @param tree - The virtual file tree provided by the Angular schematics
 * @returns The parsed package.json content as an object
 * @throws SchematicsException if package.json cannot be found or parsed
 */
function readPackageJson(tree) {
    var pkgPath = '/package.json';
    var buffer = tree.read(pkgPath);
    if (!buffer) {
        throw new schematics_1.SchematicsException('Could not find package.json');
    }
    return JSON.parse(buffer.toString(constants_1.UTF_8));
}
//# sourceMappingURL=package-utils.js.map