import { Tree } from '@angular-devkit/schematics';
import { InsertChange } from '@schematics/angular/utility/change';
import ts from 'typescript';
export declare function stripTsFromImport(importPath: string): string;
export declare function addToModuleImports(host: Tree, modulePath: string, importText: string, moduleSource?: ts.SourceFile): InsertChange[];
export declare function addToModuleExports(host: Tree, modulePath: string, exportsText: string, moduleSource?: ts.SourceFile): InsertChange[];
export declare function addToModuleProviders(host: Tree, modulePath: string, importText: string, moduleSource?: ts.SourceFile): InsertChange[];
export declare function addToMetadata(host: Tree, modulePath: string, text: string, metadataType: 'imports' | 'declarations' | 'exports' | 'providers', moduleSource?: ts.SourceFile): InsertChange[];
/**
 * Build a relative path from one file path to another file path.
 */
export declare function buildRelativePath(from: string, to: string): string;
export declare function getTemplateInfo(source: ts.SourceFile): {
    templateUrl?: string;
    inlineTemplateContent?: string;
    inlineTemplateStart?: number;
} | undefined;
