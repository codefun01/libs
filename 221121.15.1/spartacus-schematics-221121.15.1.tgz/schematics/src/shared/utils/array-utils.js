"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mergeArraysWithoutDuplicates = mergeArraysWithoutDuplicates;
/**
 * Returns a new array with all unique items from the two arrays.
 *
 * The order of the items is not guaranteed.
 */
function mergeArraysWithoutDuplicates(array1, array2) {
    return Array.from(new Set(__spreadArray(__spreadArray([], (array1 !== null && array1 !== void 0 ? array1 : []), true), (array2 !== null && array2 !== void 0 ? array2 : []), true)));
}
//# sourceMappingURL=array-utils.js.map