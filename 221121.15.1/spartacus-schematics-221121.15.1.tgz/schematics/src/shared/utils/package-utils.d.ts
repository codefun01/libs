import { Rule, Tree } from '@angular-devkit/schematics';
import { NodeDependency } from '@schematics/angular/utility/dependencies';
export declare function createSpartacusDependencies(dependencyObject: Record<string, string>): NodeDependency[];
export declare function createDependencies(dependencyObject: Record<string, string>, options?: {
    /**
     * skip the scopes that start with any of the given scopes
     */
    skipScopes: string[];
    /**
     * create and return dependencies only listed in the given array
     */
    onlyIncludeScopes?: string[];
    /** dependency version which to set. If not provided, the one from the given `dependencyObject` will be used. */
    version?: string;
    /** Overwrite the dependencies */
    overwrite?: boolean;
}): NodeDependency[];
export declare function mapPackageToNodeDependencies(packageName: string, pkgVersion: string, overwrite?: boolean): NodeDependency;
export declare function cleanSemverVersion(versionString: string): string;
export declare function getMajorVersionNumber(versionString: string): number;
export declare function getSpartacusSchematicsVersion(): string;
export declare function getPrefixedSpartacusSchematicsVersion(): string;
export declare function getSpartacusCurrentFeatureLevel(): string;
/**
 * Tells whether the app is using SSR with legacy configuration
 * (not using Application Builder, but the old Server Builder)
 */
export declare function isUsingLegacyServerBuilder(tree: Tree): boolean;
/**
 * Checks if Server-Side Rendering (SSR) is configured and used with the new Angular application builder.
 *
 * @param tree - The file tree to check for SSR configuration
 * @returns true if SSR is configured and the server file exists, false otherwise
 */
export declare function isSsrUsed(tree: Tree): boolean;
/**
 * Gets the path to the server.ts file for applications using the Angular application builder.
 * Looks up the configured server entry point in angular.json and verifies it exists.
 *
 * @param tree - The file tree to check for the server file
 * @returns The normalized path to the server.ts file if found, null otherwise
 */
export declare function getServerTsPathForApplicationBuilder(tree: Tree): string | null;
export declare function prepareSpartacusDependencies(): NodeDependency[];
export declare function prepare3rdPartyDependencies(): NodeDependency[];
export declare function updatePackageJsonDependencies(dependencies: NodeDependency[], packageJson: any): Rule;
/**
 * Reads and parses the package.json file from the root of the project.
 *
 * @param tree - The virtual file tree provided by the Angular schematics
 * @returns The parsed package.json content as an object
 * @throws SchematicsException if package.json cannot be found or parsed
 */
export declare function readPackageJson(tree: Tree): any;
