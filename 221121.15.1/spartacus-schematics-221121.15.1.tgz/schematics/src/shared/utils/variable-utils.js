"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.replaceVariableDeclaration = replaceVariableDeclaration;
exports.removeVariableDeclaration = removeVariableDeclaration;
var ast_utils_1 = require("@schematics/angular/utility/ast-utils");
var file_utils_1 = require("./file-utils");
var typescript_1 = __importDefault(require("typescript"));
/**
 * Replaces a variable declaration in the given file content.
 *
 * Returns the updated file content.
 */
function replaceVariableDeclaration(_a) {
    var fileContent = _a.fileContent, variableName = _a.variableName, newText = _a.newText, _b = _a.throwErrorIfNotFound, throwErrorIfNotFound = _b === void 0 ? false : _b;
    var sourceFile = (0, file_utils_1.parseTsFileContent)(fileContent);
    // Get all variables
    var nodes = (0, ast_utils_1.findNodes)(sourceFile, typescript_1.default.SyntaxKind.VariableDeclaration);
    // Find variable by name
    var targetNode = nodes.find(function (node) {
        if (!typescript_1.default.isVariableDeclaration(node)) {
            return false;
        }
        var name = node.name;
        return typescript_1.default.isIdentifier(name) && name.text === variableName;
    });
    if (!targetNode) {
        if (throwErrorIfNotFound) {
            throw new Error("Could not replace ".concat(variableName, " variable"));
        }
        return fileContent;
    }
    // Get the parent VariableStatement - to include the `const` keyword
    var statement = targetNode.parent.parent;
    var start = statement.getStart();
    var end = statement.getEnd();
    // Replace the whole statement
    return fileContent.slice(0, start) + newText + fileContent.slice(end);
}
/**
 * Removes a variable declaration in the given file content.
 *
 * Returns the updated file content.
 */
function removeVariableDeclaration(_a) {
    var fileContent = _a.fileContent, variableName = _a.variableName;
    return replaceVariableDeclaration({
        fileContent: fileContent,
        variableName: variableName,
        newText: '',
    });
}
//# sourceMappingURL=variable-utils.js.map