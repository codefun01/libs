import ts from 'typescript';
interface ReplaceMethodCallArgumentParams {
    fileContent: string;
    objectName: string;
    methodName: string;
    argument: {
        position: number;
        oldText: string;
        newText: string;
    };
    throwErrorIfNotFound?: boolean;
}
interface FindMethodCallsParams {
    fileContent: string;
    objectName: string;
    methodName: string;
}
/**
 * Finds all method calls in the given file content.
 *
 * Returns the method calls.
 */
export declare function findMethodCalls({ fileContent, objectName, methodName, }: FindMethodCallsParams): ts.CallExpression[];
/**
 * Replaces an argument in a method call in the given file content.
 * Works for multiple occurrences of the method call.
 *
 * It matches the call by the object name, method name, position of the argument,
 * and the argument text.
 *
 * Returns the updated file content.
 */
export declare function replaceMethodCallArgument({ fileContent, objectName, methodName, argument, throwErrorIfNotFound, }: ReplaceMethodCallArgumentParams): string;
export {};
