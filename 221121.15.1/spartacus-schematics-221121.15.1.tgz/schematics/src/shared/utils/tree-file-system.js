"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TreeFileSystem = void 0;
var core_1 = require("@angular-devkit/core");
var path = __importStar(require("path"));
var ts_morph_1 = require("ts-morph");
var TreeFileSystem = /** @class */ (function () {
    function TreeFileSystem(tree, rootDir) {
        this.tree = tree;
        this.rootDir = rootDir;
    }
    TreeFileSystem.prototype.resolvePath = function (filePath) {
        return (0, core_1.normalize)((0, core_1.resolve)((0, core_1.normalize)(this.rootDir), (0, core_1.normalize)(filePath)));
    };
    TreeFileSystem.prototype.isCaseSensitive = function () {
        return ts_morph_1.ts.sys.useCaseSensitiveFileNames;
    };
    TreeFileSystem.prototype.delete = function (filePath) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.deleteSync(filePath)];
            });
        });
    };
    TreeFileSystem.prototype.deleteSync = function (filePath) {
        return this.tree.delete(filePath);
    };
    TreeFileSystem.prototype.readDirSync = function (dirPath) {
        var entries = [];
        var dir = this.tree.getDir(dirPath);
        dir.subfiles.forEach(function (file) {
            entries.push({
                isDirectory: false,
                isSymlink: false,
                name: path.join(dirPath, file.toString()),
                isFile: true,
            });
        });
        dir.subdirs.forEach(function (subDir) {
            entries.push({
                isDirectory: true,
                isSymlink: false,
                name: path.join(dirPath, subDir.toString()),
                isFile: false,
            });
        });
        return entries;
    };
    TreeFileSystem.prototype.readFile = function (filePath, encoding) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.readFileSync(filePath, encoding)];
            });
        });
    };
    TreeFileSystem.prototype.readFileSync = function (filePath, encoding) {
        var _a;
        var result = (_a = this.tree
            .get(this.resolvePath(filePath))) === null || _a === void 0 ? void 0 : _a.content.toString(encoding);
        if (result) {
            return result;
        }
        return '';
    };
    TreeFileSystem.prototype.writeFile = function (filePath, fileText) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.writeFileSync(filePath, fileText)];
            });
        });
    };
    TreeFileSystem.prototype.writeFileSync = function (filePath, fileText) {
        if (this.fileExistsSync(filePath)) {
            var currentContent = this.readFileSync(filePath);
            // prevent the unnecessary Angular logs about the files being updated
            if (currentContent === fileText) {
                return;
            }
        }
        return this.tree.overwrite(filePath, fileText);
    };
    TreeFileSystem.prototype.mkdir = function (dirPath) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.mkdirSync(dirPath)];
            });
        });
    };
    TreeFileSystem.prototype.mkdirSync = function (dirPath) {
        if (this.tree.exists("".concat(dirPath, "/.gitkeep"))) {
            return;
        }
        return;
    };
    TreeFileSystem.prototype.move = function (srcPath, destPath) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.moveSync(srcPath, destPath)];
            });
        });
    };
    TreeFileSystem.prototype.moveSync = function (srcPath, destPath) {
        return this.tree.rename(srcPath, destPath);
    };
    TreeFileSystem.prototype.copy = function (srcPath, destPath) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.copySync(srcPath, destPath)];
            });
        });
    };
    TreeFileSystem.prototype.copySync = function (_srcPath, _destPath) {
        throw new Error('Method `copySync` not implemented in TreeFileSystem.');
    };
    TreeFileSystem.prototype.fileExists = function (filePath) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.fileExistsSync(filePath)];
            });
        });
    };
    TreeFileSystem.prototype.fileExistsSync = function (filePath) {
        return this.tree.exists(filePath);
    };
    TreeFileSystem.prototype.directoryExists = function (dirPath) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, this.directoryExistsSync(dirPath)];
            });
        });
    };
    TreeFileSystem.prototype.directoryExistsSync = function (dirPath) {
        return this.tree.exists(dirPath);
    };
    TreeFileSystem.prototype.realpathSync = function (filePath) {
        var result = (0, core_1.normalize)((0, core_1.resolve)((0, core_1.normalize)(this.rootDir), (0, core_1.normalize)(filePath)));
        return result;
    };
    TreeFileSystem.prototype.getCurrentDirectory = function () {
        return this.tree.root.path.toString();
    };
    TreeFileSystem.prototype.glob = function (_patterns) {
        throw new Error('Method `glob` not implemented in TreeFileSystem.');
    };
    TreeFileSystem.prototype.globSync = function (_patterns) {
        throw new Error('Method `globSync` not implemented in TreeFileSystem.');
    };
    return TreeFileSystem;
}());
exports.TreeFileSystem = TreeFileSystem;
//# sourceMappingURL=tree-file-system.js.map