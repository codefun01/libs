"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSpartacusProviders = getSpartacusProviders;
exports.isSpartacusConfigDuplicate = isSpartacusConfigDuplicate;
exports.normalizeObject = normalizeObject;
exports.removeProperty = removeProperty;
exports.getB2bConfiguration = getB2bConfiguration;
var ts_morph_1 = require("ts-morph");
var constants_1 = require("../constants");
var libs_constants_1 = require("../libs-constants");
var import_utils_1 = require("./import-utils");
var new_module_utils_1 = require("./new-module-utils");
function getSpartacusProviders(sourceFile, createIfMissing) {
    if (createIfMissing === void 0) { createIfMissing = true; }
    var moduleNode = (0, new_module_utils_1.getModule)(sourceFile);
    if (!moduleNode) {
        return [];
    }
    var initializer = (0, new_module_utils_1.getModulePropertyInitializer)(sourceFile, 'providers', createIfMissing);
    var providers = [];
    initializer === null || initializer === void 0 ? void 0 : initializer.getElements().forEach(function (element) {
        if (ts_morph_1.Node.isCallExpression(element) || ts_morph_1.Node.isSpreadElement(element)) {
            var expression = element.getExpression();
            if (ts_morph_1.Node.isIdentifier(expression) &&
                (0, import_utils_1.isImportedFromSpartacusLibs)(expression)) {
                providers.push(element);
            }
        }
    });
    return providers;
}
function isSpartacusConfigDuplicate(newContent, initializer) {
    var normalizedContent = normalizeConfiguration(newContent);
    var configs = getSpartacusProviders(initializer.getSourceFile());
    for (var _i = 0, configs_1 = configs; _i < configs_1.length; _i++) {
        var config = configs_1[_i];
        var normalizedConfig = normalizeConfiguration(config);
        if (normalizedContent === normalizedConfig) {
            return true;
        }
    }
    return false;
}
var EMPTY_SPACE_REG_EXP = /\s+/gm;
var COMMA_REG_EXP = /,+/gm;
function normalizeConfiguration(config) {
    var newConfig = typeof config === 'string' ? config : config.getText();
    newConfig = newConfig.trim();
    newConfig = newConfig.replace(COMMA_REG_EXP, '');
    if (newConfig.startsWith(constants_1.PROVIDE_CONFIG_FUNCTION)) {
        newConfig = newConfig.replace("".concat(constants_1.PROVIDE_CONFIG_FUNCTION, "("), '');
        newConfig = newConfig.substring(0, newConfig.length - 1);
    }
    newConfig = newConfig.replace(EMPTY_SPACE_REG_EXP, '');
    return newConfig;
}
function normalizeObject(obj) {
    return obj.replace(EMPTY_SPACE_REG_EXP, '');
}
/**
 * Removes the config for the given property name.
 * If the object is empty after removal, the object
 * itself is removed.
 */
function removeProperty(objectLiteral, propertyName) {
    var _a, _b;
    var properties = objectLiteral.getProperties();
    for (var _i = 0, properties_1 = properties; _i < properties_1.length; _i++) {
        var property = properties_1[_i];
        if (!ts_morph_1.Node.isPropertyAssignment(property)) {
            continue;
        }
        if (property.getName() === propertyName) {
            property.remove();
            return;
        }
        var nestedConfigObject = property.getFirstDescendantByKind(ts_morph_1.SyntaxKind.ObjectLiteralExpression);
        if (nestedConfigObject) {
            removeProperty(nestedConfigObject, propertyName);
        }
        if (normalizeObject((_b = (_a = property.getInitializer()) === null || _a === void 0 ? void 0 : _a.getText()) !== null && _b !== void 0 ? _b : '') === '{}') {
            property.remove();
        }
    }
}
function getB2bConfiguration() {
    return [
        {
            import: [
                {
                    moduleSpecifier: libs_constants_1.SPARTACUS_CORE,
                    namedImports: [constants_1.PROVIDE_CONFIG_FUNCTION],
                },
                {
                    moduleSpecifier: libs_constants_1.SPARTACUS_SETUP,
                    namedImports: ['defaultB2bOccConfig'],
                },
            ],
            content: "provideConfig(defaultB2bOccConfig)",
        },
    ];
}
//# sourceMappingURL=config-utils.js.map