"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.epdFeatureModulePath = exports.digitalPaymentsFeatureModulePath = exports.cdsFeatureModulePath = exports.cdpFeatureModulePath = exports.cdcFeatureModulePath = exports.userProfileWrapperModulePath = exports.userAccountWrapperModulePath = exports.userFeatureModulePath = exports.omfFeatureModulePath = exports.trackingTagManagementFeatureModulePath = exports.trackingPersonalizationFeatureModulePath = exports.storeFinderFeatureModulePath = exports.smartEditFeatureModulePath = exports.requestedDeliveryDateFeatureModulePath = exports.qualtricsFeatureModulePath = exports.productConfiguratorRulebasedWrapperModulePath = exports.productConfiguratorFeatureModulePath = exports.productFutureStockFeatureModulePath = exports.productMultiDimensionalListFeatureModulePath = exports.productMultiDimensionalSelectorFeatureModulePath = exports.productVariantsFeatureModulePath = exports.productImageZoomFeatureModulePath = exports.productBulkPricingFeatureModulePath = exports.pdfInvoicesFeatureModulePath = exports.organizationAccountSummaryFeatureModulePath = exports.organizationUnitOrderFeatureModulePath = exports.organizationUserRegistrationWrapperModulePath = exports.organizationUserRegistrationFeatureModulePath = exports.organizationOrderApprovalFeatureModulePath = exports.organizationAdministrationWrapperModulePath = exports.pickupInStoreFeatureModulePath = exports.organizationAdministrationFeatureModulePath = exports.orderWrapperModulePath = exports.orderFeatureModulePath = exports.quoteFeatureModulePath = exports.checkoutWrapperModulePath = exports.checkoutFeatureModulePath = exports.savedCartFeatureModulePath = exports.wishListFeatureModulePath = exports.quickOrderFeatureModulePath = exports.importExportFeatureModulePath = exports.estimatedDeliveryDateFeatureModulePath = exports.cpqQuoteFeatureModulePath = exports.customerTicketingWrapperModulePath = exports.customerTicketingFeatureModulePath = exports.cartBaseWrapperModulePath = exports.cartBaseFeatureModulePath = exports.asmFeatureModulePath = exports.spartacusFeaturesModulePath = exports.appModulePath = void 0;
exports.punchoutFeatureModulePath = exports.subscriptionBillingFeatureModulePath = exports.s4ServiceFeatureModulePath = exports.oppsFeatureModulePath = exports.segmentRefsFeatureModulePath = exports.opfFeatureModulePath = void 0;
exports.writeFile = writeFile;
exports.runMigration = runMigration;
exports.getConstructor = getConstructor;
exports.getSuperNode = getSuperNode;
exports.getParams = getParams;
var core_1 = require("@angular-devkit/core");
var ast_utils_1 = require("@schematics/angular/utility/ast-utils");
var typescript_1 = __importDefault(require("typescript"));
var file_utils_1 = require("./file-utils");
exports.appModulePath = 'src/app/app.module.ts';
exports.spartacusFeaturesModulePath = 'src/app/spartacus/spartacus-features.module.ts';
exports.asmFeatureModulePath = 'src/app/spartacus/features/asm/asm-feature.module.ts';
exports.cartBaseFeatureModulePath = 'src/app/spartacus/features/cart/cart-base-feature.module.ts';
exports.cartBaseWrapperModulePath = 'src/app/spartacus/features/cart/cart-base-wrapper.module.ts';
exports.customerTicketingFeatureModulePath = 'src/app/spartacus/features/customer-ticketing/customer-ticketing-feature.module.ts';
exports.customerTicketingWrapperModulePath = 'src/app/spartacus/features/customer-ticketing/customer-ticketing-wrapper.module.ts';
exports.cpqQuoteFeatureModulePath = 'src/app/spartacus/features/cpq-quote/cpq-quote-feature.module.ts';
exports.estimatedDeliveryDateFeatureModulePath = 'src/app/spartacus/features/estimated-delivery-date/estimated-delivery-date-feature.module.ts';
exports.importExportFeatureModulePath = 'src/app/spartacus/features/cart/cart-import-export-feature.module.ts';
exports.quickOrderFeatureModulePath = 'src/app/spartacus/features/cart/cart-quick-order-feature.module.ts';
exports.wishListFeatureModulePath = 'src/app/spartacus/features/cart/wish-list-feature.module.ts';
exports.savedCartFeatureModulePath = 'src/app/spartacus/features/cart/cart-saved-cart-feature.module.ts';
exports.checkoutFeatureModulePath = 'src/app/spartacus/features/checkout/checkout-feature.module.ts';
exports.checkoutWrapperModulePath = 'src/app/spartacus/features/checkout/checkout-wrapper.module.ts';
exports.quoteFeatureModulePath = 'src/app/spartacus/features/quote/quote-feature.module.ts';
exports.orderFeatureModulePath = 'src/app/spartacus/features/order/order-feature.module.ts';
exports.orderWrapperModulePath = 'src/app/spartacus/features/order/order-wrapper.module.ts';
exports.organizationAdministrationFeatureModulePath = 'src/app/spartacus/features/organization/organization-administration-feature.module.ts';
exports.pickupInStoreFeatureModulePath = 'src/app/spartacus/features/pickup-in-store/pickup-in-store-feature.module.ts';
exports.organizationAdministrationWrapperModulePath = 'src/app/spartacus/features/organization/administration-wrapper.module.ts';
exports.organizationOrderApprovalFeatureModulePath = 'src/app/spartacus/features/organization/organization-order-approval-feature.module.ts';
exports.organizationUserRegistrationFeatureModulePath = 'src/app/spartacus/features/organization/organization-user-registration-feature.module.ts';
exports.organizationUserRegistrationWrapperModulePath = 'src/app/spartacus/features/organization/organization-user-registration-wrapper.module.ts';
exports.organizationUnitOrderFeatureModulePath = 'src/app/spartacus/features/organization/organization-unit-order-feature.module.ts';
exports.organizationAccountSummaryFeatureModulePath = 'src/app/spartacus/features/organization/organization-account-summary-feature.module.ts';
exports.pdfInvoicesFeatureModulePath = 'src/app/spartacus/features/pdf-invoices/pdf-invoices-feature.module.ts';
exports.productBulkPricingFeatureModulePath = 'src/app/spartacus/features/product/product-bulk-pricing-feature.module.ts';
exports.productImageZoomFeatureModulePath = 'src/app/spartacus/features/product/product-image-zoom-feature.module.ts';
exports.productVariantsFeatureModulePath = 'src/app/spartacus/features/product/product-variants-feature.module.ts';
exports.productMultiDimensionalSelectorFeatureModulePath = 'src/app/spartacus/features/product-multi-dimensional/product-multi-dimensional-selector-feature.module.ts';
exports.productMultiDimensionalListFeatureModulePath = 'src/app/spartacus/features/product-multi-dimensional/product-multi-dimensional-list-feature.module.ts';
exports.productFutureStockFeatureModulePath = 'src/app/spartacus/features/product/product-future-stock-feature.module.ts';
exports.productConfiguratorFeatureModulePath = 'src/app/spartacus/features/product-configurator/product-configurator-feature.module.ts';
exports.productConfiguratorRulebasedWrapperModulePath = 'src/app/spartacus/features/product-configurator/rulebased-configurator-wrapper.module.ts';
exports.qualtricsFeatureModulePath = 'src/app/spartacus/features/qualtrics/qualtrics-feature.module.ts';
exports.requestedDeliveryDateFeatureModulePath = 'src/app/spartacus/features/requested-delivery-date/requested-delivery-date-feature.module.ts';
exports.smartEditFeatureModulePath = 'src/app/spartacus/features/smartedit/smart-edit-feature.module.ts';
exports.storeFinderFeatureModulePath = 'src/app/spartacus/features/storefinder/store-finder-feature.module.ts';
exports.trackingPersonalizationFeatureModulePath = 'src/app/spartacus/features/tracking/personalization-feature.module.ts';
exports.trackingTagManagementFeatureModulePath = 'src/app/spartacus/features/tracking/tag-management-feature.module.ts';
exports.omfFeatureModulePath = 'src/app/spartacus/features/omf/omf-feature.module.ts';
exports.userFeatureModulePath = 'src/app/spartacus/features/user/user-feature.module.ts';
exports.userAccountWrapperModulePath = 'src/app/spartacus/features/user/user-account-wrapper.module.ts';
exports.userProfileWrapperModulePath = 'src/app/spartacus/features/user/user-profile-wrapper.module.ts';
exports.cdcFeatureModulePath = 'src/app/spartacus/features/cdc/cdc-feature.module.ts';
exports.cdpFeatureModulePath = 'src/app/spartacus/features/cdp/cdp-feature.module.ts';
exports.cdsFeatureModulePath = 'src/app/spartacus/features/cds/cds-feature.module.ts';
exports.digitalPaymentsFeatureModulePath = 'src/app/spartacus/features/digital-payments/digital-payments-feature.module.ts';
exports.epdFeatureModulePath = 'src/app/spartacus/features/epd-visualization/epd-visualization-feature.module.ts';
exports.opfFeatureModulePath = 'src/app/spartacus/features/opf/opf-feature.module.ts';
exports.segmentRefsFeatureModulePath = 'src/app/spartacus/features/segment-refs/segment-refs-feature.module.ts';
exports.oppsFeatureModulePath = 'src/app/spartacus/features/opps/opps-feature.module.ts';
exports.s4ServiceFeatureModulePath = 'src/app/spartacus/features/s4-service/s4-service-feature.module.ts';
exports.subscriptionBillingFeatureModulePath = 'src/app/spartacus/features/subscription-billing/subscription-billing-feature.module.ts';
exports.punchoutFeatureModulePath = 'src/app/spartacus/features/punchout/punchout-feature.module.ts';
function writeFile(host, filePath, contents) {
    host.sync.write((0, core_1.normalize)(filePath), core_1.virtualFs.stringToFileBuffer(contents));
}
function runMigration(appTree, schematicRunner, migrationScript, options) {
    if (options === void 0) { options = {}; }
    return schematicRunner.runSchematic(migrationScript, options, appTree);
}
function getConstructor(nodes) {
    var constructorNode = (0, file_utils_1.findConstructor)(nodes);
    if (!constructorNode) {
        throw new Error('No constructor node found');
    }
    return constructorNode;
}
function getSuperNode(constructorNode) {
    var superNodes = (0, ast_utils_1.findNodes)(constructorNode, typescript_1.default.SyntaxKind.SuperKeyword);
    if (!superNodes || superNodes.length === 0) {
        return undefined;
    }
    return superNodes[0];
}
function getParams(constructorNode, camelizedParamNames) {
    var superNode = getSuperNode(constructorNode);
    if (!superNode) {
        throw new Error('No super() node found');
    }
    var callExpressions = (0, ast_utils_1.findNodes)(constructorNode, typescript_1.default.SyntaxKind.CallExpression);
    if (!callExpressions || callExpressions.length === 0) {
        throw new Error('No call expressions found in constructor');
    }
    var params = (0, ast_utils_1.findNodes)(callExpressions[0], typescript_1.default.SyntaxKind.Identifier);
    camelizedParamNames = camelizedParamNames.map(function (param) {
        return core_1.strings.camelize(param);
    });
    return params
        .filter(function (n) { return n.kind === typescript_1.default.SyntaxKind.Identifier; })
        .map(function (n) { return n.getText(); })
        .filter(function (text) { return camelizedParamNames.includes(text); });
}
//# sourceMappingURL=test-utils.js.map