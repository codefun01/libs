import { SchematicTestRunner, UnitTestTree } from '@angular-devkit/schematics/testing';
export declare function generateDefaultWorkspace(schematicRunner: SchematicTestRunner, appTree: UnitTestTree): Promise<UnitTestTree>;
