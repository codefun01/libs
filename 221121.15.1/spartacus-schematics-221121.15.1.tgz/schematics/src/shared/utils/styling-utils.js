"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getStylesConfigFilePath = getStylesConfigFilePath;
exports.getRelativeStyleConfigImportPath = getRelativeStyleConfigImportPath;
var path = __importStar(require("path"));
function getStylesConfigFilePath(sourceRoot) {
    var styleConfigFilePath = path.join(sourceRoot, 'styles-config.scss');
    return styleConfigFilePath;
}
function getRelativeStyleConfigImportPath(project, destFilePath) {
    var styleConfigFilePath = getStylesConfigFilePath(project.sourceRoot);
    var styleConfigFileRelativePath = path.relative(path.parse(destFilePath).dir, styleConfigFilePath);
    var styleConfigRelativeImportPath = path.join(path.parse(styleConfigFileRelativePath).dir, path.parse(styleConfigFileRelativePath).name);
    return styleConfigRelativeImportPath;
}
//# sourceMappingURL=styling-utils.js.map