"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.findMethodCalls = findMethodCalls;
exports.replaceMethodCallArgument = replaceMethodCallArgument;
var ast_utils_1 = require("@schematics/angular/utility/ast-utils");
var typescript_1 = __importDefault(require("typescript"));
var file_utils_1 = require("./file-utils");
/**
 * Finds all method calls in the given file content.
 *
 * Returns the method calls.
 */
function findMethodCalls(_a) {
    var fileContent = _a.fileContent, objectName = _a.objectName, methodName = _a.methodName;
    var sourceFile = (0, file_utils_1.parseTsFileContent)(fileContent);
    // Get all method calls
    var nodes = (0, ast_utils_1.findNodes)(sourceFile, typescript_1.default.SyntaxKind.CallExpression, undefined, true);
    return nodes.filter(function (node) {
        if (!typescript_1.default.isCallExpression(node)) {
            return false;
        }
        var expression = node.expression;
        if (!typescript_1.default.isPropertyAccessExpression(expression)) {
            return false;
        }
        var object = expression.expression;
        var method = expression.name;
        if (!typescript_1.default.isIdentifier(object) || !typescript_1.default.isIdentifier(method)) {
            return false;
        }
        return object.text === objectName && method.text === methodName;
    });
}
/**
 * Replaces an argument in a method call in the given file content.
 * Works for multiple occurrences of the method call.
 *
 * It matches the call by the object name, method name, position of the argument,
 * and the argument text.
 *
 * Returns the updated file content.
 */
function replaceMethodCallArgument(_a) {
    var fileContent = _a.fileContent, objectName = _a.objectName, methodName = _a.methodName, argument = _a.argument, _b = _a.throwErrorIfNotFound, throwErrorIfNotFound = _b === void 0 ? false : _b;
    var targetNodes = findMethodCalls({
        fileContent: fileContent,
        objectName: objectName,
        methodName: methodName,
    }).filter(function (node) {
        // filter out method calls with less arguments than the expected argument position
        if (node.arguments.length <= argument.position) {
            return false;
        }
        // filter out method calls with the wrong argument text
        if (node.arguments[argument.position].getText() !== argument.oldText) {
            return false;
        }
        return true;
    });
    if (!targetNodes.length) {
        if (throwErrorIfNotFound) {
            throw new Error("Could not replace ".concat(objectName, ".").concat(methodName, "() method call argument on position ").concat(argument.position));
        }
        return fileContent;
    }
    // Replace all occurrences of the method call
    var updatedContent = fileContent;
    // Replace occurrences from last to first - to not interfere with
    // the already calculated start and end positions of the other occurrences
    var targetNodesReversed = __spreadArray([], targetNodes, true).reverse();
    targetNodesReversed.forEach(function (methodCallNode) {
        var argumentToReplace = methodCallNode.arguments[argument.position];
        updatedContent =
            updatedContent.slice(0, argumentToReplace.getStart()) +
                argument.newText +
                updatedContent.slice(argumentToReplace.getEnd());
    });
    return updatedContent;
}
//# sourceMappingURL=method-call-utils.js.map