"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseCSV = parseCSV;
function parseCSV(raw, defaultValues) {
    if (defaultValues === void 0) { defaultValues = []; }
    if (!raw) {
        return defaultValues.map(function (x) { return "'".concat(x, "'"); }).join(', ');
    }
    return raw
        .split(',')
        .map(function (x) { return "'".concat(x, "'"); })
        .join(', ');
}
//# sourceMappingURL=transform-utils.js.map