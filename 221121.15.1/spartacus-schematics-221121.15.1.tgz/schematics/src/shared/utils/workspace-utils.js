"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSourceRoot = getSourceRoot;
exports.getWorkspace = getWorkspace;
exports.getAngularJsonFile = getAngularJsonFile;
exports.getProjectFromWorkspace = getProjectFromWorkspace;
exports.getDefaultProjectNameFromWorkspace = getDefaultProjectNameFromWorkspace;
exports.getProjectTargets = getProjectTargets;
exports.getProject = getProject;
exports.isWorkspaceSchema = isWorkspaceSchema;
exports.isWorkspaceProject = isWorkspaceProject;
exports.validateSpartacusInstallation = validateSpartacusInstallation;
exports.scaffoldStructure = scaffoldStructure;
exports.createSassSilenceDeprecations = createSassSilenceDeprecations;
var schematics_1 = require("@angular-devkit/schematics");
var jsonc_parser_1 = require("jsonc-parser");
var libs_constants_1 = require("../libs-constants");
var logger_utils_1 = require("./logger-utils");
var new_module_utils_1 = require("./new-module-utils");
var DEFAULT_POSSIBLE_PROJECT_FILES = ['/angular.json', '/.angular.json'];
function getSourceRoot(host, options) {
    if (options === void 0) { options = {}; }
    var workspace = getWorkspace(host).workspace;
    if (!options.project) {
        options.project = getDefaultProjectNameFromWorkspace(host);
    }
    var sourceRoot = workspace.projects[options.project].sourceRoot;
    if (!sourceRoot) {
        throw new schematics_1.SchematicsException('No default project found');
    }
    return sourceRoot;
}
function getWorkspace(host, files) {
    if (files === void 0) { files = DEFAULT_POSSIBLE_PROJECT_FILES; }
    var angularJson = getAngularJsonFile(host, files);
    var path = files.filter(function (filePath) { return host.exists(filePath); })[0];
    return {
        path: path,
        workspace: angularJson,
    };
}
function getAngularJsonFile(tree, possibleProjectFiles) {
    if (possibleProjectFiles === void 0) { possibleProjectFiles = DEFAULT_POSSIBLE_PROJECT_FILES; }
    var path = possibleProjectFiles.filter(function (filePath) {
        return tree.exists(filePath);
    })[0];
    if (!path) {
        throw new schematics_1.SchematicsException("Could not find Angular");
    }
    var configBuffer = tree.read(path);
    if (configBuffer === null) {
        throw new schematics_1.SchematicsException("Could not find (".concat(path, ")"));
    }
    var angularJsonContent = configBuffer.toString();
    return (0, jsonc_parser_1.parse)(angularJsonContent, undefined, { allowTrailingComma: true });
}
function getProjectFromWorkspace(tree, options, files) {
    if (files === void 0) { files = DEFAULT_POSSIBLE_PROJECT_FILES; }
    var workspace = getWorkspace(tree, files).workspace;
    if (!options.project) {
        throw new schematics_1.SchematicsException('Option "project" is required.');
    }
    var project = workspace.projects[options.project];
    if (!project) {
        throw new schematics_1.SchematicsException("Project is not defined in this workspace.");
    }
    if (project.projectType !== 'application') {
        throw new schematics_1.SchematicsException("Spartacus requires a project type of \"application\".");
    }
    return project;
}
function getDefaultProjectNameFromWorkspace(tree) {
    var workspace = getWorkspace(tree).workspace;
    return Object.keys(workspace.projects)[0];
}
function getProjectTargets(projectOrHost, projectName) {
    if (projectName === void 0) { projectName = ''; }
    var project = isWorkspaceProject(projectOrHost)
        ? projectOrHost
        : getProject(projectOrHost, projectName);
    var projectTargets = project.targets || project.architect;
    if (!projectTargets) {
        throw new Error('Project target not found.');
    }
    return projectTargets;
}
function getProject(workspaceOrHost, projectName) {
    var workspace = isWorkspaceSchema(workspaceOrHost)
        ? workspaceOrHost
        : getWorkspace(workspaceOrHost).workspace;
    return workspace.projects[projectName];
}
function isWorkspaceSchema(workspace) {
    return !!(workspace && workspace.projects);
}
function isWorkspaceProject(project) {
    return !!(project && project.projectType);
}
function validateSpartacusInstallation(packageJson) {
    if (!packageJson.dependencies.hasOwnProperty(libs_constants_1.SPARTACUS_CORE)) {
        throw new schematics_1.SchematicsException("Spartacus is not detected. Please first install Spartacus by running: 'ng add @spartacus/schematics'.\n    To see more options, please check our documentation: https://sap.github.io/spartacus-docs/schematics/");
    }
}
function scaffoldStructure(options) {
    var APP_PATH = 'app/spartacus';
    return function (_tree, _context) {
        return (0, schematics_1.chain)([
            (0, logger_utils_1.debugLogRule)("\u231B\uFE0F Scaffolding Spartacus file structure...", options.debug),
            (0, new_module_utils_1.ensureModuleExists)({
                name: libs_constants_1.SPARTACUS_MODULE,
                path: APP_PATH,
                module: 'app',
                project: options.project,
            }),
            (0, new_module_utils_1.ensureModuleExists)({
                name: libs_constants_1.SPARTACUS_FEATURES_MODULE,
                path: APP_PATH,
                module: 'spartacus',
                project: options.project,
            }),
            (0, new_module_utils_1.ensureModuleExists)({
                name: libs_constants_1.SPARTACUS_CONFIGURATION_MODULE,
                path: APP_PATH,
                module: 'spartacus',
                project: options.project,
            }),
            (0, logger_utils_1.debugLogRule)("\u2705 Spartacus file structure scaffolded.", options.debug),
        ]);
    };
}
/**
 * Creates the `silenceDeprecations` option for the `sass` preprocessor options.
 *
 * This is needed because Sass `@import` is used in Spartacus and Bootstrap 4 styles,
 * and since Angular v19, all apps would have a wall of deprecation warnings
 * in the console when running `ng serve`.
 *
 * @param context - The schematic context.
 */
function createSassSilenceDeprecations(context, originalStylePreprocessorOptions) {
    var _a;
    if (originalStylePreprocessorOptions === void 0) { originalStylePreprocessorOptions = {}; }
    var DEFAULT_SILENCE_DEPRECATIONS = [
        // We need to silence the deprecation warning for the `@import` directive
        // because `@import` is used in the Spartacus styles and in the Bootstrap 4 styles
        // (which are imported by the Spartacus styles).
        // Otherwise, since Angular v19, all apps would have a wall of deprecation warnings
        // in the console when running `ng serve`.
        //
        // CXSPA-447: Eventually we should remove all the `@import` directives from the Spartacus styles
        // and drop the usage of Bootstrap 4, and then we can remove the `silenceDeprecations` option.
        'import',
    ];
    context.logger.warn("\u26A0\uFE0F Warnings about the Sass '@import' usage were silenced, because Sass '@import' is used in Spartacus and Bootstrap 4 styles. To enable warnings back, in your 'angular.json' file remove the item \"import\" from the array at section 'architect.build.options.stylePreprocessorOptions.sass.silenceDeprecations'. For more, see: https://sass-lang.com/blog/import-is-deprecated and https://angular.dev/reference/configs/workspace-config#style-preprocessor-options");
    return {
        sass: __assign(__assign({}, (originalStylePreprocessorOptions.sass || {})), { silenceDeprecations: Array.from(new Set(__spreadArray(__spreadArray([], (((_a = originalStylePreprocessorOptions.sass) === null || _a === void 0 ? void 0 : _a.silenceDeprecations) || []), true), DEFAULT_SILENCE_DEPRECATIONS, true))) }),
    };
}
//# sourceMappingURL=workspace-utils.js.map