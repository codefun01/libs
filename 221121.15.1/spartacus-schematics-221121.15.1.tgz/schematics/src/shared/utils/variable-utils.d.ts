interface ReplaceVariableDeclarationParams {
    fileContent: string;
    variableName: string;
    newText: string;
    throwErrorIfNotFound?: boolean;
}
interface RemoveVariableDeclarationParams {
    fileContent: string;
    variableName: string;
}
/**
 * Replaces a variable declaration in the given file content.
 *
 * Returns the updated file content.
 */
export declare function replaceVariableDeclaration({ fileContent, variableName, newText, throwErrorIfNotFound, }: ReplaceVariableDeclarationParams): string;
/**
 * Removes a variable declaration in the given file content.
 *
 * Returns the updated file content.
 */
export declare function removeVariableDeclaration({ fileContent, variableName, }: RemoveVariableDeclarationParams): string;
export {};
