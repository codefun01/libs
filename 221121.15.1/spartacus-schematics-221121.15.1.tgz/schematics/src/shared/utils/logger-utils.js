"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.debugLogRule = debugLogRule;
exports.formatFeatureStart = formatFeatureStart;
exports.formatFeatureComplete = formatFeatureComplete;
/**
 * Logs the provided message if the debug option is set to true.
 */
function debugLogRule(message, debug) {
    return function (_tree, context) {
        if (debug) {
            context.logger.info(message);
        }
    };
}
/**
 * Formats the given message.
 */
function formatFeatureStart(feature, message) {
    return "\u231B\uFE0F ".concat(feature, ": ").concat(message);
}
/**
 * Formats the given message.
 */
function formatFeatureComplete(feature, message) {
    return "\u2705 ".concat(feature, ": ").concat(message);
}
//# sourceMappingURL=logger-utils.js.map