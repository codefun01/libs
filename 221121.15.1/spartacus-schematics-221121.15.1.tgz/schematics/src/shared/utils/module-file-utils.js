"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.stripTsFromImport = stripTsFromImport;
exports.addToModuleImports = addToModuleImports;
exports.addToModuleExports = addToModuleExports;
exports.addToModuleProviders = addToModuleProviders;
exports.addToMetadata = addToMetadata;
exports.buildRelativePath = buildRelativePath;
exports.getTemplateInfo = getTemplateInfo;
var core_1 = require("@angular-devkit/core");
var ast_utils_1 = require("@schematics/angular/utility/ast-utils");
var typescript_1 = __importDefault(require("typescript"));
var constants_1 = require("../constants");
var file_utils_1 = require("./file-utils");
function stripTsFromImport(importPath) {
    if (!importPath.endsWith('.ts')) {
        return importPath;
    }
    return importPath.slice(0, importPath.length - 3);
}
function addToModuleImports(host, modulePath, importText, moduleSource) {
    return addToMetadata(host, modulePath, importText, 'imports', moduleSource);
}
function addToModuleExports(host, modulePath, exportsText, moduleSource) {
    return addToMetadata(host, modulePath, exportsText, 'exports', moduleSource);
}
function addToModuleProviders(host, modulePath, importText, moduleSource) {
    return addToMetadata(host, modulePath, importText, 'providers', moduleSource);
}
function addToMetadata(host, modulePath, text, metadataType, moduleSource) {
    moduleSource = moduleSource || (0, file_utils_1.getTsSourceFile)(host, modulePath);
    return (0, ast_utils_1.addSymbolToNgModuleMetadata)(moduleSource, modulePath, metadataType, text);
}
// as this is copied from angular source, no need to test it
/**
 * Build a relative path from one file path to another file path.
 */
function buildRelativePath(from, to) {
    from = (0, core_1.normalize)(from);
    to = (0, core_1.normalize)(to);
    // Convert to arrays.
    var fromParts = from.split('/');
    var toParts = to.split('/');
    // Remove file names (preserving destination)
    fromParts.pop();
    var toFileName = toParts.pop();
    var relativePath = (0, core_1.relative)((0, core_1.normalize)(fromParts.join('/') || '/'), (0, core_1.normalize)(toParts.join('/') || '/'));
    var pathPrefix = '';
    // Set the path prefix for same dir or child dir, parent dir starts with `..`
    if (!relativePath) {
        pathPrefix = '.';
    }
    else if (!relativePath.startsWith('.')) {
        pathPrefix = "./";
    }
    if (pathPrefix && !pathPrefix.endsWith('/')) {
        pathPrefix += '/';
    }
    return pathPrefix + (relativePath ? relativePath + '/' : '') + toFileName;
}
function getTemplateInfo(source) {
    var fileUrlResult = getTemplateUrlOrInlineTemplate(source, 'templateUrl');
    if (fileUrlResult) {
        return { templateUrl: fileUrlResult.contentOrUrl };
    }
    // if the 'templateUrl' is not specified, check for the inline template
    var inlineTemplateResult = getTemplateUrlOrInlineTemplate(source, 'template');
    if (inlineTemplateResult) {
        return {
            inlineTemplateContent: inlineTemplateResult.contentOrUrl,
            inlineTemplateStart: inlineTemplateResult.start,
        };
    }
    return undefined;
}
function getTemplateUrlOrInlineTemplate(source, templateOrTemplateUrl) {
    var decorator = (0, ast_utils_1.getDecoratorMetadata)(source, 'Component', constants_1.ANGULAR_CORE)[0];
    if (!decorator) {
        return undefined;
    }
    var templateMetadata = (0, file_utils_1.getMetadataProperty)(decorator, templateOrTemplateUrl);
    if (!templateMetadata) {
        return undefined;
    }
    var stringNode;
    stringNode = stringNode = (0, ast_utils_1.findNodes)(templateMetadata, typescript_1.default.SyntaxKind.NoSubstitutionTemplateLiteral)[0];
    if (!stringNode) {
        // fallback to single/double quotes
        stringNode = (0, ast_utils_1.findNodes)(templateMetadata, typescript_1.default.SyntaxKind.StringLiteral)[0];
    }
    if (!stringNode) {
        return undefined;
    }
    var result = stringNode.text.trim();
    if (templateOrTemplateUrl === 'templateUrl') {
        var url = result.replace('./', '');
        return { contentOrUrl: url };
    }
    return {
        contentOrUrl: result,
        start: stringNode.getStart() + 1,
    };
}
//# sourceMappingURL=module-file-utils.js.map