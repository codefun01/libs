import {
  SchematicTestRunner,
  UnitTestTree,
} from '@angular-devkit/schematics/testing';
import {
  Schema as ApplicationOptions,
  FileNameStyleGuide,
  Style,
} from '@schematics/angular/application/schema';
import { Schema as WorkspaceOptions } from '@schematics/angular/workspace/schema';
import * as path from 'path';
import ts from 'typescript';
import { SPARTACUS_SCHEMATICS } from '../libs-constants';
import { getPathResultsForFile } from './file-utils';
import {
  addToModuleExports,
  addToModuleImports,
  getTemplateInfo,
  stripTsFromImport,
} from './module-file-utils';

const collectionPath = path.join(__dirname, '../../collection.json');
const schematicRunner = new SchematicTestRunner(
  SPARTACUS_SCHEMATICS,
  collectionPath
);

const TEMPLATE_NAME = 'template.html';
const COMPONENT_TEMPLATE_URL = `
import { Component } from '@angular/core';
@Component({
  selector: 'cx-consent-management-form',
  templateUrl: './${TEMPLATE_NAME}',
})
export class Test {}
`;
const TEMPLATE = '<div>test</div>';
const COMPONENT_INLINE_TEMPLATE = `
import { Component } from '@angular/core';
@Component({
  selector: 'cx-consent-management-form',
  template: \`${TEMPLATE}\`,
})
export class Test {}
`;

describe('Module file utils', () => {
  let appTree: UnitTestTree;
  const workspaceOptions: WorkspaceOptions = {
    name: 'workspace',
    version: '0.5.0',
  };
  const appOptions: ApplicationOptions = {
    name: 'schematics-test',
    inlineStyle: false,
    inlineTemplate: false,
    style: Style.Scss,
    skipTests: false,
    projectRoot: '',
    zoneless: false,
    fileNameStyleGuide: FileNameStyleGuide.The2016,
  };
  const defaultOptions = {
    project: 'schematics-test',
  };

  beforeAll(async () => {
    appTree = await schematicRunner.runExternalSchematic(
      '@schematics/angular',
      'workspace',
      workspaceOptions
    );

    appTree = await schematicRunner.runExternalSchematic(
      '@schematics/angular',
      'application',
      appOptions,
      appTree
    );

    appTree = await schematicRunner.runSchematic(
      'add-spartacus',
      defaultOptions,
      appTree
    );
  });

  describe('stripTsFromImport', () => {
    it('should strip the .ts when present', () => {
      const test1 = '../../components.ts';
      expect(stripTsFromImport(test1)).toEqual('../../components');

      const test2 = '../../ts.ts.ts';
      expect(stripTsFromImport(test2)).toEqual('../../ts.ts');
    });
    it('should NOT strip the .ts when the import path does not end with it', () => {
      const test = '../ts.tsts';
      expect(stripTsFromImport(test)).toEqual(test);
    });
  });

  describe('add metadata to ng module', () => {
    describe('addToModuleImports', () => {
      it('should add passed position to imports array', async () => {
        const appModulePath = getPathResultsForFile(
          appTree,
          'app.module.ts',
          'src'
        )[0];
        expect(appModulePath).toBeTruthy();
        const resultChange = addToModuleImports(
          appTree,
          appModulePath,
          'MockUnitTestModule'
        );

        expect(resultChange).toBeTruthy();
        expect(resultChange.length).toEqual(1);
        expect(resultChange[0].toAdd).toContain('MockUnitTestModule');
      });
    });

    describe('addToModuleExports', () => {
      it('should add passed position to exports array', async () => {
        const appModulePath = getPathResultsForFile(
          appTree,
          'app.module.ts',
          'src'
        )[0];
        expect(appModulePath).toBeTruthy();
        const resultChange = addToModuleExports(
          appTree,
          appModulePath,
          'MockUnitTestModule'
        );

        expect(resultChange).toBeTruthy();
        expect(resultChange.length).toEqual(1);
        expect(resultChange[0].toAdd).toContain('MockUnitTestModule');
      });
    });
  });

  describe('getTemplateInfo', () => {
    describe('when the templateUrl is specified', () => {
      it('should return the template path', () => {
        const source = ts.createSourceFile(
          'component.ts',
          COMPONENT_TEMPLATE_URL,
          ts.ScriptTarget.Latest,
          true
        );
        const result = getTemplateInfo(source);
        expect(result).toBeTruthy();
        if (result) {
          expect(result.templateUrl).toEqual(TEMPLATE_NAME);
          expect(result.inlineTemplateContent).toBeUndefined();
          expect(result.inlineTemplateStart).toBeUndefined();
        }
      });
    });

    describe('when the inline template is defined', () => {
      it('should return the template path', () => {
        const source = ts.createSourceFile(
          'component.ts',
          COMPONENT_INLINE_TEMPLATE,
          ts.ScriptTarget.Latest,
          true
        );
        const result = getTemplateInfo(source);
        expect(result).toBeTruthy();
        if (result) {
          expect(result.inlineTemplateContent).toEqual(TEMPLATE);
          expect(result.inlineTemplateStart).toEqual(112);
          expect(result.templateUrl).toBeUndefined();
        }
      });
    });
  });
});
