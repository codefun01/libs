"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.isImportedFromSpartacusLibs = isImportedFromSpartacusLibs;
exports.isImportedFrom = isImportedFrom;
exports.getImportPath = getImportPath;
exports.getImportDeclaration = getImportDeclaration;
exports.collectDynamicImports = collectDynamicImports;
exports.getDynamicImportCallExpression = getDynamicImportCallExpression;
exports.getDynamicImportImportPath = getDynamicImportImportPath;
exports.getDynamicImportPropertyAccess = getDynamicImportPropertyAccess;
exports.createImports = createImports;
exports.staticImportExists = staticImportExists;
exports.removeImports = removeImports;
exports.isRelative = isRelative;
exports.findDynamicImport = findDynamicImport;
var ts_morph_1 = require("ts-morph");
var libs_constants_1 = require("../libs-constants");
var config_utils_1 = require("./config-utils");
/**
 * Checks if the provided import is a Spartacus library.
 */
function isImportedFromSpartacusLibs(node) {
    return isImportedFrom(node, libs_constants_1.SPARTACUS_SCOPE);
}
function isImportedFrom(node, toCheck) {
    var _a;
    var moduleImportPath;
    if (typeof node === 'string') {
        moduleImportPath = node;
    }
    else {
        moduleImportPath = (_a = getImportPath(node)) !== null && _a !== void 0 ? _a : '';
    }
    return moduleImportPath.startsWith(toCheck);
}
function getImportPath(node) {
    var declaration = getImportDeclaration(node);
    if (declaration) {
        return declaration.getModuleSpecifierValue();
    }
    return undefined;
}
function getImportDeclaration(node) {
    var references = node.findReferencesAsNodes();
    for (var _i = 0, references_1 = references; _i < references_1.length; _i++) {
        var reference = references_1[_i];
        var importDeclaration = reference === null || reference === void 0 ? void 0 : reference.getFirstAncestorByKind(ts_morph_1.ts.SyntaxKind.ImportDeclaration);
        if (importDeclaration) {
            return importDeclaration;
        }
    }
    return undefined;
}
/**
 * Collects the higher-order arrow functions.
 * E.g. `() => import('@spartacus/cart/base/components/add-to-cart').then((m) => m.AddToCartModule)`,
 * but not the inner one `(m) => m.AddToCartModule`.
 */
function collectDynamicImports(source) {
    var providers = (0, config_utils_1.getSpartacusProviders)(source, false);
    var arrowFunctions = [];
    for (var _i = 0, providers_1 = providers; _i < providers_1.length; _i++) {
        var element = providers_1[_i];
        var higherArrowFunctions = element
            .getDescendantsOfKind(ts_morph_1.ts.SyntaxKind.ArrowFunction)
            .filter(function (arrowFn) {
            return arrowFn.getParentIfKind(ts_morph_1.ts.SyntaxKind.PropertyAssignment);
        });
        arrowFunctions = arrowFunctions.concat(higherArrowFunctions);
    }
    return arrowFunctions;
}
/**
 * Returns the call expression of the dynamic import (if any).
 * E.g. for the given `() => import('@spartacus/cart/base').then((m) => m.CartBaseModule)` it returns `import('@spartacus/cart/base')`
 */
function getDynamicImportCallExpression(arrowFunction) {
    var _a;
    return (_a = arrowFunction
        .getFirstDescendantByKind(ts_morph_1.ts.SyntaxKind.ImportKeyword)) === null || _a === void 0 ? void 0 : _a.getParentIfKind(ts_morph_1.ts.SyntaxKind.CallExpression);
}
/**
 * Returns the import path, e.g. @spartacus/cart/base
 */
function getDynamicImportImportPath(arrowFunction) {
    var _a, _b;
    return (_b = (_a = getDynamicImportCallExpression(arrowFunction)) === null || _a === void 0 ? void 0 : _a.getFirstDescendantByKind(ts_morph_1.ts.SyntaxKind.StringLiteral)) === null || _b === void 0 ? void 0 : _b.getLiteralValue();
}
/**
 * Returns the import module of the dynamic import (if any).
 * E.g. for the given `() => import('@spartacus/cart/base').then((m) => m.CartBaseModule)` it returns `m.CartBaseModule`
 */
function getDynamicImportPropertyAccess(arrowFunction) {
    var _a;
    return (_a = arrowFunction
        .getFirstDescendantByKind(ts_morph_1.ts.SyntaxKind.ArrowFunction)) === null || _a === void 0 ? void 0 : _a.getFirstDescendantByKind(ts_morph_1.ts.SyntaxKind.PropertyAccessExpression);
}
/**
 * Creates the import statement in the given source file.
 * If an import from the same module already exists, it adds the named imports to the existing import.
 */
function createImports(sourceFile, imports) {
    var importDeclarations = [];
    [].concat(imports).forEach(function (specifiedImport) {
        var _a, _b;
        // Check if an import declaration with the same module specifier already exists
        var existingImport = sourceFile
            .getImportDeclarations()
            .find(function (id) { return id.getModuleSpecifierValue() === specifiedImport.moduleSpecifier; });
        if (existingImport) {
            // Add named imports to the existing import declaration (avoiding duplicates)
            var existingNamedImports = (_b = (_a = existingImport.getImportClause()) === null || _a === void 0 ? void 0 : _a.getNamedImports()) !== null && _b !== void 0 ? _b : [];
            var existingImportNames_1 = existingNamedImports.map(function (ni) {
                return ni.getName();
            });
            var newNamedImports = specifiedImport.namedImports.filter(function (name) { return !existingImportNames_1.includes(name); });
            if (newNamedImports.length > 0) {
                existingImport.addNamedImports(newNamedImports.map(function (name) { return ({ name: name }); }));
            }
            importDeclarations.push(existingImport);
        }
        else {
            // Create a new import declaration
            var importDeclaration = sourceFile.addImportDeclaration({
                moduleSpecifier: specifiedImport.moduleSpecifier,
                namedImports: specifiedImport.namedImports,
            });
            importDeclarations.push(importDeclaration);
        }
    });
    return importDeclarations;
}
/**
 * Searches through the given module's imports
 * for the given import path and import name.
 */
function staticImportExists(sourceFile, importPathToFind, moduleNameToFind) {
    var _a, _b;
    var importDeclarations = sourceFile.getImportDeclarations();
    for (var _i = 0, importDeclarations_1 = importDeclarations; _i < importDeclarations_1.length; _i++) {
        var importDeclaration = importDeclarations_1[_i];
        var importPath = importDeclaration.getModuleSpecifierValue();
        if (importPathToFind === importPath) {
            var namedImports = (_b = (_a = importDeclaration.getImportClause()) === null || _a === void 0 ? void 0 : _a.getNamedImports()) !== null && _b !== void 0 ? _b : [];
            for (var _c = 0, namedImports_1 = namedImports; _c < namedImports_1.length; _c++) {
                var namedImport = namedImports_1[_c];
                if (namedImport.getName() === moduleNameToFind) {
                    return true;
                }
            }
        }
    }
    return false;
}
/**
 * Removes the imports in the given source file.
 */
function removeImports(sourceFile, symbolsToRemove) {
    var removedImports = [];
    sourceFile.getImportDeclarations().forEach(function (id) {
        var _a;
        (_a = id
            .getImportClause()) === null || _a === void 0 ? void 0 : _a.getNamedImports().forEach(function (namedImport) {
            var _a, _b;
            var importName = namedImport.getName();
            var symbolToRemove = symbolsToRemove.find(function (symbol) {
                return symbol.node === importName &&
                    symbol.importPath === id.getModuleSpecifierValue();
            });
            if (symbolToRemove) {
                if ((((_b = (_a = id.getImportClause()) === null || _a === void 0 ? void 0 : _a.getNamedImports()) === null || _b === void 0 ? void 0 : _b.length) || 0) > 1) {
                    namedImport.remove();
                }
                else {
                    id.remove();
                }
                removedImports.push(namedImport);
            }
        });
    });
    return removedImports;
}
/**
 * Returns true if the given path is relative
 */
function isRelative(path) {
    return path.startsWith('./') || path.startsWith('../');
}
/**
 * Analyzes the dynamic imports of the given module.
 * If both dynamic import's import path and module name
 * are found in the given config, it returns it.
 */
function findDynamicImport(sourceFile, importToFind) {
    var _a, _b, _c, _d;
    var collectedDynamicImports = collectDynamicImports(sourceFile);
    for (var _i = 0, collectedDynamicImports_1 = collectedDynamicImports; _i < collectedDynamicImports_1.length; _i++) {
        var dynamicImport = collectedDynamicImports_1[_i];
        var importPath = (_a = getDynamicImportImportPath(dynamicImport)) !== null && _a !== void 0 ? _a : '';
        if (isRelative(importPath)) {
            if (!importPath.includes(importToFind.moduleSpecifier)) {
                continue;
            }
        }
        else {
            if (importPath !== importToFind.moduleSpecifier) {
                continue;
            }
        }
        var importModule = (_d = (_c = (_b = getDynamicImportPropertyAccess(dynamicImport)) === null || _b === void 0 ? void 0 : _b.getLastChildByKind(ts_morph_1.ts.SyntaxKind.Identifier)) === null || _c === void 0 ? void 0 : _c.getText()) !== null && _d !== void 0 ? _d : '';
        if (importToFind.namedImports.includes(importModule)) {
            return dynamicImport;
        }
    }
    return undefined;
}
//# sourceMappingURL=import-utils.js.map