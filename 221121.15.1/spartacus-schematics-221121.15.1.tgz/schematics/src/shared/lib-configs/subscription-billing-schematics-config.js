"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUBSCRIPTION_BILLING_SCHEMATICS_CONFIG = exports.SUBSCRIPTION_BILLING_TRANSLATION_CHUNKS_CONFIG = exports.SUBSCRIPTION_BILLING_TRANSLATIONS = exports.SUBSCRIPTION_BILLING_FEATURE_NAME_CONSTANT = exports.SUBSCRIPTION_BILLING_SCSS_FILE_NAME = exports.SUBSCRIPTION_BILLING_ROOT_MODULE = exports.SUBSCRIPTION_BILLING_MODULE_NAME = exports.SUBSCRIPTION_BILLING_MODULE = exports.SUBSCRIPTION_BILLING_FOLDER_NAME = void 0;
var libs_constants_1 = require("../libs-constants");
exports.SUBSCRIPTION_BILLING_FOLDER_NAME = 'subscription-billing';
exports.SUBSCRIPTION_BILLING_MODULE = 'SubscriptionBillingModule';
exports.SUBSCRIPTION_BILLING_MODULE_NAME = 'SubscriptionBilling';
exports.SUBSCRIPTION_BILLING_ROOT_MODULE = 'SubscriptionBillingRootModule';
exports.SUBSCRIPTION_BILLING_SCSS_FILE_NAME = 'subscription-billing.scss';
exports.SUBSCRIPTION_BILLING_FEATURE_NAME_CONSTANT = 'SUBSCRIPTION_BILLING_FEATURE';
exports.SUBSCRIPTION_BILLING_TRANSLATIONS = 'subscriptionBillingTranslations';
exports.SUBSCRIPTION_BILLING_TRANSLATION_CHUNKS_CONFIG = 'subscriptionBillingTranslationChunksConfig';
exports.SUBSCRIPTION_BILLING_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.SUBSCRIPTION_BILLING_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_SUBSCRIPTION_BILLING,
    },
    folderName: exports.SUBSCRIPTION_BILLING_FOLDER_NAME,
    moduleName: exports.SUBSCRIPTION_BILLING_MODULE_NAME,
    featureModule: [
        {
            name: exports.SUBSCRIPTION_BILLING_MODULE,
            importPath: libs_constants_1.SPARTACUS_SUBSCRIPTION_BILLING,
        },
    ],
    rootModule: {
        importPath: libs_constants_1.SPARTACUS_SUBSCRIPTION_BILLING_ROOT,
        name: exports.SUBSCRIPTION_BILLING_ROOT_MODULE,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_SUBSCRIPTION_BILLING_ROOT,
        namedImports: [exports.SUBSCRIPTION_BILLING_FEATURE_NAME_CONSTANT],
    },
    styles: {
        scssFileName: exports.SUBSCRIPTION_BILLING_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_SUBSCRIPTION_BILLING,
    },
    i18n: {
        resources: exports.SUBSCRIPTION_BILLING_TRANSLATIONS,
        chunks: exports.SUBSCRIPTION_BILLING_TRANSLATION_CHUNKS_CONFIG,
        importPath: libs_constants_1.SPARTACUS_SUBSCRIPTION_BILLING_ASSETS,
    },
};
//# sourceMappingURL=subscription-billing-schematics-config.js.map