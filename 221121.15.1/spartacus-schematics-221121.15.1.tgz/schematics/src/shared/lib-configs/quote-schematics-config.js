"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.QUOTE_SCHEMATICS_CONFIG = exports.QUOTE_SCSS_FILE_NAME = exports.QUOTE_TRANSLATION_CHUNKS_CONFIG = exports.QUOTE_TRANSLATIONS = exports.QUOTE_ROOT_MODULE = exports.QUOTE_REQUEST_MODULE = exports.QUOTE_CART_GUARD_MODULE = exports.QUOTE_MODULE = exports.QUOTE_FEATURE_REQUEST_NAME_CONSTANT = exports.QUOTE_FEATURE_CART_GUARD_NAME_CONSTANT = exports.QUOTE_FEATURE_NAME_CONSTANT = exports.QUOTE_MODULE_NAME = exports.QUOTE_FOLDER_NAME = void 0;
var libs_constants_1 = require("../libs-constants");
exports.QUOTE_FOLDER_NAME = 'quote';
exports.QUOTE_MODULE_NAME = 'Quote';
exports.QUOTE_FEATURE_NAME_CONSTANT = 'QUOTE_FEATURE';
exports.QUOTE_FEATURE_CART_GUARD_NAME_CONSTANT = 'QUOTE_CART_GUARD_FEATURE';
exports.QUOTE_FEATURE_REQUEST_NAME_CONSTANT = 'QUOTE_REQUEST_FEATURE';
exports.QUOTE_MODULE = 'QuoteModule';
exports.QUOTE_CART_GUARD_MODULE = 'QuoteCartGuardComponentModule';
exports.QUOTE_REQUEST_MODULE = 'QuoteRequestButtonModule';
exports.QUOTE_ROOT_MODULE = 'QuoteRootModule';
exports.QUOTE_TRANSLATIONS = 'quoteTranslations';
exports.QUOTE_TRANSLATION_CHUNKS_CONFIG = 'quoteTranslationChunksConfig';
exports.QUOTE_SCSS_FILE_NAME = 'quote.scss';
exports.QUOTE_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.QUOTE_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_QUOTE,
        b2b: true,
    },
    folderName: exports.QUOTE_FOLDER_NAME,
    moduleName: exports.QUOTE_MODULE_NAME,
    featureModule: [
        {
            name: exports.QUOTE_MODULE,
            importPath: libs_constants_1.SPARTACUS_QUOTE,
        },
        {
            name: exports.QUOTE_CART_GUARD_MODULE,
            importPath: libs_constants_1.SPARTACUS_QUOTE_CART_GUARD,
        },
        {
            name: exports.QUOTE_REQUEST_MODULE,
            importPath: libs_constants_1.SPARTACUS_QUOTE_REQUEST,
        },
    ],
    rootModule: {
        name: exports.QUOTE_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_QUOTE_ROOT,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_QUOTE_ROOT,
        namedImports: [
            exports.QUOTE_FEATURE_NAME_CONSTANT,
            exports.QUOTE_FEATURE_CART_GUARD_NAME_CONSTANT,
            exports.QUOTE_FEATURE_REQUEST_NAME_CONSTANT,
        ],
    },
    styles: {
        scssFileName: exports.QUOTE_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_QUOTE,
        importStyles: [
            libs_constants_1.SPARTACUS_BOOTSTRAP_FUNCTIONS,
            libs_constants_1.SPARTACUS_BOOTSTRAP_VARIABLES,
            libs_constants_1.SPARTACUS_BOOTSTRAP_MIXINS,
        ],
    },
    i18n: {
        resources: exports.QUOTE_TRANSLATIONS,
        chunks: exports.QUOTE_TRANSLATION_CHUNKS_CONFIG,
        importPath: libs_constants_1.SPARTACUS_QUOTE_ASSETS,
    },
    dependencyFeatures: [libs_constants_1.CART_BASE_FEATURE_NAME],
};
//# sourceMappingURL=quote-schematics-config.js.map