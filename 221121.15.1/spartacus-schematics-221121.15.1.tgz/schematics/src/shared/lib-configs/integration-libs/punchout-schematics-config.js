"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PUNCHOUT_SCHEMATICS_CONFIG = exports.PUNCHOUT_TRANSLATION_CHUNKS_CONFIG = exports.PUNCHOUT_TRANSLATIONS = exports.PUNCHOUT_FEATURE_NAME_CONSTANT = exports.PUNCHOUT_ROOT_MODULE = exports.PUNCHOUT_MODULE = exports.PUNCHOUT_MODULE_NAME = exports.PUNCHOUT_FOLDER_NAME = exports.PUNCHOUT_SCSS_FILE_NAME = void 0;
var libs_constants_1 = require("../../libs-constants");
exports.PUNCHOUT_SCSS_FILE_NAME = 'punchout.scss';
exports.PUNCHOUT_FOLDER_NAME = 'punchout';
exports.PUNCHOUT_MODULE_NAME = 'Punchout';
exports.PUNCHOUT_MODULE = 'PunchoutModule';
exports.PUNCHOUT_ROOT_MODULE = 'PunchoutRootModule';
exports.PUNCHOUT_FEATURE_NAME_CONSTANT = 'PUNCHOUT_FEATURE';
exports.PUNCHOUT_TRANSLATIONS = 'punchoutTranslations';
exports.PUNCHOUT_TRANSLATION_CHUNKS_CONFIG = 'punchoutTranslationChunksConfig';
exports.PUNCHOUT_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.PUNCHOUT_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_PUNCHOUT,
        b2b: true,
    },
    folderName: exports.PUNCHOUT_FOLDER_NAME,
    moduleName: exports.PUNCHOUT_MODULE_NAME,
    featureModule: {
        name: exports.PUNCHOUT_MODULE,
        importPath: libs_constants_1.SPARTACUS_PUNCHOUT,
    },
    rootModule: {
        name: exports.PUNCHOUT_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_PUNCHOUT_ROOT,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_PUNCHOUT_ROOT,
        namedImports: [exports.PUNCHOUT_FEATURE_NAME_CONSTANT],
    },
    i18n: {
        resources: exports.PUNCHOUT_TRANSLATIONS,
        chunks: exports.PUNCHOUT_TRANSLATION_CHUNKS_CONFIG,
        importPath: libs_constants_1.SPARTACUS_PUNCHOUT_ASSETS,
    },
    styles: {
        scssFileName: exports.PUNCHOUT_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_PUNCHOUT,
        importStyles: [
            libs_constants_1.SPARTACUS_BOOTSTRAP_FUNCTIONS,
            libs_constants_1.SPARTACUS_BOOTSTRAP_VARIABLES,
            libs_constants_1.SPARTACUS_BOOTSTRAP_MIXINS,
        ],
    },
};
//# sourceMappingURL=punchout-schematics-config.js.map