"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.CPQ_QUOTE_SCHEMATICS_CONFIG = exports.CPQ_QUOTE_MODULE = exports.CPQ_QUOTE_TRANSLATION_CHUNKS_CONFIG = exports.CPQ_QUOTE_TRANSLATIONS = exports.CPQ_QUOTE_MODULE_ROOT = exports.CPQ_QUOTE_MODULE_NAME = exports.CPQ_QUOTE_FOLDER_NAME = void 0;
var libs_constants_1 = require("../../libs-constants");
var cart_schematics_config_1 = require("../cart-schematics-config");
exports.CPQ_QUOTE_FOLDER_NAME = 'cpq-quote';
exports.CPQ_QUOTE_MODULE_NAME = 'CpqQuote';
exports.CPQ_QUOTE_MODULE_ROOT = 'CpqQuoteRootModule';
exports.CPQ_QUOTE_TRANSLATIONS = 'cpqquoteTranslations';
exports.CPQ_QUOTE_TRANSLATION_CHUNKS_CONFIG = 'cpqquoteTranslationChunksConfig';
exports.CPQ_QUOTE_MODULE = 'CpqQuoteModule'; //pushed
exports.CPQ_QUOTE_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.CPQ_QUOTE_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_CPQ_QUOTE,
    },
    folderName: exports.CPQ_QUOTE_FOLDER_NAME,
    moduleName: exports.CPQ_QUOTE_MODULE_NAME,
    featureModule: {
        name: exports.CPQ_QUOTE_MODULE,
        importPath: libs_constants_1.SPARTACUS_CPQ_QUOTE,
    },
    rootModule: {
        name: exports.CPQ_QUOTE_MODULE_ROOT,
        importPath: libs_constants_1.SPARTACUS_CPQ_QUOTE_ROOT,
    },
    i18n: {
        resources: exports.CPQ_QUOTE_TRANSLATIONS,
        chunks: exports.CPQ_QUOTE_TRANSLATION_CHUNKS_CONFIG,
        importPath: libs_constants_1.SPARTACUS_CPQ_QUOTE_ASSETS,
    },
    dependencyFeatures: [libs_constants_1.CART_BASE_FEATURE_NAME],
    importAfter: [
        {
            markerModuleName: cart_schematics_config_1.CART_BASE_MODULE,
            featureModuleName: exports.CPQ_QUOTE_MODULE,
        },
    ],
};
//# sourceMappingURL=cpq-quote-schematics-config.js.map