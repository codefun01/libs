"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.OMF_SCHEMATICS_CONFIG = exports.OMF_ORDER_MODULE = exports.OMF_ROOT_MODULE = exports.OMF_MODULE_NAME = exports.OMF_FOLDER_NAME = void 0;
var libs_constants_1 = require("../../libs-constants");
var order_schematics_config_1 = require("../order-schematics-config");
exports.OMF_FOLDER_NAME = 'omf';
exports.OMF_MODULE_NAME = 'Omf';
exports.OMF_ROOT_MODULE = 'OmfRootModule';
exports.OMF_ORDER_MODULE = 'OmfOrderModule';
exports.OMF_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.OMF_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_OMF,
    },
    folderName: exports.OMF_FOLDER_NAME,
    moduleName: exports.OMF_MODULE_NAME,
    featureModule: [
        {
            name: exports.OMF_ROOT_MODULE,
            importPath: libs_constants_1.SPARTACUS_OMF,
        },
        {
            name: exports.OMF_ORDER_MODULE,
            importPath: libs_constants_1.SPARTACUS_OMF_ORDER,
        },
    ],
    rootModule: {
        importPath: libs_constants_1.SPARTACUS_OMF_ROOT,
        name: exports.OMF_ROOT_MODULE,
        content: "".concat(exports.OMF_ROOT_MODULE),
    },
    dependencyFeatures: [libs_constants_1.ORDER_FEATURE_NAME],
    importAfter: [
        {
            markerModuleName: order_schematics_config_1.ORDER_MODULE,
            featureModuleName: exports.OMF_ORDER_MODULE,
        },
    ],
};
//# sourceMappingURL=omf-schematics-config.js.map