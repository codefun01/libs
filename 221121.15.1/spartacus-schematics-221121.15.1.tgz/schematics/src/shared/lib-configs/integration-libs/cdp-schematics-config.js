"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.CDP_SCHEMATICS_CONFIG = exports.CDP_CUSTOMER_TICKETING_MODULE = exports.CDP_FEATURE_NAME_CONSTANT = exports.CDP_MODULE_NAME = exports.CDP_FOLDER_NAME = void 0;
var libs_constants_1 = require("../../libs-constants");
var customer_ticketing_schematics_config_1 = require("../customer-ticketing-schematics-config");
exports.CDP_FOLDER_NAME = 'cdp';
exports.CDP_MODULE_NAME = 'Cdp';
exports.CDP_FEATURE_NAME_CONSTANT = 'CDP_FEATURE';
exports.CDP_CUSTOMER_TICKETING_MODULE = 'CdpCustomerTicketingModule';
exports.CDP_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.CDP_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_CDP,
    },
    folderName: exports.CDP_FOLDER_NAME,
    moduleName: exports.CDP_MODULE_NAME,
    featureModule: [
        {
            name: exports.CDP_CUSTOMER_TICKETING_MODULE,
            importPath: libs_constants_1.SPARTACUS_CDP_CUSTOMER_TICKETING,
        },
    ],
    dependencyFeatures: [libs_constants_1.CUSTOMER_TICKETING_FEATURE_NAME],
    importAfter: [
        {
            markerModuleName: customer_ticketing_schematics_config_1.CUSTOMER_TICKETING_MODULE,
            featureModuleName: exports.CDP_CUSTOMER_TICKETING_MODULE,
        },
    ],
};
//# sourceMappingURL=cdp-schematics-config.js.map