"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.S4_SERVICE_SCHEMATICS_CONFIG = exports.S4_SERVICE_TRANSLATION_CHUNKS_CONFIG = exports.S4_SERVICE_TRANSLATIONS = exports.S4_SERVICE_FEATURE_NAME_CONSTANT = exports.S4_SERVICE_ROOT_MODULE = exports.S4_SERVICE_ORDER_MODULE = exports.S4_SERVICE_CHECKOUT_MODULE = exports.S4_SERVICE_MODULE = exports.S4_SERVICE_SCSS_FILE_NAME = exports.S4_SERVICE_MODULE_NAME = exports.S4_SERVICE_FOLDER_NAME = void 0;
var libs_constants_1 = require("../../libs-constants");
var checkout_schematics_config_1 = require("../checkout-schematics-config");
var order_schematics_config_1 = require("../order-schematics-config");
exports.S4_SERVICE_FOLDER_NAME = 's4-service';
exports.S4_SERVICE_MODULE_NAME = 'S4Service';
exports.S4_SERVICE_SCSS_FILE_NAME = 's4-service.scss';
exports.S4_SERVICE_MODULE = 'S4ServiceModule';
exports.S4_SERVICE_CHECKOUT_MODULE = 'S4ServiceCheckoutModule';
exports.S4_SERVICE_ORDER_MODULE = 'S4ServiceOrderModule';
exports.S4_SERVICE_ROOT_MODULE = 'S4ServiceRootModule';
exports.S4_SERVICE_FEATURE_NAME_CONSTANT = 'S4_SERVICE_FEATURE';
exports.S4_SERVICE_TRANSLATIONS = 's4ServiceTranslations';
exports.S4_SERVICE_TRANSLATION_CHUNKS_CONFIG = 's4ServiceTranslationChunksConfig';
exports.S4_SERVICE_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.S4_SERVICE_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_S4_SERVICE,
        b2b: true,
    },
    folderName: exports.S4_SERVICE_FOLDER_NAME,
    moduleName: exports.S4_SERVICE_MODULE_NAME,
    featureModule: [
        {
            name: exports.S4_SERVICE_MODULE,
            importPath: libs_constants_1.SPARTACUS_S4_SERVICE,
        },
        {
            name: exports.S4_SERVICE_CHECKOUT_MODULE,
            importPath: libs_constants_1.SPARTACUS_S4_SERVICE_CHECKOUT,
        },
        {
            name: exports.S4_SERVICE_ORDER_MODULE,
            importPath: libs_constants_1.SPARTACUS_S4_SERVICE_ORDER,
        },
    ],
    rootModule: {
        name: exports.S4_SERVICE_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_S4_SERVICE_ROOT,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_S4_SERVICE_ROOT,
        namedImports: [exports.S4_SERVICE_FEATURE_NAME_CONSTANT],
    },
    i18n: {
        resources: exports.S4_SERVICE_TRANSLATIONS,
        chunks: exports.S4_SERVICE_TRANSLATION_CHUNKS_CONFIG,
        importPath: libs_constants_1.SPARTACUS_S4_SERVICE_ASSETS,
    },
    dependencyFeatures: [libs_constants_1.CHECKOUT_B2B_FEATURE_NAME, libs_constants_1.ORDER_FEATURE_NAME],
    styles: {
        scssFileName: exports.S4_SERVICE_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_S4_SERVICE,
    },
    importAfter: [
        {
            markerModuleName: checkout_schematics_config_1.CHECKOUT_B2B_MODULE,
            featureModuleName: exports.S4_SERVICE_CHECKOUT_MODULE,
        },
        {
            markerModuleName: order_schematics_config_1.ORDER_MODULE,
            featureModuleName: exports.S4_SERVICE_ORDER_MODULE,
        },
    ],
};
//# sourceMappingURL=s4-service-schematics-config.js.map