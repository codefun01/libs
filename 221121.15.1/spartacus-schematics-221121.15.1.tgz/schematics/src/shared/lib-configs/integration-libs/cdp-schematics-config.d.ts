import { SchematicConfig } from '../../utils/lib-utils';
export declare const CDP_FOLDER_NAME = "cdp";
export declare const CDP_MODULE_NAME = "Cdp";
export declare const CDP_FEATURE_NAME_CONSTANT = "CDP_FEATURE";
export declare const CDP_CUSTOMER_TICKETING_MODULE = "CdpCustomerTicketingModule";
export declare const CDP_SCHEMATICS_CONFIG: SchematicConfig;
