import { SchematicConfig } from '../../utils/lib-utils';
export declare const OMF_FOLDER_NAME = "omf";
export declare const OMF_MODULE_NAME = "Omf";
export declare const OMF_ROOT_MODULE = "OmfRootModule";
export declare const OMF_ORDER_MODULE = "OmfOrderModule";
export declare const OMF_SCHEMATICS_CONFIG: SchematicConfig;
