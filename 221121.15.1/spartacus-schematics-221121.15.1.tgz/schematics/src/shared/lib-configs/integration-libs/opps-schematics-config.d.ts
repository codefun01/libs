import { SchematicConfig } from '../../utils/lib-utils';
export declare const OPPS_FOLDER_NAME = "opps";
export declare const OPPS_MODULE_NAME = "Opps";
export declare const OPPS_ROOT_MODULE = "OppsRootModule";
export declare const OPPS_SCHEMATICS_CONFIG: SchematicConfig;
