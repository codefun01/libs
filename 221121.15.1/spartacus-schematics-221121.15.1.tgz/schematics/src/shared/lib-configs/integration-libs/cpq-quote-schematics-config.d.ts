import { SchematicConfig } from '../../utils/lib-utils';
export declare const CPQ_QUOTE_FOLDER_NAME = "cpq-quote";
export declare const CPQ_QUOTE_MODULE_NAME = "CpqQuote";
export declare const CPQ_QUOTE_MODULE_ROOT = "CpqQuoteRootModule";
export declare const CPQ_QUOTE_TRANSLATIONS = "cpqquoteTranslations";
export declare const CPQ_QUOTE_TRANSLATION_CHUNKS_CONFIG = "cpqquoteTranslationChunksConfig";
export declare const CPQ_QUOTE_MODULE = "CpqQuoteModule";
export declare const CPQ_QUOTE_SCHEMATICS_CONFIG: SchematicConfig;
