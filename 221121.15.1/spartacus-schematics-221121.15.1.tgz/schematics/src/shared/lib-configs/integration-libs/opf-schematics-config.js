"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.OPF_GLOBAL_FUNCTIONS_SCHEMATICS_CONFIG = exports.OPF_CTA_SCHEMATICS_CONFIG = exports.OPF_B2B_CHECKOUT_SCHEMATICS_CONFIG = exports.OPF_CHECKOUT_SCHEMATICS_CONFIG = exports.OPF_PAYMENT_SCHEMATICS_CONFIG = exports.OPF_BASE_SCHEMATICS_CONFIG = exports.OPF_GIFT_CARD_CART_CONFIG = exports.OPF_GIFT_CARD_DEFAULT_OCC_ORDER_CONFIG = exports.OPF_GIFT_CARD_DEFAULT_OCC_CART_CONFIG = exports.OPF_GIFT_CARD_TRANSLATION_CHUNKS_CONFIG = exports.OPF_GIFT_CARD_TRANSLATIONS = exports.OPF_GIFT_CARD_ROOT_MODULE = exports.OPF_GIFT_CARD_MODULE = exports.OPF_GIFT_CARD_FEATURE_NAME_CONSTANT = exports.OPF_ORDER_MODULE = exports.OPF_PAYMENT_TRANSLATION_CHUNKS_CONFIG = exports.OPF_PAYMENT_TRANSLATIONS = exports.OPF_PAYMENT_ROOT_MODULE = exports.OPF_PAYMENT_MODULE = exports.OPF_PAYMENT_FEATURE_NAME_CONSTANT = exports.OPF_TOKENISATION_ROOT_MODULE = exports.OPF_TOKENISATION_MODULE = exports.OPF_TOKENISATION_FEATURE_NAME_CONSTANT = exports.OPF_QUICK_BUY_ROOT_MODULE = exports.OPF_QUICK_BUY_MODULE = exports.OPF_QUICK_BUY_FEATURE_NAME_CONSTANT = exports.OPF_CTA_ROOT_MODULE = exports.OPF_CTA_MODULE = exports.OPF_CTA_FEATURE_NAME_CONSTANT = exports.OPF_GLOBAL_FUNCTIONS_DEFAULT_OCC_CART_CONFIG = exports.OPF_GLOBAL_FUNCTIONS_ROOT_MODULE = exports.OPF_GLOBAL_FUNCTIONS_MODULE = exports.OPF_GLOBAL_FUNCTIONS_FEATURE_NAME_CONSTANT = exports.OPF_BASE_ROOT_MODULE = exports.OPF_BASE_MODULE = exports.OPF_BASE_FEATURE_NAME_CONSTANT = exports.OPF_B2B_CHECKOUT_DEFAULT_OCC_ENDPOINTS_CONFIG = exports.OPF_B2B_CHECKOUT_ROOT_MODULE = exports.OPF_B2B_CHECKOUT_MODULE = exports.OPF_B2B_CHECKOUT_FEATURE_NAME_CONSTANT = exports.OPF_CHECKOUT_TRANSLATION_CHUNKS_CONFIG = exports.OPF_CHECKOUT_TRANSLATIONS = exports.OPF_CHECKOUT_ROOT_MODULE = exports.OPF_CHECKOUT_MODULE = exports.OPF_CHECKOUT_FEATURE_NAME_CONSTANT = exports.OPF_QUICKBUY_CONFIG = exports.OPF_CONFIG = exports.OPF_SCSS_FILE_NAME = exports.OPF_MODULE_NAME = exports.OPF_FOLDER_NAME = void 0;
exports.OPF_GIFT_CARD_SCHEMATICS_CONFIG = exports.OPF_TOKENISATION_SCHEMATICS_CONFIG = exports.OPF_QUICK_BUY_SCHEMATICS_CONFIG = void 0;
var libs_constants_1 = require("../../libs-constants");
var order_schematics_config_1 = require("../order-schematics-config");
exports.OPF_FOLDER_NAME = 'opf';
exports.OPF_MODULE_NAME = 'Opf';
exports.OPF_SCSS_FILE_NAME = 'opf.scss';
exports.OPF_CONFIG = 'OpfConfig';
exports.OPF_QUICKBUY_CONFIG = 'OpfQuickBuyConfig';
exports.OPF_CHECKOUT_FEATURE_NAME_CONSTANT = 'OPF_CHECKOUT_FEATURE';
exports.OPF_CHECKOUT_MODULE = 'OpfCheckoutModule';
exports.OPF_CHECKOUT_ROOT_MODULE = 'OpfCheckoutRootModule';
exports.OPF_CHECKOUT_TRANSLATIONS = 'opfCheckoutTranslations';
exports.OPF_CHECKOUT_TRANSLATION_CHUNKS_CONFIG = 'opfCheckoutTranslationChunksConfig';
exports.OPF_B2B_CHECKOUT_FEATURE_NAME_CONSTANT = 'OPF_B2B_CHECKOUT_FEATURE';
exports.OPF_B2B_CHECKOUT_MODULE = 'OpfB2bCheckoutModule';
exports.OPF_B2B_CHECKOUT_ROOT_MODULE = 'OpfB2bCheckoutRootModule';
exports.OPF_B2B_CHECKOUT_DEFAULT_OCC_ENDPOINTS_CONFIG = 'defaultOpfB2bCheckoutOccEndpointsConfig';
exports.OPF_BASE_FEATURE_NAME_CONSTANT = 'OPF_BASE_FEATURE';
exports.OPF_BASE_MODULE = 'OpfBaseModule';
exports.OPF_BASE_ROOT_MODULE = 'OpfBaseRootModule';
exports.OPF_GLOBAL_FUNCTIONS_FEATURE_NAME_CONSTANT = 'OPF_GLOBAL_FUNCTIONS_FEATURE';
exports.OPF_GLOBAL_FUNCTIONS_MODULE = 'OpfGlobalFunctionsModule';
exports.OPF_GLOBAL_FUNCTIONS_ROOT_MODULE = 'OpfGlobalFunctionsRootModule';
exports.OPF_GLOBAL_FUNCTIONS_DEFAULT_OCC_CART_CONFIG = 'defaultOccOpfCartConfig';
exports.OPF_CTA_FEATURE_NAME_CONSTANT = 'OPF_CTA_FEATURE';
exports.OPF_CTA_MODULE = 'OpfCtaModule';
exports.OPF_CTA_ROOT_MODULE = 'OpfCtaRootModule';
exports.OPF_QUICK_BUY_FEATURE_NAME_CONSTANT = 'OPF_QUICK_BUY_FEATURE';
exports.OPF_QUICK_BUY_MODULE = 'OpfQuickBuyModule';
exports.OPF_QUICK_BUY_ROOT_MODULE = 'OpfQuickBuyRootModule';
exports.OPF_TOKENISATION_FEATURE_NAME_CONSTANT = 'OPF_TOKENISATION_FEATURE';
exports.OPF_TOKENISATION_MODULE = 'OpfTokenisationModule';
exports.OPF_TOKENISATION_ROOT_MODULE = 'OpfTokenisationRootModule';
exports.OPF_PAYMENT_FEATURE_NAME_CONSTANT = 'OPF_PAYMENT_FEATURE';
exports.OPF_PAYMENT_MODULE = 'OpfPaymentModule';
exports.OPF_PAYMENT_ROOT_MODULE = 'OpfPaymentRootModule';
exports.OPF_PAYMENT_TRANSLATIONS = 'opfPaymentTranslations';
exports.OPF_PAYMENT_TRANSLATION_CHUNKS_CONFIG = 'opfPaymentTranslationChunksConfig';
exports.OPF_ORDER_MODULE = 'OpfOrderModule';
exports.OPF_GIFT_CARD_FEATURE_NAME_CONSTANT = 'OPF_GIFT_CARD_FEATURE';
exports.OPF_GIFT_CARD_MODULE = 'OpfGiftCardModule';
exports.OPF_GIFT_CARD_ROOT_MODULE = 'OpfGiftCardRootModule';
exports.OPF_GIFT_CARD_TRANSLATIONS = 'opfGiftCardTranslations';
exports.OPF_GIFT_CARD_TRANSLATION_CHUNKS_CONFIG = 'opfGiftCardTranslationChunksConfig';
exports.OPF_GIFT_CARD_DEFAULT_OCC_CART_CONFIG = 'defaultOccOpfGiftCardCartEndpointsConfig';
exports.OPF_GIFT_CARD_DEFAULT_OCC_ORDER_CONFIG = 'defaultOccOpfGiftCardOrderEndpointsConfig';
exports.OPF_GIFT_CARD_CART_CONFIG = 'defaultOpfGiftCardCartConfig';
exports.OPF_BASE_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.OPF_BASE_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_OPF,
        featureScope: libs_constants_1.SPARTACUS_OPF_BASE,
    },
    folderName: exports.OPF_FOLDER_NAME,
    moduleName: exports.OPF_MODULE_NAME,
    featureModule: {
        name: exports.OPF_BASE_MODULE,
        importPath: libs_constants_1.SPARTACUS_OPF_BASE,
    },
    rootModule: {
        name: exports.OPF_BASE_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_OPF_BASE_ROOT,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_OPF_BASE_ROOT,
        namedImports: [exports.OPF_BASE_FEATURE_NAME_CONSTANT],
    },
    styles: {
        scssFileName: exports.OPF_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_OPF,
        importStyles: [
            libs_constants_1.SPARTACUS_BOOTSTRAP_FUNCTIONS,
            libs_constants_1.SPARTACUS_BOOTSTRAP_VARIABLES,
            libs_constants_1.SPARTACUS_BOOTSTRAP_MIXINS,
        ],
    },
    customConfig: buildOpfConfig,
};
exports.OPF_PAYMENT_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.OPF_PAYMENT_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_OPF,
        featureScope: libs_constants_1.SPARTACUS_OPF_PAYMENT,
    },
    folderName: exports.OPF_FOLDER_NAME,
    moduleName: exports.OPF_MODULE_NAME,
    featureModule: {
        name: exports.OPF_PAYMENT_MODULE,
        importPath: libs_constants_1.SPARTACUS_OPF_PAYMENT,
    },
    rootModule: {
        name: exports.OPF_PAYMENT_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_OPF_PAYMENT_ROOT,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_OPF_PAYMENT_ROOT,
        namedImports: [exports.OPF_PAYMENT_FEATURE_NAME_CONSTANT],
    },
    i18n: {
        resources: exports.OPF_PAYMENT_TRANSLATIONS,
        chunks: exports.OPF_PAYMENT_TRANSLATION_CHUNKS_CONFIG,
        importPath: libs_constants_1.SPARTACUS_OPF_PAYMENT_ASSETS,
    },
    styles: {
        scssFileName: exports.OPF_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_OPF,
        importStyles: [
            libs_constants_1.SPARTACUS_BOOTSTRAP_FUNCTIONS,
            libs_constants_1.SPARTACUS_BOOTSTRAP_VARIABLES,
            libs_constants_1.SPARTACUS_BOOTSTRAP_MIXINS,
        ],
    },
    customConfig: buildOpfConfig,
};
exports.OPF_CHECKOUT_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.OPF_CHECKOUT_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_OPF,
        featureScope: libs_constants_1.SPARTACUS_OPF_CHECKOUT,
    },
    folderName: exports.OPF_FOLDER_NAME,
    moduleName: exports.OPF_MODULE_NAME,
    featureModule: [
        {
            name: exports.OPF_CHECKOUT_MODULE,
            importPath: libs_constants_1.SPARTACUS_OPF_CHECKOUT,
        },
        {
            name: exports.OPF_ORDER_MODULE,
            importPath: libs_constants_1.SPARTACUS_OPF_ORDER,
        },
    ],
    rootModule: {
        name: exports.OPF_CHECKOUT_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_OPF_CHECKOUT_ROOT,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_OPF_CHECKOUT_ROOT,
        namedImports: [exports.OPF_CHECKOUT_FEATURE_NAME_CONSTANT],
    },
    i18n: {
        resources: exports.OPF_CHECKOUT_TRANSLATIONS,
        chunks: exports.OPF_CHECKOUT_TRANSLATION_CHUNKS_CONFIG,
        importPath: libs_constants_1.SPARTACUS_OPF_CHECKOUT_ASSETS,
    },
    styles: {
        scssFileName: exports.OPF_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_OPF,
        importStyles: [
            libs_constants_1.SPARTACUS_BOOTSTRAP_FUNCTIONS,
            libs_constants_1.SPARTACUS_BOOTSTRAP_VARIABLES,
            libs_constants_1.SPARTACUS_BOOTSTRAP_MIXINS,
        ],
    },
    customConfig: buildOpfConfig,
    dependencyFeatures: [
        libs_constants_1.OPF_PAYMENT_FEATURE_NAME,
        libs_constants_1.OPF_BASE_FEATURE_NAME,
        libs_constants_1.OPF_CTA_FEATURE_NAME,
        libs_constants_1.OPF_GLOBAL_FUNCTIONS_FEATURE_NAME,
        libs_constants_1.OPF_QUICK_BUY_FEATURE_NAME,
        libs_constants_1.ORDER_FEATURE_NAME,
        libs_constants_1.OPF_GIFT_CARD_FEATURE_NAME,
    ],
    importAfter: [
        {
            markerModuleName: order_schematics_config_1.ORDER_MODULE,
            featureModuleName: exports.OPF_ORDER_MODULE,
        },
    ],
};
exports.OPF_B2B_CHECKOUT_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.OPF_B2B_CHECKOUT_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_OPF,
        featureScope: libs_constants_1.SPARTACUS_OPF_B2B_CHECKOUT,
        b2b: true,
    },
    folderName: exports.OPF_FOLDER_NAME,
    moduleName: exports.OPF_MODULE_NAME,
    featureModule: [
        {
            name: exports.OPF_B2B_CHECKOUT_MODULE,
            importPath: libs_constants_1.SPARTACUS_OPF_B2B_CHECKOUT,
        },
        {
            name: exports.OPF_ORDER_MODULE,
            importPath: libs_constants_1.SPARTACUS_OPF_ORDER,
        },
    ],
    rootModule: {
        name: exports.OPF_B2B_CHECKOUT_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_OPF_B2B_CHECKOUT_ROOT,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_OPF_B2B_CHECKOUT_ROOT,
        namedImports: [exports.OPF_B2B_CHECKOUT_FEATURE_NAME_CONSTANT],
    },
    styles: {
        scssFileName: exports.OPF_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_OPF,
        importStyles: [
            libs_constants_1.SPARTACUS_BOOTSTRAP_FUNCTIONS,
            libs_constants_1.SPARTACUS_BOOTSTRAP_VARIABLES,
            libs_constants_1.SPARTACUS_BOOTSTRAP_MIXINS,
        ],
    },
    customConfig: buildOpfB2bConfig,
    dependencyFeatures: [
        libs_constants_1.OPF_PAYMENT_FEATURE_NAME,
        libs_constants_1.OPF_BASE_FEATURE_NAME,
        libs_constants_1.OPF_CTA_FEATURE_NAME,
        libs_constants_1.OPF_GLOBAL_FUNCTIONS_FEATURE_NAME,
        libs_constants_1.OPF_QUICK_BUY_FEATURE_NAME,
        libs_constants_1.OPF_CHECKOUT_FEATURE_NAME,
        libs_constants_1.ORDER_FEATURE_NAME,
    ],
    importAfter: [
        {
            markerModuleName: order_schematics_config_1.ORDER_MODULE,
            featureModuleName: exports.OPF_ORDER_MODULE,
        },
    ],
};
exports.OPF_CTA_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.OPF_CTA_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_OPF,
        featureScope: libs_constants_1.SPARTACUS_OPF_CTA,
    },
    folderName: exports.OPF_FOLDER_NAME,
    moduleName: exports.OPF_MODULE_NAME,
    featureModule: {
        name: exports.OPF_CTA_MODULE,
        importPath: libs_constants_1.SPARTACUS_OPF_CTA,
    },
    rootModule: {
        name: exports.OPF_CTA_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_OPF_CTA_ROOT,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_OPF_CTA_ROOT,
        namedImports: [exports.OPF_CTA_FEATURE_NAME_CONSTANT],
    },
    styles: {
        scssFileName: exports.OPF_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_OPF,
        importStyles: [
            libs_constants_1.SPARTACUS_BOOTSTRAP_FUNCTIONS,
            libs_constants_1.SPARTACUS_BOOTSTRAP_VARIABLES,
            libs_constants_1.SPARTACUS_BOOTSTRAP_MIXINS,
        ],
    },
};
exports.OPF_GLOBAL_FUNCTIONS_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.OPF_GLOBAL_FUNCTIONS_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_OPF,
        featureScope: libs_constants_1.SPARTACUS_OPF_GLOBAL_FUNCTIONS,
    },
    folderName: exports.OPF_FOLDER_NAME,
    moduleName: exports.OPF_MODULE_NAME,
    featureModule: {
        name: exports.OPF_GLOBAL_FUNCTIONS_MODULE,
        importPath: libs_constants_1.SPARTACUS_OPF_GLOBAL_FUNCTIONS,
    },
    rootModule: {
        name: exports.OPF_GLOBAL_FUNCTIONS_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_OPF_GLOBAL_FUNCTIONS_ROOT,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_OPF_GLOBAL_FUNCTIONS_ROOT,
        namedImports: [exports.OPF_GLOBAL_FUNCTIONS_FEATURE_NAME_CONSTANT],
    },
    styles: {
        scssFileName: exports.OPF_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_OPF,
        importStyles: [
            libs_constants_1.SPARTACUS_BOOTSTRAP_FUNCTIONS,
            libs_constants_1.SPARTACUS_BOOTSTRAP_VARIABLES,
            libs_constants_1.SPARTACUS_BOOTSTRAP_MIXINS,
        ],
    },
    customConfig: buildOpfGlobalFunctionsConfig,
};
exports.OPF_QUICK_BUY_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.OPF_QUICK_BUY_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_OPF,
        featureScope: libs_constants_1.SPARTACUS_OPF_QUICK_BUY,
    },
    folderName: exports.OPF_FOLDER_NAME,
    moduleName: exports.OPF_MODULE_NAME,
    featureModule: {
        name: exports.OPF_QUICK_BUY_MODULE,
        importPath: libs_constants_1.SPARTACUS_OPF_QUICK_BUY,
    },
    rootModule: {
        name: exports.OPF_QUICK_BUY_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_OPF_QUICK_BUY_ROOT,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_OPF_QUICK_BUY_ROOT,
        namedImports: [exports.OPF_QUICK_BUY_FEATURE_NAME_CONSTANT],
    },
    styles: {
        scssFileName: exports.OPF_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_OPF,
        importStyles: [
            libs_constants_1.SPARTACUS_BOOTSTRAP_FUNCTIONS,
            libs_constants_1.SPARTACUS_BOOTSTRAP_VARIABLES,
            libs_constants_1.SPARTACUS_BOOTSTRAP_MIXINS,
        ],
    },
};
exports.OPF_TOKENISATION_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.OPF_TOKENISATION_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_OPF,
        featureScope: libs_constants_1.SPARTACUS_OPF_TOKENISATION,
    },
    folderName: exports.OPF_FOLDER_NAME,
    moduleName: exports.OPF_MODULE_NAME,
    featureModule: {
        name: exports.OPF_TOKENISATION_MODULE,
        importPath: libs_constants_1.SPARTACUS_OPF_TOKENISATION,
    },
    rootModule: {
        name: exports.OPF_TOKENISATION_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_OPF_TOKENISATION_ROOT,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_OPF_TOKENISATION_ROOT,
        namedImports: [exports.OPF_TOKENISATION_FEATURE_NAME_CONSTANT],
    },
    styles: {
        scssFileName: exports.OPF_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_OPF,
        importStyles: [
            libs_constants_1.SPARTACUS_BOOTSTRAP_FUNCTIONS,
            libs_constants_1.SPARTACUS_BOOTSTRAP_VARIABLES,
            libs_constants_1.SPARTACUS_BOOTSTRAP_MIXINS,
        ],
    },
};
exports.OPF_GIFT_CARD_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.OPF_GIFT_CARD_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_OPF,
        featureScope: libs_constants_1.SPARTACUS_OPF_GIFT_CARD,
    },
    folderName: exports.OPF_FOLDER_NAME,
    moduleName: exports.OPF_MODULE_NAME,
    featureModule: {
        name: exports.OPF_GIFT_CARD_MODULE,
        importPath: libs_constants_1.SPARTACUS_OPF_GIFT_CARD,
    },
    rootModule: {
        name: exports.OPF_GIFT_CARD_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_OPF_GIFT_CARD_ROOT,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_OPF_GIFT_CARD_ROOT,
        namedImports: [exports.OPF_GIFT_CARD_FEATURE_NAME_CONSTANT],
    },
    i18n: {
        resources: exports.OPF_GIFT_CARD_TRANSLATIONS,
        chunks: exports.OPF_GIFT_CARD_TRANSLATION_CHUNKS_CONFIG,
        importPath: libs_constants_1.SPARTACUS_OPF_GIFT_CARD_ASSETS,
    },
    styles: {
        scssFileName: exports.OPF_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_OPF,
        importStyles: [
            libs_constants_1.SPARTACUS_BOOTSTRAP_FUNCTIONS,
            libs_constants_1.SPARTACUS_BOOTSTRAP_VARIABLES,
            libs_constants_1.SPARTACUS_BOOTSTRAP_MIXINS,
        ],
    },
    customConfig: buildOpfGiftCardConfig,
};
function buildOpfConfig(options) {
    return {
        providers: {
            import: [
                {
                    moduleSpecifier: libs_constants_1.SPARTACUS_OPF_BASE_ROOT,
                    namedImports: [exports.OPF_CONFIG],
                },
            ],
            content: "<".concat(exports.OPF_CONFIG, ">{\n          opf: {\n            opfBaseUrl: \"").concat(options.opfBaseUrl || 'PLACEHOLDER_OPF_BASE_URL', "\",\n            commerceCloudPublicKey: \"").concat(options.commerceCloudPublicKey ||
                'PLACEHOLDER_COMMERCE_CLOUD_PUBLIC_KEY', "\",\n          },\n        }"),
        },
    };
}
function buildOpfGlobalFunctionsConfig(_options) {
    return {
        providers: {
            import: [
                {
                    moduleSpecifier: libs_constants_1.SPARTACUS_OPF_GLOBAL_FUNCTIONS_ROOT,
                    namedImports: [exports.OPF_GLOBAL_FUNCTIONS_DEFAULT_OCC_CART_CONFIG],
                },
            ],
            content: "".concat(exports.OPF_GLOBAL_FUNCTIONS_DEFAULT_OCC_CART_CONFIG),
        },
    };
}
function buildOpfB2bConfig(_options) {
    return {
        providers: {
            import: [
                {
                    moduleSpecifier: libs_constants_1.SPARTACUS_OPF_B2B_CHECKOUT_ROOT,
                    namedImports: [exports.OPF_B2B_CHECKOUT_DEFAULT_OCC_ENDPOINTS_CONFIG],
                },
            ],
            content: "".concat(exports.OPF_B2B_CHECKOUT_DEFAULT_OCC_ENDPOINTS_CONFIG),
        },
    };
}
function buildOpfGiftCardConfig(_options) {
    return {
        providers: [
            {
                import: [
                    {
                        moduleSpecifier: libs_constants_1.SPARTACUS_OPF_GIFT_CARD_ROOT,
                        namedImports: [exports.OPF_GIFT_CARD_DEFAULT_OCC_CART_CONFIG],
                    },
                ],
                content: "".concat(exports.OPF_GIFT_CARD_DEFAULT_OCC_CART_CONFIG),
            },
            {
                import: [
                    {
                        moduleSpecifier: libs_constants_1.SPARTACUS_OPF_GIFT_CARD_ROOT,
                        namedImports: [exports.OPF_GIFT_CARD_DEFAULT_OCC_ORDER_CONFIG],
                    },
                ],
                content: "".concat(exports.OPF_GIFT_CARD_DEFAULT_OCC_ORDER_CONFIG),
            },
            {
                import: [
                    {
                        moduleSpecifier: libs_constants_1.SPARTACUS_OPF_GIFT_CARD_ROOT,
                        namedImports: [exports.OPF_GIFT_CARD_CART_CONFIG],
                    },
                ],
                content: "".concat(exports.OPF_GIFT_CARD_CART_CONFIG),
            },
        ],
    };
}
//# sourceMappingURL=opf-schematics-config.js.map