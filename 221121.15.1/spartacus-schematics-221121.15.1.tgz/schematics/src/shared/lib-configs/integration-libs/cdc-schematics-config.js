"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CDC_SCHEMATICS_CONFIG = exports.CDC_B2B_SCHEMATICS_CONFIG = exports.CDC_TRANSLATIONS = exports.CDC_TRANSLATION_CHUNKS_CONFIG = exports.CDC_B2B_REGISTER_MODULE = exports.CDC_ADMINISTRATION_MODULE = exports.CDC_USER_PROFILE_MODULE = exports.CDC_USER_ACCOUNT_MODULE = exports.CDC_CONFIG = exports.CDC_FEATURE_CONSTANT = exports.CDC_ROOT_MODULE = exports.CDC_MODULE = exports.CDC_MODULE_NAME = exports.CDC_FOLDER_NAME = void 0;
var libs_constants_1 = require("../../libs-constants");
var organization_schematics_config_1 = require("../organization-schematics-config");
var user_schematics_config_1 = require("../user-schematics-config");
exports.CDC_FOLDER_NAME = 'cdc';
exports.CDC_MODULE_NAME = 'Cdc';
exports.CDC_MODULE = 'CdcModule';
exports.CDC_ROOT_MODULE = 'CdcRootModule';
exports.CDC_FEATURE_CONSTANT = 'CDC_FEATURE';
exports.CDC_CONFIG = 'CdcConfig';
exports.CDC_USER_ACCOUNT_MODULE = 'CDCUserAccountModule';
exports.CDC_USER_PROFILE_MODULE = 'CDCUserProfileModule';
exports.CDC_ADMINISTRATION_MODULE = 'CdcAdministrationModule';
exports.CDC_B2B_REGISTER_MODULE = 'CDCB2BRegisterModule';
exports.CDC_TRANSLATION_CHUNKS_CONFIG = 'cdcTranslationChunksConfig';
exports.CDC_TRANSLATIONS = 'cdcTranslations';
var CDC_SHARED_FEATURE_MODULES = [
    {
        importPath: libs_constants_1.SPARTACUS_CDC,
        name: exports.CDC_MODULE,
    },
    {
        name: exports.CDC_USER_ACCOUNT_MODULE,
        importPath: libs_constants_1.SPARTACUS_CDC_USER_ACCOUNT,
    },
    {
        name: exports.CDC_USER_PROFILE_MODULE,
        importPath: libs_constants_1.SPARTACUS_CDC_USER_PROFILE,
    },
];
var CDC_SHARED_IMPORT_AFTER = [
    {
        markerModuleName: user_schematics_config_1.USER_ACCOUNT_MODULE,
        featureModuleName: exports.CDC_USER_ACCOUNT_MODULE,
    },
    {
        markerModuleName: user_schematics_config_1.USER_PROFILE_MODULE,
        featureModuleName: exports.CDC_USER_PROFILE_MODULE,
    },
];
var CDC_SHARED_DEPENDENCY_FEATURES = [libs_constants_1.USER_PROFILE_FEATURE_NAME];
var CDC_SHARED_CONFIG = {
    folderName: exports.CDC_FOLDER_NAME,
    moduleName: exports.CDC_MODULE_NAME,
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_CDC_ROOT,
        namedImports: [exports.CDC_FEATURE_CONSTANT],
    },
    rootModule: {
        importPath: libs_constants_1.SPARTACUS_CDC_ROOT,
        name: exports.CDC_ROOT_MODULE,
        content: "".concat(exports.CDC_ROOT_MODULE),
    },
    customConfig: buildCdcConfig,
    i18n: {
        resources: exports.CDC_TRANSLATIONS,
        chunks: exports.CDC_TRANSLATION_CHUNKS_CONFIG,
        importPath: libs_constants_1.SPARTACUS_CDC_ASSETS,
    },
};
exports.CDC_B2B_SCHEMATICS_CONFIG = __assign(__assign({ library: {
        featureName: libs_constants_1.CDC_B2B_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_CDC,
        b2b: true,
    } }, CDC_SHARED_CONFIG), { featureModule: __spreadArray(__spreadArray([], CDC_SHARED_FEATURE_MODULES, true), [
        {
            name: exports.CDC_ADMINISTRATION_MODULE,
            importPath: libs_constants_1.SPARTACUS_CDC_ORGANIZATION_ADMINISTRATION,
        },
        {
            name: exports.CDC_B2B_REGISTER_MODULE,
            importPath: libs_constants_1.SPARTACUS_CDC_ORGANIZATION_REGISTRATION,
        },
    ], false), dependencyFeatures: __spreadArray(__spreadArray([], CDC_SHARED_DEPENDENCY_FEATURES, true), [
        libs_constants_1.ORGANIZATION_ADMINISTRATION_FEATURE_NAME,
        libs_constants_1.ORGANIZATION_USER_REGISTRATION_FEATURE_NAME,
    ], false), importAfter: __spreadArray(__spreadArray([], CDC_SHARED_IMPORT_AFTER, true), [
        {
            markerModuleName: organization_schematics_config_1.ADMINISTRATION_MODULE,
            featureModuleName: exports.CDC_ADMINISTRATION_MODULE,
        },
        {
            markerModuleName: organization_schematics_config_1.ORGANIZATION_USER_REGISTRATION_MODULE,
            featureModuleName: exports.CDC_B2B_REGISTER_MODULE,
        },
    ], false) });
exports.CDC_SCHEMATICS_CONFIG = __assign(__assign({ library: {
        featureName: libs_constants_1.CDC_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_CDC,
    } }, CDC_SHARED_CONFIG), { featureModule: __spreadArray([], CDC_SHARED_FEATURE_MODULES, true), dependencyFeatures: __spreadArray([], CDC_SHARED_DEPENDENCY_FEATURES, true), importAfter: __spreadArray([], CDC_SHARED_IMPORT_AFTER, true) });
function buildCdcConfig(options) {
    return {
        providers: {
            import: [
                {
                    moduleSpecifier: libs_constants_1.SPARTACUS_CDC_ROOT,
                    namedImports: [exports.CDC_CONFIG],
                },
            ],
            content: "<".concat(exports.CDC_CONFIG, ">{\n        cdc: [\n          {\n            baseSite: '").concat(options.baseSite || 'BASE_SITE_PLACEHOLDER', "',\n            javascriptUrl: '").concat(options.javascriptUrl || 'JS_SDK_URL_PLACEHOLDER', "',\n            sessionExpiration: ").concat(options.sessionExpiration || 3600, "\n          },\n        ],\n      }"),
        },
    };
}
//# sourceMappingURL=cdc-schematics-config.js.map