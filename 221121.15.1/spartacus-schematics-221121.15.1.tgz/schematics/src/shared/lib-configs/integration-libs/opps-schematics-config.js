"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.OPPS_SCHEMATICS_CONFIG = exports.OPPS_ROOT_MODULE = exports.OPPS_MODULE_NAME = exports.OPPS_FOLDER_NAME = void 0;
var libs_constants_1 = require("../../libs-constants");
exports.OPPS_FOLDER_NAME = 'opps';
exports.OPPS_MODULE_NAME = 'Opps';
exports.OPPS_ROOT_MODULE = 'OppsRootModule';
exports.OPPS_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.OPPS_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_OPPS,
    },
    folderName: exports.OPPS_FOLDER_NAME,
    moduleName: exports.OPPS_MODULE_NAME,
    featureModule: {
        name: exports.OPPS_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_OPPS,
    },
    rootModule: {
        importPath: libs_constants_1.SPARTACUS_OPPS_ROOT,
        name: exports.OPPS_ROOT_MODULE,
        content: "".concat(exports.OPPS_ROOT_MODULE),
    },
    /* Through Spartacus OPPS code does not have a dependency on Personalization,
    backend occ api of OPPS requires Personalization to be enabled , hence adding this dependency */
    dependencyFeatures: [libs_constants_1.TRACKING_PERSONALIZATION_FEATURE_NAME],
};
//# sourceMappingURL=opps-schematics-config.js.map