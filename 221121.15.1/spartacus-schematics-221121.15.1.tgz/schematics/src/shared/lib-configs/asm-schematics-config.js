"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ASM_CUSTOMER_360_SCHEMATICS_CONFIG = exports.ASM_CUSTOMER_360_TRANSLATION_CHUNKS_CONFIG = exports.ASM_CUSTOMER_360_TRANSLATIONS = exports.ASM_CUSTOMER_360_FEATURE_NAME_CONSTANT = exports.ASM_CUSTOMER_360_MODULE_NAME = exports.ASM_CUSTOMER_360_ROOT_MODULE = exports.ASM_CUSTOMER_360_MODULE = exports.ASM_SCHEMATICS_CONFIG = exports.ASM_SCSS_FILE_NAME = exports.ASM_TRANSLATION_CHUNKS_CONFIG = exports.ASM_TRANSLATIONS = exports.ASM_ROOT_MODULE = exports.ASM_MODULE = exports.ASM_FEATURE_NAME_CONSTANT = exports.ASM_FEATURE_MODULE_NAME = exports.ASM_FOLDER_NAME = void 0;
var libs_constants_1 = require("../libs-constants");
exports.ASM_FOLDER_NAME = 'asm';
exports.ASM_FEATURE_MODULE_NAME = 'Asm';
exports.ASM_FEATURE_NAME_CONSTANT = 'ASM_FEATURE';
exports.ASM_MODULE = 'AsmModule';
exports.ASM_ROOT_MODULE = 'AsmRootModule';
exports.ASM_TRANSLATIONS = 'asmTranslations';
exports.ASM_TRANSLATION_CHUNKS_CONFIG = 'asmTranslationChunksConfig';
exports.ASM_SCSS_FILE_NAME = 'asm.scss';
exports.ASM_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.ASM_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_ASM,
    },
    folderName: exports.ASM_FOLDER_NAME,
    moduleName: exports.ASM_FEATURE_MODULE_NAME,
    featureModule: {
        name: exports.ASM_MODULE,
        importPath: libs_constants_1.SPARTACUS_ASM,
    },
    rootModule: {
        name: exports.ASM_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_ASM_ROOT,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_ASM_ROOT,
        namedImports: [exports.ASM_FEATURE_NAME_CONSTANT],
    },
    styles: {
        scssFileName: exports.ASM_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_ASM,
    },
    i18n: {
        resources: exports.ASM_TRANSLATIONS,
        chunks: exports.ASM_TRANSLATION_CHUNKS_CONFIG,
        importPath: libs_constants_1.SPARTACUS_ASM_ASSETS,
    },
    dependencyFeatures: [libs_constants_1.USER_PROFILE_FEATURE_NAME],
};
exports.ASM_CUSTOMER_360_MODULE = 'AsmCustomer360Module';
exports.ASM_CUSTOMER_360_ROOT_MODULE = 'AsmCustomer360RootModule';
exports.ASM_CUSTOMER_360_MODULE_NAME = 'AsmCustomer360';
exports.ASM_CUSTOMER_360_FEATURE_NAME_CONSTANT = 'ASM_CUSTOMER_360_FEATURE';
exports.ASM_CUSTOMER_360_TRANSLATIONS = 'asmCustomer360Translations';
exports.ASM_CUSTOMER_360_TRANSLATION_CHUNKS_CONFIG = 'asmCustomer360TranslationChunksConfig';
exports.ASM_CUSTOMER_360_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.ASM_CUSTOMER_360_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_ASM,
        featureScope: libs_constants_1.SPARTACUS_ASM_CUSTOMER_360,
    },
    folderName: exports.ASM_FOLDER_NAME,
    moduleName: exports.ASM_CUSTOMER_360_MODULE_NAME,
    featureModule: {
        name: exports.ASM_CUSTOMER_360_MODULE,
        importPath: libs_constants_1.SPARTACUS_ASM_CUSTOMER_360,
    },
    rootModule: {
        name: exports.ASM_CUSTOMER_360_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_ASM_CUSTOMER_360_ROOT,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_ASM_CUSTOMER_360_ROOT,
        namedImports: [exports.ASM_CUSTOMER_360_FEATURE_NAME_CONSTANT],
    },
    i18n: {
        resources: exports.ASM_CUSTOMER_360_TRANSLATIONS,
        chunks: exports.ASM_CUSTOMER_360_TRANSLATION_CHUNKS_CONFIG,
        importPath: libs_constants_1.SPARTACUS_ASM_CUSTOMER_360_ASSETS,
    },
    styles: {
        scssFileName: exports.ASM_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_ASM,
    },
    dependencyFeatures: [
        libs_constants_1.ASM_FEATURE_NAME,
        libs_constants_1.STOREFINDER_FEATURE_NAME,
        libs_constants_1.ORDER_FEATURE_NAME,
    ],
};
//# sourceMappingURL=asm-schematics-config.js.map