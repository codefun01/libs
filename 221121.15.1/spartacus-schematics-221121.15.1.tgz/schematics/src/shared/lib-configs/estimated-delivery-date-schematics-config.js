"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ESTIMATED_DELIVERY_DATE_SCHEMATICS_CONFIG = exports.ESTIMATED_DELIVERY_DATE_SCSS_FILE_NAME = exports.ESTIMATED_DELIVERY_DATE_MODULE_NAME = exports.ESTIMATED_DELIVERY_DATE_MODULE = exports.ESTIMATED_DELIVERY_DATE_ROOT_MODULE = exports.ESTIMATED_DELIVERY_DATE_TRANSLATION_CHUNKS_CONFIG = exports.ESTIMATED_DELIVERY_DATE_TRANSLATIONS = exports.ESTIMATED_DELIVERY_DATE_FOLDER_NAME = exports.ESTIMATED_DELIVERY_DATE_FEATURE_NAME_CONSTANT = void 0;
var libs_constants_1 = require("../libs-constants");
var cart_schematics_config_1 = require("./cart-schematics-config");
exports.ESTIMATED_DELIVERY_DATE_FEATURE_NAME_CONSTANT = 'ESTIMATED_DELIVERY_DATE_FEATURE';
exports.ESTIMATED_DELIVERY_DATE_FOLDER_NAME = 'estimated-delivery-date';
exports.ESTIMATED_DELIVERY_DATE_TRANSLATIONS = 'estimatedDeliveryDateTranslations';
exports.ESTIMATED_DELIVERY_DATE_TRANSLATION_CHUNKS_CONFIG = 'estimatedDeliveryDateTranslationChunksConfig';
exports.ESTIMATED_DELIVERY_DATE_ROOT_MODULE = 'EstimatedDeliveryDateRootModule';
exports.ESTIMATED_DELIVERY_DATE_MODULE = 'EstimatedDeliveryDateModule';
exports.ESTIMATED_DELIVERY_DATE_MODULE_NAME = 'EstimatedDeliveryDate';
exports.ESTIMATED_DELIVERY_DATE_SCSS_FILE_NAME = 'estimated-delivery-date.scss';
exports.ESTIMATED_DELIVERY_DATE_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.ESTIMATED_DELIVERY_DATE_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_ESTIMATED_DELIVERY_DATE,
    },
    folderName: exports.ESTIMATED_DELIVERY_DATE_FOLDER_NAME,
    moduleName: exports.ESTIMATED_DELIVERY_DATE_MODULE_NAME,
    featureModule: {
        name: exports.ESTIMATED_DELIVERY_DATE_MODULE,
        importPath: libs_constants_1.SPARTACUS_ESTIMATED_DELIVERY_DATE,
    },
    rootModule: {
        name: exports.ESTIMATED_DELIVERY_DATE_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_ESTIMATED_DELIVERY_DATE_ROOT,
    },
    styles: {
        scssFileName: exports.ESTIMATED_DELIVERY_DATE_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_ESTIMATED_DELIVERY_DATE,
    },
    i18n: {
        resources: exports.ESTIMATED_DELIVERY_DATE_TRANSLATIONS,
        chunks: exports.ESTIMATED_DELIVERY_DATE_TRANSLATION_CHUNKS_CONFIG,
        importPath: libs_constants_1.SPARTACUS_ESTIMATED_DELIVERY_DATE_ASSETS,
    },
    dependencyFeatures: [libs_constants_1.CART_BASE_FEATURE_NAME],
    importAfter: [
        {
            markerModuleName: cart_schematics_config_1.CART_BASE_MODULE,
            featureModuleName: exports.ESTIMATED_DELIVERY_DATE_MODULE,
        },
    ],
};
//# sourceMappingURL=estimated-delivery-date-schematics-config.js.map