"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_SCHEMATICS_CONFIG = exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_TRANSLATION_CHUNKS_CONFIG = exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_TRANSLATIONS = exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_FEATURE_NAME_CONSTANT = exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_ROOT_MODULE_NAME = exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_MODULE = exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_MODULE_NAME = exports.PRODUCT_MULTI_DIMENSIONAL_LIST_SCHEMATICS_CONFIG = exports.PRODUCT_MULTI_DIMENSIONAL_LIST_ROOT_MODULE_NAME = exports.PRODUCT_MULTI_DIMENSIONAL_LIST_MODULE_NAME = exports.PRODUCT_MULTI_DIMENSIONAL_SCSS_FILE_NAME = exports.PRODUCT_MULTI_DIMENSIONAL_FOLDER_NAME = void 0;
var libs_constants_1 = require("../libs-constants");
exports.PRODUCT_MULTI_DIMENSIONAL_FOLDER_NAME = 'product-multi-dimensional';
exports.PRODUCT_MULTI_DIMENSIONAL_SCSS_FILE_NAME = 'product-multi-dimensional.scss';
exports.PRODUCT_MULTI_DIMENSIONAL_LIST_MODULE_NAME = 'ProductMultiDimensionalList';
exports.PRODUCT_MULTI_DIMENSIONAL_LIST_ROOT_MODULE_NAME = 'ProductMultiDimensionalListRootModule';
exports.PRODUCT_MULTI_DIMENSIONAL_LIST_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.PRODUCT_MULTI_DIMENSIONAL_LIST_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_PRODUCT_MULTI_DIMENSIONAL,
        featureScope: libs_constants_1.SPARTACUS_PRODUCT_MULTI_DIMENSIONAL_LIST,
    },
    folderName: exports.PRODUCT_MULTI_DIMENSIONAL_FOLDER_NAME,
    moduleName: exports.PRODUCT_MULTI_DIMENSIONAL_LIST_MODULE_NAME,
    featureModule: [],
    rootModule: {
        name: exports.PRODUCT_MULTI_DIMENSIONAL_LIST_ROOT_MODULE_NAME,
        importPath: libs_constants_1.SPARTACUS_PRODUCT_MULTI_DIMENSIONAL_LIST_ROOT,
    },
};
exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_MODULE_NAME = 'ProductMultiDimensionalSelector';
exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_MODULE = 'ProductMultiDimensionalSelectorModule';
exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_ROOT_MODULE_NAME = 'ProductMultiDimensionalSelectorRootModule';
exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_FEATURE_NAME_CONSTANT = 'PRODUCT_MULTI_DIMENSIONAL_SELECTOR_FEATURE';
exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_TRANSLATIONS = 'multiDimensionalSelectorTranslations';
exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_TRANSLATION_CHUNKS_CONFIG = 'multiDimensionalSelectorTranslationChunksConfig';
exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_PRODUCT_MULTI_DIMENSIONAL,
        featureScope: libs_constants_1.SPARTACUS_PRODUCT_MULTI_DIMENSIONAL_SELECTOR,
    },
    folderName: exports.PRODUCT_MULTI_DIMENSIONAL_FOLDER_NAME,
    moduleName: exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_MODULE_NAME,
    featureModule: [
        {
            name: exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_MODULE,
            importPath: libs_constants_1.SPARTACUS_PRODUCT_MULTI_DIMENSIONAL_SELECTOR,
        },
    ],
    rootModule: {
        name: exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_ROOT_MODULE_NAME,
        importPath: libs_constants_1.SPARTACUS_PRODUCT_MULTI_DIMENSIONAL_SELECTOR_ROOT,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_PRODUCT_MULTI_DIMENSIONAL_SELECTOR_ROOT,
        namedImports: [exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_FEATURE_NAME_CONSTANT],
    },
    styles: {
        scssFileName: exports.PRODUCT_MULTI_DIMENSIONAL_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_PRODUCT_MULTI_DIMENSIONAL,
        importStyles: [
            libs_constants_1.SPARTACUS_BOOTSTRAP_FUNCTIONS,
            libs_constants_1.SPARTACUS_BOOTSTRAP_VARIABLES,
            libs_constants_1.SPARTACUS_BOOTSTRAP_MIXINS,
        ],
    },
    i18n: {
        resources: exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_TRANSLATIONS,
        chunks: exports.PRODUCT_MULTI_DIMENSIONAL_SELECTOR_TRANSLATION_CHUNKS_CONFIG,
        importPath: libs_constants_1.SPARTACUS_PRODUCT_MULTI_DIMENSIONAL_SELECTOR_CONFIGURATOR_ASSETS,
    },
};
//# sourceMappingURL=product-multi-dimensional-schematics-config.js.map