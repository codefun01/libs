"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrate = migrate;
var missing_packages_1 = require("../../mechanism/missing-packages/missing-packages");
var MISSING_PACKAGE_DATA = [];
function migrate() {
    return function (tree, context) {
        for (var _i = 0, MISSING_PACKAGE_DATA_1 = MISSING_PACKAGE_DATA; _i < MISSING_PACKAGE_DATA_1.length; _i++) { // NOSONAR typescript:S4158
            var migrationData = MISSING_PACKAGE_DATA_1[_i];
            (0, missing_packages_1.migrateMissingPackage)(tree, context, migrationData);
        }
    };
}
//# sourceMappingURL=missing-packages.js.map