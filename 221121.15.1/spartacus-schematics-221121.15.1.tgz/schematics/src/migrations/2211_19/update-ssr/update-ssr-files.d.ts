import { Rule } from '@angular-devkit/schematics';
export declare function updateServerFiles(): Rule;
