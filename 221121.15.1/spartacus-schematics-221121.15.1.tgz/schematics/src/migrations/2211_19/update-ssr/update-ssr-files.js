"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateServerFiles = updateServerFiles;
var schematics_1 = require("@angular-devkit/schematics");
var ts = __importStar(require("typescript"));
var constants_1 = require("../../../shared/constants");
function updateServerFiles() {
    return (0, schematics_1.chain)([
        removeServer,
        modifyServerImports,
        removeExpressTokensFile,
        updateTokenImportPaths,
    ]);
}
function removeServer() {
    return function (tree, _context) {
        var serverPath;
        var serverBakPath;
        tree.visit(function (filePath) {
            var fileName = filePath.replace(/^.*[\\/]/, '');
            if (fileName === constants_1.SERVER_FILENAME) {
                serverPath = filePath;
            }
            if (fileName === constants_1.SERVER_BAK_FILENAME) {
                serverBakPath = filePath;
            }
        });
        if (serverPath && serverBakPath) {
            tree.delete(serverPath);
            tree.rename(serverBakPath, serverPath);
        }
    };
}
function modifyServerImports() {
    return function (tree, _context) {
        var serverFileBuffer = tree.read(constants_1.SERVER_FILENAME);
        if (!serverFileBuffer) {
            return tree;
        }
        var updateContent = serverFileBuffer.toString('utf-8');
        var hasOldImport = updateContent.includes(constants_1.OLD_ZONE_IMPORT) ||
            updateContent.includes(constants_1.NGUNIVERSAL_IMPORT);
        if (hasOldImport) {
            updateContent = updateContent.replace(constants_1.OLD_ZONE_IMPORT, constants_1.NEW_ZONE_IMPORT);
            updateContent = updateContent.replace(constants_1.NGUNIVERSAL_IMPORT, constants_1.SSR_SETUP_IMPORT);
            tree.overwrite(constants_1.SERVER_FILENAME, updateContent);
        }
        return tree;
    };
}
function removeExpressTokensFile() {
    return function (tree, _context) {
        tree.visit(function (filePath) {
            if (filePath.endsWith("".concat(constants_1.EXPRESS_TOKENS, ".ts"))) {
                tree.delete(filePath);
            }
        });
        return tree;
    };
}
function getExpressImportPaths(source) {
    var importPaths = [];
    source.statements.forEach(function (node) {
        if (ts.isImportDeclaration(node) &&
            ts.isStringLiteral(node.moduleSpecifier)) {
            var importPath = node.moduleSpecifier.text;
            if (importPath.includes(constants_1.EXPRESS_TOKENS)) {
                importPaths.push(importPath);
            }
        }
    });
    return importPaths;
}
function updateTokenImportPaths() {
    return function (tree, _context) {
        tree.visit(function (filePath) {
            if (filePath.endsWith('.ts')) {
                var fileContentBuffer = tree.read(filePath);
                if (fileContentBuffer) {
                    var fileContent = fileContentBuffer.toString('utf-8');
                    var source = ts.createSourceFile(filePath, fileContent, ts.ScriptTarget.Latest, true);
                    var importPaths = getExpressImportPaths(source);
                    if (importPaths.length) {
                        var importPathsRegex = new RegExp(importPaths.join('|'), 'g');
                        var updatedFileContent = fileContent.replace(importPathsRegex, constants_1.SSR_SETUP_IMPORT);
                        tree.overwrite(filePath, updatedFileContent);
                    }
                }
            }
        });
        return tree;
    };
}
//# sourceMappingURL=update-ssr-files.js.map