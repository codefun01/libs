"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.CONFIG_DEPRECATIONS_DATA = void 0;
exports.migrate = migrate;
var config_deprecation_1 = require("../../mechanism/config-deprecations/config-deprecation");
exports.CONFIG_DEPRECATIONS_DATA = [];
function migrate() {
    return function (tree, context) {
        return (0, config_deprecation_1.migrateConfigDeprecation)(tree, context, exports.CONFIG_DEPRECATIONS_DATA);
    };
}
//# sourceMappingURL=config-deprecations.js.map