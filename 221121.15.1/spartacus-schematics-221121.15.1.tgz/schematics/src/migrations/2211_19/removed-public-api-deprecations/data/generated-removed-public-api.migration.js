"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GENERATED_REMOVED_PUBLIC_API_DATA = void 0;
//
// Generated file, don't update manually.
//
exports.GENERATED_REMOVED_PUBLIC_API_DATA = [
    {
        node: 'UserService',
        importPath: '@spartacus/core',
        comment: '// TODO:Spartacus - Class UserService has been removed and is no longer part of the public API. ',
    },
    {
        node: 'LegacyExpressServerLogger',
        importPath: '@spartacus/setup/ssr',
        comment: '// TODO:Spartacus - Class LegacyExpressServerLogger has been removed and is no longer part of the public API. ',
    },
];
//# sourceMappingURL=generated-removed-public-api.migration.js.map