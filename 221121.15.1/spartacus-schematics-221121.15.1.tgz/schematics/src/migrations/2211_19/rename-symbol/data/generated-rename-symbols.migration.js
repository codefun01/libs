"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GENERATED_RENAMED_SYMBOLS_DATA = void 0;
//
// Generated file, don't update manually.
//
exports.GENERATED_RENAMED_SYMBOLS_DATA = [
    {
        previousNode: 'CardType',
        previousImportPath: '@spartacus/cart/base/root',
        newImportPath: '@spartacus/core',
    },
    {
        previousNode: 'PaymentDetails',
        previousImportPath: '@spartacus/cart/base/root',
        newImportPath: '@spartacus/core',
    },
    {
        previousNode: 'AddressBookComponent',
        previousImportPath: '@spartacus/storefront',
        newImportPath: '@spartacus/user/profile/components',
    },
    {
        previousNode: 'AddressBookComponentService',
        previousImportPath: '@spartacus/storefront',
        newImportPath: '@spartacus/user/profile/components',
    },
    {
        previousNode: 'AddressBookModule',
        previousImportPath: '@spartacus/storefront',
        newImportPath: '@spartacus/user/profile/components',
    },
    {
        previousNode: 'AddressFormComponent',
        previousImportPath: '@spartacus/storefront',
        newImportPath: '@spartacus/user/profile/components',
    },
    {
        previousNode: 'AddressFormModule',
        previousImportPath: '@spartacus/storefront',
        newImportPath: '@spartacus/user/profile/components',
    },
    {
        previousNode: 'SuggestedAddressDialogComponent',
        previousImportPath: '@spartacus/storefront',
        newImportPath: '@spartacus/user/profile/components',
    },
];
//# sourceMappingURL=generated-rename-symbols.migration.js.map