"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrate = migrate;
var add_spartacus_1 = require("../../../add-spartacus");
function migrate() {
    return function () {
        return (0, add_spartacus_1.createStylePreprocessorOptions)();
    };
}
//# sourceMappingURL=angular-json-styles.js.map