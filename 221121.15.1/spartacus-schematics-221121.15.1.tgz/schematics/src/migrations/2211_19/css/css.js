"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrate = migrate;
var constants_1 = require("../../../shared/constants");
function migrate() {
    return function (_tree, context) {
        context.logger.warn("For a CSS migration guide, please visit this URL: ".concat(constants_1.CSS_V6_DOCS_URL, ". Under the Installation and Upgrade header, select \u201CUpdating Composable Storefront\u201D for version 2211, and then open \u201CChanges to Styles in Composable Storefront 2211."));
    };
}
//# sourceMappingURL=css.js.map