var customerTicketing$w = {
	mainLogoLabel: "SAP",
	mainTitle: "Tikety zákazníka",
	ticketId: "ID",
	createdOn: "Datum vytvoření",
	changedOn: "Změněno dne",
	status: "Status",
	message: "Zpráva",
	cancel: "Zrušit",
	submit: "Odeslat",
	uploadFile: "Uploadovat soubor",
	fileSizeLimit: "Maximální velikost souboru: {{count}} MB",
	maximumAttachment: "Maximálně jedna příloha ke zprávě",
	errorMessage: "Něco se nepovedlo",
	charactersLeft: "zbývá znaků: {{count}}",
	customerService: "služby zákazníkům"
};
var customerTicketingList$g = {
	subject: "Předmět",
	ticketCategory: "Kategorie",
	sortSubtitle: "Řadit podle",
	sortOrders: "Seřadit objednávky",
	noTickets: "Nemáte žádné požadavky",
	requestTitle: "Všechny požadavky",
	mobile: {
		ticketIdFull: "ID tiketu"
	}
};
var createCustomerTicket$g = {
	createNewTicket: "Přidat",
	addNewRequest: "Přidat nový požadavek",
	addRequest: "Přidat požadavek",
	subject: "Předmět",
	category: "Kategorie",
	associateTo: "Přiřadit k",
	ticketCreated: "Požadavek vytvořen.",
	optionallySelectAssociatedObject: "Vybrat možnost",
	selectCategory: "Vybrat kategorii"
};
var customerTicketingDetails$g = {
	requestReopened: "Požadavek byl znovu otevřen.",
	requestClosed: "Požadavek byl uzavřen. V případě potřeby jej můžete znovu otevřít.",
	reopenRequest: "Znovu otevřít požadavek",
	closeRequest: "Uzavřít požadavek",
	ticketNotFound: "Tiket nebyl nalezen"
};
var customerTicketing$x = {
	customerTicketing: customerTicketing$w,
	customerTicketingList: customerTicketingList$g,
	createCustomerTicket: createCustomerTicket$g,
	customerTicketingDetails: customerTicketingDetails$g
};

var myAccountV2CustomerTicketing$w = {
	heading: "Služby zákazníkům",
	showMore: "Zobrazit více",
	showMoreLabel: "Přejít na historii servisních požadavků zákazníka",
	changedOn: "Změněno dne: {{value}}",
	ticketId: "ID: {{value}}",
	subjectLabel: "Předmět",
	idLabel: "ID služby zákazníkům"
};
var myAccountV2CustomerTicketing$x = {
	myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$w
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const cs = {
    customerTicketing: customerTicketing$x,
    myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$x,
};

var customerTicketing$u = {
	mainLogoLabel: "SAP",
	mainTitle: "Kunden-Ticketing",
	ticketId: "ID",
	createdOn: "Erstellt am",
	changedOn: "Geändert am",
	status: "Status",
	message: "Nachricht",
	cancel: "Abbrechen",
	submit: "Absenden",
	uploadFile: "Datei hochladen",
	fileSizeLimit: "Maximale Dateigröße: {{count}} MB",
	maximumAttachment: "Maximal ein Anhang pro Nachricht",
	errorMessage: "Es ist etwas schiefgegangen.",
	charactersLeft: "Zeichen übrig: {{count}}",
	customerService: "Kundenservice"
};
var customerTicketingList$f = {
	subject: "Betreff",
	ticketCategory: "Kategorie",
	sortSubtitle: "Sortieren nach",
	sortOrders: "Bestellungen sortieren",
	noTickets: "Sie haben keine Anfrage",
	requestTitle: "Alle Anfragen",
	mobile: {
		ticketIdFull: "Ticket-ID"
	}
};
var createCustomerTicket$f = {
	createNewTicket: "Hinzufügen",
	addNewRequest: "Neue Anfrage hinzufügen",
	addRequest: "Anfrage hinzufügen",
	subject: "Betreff",
	category: "Kategorie",
	associateTo: "Zuordnen zu",
	ticketCreated: "Anfrage erstellt.",
	optionallySelectAssociatedObject: "Selektionsoption",
	selectCategory: "Kategorie auswählen"
};
var customerTicketingDetails$f = {
	requestReopened: "Antrag erneut geöffnet.",
	requestClosed: "Anfrage geschlossen, Sie können sie bei Bedarf wieder öffnen",
	reopenRequest: "Anfrage wieder öffnen",
	closeRequest: "Anfrage schließen",
	ticketNotFound: "Ticket nicht gefunden."
};
var customerTicketing$v = {
	customerTicketing: customerTicketing$u,
	customerTicketingList: customerTicketingList$f,
	createCustomerTicket: createCustomerTicket$f,
	customerTicketingDetails: customerTicketingDetails$f
};

var myAccountV2CustomerTicketing$u = {
	heading: "Kundenservice",
	showMore: "Mehr anzeigen",
	showMoreLabel: "Zum Verlauf der Kundenserviceanforderungen navigieren ",
	changedOn: "Geändert am: {{value}}",
	ticketId: "ID: {{value}}",
	subjectLabel: "Betreff",
	idLabel: "Kundenservice-ID"
};
var myAccountV2CustomerTicketing$v = {
	myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$u
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const de = {
    customerTicketing: customerTicketing$v,
    myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$v,
};

var customerTicketing$s = {
	mainLogoLabel: "SAP",
	mainTitle: "Customer Ticketing",
	ticketId: "ID",
	createdOn: "Created On",
	changedOn: "Changed On",
	status: "Status",
	message: "Message",
	cancel: "Cancel",
	submit: "Submit",
	uploadFile: "Upload File",
	fileSizeLimit: "File size limit: {{count}} MB",
	maximumAttachment: "Maximum of one attachment per message",
	errorMessage: "Something went wrong.",
	charactersLeft: "characters left: {{count}}",
	customerService: "Customer Service"
};
var customerTicketingList$e = {
	subject: "Subject",
	ticketCategory: "Category",
	sortSubtitle: "Sort by",
	sortOrders: "Sort orders",
	noTickets: "You don't have any request",
	requestTitle: "All Requests",
	mobile: {
		ticketIdFull: "Ticket ID"
	}
};
var createCustomerTicket$e = {
	createNewTicket: "Add",
	addNewRequest: "Add New Request",
	addRequest: "Add Request",
	subject: "Subject",
	category: "Category",
	associateTo: "Associate To",
	ticketCreated: "Request created.",
	optionallySelectAssociatedObject: "Select Option",
	selectCategory: "Select Category"
};
var customerTicketingDetails$e = {
	requestReopened: "Request Reopened.",
	requestClosed: "Request closed, you may reopen if needed.",
	reopenRequest: "Reopen Request",
	closeRequest: "Close Request",
	ticketNotFound: "Ticket not found."
};
var customerTicketing$t = {
	customerTicketing: customerTicketing$s,
	customerTicketingList: customerTicketingList$e,
	createCustomerTicket: createCustomerTicket$e,
	customerTicketingDetails: customerTicketingDetails$e
};

var myAccountV2CustomerTicketing$s = {
	heading: "Customer Service",
	showMore: "Show More",
	showMoreLabel: "Navigate to customer service requests history",
	changedOn: "Changed On: {{value}}",
	ticketId: "ID: {{value}}",
	subjectLabel: "Subject",
	idLabel: "Customer Service Id"
};
var myAccountV2CustomerTicketing$t = {
	myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$s
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const en = {
    customerTicketing: customerTicketing$t,
    myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$t,
};

var customerTicketing$q = {
	mainLogoLabel: "SAP",
	mainTitle: "Tickets de cliente",
	ticketId: "ID",
	createdOn: "Fecha de creación",
	changedOn: "Fecha de modificación",
	status: "Estado",
	message: "Mensaje",
	cancel: "Cancelar",
	submit: "Enviar",
	uploadFile: "Cargar fichero",
	fileSizeLimit: "Límite de tamaño del fichero: {{count}} MB",
	maximumAttachment: "Máximo un anexo por mensaje",
	errorMessage: "Algo ha fallado.",
	charactersLeft: "caracteres restantes: {{count}}",
	customerService: "Servicio de atención al cliente"
};
var customerTicketingList$d = {
	subject: "Asunto",
	ticketCategory: "Categoría",
	sortSubtitle: "Ordenar por",
	sortOrders: "Órdenes de clasificación",
	noTickets: "No tiene ninguna solicitud",
	requestTitle: "Todas las solicitudes",
	mobile: {
		ticketIdFull: "ID de ticket"
	}
};
var createCustomerTicket$d = {
	createNewTicket: "Añadir",
	addNewRequest: "Añadir solicitud nueva",
	addRequest: "Añadir solicitud",
	subject: "Asunto",
	category: "Categoría",
	associateTo: "Asociar a",
	ticketCreated: "Se ha creado la solicitud.",
	optionallySelectAssociatedObject: "Seleccionar opción",
	selectCategory: "Seleccionar categoría"
};
var customerTicketingDetails$d = {
	requestReopened: "Se ha vuelto a abrir la solicitud.",
	requestClosed: "Solicitud cerrada. Puede volver a abrirla de ser necesario.",
	reopenRequest: "Volver a abrir solicitud",
	closeRequest: "Cerrar solicitud",
	ticketNotFound: "El ticket no existe."
};
var customerTicketing$r = {
	customerTicketing: customerTicketing$q,
	customerTicketingList: customerTicketingList$d,
	createCustomerTicket: createCustomerTicket$d,
	customerTicketingDetails: customerTicketingDetails$d
};

var myAccountV2CustomerTicketing$q = {
	heading: "Servicio de atención al cliente",
	showMore: "Mostrar más",
	showMoreLabel: "Ir al historial de solicitudes del servicio de atención al cliente",
	changedOn: "Fecha de modificación: {{value}}",
	ticketId: "ID: {{value}}",
	subjectLabel: "Asunto",
	idLabel: "ID del servicio de atención al cliente"
};
var myAccountV2CustomerTicketing$r = {
	myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$q
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const es = {
    customerTicketing: customerTicketing$r,
    myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$r,
};

var customerTicketing$o = {
	mainLogoLabel: "SAP",
	mainTitle: "Tickets de cliente",
	ticketId: "ID",
	createdOn: "Fecha de creación",
	changedOn: "Fecha de modificación",
	status: "Estado",
	message: "Mensaje",
	cancel: "Cancelar",
	submit: "Enviar",
	uploadFile: "Cargar archivo",
	fileSizeLimit: "Límite de tamaño del archivo: {{count}} MB",
	maximumAttachment: "Máximo un archivo adjunto por mensaje",
	errorMessage: "Algo salió mal.",
	charactersLeft: "caracteres restantes: {{count}}",
	customerService: "Servicio de atención al cliente"
};
var customerTicketingList$c = {
	subject: "Asunto",
	ticketCategory: "Categoría",
	sortSubtitle: "Clasificar por",
	sortOrders: "Órdenes de clasificación",
	noTickets: "No tiene ninguna solicitud",
	requestTitle: "Todas las solicitudes",
	mobile: {
		ticketIdFull: "ID de ticket"
	}
};
var createCustomerTicket$c = {
	createNewTicket: "Agregar",
	addNewRequest: "Agregar solicitud nueva",
	addRequest: "Agregar solicitud",
	subject: "Asunto",
	category: "Categoría",
	associateTo: "Asociar a",
	ticketCreated: "Solicitud creada.",
	optionallySelectAssociatedObject: "Seleccionar opción",
	selectCategory: "Seleccionar categoría"
};
var customerTicketingDetails$c = {
	requestReopened: "Se volvió a abrir la solicitud.",
	requestClosed: "Solicitud cerrada. Puede volver a abrirla de ser necesario.",
	reopenRequest: "Volver a abrir solicitud",
	closeRequest: "Cerrar solicitud",
	ticketNotFound: "El ticket no existe."
};
var customerTicketing$p = {
	customerTicketing: customerTicketing$o,
	customerTicketingList: customerTicketingList$c,
	createCustomerTicket: createCustomerTicket$c,
	customerTicketingDetails: customerTicketingDetails$c
};

var myAccountV2CustomerTicketing$o = {
	heading: "Servicio de atención al cliente",
	showMore: "Mostrar más",
	showMoreLabel: "Ir al historial de solicitudes del servicio de atención al cliente",
	changedOn: "Fecha de modificación: {{value}}",
	ticketId: "ID: {{value}}",
	subjectLabel: "Asunto",
	idLabel: "ID del servicio de atención al cliente"
};
var myAccountV2CustomerTicketing$p = {
	myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$o
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const es_CO = {
    customerTicketing: customerTicketing$p,
    myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$p,
};

var customerTicketing$m = {
	mainLogoLabel: "SAP",
	mainTitle: "Gestion des tickets clients",
	ticketId: "ID",
	createdOn: "Créé le",
	changedOn: "Modifié le",
	status: "Statut",
	message: "Message",
	cancel: "Annuler",
	submit: "Envoyer",
	uploadFile: "Charger un fichier",
	fileSizeLimit: "Limite de taille du fichier : {{count}} Mo",
	maximumAttachment: "Une pièce jointe au maximum par message",
	errorMessage: "Une erreur s'est produite.",
	charactersLeft: "Caractères restants : {{count}}",
	customerService: "Service clients"
};
var customerTicketingList$b = {
	subject: "Objet",
	ticketCategory: "Catégorie",
	sortSubtitle: "Trier par",
	sortOrders: "Trier les commandes",
	noTickets: "Vous n'avez aucune demande",
	requestTitle: "Toutes les demandes",
	mobile: {
		ticketIdFull: "ID de ticket"
	}
};
var createCustomerTicket$b = {
	createNewTicket: "Ajouter",
	addNewRequest: "Ajouter une nouvelle demande",
	addRequest: "Ajouter une demande",
	subject: "Objet",
	category: "Catégorie",
	associateTo: "Associer à",
	ticketCreated: "Demande créée",
	optionallySelectAssociatedObject: "Sélectionner l'option",
	selectCategory: "Sélectionner la catégorie"
};
var customerTicketingDetails$b = {
	requestReopened: "demande rouverte",
	requestClosed: "Demande clôturée, vous pouvez la rouvrir si nécessaire.",
	reopenRequest: "Rouvrir la demande",
	closeRequest: "Clôturer la demande",
	ticketNotFound: "Ticket non trouvé"
};
var customerTicketing$n = {
	customerTicketing: customerTicketing$m,
	customerTicketingList: customerTicketingList$b,
	createCustomerTicket: createCustomerTicket$b,
	customerTicketingDetails: customerTicketingDetails$b
};

var myAccountV2CustomerTicketing$m = {
	heading: "Service clients",
	showMore: "Afficher plus",
	showMoreLabel: "Naviguer jusqu'à l'historique des demandes du service clients",
	changedOn: "Modifié le : {{value}}",
	ticketId: "ID : {{value}}",
	subjectLabel: "Objet",
	idLabel: "ID du service clients"
};
var myAccountV2CustomerTicketing$n = {
	myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$m
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const fr = {
    customerTicketing: customerTicketing$n,
    myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$n,
};

var customerTicketing$k = {
	mainLogoLabel: "SAP",
	mainTitle: "ग्राहक टिकटिंग",
	ticketId: "ID",
	createdOn: "निर्माण दिनांक",
	changedOn: "परिवर्तन दिनांक",
	status: "स्थिति",
	message: "संदेश",
	cancel: "रद्द करें",
	submit: "सबमिट करें",
	uploadFile: "फ़ाइल अपलोड करें",
	fileSizeLimit: "फ़ाइल आकार सीमा: {{count}} MB",
	maximumAttachment: "अधिकतम एक अनुलग्नक प्रति संदेश",
	errorMessage: "कुछ गलत हुआ है.",
	charactersLeft: "वर्ण बचे हैंः  {{count}}",
	customerService: "ग्राहक सेवा"
};
var customerTicketingList$a = {
	subject: "विषय",
	ticketCategory: "श्रेणी",
	sortSubtitle: "इसके द्वारा क्रमित",
	sortOrders: "ऑर्डर क्रमित करें",
	noTickets: "आपके पास कोई अनुरोध नहीं है",
	requestTitle: "सभी अनुरोध",
	mobile: {
		ticketIdFull: "टिकट ID"
	}
};
var createCustomerTicket$a = {
	createNewTicket: "जोड़ें",
	addNewRequest: "नया अनुरोध जोड़ें",
	addRequest: "अनुरोध जोड़ें",
	subject: "विषय",
	category: "श्रेणी",
	associateTo: "इससे संबंधित",
	ticketCreated: "अनुरोध बनाया गया.",
	optionallySelectAssociatedObject: "विकल्प का चयन करें",
	selectCategory: "श्रेणी का चयन करें"
};
var customerTicketingDetails$a = {
	requestReopened: "अनुरोध का प्रतिसाद दिया गया.",
	requestClosed: "अनुरोध बंद किया गया. आवश्यकता हो तो आप प्रतिसाद दे सकते हैं.",
	reopenRequest: "प्रतिसाद अनुरोध",
	closeRequest: "अनुरोध बंद करें",
	ticketNotFound: "टिकट हीं मिला."
};
var customerTicketing$l = {
	customerTicketing: customerTicketing$k,
	customerTicketingList: customerTicketingList$a,
	createCustomerTicket: createCustomerTicket$a,
	customerTicketingDetails: customerTicketingDetails$a
};

var myAccountV2CustomerTicketing$k = {
	heading: "ग्राहक सेवा",
	showMore: "अधिक दिखाएं",
	showMoreLabel: "ग्राहक सेवा अनुरोध इतिहास पर नेविगेट करें",
	changedOn: "परिवर्तन दिनांक: {{value}}",
	ticketId: "ID: {{value}}",
	subjectLabel: "विषय",
	idLabel: "ग्राहक सेवा Id"
};
var myAccountV2CustomerTicketing$l = {
	myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$k
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const hi = {
    customerTicketing: customerTicketing$l,
    myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$l,
};

var customerTicketing$i = {
	mainLogoLabel: "SAP",
	mainTitle: "Ügyféljegyek kezelése",
	ticketId: "Azonosító",
	createdOn: "Létrehozás dátuma",
	changedOn: "Módosítás dátuma",
	status: "Státus",
	message: "Üzenet",
	cancel: "Mégse",
	submit: "Elküldés",
	uploadFile: "Fájl feltöltése",
	fileSizeLimit: "Maximális fájlméret: {{count}} MB",
	maximumAttachment: "Legfeljebb egy csatolmány üzenetenként",
	errorMessage: "Hiba történt.",
	charactersLeft: "hátralévő karakterek: {{count}}",
	customerService: "Ügyfélszolgálat"
};
var customerTicketingList$9 = {
	subject: "Tárgy",
	ticketCategory: "Kategória",
	sortSubtitle: "Rendezés alapja",
	sortOrders: "Rendezési sorrend",
	noTickets: "Nincsenek kérései",
	requestTitle: "Összes kérés",
	mobile: {
		ticketIdFull: "Jegyazonosító"
	}
};
var createCustomerTicket$9 = {
	createNewTicket: "Hozzáadás",
	addNewRequest: "Új kérés hozzáadása",
	addRequest: "Kérés hozzáadása",
	subject: "Tárgy",
	category: "Kategória",
	associateTo: "Társítás:",
	ticketCreated: "Kérés létrehozva.",
	optionallySelectAssociatedObject: "Beállítás kiválasztása",
	selectCategory: "Kategória kiválasztása"
};
var customerTicketingDetails$9 = {
	requestReopened: "Kérés újranyitva.",
	requestClosed: "Kérés lezárva; szükség esetén újranyithatja.",
	reopenRequest: "Kérés újranyitása",
	closeRequest: "Kérés lezárása",
	ticketNotFound: "Jegy nem található."
};
var customerTicketing$j = {
	customerTicketing: customerTicketing$i,
	customerTicketingList: customerTicketingList$9,
	createCustomerTicket: createCustomerTicket$9,
	customerTicketingDetails: customerTicketingDetails$9
};

var myAccountV2CustomerTicketing$i = {
	heading: "Ügyfélszolgálat",
	showMore: "Több megjelenítése",
	showMoreLabel: "Navigálás az ügyfélszolgálati kérelmek előzményeire",
	changedOn: "Módosítás dátuma: {{value}}",
	ticketId: "Azonosító: {{value}}",
	subjectLabel: "Tárgy",
	idLabel: "Ügyfélszolgálati azonosító"
};
var myAccountV2CustomerTicketing$j = {
	myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$i
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const hu = {
    customerTicketing: customerTicketing$j,
    myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$j,
};

var customerTicketing$g = {
	mainLogoLabel: "SAP",
	mainTitle: "Pertiketan Pelanggan",
	ticketId: "ID",
	createdOn: "Dibuat Pada",
	changedOn: "Diubah Pada",
	status: "Status",
	message: "Pesan",
	cancel: "Batal",
	submit: "Kirim",
	uploadFile: "Unggah File",
	fileSizeLimit: "Batas ukuran file: {{count}} MB",
	maximumAttachment: "Maksimal satu lampiran per pesan",
	errorMessage: "Terjadi kesalahan.",
	charactersLeft: "karakter tersisa: {{count}}",
	customerService: "Layanan Pelanggan"
};
var customerTicketingList$8 = {
	subject: "Subjek",
	ticketCategory: "Kategori",
	sortSubtitle: "Urutkan berdasarkan",
	sortOrders: "Pengaturan urutan",
	noTickets: "Anda tidak memiliki permintaan apa pun",
	requestTitle: "Semua Permintaan",
	mobile: {
		ticketIdFull: "ID Tiket"
	}
};
var createCustomerTicket$8 = {
	createNewTicket: "Tambahkan",
	addNewRequest: "Tambahkan Permintaan Baru",
	addRequest: "Tambahkan Permintaan",
	subject: "Subjek",
	category: "Kategori",
	associateTo: "Hubungkan Ke",
	ticketCreated: "Permintaan dibuat.",
	optionallySelectAssociatedObject: "Pilih Opsi",
	selectCategory: "Pilih Kategori"
};
var customerTicketingDetails$8 = {
	requestReopened: "Permintaan Dibuka Kembali.",
	requestClosed: "Permintaan ditutup, tetapi dapat dibuka kembali jika diperlukan.",
	reopenRequest: "Buka Kembali Permintaan",
	closeRequest: "Tutup Permintaan",
	ticketNotFound: "Tiket tidak ditemukan."
};
var customerTicketing$h = {
	customerTicketing: customerTicketing$g,
	customerTicketingList: customerTicketingList$8,
	createCustomerTicket: createCustomerTicket$8,
	customerTicketingDetails: customerTicketingDetails$8
};

var myAccountV2CustomerTicketing$g = {
	heading: "Layanan Pelanggan",
	showMore: "Tampilkan Lebih Banyak",
	showMoreLabel: "Arahkan ke riwayat permintaan layanan pelanggan",
	changedOn: "Diubah Pada: {{value}}",
	ticketId: "ID: {{value}}",
	subjectLabel: "Subjek",
	idLabel: "Id Layanan Pelanggan"
};
var myAccountV2CustomerTicketing$h = {
	myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$g
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const id = {
    customerTicketing: customerTicketing$h,
    myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$h,
};

var customerTicketing$e = {
	mainLogoLabel: "SAP",
	mainTitle: "Creazione di ticket cliente",
	ticketId: "ID",
	createdOn: "Data di creazione",
	changedOn: "Data di modifica",
	status: "Stato",
	message: "Messaggio",
	cancel: "Annulla",
	submit: "Invia",
	uploadFile: "Carica file",
	fileSizeLimit: "Limite dimensione file: {{count}} MB",
	maximumAttachment: "Al massimo un allegato per ciascun messaggio",
	errorMessage: "Si è verificato un errore.",
	charactersLeft: "caratteri rimanenti: {{count}}",
	customerService: "Servizio clienti"
};
var customerTicketingList$7 = {
	subject: "Oggetto",
	ticketCategory: "Categoria",
	sortSubtitle: "Ordina per",
	sortOrders: "Ordina ordini",
	noTickets: "Non sono presenti richieste",
	requestTitle: "Tutte le richieste",
	mobile: {
		ticketIdFull: "ID ticket"
	}
};
var createCustomerTicket$7 = {
	createNewTicket: "Aggiungi",
	addNewRequest: "Aggiungi nuova richiesta",
	addRequest: "Aggiungi richiesta",
	subject: "Oggetto",
	category: "Categoria",
	associateTo: "Associa a",
	ticketCreated: "Richiesta creata.",
	optionallySelectAssociatedObject: "Seleziona opzione",
	selectCategory: "Seleziona categoria"
};
var customerTicketingDetails$7 = {
	requestReopened: "Richiesta riaperta.",
	requestClosed: "Richiesta chiusa; se necessario è possibile riaprila.",
	reopenRequest: "Riapri richiesta",
	closeRequest: "Chiudi richiesta",
	ticketNotFound: "Ticket non trovato."
};
var customerTicketing$f = {
	customerTicketing: customerTicketing$e,
	customerTicketingList: customerTicketingList$7,
	createCustomerTicket: createCustomerTicket$7,
	customerTicketingDetails: customerTicketingDetails$7
};

var myAccountV2CustomerTicketing$e = {
	heading: "Servizio clienti",
	showMore: "Mostra di più",
	showMoreLabel: "Passa alla cronologia delle richieste di servizio clienti",
	changedOn: "Data modifica: {{value}}",
	ticketId: "ID: {{value}}",
	subjectLabel: "Oggetto",
	idLabel: "ID servizio clienti"
};
var myAccountV2CustomerTicketing$f = {
	myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$e
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const it = {
    customerTicketing: customerTicketing$f,
    myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$f,
};

var customerTicketing$c = {
	mainLogoLabel: "SAP",
	mainTitle: "顧客チケット",
	ticketId: "ID",
	createdOn: "作成日付",
	changedOn: "変更日付",
	status: "ステータス",
	message: "メッセージ",
	cancel: "キャンセル",
	submit: "送信",
	uploadFile: "ファイルのアップロード",
	fileSizeLimit: "ファイルサイズ制限: {{count}} MB",
	maximumAttachment: "メッセージごとの 1 添付ファイルの最大",
	errorMessage: "問題が発生しました。",
	charactersLeft: "残り文字数: {{count}}",
	customerService: "カスタマーサービス"
};
var customerTicketingList$6 = {
	subject: "件名",
	ticketCategory: "カテゴリ",
	sortSubtitle: "ソート基準",
	sortOrders: "ソート順序",
	noTickets: "申請がありません",
	requestTitle: "すべての申請",
	mobile: {
		ticketIdFull: "チケット ID"
	}
};
var createCustomerTicket$6 = {
	createNewTicket: "追加",
	addNewRequest: "新しい申請の追加",
	addRequest: "申請の追加",
	subject: "件名",
	category: "カテゴリ",
	associateTo: "関連付け",
	ticketCreated: "申請が作成されました。",
	optionallySelectAssociatedObject: "オプションの選択",
	selectCategory: "カテゴリの選択"
};
var customerTicketingDetails$6 = {
	requestReopened: "申請が再開されました。",
	requestClosed: "申請は終了しました。必要に応じて再開することができます。",
	reopenRequest: "再開申請",
	closeRequest: "申請の終了",
	ticketNotFound: "チケットが見つかりません。"
};
var customerTicketing$d = {
	customerTicketing: customerTicketing$c,
	customerTicketingList: customerTicketingList$6,
	createCustomerTicket: createCustomerTicket$6,
	customerTicketingDetails: customerTicketingDetails$6
};

var myAccountV2CustomerTicketing$c = {
	heading: "カスタマーサービス",
	showMore: "さらに表示",
	showMoreLabel: "カスタマーサービス依頼履歴へナビゲート",
	changedOn: "変更日: {{value}}",
	ticketId: "ID: {{value}}",
	subjectLabel: "件名",
	idLabel: "カスタマーサービス ID"
};
var myAccountV2CustomerTicketing$d = {
	myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$c
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ja = {
    customerTicketing: customerTicketing$d,
    myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$d,
};

var customerTicketing$a = {
	mainLogoLabel: "SAP",
	mainTitle: "고객 티케팅",
	ticketId: "ID",
	createdOn: "작성일",
	changedOn: "변경일",
	status: "상태",
	message: "메시지",
	cancel: "취소",
	submit: "제출",
	uploadFile: "파일 업로드",
	fileSizeLimit: "파일 크기 한도: {{count}}MB",
	maximumAttachment: "메시지별 최대 한 개의 첨부 파일",
	errorMessage: "문제가 발생했습니다.",
	charactersLeft: "{{count}}자 남음",
	customerService: "고객 서비스"
};
var customerTicketingList$5 = {
	subject: "제목",
	ticketCategory: "범주",
	sortSubtitle: "정렬 기준",
	sortOrders: "정렬 순서",
	noTickets: "요청이 없습니다.",
	requestTitle: "모든 요청",
	mobile: {
		ticketIdFull: "티켓 ID"
	}
};
var createCustomerTicket$5 = {
	createNewTicket: "추가",
	addNewRequest: "새 요청 추가",
	addRequest: "요청 추가",
	subject: "제목",
	category: "범주",
	associateTo: "연계 대상",
	ticketCreated: "요청이 작성되었습니다.",
	optionallySelectAssociatedObject: "옵션 선택",
	selectCategory: "범주 선택"
};
var customerTicketingDetails$5 = {
	requestReopened: "요청을 다시 열었습니다.",
	requestClosed: "요청을 닫았습니다. 필요하면 다시 열 수 있습니다.",
	reopenRequest: "요청 다시 열기",
	closeRequest: "요청 닫기",
	ticketNotFound: "티켓이 없습니다."
};
var customerTicketing$b = {
	customerTicketing: customerTicketing$a,
	customerTicketingList: customerTicketingList$5,
	createCustomerTicket: createCustomerTicket$5,
	customerTicketingDetails: customerTicketingDetails$5
};

var myAccountV2CustomerTicketing$a = {
	heading: "고객 서비스",
	showMore: "자세히 보기",
	showMoreLabel: "고객 서비스 요청 이력으로 이동",
	changedOn: "변경일: {{value}}",
	ticketId: "ID: {{value}}",
	subjectLabel: "제목",
	idLabel: "고객 서비스 ID"
};
var myAccountV2CustomerTicketing$b = {
	myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$a
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ko = {
    customerTicketing: customerTicketing$b,
    myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$b,
};

var customerTicketing$8 = {
	mainLogoLabel: "SAP",
	mainTitle: "Zgłoszenie klienta",
	ticketId: "ID",
	createdOn: "Data utworzenia",
	changedOn: "Data zmiany",
	status: "Status",
	message: "Wiadomość",
	cancel: "Anuluj",
	submit: "Wyślij",
	uploadFile: "Wczytaj plik",
	fileSizeLimit: "Limit rozmiaru pliku: {{count}} MB",
	maximumAttachment: "Maksymalnie jeden załącznik na wiadomość",
	errorMessage: "Coś poszło nie tak.",
	charactersLeft: "pozostało znaków: {{count}}",
	customerService: "Obsługa klienta"
};
var customerTicketingList$4 = {
	subject: "Temat",
	ticketCategory: "Kategoria",
	sortSubtitle: "Sortuj według",
	sortOrders: "Sortuj zamówienia",
	noTickets: "Nie masz żądań",
	requestTitle: "Wszystkie żądania",
	mobile: {
		ticketIdFull: "ID zgłoszenia"
	}
};
var createCustomerTicket$4 = {
	createNewTicket: "Dodaj",
	addNewRequest: "Dodaj nowe żądanie",
	addRequest: "Dodaj żądanie",
	subject: "Temat",
	category: "Kategoria",
	associateTo: "Powiąż z",
	ticketCreated: "Żądanie zostało utworzone.",
	optionallySelectAssociatedObject: "Wybierz opcję",
	selectCategory: "Wybierz kategorię"
};
var customerTicketingDetails$4 = {
	requestReopened: "Żądanie zostało otwarte ponownie.",
	requestClosed: "Żądanie zostało zamknięte, w razie potrzeby można je ponownie otworzyć.",
	reopenRequest: "Ponownie otwórz żądanie",
	closeRequest: "Zamknij żądanie",
	ticketNotFound: "Nie znaleziono zgłoszenia."
};
var customerTicketing$9 = {
	customerTicketing: customerTicketing$8,
	customerTicketingList: customerTicketingList$4,
	createCustomerTicket: createCustomerTicket$4,
	customerTicketingDetails: customerTicketingDetails$4
};

var myAccountV2CustomerTicketing$8 = {
	heading: "Obsługa klienta",
	showMore: "Pokaż więcej",
	showMoreLabel: "Przejdź do historii zgłoszeń obsługi klienta",
	changedOn: "Data zmiany: {{value}}",
	ticketId: "ID: {{value}}",
	subjectLabel: "Temat",
	idLabel: "ID obsługi klienta"
};
var myAccountV2CustomerTicketing$9 = {
	myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$8
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const pl = {
    customerTicketing: customerTicketing$9,
    myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$9,
};

var customerTicketing$6 = {
	mainLogoLabel: "SAP",
	mainTitle: "Tickets do cliente",
	ticketId: "ID",
	createdOn: "Criado em",
	changedOn: "Modificado em",
	status: "Status",
	message: "Mensagem",
	cancel: "Cancelar",
	submit: "Enviar",
	uploadFile: "Carregar arquivo",
	fileSizeLimit: "Limite de tamanho do arquivo: {{count}} MB",
	maximumAttachment: "Máximo de um anexo por mensagem",
	errorMessage: "Algo deu errado",
	charactersLeft: "caracteres restantes: {{count}}",
	customerService: "Serviço ao cliente"
};
var customerTicketingList$3 = {
	subject: "Assunto",
	ticketCategory: "Categoria",
	sortSubtitle: "Ordenar por",
	sortOrders: "Ordens de classificação",
	noTickets: "Você não tem solicitações",
	requestTitle: "Todas as solicitações",
	mobile: {
		ticketIdFull: "ID do ticket"
	}
};
var createCustomerTicket$3 = {
	createNewTicket: "Adicionar",
	addNewRequest: "Adicionar nova solicitação",
	addRequest: "Adicionar solicitação",
	subject: "Assunto",
	category: "Categoria",
	associateTo: "Associar a",
	ticketCreated: "Solicitação criada.",
	optionallySelectAssociatedObject: "Selecionar opção",
	selectCategory: "Selecionar categoria"
};
var customerTicketingDetails$3 = {
	requestReopened: "Solicitação reaberta.",
	requestClosed: "Solicitação fechada, você pode reabrir a mesma, se necessário.",
	reopenRequest: "Reabrir solicitação",
	closeRequest: "Fechar solicitação",
	ticketNotFound: "Ticket não encontrado."
};
var customerTicketing$7 = {
	customerTicketing: customerTicketing$6,
	customerTicketingList: customerTicketingList$3,
	createCustomerTicket: createCustomerTicket$3,
	customerTicketingDetails: customerTicketingDetails$3
};

var myAccountV2CustomerTicketing$6 = {
	heading: "Serviço ao cliente",
	showMore: "Mostrar mais",
	showMoreLabel: "Navegar para histórico de solicitações de serviço ao cliente",
	changedOn: "Modificado em: {{value}}",
	ticketId: "ID: {{value}}",
	subjectLabel: "Assunto",
	idLabel: "ID do serviço ao cliente"
};
var myAccountV2CustomerTicketing$7 = {
	myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$6
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const pt = {
    customerTicketing: customerTicketing$7,
    myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$7,
};

var customerTicketing$4 = {
	mainLogoLabel: "SAP",
	mainTitle: "Сервисные запросы клиента",
	ticketId: "Ид.",
	createdOn: "Дата создания",
	changedOn: "Дата изменения",
	status: "Статус",
	message: "Сообщение",
	cancel: "Отменить",
	submit: "Отправить",
	uploadFile: "Загрузить файл",
	fileSizeLimit: "Максимальный размер файла: {{count}} МБ",
	maximumAttachment: "Максимум одно вложение на сообщение",
	errorMessage: "Что-то пошло не так.",
	charactersLeft: "осталось символов: {{count}}",
	customerService: "Сервисная служба"
};
var customerTicketingList$2 = {
	subject: "Тема",
	ticketCategory: "Категория",
	sortSubtitle: "Сортировать по",
	sortOrders: "Сортировать заказы",
	noTickets: "У вас нет запросов",
	requestTitle: "Все запросы",
	mobile: {
		ticketIdFull: "Ид. сервисного запроса"
	}
};
var createCustomerTicket$2 = {
	createNewTicket: "Добавить",
	addNewRequest: "Добавить новый запрос",
	addRequest: "Добавить запрос",
	subject: "Тема",
	category: "Категория",
	associateTo: "Связать с",
	ticketCreated: "Запрос создан.",
	optionallySelectAssociatedObject: "Выбрать опцию",
	selectCategory: "Выбрать категорию"
};
var customerTicketingDetails$2 = {
	requestReopened: "Запрос открыт повторно.",
	requestClosed: "Запрос закрыт, если нужно, его можно открыть повторно.",
	reopenRequest: "Открыть запрос повторно ",
	closeRequest: "Закрыть запрос ",
	ticketNotFound: "Сервисный запрос не найден."
};
var customerTicketing$5 = {
	customerTicketing: customerTicketing$4,
	customerTicketingList: customerTicketingList$2,
	createCustomerTicket: createCustomerTicket$2,
	customerTicketingDetails: customerTicketingDetails$2
};

var myAccountV2CustomerTicketing$4 = {
	heading: "Сервисная служба",
	showMore: "Показать больше",
	showMoreLabel: "Перейти к истории запросов в сервисную службу",
	changedOn: "Дата изменения: {{value}}",
	ticketId: "Ид.: {{value}}",
	subjectLabel: "Тема",
	idLabel: "Ид. сервисной службы"
};
var myAccountV2CustomerTicketing$5 = {
	myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$4
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ru = {
    customerTicketing: customerTicketing$5,
    myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$5,
};

var customerTicketing$2 = {
	mainLogoLabel: "SAP",
	mainTitle: "客户票证",
	ticketId: "标识",
	createdOn: "创建日期",
	changedOn: "更改日期",
	status: "状态",
	message: "消息",
	cancel: "取消",
	submit: "提交",
	uploadFile: "上载文件",
	fileSizeLimit: "文件大小限制：{{count}} MB",
	maximumAttachment: "每条消息最多一个附件",
	errorMessage: "出现错误。",
	charactersLeft: "剩余字符：{{count}}",
	customerService: "客户服务"
};
var customerTicketingList$1 = {
	subject: "主题",
	ticketCategory: "类别",
	sortSubtitle: "排序依据",
	sortOrders: "排序订单",
	noTickets: "您没有任何请求",
	requestTitle: "所有请求",
	mobile: {
		ticketIdFull: "票证标识"
	}
};
var createCustomerTicket$1 = {
	createNewTicket: "添加",
	addNewRequest: "添加新请求",
	addRequest: "添加请求",
	subject: "主题",
	category: "类别",
	associateTo: "关联至",
	ticketCreated: "已创建请求。",
	optionallySelectAssociatedObject: "选择选项",
	selectCategory: "选择类别"
};
var customerTicketingDetails$1 = {
	requestReopened: "已重新打开请求。",
	requestClosed: "请求已关闭，您可以根据需要重新打开。",
	reopenRequest: "重新打开请求",
	closeRequest: "关闭请求",
	ticketNotFound: "未找到票证。"
};
var customerTicketing$3 = {
	customerTicketing: customerTicketing$2,
	customerTicketingList: customerTicketingList$1,
	createCustomerTicket: createCustomerTicket$1,
	customerTicketingDetails: customerTicketingDetails$1
};

var myAccountV2CustomerTicketing$2 = {
	heading: "客户服务",
	showMore: "显示更多",
	showMoreLabel: "导航到客户服务请求历史记录",
	changedOn: "更改日期：{{value}}",
	ticketId: "标识：{{value}}",
	subjectLabel: "主题",
	idLabel: "客户服务标识"
};
var myAccountV2CustomerTicketing$3 = {
	myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$2
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const zh = {
    customerTicketing: customerTicketing$3,
    myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$3,
};

var customerTicketing = {
	mainLogoLabel: "SAP",
	mainTitle: "客戶記錄單",
	ticketId: "ID",
	createdOn: "建立日期",
	changedOn: "更改日期",
	status: "狀態",
	message: "訊息",
	cancel: "取消",
	submit: "提交",
	uploadFile: "上傳檔案",
	fileSizeLimit: "檔案大小限制：{{count}} MB",
	maximumAttachment: "各訊息最多一個附件",
	errorMessage: "發生錯誤。",
	charactersLeft: "剩餘字元：{{count}}",
	customerService: "客戶服務"
};
var customerTicketingList = {
	subject: "主旨",
	ticketCategory: "種類",
	sortSubtitle: "排序依據",
	sortOrders: "排序順序",
	noTickets: "您沒有請求",
	requestTitle: "所有請求",
	mobile: {
		ticketIdFull: "記錄單 ID"
	}
};
var createCustomerTicket = {
	createNewTicket: "新增",
	addNewRequest: "新增請求",
	addRequest: "新增請求",
	subject: "主旨",
	category: "種類",
	associateTo: "關聯至",
	ticketCreated: "請求已建立。",
	optionallySelectAssociatedObject: "選擇選項",
	selectCategory: "選擇種類"
};
var customerTicketingDetails = {
	requestReopened: "請求已重新開啟。",
	requestClosed: "請求已關閉，您可視需求重新開啟。",
	reopenRequest: "重新開啟請求",
	closeRequest: "關閉請求",
	ticketNotFound: "找不到記錄單。"
};
var customerTicketing$1 = {
	customerTicketing: customerTicketing,
	customerTicketingList: customerTicketingList,
	createCustomerTicket: createCustomerTicket,
	customerTicketingDetails: customerTicketingDetails
};

var myAccountV2CustomerTicketing = {
	heading: "客戶服務",
	showMore: "顯示更多",
	showMoreLabel: "瀏覽至客戶服務請求歷史記錄",
	changedOn: "更改日期：{{value}}",
	ticketId: "ID：{{value}}",
	subjectLabel: "主旨",
	idLabel: "客戶服務 ID"
};
var myAccountV2CustomerTicketing$1 = {
	myAccountV2CustomerTicketing: myAccountV2CustomerTicketing
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const zh_TW = {
    customerTicketing: customerTicketing$1,
    myAccountV2CustomerTicketing: myAccountV2CustomerTicketing$1,
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const customerTicketingTranslationChunksConfig = {
    customerTicketing: [
        'customerTicketing',
        'customerTicketingList',
        'createCustomerTicket',
        'customerTicketingDetails',
    ],
    myAccountV2CustomerTicketing: ['myAccountV2CustomerTicketing'],
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { customerTicketingTranslationChunksConfig, cs as customerTicketingTranslationsCs, de as customerTicketingTranslationsDe, en as customerTicketingTranslationsEn, es as customerTicketingTranslationsEs, es_CO as customerTicketingTranslationsEs_CO, fr as customerTicketingTranslationsFr, hi as customerTicketingTranslationsHi, hu as customerTicketingTranslationsHu, id as customerTicketingTranslationsId, it as customerTicketingTranslationsIt, ja as customerTicketingTranslationsJa, ko as customerTicketingTranslationsKo, pl as customerTicketingTranslationsPl, pt as customerTicketingTranslationsPt, ru as customerTicketingTranslationsRu, zh as customerTicketingTranslationsZh, zh_TW as customerTicketingTranslationsZh_TW };
//# sourceMappingURL=spartacus-customer-ticketing-assets.mjs.map
