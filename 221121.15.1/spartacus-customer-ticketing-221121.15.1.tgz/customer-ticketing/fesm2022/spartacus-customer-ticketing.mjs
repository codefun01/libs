import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { CustomerTicketingComponentsModule } from '@spartacus/customer-ticketing/components';
import { CustomerTicketingCoreModule } from '@spartacus/customer-ticketing/core';
import { CustomerTicketingOccModule } from '@spartacus/customer-ticketing/occ';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingModule, imports: [CustomerTicketingComponentsModule,
            CustomerTicketingCoreModule,
            CustomerTicketingOccModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingModule, imports: [CustomerTicketingComponentsModule,
            CustomerTicketingCoreModule,
            CustomerTicketingOccModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CustomerTicketingComponentsModule,
                        CustomerTicketingCoreModule,
                        CustomerTicketingOccModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Triple-slash reference directive to include global type augmentations.
 * This ensures that Angular's compiler loads the type declarations
 * during the build process, enabling proper type checking for @HostListener decorators
 * with platform event syntax (e.g., 'keydown.Escape', 'keydown.ArrowUp').
 * for more about triple-slash directives, see: https://www.typescriptlang.org/docs/handbook/triple-slash-directives.html
 */
/// <reference path="../../types.d.ts" />
/*
 * Public API Surface of customer-ticketing
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CustomerTicketingModule };
//# sourceMappingURL=spartacus-customer-ticketing.mjs.map
