import * as i0 from '@angular/core';
import { inject, Injectable, ViewChild, Component, HostListener, Directive, NgModule, Input, ChangeDetectionStrategy } from '@angular/core';
import * as i1$3 from '@angular/forms';
import { FormGroup, FormControl, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i1$2 from '@spartacus/core';
import { TranslatePipe, useFeatureStyles, I18nModule, FeaturesConfigModule, provideDefaultConfig, AuthGuard, GlobalMessageService, TranslationService, HttpErrorModel, GlobalMessageType, CxDatePipe, UrlPipe, UrlModule } from '@spartacus/core';
import * as i1$1 from '@spartacus/storefront';
import { LAUNCH_CALLER, ICON_TYPE, FormUtils, FocusDirective, IconComponent, FormRequiredAsterisksComponent, FormErrorsComponent, SpinnerComponent, IconModule, KeyboardFocusModule, FormErrorsModule, FileUploadModule, SpinnerModule, FormRequiredLegendComponent, NgSelectA11yDirective, FileUploadComponent, NgSelectA11yModule, DIALOG_TYPE, SortingComponent, PaginationComponent, CardModule, ListNavigationModule, CardComponent, MessagingComponent, ChatMessagingModule } from '@spartacus/storefront';
import { NgIf, AsyncPipe, CommonModule, NgFor, NgClass } from '@angular/common';
import { map, Subscription, BehaviorSubject, of, combineLatest } from 'rxjs';
import { take, tap, map as map$1, catchError, first, filter } from 'rxjs/operators';
import * as i1 from '@spartacus/customer-ticketing/root';
import { CustomerTicketingFacade, STATUS, MAX_INPUT_CHARACTERS, MAX_INPUT_CHARACTERS_FOR_SUBJECT, MAX_SIZE_FOR_ATTACHMENT, MAX_ENTRIES_FOR_ATTACHMENT, STATUS_NAME, TEXT_COLOR_CLASS, DATE_FORMAT, GetTicketQueryReloadEvent } from '@spartacus/customer-ticketing/root';
import { NgSelectComponent, NgOptionTemplateDirective, NgSelectModule } from '@ng-select/ng-select';
import { RouterLink, RouterModule } from '@angular/router';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingCloseComponentService {
    constructor() {
        this.customerTicketingFacade = inject(CustomerTicketingFacade);
    }
    enableCloseButton() {
        return this.customerTicketingFacade
            .getTicket()
            .pipe(map((ticket) => (ticket?.status?.id === STATUS.OPEN ||
            ticket?.status?.id === STATUS.INPROCESS) &&
            ticket.availableStatusTransitions?.some((status) => status.id.toUpperCase() === STATUS.CLOSED)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCloseComponentService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCloseComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCloseComponentService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingCloseComponent {
    constructor(customerTicketingFacade, launchDialogService, vcr) {
        this.customerTicketingFacade = customerTicketingFacade;
        this.launchDialogService = launchDialogService;
        this.vcr = vcr;
        this.subscription = new Subscription();
        this.customerTicketingCloseComponentService = inject(CustomerTicketingCloseComponentService);
        this.enableCloseButton$ = this.customerTicketingCloseComponentService.enableCloseButton();
    }
    openDialog() {
        const dialog = this.launchDialogService.openDialog(LAUNCH_CALLER.CUSTOMER_TICKETING_CLOSE, this.element, this.vcr);
        if (dialog) {
            this.subscription.add(dialog.pipe(take(1)).subscribe());
        }
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCloseComponent, deps: [{ token: i1.CustomerTicketingFacade }, { token: i1$1.LaunchDialogService }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CustomerTicketingCloseComponent, isStandalone: true, selector: "cx-customer-ticketing-close", viewQueries: [{ propertyName: "element", first: true, predicate: ["element"], descendants: true }], ngImport: i0, template: "<div class=\"col-xs-12 col-md-5 col-lg-4\" *ngIf=\"enableCloseButton$ | async\">\n  <button #element class=\"btn btn-block btn-secondary\" (click)=\"openDialog()\">\n    {{ 'customerTicketingDetails.closeRequest' | cxTranslate }}\n  </button>\n</div>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCloseComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-customer-ticketing-close', imports: [NgIf, AsyncPipe, TranslatePipe], template: "<div class=\"col-xs-12 col-md-5 col-lg-4\" *ngIf=\"enableCloseButton$ | async\">\n  <button #element class=\"btn btn-block btn-secondary\" (click)=\"openDialog()\">\n    {{ 'customerTicketingDetails.closeRequest' | cxTranslate }}\n  </button>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1.CustomerTicketingFacade }, { type: i1$1.LaunchDialogService }, { type: i0.ViewContainerRef }], propDecorators: { element: [{
                type: ViewChild,
                args: ['element']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingDialogComponent {
    get messagesCharacterLeft() {
        return (this.inputCharactersLimit - (this.form.get('message')?.value?.length || 0));
    }
    get subjectCharacterLeft() {
        return (this.inputCharactersForSubject -
            (this.form.get('subject')?.value?.length || 0));
    }
    get allowedTypes() {
        return this.customerTicketingConfig.customerTicketing
            ?.attachmentRestrictions?.allowedTypes;
    }
    get getInputCharactersLimit() {
        return (this.customerTicketingConfig.customerTicketing?.inputCharactersLimit ??
            MAX_INPUT_CHARACTERS);
    }
    get getInputCharactersForSubject() {
        return (this.customerTicketingConfig.customerTicketing
            ?.inputCharactersLimitForSubject ?? MAX_INPUT_CHARACTERS_FOR_SUBJECT);
    }
    get maxSize() {
        return (this.customerTicketingConfig.customerTicketing?.attachmentRestrictions
            ?.maxSize ?? MAX_SIZE_FOR_ATTACHMENT);
    }
    handleClick(event) {
        if (event.target.tagName === this.el.nativeElement.tagName) {
            this.close('Click outside of the window');
        }
    }
    constructor(launchDialogService, el, customerTicketingConfig, filesFormValidators, customerTicketingFacade, routingService) {
        this.launchDialogService = launchDialogService;
        this.el = el;
        this.customerTicketingConfig = customerTicketingConfig;
        this.filesFormValidators = filesFormValidators;
        this.customerTicketingFacade = customerTicketingFacade;
        this.routingService = routingService;
        this.iconTypes = ICON_TYPE;
        this.inputCharactersLimit = this.getInputCharactersLimit;
        this.inputCharactersForSubject = this.getInputCharactersForSubject;
        this.isDataLoading$ = new BehaviorSubject(false);
        this.focusConfig = {
            trap: true,
            block: true,
            autofocus: 'button',
            focusOnEscape: true,
        };
        useFeatureStyles('a11yCustomerTicketingVisualFocusFix');
    }
    buildForm() {
        const form = new FormGroup({});
        form.setControl('message', new FormControl('', [
            Validators.required,
            Validators.maxLength(this.inputCharactersLimit),
        ]));
        form.setControl('file', new FormControl('', [
            this.filesFormValidators.maxSize(this.maxSize),
            this.filesFormValidators.maxEntries(MAX_ENTRIES_FOR_ATTACHMENT),
            this.filesFormValidators.allowedTypes(this.allowedTypes),
        ]));
        this.form = form;
    }
    close(reason) {
        this.launchDialogService.closeDialog(reason);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingDialogComponent, deps: [{ token: i1$1.LaunchDialogService }, { token: i0.ElementRef }, { token: i1.CustomerTicketingConfig }, { token: i1$1.FilesFormValidators }, { token: i1.CustomerTicketingFacade }, { token: i1$2.RoutingService }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.19", type: CustomerTicketingDialogComponent, isStandalone: true, host: { listeners: { "click": "handleClick($event)" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingDialogComponent, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: i1$1.LaunchDialogService }, { type: i0.ElementRef }, { type: i1.CustomerTicketingConfig }, { type: i1$1.FilesFormValidators }, { type: i1.CustomerTicketingFacade }, { type: i1$2.RoutingService }], propDecorators: { handleClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingCloseDialogComponent extends CustomerTicketingDialogComponent {
    ngOnInit() {
        this.buildForm();
    }
    closeRequest() {
        if (this.form.invalid) {
            this.form.markAllAsTouched();
            FormUtils.deepUpdateValueAndValidity(this.form);
        }
        else {
            this.isDataLoading$.next(true);
            this.subscription = this.customerTicketingFacade
                .createTicketEvent(this.prepareTicketEvent())
                .subscribe({
                complete: () => {
                    this.onComplete();
                },
                error: () => {
                    this.onError();
                },
            });
        }
    }
    prepareTicketEvent() {
        return {
            message: this.form?.get('message')?.value,
            toStatus: {
                id: STATUS.CLOSED,
                name: STATUS_NAME.CLOSED,
            },
        };
    }
    onComplete() {
        this.isDataLoading$.next(false);
        this.close('Ticket closed successfully');
        this.routingService.go({ cxRoute: 'supportTickets' });
    }
    onError() {
        this.close('Something went wrong while closing the ticket');
        this.isDataLoading$.next(false);
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCloseDialogComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CustomerTicketingCloseDialogComponent, isStandalone: true, selector: "cx-customer-ticketing-close-dialog", usesInheritance: true, ngImport: i0, template: "<div\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"close('Escape clicked')\"\n  class=\"modal-dialog modal-dialog-centered cx-customer-ticket-form-dialog\"\n  role=\"dialog\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <form\n    [formGroup]=\"form\"\n    class=\"modal-content cx-customer-ticket-form-container\"\n  >\n    <div class=\"modal-header cx-customer-ticket-form-header\">\n      <div id=\"dialogTitle\" class=\"cx-customer-ticket-form-title modal-title\">\n        {{ 'customerTicketingDetails.closeRequest' | cxTranslate }}\n      </div>\n      <button\n        (click)=\"close('Close Request Dialog')\"\n        [attr.aria-label]=\"'common.close' | cxTranslate\"\n        class=\"cx-customer-ticket-form-close close\"\n        title=\"{{ 'common.close' | cxTranslate }}\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n        </span>\n      </button>\n    </div>\n\n    <div class=\"modal-body cx-customer-ticket-form-body\">\n      <div class=\"cx-customer-ticket-form-row\">\n        <label>\n          <span class=\"cx-customer-ticket-label label-content\">\n            {{ 'customerTicketing.message' | cxTranslate }}\n            <cx-form-required-asterisks />\n          </span>\n          <textarea\n            required=\"true\"\n            [maxLength]=\"inputCharactersLimit\"\n            class=\"form-control\"\n            formControlName=\"message\"\n            [attr.aria-invalid]=\"\n              form.get('message')?.touched && form.get('message')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'messageError'\"\n            rows=\"5\"\n          ></textarea>\n\n          <cx-form-errors\n            id=\"messageError\"\n            [control]=\"form.get('message')\"\n          ></cx-form-errors>\n\n          <p class=\"cx-customer-ticket-input-hint\">\n            {{\n              'customerTicketing.charactersLeft'\n                | cxTranslate: { count: messagesCharacterLeft }\n            }}\n          </p>\n        </label>\n      </div>\n\n      <div class=\"cx-customer-ticket-form-footer\">\n        <button\n          (click)=\"close('Close Request Dialog')\"\n          class=\"btn btn-secondary\"\n        >\n          {{ 'customerTicketing.cancel' | cxTranslate }}\n        </button>\n        <button (click)=\"closeRequest()\" class=\"btn btn-primary\">\n          {{ 'customerTicketing.submit' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n    <cx-spinner *ngIf=\"isDataLoading$ | async\" class=\"overlay\"></cx-spinner>\n  </form>\n</div>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$3.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$3.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$3.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$3.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$3.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCloseDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-customer-ticketing-close-dialog', imports: [
                        FocusDirective,
                        FormsModule,
                        ReactiveFormsModule,
                        IconComponent,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        NgIf,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<div\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"close('Escape clicked')\"\n  class=\"modal-dialog modal-dialog-centered cx-customer-ticket-form-dialog\"\n  role=\"dialog\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <form\n    [formGroup]=\"form\"\n    class=\"modal-content cx-customer-ticket-form-container\"\n  >\n    <div class=\"modal-header cx-customer-ticket-form-header\">\n      <div id=\"dialogTitle\" class=\"cx-customer-ticket-form-title modal-title\">\n        {{ 'customerTicketingDetails.closeRequest' | cxTranslate }}\n      </div>\n      <button\n        (click)=\"close('Close Request Dialog')\"\n        [attr.aria-label]=\"'common.close' | cxTranslate\"\n        class=\"cx-customer-ticket-form-close close\"\n        title=\"{{ 'common.close' | cxTranslate }}\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n        </span>\n      </button>\n    </div>\n\n    <div class=\"modal-body cx-customer-ticket-form-body\">\n      <div class=\"cx-customer-ticket-form-row\">\n        <label>\n          <span class=\"cx-customer-ticket-label label-content\">\n            {{ 'customerTicketing.message' | cxTranslate }}\n            <cx-form-required-asterisks />\n          </span>\n          <textarea\n            required=\"true\"\n            [maxLength]=\"inputCharactersLimit\"\n            class=\"form-control\"\n            formControlName=\"message\"\n            [attr.aria-invalid]=\"\n              form.get('message')?.touched && form.get('message')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'messageError'\"\n            rows=\"5\"\n          ></textarea>\n\n          <cx-form-errors\n            id=\"messageError\"\n            [control]=\"form.get('message')\"\n          ></cx-form-errors>\n\n          <p class=\"cx-customer-ticket-input-hint\">\n            {{\n              'customerTicketing.charactersLeft'\n                | cxTranslate: { count: messagesCharacterLeft }\n            }}\n          </p>\n        </label>\n      </div>\n\n      <div class=\"cx-customer-ticket-form-footer\">\n        <button\n          (click)=\"close('Close Request Dialog')\"\n          class=\"btn btn-secondary\"\n        >\n          {{ 'customerTicketing.cancel' | cxTranslate }}\n        </button>\n        <button (click)=\"closeRequest()\" class=\"btn btn-primary\">\n          {{ 'customerTicketing.submit' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n    <cx-spinner *ngIf=\"isDataLoading$ | async\" class=\"overlay\"></cx-spinner>\n  </form>\n</div>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingCloseModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCloseModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCloseModule, imports: [CommonModule,
            I18nModule,
            IconModule,
            KeyboardFocusModule,
            ReactiveFormsModule,
            FormErrorsModule,
            FileUploadModule,
            SpinnerModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            CustomerTicketingCloseComponent,
            CustomerTicketingCloseDialogComponent], exports: [CustomerTicketingCloseComponent,
            CustomerTicketingCloseDialogComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCloseModule, providers: [
            CustomerTicketingCloseComponentService,
            provideDefaultConfig({
                cmsComponents: {
                    SupportTicketCloseComponent: {
                        component: CustomerTicketingCloseComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            IconModule,
            KeyboardFocusModule,
            ReactiveFormsModule,
            FormErrorsModule,
            FileUploadModule,
            SpinnerModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            CustomerTicketingCloseDialogComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCloseModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        IconModule,
                        KeyboardFocusModule,
                        ReactiveFormsModule,
                        FormErrorsModule,
                        FileUploadModule,
                        SpinnerModule,
                        FeaturesConfigModule,
                        FormRequiredAsterisksComponent,
                        CustomerTicketingCloseComponent,
                        CustomerTicketingCloseDialogComponent,
                    ],
                    providers: [
                        CustomerTicketingCloseComponentService,
                        provideDefaultConfig({
                            cmsComponents: {
                                SupportTicketCloseComponent: {
                                    component: CustomerTicketingCloseComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                    ],
                    exports: [
                        CustomerTicketingCloseComponent,
                        CustomerTicketingCloseDialogComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingCreateDialogComponent extends CustomerTicketingDialogComponent {
    constructor() {
        super(...arguments);
        this.ticketCategories$ = this.customerTicketingFacade.getTicketCategories().pipe(tap((categories) => {
            this.manageCategoryValidation(categories);
        }));
        this.ticketAssociatedObjects$ = this.customerTicketingFacade.getTicketAssociatedObjects().pipe(map$1((ao) => ao.map((cao) => ({
            ...cao,
            label: `${cao.type} ${cao.code}`,
        }))), catchError((error) => {
            this.handleError(error);
            return of([]);
        }));
        this.globalMessage = inject(GlobalMessageService);
        this.translationService = inject(TranslationService);
    }
    getCreateTicketPayload(form) {
        return {
            message: form?.get('message')?.value,
            subject: form?.get('subject')?.value,
            associatedTo: form?.get('associatedTo')?.value || undefined,
            ticketCategory: form?.get('ticketCategory')?.value,
        };
    }
    ngOnInit() {
        this.buildForm();
        this.focusConfig.trap = false;
        this.focusConfig.trapTabOnly = true;
    }
    buildForm() {
        const form = new FormGroup({});
        form.setControl('subject', new FormControl('', [
            Validators.required,
            Validators.maxLength(this.inputCharactersForSubject),
        ]));
        form.setControl('ticketCategory', new FormControl('', [Validators.required]));
        form.setControl('associatedTo', new FormControl(''));
        form.setControl('message', new FormControl('', [
            Validators.required,
            Validators.maxLength(this.inputCharactersLimit),
        ]));
        form.setControl('file', new FormControl('', [
            this.filesFormValidators.maxSize(this.maxSize),
            this.filesFormValidators.maxEntries(MAX_ENTRIES_FOR_ATTACHMENT),
            this.filesFormValidators.allowedTypes(this.allowedTypes),
        ]));
        this.form = form;
    }
    createTicketRequest() {
        this.attachment = this.form.get('file')?.value?.[0];
        if (this.form.invalid) {
            this.form.markAllAsTouched();
            FormUtils.deepUpdateValueAndValidity(this.form);
        }
        else {
            this.subscription = this.customerTicketingFacade
                .createTicket(this.getCreateTicketPayload(this.form))
                .subscribe({
                next: (response) => {
                    if (response.id &&
                        this.attachment &&
                        response.ticketEvents?.[0].code) {
                        this.customerTicketingFacade.uploadAttachment(this.attachment, response.ticketEvents?.[0].code, response.id);
                    }
                },
                complete: () => {
                    this.onComplete();
                },
                error: (error) => {
                    this.handleError(error);
                },
            });
        }
    }
    handleError(error) {
        if (error instanceof HttpErrorModel) {
            (error.details ?? []).forEach((err) => {
                if (err.message) {
                    this.globalMessage.add({ raw: err.message }, GlobalMessageType.MSG_TYPE_ERROR);
                }
            });
        }
        else {
            this.translationService
                .translate('httpHandlers.unknownError')
                .pipe(first())
                .subscribe((text) => {
                this.globalMessage.add({ raw: text }, GlobalMessageType.MSG_TYPE_ERROR);
            });
        }
        this.onError();
    }
    manageCategoryValidation(categories) {
        const categoryControl = this.form.get('ticketCategory');
        if (!categoryControl) {
            return;
        }
        if (categories?.length) {
            categoryControl.setValidators(Validators.required);
            categoryControl.updateValueAndValidity();
        }
        else {
            categoryControl.clearValidators();
            categoryControl.updateValueAndValidity();
        }
    }
    onComplete() {
        this.close('Ticket created successfully');
    }
    onError() {
        this.close('Something went wrong');
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCreateDialogComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CustomerTicketingCreateDialogComponent, isStandalone: true, selector: "cx-customer-ticketing-create-dialog", inputs: { selectedCategory: "selectedCategory", selectedAssociatedObject: "selectedAssociatedObject" }, usesInheritance: true, ngImport: i0, template: "<div\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"close('Escape clicked')\"\n  class=\"modal-dialog modal-dialog-centered cx-customer-ticket-form-dialog\"\n  role=\"dialog\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <form\n    [formGroup]=\"form\"\n    class=\"modal-content cx-customer-ticket-form-container\"\n  >\n    <div class=\"modal-header cx-customer-ticket-form-header\">\n      <div id=\"dialogTitle\" class=\"cx-customer-ticket-form-title modal-title\">\n        {{ 'createCustomerTicket.addNewRequest' | cxTranslate }}\n      </div>\n      <button\n        (click)=\"close('Close Create Request Dialog')\"\n        [attr.aria-label]=\"'common.close' | cxTranslate\"\n        class=\"cx-customer-ticket-form-close close\"\n        type=\"button\"\n        title=\"{{ 'common.close' | cxTranslate }}\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n        </span>\n      </button>\n    </div>\n\n    <div class=\"modal-body cx-customer-ticket-form-body\">\n      <div class=\"cx-customer-ticket-form-row\">\n        <cx-form-required-legend />\n        <label>\n          <span class=\"cx-customer-ticket-label label-content\">\n            {{ 'createCustomerTicket.subject' | cxTranslate }}\n            <cx-form-required-asterisks />\n          </span>\n          <textarea\n            [maxLength]=\"inputCharactersForSubject\"\n            required=\"true\"\n            class=\"form-control\"\n            formControlName=\"subject\"\n            rows=\"1\"\n            [attr.aria-invalid]=\"\n              form.get('subject')?.touched && form.get('subject')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'subjectError'\"\n          ></textarea>\n\n          <cx-form-errors\n            id=\"subjectError\"\n            [control]=\"form.get('subject')\"\n          ></cx-form-errors>\n          <p class=\"cx-customer-ticket-input-hint\">\n            {{\n              'customerTicketing.charactersLeft'\n                | cxTranslate: { count: subjectCharacterLeft }\n            }}\n          </p>\n        </label>\n\n        <label *ngIf=\"ticketCategories$ | async as ticketCategories\">\n          <span class=\"cx-customer-ticket-label label-content\">\n            {{ 'createCustomerTicket.category' | cxTranslate }}\n            <cx-form-required-asterisks />\n          </span>\n          <ng-select\n            [inputAttrs]=\"{ required: 'true' }\"\n            class=\"ticket-category-select\"\n            id=\"ticket-category-select\"\n            [searchable]=\"false\"\n            [clearable]=\"false\"\n            [items]=\"ticketCategories\"\n            [placeholder]=\"'createCustomerTicket.selectCategory' | cxTranslate\"\n            bindLabel=\"name\"\n            formControlName=\"ticketCategory\"\n            ariaLabelDropdown=\"{{\n              'common.ngSelectDropdownOptionsList' | cxTranslate\n            }}\"\n            [cxNgSelectA11y]=\"{}\"\n            [attr.aria-invalid]=\"\n              form.get('ticketCategory')?.touched &&\n              form.get('ticketCategory')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'ticketCategoryError'\"\n          >\n          </ng-select>\n\n          <cx-form-errors\n            id=\"ticketCategoryError\"\n            [control]=\"form.get('ticketCategory')\"\n          ></cx-form-errors>\n        </label>\n\n        <ng-container\n          *ngIf=\"ticketAssociatedObjects$ | async as ticketAssociatedObjects\"\n        >\n          <label *ngIf=\"ticketAssociatedObjects.length > 0\">\n            <span class=\"cx-customer-ticket-label label-content\">\n              {{ 'createCustomerTicket.associateTo' | cxTranslate }}\n            </span>\n            <ng-select\n              [clearable]=\"false\"\n              [items]=\"ticketAssociatedObjects\"\n              [placeholder]=\"\n                'createCustomerTicket.optionallySelectAssociatedObject'\n                  | cxTranslate\n              \"\n              [searchable]=\"false\"\n              formControlName=\"associatedTo\"\n              id=\"associated-to-select\"\n              ariaLabelDropdown=\"{{\n                'common.ngSelectDropdownOptionsList' | cxTranslate\n              }}\"\n              [cxNgSelectA11y]=\"{}\"\n            >\n              <ng-template\n                ng-option-tmp\n                let-item=\"item\"\n                let-search=\"searchTerm\"\n                let-index=\"index\"\n              >\n                <span>{{ item.type + ' ' + item.code }}</span>\n              </ng-template>\n            </ng-select>\n          </label>\n        </ng-container>\n\n        <label>\n          <span class=\"cx-customer-ticket-label label-content\">\n            {{ 'customerTicketing.message' | cxTranslate }}\n            <cx-form-required-asterisks />\n          </span>\n          <textarea\n            required=\"true\"\n            [maxLength]=\"inputCharactersLimit\"\n            class=\"form-control\"\n            formControlName=\"message\"\n            rows=\"5\"\n            [attr.aria-invalid]=\"\n              form.get('message')?.touched && form.get('message')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'messageError'\"\n          ></textarea>\n\n          <cx-form-errors\n            id=\"messageError\"\n            [control]=\"form.get('message')\"\n          ></cx-form-errors>\n\n          <p class=\"cx-customer-ticket-input-hint\">\n            {{\n              'customerTicketing.charactersLeft'\n                | cxTranslate: { count: messagesCharacterLeft }\n            }}\n          </p>\n        </label>\n\n        <div>\n          <cx-file-upload\n            [formControl]=\"$any(form.get('file'))\"\n            [accept]=\"allowedTypes\"\n          >\n            <ng-template>\n              <cx-icon [type]=\"iconTypes.UPLOAD\"></cx-icon>\n              <span class=\"cx-message-footer-text\">{{\n                'customerTicketing.uploadFile' | cxTranslate\n              }}</span>\n            </ng-template>\n          </cx-file-upload>\n\n          <p class=\"cx-customer-ticket-file-upload-hint\">\n            {{\n              'customerTicketing.fileSizeLimit'\n                | cxTranslate: { count: maxSize }\n            }}\n          </p>\n          <p class=\"cx-customer-ticket-file-upload-hint\">\n            {{ 'customerTicketing.maximumAttachment' | cxTranslate }}\n          </p>\n\n          <cx-form-errors\n            [control]=\"form.get('file')\"\n            prefix=\"formErrors.file\"\n          ></cx-form-errors>\n        </div>\n      </div>\n\n      <div class=\"cx-customer-ticket-form-footer\">\n        <button\n          (click)=\"close('Close Create Request Dialog')\"\n          class=\"btn btn-secondary\"\n          type=\"button\"\n        >\n          {{ 'customerTicketing.cancel' | cxTranslate }}\n        </button>\n        <button\n          (click)=\"createTicketRequest()\"\n          class=\"btn btn-primary\"\n          type=\"button\"\n        >\n          {{ 'customerTicketing.submit' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n  </form>\n</div>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$3.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$3.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$3.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$3.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$3.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$3.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "directive", type: NgSelectA11yDirective, selector: "[cxNgSelectA11y]", inputs: ["cxNgSelectA11y"] }, { kind: "directive", type: NgOptionTemplateDirective, selector: "[ng-option-tmp]" }, { kind: "component", type: FileUploadComponent, selector: "cx-file-upload", inputs: ["accept", "multiple"], outputs: ["update"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCreateDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-customer-ticketing-create-dialog', imports: [
                        FocusDirective,
                        FormsModule,
                        ReactiveFormsModule,
                        IconComponent,
                        FormRequiredLegendComponent,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        NgIf,
                        NgSelectComponent,
                        NgSelectA11yDirective,
                        NgOptionTemplateDirective,
                        FileUploadComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<div\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"close('Escape clicked')\"\n  class=\"modal-dialog modal-dialog-centered cx-customer-ticket-form-dialog\"\n  role=\"dialog\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <form\n    [formGroup]=\"form\"\n    class=\"modal-content cx-customer-ticket-form-container\"\n  >\n    <div class=\"modal-header cx-customer-ticket-form-header\">\n      <div id=\"dialogTitle\" class=\"cx-customer-ticket-form-title modal-title\">\n        {{ 'createCustomerTicket.addNewRequest' | cxTranslate }}\n      </div>\n      <button\n        (click)=\"close('Close Create Request Dialog')\"\n        [attr.aria-label]=\"'common.close' | cxTranslate\"\n        class=\"cx-customer-ticket-form-close close\"\n        type=\"button\"\n        title=\"{{ 'common.close' | cxTranslate }}\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n        </span>\n      </button>\n    </div>\n\n    <div class=\"modal-body cx-customer-ticket-form-body\">\n      <div class=\"cx-customer-ticket-form-row\">\n        <cx-form-required-legend />\n        <label>\n          <span class=\"cx-customer-ticket-label label-content\">\n            {{ 'createCustomerTicket.subject' | cxTranslate }}\n            <cx-form-required-asterisks />\n          </span>\n          <textarea\n            [maxLength]=\"inputCharactersForSubject\"\n            required=\"true\"\n            class=\"form-control\"\n            formControlName=\"subject\"\n            rows=\"1\"\n            [attr.aria-invalid]=\"\n              form.get('subject')?.touched && form.get('subject')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'subjectError'\"\n          ></textarea>\n\n          <cx-form-errors\n            id=\"subjectError\"\n            [control]=\"form.get('subject')\"\n          ></cx-form-errors>\n          <p class=\"cx-customer-ticket-input-hint\">\n            {{\n              'customerTicketing.charactersLeft'\n                | cxTranslate: { count: subjectCharacterLeft }\n            }}\n          </p>\n        </label>\n\n        <label *ngIf=\"ticketCategories$ | async as ticketCategories\">\n          <span class=\"cx-customer-ticket-label label-content\">\n            {{ 'createCustomerTicket.category' | cxTranslate }}\n            <cx-form-required-asterisks />\n          </span>\n          <ng-select\n            [inputAttrs]=\"{ required: 'true' }\"\n            class=\"ticket-category-select\"\n            id=\"ticket-category-select\"\n            [searchable]=\"false\"\n            [clearable]=\"false\"\n            [items]=\"ticketCategories\"\n            [placeholder]=\"'createCustomerTicket.selectCategory' | cxTranslate\"\n            bindLabel=\"name\"\n            formControlName=\"ticketCategory\"\n            ariaLabelDropdown=\"{{\n              'common.ngSelectDropdownOptionsList' | cxTranslate\n            }}\"\n            [cxNgSelectA11y]=\"{}\"\n            [attr.aria-invalid]=\"\n              form.get('ticketCategory')?.touched &&\n              form.get('ticketCategory')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'ticketCategoryError'\"\n          >\n          </ng-select>\n\n          <cx-form-errors\n            id=\"ticketCategoryError\"\n            [control]=\"form.get('ticketCategory')\"\n          ></cx-form-errors>\n        </label>\n\n        <ng-container\n          *ngIf=\"ticketAssociatedObjects$ | async as ticketAssociatedObjects\"\n        >\n          <label *ngIf=\"ticketAssociatedObjects.length > 0\">\n            <span class=\"cx-customer-ticket-label label-content\">\n              {{ 'createCustomerTicket.associateTo' | cxTranslate }}\n            </span>\n            <ng-select\n              [clearable]=\"false\"\n              [items]=\"ticketAssociatedObjects\"\n              [placeholder]=\"\n                'createCustomerTicket.optionallySelectAssociatedObject'\n                  | cxTranslate\n              \"\n              [searchable]=\"false\"\n              formControlName=\"associatedTo\"\n              id=\"associated-to-select\"\n              ariaLabelDropdown=\"{{\n                'common.ngSelectDropdownOptionsList' | cxTranslate\n              }}\"\n              [cxNgSelectA11y]=\"{}\"\n            >\n              <ng-template\n                ng-option-tmp\n                let-item=\"item\"\n                let-search=\"searchTerm\"\n                let-index=\"index\"\n              >\n                <span>{{ item.type + ' ' + item.code }}</span>\n              </ng-template>\n            </ng-select>\n          </label>\n        </ng-container>\n\n        <label>\n          <span class=\"cx-customer-ticket-label label-content\">\n            {{ 'customerTicketing.message' | cxTranslate }}\n            <cx-form-required-asterisks />\n          </span>\n          <textarea\n            required=\"true\"\n            [maxLength]=\"inputCharactersLimit\"\n            class=\"form-control\"\n            formControlName=\"message\"\n            rows=\"5\"\n            [attr.aria-invalid]=\"\n              form.get('message')?.touched && form.get('message')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'messageError'\"\n          ></textarea>\n\n          <cx-form-errors\n            id=\"messageError\"\n            [control]=\"form.get('message')\"\n          ></cx-form-errors>\n\n          <p class=\"cx-customer-ticket-input-hint\">\n            {{\n              'customerTicketing.charactersLeft'\n                | cxTranslate: { count: messagesCharacterLeft }\n            }}\n          </p>\n        </label>\n\n        <div>\n          <cx-file-upload\n            [formControl]=\"$any(form.get('file'))\"\n            [accept]=\"allowedTypes\"\n          >\n            <ng-template>\n              <cx-icon [type]=\"iconTypes.UPLOAD\"></cx-icon>\n              <span class=\"cx-message-footer-text\">{{\n                'customerTicketing.uploadFile' | cxTranslate\n              }}</span>\n            </ng-template>\n          </cx-file-upload>\n\n          <p class=\"cx-customer-ticket-file-upload-hint\">\n            {{\n              'customerTicketing.fileSizeLimit'\n                | cxTranslate: { count: maxSize }\n            }}\n          </p>\n          <p class=\"cx-customer-ticket-file-upload-hint\">\n            {{ 'customerTicketing.maximumAttachment' | cxTranslate }}\n          </p>\n\n          <cx-form-errors\n            [control]=\"form.get('file')\"\n            prefix=\"formErrors.file\"\n          ></cx-form-errors>\n        </div>\n      </div>\n\n      <div class=\"cx-customer-ticket-form-footer\">\n        <button\n          (click)=\"close('Close Create Request Dialog')\"\n          class=\"btn btn-secondary\"\n          type=\"button\"\n        >\n          {{ 'customerTicketing.cancel' | cxTranslate }}\n        </button>\n        <button\n          (click)=\"createTicketRequest()\"\n          class=\"btn btn-primary\"\n          type=\"button\"\n        >\n          {{ 'customerTicketing.submit' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n  </form>\n</div>\n" }]
        }], propDecorators: { selectedCategory: [{
                type: Input
            }], selectedAssociatedObject: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingCreateComponent {
    constructor(launchDialogService, vcr) {
        this.launchDialogService = launchDialogService;
        this.vcr = vcr;
        this.subscription = new Subscription();
    }
    openCreateNewTicketDialog() {
        const dialog = this.launchDialogService.openDialog(LAUNCH_CALLER.CUSTOMER_TICKETING_CREATE, this.element, this.vcr);
        if (dialog) {
            this.subscription.add(dialog.pipe(take(1)).subscribe());
        }
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCreateComponent, deps: [{ token: i1$1.LaunchDialogService }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CustomerTicketingCreateComponent, isStandalone: true, selector: "cx-customer-ticketing-create", viewQueries: [{ propertyName: "element", first: true, predicate: ["element"], descendants: true }], ngImport: i0, template: "<button\n  #element\n  class=\"btn btn-primary cx-customer-ticketing-create\"\n  (click)=\"openCreateNewTicketDialog()\"\n>\n  {{ 'createCustomerTicket.addRequest' | cxTranslate }}\n</button>\n", dependencies: [{ kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCreateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-customer-ticketing-create', imports: [TranslatePipe], template: "<button\n  #element\n  class=\"btn btn-primary cx-customer-ticketing-create\"\n  (click)=\"openCreateNewTicketDialog()\"\n>\n  {{ 'createCustomerTicket.addRequest' | cxTranslate }}\n</button>\n" }]
        }], ctorParameters: () => [{ type: i1$1.LaunchDialogService }, { type: i0.ViewContainerRef }], propDecorators: { element: [{
                type: ViewChild,
                args: ['element']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingCreateModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCreateModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCreateModule, imports: [CommonModule,
            I18nModule,
            IconModule,
            KeyboardFocusModule,
            ReactiveFormsModule,
            FormErrorsModule,
            FileUploadModule,
            FeaturesConfigModule,
            NgSelectModule,
            NgSelectA11yModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            CustomerTicketingCreateComponent,
            CustomerTicketingCreateDialogComponent], exports: [CustomerTicketingCreateComponent,
            CustomerTicketingCreateDialogComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCreateModule, imports: [CommonModule,
            I18nModule,
            IconModule,
            KeyboardFocusModule,
            ReactiveFormsModule,
            FormErrorsModule,
            FileUploadModule,
            FeaturesConfigModule,
            NgSelectModule,
            NgSelectA11yModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            CustomerTicketingCreateDialogComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingCreateModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        IconModule,
                        KeyboardFocusModule,
                        ReactiveFormsModule,
                        FormErrorsModule,
                        FileUploadModule,
                        FeaturesConfigModule,
                        NgSelectModule,
                        NgSelectA11yModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        CustomerTicketingCreateComponent,
                        CustomerTicketingCreateDialogComponent,
                    ],
                    exports: [
                        CustomerTicketingCreateComponent,
                        CustomerTicketingCreateDialogComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingReopenDialogComponent extends CustomerTicketingDialogComponent {
    ngOnInit() {
        this.buildForm();
    }
    reopenRequest() {
        if (this.form.invalid) {
            this.form.markAllAsTouched();
            FormUtils.deepUpdateValueAndValidity(this.form);
        }
        else {
            const mustWaitForAttachment = this.form.get('file')?.value?.length > 0;
            this.isDataLoading$.next(true);
            this.subscription = this.customerTicketingFacade
                .createTicketEvent(this.prepareTicketEvent(), mustWaitForAttachment)
                .subscribe({
                next: (createdEvent) => {
                    if (this.form.get('file')?.value?.length && createdEvent.code) {
                        this.customerTicketingFacade.uploadAttachment(this.form.get('file')?.value?.item(0), createdEvent.code);
                    }
                },
                complete: () => {
                    this.onComplete();
                },
                error: () => {
                    this.onError();
                },
            });
        }
    }
    onComplete() {
        this.isDataLoading$.next(false);
        this.close('Ticket reopened successfully');
    }
    onError() {
        this.isDataLoading$.next(false);
        this.close('Something went wrong while reopening ticket');
    }
    prepareTicketEvent() {
        return {
            message: this.form?.get('message')?.value,
            toStatus: {
                id: STATUS.INPROCESS,
                name: STATUS_NAME.INPROCESS,
            },
        };
    }
    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingReopenDialogComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CustomerTicketingReopenDialogComponent, isStandalone: true, selector: "cx-customer-ticketing-reopen-dialog", usesInheritance: true, ngImport: i0, template: "<div\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"close('Escape clicked')\"\n  class=\"modal-dialog modal-dialog-centered cx-customer-ticket-form-dialog\"\n  role=\"dialog\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <form\n    [formGroup]=\"form\"\n    class=\"modal-content cx-customer-ticket-form-container\"\n  >\n    <div class=\"modal-header cx-customer-ticket-form-header\">\n      <div id=\"dialogTitle\" class=\"cx-customer-ticket-form-title modal-title\">\n        {{ 'customerTicketingDetails.reopenRequest' | cxTranslate }}\n      </div>\n      <button\n        (click)=\"close('Close Reopen Request Dialog')\"\n        [attr.aria-label]=\"'common.close' | cxTranslate\"\n        class=\"cx-customer-ticket-form-close close\"\n        type=\"button\"\n        title=\"{{ 'common.close' | cxTranslate }}\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n        </span>\n      </button>\n    </div>\n\n    <div class=\"modal-body cx-customer-ticket-form-body\">\n      <div class=\"cx-customer-ticket-form-row\">\n        <label>\n          <span class=\"cx-customer-ticket-label label-content\">\n            {{ 'customerTicketing.message' | cxTranslate }}\n          </span>\n          <textarea\n            [maxLength]=\"inputCharactersLimit\"\n            class=\"form-control\"\n            formControlName=\"message\"\n            rows=\"5\"\n            [attr.aria-invalid]=\"\n              form.get('message')?.touched && form.get('message')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'messageError'\"\n          ></textarea>\n\n          <cx-form-errors\n            id=\"messageError\"\n            [control]=\"form.get('message')\"\n          ></cx-form-errors>\n\n          <p class=\"cx-customer-ticket-input-hint\">\n            {{\n              'customerTicketing.charactersLeft'\n                | cxTranslate: { count: messagesCharacterLeft }\n            }}\n          </p>\n        </label>\n      </div>\n\n      <div>\n        <cx-file-upload\n          [formControl]=\"$any(form.get('file'))\"\n          [accept]=\"allowedTypes\"\n        >\n          <ng-template>\n            <cx-icon [type]=\"iconTypes.UPLOAD\"></cx-icon>\n            <span class=\"cx-message-footer-text\">{{\n              'customerTicketing.uploadFile' | cxTranslate\n            }}</span>\n          </ng-template>\n        </cx-file-upload>\n\n        <p class=\"cx-customer-ticket-file-upload-hint\">\n          {{\n            'customerTicketing.fileSizeLimit' | cxTranslate: { count: maxSize }\n          }}\n        </p>\n        <p class=\"cx-customer-ticket-file-upload-hint\">\n          {{ 'customerTicketing.maximumAttachment' | cxTranslate }}\n        </p>\n\n        <cx-form-errors\n          [control]=\"form.get('file')\"\n          prefix=\"formErrors.file\"\n        ></cx-form-errors>\n      </div>\n\n      <div class=\"cx-customer-ticket-form-footer\">\n        <button\n          (click)=\"close('Close Reopen Request Dialog')\"\n          class=\"btn btn-secondary\"\n          type=\"button\"\n        >\n          {{ 'customerTicketing.cancel' | cxTranslate }}\n        </button>\n        <button (click)=\"reopenRequest()\" class=\"btn btn-primary\" type=\"button\">\n          {{ 'customerTicketing.submit' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n    <cx-spinner *ngIf=\"isDataLoading$ | async\" class=\"overlay\"></cx-spinner>\n  </form>\n</div>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$3.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$3.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$3.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$3.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$3.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "component", type: FileUploadComponent, selector: "cx-file-upload", inputs: ["accept", "multiple"], outputs: ["update"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingReopenDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-customer-ticketing-reopen-dialog', imports: [
                        FocusDirective,
                        FormsModule,
                        ReactiveFormsModule,
                        IconComponent,
                        FormErrorsComponent,
                        FileUploadComponent,
                        NgIf,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<div\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"close('Escape clicked')\"\n  class=\"modal-dialog modal-dialog-centered cx-customer-ticket-form-dialog\"\n  role=\"dialog\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <form\n    [formGroup]=\"form\"\n    class=\"modal-content cx-customer-ticket-form-container\"\n  >\n    <div class=\"modal-header cx-customer-ticket-form-header\">\n      <div id=\"dialogTitle\" class=\"cx-customer-ticket-form-title modal-title\">\n        {{ 'customerTicketingDetails.reopenRequest' | cxTranslate }}\n      </div>\n      <button\n        (click)=\"close('Close Reopen Request Dialog')\"\n        [attr.aria-label]=\"'common.close' | cxTranslate\"\n        class=\"cx-customer-ticket-form-close close\"\n        type=\"button\"\n        title=\"{{ 'common.close' | cxTranslate }}\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n        </span>\n      </button>\n    </div>\n\n    <div class=\"modal-body cx-customer-ticket-form-body\">\n      <div class=\"cx-customer-ticket-form-row\">\n        <label>\n          <span class=\"cx-customer-ticket-label label-content\">\n            {{ 'customerTicketing.message' | cxTranslate }}\n          </span>\n          <textarea\n            [maxLength]=\"inputCharactersLimit\"\n            class=\"form-control\"\n            formControlName=\"message\"\n            rows=\"5\"\n            [attr.aria-invalid]=\"\n              form.get('message')?.touched && form.get('message')?.invalid\n            \"\n            [attr.aria-errormessage]=\"'messageError'\"\n          ></textarea>\n\n          <cx-form-errors\n            id=\"messageError\"\n            [control]=\"form.get('message')\"\n          ></cx-form-errors>\n\n          <p class=\"cx-customer-ticket-input-hint\">\n            {{\n              'customerTicketing.charactersLeft'\n                | cxTranslate: { count: messagesCharacterLeft }\n            }}\n          </p>\n        </label>\n      </div>\n\n      <div>\n        <cx-file-upload\n          [formControl]=\"$any(form.get('file'))\"\n          [accept]=\"allowedTypes\"\n        >\n          <ng-template>\n            <cx-icon [type]=\"iconTypes.UPLOAD\"></cx-icon>\n            <span class=\"cx-message-footer-text\">{{\n              'customerTicketing.uploadFile' | cxTranslate\n            }}</span>\n          </ng-template>\n        </cx-file-upload>\n\n        <p class=\"cx-customer-ticket-file-upload-hint\">\n          {{\n            'customerTicketing.fileSizeLimit' | cxTranslate: { count: maxSize }\n          }}\n        </p>\n        <p class=\"cx-customer-ticket-file-upload-hint\">\n          {{ 'customerTicketing.maximumAttachment' | cxTranslate }}\n        </p>\n\n        <cx-form-errors\n          [control]=\"form.get('file')\"\n          prefix=\"formErrors.file\"\n        ></cx-form-errors>\n      </div>\n\n      <div class=\"cx-customer-ticket-form-footer\">\n        <button\n          (click)=\"close('Close Reopen Request Dialog')\"\n          class=\"btn btn-secondary\"\n          type=\"button\"\n        >\n          {{ 'customerTicketing.cancel' | cxTranslate }}\n        </button>\n        <button (click)=\"reopenRequest()\" class=\"btn btn-primary\" type=\"button\">\n          {{ 'customerTicketing.submit' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n    <cx-spinner *ngIf=\"isDataLoading$ | async\" class=\"overlay\"></cx-spinner>\n  </form>\n</div>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultCustomerTicketingFormLayoutConfig = {
    launch: {
        CUSTOMER_TICKETING_REOPEN: {
            inline: true,
            component: CustomerTicketingReopenDialogComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
        CUSTOMER_TICKETING_CLOSE: {
            inline: true,
            component: CustomerTicketingCloseDialogComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
        CUSTOMER_TICKETING_CREATE: {
            inline: true,
            component: CustomerTicketingCreateDialogComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingListComponent {
    constructor(customerTicketingFacade, routingService, translationService, customerTicketingConfig) {
        this.customerTicketingFacade = customerTicketingFacade;
        this.routingService = routingService;
        this.translationService = translationService;
        this.customerTicketingConfig = customerTicketingConfig;
        this.PAGE_SIZE = this.customerTicketingConfig.customerTicketing?.listViewPageSize || 5;
        this.iconTypes = ICON_TYPE;
        this.tickets$ = this.customerTicketingFacade
            .getTickets(this.PAGE_SIZE)
            .pipe(tap((tickets) => (this.sortType = tickets?.pagination?.sort || '')));
        this.getStatusClass = (status) => {
            switch (status) {
                case STATUS.OPEN:
                case STATUS.INPROCESS:
                    return TEXT_COLOR_CLASS.GREEN;
                case STATUS.CLOSED:
                    return TEXT_COLOR_CLASS.GREY;
                default:
                    return '';
            }
        };
    }
    goToTicketDetail(ticketId) {
        this.routingService.go({
            cxRoute: 'supportTicketDetails',
            params: { ticketCode: ticketId },
        });
    }
    getSortLabels() {
        return combineLatest([
            this.translationService.translate('customerTicketing.ticketId'),
            this.translationService.translate('customerTicketing.changedOn'),
        ]).pipe(map$1(([textByTicketId, textByDate]) => {
            return {
                byTicketId: textByTicketId,
                byDate: textByDate,
            };
        }));
    }
    changeSortCode(sortCode) {
        this.sortType = sortCode;
        this.pageChange(0);
    }
    pageChange(page) {
        const ticketListParams = this.createTicketListEvent(this.sortType, page);
        this.fetchTicketList(ticketListParams);
    }
    createTicketListEvent(sortCode, currentPage) {
        return {
            currentPage: currentPage,
            sortCode: sortCode,
        };
    }
    fetchTicketList(ticketListParams) {
        this.tickets$ = this.customerTicketingFacade.getTickets(this.PAGE_SIZE, ticketListParams.currentPage, ticketListParams.sortCode);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingListComponent, deps: [{ token: i1.CustomerTicketingFacade }, { token: i1$2.RoutingService }, { token: i1$2.TranslationService }, { token: i1.CustomerTicketingConfig }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CustomerTicketingListComponent, isStandalone: true, selector: "cx-customer-ticketing-list", ngImport: i0, template: "<ng-container *ngIf=\"tickets$ | async as ticketList; else spinner\">\n  <span class=\"cx-ticketing-list-title\">\n    <h2 class=\"cx-ticketing-list-title-text\">\n      {{ 'customerTicketingList.requestTitle' | cxTranslate }}\n      ({{ ticketList.pagination?.totalResults || 0 }})\n    </h2>\n  </span>\n  <ng-container *ngIf=\"ticketList.tickets.length > 0; else noCustomerTickets\">\n    <div class=\"cx-ticketing-list-sort top\">\n      <label class=\"cx-ticketing-list-form-group form-group\">\n        <span>\n          {{ 'customerTicketingList.sortSubtitle' | cxTranslate }}\n        </span>\n        <cx-sorting\n          [sortOptions]=\"ticketList.sorts\"\n          [sortLabels]=\"getSortLabels() | async\"\n          (sortListEvent)=\"changeSortCode($event)\"\n          [selectedOption]=\"ticketList.pagination?.sort\"\n          placeholder=\"{{ 'customerTicketingList.sortSubtitle' | cxTranslate }}\"\n          [ariaLabel]=\"'customerTicketingList.sortOrders' | cxTranslate\"\n          ariaControls=\"ticketing-list-table\"\n        ></cx-sorting>\n      </label>\n      <cx-customer-ticketing-create></cx-customer-ticketing-create>\n    </div>\n    <table\n      id=\"ticketing-list-table\"\n      class=\"table cx-ticketing-list-table\"\n      aria-hidden=\"true\"\n    >\n      <thead class=\"cx-ticketing-list-thead-mobile\">\n        <tr>\n          <th scope=\"col\">{{ 'customerTicketing.ticketId' | cxTranslate }}</th>\n          <th scope=\"col\">\n            {{ 'customerTicketingList.subject' | cxTranslate }}\n          </th>\n          <th scope=\"col\">\n            {{ 'customerTicketingList.ticketCategory' | cxTranslate }}\n          </th>\n          <th scope=\"col\">{{ 'customerTicketing.createdOn' | cxTranslate }}</th>\n          <th scope=\"col\">{{ 'customerTicketing.changedOn' | cxTranslate }}</th>\n          <th scope=\"col\">{{ 'customerTicketing.status' | cxTranslate }}</th>\n        </tr>\n      </thead>\n      <tbody>\n        <tr\n          *ngFor=\"let ticket of ticketList.tickets\"\n          (click)=\"goToTicketDetail(ticket.id)\"\n        >\n          <td class=\"cx-ticketing-list-data cx-ticketing-list-id\">\n            <div class=\"cx-ticketing-list-label\">\n              {{ 'customerTicketingList.mobile.ticketIdFull' | cxTranslate }}\n            </div>\n            <a\n              [routerLink]=\"\n                {\n                  cxRoute: 'supportTicketDetails',\n                  params: { ticketCode: ticket.id },\n                } | cxUrl\n              \"\n              class=\"cx-ticketing-list-value\"\n            >\n              {{ ticket.id }}\n            </a>\n          </td>\n          <td class=\"cx-ticketing-list-data\">\n            <div class=\"cx-ticketing-list-label\">\n              {{ 'customerTicketingList.subject' | cxTranslate }}\n            </div>\n            <a\n              [routerLink]=\"\n                {\n                  cxRoute: 'supportTicketDetails',\n                  params: { ticketCode: ticket.id },\n                } | cxUrl\n              \"\n              class=\"cx-ticketing-list-value\"\n            >\n              {{ ticket.subject }}\n            </a>\n          </td>\n          <td class=\"cx-ticketing-list-data\">\n            <div class=\"cx-ticketing-list-label\">\n              {{ 'customerTicketingList.ticketCategory' | cxTranslate }}\n            </div>\n            <a\n              [routerLink]=\"\n                {\n                  cxRoute: 'supportTicketDetails',\n                  params: { ticketCode: ticket.id },\n                } | cxUrl\n              \"\n              class=\"cx-ticketing-list-value\"\n            >\n              {{ ticket.ticketCategory?.name }}\n            </a>\n          </td>\n          <td class=\"cx-ticketing-list-data\">\n            <div class=\"cx-ticketing-list-label\">\n              {{ 'customerTicketing.createdOn' | cxTranslate }}\n            </div>\n            <a\n              [routerLink]=\"\n                {\n                  cxRoute: 'supportTicketDetails',\n                  params: { ticketCode: ticket.id },\n                } | cxUrl\n              \"\n              class=\"cx-ticketing-list-value\"\n            >\n              {{ ticket.createdAt | cxDate }}\n            </a>\n          </td>\n          <td class=\"cx-ticketing-list-data\">\n            <div class=\"cx-ticketing-list-label\">\n              {{ 'customerTicketing.changedOn' | cxTranslate }}\n            </div>\n            <a\n              [routerLink]=\"\n                {\n                  cxRoute: 'supportTicketDetails',\n                  params: { ticketCode: ticket.id },\n                } | cxUrl\n              \"\n              class=\"cx-ticketing-list-value\"\n            >\n              {{ ticket.modifiedAt | cxDate }}\n            </a>\n          </td>\n          <td class=\"cx-ticketing-list-data\">\n            <div class=\"cx-ticketing-list-label\">\n              {{ 'customerTicketing.status' | cxTranslate }}\n            </div>\n            <a\n              [routerLink]=\"\n                {\n                  cxRoute: 'supportTicketDetails',\n                  params: { ticketCode: ticket.id },\n                } | cxUrl\n              \"\n              class=\"cx-ticketing-list-value\"\n              [ngClass]=\"getStatusClass(ticket.status.id)\"\n            >\n              {{ ticket.status?.name }}\n            </a>\n          </td>\n        </tr>\n      </tbody>\n    </table>\n    <div class=\"cx-ticketing-list-sort bottom\">\n      <div\n        *ngIf=\"ticketList.pagination?.totalPages > 1\"\n        class=\"cx-ticketing-list-pagination\"\n      >\n        <cx-pagination\n          [pagination]=\"ticketList.pagination\"\n          (viewPageEvent)=\"pageChange($event)\"\n        ></cx-pagination>\n      </div>\n    </div>\n  </ng-container>\n  <ng-template #noCustomerTickets>\n    <cx-customer-ticketing-create></cx-customer-ticketing-create>\n    <ng-container>\n      <div class=\"text-center\">\n        <h3>{{ 'customerTicketingList.noTickets' | cxTranslate }}</h3>\n      </div>\n    </ng-container>\n  </ng-template>\n</ng-container>\n\n<ng-template #spinner>\n  <cx-spinner></cx-spinner>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SortingComponent, selector: "cx-sorting", inputs: ["sortOptions", "ariaControls", "ariaLabel", "selectedOption", "placeholder", "sortLabels"], outputs: ["sortListEvent"] }, { kind: "component", type: CustomerTicketingCreateComponent, selector: "cx-customer-ticketing-create" }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: PaginationComponent, selector: "cx-pagination", inputs: ["pageRoute", "queryParam", "defaultPage", "pagination", "paginationID"], outputs: ["viewPageEvent"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: CxDatePipe, name: "cxDate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-customer-ticketing-list', imports: [
                        NgIf,
                        SortingComponent,
                        CustomerTicketingCreateComponent,
                        NgFor,
                        RouterLink,
                        NgClass,
                        PaginationComponent,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                        CxDatePipe,
                        UrlPipe,
                    ], template: "<ng-container *ngIf=\"tickets$ | async as ticketList; else spinner\">\n  <span class=\"cx-ticketing-list-title\">\n    <h2 class=\"cx-ticketing-list-title-text\">\n      {{ 'customerTicketingList.requestTitle' | cxTranslate }}\n      ({{ ticketList.pagination?.totalResults || 0 }})\n    </h2>\n  </span>\n  <ng-container *ngIf=\"ticketList.tickets.length > 0; else noCustomerTickets\">\n    <div class=\"cx-ticketing-list-sort top\">\n      <label class=\"cx-ticketing-list-form-group form-group\">\n        <span>\n          {{ 'customerTicketingList.sortSubtitle' | cxTranslate }}\n        </span>\n        <cx-sorting\n          [sortOptions]=\"ticketList.sorts\"\n          [sortLabels]=\"getSortLabels() | async\"\n          (sortListEvent)=\"changeSortCode($event)\"\n          [selectedOption]=\"ticketList.pagination?.sort\"\n          placeholder=\"{{ 'customerTicketingList.sortSubtitle' | cxTranslate }}\"\n          [ariaLabel]=\"'customerTicketingList.sortOrders' | cxTranslate\"\n          ariaControls=\"ticketing-list-table\"\n        ></cx-sorting>\n      </label>\n      <cx-customer-ticketing-create></cx-customer-ticketing-create>\n    </div>\n    <table\n      id=\"ticketing-list-table\"\n      class=\"table cx-ticketing-list-table\"\n      aria-hidden=\"true\"\n    >\n      <thead class=\"cx-ticketing-list-thead-mobile\">\n        <tr>\n          <th scope=\"col\">{{ 'customerTicketing.ticketId' | cxTranslate }}</th>\n          <th scope=\"col\">\n            {{ 'customerTicketingList.subject' | cxTranslate }}\n          </th>\n          <th scope=\"col\">\n            {{ 'customerTicketingList.ticketCategory' | cxTranslate }}\n          </th>\n          <th scope=\"col\">{{ 'customerTicketing.createdOn' | cxTranslate }}</th>\n          <th scope=\"col\">{{ 'customerTicketing.changedOn' | cxTranslate }}</th>\n          <th scope=\"col\">{{ 'customerTicketing.status' | cxTranslate }}</th>\n        </tr>\n      </thead>\n      <tbody>\n        <tr\n          *ngFor=\"let ticket of ticketList.tickets\"\n          (click)=\"goToTicketDetail(ticket.id)\"\n        >\n          <td class=\"cx-ticketing-list-data cx-ticketing-list-id\">\n            <div class=\"cx-ticketing-list-label\">\n              {{ 'customerTicketingList.mobile.ticketIdFull' | cxTranslate }}\n            </div>\n            <a\n              [routerLink]=\"\n                {\n                  cxRoute: 'supportTicketDetails',\n                  params: { ticketCode: ticket.id },\n                } | cxUrl\n              \"\n              class=\"cx-ticketing-list-value\"\n            >\n              {{ ticket.id }}\n            </a>\n          </td>\n          <td class=\"cx-ticketing-list-data\">\n            <div class=\"cx-ticketing-list-label\">\n              {{ 'customerTicketingList.subject' | cxTranslate }}\n            </div>\n            <a\n              [routerLink]=\"\n                {\n                  cxRoute: 'supportTicketDetails',\n                  params: { ticketCode: ticket.id },\n                } | cxUrl\n              \"\n              class=\"cx-ticketing-list-value\"\n            >\n              {{ ticket.subject }}\n            </a>\n          </td>\n          <td class=\"cx-ticketing-list-data\">\n            <div class=\"cx-ticketing-list-label\">\n              {{ 'customerTicketingList.ticketCategory' | cxTranslate }}\n            </div>\n            <a\n              [routerLink]=\"\n                {\n                  cxRoute: 'supportTicketDetails',\n                  params: { ticketCode: ticket.id },\n                } | cxUrl\n              \"\n              class=\"cx-ticketing-list-value\"\n            >\n              {{ ticket.ticketCategory?.name }}\n            </a>\n          </td>\n          <td class=\"cx-ticketing-list-data\">\n            <div class=\"cx-ticketing-list-label\">\n              {{ 'customerTicketing.createdOn' | cxTranslate }}\n            </div>\n            <a\n              [routerLink]=\"\n                {\n                  cxRoute: 'supportTicketDetails',\n                  params: { ticketCode: ticket.id },\n                } | cxUrl\n              \"\n              class=\"cx-ticketing-list-value\"\n            >\n              {{ ticket.createdAt | cxDate }}\n            </a>\n          </td>\n          <td class=\"cx-ticketing-list-data\">\n            <div class=\"cx-ticketing-list-label\">\n              {{ 'customerTicketing.changedOn' | cxTranslate }}\n            </div>\n            <a\n              [routerLink]=\"\n                {\n                  cxRoute: 'supportTicketDetails',\n                  params: { ticketCode: ticket.id },\n                } | cxUrl\n              \"\n              class=\"cx-ticketing-list-value\"\n            >\n              {{ ticket.modifiedAt | cxDate }}\n            </a>\n          </td>\n          <td class=\"cx-ticketing-list-data\">\n            <div class=\"cx-ticketing-list-label\">\n              {{ 'customerTicketing.status' | cxTranslate }}\n            </div>\n            <a\n              [routerLink]=\"\n                {\n                  cxRoute: 'supportTicketDetails',\n                  params: { ticketCode: ticket.id },\n                } | cxUrl\n              \"\n              class=\"cx-ticketing-list-value\"\n              [ngClass]=\"getStatusClass(ticket.status.id)\"\n            >\n              {{ ticket.status?.name }}\n            </a>\n          </td>\n        </tr>\n      </tbody>\n    </table>\n    <div class=\"cx-ticketing-list-sort bottom\">\n      <div\n        *ngIf=\"ticketList.pagination?.totalPages > 1\"\n        class=\"cx-ticketing-list-pagination\"\n      >\n        <cx-pagination\n          [pagination]=\"ticketList.pagination\"\n          (viewPageEvent)=\"pageChange($event)\"\n        ></cx-pagination>\n      </div>\n    </div>\n  </ng-container>\n  <ng-template #noCustomerTickets>\n    <cx-customer-ticketing-create></cx-customer-ticketing-create>\n    <ng-container>\n      <div class=\"text-center\">\n        <h3>{{ 'customerTicketingList.noTickets' | cxTranslate }}</h3>\n      </div>\n    </ng-container>\n  </ng-template>\n</ng-container>\n\n<ng-template #spinner>\n  <cx-spinner></cx-spinner>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1.CustomerTicketingFacade }, { type: i1$2.RoutingService }, { type: i1$2.TranslationService }, { type: i1.CustomerTicketingConfig }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingListModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingListModule, imports: [CustomerTicketingCreateModule,
            CommonModule,
            I18nModule,
            UrlModule,
            CardModule,
            IconModule,
            ListNavigationModule,
            RouterModule,
            SpinnerModule,
            CustomerTicketingListComponent], exports: [CustomerTicketingListComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingListModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    SupportTicketHistoryComponent: {
                        component: CustomerTicketingListComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
        ], imports: [CustomerTicketingCreateModule,
            CommonModule,
            I18nModule,
            UrlModule,
            CardModule,
            IconModule,
            ListNavigationModule,
            RouterModule,
            SpinnerModule,
            CustomerTicketingListComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CustomerTicketingCreateModule,
                        CommonModule,
                        I18nModule,
                        UrlModule,
                        CardModule,
                        IconModule,
                        ListNavigationModule,
                        RouterModule,
                        SpinnerModule,
                        CustomerTicketingListComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                SupportTicketHistoryComponent: {
                                    component: CustomerTicketingListComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                    ],
                    exports: [CustomerTicketingListComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingDetailsComponent {
    constructor(translation, customerTicketingFacade, routingService, eventService) {
        this.translation = translation;
        this.customerTicketingFacade = customerTicketingFacade;
        this.routingService = routingService;
        this.eventService = eventService;
        this.dateFormat = DATE_FORMAT;
        this.subscription = new Subscription();
        this.ticketDetails$ = this.customerTicketingFacade.getTicket();
        this.reloadOnRedirection();
    }
    prepareCardContent(entity, titleTranslation, id) {
        return this.translation.translate(titleTranslation).pipe(filter(() => Boolean(entity)), map$1((textTitle) => ({
            title: textTitle,
            text: [entity || ''],
            customClass: this.getStatusClass(id?.toUpperCase()),
        })));
    }
    getStatusClass(id) {
        if (id === STATUS.OPEN || id === STATUS.INPROCESS) {
            return TEXT_COLOR_CLASS.GREEN;
        }
        else if (id === STATUS.CLOSED) {
            return TEXT_COLOR_CLASS.GREY;
        }
        return '';
    }
    reloadOnRedirection() {
        this.subscription = combineLatest([
            this.ticketDetails$,
            this.routingService.getParams().pipe(map$1((params) => params.ticketCode)),
        ])
            .pipe(take(1), tap(([ticket, ticketCode]) => {
            if (ticket && ticketCode !== ticket?.id) {
                this.eventService.dispatch({}, GetTicketQueryReloadEvent);
            }
        }))
            .subscribe();
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingDetailsComponent, deps: [{ token: i1$2.TranslationService }, { token: i1.CustomerTicketingFacade }, { token: i1$2.RoutingService }, { token: i1$2.EventService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CustomerTicketingDetailsComponent, isStandalone: true, selector: "cx-customer-ticketing-details", ngImport: i0, template: "<ng-container *ngIf=\"ticketDetails$ | async as ticket; else spinner\">\n  <div class=\"cx-ticket-details\">\n    <div class=\"container\">\n      <div class=\"cx-details-card\">\n        <cx-card\n          [content]=\"\n            prepareCardContent(ticket.id, 'customerTicketing.ticketId') | async\n          \"\n        ></cx-card>\n      </div>\n\n      <div class=\"cx-details-card\">\n        <cx-card\n          [content]=\"\n            prepareCardContent(\n              (ticket.createdAt | cxDate: dateFormat) ?? dateFormat,\n              'customerTicketing.createdOn'\n            ) | async\n          \"\n        ></cx-card>\n      </div>\n\n      <div class=\"cx-details-card\">\n        <cx-card\n          [content]=\"\n            prepareCardContent(\n              (ticket.modifiedAt | cxDate: dateFormat) ?? dateFormat,\n              'customerTicketing.changedOn'\n            ) | async\n          \"\n        ></cx-card>\n      </div>\n\n      <div class=\"cx-details-card\">\n        <cx-card\n          [content]=\"\n            prepareCardContent(\n              ticket.status ? ticket.status.name : undefined,\n              'customerTicketing.status',\n              ticket.status ? ticket.status.id : undefined\n            ) | async\n          \"\n        ></cx-card>\n      </div>\n    </div>\n  </div>\n</ng-container>\n<ng-template #spinner>\n  <cx-spinner></cx-spinner>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CardComponent, selector: "cx-card", inputs: ["border", "editMode", "isDefault", "content", "fitToContainer", "truncateText", "truncateParagraphText", "charactersLimit", "index", "role"], outputs: ["deleteCard", "setDefaultCard", "sendCard", "editCard", "cancelCard"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: CxDatePipe, name: "cxDate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-customer-ticketing-details', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, CardComponent, SpinnerComponent, AsyncPipe, CxDatePipe], template: "<ng-container *ngIf=\"ticketDetails$ | async as ticket; else spinner\">\n  <div class=\"cx-ticket-details\">\n    <div class=\"container\">\n      <div class=\"cx-details-card\">\n        <cx-card\n          [content]=\"\n            prepareCardContent(ticket.id, 'customerTicketing.ticketId') | async\n          \"\n        ></cx-card>\n      </div>\n\n      <div class=\"cx-details-card\">\n        <cx-card\n          [content]=\"\n            prepareCardContent(\n              (ticket.createdAt | cxDate: dateFormat) ?? dateFormat,\n              'customerTicketing.createdOn'\n            ) | async\n          \"\n        ></cx-card>\n      </div>\n\n      <div class=\"cx-details-card\">\n        <cx-card\n          [content]=\"\n            prepareCardContent(\n              (ticket.modifiedAt | cxDate: dateFormat) ?? dateFormat,\n              'customerTicketing.changedOn'\n            ) | async\n          \"\n        ></cx-card>\n      </div>\n\n      <div class=\"cx-details-card\">\n        <cx-card\n          [content]=\"\n            prepareCardContent(\n              ticket.status ? ticket.status.name : undefined,\n              'customerTicketing.status',\n              ticket.status ? ticket.status.id : undefined\n            ) | async\n          \"\n        ></cx-card>\n      </div>\n    </div>\n  </div>\n</ng-container>\n<ng-template #spinner>\n  <cx-spinner></cx-spinner>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1$2.TranslationService }, { type: i1.CustomerTicketingFacade }, { type: i1$2.RoutingService }, { type: i1$2.EventService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingDetailsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingDetailsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingDetailsModule, imports: [CommonModule,
            I18nModule,
            UrlModule,
            CardModule,
            SpinnerModule,
            CustomerTicketingDetailsComponent], exports: [CustomerTicketingDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingDetailsModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    SupportTicketDetailsComponent: {
                        component: CustomerTicketingDetailsComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            UrlModule,
            CardModule,
            SpinnerModule,
            CustomerTicketingDetailsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingDetailsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        UrlModule,
                        CardModule,
                        SpinnerModule,
                        CustomerTicketingDetailsComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                SupportTicketDetailsComponent: {
                                    component: CustomerTicketingDetailsComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                    ],
                    exports: [CustomerTicketingDetailsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingReopenComponentService {
    constructor() {
        this.customerTicketingFacade = inject(CustomerTicketingFacade);
    }
    enableReopenButton() {
        return this.customerTicketingFacade
            .getTicket()
            .pipe(map((ticket) => ticket?.status?.id === STATUS.CLOSED &&
            ticket.availableStatusTransitions?.some((status) => status.id.toUpperCase() === STATUS.INPROCESS ||
                status.id.toUpperCase() === STATUS.OPEN)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingReopenComponentService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingReopenComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingReopenComponentService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingReopenComponent {
    constructor(customerTicketingFacade, launchDialogService, vcr) {
        this.customerTicketingFacade = customerTicketingFacade;
        this.launchDialogService = launchDialogService;
        this.vcr = vcr;
        this.subscription = new Subscription();
        this.CustomerTicketingReopenComponentService = inject(CustomerTicketingReopenComponentService);
        this.enableReopenButton$ = this.CustomerTicketingReopenComponentService.enableReopenButton();
    }
    openDialog() {
        const dialog = this.launchDialogService.openDialog(LAUNCH_CALLER.CUSTOMER_TICKETING_REOPEN, this.element, this.vcr);
        if (dialog) {
            this.subscription.add(dialog.pipe(take(1)).subscribe());
        }
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingReopenComponent, deps: [{ token: i1.CustomerTicketingFacade }, { token: i1$1.LaunchDialogService }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CustomerTicketingReopenComponent, isStandalone: true, selector: "cx-customer-ticketing-reopen", viewQueries: [{ propertyName: "element", first: true, predicate: ["element"], descendants: true }], ngImport: i0, template: "<div class=\"col-xs-12 col-md-5 col-lg-4\" *ngIf=\"enableReopenButton$ | async\">\n  <button #element class=\"btn btn-block btn-secondary\" (click)=\"openDialog()\">\n    {{ 'customerTicketingDetails.reopenRequest' | cxTranslate }}\n  </button>\n</div>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingReopenComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-customer-ticketing-reopen', imports: [NgIf, AsyncPipe, TranslatePipe], template: "<div class=\"col-xs-12 col-md-5 col-lg-4\" *ngIf=\"enableReopenButton$ | async\">\n  <button #element class=\"btn btn-block btn-secondary\" (click)=\"openDialog()\">\n    {{ 'customerTicketingDetails.reopenRequest' | cxTranslate }}\n  </button>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1.CustomerTicketingFacade }, { type: i1$1.LaunchDialogService }, { type: i0.ViewContainerRef }], propDecorators: { element: [{
                type: ViewChild,
                args: ['element']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingReopenModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingReopenModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingReopenModule, imports: [CommonModule,
            I18nModule,
            IconModule,
            KeyboardFocusModule,
            ReactiveFormsModule,
            FormErrorsModule,
            FileUploadModule,
            SpinnerModule,
            CustomerTicketingReopenComponent,
            CustomerTicketingReopenDialogComponent], exports: [CustomerTicketingReopenComponent,
            CustomerTicketingReopenDialogComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingReopenModule, providers: [
            CustomerTicketingReopenComponentService,
            provideDefaultConfig({
                cmsComponents: {
                    SupportTicketReopenComponent: {
                        component: CustomerTicketingReopenComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            IconModule,
            KeyboardFocusModule,
            ReactiveFormsModule,
            FormErrorsModule,
            FileUploadModule,
            SpinnerModule,
            CustomerTicketingReopenDialogComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingReopenModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        IconModule,
                        KeyboardFocusModule,
                        ReactiveFormsModule,
                        FormErrorsModule,
                        FileUploadModule,
                        SpinnerModule,
                        CustomerTicketingReopenComponent,
                        CustomerTicketingReopenDialogComponent,
                    ],
                    providers: [
                        CustomerTicketingReopenComponentService,
                        provideDefaultConfig({
                            cmsComponents: {
                                SupportTicketReopenComponent: {
                                    component: CustomerTicketingReopenComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                    ],
                    exports: [
                        CustomerTicketingReopenComponent,
                        CustomerTicketingReopenDialogComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingMessagesComponentService {
    displayAddMessageSection(ticket) {
        return ticket?.status?.id !== STATUS.CLOSED;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingMessagesComponentService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingMessagesComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingMessagesComponentService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingMessagesComponent {
    constructor(customerTicketingConfig, customerTicketingFacade, eventService) {
        this.customerTicketingConfig = customerTicketingConfig;
        this.customerTicketingFacade = customerTicketingFacade;
        this.eventService = eventService;
        this.customerTicketingMessagesComponentService = inject(CustomerTicketingMessagesComponentService);
        this.ticketDetails$ = this.customerTicketingFacade.getTicket();
        this.subscription = new Subscription();
        this.messageEvents$ = this.prepareMessageEvents();
        this.messagingConfigs = this.prepareMessagingConfigs();
    }
    onSend(event) {
        const mustWaitForAttachment = (event.files instanceof FileList && event.files?.length > 0) ?? false;
        this.subscription.add(this.customerTicketingFacade
            .createTicketEvent(this.prepareTicketEvent(event.message), mustWaitForAttachment)
            .subscribe((createdEvent) => {
            if (event.files && event.files?.length && createdEvent.code) {
                this.customerTicketingFacade.uploadAttachment(event.files.item(0), createdEvent.code);
            }
            this.messagingComponent?.resetForm();
        }));
    }
    downloadAttachment(event) {
        this.subscription.add(this.customerTicketingFacade
            .downloadAttachment(event.messageCode, event.attachmentId)
            .subscribe((data) => {
            const downloadURL = window.URL.createObjectURL(data);
            const link = document.createElement('a');
            link.href = downloadURL;
            link.download = event.fileName ?? '';
            link.click();
        }));
    }
    prepareMessageEvents() {
        return this.ticketDetails$.pipe(map$1((ticket) => ticket?.ticketEvents?.map((event) => ({
            ...event,
            text: event.message ?? '',
            rightAlign: event.addedByAgent || false,
            attachments: event.ticketEventAttachments ?? [],
        })) ?? []));
    }
    prepareMessagingConfigs() {
        return {
            attachmentRestrictions: this.customerTicketingConfig.customerTicketing?.attachmentRestrictions,
            charactersLimit: this.customerTicketingConfig.customerTicketing?.inputCharactersLimit,
            enableFileUploadOption: true,
            displayAddMessageSection: this.ticketDetails$.pipe(map$1((ticket) => this.customerTicketingMessagesComponentService.displayAddMessageSection(ticket))),
        };
    }
    prepareTicketEvent(messageText) {
        return {
            message: messageText,
        };
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingMessagesComponent, deps: [{ token: i1.CustomerTicketingConfig }, { token: i1.CustomerTicketingFacade }, { token: i1$2.EventService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CustomerTicketingMessagesComponent, isStandalone: true, selector: "cx-customer-ticketing-messages", viewQueries: [{ propertyName: "messagingComponent", first: true, predicate: MessagingComponent, descendants: true }], ngImport: i0, template: "<cx-messaging\n  [messageEvents$]=\"messageEvents$\"\n  [messagingConfigs]=\"messagingConfigs\"\n  (send)=\"onSend($event)\"\n  (downloadAttachment)=\"downloadAttachment($event)\"\n></cx-messaging>\n", dependencies: [{ kind: "component", type: MessagingComponent, selector: "cx-messaging", inputs: ["messageEvents$", "scrollToInput", "messagingConfigs"], outputs: ["send", "itemClicked", "downloadAttachment"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingMessagesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-customer-ticketing-messages', imports: [MessagingComponent], template: "<cx-messaging\n  [messageEvents$]=\"messageEvents$\"\n  [messagingConfigs]=\"messagingConfigs\"\n  (send)=\"onSend($event)\"\n  (downloadAttachment)=\"downloadAttachment($event)\"\n></cx-messaging>\n" }]
        }], ctorParameters: () => [{ type: i1.CustomerTicketingConfig }, { type: i1.CustomerTicketingFacade }, { type: i1$2.EventService }], propDecorators: { messagingComponent: [{
                type: ViewChild,
                args: [MessagingComponent]
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingMessagesModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingMessagesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingMessagesModule, imports: [CommonModule,
            I18nModule,
            UrlModule,
            ChatMessagingModule,
            ReactiveFormsModule,
            FormsModule,
            CustomerTicketingMessagesComponent], exports: [CustomerTicketingMessagesComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingMessagesModule, providers: [
            CustomerTicketingMessagesComponentService,
            provideDefaultConfig({
                cmsComponents: {
                    SupportTicketUpdateComponent: {
                        component: CustomerTicketingMessagesComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            UrlModule,
            ChatMessagingModule,
            ReactiveFormsModule,
            FormsModule,
            CustomerTicketingMessagesComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingMessagesModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        UrlModule,
                        ChatMessagingModule,
                        ReactiveFormsModule,
                        FormsModule,
                        CustomerTicketingMessagesComponent,
                    ],
                    providers: [
                        CustomerTicketingMessagesComponentService,
                        provideDefaultConfig({
                            cmsComponents: {
                                SupportTicketUpdateComponent: {
                                    component: CustomerTicketingMessagesComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                    ],
                    exports: [CustomerTicketingMessagesComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class MyAccountV2CustomerTicketingComponent {
    constructor() {
        this.PAGE_SIZE = 1;
        this.customerTicketingFacade = inject(CustomerTicketingFacade);
        this.tickets$ = this.customerTicketingFacade.getTickets(this.PAGE_SIZE);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MyAccountV2CustomerTicketingComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: MyAccountV2CustomerTicketingComponent, isStandalone: true, selector: "cx-my-account-v2-customer-ticketing", ngImport: i0, template: "<ng-container>\n  <div class=\"cx-my-account-customer-ticket-header\">\n    <!-- HEADER -->\n    <div\n      class=\"cx-my-account-customer-ticket-heading\"\n      role=\"heading\"\n      aria-level=\"4\"\n      [attr.aria-label]=\"'myAccountV2CustomerTicketing.heading' | cxTranslate\"\n    >\n      {{ 'myAccountV2CustomerTicketing.heading' | cxTranslate }}\n    </div>\n\n    <!-- SHOW MORE -->\n    <div class=\"cx-my-account-customer-ticket-show-more\">\n      <a\n        id=\"show-more-requests\"\n        [attr.aria-label]=\"\n          'myAccountV2CustomerTicketing.showMoreLabel' | cxTranslate\n        \"\n        class=\"btn-link cx-action-link\"\n        [routerLink]=\"\n          {\n            cxRoute: 'supportTickets',\n          } | cxUrl\n        \"\n      >\n        {{ 'myAccountV2CustomerTicketing.showMore' | cxTranslate }}\n      </a>\n    </div>\n  </div>\n  <ng-container *ngIf=\"tickets$ | async as ticketList; else spinner\">\n    <ng-container *ngIf=\"ticketList.tickets.length > 0; else noCustomerTickets\">\n      <div class=\"cx-my-account-customer-ticket-body\">\n        <ng-container *ngFor=\"let ticket of ticketList.tickets\">\n          <div class=\"cx-my-account-customer-ticket-details\">\n            <span\n              class=\"cx-my-account-customer-ticket-subject\"\n              [attr.aria-label]=\"\n                'myAccountV2CustomerTicketing.subjectLabel' | cxTranslate\n              \"\n            >\n              {{ ticket.subject }}\n            </span>\n            <span class=\"cx-my-account-customer-ticket-details-light\">\n              | {{ ticket.ticketCategory?.name }}\n            </span>\n            <span\n              class=\"cx-my-account-customer-ticket-details-light\"\n              [attr.aria-label]=\"\n                'myAccountV2CustomerTicketing.idLabel' | cxTranslate\n              \"\n            >\n              |\n              {{\n                'myAccountV2CustomerTicketing.ticketId'\n                  | cxTranslate: { value: ticket.id }\n              }}\n            </span>\n          </div>\n          <div class=\"cx-my-account-customer-ticket-details-light\">\n            {{\n              'myAccountV2CustomerTicketing.changedOn'\n                | cxTranslate\n                  : { value: ticket.modifiedAt | cxDate: 'd, MMMM, yyyy' }\n            }}\n          </div>\n        </ng-container>\n      </div>\n    </ng-container>\n  </ng-container>\n</ng-container>\n\n<ng-template #noCustomerTickets>\n  <div\n    class=\"cx-my-account-no-ticket\"\n    [attr.aria-label]=\"'customerTicketingList.noTickets' | cxTranslate\"\n  >\n    {{ 'customerTicketingList.noTickets' | cxTranslate }}\n  </div>\n</ng-template>\n\n<ng-template #spinner>\n  <cx-spinner></cx-spinner>\n</ng-template>\n", dependencies: [{ kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: CxDatePipe, name: "cxDate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MyAccountV2CustomerTicketingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-my-account-v2-customer-ticketing', imports: [
                        RouterLink,
                        NgIf,
                        NgFor,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                        CxDatePipe,
                        UrlPipe,
                    ], template: "<ng-container>\n  <div class=\"cx-my-account-customer-ticket-header\">\n    <!-- HEADER -->\n    <div\n      class=\"cx-my-account-customer-ticket-heading\"\n      role=\"heading\"\n      aria-level=\"4\"\n      [attr.aria-label]=\"'myAccountV2CustomerTicketing.heading' | cxTranslate\"\n    >\n      {{ 'myAccountV2CustomerTicketing.heading' | cxTranslate }}\n    </div>\n\n    <!-- SHOW MORE -->\n    <div class=\"cx-my-account-customer-ticket-show-more\">\n      <a\n        id=\"show-more-requests\"\n        [attr.aria-label]=\"\n          'myAccountV2CustomerTicketing.showMoreLabel' | cxTranslate\n        \"\n        class=\"btn-link cx-action-link\"\n        [routerLink]=\"\n          {\n            cxRoute: 'supportTickets',\n          } | cxUrl\n        \"\n      >\n        {{ 'myAccountV2CustomerTicketing.showMore' | cxTranslate }}\n      </a>\n    </div>\n  </div>\n  <ng-container *ngIf=\"tickets$ | async as ticketList; else spinner\">\n    <ng-container *ngIf=\"ticketList.tickets.length > 0; else noCustomerTickets\">\n      <div class=\"cx-my-account-customer-ticket-body\">\n        <ng-container *ngFor=\"let ticket of ticketList.tickets\">\n          <div class=\"cx-my-account-customer-ticket-details\">\n            <span\n              class=\"cx-my-account-customer-ticket-subject\"\n              [attr.aria-label]=\"\n                'myAccountV2CustomerTicketing.subjectLabel' | cxTranslate\n              \"\n            >\n              {{ ticket.subject }}\n            </span>\n            <span class=\"cx-my-account-customer-ticket-details-light\">\n              | {{ ticket.ticketCategory?.name }}\n            </span>\n            <span\n              class=\"cx-my-account-customer-ticket-details-light\"\n              [attr.aria-label]=\"\n                'myAccountV2CustomerTicketing.idLabel' | cxTranslate\n              \"\n            >\n              |\n              {{\n                'myAccountV2CustomerTicketing.ticketId'\n                  | cxTranslate: { value: ticket.id }\n              }}\n            </span>\n          </div>\n          <div class=\"cx-my-account-customer-ticket-details-light\">\n            {{\n              'myAccountV2CustomerTicketing.changedOn'\n                | cxTranslate\n                  : { value: ticket.modifiedAt | cxDate: 'd, MMMM, yyyy' }\n            }}\n          </div>\n        </ng-container>\n      </div>\n    </ng-container>\n  </ng-container>\n</ng-container>\n\n<ng-template #noCustomerTickets>\n  <div\n    class=\"cx-my-account-no-ticket\"\n    [attr.aria-label]=\"'customerTicketingList.noTickets' | cxTranslate\"\n  >\n    {{ 'customerTicketingList.noTickets' | cxTranslate }}\n  </div>\n</ng-template>\n\n<ng-template #spinner>\n  <cx-spinner></cx-spinner>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class MyAccountV2CustomerTicketingModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MyAccountV2CustomerTicketingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: MyAccountV2CustomerTicketingModule, imports: [CommonModule,
            I18nModule,
            UrlModule,
            SpinnerModule,
            RouterModule,
            MyAccountV2CustomerTicketingComponent], exports: [MyAccountV2CustomerTicketingComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MyAccountV2CustomerTicketingModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    MyAccountViewRequestsComponent: {
                        component: MyAccountV2CustomerTicketingComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            UrlModule,
            SpinnerModule,
            RouterModule,
            MyAccountV2CustomerTicketingComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MyAccountV2CustomerTicketingModule, decorators: [{
            type: NgModule,
            args: [{
                    exports: [MyAccountV2CustomerTicketingComponent],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                MyAccountViewRequestsComponent: {
                                    component: MyAccountV2CustomerTicketingComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                    ],
                    imports: [
                        CommonModule,
                        I18nModule,
                        UrlModule,
                        SpinnerModule,
                        RouterModule,
                        MyAccountV2CustomerTicketingComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CustomerTicketingComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingComponentsModule, imports: [ReactiveFormsModule,
            FormErrorsModule,
            CustomerTicketingDetailsModule,
            CustomerTicketingCloseModule,
            CustomerTicketingReopenModule,
            CustomerTicketingListModule,
            CustomerTicketingMessagesModule,
            CustomerTicketingCreateModule,
            MyAccountV2CustomerTicketingModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingComponentsModule, providers: [provideDefaultConfig(defaultCustomerTicketingFormLayoutConfig)], imports: [ReactiveFormsModule,
            FormErrorsModule,
            CustomerTicketingDetailsModule,
            CustomerTicketingCloseModule,
            CustomerTicketingReopenModule,
            CustomerTicketingListModule,
            CustomerTicketingMessagesModule,
            CustomerTicketingCreateModule,
            MyAccountV2CustomerTicketingModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CustomerTicketingComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        ReactiveFormsModule,
                        FormErrorsModule,
                        CustomerTicketingDetailsModule,
                        CustomerTicketingCloseModule,
                        CustomerTicketingReopenModule,
                        CustomerTicketingListModule,
                        CustomerTicketingMessagesModule,
                        CustomerTicketingCreateModule,
                        MyAccountV2CustomerTicketingModule,
                    ],
                    providers: [provideDefaultConfig(defaultCustomerTicketingFormLayoutConfig)],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CustomerTicketingCloseComponent, CustomerTicketingCloseComponentService, CustomerTicketingCloseDialogComponent, CustomerTicketingCloseModule, CustomerTicketingComponentsModule, CustomerTicketingCreateComponent, CustomerTicketingCreateDialogComponent, CustomerTicketingCreateModule, CustomerTicketingDetailsComponent, CustomerTicketingDetailsModule, CustomerTicketingDialogComponent, CustomerTicketingListComponent, CustomerTicketingListModule, CustomerTicketingMessagesComponent, CustomerTicketingMessagesComponentService, CustomerTicketingMessagesModule, CustomerTicketingReopenComponent, CustomerTicketingReopenComponentService, CustomerTicketingReopenDialogComponent, CustomerTicketingReopenModule, MyAccountV2CustomerTicketingComponent, MyAccountV2CustomerTicketingModule, defaultCustomerTicketingFormLayoutConfig };
//# sourceMappingURL=spartacus-customer-ticketing-components.mjs.map
