import * as i0 from '@angular/core';
import { OnDestroy } from '@angular/core';
import { EventService, GlobalMessageService, CmsConfig, CxEvent, PaginationModel, SortModel, QueryState } from '@spartacus/core';
import { Subscription, Observable } from 'rxjs';
import * as i2 from '@angular/router';

declare abstract class CustomerTicketingConfig {
    customerTicketing?: {
        agentSessionTimer?: {
            startingDelayInSeconds?: number;
        };
        attachmentRestrictions?: {
            maxSize?: number;
            allowedTypes?: string[];
        };
        inputCharactersLimit?: number;
        inputCharactersLimitForSubject?: number;
        listViewPageSize?: number;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomerTicketingConfig>;
}
declare module '@spartacus/core' {
    interface Config extends CustomerTicketingConfig {
    }
}

declare const defaultCustomerTicketingConfig: CustomerTicketingConfig;

declare const MAX_INPUT_CHARACTERS = 5000;
declare const MAX_INPUT_CHARACTERS_FOR_SUBJECT = 255;
declare const MAX_SIZE_FOR_ATTACHMENT = 10;
declare const MAX_ENTRIES_FOR_ATTACHMENT = 1;
declare const DATE_FORMAT = "MMMM d, YYYY h:mm aa";
declare const LIST_VIEW_PAGE_SIZE = 5;

declare class CustomerTicketingEventListener implements OnDestroy {
    protected eventService: EventService;
    protected globalMessageService: GlobalMessageService;
    protected subscriptions: Subscription;
    constructor(eventService: EventService, globalMessageService: GlobalMessageService);
    protected onTicketCreatedEvent(): void;
    protected onLanguageAndCurrencySetEvent(): void;
    protected onLoginAndLogoutEvent(): void;
    protected onNewMessage(): void;
    protected onTicketClosed(): void;
    protected onTicketReopened(): void;
    protected onUploadAttachmentSucess(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomerTicketingEventListener>;
}

declare class CustomerTicketingEventModule {
    constructor(_customerTicketingEventListener: CustomerTicketingEventListener);
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CustomerTicketingEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CustomerTicketingEventModule>;
}

declare function defaultCustomerTicketingComponentsConfig(): CmsConfig;
declare class CustomerTicketingRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CustomerTicketingRootModule, never, [typeof CustomerTicketingEventModule, typeof i2.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CustomerTicketingRootModule>;
}

declare class GetTicketQueryResetEvent extends CxEvent {
    static readonly type = "GetTicketQueryResetEvent";
}
declare class GetTicketQueryReloadEvent extends CxEvent {
    static readonly type = "GetTicketQueryReloadEvent";
}
declare class GetTicketsQueryResetEvents extends CxEvent {
    static readonly type = "GetTicketsQueryResetEvents";
}
declare class GetTicketsQueryReloadEvents extends CxEvent {
    static readonly type = "GetTicketsQueryReloadEvents";
}
declare class NewMessageEvent extends CxEvent {
    static readonly type = "NewMessageEvent";
}
declare class TicketReopenedEvent extends CxEvent {
    static readonly type = "TicketReopenedEvent";
}
declare class TicketClosedEvent extends CxEvent {
    static readonly type = "TicketClosedEvent";
}
declare class GetTicketCategoryQueryResetEvent extends CxEvent {
    static readonly type = "GetTicketCategoryQueryResetEvent";
}
declare class GetTicketCategoryQueryReloadEvent extends CxEvent {
    static readonly type = "GetTicketCategoryQueryReloadEvent";
}
declare class GetTicketAssociatedObjectsQueryResetEvent extends CxEvent {
    static readonly type = "GetTicketAssociatedObjectsQueryResetEvent";
}
declare class GetTicketAssociatedObjectsQueryReloadEvent extends CxEvent {
    static readonly type = "GetTicketAssociatedObjectsQueryReloadEvent";
}
declare class TicketCreatedEvent extends CxEvent {
    static readonly type = "TicketCreatedEvent";
}
declare class CreateEvent extends CxEvent {
    static readonly type = "CreateEvent";
}
declare class UploadAttachmentSuccessEvent extends CxEvent {
    static readonly type = "UploadAttachmentSuccessEvent";
}

declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        CUSTOMER_TICKETING_REOPEN = "CUSTOMER_TICKETING_REOPEN",
        CUSTOMER_TICKETING_CLOSE = "CUSTOMER_TICKETING_CLOSE",
        CUSTOMER_TICKETING_CREATE = "CUSTOMER_TICKETING_CREATE"
    }
}

declare enum TEXT_COLOR_CLASS {
    GREY = "cx-text-grey",
    GREEN = "cx-text-green"
}
declare enum STATUS {
    OPEN = "OPEN",
    CLOSED = "CLOSED",
    INPROCESS = "INPROCESS"
}
declare enum STATUS_NAME {
    OPEN = "Open",
    CLOSED = "Closed",
    INPROCESS = "INPROCESS"
}
interface TicketDetails {
    availableStatusTransitions?: Array<Status>;
    id?: string;
    createdAt?: string;
    modifiedAt?: string;
    status?: Status;
    subject?: string;
    ticketCategory?: Category;
    ticketEvents?: Array<TicketEvent>;
}
interface Status {
    id: string;
    name: string;
}
interface Category {
    id: string;
    name: string;
}
interface CategoriesList {
    ticketCategories?: Category[];
}
interface AssociatedObject {
    code: string;
    modifiedAt: string;
    type: string;
}
interface AssociatedObjectsList {
    ticketAssociatedObjects: AssociatedObject[];
}
interface TicketEvent {
    author?: string;
    createdAt?: string;
    message?: string;
    toStatus?: Status;
    code?: string;
    addedByAgent?: boolean;
    ticketEventAttachments?: Array<Attachment>;
}
interface Attachment {
    id?: string;
    filename?: string;
}
interface TicketList {
    pagination?: PaginationModel;
    sorts?: SortModel[];
    tickets?: Array<TicketDetails>;
}
interface TicketSearchConfig {
    pageSize?: number;
    currentPage?: number;
    sort?: string;
}
interface TicketStarter {
    associatedTo?: AssociatedObject;
    message?: string;
    subject?: string;
    ticketCategory?: Category;
    attachments?: Array<Attachment>;
}

declare abstract class CustomerTicketingFacade {
    abstract getTicketState(): Observable<QueryState<TicketDetails | undefined>>;
    abstract getTicket(): Observable<TicketDetails | undefined>;
    abstract getTicketsState(pageSize: number, currentPage?: number, sort?: string): Observable<QueryState<TicketList | undefined>>;
    abstract getTickets(pageSize: number, currentPage?: number, sort?: string): Observable<TicketList | undefined>;
    abstract getTicketCategoriesState(): Observable<QueryState<Category[]>>;
    abstract getTicketCategories(): Observable<Category[]>;
    abstract getTicketAssociatedObjectsState(): Observable<QueryState<AssociatedObject[]>>;
    abstract getTicketAssociatedObjects(): Observable<AssociatedObject[]>;
    abstract createTicket(ticket: TicketStarter): Observable<TicketDetails>;
    abstract createTicketEvent(ticketEvent: TicketEvent, containsAttachment?: boolean): Observable<TicketEvent>;
    abstract uploadAttachment(file: File, eventCode: string, ticketId?: string): Observable<unknown>;
    abstract downloadAttachment(eventCode: string | undefined, attachmentId: string | undefined): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomerTicketingFacade>;
}

declare const CUSTOMER_TICKETING_FEATURE = "customerTicketing";
declare const CUSTOMER_TICKETING_CORE_FEATURE = "customerTicketingCore";

export { CUSTOMER_TICKETING_CORE_FEATURE, CUSTOMER_TICKETING_FEATURE, CreateEvent, CustomerTicketingConfig, CustomerTicketingEventListener, CustomerTicketingEventModule, CustomerTicketingFacade, CustomerTicketingRootModule, DATE_FORMAT, GetTicketAssociatedObjectsQueryReloadEvent, GetTicketAssociatedObjectsQueryResetEvent, GetTicketCategoryQueryReloadEvent, GetTicketCategoryQueryResetEvent, GetTicketQueryReloadEvent, GetTicketQueryResetEvent, GetTicketsQueryReloadEvents, GetTicketsQueryResetEvents, LIST_VIEW_PAGE_SIZE, MAX_ENTRIES_FOR_ATTACHMENT, MAX_INPUT_CHARACTERS, MAX_INPUT_CHARACTERS_FOR_SUBJECT, MAX_SIZE_FOR_ATTACHMENT, NewMessageEvent, STATUS, STATUS_NAME, TEXT_COLOR_CLASS, TicketClosedEvent, TicketCreatedEvent, TicketReopenedEvent, UploadAttachmentSuccessEvent, defaultCustomerTicketingComponentsConfig, defaultCustomerTicketingConfig };
export type { AssociatedObject, AssociatedObjectsList, Attachment, CategoriesList, Category, Status, TicketDetails, TicketEvent, TicketList, TicketSearchConfig, TicketStarter };
