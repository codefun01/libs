import * as i0 from '@angular/core';
import { Injectable, inject, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import * as i1$1 from '@spartacus/cdc/root';
import { CdcReConsentEvent, CdcConsentManagementComponentService, CdcJsService } from '@spartacus/cdc/root';
import * as i1 from '@spartacus/core';
import { GlobalMessageType, TranslatePipe, I18nModule, provideDefaultConfig, UrlModule, AuthService, GlobalMessageService, WindowRef, NotAuthGuard } from '@spartacus/core';
import { LoginFormComponentService, LoginFormComponent } from '@spartacus/user/account/components';
import { Subscription, of, map } from 'rxjs';
import { NgIf, NgFor, AsyncPipe, CommonModule } from '@angular/common';
import { UntypedFormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import * as i2 from '@spartacus/storefront';
import { LAUNCH_CALLER, ICON_TYPE, FocusDirective, IconComponent, ConsentManagementFormComponent, BtnLikeLinkDirective, SpinnerComponent, DIALOG_TYPE, SpinnerModule, IconModule, KeyboardFocusModule, ConsentManagementModule, BtnLikeLinkModule, FormErrorsModule } from '@spartacus/storefront';
import { take } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CdcLoginFormComponentService extends LoginFormComponentService {
    constructor(auth, globalMessageService, winRef, cdcJsService) {
        super(auth, globalMessageService, winRef);
        this.auth = auth;
        this.globalMessageService = globalMessageService;
        this.winRef = winRef;
        this.cdcJsService = cdcJsService;
        this.subscription = new Subscription();
    }
    login() {
        if (!this.form.valid) {
            this.form.markAllAsTouched();
            return;
        }
        this.busy$.next(true);
        this.subscription.add(this.cdcJsService.didLoad().subscribe((cdcLoaded) => {
            if (cdcLoaded) {
                // Logging in using CDC Gigya SDK
                this.cdcJsService
                    .loginUserWithoutScreenSet(this.form.value.userId.toLowerCase(), this.form.value.password)
                    .subscribe({
                    next: () => this.busy$.next(false),
                    error: () => this.busy$.next(false),
                });
            }
            else {
                // CDC Gigya SDK not loaded, show error to the user
                this.globalMessageService.add({
                    key: 'errorHandlers.scriptFailedToLoad',
                }, GlobalMessageType.MSG_TYPE_ERROR);
                this.busy$.next(false);
            }
        }));
    }
    initCustomLogin() {
        // Intentional empty method , so csrf token is not initialized in case of CDC
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdcLoginFormComponentService, deps: [{ token: i1.AuthService }, { token: i1.GlobalMessageService }, { token: i1.WindowRef }, { token: i1$1.CdcJsService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdcLoginFormComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdcLoginFormComponentService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.AuthService }, { type: i1.GlobalMessageService }, { type: i1.WindowRef }, { type: i1$1.CdcJsService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CdcReconsentDialogEventListener {
    constructor(eventService, launchDialogService) {
        this.eventService = eventService;
        this.launchDialogService = launchDialogService;
        this.subscription = new Subscription();
        this.onReconsent();
    }
    onReconsent() {
        this.subscription.add(this.eventService.get(CdcReConsentEvent).subscribe((event) => {
            this.openDialog(event);
        }));
    }
    openDialog(event) {
        const reconsentData = {
            user: event.user,
            password: event.password,
            consentIds: event.consentIds,
            errorMessage: event.errorMessage,
            regToken: event.regToken,
            preferences: event.preferences,
        };
        const dialog = this.launchDialogService.openDialog(LAUNCH_CALLER.CDC_RECONSENT, undefined, undefined, reconsentData);
        if (dialog) {
            dialog.pipe(take(1)).subscribe();
        }
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdcReconsentDialogEventListener, deps: [{ token: i1.EventService }, { token: i2.LaunchDialogService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdcReconsentDialogEventListener, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdcReconsentDialogEventListener, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.EventService }, { type: i2.LaunchDialogService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CdcReconsentComponentService {
    constructor(cdcUserConsentService, cdcJsService, globalMessageService, launchDialogService) {
        this.cdcUserConsentService = cdcUserConsentService;
        this.cdcJsService = cdcJsService;
        this.globalMessageService = globalMessageService;
        this.launchDialogService = launchDialogService;
        this.subscription = new Subscription();
    }
    /**
     * saves the preferences given in reconsent pop-up and triggers a re-login
     * @param consents array of consent ID with status
     * @param userParams data from login session
     */
    savePreferencesAndLogin(consents, userParams) {
        this.subscription.add(this.cdcJsService.didLoad().subscribe((cdcLoaded) => {
            if (cdcLoaded) {
                this.cdcUserConsentService
                    .updateCdcUserPreferences(consents, userParams?.user, userParams?.regToken)
                    .subscribe({
                    next: (result) => {
                        if (result?.errorCode === 0) {
                            this.cdcJsService
                                .loginUserWithoutScreenSet(userParams.user, userParams.password)
                                .subscribe(() => {
                                this.launchDialogService.closeDialog('relogin successful');
                            });
                        }
                    },
                    error: (error) => {
                        this.handleReconsentUpdateError('Reconsent Error', error?.message);
                    },
                });
            }
            else {
                // CDC Gigya SDK not loaded, show error to the user
                this.globalMessageService.add({
                    key: 'errorHandlers.scriptFailedToLoad',
                }, GlobalMessageType.MSG_TYPE_ERROR);
            }
        }));
    }
    /**
     * Displays error message after closing reconsent dialog
     */
    handleReconsentUpdateError(reason, errorMessage) {
        this.launchDialogService.closeDialog(reason);
        if (errorMessage) {
            this.globalMessageService.add({
                key: 'httpHandlers.badRequestPleaseLoginAgain',
                params: {
                    errorMessage: errorMessage,
                },
            }, GlobalMessageType.MSG_TYPE_ERROR);
        }
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdcReconsentComponentService, deps: [{ token: i1$1.CdcUserConsentService }, { token: i1$1.CdcJsService }, { token: i1.GlobalMessageService }, { token: i2.LaunchDialogService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdcReconsentComponentService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdcReconsentComponentService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1$1.CdcUserConsentService }, { type: i1$1.CdcJsService }, { type: i1.GlobalMessageService }, { type: i2.LaunchDialogService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CdcReconsentComponent {
    constructor(launchDialogService, anonymousConsentsService, cdcReconsentService) {
        this.launchDialogService = launchDialogService;
        this.anonymousConsentsService = anonymousConsentsService;
        this.cdcReconsentService = cdcReconsentService;
        this.subscription = new Subscription();
        this.cdcConsentManagementComponentService = inject(CdcConsentManagementComponentService);
        this.form = new UntypedFormGroup({});
        this.iconTypes = ICON_TYPE;
        this.loaded$ = of(false);
        this.reconsentEvent = {};
        this.requiredReconsents = [];
        this.selectedConsents = [];
        this.disableSubmitButton = true;
        this.focusConfig = {
            trap: true,
            block: true,
            autofocus: 'button',
            focusOnEscape: true,
        };
    }
    ngOnInit() {
        this.subscription.add(this.launchDialogService.data$.subscribe((data) => {
            this.reconsentEvent = { ...data };
            this.loadConsents(data.consentIds);
        }));
    }
    loadConsents(reconsentIds) {
        this.templateList$ = this.anonymousConsentsService
            .getTemplates(true)
            .pipe(map((templates) => templates.filter((template) => reconsentIds.includes(template.id || ''))));
        this.requiredReconsents = reconsentIds.filter((id) => this.cdcConsentManagementComponentService
            .getCdcConsentIDs(true)
            .includes(id));
        this.disableSubmitButton = this.requiredReconsents.length > 0;
        this.loaded$ = of(true);
    }
    onConsentChange(event) {
        if (!event.template?.id) {
            return;
        }
        const { given, template } = event;
        this.updateSelectedConsents(given, template.id ?? '');
        this.areAllMandatoryConsentsGiven().subscribe((result) => {
            this.disableSubmitButton = !result;
        });
    }
    dismissDialog(reason, message) {
        if (reason === 'Proceed To Login') {
            this.loaded$ = of(false);
            this.templateList$.subscribe((templates) => {
                const consents = this.buildPreferenceList(templates);
                if (consents.length) {
                    this.cdcReconsentService.savePreferencesAndLogin(consents, this.reconsentEvent);
                }
            });
        }
        else {
            this.cdcReconsentService.handleReconsentUpdateError(reason, message);
        }
    }
    buildPreferenceList(templates) {
        const preferences = this.reconsentEvent.preferences || {};
        const consents = Object.entries(preferences).map(([id, value]) => ({
            id,
            isConsentGranted: value?.isConsentGranted || false,
        }));
        templates.forEach((template) => {
            const existingIndex = consents.findIndex((consent) => consent.id === template.id);
            // If id is already present, remove the existing entry
            if (existingIndex !== -1) {
                consents.splice(existingIndex, 1);
            }
            consents.push({
                id: template.id || '',
                isConsentGranted: this.selectedConsents.includes(template.id || ''),
            });
        });
        return consents;
    }
    areAllMandatoryConsentsGiven() {
        return this.templateList$.pipe(map((templates) => templates.every((template) => !this.requiredReconsents.includes(template.id || '') ||
            this.selectedConsents.includes(template.id || ''))));
    }
    updateSelectedConsents(given, templateId) {
        if (given) {
            if (!this.selectedConsents.includes(templateId)) {
                this.selectedConsents.push(templateId);
            }
        }
        else {
            this.selectedConsents = this.selectedConsents.filter((id) => id !== templateId);
        }
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdcReconsentComponent, deps: [{ token: i2.LaunchDialogService }, { token: i1.AnonymousConsentsService }, { token: CdcReconsentComponentService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CdcReconsentComponent, isStandalone: true, selector: "cx-anonymous-consent-dialog", ngImport: i0, template: "<div\n  class=\"modal-dialog modal-dialog-centered modal-lg cx-anonymous-consent-dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"dismissDialog('Escape pressed', reconsentEvent.errorMessage)\"\n>\n  <div class=\"modal-content cx-dialog-content\">\n    <!-- Modal Header -->\n    <ng-container *ngIf=\"loaded$ | async; else loading\">\n      <div class=\"modal-header cx-dialog-header\">\n        <h3>\n          {{ 'reconsent.dialog.title' | cxTranslate }}\n        </h3>\n        <button\n          type=\"button\"\n          class=\"close\"\n          title=\"{{ 'common.close' | cxTranslate }}\"\n          [attr.aria-label]=\"'common.close' | cxTranslate\"\n          (click)=\"dismissDialog('Cross click', reconsentEvent.errorMessage)\"\n        >\n          <span aria-hidden=\"true\">\n            <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n          </span>\n        </button>\n      </div>\n      <div class=\"cx-dialog-description\">\n        {{ 'reconsent.dialog.description' | cxTranslate }}\n        <div\n          class=\"cx-dialog-separator col-sm-12 d-xs-block d-sm-block d-md-none\"\n        ></div>\n      </div>\n      <div class=\"cx-dialog-buttons\"></div>\n      <!-- Modal Body -->\n      <div\n        class=\"modal-body cx-dialog-body\"\n        *ngIf=\"templateList$ | async as templateList\"\n      >\n        <div\n          class=\"cx-dialog-row col-sm-12 col-md-6\"\n          *ngFor=\"let consentTemplate of templateList\"\n        >\n          <cx-consent-management-form\n            [consentTemplate]=\"consentTemplate\"\n            (consentChanged)=\"onConsentChange($event)\"\n            [showMandatory]=\"\n              requiredReconsents.includes(consentTemplate.id ?? '')\n            \"\n          ></cx-consent-management-form>\n        </div>\n      </div>\n      <!-- Actions -->\n      <div class=\"cx-dialog-buttons\">\n        <a\n          [class.disabled]=\"disableSubmitButton\"\n          (click)=\"\n            dismissDialog('Proceed To Login', reconsentEvent.errorMessage)\n          \"\n          class=\"btn btn-primary\"\n          cxBtnLikeLink\n          autofocus\n          >{{ 'common.submit' | cxTranslate }}</a\n        >\n      </div>\n    </ng-container>\n  </div>\n\n  <ng-template #loading>\n    <cx-spinner></cx-spinner>\n  </ng-template>\n</div>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: ConsentManagementFormComponent, selector: "cx-consent-management-form", inputs: ["consentTemplate", "requiredConsents", "consent", "disabled", "showMandatory"], outputs: ["consentChanged"] }, { kind: "directive", type: BtnLikeLinkDirective, selector: "a[cxBtnLikeLink].btn" }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdcReconsentComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-anonymous-consent-dialog', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        FocusDirective,
                        NgIf,
                        IconComponent,
                        NgFor,
                        ConsentManagementFormComponent,
                        BtnLikeLinkDirective,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<div\n  class=\"modal-dialog modal-dialog-centered modal-lg cx-anonymous-consent-dialog\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"dismissDialog('Escape pressed', reconsentEvent.errorMessage)\"\n>\n  <div class=\"modal-content cx-dialog-content\">\n    <!-- Modal Header -->\n    <ng-container *ngIf=\"loaded$ | async; else loading\">\n      <div class=\"modal-header cx-dialog-header\">\n        <h3>\n          {{ 'reconsent.dialog.title' | cxTranslate }}\n        </h3>\n        <button\n          type=\"button\"\n          class=\"close\"\n          title=\"{{ 'common.close' | cxTranslate }}\"\n          [attr.aria-label]=\"'common.close' | cxTranslate\"\n          (click)=\"dismissDialog('Cross click', reconsentEvent.errorMessage)\"\n        >\n          <span aria-hidden=\"true\">\n            <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n          </span>\n        </button>\n      </div>\n      <div class=\"cx-dialog-description\">\n        {{ 'reconsent.dialog.description' | cxTranslate }}\n        <div\n          class=\"cx-dialog-separator col-sm-12 d-xs-block d-sm-block d-md-none\"\n        ></div>\n      </div>\n      <div class=\"cx-dialog-buttons\"></div>\n      <!-- Modal Body -->\n      <div\n        class=\"modal-body cx-dialog-body\"\n        *ngIf=\"templateList$ | async as templateList\"\n      >\n        <div\n          class=\"cx-dialog-row col-sm-12 col-md-6\"\n          *ngFor=\"let consentTemplate of templateList\"\n        >\n          <cx-consent-management-form\n            [consentTemplate]=\"consentTemplate\"\n            (consentChanged)=\"onConsentChange($event)\"\n            [showMandatory]=\"\n              requiredReconsents.includes(consentTemplate.id ?? '')\n            \"\n          ></cx-consent-management-form>\n        </div>\n      </div>\n      <!-- Actions -->\n      <div class=\"cx-dialog-buttons\">\n        <a\n          [class.disabled]=\"disableSubmitButton\"\n          (click)=\"\n            dismissDialog('Proceed To Login', reconsentEvent.errorMessage)\n          \"\n          class=\"btn btn-primary\"\n          cxBtnLikeLink\n          autofocus\n          >{{ 'common.submit' | cxTranslate }}</a\n        >\n      </div>\n    </ng-container>\n  </div>\n\n  <ng-template #loading>\n    <cx-spinner></cx-spinner>\n  </ng-template>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i2.LaunchDialogService }, { type: i1.AnonymousConsentsService }, { type: CdcReconsentComponentService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultCdcReconsentLayoutConfig = {
    launch: {
        CDC_RECONSENT: {
            inlineRoot: true,
            component: CdcReconsentComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CdcReconsentModule {
    constructor(_cdcReconsentDialogEventListener) {
        // Intentional empty constructor
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdcReconsentModule, deps: [{ token: CdcReconsentDialogEventListener }], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CdcReconsentModule, imports: [CommonModule,
            SpinnerModule,
            IconModule,
            I18nModule,
            KeyboardFocusModule,
            ConsentManagementModule,
            BtnLikeLinkModule,
            CdcReconsentComponent], exports: [CdcReconsentComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdcReconsentModule, providers: [provideDefaultConfig(defaultCdcReconsentLayoutConfig)], imports: [CommonModule,
            SpinnerModule,
            IconModule,
            I18nModule,
            KeyboardFocusModule,
            ConsentManagementModule,
            BtnLikeLinkModule,
            CdcReconsentComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdcReconsentModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [provideDefaultConfig(defaultCdcReconsentLayoutConfig)],
                    exports: [CdcReconsentComponent],
                    imports: [
                        CommonModule,
                        SpinnerModule,
                        IconModule,
                        I18nModule,
                        KeyboardFocusModule,
                        ConsentManagementModule,
                        BtnLikeLinkModule,
                        CdcReconsentComponent,
                    ],
                }]
        }], ctorParameters: () => [{ type: CdcReconsentDialogEventListener }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CDCLoginFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CDCLoginFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CDCLoginFormModule, imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            FormErrorsModule,
            SpinnerModule,
            CdcReconsentModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CDCLoginFormModule, providers: [
            provideDefaultConfig({
                authentication: {
                    customLoginPage: undefined,
                },
            }),
            provideDefaultConfig({
                cmsComponents: {
                    ReturningCustomerLoginComponent: {
                        component: LoginFormComponent,
                        guards: [NotAuthGuard],
                        providers: [
                            {
                                provide: LoginFormComponentService,
                                useClass: CdcLoginFormComponentService,
                                deps: [
                                    AuthService,
                                    GlobalMessageService,
                                    WindowRef,
                                    CdcJsService,
                                ],
                            },
                        ],
                    },
                },
            }),
        ], imports: [CommonModule,
            FormsModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            FormErrorsModule,
            SpinnerModule,
            CdcReconsentModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CDCLoginFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        FormErrorsModule,
                        SpinnerModule,
                        CdcReconsentModule,
                    ],
                    providers: [
                        provideDefaultConfig({
                            authentication: {
                                customLoginPage: undefined,
                            },
                        }),
                        provideDefaultConfig({
                            cmsComponents: {
                                ReturningCustomerLoginComponent: {
                                    component: LoginFormComponent,
                                    guards: [NotAuthGuard],
                                    providers: [
                                        {
                                            provide: LoginFormComponentService,
                                            useClass: CdcLoginFormComponentService,
                                            deps: [
                                                AuthService,
                                                GlobalMessageService,
                                                WindowRef,
                                                CdcJsService,
                                            ],
                                        },
                                    ],
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CDCUserAccountModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CDCUserAccountModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CDCUserAccountModule, imports: [CDCLoginFormModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CDCUserAccountModule, imports: [CDCLoginFormModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CDCUserAccountModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CDCLoginFormModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CDCLoginFormModule, CDCUserAccountModule, CdcLoginFormComponentService, CdcReconsentComponent, CdcReconsentComponentService, CdcReconsentDialogEventListener, CdcReconsentModule, defaultCdcReconsentLayoutConfig };
//# sourceMappingURL=spartacus-cdc-user-account.mjs.map
