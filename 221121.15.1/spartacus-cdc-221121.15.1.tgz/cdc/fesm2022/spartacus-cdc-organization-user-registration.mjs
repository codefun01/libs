import * as i0 from '@angular/core';
import { Injectable, NgModule } from '@angular/core';
import * as i5 from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import * as i2 from '@spartacus/cdc/root';
import { CdcLoadUserTokenFailEvent } from '@spartacus/cdc/root';
import * as i1 from '@spartacus/core';
import { GlobalMessageType, UrlModule, I18nModule } from '@spartacus/core';
import { UserRegistrationFormService } from '@spartacus/organization/user-registration/components';
import * as i4 from '@spartacus/organization/user-registration/root';
import * as i3 from '@spartacus/user/profile/root';
import { throwError } from 'rxjs';
import { map, tap, switchMap } from 'rxjs/operators';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgSelectModule } from '@ng-select/ng-select';
import { SpinnerModule, FormErrorsModule, NgSelectA11yModule } from '@spartacus/storefront';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CDCB2BRegisterComponentService extends UserRegistrationFormService {
    constructor(command, cdcJSService, authService, eventService, userRegisterFacade, userAddressService, organizationUserRegistrationFacade, translationService, globalMessageService, authConfigService, routingService, formBuilder) {
        super(userRegisterFacade, userAddressService, organizationUserRegistrationFacade, translationService, globalMessageService, authConfigService, routingService, formBuilder);
        this.command = command;
        this.cdcJSService = cdcJSService;
        this.authService = authService;
        this.eventService = eventService;
        this.userRegisterFacade = userRegisterFacade;
        this.userAddressService = userAddressService;
        this.organizationUserRegistrationFacade = organizationUserRegistrationFacade;
        this.translationService = translationService;
        this.globalMessageService = globalMessageService;
        this.authConfigService = authConfigService;
        this.routingService = routingService;
        this.formBuilder = formBuilder;
        this.registerCommand = this.command.create(({ orgInfo }) => 
        // Registering user through CDC Gigya SDK
        this.cdcJSService.registerOrganisationWithoutScreenSet(orgInfo));
        this.loadUserTokenFailed$ = this.eventService
            .get(CdcLoadUserTokenFailEvent)
            .pipe(map((event) => !!event), tap((failed) => {
            if (failed) {
                throw new Error(`User token failed to load.`);
            }
        }));
    }
    /**
     * Register a new user using CDC SDK.
     *
     * @param form as FormGroup
     */
    registerUser(form) {
        if (!form.get('firstName')?.value ||
            !form.get('lastName')?.value ||
            !form.get('email')?.value ||
            !form.get('companyName')?.value) {
            return throwError(`The provided user is not valid: ${form.value}`);
        }
        const orgInfo = {
            firstName: form.get('firstName')?.value,
            lastName: form.get('lastName')?.value,
            email: form.get('email')?.value,
            companyName: form.get('companyName')?.value,
            addressLine1: form.get('line1')?.value,
            addressLine2: form.get('line2')?.value,
            postalCode: form.get('postalCode')?.value,
            town: form.get('town')?.value,
            region: form.get('region')?.get('isocode')?.value,
            country: form.get('country')?.get('isocode')?.value,
            phoneNumber: form.get('phoneNumber')?.value,
            message: form.get('message')?.value,
        };
        return this.cdcJSService.didLoad().pipe(tap((cdcLoaded) => {
            if (!cdcLoaded) {
                this.globalMessageService.add({
                    key: 'errorHandlers.scriptFailedToLoad',
                }, GlobalMessageType.MSG_TYPE_ERROR);
                throw new Error(`CDC script didn't load.`);
            }
        }), switchMap(() => 
        // Logging in using CDC Gigya SDK, update the registerCommand
        this.registerCommand.execute({ orgInfo })), tap(() => {
            this.displayGlobalMessage();
            this.redirectToLogin();
            form.reset();
        }));
    }
    // @override
    postRegisterMessage() {
        // don't show the message
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CDCB2BRegisterComponentService, deps: [{ token: i1.CommandService }, { token: i2.CdcJsService }, { token: i1.AuthService }, { token: i1.EventService }, { token: i3.UserRegisterFacade }, { token: i1.UserAddressService }, { token: i4.UserRegistrationFacade }, { token: i1.TranslationService }, { token: i1.GlobalMessageService }, { token: i1.AuthConfigService }, { token: i1.RoutingService }, { token: i5.FormBuilder }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CDCB2BRegisterComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CDCB2BRegisterComponentService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.CommandService }, { type: i2.CdcJsService }, { type: i1.AuthService }, { type: i1.EventService }, { type: i3.UserRegisterFacade }, { type: i1.UserAddressService }, { type: i4.UserRegistrationFacade }, { type: i1.TranslationService }, { type: i1.GlobalMessageService }, { type: i1.AuthConfigService }, { type: i1.RoutingService }, { type: i5.FormBuilder }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CDCB2BRegisterModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CDCB2BRegisterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CDCB2BRegisterModule, imports: [CommonModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            SpinnerModule,
            FormErrorsModule,
            NgSelectModule,
            NgSelectA11yModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CDCB2BRegisterModule, providers: [
            {
                provide: UserRegistrationFormService,
                useClass: CDCB2BRegisterComponentService,
            },
        ], imports: [CommonModule,
            ReactiveFormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            SpinnerModule,
            FormErrorsModule,
            NgSelectModule,
            NgSelectA11yModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CDCB2BRegisterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        SpinnerModule,
                        FormErrorsModule,
                        NgSelectModule,
                        NgSelectA11yModule,
                    ],
                    providers: [
                        {
                            provide: UserRegistrationFormService,
                            useClass: CDCB2BRegisterComponentService,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CDCB2BRegisterComponentService, CDCB2BRegisterModule };
//# sourceMappingURL=spartacus-cdc-organization-user-registration.mjs.map
