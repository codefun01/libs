import { NgIf, AsyncPipe, CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { ChangeDetectionStrategy, ViewEncapsulation, Component, inject, Injectable, NgModule } from '@angular/core';
import * as i2 from '@spartacus/core';
import { TranslatePipe, RoutingService, CmsService, AuthGuard, NotAuthGuard, isNotUndefined, I18nModule, ConfigModule } from '@spartacus/core';
import * as i3 from '@spartacus/cdc/root';
import * as i1 from '@spartacus/storefront';
import { distinctUntilChanged, tap, take } from 'rxjs/operators';
import { switchMap, of, combineLatest, map, catchError, filter, take as take$1 } from 'rxjs';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class GigyaRaasComponent {
    constructor(component, baseSiteService, languageService, cdcConfig, winRef, cdcJSService, zone) {
        this.component = component;
        this.baseSiteService = baseSiteService;
        this.languageService = languageService;
        this.cdcConfig = cdcConfig;
        this.winRef = winRef;
        this.cdcJSService = cdcJSService;
        this.zone = zone;
        this.renderScreenSet = true;
        this.isPasswordReset = false;
    }
    ngOnInit() {
        this.jsLoaded$ = this.cdcJSService.didLoad();
        this.jsError$ = this.cdcJSService.didScriptFailToLoad();
        this.language$ = this.languageService.getActive().pipe(distinctUntilChanged(), 
        // On language change we want to rerender CDC screen with proper translations
        tap(() => (this.renderScreenSet = true)));
    }
    /**
     * Display screen set in embed mode
     *
     * @param data - GigyaRaasComponentData
     * @param lang - language
     */
    displayScreenSet(data, lang) {
        if (this.renderScreenSet) {
            this.showScreenSet(data, lang);
        }
        this.renderScreenSet = false;
    }
    /**
     * Show screen set
     *
     * @param data - GigyaRaasComponentData
     * @param lang - language
     */
    showScreenSet(data, lang) {
        this.winRef.nativeWindow?.['gigya']?.accounts?.showScreenSet({
            screenSet: data.screenSet,
            startScreen: data.startScreen,
            lang,
            ...(this.displayInEmbedMode(data)
                ? { containerID: data.containerID }
                : {}),
            ...(this.isLoginScreenSet(data)
                ? { sessionExpiration: this.getSessionExpirationValue() }
                : {
                    onSubmit: (event) => {
                        const formData = event.formModel;
                        this.isPasswordReset = !!formData?.newPassword;
                    },
                    onAfterSubmit: (...params) => {
                        this.zone.run(() => {
                            params.push({ passwordReset: this.isPasswordReset });
                            this.cdcJSService.onProfileUpdateEventHandler(...params);
                        });
                    },
                }),
        });
    }
    isLoginScreenSet(data) {
        const profileEditScreen = data.profileEdit === 'true' ? true : false;
        return !profileEditScreen;
    }
    getSessionExpirationValue() {
        if (this.cdcConfig?.cdc !== undefined) {
            const filteredConfigs = this.cdcConfig.cdc.filter((conf) => conf.baseSite === this.getCurrentBaseSite());
            if (filteredConfigs && filteredConfigs.length > 0) {
                return filteredConfigs[0].sessionExpiration;
            }
        }
        // Return a default value
        return 3600;
    }
    getCurrentBaseSite() {
        let baseSite = '';
        this.baseSiteService
            .getActive()
            .pipe(take(1))
            .subscribe((data) => (baseSite = data));
        return baseSite;
    }
    /**
     * Check if the component should be displayed in embed mode
     *
     * @param data - GigyaRaasComponentData
     */
    displayInEmbedMode(data) {
        const embedValue = data.embed === 'true' ? true : false;
        if (embedValue && data.containerID && data.containerID.length > 0) {
            return true;
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: GigyaRaasComponent, deps: [{ token: i1.CmsComponentData }, { token: i2.BaseSiteService }, { token: i2.LanguageService }, { token: i3.CdcConfig }, { token: i2.WindowRef }, { token: i3.CdcJsService }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: GigyaRaasComponent, isStandalone: true, selector: "cx-gigya-raas", ngImport: i0, template: "<div *ngIf=\"component.data$ | async as data\">\n  <div *ngIf=\"jsLoaded$ | async\">\n    <div *ngIf=\"language$ | async as lang\">\n      <div\n        *ngIf=\"displayInEmbedMode(data); else popupLink\"\n        [attr.id]=\"data.containerID\"\n      >\n        {{ displayScreenSet(data, lang) }}\n      </div>\n      <ng-template #popupLink>\n        <a\n          class=\"popup-link\"\n          [attr.data-cdc-id]=\"data.uid\"\n          [attr.data-profile-edit]=\"data.profileEdit\"\n          (click)=\"showScreenSet(data, lang)\"\n          >{{ data.linkText }}</a\n        >\n      </ng-template>\n    </div>\n  </div>\n  <div *ngIf=\"jsError$ | async\" class=\"js-error\">\n    {{ 'errorHandlers.scriptFailedToLoad' | cxTranslate }}\n    {{ 'errorHandlers.refreshThePage' | cxTranslate }}\n  </div>\n</div>\n", styles: ["cx-gigya-raas .popup-link{cursor:pointer;color:var(--cx-color-primary)}cx-gigya-raas .js-error{text-align:center;padding:4rem}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: GigyaRaasComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-gigya-raas', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, AsyncPipe, TranslatePipe], template: "<div *ngIf=\"component.data$ | async as data\">\n  <div *ngIf=\"jsLoaded$ | async\">\n    <div *ngIf=\"language$ | async as lang\">\n      <div\n        *ngIf=\"displayInEmbedMode(data); else popupLink\"\n        [attr.id]=\"data.containerID\"\n      >\n        {{ displayScreenSet(data, lang) }}\n      </div>\n      <ng-template #popupLink>\n        <a\n          class=\"popup-link\"\n          [attr.data-cdc-id]=\"data.uid\"\n          [attr.data-profile-edit]=\"data.profileEdit\"\n          (click)=\"showScreenSet(data, lang)\"\n          >{{ data.linkText }}</a\n        >\n      </ng-template>\n    </div>\n  </div>\n  <div *ngIf=\"jsError$ | async\" class=\"js-error\">\n    {{ 'errorHandlers.scriptFailedToLoad' | cxTranslate }}\n    {{ 'errorHandlers.refreshThePage' | cxTranslate }}\n  </div>\n</div>\n", styles: ["cx-gigya-raas .popup-link{cursor:pointer;color:var(--cx-color-primary)}cx-gigya-raas .js-error{text-align:center;padding:4rem}\n"] }]
        }], ctorParameters: () => [{ type: i1.CmsComponentData }, { type: i2.BaseSiteService }, { type: i2.LanguageService }, { type: i3.CdcConfig }, { type: i2.WindowRef }, { type: i3.CdcJsService }, { type: i0.NgZone }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class GigyaRaasGuard {
    constructor() {
        this.routingService = inject(RoutingService);
        this.cmsService = inject(CmsService);
        this.authGuard = inject(AuthGuard);
        this.notAuthGuard = inject(NotAuthGuard);
    }
    canActivate() {
        return this.getComponentData().pipe(switchMap((componentData) => {
            if (!componentData.length) {
                return of(false);
            }
            // Run guard checks for each component
            const guardResults$ = componentData.map((data) => this.checksToProcess(data));
            // Allow activation only if all checks pass, else return first non-true value
            return combineLatest(guardResults$).pipe(map((results) => {
                const firstNonTrue = results.find((result) => result !== true);
                return firstNonTrue ?? true;
            }));
        }), catchError(() => of(false)));
    }
    checksToProcess(componentData) {
        if (Object.keys(componentData).length === 0) {
            return of(false);
        }
        if (componentData.showAnonymous === 'false') {
            return this.authGuard.canActivate();
        }
        if (componentData.showLoggedIn === 'false') {
            return this.notAuthGuard.canActivate();
        }
        return of(true);
    }
    getComponentsByType(pageContext, componentType) {
        return this.cmsService.getPage(pageContext).pipe(switchMap((page) => {
            if (!page) {
                return of([]);
            }
            const componentUids = Object.values(page.slots || {})
                .flatMap((slot) => slot.components)
                .filter((component) => component?.typeCode === componentType)
                .map((component) => component?.uid);
            return of(componentUids);
        }), catchError(() => of([])));
    }
    getComponentData() {
        return this.routingService.getNextPageContext().pipe(filter(isNotUndefined), take$1(1), switchMap((pageContext) => this.getComponentsByType(pageContext, 'GigyaRaasComponent')), switchMap((componentUids) => {
            if (!componentUids.length) {
                return of([]);
            }
            const componentData$ = componentUids
                .filter((uid) => Boolean(uid))
                .map((uid) => this.cmsService
                .getComponentData(uid)
                .pipe(catchError(() => of({}))));
            return combineLatest(componentData$);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: GigyaRaasGuard, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: GigyaRaasGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: GigyaRaasGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class GigyaRaasModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: GigyaRaasModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: GigyaRaasModule, imports: [CommonModule,
            I18nModule, i2.ConfigModule, GigyaRaasComponent], exports: [GigyaRaasComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: GigyaRaasModule, imports: [CommonModule,
            I18nModule,
            ConfigModule.withConfig({
                cmsComponents: {
                    GigyaRaasComponent: {
                        component: GigyaRaasComponent,
                        guards: [GigyaRaasGuard],
                    },
                },
                layoutSlots: {
                    GigyaLoginPageTemplate: {
                        slots: ['BodyContent', 'BottomContent'],
                    },
                },
            })] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: GigyaRaasModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        ConfigModule.withConfig({
                            cmsComponents: {
                                GigyaRaasComponent: {
                                    component: GigyaRaasComponent,
                                    guards: [GigyaRaasGuard],
                                },
                            },
                            layoutSlots: {
                                GigyaLoginPageTemplate: {
                                    slots: ['BodyContent', 'BottomContent'],
                                },
                            },
                        }),
                        GigyaRaasComponent,
                    ],
                    exports: [GigyaRaasComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CdcComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdcComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CdcComponentsModule, imports: [CommonModule, GigyaRaasModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdcComponentsModule, imports: [CommonModule, GigyaRaasModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdcComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [],
                    imports: [CommonModule, GigyaRaasModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CdcComponentsModule, GigyaRaasComponent, GigyaRaasGuard, GigyaRaasModule };
//# sourceMappingURL=spartacus-cdc-components.mjs.map
