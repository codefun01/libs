import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { PersonalizationCoreModule } from '@spartacus/tracking/personalization/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PersonalizationModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PersonalizationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: PersonalizationModule, imports: [PersonalizationCoreModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PersonalizationModule, imports: [PersonalizationCoreModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PersonalizationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [PersonalizationCoreModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/*
 * Public API Surface of personalizatiion
 */

/**
 * Generated bundle index. Do not edit.
 */

export { PersonalizationModule };
//# sourceMappingURL=spartacus-tracking-personalization.mjs.map
