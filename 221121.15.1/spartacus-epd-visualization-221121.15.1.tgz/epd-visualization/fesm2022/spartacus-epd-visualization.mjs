import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { EpdVisualizationComponentsModule } from '@spartacus/epd-visualization/components';
import { EpdVisualizationCoreModule } from '@spartacus/epd-visualization/core';
import { EpdVisualizationApiModule } from '@spartacus/epd-visualization/epd-visualization-api';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * @deprecated since v221121.5.0 - The epd-visualization integration library will be removed in the future.
 */
class EpdVisualizationModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: EpdVisualizationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: EpdVisualizationModule, imports: [EpdVisualizationComponentsModule,
            EpdVisualizationCoreModule,
            EpdVisualizationApiModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: EpdVisualizationModule, imports: [EpdVisualizationComponentsModule,
            EpdVisualizationCoreModule,
            EpdVisualizationApiModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: EpdVisualizationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        EpdVisualizationComponentsModule,
                        EpdVisualizationCoreModule,
                        EpdVisualizationApiModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { EpdVisualizationModule };
//# sourceMappingURL=spartacus-epd-visualization.mjs.map
