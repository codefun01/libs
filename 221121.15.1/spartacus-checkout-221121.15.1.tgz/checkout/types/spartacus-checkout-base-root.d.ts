import { QueryState, Address, EventService, GlobalMessageService, CmsConfig, CxEvent, PaymentDetails, CardType } from '@spartacus/core';
import * as i0 from '@angular/core';
import { OnDestroy } from '@angular/core';
import { ActiveCartFacade, DeliveryMode } from '@spartacus/cart/base/root';
import { Observable, Subscription } from 'rxjs';
import { Store } from '@ngrx/store';

declare abstract class CheckoutDeliveryAddressFacade {
    /**
     * Returns the delivery address state
     */
    abstract getDeliveryAddressState(): Observable<QueryState<Address | undefined>>;
    /**
     * Creates and sets the delivery address using the provided address
     */
    abstract createAndSetAddress(address: Address): Observable<unknown>;
    /**
     * Sets the delivery address to the cart
     */
    abstract setDeliveryAddress(address: Address): Observable<unknown>;
    /**
     * Clears the delivery address set in the cart
     */
    abstract clearCheckoutDeliveryAddress(): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutDeliveryAddressFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutDeliveryAddressFacade>;
}

/**
 * Checkout delivery address event listener.
 */
declare class CheckoutDeliveryAddressEventListener implements OnDestroy {
    protected checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade;
    protected eventService: EventService;
    protected globalMessageService: GlobalMessageService;
    protected activeCartFacade: ActiveCartFacade;
    protected subscriptions: Subscription;
    constructor(checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade, eventService: EventService, globalMessageService: GlobalMessageService, activeCartFacade: ActiveCartFacade);
    /**
     * Registers listeners for the User address events.
     */
    protected onUserAddressChange(): void;
    protected onDeliveryAddressCreated(): void;
    protected onDeliveryAddressSet(): void;
    protected onDeliveryAddressCleared(): void;
    protected onCartDeleted(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutDeliveryAddressEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutDeliveryAddressEventListener>;
}

/**
 * Checkout delivery mode event listener.
 */
declare class CheckoutDeliveryModeEventListener implements OnDestroy {
    protected eventService: EventService;
    protected subscriptions: Subscription;
    constructor(eventService: EventService);
    protected onDeliveryModeSet(): void;
    protected onDeliveryModeCleared(): void;
    protected onDeliveryModeClearedError(): void;
    /**
     * Registers listeners for the delivery mode clear event.
     * This is needed for when `CheckoutSupportedDeliveryModesQueryResetEvent` is dispatched
     * as we need to update the user's cart when the delivery mode is cleared from the backend checkout details.
     */
    protected onDeliveryModeReset(): void;
    protected onGetSupportedDeliveryModesQueryReload(): void;
    protected onGetSupportedDeliveryModesQueryReset(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutDeliveryModeEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutDeliveryModeEventListener>;
}

/**
 * The event listener which dispatches legacy store actions.
 * It will be removed as soon as the legacy store is removed.
 */
declare class CheckoutLegacyStoreEventListener implements OnDestroy {
    protected eventService: EventService;
    protected store: Store<unknown>;
    protected subscriptions: Subscription;
    constructor(eventService: EventService, store: Store<unknown>);
    /**
     * Registers events for the user address actions.
     */
    protected onUserAddressAction(): void;
    /**
     * Registers events for the user payment actions.
     */
    protected onUserPaymentAction(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutLegacyStoreEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutLegacyStoreEventListener>;
}

/**
 * Checkout payment event listener.
 */
declare class CheckoutPaymentEventListener implements OnDestroy {
    protected eventService: EventService;
    protected globalMessageService: GlobalMessageService;
    protected subscriptions: Subscription;
    constructor(eventService: EventService, globalMessageService: GlobalMessageService);
    protected onPaymentCreated(): void;
    protected onPaymentSet(): void;
    protected onGetCardTypesQueryReload(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPaymentEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutPaymentEventListener>;
}

declare class CheckoutPlaceOrderEventListener implements OnDestroy {
    protected eventService: EventService;
    protected subscriptions: Subscription;
    constructor(eventService: EventService);
    protected onOrderPlaced(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPlaceOrderEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutPlaceOrderEventListener>;
}

declare class CheckoutQueryEventListener implements OnDestroy {
    protected eventService: EventService;
    protected subscriptions: Subscription;
    constructor(eventService: EventService);
    protected onCheckoutQueryReload(): void;
    protected onCheckoutQueryReset(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutQueryEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutQueryEventListener>;
}

declare class CheckoutEventModule {
    constructor(_checkoutQueryEventListener: CheckoutQueryEventListener, _checkoutDeliveryAddressEventListener: CheckoutDeliveryAddressEventListener, _checkoutDeliveryModeEventListener: CheckoutDeliveryModeEventListener, _checkoutPaymentEventListener: CheckoutPaymentEventListener, _checkoutPlaceOrderEventListener: CheckoutPlaceOrderEventListener, _checkoutLegacyStoreEventListener: CheckoutLegacyStoreEventListener);
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutEventModule>;
}

declare const CHECKOUT_BASE_CMS_COMPONENTS: string[];
declare function defaultCheckoutComponentsConfig(): CmsConfig;
declare class CheckoutRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutRootModule, never, [typeof CheckoutEventModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutRootModule>;
}

declare enum CheckoutStepType {
    DELIVERY_ADDRESS = "deliveryAddress",
    DELIVERY_MODE = "deliveryMode",
    PAYMENT_DETAILS = "paymentDetails",
    REVIEW_ORDER = "reviewOrder"
}
declare enum CheckoutStepState {
    COMPLETED = "completed",
    SELECTED = "selected",
    DISABLED = "disabled"
}
interface CheckoutStep {
    id: string;
    name: string;
    routeName: string;
    type: Array<CheckoutStepType>;
    disabled?: boolean;
    nameMultiLine?: boolean;
}

interface CheckoutFlow {
    /**
     * Set checkout steps as ordered array of pages.
     */
    steps?: Array<CheckoutStep>;
    /**
     * Allow for express checkout when default shipping method and payment method are available.
     */
    express?: boolean;
    /**
     * Default delivery mode for i.a. express checkout. Set preferences in order with general preferences (eg. DeliveryModePreferences.LEAST_EXPENSIVE) or specific delivery codes.
     */
    defaultDeliveryMode?: Array<DeliveryModePreferences | string>;
    /**
     * Allow for guest checkout.
     */
    guest?: boolean;
    /**
     * Use delivery address saved in cart for pre-filling delivery address form.
     */
    guestUseSavedAddress?: boolean;
}

declare enum DeliveryModePreferences {
    FREE = "FREE",
    LEAST_EXPENSIVE = "LEAST_EXPENSIVE",// but not free
    MOST_EXPENSIVE = "MOST_EXPENSIVE"
}
declare abstract class CheckoutConfig {
    checkout?: {
        /**
         * Set checkout steps as ordered array of pages.
         */
        steps?: Array<CheckoutStep>;
        /**
         * Allow for express checkout when default shipping method and payment method are available.
         */
        express?: boolean;
        /**
         * Default delivery mode for i.a. express checkout. Set preferences in order with general preferences (eg. DeliveryModePreferences.LEAST_EXPENSIVE) or specific delivery codes.
         */
        defaultDeliveryMode?: Array<DeliveryModePreferences | string>;
        /**
         * Allow for guest checkout.
         */
        guest?: boolean;
        /**
         * Use delivery address saved in cart for pre-filling delivery address form.
         */
        guestUseSavedAddress?: boolean;
        /**
         * Determine multiple flows that can be used during the checkout process.
         */
        flows?: {
            [key: string]: CheckoutFlow;
        };
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutConfig>;
}
declare module '@spartacus/core' {
    interface Config extends CheckoutConfig {
    }
}

/**
 * Emit this event to force checkout details reload
 */
declare class CheckoutQueryReloadEvent extends CxEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutQueryReloadEvent";
}
/**
 * Emit this event to force checkout details reset
 */
declare class CheckoutQueryResetEvent extends CxEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutQueryResetEvent";
}
/**
 * An abstract event for all the checkout events.
 */
declare abstract class CheckoutEvent extends CxEvent {
    userId?: string;
    /**
     * Usually set via `getCartIdByUserId()` util method,
     * It is an abstraction over the different properties
     * used for anonymous and logged-in users' carts:
     * - `code` for logged-in users
     * - `guid` for anonymous users
     */
    cartId?: string;
    /**
     * All carts have the `code` property assigned to them,
     * regardless of whether they are anonymous or logged-in.
     * In case of logged-in users, the `cartCode` and `cartId` are the same.
     */
    cartCode?: string;
}
/**
 * An abstract event for all the delivery address related events.
 */
declare abstract class CheckoutDeliveryAddressEvent extends CheckoutEvent {
}
/**
 * Fired when the delivery address is create cleared.
 */
declare class CheckoutDeliveryAddressCreatedEvent extends CheckoutDeliveryAddressEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutDeliveryAddressCreatedEvent";
    /**
     * The address.
     */
    address: Address;
}
/**
 * Fired when the user sets a delivery address during checkout.
 */
declare class CheckoutDeliveryAddressSetEvent extends CheckoutDeliveryAddressEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutDeliveryAddressSetEvent";
    /**
     * The address.
     */
    address: Address;
}
/**
 * Fired when the delivery address has to be cleared.
 */
declare class CheckoutDeliveryAddressClearedEvent extends CheckoutDeliveryAddressEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutDeliveryAddressClearedEvent";
}
/**
 * An abstract event for all the delivery mode related events.
 */
declare abstract class CheckoutDeliveryModeEvent extends CheckoutEvent {
}
/**
 * Fired when the delivery mode was set.
 */
declare class CheckoutDeliveryModeSetEvent extends CheckoutDeliveryModeEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutDeliveryModeSetEvent";
    /**
     * Delivery mode code.
     */
    deliveryModeCode: string;
}
/**
 * Fired when the delivery mode has been cleared.
 */
declare class CheckoutDeliveryModeClearedEvent extends CheckoutDeliveryModeEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutDeliveryModeClearedEvent";
}
/**
 * Fired when the delivery mode has an error when trying to be cleared.
 */
declare class CheckoutDeliveryModeClearedErrorEvent extends CheckoutDeliveryModeEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutDeliveryModeClearedErrorEvent";
}
/**
 * Emit this event to force delivery modes reload
 */
declare class CheckoutSupportedDeliveryModesQueryReloadEvent extends CheckoutDeliveryModeEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutSupportedDeliveryModesQueryReloadEvent";
}
/**
 * Emit this event to force delivery modes reset
 */
declare class CheckoutSupportedDeliveryModesQueryResetEvent extends CheckoutDeliveryModeEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutSupportedDeliveryModesQueryResetEvent";
}
/**
 * An abstract event for all the payment details related events.
 */
declare abstract class CheckoutPaymentDetailsEvent extends CheckoutEvent {
}
/**
 * Fired when the payment details have been created.
 */
declare class CheckoutPaymentDetailsCreatedEvent extends CheckoutPaymentDetailsEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutPaymentDetailsCreatedEvent";
    /**
     * Payment details
     */
    paymentDetails: PaymentDetails;
}
/**
 * Fired when the payment details have been set.
 */
declare class CheckoutPaymentDetailsSetEvent extends CheckoutPaymentDetailsEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutPaymentDetailsSetEvent";
    /**
     * Payment details id
     */
    paymentDetailsId: string;
}
/**
 * Emit this event to force payment card types reload
 */
declare class CheckoutPaymentCardTypesQueryReloadEvent extends CheckoutPaymentDetailsEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutPaymentCardTypesQueryReloadEvent";
}
/**
 * Emit this event to force payment card types reset
 */
declare class CheckoutPaymentCardTypesQueryResetEvent extends CheckoutPaymentDetailsEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutPaymentCardTypesQueryResetEvent";
}

declare abstract class CheckoutBillingAddressFacade {
    /**
     * Sets the billing address to the cart
     */
    abstract setBillingAddress(address: Address): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutBillingAddressFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutBillingAddressFacade>;
}

declare abstract class CheckoutDeliveryModesFacade {
    /**
     * Returns the supported delivery modes state.
     */
    abstract getSupportedDeliveryModesState(): Observable<QueryState<DeliveryMode[]>>;
    /**
     * Returns the supported delivery modes, or an empty array if the data is undefined.
     */
    abstract getSupportedDeliveryModes(): Observable<DeliveryMode[]>;
    /**
     * Returns the selected delivery mode
     */
    abstract getSelectedDeliveryModeState(): Observable<QueryState<DeliveryMode | undefined>>;
    /**
     * Sets the provided delivery mode to the current cart
     */
    abstract setDeliveryMode(mode: string): Observable<unknown>;
    /**
     * Clears the selected delivery mode from the current cart
     */
    abstract clearCheckoutDeliveryMode(): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutDeliveryModesFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutDeliveryModesFacade>;
}

declare abstract class CheckoutPaymentFacade {
    /**
     * Returns the card types state
     */
    abstract getPaymentCardTypesState(): Observable<QueryState<CardType[] | undefined>>;
    /**
     * Returns the card types, or an empty array if the data is undefined.
     */
    abstract getPaymentCardTypes(): Observable<CardType[]>;
    /**
     * Returns the payment details state
     */
    abstract getPaymentDetailsState(): Observable<QueryState<PaymentDetails | undefined>>;
    /**
     * Creates the payment details using the provided paymentDetails
     */
    abstract createPaymentDetails(paymentDetails: PaymentDetails): Observable<unknown>;
    /**
     * Sets the payment details to the current cart
     */
    abstract setPaymentDetails(paymentDetails: PaymentDetails): Observable<unknown>;
    /**
     * Deletes the payment details from the current cart
     */
    abstract deletePaymentDetails(): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPaymentFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutPaymentFacade>;
}

interface CheckoutState {
    deliveryAddress?: Address;
    deliveryMode?: DeliveryMode;
    paymentInfo?: PaymentDetails;
}

declare abstract class CheckoutQueryFacade {
    /**
     * Returns the checkout details state.
     */
    abstract getCheckoutDetailsState(): Observable<QueryState<CheckoutState | undefined>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutQueryFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutQueryFacade>;
}

declare const CHECKOUT_FEATURE = "checkout";
declare const CHECKOUT_CORE_FEATURE = "checkoutCore";

export { CHECKOUT_BASE_CMS_COMPONENTS, CHECKOUT_CORE_FEATURE, CHECKOUT_FEATURE, CheckoutBillingAddressFacade, CheckoutConfig, CheckoutDeliveryAddressClearedEvent, CheckoutDeliveryAddressCreatedEvent, CheckoutDeliveryAddressEvent, CheckoutDeliveryAddressEventListener, CheckoutDeliveryAddressFacade, CheckoutDeliveryAddressSetEvent, CheckoutDeliveryModeClearedErrorEvent, CheckoutDeliveryModeClearedEvent, CheckoutDeliveryModeEvent, CheckoutDeliveryModeEventListener, CheckoutDeliveryModeSetEvent, CheckoutDeliveryModesFacade, CheckoutEvent, CheckoutEventModule, CheckoutPaymentCardTypesQueryReloadEvent, CheckoutPaymentCardTypesQueryResetEvent, CheckoutPaymentDetailsCreatedEvent, CheckoutPaymentDetailsEvent, CheckoutPaymentDetailsSetEvent, CheckoutPaymentEventListener, CheckoutPaymentFacade, CheckoutQueryFacade, CheckoutQueryReloadEvent, CheckoutQueryResetEvent, CheckoutRootModule, CheckoutStepState, CheckoutStepType, CheckoutSupportedDeliveryModesQueryReloadEvent, CheckoutSupportedDeliveryModesQueryResetEvent, DeliveryModePreferences, defaultCheckoutComponentsConfig };
export type { CheckoutFlow, CheckoutState, CheckoutStep };
