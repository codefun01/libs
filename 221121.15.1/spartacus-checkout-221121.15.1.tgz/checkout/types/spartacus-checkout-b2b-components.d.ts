import * as i0 from '@angular/core';
import { OnInit, OnDestroy } from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/core';
import { UserCostCenterService, CostCenter, GlobalMessageService, UserAddressService, TranslationService, Address, AuthService, AuthRedirectService, SemanticPathService, RoutingConfigService, LoggerService } from '@spartacus/core';
import { CheckoutCostCenterFacade, CheckoutPaymentTypeFacade } from '@spartacus/checkout/b2b/root';
import { Subscription, Observable, BehaviorSubject } from 'rxjs';
import * as i2$1 from '@spartacus/storefront';
import { Card } from '@spartacus/storefront';
import * as i2$2 from '@angular/router';
import { ActivatedRoute, Router, GuardResult, UrlTree, ActivatedRouteSnapshot } from '@angular/router';
import { PaymentType, ActiveCartFacade } from '@spartacus/cart/base/root';
import { CheckoutStepService, CheckoutDeliveryAddressComponent, CheckoutReviewSubmitComponent, CheckoutAuthGuard, CheckoutConfigService, CheckoutStepsSetGuard } from '@spartacus/checkout/base/components';
import * as i3 from '@spartacus/user/profile/components';
import { CheckoutDeliveryAddressFacade, CheckoutDeliveryModesFacade, CheckoutPaymentFacade, CheckoutStepType, CheckoutStep } from '@spartacus/checkout/base/root';
import { UserAccountFacade, User } from '@spartacus/user/account/root';

declare class CheckoutCostCenterComponent implements OnInit, OnDestroy {
    protected userCostCenterService: UserCostCenterService;
    protected checkoutCostCenterFacade: CheckoutCostCenterFacade;
    protected checkoutPaymentTypeFacade: CheckoutPaymentTypeFacade;
    protected subscription: Subscription;
    protected userCostCenters$: Observable<CostCenter[]>;
    costCenterId: string | undefined;
    costCenters$: Observable<CostCenter[]>;
    isAccountPayment: boolean;
    get disabled(): boolean;
    constructor(userCostCenterService: UserCostCenterService, checkoutCostCenterFacade: CheckoutCostCenterFacade, checkoutPaymentTypeFacade: CheckoutPaymentTypeFacade);
    ngOnInit(): void;
    setCostCenter(selectCostCenter: string): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutCostCenterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutCostCenterComponent, "cx-cost-center", never, {}, {}, never, never, true, never>;
}

declare class CheckoutCostCenterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutCostCenterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutCostCenterModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i2.ConfigModule, typeof CheckoutCostCenterComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutCostCenterModule>;
}

declare class CheckoutPaymentTypeComponent {
    protected checkoutPaymentTypeFacade: CheckoutPaymentTypeFacade;
    protected checkoutStepService: CheckoutStepService;
    protected activatedRoute: ActivatedRoute;
    protected globalMessageService: GlobalMessageService;
    private poNumberInputElement;
    protected busy$: BehaviorSubject<boolean>;
    typeSelected?: string;
    paymentTypesError: boolean;
    isUpdating$: Observable<boolean>;
    paymentTypes$: Observable<PaymentType[]>;
    typeSelected$: Observable<PaymentType>;
    cartPoNumber$: Observable<string>;
    activeCartFacade: ActiveCartFacade;
    isPONumberEditable$: Observable<boolean>;
    constructor(checkoutPaymentTypeFacade: CheckoutPaymentTypeFacade, checkoutStepService: CheckoutStepService, activatedRoute: ActivatedRoute, globalMessageService: GlobalMessageService);
    changeType(code: string): void;
    next(): void;
    back(): void;
    protected onSuccess(): void;
    protected onError(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPaymentTypeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutPaymentTypeComponent, "cx-payment-type", never, {}, {}, never, never, true, never>;
}

declare class CheckoutPaymentTypeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPaymentTypeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutPaymentTypeModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i2$1.SpinnerModule, typeof i2.ConfigModule, typeof i2.FeaturesConfigModule, typeof CheckoutPaymentTypeComponent], [typeof CheckoutPaymentTypeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutPaymentTypeModule>;
}

interface CardWithAddress {
    card: Card;
    address: Address;
}
declare class B2BCheckoutDeliveryAddressComponent extends CheckoutDeliveryAddressComponent implements OnInit, OnDestroy {
    protected userAddressService: UserAddressService;
    protected checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade;
    protected activatedRoute: ActivatedRoute;
    protected translationService: TranslationService;
    protected activeCartFacade: ActiveCartFacade;
    protected checkoutStepService: CheckoutStepService;
    protected checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade;
    protected globalMessageService: GlobalMessageService;
    protected checkoutCostCenterFacade: CheckoutCostCenterFacade;
    protected checkoutPaymentTypeFacade: CheckoutPaymentTypeFacade;
    protected userCostCenterService: UserCostCenterService;
    protected subscriptions: Subscription;
    protected isAccountPayment$: Observable<boolean>;
    protected costCenterAddresses$: Observable<Address[]>;
    protected creditCardAddressLoading$: Observable<boolean>;
    protected accountAddressLoading$: Observable<boolean>;
    isAccountPayment: boolean;
    constructor(userAddressService: UserAddressService, checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade, activatedRoute: ActivatedRoute, translationService: TranslationService, activeCartFacade: ActiveCartFacade, checkoutStepService: CheckoutStepService, checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade, globalMessageService: GlobalMessageService, checkoutCostCenterFacade: CheckoutCostCenterFacade, checkoutPaymentTypeFacade: CheckoutPaymentTypeFacade, userCostCenterService: UserCostCenterService);
    ngOnInit(): void;
    protected loadAddresses(): void;
    protected getAddressLoading(): Observable<boolean>;
    protected getSupportedAddresses(): Observable<Address[]>;
    protected selectDefaultAddress(addresses: Address[], selected: Address | undefined): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<B2BCheckoutDeliveryAddressComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<B2BCheckoutDeliveryAddressComponent, "cx-delivery-address", never, {}, {}, never, never, true, never>;
}

declare class B2BCheckoutDeliveryAddressModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<B2BCheckoutDeliveryAddressModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<B2BCheckoutDeliveryAddressModule, never, [typeof i1.CommonModule, typeof i2$2.RouterModule, typeof i3.AddressFormModule, typeof i2$1.CardModule, typeof i2$1.SpinnerModule, typeof i2.I18nModule, typeof i2.FeaturesConfigModule, typeof B2BCheckoutDeliveryAddressComponent], [typeof B2BCheckoutDeliveryAddressComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<B2BCheckoutDeliveryAddressModule>;
}

declare class B2BCheckoutReviewSubmitComponent extends CheckoutReviewSubmitComponent {
    protected checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade;
    protected checkoutPaymentFacade: CheckoutPaymentFacade;
    protected activeCartFacade: ActiveCartFacade;
    protected translationService: TranslationService;
    protected checkoutStepService: CheckoutStepService;
    protected checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade;
    protected checkoutPaymentTypeFacade: CheckoutPaymentTypeFacade;
    protected checkoutCostCenterFacade: CheckoutCostCenterFacade;
    protected userCostCenterService: UserCostCenterService;
    checkoutStepTypePaymentType: CheckoutStepType;
    constructor(checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade, checkoutPaymentFacade: CheckoutPaymentFacade, activeCartFacade: ActiveCartFacade, translationService: TranslationService, checkoutStepService: CheckoutStepService, checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade, checkoutPaymentTypeFacade: CheckoutPaymentTypeFacade, checkoutCostCenterFacade: CheckoutCostCenterFacade, userCostCenterService: UserCostCenterService);
    get poNumber$(): Observable<string | undefined>;
    get paymentType$(): Observable<PaymentType | undefined>;
    get isAccountPayment$(): Observable<boolean>;
    get costCenter$(): Observable<CostCenter | undefined>;
    protected getCheckoutPaymentSteps(): Array<CheckoutStepType | string>;
    getCostCenterCard(costCenter?: CostCenter): Observable<Card>;
    getPoNumberCard(poNumber?: string | null): Observable<Card>;
    getPaymentTypeCard(paymentType: PaymentType): Observable<Card>;
    static ɵfac: i0.ɵɵFactoryDeclaration<B2BCheckoutReviewSubmitComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<B2BCheckoutReviewSubmitComponent, "cx-review-submit", never, {}, {}, never, never, true, never>;
}

declare class B2BCheckoutReviewSubmitModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<B2BCheckoutReviewSubmitModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<B2BCheckoutReviewSubmitModule, never, [typeof i1.CommonModule, typeof i2$1.CardModule, typeof i2.I18nModule, typeof i2.UrlModule, typeof i2$2.RouterModule, typeof i2$1.PromotionsModule, typeof i2$1.IconModule, typeof i2$1.OutletModule, typeof B2BCheckoutReviewSubmitComponent], [typeof B2BCheckoutReviewSubmitComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<B2BCheckoutReviewSubmitModule>;
}

declare class CheckoutB2BComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutB2BComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutB2BComponentsModule, never, [typeof i1.CommonModule, typeof CheckoutCostCenterModule, typeof CheckoutPaymentTypeModule, typeof B2BCheckoutDeliveryAddressModule, typeof B2BCheckoutReviewSubmitModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutB2BComponentsModule>;
}

declare class CheckoutB2BAuthGuard extends CheckoutAuthGuard {
    protected authService: AuthService;
    protected authRedirectService: AuthRedirectService;
    protected checkoutConfigService: CheckoutConfigService;
    protected activeCartFacade: ActiveCartFacade;
    protected semanticPathService: SemanticPathService;
    protected router: Router;
    protected userAccountFacade: UserAccountFacade;
    protected globalMessageService: GlobalMessageService;
    constructor(authService: AuthService, authRedirectService: AuthRedirectService, checkoutConfigService: CheckoutConfigService, activeCartFacade: ActiveCartFacade, semanticPathService: SemanticPathService, router: Router, userAccountFacade: UserAccountFacade, globalMessageService: GlobalMessageService);
    canActivate(): Observable<GuardResult>;
    protected handleUserRole(user: User): boolean | UrlTree;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutB2BAuthGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutB2BAuthGuard>;
}

declare class CheckoutB2BStepsSetGuard extends CheckoutStepsSetGuard {
    protected checkoutStepService: CheckoutStepService;
    protected routingConfigService: RoutingConfigService;
    protected checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade;
    protected checkoutPaymentFacade: CheckoutPaymentFacade;
    protected checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade;
    protected router: Router;
    protected checkoutPaymentTypeFacade: CheckoutPaymentTypeFacade;
    protected checkoutCostCenterFacade: CheckoutCostCenterFacade;
    protected activeCartFacade: ActiveCartFacade;
    protected logger: LoggerService;
    constructor(checkoutStepService: CheckoutStepService, routingConfigService: RoutingConfigService, checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade, checkoutPaymentFacade: CheckoutPaymentFacade, checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade, router: Router, checkoutPaymentTypeFacade: CheckoutPaymentTypeFacade, checkoutCostCenterFacade: CheckoutCostCenterFacade, activeCartFacade: ActiveCartFacade);
    canActivate(route: ActivatedRouteSnapshot): Observable<GuardResult>;
    protected isB2BStepSet(step: CheckoutStep, isAccountPayment: boolean): Observable<GuardResult>;
    protected isPaymentTypeSet(step: CheckoutStep): Observable<GuardResult>;
    protected isDeliveryAddressAndCostCenterSet(step: CheckoutStep, isAccountPayment: boolean): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutB2BStepsSetGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutB2BStepsSetGuard>;
}

export { B2BCheckoutDeliveryAddressComponent, B2BCheckoutDeliveryAddressModule, B2BCheckoutReviewSubmitComponent, B2BCheckoutReviewSubmitModule, CheckoutB2BAuthGuard, CheckoutB2BComponentsModule, CheckoutB2BStepsSetGuard, CheckoutCostCenterComponent, CheckoutCostCenterModule, CheckoutPaymentTypeComponent, CheckoutPaymentTypeModule };
export type { CardWithAddress };
