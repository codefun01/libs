import { HttpClient } from '@angular/common/http';
import { Cart, PaymentType } from '@spartacus/cart/base/root';
import { CheckoutCostCenterAdapter, CheckoutPaymentTypeAdapter } from '@spartacus/checkout/b2b/core';
import { OccEndpointsService, ConverterService, LoggerService, OccEndpoint } from '@spartacus/core';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare class OccCheckoutCostCenterAdapter implements CheckoutCostCenterAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    setCostCenter(userId: string, cartId: string, costCenterId: string): Observable<Cart>;
    protected getSetCartCostCenterEndpoint(userId: string, cartId: string, costCenterId: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCheckoutCostCenterAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCheckoutCostCenterAdapter>;
}

declare class OccCheckoutPaymentTypeAdapter implements CheckoutPaymentTypeAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    getPaymentTypes(): Observable<PaymentType[]>;
    protected getPaymentTypesEndpoint(): string;
    setPaymentType(userId: string, cartId: string, paymentType: string, purchaseOrderNumber?: string): Observable<Cart>;
    protected getSetCartPaymentTypeEndpoint(userId: string, cartId: string, paymentType: string, purchaseOrderNumber?: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCheckoutPaymentTypeAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCheckoutPaymentTypeAdapter>;
}

declare class CheckoutB2BOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutB2BOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutB2BOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutB2BOccModule>;
}

interface CheckoutB2BOccEndpoints {
    /**
     * Returns a list of the available payment types.
     */
    paymentTypes?: string | OccEndpoint;
    /**
     * Sets the cost center for the checkout cart.
     */
    setCartCostCenter?: string | OccEndpoint;
    /**
     * Sets the payment type for the checkout cart
     */
    setCartPaymentType?: string | OccEndpoint;
}
declare module '@spartacus/core' {
    interface OccEndpoints extends CheckoutB2BOccEndpoints {
    }
}

export { CheckoutB2BOccModule, OccCheckoutCostCenterAdapter, OccCheckoutPaymentTypeAdapter };
export type { CheckoutB2BOccEndpoints };
