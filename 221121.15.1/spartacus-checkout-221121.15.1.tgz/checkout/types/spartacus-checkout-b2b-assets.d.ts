import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    checkoutB2B: {
        checkoutB2B: {
            noPoNumber: string;
            poNumber: string;
            costCenter: string;
            placeholder: string;
            availableLabel: string;
            invalid: {
                accountType: string;
            };
            methodOfPayment: {
                paymentType: string;
            };
            review: {
                poNumber: string;
            };
            progress: {
                methodOfPayment: string;
            };
            invalidCostCenter: string;
        };
    };
};

declare const de: {
    checkoutB2B: {
        checkoutB2B: {
            noPoNumber: string;
            poNumber: string;
            costCenter: string;
            placeholder: string;
            availableLabel: string;
            invalid: {
                accountType: string;
            };
            methodOfPayment: {
                paymentType: string;
            };
            review: {
                poNumber: string;
            };
            progress: {
                methodOfPayment: string;
            };
            invalidCostCenter: string;
        };
    };
};

declare const en: {
    checkoutB2B: {
        checkoutB2B: {
            noPoNumber: string;
            poNumber: string;
            costCenter: string;
            placeholder: string;
            availableLabel: string;
            invalid: {
                accountType: string;
            };
            methodOfPayment: {
                paymentType: string;
            };
            review: {
                poNumber: string;
            };
            progress: {
                methodOfPayment: string;
            };
            invalidCostCenter: string;
        };
    };
};

declare const es: {
    checkoutB2B: {
        checkoutB2B: {
            noPoNumber: string;
            poNumber: string;
            costCenter: string;
            placeholder: string;
            availableLabel: string;
            invalid: {
                accountType: string;
            };
            methodOfPayment: {
                paymentType: string;
            };
            review: {
                poNumber: string;
            };
            progress: {
                methodOfPayment: string;
            };
            invalidCostCenter: string;
        };
    };
};

declare const es_CO: {
    checkoutB2B: {
        checkoutB2B: {
            noPoNumber: string;
            poNumber: string;
            costCenter: string;
            placeholder: string;
            availableLabel: string;
            invalid: {
                accountType: string;
            };
            methodOfPayment: {
                paymentType: string;
            };
            review: {
                poNumber: string;
            };
            progress: {
                methodOfPayment: string;
            };
            invalidCostCenter: string;
        };
    };
};

declare const fr: {
    checkoutB2B: {
        checkoutB2B: {
            noPoNumber: string;
            poNumber: string;
            costCenter: string;
            placeholder: string;
            availableLabel: string;
            invalid: {
                accountType: string;
            };
            methodOfPayment: {
                paymentType: string;
            };
            review: {
                poNumber: string;
            };
            progress: {
                methodOfPayment: string;
            };
            invalidCostCenter: string;
        };
    };
};

declare const hi: {
    checkoutB2B: {
        checkoutB2B: {
            noPoNumber: string;
            poNumber: string;
            costCenter: string;
            placeholder: string;
            availableLabel: string;
            invalid: {
                accountType: string;
            };
            methodOfPayment: {
                paymentType: string;
            };
            review: {
                poNumber: string;
            };
            progress: {
                methodOfPayment: string;
            };
            invalidCostCenter: string;
        };
    };
};

declare const hu: {
    checkoutB2B: {
        checkoutB2B: {
            noPoNumber: string;
            poNumber: string;
            costCenter: string;
            placeholder: string;
            availableLabel: string;
            invalid: {
                accountType: string;
            };
            methodOfPayment: {
                paymentType: string;
            };
            review: {
                poNumber: string;
            };
            progress: {
                methodOfPayment: string;
            };
            invalidCostCenter: string;
        };
    };
};

declare const id: {
    checkoutB2B: {
        checkoutB2B: {
            noPoNumber: string;
            poNumber: string;
            costCenter: string;
            placeholder: string;
            availableLabel: string;
            invalid: {
                accountType: string;
            };
            methodOfPayment: {
                paymentType: string;
            };
            review: {
                poNumber: string;
            };
            progress: {
                methodOfPayment: string;
            };
            invalidCostCenter: string;
        };
    };
};

declare const it: {
    checkoutB2B: {
        checkoutB2B: {
            noPoNumber: string;
            poNumber: string;
            costCenter: string;
            placeholder: string;
            availableLabel: string;
            invalid: {
                accountType: string;
            };
            methodOfPayment: {
                paymentType: string;
            };
            review: {
                poNumber: string;
            };
            progress: {
                methodOfPayment: string;
            };
            invalidCostCenter: string;
        };
    };
};

declare const ja: {
    checkoutB2B: {
        checkoutB2B: {
            noPoNumber: string;
            poNumber: string;
            costCenter: string;
            placeholder: string;
            availableLabel: string;
            invalid: {
                accountType: string;
            };
            methodOfPayment: {
                paymentType: string;
            };
            review: {
                poNumber: string;
            };
            progress: {
                methodOfPayment: string;
            };
            invalidCostCenter: string;
        };
    };
};

declare const ko: {
    checkoutB2B: {
        checkoutB2B: {
            noPoNumber: string;
            poNumber: string;
            costCenter: string;
            placeholder: string;
            availableLabel: string;
            invalid: {
                accountType: string;
            };
            methodOfPayment: {
                paymentType: string;
            };
            review: {
                poNumber: string;
            };
            progress: {
                methodOfPayment: string;
            };
            invalidCostCenter: string;
        };
    };
};

declare const pl: {
    checkoutB2B: {
        checkoutB2B: {
            noPoNumber: string;
            poNumber: string;
            costCenter: string;
            placeholder: string;
            availableLabel: string;
            invalid: {
                accountType: string;
            };
            methodOfPayment: {
                paymentType: string;
            };
            review: {
                poNumber: string;
            };
            progress: {
                methodOfPayment: string;
            };
            invalidCostCenter: string;
        };
    };
};

declare const pt: {
    checkoutB2B: {
        checkoutB2B: {
            noPoNumber: string;
            poNumber: string;
            costCenter: string;
            placeholder: string;
            availableLabel: string;
            invalid: {
                accountType: string;
            };
            methodOfPayment: {
                paymentType: string;
            };
            review: {
                poNumber: string;
            };
            progress: {
                methodOfPayment: string;
            };
            invalidCostCenter: string;
        };
    };
};

declare const ru: {
    checkoutB2B: {
        checkoutB2B: {
            noPoNumber: string;
            poNumber: string;
            costCenter: string;
            placeholder: string;
            availableLabel: string;
            invalid: {
                accountType: string;
            };
            methodOfPayment: {
                paymentType: string;
            };
            review: {
                poNumber: string;
            };
            progress: {
                methodOfPayment: string;
            };
            invalidCostCenter: string;
        };
    };
};

declare const zh: {
    checkoutB2B: {
        checkoutB2B: {
            noPoNumber: string;
            poNumber: string;
            costCenter: string;
            placeholder: string;
            availableLabel: string;
            invalid: {
                accountType: string;
            };
            methodOfPayment: {
                paymentType: string;
            };
            review: {
                poNumber: string;
            };
            progress: {
                methodOfPayment: string;
            };
            invalidCostCenter: string;
        };
    };
};

declare const zh_TW: {
    checkoutB2B: {
        checkoutB2B: {
            noPoNumber: string;
            poNumber: string;
            costCenter: string;
            placeholder: string;
            availableLabel: string;
            invalid: {
                accountType: string;
            };
            methodOfPayment: {
                paymentType: string;
            };
            review: {
                poNumber: string;
            };
            progress: {
                methodOfPayment: string;
            };
            invalidCostCenter: string;
        };
    };
};

declare const checkoutB2BTranslationChunksConfig: TranslationChunksConfig;

export { checkoutB2BTranslationChunksConfig, cs as checkoutB2BTranslationsCs, de as checkoutB2BTranslationsDe, en as checkoutB2BTranslationsEn, es as checkoutB2BTranslationsEs, es_CO as checkoutB2BTranslationsEs_CO, fr as checkoutB2BTranslationsFr, hi as checkoutB2BTranslationsHi, hu as checkoutB2BTranslationsHu, id as checkoutB2BTranslationsId, it as checkoutB2BTranslationsIt, ja as checkoutB2BTranslationsJa, ko as checkoutB2BTranslationsKo, pl as checkoutB2BTranslationsPl, pt as checkoutB2BTranslationsPt, ru as checkoutB2BTranslationsRu, zh as checkoutB2BTranslationsZh, zh_TW as checkoutB2BTranslationsZh_TW };
