import { HttpClient } from '@angular/common/http';
import { CheckoutBillingAddressAdapter, CheckoutDeliveryAddressAdapter, CheckoutDeliveryModesAdapter, CheckoutPaymentAdapter, CheckoutAdapter } from '@spartacus/checkout/base/core';
import { LoggerService, OccEndpointsService, ConverterService, Address, PaymentDetails, CardType, OccEndpoint } from '@spartacus/core';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import { DeliveryMode } from '@spartacus/cart/base/root';
import { CheckoutState } from '@spartacus/checkout/base/root';
import * as i1 from '@angular/common';

declare class OccCheckoutBillingAddressAdapter implements CheckoutBillingAddressAdapter {
    protected logger: LoggerService;
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    setBillingAddress(userId: string, cartId: string, address: Address): Observable<unknown>;
    protected getSetBillingAddressEndpoint(userId: string, cartId: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCheckoutBillingAddressAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCheckoutBillingAddressAdapter>;
}

declare class OccCheckoutDeliveryAddressAdapter implements CheckoutDeliveryAddressAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    createAddress(userId: string, cartId: string, address: Address): Observable<Address>;
    protected getCreateDeliveryAddressEndpoint(userId: string, cartId: string): string;
    setAddress(userId: string, cartId: string, addressId: string): Observable<unknown>;
    protected getSetDeliveryAddressEndpoint(userId: string, cartId: string, addressId?: string): string;
    clearCheckoutDeliveryAddress(userId: string, cartId: string): Observable<unknown>;
    protected getRemoveDeliveryAddressEndpoint(userId: string, cartId: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCheckoutDeliveryAddressAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCheckoutDeliveryAddressAdapter>;
}

declare class OccCheckoutDeliveryModesAdapter implements CheckoutDeliveryModesAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    setMode(userId: string, cartId: string, deliveryModeId: string): Observable<unknown>;
    protected getSetDeliveryModeEndpoint(userId: string, cartId: string, deliveryModeId?: string): string;
    getSupportedModes(userId: string, cartId: string): Observable<DeliveryMode[]>;
    protected getDeliveryModesEndpoint(userId: string, cartId: string): string;
    clearCheckoutDeliveryMode(userId: string, cartId: string): Observable<unknown>;
    protected getClearDeliveryModeEndpoint(userId: string, cartId: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCheckoutDeliveryModesAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCheckoutDeliveryModesAdapter>;
}

declare class OccCheckoutPaymentAdapter implements CheckoutPaymentAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    private domparser;
    createPaymentDetails(userId: string, cartId: string, paymentDetails: PaymentDetails): Observable<PaymentDetails>;
    setPaymentDetails(userId: string, cartId: string, paymentDetailsId: string): Observable<unknown>;
    protected getSetPaymentDetailsEndpoint(userId: string, cartId: string, paymentDetailsId: string): string;
    deletePaymentDetails(userId: string, cartId: string): Observable<unknown>;
    getPaymentCardTypes(): Observable<CardType[]>;
    protected getPaymentCardTypesEndpoint(): string;
    protected getProviderSubInfo(userId: string, cartId: string): Observable<any>;
    protected getPaymentProviderSubInfoEndpoint(userId: string, cartId: string): string;
    protected createSubWithProvider(postUrl: string, parameters: any): Observable<any>;
    protected createDetailsWithParameters(userId: string, cartId: string, parameters: any): Observable<PaymentDetails>;
    protected getCreatePaymentDetailsEndpoint(userId: string, cartId: string): string;
    private getParamsForPaymentProvider;
    private extractPaymentDetailsFromHtml;
    private convertToMap;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCheckoutPaymentAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCheckoutPaymentAdapter>;
}

declare class OccCheckoutAdapter implements CheckoutAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    getCheckoutDetails(userId: string, cartId: string): Observable<CheckoutState>;
    protected getGetCheckoutDetailsEndpoint(userId: string, cartId: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCheckoutAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCheckoutAdapter>;
}

declare class CheckoutOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutOccModule>;
}

interface CheckoutOccEndpoints {
    /**
     * Endpoint for set delivery address to cart
     */
    setDeliveryAddress?: string | OccEndpoint;
    /**
     * Get a list of supported payment card types.
     */
    cardTypes?: string | OccEndpoint;
    /**
     * Sets credit card payment details for the cart.
     */
    setCartPaymentDetails?: string | OccEndpoint;
    /**
     *  Get information needed for create subscription
     */
    paymentProviderSubInfo?: string | OccEndpoint;
    /**
     * Handles response from payment provider and create payment details
     */
    createPaymentDetails?: string | OccEndpoint;
    /**
     * Get checkout details
     */
    getCheckoutDetails?: string | OccEndpoint;
    /**
     * Endpoint for create delivery address
     */
    createDeliveryAddress?: string | OccEndpoint;
    /**
     * Endpoint for delete deliver address
     */
    removeDeliveryAddress?: string | OccEndpoint;
    /**
     * Endpoint for get the delivery mode selected for the cart.
     */
    deliveryMode?: string | OccEndpoint;
    /**
     * Endpoint for sets the delivery mode for a cart.
     */
    setDeliveryMode?: string | OccEndpoint;
    /**
     * Endpoint for deletes the delivery mode from the cart.
     */
    clearDeliveryMode?: string | OccEndpoint;
    /**
     *Endpoint for get all delivery modes for the current store and delivery address.
     */
    deliveryModes?: string | OccEndpoint;
    /**
     * Endpoint for set billing address to cart
     */
    setBillingAddress?: string | OccEndpoint;
}
declare module '@spartacus/core' {
    interface OccEndpoints extends CheckoutOccEndpoints {
    }
}

export { CheckoutOccModule, OccCheckoutAdapter, OccCheckoutBillingAddressAdapter, OccCheckoutDeliveryAddressAdapter, OccCheckoutDeliveryModesAdapter, OccCheckoutPaymentAdapter };
export type { CheckoutOccEndpoints };
