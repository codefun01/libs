import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    checkoutScheduledReplenishment: {
        checkoutScheduledReplenishment: {
            autoReplenishOrder: string;
            orderType_PLACE_ORDER: string;
            orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
            every: string;
            recurrencePeriodType_DAILY: string;
            recurrencePeriodType_WEEKLY: string;
            recurrencePeriodType_MONTHLY: string;
            dayOfMonth: string;
            startOn: string;
            repeatOnDays: string;
            duration: string;
        };
    };
};

declare const de: {
    checkoutScheduledReplenishment: {
        checkoutScheduledReplenishment: {
            autoReplenishOrder: string;
            orderType_PLACE_ORDER: string;
            orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
            every: string;
            recurrencePeriodType_DAILY: string;
            recurrencePeriodType_WEEKLY: string;
            recurrencePeriodType_MONTHLY: string;
            dayOfMonth: string;
            startOn: string;
            repeatOnDays: string;
            duration: string;
        };
    };
};

declare const en: {
    checkoutScheduledReplenishment: {
        checkoutScheduledReplenishment: {
            autoReplenishOrder: string;
            orderType_PLACE_ORDER: string;
            orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
            every: string;
            recurrencePeriodType_DAILY: string;
            recurrencePeriodType_WEEKLY: string;
            recurrencePeriodType_MONTHLY: string;
            dayOfMonth: string;
            startOn: string;
            repeatOnDays: string;
            duration: string;
        };
    };
};

declare const es: {
    checkoutScheduledReplenishment: {
        checkoutScheduledReplenishment: {
            autoReplenishOrder: string;
            orderType_PLACE_ORDER: string;
            orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
            every: string;
            recurrencePeriodType_DAILY: string;
            recurrencePeriodType_WEEKLY: string;
            recurrencePeriodType_MONTHLY: string;
            dayOfMonth: string;
            startOn: string;
            repeatOnDays: string;
            duration: string;
        };
    };
};

declare const es_CO: {
    checkoutScheduledReplenishment: {
        checkoutScheduledReplenishment: {
            autoReplenishOrder: string;
            orderType_PLACE_ORDER: string;
            orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
            every: string;
            recurrencePeriodType_DAILY: string;
            recurrencePeriodType_WEEKLY: string;
            recurrencePeriodType_MONTHLY: string;
            dayOfMonth: string;
            startOn: string;
            repeatOnDays: string;
            duration: string;
        };
    };
};

declare const fr: {
    checkoutScheduledReplenishment: {
        checkoutScheduledReplenishment: {
            autoReplenishOrder: string;
            orderType_PLACE_ORDER: string;
            orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
            every: string;
            recurrencePeriodType_DAILY: string;
            recurrencePeriodType_WEEKLY: string;
            recurrencePeriodType_MONTHLY: string;
            dayOfMonth: string;
            startOn: string;
            repeatOnDays: string;
            duration: string;
        };
    };
};

declare const hi: {
    checkoutScheduledReplenishment: {
        checkoutScheduledReplenishment: {
            autoReplenishOrder: string;
            orderType_PLACE_ORDER: string;
            orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
            every: string;
            recurrencePeriodType_DAILY: string;
            recurrencePeriodType_WEEKLY: string;
            recurrencePeriodType_MONTHLY: string;
            dayOfMonth: string;
            startOn: string;
            repeatOnDays: string;
            duration: string;
        };
    };
};

declare const hu: {
    checkoutScheduledReplenishment: {
        checkoutScheduledReplenishment: {
            autoReplenishOrder: string;
            orderType_PLACE_ORDER: string;
            orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
            every: string;
            recurrencePeriodType_DAILY: string;
            recurrencePeriodType_WEEKLY: string;
            recurrencePeriodType_MONTHLY: string;
            dayOfMonth: string;
            startOn: string;
            repeatOnDays: string;
            duration: string;
        };
    };
};

declare const id: {
    checkoutScheduledReplenishment: {
        checkoutScheduledReplenishment: {
            autoReplenishOrder: string;
            orderType_PLACE_ORDER: string;
            orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
            every: string;
            recurrencePeriodType_DAILY: string;
            recurrencePeriodType_WEEKLY: string;
            recurrencePeriodType_MONTHLY: string;
            dayOfMonth: string;
            startOn: string;
            repeatOnDays: string;
            duration: string;
        };
    };
};

declare const it: {
    checkoutScheduledReplenishment: {
        checkoutScheduledReplenishment: {
            autoReplenishOrder: string;
            orderType_PLACE_ORDER: string;
            orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
            every: string;
            recurrencePeriodType_DAILY: string;
            recurrencePeriodType_WEEKLY: string;
            recurrencePeriodType_MONTHLY: string;
            dayOfMonth: string;
            startOn: string;
            repeatOnDays: string;
            duration: string;
        };
    };
};

declare const ja: {
    checkoutScheduledReplenishment: {
        checkoutScheduledReplenishment: {
            autoReplenishOrder: string;
            orderType_PLACE_ORDER: string;
            orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
            every: string;
            recurrencePeriodType_DAILY: string;
            recurrencePeriodType_WEEKLY: string;
            recurrencePeriodType_MONTHLY: string;
            dayOfMonth: string;
            startOn: string;
            repeatOnDays: string;
            duration: string;
        };
    };
};

declare const ko: {
    checkoutScheduledReplenishment: {
        checkoutScheduledReplenishment: {
            autoReplenishOrder: string;
            orderType_PLACE_ORDER: string;
            orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
            every: string;
            recurrencePeriodType_DAILY: string;
            recurrencePeriodType_WEEKLY: string;
            recurrencePeriodType_MONTHLY: string;
            dayOfMonth: string;
            startOn: string;
            repeatOnDays: string;
            duration: string;
        };
    };
};

declare const pl: {
    checkoutScheduledReplenishment: {
        checkoutScheduledReplenishment: {
            autoReplenishOrder: string;
            orderType_PLACE_ORDER: string;
            orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
            every: string;
            recurrencePeriodType_DAILY: string;
            recurrencePeriodType_WEEKLY: string;
            recurrencePeriodType_MONTHLY: string;
            dayOfMonth: string;
            startOn: string;
            repeatOnDays: string;
            duration: string;
        };
    };
};

declare const pt: {
    checkoutScheduledReplenishment: {
        checkoutScheduledReplenishment: {
            autoReplenishOrder: string;
            orderType_PLACE_ORDER: string;
            orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
            every: string;
            recurrencePeriodType_DAILY: string;
            recurrencePeriodType_WEEKLY: string;
            recurrencePeriodType_MONTHLY: string;
            dayOfMonth: string;
            startOn: string;
            repeatOnDays: string;
            duration: string;
        };
    };
};

declare const ru: {
    checkoutScheduledReplenishment: {
        checkoutScheduledReplenishment: {
            autoReplenishOrder: string;
            orderType_PLACE_ORDER: string;
            orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
            every: string;
            recurrencePeriodType_DAILY: string;
            recurrencePeriodType_WEEKLY: string;
            recurrencePeriodType_MONTHLY: string;
            dayOfMonth: string;
            startOn: string;
            repeatOnDays: string;
            duration: string;
        };
    };
};

declare const zh: {
    checkoutScheduledReplenishment: {
        checkoutScheduledReplenishment: {
            autoReplenishOrder: string;
            orderType_PLACE_ORDER: string;
            orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
            every: string;
            recurrencePeriodType_DAILY: string;
            recurrencePeriodType_WEEKLY: string;
            recurrencePeriodType_MONTHLY: string;
            dayOfMonth: string;
            startOn: string;
            repeatOnDays: string;
            duration: string;
        };
    };
};

declare const zh_TW: {
    checkoutScheduledReplenishment: {
        checkoutScheduledReplenishment: {
            autoReplenishOrder: string;
            orderType_PLACE_ORDER: string;
            orderType_SCHEDULE_REPLENISHMENT_ORDER: string;
            every: string;
            recurrencePeriodType_DAILY: string;
            recurrencePeriodType_WEEKLY: string;
            recurrencePeriodType_MONTHLY: string;
            dayOfMonth: string;
            startOn: string;
            repeatOnDays: string;
            duration: string;
        };
    };
};

declare const checkoutScheduledReplenishmentTranslationChunksConfig: TranslationChunksConfig;

export { checkoutScheduledReplenishmentTranslationChunksConfig, cs as checkoutScheduledReplenishmentTranslationsCs, de as checkoutScheduledReplenishmentTranslationsDe, en as checkoutScheduledReplenishmentTranslationsEn, es as checkoutScheduledReplenishmentTranslationsEs, es_CO as checkoutScheduledReplenishmentTranslationsEs_CO, fr as checkoutScheduledReplenishmentTranslationsFr, hi as checkoutScheduledReplenishmentTranslationsHi, hu as checkoutScheduledReplenishmentTranslationsHu, id as checkoutScheduledReplenishmentTranslationsId, it as checkoutScheduledReplenishmentTranslationsIt, ja as checkoutScheduledReplenishmentTranslationsJa, ko as checkoutScheduledReplenishmentTranslationsKo, pl as checkoutScheduledReplenishmentTranslationsPl, pt as checkoutScheduledReplenishmentTranslationsPt, ru as checkoutScheduledReplenishmentTranslationsRu, zh as checkoutScheduledReplenishmentTranslationsZh, zh_TW as checkoutScheduledReplenishmentTranslationsZh_TW };
