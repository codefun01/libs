import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    checkout: {
        checkout: {
            backToCart: string;
        };
        checkoutProgress: {
            label: string;
            deliveryAddress: string;
            deliveryMode: string;
            paymentDetails: string;
            reviewOrder: string;
            state: {
                completed: string;
                selected: string;
                disabled: string;
            };
        };
        checkoutAddress: {
            shippingAddress: string;
            selectYourDeliveryAddress: string;
            defaultDeliveryAddress: string;
            addNewAddress: string;
            shipToThisAddress: string;
            deliveryAddressSelected: string;
        };
        checkoutMode: {
            deliveryMethod: string;
            deliveryOptions: string;
            standardDelivery: string;
            premiumDelivery: string;
            deliveryEntries: string;
        };
        checkoutReview: {
            review: string;
            reviewOrder: string;
            orderItems: string;
            confirmThatRead: string;
            placeOrder: string;
            termsAndConditions: string;
            editDeliveryAddressDetails: string;
            editBillingDetails: string;
            editPaymentDetails: string;
            editPaymentType: string;
            editDeliveryMode: string;
            orderInProcess: string;
        };
        checkoutOrderConfirmation: {
            confirmationOfOrder: string;
            thankYou: string;
            invoiceHasBeenSentByEmail: string;
            orderItems: string;
            orderPlacedSuccessfully: string;
            createAccount: string;
            createAccountForNext: string;
        };
    };
};

declare const de: {
    checkout: {
        checkout: {
            backToCart: string;
        };
        checkoutProgress: {
            label: string;
            deliveryAddress: string;
            deliveryMode: string;
            paymentDetails: string;
            reviewOrder: string;
            state: {
                completed: string;
                selected: string;
                disabled: string;
            };
        };
        checkoutAddress: {
            shippingAddress: string;
            selectYourDeliveryAddress: string;
            defaultDeliveryAddress: string;
            addNewAddress: string;
            shipToThisAddress: string;
            deliveryAddressSelected: string;
        };
        checkoutMode: {
            deliveryMethod: string;
            deliveryOptions: string;
            standardDelivery: string;
            premiumDelivery: string;
            deliveryEntries: string;
        };
        checkoutReview: {
            review: string;
            reviewOrder: string;
            orderItems: string;
            confirmThatRead: string;
            placeOrder: string;
            termsAndConditions: string;
            editDeliveryAddressDetails: string;
            editBillingDetails: string;
            editPaymentDetails: string;
            editPaymentType: string;
            editDeliveryMode: string;
            orderInProcess: string;
        };
        checkoutOrderConfirmation: {
            confirmationOfOrder: string;
            thankYou: string;
            invoiceHasBeenSentByEmail: string;
            orderItems: string;
            orderPlacedSuccessfully: string;
            createAccount: string;
            createAccountForNext: string;
        };
    };
};

declare const en: {
    checkout: {
        checkout: {
            backToCart: string;
        };
        checkoutProgress: {
            label: string;
            deliveryAddress: string;
            deliveryMode: string;
            paymentDetails: string;
            reviewOrder: string;
            state: {
                completed: string;
                selected: string;
                disabled: string;
            };
        };
        checkoutAddress: {
            shippingAddress: string;
            selectYourDeliveryAddress: string;
            defaultDeliveryAddress: string;
            addNewAddress: string;
            shipToThisAddress: string;
            deliveryAddressSelected: string;
        };
        checkoutMode: {
            deliveryMethod: string;
            deliveryOptions: string;
            standardDelivery: string;
            premiumDelivery: string;
            deliveryEntries: string;
        };
        checkoutReview: {
            review: string;
            reviewOrder: string;
            orderItems: string;
            confirmThatRead: string;
            placeOrder: string;
            termsAndConditions: string;
            editDeliveryAddressDetails: string;
            editBillingDetails: string;
            editPaymentDetails: string;
            editPaymentType: string;
            editDeliveryMode: string;
            orderInProcess: string;
        };
        checkoutOrderConfirmation: {
            confirmationOfOrder: string;
            thankYou: string;
            invoiceHasBeenSentByEmail: string;
            orderItems: string;
            orderPlacedSuccessfully: string;
            createAccount: string;
            createAccountForNext: string;
        };
    };
};

declare const es: {
    checkout: {
        checkout: {
            backToCart: string;
        };
        checkoutProgress: {
            label: string;
            deliveryAddress: string;
            deliveryMode: string;
            paymentDetails: string;
            reviewOrder: string;
            state: {
                completed: string;
                selected: string;
                disabled: string;
            };
        };
        checkoutAddress: {
            shippingAddress: string;
            selectYourDeliveryAddress: string;
            defaultDeliveryAddress: string;
            addNewAddress: string;
            shipToThisAddress: string;
            deliveryAddressSelected: string;
        };
        checkoutMode: {
            deliveryMethod: string;
            deliveryOptions: string;
            standardDelivery: string;
            premiumDelivery: string;
            deliveryEntries: string;
        };
        checkoutReview: {
            review: string;
            reviewOrder: string;
            orderItems: string;
            confirmThatRead: string;
            placeOrder: string;
            termsAndConditions: string;
            editDeliveryAddressDetails: string;
            editBillingDetails: string;
            editPaymentDetails: string;
            editPaymentType: string;
            editDeliveryMode: string;
            orderInProcess: string;
        };
        checkoutOrderConfirmation: {
            confirmationOfOrder: string;
            thankYou: string;
            invoiceHasBeenSentByEmail: string;
            orderItems: string;
            orderPlacedSuccessfully: string;
            createAccount: string;
            createAccountForNext: string;
        };
    };
};

declare const es_CO: {
    checkout: {
        checkout: {
            backToCart: string;
        };
        checkoutProgress: {
            label: string;
            deliveryAddress: string;
            deliveryMode: string;
            paymentDetails: string;
            reviewOrder: string;
            state: {
                completed: string;
                selected: string;
                disabled: string;
            };
        };
        checkoutAddress: {
            shippingAddress: string;
            selectYourDeliveryAddress: string;
            defaultDeliveryAddress: string;
            addNewAddress: string;
            shipToThisAddress: string;
            deliveryAddressSelected: string;
        };
        checkoutMode: {
            deliveryMethod: string;
            deliveryOptions: string;
            standardDelivery: string;
            premiumDelivery: string;
            deliveryEntries: string;
        };
        checkoutReview: {
            review: string;
            reviewOrder: string;
            orderItems: string;
            confirmThatRead: string;
            placeOrder: string;
            termsAndConditions: string;
            editDeliveryAddressDetails: string;
            editBillingDetails: string;
            editPaymentDetails: string;
            editPaymentType: string;
            editDeliveryMode: string;
            orderInProcess: string;
        };
        checkoutOrderConfirmation: {
            confirmationOfOrder: string;
            thankYou: string;
            invoiceHasBeenSentByEmail: string;
            orderItems: string;
            orderPlacedSuccessfully: string;
            createAccount: string;
            createAccountForNext: string;
        };
    };
};

declare const fr: {
    checkout: {
        checkout: {
            backToCart: string;
        };
        checkoutProgress: {
            label: string;
            deliveryAddress: string;
            deliveryMode: string;
            paymentDetails: string;
            reviewOrder: string;
            state: {
                completed: string;
                selected: string;
                disabled: string;
            };
        };
        checkoutAddress: {
            shippingAddress: string;
            selectYourDeliveryAddress: string;
            defaultDeliveryAddress: string;
            addNewAddress: string;
            shipToThisAddress: string;
            deliveryAddressSelected: string;
        };
        checkoutMode: {
            deliveryMethod: string;
            deliveryOptions: string;
            standardDelivery: string;
            premiumDelivery: string;
            deliveryEntries: string;
        };
        checkoutReview: {
            review: string;
            reviewOrder: string;
            orderItems: string;
            confirmThatRead: string;
            placeOrder: string;
            termsAndConditions: string;
            editDeliveryAddressDetails: string;
            editBillingDetails: string;
            editPaymentDetails: string;
            editPaymentType: string;
            editDeliveryMode: string;
            orderInProcess: string;
        };
        checkoutOrderConfirmation: {
            confirmationOfOrder: string;
            thankYou: string;
            invoiceHasBeenSentByEmail: string;
            orderItems: string;
            orderPlacedSuccessfully: string;
            createAccount: string;
            createAccountForNext: string;
        };
    };
};

declare const hi: {
    checkout: {
        checkout: {
            backToCart: string;
        };
        checkoutProgress: {
            label: string;
            deliveryAddress: string;
            deliveryMode: string;
            paymentDetails: string;
            reviewOrder: string;
            state: {
                completed: string;
                selected: string;
                disabled: string;
            };
        };
        checkoutAddress: {
            shippingAddress: string;
            selectYourDeliveryAddress: string;
            defaultDeliveryAddress: string;
            addNewAddress: string;
            shipToThisAddress: string;
            deliveryAddressSelected: string;
        };
        checkoutMode: {
            deliveryMethod: string;
            deliveryOptions: string;
            standardDelivery: string;
            premiumDelivery: string;
            deliveryEntries: string;
        };
        checkoutReview: {
            review: string;
            reviewOrder: string;
            orderItems: string;
            confirmThatRead: string;
            placeOrder: string;
            termsAndConditions: string;
            editDeliveryAddressDetails: string;
            editBillingDetails: string;
            editPaymentDetails: string;
            editPaymentType: string;
            editDeliveryMode: string;
            orderInProcess: string;
        };
        checkoutOrderConfirmation: {
            confirmationOfOrder: string;
            thankYou: string;
            invoiceHasBeenSentByEmail: string;
            orderItems: string;
            orderPlacedSuccessfully: string;
            createAccount: string;
            createAccountForNext: string;
        };
    };
};

declare const hu: {
    checkout: {
        checkout: {
            backToCart: string;
        };
        checkoutProgress: {
            label: string;
            deliveryAddress: string;
            deliveryMode: string;
            paymentDetails: string;
            reviewOrder: string;
            state: {
                completed: string;
                selected: string;
                disabled: string;
            };
        };
        checkoutAddress: {
            shippingAddress: string;
            selectYourDeliveryAddress: string;
            defaultDeliveryAddress: string;
            addNewAddress: string;
            shipToThisAddress: string;
            deliveryAddressSelected: string;
        };
        checkoutMode: {
            deliveryMethod: string;
            deliveryOptions: string;
            standardDelivery: string;
            premiumDelivery: string;
            deliveryEntries: string;
        };
        checkoutReview: {
            review: string;
            reviewOrder: string;
            orderItems: string;
            confirmThatRead: string;
            placeOrder: string;
            termsAndConditions: string;
            editDeliveryAddressDetails: string;
            editBillingDetails: string;
            editPaymentDetails: string;
            editPaymentType: string;
            editDeliveryMode: string;
            orderInProcess: string;
        };
        checkoutOrderConfirmation: {
            confirmationOfOrder: string;
            thankYou: string;
            invoiceHasBeenSentByEmail: string;
            orderItems: string;
            orderPlacedSuccessfully: string;
            createAccount: string;
            createAccountForNext: string;
        };
    };
};

declare const id: {
    checkout: {
        checkout: {
            backToCart: string;
        };
        checkoutProgress: {
            label: string;
            deliveryAddress: string;
            deliveryMode: string;
            paymentDetails: string;
            reviewOrder: string;
            state: {
                completed: string;
                selected: string;
                disabled: string;
            };
        };
        checkoutAddress: {
            shippingAddress: string;
            selectYourDeliveryAddress: string;
            defaultDeliveryAddress: string;
            addNewAddress: string;
            shipToThisAddress: string;
            deliveryAddressSelected: string;
        };
        checkoutMode: {
            deliveryMethod: string;
            deliveryOptions: string;
            standardDelivery: string;
            premiumDelivery: string;
            deliveryEntries: string;
        };
        checkoutReview: {
            review: string;
            reviewOrder: string;
            orderItems: string;
            confirmThatRead: string;
            placeOrder: string;
            termsAndConditions: string;
            editDeliveryAddressDetails: string;
            editBillingDetails: string;
            editPaymentDetails: string;
            editPaymentType: string;
            editDeliveryMode: string;
            orderInProcess: string;
        };
        checkoutOrderConfirmation: {
            confirmationOfOrder: string;
            thankYou: string;
            invoiceHasBeenSentByEmail: string;
            orderItems: string;
            orderPlacedSuccessfully: string;
            createAccount: string;
            createAccountForNext: string;
        };
    };
};

declare const it: {
    checkout: {
        checkout: {
            backToCart: string;
        };
        checkoutProgress: {
            label: string;
            deliveryAddress: string;
            deliveryMode: string;
            paymentDetails: string;
            reviewOrder: string;
            state: {
                completed: string;
                selected: string;
                disabled: string;
            };
        };
        checkoutAddress: {
            shippingAddress: string;
            selectYourDeliveryAddress: string;
            defaultDeliveryAddress: string;
            addNewAddress: string;
            shipToThisAddress: string;
            deliveryAddressSelected: string;
        };
        checkoutMode: {
            deliveryMethod: string;
            deliveryOptions: string;
            standardDelivery: string;
            premiumDelivery: string;
            deliveryEntries: string;
        };
        checkoutReview: {
            review: string;
            reviewOrder: string;
            orderItems: string;
            confirmThatRead: string;
            placeOrder: string;
            termsAndConditions: string;
            editDeliveryAddressDetails: string;
            editBillingDetails: string;
            editPaymentDetails: string;
            editPaymentType: string;
            editDeliveryMode: string;
            orderInProcess: string;
        };
        checkoutOrderConfirmation: {
            confirmationOfOrder: string;
            thankYou: string;
            invoiceHasBeenSentByEmail: string;
            orderItems: string;
            orderPlacedSuccessfully: string;
            createAccount: string;
            createAccountForNext: string;
        };
    };
};

declare const ja: {
    checkout: {
        checkout: {
            backToCart: string;
        };
        checkoutProgress: {
            label: string;
            deliveryAddress: string;
            deliveryMode: string;
            paymentDetails: string;
            reviewOrder: string;
            state: {
                completed: string;
                selected: string;
                disabled: string;
            };
        };
        checkoutAddress: {
            shippingAddress: string;
            selectYourDeliveryAddress: string;
            defaultDeliveryAddress: string;
            addNewAddress: string;
            shipToThisAddress: string;
            deliveryAddressSelected: string;
        };
        checkoutMode: {
            deliveryMethod: string;
            deliveryOptions: string;
            standardDelivery: string;
            premiumDelivery: string;
            deliveryEntries: string;
        };
        checkoutReview: {
            review: string;
            reviewOrder: string;
            orderItems: string;
            confirmThatRead: string;
            placeOrder: string;
            termsAndConditions: string;
            editDeliveryAddressDetails: string;
            editBillingDetails: string;
            editPaymentDetails: string;
            editPaymentType: string;
            editDeliveryMode: string;
            orderInProcess: string;
        };
        checkoutOrderConfirmation: {
            confirmationOfOrder: string;
            thankYou: string;
            invoiceHasBeenSentByEmail: string;
            orderItems: string;
            orderPlacedSuccessfully: string;
            createAccount: string;
            createAccountForNext: string;
        };
    };
};

declare const ko: {
    checkout: {
        checkout: {
            backToCart: string;
        };
        checkoutProgress: {
            label: string;
            deliveryAddress: string;
            deliveryMode: string;
            paymentDetails: string;
            reviewOrder: string;
            state: {
                completed: string;
                selected: string;
                disabled: string;
            };
        };
        checkoutAddress: {
            shippingAddress: string;
            selectYourDeliveryAddress: string;
            defaultDeliveryAddress: string;
            addNewAddress: string;
            shipToThisAddress: string;
            deliveryAddressSelected: string;
        };
        checkoutMode: {
            deliveryMethod: string;
            deliveryOptions: string;
            standardDelivery: string;
            premiumDelivery: string;
            deliveryEntries: string;
        };
        checkoutReview: {
            review: string;
            reviewOrder: string;
            orderItems: string;
            confirmThatRead: string;
            placeOrder: string;
            termsAndConditions: string;
            editDeliveryAddressDetails: string;
            editBillingDetails: string;
            editPaymentDetails: string;
            editPaymentType: string;
            editDeliveryMode: string;
            orderInProcess: string;
        };
        checkoutOrderConfirmation: {
            confirmationOfOrder: string;
            thankYou: string;
            invoiceHasBeenSentByEmail: string;
            orderItems: string;
            orderPlacedSuccessfully: string;
            createAccount: string;
            createAccountForNext: string;
        };
    };
};

declare const pl: {
    checkout: {
        checkout: {
            backToCart: string;
        };
        checkoutProgress: {
            label: string;
            deliveryAddress: string;
            deliveryMode: string;
            paymentDetails: string;
            reviewOrder: string;
            state: {
                completed: string;
                selected: string;
                disabled: string;
            };
        };
        checkoutAddress: {
            shippingAddress: string;
            selectYourDeliveryAddress: string;
            defaultDeliveryAddress: string;
            addNewAddress: string;
            shipToThisAddress: string;
            deliveryAddressSelected: string;
        };
        checkoutMode: {
            deliveryMethod: string;
            deliveryOptions: string;
            standardDelivery: string;
            premiumDelivery: string;
            deliveryEntries: string;
        };
        checkoutReview: {
            review: string;
            reviewOrder: string;
            orderItems: string;
            confirmThatRead: string;
            placeOrder: string;
            termsAndConditions: string;
            editDeliveryAddressDetails: string;
            editBillingDetails: string;
            editPaymentDetails: string;
            editPaymentType: string;
            editDeliveryMode: string;
            orderInProcess: string;
        };
        checkoutOrderConfirmation: {
            confirmationOfOrder: string;
            thankYou: string;
            invoiceHasBeenSentByEmail: string;
            orderItems: string;
            orderPlacedSuccessfully: string;
            createAccount: string;
            createAccountForNext: string;
        };
    };
};

declare const pt: {
    checkout: {
        checkout: {
            backToCart: string;
        };
        checkoutProgress: {
            label: string;
            deliveryAddress: string;
            deliveryMode: string;
            paymentDetails: string;
            reviewOrder: string;
            state: {
                completed: string;
                selected: string;
                disabled: string;
            };
        };
        checkoutAddress: {
            shippingAddress: string;
            selectYourDeliveryAddress: string;
            defaultDeliveryAddress: string;
            addNewAddress: string;
            shipToThisAddress: string;
            deliveryAddressSelected: string;
        };
        checkoutMode: {
            deliveryMethod: string;
            deliveryOptions: string;
            standardDelivery: string;
            premiumDelivery: string;
            deliveryEntries: string;
        };
        checkoutReview: {
            review: string;
            reviewOrder: string;
            orderItems: string;
            confirmThatRead: string;
            placeOrder: string;
            termsAndConditions: string;
            editDeliveryAddressDetails: string;
            editBillingDetails: string;
            editPaymentDetails: string;
            editPaymentType: string;
            editDeliveryMode: string;
            orderInProcess: string;
        };
        checkoutOrderConfirmation: {
            confirmationOfOrder: string;
            thankYou: string;
            invoiceHasBeenSentByEmail: string;
            orderItems: string;
            orderPlacedSuccessfully: string;
            createAccount: string;
            createAccountForNext: string;
        };
    };
};

declare const ru: {
    checkout: {
        checkout: {
            backToCart: string;
        };
        checkoutProgress: {
            label: string;
            deliveryAddress: string;
            deliveryMode: string;
            paymentDetails: string;
            reviewOrder: string;
            state: {
                completed: string;
                selected: string;
                disabled: string;
            };
        };
        checkoutAddress: {
            shippingAddress: string;
            selectYourDeliveryAddress: string;
            defaultDeliveryAddress: string;
            addNewAddress: string;
            shipToThisAddress: string;
            deliveryAddressSelected: string;
        };
        checkoutMode: {
            deliveryMethod: string;
            deliveryOptions: string;
            standardDelivery: string;
            premiumDelivery: string;
            deliveryEntries: string;
        };
        checkoutReview: {
            review: string;
            reviewOrder: string;
            orderItems: string;
            confirmThatRead: string;
            placeOrder: string;
            termsAndConditions: string;
            editDeliveryAddressDetails: string;
            editBillingDetails: string;
            editPaymentDetails: string;
            editPaymentType: string;
            editDeliveryMode: string;
            orderInProcess: string;
        };
        checkoutOrderConfirmation: {
            confirmationOfOrder: string;
            thankYou: string;
            invoiceHasBeenSentByEmail: string;
            orderItems: string;
            orderPlacedSuccessfully: string;
            createAccount: string;
            createAccountForNext: string;
        };
    };
};

declare const zh: {
    checkout: {
        checkout: {
            backToCart: string;
        };
        checkoutProgress: {
            label: string;
            deliveryAddress: string;
            deliveryMode: string;
            paymentDetails: string;
            reviewOrder: string;
            state: {
                completed: string;
                selected: string;
                disabled: string;
            };
        };
        checkoutAddress: {
            shippingAddress: string;
            selectYourDeliveryAddress: string;
            defaultDeliveryAddress: string;
            addNewAddress: string;
            shipToThisAddress: string;
            deliveryAddressSelected: string;
        };
        checkoutMode: {
            deliveryMethod: string;
            deliveryOptions: string;
            standardDelivery: string;
            premiumDelivery: string;
            deliveryEntries: string;
        };
        checkoutReview: {
            review: string;
            reviewOrder: string;
            orderItems: string;
            confirmThatRead: string;
            placeOrder: string;
            termsAndConditions: string;
            editDeliveryAddressDetails: string;
            editBillingDetails: string;
            editPaymentDetails: string;
            editPaymentType: string;
            editDeliveryMode: string;
            orderInProcess: string;
        };
        checkoutOrderConfirmation: {
            confirmationOfOrder: string;
            thankYou: string;
            invoiceHasBeenSentByEmail: string;
            orderItems: string;
            orderPlacedSuccessfully: string;
            createAccount: string;
            createAccountForNext: string;
        };
    };
};

declare const zh_TW: {
    checkout: {
        checkout: {
            backToCart: string;
        };
        checkoutProgress: {
            label: string;
            deliveryAddress: string;
            deliveryMode: string;
            paymentDetails: string;
            reviewOrder: string;
            state: {
                completed: string;
                selected: string;
                disabled: string;
            };
        };
        checkoutAddress: {
            shippingAddress: string;
            selectYourDeliveryAddress: string;
            defaultDeliveryAddress: string;
            addNewAddress: string;
            shipToThisAddress: string;
            deliveryAddressSelected: string;
        };
        checkoutMode: {
            deliveryMethod: string;
            deliveryOptions: string;
            standardDelivery: string;
            premiumDelivery: string;
            deliveryEntries: string;
        };
        checkoutReview: {
            review: string;
            reviewOrder: string;
            orderItems: string;
            confirmThatRead: string;
            placeOrder: string;
            termsAndConditions: string;
            editDeliveryAddressDetails: string;
            editBillingDetails: string;
            editPaymentDetails: string;
            editPaymentType: string;
            editDeliveryMode: string;
            orderInProcess: string;
        };
        checkoutOrderConfirmation: {
            confirmationOfOrder: string;
            thankYou: string;
            invoiceHasBeenSentByEmail: string;
            orderItems: string;
            orderPlacedSuccessfully: string;
            createAccount: string;
            createAccountForNext: string;
        };
    };
};

declare const checkoutTranslationChunksConfig: TranslationChunksConfig;

export { checkoutTranslationChunksConfig, cs as checkoutTranslationsCs, de as checkoutTranslationsDe, en as checkoutTranslationsEn, es as checkoutTranslationsEs, es_CO as checkoutTranslationsEs_CO, fr as checkoutTranslationsFr, hi as checkoutTranslationsHi, hu as checkoutTranslationsHu, id as checkoutTranslationsId, it as checkoutTranslationsIt, ja as checkoutTranslationsJa, ko as checkoutTranslationsKo, pl as checkoutTranslationsPl, pt as checkoutTranslationsPt, ru as checkoutTranslationsRu, zh as checkoutTranslationsZh, zh_TW as checkoutTranslationsZh_TW };
