import { EventService, CmsConfig } from '@spartacus/core';
import * as i0 from '@angular/core';
import { OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';

declare class CheckoutScheduledReplenishmentEventListener implements OnDestroy {
    protected eventService: EventService;
    protected subscriptions: Subscription;
    constructor(eventService: EventService);
    protected onReplenishmentOrder(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutScheduledReplenishmentEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutScheduledReplenishmentEventListener>;
}

declare class CheckoutScheduledReplenishmentEventModule {
    constructor(_checkoutScheduledReplenishmentEventListener: CheckoutScheduledReplenishmentEventListener);
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutScheduledReplenishmentEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutScheduledReplenishmentEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutScheduledReplenishmentEventModule>;
}

declare const CHECKOUT_SCHEDULED_REPLENISHMENT_CMS_COMPONENTS: string[];
declare function defaultCheckoutComponentsConfig(): CmsConfig;
declare class CheckoutScheduledReplenishmentRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutScheduledReplenishmentRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutScheduledReplenishmentRootModule, never, [typeof CheckoutScheduledReplenishmentEventModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutScheduledReplenishmentRootModule>;
}

export { CHECKOUT_SCHEDULED_REPLENISHMENT_CMS_COMPONENTS, CheckoutScheduledReplenishmentEventListener, CheckoutScheduledReplenishmentEventModule, CheckoutScheduledReplenishmentRootModule, defaultCheckoutComponentsConfig };
