import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import * as _spartacus_core from '@spartacus/core';
import { Address, Converter, PaymentDetails, CardType, UserIdService, CommandService, EventService, Command, QueryState, QueryService, QueryNotifier, Query, PageMetaResolver, PageHeadingResolver, PageTitleResolver, PageDescriptionResolver, PageRobotsResolver, TranslationService, BasePageMetaResolver, PageRobotsMeta } from '@spartacus/core';
import { Observable } from 'rxjs';
import { DeliveryMode, ActiveCartFacade } from '@spartacus/cart/base/root';
import { CheckoutState, CheckoutBillingAddressFacade, CheckoutQueryFacade, CheckoutDeliveryAddressFacade, CheckoutDeliveryModesFacade, CheckoutPaymentFacade } from '@spartacus/checkout/base/root';

declare class CheckoutCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutCoreModule>;
}

declare abstract class CheckoutBillingAddressAdapter {
    /**
     * Abstract method used to set address for billing
     *
     * @param userId
     * @param cartId
     * @param addressId
     */
    abstract setBillingAddress(userId: string, cartId: string, address: Address): Observable<unknown>;
}

declare abstract class CheckoutDeliveryAddressAdapter {
    /**
     * Abstract method used to create address in cart
     *
     * @param userId
     * @param cartId
     * @param address
     */
    abstract createAddress(userId: string, cartId: string, address: Address): Observable<Address>;
    /**
     * Abstract method used to set address for delivery
     *
     * @param userId
     * @param cartId
     * @param addressId
     */
    abstract setAddress(userId: string, cartId: string, addressId: string): Observable<unknown>;
    /**
     * Abstract method used to clear checkout delivery address
     *
     * @param userId
     * @param cartId
     */
    abstract clearCheckoutDeliveryAddress(userId: string, cartId: string): Observable<unknown>;
}

declare class CheckoutDeliveryAddressConnector {
    protected adapter: CheckoutDeliveryAddressAdapter;
    constructor(adapter: CheckoutDeliveryAddressAdapter);
    createAddress(userId: string, cartId: string, address: Address): Observable<Address>;
    setAddress(userId: string, cartId: string, addressId: string): Observable<unknown>;
    clearCheckoutDeliveryAddress(userId: string, cartId: string): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutDeliveryAddressConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutDeliveryAddressConnector>;
}

declare abstract class CheckoutDeliveryModesAdapter {
    /**
     * Abstract method used to set delivery mode on cart
     *
     * @param userId
     * @param cartId
     * @param deliveryModeId
     */
    abstract setMode(userId: string, cartId: string, deliveryModeId: string): Observable<unknown>;
    /**
     * Abstract method used to get supported delivery modes for cart
     *
     * @param userId
     * @param cartId
     */
    abstract getSupportedModes(userId: string, cartId: string): Observable<DeliveryMode[]>;
    /**
     * Abstract method used to clear checkout delivery mode
     *
     * @param userId
     * @param cartId
     */
    abstract clearCheckoutDeliveryMode(userId: string, cartId: string): Observable<unknown>;
}

declare class CheckoutDeliveryModesConnector {
    protected adapter: CheckoutDeliveryModesAdapter;
    constructor(adapter: CheckoutDeliveryModesAdapter);
    setMode(userId: string, cartId: string, deliveryModeId: string): Observable<unknown>;
    getSupportedModes(userId: string, cartId: string): Observable<DeliveryMode[]>;
    clearCheckoutDeliveryMode(userId: string, cartId: string): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutDeliveryModesConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutDeliveryModesConnector>;
}

declare const DELIVERY_MODE_NORMALIZER: InjectionToken<Converter<any, DeliveryMode>>;

declare abstract class CheckoutPaymentAdapter {
    /**
     * Abstract method used to create payment details on cart
     *
     * @param userId
     * @param cartId
     * @param paymentDetails
     */
    abstract createPaymentDetails(userId: string, cartId: string, paymentDetails: PaymentDetails): Observable<PaymentDetails>;
    /**
     * Abstract method used to set payment details on cart
     *
     * @param userId
     * @param cartId
     * @param paymentDetailsId
     */
    abstract setPaymentDetails(userId: string, cartId: string, paymentDetailsId: string): Observable<unknown>;
    /**
     * Abstract method used to delete payment details from cart
     *
     * @param userId
     * @param cartId
     */
    abstract deletePaymentDetails(userId: string, cartId: string): Observable<unknown>;
    /**
     * Abstract method used to get available card types
     */
    abstract getPaymentCardTypes(): Observable<CardType[]>;
}

declare class CheckoutPaymentConnector {
    protected adapter: CheckoutPaymentAdapter;
    constructor(adapter: CheckoutPaymentAdapter);
    createPaymentDetails(userId: string, cartId: string, paymentDetails: PaymentDetails): Observable<PaymentDetails>;
    setPaymentDetails(userId: string, cartId: string, paymentDetailsId: string): Observable<unknown>;
    deletePaymentDetails(userId: string, cartId: string): Observable<unknown>;
    getPaymentCardTypes(): Observable<CardType[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPaymentConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutPaymentConnector>;
}

declare const PAYMENT_DETAILS_SERIALIZER: InjectionToken<Converter<PaymentDetails, any>>;
declare const PAYMENT_CARD_TYPE_NORMALIZER: InjectionToken<Converter<any, CardType>>;

declare abstract class CheckoutAdapter {
    /**
     * Abstract method used to get checkout details
     *
     * @param userId
     * @param cartId
     */
    abstract getCheckoutDetails(userId: string, cartId: string): Observable<CheckoutState>;
}

declare class CheckoutConnector {
    protected adapter: CheckoutAdapter;
    constructor(adapter: CheckoutAdapter);
    getCheckoutDetails(userId: string, cartId: string): Observable<CheckoutState>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutConnector>;
}

declare const CHECKOUT_NORMALIZER: InjectionToken<Converter<any, CheckoutState>>;

declare class CheckoutBillingAddressConnector {
    protected adapter: CheckoutBillingAddressAdapter;
    setBillingAddress(userId: string, cartId: string, address: Address): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutBillingAddressConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutBillingAddressConnector>;
}

declare class CheckoutBillingAddressService implements CheckoutBillingAddressFacade {
    protected activeCartFacade: ActiveCartFacade;
    protected userIdService: UserIdService;
    protected commandService: CommandService;
    protected checkoutBillingAddressConnector: CheckoutBillingAddressConnector;
    protected checkoutQueryFacade: CheckoutQueryFacade;
    protected setBillingAddressCommand: _spartacus_core.Command<Address, unknown>;
    /**
     * Performs the necessary checkout preconditions.
     */
    protected checkoutPreconditions(): Observable<[string, string]>;
    setBillingAddress(address: Address): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutBillingAddressService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutBillingAddressService>;
}

declare class CheckoutDeliveryAddressService implements CheckoutDeliveryAddressFacade {
    protected activeCartFacade: ActiveCartFacade;
    protected userIdService: UserIdService;
    protected eventService: EventService;
    protected commandService: CommandService;
    protected checkoutDeliveryAddressConnector: CheckoutDeliveryAddressConnector;
    protected checkoutQueryFacade: CheckoutQueryFacade;
    protected createDeliveryAddressCommand: Command<Address, unknown>;
    protected setDeliveryAddressCommand: Command<Address, unknown>;
    protected clearDeliveryAddressCommand: Command<void, unknown>;
    constructor(activeCartFacade: ActiveCartFacade, userIdService: UserIdService, eventService: EventService, commandService: CommandService, checkoutDeliveryAddressConnector: CheckoutDeliveryAddressConnector, checkoutQueryFacade: CheckoutQueryFacade);
    /**
     * Performs the necessary checkout preconditions.
     */
    protected checkoutPreconditions(): Observable<[string, string]>;
    getDeliveryAddressState(): Observable<QueryState<Address | undefined>>;
    createAndSetAddress(address: Address): Observable<unknown>;
    setDeliveryAddress(address: Address): Observable<unknown>;
    clearCheckoutDeliveryAddress(): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutDeliveryAddressService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutDeliveryAddressService>;
}

declare class CheckoutDeliveryModesService implements CheckoutDeliveryModesFacade {
    protected activeCartFacade: ActiveCartFacade;
    protected userIdService: UserIdService;
    protected eventService: EventService;
    protected queryService: QueryService;
    protected commandService: CommandService;
    protected checkoutDeliveryModesConnector: CheckoutDeliveryModesConnector;
    protected checkoutQueryFacade: CheckoutQueryFacade;
    /**
     * Returns the reload events for the supportedDeliveryModes query
     */
    protected getCheckoutSupportedDeliveryModesQueryReloadEvents(): QueryNotifier[];
    /**
     * Return the reset events for the supportedDeliveryModes query
     */
    protected getCheckoutSupportedDeliveryModesQueryResetEvents(): QueryNotifier[];
    protected supportedDeliveryModesQuery: Query<DeliveryMode[]>;
    protected setDeliveryModeCommand: Command<string, unknown>;
    protected clearDeliveryModeCommand: Command<void, unknown>;
    constructor(activeCartFacade: ActiveCartFacade, userIdService: UserIdService, eventService: EventService, queryService: QueryService, commandService: CommandService, checkoutDeliveryModesConnector: CheckoutDeliveryModesConnector, checkoutQueryFacade: CheckoutQueryFacade);
    /**
     * Performs the necessary checkout preconditions.
     */
    protected checkoutPreconditions(): Observable<[string, string]>;
    getSupportedDeliveryModesState(): Observable<QueryState<DeliveryMode[]>>;
    getSupportedDeliveryModes(): Observable<DeliveryMode[]>;
    getSelectedDeliveryModeState(): Observable<QueryState<DeliveryMode | undefined>>;
    setDeliveryMode(mode: string): Observable<unknown>;
    clearCheckoutDeliveryMode(): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutDeliveryModesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutDeliveryModesService>;
}

declare class CheckoutPaymentService implements CheckoutPaymentFacade {
    protected activeCartFacade: ActiveCartFacade;
    protected userIdService: UserIdService;
    protected queryService: QueryService;
    protected commandService: CommandService;
    protected eventService: EventService;
    protected checkoutPaymentConnector: CheckoutPaymentConnector;
    protected checkoutQueryFacade: CheckoutQueryFacade;
    /**
     * Returns the reload events for the cardTypes query
     */
    protected getCheckoutPaymentCardTypesQueryReloadEvents(): QueryNotifier[];
    /**
     * Returns the reset events for the cardTypes query
     */
    protected getCheckoutPaymentCardTypesQueryResetEvents(): QueryNotifier[];
    protected paymentCardTypesQuery: Query<CardType[]>;
    protected createPaymentMethodCommand: Command<PaymentDetails, unknown>;
    protected setPaymentMethodCommand: Command<PaymentDetails, unknown>;
    protected deletePaymentMethodCommand: Command<void>;
    constructor(activeCartFacade: ActiveCartFacade, userIdService: UserIdService, queryService: QueryService, commandService: CommandService, eventService: EventService, checkoutPaymentConnector: CheckoutPaymentConnector, checkoutQueryFacade: CheckoutQueryFacade);
    /**
     * Performs the necessary checkout preconditions.
     */
    protected checkoutPreconditions(): Observable<[string, string]>;
    getPaymentCardTypesState(): Observable<QueryState<CardType[] | undefined>>;
    getPaymentCardTypes(): Observable<CardType[]>;
    getPaymentDetailsState(): Observable<QueryState<PaymentDetails | undefined>>;
    createPaymentDetails(paymentDetails: PaymentDetails): Observable<unknown>;
    setPaymentDetails(paymentDetails: PaymentDetails): Observable<unknown>;
    deletePaymentDetails(): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPaymentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutPaymentService>;
}

declare class CheckoutQueryService implements CheckoutQueryFacade {
    protected activeCartFacade: ActiveCartFacade;
    protected userIdService: UserIdService;
    protected queryService: QueryService;
    protected checkoutConnector: CheckoutConnector;
    /**
     * Returns the reload events for the checkout query.
     */
    protected getCheckoutQueryReloadEvents(): QueryNotifier[];
    /**
     * Returns the reset events for the checkout query.
     */
    protected getCheckoutQueryResetEvents(): QueryNotifier[];
    protected checkoutQuery$: Query<CheckoutState | undefined>;
    constructor(activeCartFacade: ActiveCartFacade, userIdService: UserIdService, queryService: QueryService, checkoutConnector: CheckoutConnector);
    /**
     * Performs the necessary checkout preconditions.
     */
    protected checkoutPreconditions(): Observable<[string, string]>;
    getCheckoutDetailsState(): Observable<QueryState<CheckoutState | undefined>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutQueryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutQueryService>;
}

/**
 * Resolves the page data for all Content Pages based on the `PageType.CONTENT_PAGE`
 * and the `MultiStepCheckoutSummaryPageTemplate`. If the checkout page matches this template,
 * the more generic `ContentPageMetaResolver` is overridden by this resolver.
 *
 * The page title and robots are resolved in this implementation only.
 */
declare class CheckoutPageMetaResolver extends PageMetaResolver implements PageHeadingResolver, PageTitleResolver, PageDescriptionResolver, PageRobotsResolver {
    protected translationService: TranslationService;
    protected activeCartFacade: ActiveCartFacade;
    protected basePageMetaResolver: BasePageMetaResolver;
    constructor(translationService: TranslationService, activeCartFacade: ActiveCartFacade, basePageMetaResolver: BasePageMetaResolver);
    /**
     * @override
     * Resolves the page title for the Checkout Page to include checkout step.
     * The page title used by the browser (history, tabs) and crawlers.
     *
     * The title from the page data is ignored for this page title.
     */
    resolveTitle(): Observable<string | undefined>;
    /**
     * Resolves the page heading for the Checkout Page.
     * The page heading is used in the UI (`<h1>`), where as the page
     * title is used by the browser and crawlers.
     */
    resolveHeading(): Observable<string>;
    resolveDescription(): Observable<string | undefined>;
    resolveRobots(): Observable<PageRobotsMeta[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPageMetaResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutPageMetaResolver>;
}

export { CHECKOUT_NORMALIZER, CheckoutAdapter, CheckoutBillingAddressAdapter, CheckoutBillingAddressService, CheckoutConnector, CheckoutCoreModule, CheckoutDeliveryAddressAdapter, CheckoutDeliveryAddressConnector, CheckoutDeliveryAddressService, CheckoutDeliveryModesAdapter, CheckoutDeliveryModesConnector, CheckoutDeliveryModesService, CheckoutPageMetaResolver, CheckoutPaymentAdapter, CheckoutPaymentConnector, CheckoutPaymentService, CheckoutQueryService, DELIVERY_MODE_NORMALIZER, PAYMENT_CARD_TYPE_NORMALIZER, PAYMENT_DETAILS_SERIALIZER };
