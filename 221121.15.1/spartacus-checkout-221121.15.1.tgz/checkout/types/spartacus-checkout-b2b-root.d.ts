import { PaymentType, Cart } from '@spartacus/cart/base/root';
import { CostCenter, EventService, CmsConfig, RoutingConfig, QueryState } from '@spartacus/core';
import * as i0 from '@angular/core';
import { OnDestroy } from '@angular/core';
import { Subscription, Observable } from 'rxjs';
import { CheckoutConfig, CheckoutEvent } from '@spartacus/checkout/base/root';

declare module '@spartacus/checkout/base/root' {
    enum CheckoutStepType {
        PAYMENT_TYPE = "paymentType"
    }
    interface CheckoutState {
        costCenter?: CostCenter;
        purchaseOrderNumber?: string;
        paymentType?: PaymentType;
    }
}

declare class CheckoutCostCenterEventListener implements OnDestroy {
    protected eventService: EventService;
    protected subscriptions: Subscription;
    constructor(eventService: EventService);
    protected onCostCenterSet(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutCostCenterEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutCostCenterEventListener>;
}

declare class CheckoutPaymentTypeEventListener implements OnDestroy {
    protected eventService: EventService;
    protected subscriptions: Subscription;
    constructor(eventService: EventService);
    protected onPaymentTypeSet(): void;
    protected onGetPaymentTypesQueryReload(): void;
    protected onGetPaymentTypesQueryReset(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPaymentTypeEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutPaymentTypeEventListener>;
}

declare class CheckoutB2BEventModule {
    constructor(_checkoutCostCenterEventListener: CheckoutCostCenterEventListener, _checkoutPaymentTypeEventListener: CheckoutPaymentTypeEventListener);
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutB2BEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutB2BEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutB2BEventModule>;
}

declare const CHECKOUT_B2B_CMS_COMPONENTS: string[];
declare function defaultCheckoutComponentsConfig(): CmsConfig;
declare class CheckoutB2BRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutB2BRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutB2BRootModule, never, [typeof CheckoutB2BEventModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutB2BRootModule>;
}

declare const defaultB2BCheckoutConfig: CheckoutConfig;

declare const defaultCheckoutB2BRoutingConfig: RoutingConfig;

/**
 * An abstract event for all the cost center related events.
 */
declare abstract class CheckoutCostCenterEvent extends CheckoutEvent {
}
/**
 * Fired when the cost center has been set.
 */
declare class CheckoutCostCenterSetEvent extends CheckoutCostCenterEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutCostCenterSetEvent";
    /**
     * Cost center code
     */
    code: string;
}
/**
 * An abstract event for all the payment type related events.
 */
declare abstract class CheckoutPaymentTypeEvent extends CheckoutEvent {
}
/**
 * Emit this event to force payment types reload
 */
declare class CheckoutPaymentTypesQueryReloadEvent extends CheckoutPaymentTypeEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutPaymentTypesQueryReloadEvent";
}
/**
 * Emit this event to force payment types reset
 */
declare class CheckoutPaymentTypesQueryResetEvent extends CheckoutPaymentTypeEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutPaymentTypesQueryResetEvent";
}
/**
 * Fired when the payment type has been set
 */
declare class CheckoutPaymentTypeSetEvent extends CheckoutPaymentTypeEvent {
    /**
     * Event's type
     */
    static readonly type = "CheckoutPaymentTypeSetEvent";
    /**
     * Payment type code
     */
    paymentTypeCode: string;
    /**
     * Purchase order number
     */
    purchaseOrderNumber?: string;
}

declare abstract class CheckoutCostCenterFacade {
    /**
     * Set cost center to cart
     * @param costCenterId : cost center id
     */
    abstract setCostCenter(costCenterId: string): Observable<Cart>;
    /**
     * Get cost center id from cart
     */
    abstract getCostCenterState(): Observable<QueryState<CostCenter | undefined>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutCostCenterFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutCostCenterFacade>;
}

declare abstract class CheckoutPaymentTypeFacade {
    /**
     * Get payment types state.
     */
    abstract getPaymentTypesState(): Observable<QueryState<PaymentType[] | undefined>>;
    /**
     * Get payment types.
     */
    abstract getPaymentTypes(): Observable<PaymentType[]>;
    /**
     * Set payment type to cart
     */
    abstract setPaymentType(paymentTypeCode: string, purchaseOrderNumber?: string): Observable<unknown>;
    /**
     * Get the selected payment type
     */
    abstract getSelectedPaymentTypeState(): Observable<QueryState<PaymentType | undefined>>;
    /**
     * Get whether the selected payment type is "ACCOUNT" payment
     */
    abstract isAccountPayment(): Observable<boolean>;
    /**
     * Get purchase order number
     */
    abstract getPurchaseOrderNumberState(): Observable<QueryState<string | undefined>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPaymentTypeFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutPaymentTypeFacade>;
}

declare enum B2BPaymentTypeEnum {
    ACCOUNT_PAYMENT = "ACCOUNT",
    CARD_PAYMENT = "CARD"
}

export { B2BPaymentTypeEnum, CHECKOUT_B2B_CMS_COMPONENTS, CheckoutB2BEventModule, CheckoutB2BRootModule, CheckoutCostCenterEvent, CheckoutCostCenterEventListener, CheckoutCostCenterFacade, CheckoutCostCenterSetEvent, CheckoutPaymentTypeEvent, CheckoutPaymentTypeEventListener, CheckoutPaymentTypeFacade, CheckoutPaymentTypeSetEvent, CheckoutPaymentTypesQueryReloadEvent, CheckoutPaymentTypesQueryResetEvent, defaultB2BCheckoutConfig, defaultCheckoutB2BRoutingConfig, defaultCheckoutComponentsConfig };
