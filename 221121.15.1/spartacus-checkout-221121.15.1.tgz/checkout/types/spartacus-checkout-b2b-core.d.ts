import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import { Cart, PaymentType, ActiveCartFacade } from '@spartacus/cart/base/root';
import { Observable } from 'rxjs';
import { Converter, UserIdService, CommandService, EventService, Command, QueryState, CostCenter, QueryService, QueryNotifier, Query } from '@spartacus/core';
import { CheckoutCostCenterFacade, CheckoutPaymentTypeFacade, B2BPaymentTypeEnum } from '@spartacus/checkout/b2b/root';
import { CheckoutQueryFacade } from '@spartacus/checkout/base/root';

declare class CheckoutB2BCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutB2BCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutB2BCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutB2BCoreModule>;
}

declare abstract class CheckoutCostCenterAdapter {
    /**
     * Abstract method used to set cost center to cart
     *
     * @param userId: user id
     * @param cartId: cart id
     * @param costCenterId: cost center id
     */
    abstract setCostCenter(userId: string, cartId: string, costCenterId: string): Observable<Cart>;
}

declare class CheckoutCostCenterConnector {
    protected adapter: CheckoutCostCenterAdapter;
    constructor(adapter: CheckoutCostCenterAdapter);
    setCostCenter(userId: string, cartId: string, costCenterId: string): Observable<Cart>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutCostCenterConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutCostCenterConnector>;
}

declare abstract class CheckoutPaymentTypeAdapter {
    /**
     * Abstract method used to get available payment types
     */
    abstract getPaymentTypes(): Observable<PaymentType[]>;
    /**
     * Abstract method used to set payment type to cart
     *
     * @param userId
     * @param cartId
     * @param typeCode
     * @param purchaseOrderNumber: purchase order number
     */
    abstract setPaymentType(userId: string, cartId: string, typeCode: string, purchaseOrderNumber?: string): Observable<unknown>;
}

declare class CheckoutPaymentTypeConnector {
    protected adapter: CheckoutPaymentTypeAdapter;
    constructor(adapter: CheckoutPaymentTypeAdapter);
    getPaymentTypes(): Observable<PaymentType[]>;
    setPaymentType(userId: string, cartId: string, typeCode: string, purchaseOrderNumber?: string): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPaymentTypeConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutPaymentTypeConnector>;
}

declare const CHECKOUT_PAYMENT_TYPE_NORMALIZER: InjectionToken<Converter<any, PaymentType>>;

declare class CheckoutCostCenterService implements CheckoutCostCenterFacade {
    protected activeCartFacade: ActiveCartFacade;
    protected userIdService: UserIdService;
    protected commandService: CommandService;
    protected checkoutCostCenterConnector: CheckoutCostCenterConnector;
    protected checkoutQueryFacade: CheckoutQueryFacade;
    protected eventService: EventService;
    protected setCostCenterCommand: Command<string, Cart>;
    constructor(activeCartFacade: ActiveCartFacade, userIdService: UserIdService, commandService: CommandService, checkoutCostCenterConnector: CheckoutCostCenterConnector, checkoutQueryFacade: CheckoutQueryFacade, eventService: EventService);
    protected checkoutPreconditions(): Observable<[string, string]>;
    getCostCenterState(): Observable<QueryState<CostCenter | undefined>>;
    setCostCenter(costCenterId: string): Observable<Cart>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutCostCenterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutCostCenterService>;
}

declare class CheckoutPaymentTypeService implements CheckoutPaymentTypeFacade {
    protected activeCartFacade: ActiveCartFacade;
    protected userIdService: UserIdService;
    protected queryService: QueryService;
    protected commandService: CommandService;
    protected paymentTypeConnector: CheckoutPaymentTypeConnector;
    protected eventService: EventService;
    protected checkoutQueryFacade: CheckoutQueryFacade;
    protected getCheckoutPaymentTypesQueryReloadEvents(): QueryNotifier[];
    protected getCheckoutPaymentTypesQueryResetEvents(): QueryNotifier[];
    protected paymentTypesQuery: Query<PaymentType[]>;
    protected setPaymentTypeCommand: Command<{
        paymentTypeCode: string;
        purchaseOrderNumber?: string;
    }, unknown>;
    constructor(activeCartFacade: ActiveCartFacade, userIdService: UserIdService, queryService: QueryService, commandService: CommandService, paymentTypeConnector: CheckoutPaymentTypeConnector, eventService: EventService, checkoutQueryFacade: CheckoutQueryFacade);
    protected checkoutPreconditions(): Observable<[string, string]>;
    getPaymentTypesState(): Observable<QueryState<PaymentType[] | undefined>>;
    getPaymentTypes(): Observable<PaymentType[]>;
    setPaymentType(paymentTypeCode: B2BPaymentTypeEnum, purchaseOrderNumber?: string): Observable<unknown>;
    getSelectedPaymentTypeState(): Observable<QueryState<PaymentType | undefined>>;
    isAccountPayment(): Observable<boolean>;
    getPurchaseOrderNumberState(): Observable<QueryState<string | undefined>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutPaymentTypeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutPaymentTypeService>;
}

export { CHECKOUT_PAYMENT_TYPE_NORMALIZER, CheckoutB2BCoreModule, CheckoutCostCenterAdapter, CheckoutCostCenterConnector, CheckoutCostCenterService, CheckoutPaymentTypeAdapter, CheckoutPaymentTypeConnector, CheckoutPaymentTypeService };
