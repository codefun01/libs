import * as i0 from '@angular/core';
import { OnInit, OnDestroy, ViewContainerRef, ElementRef, OnChanges, AfterViewInit, EventEmitter, ChangeDetectorRef, TemplateRef } from '@angular/core';
import { ActiveCartFacade, OrderEntry, CartType } from '@spartacus/cart/base/root';
import * as i2 from '@spartacus/core';
import { CmsService, RoutingService, PointOfService, PointOfServiceStock, CmsPickupItemDetails, WindowRef } from '@spartacus/core';
import { PickupLocationsSearchFacade, PickupOptionFacade, PreferredStoreFacade, IntendedPickupLocationFacade, PickupOption, RequiredDeepPath, PointOfServiceNames, AugmentedPointOfService, DeliveryPointOfService, LocationSearchParams } from '@spartacus/pickup-in-store/root';
import * as i3$1 from '@spartacus/storefront';
import { LaunchDialogService, OutletContextData, Tab, TabConfig, TabComponent, ICON_TYPE, CurrentProductService, CmsComponentData, LayoutConfig, FocusConfig } from '@spartacus/storefront';
import { Observable, Subscription } from 'rxjs';
import * as i1 from '@angular/common';
import * as i3 from '@angular/forms';
import { FormGroup, FormControl } from '@angular/forms';
import { StoreLocationService } from '@spartacus/storefinder/core';
import { StoreFinderFacade } from '@spartacus/storefinder/root';
import { Consignment, OrderFacade } from '@spartacus/order/root';
import * as i3$2 from '@angular/router';

type OrderEntryRequiredFields = 'entryNumber' | 'quantity' | 'product.code' | 'product.availableForPickup';
/** An order entry with all the fields needed for using pickup in store */
type OrderEntryWithRequiredFields = RequiredDeepPath<OrderEntry, OrderEntryRequiredFields>;
/** Custom type guard to ensure we have an order entry with all the required fields */
declare function orderEntryWithRequiredFields(orderEntry: OrderEntry | undefined): orderEntry is OrderEntryWithRequiredFields;
/**
 * A container component of the pair of the pickup options radio buttons for cart entry.
 */
declare class CartPickupOptionsContainerComponent implements OnInit, OnDestroy {
    protected activeCartFacade: ActiveCartFacade;
    protected launchDialogService: LaunchDialogService;
    protected pickupLocationsSearchService: PickupLocationsSearchFacade;
    protected pickupOptionFacade: PickupOptionFacade;
    protected preferredStoreFacade: PreferredStoreFacade;
    protected vcr: ViewContainerRef;
    protected cmsService: CmsService;
    protected intendedPickupLocationService: IntendedPickupLocationFacade;
    protected outlet: OutletContextData<{
        item: OrderEntry;
        cartType: CartType;
    }>;
    pickupOption$: Observable<PickupOption | undefined>;
    disableControls$: Observable<boolean>;
    storeDetails$: Observable<{
        name: string | undefined;
        displayName: string | undefined;
    }>;
    availableForPickup$: Observable<boolean>;
    subscription: Subscription;
    cartId: string;
    cartType: CartType;
    entryNumber: number;
    productCode: string;
    quantity: number;
    userId: string;
    page?: string;
    readonly CartType: typeof CartType;
    constructor(activeCartFacade: ActiveCartFacade, launchDialogService: LaunchDialogService, pickupLocationsSearchService: PickupLocationsSearchFacade, pickupOptionFacade: PickupOptionFacade, preferredStoreFacade: PreferredStoreFacade, vcr: ViewContainerRef, cmsService: CmsService, intendedPickupLocationService: IntendedPickupLocationFacade, outlet: OutletContextData<{
        item: OrderEntry;
        cartType: CartType;
    }>);
    ngOnInit(): void;
    onPickupOptionChange(event: {
        option: PickupOption;
        triggerElement: ElementRef;
    }): void;
    ngOnDestroy(): void;
    openDialog(triggerElement: ElementRef): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CartPickupOptionsContainerComponent, [null, null, null, null, null, null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CartPickupOptionsContainerComponent, "cx-cart-pickup-options-container", never, {}, {}, never, never, true, never>;
}

/**
 * The presentational component of a pair of radio buttons for pickup options for a product.
 */
declare class PickupOptionsComponent implements OnChanges, AfterViewInit, OnDestroy {
    protected subscription: Subscription;
    /** The selected option, either `'pickup'` or `'delivery'`. */
    selectedOption: PickupOption;
    /** The location to display in the pickup option. */
    displayPickupLocation: string | undefined;
    disableControls: boolean;
    /** Emitted when the selected option is changed. */
    pickupOptionChange: EventEmitter<{
        option: PickupOption;
        triggerElement: ElementRef;
    }>;
    /** Emitted when a new store should be selected. */
    pickupLocationChange: EventEmitter<ElementRef<any>>;
    triggerElement: ElementRef;
    pickupId: string;
    deliveryId: string;
    pickupOptionsForm: FormGroup<{
        pickupOption: FormControl<PickupOption | null>;
    }>;
    tabs: Tab[];
    tabConfig: TabConfig;
    protected cdr: ChangeDetectorRef | null;
    deliveryTabPanel: TemplateRef<any>;
    pickupTabPanel: TemplateRef<any>;
    tabComponent: TabComponent | undefined;
    get validationError(): "pickupOptions.storeIsNotSelected" | null;
    ngOnChanges(): void;
    ngAfterViewInit(): void;
    /** Emit a new selected option. */
    onPickupOptionChange(option: PickupOption): void;
    /** Emit to indicate a new store should be selected. */
    onPickupLocationChange(): boolean;
    protected initializeTabs(): void;
    protected onSelectedOptionChange(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupOptionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PickupOptionsComponent, "cx-pickup-options", never, { "selectedOption": { "alias": "selectedOption"; "required": false; }; "displayPickupLocation": { "alias": "displayPickupLocation"; "required": false; }; "disableControls": { "alias": "disableControls"; "required": false; }; }, { "pickupOptionChange": "pickupOptionChange"; "pickupLocationChange": "pickupLocationChange"; }, never, never, true, never>;
}

declare class PickupOptionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupOptionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PickupOptionsModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.ReactiveFormsModule, typeof i2.FeaturesConfigModule, typeof i3$1.TabModule, typeof PickupOptionsComponent], [typeof PickupOptionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PickupOptionsModule>;
}

declare class CartPickupOptionsContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CartPickupOptionsContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CartPickupOptionsContainerModule, never, [typeof i1.CommonModule, typeof PickupOptionsModule, typeof CartPickupOptionsContainerComponent], [typeof CartPickupOptionsContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CartPickupOptionsContainerModule>;
}

interface PreferredStoreContent {
    header: string;
    actions: Array<{
        event: string;
        name: string;
    } | {
        link: string;
        name: string;
        ariaLabel?: string;
        target?: string;
    }>;
}
declare class MyPreferredStoreComponent implements OnInit {
    private preferredStoreFacade;
    protected pickupLocationsSearchService: PickupLocationsSearchFacade;
    protected routingService: RoutingService;
    protected storeFinderService: StoreFinderFacade;
    protected cmsService: CmsService;
    protected storeLocationService: StoreLocationService;
    preferredStore$: Observable<PointOfService>;
    content: PreferredStoreContent | null;
    defaultContent: PreferredStoreContent;
    openHoursOpen: boolean;
    readonly ICON_TYPE: typeof ICON_TYPE;
    pointOfService: PointOfService;
    isStoreFinder: boolean;
    protected cdr: ChangeDetectorRef | null;
    constructor(preferredStoreFacade: PreferredStoreFacade, pickupLocationsSearchService: PickupLocationsSearchFacade, routingService: RoutingService, storeFinderService: StoreFinderFacade, cmsService: CmsService);
    ngOnInit(): void;
    /**
     * Toggle whether the store's opening hours are visible.
     */
    toggleOpenHours(): boolean;
    changeStore(): void;
    getDirectionsToStore(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyPreferredStoreComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyPreferredStoreComponent, "cx-my-preferred-store", never, {}, {}, never, never, true, never>;
}

declare class SetPreferredStoreComponent implements OnInit, OnDestroy {
    protected preferredStoreFacade: PreferredStoreFacade;
    protected outlet: OutletContextData<PointOfServiceNames>;
    readonly ICON_TYPE: typeof ICON_TYPE;
    pointOfServiceName: PointOfServiceNames;
    storeSelected$: Observable<PointOfServiceNames | null>;
    subscription: Subscription;
    constructor(preferredStoreFacade: PreferredStoreFacade, outlet: OutletContextData<PointOfServiceNames>);
    ngOnInit(): void;
    ngOnDestroy(): void;
    setAsPreferred(): boolean;
    getSetStoreButtonLabel(storeName: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SetPreferredStoreComponent, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SetPreferredStoreComponent, "cx-set-preferred-store", never, { "pointOfServiceName": { "alias": "pointOfServiceName"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SetPreferredStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SetPreferredStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SetPreferredStoreModule, never, [typeof i1.CommonModule, typeof i3$1.IconModule, typeof i2.I18nModule, typeof i2.FeaturesConfigModule, typeof SetPreferredStoreComponent], [typeof SetPreferredStoreComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SetPreferredStoreModule>;
}

/**
 * A store in the store list including address, opening times, stock level, and
 * distance from the search location.
 */
declare class StoreComponent implements OnInit {
    /** The details of the store to be displayed */
    storeDetails: PointOfServiceStock;
    /** An event emitter triggered when this store is selected for pickup */
    storeSelected: EventEmitter<PointOfServiceStock>;
    isInStock: boolean;
    openHoursOpen: boolean;
    readonly ICON_TYPE: typeof ICON_TYPE;
    constructor();
    ngOnInit(): void;
    /**
     * Select the current store for pickup.
     */
    selectStore(): boolean;
    /**
     * Toggle whether the store's opening hours are visible.
     */
    toggleOpenHours(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreComponent, "cx-store", never, { "storeDetails": { "alias": "storeDetails"; "required": false; }; }, { "storeSelected": "storeSelected"; }, never, never, true, never>;
}

type OpeningTime = {
    weekDay?: string;
    openingHours?: string;
    closed?: boolean;
};
/**
 * A presentational component for a store's opening hours
 */
declare class StoreScheduleComponent implements OnChanges {
    /** The details of the store */
    storeDetails: PointOfService;
    openingTimes: OpeningTime[];
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreScheduleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreScheduleComponent, "cx-store-schedule", never, { "storeDetails": { "alias": "storeDetails"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * The address of a point of service.
 */
declare class StoreAddressComponent {
    /** The details of the store */
    storeDetails: PointOfService;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreAddressComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreAddressComponent, "cx-store-address", never, { "storeDetails": { "alias": "storeDetails"; "required": false; }; }, {}, never, never, true, never>;
}

declare class StoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StoreModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3$1.IconModule, typeof i3$1.SpinnerModule, typeof SetPreferredStoreModule, typeof StoreComponent, typeof StoreScheduleComponent, typeof StoreAddressComponent], [typeof StoreComponent, typeof StoreScheduleComponent, typeof StoreAddressComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StoreModule>;
}

declare class MyPreferredStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MyPreferredStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MyPreferredStoreModule, never, [typeof i3$1.CardModule, typeof StoreModule, typeof i1.CommonModule, typeof i2.I18nModule, typeof i3$1.IconModule, typeof i2.ConfigModule, typeof MyPreferredStoreComponent], [typeof MyPreferredStoreComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MyPreferredStoreModule>;
}

/**
 * A container component of the pair of the pickup options radio buttons for cart entry.
 */
declare class PdpPickupOptionsContainerComponent implements OnInit, OnDestroy {
    protected currentProductService: CurrentProductService;
    protected intendedPickupLocationService: IntendedPickupLocationFacade;
    protected launchDialogService: LaunchDialogService;
    protected pickupOptionFacade: PickupOptionFacade;
    protected preferredStoreFacade: PreferredStoreFacade;
    protected pickupLocationsSearchService: PickupLocationsSearchFacade;
    protected vcr: ViewContainerRef;
    intendedPickupChange: EventEmitter<AugmentedPointOfService | undefined>;
    subscription: Subscription;
    availableForPickup: boolean;
    displayPickupLocation$: Observable<string | undefined>;
    pickupOption$: Observable<PickupOption>;
    intendedPickupLocation$: Observable<AugmentedPointOfService | undefined>;
    private productCode;
    constructor(currentProductService: CurrentProductService, intendedPickupLocationService: IntendedPickupLocationFacade, launchDialogService: LaunchDialogService, pickupOptionFacade: PickupOptionFacade, preferredStoreFacade: PreferredStoreFacade, pickupLocationsSearchService: PickupLocationsSearchFacade, vcr: ViewContainerRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    setIntendedPickupLocation(productCode: string): void;
    openDialog(triggerElement: ElementRef): void;
    onPickupOptionChange(event: {
        option: PickupOption;
        triggerElement: ElementRef;
    }): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PdpPickupOptionsContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PdpPickupOptionsContainerComponent, "cx-cart-pickup-options-container", never, {}, { "intendedPickupChange": "intendedPickupChange"; }, never, never, true, never>;
}

declare class PdpPickupOptionsContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PdpPickupOptionsContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PdpPickupOptionsContainerModule, never, [typeof i1.CommonModule, typeof PickupOptionsModule, typeof PdpPickupOptionsContainerComponent], [typeof PdpPickupOptionsContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PdpPickupOptionsContainerModule>;
}

type IOutletContextData = {
    item: Consignment;
};
/**
 * A container component of the pickup address for order consignment.
 */
declare class PickupInStoreOrderConsignmentContainerComponent implements OnInit {
    protected outlet: OutletContextData<IOutletContextData>;
    constructor(outlet: OutletContextData<IOutletContextData>);
    pointOfService$: Observable<PointOfService> | undefined;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupInStoreOrderConsignmentContainerComponent, [{ optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PickupInStoreOrderConsignmentContainerComponent, "cx-pickup-in-store-order-consignment", never, { "pointOfService$": { "alias": "pointOfService$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OrderConsignmentContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderConsignmentContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderConsignmentContainerModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof PickupInStoreOrderConsignmentContainerComponent], [typeof PickupInStoreOrderConsignmentContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderConsignmentContainerModule>;
}

declare class PickupInfoContainerComponent implements OnInit {
    protected activeCartService: ActiveCartFacade;
    protected storeDetails: PickupLocationsSearchFacade;
    storesDetailsData: Partial<PointOfService>[];
    constructor(activeCartService: ActiveCartFacade, storeDetails: PickupLocationsSearchFacade);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupInfoContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PickupInfoContainerComponent, "cx-pickup-info-container", never, {}, {}, never, never, true, never>;
}

declare class PickupInfoComponent {
    storeDetails: PointOfService;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupInfoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PickupInfoComponent, "cx-pickup-info", never, { "storeDetails": { "alias": "storeDetails"; "required": false; }; }, {}, never, never, true, never>;
}

declare class PickupInfoModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupInfoModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PickupInfoModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof StoreModule, typeof PickupInfoComponent], [typeof PickupInfoComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PickupInfoModule>;
}

declare class PickupInfoContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupInfoContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PickupInfoContainerModule, never, [typeof i1.CommonModule, typeof PickupInfoModule, typeof PickupInfoContainerComponent], [typeof PickupInfoContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PickupInfoContainerModule>;
}

/**
 * A service to get the Delivery Points Of Service for items to be picked up in store for the active cart
 */
declare class DeliveryPointsService {
    protected activeCartFacade: ActiveCartFacade;
    protected pickupLocationsSearchFacade: PickupLocationsSearchFacade;
    protected orderFacade: OrderFacade;
    constructor(activeCartFacade: ActiveCartFacade, pickupLocationsSearchFacade: PickupLocationsSearchFacade, orderFacade: OrderFacade);
    getDeliveryPointsOfServiceFromCart(): Observable<Array<DeliveryPointOfService>>;
    getDeliveryPointsOfServiceFromOrder(): Observable<Array<DeliveryPointOfService>>;
    getDeliveryPointsOfService(entries: Array<OrderEntry>): Observable<Array<DeliveryPointOfService>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeliveryPointsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DeliveryPointsService>;
}

declare class PickUpItemsDetailsComponent implements OnInit {
    protected component: CmsComponentData<CmsPickupItemDetails>;
    protected deliveryPointsService: DeliveryPointsService;
    showEdit: boolean;
    itemsDetails: Observable<Array<DeliveryPointOfService>>;
    readonly ICON_TYPE: typeof ICON_TYPE;
    protected context: string;
    constructor(component: CmsComponentData<CmsPickupItemDetails>, deliveryPointsService: DeliveryPointsService);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickUpItemsDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PickUpItemsDetailsComponent, "cx-pick-up-in-store-items-details", never, { "showEdit": { "alias": "showEdit"; "required": false; }; "itemsDetails": { "alias": "itemsDetails"; "required": false; }; }, {}, never, never, true, never>;
}

declare class PickUpItemsDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PickUpItemsDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PickUpItemsDetailsModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3$2.RouterModule, typeof i2.UrlModule, typeof i3$1.IconModule, typeof StoreModule, typeof i3$1.CardModule, typeof i3$1.MediaModule, typeof i2.FeaturesConfigModule, typeof i2.ConfigModule, typeof PickUpItemsDetailsComponent], [typeof PickUpItemsDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PickUpItemsDetailsModule>;
}

declare const defaultPickupOptionsDialogLayoutConfig: LayoutConfig;

/**
 * The dialog box to select the pickup location for a product.
 */
declare class PickupOptionDialogComponent implements OnInit, OnDestroy {
    protected activeCartFacade: ActiveCartFacade;
    protected elementRef: ElementRef;
    protected intendedPickupLocationService: IntendedPickupLocationFacade;
    protected launchDialogService: LaunchDialogService;
    protected pickupLocationsSearchService: PickupLocationsSearchFacade;
    protected pickupOptionFacade: PickupOptionFacade;
    productCode: string;
    entryNumber: number;
    quantity: number;
    getHideOutOfStockState$: Observable<boolean>;
    loading: boolean;
    subscription: Subscription;
    isPDP: boolean;
    cartId: string;
    userId: string;
    readonly ICON_TYPE: typeof ICON_TYPE;
    /** The reason given closing the dialog window without selecting a location */
    readonly CLOSE_WITHOUT_SELECTION = "CLOSE_WITHOUT_SELECTION";
    /** The reason given closing the dialog window after selecting a location */
    readonly LOCATION_SELECTED = "LOCATION_SELECTED";
    get focusConfig(): FocusConfig;
    constructor(activeCartFacade: ActiveCartFacade, elementRef: ElementRef, intendedPickupLocationService: IntendedPickupLocationFacade, launchDialogService: LaunchDialogService, pickupLocationsSearchService: PickupLocationsSearchFacade, pickupOptionFacade: PickupOptionFacade);
    handleClick(event: UIEvent): void;
    ngOnInit(): void;
    /**
     * Find the pickup points of service nearest to a place based on given search parameters.
     * @param locationSearchParams The latitude and longitude or free text search query to be used
     */
    onFindStores(locationSearchParams: LocationSearchParams): void;
    /**
     * Toggle whether locations without store should be shown or hidden.
     */
    onHideOutOfStock(): void;
    /**
     * Close the dialog window. This has additional side effects based upon whether
     * we are making a selection on the PDP or in the cart/during checkout.
     *
     * On the PDP:
     *
     * If the dialog is closed without making a selection, then the radio buttons
     * are left on pickup if there already exists an intended pickup location or
     * to delivery if not.
     *
     * Not on the PDP:
     *
     * If the window is closed after making a selection, then the cart is updated
     * to the the new selection.
     *
     * @param reason The reason the dialog window was closed
     */
    close(reason: string): void;
    /**
     * Change if the loading spinner should be displayed or not.
     * @param showSpinner Whether the loading spinner should be displayed
     */
    showSpinner(showSpinner: boolean): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupOptionDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PickupOptionDialogComponent, "cx-pickup-option-dialog", never, {}, {}, never, never, true, never>;
}

/**
 * The list of stores with their stock level and distance from a searched location.
 * Used in the PickupOptionDialog component for selecting a pickup location.
 */
declare class StoreListComponent implements OnInit {
    protected intendedPickupLocationService: IntendedPickupLocationFacade;
    protected pickupLocationsSearchService: PickupLocationsSearchFacade;
    /** The product code for the stock levels at each location */
    productCode: string;
    /** Event emitter triggered when a store is selected for pickup */
    storeSelected: EventEmitter<null>;
    stores$: Observable<PointOfServiceStock[]>;
    hasSearchStarted$: Observable<boolean>;
    isSearchRunning$: Observable<boolean>;
    constructor(intendedPickupLocationService: IntendedPickupLocationFacade, pickupLocationsSearchService: PickupLocationsSearchFacade);
    ngOnInit(): void;
    /**
     * Select the store to pickup from. This also sets the user's preferred store
     * the selected point of service.
     *
     * @param store Store to pickup from
     */
    onSelectStore(store: PointOfServiceStock): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreListComponent, "cx-store-list", never, { "productCode": { "alias": "productCode"; "required": false; }; }, { "storeSelected": "storeSelected"; }, never, never, true, never>;
}

declare class StoreListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StoreListModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3$1.IconModule, typeof i3$1.SpinnerModule, typeof StoreModule, typeof i2.FeaturesConfigModule, typeof StoreListComponent], [typeof StoreListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StoreListModule>;
}

/**
 * A service to wrap the browser's current position API.
 */
declare class CurrentLocationService {
    protected windowRef: WindowRef;
    constructor(windowRef: WindowRef);
    /**
     * Obtains the user's current position for the browser and calls the provided callback with it.
     *
     * @param successCallback - A callback to be called with the current location.
     * @param errorCallback - A callback to be called with the error.
     * @param options - Options for the current position API.
     */
    getCurrentLocation(successCallback: PositionCallback, errorCallback?: PositionErrorCallback | null, options?: PositionOptions): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrentLocationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrentLocationService>;
}

/**
 * The search box and find my location button for finding points of
 * service to pickup from. Also with controls for toggling the display of
 * locations without stock.
 */
declare class StoreSearchComponent {
    protected currentLocationService: CurrentLocationService;
    /** Whether the hide out of stock checkbox appears checked */
    hideOutOfStock: boolean;
    /** Whether out of stock locations should be hidden in the search list */
    eventHideOutOfStock: EventEmitter<boolean>;
    /** The search parameters used to find pickup stores */
    findStores: EventEmitter<LocationSearchParams>;
    /** Whether the loading spinner should be displayed */
    showSpinner: EventEmitter<boolean>;
    constructor(currentLocationService: CurrentLocationService);
    /** Initiate a free text location search */
    onFindStores(location: string): boolean;
    /** Toggle whether locations without stock should be displayed */
    onHideOutOfStock(): void;
    /** Initiate a latitude and longitude search using the current browser location */
    useMyLocation(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreSearchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StoreSearchComponent, "cx-store-search", never, { "hideOutOfStock": { "alias": "hideOutOfStock"; "required": false; }; }, { "eventHideOutOfStock": "eventHideOutOfStock"; "findStores": "findStores"; "showSpinner": "showSpinner"; }, never, never, true, never>;
}

declare class StoreSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StoreSearchModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof StoreSearchComponent], [typeof StoreSearchComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StoreSearchModule>;
}

declare class PickupOptionDialogModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupOptionDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PickupOptionDialogModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3$1.IconModule, typeof i3$1.KeyboardFocusModule, typeof i3$1.SpinnerModule, typeof StoreListModule, typeof StoreSearchModule, typeof i2.FeaturesConfigModule, typeof PickupOptionDialogComponent], [typeof PickupOptionDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PickupOptionDialogModule>;
}

declare class PickupInStoreComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PickupInStoreComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PickupInStoreComponentsModule, never, [typeof i3.ReactiveFormsModule, typeof PickupInfoContainerModule, typeof MyPreferredStoreModule, typeof PickUpItemsDetailsModule, typeof PdpPickupOptionsContainerModule, typeof i3$1.OutletModule, typeof CartPickupOptionsContainerModule, typeof OrderConsignmentContainerModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PickupInStoreComponentsModule>;
}

export { CartPickupOptionsContainerComponent, CartPickupOptionsContainerModule, MyPreferredStoreComponent, MyPreferredStoreModule, OrderConsignmentContainerModule, PdpPickupOptionsContainerComponent, PdpPickupOptionsContainerModule, PickUpItemsDetailsComponent, PickUpItemsDetailsModule, PickupInStoreComponentsModule, PickupInStoreOrderConsignmentContainerComponent, PickupInfoComponent, PickupInfoContainerComponent, PickupInfoContainerModule, PickupInfoModule, PickupOptionDialogComponent, PickupOptionDialogModule, PickupOptionsComponent, PickupOptionsModule, StoreAddressComponent, StoreComponent, StoreListComponent, StoreListModule, StoreModule, StoreScheduleComponent, StoreSearchComponent, StoreSearchModule, defaultPickupOptionsDialogLayoutConfig, orderEntryWithRequiredFields };
export type { IOutletContextData };
