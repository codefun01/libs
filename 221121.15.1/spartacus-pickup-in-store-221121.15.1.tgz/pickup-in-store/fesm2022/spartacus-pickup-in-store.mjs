import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { PickupInStoreComponentsModule } from '@spartacus/pickup-in-store/components';
import { PickupInStoreCoreModule } from '@spartacus/pickup-in-store/core';
import { PickupInStoreOccModule } from '@spartacus/pickup-in-store/occ';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PickupInStoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PickupInStoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: PickupInStoreModule, imports: [PickupInStoreComponentsModule,
            PickupInStoreCoreModule,
            PickupInStoreOccModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PickupInStoreModule, imports: [PickupInStoreComponentsModule,
            PickupInStoreCoreModule,
            PickupInStoreOccModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PickupInStoreModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        PickupInStoreComponentsModule,
                        PickupInStoreCoreModule,
                        PickupInStoreOccModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Triple-slash reference directive to include global type augmentations.
 * This ensures that Angular's compiler loads the type declarations
 * during the build process, enabling proper type checking for @HostListener decorators
 * with platform event syntax (e.g., 'keydown.Escape', 'keydown.ArrowUp').
 * for more about triple-slash directives, see: https://www.typescriptlang.org/docs/handbook/triple-slash-directives.html
 */
/// <reference path="../../types.d.ts" />
/**
 * Public API surface of pickup-in-store
 */

/**
 * Generated bundle index. Do not edit.
 */

export { PickupInStoreModule };
//# sourceMappingURL=spartacus-pickup-in-store.mjs.map
