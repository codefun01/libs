import * as i0 from '@angular/core';
import { Injectable, inject, RendererFactory2, NgModule, APP_BOOTSTRAP_LISTENER, provideAppInitializer } from '@angular/core';
import * as i1 from '@spartacus/core';
import { Config, facadeFactory, SemanticPathService, AuthHttpHeaderService, StatePersistenceService, AuthService, RoutingService, GlobalMessageService, RoutingConfigService, GlobalMessageType, EXPIRED_REFRESH_TOKEN_HANDLERS, provideDefaultConfig, FeatureConfigService, DELEGATED_AUTH_HTTP_HEADER_SERVICE, DEFAULT_AUTH_HTTP_HEADER_SERVICE } from '@spartacus/core';
import { BEFORE_CMS_PAGE_GUARD } from '@spartacus/storefront';
import { Router } from '@angular/router';
import { BehaviorSubject, of, Subscription, map as map$1, take, switchMap as switchMap$1, catchError } from 'rxjs';
import { Location } from '@angular/common';
import { map, defaultIfEmpty, switchMap, tap } from 'rxjs/operators';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const PUNCHOUT_FEATURE = 'punchout';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultPunchoutCmsComponentsConfig = {
    featureModules: {
        [PUNCHOUT_FEATURE]: {
            cmsComponents: [
                'PunchoutSessionComponent',
                'PunchoutErrorComponent',
                'PunchoutButtonsComponent',
                'PunchoutRequisitionComponent',
                'PunchoutCloseSessionComponent',
                'PunchoutInspectCartComponent',
            ],
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultPunchoutRoutingConfig = {
    routing: {
        routes: {
            punchoutSession: {
                paths: ['punchout/cxml/session'],
                protected: false,
                authFlow: true,
            },
            punchoutRequisition: {
                paths: ['punchout/cxml/requisition'],
            },
            punchoutInspect: {
                paths: ['punchout/cxml/inspect'],
            },
            punchoutError: {
                paths: ['punchout/cxml/error'],
                protected: false,
                authFlow: true,
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var PunchOutLevel;
(function (PunchOutLevel) {
    PunchOutLevel["STORE"] = "STORE";
    PunchOutLevel["PRODUCT"] = "PRODUCT";
    PunchOutLevel["AISLE"] = "AISLE";
    PunchOutLevel["SHELF"] = "SHELF";
})(PunchOutLevel || (PunchOutLevel = {}));
var PunchOutOperation;
(function (PunchOutOperation) {
    PunchOutOperation["CREATE"] = "CREATE";
    PunchOutOperation["EDIT"] = "EDIT";
    PunchOutOperation["INSPECT"] = "INSPECT";
})(PunchOutOperation || (PunchOutOperation = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const allowedCxRoutesForAll = ['punchoutSession', 'punchoutRequisition'];
const allowedCxRoutesForEditCreate = [
    'category',
    'brand',
    'quickOrder',
    'product',
    'cart',
    'search',
    'punchoutError',
];
const defaultPunchoutNavigationGuardConfig = {
    punchoutNavigation: {
        [PunchOutOperation.INSPECT]: {
            allowedCxRoutes: [...allowedCxRoutesForAll, 'punchoutInspect'],
            redirectPage: { cxRoute: 'punchoutInspect' },
        },
        [PunchOutOperation.EDIT]: {
            allowedUrls: ['/'],
            allowedCxRoutes: [
                ...allowedCxRoutesForAll,
                ...allowedCxRoutesForEditCreate,
            ],
            redirectPage: { cxRoute: 'home' },
        },
        [PunchOutOperation.CREATE]: {
            allowedUrls: ['/'],
            allowedCxRoutes: [
                ...allowedCxRoutesForAll,
                ...allowedCxRoutesForEditCreate,
            ],
            redirectPage: { cxRoute: 'home' },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutNavigationGuardConfig {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutNavigationGuardConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutNavigationGuardConfig, providedIn: 'root', useExisting: Config }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutNavigationGuardConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useExisting: Config,
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
function punchoutFacadeFactory() {
    return facadeFactory({
        facade: PunchoutFacade,
        feature: PUNCHOUT_FEATURE,
        methods: [
            'initPunchoutSession',
            'getPunchoutSessionRequisition',
            'logoutPunchoutUser',
            'closePunchoutSession',
            'requestPunchoutSession',
            'endPunchoutSession',
            'submitRequisition',
        ],
    });
}
class PunchoutFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutFacade, providedIn: 'root', useFactory: punchoutFacadeFactory }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: punchoutFacadeFactory,
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutStoreService {
    constructor() {
        this.INITIAL_STATE = Object.freeze({
            punchoutSessionId: undefined,
            punchoutSession: undefined,
            cancelRequisition: undefined,
            punchoutInitialRequisition: undefined,
            closePunchoutSession: undefined,
        });
        this.punchoutState = new BehaviorSubject(this.INITIAL_STATE);
    }
    getPunchoutSessionId() {
        return this.punchoutState?.value?.punchoutSessionId;
    }
    getPunchoutState() {
        return this.punchoutState.asObservable();
    }
    setPunchoutState(payload) {
        this.punchoutState.next({
            ...payload,
        });
    }
    updatePunchoutState(payload) {
        this.punchoutState.next({
            ...this.punchoutState.value,
            ...payload,
        });
    }
    clearPunchoutState() {
        this.punchoutState.next(this.INITIAL_STATE);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutStoreService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutStoreService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutStoreService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutDetectionService {
    constructor() {
        this.location = inject(Location);
        this.punchoutStoreService = inject(PunchoutStoreService);
        this.semanticPathService = inject(SemanticPathService);
    }
    /**
     * Check if browser url is the punchout initial session page.
     * With default config, the expected url shape is '/punchout/cxml/session?abcd'.
     * @returns boolean
     */
    isPunchoutSessionPage() {
        const urlSections = this.location.path().split('?');
        return (urlSections.length > 1 &&
            urlSections[0].includes(this.semanticPathService.get('punchoutSession')));
    }
    isPunchoutSession() {
        return !!this.punchoutStoreService.getPunchoutSessionId();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutDetectionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutDetectionService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutDetectionService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutAuthHttpHeaderService extends AuthHttpHeaderService {
    constructor(authService, authStorageService, oAuthLibWrapperService, routingService, globalMessageService, occEndpointsService, authRedirectService) {
        super(authService, authStorageService, oAuthLibWrapperService, routingService, occEndpointsService, globalMessageService, authRedirectService);
        this.authService = authService;
        this.authStorageService = authStorageService;
        this.oAuthLibWrapperService = oAuthLibWrapperService;
        this.routingService = routingService;
        this.globalMessageService = globalMessageService;
        this.occEndpointsService = occEndpointsService;
        this.authRedirectService = authRedirectService;
        this.punchoutDetectionService = inject(PunchoutDetectionService);
        this.punchoutFacade = inject(PunchoutFacade);
    }
    /**
     * @override
     *
     * On backend errors indicating expired `refresh_token`, 2 punchout use cases:
     * - When initializing punchout session, previous token gets silently revoked, punchoutFacade can then create punchout session.
     * - When punchout session already exists, punchout session gets ended.
     * It is a workaround to address CXSPA-9608 - Public pages not displayed when token is invalid.
     * To be removed once CXSPA-9608 is closed.
     */
    handleExpiredRefreshToken() {
        if (this.punchoutDetectionService.isPunchoutSessionPage()) {
            this.punchoutFacade.logoutPunchoutUser().subscribe();
            return;
        }
        if (this.punchoutDetectionService.isPunchoutSession()) {
            this.punchoutFacade.endPunchoutSession().subscribe();
            return;
        }
        super.handleExpiredRefreshToken();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutAuthHttpHeaderService, deps: [{ token: i1.AuthService }, { token: i1.AuthStorageService }, { token: i1.OAuthLibWrapperService }, { token: i1.RoutingService }, { token: i1.GlobalMessageService }, { token: i1.OccEndpointsService }, { token: i1.AuthRedirectService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutAuthHttpHeaderService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutAuthHttpHeaderService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.AuthService }, { type: i1.AuthStorageService }, { type: i1.OAuthLibWrapperService }, { type: i1.RoutingService }, { type: i1.GlobalMessageService }, { type: i1.OccEndpointsService }, { type: i1.AuthRedirectService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutExpiredRefreshTokenHandler {
    constructor() {
        this.punchoutDetectionService = inject(PunchoutDetectionService);
        this.punchoutFacade = inject(PunchoutFacade);
    }
    /**
     * Returns whether punchout-specific refresh-token expiration handling was applied.
     * On backend errors indicating expired `refresh_token`, 2 punchout use cases:
     * - When initializing punchout session, previous token gets silently revoked, punchoutFacade can then create punchout session.
     * - When punchout session already exists, punchout session gets ended.
     * It is a workaround to address CXSPA-9608 - Public pages not displayed when token is invalid.
     * To be removed once CXSPA-9608 is closed.
     */
    handleExpiredRefreshTokenIfApplicable() {
        if (this.punchoutDetectionService.isPunchoutSessionPage()) {
            return this.punchoutFacade.logoutPunchoutUser().pipe(map(() => true), defaultIfEmpty(true));
        }
        if (this.punchoutDetectionService.isPunchoutSession()) {
            return this.punchoutFacade.endPunchoutSession().pipe(map(() => true), defaultIfEmpty(true));
        }
        return of(false);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutExpiredRefreshTokenHandler, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutExpiredRefreshTokenHandler, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutExpiredRefreshTokenHandler, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutStatePersistenceService {
    constructor() {
        this.statePersistenceService = inject(StatePersistenceService);
        this.punchoutStoreService = inject(PunchoutStoreService);
        this.punchoutFacade = inject(PunchoutFacade);
        this.punchoutDetectionService = inject(PunchoutDetectionService);
        this.subscription = new Subscription();
        this.hasPunchoutStarted = false;
        this.PUNCHOUT_STORAGE_KEY = 'punchout';
    }
    /**
     * Initializes the synchronization between state and browser storage.
     * Through getPunchoutSessionId(), storage is updated everytime PunchoutState is modified.
     */
    initSync() {
        this.subscription.add(this.statePersistenceService.syncWithStorage({
            key: this.PUNCHOUT_STORAGE_KEY,
            state$: this.getPunchoutSessionId(),
            onRead: (state) => this.onRead(state),
        }));
    }
    /**
     * Gets and transforms state into the form that should
     * be saved in storage.
     */
    getPunchoutSessionId() {
        return this.punchoutStoreService.getPunchoutState().pipe(map$1((punchoutState) => {
            if (punchoutState?.punchoutSessionId) {
                this.hasPunchoutStarted = true;
                return punchoutState?.punchoutSessionId;
            }
            // With 'undefined' value, no key/value gets modified or created, it keeps the storage cleaned when Punchout is unused.
            // Note that StatePersistenceService does not allow to delete key/value once it has been created.
            return this.hasPunchoutStarted ? '' : undefined;
        }));
    }
    /**
     * Function called on each browser storage read.
     * Used to update state from browser -> state.
     * storage stores minimum data: only punchoutSessionId.
     * Full PunchoutSession object is retrieved by calling punchoutFacade.initPunchoutSession
     */
    onRead(punchoutSessionId) {
        if (punchoutSessionId &&
            !this.punchoutDetectionService.isPunchoutSessionPage()) {
            this.punchoutStoreService.setPunchoutState({ punchoutSessionId });
            this.punchoutFacade
                .initPunchoutSession({
                punchoutSessionId,
                isPageRefresh: true,
            })
                .pipe(take(1))
                .subscribe();
        }
    }
    ngOnDestroy() {
        this.hasPunchoutStarted = false;
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutStatePersistenceService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutStatePersistenceService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutStatePersistenceService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutUiRestrictionService {
    constructor() {
        this.rendererFactory = inject(RendererFactory2); // private, because needed only to create a renderer
        this.punchoutStoreService = inject(PunchoutStoreService);
        this.authService = inject(AuthService);
        this.CSS_PUNCHOUT_SESSION_CLASS = 'cxPunchoutSessionActive';
        this.renderer = this.rendererFactory.createRenderer(null, null);
    }
    isPunchoutSessionActive() {
        return this.authService.isUserLoggedIn().pipe(switchMap((isLoggedIn) => {
            return isLoggedIn
                ? this.punchoutStoreService.getPunchoutState()
                : of({ punchoutSessionId: undefined });
        }), map((punchoutState) => {
            return !!punchoutState.punchoutSessionId;
        }), tap((punchoutActive) => this.updateClass(punchoutActive)));
    }
    updateClass(punchoutActive) {
        if (!this.rootElement) {
            return;
        }
        if (punchoutActive) {
            this.renderer.addClass(this.rootElement, this.CSS_PUNCHOUT_SESSION_CLASS);
        }
        else {
            this.renderer.removeClass(this.rootElement, this.CSS_PUNCHOUT_SESSION_CLASS);
        }
    }
    init(rootComponent) {
        this.rootElement = rootComponent.location.nativeElement;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutUiRestrictionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutUiRestrictionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutUiRestrictionService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutNavigationGuard {
    constructor() {
        this.router = inject(Router);
        this.punchoutStoreService = inject(PunchoutStoreService);
        this.authService = inject(AuthService);
        this.routingService = inject(RoutingService);
        this.globalMessageService = inject(GlobalMessageService);
        this.punchoutFacade = inject(PunchoutFacade);
        this.config = inject(PunchoutNavigationGuardConfig);
        this.routingConfigService = inject(RoutingConfigService);
    }
    canActivate(route, _state) {
        const relativeUrl = `${route.url.map((u) => u.path).join('/')}`;
        const cxRoute = route?.data?.cxRoute ??
            this.routingConfigService.getRouteName(relativeUrl);
        return this.getPunchoutOperation(cxRoute).pipe(map$1((punchoutOperation) => {
            if (punchoutOperation &&
                !this.isAllowedCxRoute(cxRoute, punchoutOperation) &&
                !this.isAllowedUrls(route, punchoutOperation, relativeUrl)) {
                this.handleWarning();
                this.routingService.go(this.config.punchoutNavigation?.[punchoutOperation]?.redirectPage);
                return false;
            }
            return true;
        }));
    }
    isAllowedUrls(route, punchoutOperation, relativeUrl) {
        let isHomePageAllowed = false;
        const urls = this.config.punchoutNavigation?.[punchoutOperation]?.allowedUrls;
        if (!urls) {
            return false;
        }
        if (urls.includes('/')) {
            isHomePageAllowed = route?.url?.length === 0;
        }
        return (urls
            .filter((url) => url !== '/')
            .some((url) => relativeUrl.includes(url)) || isHomePageAllowed);
    }
    isAllowedCxRoute(cxRoute, punchoutOperation) {
        const cxRoutes = this.config.punchoutNavigation?.[punchoutOperation]?.allowedCxRoutes;
        if (!cxRoutes) {
            return false;
        }
        return !!cxRoute && cxRoutes.includes(cxRoute);
    }
    getPunchoutOperation(cxRoute) {
        return this.authService.isUserLoggedIn().pipe(take(1), switchMap$1((isLoggedIn) => {
            if (isLoggedIn) {
                return this.punchoutStoreService.getPunchoutState();
            }
            return of(undefined);
        }), take(1), switchMap$1((punchoutState) => {
            if (punchoutState?.punchoutSessionId) {
                //handle race condition with logout guard, it needs to be assessed before punchout session is requested
                if (cxRoute === 'logout') {
                    this.handleWarning();
                }
                return punchoutState?.punchoutSession?.punchOutOperation
                    ? of(punchoutState.punchoutSession)
                    : this.punchoutFacade.requestPunchoutSession(punchoutState.punchoutSessionId);
            }
            return of(undefined);
        }), map$1((punchoutSession) => {
            if (punchoutSession?.punchOutOperation) {
                return punchoutSession?.punchOutOperation;
            }
            return undefined;
        }), catchError(() => of(undefined)));
    }
    handleWarning() {
        this.globalMessageService.add({
            key: 'punchout.noSufficientPermissions',
        }, GlobalMessageType.MSG_TYPE_WARNING);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutNavigationGuard, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutNavigationGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutNavigationGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutNavigationModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutNavigationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: PunchoutNavigationModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutNavigationModule, providers: [
            {
                provide: BEFORE_CMS_PAGE_GUARD,
                useClass: PunchoutNavigationGuard,
                multi: true,
            },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutNavigationModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        {
                            provide: BEFORE_CMS_PAGE_GUARD,
                            useClass: PunchoutNavigationGuard,
                            multi: true,
                        },
                    ],
                }]
        }] });

/**
 * Add required punchoutsid key/value to request header
 * It is applied to all occ requests containing punchout cart Id with shape: 'carts/{punchoutCartId}'
 */
class PunchoutCartInterceptor {
    constructor() {
        this.PUNCHOUT_SESSION_ID_HEADER_KEY = 'punchoutsid';
        this.punchoutStoreService = inject(PunchoutStoreService);
    }
    intercept(request, next) {
        return this.punchoutStoreService.getPunchoutState().pipe(take(1), switchMap$1((punchoutState) => {
            if (punchoutState?.punchoutSessionId &&
                punchoutState?.punchoutSession?.cartId &&
                request.url.includes(`/carts/${punchoutState.punchoutSession.cartId}`)) {
                request = request.clone({
                    headers: request.headers.append(this.PUNCHOUT_SESSION_ID_HEADER_KEY, punchoutState.punchoutSessionId),
                });
            }
            return next.handle(request);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutCartInterceptor, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutCartInterceptor, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutCartInterceptor, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const interceptors = [
    {
        provide: HTTP_INTERCEPTORS,
        useExisting: PunchoutCartInterceptor,
        multi: true,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: PunchoutRootModule, imports: [PunchoutNavigationModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutRootModule, providers: [
            provideDefaultConfig(defaultPunchoutCmsComponentsConfig),
            provideDefaultConfig(defaultPunchoutRoutingConfig),
            provideDefaultConfig(defaultPunchoutNavigationGuardConfig),
            provideAppInitializer(() => {
                const punchoutPersistenceService = inject(PunchoutStatePersistenceService);
                punchoutPersistenceService.initSync();
            }),
            ...interceptors,
            // below provider should be removed after enableExpiredRefreshTokenHandlers is fully rolled out
            {
                provide: AuthHttpHeaderService,
                useFactory: () => {
                    const featureConfig = inject(FeatureConfigService);
                    const delegatedAuthHttpHeaderService = inject(DELEGATED_AUTH_HTTP_HEADER_SERVICE, {
                        optional: true,
                    });
                    // delegatedService is expected to be used by ASM to address breaking changes of CXSPA-12514
                    return featureConfig.isEnabled('enableExpiredRefreshTokenHandlers')
                        ? (delegatedAuthHttpHeaderService ??
                            inject(DEFAULT_AUTH_HTTP_HEADER_SERVICE))
                        : inject(PunchoutAuthHttpHeaderService);
                },
            },
            {
                provide: EXPIRED_REFRESH_TOKEN_HANDLERS,
                useExisting: PunchoutExpiredRefreshTokenHandler,
                multi: true,
            },
            PunchoutUiRestrictionService,
            {
                provide: APP_BOOTSTRAP_LISTENER,
                multi: true,
                useFactory: () => {
                    const punchoutComponentsService = inject(PunchoutUiRestrictionService);
                    return (compRef) => punchoutComponentsService.init(compRef);
                },
            },
        ], imports: [PunchoutNavigationModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutRootModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [PunchoutNavigationModule],
                    providers: [
                        provideDefaultConfig(defaultPunchoutCmsComponentsConfig),
                        provideDefaultConfig(defaultPunchoutRoutingConfig),
                        provideDefaultConfig(defaultPunchoutNavigationGuardConfig),
                        provideAppInitializer(() => {
                            const punchoutPersistenceService = inject(PunchoutStatePersistenceService);
                            punchoutPersistenceService.initSync();
                        }),
                        ...interceptors,
                        // below provider should be removed after enableExpiredRefreshTokenHandlers is fully rolled out
                        {
                            provide: AuthHttpHeaderService,
                            useFactory: () => {
                                const featureConfig = inject(FeatureConfigService);
                                const delegatedAuthHttpHeaderService = inject(DELEGATED_AUTH_HTTP_HEADER_SERVICE, {
                                    optional: true,
                                });
                                // delegatedService is expected to be used by ASM to address breaking changes of CXSPA-12514
                                return featureConfig.isEnabled('enableExpiredRefreshTokenHandlers')
                                    ? (delegatedAuthHttpHeaderService ??
                                        inject(DEFAULT_AUTH_HTTP_HEADER_SERVICE))
                                    : inject(PunchoutAuthHttpHeaderService);
                            },
                        },
                        {
                            provide: EXPIRED_REFRESH_TOKEN_HANDLERS,
                            useExisting: PunchoutExpiredRefreshTokenHandler,
                            multi: true,
                        },
                        PunchoutUiRestrictionService,
                        {
                            provide: APP_BOOTSTRAP_LISTENER,
                            multi: true,
                            useFactory: () => {
                                const punchoutComponentsService = inject(PunchoutUiRestrictionService);
                                return (compRef) => punchoutComponentsService.init(compRef);
                            },
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { PUNCHOUT_FEATURE, PunchOutLevel, PunchOutOperation, PunchoutAuthHttpHeaderService, PunchoutDetectionService, PunchoutExpiredRefreshTokenHandler, PunchoutFacade, PunchoutNavigationGuard, PunchoutNavigationGuardConfig, PunchoutRootModule, PunchoutStatePersistenceService, PunchoutStoreService, PunchoutUiRestrictionService, defaultPunchoutCmsComponentsConfig, defaultPunchoutNavigationGuardConfig, defaultPunchoutRoutingConfig, punchoutFacadeFactory };
//# sourceMappingURL=spartacus-punchout-root.mjs.map
