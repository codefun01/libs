import { HttpClient, HttpParams } from '@angular/common/http';
import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { OccEndpointsService, LoggerService, ConverterService, tryNormalizeHttpError, provideDefaultConfig } from '@spartacus/core';
import { PUNCHOUT_SESSION_NORMALIZER, PUNCHOUT_REQUISITION_NORMALIZER, PunchoutAdapter } from '@spartacus/punchout/core';
import { catchError } from 'rxjs';
import { CommonModule } from '@angular/common';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccPunchoutAdapter {
    constructor() {
        this.http = inject(HttpClient);
        this.occEndpoints = inject(OccEndpointsService);
        this.logger = inject(LoggerService);
        this.converter = inject(ConverterService);
    }
    getPunchoutSession(sessionId) {
        return this.http
            .get(this.occEndpoints.buildUrl('punchoutSession', {
            urlParams: { sessionId },
        }))
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), this.converter.pipeable(PUNCHOUT_SESSION_NORMALIZER));
    }
    getPunchoutSessionRequisition(sessionId, discardCartEntries) {
        const params = discardCartEntries
            ? new HttpParams().set('discardCartEntries', 'true')
            : undefined;
        return this.http
            .get(this.occEndpoints.buildUrl('punchoutSessionRequisition', {
            urlParams: { sessionId },
        }), { params })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), this.converter.pipeable(PUNCHOUT_REQUISITION_NORMALIZER));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccPunchoutAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccPunchoutAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccPunchoutAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const punchoutOccEndpoints = {
    punchoutSession: 'punchout/sessions/${sessionId}',
    punchoutSessionRequisition: 'punchout/sessions/${sessionId}/requisition',
};
const defaultOccPunchoutConfig = {
    backend: {
        occ: {
            endpoints: {
                ...punchoutOccEndpoints,
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutOccModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutOccModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: PunchoutOccModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutOccModule, providers: [
            provideDefaultConfig(defaultOccPunchoutConfig),
            {
                provide: PunchoutAdapter,
                useClass: OccPunchoutAdapter,
            },
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PunchoutOccModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [
                        provideDefaultConfig(defaultOccPunchoutConfig),
                        {
                            provide: PunchoutAdapter,
                            useClass: OccPunchoutAdapter,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OccPunchoutAdapter, PunchoutOccModule };
//# sourceMappingURL=spartacus-punchout-occ.mjs.map
