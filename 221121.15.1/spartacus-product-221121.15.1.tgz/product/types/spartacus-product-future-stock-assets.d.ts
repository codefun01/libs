import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    futureStock: {
        futureStockDropdown: {
            header: string;
            quantity: string;
            noFutureStocks: string;
        };
    };
};

declare const de: {
    futureStock: {
        futureStockDropdown: {
            header: string;
            quantity: string;
            noFutureStocks: string;
        };
    };
};

declare const en: {
    futureStock: {
        futureStockDropdown: {
            header: string;
            quantity: string;
            noFutureStocks: string;
        };
    };
};

declare const es: {
    futureStock: {
        futureStockDropdown: {
            header: string;
            quantity: string;
            noFutureStocks: string;
        };
    };
};

declare const es_CO: {
    futureStock: {
        futureStockDropdown: {
            header: string;
            quantity: string;
            noFutureStocks: string;
        };
    };
};

declare const fr: {
    futureStock: {
        futureStockDropdown: {
            header: string;
            quantity: string;
            noFutureStocks: string;
        };
    };
};

declare const hi: {
    futureStock: {
        futureStockDropdown: {
            header: string;
            quantity: string;
            noFutureStocks: string;
        };
    };
};

declare const hu: {
    futureStock: {
        futureStockDropdown: {
            header: string;
            quantity: string;
            noFutureStocks: string;
        };
    };
};

declare const id: {
    futureStock: {
        futureStockDropdown: {
            header: string;
            quantity: string;
            noFutureStocks: string;
        };
    };
};

declare const it: {
    futureStock: {
        futureStockDropdown: {
            header: string;
            quantity: string;
            noFutureStocks: string;
        };
    };
};

declare const ja: {
    futureStock: {
        futureStockDropdown: {
            header: string;
            quantity: string;
            noFutureStocks: string;
        };
    };
};

declare const ko: {
    futureStock: {
        futureStockDropdown: {
            header: string;
            quantity: string;
            noFutureStocks: string;
        };
    };
};

declare const pl: {
    futureStock: {
        futureStockDropdown: {
            header: string;
            quantity: string;
            noFutureStocks: string;
        };
    };
};

declare const pt: {
    futureStock: {
        futureStockDropdown: {
            header: string;
            quantity: string;
            noFutureStocks: string;
        };
    };
};

declare const ru: {
    futureStock: {
        futureStockDropdown: {
            header: string;
            quantity: string;
            noFutureStocks: string;
        };
    };
};

declare const zh: {
    futureStock: {
        futureStockDropdown: {
            header: string;
            quantity: string;
            noFutureStocks: string;
        };
    };
};

declare const zh_TW: {
    futureStock: {
        futureStockDropdown: {
            header: string;
            quantity: string;
            noFutureStocks: string;
        };
    };
};

declare const futureStockTranslationChunksConfig: TranslationChunksConfig;

export { futureStockTranslationChunksConfig, cs as futureStockTranslationsCs, de as futureStockTranslationsDe, en as futureStockTranslationsEn, es as futureStockTranslationsEs, es_CO as futureStockTranslationsEs_CO, fr as futureStockTranslationsFr, hi as futureStockTranslationsHi, hu as futureStockTranslationsHu, id as futureStockTranslationsId, it as futureStockTranslationsIt, ja as futureStockTranslationsJa, ko as futureStockTranslationsKo, pl as futureStockTranslationsPl, pt as futureStockTranslationsPt, ru as futureStockTranslationsRu, zh as futureStockTranslationsZh, zh_TW as futureStockTranslationsZh_TW };
