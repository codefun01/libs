import * as i0 from '@angular/core';
import { OnInit } from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/core';
import { RoutingService } from '@spartacus/core';
import * as i3 from '@spartacus/storefront';
import { BulkPricingService, BulkPrice } from '@spartacus/product/bulk-pricing/core';
import { Observable } from 'rxjs';

declare class BulkPricingOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BulkPricingOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BulkPricingOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BulkPricingOccModule>;
}

declare class BulkPricingTableComponent implements OnInit {
    protected routingService: RoutingService;
    protected bulkPricingService: BulkPricingService;
    protected readonly PRODUCT_KEY = "productCode";
    priceTiers$: Observable<BulkPrice[] | undefined>;
    constructor(routingService: RoutingService, bulkPricingService: BulkPricingService);
    ngOnInit(): void;
    formatQuantity(tier: BulkPrice): string;
    getPrices(): Observable<BulkPrice[] | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BulkPricingTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BulkPricingTableComponent, "cx-bulk-pricing-table", never, {}, {}, never, never, true, never>;
}

declare class BulkPricingTableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BulkPricingTableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BulkPricingTableModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.SpinnerModule, typeof i2.ConfigModule, typeof BulkPricingTableComponent], [typeof BulkPricingTableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BulkPricingTableModule>;
}

declare class BulkPricingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BulkPricingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BulkPricingModule, never, [typeof BulkPricingOccModule, typeof BulkPricingTableModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BulkPricingModule>;
}

export { BulkPricingModule };
