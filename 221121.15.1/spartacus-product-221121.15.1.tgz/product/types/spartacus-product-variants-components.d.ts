import * as i0 from '@angular/core';
import { OnInit } from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@angular/router';
import { Router, ActivatedRouteSnapshot, GuardResult } from '@angular/router';
import * as i3 from '@spartacus/core';
import { OccConfig, ProductService, RoutingService, VariantQualifier, BaseOption, VariantOptionQualifier, TranslationService, Product, VariantType, SemanticPathService } from '@spartacus/core';
import { Observable } from 'rxjs';
import { CurrentProductService } from '@spartacus/storefront';

declare class ProductVariantStyleSelectorComponent {
    private config;
    private productService;
    private routingService;
    constructor(config: OccConfig, productService: ProductService, routingService: RoutingService);
    variantQualifier: typeof VariantQualifier;
    variants: BaseOption;
    getVariantOptionValue(qualifiers: VariantOptionQualifier[]): string | undefined;
    getVariantThumbnailUrl(variantOptionQualifiers: VariantOptionQualifier[]): string;
    changeStyle(code: string): null;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductVariantStyleSelectorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductVariantStyleSelectorComponent, "cx-product-variant-style-selector", never, { "variants": { "alias": "variants"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ProductVariantStyleSelectorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductVariantStyleSelectorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductVariantStyleSelectorModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof ProductVariantStyleSelectorComponent], [typeof ProductVariantStyleSelectorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductVariantStyleSelectorModule>;
}

declare class ProductVariantSizeSelectorComponent {
    private productService;
    private routingService;
    protected translationService: TranslationService;
    constructor(productService: ProductService, routingService: RoutingService);
    product: Product;
    variants: BaseOption;
    changeSize(code: string): null;
    getVariantOptionValue(qualifiers: VariantOptionQualifier[]): string | undefined;
    ariaLabel$(qualifiers: VariantOptionQualifier[], index: number, quantity: number): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductVariantSizeSelectorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductVariantSizeSelectorComponent, "cx-product-variant-size-selector", never, { "product": { "alias": "product"; "required": false; }; "variants": { "alias": "variants"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ProductVariantSizeSelectorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductVariantSizeSelectorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductVariantSizeSelectorModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof ProductVariantSizeSelectorComponent], [typeof ProductVariantSizeSelectorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductVariantSizeSelectorModule>;
}

declare class ProductVariantColorSelectorComponent {
    private routingService;
    constructor(routingService: RoutingService);
    product: Product;
    variants: BaseOption;
    changeColor(code: string, name: string): null;
    getVariantOptionValue(qualifiers: VariantOptionQualifier[]): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductVariantColorSelectorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductVariantColorSelectorComponent, "cx-product-variant-color-selector", never, { "product": { "alias": "product"; "required": false; }; "variants": { "alias": "variants"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ProductVariantColorSelectorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductVariantColorSelectorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductVariantColorSelectorModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof ProductVariantColorSelectorComponent], [typeof ProductVariantColorSelectorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductVariantColorSelectorModule>;
}

declare class ProductVariantsContainerComponent implements OnInit {
    private currentProductService;
    constructor(currentProductService: CurrentProductService);
    variants: {
        [key: string]: BaseOption;
    };
    variantType: typeof VariantType;
    product$: Observable<Product | null>;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductVariantsContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductVariantsContainerComponent, "cx-product-variants-container", never, {}, {}, never, never, true, never>;
}

declare class ProductVariantsContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductVariantsContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductVariantsContainerModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof ProductVariantStyleSelectorModule, typeof ProductVariantSizeSelectorModule, typeof ProductVariantColorSelectorModule, typeof ProductVariantsContainerComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductVariantsContainerModule>;
}

declare class ProductVariantsComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductVariantsComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductVariantsComponentsModule, never, [typeof ProductVariantsContainerModule, typeof ProductVariantColorSelectorModule, typeof ProductVariantSizeSelectorModule, typeof ProductVariantStyleSelectorModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductVariantsComponentsModule>;
}

/**
 * Guard that will redirect to purchasable variant of product, if the navigation
 * is for the non-purchasable one
 */
declare class ProductVariantsGuard {
    protected productService: ProductService;
    protected semanticPathService: SemanticPathService;
    protected router: Router;
    constructor(productService: ProductService, semanticPathService: SemanticPathService, router: Router);
    canActivate(activatedRoute: ActivatedRouteSnapshot): Observable<GuardResult>;
    /**
     * Finds a purchasable product code looking at variant options, if any
     *
     * @param product
     */
    protected findPurchasableProductCode(product: Product): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductVariantsGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductVariantsGuard>;
}

export { ProductVariantColorSelectorComponent, ProductVariantColorSelectorModule, ProductVariantSizeSelectorComponent, ProductVariantSizeSelectorModule, ProductVariantStyleSelectorComponent, ProductVariantStyleSelectorModule, ProductVariantsComponentsModule, ProductVariantsContainerComponent, ProductVariantsContainerModule, ProductVariantsGuard };
