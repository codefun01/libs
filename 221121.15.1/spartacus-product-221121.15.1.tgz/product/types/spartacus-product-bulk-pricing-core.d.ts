import { ProductService, ProductScope, Product, Price } from '@spartacus/core';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';

interface BulkPrice {
    currencyIso?: string;
    formattedValue?: string;
    maxQuantity?: number;
    minQuantity?: number;
    priceType?: string;
    value?: number;
    formattedDiscount?: string;
    discount?: number;
}

declare module '@spartacus/core' {
    enum ProductScope {
        BULK_PRICES = "bulkPrices"
    }
}

declare class BulkPricingService {
    protected productService: ProductService;
    protected readonly PRODUCT_SCOPE = ProductScope.BULK_PRICES;
    constructor(productService: ProductService);
    getBulkPrices(productCode: string): Observable<BulkPrice[] | undefined>;
    protected convert(productPriceScope: Product | undefined): BulkPrice[] | undefined;
    protected parsePrice(priceTier: Price, basePrice: number | undefined): BulkPrice;
    protected calculateDiscount(bulkPriceTemplate: BulkPrice, basePrice: number | undefined): BulkPrice;
    static ɵfac: i0.ɵɵFactoryDeclaration<BulkPricingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BulkPricingService>;
}

export { BulkPricingService };
export type { BulkPrice };
