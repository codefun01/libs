import * as i0 from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/core';
import * as i3 from '@spartacus/storefront';
import { ICON_TYPE } from '@spartacus/storefront';
import * as rxjs from 'rxjs';
import { FutureStockFacade } from '@spartacus/product/future-stock/root';

declare class FutureStockAccordionComponent {
    protected futureStockService: FutureStockFacade;
    futureStocks$: rxjs.Observable<any>;
    expanded: boolean;
    iconType: typeof ICON_TYPE;
    constructor(futureStockService: FutureStockFacade);
    toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FutureStockAccordionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FutureStockAccordionComponent, "cx-future-stock-accordion", never, {}, {}, never, never, true, never>;
}

declare class FutureStockAccordionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FutureStockAccordionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FutureStockAccordionModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof FutureStockAccordionComponent], [typeof FutureStockAccordionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FutureStockAccordionModule>;
}

declare class FutureStockComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FutureStockComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FutureStockComponentsModule, never, [typeof i1.CommonModule, typeof FutureStockAccordionModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FutureStockComponentsModule>;
}

export { FutureStockAccordionComponent, FutureStockComponentsModule };
