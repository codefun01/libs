import * as i3 from '@spartacus/core';
import { OccConfig, Product, VariantOption, VariantOptionQualifier, CmsConfig } from '@spartacus/core';
import * as i0 from '@angular/core';
import { OnInit, OnDestroy } from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@angular/router';
import { ProductListItemContext, ProductListOutlets } from '@spartacus/storefront';
import { Subscription, Observable } from 'rxjs';

declare const PRODUCT_VARIANTS_FEATURE = "productVariants";

declare class ProductVariantStyleIconsComponent implements OnInit, OnDestroy {
    private config;
    protected productListItemContext?: ProductListItemContext | undefined;
    constructor(config: OccConfig, productListItemContext?: ProductListItemContext | undefined);
    protected subscriptions: Subscription;
    readonly ProductListOutlets: typeof ProductListOutlets;
    readonly product$: Observable<Product>;
    variants: VariantOption[];
    variantNames: {
        [key: string]: string;
    };
    ngOnInit(): void;
    private setVariantsNames;
    getVariantThumbnailUrl(variantOptionQualifiers: VariantOptionQualifier[]): string;
    private getVariantName;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductVariantStyleIconsComponent, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductVariantStyleIconsComponent, "cx-variant-style-icons", never, { "variants": { "alias": "variants"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ProductVariantStyleIconsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductVariantStyleIconsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductVariantStyleIconsModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i3.UrlModule, typeof i3.I18nModule, typeof ProductVariantStyleIconsComponent], [typeof ProductVariantStyleIconsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductVariantStyleIconsModule>;
}

declare function defaultProductVariantsComponentsConfig(): CmsConfig;
declare class ProductVariantsRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductVariantsRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductVariantsRootModule, never, [typeof ProductVariantStyleIconsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductVariantsRootModule>;
}

export { PRODUCT_VARIANTS_FEATURE, ProductVariantStyleIconsComponent, ProductVariantStyleIconsModule, ProductVariantsRootModule, defaultProductVariantsComponentsConfig };
