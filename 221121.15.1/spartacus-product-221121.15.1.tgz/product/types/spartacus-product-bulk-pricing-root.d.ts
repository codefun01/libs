import { CmsConfig } from '@spartacus/core';
import * as i0 from '@angular/core';

declare function defaultProductBulkPricingComponentsConfig(): CmsConfig;
declare class BulkPricingRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BulkPricingRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BulkPricingRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BulkPricingRootModule>;
}

declare const PRODUCT_BULK_PRICING_FEATURE = "productBulkPricing";

export { BulkPricingRootModule, PRODUCT_BULK_PRICING_FEATURE, defaultProductBulkPricingComponentsConfig };
