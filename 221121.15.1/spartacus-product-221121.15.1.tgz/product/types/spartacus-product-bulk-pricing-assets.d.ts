import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};

declare const de: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};

declare const en: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};

declare const es: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};

declare const es_CO: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};

declare const fr: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};

declare const hi: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};

declare const hu: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};

declare const id: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};

declare const it: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};

declare const ja: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};

declare const ko: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};

declare const pl: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};

declare const pt: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};

declare const ru: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};

declare const zh: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};

declare const zh_TW: {
    bulkPricing: {
        bulkPricingTable: {
            quantity: string;
            price: string;
            discount: string;
        };
    };
};

declare const bulkPricingTranslationChunksConfig: TranslationChunksConfig;

export { bulkPricingTranslationChunksConfig, cs as bulkPricingTranslationsCs, de as bulkPricingTranslationsDe, en as bulkPricingTranslationsEn, es as bulkPricingTranslationsEs, es_CO as bulkPricingTranslationsEs_CO, fr as bulkPricingTranslationsFr, hi as bulkPricingTranslationsHi, hu as bulkPricingTranslationsHu, id as bulkPricingTranslationsId, it as bulkPricingTranslationsIt, ja as bulkPricingTranslationsJa, ko as bulkPricingTranslationsKo, pl as bulkPricingTranslationsPl, pt as bulkPricingTranslationsPt, ru as bulkPricingTranslationsRu, zh as bulkPricingTranslationsZh, zh_TW as bulkPricingTranslationsZh_TW };
