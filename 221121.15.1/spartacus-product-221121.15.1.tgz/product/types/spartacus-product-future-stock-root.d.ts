import { Observable } from 'rxjs';
import * as i0 from '@angular/core';

declare function futureStockFacadeFactory(): FutureStockFacade;
declare abstract class FutureStockFacade {
    /**
     * Get future stock
     */
    abstract getFutureStock(): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FutureStockFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FutureStockFacade>;
}

declare const PRODUCT_FUTURE_STOCK_FEATURE = "productFutureStock";
declare const PRODUCT_FUTURE_STOCK_CORE_FEATURE = "productFutureStockCore";

declare function defaultFutureStockComponentsConfig(): {
    featureModules: {
        productFutureStock: {
            cmsComponents: string[];
        };
    };
};
declare class FutureStockRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FutureStockRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FutureStockRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FutureStockRootModule>;
}

export { FutureStockFacade, FutureStockRootModule, PRODUCT_FUTURE_STOCK_CORE_FEATURE, PRODUCT_FUTURE_STOCK_FEATURE, defaultFutureStockComponentsConfig, futureStockFacadeFactory };
