import { Observable } from 'rxjs';
import { FutureStock, Converter, UserIdService, RoutingService } from '@spartacus/core';
import * as i0 from '@angular/core';
import { InjectionToken, ModuleWithProviders } from '@angular/core';
import { FutureStockFacade } from '@spartacus/product/future-stock/root';

interface ProductFutureStock {
    futureStocks: FutureStock[];
    productCode: string;
}
interface ProductFutureStockList {
    productFutureStocks: FutureStock[];
}

declare abstract class FutureStockAdapter {
    /**
     * Abstract method used to get the future product availability for the specified product
     */
    abstract getFutureStock(userId: string, productCode: string): Observable<ProductFutureStock>;
    /**
     * Abstract method  used to get the future product availability for the list of specified products
     * example list of products: '3318057,72399000,3228058'
     */
    abstract getFutureStocks(userId: string, productCodes: string): Observable<ProductFutureStockList>;
}

declare class FutureStockConnector {
    protected adapter: FutureStockAdapter;
    constructor(adapter: FutureStockAdapter);
    getFutureStock(userId: string, productCode: string): Observable<ProductFutureStock>;
    getFutureStocks(userId: string, productCodes: string): Observable<ProductFutureStockList>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FutureStockConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FutureStockConnector>;
}

declare const FUTURE_STOCK_NORMALIZER: InjectionToken<Converter<any, ProductFutureStock>>;
declare const FUTURE_STOCK_LIST_NORMALIZER: InjectionToken<Converter<any, ProductFutureStockList>>;

declare class FutureStockService implements FutureStockFacade {
    protected userIdService: UserIdService;
    protected futureStockConnector: FutureStockConnector;
    protected routingService: RoutingService;
    protected readonly PRODUCT_KEY = "productCode";
    protected futureStockState$: Observable<ProductFutureStock | undefined>;
    /**
     * Get future stock
     */
    getFutureStock(): Observable<ProductFutureStock | undefined>;
    constructor(userIdService: UserIdService, futureStockConnector: FutureStockConnector, routingService: RoutingService);
    static ɵfac: i0.ɵɵFactoryDeclaration<FutureStockService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FutureStockService>;
}

declare class FutureStockCoreModule {
    static forRoot(): ModuleWithProviders<FutureStockCoreModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FutureStockCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FutureStockCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FutureStockCoreModule>;
}

export { FUTURE_STOCK_LIST_NORMALIZER, FUTURE_STOCK_NORMALIZER, FutureStockAdapter, FutureStockConnector, FutureStockCoreModule, FutureStockService };
export type { ProductFutureStock, ProductFutureStockList };
