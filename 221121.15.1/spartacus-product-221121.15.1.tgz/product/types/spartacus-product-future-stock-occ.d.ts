import { HttpClient } from '@angular/common/http';
import { OccEndpointsService, ConverterService, LoggerService, OccEndpoint } from '@spartacus/core';
import { FutureStockAdapter, ProductFutureStock, ProductFutureStockList } from '@spartacus/product/future-stock/core';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare class OccFutureStockAdapter implements FutureStockAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    getFutureStock(userId: string, productCode: string): Observable<ProductFutureStock>;
    getFutureStocks(userId: string, productCodes: string): Observable<ProductFutureStockList>;
    protected getFutureStockEndpoint(userId: string, productCode: string): string;
    protected getFutureStocksEndpoint(userId: string, productCodes: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccFutureStockAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccFutureStockAdapter>;
}

interface FutureStockOccEndpoints {
    /**
     * Get a specific future stock.
     */
    futureStock?: string | OccEndpoint;
    /**
     * Get all future stocks.
     */
    futureStocks?: string | OccEndpoint;
}
declare module '@spartacus/core' {
    interface OccEndpoints extends FutureStockOccEndpoints {
    }
}

declare class FutureStockOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FutureStockOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FutureStockOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FutureStockOccModule>;
}

export { FutureStockOccModule, OccFutureStockAdapter };
export type { FutureStockOccEndpoints };
