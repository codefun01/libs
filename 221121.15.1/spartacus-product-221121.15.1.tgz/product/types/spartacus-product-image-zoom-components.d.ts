import * as i0 from '@angular/core';
import { ElementRef, OnInit, OnDestroy, EventEmitter, ViewContainerRef, Renderer2, ChangeDetectorRef } from '@angular/core';
import * as i1 from '@spartacus/storefront';
import { LaunchDialogService, ICON_TYPE, FocusConfig, ProductImagesComponent, CurrentProductService, BreakpointService, LayoutConfig } from '@spartacus/storefront';
import * as i2 from '@angular/common';
import * as i3 from '@spartacus/core';
import { Product, ImageGroup } from '@spartacus/core';
import * as i4 from '@angular/router';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
import { ThumbnailsGroup } from '@spartacus/product/image-zoom/root';

declare class ProductImageZoomDialogComponent {
    protected launchDialogService: LaunchDialogService;
    protected el: ElementRef;
    iconType: typeof ICON_TYPE;
    focusConfig: FocusConfig;
    galleryIndex: number;
    handleClick(event: UIEvent): void;
    constructor(launchDialogService: LaunchDialogService, el: ElementRef);
    close(reason?: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductImageZoomDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductImageZoomDialogComponent, "cx-product-image-zoom-dialog", never, { "galleryIndex": { "alias": "galleryIndex"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ProductImageZoomProductImagesComponent extends ProductImagesComponent {
    protected currentProductService: CurrentProductService;
    expandImage: BehaviorSubject<boolean>;
    selectedIndex: number | undefined;
    product$: Observable<Product>;
    constructor(currentProductService: CurrentProductService);
    openImage(item: any): void;
    /**
     * Opens image zoom dialog.
     */
    triggerZoom(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductImageZoomProductImagesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductImageZoomProductImagesComponent, "cx-product-images", never, {}, {}, never, never, true, never>;
}

declare class ProductImageZoomThumbnailsComponent implements OnInit, OnDestroy {
    private mainMediaContainer;
    productImage: EventEmitter<{
        image: any;
        index: number;
    }>;
    thumbs$: Observable<ThumbnailsGroup[]>;
    activeThumb: EventEmitter<ImageGroup>;
    protected subscription: Subscription;
    selectedIndex: number;
    constructor();
    ngOnInit(): void;
    openImage(image: ImageGroup): void;
    isActive(thumbnail: ImageGroup): Observable<boolean>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductImageZoomThumbnailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductImageZoomThumbnailsComponent, "cx-product-image-zoom-thumbnails", never, { "thumbs$": { "alias": "thumbs$"; "required": false; }; "activeThumb": { "alias": "activeThumb"; "required": false; }; }, { "productImage": "productImage"; }, never, never, true, never>;
}

declare class ProductImageZoomTriggerComponent implements OnDestroy {
    protected launchDialogService: LaunchDialogService;
    protected vcr: ViewContainerRef;
    iconType: typeof ICON_TYPE;
    protected subscriptions: Subscription;
    expandButton: ElementRef;
    galleryIndex: number;
    set expandImage(expand: boolean);
    dialogClose: EventEmitter<void>;
    constructor(launchDialogService: LaunchDialogService, vcr: ViewContainerRef);
    triggerZoom(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductImageZoomTriggerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductImageZoomTriggerComponent, "cx-product-image-zoom-trigger", never, { "galleryIndex": { "alias": "galleryIndex"; "required": false; }; "expandImage": { "alias": "expandImage"; "required": false; }; }, { "dialogClose": "dialogClose"; }, never, never, true, never>;
}

declare class ProductImageZoomViewComponent implements OnInit, OnDestroy {
    protected currentProductService: CurrentProductService;
    protected renderer: Renderer2;
    protected cdRef: ChangeDetectorRef;
    protected breakpointService: BreakpointService;
    iconType: typeof ICON_TYPE;
    galleryIndex: number;
    private mainMediaContainer;
    private defaultImageReady;
    private zoomReady;
    private _defaultImage;
    private _zoomImage;
    protected imageLoaded: BehaviorSubject<boolean>;
    protected subscription: Subscription;
    protected mainMediaContainer$: Observable<ImageGroup | null>;
    protected defaultImageReady$: Observable<boolean>;
    protected zoomReady$: Observable<boolean>;
    private featureConfigService;
    activeThumb: EventEmitter<ImageGroup>;
    defaultImageClickHandler$: Observable<any[]>;
    get defaultImage(): ElementRef;
    set defaultImage(el: ElementRef);
    zoomImageClickHandler$: Observable<any[]>;
    get zoomImage(): ElementRef;
    set zoomImage(el: ElementRef);
    zoomedImage: ElementRef;
    zoomButton: ElementRef;
    startCoords: {
        x: number;
        y: number;
    } | null;
    left: number;
    top: number;
    isZoomed: boolean;
    protected product$: Observable<Product>;
    thumbnails$: Observable<Observable<ThumbnailsGroup>[]>;
    mainImage$: Observable<ImageGroup | null>;
    constructor(currentProductService: CurrentProductService, renderer: Renderer2, cdRef: ChangeDetectorRef, breakpointService: BreakpointService);
    ngOnInit(): void;
    openImage(item: ImageGroup): void;
    /** find the index of the main media in the list of media */
    protected getActive(): number;
    getPreviousProduct(thumbs: Observable<ImageGroup>[]): Observable<ImageGroup>;
    getNextProduct(thumbs: Observable<ImageGroup>[]): Observable<ImageGroup>;
    /**
     * Zoom in or out of the image
     */
    zoom(): void;
    /**
     * Touch screen image pan
     *
     * @param event
     */
    touchMove(event: TouchEvent): void;
    /**
     * Clears touch location
     */
    clearTouch(): void;
    /**
     * Pointer image pan
     *
     * @param event
     */
    pointerMove(event: MouseEvent): void;
    changeImage(event: {
        image: ImageGroup;
        index: number;
    }): void;
    /**
     * Applies the offset from touchMove or pointerMove to the image element
     *
     * @param positionX
     * @param positionY
     * @param boundingRect
     * @param imageElement
     */
    protected moveImage(positionX: number, positionY: number, boundingRect: any, imageElement: DOMRect): void;
    ngOnDestroy(): void;
    /**
     * Returns click and dblclick event mapping for the given element
     *
     * @param element
     */
    private clickOrDoubleClick;
    /**
     * Return an array of CarouselItems for the product thumbnails.
     * In case there are less then 2 thumbs, we return null.
     */
    private createThumbs;
    /**
     * Keeps the zoom image from leaving the bounding container
     *
     * @param positionX
     * @param positionY
     * @param imageElement
     * @param boundingRect
     */
    handleOutOfBounds(positionX: number, positionY: number, imageElement: any, boundingRect: DOMRect): {
        x: number;
        y: number;
    };
    /**
     * Returns the position of the image based on the cursor pointer
     *
     * @param element
     * @param clientX
     * @param clientY
     */
    calculatePointerMovePosition(element: ElementRef, clientX: number, clientY: number): {
        positionX: number;
        positionY: number;
    };
    onImageLoad(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductImageZoomViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductImageZoomViewComponent, "cx-product-image-zoom-view", never, { "galleryIndex": { "alias": "galleryIndex"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ProductImageZoomModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductImageZoomModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductImageZoomModule, never, [typeof i1.CarouselModule, typeof i1.CarouselScrollingModule, typeof i2.CommonModule, typeof i3.I18nModule, typeof i1.IconModule, typeof i1.KeyboardFocusModule, typeof i1.MediaModule, typeof i1.OutletModule, typeof i4.RouterModule, typeof i3.FeaturesConfigModule, typeof i1.LcpContextDirectiveModule, typeof ProductImageZoomDialogComponent, typeof ProductImageZoomProductImagesComponent, typeof ProductImageZoomThumbnailsComponent, typeof ProductImageZoomTriggerComponent, typeof ProductImageZoomViewComponent], [typeof ProductImageZoomDialogComponent, typeof ProductImageZoomProductImagesComponent, typeof ProductImageZoomThumbnailsComponent, typeof ProductImageZoomTriggerComponent, typeof ProductImageZoomViewComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductImageZoomModule>;
}

declare class ProductImageZoomComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductImageZoomComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductImageZoomComponentsModule, never, [typeof ProductImageZoomModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductImageZoomComponentsModule>;
}

declare const defaultProductImageZoomLayoutConfig: LayoutConfig;

export { ProductImageZoomComponentsModule, ProductImageZoomDialogComponent, ProductImageZoomModule, ProductImageZoomProductImagesComponent, ProductImageZoomThumbnailsComponent, ProductImageZoomTriggerComponent, ProductImageZoomViewComponent, defaultProductImageZoomLayoutConfig };
