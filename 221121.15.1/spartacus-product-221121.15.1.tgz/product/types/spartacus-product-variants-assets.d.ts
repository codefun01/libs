import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};

declare const de: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};

declare const en: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};

declare const es: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};

declare const es_CO: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};

declare const fr: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};

declare const hi: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};

declare const hu: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};

declare const id: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};

declare const it: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};

declare const ja: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};

declare const ko: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};

declare const pl: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};

declare const pt: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};

declare const ru: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};

declare const zh: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};

declare const zh_TW: {
    productVariants: {
        productVariants: {
            style: string;
            selectedStyle: string;
            size: string;
            color: string;
            sizeGuideLabel: string;
        };
    };
};

declare const productVariantsTranslationChunksConfig: TranslationChunksConfig;

export { productVariantsTranslationChunksConfig, cs as productVariantsTranslationsCs, de as productVariantsTranslationsDe, en as productVariantsTranslationsEn, es as productVariantsTranslationsEs, es_CO as productVariantsTranslationsEs_CO, fr as productVariantsTranslationsFr, hi as productVariantsTranslationsHi, hu as productVariantsTranslationsHu, id as productVariantsTranslationsId, it as productVariantsTranslationsIt, ja as productVariantsTranslationsJa, ko as productVariantsTranslationsKo, pl as productVariantsTranslationsPl, pt as productVariantsTranslationsPt, ru as productVariantsTranslationsRu, zh as productVariantsTranslationsZh, zh_TW as productVariantsTranslationsZh_TW };
