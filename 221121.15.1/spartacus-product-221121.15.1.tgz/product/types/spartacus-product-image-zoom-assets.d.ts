import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            zoomedInImage: string;
            previousSlide: string;
            nextSlide: string;
            close: string;
        };
    };
};

declare const de: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            zoomedInImage: string;
            previousSlide: string;
            nextSlide: string;
            close: string;
        };
    };
};

declare const en: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            zoomedInImage: string;
            previousSlide: string;
            nextSlide: string;
            close: string;
        };
    };
};

declare const es: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            zoomedInImage: string;
            previousSlide: string;
            nextSlide: string;
            close: string;
        };
    };
};

declare const es_CO: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            zoomedInImage: string;
            previousSlide: string;
            nextSlide: string;
            close: string;
        };
    };
};

declare const fr: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            zoomedInImage: string;
            previousSlide: string;
            nextSlide: string;
            close: string;
        };
    };
};

declare const hi: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            zoomedInImage: string;
            previousSlide: string;
            nextSlide: string;
            close: string;
        };
    };
};

declare const hu: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            zoomedInImage: string;
            previousSlide: string;
            nextSlide: string;
            close: string;
        };
    };
};

declare const id: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            zoomedInImage: string;
            previousSlide: string;
            nextSlide: string;
            close: string;
        };
    };
};

declare const it: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            zoomedInImage: string;
            previousSlide: string;
            nextSlide: string;
            close: string;
        };
    };
};

declare const ja: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            zoomedInImage: string;
            previousSlide: string;
            nextSlide: string;
            close: string;
        };
    };
};

declare const ko: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            zoomedInImage: string;
            previousSlide: string;
            nextSlide: string;
            close: string;
        };
    };
};

declare const pl: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            zoomedInImage: string;
            previousSlide: string;
            nextSlide: string;
            close: string;
        };
    };
};

declare const pt: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            zoomedInImage: string;
            previousSlide: string;
            nextSlide: string;
            close: string;
        };
    };
};

declare const ru: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            zoomedInImage: string;
            previousSlide: string;
            nextSlide: string;
            close: string;
        };
    };
};

declare const zh: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            zoomedInImage: string;
            previousSlide: string;
            nextSlide: string;
            close: string;
        };
    };
};

declare const zh_TW: {
    productImageZoom: {
        productImageZoomTrigger: {
            expand: string;
        };
        productImageZoomDialog: {
            zoomedInImage: string;
            previousSlide: string;
            nextSlide: string;
            close: string;
        };
    };
};

declare const productImageZoomTranslationChunksConfig: TranslationChunksConfig;

export { productImageZoomTranslationChunksConfig, cs as productImageZoomTranslationsCs, de as productImageZoomTranslationsDe, en as productImageZoomTranslationsEn, es as productImageZoomTranslationsEs, es_CO as productImageZoomTranslationsEs_CO, fr as productImageZoomTranslationsFr, hi as productImageZoomTranslationsHi, hu as productImageZoomTranslationsHu, id as productImageZoomTranslationsId, it as productImageZoomTranslationsIt, ja as productImageZoomTranslationsJa, ko as productImageZoomTranslationsKo, pl as productImageZoomTranslationsPl, pt as productImageZoomTranslationsPt, ru as productImageZoomTranslationsRu, zh as productImageZoomTranslationsZh, zh_TW as productImageZoomTranslationsZh_TW };
