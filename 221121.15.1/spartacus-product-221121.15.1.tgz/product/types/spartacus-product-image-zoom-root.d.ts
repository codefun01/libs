import { ImageGroup } from '@spartacus/core';
import * as i0 from '@angular/core';

declare const PRODUCT_IMAGE_ZOOM_FEATURE = "productImageZoom";

interface ThumbnailsGroup {
    container: ImageGroup;
}

declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        PRODUCT_IMAGE_ZOOM = "PRODUCT_IMAGE_ZOOM"
    }
}

declare function defaultImageZoomComponentsConfig(): {
    featureModules: {
        productImageZoom: {
            cmsComponents: string[];
        };
    };
};
declare class ProductImageZoomRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductImageZoomRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductImageZoomRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductImageZoomRootModule>;
}

export { PRODUCT_IMAGE_ZOOM_FEATURE, ProductImageZoomRootModule, defaultImageZoomComponentsConfig };
export type { ThumbnailsGroup };
