import { NgIf, NgFor, AsyncPipe, CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Component, NgModule } from '@angular/core';
import * as i1 from '@spartacus/core';
import { TranslatePipe, I18nModule, ConfigModule } from '@spartacus/core';
import { SpinnerModule } from '@spartacus/storefront';
import { switchMap } from 'rxjs/operators';
import * as i2 from '@spartacus/product/bulk-pricing/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class BulkPricingTableComponent {
    constructor(routingService, bulkPricingService) {
        this.routingService = routingService;
        this.bulkPricingService = bulkPricingService;
        this.PRODUCT_KEY = 'productCode';
    }
    ngOnInit() {
        this.priceTiers$ = this.getPrices();
    }
    formatQuantity(tier) {
        let formattedQuantityRange = '';
        if (!tier.maxQuantity) {
            formattedQuantityRange = tier.minQuantity + '+';
        }
        else {
            formattedQuantityRange = tier.minQuantity + ' - ' + tier.maxQuantity;
        }
        return formattedQuantityRange;
    }
    getPrices() {
        return this.routingService.getRouterState().pipe(switchMap((state) => {
            const productCode = state.state.params[this.PRODUCT_KEY];
            return this.bulkPricingService.getBulkPrices(productCode);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BulkPricingTableComponent, deps: [{ token: i1.RoutingService }, { token: i2.BulkPricingService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: BulkPricingTableComponent, isStandalone: true, selector: "cx-bulk-pricing-table", ngImport: i0, template: "<ng-container *ngIf=\"priceTiers$ | async as priceTiers\">\n  <div class=\"cx-bulk-pricing-table-container\" *ngIf=\"priceTiers.length > 0\">\n    <table class=\"table\">\n      <thead class=\"thead-light\">\n        <tr>\n          <th scope=\"col\">{{ 'bulkPricingTable.quantity' | cxTranslate }}</th>\n          <th scope=\"col\">{{ 'bulkPricingTable.price' | cxTranslate }}</th>\n          <th scope=\"col\">{{ 'bulkPricingTable.discount' | cxTranslate }}</th>\n        </tr>\n      </thead>\n      <tbody>\n        <tr *ngFor=\"let tier of priceTiers\">\n          <td>{{ formatQuantity(tier) }}</td>\n          <td>{{ tier.formattedValue }}</td>\n          <td>{{ tier.formattedDiscount }}</td>\n        </tr>\n      </tbody>\n    </table>\n  </div>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BulkPricingTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-bulk-pricing-table', imports: [NgIf, NgFor, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"priceTiers$ | async as priceTiers\">\n  <div class=\"cx-bulk-pricing-table-container\" *ngIf=\"priceTiers.length > 0\">\n    <table class=\"table\">\n      <thead class=\"thead-light\">\n        <tr>\n          <th scope=\"col\">{{ 'bulkPricingTable.quantity' | cxTranslate }}</th>\n          <th scope=\"col\">{{ 'bulkPricingTable.price' | cxTranslate }}</th>\n          <th scope=\"col\">{{ 'bulkPricingTable.discount' | cxTranslate }}</th>\n        </tr>\n      </thead>\n      <tbody>\n        <tr *ngFor=\"let tier of priceTiers\">\n          <td>{{ formatQuantity(tier) }}</td>\n          <td>{{ tier.formattedValue }}</td>\n          <td>{{ tier.formattedDiscount }}</td>\n        </tr>\n      </tbody>\n    </table>\n  </div>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: i1.RoutingService }, { type: i2.BulkPricingService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class BulkPricingTableModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BulkPricingTableModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: BulkPricingTableModule, imports: [CommonModule,
            I18nModule,
            SpinnerModule, i1.ConfigModule, BulkPricingTableComponent], exports: [BulkPricingTableComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BulkPricingTableModule, imports: [CommonModule,
            I18nModule,
            SpinnerModule,
            ConfigModule.withConfig({
                cmsComponents: {
                    BulkPricingTableComponent: {
                        component: BulkPricingTableComponent,
                    },
                },
            })] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BulkPricingTableModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        SpinnerModule,
                        ConfigModule.withConfig({
                            cmsComponents: {
                                BulkPricingTableComponent: {
                                    component: BulkPricingTableComponent,
                                },
                            },
                        }),
                        BulkPricingTableComponent,
                    ],
                    exports: [BulkPricingTableComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { BulkPricingTableComponent, BulkPricingTableModule };
//# sourceMappingURL=spartacus-product-bulk-pricing-components.mjs.map
