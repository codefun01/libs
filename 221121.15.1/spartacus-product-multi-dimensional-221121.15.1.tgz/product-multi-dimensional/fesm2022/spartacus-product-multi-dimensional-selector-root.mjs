import * as i0 from '@angular/core';
import { NgModule, Injectable } from '@angular/core';
import { VariantQualifier, provideDefaultConfig, provideDefaultConfigFactory, Config } from '@spartacus/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const PRODUCT_MULTI_DIMENSIONAL_SELECTOR_FEATURE = 'productMultiDimensionalSelector';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultProductMultiDimensionalConfig = {
    multiDimensional: {
        imageFormat: VariantQualifier.STYLE_SWATCH,
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
function defaultProductMultiDimensionalSelectorComponentsConfig() {
    return {
        featureModules: {
            [PRODUCT_MULTI_DIMENSIONAL_SELECTOR_FEATURE]: {
                cmsComponents: ['ProductMultiDimensionalSelectorComponent'],
            },
        },
    };
}
class ProductMultiDimensionalSelectorRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ProductMultiDimensionalSelectorRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: ProductMultiDimensionalSelectorRootModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ProductMultiDimensionalSelectorRootModule, providers: [
            provideDefaultConfig(defaultProductMultiDimensionalConfig),
            provideDefaultConfigFactory(defaultProductMultiDimensionalSelectorComponentsConfig),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ProductMultiDimensionalSelectorRootModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        provideDefaultConfig(defaultProductMultiDimensionalConfig),
                        provideDefaultConfigFactory(defaultProductMultiDimensionalSelectorComponentsConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ProductMultiDimensionalConfig {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ProductMultiDimensionalConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ProductMultiDimensionalConfig, providedIn: 'root', useExisting: Config }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ProductMultiDimensionalConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useExisting: Config,
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { PRODUCT_MULTI_DIMENSIONAL_SELECTOR_FEATURE, ProductMultiDimensionalConfig, ProductMultiDimensionalSelectorRootModule, defaultProductMultiDimensionalConfig, defaultProductMultiDimensionalSelectorComponentsConfig };
//# sourceMappingURL=spartacus-product-multi-dimensional-selector-root.mjs.map
