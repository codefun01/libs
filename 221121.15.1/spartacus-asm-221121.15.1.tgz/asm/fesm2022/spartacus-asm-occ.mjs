import * as i1 from '@angular/common/http';
import { HttpParams, HttpHeaders } from '@angular/common/http';
import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { CUSTOMER_LISTS_NORMALIZER, CUSTOMER_SEARCH_PAGE_NORMALIZER, AsmAdapter } from '@spartacus/asm/core';
import * as i2 from '@spartacus/core';
import { LoggerService, UserIdService, tryNormalizeHttpError, InterceptorUtil, USE_CUSTOMER_SUPPORT_AGENT_TOKEN, provideDefaultConfig } from '@spartacus/core';
import { catchError } from 'rxjs/operators';
import * as i3 from '@spartacus/asm/root';
import { CommonModule } from '@angular/common';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccAsmAdapter {
    constructor(http, occEndpointsService, converterService, config, baseSiteService) {
        this.http = http;
        this.occEndpointsService = occEndpointsService;
        this.converterService = converterService;
        this.config = config;
        this.baseSiteService = baseSiteService;
        this.logger = inject(LoggerService);
        this.userIdService = inject(UserIdService);
        this.baseSiteService
            .getActive()
            .subscribe((value) => (this.activeBaseSite = value));
        this.userIdService
            .getUserId()
            .subscribe((value) => (this.currentUserId = value));
    }
    createAsmSessionEvent(options) {
        const headers = this.getHeaders();
        const params = new HttpParams();
        const requestBody = {
            ...options,
        };
        const url = this.occEndpointsService.buildUrl('asmSessionEvent', {
            urlParams: {
                baseSiteId: this.activeBaseSite,
                userId: this.currentUserId,
            },
        }, {
            baseSite: false,
            prefix: false,
        });
        return this.http.post(url, requestBody, { headers, params }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    getHeaders() {
        return InterceptorUtil.createHeader(USE_CUSTOMER_SUPPORT_AGENT_TOKEN, true, new HttpHeaders());
    }
    customerLists() {
        const headers = this.getHeaders();
        const params = new HttpParams().set('baseSite', this.activeBaseSite);
        const url = this.occEndpointsService.buildUrl('asmCustomerLists', {}, {
            baseSite: false,
            prefix: false,
        });
        return this.http.get(url, { headers, params }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), this.converterService.pipeable(CUSTOMER_LISTS_NORMALIZER));
    }
    customerSearch(options) {
        const headers = this.getHeaders();
        let params = new HttpParams().set('baseSite', this.activeBaseSite);
        const searchBody = {};
        if (options.sort !== undefined) {
            params = params.set('sort', options.sort);
        }
        else {
            if (!options.customerListId) {
                params = params.set('sort', 'byNameAsc');
            }
        }
        if (options.query !== undefined) {
            searchBody.query = options.query;
        }
        if (options.orderId !== undefined) {
            searchBody.orderId = options.orderId;
        }
        if (options.pageSize !== undefined) {
            params = params.set('pageSize', options.pageSize.toString());
        }
        if (options.page !== undefined) {
            params = params.set('page', options.page.toString());
        }
        if (options.customerListId !== undefined) {
            searchBody.customerListId = options.customerListId;
        }
        const url = this.occEndpointsService.buildUrl('asmCustomerSearch', {}, {
            baseSite: false,
            prefix: false,
        });
        return this.http
            .post(url, searchBody, { headers, params })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), this.converterService.pipeable(CUSTOMER_SEARCH_PAGE_NORMALIZER));
    }
    bindCart({ cartId, customerId }) {
        const headers = InterceptorUtil.createHeader(USE_CUSTOMER_SUPPORT_AGENT_TOKEN, true, new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded'));
        const params = new HttpParams().set('baseSite', this.activeBaseSite);
        const body = new URLSearchParams();
        body.set('cartId', cartId);
        body.set('customerId', customerId);
        const url = this.occEndpointsService.buildUrl('asmBindCart', {}, {
            baseSite: false,
            prefix: false,
        });
        return this.http.post(url, body, { headers, params }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    createCustomer(user) {
        const headers = this.getHeaders();
        const params = new HttpParams().set('baseSite', this.activeBaseSite);
        const url = this.occEndpointsService.buildUrl('asmCreateCustomer', {}, {
            baseSite: false,
            prefix: false,
        });
        return this.http.post(url, user, { headers, params }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccAsmAdapter, deps: [{ token: i1.HttpClient }, { token: i2.OccEndpointsService }, { token: i2.ConverterService }, { token: i3.AsmConfig }, { token: i2.BaseSiteService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccAsmAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccAsmAdapter, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: i2.OccEndpointsService }, { type: i2.ConverterService }, { type: i3.AsmConfig }, { type: i2.BaseSiteService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOccAsmConfig = {
    backend: {
        occ: {
            endpoints: {
                asmCustomerSearch: '/assistedservicewebservices/customers/search',
                asmCustomerLists: '/assistedservicewebservices/customerlists',
                asmBindCart: '/assistedservicewebservices/bind-cart',
                asmCreateCustomer: '/assistedservicewebservices/customers',
                asmSessionEvent: 'assistedservicewebservices/${baseSiteId}/users/${userId}/asmSessionEvents',
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AsmOccModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AsmOccModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: AsmOccModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AsmOccModule, providers: [
            provideDefaultConfig(defaultOccAsmConfig),
            {
                provide: AsmAdapter,
                useClass: OccAsmAdapter,
            },
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AsmOccModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [
                        provideDefaultConfig(defaultOccAsmConfig),
                        {
                            provide: AsmAdapter,
                            useClass: OccAsmAdapter,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AsmOccModule, OccAsmAdapter };
//# sourceMappingURL=spartacus-asm-occ.mjs.map
