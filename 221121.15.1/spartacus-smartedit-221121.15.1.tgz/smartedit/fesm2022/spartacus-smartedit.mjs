import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { SmartEditCoreModule } from '@spartacus/smartedit/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SmartEditModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: SmartEditModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: SmartEditModule, imports: [SmartEditCoreModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: SmartEditModule, imports: [SmartEditCoreModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: SmartEditModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [SmartEditCoreModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/*
 * Public API Surface of smartedit
 */

/**
 * Generated bundle index. Do not edit.
 */

export { SmartEditModule };
//# sourceMappingURL=spartacus-smartedit.mjs.map
