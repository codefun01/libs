import * as i0 from '@angular/core';
import { Injectable, NgModule } from '@angular/core';
import { CustomerTicketingCloseComponentService, CustomerTicketingMessagesComponentService, CustomerTicketingReopenComponentService } from '@spartacus/customer-ticketing/components';
import { of } from 'rxjs';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CdpCustomerTicketingCloseComponentService extends CustomerTicketingCloseComponentService {
    enableCloseButton() {
        return of(false);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdpCustomerTicketingCloseComponentService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdpCustomerTicketingCloseComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdpCustomerTicketingCloseComponentService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CdpCustomerTicketingMessagesComponentService extends CustomerTicketingMessagesComponentService {
    displayAddMessageSection(_ticket) {
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdpCustomerTicketingMessagesComponentService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdpCustomerTicketingMessagesComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdpCustomerTicketingMessagesComponentService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CdpCustomerTicketingReopenComponentService extends CustomerTicketingReopenComponentService {
    enableReopenButton() {
        return of(false);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdpCustomerTicketingReopenComponentService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdpCustomerTicketingReopenComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdpCustomerTicketingReopenComponentService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CdpCustomerTicketingModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdpCustomerTicketingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CdpCustomerTicketingModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdpCustomerTicketingModule, providers: [
            {
                provide: CustomerTicketingCloseComponentService,
                useClass: CdpCustomerTicketingCloseComponentService,
            },
            {
                provide: CustomerTicketingReopenComponentService,
                useClass: CdpCustomerTicketingReopenComponentService,
            },
            {
                provide: CustomerTicketingMessagesComponentService,
                useClass: CdpCustomerTicketingMessagesComponentService,
            },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CdpCustomerTicketingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    providers: [
                        {
                            provide: CustomerTicketingCloseComponentService,
                            useClass: CdpCustomerTicketingCloseComponentService,
                        },
                        {
                            provide: CustomerTicketingReopenComponentService,
                            useClass: CdpCustomerTicketingReopenComponentService,
                        },
                        {
                            provide: CustomerTicketingMessagesComponentService,
                            useClass: CdpCustomerTicketingMessagesComponentService,
                        },
                    ],
                    declarations: [],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CdpCustomerTicketingCloseComponentService, CdpCustomerTicketingMessagesComponentService, CdpCustomerTicketingModule, CdpCustomerTicketingReopenComponentService };
//# sourceMappingURL=spartacus-cdp-customer-ticketing.mjs.map
