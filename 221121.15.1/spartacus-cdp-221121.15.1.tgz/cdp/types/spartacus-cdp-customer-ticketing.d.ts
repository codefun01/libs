import { CustomerTicketingCloseComponentService, CustomerTicketingMessagesComponentService, CustomerTicketingReopenComponentService } from '@spartacus/customer-ticketing/components';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import { TicketDetails } from '@spartacus/customer-ticketing/root';

declare class CdpCustomerTicketingCloseComponentService extends CustomerTicketingCloseComponentService {
    enableCloseButton(): Observable<boolean | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdpCustomerTicketingCloseComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdpCustomerTicketingCloseComponentService>;
}

declare class CdpCustomerTicketingMessagesComponentService extends CustomerTicketingMessagesComponentService {
    displayAddMessageSection(_ticket: TicketDetails | undefined): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdpCustomerTicketingMessagesComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdpCustomerTicketingMessagesComponentService>;
}

declare class CdpCustomerTicketingReopenComponentService extends CustomerTicketingReopenComponentService {
    enableReopenButton(): Observable<boolean | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdpCustomerTicketingReopenComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdpCustomerTicketingReopenComponentService>;
}

declare class CdpCustomerTicketingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CdpCustomerTicketingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CdpCustomerTicketingModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CdpCustomerTicketingModule>;
}

export { CdpCustomerTicketingCloseComponentService, CdpCustomerTicketingMessagesComponentService, CdpCustomerTicketingModule, CdpCustomerTicketingReopenComponentService };
