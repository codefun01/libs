import * as i0 from '@angular/core';
import { Injectable, inject, isDevMode, NgModule } from '@angular/core';
import { OrderSelectors, OrderHistoryService, OrderHistoryAdapter } from '@spartacus/order/core';
import { Config, OCC_USER_ID_ANONYMOUS, InterceptorUtil, USE_CLIENT_TOKEN, provideDefaultConfig } from '@spartacus/core';
import { OccOrderHistoryAdapter } from '@spartacus/order/occ';
import { ORDER_NORMALIZER, OrderHistoryFacade } from '@spartacus/order/root';
import { HttpHeaders } from '@angular/common/http';
import { map, switchMap, of } from 'rxjs';
import { Store } from '@ngrx/store';
import { ActivatedRoute } from '@angular/router';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OmfConfig {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OmfConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OmfConfig, providedIn: 'root', useExisting: Config }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OmfConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useExisting: Config,
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccOmfOrderHistoryAdapter extends OccOrderHistoryAdapter {
    constructor() {
        super(...arguments);
        this.route = inject(ActivatedRoute);
        this.store = inject((Store));
        this.config = inject(OmfConfig);
    }
    getOrderDetailsValue(code) {
        return this.store.select(OrderSelectors.getOrdersState).pipe(map((orderListState) => orderListState.value), map((orderList) => {
            return (orderList?.orders ?? []).find((order) => order.code === code);
        }));
    }
    getOrderGuid(orderCode) {
        return this.route.queryParams.pipe(switchMap((queryParams) => {
            if (queryParams.guid) {
                // when navigating from Order History to Order Details page
                return of(queryParams.guid);
            }
            else {
                // when loading Order History page in case of My-Account-V2
                return this.getOrderDetailsValue(orderCode).pipe(map((order) => (order ? order.guid : undefined)));
            }
        }));
    }
    getRequestHeader(guid) {
        let headers = new HttpHeaders();
        if (!this.config.omf?.guidHttpHeaderName && isDevMode()) {
            this.logger.warn(`There is no guidHttpHeaderName configured in OMF configuration`);
        }
        const guidHeader = this.config.omf?.guidHttpHeaderName?.toLowerCase?.();
        if (guid && guidHeader) {
            headers = headers.set(guidHeader, guid);
        }
        return headers;
    }
    load(userId, orderCode) {
        return this.getOrderGuid(orderCode).pipe(switchMap((guid) => {
            const url = this.getOrderDetailUrl(userId, orderCode);
            let headers = this.getRequestHeader(guid);
            if (userId === OCC_USER_ID_ANONYMOUS) {
                headers = InterceptorUtil.createHeader(USE_CLIENT_TOKEN, true, headers);
            }
            return this.http
                .get(url, { headers })
                .pipe(this.converter.pipeable(ORDER_NORMALIZER));
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccOmfOrderHistoryAdapter, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccOmfOrderHistoryAdapter, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OccOmfOrderHistoryAdapter, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OmfOrderHistoryService extends OrderHistoryService {
    getQueryParams(order) {
        return order.guid
            ? {
                guid: order.guid,
            }
            : null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OmfOrderHistoryService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OmfOrderHistoryService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OmfOrderHistoryService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOmfConfig = {
    omf: {
        guidHttpHeaderName: 'guid',
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OmfOrderModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OmfOrderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: OmfOrderModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OmfOrderModule, providers: [
            OmfOrderHistoryService,
            provideDefaultConfig(defaultOmfConfig),
            { provide: OrderHistoryAdapter, useClass: OccOmfOrderHistoryAdapter },
            {
                provide: OrderHistoryFacade,
                useClass: OmfOrderHistoryService,
            },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: OmfOrderModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        OmfOrderHistoryService,
                        provideDefaultConfig(defaultOmfConfig),
                        { provide: OrderHistoryAdapter, useClass: OccOmfOrderHistoryAdapter },
                        {
                            provide: OrderHistoryFacade,
                            useClass: OmfOrderHistoryService,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OccOmfOrderHistoryAdapter, OmfOrderHistoryService, OmfOrderModule };
//# sourceMappingURL=spartacus-omf-order.mjs.map
