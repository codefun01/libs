import * as i0 from '@angular/core';
import { Injectable, PLATFORM_ID, HostBinding, Inject, Directive, inject, ChangeDetectionStrategy, Component, Injector, ChangeDetectorRef, ViewContainerRef, ViewChild, NgModule, Input, Optional, DestroyRef, ElementRef } from '@angular/core';
import * as i1 from '@spartacus/core';
import { GlobalMessageType, FeatureConfigService, TranslatePipe, I18nModule, UrlModule, FeaturesConfigModule, isNotNullable, UrlPipe, CxDatePipe, isNotUndefined, DefaultRoutePageMetaResolver, AuthGuard, provideDefaultConfig, provideDefaultConfigFactory, CurrencyService, B2BUserRole, RoutingService, FeatureDirective } from '@spartacus/core';
import { isPlatformBrowser, NgIf, CommonModule, AsyncPipe, NgFor, NgTemplateOutlet } from '@angular/common';
import * as i4 from '@angular/forms';
import { FormsModule, UntypedFormGroup, UntypedFormControl, Validators, ReactiveFormsModule, UntypedFormArray } from '@angular/forms';
import { RouterLink, RouterOutlet, RouterModule, RouterLinkActive } from '@angular/router';
import * as i1$1 from '@spartacus/storefront';
import { ICON_TYPE, FocusDirective, IconComponent, IconModule, KeyboardFocusModule, FormUtils, ViewComponent, PopoverDirective, SplitViewModule, PopoverModule, TableLayout, TrapFocus, SplitViewComponent, TableComponent, PaginationComponent, TableModule, PaginationModule, CustomFormValidators, FormRequiredLegendComponent, FormRequiredAsterisksComponent, FormErrorsComponent, DatePickerComponent, FormErrorsModule, DatePickerModule, NgSelectA11yDirective, NgSelectA11yModule, BreakpointService, BREAKPOINT, PasswordVisibilityToggleDirective, PasswordVisibilityToggleModule } from '@spartacus/storefront';
import { ReplaySubject, Subject, Subscription, of, BehaviorSubject, EMPTY, take as take$1 } from 'rxjs';
import { filter, map, distinctUntilChanged, switchMap, tap, first, take, startWith, debounceTime, takeUntil, withLatestFrom, shareReplay } from 'rxjs/operators';
import { ROUTE_PARAMS, OrganizationUIConfig } from '@spartacus/organization/administration/root';
import * as i2 from '@spartacus/organization/administration/core';
import { LoadStatus, AdminGuard, OrgUnitService, Period, OrgUnitGuard, UserGuard } from '@spartacus/organization/administration/core';
import { NgSelectComponent, NgOptionComponent, NgSelectModule } from '@ng-select/ng-select';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i2$1 from '@spartacus/user/profile/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const DEFAULT_INFO_TIMEOUT = 3000;
class MessageService {
    constructor() {
        this.data$ = new ReplaySubject();
    }
    get() {
        return this.data$;
    }
    add(message) {
        message = { ...this.getDefaultMessage(message), ...message };
        message.events = new Subject();
        this.data$.next(message);
        return message.events;
    }
    close(message) {
        message?.next({ close: true });
    }
    /**
     * Sets the message type to INFO, and adds a default timeout
     * for info messages.
     */
    getDefaultMessage(message) {
        const defaultMessage = {
            type: GlobalMessageType.MSG_TYPE_INFO,
        };
        if (!message.type ||
            (message.type === GlobalMessageType.MSG_TYPE_INFO && !message.timeout)) {
            defaultMessage.timeout = DEFAULT_INFO_TIMEOUT;
        }
        return defaultMessage;
    }
    clear() {
        this.data$.next(undefined);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MessageService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MessageService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MessageService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class MessageData {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
// eslint-disable-next-line @angular-eslint/directive-class-suffix
class BaseMessageComponent {
    constructor(messageData, platformId) {
        this.messageData = messageData;
        this.platformId = platformId;
        this.terminated = false;
    }
    ngOnInit() {
        this.message = this.messageData.message ?? {};
        this.messageTitle = this.messageData.messageTitle;
        this.type = this.resolveType();
        this.messageIcon = this.messageData.messageIcon;
        if (this.messageData.timeout) {
            this.handleAutoHide();
        }
    }
    close() {
        this.messageData.events?.next({ close: true });
    }
    resolveType() {
        if (!this.messageData.type ||
            this.messageData.type === GlobalMessageType.MSG_TYPE_INFO) {
            return 'info';
        }
        if (this.messageData.type === GlobalMessageType.MSG_TYPE_ERROR) {
            return 'error';
        }
        if (this.messageData.type === GlobalMessageType.MSG_TYPE_WARNING) {
            return 'warning';
        }
    }
    handleAutoHide() {
        if (isPlatformBrowser(this.platformId)) {
            // we don't want to run this logic when doing SSR
            setTimeout(() => {
                this.close();
            }, this.messageData.timeout);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BaseMessageComponent, deps: [{ token: MessageData }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.19", type: BaseMessageComponent, isStandalone: true, host: { properties: { "class": "this.type", "class.terminated": "this.terminated" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BaseMessageComponent, decorators: [{
            type: Directive
        }], ctorParameters: () => [{ type: MessageData }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { type: [{
                type: HostBinding,
                args: ['class']
            }], terminated: [{
                type: HostBinding,
                args: ['class.terminated']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class NotificationMessageComponent extends BaseMessageComponent {
    constructor() {
        super(...arguments);
        this.closeIcon = ICON_TYPE.CLOSE;
        this.featureConfigService = inject(FeatureConfigService);
    }
    get isA11yCardNotificationMessageFeatureEnabled() {
        return this.featureConfigService.isEnabled('a11yCardNotificationMessage');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: NotificationMessageComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: NotificationMessageComponent, isStandalone: true, selector: "cx-org-notification", usesInheritance: true, ngImport: i0, template: "<div\n  class=\"inner\"\n  [cxFocus]=\"\n    isA11yCardNotificationMessageFeatureEnabled\n      ? {}\n      : { autofocus: true, focusOnEscape: true }\n  \"\n  (esc)=\"close()\"\n>\n  <cx-icon *ngIf=\"messageIcon\" [type]=\"messageIcon\"></cx-icon>\n  <p>{{ message | cxTranslate }}</p>\n  <button\n    class=\"close\"\n    (click)=\"close()\"\n    type=\"button\"\n    attr.aria-label=\"{{ 'common.close' | cxTranslate }}\"\n    attr.title=\"{{ 'common.close' | cxTranslate }}\"\n  >\n    <cx-icon [type]=\"closeIcon\"></cx-icon>\n  </button>\n</div>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: NotificationMessageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-notification', changeDetection: ChangeDetectionStrategy.OnPush, imports: [FocusDirective, NgIf, IconComponent, TranslatePipe], template: "<div\n  class=\"inner\"\n  [cxFocus]=\"\n    isA11yCardNotificationMessageFeatureEnabled\n      ? {}\n      : { autofocus: true, focusOnEscape: true }\n  \"\n  (esc)=\"close()\"\n>\n  <cx-icon *ngIf=\"messageIcon\" [type]=\"messageIcon\"></cx-icon>\n  <p>{{ message | cxTranslate }}</p>\n  <button\n    class=\"close\"\n    (click)=\"close()\"\n    type=\"button\"\n    attr.aria-label=\"{{ 'common.close' | cxTranslate }}\"\n    attr.title=\"{{ 'common.close' | cxTranslate }}\"\n  >\n    <cx-icon [type]=\"closeIcon\"></cx-icon>\n  </button>\n</div>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class MessageRenderService {
    constructor(componentFactoryResolver) {
        this.componentFactoryResolver = componentFactoryResolver;
    }
    getComponent(msg) {
        return this.componentFactoryResolver.resolveComponentFactory(msg.component || NotificationMessageComponent);
    }
    getInjector(componentData, parent) {
        return Injector.create({
            providers: [
                {
                    provide: MessageData,
                    useValue: componentData,
                },
            ],
            parent,
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MessageRenderService, deps: [{ token: i0.ComponentFactoryResolver }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MessageRenderService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MessageRenderService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i0.ComponentFactoryResolver }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class MessageComponent {
    constructor(messageService, renderService) {
        this.messageService = messageService;
        this.renderService = renderService;
        this.subscription = new Subscription();
    }
    ngAfterViewInit() {
        this.subscription.add(this.messageService.get().subscribe((msg) => {
            if (msg) {
                this.render(msg);
            }
            else {
                this.vcr?.clear();
            }
        }));
    }
    render(msg) {
        const ref = this.vcr.createComponent(this.renderService.getComponent(msg), 0, this.renderService.getInjector(msg, this.vcr.injector));
        ref.injector.get(ChangeDetectorRef).markForCheck();
        this.subscription.add(msg.events
            ?.pipe(filter((event) => !!event.close))
            .subscribe(() => this.terminate(ref)));
    }
    /**
     * Terminates the message component in 2 steps. It starts to toggle the terminate
     * state of the component and shortly after destroys the component completely. The
     * termination state allows the CSS layer to play an animation before destroying.
     */
    terminate(ref) {
        ref.instance.terminated = true;
        ref.injector.get(ChangeDetectorRef).markForCheck();
        setTimeout(() => {
            ref.destroy();
        }, 500);
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MessageComponent, deps: [{ token: MessageService }, { token: MessageRenderService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: MessageComponent, isStandalone: true, selector: "cx-org-message", viewQueries: [{ propertyName: "vcr", first: true, predicate: ["vcr"], descendants: true, read: ViewContainerRef }], ngImport: i0, template: "<ng-container #vcr></ng-container>\n", changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MessageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-message', changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-container #vcr></ng-container>\n" }]
        }], ctorParameters: () => [{ type: MessageService }, { type: MessageRenderService }], propDecorators: { vcr: [{
                type: ViewChild,
                args: ['vcr', { read: ViewContainerRef }]
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class NotificationMessageModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: NotificationMessageModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: NotificationMessageModule, imports: [CommonModule,
            I18nModule,
            IconModule,
            KeyboardFocusModule,
            NotificationMessageComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: NotificationMessageModule, imports: [CommonModule,
            I18nModule,
            IconModule,
            KeyboardFocusModule,
            NotificationMessageComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: NotificationMessageModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        IconModule,
                        KeyboardFocusModule,
                        NotificationMessageComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class MessageModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MessageModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: MessageModule, imports: [CommonModule, NotificationMessageModule, MessageComponent], exports: [MessageComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MessageModule, imports: [CommonModule, NotificationMessageModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: MessageModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, NotificationMessageModule, MessageComponent],
                    exports: [MessageComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Abstract Base class for all organization entities. This class simplifies
 * the various entity implementation, that only differ by dependencies and
 * data model.
 */
class CurrentItemService {
    constructor(routingService) {
        this.routingService = routingService;
        /**
         * Observes the key for the active organization item. The active key is observed
         * from the list of route parameters. The full route parameter list is evaluated,
         * including child routes.
         *
         * To allow for specific ("semantic") route parameters, the route parameter _key_ is
         * retrieved from the `getParamKey`.
         */
        this.key$ = this.routingService.getParams().pipe(map((params) => params[this.getParamKey()]), distinctUntilChanged());
        /**
         * Observes the active item.
         *
         * The active item is loaded by the active `key$`.
         */
        this.item$ = this.key$.pipe(switchMap((code) => (code ? this.getItem(code) : of(undefined))));
        /**
         * Observes the b2bUnit based on the unitCode route parameter.
         */
        this.b2bUnit$ = this.routingService.getParams().pipe(map((params) => params[ROUTE_PARAMS.unitCode]), distinctUntilChanged());
    }
    getRouterParam(paramKey) {
        return this.routingService
            .getParams()
            .pipe(map((params) => params[paramKey]));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentItemService, deps: [{ token: i1.RoutingService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentItemService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentItemService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.RoutingService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class FormService {
    getForm(item) {
        if (this.form && !!item) {
            this.patchData(item);
            return this.form;
        }
        if (!this.form) {
            this.build(item);
        }
        // while we should be able to reset with initial value, this doesn't always work
        // hence, we're patching afterwards.
        this.form?.reset();
        this.form?.enable();
        this.patchData(item);
        return this.form;
    }
    patchData(item) {
        this.toggleFreeze(item);
        this.form?.patchValue({ ...this.defaultValue, ...item });
    }
    toggleFreeze(item) {
        if (this.form?.enabled && item?.active === false) {
            this.form.disable();
        }
        if (this.form?.disabled && item?.active === true) {
            this.form.enable();
        }
    }
    /**
     * returns the default form value.
     */
    get defaultValue() {
        return {};
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: FormService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: FormService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: FormService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Provides CRUD operations for all organization entities.
 *
 * This base class simplifies the various entity implementation, and ensures a consistent
 * component implementation.
 */
class ItemService {
    constructor(currentItemService, routingService, formService) {
        this.currentItemService = currentItemService;
        this.routingService = routingService;
        this.formService = formService;
        this.key$ = this.currentItemService.key$;
        this.current$ = this.currentItemService.item$;
        this.isInEditMode$ = new BehaviorSubject(false);
        /**
         * Returns the current business unit code.
         *
         * The current unit is driven by the route parameter.
         */
        this.unit$ = this.currentItemService.b2bUnit$;
        this.error$ = this.key$.pipe(switchMap((key) => this.currentItemService.getError(key)));
    }
    save(form, key) {
        if (form.invalid) {
            form.markAllAsTouched();
            FormUtils.deepUpdateValueAndValidity(form);
            return EMPTY;
        }
        else {
            /**
             * This assignment is needed to re-use form value after `form.disable()` call
             * In some cases value was converted by `form.disable()` into empty object
             */
            const formValue = form.value;
            form.disable();
            return key ? this.update(key, formValue) : this.create(formValue);
        }
    }
    getForm(item) {
        return this.formService.getForm(item);
    }
    /**
     * Launches the detailed route for the given item item.
     */
    launchDetails(item) {
        const cxRoute = this.getDetailsRoute();
        const params = this.buildRouteParams(item);
        if (cxRoute && item && Object.keys(item).length > 0) {
            this.routingService.go({ cxRoute, params });
        }
    }
    /**
     * Returns the route parameters that are used when launching the
     * details page. The route parameters default to the actual item,
     * but can be further populated in implementations.
     *
     * Customized route parameters are useful in case the actual item
     * doesn't match the expected route parameters. You can manipulate
     * the parameter data.
     */
    buildRouteParams(item) {
        return item;
    }
    getRouterParam(key) {
        return this.currentItemService.getRouterParam(key);
    }
    /**
     * Sets to true when the user is on the entity item form page
     */
    setEditMode(isInEdit) {
        this.isInEditMode$.next(isInEdit);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ItemService, deps: [{ token: CurrentItemService }, { token: i1.RoutingService }, { token: FormService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ItemService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ItemService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: CurrentItemService }, { type: i1.RoutingService }, { type: FormService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CardComponent {
    constructor(itemService, messageService) {
        this.itemService = itemService;
        this.messageService = messageService;
        this.previous = true;
        this.showHint = false;
        this.iconTypes = ICON_TYPE;
        this.item$ = this.itemService.current$.pipe(tap((item) => this.refreshMessages(item)));
    }
    /**
     * The views are router based, which means if we close a view, the router outlet is
     * cleaned immediately. To prevent this, we're closing the view manually, before
     * navigating back.
     */
    closeView(event) {
        event.stopPropagation();
        this.view.toggle(true);
        setTimeout(() => {
            event.target?.parentElement?.click();
        }, 500);
        return false;
    }
    get previousLabel() {
        return this.previous;
    }
    refreshMessages(item) {
        if (this.itemKey !== undefined &&
            item?.code !== this.itemKey &&
            item?.uid !== this.itemKey &&
            item?.customerId !== this.itemKey) {
            this.messageService.clear();
        }
        this.itemKey = item?.code ?? item?.uid ?? item?.customerId;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CardComponent, deps: [{ token: ItemService }, { token: MessageService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CardComponent, isStandalone: true, selector: "cx-org-card", inputs: { i18nRoot: "i18nRoot", previous: "previous", subtitle: "subtitle", showHint: "showHint" }, host: { classAttribute: "content-wrapper" }, providers: [MessageService], viewQueries: [{ propertyName: "view", first: true, predicate: ViewComponent, descendants: true, read: ViewComponent }], ngImport: i0, template: "<cx-view\n  [viewTitle]=\"i18nRoot + '.title' | cxTranslate: { item: item$ | async }\"\n  class=\"card\"\n  role=\"tabpanel\"\n  [attr.aria-labelledby]=\"i18nRoot + '_title'\"\n>\n  <div class=\"header\">\n    <div class=\"title-bar\">\n      <div class=\"title\">\n        <h3>\n          <span id=\"{{ i18nRoot + '_title' }}\">\n            {{ i18nRoot + '.title' | cxTranslate: { item: item$ | async } }}\n          </span>\n          <button\n            *ngIf=\"showHint\"\n            [cxPopover]=\"detailHint\"\n            [cxPopoverOptions]=\"{\n              placement: 'auto',\n              class: 'hint-popover',\n              appendToBody: true,\n              displayCloseButton: true,\n            }\"\n            [attr.aria-label]=\"'organization.information' | cxTranslate\"\n            [attr.title]=\"'organization.information' | cxTranslate\"\n          >\n            <cx-icon [type]=\"iconTypes.INFO\"> </cx-icon>\n          </button>\n        </h3>\n        <h4>\n          {{\n            subtitle ||\n              (i18nRoot + '.subtitle' | cxTranslate: { item: item$ | async })\n          }}\n        </h4>\n      </div>\n      <div class=\"actions\">\n        <ng-content select=\"[actions]\"></ng-content>\n      </div>\n    </div>\n    <button\n      *ngIf=\"!!previous\"\n      class=\"link btn btn-link btn-sm close\"\n      [attr.aria-label]=\"'common.close' | cxTranslate\"\n      routerLink=\"../\"\n    >\n      <cx-icon\n        *ngIf=\"previous === true; else prevLabel\"\n        type=\"CLOSE\"\n        title=\"{{ 'common.close' | cxTranslate }}\"\n        (click)=\"closeView($event)\"\n      ></cx-icon>\n      <ng-template #prevLabel>{{ previousLabel | cxTranslate }}</ng-template>\n    </button>\n  </div>\n\n  <div class=\"main\">\n    <cx-org-message aria-live=\"assertive\"></cx-org-message>\n    <ng-content select=\"[info]\"></ng-content>\n    <ng-content select=\"[main]\"></ng-content>\n  </div>\n</cx-view>\n\n<router-outlet></router-outlet>\n\n<ng-template #detailHint>\n  <p>\n    {{ i18nRoot + '.hint' | cxTranslate }}\n  </p>\n</ng-template>\n", dependencies: [{ kind: "component", type: ViewComponent, selector: "cx-view", inputs: ["position", "hidden", "viewTitle"], outputs: ["hiddenChange"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: PopoverDirective, selector: "[cxPopover]", inputs: ["cxPopover", "cxPopoverOptions"], outputs: ["openPopover", "closePopover"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: MessageComponent, selector: "cx-org-message" }, { kind: "directive", type: RouterOutlet, selector: "router-outlet", inputs: ["name", "routerOutletData"], outputs: ["activate", "deactivate", "attach", "detach"], exportAs: ["outlet"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-card', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [MessageService], imports: [
                        ViewComponent,
                        NgIf,
                        PopoverDirective,
                        IconComponent,
                        RouterLink,
                        MessageComponent,
                        RouterOutlet,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<cx-view\n  [viewTitle]=\"i18nRoot + '.title' | cxTranslate: { item: item$ | async }\"\n  class=\"card\"\n  role=\"tabpanel\"\n  [attr.aria-labelledby]=\"i18nRoot + '_title'\"\n>\n  <div class=\"header\">\n    <div class=\"title-bar\">\n      <div class=\"title\">\n        <h3>\n          <span id=\"{{ i18nRoot + '_title' }}\">\n            {{ i18nRoot + '.title' | cxTranslate: { item: item$ | async } }}\n          </span>\n          <button\n            *ngIf=\"showHint\"\n            [cxPopover]=\"detailHint\"\n            [cxPopoverOptions]=\"{\n              placement: 'auto',\n              class: 'hint-popover',\n              appendToBody: true,\n              displayCloseButton: true,\n            }\"\n            [attr.aria-label]=\"'organization.information' | cxTranslate\"\n            [attr.title]=\"'organization.information' | cxTranslate\"\n          >\n            <cx-icon [type]=\"iconTypes.INFO\"> </cx-icon>\n          </button>\n        </h3>\n        <h4>\n          {{\n            subtitle ||\n              (i18nRoot + '.subtitle' | cxTranslate: { item: item$ | async })\n          }}\n        </h4>\n      </div>\n      <div class=\"actions\">\n        <ng-content select=\"[actions]\"></ng-content>\n      </div>\n    </div>\n    <button\n      *ngIf=\"!!previous\"\n      class=\"link btn btn-link btn-sm close\"\n      [attr.aria-label]=\"'common.close' | cxTranslate\"\n      routerLink=\"../\"\n    >\n      <cx-icon\n        *ngIf=\"previous === true; else prevLabel\"\n        type=\"CLOSE\"\n        title=\"{{ 'common.close' | cxTranslate }}\"\n        (click)=\"closeView($event)\"\n      ></cx-icon>\n      <ng-template #prevLabel>{{ previousLabel | cxTranslate }}</ng-template>\n    </button>\n  </div>\n\n  <div class=\"main\">\n    <cx-org-message aria-live=\"assertive\"></cx-org-message>\n    <ng-content select=\"[info]\"></ng-content>\n    <ng-content select=\"[main]\"></ng-content>\n  </div>\n</cx-view>\n\n<router-outlet></router-outlet>\n\n<ng-template #detailHint>\n  <p>\n    {{ i18nRoot + '.hint' | cxTranslate }}\n  </p>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: ItemService }, { type: MessageService }], propDecorators: { i18nRoot: [{
                type: Input
            }], previous: [{
                type: Input
            }], subtitle: [{
                type: Input
            }], showHint: [{
                type: Input
            }], view: [{
                type: ViewChild,
                args: [ViewComponent, { read: ViewComponent }]
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Provides a reusable card UI component for the organization split views.
 *
 * The component does not intend to provide a complete set of card features, it's just
 * a reusable component inside the organization UI.
 */
class CardModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CardModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CardModule, imports: [CommonModule,
            SplitViewModule,
            RouterModule,
            I18nModule,
            IconModule,
            UrlModule,
            MessageModule,
            PopoverModule,
            FeaturesConfigModule,
            CardComponent], exports: [CardComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CardModule, imports: [CommonModule,
            SplitViewModule,
            RouterModule,
            I18nModule,
            IconModule,
            UrlModule,
            MessageModule,
            PopoverModule,
            FeaturesConfigModule,
            CardComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CardModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        SplitViewModule,
                        RouterModule,
                        I18nModule,
                        IconModule,
                        UrlModule,
                        MessageModule,
                        PopoverModule,
                        FeaturesConfigModule,
                        CardComponent,
                    ],
                    exports: [CardComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ItemActiveDirective {
    constructor(itemService, messageService) {
        this.itemService = itemService;
        this.messageService = messageService;
    }
    ngOnInit() {
        this.subscription = this.itemService.current$
            .pipe(distinctUntilChanged((previous, current) => previous?.active === current?.active), filter(isNotNullable), filter((item) => item.active === false))
            .subscribe((item) => this.handleDisabledItems(item));
    }
    handleDisabledItems(item) {
        this.messageService.add({
            message: {
                key: 'organization.notification.disabled',
                params: { item },
            },
            type: GlobalMessageType.MSG_TYPE_ERROR,
        });
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ItemActiveDirective, deps: [{ token: ItemService }, { token: MessageService }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.19", type: ItemActiveDirective, isStandalone: true, selector: "[cxOrgItemActive]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ItemActiveDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[cxOrgItemActive]' }]
        }], ctorParameters: () => [{ type: ItemService }, { type: MessageService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ItemActiveModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ItemActiveModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: ItemActiveModule, imports: [CommonModule, ItemActiveDirective], exports: [ItemActiveDirective] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ItemActiveModule, imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ItemActiveModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, ItemActiveDirective],
                    exports: [ItemActiveDirective],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const DISABLED_STATUS = 'DISABLED';
/**
 * Reusable component for creating and editing organization items. The component does not
 * know anything about form specific.
 */
class FormComponent {
    constructor(itemService, messageService) {
        this.itemService = itemService;
        this.messageService = messageService;
        this.animateBack = true;
        this.form$ = this.itemService.current$.pipe(map((item) => {
            this.setI18nRoot(item);
            if (!item) {
                // we trick the form builder...
                item = {};
            }
            return this.itemService.getForm(item);
        }));
        /**
         * To handle the case of receiving a negative response during creation an item
         */
        this.disabled$ = this.form$.pipe(switchMap((form) => form?.statusChanges ?? EMPTY), map((status) => status === DISABLED_STATUS));
    }
    save(form) {
        this.itemService.key$
            .pipe(first(), switchMap((key) => this.itemService.save(form, key).pipe(take(1), map((data) => ({
            item: data.item,
            status: data.status,
            action: key ? 'update' : 'create',
        })))))
            .subscribe(({ item, action, status }) => {
            if (status === LoadStatus.SUCCESS) {
                this.itemService.launchDetails(item);
                this.notify(item, action);
            }
            form.enable();
        });
    }
    notify(item, action) {
        this.messageService?.add({
            message: {
                key: `${this.i18nRoot}.messages.${action}`,
                params: {
                    item,
                },
            },
        });
    }
    setI18nRoot(item) {
        // concatenate the i18n root with .edit or .create suffix
        this.i18n = this.i18nRoot + (item ? '.edit' : '.create');
    }
    back(event, card) {
        if (this.animateBack) {
            card.closeView(event);
        }
    }
    ngOnInit() {
        this.itemService.setEditMode(true);
    }
    ngOnDestroy() {
        this.itemService.setEditMode(false);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: FormComponent, deps: [{ token: ItemService }, { token: MessageService, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: FormComponent, isStandalone: true, selector: "cx-org-form", inputs: { i18nRoot: "i18nRoot", animateBack: "animateBack", subtitle: "subtitle" }, host: { classAttribute: "content-wrapper" }, ngImport: i0, template: "<form *ngIf=\"form$ | async as form\" (submit)=\"save(form)\">\n  <cx-org-card\n    #card\n    [previous]=\"false\"\n    [i18nRoot]=\"i18n\"\n    cxOrgItemActive\n    [subtitle]=\"subtitle\"\n    [cxFocus]=\"{ autofocus: 'input', refreshFocus: form }\"\n  >\n    <button\n      actions\n      class=\"button btn btn-sm primary btn-primary\"\n      [disabled]=\"form.disabled || (disabled$ | async)\"\n    >\n      {{ 'organization.save' | cxTranslate }}\n    </button>\n    <button\n      actions\n      class=\"link btn btn-link btn-sm\"\n      routerLink=\"../\"\n      type=\"button\"\n    >\n      <!--\n        We leverage the soft-close feature from the split view, so that the animation\n        has time to kick in before the router outlet is deleted.\n       -->\n      <span (click)=\"back($event, card)\">{{\n        'organization.cancel' | cxTranslate\n      }}</span>\n    </button>\n\n    <section main class=\"details\">\n      <ng-content select=\"[main]\" ngProjectAs=\"[main]\"></ng-content>\n    </section>\n  </cx-org-card>\n</form>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i4.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i4.NgForm, selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: CardComponent, selector: "cx-org-card", inputs: ["i18nRoot", "previous", "subtitle", "showHint"] }, { kind: "directive", type: ItemActiveDirective, selector: "[cxOrgItemActive]" }, { kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: FormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-form', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, imports: [
                        NgIf,
                        FormsModule,
                        CardComponent,
                        ItemActiveDirective,
                        FocusDirective,
                        RouterLink,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<form *ngIf=\"form$ | async as form\" (submit)=\"save(form)\">\n  <cx-org-card\n    #card\n    [previous]=\"false\"\n    [i18nRoot]=\"i18n\"\n    cxOrgItemActive\n    [subtitle]=\"subtitle\"\n    [cxFocus]=\"{ autofocus: 'input', refreshFocus: form }\"\n  >\n    <button\n      actions\n      class=\"button btn btn-sm primary btn-primary\"\n      [disabled]=\"form.disabled || (disabled$ | async)\"\n    >\n      {{ 'organization.save' | cxTranslate }}\n    </button>\n    <button\n      actions\n      class=\"link btn btn-link btn-sm\"\n      routerLink=\"../\"\n      type=\"button\"\n    >\n      <!--\n        We leverage the soft-close feature from the split view, so that the animation\n        has time to kick in before the router outlet is deleted.\n       -->\n      <span (click)=\"back($event, card)\">{{\n        'organization.cancel' | cxTranslate\n      }}</span>\n    </button>\n\n    <section main class=\"details\">\n      <ng-content select=\"[main]\" ngProjectAs=\"[main]\"></ng-content>\n    </section>\n  </cx-org-card>\n</form>\n" }]
        }], ctorParameters: () => [{ type: ItemService }, { type: MessageService, decorators: [{
                    type: Optional
                }] }], propDecorators: { i18nRoot: [{
                type: Input
            }], animateBack: [{
                type: Input
            }], subtitle: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class FormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: FormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: FormModule, imports: [CommonModule,
            FormsModule,
            I18nModule,
            RouterModule,
            CardModule,
            MessageModule,
            ItemActiveModule,
            KeyboardFocusModule,
            FormComponent], exports: [FormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: FormModule, imports: [CommonModule,
            FormsModule,
            I18nModule,
            RouterModule,
            CardModule,
            MessageModule,
            ItemActiveModule,
            KeyboardFocusModule,
            FormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: FormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        FormsModule,
                        I18nModule,
                        RouterModule,
                        CardModule,
                        MessageModule,
                        ItemActiveModule,
                        KeyboardFocusModule,
                        FormComponent,
                    ],
                    exports: [FormComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var CreateButtonType;
(function (CreateButtonType) {
    CreateButtonType["LINK"] = "LINK";
    CreateButtonType["BUTTON"] = "BUTTON";
})(CreateButtonType || (CreateButtonType = {}));
/**
 * The `ListService` deals with the table structure, list data and
 * pagination of tables inside the b2b organization.
 *
 * @property {OrganizationTableType} tableType
 *   Used to load the table structure configuration and generate table outlets.
 * @property {PaginationModel} pagination$
 *   The pagination state of the listing.
 */
class ListService {
    get viewType() {
        return this.tableType;
    }
    get domainType() {
        return this._domainType ?? this.viewType;
    }
    constructor(tableService) {
        this.tableService = tableService;
        /**
         * The default table structure is used to add the default configuration for all
         * organization list related tables. This avoids a lot of boilerplate configuration.
         */
        this.defaultTableStructure = {
            options: { layout: TableLayout.VERTICAL_STACKED },
            lg: { options: { layout: TableLayout.VERTICAL } },
        };
        /**
         * The ghost data contains an empty list of objects that is used in the UI
         * to render the HTML elements.
         *
         * This list contains 10 items, so that the ghost will show 10 rows by default.
         */
        this.ghostData = { values: new Array(10) };
        this.notification$ = new Subject();
        /**
         * The pagination state of the listing.
         *
         * The pagination size defaults to 10, but can be overridden by the
         * table configuration for each entity type.
         */
        this.pagination$ = new BehaviorSubject({
            pageSize: 10,
        });
        this.config = inject(OrganizationUIConfig);
    }
    /**
     * Indicates the unique key for the item model. The key is different for various
     * organizations, i.e. `budget.code`, `user.uid`.
     */
    key() {
        return 'code';
    }
    /**
     * Loads the data by delegating to the `load` method, which must be implemented
     * in specific implementations of this abstract class.
     *
     * The load method is streamed from the `pagination$` stream, which is initialized
     * with default pagination and structure drive properties.
     *
     * The ghostData is emitted before each load operation (initial load, search,
     * pagination, sort) to show a loading skeleton while waiting for the API response.
     */
    getData(...args) {
        return this.pagination$.pipe(
        // we merge any configured pagination from the table structure
        switchMap((pagination) => this.getStructure().pipe(map((config) => ({ ...pagination, ...config.options?.pagination })))), switchMap((pagination) => this.load(pagination, ...args).pipe(startWith(this.ghostData))));
    }
    /**
     * Returns the `TableStructure` for the `OrganizationTableType`.
     *
     * The table structure is build by the `TableService` based on configuration.
     * The `defaultTableStructure` is deep merged as a fallback configuration.
     */
    getStructure() {
        return this.tableService.buildStructure(this.viewType, this.defaultTableStructure);
    }
    /**
     * Views the page.
     */
    view(pagination, nextPage) {
        this.pagination$.next({ ...pagination, currentPage: nextPage });
    }
    /**
     * Updates the sort code for the PaginationModel.
     *
     * The `currentPage` is reset to 0.
     */
    sort(pagination, _obsoleteSort) {
        this.view(pagination, 0);
    }
    /**
     * Indicates whether the given data equals to the ghost data.
     *
     * This is used to validate the initial loading state, which is
     * different from the loading state; the loading state occurs
     * while sorting and paginating, where as the initial loading state
     * only happens at the very first load.
     */
    hasGhostData(data) {
        return data === this.ghostData;
    }
    /**
     * This method will return what kind of UI element to be used for create option in UI
     */
    getCreateButtonType() {
        return CreateButtonType.LINK;
    }
    /**
     * This method will be called when the button to create new item is clicked.
     */
    onCreateButtonClick() { }
    /**
     * This method will return the label for create button
     */
    getCreateButtonLabel() {
        return { key: 'organization.add' };
    }
    /**
     * Returns whether search functionality is enabled for this list.
     * Override in subclass to enable search.
     */
    isSearchEnabled() {
        return false;
    }
    /**
     * Returns the i18n key for the search input placeholder.
     * Override in subclass to provide a custom placeholder.
     */
    getSearchPlaceholderKey() {
        return 'organization.search.placeholder';
    }
    /**
     * Returns the minimum number of characters required to trigger a search.
     * This value can be configured via `organizationUI.listSearch.minCharacters`.
     * Override in subclass to customize.
     */
    getMinSearchCharacters() {
        return this.config.organizationUI?.listSearch?.minCharacters ?? 3;
    }
    /**
     * Search method to filter the list by query string.
     * Resets to first page when search query changes.
     */
    search(pagination, query) {
        this.pagination$.next({
            ...pagination,
            query,
            currentPage: 0,
        });
    }
    /**
     * Clears the search query and resets to first page.
     */
    clearSearch(pagination) {
        this.search(pagination, '');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ListService, deps: [{ token: i1$1.TableService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ListService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ListService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1$1.TableService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ListComponent {
    ngOnInit() {
        this.searchSubject$
            .pipe(debounceTime(300), filter(({ query }) => query.length >= this.minSearchCharacters || query.length === 0), distinctUntilChanged((prev, curr) => prev.query === curr.query), takeUntil(this.destroy$))
            .subscribe(({ pagination, query }) => {
            this.service.search(pagination, query);
        });
    }
    ngOnDestroy() {
        this.destroy$.next();
        this.destroy$.complete();
    }
    constructor(service, organizationItemService) {
        this.service = service;
        this.organizationItemService = organizationItemService;
        this.searchSubject$ = new Subject();
        this.destroy$ = new Subject();
        this.minSearchCharacters = this.service.getMinSearchCharacters();
        this.trapFocus = TrapFocus;
        this.hasGhostData = false;
        this.viewType = this.service.viewType;
        this.domainType = this.service.domainType;
        this.iconTypes = ICON_TYPE;
        this.createButtonAllTypes = CreateButtonType;
        this.createButtonType = this.service.getCreateButtonType();
        /**
         * Current search query value.
         */
        this.searchQuery = '';
        /**
         * Whether search is enabled for this list.
         */
        this.isSearchEnabled = this.service.isSearchEnabled();
        /**
         * The i18n key for the search input placeholder.
         */
        this.searchPlaceholderKey = this.service.getSearchPlaceholderKey();
        /**
         * The current key represents the current selected item from the dataset.
         * This key is used to load the item details as well as highlight the item in
         * a list of items.
         */
        this.currentKey$ = this.organizationItemService.key$;
        this.structure$ = this.service.getStructure();
        /**
         * Cached values from the last successful data load.
         * Used to display semi-transparent table during loading.
         */
        this.cachedValues = [];
        this.listData$ = this.service
            .getData()
            .pipe(tap((data) => {
            this.sortCode = data?.pagination?.sort;
            this.hasGhostData = this.service.hasGhostData(data);
            // Cache the values and total count when we have real data
            if (!this.hasGhostData && data?.values) {
                if (data.values.length >= 0) {
                    this.cachedValues = data.values;
                }
                if (data.pagination?.totalResults !== undefined) {
                    this.cachedTotalCount = data.pagination.totalResults;
                }
            }
        }));
        this.key = this.service.key();
        this.hideAddButton = false;
    }
    onSearchQueryChange(pagination, query) {
        if (pagination && this.isSearchEnabled) {
            this.searchSubject$.next({ pagination, query });
        }
    }
    /**
     * Returns the total number of items.
     */
    getListCount(dataTable) {
        return dataTable.pagination?.totalResults;
    }
    /**
     * Browses to the given page number
     */
    browse(pagination, pageNumber) {
        if (pagination) {
            this.service.view(pagination, pageNumber);
        }
    }
    /**
     * Navigates to the detailed view of the selected list item.
     */
    launchItem(event) {
        this.organizationItemService.launchDetails(event);
    }
    /**
     * Sorts the list.
     */
    sort(pagination) {
        if (pagination) {
            this.service.sort({
                ...pagination,
                ...{ sort: this.sortCode },
            });
        }
    }
    /**
     * Function to call when 'Manage Users' button is clicked
     */
    onCreateButtonClick() {
        this.service.onCreateButtonClick();
    }
    /**
     * Returns the label for Create button
     */
    getCreateButtonLabel() {
        return this.service.getCreateButtonLabel();
    }
    /**
     * Clears the search query and reloads the list.
     */
    clearSearch(pagination) {
        if (pagination) {
            this.searchQuery = '';
            this.service.clearSearch(pagination);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ListComponent, deps: [{ token: ListService }, { token: ItemService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: ListComponent, isStandalone: true, selector: "cx-org-list", inputs: { key: "key", hideAddButton: "hideAddButton" }, host: { properties: { "class": "this.viewType" } }, ngImport: i0, template: "<cx-split-view [hideMode]=\"false\">\n  <ng-container *ngIf=\"structure$ | async as structure\">\n    <cx-view\n      class=\"list\"\n      *ngIf=\"listData$ | async as data\"\n      role=\"region\"\n      [attr.aria-labelledby]=\"viewType + '_title'\"\n    >\n      <div class=\"header\">\n        <div aria-live=\"polite\" class=\"title\">\n          <h2>\n            <span id=\"{{ viewType + '_title' }}\">\n              {{\n                viewType + '.header'\n                  | cxTranslate\n                    : {\n                        count: hasGhostData\n                          ? cachedTotalCount\n                          : getListCount(data),\n                      }\n              }}\n            </span>\n            <button\n              [cxPopover]=\"listHint\"\n              [cxPopoverOptions]=\"{\n                placement: 'auto',\n                class: 'hint-popover',\n                appendToBody: true,\n                displayCloseButton: true,\n              }\"\n              [attr.aria-label]=\"\n                'organization.information'\n                  | cxTranslate\n                    : { title: viewType + '.groupName' | cxTranslate }\n              \"\n              [attr.title]=\"\n                'organization.information'\n                  | cxTranslate\n                    : { title: viewType + '.groupName' | cxTranslate }\n              \"\n            >\n              <cx-icon [type]=\"iconTypes.INFO\"> </cx-icon>\n            </button>\n          </h2>\n        </div>\n\n        <div class=\"actions\">\n          <!-- Search box -->\n          <div class=\"search-wrapper\" *ngIf=\"isSearchEnabled\">\n            <label class=\"search-label\">\n              <span class=\"label-text\">{{\n                'organization.search.label' | cxTranslate\n              }}</span>\n              <div class=\"input-wrapper\">\n                <input\n                  type=\"text\"\n                  class=\"form-control search-input\"\n                  [placeholder]=\"searchPlaceholderKey | cxTranslate\"\n                  [(ngModel)]=\"searchQuery\"\n                  (ngModelChange)=\"\n                    onSearchQueryChange($any(data.pagination), $event)\n                  \"\n                  [attr.aria-label]=\"'organization.search.label' | cxTranslate\"\n                />\n                <button\n                  *ngIf=\"!searchQuery\"\n                  type=\"button\"\n                  class=\"search-btn\"\n                  [attr.aria-label]=\"'organization.search.label' | cxTranslate\"\n                  [title]=\"'organization.search.label' | cxTranslate\"\n                >\n                  <cx-icon [type]=\"iconTypes.SEARCH\"></cx-icon>\n                </button>\n                <button\n                  *ngIf=\"searchQuery\"\n                  type=\"button\"\n                  class=\"search-clear\"\n                  (click)=\"clearSearch($any(data.pagination))\"\n                  [attr.aria-label]=\"'organization.search.clear' | cxTranslate\"\n                  [title]=\"'organization.search.clear' | cxTranslate\"\n                >\n                  <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n                </button>\n              </div>\n            </label>\n          </div>\n          <label\n            class=\"sort-wrapper\"\n            *ngIf=\"data.pagination?.sort\"\n            [class.disabled]=\"hasGhostData\"\n          >\n            <span class=\"label-text\">{{\n              structure.type + '.sortBy' | cxTranslate\n            }}</span>\n            <ng-select\n              name=\"sort\"\n              class=\"sort\"\n              [searchable]=\"false\"\n              [clearable]=\"false\"\n              [disabled]=\"hasGhostData\"\n              (change)=\"sort($any(data.pagination))\"\n              [tabIndex]=\"0\"\n              [(ngModel)]=\"sortCode\"\n              [attr.aria-label]=\"\n                (sortCode\n                  ? structure.type + '.sort.' + sortCode\n                  : structure.type + '.sortBy'\n                ) | cxTranslate\n              \"\n              ariaLabelDropdown=\"{{\n                'common.ngSelectDropdownOptionsList' | cxTranslate\n              }}\"\n            >\n              <ng-option *ngFor=\"let sort of data.sorts\" [value]=\"sort.code\">\n                {{ structure.type + '.sort.' + sort.code | cxTranslate }}\n              </ng-option>\n            </ng-select>\n          </label>\n\n          <ng-content select=\"[actions]\"></ng-content>\n\n          <ng-container\n            *ngIf=\"\n              createButtonType === createButtonAllTypes.LINK;\n              else showButton\n            \"\n          >\n            <a\n              *ngIf=\"!hideAddButton\"\n              class=\"button btn btn-sm primary btn-primary create\"\n              [class.disabled]=\"hasGhostData\"\n              [routerLink]=\"\n                hasGhostData\n                  ? null\n                  : ({ cxRoute: structure.type + 'Create' } | cxUrl)\n              \"\n              routerLinkActive=\"disabled\"\n            >\n              {{ getCreateButtonLabel() | cxTranslate }}\n            </a>\n          </ng-container>\n        </div>\n      </div>\n\n      <div class=\"cx-list-content\" [class.is-loading]=\"hasGhostData\">\n        <!-- Loading overlay with dots -->\n        <div class=\"cx-loading-overlay\" *ngIf=\"hasGhostData\">\n          <div class=\"cx-dots-loader\">\n            <span></span>\n            <span></span>\n            <span></span>\n          </div>\n        </div>\n\n        <!-- Show cached data as semi-transparent during loading -->\n        <cx-table\n          *ngIf=\"hasGhostData && cachedValues.length > 0\"\n          [structure]=\"structure\"\n          [data]=\"cachedValues\"\n          [i18nRoot]=\"domainType\"\n          role=\"tree\"\n        >\n        </cx-table>\n\n        <!-- List content when not loading -->\n        <cx-table\n          *ngIf=\"!hasGhostData && data.values && data.values.length > 0\"\n          [structure]=\"structure\"\n          [data]=\"data.values\"\n          [i18nRoot]=\"domainType\"\n          [currentItem]=\"{ property: key, value: currentKey$ | async }\"\n          (launch)=\"launchItem($event)\"\n          role=\"tree\"\n        >\n        </cx-table>\n\n        <!-- Empty list when not loading and no data -->\n        <ng-container\n          *ngIf=\"!hasGhostData && (!data.values || data.values.length === 0)\"\n        >\n          <ng-container\n            *ngIf=\"isSearchEnabled && searchQuery; else defaultEmpty\"\n          >\n            <cx-table\n              [structure]=\"structure\"\n              [data]=\"[]\"\n              [i18nRoot]=\"domainType\"\n              role=\"tree\"\n            >\n            </cx-table>\n            <p class=\"cx-no-results\">\n              {{ 'organization.search.noResultsFound' | cxTranslate }}\n            </p>\n          </ng-container>\n          <ng-template #defaultEmpty>\n            <p class=\"instruction is-empty\">\n              {{ 'organization.messages.emptyList' | cxTranslate }}\n            </p>\n          </ng-template>\n        </ng-container>\n      </div>\n\n      <div class=\"footer\">\n        <cx-pagination\n          [pagination]=\"data.pagination\"\n          (viewPageEvent)=\"browse($any(data.pagination), $event)\"\n        ></cx-pagination>\n      </div>\n    </cx-view>\n\n    <!-- nested split views are rendered inside child routes -->\n    <router-outlet></router-outlet>\n  </ng-container>\n</cx-split-view>\n\n<ng-template #listHint>\n  <p>\n    {{ viewType + '.hint' | cxTranslate }}\n  </p>\n</ng-template>\n\n<ng-template #showButton>\n  <button\n    *ngIf=\"!hideAddButton\"\n    class=\"button btn btn-sm primary btn-primary create\"\n    [disabled]=\"hasGhostData\"\n    (click)=\"onCreateButtonClick()\"\n  >\n    {{ getCreateButtonLabel() | cxTranslate }}\n  </button>\n</ng-template>\n", dependencies: [{ kind: "component", type: SplitViewComponent, selector: "cx-split-view", inputs: ["hideMode"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: ViewComponent, selector: "cx-view", inputs: ["position", "hidden", "viewTitle"], outputs: ["hiddenChange"] }, { kind: "directive", type: PopoverDirective, selector: "[cxPopover]", inputs: ["cxPopover", "cxPopoverOptions"], outputs: ["openPopover", "closePopover"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: NgOptionComponent, selector: "ng-option", inputs: ["value", "disabled"] }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: TableComponent, selector: "cx-table", inputs: ["structure", "data", "i18nRoot", "currentItem"], outputs: ["launch"] }, { kind: "component", type: PaginationComponent, selector: "cx-pagination", inputs: ["pageRoute", "queryParam", "defaultPage", "pagination", "paginationID"], outputs: ["viewPageEvent"] }, { kind: "directive", type: RouterOutlet, selector: "router-outlet", inputs: ["name", "routerOutletData"], outputs: ["activate", "deactivate", "attach", "detach"], exportAs: ["outlet"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-list', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        SplitViewComponent,
                        NgIf,
                        ViewComponent,
                        PopoverDirective,
                        IconComponent,
                        NgSelectComponent,
                        FormsModule,
                        NgFor,
                        NgOptionComponent,
                        RouterLinkActive,
                        RouterLink,
                        TableComponent,
                        PaginationComponent,
                        RouterOutlet,
                        AsyncPipe,
                        UrlPipe,
                        TranslatePipe,
                    ], template: "<cx-split-view [hideMode]=\"false\">\n  <ng-container *ngIf=\"structure$ | async as structure\">\n    <cx-view\n      class=\"list\"\n      *ngIf=\"listData$ | async as data\"\n      role=\"region\"\n      [attr.aria-labelledby]=\"viewType + '_title'\"\n    >\n      <div class=\"header\">\n        <div aria-live=\"polite\" class=\"title\">\n          <h2>\n            <span id=\"{{ viewType + '_title' }}\">\n              {{\n                viewType + '.header'\n                  | cxTranslate\n                    : {\n                        count: hasGhostData\n                          ? cachedTotalCount\n                          : getListCount(data),\n                      }\n              }}\n            </span>\n            <button\n              [cxPopover]=\"listHint\"\n              [cxPopoverOptions]=\"{\n                placement: 'auto',\n                class: 'hint-popover',\n                appendToBody: true,\n                displayCloseButton: true,\n              }\"\n              [attr.aria-label]=\"\n                'organization.information'\n                  | cxTranslate\n                    : { title: viewType + '.groupName' | cxTranslate }\n              \"\n              [attr.title]=\"\n                'organization.information'\n                  | cxTranslate\n                    : { title: viewType + '.groupName' | cxTranslate }\n              \"\n            >\n              <cx-icon [type]=\"iconTypes.INFO\"> </cx-icon>\n            </button>\n          </h2>\n        </div>\n\n        <div class=\"actions\">\n          <!-- Search box -->\n          <div class=\"search-wrapper\" *ngIf=\"isSearchEnabled\">\n            <label class=\"search-label\">\n              <span class=\"label-text\">{{\n                'organization.search.label' | cxTranslate\n              }}</span>\n              <div class=\"input-wrapper\">\n                <input\n                  type=\"text\"\n                  class=\"form-control search-input\"\n                  [placeholder]=\"searchPlaceholderKey | cxTranslate\"\n                  [(ngModel)]=\"searchQuery\"\n                  (ngModelChange)=\"\n                    onSearchQueryChange($any(data.pagination), $event)\n                  \"\n                  [attr.aria-label]=\"'organization.search.label' | cxTranslate\"\n                />\n                <button\n                  *ngIf=\"!searchQuery\"\n                  type=\"button\"\n                  class=\"search-btn\"\n                  [attr.aria-label]=\"'organization.search.label' | cxTranslate\"\n                  [title]=\"'organization.search.label' | cxTranslate\"\n                >\n                  <cx-icon [type]=\"iconTypes.SEARCH\"></cx-icon>\n                </button>\n                <button\n                  *ngIf=\"searchQuery\"\n                  type=\"button\"\n                  class=\"search-clear\"\n                  (click)=\"clearSearch($any(data.pagination))\"\n                  [attr.aria-label]=\"'organization.search.clear' | cxTranslate\"\n                  [title]=\"'organization.search.clear' | cxTranslate\"\n                >\n                  <cx-icon [type]=\"iconTypes.CLOSE\"></cx-icon>\n                </button>\n              </div>\n            </label>\n          </div>\n          <label\n            class=\"sort-wrapper\"\n            *ngIf=\"data.pagination?.sort\"\n            [class.disabled]=\"hasGhostData\"\n          >\n            <span class=\"label-text\">{{\n              structure.type + '.sortBy' | cxTranslate\n            }}</span>\n            <ng-select\n              name=\"sort\"\n              class=\"sort\"\n              [searchable]=\"false\"\n              [clearable]=\"false\"\n              [disabled]=\"hasGhostData\"\n              (change)=\"sort($any(data.pagination))\"\n              [tabIndex]=\"0\"\n              [(ngModel)]=\"sortCode\"\n              [attr.aria-label]=\"\n                (sortCode\n                  ? structure.type + '.sort.' + sortCode\n                  : structure.type + '.sortBy'\n                ) | cxTranslate\n              \"\n              ariaLabelDropdown=\"{{\n                'common.ngSelectDropdownOptionsList' | cxTranslate\n              }}\"\n            >\n              <ng-option *ngFor=\"let sort of data.sorts\" [value]=\"sort.code\">\n                {{ structure.type + '.sort.' + sort.code | cxTranslate }}\n              </ng-option>\n            </ng-select>\n          </label>\n\n          <ng-content select=\"[actions]\"></ng-content>\n\n          <ng-container\n            *ngIf=\"\n              createButtonType === createButtonAllTypes.LINK;\n              else showButton\n            \"\n          >\n            <a\n              *ngIf=\"!hideAddButton\"\n              class=\"button btn btn-sm primary btn-primary create\"\n              [class.disabled]=\"hasGhostData\"\n              [routerLink]=\"\n                hasGhostData\n                  ? null\n                  : ({ cxRoute: structure.type + 'Create' } | cxUrl)\n              \"\n              routerLinkActive=\"disabled\"\n            >\n              {{ getCreateButtonLabel() | cxTranslate }}\n            </a>\n          </ng-container>\n        </div>\n      </div>\n\n      <div class=\"cx-list-content\" [class.is-loading]=\"hasGhostData\">\n        <!-- Loading overlay with dots -->\n        <div class=\"cx-loading-overlay\" *ngIf=\"hasGhostData\">\n          <div class=\"cx-dots-loader\">\n            <span></span>\n            <span></span>\n            <span></span>\n          </div>\n        </div>\n\n        <!-- Show cached data as semi-transparent during loading -->\n        <cx-table\n          *ngIf=\"hasGhostData && cachedValues.length > 0\"\n          [structure]=\"structure\"\n          [data]=\"cachedValues\"\n          [i18nRoot]=\"domainType\"\n          role=\"tree\"\n        >\n        </cx-table>\n\n        <!-- List content when not loading -->\n        <cx-table\n          *ngIf=\"!hasGhostData && data.values && data.values.length > 0\"\n          [structure]=\"structure\"\n          [data]=\"data.values\"\n          [i18nRoot]=\"domainType\"\n          [currentItem]=\"{ property: key, value: currentKey$ | async }\"\n          (launch)=\"launchItem($event)\"\n          role=\"tree\"\n        >\n        </cx-table>\n\n        <!-- Empty list when not loading and no data -->\n        <ng-container\n          *ngIf=\"!hasGhostData && (!data.values || data.values.length === 0)\"\n        >\n          <ng-container\n            *ngIf=\"isSearchEnabled && searchQuery; else defaultEmpty\"\n          >\n            <cx-table\n              [structure]=\"structure\"\n              [data]=\"[]\"\n              [i18nRoot]=\"domainType\"\n              role=\"tree\"\n            >\n            </cx-table>\n            <p class=\"cx-no-results\">\n              {{ 'organization.search.noResultsFound' | cxTranslate }}\n            </p>\n          </ng-container>\n          <ng-template #defaultEmpty>\n            <p class=\"instruction is-empty\">\n              {{ 'organization.messages.emptyList' | cxTranslate }}\n            </p>\n          </ng-template>\n        </ng-container>\n      </div>\n\n      <div class=\"footer\">\n        <cx-pagination\n          [pagination]=\"data.pagination\"\n          (viewPageEvent)=\"browse($any(data.pagination), $event)\"\n        ></cx-pagination>\n      </div>\n    </cx-view>\n\n    <!-- nested split views are rendered inside child routes -->\n    <router-outlet></router-outlet>\n  </ng-container>\n</cx-split-view>\n\n<ng-template #listHint>\n  <p>\n    {{ viewType + '.hint' | cxTranslate }}\n  </p>\n</ng-template>\n\n<ng-template #showButton>\n  <button\n    *ngIf=\"!hideAddButton\"\n    class=\"button btn btn-sm primary btn-primary create\"\n    [disabled]=\"hasGhostData\"\n    (click)=\"onCreateButtonClick()\"\n  >\n    {{ getCreateButtonLabel() | cxTranslate }}\n  </button>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: ListService }, { type: ItemService }], propDecorators: { viewType: [{
                type: HostBinding,
                args: ['class']
            }], key: [{
                type: Input
            }], hideAddButton: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ListModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: ListModule, imports: [CommonModule,
            RouterModule,
            SplitViewModule,
            TableModule,
            IconModule,
            UrlModule,
            I18nModule,
            PaginationModule,
            NgSelectModule,
            FormsModule,
            MessageModule,
            KeyboardFocusModule,
            PopoverModule,
            FeaturesConfigModule,
            ListComponent], exports: [ListComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ListModule, imports: [CommonModule,
            RouterModule,
            SplitViewModule,
            TableModule,
            IconModule,
            UrlModule,
            I18nModule,
            PaginationModule,
            NgSelectModule,
            FormsModule,
            MessageModule,
            KeyboardFocusModule,
            PopoverModule,
            FeaturesConfigModule,
            ListComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        SplitViewModule,
                        TableModule,
                        IconModule,
                        UrlModule,
                        I18nModule,
                        PaginationModule,
                        NgSelectModule,
                        FormsModule,
                        MessageModule,
                        KeyboardFocusModule,
                        PopoverModule,
                        FeaturesConfigModule,
                        ListComponent,
                    ],
                    exports: [ListComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CellComponent {
    constructor(outlet) {
        this.outlet = outlet;
        this.changeDetectorRef = inject(ChangeDetectorRef);
        this.featureConfigService = inject(FeatureConfigService);
        this.destroyRef = inject(DestroyRef);
    }
    ngOnInit() {
        if (this.featureConfigService.isEnabled('a11yCardNotificationMessage')) {
            this.outlet.context$
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe((context) => {
                this.outlet.context = context;
                this.changeDetectorRef.markForCheck();
            });
        }
    }
    get tabIndex() {
        return -1;
    }
    get model() {
        return this.outlet.context;
    }
    get property() {
        return this.model?.[this.outlet?.context?._field];
    }
    /**
     * Indicates wether the cell is linkable.
     *
     * If the cells is linkable, an anchor link is created to the detailed route
     * of the given `_type`.
     *
     * Defaults to `false`.
     */
    get linkable() {
        return this.property !== undefined && (this.cellOptions.linkable ?? false);
    }
    /**
     * Helper method to access the cell options.
     */
    get cellOptions() {
        return (this.outlet.context?._options?.cells?.[this.outlet.context?._field] ?? {});
    }
    /**
     * Generates the configurable route to the detail page of the given context item.
     */
    get route() {
        return this.outlet.context._type + 'Details';
    }
    get routeModel() {
        return this.outlet.context;
    }
    get type() {
        return this.model._type;
    }
    /**
     * Indicates whether the item is loaded.
     */
    get hasItem() {
        return !!this.item && Object.keys(this.item).length > 0;
    }
    get item() {
        if (!this.outlet.context) {
            return null;
        }
        const { _field, _options, _type, _i18nRoot, ...all } = this.outlet.context;
        return all;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CellComponent, deps: [{ token: i1$1.OutletContextData }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CellComponent, isStandalone: true, selector: "cx-org-cell", ngImport: i0, template: "<a\n  *ngIf=\"linkable; else text\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  [tabIndex]=\"tabIndex\"\n>\n  <ng-container *ngTemplateOutlet=\"text\"></ng-container>\n</a>\n\n<ng-template #text>\n  <span class=\"text\" title=\"{{ property }}\">{{ property }}</span>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-cell', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, RouterLink, NgTemplateOutlet, UrlPipe], template: "<a\n  *ngIf=\"linkable; else text\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  [tabIndex]=\"tabIndex\"\n>\n  <ng-container *ngTemplateOutlet=\"text\"></ng-container>\n</a>\n\n<ng-template #text>\n  <span class=\"text\" title=\"{{ property }}\">{{ property }}</span>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1$1.OutletContextData }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AssignCellComponent extends CellComponent {
    constructor(outlet, organizationItemService, messageService, organizationSubListService) {
        super(outlet);
        this.outlet = outlet;
        this.organizationItemService = organizationItemService;
        this.messageService = messageService;
        this.organizationSubListService = organizationSubListService;
    }
    get isAssigned() {
        return this.item?.selected;
    }
    toggleAssign() {
        const isAssigned = this.isAssigned;
        this.organizationItemService.key$
            .pipe(first(), switchMap((key) => isAssigned
            ? this.unassign?.(key, this.link)
            : this.assign(key, this.link)), take(1), filter((data) => data.status === LoadStatus.SUCCESS))
            .subscribe((data) => this.notify(data.item, isAssigned ? 'unassigned' : 'assigned'));
    }
    assign(key, linkKey) {
        return (this.organizationSubListService.assign?.(key, linkKey) ?? EMPTY);
    }
    unassign(key, linkKey) {
        return (this.organizationSubListService.unassign?.(key, linkKey) ?? EMPTY);
    }
    /**
     * Returns the key for the linked object.
     *
     * At the moment, we're using a generic approach to assign objects,
     * but the object do not have a normalized shape. Therefor, we need
     * to evaluate the context to return the right key for the associated
     * item.
     */
    get link() {
        return (this.outlet.context.code ??
            this.outlet.context.customerId ??
            this.outlet.context.uid);
    }
    notify(item, state) {
        this.messageService.add({
            message: {
                key: `${this.organizationSubListService.viewType}.${state}`,
                params: {
                    item,
                },
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AssignCellComponent, deps: [{ token: i1$1.OutletContextData }, { token: ItemService }, { token: MessageService }, { token: ListService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: AssignCellComponent, isStandalone: true, selector: "cx-org-assign-cell", usesInheritance: true, ngImport: i0, template: `
    <button type="button" *ngIf="hasItem" (click)="toggleAssign()" class="link">
      {{ isAssigned ? 'unassign' : 'assign' }}
    </button>
  `, isInline: true, dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AssignCellComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'cx-org-assign-cell',
                    template: `
    <button type="button" *ngIf="hasItem" (click)="toggleAssign()" class="link">
      {{ isAssigned ? 'unassign' : 'assign' }}
    </button>
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [NgIf],
                }]
        }], ctorParameters: () => [{ type: i1$1.OutletContextData }, { type: ItemService }, { type: MessageService }, { type: ListService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubListComponent extends ListComponent {
    constructor() {
        super(...arguments);
        this.hostClass = '';
        this.previous = true;
        this.key = this.service.key();
        this.showHint = false;
        this.hasGhostData = false;
        this.listData$ = this.currentKey$.pipe(switchMap((key) => this.service.getData(key)), tap((data) => {
            this.hasGhostData = this.service.hasGhostData(data);
        }));
        this.dataStructure$ = this.service.getStructure();
    }
    set routerKey(key) {
        this.subKey$ = this.organizationItemService.getRouterParam(key);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: SubListComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: SubListComponent, isStandalone: true, selector: "cx-org-sub-list", inputs: { previous: "previous", key: "key", showHint: "showHint", routerKey: "routerKey" }, host: { properties: { "class.ghost": "this.hasGhostData" }, classAttribute: "content-wrapper" }, viewQueries: [{ propertyName: "messageService", first: true, predicate: MessageService, descendants: true, read: MessageService }], usesInheritance: true, ngImport: i0, template: "<cx-org-card\n  [previous]=\"previous\"\n  [i18nRoot]=\"viewType\"\n  [showHint]=\"showHint\"\n  [cxFocus]=\"{ autofocus: true }\"\n>\n  <ng-content select=\"[actions]\" ngProjectAs=\"[actions]\"></ng-content>\n  <ng-content select=\"[main]\" ngProjectAs=\"[main]\"></ng-content>\n  <ng-content select=\"[info]\" ngProjectAs=\"[info]\"></ng-content>\n\n  <ng-container main *ngIf=\"dataStructure$ | async as structure\">\n    <ng-container *ngIf=\"listData$ | async as data\">\n      <section>\n        <cx-table\n          *ngIf=\"data.values && data.values.length > 0; else emptyList\"\n          [structure]=\"structure\"\n          [data]=\"data.values\"\n          [i18nRoot]=\"domainType\"\n          [currentItem]=\"{ property: key, value: subKey$ | async }\"\n        >\n        </cx-table>\n      </section>\n\n      <div\n        class=\"footer\"\n        *ngIf=\"\n          data.pagination &&\n          data.pagination.totalPages !== undefined &&\n          data.pagination.totalPages > 1\n        \"\n      >\n        <cx-pagination\n          [pagination]=\"data.pagination\"\n          (viewPageEvent)=\"browse(data.pagination, $event)\"\n        ></cx-pagination>\n      </div>\n    </ng-container>\n  </ng-container>\n</cx-org-card>\n\n<ng-template #emptyList>\n  <p class=\"is-empty\">{{ 'organization.messages.emptyList' | cxTranslate }}</p>\n</ng-template>\n", dependencies: [{ kind: "component", type: CardComponent, selector: "cx-org-card", inputs: ["i18nRoot", "previous", "subtitle", "showHint"] }, { kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: TableComponent, selector: "cx-table", inputs: ["structure", "data", "i18nRoot", "currentItem"], outputs: ["launch"] }, { kind: "component", type: PaginationComponent, selector: "cx-pagination", inputs: ["pageRoute", "queryParam", "defaultPage", "pagination", "paginationID"], outputs: ["viewPageEvent"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: SubListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-sub-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, imports: [
                        CardComponent,
                        FocusDirective,
                        NgIf,
                        TableComponent,
                        PaginationComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<cx-org-card\n  [previous]=\"previous\"\n  [i18nRoot]=\"viewType\"\n  [showHint]=\"showHint\"\n  [cxFocus]=\"{ autofocus: true }\"\n>\n  <ng-content select=\"[actions]\" ngProjectAs=\"[actions]\"></ng-content>\n  <ng-content select=\"[main]\" ngProjectAs=\"[main]\"></ng-content>\n  <ng-content select=\"[info]\" ngProjectAs=\"[info]\"></ng-content>\n\n  <ng-container main *ngIf=\"dataStructure$ | async as structure\">\n    <ng-container *ngIf=\"listData$ | async as data\">\n      <section>\n        <cx-table\n          *ngIf=\"data.values && data.values.length > 0; else emptyList\"\n          [structure]=\"structure\"\n          [data]=\"data.values\"\n          [i18nRoot]=\"domainType\"\n          [currentItem]=\"{ property: key, value: subKey$ | async }\"\n        >\n        </cx-table>\n      </section>\n\n      <div\n        class=\"footer\"\n        *ngIf=\"\n          data.pagination &&\n          data.pagination.totalPages !== undefined &&\n          data.pagination.totalPages > 1\n        \"\n      >\n        <cx-pagination\n          [pagination]=\"data.pagination\"\n          (viewPageEvent)=\"browse(data.pagination, $event)\"\n        ></cx-pagination>\n      </div>\n    </ng-container>\n  </ng-container>\n</cx-org-card>\n\n<ng-template #emptyList>\n  <p class=\"is-empty\">{{ 'organization.messages.emptyList' | cxTranslate }}</p>\n</ng-template>\n" }]
        }], propDecorators: { messageService: [{
                type: ViewChild,
                args: [MessageService, { read: MessageService }]
            }], previous: [{
                type: Input
            }], key: [{
                type: Input
            }], showHint: [{
                type: Input
            }], routerKey: [{
                type: Input
            }], hasGhostData: [{
                type: HostBinding,
                args: ['class.ghost']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubListModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: SubListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: SubListModule, imports: [CommonModule,
            I18nModule,
            CardModule,
            TableModule,
            PaginationModule,
            MessageModule,
            KeyboardFocusModule,
            SubListComponent,
            AssignCellComponent], exports: [SubListComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: SubListModule, imports: [CommonModule,
            I18nModule,
            CardModule,
            TableModule,
            PaginationModule,
            MessageModule,
            KeyboardFocusModule,
            SubListComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: SubListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        CardModule,
                        TableModule,
                        PaginationModule,
                        MessageModule,
                        KeyboardFocusModule,
                        SubListComponent,
                        AssignCellComponent,
                    ],
                    exports: [SubListComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SharedOrganizationModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: SharedOrganizationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: SharedOrganizationModule, imports: [ListModule, SubListModule, FormModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: SharedOrganizationModule, imports: [ListModule, SubListModule, FormModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: SharedOrganizationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [ListModule, SubListModule, FormModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
// This is not for the public API
// TODO:#my-account-architecture - Number.MAX_VALUE?
const MAX_OCC_INTEGER_VALUE = 2147483647;

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ItemExistsDirective {
    constructor(itemService, messageService) {
        this.itemService = itemService;
        this.messageService = messageService;
    }
    ngOnInit() {
        this.subscription = this.itemService.error$
            .pipe(filter((error) => error))
            .subscribe(() => this.handleErrorMessage());
    }
    handleErrorMessage() {
        this.messageService.add({
            message: {
                key: 'organization.notification.notExist',
            },
            type: GlobalMessageType.MSG_TYPE_ERROR,
        });
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ItemExistsDirective, deps: [{ token: ItemService }, { token: MessageService }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.19", type: ItemExistsDirective, isStandalone: true, selector: "[cxOrgItemExists]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ItemExistsDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[cxOrgItemExists]' }]
        }], ctorParameters: () => [{ type: ItemService }, { type: MessageService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Renders a confirmation message and cancel/confirm button in the message component.
 */
class ConfirmationMessageComponent extends BaseMessageComponent {
    constructor(data, platformId, messageService) {
        super(data, platformId);
        this.data = data;
        this.platformId = platformId;
        this.messageService = messageService;
        this.cancelText = {
            key: 'organization.confirmation.cancel',
        };
        this.confirmText = {
            key: 'organization.confirmation.confirm',
        };
    }
    ngOnInit() {
        super.ngOnInit();
        this.cancelText = this.messageData.cancel ?? this.cancelText;
        this.confirmText = this.messageData.confirm ?? this.confirmText;
    }
    /**
     * Emits a confirmation event to the data events.
     *
     * The original author of the event message or other parties can observe
     * the event data.
     */
    confirm() {
        this.data.events?.next({ confirm: true });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ConfirmationMessageComponent, deps: [{ token: MessageData }, { token: PLATFORM_ID }, { token: MessageService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: ConfirmationMessageComponent, isStandalone: true, selector: "cx-org-confirmation", usesInheritance: true, ngImport: i0, template: "<div class=\"inner\" [cxFocus]=\"{ focusOnEscape: true }\" (esc)=\"close()\">\n  <p class=\"messageTitle\" *ngIf=\"messageTitle\">\n    {{ messageTitle | cxTranslate }}\n  </p>\n  <div class=\"message\">\n    <cx-icon *ngIf=\"messageIcon\" [type]=\"messageIcon\"></cx-icon>\n    <p>\n      {{ message | cxTranslate }}\n    </p>\n  </div>\n  <div class=\"actions\" [cxFocus]=\"{ autofocus: 'button.primary' }\">\n    <button class=\"button btn btn-sm cancel\" (click)=\"close()\">\n      {{ cancelText | cxTranslate }}\n    </button>\n\n    <button\n      class=\"button btn btn-sm primary btn-primary confirm\"\n      (click)=\"confirm()\"\n    >\n      {{ confirmText | cxTranslate }}\n    </button>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ConfirmationMessageComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-confirmation', changeDetection: ChangeDetectionStrategy.OnPush, imports: [FocusDirective, NgIf, IconComponent, TranslatePipe], template: "<div class=\"inner\" [cxFocus]=\"{ focusOnEscape: true }\" (esc)=\"close()\">\n  <p class=\"messageTitle\" *ngIf=\"messageTitle\">\n    {{ messageTitle | cxTranslate }}\n  </p>\n  <div class=\"message\">\n    <cx-icon *ngIf=\"messageIcon\" [type]=\"messageIcon\"></cx-icon>\n    <p>\n      {{ message | cxTranslate }}\n    </p>\n  </div>\n  <div class=\"actions\" [cxFocus]=\"{ autofocus: 'button.primary' }\">\n    <button class=\"button btn btn-sm cancel\" (click)=\"close()\">\n      {{ cancelText | cxTranslate }}\n    </button>\n\n    <button\n      class=\"button btn btn-sm primary btn-primary confirm\"\n      (click)=\"confirm()\"\n    >\n      {{ confirmText | cxTranslate }}\n    </button>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [{ type: MessageData }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }, { type: MessageService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DisableInfoService {
    isItemDisabled(item) {
        return item?.active === false;
    }
    isParentDisabled(item) {
        return ((item.orgUnit || item.unit || item.parentOrgUnit)?.active === false &&
            !this.isRootUnit(item));
    }
    isRootUnit(item) {
        return Boolean(item?.uid &&
            item?.name &&
            !item?.orgUnit &&
            !item?.unit &&
            (!item?.parentOrgUnit || item?.uid === item?.parentOrgUnit));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DisableInfoService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DisableInfoService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DisableInfoService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Reusable component in the my-company is to toggle the disabled state for
 * my company entities.
 */
class ToggleStatusComponent {
    constructor(itemService, messageService, disableInfoService) {
        this.itemService = itemService;
        this.messageService = messageService;
        this.disableInfoService = disableInfoService;
        /**
         * The key input can be used to add a custom key.
         *
         * Most _organization_ entities use the `code` key, but there is some variations.
         */
        this.key = 'code';
        /**
         * resolves the current item.
         */
        this.current$ = this.itemService.current$;
        /**
         * resolves if the user is currently in the edit form.
         */
        this.isInEditMode$ = this.itemService.isInEditMode$;
        this.subscription = new Subscription();
    }
    toggle(item) {
        if (!item.active) {
            // we do ask for confirmation when the entity gets activated
            this.update(item);
        }
        else {
            if (!this.confirmation) {
                this.confirmation = this.messageService.add({
                    message: {
                        key: this.i18nRoot + '.messages.deactivate',
                        params: { item },
                    },
                    messageTitle: {
                        key: this.i18nRoot + '.messages.deactivateTitle',
                        params: { item },
                    },
                    confirm: {
                        key: 'organization.confirmation.disable',
                    },
                    component: ConfirmationMessageComponent,
                });
                this.subscription.add(this.confirmation.pipe(first()).subscribe((event) => {
                    if (event.close) {
                        this.confirmation = null;
                    }
                    if (event.confirm) {
                        this.messageService.close(this.confirmation);
                        this.update(item);
                        this.confirmation = null;
                    }
                }));
            }
        }
    }
    /**
     * Indicates whether the status can be toggled or not.
     */
    isDisabled(item) {
        return (this.disabled ??
            (this.disableInfoService.isParentDisabled(item) ||
                this.disableInfoService.isRootUnit(item)));
    }
    update(item) {
        this.itemService
            .update(item[this.key], this.getPatchedItem(item))
            .pipe(take(1), filter((data) => data.status === LoadStatus.SUCCESS))
            .subscribe((data) => this.notify({ ...item, ...data.item }));
    }
    getPatchedItem(item) {
        const patch = {};
        Object.assign(patch, { [this.key]: item[this.key] });
        patch.active = !item.active;
        return patch;
    }
    notify(item) {
        this.messageService.add({
            message: {
                key: `${this.i18nRoot}.messages.${item.active ? 'confirmEnabled' : 'confirmDisabled'}`,
                params: { item },
            },
        });
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ToggleStatusComponent, deps: [{ token: ItemService }, { token: MessageService }, { token: DisableInfoService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: ToggleStatusComponent, isStandalone: true, selector: "cx-org-toggle-status", inputs: { i18nRoot: "i18nRoot", key: "key", disabled: "disabled" }, host: { classAttribute: "content-wrapper" }, ngImport: i0, template: "<button\n  *ngIf=\"current$ | async as item\"\n  class=\"button btn btn-sm active\"\n  [disabled]=\"\n    isDisabled(item) ||\n    ((isInEditMode$ | async) && item.active && disabled !== true)\n  \"\n  (click)=\"toggle(item)\"\n>\n  {{ 'organization.' + (item.active ? 'disable' : 'enable') | cxTranslate }}\n</button>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ToggleStatusComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-toggle-status', host: { class: 'content-wrapper' }, imports: [NgIf, AsyncPipe, TranslatePipe], template: "<button\n  *ngIf=\"current$ | async as item\"\n  class=\"button btn btn-sm active\"\n  [disabled]=\"\n    isDisabled(item) ||\n    ((isInEditMode$ | async) && item.active && disabled !== true)\n  \"\n  (click)=\"toggle(item)\"\n>\n  {{ 'organization.' + (item.active ? 'disable' : 'enable') | cxTranslate }}\n</button>\n" }]
        }], ctorParameters: () => [{ type: ItemService }, { type: MessageService }, { type: DisableInfoService }], propDecorators: { i18nRoot: [{
                type: Input
            }], key: [{
                type: Input
            }], disabled: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ConfirmationMessageModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ConfirmationMessageModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: ConfirmationMessageModule, imports: [CommonModule,
            I18nModule,
            IconModule,
            KeyboardFocusModule,
            ConfirmationMessageComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ConfirmationMessageModule, imports: [CommonModule,
            I18nModule,
            IconModule,
            KeyboardFocusModule,
            ConfirmationMessageComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ConfirmationMessageModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        IconModule,
                        KeyboardFocusModule,
                        ConfirmationMessageComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ToggleStatusModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ToggleStatusModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: ToggleStatusModule, imports: [CommonModule,
            I18nModule,
            MessageModule,
            ConfirmationMessageModule,
            ToggleStatusComponent], exports: [ToggleStatusComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ToggleStatusModule, imports: [CommonModule,
            I18nModule,
            MessageModule,
            ConfirmationMessageModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ToggleStatusModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        MessageModule,
                        ConfirmationMessageModule,
                        ToggleStatusComponent,
                    ],
                    exports: [ToggleStatusComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Reusable component in the my-company is to delete an item (if it's possible)
 */
class DeleteItemComponent {
    constructor(itemService, messageService) {
        this.itemService = itemService;
        this.messageService = messageService;
        /**
         * The key input can be used to add a custom key.
         *
         * Most _organization_ entities use the `code` key, but there is some variations.
         */
        this.key = 'code';
        /**
         * resolves the current item.
         */
        this.current$ = this.itemService.current$;
        /**
         * resolves if the user is currently in the edit form.
         */
        this.isInEditMode$ = this.itemService.isInEditMode$;
        this.subscription = new Subscription();
    }
    delete(item) {
        if (!this.confirmation) {
            this.confirmation = this.messageService.add({
                message: {
                    key: this.i18nRoot + '.messages.delete',
                    params: { item },
                },
                messageTitle: {
                    key: this.i18nRoot + '.messages.deleteTitle',
                    params: { item },
                },
                component: ConfirmationMessageComponent,
            });
            this.subscription.add(this.confirmation.pipe(first()).subscribe((event) => {
                if (event.close) {
                    this.confirmation = null;
                }
                if (event.confirm) {
                    this.messageService.close(this.confirmation);
                    this.confirmDelete(item);
                    this.confirmation = null;
                }
            }));
        }
    }
    confirmDelete(item) {
        this.itemService
            .delete?.(item[this.key], this.additionalParam)
            .pipe(take(1), filter((data) => data.status === LoadStatus.SUCCESS))
            .subscribe((data) => this.notify({ ...item, ...data.item }));
    }
    notify(item) {
        this.messageService.add({
            message: {
                key: `${this.i18nRoot}.messages.deleted`,
                params: { item },
            },
        });
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DeleteItemComponent, deps: [{ token: ItemService }, { token: MessageService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: DeleteItemComponent, isStandalone: true, selector: "cx-org-delete-item", inputs: { i18nRoot: "i18nRoot", key: "key", additionalParam: "additionalParam" }, host: { classAttribute: "content-wrapper" }, ngImport: i0, template: "<button\n  *ngIf=\"current$ | async as item\"\n  class=\"button btn btn-sm active\"\n  [disabled]=\"isInEditMode$ | async\"\n  (click)=\"delete(item)\"\n>\n  {{ 'organization.delete' | cxTranslate }}\n</button>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DeleteItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-delete-item', host: { class: 'content-wrapper' }, imports: [NgIf, AsyncPipe, TranslatePipe], template: "<button\n  *ngIf=\"current$ | async as item\"\n  class=\"button btn btn-sm active\"\n  [disabled]=\"isInEditMode$ | async\"\n  (click)=\"delete(item)\"\n>\n  {{ 'organization.delete' | cxTranslate }}\n</button>\n" }]
        }], ctorParameters: () => [{ type: ItemService }, { type: MessageService }], propDecorators: { i18nRoot: [{
                type: Input
            }], key: [{
                type: Input
            }], additionalParam: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DeleteItemModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DeleteItemModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: DeleteItemModule, imports: [CommonModule,
            I18nModule,
            MessageModule,
            ConfirmationMessageModule,
            DeleteItemComponent], exports: [DeleteItemComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DeleteItemModule, imports: [CommonModule,
            I18nModule,
            MessageModule,
            ConfirmationMessageModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DeleteItemModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        MessageModule,
                        ConfirmationMessageModule,
                        DeleteItemComponent,
                    ],
                    exports: [DeleteItemComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DisableInfoComponent {
    constructor(itemService, disableInfoService) {
        this.itemService = itemService;
        this.disableInfoService = disableInfoService;
        /**
         * Flag to enable display custom message(s) even if no condition has been met
         */
        this.displayCustomInfo = false;
        /**
         * resolves the current item.
         */
        this.current$ = this.itemService.current$;
        this.iconTypes = ICON_TYPE;
    }
    get defaultInfoConfig() {
        return {
            disabledCreate: false,
            disabledEdit: true,
            disabledEnable: true,
            disabledDisable: false,
        };
    }
    ngOnInit() {
        this.displayInfoConfig = {
            ...this.defaultInfoConfig,
            ...this.displayInfoConfig,
        };
    }
    displayDisabledCreate(item) {
        return (this.displayInfoConfig?.disabledCreate &&
            this.disableInfoService.isItemDisabled(item));
    }
    displayDisabledEdit(item) {
        return (this.displayInfoConfig?.disabledEdit &&
            this.disableInfoService.isItemDisabled(item));
    }
    displayDisabledEnable(item) {
        return (this.displayInfoConfig?.disabledEnable &&
            this.disableInfoService.isParentDisabled(item));
    }
    displayDisabledDisable(item) {
        return (this.displayInfoConfig?.disabledDisable &&
            this.disableInfoService.isRootUnit(item));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DisableInfoComponent, deps: [{ token: ItemService }, { token: DisableInfoService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: DisableInfoComponent, isStandalone: true, selector: "cx-org-disable-info", inputs: { i18nRoot: "i18nRoot", displayInfoConfig: "displayInfoConfig", displayCustomInfo: "displayCustomInfo" }, host: { classAttribute: "content-wrapper" }, ngImport: i0, template: "<ng-container *ngIf=\"current$ | async as item\">\n  <section\n    *ngIf=\"\n      displayDisabledCreate(item) ||\n      displayDisabledEdit(item) ||\n      displayDisabledEnable(item) ||\n      displayDisabledDisable(item) ||\n      displayCustomInfo\n    \"\n  >\n    <cx-icon [type]=\"iconTypes.INFO\"></cx-icon>\n    <ul>\n      <li *ngIf=\"displayDisabledEnable(item)\">\n        {{ i18nRoot + '.info.disabledEnable' | cxTranslate }}\n      </li>\n      <li *ngIf=\"displayDisabledCreate(item)\">\n        {{ i18nRoot + '.info.disabledCreate' | cxTranslate }}\n      </li>\n      <li *ngIf=\"displayDisabledEdit(item)\">\n        {{ i18nRoot + '.info.disabledEdit' | cxTranslate }}\n      </li>\n      <li *ngIf=\"displayDisabledDisable(item)\">\n        {{ i18nRoot + '.info.disabledDisable' | cxTranslate }}\n      </li>\n      <ng-content></ng-content>\n    </ul>\n  </section>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DisableInfoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-disable-info', host: { class: 'content-wrapper' }, imports: [NgIf, IconComponent, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"current$ | async as item\">\n  <section\n    *ngIf=\"\n      displayDisabledCreate(item) ||\n      displayDisabledEdit(item) ||\n      displayDisabledEnable(item) ||\n      displayDisabledDisable(item) ||\n      displayCustomInfo\n    \"\n  >\n    <cx-icon [type]=\"iconTypes.INFO\"></cx-icon>\n    <ul>\n      <li *ngIf=\"displayDisabledEnable(item)\">\n        {{ i18nRoot + '.info.disabledEnable' | cxTranslate }}\n      </li>\n      <li *ngIf=\"displayDisabledCreate(item)\">\n        {{ i18nRoot + '.info.disabledCreate' | cxTranslate }}\n      </li>\n      <li *ngIf=\"displayDisabledEdit(item)\">\n        {{ i18nRoot + '.info.disabledEdit' | cxTranslate }}\n      </li>\n      <li *ngIf=\"displayDisabledDisable(item)\">\n        {{ i18nRoot + '.info.disabledDisable' | cxTranslate }}\n      </li>\n      <ng-content></ng-content>\n    </ul>\n  </section>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: ItemService }, { type: DisableInfoService }], propDecorators: { i18nRoot: [{
                type: Input
            }], displayInfoConfig: [{
                type: Input
            }], displayCustomInfo: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DisableInfoModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DisableInfoModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: DisableInfoModule, imports: [CommonModule, IconModule, I18nModule, DisableInfoComponent], exports: [DisableInfoComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DisableInfoModule, imports: [CommonModule, IconModule, I18nModule, DisableInfoComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DisableInfoModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, IconModule, I18nModule, DisableInfoComponent],
                    exports: [DisableInfoComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubListService extends ListService {
    constructor() {
        super(...arguments);
        /**
         * The default table structure for sub lists is only showing tables with vertical layout.
         */
        this.defaultTableStructure = {
            options: { layout: TableLayout.VERTICAL },
        };
        /**
         * @override This sub list will show 3 items.
         */
        this.ghostData = { values: new Array(3) };
    }
    // TODO: abstract
    assign(_key, ..._args) {
        return EMPTY;
    }
    unassign(_key, ..._args) {
        return EMPTY;
    }
    /**
     * As we can't filter with the backend API, we do this client side.
     */
    filterSelected(list) {
        if (!list) {
            return list;
        }
        const { pagination, sorts, values } = list;
        return {
            pagination,
            sorts,
            values: values.filter((value) => value.selected),
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: SubListService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: SubListService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: SubListService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ActiveLinkCellComponent extends CellComponent {
    get tabIndex() {
        return 0;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ActiveLinkCellComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: ActiveLinkCellComponent, isStandalone: true, selector: "cx-org-active-link-cell", usesInheritance: true, ngImport: i0, template: "<a\n  *ngIf=\"linkable; else text\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  [tabIndex]=\"tabIndex\"\n>\n  <ng-container *ngTemplateOutlet=\"text\"></ng-container>\n</a>\n\n<ng-template #text>\n  <span class=\"text\" title=\"{{ property }}\">{{ property }}</span>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ActiveLinkCellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-active-link-cell', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, RouterLink, NgTemplateOutlet, UrlPipe], template: "<a\n  *ngIf=\"linkable; else text\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  [tabIndex]=\"tabIndex\"\n>\n  <ng-container *ngTemplateOutlet=\"text\"></ng-container>\n</a>\n\n<ng-template #text>\n  <span class=\"text\" title=\"{{ property }}\">{{ property }}</span>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AmountCellComponent extends CellComponent {
    get property() {
        if (this.budget && this.currency) {
            return this.budget + ' ' + this.currency;
        }
        return undefined;
    }
    get budget() {
        return this.model.budget;
    }
    get currency() {
        return this.model.currency?.isocode || this.model.currency;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AmountCellComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: AmountCellComponent, isStandalone: true, selector: "cx-org-amount-cell", usesInheritance: true, ngImport: i0, template: "<a\n  *ngIf=\"linkable; else text\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  [tabIndex]=\"tabIndex\"\n>\n  <ng-container *ngTemplateOutlet=\"text\"></ng-container>\n</a>\n\n<ng-template #text>\n  <span class=\"text\" title=\"{{ property }}\">{{ property }}</span>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AmountCellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-amount-cell', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, RouterLink, NgTemplateOutlet, UrlPipe], template: "<a\n  *ngIf=\"linkable; else text\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  [tabIndex]=\"tabIndex\"\n>\n  <ng-container *ngTemplateOutlet=\"text\"></ng-container>\n</a>\n\n<ng-template #text>\n  <span class=\"text\" title=\"{{ property }}\">{{ property }}</span>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DateRangeCellComponent extends CellComponent {
    get linkable() {
        return this.hasRange && (this.cellOptions.linkable ?? false);
    }
    get hasRange() {
        return !!this.model.startDate && !!this.model.endDate;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DateRangeCellComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: DateRangeCellComponent, isStandalone: true, selector: "cx-org-date-range-cell", usesInheritance: true, ngImport: i0, template: "<a\n  *ngIf=\"linkable; else text\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  [tabindex]=\"tabIndex\"\n>\n  <ng-container *ngTemplateOutlet=\"text\"></ng-container>\n</a>\n\n<ng-template #text>\n  <span\n    class=\"text\"\n    title=\"{{ model.startDate | cxDate }} - {{ model.endDate | cxDate }}\"\n    *ngIf=\"hasRange\"\n  >\n    {{ model.startDate | cxDate }} - {{ model.endDate | cxDate }}\n  </span>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: CxDatePipe, name: "cxDate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: DateRangeCellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-date-range-cell', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, RouterLink, NgTemplateOutlet, UrlPipe, CxDatePipe], template: "<a\n  *ngIf=\"linkable; else text\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  [tabindex]=\"tabIndex\"\n>\n  <ng-container *ngTemplateOutlet=\"text\"></ng-container>\n</a>\n\n<ng-template #text>\n  <span\n    class=\"text\"\n    title=\"{{ model.startDate | cxDate }} - {{ model.endDate | cxDate }}\"\n    *ngIf=\"hasRange\"\n  >\n    {{ model.startDate | cxDate }} - {{ model.endDate | cxDate }}\n  </span>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class LimitCellComponent extends CellComponent {
    get isTimeSpanThreshold() {
        return (this.model.orderApprovalPermissionType?.code ===
            'B2BOrderThresholdTimespanPermission');
    }
    get isOrderThreshold() {
        return (this.model.orderApprovalPermissionType?.code ===
            'B2BOrderThresholdPermission');
    }
    get isExceedPermission() {
        return (this.model.orderApprovalPermissionType?.code ===
            'B2BBudgetExceededPermission');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: LimitCellComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: LimitCellComponent, isStandalone: true, selector: "cx-org-limit-cell", usesInheritance: true, ngImport: i0, template: "<a\n  *ngIf=\"linkable; else threshold\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  [tabindex]=\"tabIndex\"\n>\n  <ng-container *ngTemplateOutlet=\"threshold\"></ng-container>\n</a>\n\n<ng-template #threshold>\n  <span\n    class=\"text\"\n    title=\"{{ model.threshold }} {{ model.currency?.symbol }} {{\n      'orgPurchaseLimit.per.' + model.periodRange | cxTranslate\n    }}\"\n    *ngIf=\"isTimeSpanThreshold\"\n  >\n    {{ model.threshold }} {{ model.currency?.symbol }}\n    {{ 'orgPurchaseLimit.per.' + model.periodRange | cxTranslate }}\n  </span>\n\n  <span\n    class=\"text\"\n    title=\"{{ model.threshold }} {{ model.currency?.symbol }}\"\n    *ngIf=\"isOrderThreshold\"\n  >\n    {{ model.threshold }} {{ model.currency?.symbol }}\n  </span>\n\n  <span\n    class=\"text\"\n    title=\"{{ model.orderApprovalPermissionType.name }}\"\n    *ngIf=\"isExceedPermission\"\n  >\n    {{ model.orderApprovalPermissionType.name }}\n  </span>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: LimitCellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-limit-cell', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, RouterLink, NgTemplateOutlet, UrlPipe, TranslatePipe], template: "<a\n  *ngIf=\"linkable; else threshold\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  [tabindex]=\"tabIndex\"\n>\n  <ng-container *ngTemplateOutlet=\"threshold\"></ng-container>\n</a>\n\n<ng-template #threshold>\n  <span\n    class=\"text\"\n    title=\"{{ model.threshold }} {{ model.currency?.symbol }} {{\n      'orgPurchaseLimit.per.' + model.periodRange | cxTranslate\n    }}\"\n    *ngIf=\"isTimeSpanThreshold\"\n  >\n    {{ model.threshold }} {{ model.currency?.symbol }}\n    {{ 'orgPurchaseLimit.per.' + model.periodRange | cxTranslate }}\n  </span>\n\n  <span\n    class=\"text\"\n    title=\"{{ model.threshold }} {{ model.currency?.symbol }}\"\n    *ngIf=\"isOrderThreshold\"\n  >\n    {{ model.threshold }} {{ model.currency?.symbol }}\n  </span>\n\n  <span\n    class=\"text\"\n    title=\"{{ model.orderApprovalPermissionType.name }}\"\n    *ngIf=\"isExceedPermission\"\n  >\n    {{ model.orderApprovalPermissionType.name }}\n  </span>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class RolesCellComponent extends CellComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RolesCellComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: RolesCellComponent, isStandalone: true, selector: "cx-org-roles-cell", usesInheritance: true, ngImport: i0, template: "<a\n  *ngIf=\"linkable; else text\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  [tabindex]=\"tabIndex\"\n>\n  <ng-container *ngTemplateOutlet=\"text\"></ng-container>\n</a>\n\n<ng-template #text>\n  <ul class=\"text\">\n    <li\n      *ngFor=\"let role of model.roles\"\n      class=\"li\"\n      [innerText]=\"'organization.userRoles.' + role | cxTranslate\"\n    ></li>\n    <li *ngIf=\"model.roles?.length === 0\">-</li>\n  </ul>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: RolesCellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-roles-cell', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, RouterLink, NgTemplateOutlet, NgFor, UrlPipe, TranslatePipe], template: "<a\n  *ngIf=\"linkable; else text\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  [tabindex]=\"tabIndex\"\n>\n  <ng-container *ngTemplateOutlet=\"text\"></ng-container>\n</a>\n\n<ng-template #text>\n  <ul class=\"text\">\n    <li\n      *ngFor=\"let role of model.roles\"\n      class=\"li\"\n      [innerText]=\"'organization.userRoles.' + role | cxTranslate\"\n    ></li>\n    <li *ngIf=\"model.roles?.length === 0\">-</li>\n  </ul>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class StatusCellComponent extends CellComponent {
    get label() {
        if (this.isActive === undefined) {
            return;
        }
        return this.isActive ? 'organization.enabled' : 'organization.disabled';
    }
    get isActive() {
        return this.model.active;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: StatusCellComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: StatusCellComponent, isStandalone: true, selector: "cx-org-status-cell", usesInheritance: true, ngImport: i0, template: "<a\n  *ngIf=\"linkable; else text\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  [tabindex]=\"tabIndex\"\n>\n  <ng-container *ngTemplateOutlet=\"text\"></ng-container>\n</a>\n\n<ng-template #text>\n  <span\n    class=\"text\"\n    title=\"{{ label | cxTranslate }}\"\n    [class.is-active]=\"isActive\"\n    *ngIf=\"label\"\n  >\n    {{ label | cxTranslate }}</span\n  >\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: StatusCellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-status-cell', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, RouterLink, NgTemplateOutlet, UrlPipe, TranslatePipe], template: "<a\n  *ngIf=\"linkable; else text\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  [tabindex]=\"tabIndex\"\n>\n  <ng-container *ngTemplateOutlet=\"text\"></ng-container>\n</a>\n\n<ng-template #text>\n  <span\n    class=\"text\"\n    title=\"{{ label | cxTranslate }}\"\n    [class.is-active]=\"isActive\"\n    *ngIf=\"label\"\n  >\n    {{ label | cxTranslate }}</span\n  >\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitCellComponent extends CellComponent {
    get property() {
        return this.model.unit?.name ?? this.model.orgUnit?.name;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCellComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitCellComponent, isStandalone: true, selector: "cx-org-unit-cell", usesInheritance: true, ngImport: i0, template: "<a\n  *ngIf=\"linkable; else text\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  [tabIndex]=\"tabIndex\"\n>\n  <ng-container *ngTemplateOutlet=\"text\"></ng-container>\n</a>\n\n<ng-template #text>\n  <span class=\"text\" title=\"{{ property }}\">{{ property }}</span>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-unit-cell', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, RouterLink, NgTemplateOutlet, UrlPipe], template: "<a\n  *ngIf=\"linkable; else text\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  [tabIndex]=\"tabIndex\"\n>\n  <ng-container *ngTemplateOutlet=\"text\"></ng-container>\n</a>\n\n<ng-template #text>\n  <span class=\"text\" title=\"{{ property }}\">{{ property }}</span>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CellModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CellModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CellModule, imports: [CommonModule,
            RouterModule,
            UrlModule,
            I18nModule,
            IconModule,
            CellComponent,
            ActiveLinkCellComponent,
            AmountCellComponent,
            DateRangeCellComponent,
            LimitCellComponent,
            RolesCellComponent,
            StatusCellComponent,
            UnitCellComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CellModule, imports: [CommonModule,
            RouterModule,
            UrlModule,
            I18nModule,
            IconModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CellModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        IconModule,
                        CellComponent,
                        ActiveLinkCellComponent,
                        AmountCellComponent,
                        DateRangeCellComponent,
                        LimitCellComponent,
                        RolesCellComponent,
                        StatusCellComponent,
                        UnitCellComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var OrganizationTableType;
(function (OrganizationTableType) {
    OrganizationTableType["BUDGET"] = "orgBudget";
    OrganizationTableType["BUDGET_ASSIGNED_COST_CENTERS"] = "orgBudgetAssignedCostCenters";
    OrganizationTableType["COST_CENTER"] = "orgCostCenter";
    OrganizationTableType["COST_CENTER_BUDGETS"] = "orgCostCenterBudgets";
    OrganizationTableType["COST_CENTER_ASSIGNED_BUDGETS"] = "orgCostCenterAssignedBudgets";
    OrganizationTableType["UNIT"] = "orgUnit";
    OrganizationTableType["UNIT_USERS"] = "orgUnitUsers";
    OrganizationTableType["UNIT_CHILDREN"] = "orgUnitChildren";
    OrganizationTableType["UNIT_APPROVERS"] = "orgUnitApprovers";
    OrganizationTableType["UNIT_ASSIGNED_APPROVERS"] = "orgUnitAssignedApprovers";
    OrganizationTableType["UNIT_ADDRESS"] = "orgUnitAddress";
    OrganizationTableType["UNIT_COST_CENTERS"] = "orgUnitCostCenters";
    OrganizationTableType["USER_GROUP"] = "orgUserGroup";
    OrganizationTableType["USER_GROUP_USERS"] = "orgUserGroupUsers";
    OrganizationTableType["USER_GROUP_ASSIGNED_USERS"] = "orgUserGroupAssignedUsers";
    OrganizationTableType["USER_GROUP_PERMISSIONS"] = "orgUserGroupPermissions";
    OrganizationTableType["USER_GROUP_ASSIGNED_PERMISSIONS"] = "orgUserGroupAssignedPermissions";
    OrganizationTableType["USER"] = "orgUser";
    OrganizationTableType["USER_APPROVERS"] = "orgUserApprovers";
    OrganizationTableType["USER_ASSIGNED_APPROVERS"] = "orgUserAssignedApprovers";
    OrganizationTableType["USER_PERMISSIONS"] = "orgUserPermissions";
    OrganizationTableType["USER_ASSIGNED_PERMISSIONS"] = "orgUserAssignedPermissions";
    OrganizationTableType["USER_USER_GROUPS"] = "orgUserUserGroups";
    OrganizationTableType["USER_ASSIGNED_USER_GROUPS"] = "orgUserAssignedUserGroups";
    OrganizationTableType["PERMISSION"] = "orgPurchaseLimit";
})(OrganizationTableType || (OrganizationTableType = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CostCenterDetailsCellComponent extends CellComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterDetailsCellComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CostCenterDetailsCellComponent, isStandalone: true, selector: "cx-org-cost-center-details-cell", usesInheritance: true, ngImport: i0, template: "<ng-template #details>\n  <div class=\"popover-details\">\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.name' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgCostCenterDetails',\n            params: model,\n          } | cxUrl\n        \"\n      >\n        {{ model.name }}\n      </a>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.code' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.code }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.active' | cxTranslate }}</label>\n      <span\n        class=\"value\"\n        [class.is-active]=\"model.active\"\n        [class.is-inactive]=\"!model.active\"\n      >\n        {{\n          (model.active ? 'organization.enabled' : 'organization.disabled')\n            | cxTranslate\n        }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.currency' | cxTranslate }}</label>\n\n      <span class=\"value\">\n        {{ model.currency?.isocode }}\n      </span>\n    </div>\n\n    <div class=\"property\" *ngIf=\"model.unit\">\n      <label>{{ 'orgCostCenter.unit' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.unit,\n          } | cxUrl\n        \"\n      >\n        {{ model.unit?.name }}\n      </a>\n    </div>\n  </div>\n</ng-template>\n\n<button\n  class=\"button btn btn-sm text\"\n  [cxPopover]=\"details\"\n  [cxPopoverOptions]=\"{\n    placement: 'auto',\n    class: 'my-company-popover',\n    appendToBody: true,\n    displayCloseButton: true,\n  }\"\n>\n  {{ model.name }}\n</button>\n", dependencies: [{ kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: PopoverDirective, selector: "[cxPopover]", inputs: ["cxPopover", "cxPopoverOptions"], outputs: ["openPopover", "closePopover"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterDetailsCellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-cost-center-details-cell', changeDetection: ChangeDetectionStrategy.OnPush, imports: [RouterLink, NgIf, PopoverDirective, TranslatePipe, UrlPipe], template: "<ng-template #details>\n  <div class=\"popover-details\">\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.name' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgCostCenterDetails',\n            params: model,\n          } | cxUrl\n        \"\n      >\n        {{ model.name }}\n      </a>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.code' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.code }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.active' | cxTranslate }}</label>\n      <span\n        class=\"value\"\n        [class.is-active]=\"model.active\"\n        [class.is-inactive]=\"!model.active\"\n      >\n        {{\n          (model.active ? 'organization.enabled' : 'organization.disabled')\n            | cxTranslate\n        }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.currency' | cxTranslate }}</label>\n\n      <span class=\"value\">\n        {{ model.currency?.isocode }}\n      </span>\n    </div>\n\n    <div class=\"property\" *ngIf=\"model.unit\">\n      <label>{{ 'orgCostCenter.unit' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.unit,\n          } | cxUrl\n        \"\n      >\n        {{ model.unit?.name }}\n      </a>\n    </div>\n  </div>\n</ng-template>\n\n<button\n  class=\"button btn btn-sm text\"\n  [cxPopover]=\"details\"\n  [cxPopoverOptions]=\"{\n    placement: 'auto',\n    class: 'my-company-popover',\n    appendToBody: true,\n    displayCloseButton: true,\n  }\"\n>\n  {{ model.name }}\n</button>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class BudgetCostCenterListService extends SubListService {
    constructor(tableService, budgetService) {
        super(tableService);
        this.tableService = tableService;
        this.budgetService = budgetService;
        this.tableType = OrganizationTableType.BUDGET_ASSIGNED_COST_CENTERS;
        this._domainType = OrganizationTableType.COST_CENTER;
    }
    load(_pagination, code) {
        return this.budgetService.getCostCenters(code).pipe(filter((list) => Boolean(list)), map((costCenter) => this.filterSelected(costCenter)));
    }
    /**
     * As we can't filter with the backend API, we do this client side.
     */
    filterSelected({ pagination, sorts, values, }) {
        return {
            pagination,
            sorts,
            values: values.filter((value) => value.active),
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetCostCenterListService, deps: [{ token: i1$1.TableService }, { token: i2.BudgetService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetCostCenterListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetCostCenterListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.BudgetService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class BudgetCostCenterListComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetCostCenterListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: BudgetCostCenterListComponent, isStandalone: true, selector: "cx-org-budget-cost-center-list", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: BudgetCostCenterListService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list></cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetCostCenterListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-budget-cost-center-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: BudgetCostCenterListService,
                        },
                    ], imports: [SubListComponent], template: "<cx-org-sub-list></cx-org-sub-list>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CurrentBudgetService extends CurrentItemService {
    constructor(routingService, budgetService) {
        super(routingService);
        this.routingService = routingService;
        this.budgetService = budgetService;
    }
    getDetailsRoute() {
        return 'orgBudgetDetails';
    }
    getParamKey() {
        return ROUTE_PARAMS.budgetCode;
    }
    getItem(code) {
        return this.budgetService.get(code);
    }
    getError(code) {
        return this.budgetService.getErrorState(code);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentBudgetService, deps: [{ token: i1.RoutingService }, { token: i2.BudgetService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentBudgetService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentBudgetService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.RoutingService }, { type: i2.BudgetService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class BudgetFormService extends FormService {
    constructor(datePickerService) {
        super();
        this.datePickerService = datePickerService;
    }
    build() {
        const form = new UntypedFormGroup({});
        form.setControl('code', new UntypedFormControl('', [
            Validators.required,
            CustomFormValidators.noSpecialCharacters,
        ]));
        form.setControl('name', new UntypedFormControl('', Validators.required));
        form.setControl('startDate', new UntypedFormControl('', [
            Validators.required,
            CustomFormValidators.patternValidation((date) => this.datePickerService.isValidFormat(date)),
        ]));
        form.setControl('endDate', new UntypedFormControl('', [
            Validators.required,
            CustomFormValidators.patternValidation((date) => this.datePickerService.isValidFormat(date)),
        ]));
        form.setControl('budget', new UntypedFormControl('', [
            Validators.required,
            CustomFormValidators.mustBePositive,
        ]));
        form.setControl('currency', new UntypedFormGroup({
            isocode: new UntypedFormControl(undefined, Validators.required),
        }));
        form.setControl('orgUnit', new UntypedFormGroup({
            uid: new UntypedFormControl(undefined, Validators.required),
        }));
        form.setValidators(CustomFormValidators.dateRange('startDate', 'endDate', (date) => this.datePickerService.getDate(date)));
        this.form = form;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetFormService, deps: [{ token: i1$1.DatePickerService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetFormService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetFormService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.DatePickerService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class BudgetItemService extends ItemService {
    constructor(currentItemService, routingService, formService, budgetService) {
        super(currentItemService, routingService, formService);
        this.currentItemService = currentItemService;
        this.routingService = routingService;
        this.formService = formService;
        this.budgetService = budgetService;
    }
    /**
     * @override
     * Returns the budget for the given code.
     *
     * Loads the budget each time, to ensure accurate data is resolved.
     */
    load(code) {
        this.budgetService.loadBudget(code);
        return this.budgetService.get(code);
    }
    update(code, value) {
        this.budgetService.update(code, value);
        return this.budgetService.getLoadingStatus(value.code ?? '');
    }
    create(value) {
        this.budgetService.create(value);
        return this.budgetService.getLoadingStatus(value.code ?? '');
    }
    /**
     * @override
     * Returns 'budgetDetails'
     */
    getDetailsRoute() {
        return 'orgBudgetDetails';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetItemService, deps: [{ token: CurrentBudgetService }, { token: i1.RoutingService }, { token: BudgetFormService }, { token: i2.BudgetService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetItemService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetItemService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: CurrentBudgetService }, { type: i1.RoutingService }, { type: BudgetFormService }, { type: i2.BudgetService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class BudgetDetailsComponent {
    ngOnInit() {
        this.model$ = this.itemService.key$.pipe(switchMap((code) => this.itemService.load(code)), startWith({}));
    }
    constructor(itemService) {
        this.itemService = itemService;
        this.isInEditMode$ = this.itemService.isInEditMode$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetDetailsComponent, deps: [{ token: ItemService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: BudgetDetailsComponent, isStandalone: true, selector: "cx-org-budget-details", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ItemService,
                useExisting: BudgetItemService,
            },
        ], ngImport: i0, template: "<cx-org-card\n  *ngIf=\"model$ | async as model\"\n  i18nRoot=\"orgBudget.details\"\n  [cxFocus]=\"{ refreshFocus: model }\"\n>\n  <a\n    actions\n    class=\"link btn btn-link btn-sm edit\"\n    [class.disabled]=\"!model.active || (isInEditMode$ | async)\"\n    [routerLink]=\"{ cxRoute: 'orgBudgetEdit', params: model } | cxUrl\"\n  >\n    {{ 'organization.edit' | cxTranslate }}\n  </a>\n\n  <cx-org-toggle-status actions i18nRoot=\"orgBudget\"></cx-org-toggle-status>\n\n  <cx-org-disable-info info i18nRoot=\"orgBudget\"> </cx-org-disable-info>\n\n  <section main class=\"details\" cxOrgItemExists>\n    <div class=\"property\">\n      <label>{{ 'orgBudget.name' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.name }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.code' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.code }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.startDate' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.startDate | cxDate }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.endDate' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.endDate | cxDate }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.active' | cxTranslate }}</label>\n      <span class=\"value\" [class.is-active]=\"model.active\">\n        {{\n          (model.active ? 'organization.enabled' : 'organization.disabled')\n            | cxTranslate\n        }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.amount' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.budget }} {{ model.currency?.isocode }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.unit' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.orgUnit,\n          } | cxUrl\n        \"\n      >\n        {{ model.orgUnit?.name }}\n      </a>\n    </div>\n  </section>\n\n  <section main class=\"link-list\">\n    <a\n      *ngIf=\"model.code\"\n      class=\"link\"\n      [routerLink]=\"{ cxRoute: 'orgBudgetCostCenters', params: model } | cxUrl\"\n      routerLinkActive=\"is-current\"\n    >\n      {{ 'orgBudget.links.costCenters' | cxTranslate }}\n    </a>\n  </section>\n</cx-org-card>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CardComponent, selector: "cx-org-card", inputs: ["i18nRoot", "previous", "subtitle", "showHint"] }, { kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: ToggleStatusComponent, selector: "cx-org-toggle-status", inputs: ["i18nRoot", "key", "disabled"] }, { kind: "component", type: DisableInfoComponent, selector: "cx-org-disable-info", inputs: ["i18nRoot", "displayInfoConfig", "displayCustomInfo"] }, { kind: "directive", type: ItemExistsDirective, selector: "[cxOrgItemExists]" }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: CxDatePipe, name: "cxDate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-budget-details', changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: ItemService,
                            useExisting: BudgetItemService,
                        },
                    ], host: { class: 'content-wrapper' }, imports: [
                        NgIf,
                        CardComponent,
                        FocusDirective,
                        RouterLink,
                        ToggleStatusComponent,
                        DisableInfoComponent,
                        ItemExistsDirective,
                        RouterLinkActive,
                        AsyncPipe,
                        UrlPipe,
                        TranslatePipe,
                        CxDatePipe,
                    ], template: "<cx-org-card\n  *ngIf=\"model$ | async as model\"\n  i18nRoot=\"orgBudget.details\"\n  [cxFocus]=\"{ refreshFocus: model }\"\n>\n  <a\n    actions\n    class=\"link btn btn-link btn-sm edit\"\n    [class.disabled]=\"!model.active || (isInEditMode$ | async)\"\n    [routerLink]=\"{ cxRoute: 'orgBudgetEdit', params: model } | cxUrl\"\n  >\n    {{ 'organization.edit' | cxTranslate }}\n  </a>\n\n  <cx-org-toggle-status actions i18nRoot=\"orgBudget\"></cx-org-toggle-status>\n\n  <cx-org-disable-info info i18nRoot=\"orgBudget\"> </cx-org-disable-info>\n\n  <section main class=\"details\" cxOrgItemExists>\n    <div class=\"property\">\n      <label>{{ 'orgBudget.name' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.name }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.code' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.code }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.startDate' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.startDate | cxDate }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.endDate' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.endDate | cxDate }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.active' | cxTranslate }}</label>\n      <span class=\"value\" [class.is-active]=\"model.active\">\n        {{\n          (model.active ? 'organization.enabled' : 'organization.disabled')\n            | cxTranslate\n        }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.amount' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.budget }} {{ model.currency?.isocode }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.unit' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.orgUnit,\n          } | cxUrl\n        \"\n      >\n        {{ model.orgUnit?.name }}\n      </a>\n    </div>\n  </section>\n\n  <section main class=\"link-list\">\n    <a\n      *ngIf=\"model.code\"\n      class=\"link\"\n      [routerLink]=\"{ cxRoute: 'orgBudgetCostCenters', params: model } | cxUrl\"\n      routerLinkActive=\"is-current\"\n    >\n      {{ 'orgBudget.links.costCenters' | cxTranslate }}\n    </a>\n  </section>\n</cx-org-card>\n" }]
        }], ctorParameters: () => [{ type: ItemService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
function createCodeForEntityName(name, code) {
    if (!code?.value) {
        const codeFromName = name?.value?.replace(/\s+/g, '-').toLowerCase();
        code?.patchValue(codeFromName);
    }
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class BudgetFormComponent {
    constructor(itemService, unitService, currencyService) {
        this.itemService = itemService;
        this.unitService = unitService;
        this.currencyService = currencyService;
        this.form = this.itemService.getForm();
        this.units$ = this.unitService
            .getActiveUnitList()
            .pipe(tap((units) => {
            if (units && units.length === 1) {
                this.form?.get('orgUnit.uid')?.setValue(units[0]?.id);
            }
        }));
        this.currencies$ = this.currencyService.getAll().pipe(tap((currency) => {
            if (currency.length === 1) {
                this.form?.get('currency.isocode')?.setValue(currency[0]?.isocode);
            }
        }));
    }
    ngOnInit() {
        this.unitService.loadList();
    }
    createCodeWithName(name, code) {
        createCodeForEntityName(name, code);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetFormComponent, deps: [{ token: ItemService }, { token: i2.OrgUnitService }, { token: i1.CurrencyService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: BudgetFormComponent, isStandalone: true, selector: "cx-org-budget-form", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ItemService,
                useExisting: BudgetItemService,
            },
            {
                provide: CurrentItemService,
                useExisting: CurrentBudgetService,
            },
        ], ngImport: i0, template: "<cx-org-form i18nRoot=\"orgBudget\">\n  <ng-container *ngIf=\"form\" [formGroup]=\"form\" main>\n    <cx-form-required-legend />\n    <label>\n      <span class=\"label-content required\">\n        {{ 'orgBudget.name' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        required\n        placeholder=\"{{ 'orgBudget.name' | cxTranslate }}\"\n        formControlName=\"name\"\n        (blur)=\"createCodeWithName(form.get('name'), form.get('code'))\"\n        [attr.aria-invalid]=\"\n          form.get('name')?.touched && form.get('name')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'nameError'\"\n      />\n\n      <cx-form-errors\n        id=\"nameError\"\n        [translationParams]=\"{\n          label: 'orgBudget.name' | cxTranslate,\n        }\"\n        [control]=\"form.get('name')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\">\n        {{ 'orgBudget.code' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        class=\"form-control\"\n        type=\"text\"\n        required\n        placeholder=\"{{ 'orgBudget.code' | cxTranslate }}\"\n        formControlName=\"code\"\n        [attr.aria-invalid]=\"\n          form.get('code')?.touched && form.get('code')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'codeError'\"\n      />\n\n      <cx-form-errors\n        id=\"codeError\"\n        [translationParams]=\"{\n          label: 'orgBudget.code' | cxTranslate,\n        }\"\n        [control]=\"form.get('code')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">\n        {{ 'orgBudget.startDate' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <cx-date-picker\n        [control]=\"$any(form.get('startDate'))\"\n        [max]=\"form.get('endDate')?.value\"\n        [required]=\"true\"\n        (update)=\"form.get('endDate')?.updateValueAndValidity()\"\n        label=\"orgBudget.startDate\"\n      ></cx-date-picker>\n    </label>\n\n    <label>\n      <span class=\"label-content\">\n        {{ 'orgBudget.endDate' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n\n      <cx-date-picker\n        [control]=\"$any(form.get('endDate'))\"\n        [min]=\"form.get('startDate')?.value\"\n        [required]=\"true\"\n        (update)=\"form.get('startDate')?.updateValueAndValidity()\"\n        label=\"orgBudget.endDate\"\n      ></cx-date-picker>\n    </label>\n\n    <label [formGroup]=\"$any(form.get('currency'))\">\n      <span class=\"label-content required\">{{\n        'orgBudget.currency' | cxTranslate\n      }}</span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"isocode\"\n        [attr.aria-invalid]=\"\n          form.get('isocode')?.touched && form.get('isocode')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'isocodeError'\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"(currencies$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"isocode\"\n        [class.invalid]=\"form.get('currency.isocode')?.invalid ?? false\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgBudget.currency' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        id=\"isocodeError\"\n        [translationParams]=\"{\n          label: 'orgBudget.currency' | cxTranslate,\n        }\"\n        [control]=\"form.get('currency.isocode')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">\n        {{ 'orgBudget.amount' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"number\"\n        class=\"form-control\"\n        placeholder=\"{{ 'orgBudget.amount' | cxTranslate }}\"\n        formControlName=\"budget\"\n        min=\"0\"\n        [attr.aria-invalid]=\"\n          form.get('budget')?.touched && form.get('budget')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'budgetError'\"\n      />\n\n      <cx-form-errors\n        id=\"budgetError\"\n        [translationParams]=\"{\n          label: 'orgBudget.amount' | cxTranslate,\n        }\"\n        [control]=\"form.get('budget')\"\n      ></cx-form-errors>\n    </label>\n\n    <label\n      *ngIf=\"units$ | async as units\"\n      [formGroup]=\"$any(form.get('orgUnit'))\"\n    >\n      <span class=\"label-content required\">\n        {{ 'orgBudget.businessUnits' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"uid\"\n        [attr.aria-invalid]=\"\n          form.get('uid')?.touched && form.get('uid')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'uidError'\"\n        [searchable]=\"true\"\n        [clearable]=\"false\"\n        [items]=\"units\"\n        bindLabel=\"name\"\n        bindValue=\"id\"\n        [readonly]=\"form.get('orgUnit.uid')?.disabled ?? false\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgBudget.businessUnits' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        id=\"uidError\"\n        [translationParams]=\"{\n          label: 'orgBudget.businessUnits' | cxTranslate,\n        }\"\n        [control]=\"form.get('orgUnit.uid')\"\n      ></cx-form-errors>\n    </label>\n  </ng-container>\n</cx-org-form>\n", dependencies: [{ kind: "component", type: FormComponent, selector: "cx-org-form", inputs: ["i18nRoot", "animateBack", "subtitle"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i4.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i4.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i4.MinValidator, selector: "input[type=number][min][formControlName],input[type=number][min][formControl],input[type=number][min][ngModel]", inputs: ["min"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i4.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i4.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "component", type: DatePickerComponent, selector: "cx-date-picker", inputs: ["control", "min", "max", "required", "label"], outputs: ["update"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-budget-form', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ItemService,
                            useExisting: BudgetItemService,
                        },
                        {
                            provide: CurrentItemService,
                            useExisting: CurrentBudgetService,
                        },
                    ], imports: [
                        FormComponent,
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredLegendComponent,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        DatePickerComponent,
                        NgSelectComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<cx-org-form i18nRoot=\"orgBudget\">\n  <ng-container *ngIf=\"form\" [formGroup]=\"form\" main>\n    <cx-form-required-legend />\n    <label>\n      <span class=\"label-content required\">\n        {{ 'orgBudget.name' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        required\n        placeholder=\"{{ 'orgBudget.name' | cxTranslate }}\"\n        formControlName=\"name\"\n        (blur)=\"createCodeWithName(form.get('name'), form.get('code'))\"\n        [attr.aria-invalid]=\"\n          form.get('name')?.touched && form.get('name')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'nameError'\"\n      />\n\n      <cx-form-errors\n        id=\"nameError\"\n        [translationParams]=\"{\n          label: 'orgBudget.name' | cxTranslate,\n        }\"\n        [control]=\"form.get('name')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\">\n        {{ 'orgBudget.code' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        class=\"form-control\"\n        type=\"text\"\n        required\n        placeholder=\"{{ 'orgBudget.code' | cxTranslate }}\"\n        formControlName=\"code\"\n        [attr.aria-invalid]=\"\n          form.get('code')?.touched && form.get('code')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'codeError'\"\n      />\n\n      <cx-form-errors\n        id=\"codeError\"\n        [translationParams]=\"{\n          label: 'orgBudget.code' | cxTranslate,\n        }\"\n        [control]=\"form.get('code')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">\n        {{ 'orgBudget.startDate' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <cx-date-picker\n        [control]=\"$any(form.get('startDate'))\"\n        [max]=\"form.get('endDate')?.value\"\n        [required]=\"true\"\n        (update)=\"form.get('endDate')?.updateValueAndValidity()\"\n        label=\"orgBudget.startDate\"\n      ></cx-date-picker>\n    </label>\n\n    <label>\n      <span class=\"label-content\">\n        {{ 'orgBudget.endDate' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n\n      <cx-date-picker\n        [control]=\"$any(form.get('endDate'))\"\n        [min]=\"form.get('startDate')?.value\"\n        [required]=\"true\"\n        (update)=\"form.get('startDate')?.updateValueAndValidity()\"\n        label=\"orgBudget.endDate\"\n      ></cx-date-picker>\n    </label>\n\n    <label [formGroup]=\"$any(form.get('currency'))\">\n      <span class=\"label-content required\">{{\n        'orgBudget.currency' | cxTranslate\n      }}</span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"isocode\"\n        [attr.aria-invalid]=\"\n          form.get('isocode')?.touched && form.get('isocode')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'isocodeError'\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"(currencies$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"isocode\"\n        [class.invalid]=\"form.get('currency.isocode')?.invalid ?? false\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgBudget.currency' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        id=\"isocodeError\"\n        [translationParams]=\"{\n          label: 'orgBudget.currency' | cxTranslate,\n        }\"\n        [control]=\"form.get('currency.isocode')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content\">\n        {{ 'orgBudget.amount' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"number\"\n        class=\"form-control\"\n        placeholder=\"{{ 'orgBudget.amount' | cxTranslate }}\"\n        formControlName=\"budget\"\n        min=\"0\"\n        [attr.aria-invalid]=\"\n          form.get('budget')?.touched && form.get('budget')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'budgetError'\"\n      />\n\n      <cx-form-errors\n        id=\"budgetError\"\n        [translationParams]=\"{\n          label: 'orgBudget.amount' | cxTranslate,\n        }\"\n        [control]=\"form.get('budget')\"\n      ></cx-form-errors>\n    </label>\n\n    <label\n      *ngIf=\"units$ | async as units\"\n      [formGroup]=\"$any(form.get('orgUnit'))\"\n    >\n      <span class=\"label-content required\">\n        {{ 'orgBudget.businessUnits' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"uid\"\n        [attr.aria-invalid]=\"\n          form.get('uid')?.touched && form.get('uid')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'uidError'\"\n        [searchable]=\"true\"\n        [clearable]=\"false\"\n        [items]=\"units\"\n        bindLabel=\"name\"\n        bindValue=\"id\"\n        [readonly]=\"form.get('orgUnit.uid')?.disabled ?? false\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgBudget.businessUnits' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        id=\"uidError\"\n        [translationParams]=\"{\n          label: 'orgBudget.businessUnits' | cxTranslate,\n        }\"\n        [control]=\"form.get('orgUnit.uid')\"\n      ></cx-form-errors>\n    </label>\n  </ng-container>\n</cx-org-form>\n" }]
        }], ctorParameters: () => [{ type: ItemService }, { type: i2.OrgUnitService }, { type: i1.CurrencyService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Service to populate Budget data to `Table` data. Budget
 * data is driven by the table configuration, using the `OrganizationTables.BUDGET`.
 */
class BudgetListService extends ListService {
    constructor(tableService, budgetService) {
        super(tableService);
        this.tableService = tableService;
        this.budgetService = budgetService;
        this.tableType = OrganizationTableType.BUDGET;
    }
    load(pagination) {
        return this.budgetService.getList(pagination).pipe(filter(isNotUndefined), map((raw) => this.convertBudgets(raw)));
    }
    /**
     * Populates budget data to a convenient table data model, so that we
     * can skip specific conversion in the view logic where possible.
     */
    convertBudgets({ pagination, sorts, values, }) {
        const budgetModels = {
            pagination,
            sorts,
            values: values.map((value) => ({
                ...value,
                currency: value.currency?.isocode,
                unit: value.orgUnit,
            })),
        };
        return budgetModels;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetListService, deps: [{ token: i1$1.TableService }, { token: i2.BudgetService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.BudgetService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class BudgetRoutePageMetaResolver extends DefaultRoutePageMetaResolver {
    constructor(translation, currentItemService) {
        super(translation);
        this.currentItemService = currentItemService;
    }
    getParams() {
        return this.currentItemService.item$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetRoutePageMetaResolver, deps: [{ token: i1.TranslationService }, { token: CurrentBudgetService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetRoutePageMetaResolver, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetRoutePageMetaResolver, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1.TranslationService }, { type: CurrentBudgetService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const budgetCmsConfig = {
    cmsComponents: {
        ManageBudgetsListComponent: {
            component: ListComponent,
            providers: [
                {
                    provide: ListService,
                    useExisting: BudgetListService,
                },
                {
                    provide: ItemService,
                    useExisting: BudgetItemService,
                },
            ],
            childRoutes: {
                parent: {
                    data: {
                        cxPageMeta: {
                            breadcrumb: 'orgBudget.breadcrumbs.list',
                            resolver: BudgetRoutePageMetaResolver,
                        },
                    },
                },
                children: [
                    {
                        path: 'create',
                        component: BudgetFormComponent,
                    },
                    {
                        path: `:${ROUTE_PARAMS.budgetCode}`,
                        component: BudgetDetailsComponent,
                        data: {
                            cxPageMeta: {
                                breadcrumb: 'orgBudget.breadcrumbs.details',
                            },
                        },
                        children: [
                            {
                                path: `edit`,
                                component: BudgetFormComponent,
                            },
                            {
                                path: 'cost-centers',
                                component: BudgetCostCenterListComponent,
                            },
                        ],
                    },
                ],
            },
            guards: [AuthGuard, AdminGuard],
        },
    },
};
function budgetTableConfigFactory() {
    return budgetTableConfig;
}
const budgetTableConfig = {
    table: {
        [OrganizationTableType.BUDGET]: {
            cells: ['name', 'active', 'amount', 'dateRange', 'unit'],
            options: {
                cells: {
                    name: {
                        dataComponent: ActiveLinkCellComponent,
                        linkable: true,
                    },
                    active: {
                        dataComponent: StatusCellComponent,
                    },
                    amount: {
                        dataComponent: AmountCellComponent,
                    },
                    dateRange: {
                        dataComponent: DateRangeCellComponent,
                    },
                    unit: {
                        dataComponent: UnitCellComponent,
                    },
                },
            },
        },
        [OrganizationTableType.BUDGET_ASSIGNED_COST_CENTERS]: {
            cells: ['name'],
            options: {
                cells: {
                    name: {
                        dataComponent: CostCenterDetailsCellComponent,
                    },
                },
                pagination: {
                    pageSize: MAX_OCC_INTEGER_VALUE,
                },
            },
        },
    },
};
/**
 * @deprecated Use `budgetTableConfig` instead.
 */
const newBudgetTableConfig = budgetTableConfig;

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class BudgetCostCenterListModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetCostCenterListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: BudgetCostCenterListModule, imports: [CommonModule, SubListModule, BudgetCostCenterListComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetCostCenterListModule, imports: [CommonModule, SubListModule, BudgetCostCenterListComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetCostCenterListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, SubListModule, BudgetCostCenterListComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ItemExistsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ItemExistsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: ItemExistsModule, imports: [CommonModule, ItemExistsDirective], exports: [ItemExistsDirective] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ItemExistsModule, imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ItemExistsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, ItemExistsDirective],
                    exports: [ItemExistsDirective],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class BudgetDetailsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetDetailsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: BudgetDetailsModule, imports: [CommonModule,
            CardModule,
            RouterModule,
            UrlModule,
            I18nModule,
            ToggleStatusModule,
            ItemExistsModule,
            DisableInfoModule,
            KeyboardFocusModule,
            BudgetDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetDetailsModule, imports: [CommonModule,
            CardModule,
            RouterModule,
            UrlModule,
            I18nModule,
            ToggleStatusModule,
            ItemExistsModule,
            DisableInfoModule,
            KeyboardFocusModule,
            BudgetDetailsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetDetailsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        CardModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        ToggleStatusModule,
                        ItemExistsModule,
                        DisableInfoModule,
                        KeyboardFocusModule,
                        BudgetDetailsComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class BudgetFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: BudgetFormModule, imports: [CommonModule,
            RouterModule,
            FormModule,
            NgSelectModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            FormErrorsModule,
            ItemActiveModule,
            DatePickerModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            BudgetFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetFormModule, imports: [CommonModule,
            RouterModule,
            FormModule,
            NgSelectModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            FormErrorsModule,
            ItemActiveModule,
            DatePickerModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            BudgetFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        FormModule,
                        NgSelectModule,
                        UrlModule,
                        I18nModule,
                        ReactiveFormsModule,
                        FormErrorsModule,
                        ItemActiveModule,
                        DatePickerModule,
                        FeaturesConfigModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        BudgetFormComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class BudgetComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: BudgetComponentsModule, imports: [SharedOrganizationModule,
            BudgetDetailsModule,
            BudgetFormModule,
            BudgetCostCenterListModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetComponentsModule, providers: [
            provideDefaultConfig(budgetCmsConfig),
            provideDefaultConfigFactory(budgetTableConfigFactory),
        ], imports: [SharedOrganizationModule,
            BudgetDetailsModule,
            BudgetFormModule,
            BudgetCostCenterListModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        SharedOrganizationModule,
                        BudgetDetailsModule,
                        BudgetFormModule,
                        BudgetCostCenterListModule,
                    ],
                    providers: [
                        provideDefaultConfig(budgetCmsConfig),
                        provideDefaultConfigFactory(budgetTableConfigFactory),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class BudgetDetailsCellComponent extends CellComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetDetailsCellComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: BudgetDetailsCellComponent, isStandalone: true, selector: "cx-org-budget-details-cell", usesInheritance: true, ngImport: i0, template: "<ng-template #details>\n  <div class=\"popover-details\">\n    <div class=\"property\">\n      <label>{{ 'orgBudget.name' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgBudgetDetails',\n            params: model,\n          } | cxUrl\n        \"\n      >\n        {{ model.name }}\n      </a>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.code' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.code }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.startDate' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.startDate | cxDate }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.endDate' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.endDate | cxDate }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.active' | cxTranslate }}</label>\n      <span class=\"value\" [class.is-active]=\"model.active\">\n        {{\n          (model.active ? 'organization.enabled' : 'organization.disabled')\n            | cxTranslate\n        }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.amount' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.budget }} {{ model.currency?.isocode }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.unit' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.orgUnit,\n          } | cxUrl\n        \"\n      >\n        {{ model.orgUnit?.name }}\n      </a>\n    </div>\n  </div>\n</ng-template>\n\n<button\n  class=\"button btn btn-sm text\"\n  [cxPopover]=\"details\"\n  [cxPopoverOptions]=\"{\n    placement: 'auto',\n    class: 'my-company-popover',\n    appendToBody: true,\n    displayCloseButton: true,\n  }\"\n>\n  {{ model.name }}\n</button>\n", dependencies: [{ kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: PopoverDirective, selector: "[cxPopover]", inputs: ["cxPopover", "cxPopoverOptions"], outputs: ["openPopover", "closePopover"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: CxDatePipe, name: "cxDate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetDetailsCellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-budget-details-cell', changeDetection: ChangeDetectionStrategy.OnPush, imports: [RouterLink, PopoverDirective, TranslatePipe, CxDatePipe, UrlPipe], template: "<ng-template #details>\n  <div class=\"popover-details\">\n    <div class=\"property\">\n      <label>{{ 'orgBudget.name' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgBudgetDetails',\n            params: model,\n          } | cxUrl\n        \"\n      >\n        {{ model.name }}\n      </a>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.code' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.code }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.startDate' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.startDate | cxDate }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.endDate' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.endDate | cxDate }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.active' | cxTranslate }}</label>\n      <span class=\"value\" [class.is-active]=\"model.active\">\n        {{\n          (model.active ? 'organization.enabled' : 'organization.disabled')\n            | cxTranslate\n        }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.amount' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.budget }} {{ model.currency?.isocode }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgBudget.unit' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.orgUnit,\n          } | cxUrl\n        \"\n      >\n        {{ model.orgUnit?.name }}\n      </a>\n    </div>\n  </div>\n</ng-template>\n\n<button\n  class=\"button btn btn-sm text\"\n  [cxPopover]=\"details\"\n  [cxPopoverOptions]=\"{\n    placement: 'auto',\n    class: 'my-company-popover',\n    appendToBody: true,\n    displayCloseButton: true,\n  }\"\n>\n  {{ model.name }}\n</button>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class BudgetDetailsCellModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetDetailsCellModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: BudgetDetailsCellModule, imports: [CommonModule,
            PopoverModule,
            RouterModule,
            I18nModule,
            UrlModule,
            BudgetDetailsCellComponent], exports: [BudgetDetailsCellComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetDetailsCellModule, imports: [CommonModule,
            PopoverModule,
            RouterModule,
            I18nModule,
            UrlModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: BudgetDetailsCellModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        PopoverModule,
                        RouterModule,
                        I18nModule,
                        UrlModule,
                        BudgetDetailsCellComponent,
                    ],
                    exports: [BudgetDetailsCellComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CostCenterBudgetListService extends SubListService {
    constructor(tableService, costCenterService, budgetService) {
        super(tableService);
        this.tableService = tableService;
        this.costCenterService = costCenterService;
        this.budgetService = budgetService;
        this.tableType = OrganizationTableType.COST_CENTER_BUDGETS;
        this._domainType = OrganizationTableType.BUDGET;
    }
    load(pagination, code) {
        return this.costCenterService.getBudgets(code, pagination);
    }
    /**
     * @override
     * Assign budget to the cost center.
     */
    assign(costCenterCode, budgetCode) {
        this.costCenterService.assignBudget(costCenterCode, budgetCode);
        return this.budgetService.getLoadingStatus(budgetCode);
    }
    /**
     * @override
     * Unassign the budget from the cost center.
     */
    unassign(costCenterCode, budgetCode) {
        this.costCenterService.unassignBudget(costCenterCode, budgetCode);
        return this.budgetService.getLoadingStatus(budgetCode);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterBudgetListService, deps: [{ token: i1$1.TableService }, { token: i2.CostCenterService }, { token: i2.BudgetService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterBudgetListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterBudgetListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.CostCenterService }, { type: i2.BudgetService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CostCenterAssignedBudgetListService extends CostCenterBudgetListService {
    constructor() {
        super(...arguments);
        this.tableType = OrganizationTableType.COST_CENTER_ASSIGNED_BUDGETS;
    }
    load(pagination, code) {
        return super
            .load(pagination, code)
            .pipe(map((budgets) => this.filterSelected(budgets)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterAssignedBudgetListService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterAssignedBudgetListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterAssignedBudgetListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CostCenterAssignedBudgetListComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterAssignedBudgetListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CostCenterAssignedBudgetListComponent, isStandalone: true, selector: "cx-org-cost-center-assigned-budget-list", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: CostCenterAssignedBudgetListService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list>\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"assign\">\n    {{ 'organization.assign' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterAssignedBudgetListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-cost-center-assigned-budget-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: CostCenterAssignedBudgetListService,
                        },
                    ], imports: [SubListComponent, RouterLink, TranslatePipe], template: "<cx-org-sub-list>\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"assign\">\n    {{ 'organization.assign' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CostCenterBudgetListComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterBudgetListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CostCenterBudgetListComponent, isStandalone: true, selector: "cx-org-cost-center-budget-list", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: CostCenterBudgetListService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list [previous]=\"false\">\n  <a actions class=\"link\" routerLink=\"../\">\n    {{ 'organization.done' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterBudgetListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-cost-center-budget-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: CostCenterBudgetListService,
                        },
                    ], imports: [SubListComponent, RouterLink, TranslatePipe], template: "<cx-org-sub-list [previous]=\"false\">\n  <a actions class=\"link\" routerLink=\"../\">\n    {{ 'organization.done' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CostCenterBudgetListModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterBudgetListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CostCenterBudgetListModule, imports: [ListModule,
            I18nModule,
            RouterModule,
            SubListModule,
            CostCenterAssignedBudgetListComponent,
            CostCenterBudgetListComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterBudgetListModule, imports: [ListModule,
            I18nModule,
            RouterModule,
            SubListModule,
            CostCenterAssignedBudgetListComponent,
            CostCenterBudgetListComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterBudgetListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        ListModule,
                        I18nModule,
                        RouterModule,
                        SubListModule,
                        CostCenterAssignedBudgetListComponent,
                        CostCenterBudgetListComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CurrentCostCenterService extends CurrentItemService {
    constructor(routingService, costCenterService) {
        super(routingService);
        this.routingService = routingService;
        this.costCenterService = costCenterService;
    }
    getParamKey() {
        return ROUTE_PARAMS.costCenterCode;
    }
    getItem(code) {
        return this.costCenterService.get(code);
    }
    getError(code) {
        return this.costCenterService.getErrorState(code);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentCostCenterService, deps: [{ token: i1.RoutingService }, { token: i2.CostCenterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentCostCenterService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentCostCenterService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.RoutingService }, { type: i2.CostCenterService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CostCenterFormService extends FormService {
    build() {
        const form = new UntypedFormGroup({});
        form.setControl('code', new UntypedFormControl('', [
            Validators.required,
            CustomFormValidators.noSpecialCharacters,
        ]));
        form.setControl('name', new UntypedFormControl('', Validators.required));
        form.setControl('currency', new UntypedFormGroup({
            isocode: new UntypedFormControl(undefined, Validators.required),
        }));
        form.setControl('unit', new UntypedFormGroup({
            uid: new UntypedFormControl(undefined, Validators.required),
        }));
        this.form = form;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterFormService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterFormService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterFormService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CostCenterItemService extends ItemService {
    constructor(currentItemService, routingService, formService, costCenterService) {
        super(currentItemService, routingService, formService);
        this.currentItemService = currentItemService;
        this.routingService = routingService;
        this.formService = formService;
        this.costCenterService = costCenterService;
    }
    load(code) {
        this.costCenterService.load(code);
        return this.costCenterService.get(code);
    }
    update(code, value) {
        this.costCenterService.update(code, value);
        return this.costCenterService.getLoadingStatus(value.code ?? '');
    }
    create(value) {
        this.costCenterService.create(value);
        return this.costCenterService.getLoadingStatus(value.code ?? '');
    }
    getDetailsRoute() {
        return 'orgCostCenterDetails';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterItemService, deps: [{ token: CurrentCostCenterService }, { token: i1.RoutingService }, { token: CostCenterFormService }, { token: i2.CostCenterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterItemService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterItemService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: CurrentCostCenterService }, { type: i1.RoutingService }, { type: CostCenterFormService }, { type: i2.CostCenterService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CostCenterDetailsComponent {
    constructor(itemService) {
        this.itemService = itemService;
        this.model$ = this.itemService.key$.pipe(switchMap((code) => this.itemService.load(code)), startWith({}));
        this.isInEditMode$ = this.itemService.isInEditMode$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterDetailsComponent, deps: [{ token: ItemService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CostCenterDetailsComponent, isStandalone: true, selector: "cx-org-cost-center-details", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ItemService,
                useExisting: CostCenterItemService,
            },
        ], ngImport: i0, template: "<cx-org-card\n  *ngIf=\"model$ | async as model\"\n  i18nRoot=\"orgCostCenter.details\"\n  [cxFocus]=\"{ refreshFocus: model }\"\n>\n  <a\n    actions\n    class=\"link edit\"\n    [class.disabled]=\"!model.active || (isInEditMode$ | async)\"\n    [routerLink]=\"{ cxRoute: 'orgCostCenterEdit', params: model } | cxUrl\"\n  >\n    {{ 'organization.edit' | cxTranslate }}\n  </a>\n\n  <cx-org-toggle-status actions i18nRoot=\"orgCostCenter\"></cx-org-toggle-status>\n\n  <cx-org-disable-info info i18nRoot=\"orgCostCenter\"> </cx-org-disable-info>\n\n  <section main class=\"details\" cxOrgItemExists>\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.name' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.name }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.code' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.code }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.active' | cxTranslate }}</label>\n      <span\n        class=\"value\"\n        [class.is-active]=\"model.active\"\n        [class.is-inactive]=\"!model.active\"\n      >\n        {{\n          (model.active ? 'organization.enabled' : 'organization.disabled')\n            | cxTranslate\n        }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.currency' | cxTranslate }}</label>\n\n      <span class=\"value\">\n        {{ model.currency?.isocode }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.unit' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.unit,\n          } | cxUrl\n        \"\n      >\n        {{ model.unit?.name }}\n      </a>\n    </div>\n  </section>\n\n  <section main class=\"link-list\">\n    <a\n      *ngIf=\"model.code\"\n      class=\"link\"\n      [routerLink]=\"{ cxRoute: 'orgCostCenterBudgets', params: model } | cxUrl\"\n      routerLinkActive=\"is-current\"\n    >\n      {{ 'orgCostCenter.budget.link' | cxTranslate }}\n    </a>\n  </section>\n</cx-org-card>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CardComponent, selector: "cx-org-card", inputs: ["i18nRoot", "previous", "subtitle", "showHint"] }, { kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: ToggleStatusComponent, selector: "cx-org-toggle-status", inputs: ["i18nRoot", "key", "disabled"] }, { kind: "component", type: DisableInfoComponent, selector: "cx-org-disable-info", inputs: ["i18nRoot", "displayInfoConfig", "displayCustomInfo"] }, { kind: "directive", type: ItemExistsDirective, selector: "[cxOrgItemExists]" }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-cost-center-details', changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: ItemService,
                            useExisting: CostCenterItemService,
                        },
                    ], host: { class: 'content-wrapper' }, imports: [
                        NgIf,
                        CardComponent,
                        FocusDirective,
                        RouterLink,
                        ToggleStatusComponent,
                        DisableInfoComponent,
                        ItemExistsDirective,
                        RouterLinkActive,
                        AsyncPipe,
                        UrlPipe,
                        TranslatePipe,
                    ], template: "<cx-org-card\n  *ngIf=\"model$ | async as model\"\n  i18nRoot=\"orgCostCenter.details\"\n  [cxFocus]=\"{ refreshFocus: model }\"\n>\n  <a\n    actions\n    class=\"link edit\"\n    [class.disabled]=\"!model.active || (isInEditMode$ | async)\"\n    [routerLink]=\"{ cxRoute: 'orgCostCenterEdit', params: model } | cxUrl\"\n  >\n    {{ 'organization.edit' | cxTranslate }}\n  </a>\n\n  <cx-org-toggle-status actions i18nRoot=\"orgCostCenter\"></cx-org-toggle-status>\n\n  <cx-org-disable-info info i18nRoot=\"orgCostCenter\"> </cx-org-disable-info>\n\n  <section main class=\"details\" cxOrgItemExists>\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.name' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.name }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.code' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.code }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.active' | cxTranslate }}</label>\n      <span\n        class=\"value\"\n        [class.is-active]=\"model.active\"\n        [class.is-inactive]=\"!model.active\"\n      >\n        {{\n          (model.active ? 'organization.enabled' : 'organization.disabled')\n            | cxTranslate\n        }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.currency' | cxTranslate }}</label>\n\n      <span class=\"value\">\n        {{ model.currency?.isocode }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgCostCenter.unit' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.unit,\n          } | cxUrl\n        \"\n      >\n        {{ model.unit?.name }}\n      </a>\n    </div>\n  </section>\n\n  <section main class=\"link-list\">\n    <a\n      *ngIf=\"model.code\"\n      class=\"link\"\n      [routerLink]=\"{ cxRoute: 'orgCostCenterBudgets', params: model } | cxUrl\"\n      routerLinkActive=\"is-current\"\n    >\n      {{ 'orgCostCenter.budget.link' | cxTranslate }}\n    </a>\n  </section>\n</cx-org-card>\n" }]
        }], ctorParameters: () => [{ type: ItemService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CostCenterFormComponent {
    /**
     * Initialize the business unit for the cost center.
     *
     * If there's a unit provided, we disable the form control.
     */
    set unitKey(value) {
        if (value) {
            this.form?.get('unit.uid')?.setValue(value);
            this.form?.get('unit')?.disable();
        }
    }
    constructor(itemService, unitService, currencyService) {
        this.itemService = itemService;
        this.unitService = unitService;
        this.currencyService = currencyService;
        this.form = this.itemService.getForm();
        this.units$ = this.unitService
            .getActiveUnitList()
            .pipe(tap((units) => {
            if (units && units.length === 1) {
                this.form?.get('unit.uid')?.setValue(units[0]?.id);
            }
        }));
        this.currencies$ = this.currencyService.getAll().pipe(tap((currency) => {
            if (currency.length === 1) {
                this.form?.get('currency.isocode')?.setValue(currency[0]?.isocode);
            }
        }));
    }
    createCodeWithName(name, code) {
        createCodeForEntityName(name, code);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterFormComponent, deps: [{ token: ItemService }, { token: i2.OrgUnitService }, { token: i1.CurrencyService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: CostCenterFormComponent, isStandalone: true, selector: "cx-org-cost-center-form", inputs: { unitKey: "unitKey" }, host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ItemService,
                useExisting: CostCenterItemService,
            },
            {
                provide: CurrentItemService,
                useExisting: CurrentCostCenterService,
            },
        ], ngImport: i0, template: "<cx-org-form i18nRoot=\"orgCostCenter\">\n  <ng-container *ngIf=\"form\" [formGroup]=\"form\" main>\n    <cx-form-required-legend />\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'orgCostCenter.name' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        required\n        placeholder=\"{{ 'orgCostCenter.name' | cxTranslate }}\"\n        formControlName=\"name\"\n        (blur)=\"createCodeWithName(form.get('name'), form.get('code'))\"\n        [attr.aria-invalid]=\"\n          form.get('name')?.touched && form.get('name')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'nameError'\"\n      />\n\n      <cx-form-errors\n        id=\"nameError\"\n        [translationParams]=\"{\n          label: 'orgCostCenter.name' | cxTranslate,\n        }\"\n        [control]=\"form.get('name')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'orgCostCenter.code' | cxTranslate }}<cx-form-required-asterisks />\n      </span>\n      <input\n        class=\"form-control\"\n        type=\"text\"\n        required\n        placeholder=\"{{ 'orgCostCenter.code' | cxTranslate }}\"\n        formControlName=\"code\"\n        [attr.aria-invalid]=\"\n          form.get('code')?.touched && form.get('code')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'codeError'\"\n      />\n\n      <cx-form-errors\n        id=\"codeError\"\n        [translationParams]=\"{\n          label: 'orgCostCenter.code' | cxTranslate,\n        }\"\n        [control]=\"form.get('code')\"\n      ></cx-form-errors>\n    </label>\n\n    <label formGroupName=\"currency\">\n      <span class=\"label-content required\"\n        >{{ 'orgCostCenter.currency' | cxTranslate\n        }}<cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"isocode\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"(currencies$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"isocode\"\n        [class.invalid]=\"form.get('currency.isocode')?.invalid ?? false\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgCostCenter.currency' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'orgCostCenter.currency' | cxTranslate,\n        }\"\n        [control]=\"form.get('currency.isocode')\"\n      ></cx-form-errors>\n    </label>\n\n    <label [formGroup]=\"$any(form.get('unit'))\">\n      <span class=\"label-content required\"\n        >{{ 'orgCostCenter.unit' | cxTranslate }}<cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"uid\"\n        [searchable]=\"true\"\n        [clearable]=\"false\"\n        [items]=\"(units$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"id\"\n        [readonly]=\"form.get('unit.uid')?.disabled ?? false\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgCostCenter.unit' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'orgCostCenter.unit' | cxTranslate,\n        }\"\n        [control]=\"form.get('unit.uid')\"\n      ></cx-form-errors>\n    </label>\n  </ng-container>\n</cx-org-form>\n", dependencies: [{ kind: "component", type: FormComponent, selector: "cx-org-form", inputs: ["i18nRoot", "animateBack", "subtitle"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i4.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i4.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i4.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: i4.FormGroupName, selector: "[formGroupName]", inputs: ["formGroupName"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-cost-center-form', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ItemService,
                            useExisting: CostCenterItemService,
                        },
                        {
                            provide: CurrentItemService,
                            useExisting: CurrentCostCenterService,
                        },
                    ], imports: [
                        FormComponent,
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredLegendComponent,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        NgSelectComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<cx-org-form i18nRoot=\"orgCostCenter\">\n  <ng-container *ngIf=\"form\" [formGroup]=\"form\" main>\n    <cx-form-required-legend />\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'orgCostCenter.name' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        required\n        placeholder=\"{{ 'orgCostCenter.name' | cxTranslate }}\"\n        formControlName=\"name\"\n        (blur)=\"createCodeWithName(form.get('name'), form.get('code'))\"\n        [attr.aria-invalid]=\"\n          form.get('name')?.touched && form.get('name')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'nameError'\"\n      />\n\n      <cx-form-errors\n        id=\"nameError\"\n        [translationParams]=\"{\n          label: 'orgCostCenter.name' | cxTranslate,\n        }\"\n        [control]=\"form.get('name')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'orgCostCenter.code' | cxTranslate }}<cx-form-required-asterisks />\n      </span>\n      <input\n        class=\"form-control\"\n        type=\"text\"\n        required\n        placeholder=\"{{ 'orgCostCenter.code' | cxTranslate }}\"\n        formControlName=\"code\"\n        [attr.aria-invalid]=\"\n          form.get('code')?.touched && form.get('code')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'codeError'\"\n      />\n\n      <cx-form-errors\n        id=\"codeError\"\n        [translationParams]=\"{\n          label: 'orgCostCenter.code' | cxTranslate,\n        }\"\n        [control]=\"form.get('code')\"\n      ></cx-form-errors>\n    </label>\n\n    <label formGroupName=\"currency\">\n      <span class=\"label-content required\"\n        >{{ 'orgCostCenter.currency' | cxTranslate\n        }}<cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"isocode\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"(currencies$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"isocode\"\n        [class.invalid]=\"form.get('currency.isocode')?.invalid ?? false\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgCostCenter.currency' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'orgCostCenter.currency' | cxTranslate,\n        }\"\n        [control]=\"form.get('currency.isocode')\"\n      ></cx-form-errors>\n    </label>\n\n    <label [formGroup]=\"$any(form.get('unit'))\">\n      <span class=\"label-content required\"\n        >{{ 'orgCostCenter.unit' | cxTranslate }}<cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"uid\"\n        [searchable]=\"true\"\n        [clearable]=\"false\"\n        [items]=\"(units$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"id\"\n        [readonly]=\"form.get('unit.uid')?.disabled ?? false\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgCostCenter.unit' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'orgCostCenter.unit' | cxTranslate,\n        }\"\n        [control]=\"form.get('unit.uid')\"\n      ></cx-form-errors>\n    </label>\n  </ng-container>\n</cx-org-form>\n" }]
        }], ctorParameters: () => [{ type: ItemService }, { type: i2.OrgUnitService }, { type: i1.CurrencyService }], propDecorators: { unitKey: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Service to populate Cost Center data to `Table` data. The cost center
 * data is driven by the table configuration, using the `OrganizationTables.COST_CENTER`.
 */
class CostCenterListService extends ListService {
    constructor(tableService, costCenterService) {
        super(tableService);
        this.tableService = tableService;
        this.costCenterService = costCenterService;
        this.tableType = OrganizationTableType.COST_CENTER;
        this.featureConfigService = inject(FeatureConfigService);
    }
    /**
     * Enable search functionality for cost center list based on feature toggle.
     */
    isSearchEnabled() {
        return this.featureConfigService.isEnabled('enableB2BCostCenterSearch');
    }
    load(pagination) {
        return this.costCenterService.getList(pagination).pipe(filter(isNotUndefined), map((raw) => this.convertCostCenters(raw)));
    }
    /**
     * Populates the cost center data to a convenient table data model, so that we
     * can skip specific conversion in the view logic where possible.
     */
    convertCostCenters({ pagination, sorts, values, }) {
        const costCenterModels = {
            pagination,
            sorts,
            values: values.map((value) => ({
                ...value,
                currency: value.currency?.isocode,
            })),
        };
        return costCenterModels;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterListService, deps: [{ token: i1$1.TableService }, { token: i2.CostCenterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.CostCenterService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CostCenterRoutePageMetaResolver extends DefaultRoutePageMetaResolver {
    constructor(translation, currentItemService) {
        super(translation);
        this.currentItemService = currentItemService;
    }
    getParams() {
        return this.currentItemService.item$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterRoutePageMetaResolver, deps: [{ token: i1.TranslationService }, { token: CurrentCostCenterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterRoutePageMetaResolver, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterRoutePageMetaResolver, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1.TranslationService }, { type: CurrentCostCenterService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const costCenterCmsConfig = {
    cmsComponents: {
        ManageCostCentersListComponent: {
            component: ListComponent,
            providers: [
                {
                    provide: ListService,
                    useExisting: CostCenterListService,
                },
                {
                    provide: ItemService,
                    useExisting: CostCenterItemService,
                },
            ],
            childRoutes: {
                parent: {
                    data: {
                        cxPageMeta: {
                            breadcrumb: 'orgCostCenter.breadcrumbs.list',
                            resolver: CostCenterRoutePageMetaResolver,
                        },
                    },
                },
                children: [
                    {
                        path: 'create',
                        component: CostCenterFormComponent,
                    },
                    {
                        path: `:${ROUTE_PARAMS.costCenterCode}`,
                        component: CostCenterDetailsComponent,
                        data: {
                            cxPageMeta: { breadcrumb: 'orgCostCenter.breadcrumbs.details' },
                        },
                        children: [
                            {
                                path: 'edit',
                                component: CostCenterFormComponent,
                            },
                            {
                                path: 'budgets',
                                data: {
                                    cxPageMeta: {
                                        breadcrumb: 'orgCostCenter.breadcrumbs.budgets',
                                    },
                                },
                                children: [
                                    {
                                        path: '',
                                        component: CostCenterAssignedBudgetListComponent,
                                    },
                                    {
                                        path: 'assign',
                                        component: CostCenterBudgetListComponent,
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },
            guards: [AuthGuard, AdminGuard],
        },
    },
};
function costCenterTableConfigFactory() {
    return costCenterTableConfig;
}
const costCenterTableConfig = {
    table: {
        [OrganizationTableType.COST_CENTER]: {
            cells: ['name', 'active', 'currency', 'unit'],
            options: {
                cells: {
                    name: {
                        dataComponent: ActiveLinkCellComponent,
                        linkable: true,
                    },
                    active: {
                        dataComponent: StatusCellComponent,
                    },
                    currency: {
                        dataComponent: CellComponent,
                    },
                    unit: {
                        dataComponent: UnitCellComponent,
                    },
                },
            },
        },
        [OrganizationTableType.COST_CENTER_ASSIGNED_BUDGETS]: {
            cells: ['name', 'actions'],
            options: {
                cells: {
                    name: {
                        dataComponent: BudgetDetailsCellComponent,
                    },
                    actions: {
                        dataComponent: AssignCellComponent,
                    },
                },
                pagination: {
                    pageSize: MAX_OCC_INTEGER_VALUE,
                },
            },
        },
        [OrganizationTableType.COST_CENTER_BUDGETS]: {
            cells: ['name', 'actions'],
            options: {
                cells: {
                    name: {
                        dataComponent: BudgetDetailsCellComponent,
                    },
                    actions: {
                        dataComponent: AssignCellComponent,
                    },
                },
            },
        },
    },
};
/**
 * @deprecated Use `costCenterTableConfig` instead.
 */
const newCostCenterTableConfig = costCenterTableConfig;

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CostCenterDetailsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterDetailsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CostCenterDetailsModule, imports: [CommonModule,
            CardModule,
            RouterModule,
            UrlModule,
            I18nModule,
            ToggleStatusModule,
            ItemExistsModule,
            DisableInfoModule,
            KeyboardFocusModule,
            CostCenterDetailsComponent], exports: [CostCenterDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterDetailsModule, imports: [CommonModule,
            CardModule,
            RouterModule,
            UrlModule,
            I18nModule,
            ToggleStatusModule,
            ItemExistsModule,
            DisableInfoModule,
            KeyboardFocusModule,
            CostCenterDetailsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterDetailsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        CardModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        ToggleStatusModule,
                        ItemExistsModule,
                        DisableInfoModule,
                        KeyboardFocusModule,
                        CostCenterDetailsComponent,
                    ],
                    exports: [CostCenterDetailsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CostCenterFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CostCenterFormModule, imports: [CommonModule,
            RouterModule,
            FormModule,
            NgSelectModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            FormErrorsModule,
            ItemActiveModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            CostCenterFormComponent], exports: [CostCenterFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterFormModule, providers: [CurrencyService, OrgUnitService], imports: [CommonModule,
            RouterModule,
            FormModule,
            NgSelectModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            FormErrorsModule,
            ItemActiveModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            CostCenterFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        FormModule,
                        NgSelectModule,
                        UrlModule,
                        I18nModule,
                        ReactiveFormsModule,
                        FormErrorsModule,
                        ItemActiveModule,
                        FeaturesConfigModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        CostCenterFormComponent,
                    ],
                    exports: [CostCenterFormComponent],
                    providers: [CurrencyService, OrgUnitService],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CostCenterComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CostCenterComponentsModule, imports: [SharedOrganizationModule,
            CostCenterDetailsModule,
            CostCenterFormModule,
            CostCenterBudgetListModule,
            BudgetDetailsCellModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterComponentsModule, providers: [
            provideDefaultConfig(costCenterCmsConfig),
            provideDefaultConfigFactory(costCenterTableConfigFactory),
        ], imports: [SharedOrganizationModule,
            CostCenterDetailsModule,
            CostCenterFormModule,
            CostCenterBudgetListModule,
            BudgetDetailsCellModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        SharedOrganizationModule,
                        CostCenterDetailsModule,
                        CostCenterFormModule,
                        CostCenterBudgetListModule,
                        BudgetDetailsCellModule,
                    ],
                    providers: [
                        provideDefaultConfig(costCenterCmsConfig),
                        provideDefaultConfigFactory(costCenterTableConfigFactory),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CurrentPermissionService extends CurrentItemService {
    constructor(routingService, permissionService) {
        super(routingService);
        this.routingService = routingService;
        this.permissionService = permissionService;
    }
    getParamKey() {
        return ROUTE_PARAMS.permissionCode;
    }
    getItem(code) {
        return this.permissionService.get(code);
    }
    getError(code) {
        return this.permissionService.getErrorState(code);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentPermissionService, deps: [{ token: i1.RoutingService }, { token: i2.PermissionService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentPermissionService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentPermissionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.RoutingService }, { type: i2.PermissionService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var PermissionType;
(function (PermissionType) {
    PermissionType["ORDER"] = "B2BOrderThresholdPermission";
    PermissionType["TIME_SPAN"] = "B2BOrderThresholdTimespanPermission";
    PermissionType["EXCEEDED"] = "B2BBudgetExceededPermission";
})(PermissionType || (PermissionType = {}));
class PermissionFormService extends FormService {
    constructor() {
        super(...arguments);
        this.subscription = new Subscription();
    }
    /**
     * @override
     * Builds a generic sub form for permissions and amends the form
     * based on the for approval permission type.
     */
    build() {
        const form = new UntypedFormGroup({});
        form.setControl('code', new UntypedFormControl('', [
            Validators.required,
            CustomFormValidators.noSpecialCharacters,
        ]));
        form.setControl('orgUnit', new UntypedFormGroup({
            uid: new UntypedFormControl(undefined, Validators.required),
        }));
        form.setControl('orderApprovalPermissionType', new UntypedFormGroup({
            code: new UntypedFormControl(undefined, Validators.required),
        }));
        // subscribe to permission type changes and amend accordingly.
        this.subscription.add(form
            .get('orderApprovalPermissionType')
            ?.get('code')
            ?.valueChanges.pipe(distinctUntilChanged(), filter((code) => !!code))
            .subscribe((code) => this.amend(form, code)));
        this.form = form;
    }
    /**
     * @override
     * The form is using  `B2BBudgetExceededPermission` by default.
     */
    get defaultValue() {
        return {
            orderApprovalPermissionType: {
                code: PermissionType.EXCEEDED,
            },
        };
    }
    /**
     * Amends the form structure based on the `PermissionType`.
     */
    amend(form, code) {
        if (code === PermissionType.EXCEEDED) {
            form.removeControl('periodRange');
            form.removeControl('currency');
            form.removeControl('threshold');
        }
        if (code === PermissionType.TIME_SPAN || code === PermissionType.ORDER) {
            if (!form.get('currency')) {
                form.setControl('currency', new UntypedFormGroup({
                    isocode: new UntypedFormControl(undefined, Validators.required),
                }));
            }
            if (!form.get('threshold')) {
                form.setControl('threshold', new UntypedFormControl('', Validators.required));
            }
        }
        if (code === PermissionType.ORDER) {
            form.removeControl('periodRange');
        }
        if (code === PermissionType.TIME_SPAN) {
            if (!form.get('periodRange')) {
                form.setControl('periodRange', new UntypedFormControl('', Validators.required));
            }
        }
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    patchData(item) {
        super.patchData(item);
        if (item?.code !== undefined) {
            this.form?.get('orderApprovalPermissionType')?.disable();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionFormService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionFormService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionFormService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PermissionItemService extends ItemService {
    constructor(currentItemService, routingService, formService, permissionService) {
        super(currentItemService, routingService, formService);
        this.currentItemService = currentItemService;
        this.routingService = routingService;
        this.formService = formService;
        this.permissionService = permissionService;
    }
    load(code) {
        this.permissionService.loadPermission(code);
        return this.permissionService.get(code);
    }
    update(code, value) {
        this.permissionService.update(code, value);
        return this.permissionService.getLoadingStatus(value.code ?? '');
    }
    create(value) {
        this.permissionService.create(value);
        return this.permissionService.getLoadingStatus(value.code ?? '');
    }
    getDetailsRoute() {
        return 'orgPurchaseLimitDetails';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionItemService, deps: [{ token: CurrentPermissionService }, { token: i1.RoutingService }, { token: PermissionFormService }, { token: i2.PermissionService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionItemService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionItemService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: CurrentPermissionService }, { type: i1.RoutingService }, { type: PermissionFormService }, { type: i2.PermissionService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PermissionDetailsComponent {
    constructor(itemService) {
        this.itemService = itemService;
        this.model$ = this.itemService.key$.pipe(switchMap((code) => this.itemService.load(code)), startWith({}));
        this.isInEditMode$ = this.itemService.isInEditMode$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionDetailsComponent, deps: [{ token: ItemService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: PermissionDetailsComponent, isStandalone: true, selector: "cx-org-permission-details", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ItemService,
                useExisting: PermissionItemService,
            },
        ], ngImport: i0, template: "<cx-org-card\n  *ngIf=\"model$ | async as model\"\n  i18nRoot=\"orgPurchaseLimit.details\"\n  [cxFocus]=\"{ refreshFocus: model }\"\n>\n  <a\n    actions\n    class=\"link btn btn-link btn-sm edit\"\n    [class.disabled]=\"!model.active || (isInEditMode$ | async)\"\n    [routerLink]=\"{ cxRoute: 'orgPurchaseLimitEdit', params: model } | cxUrl\"\n  >\n    {{ 'organization.edit' | cxTranslate }}\n  </a>\n\n  <cx-org-toggle-status\n    actions\n    i18nRoot=\"orgPurchaseLimit\"\n    [disabled]=\"false\"\n  ></cx-org-toggle-status>\n\n  <cx-org-disable-info\n    info\n    i18nRoot=\"orgPurchaseLimit\"\n    [displayInfoConfig]=\"{ disabledEnable: false }\"\n  >\n  </cx-org-disable-info>\n\n  <section main class=\"details\" cxOrgItemExists>\n    <div class=\"property\">\n      <label>{{ 'orgPurchaseLimit.code' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.code }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgPurchaseLimit.active' | cxTranslate }}</label>\n      <span class=\"value\" [class.is-active]=\"model.active\">\n        {{\n          (model.active ? 'organization.enabled' : 'organization.disabled')\n            | cxTranslate\n        }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{\n        'orgPurchaseLimit.orderApprovalPermissionType' | cxTranslate\n      }}</label>\n      <span class=\"value\">\n        {{ model.orderApprovalPermissionType?.name }}\n      </span>\n    </div>\n\n    <div class=\"property\" *ngIf=\"model.threshold || model.threshold === 0\">\n      <label>{{ 'orgPurchaseLimit.threshold' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.threshold }} {{ model.currency?.symbol }}\n      </span>\n    </div>\n\n    <div class=\"property\" *ngIf=\"model.periodRange\">\n      <label>{{ 'orgPurchaseLimit.periodRange' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.periodRange }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgPurchaseLimit.unit' | cxTranslate }}</label>\n      <a\n        *ngIf=\"model.code\"\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.orgUnit,\n          } | cxUrl\n        \"\n      >\n        {{ model.orgUnit?.name }}\n      </a>\n    </div>\n  </section>\n</cx-org-card>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CardComponent, selector: "cx-org-card", inputs: ["i18nRoot", "previous", "subtitle", "showHint"] }, { kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: ToggleStatusComponent, selector: "cx-org-toggle-status", inputs: ["i18nRoot", "key", "disabled"] }, { kind: "component", type: DisableInfoComponent, selector: "cx-org-disable-info", inputs: ["i18nRoot", "displayInfoConfig", "displayCustomInfo"] }, { kind: "directive", type: ItemExistsDirective, selector: "[cxOrgItemExists]" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-permission-details', changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: ItemService,
                            useExisting: PermissionItemService,
                        },
                    ], host: { class: 'content-wrapper' }, imports: [
                        NgIf,
                        CardComponent,
                        FocusDirective,
                        RouterLink,
                        ToggleStatusComponent,
                        DisableInfoComponent,
                        ItemExistsDirective,
                        AsyncPipe,
                        UrlPipe,
                        TranslatePipe,
                    ], template: "<cx-org-card\n  *ngIf=\"model$ | async as model\"\n  i18nRoot=\"orgPurchaseLimit.details\"\n  [cxFocus]=\"{ refreshFocus: model }\"\n>\n  <a\n    actions\n    class=\"link btn btn-link btn-sm edit\"\n    [class.disabled]=\"!model.active || (isInEditMode$ | async)\"\n    [routerLink]=\"{ cxRoute: 'orgPurchaseLimitEdit', params: model } | cxUrl\"\n  >\n    {{ 'organization.edit' | cxTranslate }}\n  </a>\n\n  <cx-org-toggle-status\n    actions\n    i18nRoot=\"orgPurchaseLimit\"\n    [disabled]=\"false\"\n  ></cx-org-toggle-status>\n\n  <cx-org-disable-info\n    info\n    i18nRoot=\"orgPurchaseLimit\"\n    [displayInfoConfig]=\"{ disabledEnable: false }\"\n  >\n  </cx-org-disable-info>\n\n  <section main class=\"details\" cxOrgItemExists>\n    <div class=\"property\">\n      <label>{{ 'orgPurchaseLimit.code' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.code }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgPurchaseLimit.active' | cxTranslate }}</label>\n      <span class=\"value\" [class.is-active]=\"model.active\">\n        {{\n          (model.active ? 'organization.enabled' : 'organization.disabled')\n            | cxTranslate\n        }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{\n        'orgPurchaseLimit.orderApprovalPermissionType' | cxTranslate\n      }}</label>\n      <span class=\"value\">\n        {{ model.orderApprovalPermissionType?.name }}\n      </span>\n    </div>\n\n    <div class=\"property\" *ngIf=\"model.threshold || model.threshold === 0\">\n      <label>{{ 'orgPurchaseLimit.threshold' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.threshold }} {{ model.currency?.symbol }}\n      </span>\n    </div>\n\n    <div class=\"property\" *ngIf=\"model.periodRange\">\n      <label>{{ 'orgPurchaseLimit.periodRange' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.periodRange }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgPurchaseLimit.unit' | cxTranslate }}</label>\n      <a\n        *ngIf=\"model.code\"\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.orgUnit,\n          } | cxUrl\n        \"\n      >\n        {{ model.orgUnit?.name }}\n      </a>\n    </div>\n  </section>\n</cx-org-card>\n" }]
        }], ctorParameters: () => [{ type: ItemService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PermissionDetailsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionDetailsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: PermissionDetailsModule, imports: [CommonModule,
            CardModule,
            RouterModule,
            UrlModule,
            I18nModule,
            ToggleStatusModule,
            ItemExistsModule,
            DisableInfoModule,
            KeyboardFocusModule,
            PermissionDetailsComponent], exports: [PermissionDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionDetailsModule, imports: [CommonModule,
            CardModule,
            RouterModule,
            UrlModule,
            I18nModule,
            ToggleStatusModule,
            ItemExistsModule,
            DisableInfoModule,
            KeyboardFocusModule,
            PermissionDetailsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionDetailsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        CardModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        ToggleStatusModule,
                        ItemExistsModule,
                        DisableInfoModule,
                        KeyboardFocusModule,
                        PermissionDetailsComponent,
                    ],
                    exports: [PermissionDetailsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PermissionFormComponent {
    constructor(itemService, unitService, currencyService, permissionService) {
        this.itemService = itemService;
        this.unitService = unitService;
        this.currencyService = currencyService;
        this.permissionService = permissionService;
        this.form = this.itemService.getForm();
        this.units$ = this.unitService
            .getActiveUnitList()
            .pipe(tap((units) => {
            if (units && units.length === 1) {
                this.form?.get('orgUnit.uid')?.setValue(units[0].id);
            }
        }));
        this.currencies$ = this.currencyService.getAll().pipe(tap((currency) => {
            if (currency.length === 1) {
                this.form?.get('currency.isocode')?.setValue(currency[0]?.isocode);
            }
        }));
        this.types$ = this.permissionService.getTypes();
        this.periods = Object.keys(Period);
    }
    ngOnInit() {
        this.unitService.loadList();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionFormComponent, deps: [{ token: ItemService }, { token: i2.OrgUnitService }, { token: i1.CurrencyService }, { token: i2.PermissionService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: PermissionFormComponent, isStandalone: true, selector: "cx-org-permission-form", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ItemService,
                useExisting: PermissionItemService,
            },
            {
                provide: CurrentItemService,
                useExisting: CurrentPermissionService,
            },
        ], ngImport: i0, template: "<cx-org-form i18nRoot=\"orgPurchaseLimit\">\n  <ng-container *ngIf=\"form\" [formGroup]=\"form\" main>\n    <cx-form-required-legend />\n    <label>\n      <span class=\"label-content required\">\n        {{ 'orgPurchaseLimit.code' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        class=\"form-control\"\n        type=\"text\"\n        required\n        placeholder=\"{{ 'orgPurchaseLimit.code' | cxTranslate }}\"\n        formControlName=\"code\"\n        [attr.aria-invalid]=\"\n          form.get('code')?.touched && form.get('code')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'codeError'\"\n      />\n\n      <cx-form-errors\n        id=\"codeError\"\n        [translationParams]=\"{ label: 'orgPurchaseLimit.code' | cxTranslate }\"\n        [control]=\"form.get('code')\"\n      ></cx-form-errors>\n    </label>\n\n    <label\n      *ngIf=\"(types$ | async)?.length\"\n      [formGroup]=\"$any(form.get('orderApprovalPermissionType'))\"\n    >\n      <span class=\"label-content required\">\n        {{ 'orgPurchaseLimit.orderApprovalPermissionType' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"code\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"(types$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"code\"\n        [readonly]=\"form.disabled\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"\n          'orgPurchaseLimit.orderApprovalPermissionType' | cxTranslate\n        \"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'orgPurchaseLimit.orderApprovalPermissionType' | cxTranslate,\n        }\"\n        [control]=\"form.get('orderApprovalPermissionType.code')\"\n      ></cx-form-errors>\n    </label>\n\n    <label *ngIf=\"form.get('periodRange')\">\n      <span class=\"label-content required\">\n        {{ 'orgPurchaseLimit.periodRange' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"periodRange\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"periods\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgPurchaseLimit.periodRange' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'orgPurchaseLimit.periodRange' | cxTranslate,\n        }\"\n        [control]=\"form.get('periodRange')\"\n      ></cx-form-errors>\n    </label>\n\n    <label\n      *ngIf=\"form.get('currency')\"\n      [formGroup]=\"$any(form.get('currency'))\"\n    >\n      <span class=\"label-content required\">\n        {{ 'orgPurchaseLimit.currency' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <ng-select\n        *ngIf=\"currencies$ | async as currencies\"\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"isocode\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"currencies\"\n        bindLabel=\"name\"\n        bindValue=\"isocode\"\n        [placeholder]=\"'orgPurchaseLimit.currency' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'orgPurchaseLimit.currency' | cxTranslate,\n        }\"\n        [control]=\"form.get('currency.isocode')\"\n      ></cx-form-errors>\n    </label>\n\n    <label *ngIf=\"form.get('threshold')\">\n      <span class=\"label-content required\">\n        {{ 'orgPurchaseLimit.threshold' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        class=\"form-control\"\n        type=\"number\"\n        required\n        placeholder=\"{{ 'orgPurchaseLimit.threshold' | cxTranslate }}\"\n        formControlName=\"threshold\"\n        [attr.aria-invalid]=\"\n          form.get('threshold')?.touched && form.get('threshold')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'thresholdError'\"\n      />\n\n      <cx-form-errors\n        id=\"thresholdError\"\n        [translationParams]=\"{\n          label: 'orgPurchaseLimit.threshold' | cxTranslate,\n        }\"\n        [control]=\"form.get('threshold')\"\n      ></cx-form-errors>\n    </label>\n\n    <label [formGroup]=\"$any(form.get('orgUnit'))\">\n      <span class=\"label-content required\">\n        {{ 'orgPurchaseLimit.orgUnit' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"uid\"\n        [searchable]=\"true\"\n        [clearable]=\"false\"\n        [items]=\"(units$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"id\"\n        [readonly]=\"form.get('orgUnit')?.disabled ?? false\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgPurchaseLimit.orgUnit' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'orgPurchaseLimit.orgUnit' | cxTranslate,\n        }\"\n        [control]=\"form.get('orgUnit.uid')\"\n      ></cx-form-errors>\n    </label>\n  </ng-container>\n</cx-org-form>\n", dependencies: [{ kind: "component", type: FormComponent, selector: "cx-org-form", inputs: ["i18nRoot", "animateBack", "subtitle"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i4.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i4.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i4.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i4.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-permission-form', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ItemService,
                            useExisting: PermissionItemService,
                        },
                        {
                            provide: CurrentItemService,
                            useExisting: CurrentPermissionService,
                        },
                    ], imports: [
                        FormComponent,
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredLegendComponent,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        NgSelectComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<cx-org-form i18nRoot=\"orgPurchaseLimit\">\n  <ng-container *ngIf=\"form\" [formGroup]=\"form\" main>\n    <cx-form-required-legend />\n    <label>\n      <span class=\"label-content required\">\n        {{ 'orgPurchaseLimit.code' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        class=\"form-control\"\n        type=\"text\"\n        required\n        placeholder=\"{{ 'orgPurchaseLimit.code' | cxTranslate }}\"\n        formControlName=\"code\"\n        [attr.aria-invalid]=\"\n          form.get('code')?.touched && form.get('code')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'codeError'\"\n      />\n\n      <cx-form-errors\n        id=\"codeError\"\n        [translationParams]=\"{ label: 'orgPurchaseLimit.code' | cxTranslate }\"\n        [control]=\"form.get('code')\"\n      ></cx-form-errors>\n    </label>\n\n    <label\n      *ngIf=\"(types$ | async)?.length\"\n      [formGroup]=\"$any(form.get('orderApprovalPermissionType'))\"\n    >\n      <span class=\"label-content required\">\n        {{ 'orgPurchaseLimit.orderApprovalPermissionType' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"code\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"(types$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"code\"\n        [readonly]=\"form.disabled\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"\n          'orgPurchaseLimit.orderApprovalPermissionType' | cxTranslate\n        \"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'orgPurchaseLimit.orderApprovalPermissionType' | cxTranslate,\n        }\"\n        [control]=\"form.get('orderApprovalPermissionType.code')\"\n      ></cx-form-errors>\n    </label>\n\n    <label *ngIf=\"form.get('periodRange')\">\n      <span class=\"label-content required\">\n        {{ 'orgPurchaseLimit.periodRange' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"periodRange\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"periods\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgPurchaseLimit.periodRange' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'orgPurchaseLimit.periodRange' | cxTranslate,\n        }\"\n        [control]=\"form.get('periodRange')\"\n      ></cx-form-errors>\n    </label>\n\n    <label\n      *ngIf=\"form.get('currency')\"\n      [formGroup]=\"$any(form.get('currency'))\"\n    >\n      <span class=\"label-content required\">\n        {{ 'orgPurchaseLimit.currency' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <ng-select\n        *ngIf=\"currencies$ | async as currencies\"\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"isocode\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"currencies\"\n        bindLabel=\"name\"\n        bindValue=\"isocode\"\n        [placeholder]=\"'orgPurchaseLimit.currency' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'orgPurchaseLimit.currency' | cxTranslate,\n        }\"\n        [control]=\"form.get('currency.isocode')\"\n      ></cx-form-errors>\n    </label>\n\n    <label *ngIf=\"form.get('threshold')\">\n      <span class=\"label-content required\">\n        {{ 'orgPurchaseLimit.threshold' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        class=\"form-control\"\n        type=\"number\"\n        required\n        placeholder=\"{{ 'orgPurchaseLimit.threshold' | cxTranslate }}\"\n        formControlName=\"threshold\"\n        [attr.aria-invalid]=\"\n          form.get('threshold')?.touched && form.get('threshold')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'thresholdError'\"\n      />\n\n      <cx-form-errors\n        id=\"thresholdError\"\n        [translationParams]=\"{\n          label: 'orgPurchaseLimit.threshold' | cxTranslate,\n        }\"\n        [control]=\"form.get('threshold')\"\n      ></cx-form-errors>\n    </label>\n\n    <label [formGroup]=\"$any(form.get('orgUnit'))\">\n      <span class=\"label-content required\">\n        {{ 'orgPurchaseLimit.orgUnit' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"uid\"\n        [searchable]=\"true\"\n        [clearable]=\"false\"\n        [items]=\"(units$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"id\"\n        [readonly]=\"form.get('orgUnit')?.disabled ?? false\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgPurchaseLimit.orgUnit' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{\n          label: 'orgPurchaseLimit.orgUnit' | cxTranslate,\n        }\"\n        [control]=\"form.get('orgUnit.uid')\"\n      ></cx-form-errors>\n    </label>\n  </ng-container>\n</cx-org-form>\n" }]
        }], ctorParameters: () => [{ type: ItemService }, { type: i2.OrgUnitService }, { type: i1.CurrencyService }, { type: i2.PermissionService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PermissionFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: PermissionFormModule, imports: [CommonModule,
            RouterModule,
            NgSelectModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            FormErrorsModule,
            FormModule,
            ItemActiveModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            PermissionFormComponent], exports: [PermissionFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionFormModule, imports: [CommonModule,
            RouterModule,
            NgSelectModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            FormErrorsModule,
            FormModule,
            ItemActiveModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            PermissionFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        NgSelectModule,
                        UrlModule,
                        I18nModule,
                        ReactiveFormsModule,
                        FormErrorsModule,
                        FormModule,
                        ItemActiveModule,
                        FeaturesConfigModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        PermissionFormComponent,
                    ],
                    exports: [PermissionFormComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Service to populate permission data to `Table` data. The permission
 * data is driven by the table configuration, using the `OrganizationTables.PERMISSION`.
 */
class PermissionListService extends ListService {
    constructor(tableService, permissionsService) {
        super(tableService);
        this.tableService = tableService;
        this.permissionsService = permissionsService;
        this.tableType = OrganizationTableType.PERMISSION;
    }
    load(pagination) {
        return this.permissionsService.getList(pagination).pipe(filter(isNotUndefined), map((raw) => this.convertPermissions(raw)));
    }
    /**
     * Populates the permission data to a convenient table data model, so that we
     * can skip specific conversion in the view logic where possible.
     */
    convertPermissions({ pagination, sorts, values, }) {
        const permissionGroupModels = {
            pagination,
            sorts,
            values: values.map((value) => ({
                ...value,
                unit: value.orgUnit,
            })),
        };
        return permissionGroupModels;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionListService, deps: [{ token: i1$1.TableService }, { token: i2.PermissionService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.PermissionService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PermissionRoutePageMetaResolver extends DefaultRoutePageMetaResolver {
    constructor(translation, currentItemService) {
        super(translation);
        this.currentItemService = currentItemService;
    }
    getParams() {
        return this.currentItemService.item$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionRoutePageMetaResolver, deps: [{ token: i1.TranslationService }, { token: CurrentPermissionService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionRoutePageMetaResolver, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionRoutePageMetaResolver, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1.TranslationService }, { type: CurrentPermissionService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const permissionCmsConfig = {
    cmsComponents: {
        ManagePermissionsListComponent: {
            component: ListComponent,
            providers: [
                {
                    provide: ListService,
                    useExisting: PermissionListService,
                },
                {
                    provide: ItemService,
                    useExisting: PermissionItemService,
                },
            ],
            childRoutes: {
                parent: {
                    data: {
                        cxPageMeta: {
                            breadcrumb: 'orgPurchaseLimit.breadcrumbs.list',
                            resolver: PermissionRoutePageMetaResolver,
                        },
                    },
                },
                children: [
                    {
                        path: 'create',
                        component: PermissionFormComponent,
                    },
                    {
                        path: `:${ROUTE_PARAMS.permissionCode}`,
                        component: PermissionDetailsComponent,
                        data: {
                            cxPageMeta: {
                                breadcrumb: 'orgPurchaseLimit.breadcrumbs.details',
                            },
                        },
                        children: [
                            {
                                path: 'edit',
                                component: PermissionFormComponent,
                            },
                        ],
                    },
                ],
            },
            guards: [AuthGuard, AdminGuard],
        },
    },
};
function permissionTableConfigFactory() {
    return permisionTableConfig;
}
const permisionTableConfig = {
    table: {
        [OrganizationTableType.PERMISSION]: {
            cells: ['code', 'active', 'limit', 'unit'],
            options: {
                cells: {
                    code: {
                        dataComponent: ActiveLinkCellComponent,
                        linkable: true,
                    },
                    active: {
                        dataComponent: StatusCellComponent,
                    },
                    unit: {
                        dataComponent: UnitCellComponent,
                    },
                    limit: {
                        dataComponent: LimitCellComponent,
                    },
                },
            },
        },
    },
};
/**
 * @deprecated Use `permisionTableConfig` instead.
 */
const newPermissionTableConfig = permisionTableConfig;

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PermissionComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: PermissionComponentsModule, imports: [SharedOrganizationModule,
            PermissionDetailsModule,
            PermissionFormModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionComponentsModule, providers: [
            provideDefaultConfig(permissionCmsConfig),
            provideDefaultConfigFactory(permissionTableConfigFactory),
        ], imports: [SharedOrganizationModule,
            PermissionDetailsModule,
            PermissionFormModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        SharedOrganizationModule,
                        PermissionDetailsModule,
                        PermissionFormModule,
                    ],
                    providers: [
                        provideDefaultConfig(permissionCmsConfig),
                        provideDefaultConfigFactory(permissionTableConfigFactory),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CurrentUnitService extends CurrentItemService {
    constructor(routingService, orgUnitService) {
        super(routingService);
        this.routingService = routingService;
        this.orgUnitService = orgUnitService;
    }
    getParamKey() {
        return ROUTE_PARAMS.unitCode;
    }
    getItem(code) {
        return this.orgUnitService.get(code);
    }
    getError(code) {
        return this.orgUnitService.getErrorState(code);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUnitService, deps: [{ token: i1.RoutingService }, { token: i2.OrgUnitService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUnitService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUnitService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.RoutingService }, { type: i2.OrgUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitFormService extends FormService {
    patchData(item) {
        this.toggleParentUnit(item);
        super.patchData(item);
    }
    build() {
        const form = new UntypedFormGroup({});
        form.setControl('uid', new UntypedFormControl('', [
            Validators.required,
            CustomFormValidators.noSpecialCharacters,
        ]));
        form.setControl('name', new UntypedFormControl('', Validators.required));
        form.setControl('approvalProcess', new UntypedFormGroup({
            code: new UntypedFormControl(null),
        }));
        this.form = form;
        this.toggleParentUnit();
    }
    toggleParentUnit(item) {
        if (this.isRootUnit(item)) {
            this.form?.removeControl('parentOrgUnit');
        }
        else if (!this.form?.get('parentOrgUnit')) {
            this.form?.setControl('parentOrgUnit', new UntypedFormGroup({
                uid: new UntypedFormControl(null, Validators.required),
            }));
        }
    }
    isRootUnit(item) {
        // as we don't have full response after toggle item status,
        // we have situation where we have object like {uid, active},
        // so decided to check name as alternative required property
        return Boolean(item?.uid &&
            item?.name &&
            (!item?.parentOrgUnit || item?.uid === item?.parentOrgUnit));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitFormService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitFormService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitFormService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitItemService extends ItemService {
    constructor(currentItemService, routingService, formService, unitService) {
        super(currentItemService, routingService, formService);
        this.currentItemService = currentItemService;
        this.routingService = routingService;
        this.formService = formService;
        this.unitService = unitService;
    }
    /**
     * @override
     * Returns the unit for the given code.
     *
     * Loads the unit each time, to ensure accurate data is resolved.
     */
    load(code) {
        this.unitService.load(code);
        return this.unitService.get(code);
    }
    update(code, value) {
        this.unitService.update(code, value);
        return this.unitService.getLoadingStatus(value.uid ?? '');
    }
    create(value) {
        this.unitService.create(value);
        return this.unitService.getLoadingStatus(value.uid ?? '');
    }
    /**
     * @override
     * Returns 'unitDetails'
     */
    getDetailsRoute() {
        return 'orgUnitDetails';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitItemService, deps: [{ token: CurrentUnitService }, { token: i1.RoutingService }, { token: UnitFormService }, { token: i2.OrgUnitService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitItemService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitItemService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: CurrentUnitService }, { type: i1.RoutingService }, { type: UnitFormService }, { type: i2.OrgUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitDetailsComponent {
    get isA11yCardNotificationMessageFeatureEnabled() {
        return this.featureConfigService.isEnabled('a11yCardNotificationMessage');
    }
    constructor(itemService, orgUnitService) {
        this.itemService = itemService;
        this.orgUnitService = orgUnitService;
        this.featureConfigService = inject(FeatureConfigService);
        this.model$ = this.itemService.key$.pipe(switchMap((code) => this.itemService.load(code)), startWith({}));
        this.refreshFocusReference$ = this.model$.pipe(map((model) => model?.uid ?? model));
        this.isInEditMode$ = this.itemService.isInEditMode$;
        this.isUpdatingUnitAllowed = this.orgUnitService
            ? this.orgUnitService.isUpdatingUnitAllowed()
            : true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitDetailsComponent, deps: [{ token: ItemService }, { token: i2.OrgUnitService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitDetailsComponent, isStandalone: true, selector: "cx-org-unit-details", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ItemService,
                useExisting: UnitItemService,
            },
        ], ngImport: i0, template: "<cx-org-card\n  *ngIf=\"model$ | async as model\"\n  i18nRoot=\"orgUnit.details\"\n  [cxFocus]=\"\n    isA11yCardNotificationMessageFeatureEnabled\n      ? { refreshFocus: (refreshFocusReference$ | async) }\n      : { refreshFocus: model }\n  \"\n  [showHint]=\"true\"\n>\n  <a\n    actions\n    *ngIf=\"isUpdatingUnitAllowed\"\n    class=\"link btn btn-link btn-sm edit\"\n    [class.disabled]=\"!model.active || (isInEditMode$ | async)\"\n    [routerLink]=\"{ cxRoute: 'orgUnitEdit', params: model } | cxUrl\"\n  >\n    {{ 'organization.edit' | cxTranslate }}\n  </a>\n\n  <cx-org-toggle-status\n    actions\n    key=\"uid\"\n    *ngIf=\"isUpdatingUnitAllowed\"\n    i18nRoot=\"orgUnit\"\n  ></cx-org-toggle-status>\n\n  <cx-org-disable-info\n    info\n    i18nRoot=\"orgUnit\"\n    [displayInfoConfig]=\"{ disabledDisable: true }\"\n  >\n  </cx-org-disable-info>\n\n  <section main class=\"details\" cxOrgItemExists>\n    <div class=\"property\">\n      <label>{{ 'orgUnit.name' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.name }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUnit.uid' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.uid }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUnit.active' | cxTranslate }}</label>\n      <span class=\"value\" [class.is-active]=\"model.active\">\n        {{\n          (model.active ? 'organization.enabled' : 'organization.disabled')\n            | cxTranslate\n        }}\n      </span>\n    </div>\n\n    <div class=\"property\" *ngIf=\"model.approvalProcess?.name\">\n      <label>{{ 'orgUnit.approvalProcess' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.approvalProcess?.name }}\n      </span>\n    </div>\n\n    <div class=\"property\" *ngIf=\"model.parentOrgUnit\">\n      <label>{{ 'orgUnit.parentUnit' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [ariaLabel]=\"\n          model.parentOrgUnit?.name ?? ('orgUnit.parentUnit' | cxTranslate)\n        \"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.parentOrgUnit,\n          } | cxUrl\n        \"\n      >\n        {{ model.parentOrgUnit?.name }}\n      </a>\n    </div>\n  </section>\n\n  <section main class=\"link-list\">\n    <ng-container *ngIf=\"model.uid\">\n      <a\n        class=\"link btn btn-link btn-sm\"\n        *ngIf=\"isUpdatingUnitAllowed\"\n        [routerLink]=\"{ cxRoute: 'orgUnitChildren', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUnit.links.units' | cxTranslate }}\n      </a>\n      <a\n        class=\"link btn btn-link btn-sm\"\n        [routerLink]=\"{ cxRoute: 'orgUnitUserList', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUnit.links.users' | cxTranslate }}\n      </a>\n      <a\n        class=\"link\"\n        [routerLink]=\"{ cxRoute: 'orgUnitApprovers', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUnit.links.approvers' | cxTranslate }}\n      </a>\n      <a\n        class=\"link\"\n        [routerLink]=\"{ cxRoute: 'orgUnitAddressList', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUnit.links.shippingAddresses' | cxTranslate }}\n      </a>\n      <a\n        class=\"link\"\n        [routerLink]=\"{ cxRoute: 'orgUnitCostCenters', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUnit.links.costCenters' | cxTranslate }}\n      </a>\n    </ng-container>\n  </section>\n</cx-org-card>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CardComponent, selector: "cx-org-card", inputs: ["i18nRoot", "previous", "subtitle", "showHint"] }, { kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: ToggleStatusComponent, selector: "cx-org-toggle-status", inputs: ["i18nRoot", "key", "disabled"] }, { kind: "component", type: DisableInfoComponent, selector: "cx-org-disable-info", inputs: ["i18nRoot", "displayInfoConfig", "displayCustomInfo"] }, { kind: "directive", type: ItemExistsDirective, selector: "[cxOrgItemExists]" }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-unit-details', changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: ItemService,
                            useExisting: UnitItemService,
                        },
                    ], host: { class: 'content-wrapper' }, imports: [
                        NgIf,
                        CardComponent,
                        FocusDirective,
                        RouterLink,
                        ToggleStatusComponent,
                        DisableInfoComponent,
                        ItemExistsDirective,
                        RouterLinkActive,
                        AsyncPipe,
                        UrlPipe,
                        TranslatePipe,
                    ], template: "<cx-org-card\n  *ngIf=\"model$ | async as model\"\n  i18nRoot=\"orgUnit.details\"\n  [cxFocus]=\"\n    isA11yCardNotificationMessageFeatureEnabled\n      ? { refreshFocus: (refreshFocusReference$ | async) }\n      : { refreshFocus: model }\n  \"\n  [showHint]=\"true\"\n>\n  <a\n    actions\n    *ngIf=\"isUpdatingUnitAllowed\"\n    class=\"link btn btn-link btn-sm edit\"\n    [class.disabled]=\"!model.active || (isInEditMode$ | async)\"\n    [routerLink]=\"{ cxRoute: 'orgUnitEdit', params: model } | cxUrl\"\n  >\n    {{ 'organization.edit' | cxTranslate }}\n  </a>\n\n  <cx-org-toggle-status\n    actions\n    key=\"uid\"\n    *ngIf=\"isUpdatingUnitAllowed\"\n    i18nRoot=\"orgUnit\"\n  ></cx-org-toggle-status>\n\n  <cx-org-disable-info\n    info\n    i18nRoot=\"orgUnit\"\n    [displayInfoConfig]=\"{ disabledDisable: true }\"\n  >\n  </cx-org-disable-info>\n\n  <section main class=\"details\" cxOrgItemExists>\n    <div class=\"property\">\n      <label>{{ 'orgUnit.name' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.name }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUnit.uid' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.uid }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUnit.active' | cxTranslate }}</label>\n      <span class=\"value\" [class.is-active]=\"model.active\">\n        {{\n          (model.active ? 'organization.enabled' : 'organization.disabled')\n            | cxTranslate\n        }}\n      </span>\n    </div>\n\n    <div class=\"property\" *ngIf=\"model.approvalProcess?.name\">\n      <label>{{ 'orgUnit.approvalProcess' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.approvalProcess?.name }}\n      </span>\n    </div>\n\n    <div class=\"property\" *ngIf=\"model.parentOrgUnit\">\n      <label>{{ 'orgUnit.parentUnit' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [ariaLabel]=\"\n          model.parentOrgUnit?.name ?? ('orgUnit.parentUnit' | cxTranslate)\n        \"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.parentOrgUnit,\n          } | cxUrl\n        \"\n      >\n        {{ model.parentOrgUnit?.name }}\n      </a>\n    </div>\n  </section>\n\n  <section main class=\"link-list\">\n    <ng-container *ngIf=\"model.uid\">\n      <a\n        class=\"link btn btn-link btn-sm\"\n        *ngIf=\"isUpdatingUnitAllowed\"\n        [routerLink]=\"{ cxRoute: 'orgUnitChildren', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUnit.links.units' | cxTranslate }}\n      </a>\n      <a\n        class=\"link btn btn-link btn-sm\"\n        [routerLink]=\"{ cxRoute: 'orgUnitUserList', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUnit.links.users' | cxTranslate }}\n      </a>\n      <a\n        class=\"link\"\n        [routerLink]=\"{ cxRoute: 'orgUnitApprovers', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUnit.links.approvers' | cxTranslate }}\n      </a>\n      <a\n        class=\"link\"\n        [routerLink]=\"{ cxRoute: 'orgUnitAddressList', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUnit.links.shippingAddresses' | cxTranslate }}\n      </a>\n      <a\n        class=\"link\"\n        [routerLink]=\"{ cxRoute: 'orgUnitCostCenters', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUnit.links.costCenters' | cxTranslate }}\n      </a>\n    </ng-container>\n  </section>\n</cx-org-card>\n" }]
        }], ctorParameters: () => [{ type: ItemService }, { type: i2.OrgUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitDetailsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitDetailsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitDetailsModule, imports: [CommonModule,
            CardModule,
            RouterModule,
            UrlModule,
            I18nModule,
            ToggleStatusModule,
            ItemExistsModule,
            KeyboardFocusModule,
            DisableInfoModule,
            UnitDetailsComponent], exports: [UnitDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitDetailsModule, imports: [CommonModule,
            CardModule,
            RouterModule,
            UrlModule,
            I18nModule,
            ToggleStatusModule,
            ItemExistsModule,
            KeyboardFocusModule,
            DisableInfoModule,
            UnitDetailsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitDetailsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        CardModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        ToggleStatusModule,
                        ItemExistsModule,
                        KeyboardFocusModule,
                        DisableInfoModule,
                        UnitDetailsComponent,
                    ],
                    exports: [UnitDetailsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitFormComponent {
    constructor(itemService, unitService) {
        this.itemService = itemService;
        this.unitService = unitService;
        this.i18nRoot = 'orgUnit';
        this.createChildUnit = false;
        this.form = this.itemService.getForm();
        this.units$ = this.itemService.unit$.pipe(tap((unit) => {
            this.form?.get('parentOrgUnit.uid')?.setValue(unit);
            if (this.createChildUnit) {
                this.form?.get('parentOrgUnit')?.disable();
            }
        }), switchMap(() => this.unitService.getActiveUnitList().pipe(map((units) => units?.filter((unit) => unit.id !== this.form?.value.uid)), tap((units) => {
            if (units && units.length === 1) {
                this.form?.get('parentOrgUnit.uid')?.setValue(units[0]?.id);
            }
        }))));
        this.approvalProcess$ = this.unitService
            .getApprovalProcesses()
            .pipe(filter(isNotUndefined), filter((items) => items.length > 0));
    }
    ngOnInit() {
        this.unitService.loadList();
    }
    createUidWithName(name, code) {
        createCodeForEntityName(name, code);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitFormComponent, deps: [{ token: ItemService }, { token: i2.OrgUnitService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitFormComponent, isStandalone: true, selector: "cx-org-unit-form", inputs: { i18nRoot: "i18nRoot", createChildUnit: "createChildUnit" }, host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ItemService,
                useExisting: UnitItemService,
            },
            {
                provide: CurrentItemService,
                useExisting: CurrentUnitService,
            },
        ], ngImport: i0, template: "<cx-org-form [i18nRoot]=\"i18nRoot\">\n  <ng-container *ngIf=\"form\" [formGroup]=\"form\" main>\n    <cx-form-required-legend />\n    <label>\n      <span class=\"label-content required\">\n        <span>{{ 'orgUnit.name' | cxTranslate }}</span>\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        required\n        placeholder=\"{{ 'orgUnit.name' | cxTranslate }}\"\n        formControlName=\"name\"\n        (blur)=\"createUidWithName(form.get('name'), form.get('uid'))\"\n        [attr.aria-invalid]=\"\n          form.get('name')?.touched && form.get('name')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'nameError'\"\n      />\n\n      <cx-form-errors\n        id=\"nameError\"\n        [translationParams]=\"{\n          label: 'orgUnit.name' | cxTranslate,\n        }\"\n        [control]=\"form.get('name')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\">\n        <span>{{ 'orgUnit.uid' | cxTranslate }}</span>\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        class=\"form-control\"\n        type=\"text\"\n        required\n        placeholder=\"{{ 'orgUnit.uid' | cxTranslate }}\"\n        formControlName=\"uid\"\n        [attr.aria-invalid]=\"\n          form.get('uid')?.touched && form.get('uid')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'uidError'\"\n      />\n\n      <cx-form-errors\n        id=\"uidError\"\n        [translationParams]=\"{\n          label: 'orgUnit.uid' | cxTranslate,\n        }\"\n        [control]=\"form.get('uid')\"\n      ></cx-form-errors>\n    </label>\n\n    <label formGroupName=\"approvalProcess\" class=\"full-width\">\n      <span class=\"label-content required\">{{\n        'orgUnit.approvalProcess' | cxTranslate\n      }}</span>\n      <ng-select\n        formControlName=\"code\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"(approvalProcess$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"code\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgUnit.approvalProcess' | cxTranslate\"\n        [attr.aria-invalid]=\"\n          form.get('code')?.touched && form.get('code')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'codeError'\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n        [cxNgSelectA11y]=\"{}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        id=\"codeError\"\n        [translationParams]=\"{\n          label: 'orgUnit.approvalProcess' | cxTranslate,\n        }\"\n        [control]=\"form.get('approvalProcess.code')\"\n      ></cx-form-errors>\n    </label>\n    <ng-container *ngIf=\"form.get('parentOrgUnit'); else parentOrgUnitNotes\">\n      <label formGroupName=\"parentOrgUnit\">\n        <span class=\"label-content required\">\n          {{ 'orgUnit.form.parentOrgUnit' | cxTranslate }}\n          <cx-form-required-asterisks />\n        </span>\n        <ng-select\n          [inputAttrs]=\"{ required: 'true' }\"\n          formControlName=\"uid\"\n          [searchable]=\"true\"\n          [clearable]=\"false\"\n          [items]=\"(units$ | async) ?? []\"\n          bindLabel=\"name\"\n          bindValue=\"id\"\n          appendTo=\"cx-org-list\"\n          [placeholder]=\"'orgUnit.form.parentOrgUnit' | cxTranslate\"\n          ariaLabelDropdown=\"{{\n            'common.ngSelectDropdownOptionsList' | cxTranslate\n          }}\"\n          [cxNgSelectA11y]=\"{}\"\n          [attr.aria-invalid]=\"\n            form.get('uid')?.touched && form.get('uid')?.invalid\n          \"\n          [attr.aria-errormessage]=\"'codeError'\"\n        >\n        </ng-select>\n\n        <cx-form-errors\n          id=\"parentUnitUidError\"\n          [translationParams]=\"{\n            label: 'orgUnit.form.parentOrgUnit' | cxTranslate,\n          }\"\n          [control]=\"form.get('parentOrgUnit.uid')\"\n        ></cx-form-errors>\n      </label>\n    </ng-container>\n    <ng-template #parentOrgUnitNotes>\n      <span class=\"notes-content\">{{\n        'orgUnit.form.parentOrgUnitNotes' | cxTranslate\n      }}</span>\n    </ng-template>\n  </ng-container>\n</cx-org-form>\n", dependencies: [{ kind: "component", type: FormComponent, selector: "cx-org-form", inputs: ["i18nRoot", "animateBack", "subtitle"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i4.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i4.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i4.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: i4.FormGroupName, selector: "[formGroupName]", inputs: ["formGroupName"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "directive", type: NgSelectA11yDirective, selector: "[cxNgSelectA11y]", inputs: ["cxNgSelectA11y"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-unit-form', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ItemService,
                            useExisting: UnitItemService,
                        },
                        {
                            provide: CurrentItemService,
                            useExisting: CurrentUnitService,
                        },
                    ], imports: [
                        FormComponent,
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredLegendComponent,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        NgSelectComponent,
                        NgSelectA11yDirective,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<cx-org-form [i18nRoot]=\"i18nRoot\">\n  <ng-container *ngIf=\"form\" [formGroup]=\"form\" main>\n    <cx-form-required-legend />\n    <label>\n      <span class=\"label-content required\">\n        <span>{{ 'orgUnit.name' | cxTranslate }}</span>\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        required\n        placeholder=\"{{ 'orgUnit.name' | cxTranslate }}\"\n        formControlName=\"name\"\n        (blur)=\"createUidWithName(form.get('name'), form.get('uid'))\"\n        [attr.aria-invalid]=\"\n          form.get('name')?.touched && form.get('name')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'nameError'\"\n      />\n\n      <cx-form-errors\n        id=\"nameError\"\n        [translationParams]=\"{\n          label: 'orgUnit.name' | cxTranslate,\n        }\"\n        [control]=\"form.get('name')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\">\n        <span>{{ 'orgUnit.uid' | cxTranslate }}</span>\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        class=\"form-control\"\n        type=\"text\"\n        required\n        placeholder=\"{{ 'orgUnit.uid' | cxTranslate }}\"\n        formControlName=\"uid\"\n        [attr.aria-invalid]=\"\n          form.get('uid')?.touched && form.get('uid')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'uidError'\"\n      />\n\n      <cx-form-errors\n        id=\"uidError\"\n        [translationParams]=\"{\n          label: 'orgUnit.uid' | cxTranslate,\n        }\"\n        [control]=\"form.get('uid')\"\n      ></cx-form-errors>\n    </label>\n\n    <label formGroupName=\"approvalProcess\" class=\"full-width\">\n      <span class=\"label-content required\">{{\n        'orgUnit.approvalProcess' | cxTranslate\n      }}</span>\n      <ng-select\n        formControlName=\"code\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"(approvalProcess$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"code\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgUnit.approvalProcess' | cxTranslate\"\n        [attr.aria-invalid]=\"\n          form.get('code')?.touched && form.get('code')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'codeError'\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n        [cxNgSelectA11y]=\"{}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        id=\"codeError\"\n        [translationParams]=\"{\n          label: 'orgUnit.approvalProcess' | cxTranslate,\n        }\"\n        [control]=\"form.get('approvalProcess.code')\"\n      ></cx-form-errors>\n    </label>\n    <ng-container *ngIf=\"form.get('parentOrgUnit'); else parentOrgUnitNotes\">\n      <label formGroupName=\"parentOrgUnit\">\n        <span class=\"label-content required\">\n          {{ 'orgUnit.form.parentOrgUnit' | cxTranslate }}\n          <cx-form-required-asterisks />\n        </span>\n        <ng-select\n          [inputAttrs]=\"{ required: 'true' }\"\n          formControlName=\"uid\"\n          [searchable]=\"true\"\n          [clearable]=\"false\"\n          [items]=\"(units$ | async) ?? []\"\n          bindLabel=\"name\"\n          bindValue=\"id\"\n          appendTo=\"cx-org-list\"\n          [placeholder]=\"'orgUnit.form.parentOrgUnit' | cxTranslate\"\n          ariaLabelDropdown=\"{{\n            'common.ngSelectDropdownOptionsList' | cxTranslate\n          }}\"\n          [cxNgSelectA11y]=\"{}\"\n          [attr.aria-invalid]=\"\n            form.get('uid')?.touched && form.get('uid')?.invalid\n          \"\n          [attr.aria-errormessage]=\"'codeError'\"\n        >\n        </ng-select>\n\n        <cx-form-errors\n          id=\"parentUnitUidError\"\n          [translationParams]=\"{\n            label: 'orgUnit.form.parentOrgUnit' | cxTranslate,\n          }\"\n          [control]=\"form.get('parentOrgUnit.uid')\"\n        ></cx-form-errors>\n      </label>\n    </ng-container>\n    <ng-template #parentOrgUnitNotes>\n      <span class=\"notes-content\">{{\n        'orgUnit.form.parentOrgUnitNotes' | cxTranslate\n      }}</span>\n    </ng-template>\n  </ng-container>\n</cx-org-form>\n" }]
        }], ctorParameters: () => [{ type: ItemService }, { type: i2.OrgUnitService }], propDecorators: { i18nRoot: [{
                type: Input
            }], createChildUnit: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitFormModule, imports: [CommonModule,
            RouterModule,
            FormModule,
            NgSelectModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            FormErrorsModule,
            ItemActiveModule,
            FeaturesConfigModule,
            NgSelectA11yModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            UnitFormComponent], exports: [UnitFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitFormModule, imports: [CommonModule,
            RouterModule,
            FormModule,
            NgSelectModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            FormErrorsModule,
            ItemActiveModule,
            FeaturesConfigModule,
            NgSelectA11yModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            UnitFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        FormModule,
                        NgSelectModule,
                        UrlModule,
                        I18nModule,
                        ReactiveFormsModule,
                        FormErrorsModule,
                        ItemActiveModule,
                        FeaturesConfigModule,
                        NgSelectA11yModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        UnitFormComponent,
                    ],
                    exports: [UnitFormComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CurrentUnitAddressService extends CurrentItemService {
    constructor(routingService, unitService) {
        super(routingService);
        this.routingService = routingService;
        this.unitService = unitService;
        // override item$ as we need to use the unit code as well
        this.item$ = this.b2bUnit$.pipe(filter((unitUid) => Boolean(unitUid)), switchMap((unitUid) => this.key$.pipe(switchMap((code) => this.getItem(unitUid, code)))));
    }
    getDetailsRoute() {
        return 'orgUnitAddressDetails';
    }
    getParamKey() {
        return ROUTE_PARAMS.addressCode;
    }
    getItem(unitUid, addressId) {
        return addressId
            ? this.unitService.getAddress(unitUid, addressId)
            : of(undefined);
    }
    getError(code) {
        return this.unitService.getErrorState(code);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUnitAddressService, deps: [{ token: i1.RoutingService }, { token: i2.OrgUnitService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUnitAddressService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUnitAddressService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.RoutingService }, { type: i2.OrgUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitAddressFormService extends FormService {
    constructor(userAddressService, userProfileFacade) {
        super();
        this.userAddressService = userAddressService;
        this.userProfileFacade = userProfileFacade;
    }
    build() {
        const form = new UntypedFormGroup({});
        form.setControl('id', new UntypedFormControl(''));
        form.setControl('titleCode', new UntypedFormControl(''));
        form.setControl('firstName', new UntypedFormControl('', Validators.required));
        form.setControl('lastName', new UntypedFormControl('', Validators.required));
        form.setControl('line1', new UntypedFormControl('', Validators.required));
        form.setControl('line2', new UntypedFormControl(''));
        form.setControl('town', new UntypedFormControl('', Validators.required));
        form.setControl('country', new UntypedFormGroup({
            isocode: new UntypedFormControl(null, Validators.required),
        }));
        form.setControl('region', new UntypedFormGroup({
            isocode: new UntypedFormControl(null, Validators.required),
        }));
        form.setControl('postalCode', new UntypedFormControl('', Validators.required));
        form.setControl('phone', new UntypedFormControl(''));
        form.setControl('cellphone', new UntypedFormControl(''));
        this.form = form;
    }
    getCountries() {
        return this.userAddressService.getDeliveryCountries().pipe(tap((countries) => {
            if (Object.keys(countries).length === 0) {
                this.userAddressService.loadDeliveryCountries();
            }
        }));
    }
    getTitles() {
        return this.userProfileFacade.getTitles();
    }
    getRegions() {
        let selectedCountryCode = this.form?.get('country.isocode')?.value;
        let newCountryCode;
        return (this.getForm()
            ?.get('country.isocode')
            ?.valueChanges.pipe(filter((countryIsoCode) => Boolean(countryIsoCode)), switchMap((countryIsoCode) => {
            newCountryCode = countryIsoCode;
            return this.userAddressService.getRegions(countryIsoCode);
        }), tap((regions) => {
            const regionControl = this.form?.get('region.isocode');
            if (!regions || regions.length === 0) {
                regionControl?.disable();
            }
            else {
                regionControl?.enable();
            }
            if (selectedCountryCode && newCountryCode !== selectedCountryCode) {
                regionControl?.reset();
            }
            selectedCountryCode = newCountryCode;
        })) ?? of([]));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressFormService, deps: [{ token: i1.UserAddressService }, { token: i2$1.UserProfileFacade }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressFormService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressFormService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.UserAddressService }, { type: i2$1.UserProfileFacade }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitAddressItemService extends ItemService {
    constructor(currentItemService, routingService, formService, unitService) {
        super(currentItemService, routingService, formService);
        this.currentItemService = currentItemService;
        this.routingService = routingService;
        this.formService = formService;
        this.unitService = unitService;
        this.unitRouteParam$ = this.routingService.getParams().pipe(map((params) => params[ROUTE_PARAMS.unitCode]), distinctUntilChanged());
    }
    load(unitUid, addressId) {
        return this.unitService
            .getAddress(unitUid, addressId)
            .pipe(filter(isNotUndefined));
    }
    update(addressCode, address) {
        this.unitRouteParam$.pipe(first()).subscribe((unitCode) => {
            this.unitService.updateAddress(unitCode, addressCode, address);
        });
        return this.unitService.getAddressLoadingStatus(addressCode);
    }
    create(value) {
        // Note: No id or code is provided when creating a new address so we
        // cannot store a value in the ngrx state to check that address to be
        // created via the loading state. That is why we need to assign some
        // temporary value to the id.
        value.id = 'new';
        this.unitRouteParam$
            .pipe(first())
            .subscribe((unitCode) => this.unitService.createAddress(unitCode, value));
        return this.unitService.getAddressLoadingStatus(value.id ?? '');
    }
    getDetailsRoute() {
        return this.currentItemService.getDetailsRoute();
    }
    delete(addressId, unitUid) {
        this.launchList();
        this.unitService.deleteAddress(unitUid, addressId);
        return this.unitService.getAddressLoadingStatus(addressId);
    }
    launchDetails(item) {
        if (!item.id) {
            // since the ID is generated in the backend
            // we redirect to the list instead.
            this.launchList();
        }
        else {
            this.unitRouteParam$.pipe(first()).subscribe((unitCode) => {
                this.routingService.go({
                    cxRoute: this.getDetailsRoute(),
                    params: { ...item, uid: unitCode },
                });
            });
        }
    }
    launchList() {
        this.unitRouteParam$.pipe(first()).subscribe((unitCode) => {
            this.routingService.go({
                cxRoute: 'orgUnitAddressList',
                params: { uid: unitCode },
            });
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressItemService, deps: [{ token: CurrentUnitAddressService }, { token: i1.RoutingService }, { token: UnitAddressFormService }, { token: i2.OrgUnitService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressItemService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressItemService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: CurrentUnitAddressService }, { type: i1.RoutingService }, { type: UnitAddressFormService }, { type: i2.OrgUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitAddressDetailsComponent {
    getCountry(isoCode) {
        return this.userAddressService.getDeliveryCountries().pipe(tap((countries) => {
            if (Object.keys(countries).length === 0) {
                this.userAddressService.loadDeliveryCountries();
            }
        }), map((countries) => countries.find((country) => country.isocode === isoCode)));
    }
    constructor(itemService, currentUnitService, userAddressService) {
        this.itemService = itemService;
        this.currentUnitService = currentUnitService;
        this.userAddressService = userAddressService;
        this.unit$ = this.currentUnitService.item$;
        this.model$ = this.itemService.key$.pipe(withLatestFrom(this.unit$), switchMap(([code, unit]) => this.itemService.load(unit?.uid, code)), shareReplay({ bufferSize: 1, refCount: true }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressDetailsComponent, deps: [{ token: ItemService }, { token: CurrentUnitService }, { token: i1.UserAddressService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitAddressDetailsComponent, isStandalone: true, selector: "cx-org-unit-address-details", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ItemService,
                useExisting: UnitAddressItemService,
            },
        ], ngImport: i0, template: "<ng-container *ngIf=\"unit$ | async as unit\">\n  <cx-org-card\n    *ngIf=\"model$ | async as model\"\n    i18nRoot=\"orgUnitAddress.details\"\n    [subtitle]=\"'orgUnitAddress.details.subtitle' | cxTranslate: { item: unit }\"\n    [cxFocus]=\"{ refreshFocus: model }\"\n  >\n    <a class=\"link btn btn-link btn-sm\" actions routerLink=\"edit\">\n      {{ 'organization.edit' | cxTranslate }}\n    </a>\n\n    <cx-org-delete-item\n      actions\n      key=\"id\"\n      [additionalParam]=\"unit.uid\"\n      i18nRoot=\"orgUnitAddress\"\n    ></cx-org-delete-item>\n\n    <section main class=\"details\">\n      <div class=\"property\">\n        <label>{{ 'orgUnit.name' | cxTranslate }}</label>\n        <span class=\"value\"> {{ model.firstName }} {{ model.lastName }} </span>\n      </div>\n\n      <div class=\"property\">\n        <label>{{ 'orgUnit.unit' | cxTranslate }}</label>\n        <span class=\"value\">\n          <a\n            [routerLink]=\"\n              {\n                cxRoute: 'orgUnitDetails',\n                params: unit,\n              } | cxUrl\n            \"\n          >\n            {{ unit.name }}\n          </a>\n        </span>\n      </div>\n\n      <div class=\"property full-width\">\n        <label>{{ 'orgUnitAddress.formattedAddress' | cxTranslate }}</label>\n        <span class=\"value\">\n          {{ model.formattedAddress }}\n        </span>\n      </div>\n\n      <div class=\"property\">\n        <label>{{ 'orgUnitAddress.country' | cxTranslate }}</label>\n        <span class=\"value\">\n          {{ (getCountry(model.country?.isocode) | async)?.name }}\n        </span>\n      </div>\n    </section>\n  </cx-org-card>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CardComponent, selector: "cx-org-card", inputs: ["i18nRoot", "previous", "subtitle", "showHint"] }, { kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: DeleteItemComponent, selector: "cx-org-delete-item", inputs: ["i18nRoot", "key", "additionalParam"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-unit-address-details', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ItemService,
                            useExisting: UnitAddressItemService,
                        },
                    ], imports: [
                        NgIf,
                        CardComponent,
                        FocusDirective,
                        RouterLink,
                        DeleteItemComponent,
                        AsyncPipe,
                        UrlPipe,
                        TranslatePipe,
                    ], template: "<ng-container *ngIf=\"unit$ | async as unit\">\n  <cx-org-card\n    *ngIf=\"model$ | async as model\"\n    i18nRoot=\"orgUnitAddress.details\"\n    [subtitle]=\"'orgUnitAddress.details.subtitle' | cxTranslate: { item: unit }\"\n    [cxFocus]=\"{ refreshFocus: model }\"\n  >\n    <a class=\"link btn btn-link btn-sm\" actions routerLink=\"edit\">\n      {{ 'organization.edit' | cxTranslate }}\n    </a>\n\n    <cx-org-delete-item\n      actions\n      key=\"id\"\n      [additionalParam]=\"unit.uid\"\n      i18nRoot=\"orgUnitAddress\"\n    ></cx-org-delete-item>\n\n    <section main class=\"details\">\n      <div class=\"property\">\n        <label>{{ 'orgUnit.name' | cxTranslate }}</label>\n        <span class=\"value\"> {{ model.firstName }} {{ model.lastName }} </span>\n      </div>\n\n      <div class=\"property\">\n        <label>{{ 'orgUnit.unit' | cxTranslate }}</label>\n        <span class=\"value\">\n          <a\n            [routerLink]=\"\n              {\n                cxRoute: 'orgUnitDetails',\n                params: unit,\n              } | cxUrl\n            \"\n          >\n            {{ unit.name }}\n          </a>\n        </span>\n      </div>\n\n      <div class=\"property full-width\">\n        <label>{{ 'orgUnitAddress.formattedAddress' | cxTranslate }}</label>\n        <span class=\"value\">\n          {{ model.formattedAddress }}\n        </span>\n      </div>\n\n      <div class=\"property\">\n        <label>{{ 'orgUnitAddress.country' | cxTranslate }}</label>\n        <span class=\"value\">\n          {{ (getCountry(model.country?.isocode) | async)?.name }}\n        </span>\n      </div>\n    </section>\n  </cx-org-card>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: ItemService }, { type: CurrentUnitService }, { type: i1.UserAddressService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitAddressDetailsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressDetailsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressDetailsModule, imports: [CommonModule,
            CardModule,
            RouterModule,
            UrlModule,
            I18nModule,
            DeleteItemModule,
            KeyboardFocusModule,
            UnitAddressDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressDetailsModule, imports: [CommonModule,
            CardModule,
            RouterModule,
            UrlModule,
            I18nModule,
            DeleteItemModule,
            KeyboardFocusModule,
            UnitAddressDetailsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressDetailsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        CardModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        DeleteItemModule,
                        KeyboardFocusModule,
                        UnitAddressDetailsComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class LinkCellComponent extends CellComponent {
    constructor(outlet, itemService) {
        super(outlet);
        this.outlet = outlet;
        this.itemService = itemService;
        this.unitKey$ = this.itemService.key$;
    }
    get tabIndex() {
        return 0;
    }
    getRouterModel(uid) {
        return { ...this.outlet.context, uid };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: LinkCellComponent, deps: [{ token: i1$1.OutletContextData }, { token: ItemService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: LinkCellComponent, isStandalone: true, selector: "cx-org-link-cell", usesInheritance: true, ngImport: i0, template: `
    <ng-container *ngIf="unitKey$ | async as uid">
      <a
        *ngIf="linkable; else text"
        [routerLink]="{ cxRoute: route, params: getRouterModel(uid) } | cxUrl"
        [tabIndex]="tabIndex"
      >
        <ng-container *ngTemplateOutlet="text"></ng-container>
      </a>
    </ng-container>

    <ng-template #text>
      <span class="text" title="{{ property }}">{{ property }}</span>
    </ng-template>
  `, isInline: true, dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: LinkCellComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'cx-org-link-cell',
                    template: `
    <ng-container *ngIf="unitKey$ | async as uid">
      <a
        *ngIf="linkable; else text"
        [routerLink]="{ cxRoute: route, params: getRouterModel(uid) } | cxUrl"
        [tabIndex]="tabIndex"
      >
        <ng-container *ngTemplateOutlet="text"></ng-container>
      </a>
    </ng-container>

    <ng-template #text>
      <span class="text" title="{{ property }}">{{ property }}</span>
    </ng-template>
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [NgIf, RouterLink, NgTemplateOutlet, AsyncPipe, UrlPipe],
                }]
        }], ctorParameters: () => [{ type: i1$1.OutletContextData }, { type: ItemService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitAddressListService extends SubListService {
    constructor(tableService, orgUnitService) {
        super(tableService);
        this.tableService = tableService;
        this.orgUnitService = orgUnitService;
        this.tableType = OrganizationTableType.UNIT_ADDRESS;
        this._domainType = OrganizationTableType.UNIT_ADDRESS;
    }
    load(_pagination, code) {
        return this.orgUnitService.getAddresses(code);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressListService, deps: [{ token: i1$1.TableService }, { token: i2.OrgUnitService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.OrgUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitAddressListComponent {
    constructor() {
        this.routerKey = ROUTE_PARAMS.addressCode;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitAddressListComponent, isStandalone: true, selector: "cx-org-unit-address-list", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: UnitAddressListService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list\n  key=\"id\"\n  [routerKey]=\"routerKey\"\n  class=\"has-nested-view\"\n  [showHint]=\"true\"\n>\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"create\">\n    {{ 'organization.create' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-unit-address-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: UnitAddressListService,
                        },
                    ], imports: [SubListComponent, RouterLink, TranslatePipe], template: "<cx-org-sub-list\n  key=\"id\"\n  [routerKey]=\"routerKey\"\n  class=\"has-nested-view\"\n  [showHint]=\"true\"\n>\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"create\">\n    {{ 'organization.create' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitAddressListModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressListModule, imports: [CommonModule,
            I18nModule,
            RouterModule,
            UrlModule,
            SubListModule,
            UnitAddressListComponent,
            LinkCellComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressListModule, imports: [CommonModule,
            I18nModule,
            RouterModule,
            UrlModule,
            SubListModule,
            UnitAddressListComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        RouterModule,
                        UrlModule,
                        SubListModule,
                        UnitAddressListComponent,
                        LinkCellComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitAddressFormComponent {
    constructor(itemService, formService, currentUnitService) {
        this.itemService = itemService;
        this.formService = formService;
        this.currentUnitService = currentUnitService;
        this.form = this.itemService.getForm();
        this.key$ = this.itemService.key$;
        this.countries$ = this.formService.getCountries();
        this.titles$ = this.formService.getTitles();
        this.regions$ = this.formService.getRegions();
        this.unit$ = this.currentUnitService.item$;
    }
    /* eslint @angular-eslint/no-empty-lifecycle-method: 1 */
    ngOnInit() {
        // Intentional empty method
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressFormComponent, deps: [{ token: ItemService }, { token: UnitAddressFormService }, { token: CurrentUnitService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitAddressFormComponent, isStandalone: true, selector: "cx-org-unit-address-form", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ItemService,
                useExisting: UnitAddressItemService,
            },
        ], ngImport: i0, template: "<cx-org-form\n  i18nRoot=\"orgUnitAddress\"\n  [animateBack]=\"!(key$ | async)\"\n  [subtitle]=\"\n    'orgUnitAddress.details.subtitle' | cxTranslate: { item: (unit$ | async) }\n  \"\n>\n  <ng-container *ngIf=\"form\" [formGroup]=\"form\" main>\n    <cx-form-required-legend />\n    <label formGroupName=\"country\">\n      <span class=\"label-content required\"\n        >{{ 'orgUnitAddress.country' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        class=\"country-select\"\n        formControlName=\"isocode\"\n        [searchable]=\"true\"\n        [clearable]=\"false\"\n        [items]=\"(countries$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"isocode\"\n        placeholder=\"{{ 'orgUnitAddress.selectOne' | cxTranslate }}\"\n        appendTo=\"cx-org-list\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{ label: 'orgUnitAddress.country' | cxTranslate }\"\n        [control]=\"form.get('country.isocode')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\">{{\n        'orgUnitAddress.titles' | cxTranslate\n      }}</span>\n      <ng-select\n        formControlName=\"titleCode\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"(titles$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"code\"\n        placeholder=\"{{ 'orgUnitAddress.selectOne' | cxTranslate }}\"\n        appendTo=\"cx-org-list\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'orgUnitAddress.firstName' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"text\"\n        placeholder=\"{{ 'orgUnitAddress.firstName' | cxTranslate }}\"\n        formControlName=\"firstName\"\n        [attr.aria-invalid]=\"\n          form.get('firstName')?.touched && form.get('firstName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'firstNameError'\"\n      />\n\n      <cx-form-errors\n        id=\"firstNameError\"\n        [translationParams]=\"{\n          label: 'orgUnitAddress.firstName' | cxTranslate,\n        }\"\n        [control]=\"form.get('firstName')\"\n      ></cx-form-errors>\n    </label>\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'orgUnitAddress.lastName' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{ 'orgUnitAddress.lastName' | cxTranslate }}\"\n        formControlName=\"lastName\"\n        [attr.aria-invalid]=\"\n          form.get('lastName')?.touched && form.get('lastName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'lastNameError'\"\n      />\n\n      <cx-form-errors\n        id=\"lastNameError\"\n        [translationParams]=\"{ label: 'orgUnitAddress.lastName' | cxTranslate }\"\n        [control]=\"form.get('lastName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label class=\"full-width\">\n      <span class=\"label-content required\"\n        >{{ 'orgUnitAddress.address1' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{ 'orgUnitAddress.streetAddress' | cxTranslate }}\"\n        formControlName=\"line1\"\n        [attr.aria-invalid]=\"\n          form.get('line1')?.touched && form.get('line1')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'line1Error'\"\n      />\n\n      <cx-form-errors\n        id=\"line1Error\"\n        [translationParams]=\"{ label: 'orgUnitAddress.address1' | cxTranslate }\"\n        [control]=\"form.get('line1')\"\n      ></cx-form-errors>\n    </label>\n\n    <label class=\"full-width\">\n      <span class=\"label-content\">{{\n        'orgUnitAddress.address2' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{ 'orgUnitAddress.aptSuite' | cxTranslate }}\"\n        formControlName=\"line2\"\n      />\n    </label>\n\n    <label class=\"full-width\">\n      <span class=\"label-content\">{{\n        'orgUnitAddress.phoneNumber' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{ 'orgUnitAddress.phoneNumber' | cxTranslate }}\"\n        formControlName=\"phone\"\n      />\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'orgUnitAddress.city' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{ 'orgUnitAddress.city' | cxTranslate }}\"\n        formControlName=\"town\"\n        [attr.aria-invalid]=\"\n          form.get('town')?.touched && form.get('town')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'townError'\"\n      />\n\n      <cx-form-errors\n        id=\"townError\"\n        [translationParams]=\"{ label: 'orgUnitAddress.city' | cxTranslate }\"\n        [control]=\"form.get('town')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'orgUnitAddress.zipCode' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{ 'orgUnitAddress.zipCode' | cxTranslate }}\"\n        formControlName=\"postalCode\"\n        [attr.aria-invalid]=\"\n          form.get('postalCode')?.touched && form.get('postalCode')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'postalCodeError'\"\n      />\n\n      <cx-form-errors\n        id=\"postalCodeError\"\n        [translationParams]=\"{ label: 'orgUnitAddress.zipCode' | cxTranslate }\"\n        [control]=\"form.get('postalCode')\"\n      ></cx-form-errors>\n    </label>\n\n    <label></label>\n\n    <ng-container *ngIf=\"regions$ | async as regions\">\n      <label\n        class=\"full-width\"\n        formGroupName=\"region\"\n        *ngIf=\"regions.length > 0\"\n      >\n        <span class=\"label-content required\"\n          >{{ 'orgUnitAddress.state' | cxTranslate }}\n          <cx-form-required-asterisks />\n        </span>\n        <ng-select\n          [inputAttrs]=\"{ required: 'true' }\"\n          class=\"region-select\"\n          formControlName=\"isocode\"\n          [searchable]=\"true\"\n          [clearable]=\"false\"\n          [items]=\"regions\"\n          bindLabel=\"name\"\n          bindValue=\"isocode\"\n          placeholder=\"{{ 'orgUnitAddress.selectOne' | cxTranslate }}\"\n          appendTo=\"cx-org-list\"\n          ariaLabelDropdown=\"{{\n            'common.ngSelectDropdownOptionsList' | cxTranslate\n          }}\"\n        >\n        </ng-select>\n\n        <cx-form-errors\n          [translationParams]=\"{ label: 'orgUnitAddress.state' | cxTranslate }\"\n          [control]=\"form.get('region.isocode')\"\n        ></cx-form-errors>\n      </label>\n    </ng-container>\n  </ng-container>\n</cx-org-form>\n", dependencies: [{ kind: "component", type: FormComponent, selector: "cx-org-form", inputs: ["i18nRoot", "animateBack", "subtitle"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i4.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i4.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i4.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: i4.FormGroupName, selector: "[formGroupName]", inputs: ["formGroupName"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-unit-address-form', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ItemService,
                            useExisting: UnitAddressItemService,
                        },
                    ], imports: [
                        FormComponent,
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredLegendComponent,
                        FormRequiredAsterisksComponent,
                        NgSelectComponent,
                        FormErrorsComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<cx-org-form\n  i18nRoot=\"orgUnitAddress\"\n  [animateBack]=\"!(key$ | async)\"\n  [subtitle]=\"\n    'orgUnitAddress.details.subtitle' | cxTranslate: { item: (unit$ | async) }\n  \"\n>\n  <ng-container *ngIf=\"form\" [formGroup]=\"form\" main>\n    <cx-form-required-legend />\n    <label formGroupName=\"country\">\n      <span class=\"label-content required\"\n        >{{ 'orgUnitAddress.country' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        class=\"country-select\"\n        formControlName=\"isocode\"\n        [searchable]=\"true\"\n        [clearable]=\"false\"\n        [items]=\"(countries$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"isocode\"\n        placeholder=\"{{ 'orgUnitAddress.selectOne' | cxTranslate }}\"\n        appendTo=\"cx-org-list\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{ label: 'orgUnitAddress.country' | cxTranslate }\"\n        [control]=\"form.get('country.isocode')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\">{{\n        'orgUnitAddress.titles' | cxTranslate\n      }}</span>\n      <ng-select\n        formControlName=\"titleCode\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"(titles$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"code\"\n        placeholder=\"{{ 'orgUnitAddress.selectOne' | cxTranslate }}\"\n        appendTo=\"cx-org-list\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'orgUnitAddress.firstName' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        class=\"form-control\"\n        type=\"text\"\n        placeholder=\"{{ 'orgUnitAddress.firstName' | cxTranslate }}\"\n        formControlName=\"firstName\"\n        [attr.aria-invalid]=\"\n          form.get('firstName')?.touched && form.get('firstName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'firstNameError'\"\n      />\n\n      <cx-form-errors\n        id=\"firstNameError\"\n        [translationParams]=\"{\n          label: 'orgUnitAddress.firstName' | cxTranslate,\n        }\"\n        [control]=\"form.get('firstName')\"\n      ></cx-form-errors>\n    </label>\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'orgUnitAddress.lastName' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{ 'orgUnitAddress.lastName' | cxTranslate }}\"\n        formControlName=\"lastName\"\n        [attr.aria-invalid]=\"\n          form.get('lastName')?.touched && form.get('lastName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'lastNameError'\"\n      />\n\n      <cx-form-errors\n        id=\"lastNameError\"\n        [translationParams]=\"{ label: 'orgUnitAddress.lastName' | cxTranslate }\"\n        [control]=\"form.get('lastName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label class=\"full-width\">\n      <span class=\"label-content required\"\n        >{{ 'orgUnitAddress.address1' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{ 'orgUnitAddress.streetAddress' | cxTranslate }}\"\n        formControlName=\"line1\"\n        [attr.aria-invalid]=\"\n          form.get('line1')?.touched && form.get('line1')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'line1Error'\"\n      />\n\n      <cx-form-errors\n        id=\"line1Error\"\n        [translationParams]=\"{ label: 'orgUnitAddress.address1' | cxTranslate }\"\n        [control]=\"form.get('line1')\"\n      ></cx-form-errors>\n    </label>\n\n    <label class=\"full-width\">\n      <span class=\"label-content\">{{\n        'orgUnitAddress.address2' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{ 'orgUnitAddress.aptSuite' | cxTranslate }}\"\n        formControlName=\"line2\"\n      />\n    </label>\n\n    <label class=\"full-width\">\n      <span class=\"label-content\">{{\n        'orgUnitAddress.phoneNumber' | cxTranslate\n      }}</span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{ 'orgUnitAddress.phoneNumber' | cxTranslate }}\"\n        formControlName=\"phone\"\n      />\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'orgUnitAddress.city' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{ 'orgUnitAddress.city' | cxTranslate }}\"\n        formControlName=\"town\"\n        [attr.aria-invalid]=\"\n          form.get('town')?.touched && form.get('town')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'townError'\"\n      />\n\n      <cx-form-errors\n        id=\"townError\"\n        [translationParams]=\"{ label: 'orgUnitAddress.city' | cxTranslate }\"\n        [control]=\"form.get('town')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'orgUnitAddress.zipCode' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        required=\"true\"\n        type=\"text\"\n        class=\"form-control\"\n        placeholder=\"{{ 'orgUnitAddress.zipCode' | cxTranslate }}\"\n        formControlName=\"postalCode\"\n        [attr.aria-invalid]=\"\n          form.get('postalCode')?.touched && form.get('postalCode')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'postalCodeError'\"\n      />\n\n      <cx-form-errors\n        id=\"postalCodeError\"\n        [translationParams]=\"{ label: 'orgUnitAddress.zipCode' | cxTranslate }\"\n        [control]=\"form.get('postalCode')\"\n      ></cx-form-errors>\n    </label>\n\n    <label></label>\n\n    <ng-container *ngIf=\"regions$ | async as regions\">\n      <label\n        class=\"full-width\"\n        formGroupName=\"region\"\n        *ngIf=\"regions.length > 0\"\n      >\n        <span class=\"label-content required\"\n          >{{ 'orgUnitAddress.state' | cxTranslate }}\n          <cx-form-required-asterisks />\n        </span>\n        <ng-select\n          [inputAttrs]=\"{ required: 'true' }\"\n          class=\"region-select\"\n          formControlName=\"isocode\"\n          [searchable]=\"true\"\n          [clearable]=\"false\"\n          [items]=\"regions\"\n          bindLabel=\"name\"\n          bindValue=\"isocode\"\n          placeholder=\"{{ 'orgUnitAddress.selectOne' | cxTranslate }}\"\n          appendTo=\"cx-org-list\"\n          ariaLabelDropdown=\"{{\n            'common.ngSelectDropdownOptionsList' | cxTranslate\n          }}\"\n        >\n        </ng-select>\n\n        <cx-form-errors\n          [translationParams]=\"{ label: 'orgUnitAddress.state' | cxTranslate }\"\n          [control]=\"form.get('region.isocode')\"\n        ></cx-form-errors>\n      </label>\n    </ng-container>\n  </ng-container>\n</cx-org-form>\n" }]
        }], ctorParameters: () => [{ type: ItemService }, { type: UnitAddressFormService }, { type: CurrentUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitAddressFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressFormModule, imports: [CommonModule,
            FormModule,
            NgSelectModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            FormErrorsModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            UnitAddressFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressFormModule, imports: [CommonModule,
            FormModule,
            NgSelectModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            FormErrorsModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            UnitAddressFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        FormModule,
                        NgSelectModule,
                        UrlModule,
                        I18nModule,
                        ReactiveFormsModule,
                        FormErrorsModule,
                        FeaturesConfigModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        UnitAddressFormComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitAddressModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressModule, imports: [UnitAddressListModule,
            UnitAddressDetailsModule,
            UnitAddressFormModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressModule, imports: [UnitAddressListModule,
            UnitAddressDetailsModule,
            UnitAddressFormModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        UnitAddressListModule,
                        UnitAddressDetailsModule,
                        UnitAddressFormModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitApproverListService extends SubListService {
    constructor(tableService, unitService, userService) {
        super(tableService);
        this.tableService = tableService;
        this.unitService = unitService;
        this.userService = userService;
        this.tableType = OrganizationTableType.UNIT_APPROVERS;
        this._domainType = OrganizationTableType.USER;
    }
    load(pagination, code) {
        return this.unitService.getUsers(code, B2BUserRole.APPROVER, pagination);
    }
    /**
     * @override
     * Assign budget to the cost center.
     */
    assign(unitId, customerId) {
        this.unitService.assignApprover(unitId, customerId, B2BUserRole.APPROVER);
        return this.userService.getLoadingStatus(customerId);
    }
    /**
     * @override
     * Unassign the budget from the cost center.
     */
    unassign(unitId, customerId) {
        this.unitService.unassignApprover(unitId, customerId, B2BUserRole.APPROVER);
        return this.userService.getLoadingStatus(customerId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitApproverListService, deps: [{ token: i1$1.TableService }, { token: i2.OrgUnitService }, { token: i2.B2BUserService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitApproverListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitApproverListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.OrgUnitService }, { type: i2.B2BUserService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitAssignedApproverListService extends UnitApproverListService {
    constructor() {
        super(...arguments);
        this.tableType = OrganizationTableType.UNIT_ASSIGNED_APPROVERS;
    }
    load(pagination, code) {
        this.unitService.clearAssignedUsersList(code, B2BUserRole.APPROVER, pagination);
        return super
            .load(pagination, code)
            .pipe(map((users) => this.filterSelected(users)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAssignedApproverListService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAssignedApproverListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAssignedApproverListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitAssignedApproverListComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAssignedApproverListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitAssignedApproverListComponent, isStandalone: true, selector: "cx-org-unit-assigned-approver-list", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: UnitAssignedApproverListService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list [showHint]=\"true\">\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"assign\">\n    {{ 'organization.assign' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAssignedApproverListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-unit-assigned-approver-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: UnitAssignedApproverListService,
                        },
                    ], imports: [SubListComponent, RouterLink, TranslatePipe], template: "<cx-org-sub-list [showHint]=\"true\">\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"assign\">\n    {{ 'organization.assign' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitApproverListComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitApproverListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitApproverListComponent, isStandalone: true, selector: "cx-org-unit-approver-list", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: UnitApproverListService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list [previous]=\"false\">\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"../\">\n    {{ 'organization.done' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitApproverListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-unit-approver-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: UnitApproverListService,
                        },
                    ], imports: [SubListComponent, RouterLink, TranslatePipe], template: "<cx-org-sub-list [previous]=\"false\">\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"../\">\n    {{ 'organization.done' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitApproverListModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitApproverListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitApproverListModule, imports: [I18nModule,
            RouterModule,
            SubListModule,
            UnitApproverListComponent,
            UnitAssignedApproverListComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitApproverListModule, imports: [I18nModule,
            RouterModule,
            SubListModule,
            UnitApproverListComponent,
            UnitAssignedApproverListComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitApproverListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        I18nModule,
                        RouterModule,
                        SubListModule,
                        UnitApproverListComponent,
                        UnitAssignedApproverListComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitChildrenService extends SubListService {
    constructor(tableService, orgUnitService) {
        super(tableService);
        this.tableService = tableService;
        this.orgUnitService = orgUnitService;
        this.tableType = OrganizationTableType.UNIT_CHILDREN;
        this._domainType = OrganizationTableType.UNIT;
    }
    // method to be adjusted for proper children list when ready
    load(_pagination, code) {
        return this.orgUnitService.getChildUnits(code);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitChildrenService, deps: [{ token: i1$1.TableService }, { token: i2.OrgUnitService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitChildrenService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitChildrenService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.OrgUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitChildrenComponent {
    constructor(currentUnitService) {
        this.currentUnitService = currentUnitService;
        this.unit$ = this.currentUnitService
            ? this.currentUnitService.item$
            : of({ active: true });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitChildrenComponent, deps: [{ token: CurrentUnitService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitChildrenComponent, isStandalone: true, selector: "cx-org-unit-children", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: UnitChildrenService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list [showHint]=\"true\">\n  <a\n    actions\n    class=\"link btn btn-link btn-sm\"\n    routerLink=\"create\"\n    [class.disabled]=\"!(unit$ | async)?.active\"\n  >\n    {{ 'organization.create' | cxTranslate }}\n  </a>\n  <cx-org-disable-info\n    info\n    i18nRoot=\"orgUnitChildren\"\n    [displayInfoConfig]=\"{\n      disabledCreate: true,\n      disabledEnable: false,\n      disabledEdit: false,\n    }\"\n  >\n  </cx-org-disable-info>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: DisableInfoComponent, selector: "cx-org-disable-info", inputs: ["i18nRoot", "displayInfoConfig", "displayCustomInfo"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitChildrenComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-unit-children', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: UnitChildrenService,
                        },
                    ], imports: [
                        SubListComponent,
                        RouterLink,
                        DisableInfoComponent,
                        TranslatePipe,
                        AsyncPipe,
                    ], template: "<cx-org-sub-list [showHint]=\"true\">\n  <a\n    actions\n    class=\"link btn btn-link btn-sm\"\n    routerLink=\"create\"\n    [class.disabled]=\"!(unit$ | async)?.active\"\n  >\n    {{ 'organization.create' | cxTranslate }}\n  </a>\n  <cx-org-disable-info\n    info\n    i18nRoot=\"orgUnitChildren\"\n    [displayInfoConfig]=\"{\n      disabledCreate: true,\n      disabledEnable: false,\n      disabledEdit: false,\n    }\"\n  >\n  </cx-org-disable-info>\n</cx-org-sub-list>\n" }]
        }], ctorParameters: () => [{ type: CurrentUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitChildrenModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitChildrenModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitChildrenModule, imports: [ListModule,
            I18nModule,
            RouterModule,
            SubListModule,
            CommonModule,
            DisableInfoModule,
            UnitChildrenComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitChildrenModule, imports: [ListModule,
            I18nModule,
            RouterModule,
            SubListModule,
            CommonModule,
            DisableInfoModule,
            UnitChildrenComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitChildrenModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        ListModule,
                        I18nModule,
                        RouterModule,
                        SubListModule,
                        CommonModule,
                        DisableInfoModule,
                        UnitChildrenComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitCostCenterListService extends SubListService {
    constructor(tableService, unitService) {
        super(tableService);
        this.tableService = tableService;
        this.unitService = unitService;
        this.tableType = OrganizationTableType.UNIT_COST_CENTERS;
        this._domainType = OrganizationTableType.COST_CENTER;
    }
    load(_pagination, code) {
        return this.unitService.getCostCenters(code);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterListService, deps: [{ token: i1$1.TableService }, { token: i2.OrgUnitService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.OrgUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitCostCenterListComponent {
    constructor(currentUnitService) {
        this.currentUnitService = currentUnitService;
        this.unit$ = this.currentUnitService
            ? this.currentUnitService.item$
            : of({ active: true });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterListComponent, deps: [{ token: CurrentUnitService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitCostCenterListComponent, isStandalone: true, selector: "cx-org-unit-cost-centers", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: UnitCostCenterListService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list [showHint]=\"true\">\n  <a\n    actions\n    class=\"link btn btn-link btn-sm\"\n    routerLink=\"create\"\n    [class.disabled]=\"!(unit$ | async)?.active\"\n  >\n    {{ 'organization.create' | cxTranslate }}\n  </a>\n  <cx-org-disable-info\n    info\n    i18nRoot=\"orgUnitCostCenters\"\n    [displayInfoConfig]=\"{\n      disabledCreate: true,\n      disabledEnable: false,\n      disabledEdit: false,\n    }\"\n  >\n  </cx-org-disable-info>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: DisableInfoComponent, selector: "cx-org-disable-info", inputs: ["i18nRoot", "displayInfoConfig", "displayCustomInfo"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-unit-cost-centers', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: UnitCostCenterListService,
                        },
                    ], imports: [
                        SubListComponent,
                        RouterLink,
                        DisableInfoComponent,
                        TranslatePipe,
                        AsyncPipe,
                    ], template: "<cx-org-sub-list [showHint]=\"true\">\n  <a\n    actions\n    class=\"link btn btn-link btn-sm\"\n    routerLink=\"create\"\n    [class.disabled]=\"!(unit$ | async)?.active\"\n  >\n    {{ 'organization.create' | cxTranslate }}\n  </a>\n  <cx-org-disable-info\n    info\n    i18nRoot=\"orgUnitCostCenters\"\n    [displayInfoConfig]=\"{\n      disabledCreate: true,\n      disabledEnable: false,\n      disabledEdit: false,\n    }\"\n  >\n  </cx-org-disable-info>\n</cx-org-sub-list>\n" }]
        }], ctorParameters: () => [{ type: CurrentUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitCostCenterListModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterListModule, imports: [I18nModule,
            RouterModule,
            SubListModule,
            CommonModule,
            DisableInfoModule,
            UnitCostCenterListComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterListModule, imports: [I18nModule,
            RouterModule,
            SubListModule,
            CommonModule,
            DisableInfoModule,
            UnitCostCenterListComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        I18nModule,
                        RouterModule,
                        SubListModule,
                        CommonModule,
                        DisableInfoModule,
                        UnitCostCenterListComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitUserRolesCellComponent extends CellComponent {
    constructor(outlet, itemService, b2bUserService) {
        super(outlet);
        this.outlet = outlet;
        this.itemService = itemService;
        this.b2bUserService = b2bUserService;
        this.unitKey$ = this.itemService.key$;
        this.isUpdatingUserAllowed = this.b2bUserService.isUpdatingUserAllowed();
    }
    getRouterModel(uid) {
        return { ...this.outlet.context, uid };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserRolesCellComponent, deps: [{ token: i1$1.OutletContextData }, { token: ItemService }, { token: i2.B2BUserService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitUserRolesCellComponent, isStandalone: true, selector: "cx-org-unit-user-link-cell", usesInheritance: true, ngImport: i0, template: `
    <a
      class="button"
      *ngIf="isUpdatingUserAllowed && hasItem && (unitKey$ | async) as uid"
      [routerLink]="
        { cxRoute: 'orgUnitUserRoles', params: getRouterModel(uid) } | cxUrl
      "
    >
      {{ 'orgUser.links.rolesAndRights' | cxTranslate }}
    </a>
  `, isInline: true, dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserRolesCellComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'cx-org-unit-user-link-cell',
                    template: `
    <a
      class="button"
      *ngIf="isUpdatingUserAllowed && hasItem && (unitKey$ | async) as uid"
      [routerLink]="
        { cxRoute: 'orgUnitUserRoles', params: getRouterModel(uid) } | cxUrl
      "
    >
      {{ 'orgUser.links.rolesAndRights' | cxTranslate }}
    </a>
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [NgIf, RouterLink, AsyncPipe, TranslatePipe, UrlPipe],
                }]
        }], ctorParameters: () => [{ type: i1$1.OutletContextData }, { type: ItemService }, { type: i2.B2BUserService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitUserListService extends SubListService {
    constructor(tableService, unitService) {
        super(tableService);
        this.tableService = tableService;
        this.unitService = unitService;
        this.tableType = OrganizationTableType.UNIT_USERS;
        this._domainType = OrganizationTableType.USER;
    }
    load(pagination, code) {
        return this.unitService.getUsers(code, B2BUserRole.CUSTOMER, pagination);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserListService, deps: [{ token: i1$1.TableService }, { token: i2.OrgUnitService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.OrgUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitUserListComponent {
    constructor(currentUnitService, b2bUserService) {
        this.currentUnitService = currentUnitService;
        this.b2bUserService = b2bUserService;
        this.routerKey = ROUTE_PARAMS.userCode;
        this.unit$ = this.currentUnitService
            ? this.currentUnitService.item$
            : of({ active: true });
        this.isUpdatingUserAllowed = this.b2bUserService.isUpdatingUserAllowed();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserListComponent, deps: [{ token: CurrentUnitService }, { token: i2.B2BUserService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitUserListComponent, isStandalone: true, selector: "cx-org-unit-user-list", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: UnitUserListService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list key=\"customerId\" [routerKey]=\"routerKey\" [showHint]=\"true\">\n  <a\n    *ngIf=\"isUpdatingUserAllowed\"\n    actions\n    class=\"link btn btn-link btn-sm\"\n    routerLink=\"create\"\n    [class.disabled]=\"!(unit$ | async)?.active\"\n  >\n    {{ 'organization.create' | cxTranslate }}\n  </a>\n  <cx-org-disable-info\n    info\n    i18nRoot=\"orgUnitUsers\"\n    [displayInfoConfig]=\"{\n      disabledCreate: true,\n      disabledEnable: false,\n      disabledEdit: false,\n    }\"\n  >\n  </cx-org-disable-info>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: DisableInfoComponent, selector: "cx-org-disable-info", inputs: ["i18nRoot", "displayInfoConfig", "displayCustomInfo"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-unit-user-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: UnitUserListService,
                        },
                    ], imports: [
                        SubListComponent,
                        NgIf,
                        RouterLink,
                        DisableInfoComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<cx-org-sub-list key=\"customerId\" [routerKey]=\"routerKey\" [showHint]=\"true\">\n  <a\n    *ngIf=\"isUpdatingUserAllowed\"\n    actions\n    class=\"link btn btn-link btn-sm\"\n    routerLink=\"create\"\n    [class.disabled]=\"!(unit$ | async)?.active\"\n  >\n    {{ 'organization.create' | cxTranslate }}\n  </a>\n  <cx-org-disable-info\n    info\n    i18nRoot=\"orgUnitUsers\"\n    [displayInfoConfig]=\"{\n      disabledCreate: true,\n      disabledEnable: false,\n      disabledEdit: false,\n    }\"\n  >\n  </cx-org-disable-info>\n</cx-org-sub-list>\n" }]
        }], ctorParameters: () => [{ type: CurrentUnitService }, { type: i2.B2BUserService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitUserListModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitUserListModule, imports: [CommonModule,
            I18nModule,
            RouterModule,
            UrlModule,
            SubListModule,
            DisableInfoModule,
            UnitUserListComponent,
            UnitUserRolesCellComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserListModule, imports: [CommonModule,
            I18nModule,
            RouterModule,
            UrlModule,
            SubListModule,
            DisableInfoModule,
            UnitUserListComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        RouterModule,
                        UrlModule,
                        SubListModule,
                        DisableInfoModule,
                        UnitUserListComponent,
                        UnitUserRolesCellComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CurrentUnitUserService extends CurrentItemService {
    constructor(routingService, b2bUserService) {
        super(routingService);
        this.routingService = routingService;
        this.b2bUserService = b2bUserService;
    }
    getDetailsRoute() {
        return 'orgUnitUserList';
    }
    getParamKey() {
        return ROUTE_PARAMS.userCode;
    }
    getItem(customerId) {
        return this.b2bUserService.get(customerId);
    }
    getError(code) {
        return this.b2bUserService.getErrorState(code);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUnitUserService, deps: [{ token: i1.RoutingService }, { token: i2.B2BUserService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUnitUserService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUnitUserService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.RoutingService }, { type: i2.B2BUserService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitUserRolesFormService extends FormService {
    constructor(userService) {
        super();
        this.userService = userService;
        this.availableRoles = this.userService.getAllRoles();
        this.availableRights = this.userService.getAllRights();
    }
    getForm(item) {
        // if form already exist, while switching between users
        // it didn't patchData again, so used force rebuild
        this.form = null;
        return super.getForm(item);
    }
    build() {
        const form = new UntypedFormGroup({});
        this.availableRoles.forEach((role) => form.addControl(role, new UntypedFormControl()));
        this.availableRights.forEach((right) => form.addControl(right, new UntypedFormControl()));
        this.form = form;
    }
    patchData(item) {
        super.patchData(item);
        if (item) {
            item.roles?.forEach((role) => {
                this.form?.get(role)?.setValue(true);
            });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserRolesFormService, deps: [{ token: i2.B2BUserService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserRolesFormService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserRolesFormService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i2.B2BUserService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitUserRolesItemService extends ItemService {
    constructor(currentItemService, routingService, formService, unitService, b2bUserService) {
        super(currentItemService, routingService, formService);
        this.currentItemService = currentItemService;
        this.routingService = routingService;
        this.formService = formService;
        this.unitService = unitService;
        this.b2bUserService = b2bUserService;
    }
    save(form, key) {
        // we enable the unit so that the underlying
        // save method can read the complete form.value.
        form.get('orgUnit')?.enable();
        return super.save(form, key);
    }
    load(unitUid) {
        return this.b2bUserService.get(unitUid);
    }
    update(customerId, _user) {
        return this.b2bUserService.getLoadingStatus(customerId);
    }
    create(_customer) {
        return this.b2bUserService.getLoadingStatus('');
    }
    getDetailsRoute() {
        return this.currentItemService.getDetailsRoute();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserRolesItemService, deps: [{ token: CurrentUnitUserService }, { token: i1.RoutingService }, { token: UnitUserRolesFormService }, { token: i2.OrgUnitService }, { token: i2.B2BUserService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserRolesItemService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserRolesItemService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: CurrentUnitUserService }, { type: i1.RoutingService }, { type: UnitUserRolesFormService }, { type: i2.OrgUnitService }, { type: i2.B2BUserService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CurrentUserService extends CurrentItemService {
    constructor(routingService, b2bUserService) {
        super(routingService);
        this.routingService = routingService;
        this.b2bUserService = b2bUserService;
        this.name$ = this.item$.pipe(map((user) => user?.name));
    }
    getParamKey() {
        return ROUTE_PARAMS.userCode;
    }
    getItem(code) {
        return this.b2bUserService.get(code);
    }
    getError(code) {
        return this.b2bUserService.getErrorState(code);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUserService, deps: [{ token: i1.RoutingService }, { token: i2.B2BUserService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUserService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUserService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.RoutingService }, { type: i2.B2BUserService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserFormService extends FormService {
    build() {
        const form = new UntypedFormGroup({});
        form.setControl('customerId', new UntypedFormControl(''));
        form.setControl('titleCode', new UntypedFormControl(''));
        form.setControl('firstName', new UntypedFormControl('', Validators.required));
        form.setControl('lastName', new UntypedFormControl('', Validators.required));
        form.setControl('email', new UntypedFormControl('', [
            Validators.required,
            CustomFormValidators.emailValidator,
        ]));
        form.setControl('orgUnit', new UntypedFormGroup({
            uid: new UntypedFormControl(undefined, Validators.required),
        }));
        form.setControl('roles', new UntypedFormArray([]));
        form.setControl('isAssignedToApprovers', new UntypedFormControl(false));
        form.get('roles')?.valueChanges.subscribe((roles) => {
            if (roles.includes(B2BUserRole.APPROVER)) {
                form.get('isAssignedToApprovers')?.enable();
            }
            else {
                form.get('isAssignedToApprovers')?.disable();
                form.get('isAssignedToApprovers')?.reset();
            }
        });
        this.form = form;
    }
    patchData(item) {
        super.patchData(item);
        if (item) {
            const roles = this.form?.get('roles');
            const emailFormControl = this.form?.get('email');
            item.roles?.forEach((role) => {
                if (!roles.value.includes(role)) {
                    roles.push(new UntypedFormControl(role));
                }
            });
            if (item.displayUid && emailFormControl) {
                emailFormControl.setValue(item.displayUid);
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserFormService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserFormService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserFormService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserItemService extends ItemService {
    constructor(currentItemService, routingService, formService, userService) {
        super(currentItemService, routingService, formService);
        this.currentItemService = currentItemService;
        this.routingService = routingService;
        this.formService = formService;
        this.userService = userService;
    }
    load(code) {
        this.userService.load(code);
        return this.userService.get(code);
    }
    update(code, value) {
        delete value.approvers;
        this.userService.update(code, value);
        return this.userService.getLoadingStatus(code);
    }
    create(value) {
        this.userService.create(value);
        return this.userService.getLoadingStatus(value.uid ?? '');
    }
    getDetailsRoute() {
        return 'orgUserDetails';
    }
    // @override to avoid errors while creation
    launchDetails(item) {
        if (item.customerId !== null) {
            super.launchDetails(item);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserItemService, deps: [{ token: CurrentUserService }, { token: i1.RoutingService }, { token: UserFormService }, { token: i2.B2BUserService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserItemService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserItemService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: CurrentUserService }, { type: i1.RoutingService }, { type: UserFormService }, { type: i2.B2BUserService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitUserRolesFormComponent {
    constructor(itemService, formService, userService, userItemService) {
        this.itemService = itemService;
        this.formService = formService;
        this.userService = userService;
        this.userItemService = userItemService;
        this.form$ = this.itemService.current$.pipe(tap((item) => {
            if (!this.item) {
                this.item = item;
            }
            if (this.item?.roles?.join() !== item?.roles?.join()) {
                this.item = { ...this.item, ...item };
            }
        }), map((item) => this.formService.getForm(item)));
        this.availableRoles = this.userService.getAllRoles();
        this.availableRights = this.userService.getAllRights();
    }
    save(form) {
        form.disable();
        const rolesAndRights = [
            ...this.availableRoles,
            ...this.availableRights,
        ].filter((role) => !!form.get(role)?.value);
        this.userItemService
            .update(this.item?.customerId ?? '', { roles: rolesAndRights })
            .pipe(take(1), filter((data) => data.status === LoadStatus.SUCCESS))
            .subscribe((data) => {
            this.notify({ ...this.item, ...data.item });
            form.enable();
        });
    }
    notify(item) {
        this.messageService.add({
            message: {
                key: 'orgUnitUserRoles.messages.rolesUpdated',
                params: { item },
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserRolesFormComponent, deps: [{ token: ItemService }, { token: UnitUserRolesFormService }, { token: i2.B2BUserService }, { token: UserItemService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitUserRolesFormComponent, isStandalone: true, selector: "cx-org-unit-user-roles", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ItemService,
                useExisting: UnitUserRolesItemService,
            },
        ], viewQueries: [{ propertyName: "messageService", first: true, predicate: MessageService, descendants: true, read: MessageService }], ngImport: i0, template: "<form *ngIf=\"form$ | async as form\" (submit)=\"save(form)\">\n  <cx-org-card\n    #card\n    [previous]=\"false\"\n    i18nRoot=\"orgUnitUserRoles\"\n    [cxFocus]=\"{ autofocus: 'input', refreshFocus: form }\"\n  >\n    <a actions routerLink=\"../../\">\n      <span (click)=\"card.closeView($event)\">\n        {{ 'organization.done' | cxTranslate }}\n      </span>\n    </a>\n\n    <section main class=\"details\" [formGroup]=\"form\">\n      <fieldset class=\"full-width\">\n        <legend class=\"label-content required\">\n          {{ 'orgUser.roles' | cxTranslate }}\n        </legend>\n        <label class=\"form-check\" *ngFor=\"let role of availableRoles\">\n          <input\n            type=\"checkbox\"\n            [formControlName]=\"role\"\n            (change)=\"save(form)\"\n          />\n          <span class=\"form-check-label\">\n            {{ 'organization.userRoles.' + role | cxTranslate }}\n          </span>\n        </label>\n      </fieldset>\n      <fieldset class=\"full-width\">\n        <legend class=\"label-content required\">\n          {{ 'orgUser.rights' | cxTranslate }}\n        </legend>\n        <label class=\"form-check\" *ngFor=\"let right of availableRights\">\n          <input\n            type=\"checkbox\"\n            [formControlName]=\"right\"\n            (change)=\"save(form)\"\n          />\n          <span class=\"form-check-label\">\n            {{ 'organization.userRights.' + right | cxTranslate }}\n          </span>\n        </label>\n      </fieldset>\n    </section>\n  </cx-org-card>\n</form>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i4.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i4.NgForm, selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: CardComponent, selector: "cx-org-card", inputs: ["i18nRoot", "previous", "subtitle", "showHint"] }, { kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i4.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i4.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserRolesFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-unit-user-roles', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ItemService,
                            useExisting: UnitUserRolesItemService,
                        },
                    ], imports: [
                        NgIf,
                        FormsModule,
                        CardComponent,
                        FocusDirective,
                        RouterLink,
                        ReactiveFormsModule,
                        NgFor,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<form *ngIf=\"form$ | async as form\" (submit)=\"save(form)\">\n  <cx-org-card\n    #card\n    [previous]=\"false\"\n    i18nRoot=\"orgUnitUserRoles\"\n    [cxFocus]=\"{ autofocus: 'input', refreshFocus: form }\"\n  >\n    <a actions routerLink=\"../../\">\n      <span (click)=\"card.closeView($event)\">\n        {{ 'organization.done' | cxTranslate }}\n      </span>\n    </a>\n\n    <section main class=\"details\" [formGroup]=\"form\">\n      <fieldset class=\"full-width\">\n        <legend class=\"label-content required\">\n          {{ 'orgUser.roles' | cxTranslate }}\n        </legend>\n        <label class=\"form-check\" *ngFor=\"let role of availableRoles\">\n          <input\n            type=\"checkbox\"\n            [formControlName]=\"role\"\n            (change)=\"save(form)\"\n          />\n          <span class=\"form-check-label\">\n            {{ 'organization.userRoles.' + role | cxTranslate }}\n          </span>\n        </label>\n      </fieldset>\n      <fieldset class=\"full-width\">\n        <legend class=\"label-content required\">\n          {{ 'orgUser.rights' | cxTranslate }}\n        </legend>\n        <label class=\"form-check\" *ngFor=\"let right of availableRights\">\n          <input\n            type=\"checkbox\"\n            [formControlName]=\"right\"\n            (change)=\"save(form)\"\n          />\n          <span class=\"form-check-label\">\n            {{ 'organization.userRights.' + right | cxTranslate }}\n          </span>\n        </label>\n      </fieldset>\n    </section>\n  </cx-org-card>\n</form>\n" }]
        }], ctorParameters: () => [{ type: ItemService }, { type: UnitUserRolesFormService }, { type: i2.B2BUserService }, { type: UserItemService }], propDecorators: { messageService: [{
                type: ViewChild,
                args: [MessageService, { read: MessageService }]
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitUserRolesModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserRolesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitUserRolesModule, imports: [CommonModule,
            CardModule,
            FormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            KeyboardFocusModule,
            UnitUserRolesFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserRolesModule, imports: [CommonModule,
            CardModule,
            FormsModule,
            RouterModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            KeyboardFocusModule,
            UnitUserRolesFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserRolesModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        CardModule,
                        FormsModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        ReactiveFormsModule,
                        KeyboardFocusModule,
                        UnitUserRolesFormComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitUsersModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUsersModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitUsersModule, imports: [UnitUserListModule, UnitUserRolesModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUsersModule, imports: [UnitUserListModule, UnitUserRolesModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUsersModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [UnitUserListModule, UnitUserRolesModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var TREE_TOGGLE;
(function (TREE_TOGGLE) {
    TREE_TOGGLE[TREE_TOGGLE["EXPANDED"] = 0] = "EXPANDED";
    TREE_TOGGLE[TREE_TOGGLE["COLLAPSED"] = 1] = "COLLAPSED";
})(TREE_TOGGLE || (TREE_TOGGLE = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Service to populate Unit data to `Table` data. Unit
 * data is driven by the table configuration, using the `OrganizationTables.UNIT`.
 */
class UnitTreeService {
    constructor() {
        /**
         * Indicates the minimum number of (initial) expanded units.
         */
        this.minimalExpanded = 1;
        this.globalToggle$ = new BehaviorSubject(undefined);
        this.treeToggle$ = new BehaviorSubject(new Map());
    }
    /**
     * Initializes the unit tree with an active unit.
     *
     * The active unit will be collapsed.
     */
    initialize(root, activeUnitId) {
        if (activeUnitId) {
            this.expandUntilActiveNode(root, activeUnitId);
        }
    }
    /**
     * Sets the global toggle state to _collapsed_ and clears the toggle state
     * for individual units.
     */
    collapseAll() {
        this.globalToggle$.next(TREE_TOGGLE.COLLAPSED);
        this.treeToggle$.next(new Map());
    }
    /**
     * Sets the global toggle state to _expanded_ and clears the toggle state
     * for individual units.
     */
    expandAll() {
        this.globalToggle$.next(TREE_TOGGLE.EXPANDED);
        this.treeToggle$.next(new Map());
    }
    /**
     * Indicates whether the give unit is expanded.
     *
     * The returned (boolean) expand state is driven by the global toggle
     * state (expand / collapse all) and the toggle state for individual units.
     * There's also the `minimalExpanded` taken into consideration.
     */
    isExpanded(unitId, level) {
        const toggleState = this.treeToggle$.value?.get(unitId);
        if (this.globalToggle$.value === TREE_TOGGLE.COLLAPSED &&
            toggleState !== TREE_TOGGLE.EXPANDED) {
            return false;
        }
        return (
        // the current node is expanded
        toggleState === TREE_TOGGLE.EXPANDED ||
            // the node is not collapsed, but globally expanded ("expand all") or above
            // the minimum visible nodes
            ((this.globalToggle$.value === TREE_TOGGLE.EXPANDED ||
                level < this.minimalExpanded) &&
                toggleState !== TREE_TOGGLE.COLLAPSED));
    }
    toggle(unit) {
        const currentState = this.treeToggle$.value;
        currentState.set(unit.id ?? '', this.isExpanded(unit.id ?? '', unit.depthLevel)
            ? TREE_TOGGLE.COLLAPSED
            : TREE_TOGGLE.EXPANDED);
        this.treeToggle$.next(currentState);
    }
    /**
     * Expands all tree nodes till the active unit, to ensure that the
     * full tree is collapsed till the active item.
     *
     * This is useful while navigating the tree by the router.
     */
    expandUntilActiveNode(node, activeUnitId) {
        const hasActiveChild = (n, id) => !!n.children?.find((child) => child.id === id || hasActiveChild(child, id));
        const findInvolvedTreeNodes = (n, activeItems = []) => {
            if (hasActiveChild(n, activeUnitId)) {
                activeItems.push(n.id ?? '');
            }
            n.children?.forEach((child) => {
                findInvolvedTreeNodes(child, activeItems);
            });
            return activeItems;
        };
        const m = this.treeToggle$.value;
        findInvolvedTreeNodes(node).forEach((activeId) => {
            if (m.get(activeId) !== TREE_TOGGLE.EXPANDED) {
                m.set(activeId, TREE_TOGGLE.EXPANDED);
            }
        });
        if (m !== this.treeToggle$.value) {
            this.treeToggle$.next(m);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitTreeService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitTreeService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitTreeService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ToggleLinkCellComponent extends CellComponent {
    get depthLevel() {
        return this.model.depthLevel;
    }
    constructor(outlet, unitTreeService) {
        super(outlet);
        this.outlet = outlet;
        this.unitTreeService = unitTreeService;
        this.elementRef = inject(ElementRef);
        this.routingService = inject(RoutingService);
        this.featureService = inject(FeatureConfigService);
        this.isLargeScreen$ = inject(BreakpointService).isUp(BREAKPOINT.lg);
    }
    get combinedName() {
        return this.property ? `${this.property} (${this.count})` : '';
    }
    get expanded() {
        return this.model.expanded;
    }
    /**
     * Counts the number of descendants
     */
    get count() {
        return this.model.count;
    }
    toggleItem(event) {
        event.preventDefault();
        event.stopPropagation();
        this.unitTreeService.toggle(this.model);
    }
    /**
     * Indicates whether the tree item should have a toggle navigation.
     *
     * The toggle navigation is used in case the tree item has descendants,
     * and if the tree item level is not configured to be shown anyway.
     */
    get isSwitchable() {
        return this.count > 0;
    }
    // TODO: leverage these methods when available from future PR.
    get hasItem() {
        return !!this.item && Object.keys(this.item).length > 0;
    }
    get item() {
        if (!this.outlet.context) {
            return null;
        }
        const { _field, _options, _type, _i18nRoot, ...all } = this.outlet.context;
        return all;
    }
    onKeydown(event) {
        const tableElement = this.elementRef?.nativeElement.closest('table');
        const siblingElements = tableElement.querySelectorAll(`cx-org-toggle-link-cell a`);
        const currentSelectedIndex = Array.from(siblingElements).findIndex((element) => {
            return element === event.target;
        });
        switch (event.key) {
            case 'ArrowDown':
                this.onArrowDown(event, currentSelectedIndex, siblingElements);
                break;
            case 'ArrowUp':
                this.onArrowUp(event, currentSelectedIndex, siblingElements);
                break;
            case 'ArrowRight':
                this.onArrowRight(event);
                break;
            case 'ArrowLeft':
                this.onArrowLeft(event);
                break;
            case ' ':
            case 'Enter':
                this.onSpace(event, siblingElements);
                break;
        }
    }
    onSpace(event, siblingElements) {
        event.preventDefault();
        siblingElements.forEach((element) => {
            element.tabIndex = -1;
        });
        event.target.tabIndex = 0;
        this.routingService
            ?.go({ cxRoute: this.route, params: this.routeModel })
            .then(() => {
            if (!this.featureService.isEnabled('isA11yCardNotificationMessageFeatureEnabled')) {
                this.restoreFocus();
            }
        });
    }
    onArrowDown(event, currentSelectedIndex, siblingElements) {
        event.preventDefault();
        siblingElements[currentSelectedIndex + 1]?.focus();
    }
    onArrowUp(event, currentSelectedIndex, siblingElements) {
        event.preventDefault();
        siblingElements[currentSelectedIndex + -1]?.focus();
    }
    onArrowRight(event) {
        if (!this.expanded && this.isSwitchable) {
            this.toggleItem(event);
            if (!this.featureService.isEnabled('isA11yCardNotificationMessageFeatureEnabled')) {
                this.restoreFocus();
            }
        }
    }
    onArrowLeft(event) {
        if (this.expanded && this.isSwitchable) {
            this.toggleItem(event);
            if (!this.featureService.isEnabled('isA11yCardNotificationMessageFeatureEnabled')) {
                this.restoreFocus();
            }
        }
    }
    /**
     * To be removed when isA11yCardNotificationMessageFeatureEnabled is enabled.
     * @deprecated
     */
    restoreFocus() {
        const focusedElementId = document.activeElement?.id || '';
        this.unitTreeService.treeToggle$.pipe(take$1(1)).subscribe(() => {
            setTimeout(() => {
                document.getElementById(focusedElementId)?.focus();
            }, 0);
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ToggleLinkCellComponent, deps: [{ token: i1$1.OutletContextData }, { token: UnitTreeService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: ToggleLinkCellComponent, isStandalone: true, selector: "cx-org-toggle-link-cell", host: { properties: { "style.--cx-depth-level": "this.depthLevel" } }, usesInheritance: true, ngImport: i0, template: "<a\n  *ngIf=\"hasItem\"\n  [id]=\"model.uid\"\n  class=\"hide-focus-border\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  (keydown)=\"onKeydown($event)\"\n  [attr.aria-haspopup]=\"isSwitchable\"\n  [attr.data-depth]=\"model.depthLevel\"\n  [attr.aria-label]=\"\n    (isLargeScreen$ | async)\n      ? combinedName +\n        ', ' +\n        ('orgUnit.uid' | cxTranslate) +\n        ': ' +\n        item?.uid +\n        ', ' +\n        ('orgUnit.active' | cxTranslate) +\n        ': ' +\n        ((item?.active ? 'organization.enabled' : 'organization.disabled')\n          | cxTranslate) +\n        ', ' +\n        ('orgUnit.tree.level' | cxTranslate: { level: model.depthLevel + 1 })\n      : combinedName +\n        ', ' +\n        ('orgUnit.tree.level' | cxTranslate: { level: model.depthLevel + 1 })\n  \"\n  role=\"treeitem\"\n>\n  <button\n    *ngIf=\"isSwitchable\"\n    class=\"button btn btn-sm tree-item-toggle\"\n    type=\"button\"\n    [attr.aria-expanded]=\"expanded\"\n    [attr.aria-label]=\"'orgUnit.tree.explore' | cxTranslate\"\n    [attr.title]=\"'orgUnit.tree.explore' | cxTranslate\"\n    (click)=\"toggleItem($event)\"\n    tabindex=\"-1\"\n  >\n    <cx-icon [type]=\"expanded ? 'CARET_DOWN' : 'CARET_RIGHT'\"></cx-icon>\n  </button>\n  <span class=\"text\" title=\"{{ combinedName }}\">{{ combinedName }}</span>\n</a>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: ToggleLinkCellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-toggle-link-cell', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, AsyncPipe, RouterLink, IconComponent, UrlPipe, TranslatePipe], template: "<a\n  *ngIf=\"hasItem\"\n  [id]=\"model.uid\"\n  class=\"hide-focus-border\"\n  [routerLink]=\"{ cxRoute: route, params: routeModel } | cxUrl\"\n  (keydown)=\"onKeydown($event)\"\n  [attr.aria-haspopup]=\"isSwitchable\"\n  [attr.data-depth]=\"model.depthLevel\"\n  [attr.aria-label]=\"\n    (isLargeScreen$ | async)\n      ? combinedName +\n        ', ' +\n        ('orgUnit.uid' | cxTranslate) +\n        ': ' +\n        item?.uid +\n        ', ' +\n        ('orgUnit.active' | cxTranslate) +\n        ': ' +\n        ((item?.active ? 'organization.enabled' : 'organization.disabled')\n          | cxTranslate) +\n        ', ' +\n        ('orgUnit.tree.level' | cxTranslate: { level: model.depthLevel + 1 })\n      : combinedName +\n        ', ' +\n        ('orgUnit.tree.level' | cxTranslate: { level: model.depthLevel + 1 })\n  \"\n  role=\"treeitem\"\n>\n  <button\n    *ngIf=\"isSwitchable\"\n    class=\"button btn btn-sm tree-item-toggle\"\n    type=\"button\"\n    [attr.aria-expanded]=\"expanded\"\n    [attr.aria-label]=\"'orgUnit.tree.explore' | cxTranslate\"\n    [attr.title]=\"'orgUnit.tree.explore' | cxTranslate\"\n    (click)=\"toggleItem($event)\"\n    tabindex=\"-1\"\n  >\n    <cx-icon [type]=\"expanded ? 'CARET_DOWN' : 'CARET_RIGHT'\"></cx-icon>\n  </button>\n  <span class=\"text\" title=\"{{ combinedName }}\">{{ combinedName }}</span>\n</a>\n" }]
        }], ctorParameters: () => [{ type: i1$1.OutletContextData }, { type: UnitTreeService }], propDecorators: { depthLevel: [{
                type: HostBinding,
                args: ['style.--cx-depth-level']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitListComponent {
    constructor(unitTreeService, orgUnitService) {
        this.unitTreeService = unitTreeService;
        this.orgUnitService = orgUnitService;
        this.isUpdatingUnitAllowed = this.orgUnitService
            ? this.orgUnitService.isUpdatingUnitAllowed()
            : true;
    }
    expandAll() {
        this.unitTreeService.expandAll();
    }
    collapseAll() {
        this.unitTreeService.collapseAll();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitListComponent, deps: [{ token: UnitTreeService }, { token: i2.OrgUnitService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitListComponent, isStandalone: true, selector: "cx-org-unit-list", ngImport: i0, template: "<cx-org-list [hideAddButton]=\"!isUpdatingUnitAllowed\">\n  <ng-container actions>\n    <button class=\"link btn btn-link btn-sm\" (click)=\"expandAll()\">\n      {{ 'orgUnit.tree.expandAll' | cxTranslate }}\n    </button>\n    <button class=\"link btn btn-link btn-sm\" (click)=\"collapseAll()\">\n      {{ 'orgUnit.tree.collapseAll' | cxTranslate }}\n    </button>\n  </ng-container>\n</cx-org-list>\n", dependencies: [{ kind: "component", type: ListComponent, selector: "cx-org-list", inputs: ["key", "hideAddButton"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-unit-list', changeDetection: ChangeDetectionStrategy.OnPush, imports: [ListComponent, TranslatePipe], template: "<cx-org-list [hideAddButton]=\"!isUpdatingUnitAllowed\">\n  <ng-container actions>\n    <button class=\"link btn btn-link btn-sm\" (click)=\"expandAll()\">\n      {{ 'orgUnit.tree.expandAll' | cxTranslate }}\n    </button>\n    <button class=\"link btn btn-link btn-sm\" (click)=\"collapseAll()\">\n      {{ 'orgUnit.tree.collapseAll' | cxTranslate }}\n    </button>\n  </ng-container>\n</cx-org-list>\n" }]
        }], ctorParameters: () => [{ type: UnitTreeService }, { type: i2.OrgUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitListModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitListModule, imports: [CommonModule,
            RouterModule,
            UrlModule,
            I18nModule,
            IconModule,
            ListModule,
            UnitListComponent,
            ToggleLinkCellComponent], exports: [ToggleLinkCellComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitListModule, imports: [CommonModule,
            RouterModule,
            UrlModule,
            I18nModule,
            IconModule,
            ListModule,
            UnitListComponent,
            ToggleLinkCellComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        IconModule,
                        ListModule,
                        UnitListComponent,
                        ToggleLinkCellComponent,
                    ],
                    exports: [ToggleLinkCellComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserDetailsCellComponent extends CellComponent {
    constructor(b2bUserService, outlet) {
        super(outlet);
        this.b2bUserService = b2bUserService;
        this.outlet = outlet;
        this.availableRoles = this.b2bUserService
            .getAllRoles()
            .map((role) => role.toString());
        this.availableRights = this.b2bUserService
            .getAllRights()
            .map((right) => right.toString());
        this.b2bUserModel = super.model;
    }
    hasRight(model) {
        return (model.roles ?? []).some((role) => this.availableRights.includes(role));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserDetailsCellComponent, deps: [{ token: i2.B2BUserService }, { token: i1$1.OutletContextData }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UserDetailsCellComponent, isStandalone: true, selector: "cx-org-user-details-cell", usesInheritance: true, ngImport: i0, template: "<ng-container *ngIf=\"b2bUserModel as model\">\n  <ng-template #details>\n    <div class=\"popover-details\">\n      <div class=\"property\">\n        <label>{{ 'orgUser.name' | cxTranslate }}</label>\n        <a\n          class=\"value\"\n          [routerLink]=\"\n            {\n              cxRoute: 'orgUserDetails',\n              params: model,\n            } | cxUrl\n          \"\n          >{{ model.name }}</a\n        >\n      </div>\n\n      <div class=\"property full-width\">\n        <label>{{ 'orgUser.uid' | cxTranslate }}</label>\n        <span class=\"value\">\n          {{ model.uid }}\n        </span>\n      </div>\n\n      <div class=\"property\">\n        <label>{{ 'orgUser.roles' | cxTranslate }}</label>\n        <ul class=\"value\">\n          <ng-container *ngFor=\"let role of model.roles\">\n            <li\n              *ngIf=\"availableRoles.includes(role)\"\n              [innerText]=\"'organization.userRoles.' + role | cxTranslate\"\n            ></li>\n          </ng-container>\n          <li *ngIf=\"model.roles?.length === 0\">-</li>\n        </ul>\n      </div>\n\n      <div class=\"property\" *ngIf=\"hasRight(model)\">\n        <label>{{ 'orgUser.rights' | cxTranslate }}</label>\n        <ul class=\"value\">\n          <ng-container *ngFor=\"let right of model.roles\">\n            <li\n              *ngIf=\"availableRights.includes(right)\"\n              [innerText]=\"'organization.userRights.' + right | cxTranslate\"\n            ></li>\n          </ng-container>\n          <li *ngIf=\"model.roles?.length === 0\">-</li>\n        </ul>\n      </div>\n\n      <div class=\"property\">\n        <label>{{ 'orgUser.orgUnit' | cxTranslate }}</label>\n        <a\n          class=\"value\"\n          [routerLink]=\"\n            {\n              cxRoute: 'orgUnitDetails',\n              params: model.orgUnit,\n            } | cxUrl\n          \"\n        >\n          {{ model.orgUnit?.name }}\n        </a>\n      </div>\n    </div>\n  </ng-template>\n\n  <button\n    class=\"button btn btn-sm text\"\n    ariaLabel=\"{model?.name ?? ('orgUser.name' | cxTranslate)}\"\n    [cxPopover]=\"details\"\n    [cxPopoverOptions]=\"{\n      placement: 'auto',\n      class: 'my-company-popover',\n      appendToBody: true,\n      displayCloseButton: true,\n    }\"\n  >\n    {{ model?.name }}\n  </button>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: PopoverDirective, selector: "[cxPopover]", inputs: ["cxPopover", "cxPopoverOptions"], outputs: ["openPopover", "closePopover"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserDetailsCellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-user-details-cell', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, RouterLink, NgFor, PopoverDirective, TranslatePipe, UrlPipe], template: "<ng-container *ngIf=\"b2bUserModel as model\">\n  <ng-template #details>\n    <div class=\"popover-details\">\n      <div class=\"property\">\n        <label>{{ 'orgUser.name' | cxTranslate }}</label>\n        <a\n          class=\"value\"\n          [routerLink]=\"\n            {\n              cxRoute: 'orgUserDetails',\n              params: model,\n            } | cxUrl\n          \"\n          >{{ model.name }}</a\n        >\n      </div>\n\n      <div class=\"property full-width\">\n        <label>{{ 'orgUser.uid' | cxTranslate }}</label>\n        <span class=\"value\">\n          {{ model.uid }}\n        </span>\n      </div>\n\n      <div class=\"property\">\n        <label>{{ 'orgUser.roles' | cxTranslate }}</label>\n        <ul class=\"value\">\n          <ng-container *ngFor=\"let role of model.roles\">\n            <li\n              *ngIf=\"availableRoles.includes(role)\"\n              [innerText]=\"'organization.userRoles.' + role | cxTranslate\"\n            ></li>\n          </ng-container>\n          <li *ngIf=\"model.roles?.length === 0\">-</li>\n        </ul>\n      </div>\n\n      <div class=\"property\" *ngIf=\"hasRight(model)\">\n        <label>{{ 'orgUser.rights' | cxTranslate }}</label>\n        <ul class=\"value\">\n          <ng-container *ngFor=\"let right of model.roles\">\n            <li\n              *ngIf=\"availableRights.includes(right)\"\n              [innerText]=\"'organization.userRights.' + right | cxTranslate\"\n            ></li>\n          </ng-container>\n          <li *ngIf=\"model.roles?.length === 0\">-</li>\n        </ul>\n      </div>\n\n      <div class=\"property\">\n        <label>{{ 'orgUser.orgUnit' | cxTranslate }}</label>\n        <a\n          class=\"value\"\n          [routerLink]=\"\n            {\n              cxRoute: 'orgUnitDetails',\n              params: model.orgUnit,\n            } | cxUrl\n          \"\n        >\n          {{ model.orgUnit?.name }}\n        </a>\n      </div>\n    </div>\n  </ng-template>\n\n  <button\n    class=\"button btn btn-sm text\"\n    ariaLabel=\"{model?.name ?? ('orgUser.name' | cxTranslate)}\"\n    [cxPopover]=\"details\"\n    [cxPopoverOptions]=\"{\n      placement: 'auto',\n      class: 'my-company-popover',\n      appendToBody: true,\n      displayCloseButton: true,\n    }\"\n  >\n    {{ model?.name }}\n  </button>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: i2.B2BUserService }, { type: i1$1.OutletContextData }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitDetailsCellComponent extends CellComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitDetailsCellComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitDetailsCellComponent, isStandalone: true, selector: "cx-org-unit-details-cell", usesInheritance: true, ngImport: i0, template: "<ng-template #details>\n  <div class=\"popover-details\">\n    <div class=\"property\">\n      <label>{{ 'orgUnit.name' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: { uid: model.id },\n          } | cxUrl\n        \"\n      >\n        {{ model.name }}\n      </a>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUnit.uid' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.id }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUnit.active' | cxTranslate }}</label>\n      <span class=\"value\" [class.is-active]=\"model.active\">\n        {{\n          (model.active ? 'organization.enabled' : 'organization.disabled')\n            | cxTranslate\n        }}\n      </span>\n    </div>\n\n    <div class=\"property\" *ngIf=\"model.approvalProcess?.name\">\n      <label>{{ 'orgUnit.approvalProcess' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.approvalProcess?.name }}\n      </span>\n    </div>\n  </div>\n</ng-template>\n\n<button\n  class=\"button btn btn-sm text\"\n  [cxPopover]=\"details\"\n  [cxPopoverOptions]=\"{\n    placement: 'auto',\n    class: 'my-company-popover',\n    appendToBody: true,\n    displayCloseButton: true,\n  }\"\n>\n  {{ model.name }}\n</button>\n", dependencies: [{ kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: PopoverDirective, selector: "[cxPopover]", inputs: ["cxPopover", "cxPopoverOptions"], outputs: ["openPopover", "closePopover"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitDetailsCellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-unit-details-cell', changeDetection: ChangeDetectionStrategy.OnPush, imports: [RouterLink, NgIf, PopoverDirective, TranslatePipe, UrlPipe], template: "<ng-template #details>\n  <div class=\"popover-details\">\n    <div class=\"property\">\n      <label>{{ 'orgUnit.name' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: { uid: model.id },\n          } | cxUrl\n        \"\n      >\n        {{ model.name }}\n      </a>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUnit.uid' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.id }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUnit.active' | cxTranslate }}</label>\n      <span class=\"value\" [class.is-active]=\"model.active\">\n        {{\n          (model.active ? 'organization.enabled' : 'organization.disabled')\n            | cxTranslate\n        }}\n      </span>\n    </div>\n\n    <div class=\"property\" *ngIf=\"model.approvalProcess?.name\">\n      <label>{{ 'orgUnit.approvalProcess' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.approvalProcess?.name }}\n      </span>\n    </div>\n  </div>\n</ng-template>\n\n<button\n  class=\"button btn btn-sm text\"\n  [cxPopover]=\"details\"\n  [cxPopoverOptions]=\"{\n    placement: 'auto',\n    class: 'my-company-popover',\n    appendToBody: true,\n    displayCloseButton: true,\n  }\"\n>\n  {{ model.name }}\n</button>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CurrentUnitChildService extends CurrentUnitService {
    getParamKey() {
        // We must come up with a fake param key, to avoid that the (parent) unit
        // code is loaded from the route parameter map.
        return 'childUnitCode';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUnitChildService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUnitChildService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUnitChildService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitChildItemService extends UnitItemService {
    constructor(currentItemService, routingService, formService, unitService) {
        super(currentItemService, routingService, formService, unitService);
        this.currentItemService = currentItemService;
        this.routingService = routingService;
        this.formService = formService;
        this.unitService = unitService;
    }
    save(form, key) {
        // we enable the parentOrgUnit temporarily so that the underlying
        // save method can read the complete form.value.
        form.get('parentOrgUnit')?.enable();
        return super.save(form, key);
    }
    /**
     * @override
     * Returns 'unitDetails'
     */
    getDetailsRoute() {
        return 'orgUnitChildren';
    }
    buildRouteParams(item) {
        return { uid: item.parentOrgUnit?.uid };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitChildItemService, deps: [{ token: CurrentUnitChildService }, { token: i1.RoutingService }, { token: UnitFormService }, { token: i2.OrgUnitService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitChildItemService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitChildItemService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: CurrentUnitChildService }, { type: i1.RoutingService }, { type: UnitFormService }, { type: i2.OrgUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitChildCreateComponent {
    constructor(unitService) {
        this.unitService = unitService;
        this.unitKey$ = this.unitService.key$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitChildCreateComponent, deps: [{ token: CurrentUnitService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitChildCreateComponent, isStandalone: true, selector: "cx-org-unit-child-create", host: { classAttribute: "content-wrapper" }, providers: [
            // we provide a specific version of the `UnitItemService` to
            // let the form component work with child units.
            {
                provide: UnitItemService,
                useExisting: UnitChildItemService,
            },
        ], ngImport: i0, template: "<cx-org-unit-form\n  [createChildUnit]=\"true\"\n  i18nRoot=\"orgUnit.children\"\n></cx-org-unit-form>\n", dependencies: [{ kind: "component", type: UnitFormComponent, selector: "cx-org-unit-form", inputs: ["i18nRoot", "createChildUnit"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitChildCreateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-unit-child-create', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        // we provide a specific version of the `UnitItemService` to
                        // let the form component work with child units.
                        {
                            provide: UnitItemService,
                            useExisting: UnitChildItemService,
                        },
                    ], imports: [UnitFormComponent], template: "<cx-org-unit-form\n  [createChildUnit]=\"true\"\n  i18nRoot=\"orgUnit.children\"\n></cx-org-unit-form>\n" }]
        }], ctorParameters: () => [{ type: CurrentUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitChildCreateModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitChildCreateModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitChildCreateModule, imports: [CommonModule, UnitFormModule, UnitChildCreateComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitChildCreateModule, imports: [CommonModule, UnitFormModule, UnitChildCreateComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitChildCreateModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, UnitFormModule, UnitChildCreateComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitCostCenterItemService extends CostCenterItemService {
    save(form, key) {
        // we enable the unit so that the underlying
        // save method can read the complete form.value.
        form.get('unit')?.enable();
        return super.save(form, key);
    }
    /**
     * @override
     * Returns 'orgUnitCostCenters'
     */
    getDetailsRoute() {
        return 'orgUnitCostCenters';
    }
    buildRouteParams(item) {
        return { uid: item.unit?.uid };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterItemService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterItemService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterItemService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitCostCenterCreateComponent {
    constructor(unitService) {
        this.unitService = unitService;
        this.unitKey$ = this.unitService.key$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterCreateComponent, deps: [{ token: CurrentUnitService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitCostCenterCreateComponent, isStandalone: true, selector: "cx-org-unit-cost-center-create", host: { classAttribute: "content-wrapper" }, providers: [
            // we provide a specific version of the `CostCenterItemService` to
            // let the form component work with unit cost centers.
            {
                provide: CostCenterItemService,
                useExisting: UnitCostCenterItemService,
            },
        ], ngImport: i0, template: "<cx-org-cost-center-form [unitKey]=\"unitKey$ | async\"></cx-org-cost-center-form>\n", dependencies: [{ kind: "component", type: CostCenterFormComponent, selector: "cx-org-cost-center-form", inputs: ["unitKey"] }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterCreateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-unit-cost-center-create', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        // we provide a specific version of the `CostCenterItemService` to
                        // let the form component work with unit cost centers.
                        {
                            provide: CostCenterItemService,
                            useExisting: UnitCostCenterItemService,
                        },
                    ], imports: [CostCenterFormComponent, AsyncPipe], template: "<cx-org-cost-center-form [unitKey]=\"unitKey$ | async\"></cx-org-cost-center-form>\n" }]
        }], ctorParameters: () => [{ type: CurrentUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitCostCenterCreateModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterCreateModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterCreateModule, imports: [CommonModule, CostCenterFormModule, UnitCostCenterCreateComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterCreateModule, imports: [CommonModule, CostCenterFormModule, UnitCostCenterCreateComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitCostCenterCreateModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, CostCenterFormModule, UnitCostCenterCreateComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserFormComponent {
    /**
     * Initialize the business unit for the user.
     *
     * If there's a unit provided, we disable the unit form control.
     */
    set unitKey(value) {
        if (value) {
            this.form?.get('orgUnit.uid')?.setValue(value);
            this.form?.get('orgUnit')?.disable();
        }
    }
    constructor(itemService, unitService, userProfileFacade, b2bUserService) {
        this.itemService = itemService;
        this.unitService = unitService;
        this.userProfileFacade = userProfileFacade;
        this.b2bUserService = b2bUserService;
        this.form = this.itemService.getForm();
        this.units$ = this.unitService
            .getActiveUnitList()
            .pipe(tap((units) => {
            if (units && units.length === 1) {
                this.form?.get('orgUnit.uid')?.setValue(units[0]?.id);
            }
        }));
        this.titles$ = this.userProfileFacade.getTitles();
        this.availableRoles = this.b2bUserService.getAllRoles();
        this.availableRights = this.b2bUserService.getAllRights();
    }
    ngOnInit() {
        this.unitService.loadList();
    }
    updateRoles(event) {
        const { checked, value } = event.target;
        if (checked) {
            this.roles.push(new UntypedFormControl(value));
        }
        else {
            this.roles.removeAt(this.roles.value.indexOf(value));
        }
    }
    get roles() {
        return this.form?.get('roles');
    }
    get isAssignedToApprovers() {
        return this.form?.get('isAssignedToApprovers');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserFormComponent, deps: [{ token: ItemService }, { token: i2.OrgUnitService }, { token: i2$1.UserProfileFacade }, { token: i2.B2BUserService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UserFormComponent, isStandalone: true, selector: "cx-org-user-form", inputs: { unitKey: "unitKey" }, host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ItemService,
                useExisting: UserItemService,
            },
            {
                provide: CurrentItemService,
                useExisting: CurrentUserService,
            },
        ], ngImport: i0, template: "<cx-org-form i18nRoot=\"orgUser\">\n  <ng-container main *ngIf=\"form\" [formGroup]=\"form\">\n    <cx-form-required-legend />\n    <label>\n      <span class=\"label-content required\">{{\n        'orgUser.title' | cxTranslate\n      }}</span>\n      <ng-select\n        formControlName=\"titleCode\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"(titles$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"code\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgUser.title' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{ label: 'orgUser.title' | cxTranslate }\"\n        [control]=\"form.get('titleCode')\"\n      ></cx-form-errors>\n    </label>\n    <label>\n      <span class=\"label-content required\">\n        {{ 'orgUser.firstName' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        required\n        placeholder=\"{{ 'orgUser.firstName' | cxTranslate }}\"\n        formControlName=\"firstName\"\n        [attr.aria-invalid]=\"\n          form.get('firstName')?.touched && form.get('firstName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'firstNameError'\"\n      />\n\n      <cx-form-errors\n        id=\"firstNameError\"\n        [translationParams]=\"{ label: 'orgUser.firstName' | cxTranslate }\"\n        [control]=\"form.get('firstName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\">\n        {{ 'orgUser.lastName' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        required\n        placeholder=\"{{ 'orgUser.lastName' | cxTranslate }}\"\n        formControlName=\"lastName\"\n        [attr.aria-invalid]=\"\n          form.get('lastName')?.touched && form.get('lastName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'lastNameError'\"\n      />\n\n      <cx-form-errors\n        id=\"lastNameError\"\n        [translationParams]=\"{ label: 'orgUser.lastName' | cxTranslate }\"\n        [control]=\"form.get('lastName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\">\n        {{ 'orgUser.email' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        class=\"form-control\"\n        type=\"email\"\n        required\n        placeholder=\"{{ 'orgUser.email' | cxTranslate }}\"\n        formControlName=\"email\"\n        [attr.aria-invalid]=\"\n          form.get('email')?.touched && form.get('email')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'emailError'\"\n      />\n\n      <cx-form-errors\n        id=\"emailError\"\n        [translationParams]=\"{ label: 'orgUser.email' | cxTranslate }\"\n        [control]=\"form.get('email')\"\n      ></cx-form-errors>\n    </label>\n\n    <fieldset required=\"true\" class=\"full-width\" formArrayName=\"roles\">\n      <legend class=\"label-content required\">\n        {{ 'orgUser.roles' | cxTranslate }}\n        <cx-form-required-asterisks *cxFeature=\"'showRequiredAsterisks'\" />\n      </legend>\n\n      <label\n        class=\"form-check\"\n        *ngFor=\"let role of availableRoles; let i = index\"\n      >\n        <input\n          type=\"checkbox\"\n          class=\"form-check-input\"\n          [value]=\"role\"\n          [checked]=\"roles?.value?.includes(role)\"\n          (change)=\"updateRoles($any($event))\"\n          [disabled]=\"form?.status === 'DISABLED'\"\n        />\n        <span class=\"form-check-label\">\n          {{ 'organization.userRoles.' + role | cxTranslate }}\n        </span>\n      </label>\n    </fieldset>\n\n    <fieldset required=\"true\" class=\"full-width\">\n      <legend class=\"label-content required\">\n        {{ 'orgUser.rights' | cxTranslate }}\n        <cx-form-required-asterisks *cxFeature=\"'showRequiredAsterisks'\" />\n      </legend>\n\n      <label\n        class=\"form-check\"\n        *ngFor=\"let right of availableRights; let i = index\"\n      >\n        <input\n          type=\"checkbox\"\n          class=\"form-check-input\"\n          [value]=\"right\"\n          [checked]=\"roles?.value?.includes(right)\"\n          (change)=\"updateRoles($any($event))\"\n          [disabled]=\"form?.status === 'DISABLED'\"\n        />\n        <span class=\"form-check-label\">\n          {{ 'organization.userRights.' + right | cxTranslate }}\n        </span>\n      </label>\n    </fieldset>\n\n    <label [formGroup]=\"$any(form.get('orgUnit'))\">\n      <span class=\"label-content required\">\n        {{ 'orgUser.orgUnit' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"uid\"\n        [searchable]=\"true\"\n        [clearable]=\"false\"\n        [items]=\"(units$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"id\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgUser.orgUnit' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{ label: 'orgUser.orgUnit' | cxTranslate }\"\n        [control]=\"form.get('orgUnit.uid')\"\n      ></cx-form-errors>\n    </label>\n\n    <div *ngIf=\"isAssignedToApprovers\" class=\"full-width\">\n      <label class=\"form-check\">\n        <input\n          type=\"checkbox\"\n          class=\"form-check-input\"\n          formControlName=\"isAssignedToApprovers\"\n        />\n        <span class=\"form-check-label\">{{\n          'orgUser.assignApprover' | cxTranslate\n        }}</span>\n      </label>\n    </div>\n  </ng-container>\n</cx-org-form>\n", dependencies: [{ kind: "component", type: FormComponent, selector: "cx-org-form", inputs: ["i18nRoot", "animateBack", "subtitle"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i4.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i4.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i4.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i4.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: i4.FormArrayName, selector: "[formArrayName]", inputs: ["formArrayName"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: FeatureDirective, selector: "[cxFeature]", inputs: ["cxFeature"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-user-form', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ItemService,
                            useExisting: UserItemService,
                        },
                        {
                            provide: CurrentItemService,
                            useExisting: CurrentUserService,
                        },
                    ], imports: [
                        FormComponent,
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredLegendComponent,
                        NgSelectComponent,
                        FormErrorsComponent,
                        FormRequiredAsterisksComponent,
                        NgFor,
                        AsyncPipe,
                        TranslatePipe,
                        FeatureDirective,
                    ], template: "<cx-org-form i18nRoot=\"orgUser\">\n  <ng-container main *ngIf=\"form\" [formGroup]=\"form\">\n    <cx-form-required-legend />\n    <label>\n      <span class=\"label-content required\">{{\n        'orgUser.title' | cxTranslate\n      }}</span>\n      <ng-select\n        formControlName=\"titleCode\"\n        [searchable]=\"false\"\n        [clearable]=\"false\"\n        [items]=\"(titles$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"code\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgUser.title' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{ label: 'orgUser.title' | cxTranslate }\"\n        [control]=\"form.get('titleCode')\"\n      ></cx-form-errors>\n    </label>\n    <label>\n      <span class=\"label-content required\">\n        {{ 'orgUser.firstName' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        required\n        placeholder=\"{{ 'orgUser.firstName' | cxTranslate }}\"\n        formControlName=\"firstName\"\n        [attr.aria-invalid]=\"\n          form.get('firstName')?.touched && form.get('firstName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'firstNameError'\"\n      />\n\n      <cx-form-errors\n        id=\"firstNameError\"\n        [translationParams]=\"{ label: 'orgUser.firstName' | cxTranslate }\"\n        [control]=\"form.get('firstName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\">\n        {{ 'orgUser.lastName' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        required\n        placeholder=\"{{ 'orgUser.lastName' | cxTranslate }}\"\n        formControlName=\"lastName\"\n        [attr.aria-invalid]=\"\n          form.get('lastName')?.touched && form.get('lastName')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'lastNameError'\"\n      />\n\n      <cx-form-errors\n        id=\"lastNameError\"\n        [translationParams]=\"{ label: 'orgUser.lastName' | cxTranslate }\"\n        [control]=\"form.get('lastName')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\">\n        {{ 'orgUser.email' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        class=\"form-control\"\n        type=\"email\"\n        required\n        placeholder=\"{{ 'orgUser.email' | cxTranslate }}\"\n        formControlName=\"email\"\n        [attr.aria-invalid]=\"\n          form.get('email')?.touched && form.get('email')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'emailError'\"\n      />\n\n      <cx-form-errors\n        id=\"emailError\"\n        [translationParams]=\"{ label: 'orgUser.email' | cxTranslate }\"\n        [control]=\"form.get('email')\"\n      ></cx-form-errors>\n    </label>\n\n    <fieldset required=\"true\" class=\"full-width\" formArrayName=\"roles\">\n      <legend class=\"label-content required\">\n        {{ 'orgUser.roles' | cxTranslate }}\n        <cx-form-required-asterisks *cxFeature=\"'showRequiredAsterisks'\" />\n      </legend>\n\n      <label\n        class=\"form-check\"\n        *ngFor=\"let role of availableRoles; let i = index\"\n      >\n        <input\n          type=\"checkbox\"\n          class=\"form-check-input\"\n          [value]=\"role\"\n          [checked]=\"roles?.value?.includes(role)\"\n          (change)=\"updateRoles($any($event))\"\n          [disabled]=\"form?.status === 'DISABLED'\"\n        />\n        <span class=\"form-check-label\">\n          {{ 'organization.userRoles.' + role | cxTranslate }}\n        </span>\n      </label>\n    </fieldset>\n\n    <fieldset required=\"true\" class=\"full-width\">\n      <legend class=\"label-content required\">\n        {{ 'orgUser.rights' | cxTranslate }}\n        <cx-form-required-asterisks *cxFeature=\"'showRequiredAsterisks'\" />\n      </legend>\n\n      <label\n        class=\"form-check\"\n        *ngFor=\"let right of availableRights; let i = index\"\n      >\n        <input\n          type=\"checkbox\"\n          class=\"form-check-input\"\n          [value]=\"right\"\n          [checked]=\"roles?.value?.includes(right)\"\n          (change)=\"updateRoles($any($event))\"\n          [disabled]=\"form?.status === 'DISABLED'\"\n        />\n        <span class=\"form-check-label\">\n          {{ 'organization.userRights.' + right | cxTranslate }}\n        </span>\n      </label>\n    </fieldset>\n\n    <label [formGroup]=\"$any(form.get('orgUnit'))\">\n      <span class=\"label-content required\">\n        {{ 'orgUser.orgUnit' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"uid\"\n        [searchable]=\"true\"\n        [clearable]=\"false\"\n        [items]=\"(units$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"id\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgUser.orgUnit' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{ label: 'orgUser.orgUnit' | cxTranslate }\"\n        [control]=\"form.get('orgUnit.uid')\"\n      ></cx-form-errors>\n    </label>\n\n    <div *ngIf=\"isAssignedToApprovers\" class=\"full-width\">\n      <label class=\"form-check\">\n        <input\n          type=\"checkbox\"\n          class=\"form-check-input\"\n          formControlName=\"isAssignedToApprovers\"\n        />\n        <span class=\"form-check-label\">{{\n          'orgUser.assignApprover' | cxTranslate\n        }}</span>\n      </label>\n    </div>\n  </ng-container>\n</cx-org-form>\n" }]
        }], ctorParameters: () => [{ type: ItemService }, { type: i2.OrgUnitService }, { type: i2$1.UserProfileFacade }, { type: i2.B2BUserService }], propDecorators: { unitKey: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitUserItemService extends UserItemService {
    save(form, key) {
        // we enable the orgUnit temporarily so that the underlying
        // save method can read the complete form.value.
        form.get('orgUnit')?.enable();
        return super.save(form, key);
    }
    /**
     * @override
     * Returns 'unitDetails'
     */
    getDetailsRoute() {
        return 'orgUnitUserList';
    }
    buildRouteParams(item) {
        return { uid: item.orgUnit?.uid };
    }
    // @override to default method
    launchDetails(item) {
        const cxRoute = this.getDetailsRoute();
        const params = this.buildRouteParams(item);
        if (cxRoute && item && Object.keys(item).length > 0) {
            this.routingService.go({ cxRoute, params });
        }
    }
    create(value) {
        // Note: No id or code is provided when creating a new user so we
        // cannot store a value in the ngrx state to check that user to be
        // created via the loading state. That is why we need to assign
        // some temporary value to the id.
        value.customerId = 'new';
        this.userService.create(value);
        return this.userService.getLoadingStatus(value.customerId ?? '');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserItemService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserItemService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserItemService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitUserCreateComponent {
    constructor(unitService) {
        this.unitService = unitService;
        this.unitKey$ = this.unitService.key$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserCreateComponent, deps: [{ token: CurrentUnitService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UnitUserCreateComponent, isStandalone: true, selector: "cx-org-unit-user-create", host: { classAttribute: "content-wrapper" }, providers: [
            // we provide a specific version of the `UnitItemService` to
            // let the form component work with child units.
            {
                provide: UserItemService,
                useExisting: UnitUserItemService,
            },
        ], ngImport: i0, template: "<cx-org-user-form\n  [unitKey]=\"unitKey$ | async\"\n  i18nRoot=\"orgUnit.users\"\n></cx-org-user-form>\n", dependencies: [{ kind: "component", type: UserFormComponent, selector: "cx-org-user-form", inputs: ["unitKey"] }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserCreateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-unit-user-create', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        // we provide a specific version of the `UnitItemService` to
                        // let the form component work with child units.
                        {
                            provide: UserItemService,
                            useExisting: UnitUserItemService,
                        },
                    ], imports: [UserFormComponent, AsyncPipe], template: "<cx-org-user-form\n  [unitKey]=\"unitKey$ | async\"\n  i18nRoot=\"orgUnit.users\"\n></cx-org-user-form>\n" }]
        }], ctorParameters: () => [{ type: CurrentUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserFormModule, imports: [CommonModule,
            RouterModule,
            FormModule,
            NgSelectModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            FormErrorsModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            UserFormComponent], exports: [UserFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserFormModule, imports: [CommonModule,
            RouterModule,
            FormModule,
            NgSelectModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            FormErrorsModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            UserFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        FormModule,
                        NgSelectModule,
                        UrlModule,
                        I18nModule,
                        ReactiveFormsModule,
                        FormErrorsModule,
                        FeaturesConfigModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        UserFormComponent,
                    ],
                    exports: [UserFormComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitUserCreateModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserCreateModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitUserCreateModule, imports: [CommonModule, UserFormModule, UnitUserCreateComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserCreateModule, imports: [CommonModule, UserFormModule, UnitUserCreateComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitUserCreateModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, UserFormModule, UnitUserCreateComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitAddressRoutePageMetaResolver extends DefaultRoutePageMetaResolver {
    constructor(translation, currentItemService) {
        super(translation);
        this.currentItemService = currentItemService;
    }
    getParams() {
        return this.currentItemService.item$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressRoutePageMetaResolver, deps: [{ token: i1.TranslationService }, { token: CurrentUnitAddressService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressRoutePageMetaResolver, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitAddressRoutePageMetaResolver, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1.TranslationService }, { type: CurrentUnitAddressService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Service to populate Unit data to `Table` data. Unit
 * data is driven by the table configuration, using the `OrganizationTables.UNIT`.
 */
class UnitListService extends ListService {
    constructor(tableService, unitService, unitItemService, unitTreeService) {
        super(tableService);
        this.tableService = tableService;
        this.unitService = unitService;
        this.unitItemService = unitItemService;
        this.unitTreeService = unitTreeService;
        this.tableType = OrganizationTableType.UNIT;
        this.featureConfigService = inject(FeatureConfigService);
    }
    isSearchEnabled() {
        return this.featureConfigService.isEnabled('enableB2BUnitSearch');
    }
    getSearchPlaceholderKey() {
        return 'orgUnit.search.placeholder';
    }
    load(pagination) {
        const query = pagination?.query
            ?.trim()
            ?.toLowerCase();
        return this.unitService.getTree().pipe(switchMap((node) => this.unitItemService.key$.pipe(map((key) => {
            if (node) {
                this.unitTreeService.initialize(node, key);
            }
            return node;
        }))), switchMap((tree) => this.unitTreeService.treeToggle$.pipe(map(() => tree))), map((tree) => {
            if (query) {
                const forceExpandIds = new Set();
                const filteredTree = this.filterTree(tree, query, forceExpandIds);
                return (this.convertListItem(filteredTree, 0, { totalResults: 0 }, forceExpandIds) ?? { values: [], pagination: { totalResults: 0 } });
            }
            return this.convertListItem(tree);
        }));
    }
    /**
     * Recursively filters the tree based on search query.
     *
     * Rules:
     * - If a node matches -> keep node + ALL children (as-is, collapsed by default)
     * - If only a descendant matches -> keep all ancestors to root + only matching branch.
     *   Ancestors are added to forceExpandIds so they appear expanded in the UI.
     * - Non-matching nodes with no matching descendants are removed.
     *
     * @param forceExpandIds Collects IDs of ancestor nodes that should be
     *   force-expanded in convertListItem(). These are nodes kept only because
     *   their descendants match (not because they match themselves).
     */
    filterTree(node, query, forceExpandIds) {
        if (!node) {
            return undefined;
        }
        const selfMatches = node.id?.toLowerCase().includes(query) ||
            node.name?.toLowerCase().includes(query);
        if (selfMatches) {
            // Self matches: keep ALL children as-is (collapsed, expandable).
            // Do NOT add to forceExpandIds — children stay in their natural state.
            return { ...node };
        }
        // Self doesn't match — check children recursively
        const filteredChildren = node.children
            ?.map((child) => this.filterTree(child, query, forceExpandIds))
            .filter((child) => child != null);
        if (filteredChildren && filteredChildren.length > 0) {
            // This is an ANCESTOR of a match -> force expand so matching descendants are visible
            forceExpandIds.add(node.id ?? '');
            return { ...node, children: filteredChildren };
        }
        // No match at all
        return undefined;
    }
    convertListItem(unit, depthLevel = 0, pagination = { totalResults: 0 }, forceExpandIds) {
        let values = [];
        if (!unit) {
            return undefined;
        }
        const node = {
            ...unit,
            count: unit.children?.length ?? 0,
            expanded: forceExpandIds?.has(unit.id ?? '') ||
                this.unitTreeService.isExpanded(unit.id ?? '', depthLevel),
            depthLevel,
            // tmp, should be normalized
            uid: unit.id ?? '',
            children: [...(unit.children ?? [])].sort((unitA, unitB) => (unitA.name ?? '').localeCompare(unitB.name ?? '')),
        };
        values.push(node);
        pagination.totalResults++;
        node.children?.forEach((childUnit) => {
            const childList = this.convertListItem(childUnit, depthLevel + 1, pagination, forceExpandIds)?.values;
            if (node.expanded && childList && childList.length > 0) {
                values = values.concat(childList);
            }
        });
        return { values, pagination };
    }
    key() {
        return 'uid';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitListService, deps: [{ token: i1$1.TableService }, { token: i2.OrgUnitService }, { token: UnitItemService }, { token: UnitTreeService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.OrgUnitService }, { type: UnitItemService }, { type: UnitTreeService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitRoutePageMetaResolver extends DefaultRoutePageMetaResolver {
    constructor(translation, currentItemService) {
        super(translation);
        this.currentItemService = currentItemService;
    }
    getParams() {
        return this.currentItemService.item$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitRoutePageMetaResolver, deps: [{ token: i1.TranslationService }, { token: CurrentUnitService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitRoutePageMetaResolver, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitRoutePageMetaResolver, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1.TranslationService }, { type: CurrentUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const unitsCmsConfig = {
    cmsComponents: {
        ManageUnitsListComponent: {
            component: UnitListComponent,
            providers: [
                {
                    provide: ListService,
                    useExisting: UnitListService,
                },
                {
                    provide: ItemService,
                    useExisting: UnitItemService,
                },
            ],
            childRoutes: {
                parent: {
                    data: {
                        cxPageMeta: {
                            breadcrumb: 'orgUnit.breadcrumbs.list',
                            resolver: UnitRoutePageMetaResolver,
                        },
                    },
                },
                children: [
                    {
                        path: 'create',
                        component: UnitFormComponent,
                        canActivate: [OrgUnitGuard],
                    },
                    {
                        path: `:${ROUTE_PARAMS.unitCode}`,
                        component: UnitDetailsComponent,
                        data: {
                            cxPageMeta: { breadcrumb: 'orgUnit.breadcrumbs.details' },
                        },
                        children: [
                            {
                                path: 'edit',
                                component: UnitFormComponent,
                                canActivate: [OrgUnitGuard],
                            },
                            {
                                path: 'children',
                                component: UnitChildrenComponent,
                                canActivate: [OrgUnitGuard],
                                data: {
                                    cxPageMeta: { breadcrumb: 'orgUnit.breadcrumbs.children' },
                                },
                                children: [
                                    {
                                        path: 'create',
                                        component: UnitChildCreateComponent,
                                    },
                                ],
                            },
                            {
                                path: 'approvers',
                                data: {
                                    cxPageMeta: { breadcrumb: 'orgUnit.breadcrumbs.approvers' },
                                },
                                children: [
                                    {
                                        path: '',
                                        component: UnitAssignedApproverListComponent,
                                    },
                                    {
                                        path: 'assign',
                                        component: UnitApproverListComponent,
                                    },
                                ],
                            },
                            {
                                path: 'users',
                                component: UnitUserListComponent,
                                data: {
                                    cxPageMeta: { breadcrumb: 'orgUnit.breadcrumbs.users' },
                                },
                                children: [
                                    {
                                        path: 'create',
                                        component: UnitUserCreateComponent,
                                        canActivate: [UserGuard],
                                    },
                                    {
                                        path: `:${ROUTE_PARAMS.userCode}/roles`,
                                        component: UnitUserRolesFormComponent,
                                        canActivate: [UserGuard],
                                    },
                                ],
                            },
                            {
                                path: 'cost-centers',
                                component: UnitCostCenterListComponent,
                                data: {
                                    cxPageMeta: { breadcrumb: 'orgUnit.breadcrumbs.costCenters' },
                                },
                                children: [
                                    {
                                        path: 'create',
                                        component: UnitCostCenterCreateComponent,
                                    },
                                ],
                            },
                            {
                                path: 'addresses',
                                component: UnitAddressListComponent,
                                data: {
                                    cxPageMeta: {
                                        breadcrumb: 'orgUnit.breadcrumbs.addresses',
                                        resolver: UnitAddressRoutePageMetaResolver,
                                    },
                                },
                                children: [
                                    {
                                        path: 'create',
                                        component: UnitAddressFormComponent,
                                    },
                                    {
                                        path: `:${ROUTE_PARAMS.addressCode}`,
                                        data: {
                                            cxPageMeta: {
                                                breadcrumb: 'orgUnit.breadcrumbs.addressDetails',
                                            },
                                        },
                                        children: [
                                            {
                                                path: '',
                                                component: UnitAddressDetailsComponent,
                                            },
                                            {
                                                path: 'edit',
                                                component: UnitAddressFormComponent,
                                            },
                                        ],
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },
            guards: [AuthGuard, AdminGuard],
        },
    },
};
function unitsTableConfigFactory() {
    return unitsTableConfig;
}
const unitsTableConfig = {
    table: {
        [OrganizationTableType.UNIT]: {
            cells: ['name'],
            options: {
                layout: TableLayout.VERTICAL,
                cells: {
                    name: {
                        dataComponent: ToggleLinkCellComponent,
                        linkable: true,
                    },
                    active: {
                        dataComponent: StatusCellComponent,
                    },
                    uid: {
                        dataComponent: CellComponent,
                    },
                },
            },
            [BREAKPOINT.lg]: {
                cells: ['name', 'uid', 'active'],
            },
        },
        [OrganizationTableType.UNIT_USERS]: {
            cells: ['name', 'roles'],
            options: {
                pagination: {
                    pageSize: MAX_OCC_INTEGER_VALUE,
                },
                cells: {
                    name: {
                        dataComponent: UserDetailsCellComponent,
                    },
                    roles: {
                        dataComponent: UnitUserRolesCellComponent,
                    },
                },
            },
        },
        [OrganizationTableType.UNIT_CHILDREN]: {
            cells: ['name', 'active'],
            options: {
                pagination: {
                    pageSize: MAX_OCC_INTEGER_VALUE,
                },
                cells: {
                    name: {
                        dataComponent: UnitDetailsCellComponent,
                    },
                    active: {
                        dataComponent: StatusCellComponent,
                    },
                },
            },
        },
        [OrganizationTableType.UNIT_APPROVERS]: {
            cells: ['name', 'orgUnit', 'actions'],
            options: {
                cells: {
                    name: {
                        dataComponent: UserDetailsCellComponent,
                    },
                    actions: {
                        dataComponent: AssignCellComponent,
                    },
                    orgUnit: {
                        dataComponent: UnitCellComponent,
                    },
                },
            },
        },
        [OrganizationTableType.UNIT_ASSIGNED_APPROVERS]: {
            cells: ['name', 'orgUnit', 'actions'],
            options: {
                pagination: {
                    pageSize: MAX_OCC_INTEGER_VALUE,
                },
                cells: {
                    name: {
                        dataComponent: UserDetailsCellComponent,
                    },
                    actions: {
                        dataComponent: AssignCellComponent,
                    },
                    orgUnit: {
                        dataComponent: UnitCellComponent,
                    },
                },
            },
        },
        [OrganizationTableType.UNIT_COST_CENTERS]: {
            cells: ['name'],
            options: {
                cells: {
                    name: {
                        dataComponent: CostCenterDetailsCellComponent,
                    },
                },
                pagination: {
                    pageSize: MAX_OCC_INTEGER_VALUE,
                },
            },
        },
        [OrganizationTableType.UNIT_ADDRESS]: {
            cells: ['formattedAddress'],
            options: {
                pagination: {
                    pageSize: MAX_OCC_INTEGER_VALUE,
                },
                cells: {
                    formattedAddress: {
                        dataComponent: LinkCellComponent,
                        linkable: true,
                    },
                },
            },
        },
    },
};
/**
 * @deprecated Use `unitsTableConfig` instead.
 */
const newUnitsTableConfig = unitsTableConfig;

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitsComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitsComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitsComponentsModule, imports: [RouterModule,
            UnitListModule,
            UnitDetailsModule,
            UnitFormModule,
            UnitChildrenModule,
            UnitApproverListModule,
            UnitUsersModule,
            UnitCostCenterListModule,
            UnitAddressModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitsComponentsModule, providers: [
            provideDefaultConfig(unitsCmsConfig),
            provideDefaultConfigFactory(unitsTableConfigFactory),
        ], imports: [RouterModule,
            UnitListModule,
            UnitDetailsModule,
            UnitFormModule,
            UnitChildrenModule,
            UnitApproverListModule,
            UnitUsersModule,
            UnitCostCenterListModule,
            UnitAddressModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitsComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        RouterModule,
                        UnitListModule,
                        UnitDetailsModule,
                        UnitFormModule,
                        UnitChildrenModule,
                        UnitApproverListModule,
                        UnitUsersModule,
                        UnitCostCenterListModule,
                        UnitAddressModule,
                    ],
                    providers: [
                        provideDefaultConfig(unitsCmsConfig),
                        provideDefaultConfigFactory(unitsTableConfigFactory),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CurrentUserGroupService extends CurrentItemService {
    constructor(routingService, userGroupService) {
        super(routingService);
        this.routingService = routingService;
        this.userGroupService = userGroupService;
    }
    getParamKey() {
        return ROUTE_PARAMS.userGroupCode;
    }
    getItem(code) {
        return this.userGroupService.get(code);
    }
    getError(code) {
        return this.userGroupService.getErrorState(code);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUserGroupService, deps: [{ token: i1.RoutingService }, { token: i2.UserGroupService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUserGroupService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CurrentUserGroupService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.RoutingService }, { type: i2.UserGroupService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupFormService extends FormService {
    build() {
        const form = new UntypedFormGroup({});
        form.setControl('uid', new UntypedFormControl('', [
            Validators.required,
            CustomFormValidators.noSpecialCharacters,
        ]));
        form.setControl('name', new UntypedFormControl('', Validators.required));
        form.setControl('orgUnit', new UntypedFormGroup({
            uid: new UntypedFormControl(undefined, Validators.required),
        }));
        this.form = form;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupFormService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupFormService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupFormService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupItemService extends ItemService {
    constructor(currentItemService, routingService, formService, userGroupService) {
        super(currentItemService, routingService, formService);
        this.currentItemService = currentItemService;
        this.routingService = routingService;
        this.formService = formService;
        this.userGroupService = userGroupService;
    }
    load(code) {
        this.userGroupService.load(code);
        return this.userGroupService.get(code);
    }
    update(code, value) {
        this.userGroupService.update(code, value);
        return this.userGroupService.getLoadingStatus(value.uid ?? '');
    }
    delete(code) {
        this.launchList();
        this.userGroupService.delete(code);
        return this.userGroupService.getLoadingStatus(code);
    }
    create(value) {
        this.userGroupService.create(value);
        return this.userGroupService.getLoadingStatus(value.uid ?? '');
    }
    getDetailsRoute() {
        return 'orgUserGroupDetails';
    }
    launchList() {
        this.routingService.go({
            cxRoute: 'orgUserGroup',
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupItemService, deps: [{ token: CurrentUserGroupService }, { token: i1.RoutingService }, { token: UserGroupFormService }, { token: i2.UserGroupService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupItemService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupItemService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: CurrentUserGroupService }, { type: i1.RoutingService }, { type: UserGroupFormService }, { type: i2.UserGroupService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupDetailsComponent {
    constructor(itemService) {
        this.itemService = itemService;
        this.model$ = this.itemService.key$.pipe(switchMap((code) => this.itemService.load(code)), startWith({}));
        this.isInEditMode$ = this.itemService.isInEditMode$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupDetailsComponent, deps: [{ token: ItemService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UserGroupDetailsComponent, isStandalone: true, selector: "cx-org-user-group-details", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ItemService,
                useExisting: UserGroupItemService,
            },
        ], ngImport: i0, template: "<cx-org-card\n  *ngIf=\"model$ | async as model\"\n  i18nRoot=\"orgUserGroup.details\"\n  [cxFocus]=\"{ refreshFocus: model }\"\n>\n  <a\n    actions\n    class=\"link btn btn-link btn-sm edit\"\n    [routerLink]=\"{ cxRoute: 'orgUserGroupEdit', params: model } | cxUrl\"\n    [class.disabled]=\"isInEditMode$ | async\"\n  >\n    {{ 'organization.edit' | cxTranslate }}\n  </a>\n\n  <cx-org-delete-item\n    actions\n    key=\"uid\"\n    i18nRoot=\"orgUserGroup\"\n  ></cx-org-delete-item>\n\n  <section main class=\"details\" cxOrgItemExists>\n    <div class=\"property\">\n      <label>{{ 'orgUserGroup.name' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.name }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUserGroup.uid' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.uid }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUserGroup.orgUnit' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.orgUnit,\n          } | cxUrl\n        \"\n      >\n        {{ model.orgUnit?.name }}\n      </a>\n    </div>\n  </section>\n\n  <section main class=\"link-list\">\n    <ng-container *ngIf=\"model.uid\">\n      <a\n        class=\"link\"\n        [routerLink]=\"{ cxRoute: 'orgUserGroupUsers', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUserGroup.links.user' | cxTranslate }}\n      </a>\n      <a\n        class=\"link\"\n        [routerLink]=\"\n          { cxRoute: 'orgUserGroupPermissions', params: model } | cxUrl\n        \"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUserGroup.links.permission' | cxTranslate }}\n      </a>\n    </ng-container>\n  </section>\n</cx-org-card>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CardComponent, selector: "cx-org-card", inputs: ["i18nRoot", "previous", "subtitle", "showHint"] }, { kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: DeleteItemComponent, selector: "cx-org-delete-item", inputs: ["i18nRoot", "key", "additionalParam"] }, { kind: "directive", type: ItemExistsDirective, selector: "[cxOrgItemExists]" }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-user-group-details', changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: ItemService,
                            useExisting: UserGroupItemService,
                        },
                    ], host: { class: 'content-wrapper' }, imports: [
                        NgIf,
                        CardComponent,
                        FocusDirective,
                        RouterLink,
                        DeleteItemComponent,
                        ItemExistsDirective,
                        RouterLinkActive,
                        AsyncPipe,
                        UrlPipe,
                        TranslatePipe,
                    ], template: "<cx-org-card\n  *ngIf=\"model$ | async as model\"\n  i18nRoot=\"orgUserGroup.details\"\n  [cxFocus]=\"{ refreshFocus: model }\"\n>\n  <a\n    actions\n    class=\"link btn btn-link btn-sm edit\"\n    [routerLink]=\"{ cxRoute: 'orgUserGroupEdit', params: model } | cxUrl\"\n    [class.disabled]=\"isInEditMode$ | async\"\n  >\n    {{ 'organization.edit' | cxTranslate }}\n  </a>\n\n  <cx-org-delete-item\n    actions\n    key=\"uid\"\n    i18nRoot=\"orgUserGroup\"\n  ></cx-org-delete-item>\n\n  <section main class=\"details\" cxOrgItemExists>\n    <div class=\"property\">\n      <label>{{ 'orgUserGroup.name' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.name }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUserGroup.uid' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.uid }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUserGroup.orgUnit' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.orgUnit,\n          } | cxUrl\n        \"\n      >\n        {{ model.orgUnit?.name }}\n      </a>\n    </div>\n  </section>\n\n  <section main class=\"link-list\">\n    <ng-container *ngIf=\"model.uid\">\n      <a\n        class=\"link\"\n        [routerLink]=\"{ cxRoute: 'orgUserGroupUsers', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUserGroup.links.user' | cxTranslate }}\n      </a>\n      <a\n        class=\"link\"\n        [routerLink]=\"\n          { cxRoute: 'orgUserGroupPermissions', params: model } | cxUrl\n        \"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUserGroup.links.permission' | cxTranslate }}\n      </a>\n    </ng-container>\n  </section>\n</cx-org-card>\n" }]
        }], ctorParameters: () => [{ type: ItemService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupDetailsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupDetailsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserGroupDetailsModule, imports: [CommonModule,
            CardModule,
            RouterModule,
            UrlModule,
            I18nModule,
            DeleteItemModule,
            ItemExistsModule,
            KeyboardFocusModule,
            UserGroupDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupDetailsModule, imports: [CommonModule,
            CardModule,
            RouterModule,
            UrlModule,
            I18nModule,
            DeleteItemModule,
            ItemExistsModule,
            KeyboardFocusModule,
            UserGroupDetailsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupDetailsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        CardModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        DeleteItemModule,
                        ItemExistsModule,
                        KeyboardFocusModule,
                        UserGroupDetailsComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupFormComponent {
    constructor(itemService, unitService) {
        this.itemService = itemService;
        this.unitService = unitService;
        this.form = this.itemService.getForm();
        // getList ???
        this.units$ = this.unitService
            .getActiveUnitList()
            .pipe(tap((units) => {
            if (units && units.length === 1) {
                this.form?.get('orgUnit.uid')?.setValue(units[0]?.id);
            }
        }));
    }
    ngOnInit() {
        this.unitService.loadList();
    }
    createUidWithName(name, code) {
        createCodeForEntityName(name, code);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupFormComponent, deps: [{ token: ItemService }, { token: i2.OrgUnitService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UserGroupFormComponent, isStandalone: true, selector: "cx-org-user-group-form", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ItemService,
                useExisting: UserGroupItemService,
            },
        ], ngImport: i0, template: "<cx-org-form i18nRoot=\"orgUserGroup\">\n  <ng-container *ngIf=\"form\" [formGroup]=\"form\" main>\n    <cx-form-required-legend />\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'orgUserGroup.name' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        required\n        placeholder=\"{{ 'orgUserGroup.name' | cxTranslate }}\"\n        formControlName=\"name\"\n        (blur)=\"createUidWithName(form.get('name'), form.get('uid'))\"\n        [attr.aria-invalid]=\"\n          form.get('name')?.touched && form.get('name')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'nameError'\"\n      />\n\n      <cx-form-errors\n        id=\"nameError\"\n        [translationParams]=\"{ label: 'orgUserGroup.name' | cxTranslate }\"\n        [control]=\"form.get('name')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'orgUserGroup.uid' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        class=\"form-control\"\n        type=\"text\"\n        required\n        placeholder=\"{{ 'orgUserGroup.uid' | cxTranslate }}\"\n        formControlName=\"uid\"\n        [attr.aria-invalid]=\"\n          form.get('uid')?.touched && form.get('uid')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'uidError'\"\n      />\n\n      <cx-form-errors\n        id=\"uidError\"\n        [translationParams]=\"{ label: 'orgUserGroup.uid' | cxTranslate }\"\n        [control]=\"form.get('uid')\"\n      ></cx-form-errors>\n    </label>\n\n    <label [formGroup]=\"$any(form.get('orgUnit'))\">\n      <span class=\"label-content required\"\n        >{{ 'orgUserGroup.orgUnit' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"uid\"\n        [searchable]=\"true\"\n        [clearable]=\"false\"\n        [items]=\"(units$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"id\"\n        [readonly]=\"form.get('orgUnit.uid')?.disabled ?? false\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgUserGroup.orgUnit' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{ label: 'orgUserGroup.orgUnit' | cxTranslate }\"\n        [control]=\"form.get('orgUnit.uid')\"\n      ></cx-form-errors>\n    </label>\n  </ng-container>\n</cx-org-form>\n", dependencies: [{ kind: "component", type: FormComponent, selector: "cx-org-form", inputs: ["i18nRoot", "animateBack", "subtitle"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i4.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i4.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i4.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-user-group-form', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ItemService,
                            useExisting: UserGroupItemService,
                        },
                    ], imports: [
                        FormComponent,
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        FormRequiredLegendComponent,
                        FormRequiredAsterisksComponent,
                        FormErrorsComponent,
                        NgSelectComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<cx-org-form i18nRoot=\"orgUserGroup\">\n  <ng-container *ngIf=\"form\" [formGroup]=\"form\" main>\n    <cx-form-required-legend />\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'orgUserGroup.name' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        type=\"text\"\n        class=\"form-control\"\n        required\n        placeholder=\"{{ 'orgUserGroup.name' | cxTranslate }}\"\n        formControlName=\"name\"\n        (blur)=\"createUidWithName(form.get('name'), form.get('uid'))\"\n        [attr.aria-invalid]=\"\n          form.get('name')?.touched && form.get('name')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'nameError'\"\n      />\n\n      <cx-form-errors\n        id=\"nameError\"\n        [translationParams]=\"{ label: 'orgUserGroup.name' | cxTranslate }\"\n        [control]=\"form.get('name')\"\n      ></cx-form-errors>\n    </label>\n\n    <label>\n      <span class=\"label-content required\"\n        >{{ 'orgUserGroup.uid' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <input\n        class=\"form-control\"\n        type=\"text\"\n        required\n        placeholder=\"{{ 'orgUserGroup.uid' | cxTranslate }}\"\n        formControlName=\"uid\"\n        [attr.aria-invalid]=\"\n          form.get('uid')?.touched && form.get('uid')?.invalid\n        \"\n        [attr.aria-errormessage]=\"'uidError'\"\n      />\n\n      <cx-form-errors\n        id=\"uidError\"\n        [translationParams]=\"{ label: 'orgUserGroup.uid' | cxTranslate }\"\n        [control]=\"form.get('uid')\"\n      ></cx-form-errors>\n    </label>\n\n    <label [formGroup]=\"$any(form.get('orgUnit'))\">\n      <span class=\"label-content required\"\n        >{{ 'orgUserGroup.orgUnit' | cxTranslate }}\n        <cx-form-required-asterisks />\n      </span>\n      <ng-select\n        [inputAttrs]=\"{ required: 'true' }\"\n        formControlName=\"uid\"\n        [searchable]=\"true\"\n        [clearable]=\"false\"\n        [items]=\"(units$ | async) ?? []\"\n        bindLabel=\"name\"\n        bindValue=\"id\"\n        [readonly]=\"form.get('orgUnit.uid')?.disabled ?? false\"\n        appendTo=\"cx-org-list\"\n        [placeholder]=\"'orgUserGroup.orgUnit' | cxTranslate\"\n        ariaLabelDropdown=\"{{\n          'common.ngSelectDropdownOptionsList' | cxTranslate\n        }}\"\n      >\n      </ng-select>\n\n      <cx-form-errors\n        [translationParams]=\"{ label: 'orgUserGroup.orgUnit' | cxTranslate }\"\n        [control]=\"form.get('orgUnit.uid')\"\n      ></cx-form-errors>\n    </label>\n  </ng-container>\n</cx-org-form>\n" }]
        }], ctorParameters: () => [{ type: ItemService }, { type: i2.OrgUnitService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserGroupFormModule, imports: [CommonModule,
            RouterModule,
            NgSelectModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            FormErrorsModule,
            FormModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            UserGroupFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupFormModule, imports: [CommonModule,
            RouterModule,
            NgSelectModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            FormErrorsModule,
            FormModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            UserGroupFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        NgSelectModule,
                        UrlModule,
                        I18nModule,
                        ReactiveFormsModule,
                        FormErrorsModule,
                        FormModule,
                        FeaturesConfigModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        UserGroupFormComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupPermissionListService extends SubListService {
    constructor(tableService, userGroupService, permissionService) {
        super(tableService);
        this.tableService = tableService;
        this.userGroupService = userGroupService;
        this.permissionService = permissionService;
        this.tableType = OrganizationTableType.USER_GROUP_PERMISSIONS;
        this._domainType = OrganizationTableType.PERMISSION;
    }
    /**
     *
     * @override
     * Loads all b2b users.
     *
     * @param code The user group code.
     */
    load(pagination, code) {
        return this.userGroupService.getAvailableOrderApprovalPermissions(code, pagination);
    }
    /**
     * @override
     * Assign user to the user group.
     */
    assign(userGroupCode, permissionCode) {
        this.userGroupService.assignPermission(userGroupCode, permissionCode);
        return this.permissionService.getLoadingStatus(permissionCode);
    }
    /**
     * @override
     * Unassigns the user from the user group.
     */
    unassign(userGroupCode, permissionCode) {
        this.userGroupService.unassignPermission(userGroupCode, permissionCode);
        return this.permissionService.getLoadingStatus(permissionCode);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupPermissionListService, deps: [{ token: i1$1.TableService }, { token: i2.UserGroupService }, { token: i2.PermissionService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupPermissionListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupPermissionListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.UserGroupService }, { type: i2.PermissionService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupAssignedPermissionsListService extends UserGroupPermissionListService {
    constructor() {
        super(...arguments);
        this.tableType = OrganizationTableType.USER_GROUP_ASSIGNED_PERMISSIONS;
    }
    /**
     * @override
     * Load all b2b users assigned to the given user group
     */
    load(pagination, code) {
        return super
            .load(pagination, code)
            .pipe(map((users) => this.filterSelected(users)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupAssignedPermissionsListService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupAssignedPermissionsListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupAssignedPermissionsListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupAssignedPermissionListComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupAssignedPermissionListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UserGroupAssignedPermissionListComponent, isStandalone: true, selector: "cx-org-user-group-assigned-permission-list", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: UserGroupAssignedPermissionsListService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list>\n  <a actions class=\"link\" routerLink=\"assign\">\n    {{ 'organization.assign' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupAssignedPermissionListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-user-group-assigned-permission-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: UserGroupAssignedPermissionsListService,
                        },
                    ], imports: [SubListComponent, RouterLink, TranslatePipe], template: "<cx-org-sub-list>\n  <a actions class=\"link\" routerLink=\"assign\">\n    {{ 'organization.assign' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupPermissionListComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupPermissionListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UserGroupPermissionListComponent, isStandalone: true, selector: "cx-org-user-group-permission-list", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: UserGroupPermissionListService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list [previous]=\"false\">\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"../\">\n    {{ 'organization.done' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupPermissionListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-user-group-permission-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: UserGroupPermissionListService,
                        },
                    ], imports: [SubListComponent, RouterLink, TranslatePipe], template: "<cx-org-sub-list [previous]=\"false\">\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"../\">\n    {{ 'organization.done' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupPermissionModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupPermissionModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserGroupPermissionModule, imports: [CommonModule,
            I18nModule,
            RouterModule,
            SubListModule,
            UserGroupPermissionListComponent,
            UserGroupAssignedPermissionListComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupPermissionModule, imports: [CommonModule,
            I18nModule,
            RouterModule,
            SubListModule,
            UserGroupPermissionListComponent,
            UserGroupAssignedPermissionListComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupPermissionModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        RouterModule,
                        SubListModule,
                        UserGroupPermissionListComponent,
                        UserGroupAssignedPermissionListComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PermissionDetailsCellComponent extends CellComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionDetailsCellComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: PermissionDetailsCellComponent, isStandalone: true, selector: "cx-org-permission-details-cell", usesInheritance: true, ngImport: i0, template: "<ng-template #details>\n  <div class=\"popover-details\">\n    <div class=\"property\">\n      <label>{{ 'orgPurchaseLimit.code' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgPurchaseLimitDetails',\n            params: model,\n          } | cxUrl\n        \"\n      >\n        {{ model.code }}\n      </a>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgPurchaseLimit.active' | cxTranslate }}</label>\n      <span class=\"value\" [class.is-active]=\"model.active\">\n        {{\n          (model.active ? 'organization.enabled' : 'organization.disabled')\n            | cxTranslate\n        }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{\n        'orgPurchaseLimit.orderApprovalPermissionType' | cxTranslate\n      }}</label>\n      <span class=\"value\">\n        {{ model.orderApprovalPermissionType?.name }}\n      </span>\n    </div>\n\n    <div class=\"property\" *ngIf=\"model.threshold || model.threshold === 0\">\n      <label>{{ 'orgPurchaseLimit.threshold' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.threshold }} {{ model.currency?.symbol }}\n      </span>\n    </div>\n\n    <div class=\"property\" *ngIf=\"model.periodRange\">\n      <label>{{ 'orgPurchaseLimit.periodRange' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.periodRange }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgPurchaseLimit.unit' | cxTranslate }}</label>\n      <a\n        *ngIf=\"model.code\"\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.orgUnit,\n          } | cxUrl\n        \"\n      >\n        {{ model.orgUnit?.name }}\n      </a>\n    </div>\n  </div>\n</ng-template>\n\n<button\n  class=\"button btn btn-sm text\"\n  [cxPopover]=\"details\"\n  [cxPopoverOptions]=\"{\n    placement: 'auto',\n    class: 'my-company-popover',\n    appendToBody: true,\n    displayCloseButton: true,\n  }\"\n>\n  {{ model.code }}\n</button>\n", dependencies: [{ kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: PopoverDirective, selector: "[cxPopover]", inputs: ["cxPopover", "cxPopoverOptions"], outputs: ["openPopover", "closePopover"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionDetailsCellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-permission-details-cell', changeDetection: ChangeDetectionStrategy.OnPush, imports: [RouterLink, NgIf, PopoverDirective, TranslatePipe, UrlPipe], template: "<ng-template #details>\n  <div class=\"popover-details\">\n    <div class=\"property\">\n      <label>{{ 'orgPurchaseLimit.code' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgPurchaseLimitDetails',\n            params: model,\n          } | cxUrl\n        \"\n      >\n        {{ model.code }}\n      </a>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgPurchaseLimit.active' | cxTranslate }}</label>\n      <span class=\"value\" [class.is-active]=\"model.active\">\n        {{\n          (model.active ? 'organization.enabled' : 'organization.disabled')\n            | cxTranslate\n        }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{\n        'orgPurchaseLimit.orderApprovalPermissionType' | cxTranslate\n      }}</label>\n      <span class=\"value\">\n        {{ model.orderApprovalPermissionType?.name }}\n      </span>\n    </div>\n\n    <div class=\"property\" *ngIf=\"model.threshold || model.threshold === 0\">\n      <label>{{ 'orgPurchaseLimit.threshold' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.threshold }} {{ model.currency?.symbol }}\n      </span>\n    </div>\n\n    <div class=\"property\" *ngIf=\"model.periodRange\">\n      <label>{{ 'orgPurchaseLimit.periodRange' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.periodRange }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgPurchaseLimit.unit' | cxTranslate }}</label>\n      <a\n        *ngIf=\"model.code\"\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.orgUnit,\n          } | cxUrl\n        \"\n      >\n        {{ model.orgUnit?.name }}\n      </a>\n    </div>\n  </div>\n</ng-template>\n\n<button\n  class=\"button btn btn-sm text\"\n  [cxPopover]=\"details\"\n  [cxPopoverOptions]=\"{\n    placement: 'auto',\n    class: 'my-company-popover',\n    appendToBody: true,\n    displayCloseButton: true,\n  }\"\n>\n  {{ model.code }}\n</button>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Service to populate Cost Center data to `Table` data. The cost center
 * data is driven by the table configuration, using the `OrganizationTables.COST_CENTER`.
 */
class UserGroupListService extends ListService {
    constructor(tableService, userGroupService) {
        super(tableService);
        this.tableService = tableService;
        this.userGroupService = userGroupService;
        this.tableType = OrganizationTableType.USER_GROUP;
    }
    key() {
        return 'uid';
    }
    load(pagination) {
        return this.userGroupService.getList(pagination).pipe(filter(isNotUndefined), map((raw) => this.convertUserGroups(raw)));
    }
    /**
     * Populates the cost center data to a convenient table data model, so that we
     * can skip specific conversion in the view logic where possible.
     */
    convertUserGroups({ pagination, sorts, values, }) {
        const userGroupModels = {
            pagination,
            sorts,
            values: values.map((value) => ({
                ...value,
                unit: value.orgUnit,
            })),
        };
        return userGroupModels;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupListService, deps: [{ token: i1$1.TableService }, { token: i2.UserGroupService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.UserGroupService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupRoutePageMetaResolver extends DefaultRoutePageMetaResolver {
    constructor(translation, currentItemService) {
        super(translation);
        this.currentItemService = currentItemService;
    }
    getParams() {
        return this.currentItemService.item$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupRoutePageMetaResolver, deps: [{ token: i1.TranslationService }, { token: CurrentUserGroupService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupRoutePageMetaResolver, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupRoutePageMetaResolver, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1.TranslationService }, { type: CurrentUserGroupService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupUserListService extends SubListService {
    constructor(tableService, userGroupService, userService) {
        super(tableService);
        this.tableService = tableService;
        this.userGroupService = userGroupService;
        this.userService = userService;
        this.tableType = OrganizationTableType.USER_GROUP_USERS;
        this._domainType = OrganizationTableType.USER;
    }
    /**
     *
     * @override
     * Loads all b2b users.
     *
     * @param code The user group code.
     */
    load(pagination, code) {
        return this.userGroupService.getAvailableOrgCustomers(code, pagination);
    }
    /**
     * @override
     * Assign user to the user group.
     */
    assign(userGroupCode, customerId) {
        this.userGroupService.assignMember(userGroupCode, customerId);
        return this.userService.getLoadingStatus(customerId);
    }
    /**
     * @override
     * Unassigns the user from the user group.
     */
    unassign(userGroupCode, customerId) {
        this.userGroupService.unassignMember(userGroupCode, customerId);
        return this.userService.getLoadingStatus(customerId);
    }
    unassignAllMembers(userGroupCode) {
        this.userGroupService.unassignAllMembers(userGroupCode);
        return this.userGroupService.getLoadingStatus(userGroupCode);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupUserListService, deps: [{ token: i1$1.TableService }, { token: i2.UserGroupService }, { token: i2.B2BUserService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupUserListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupUserListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.UserGroupService }, { type: i2.B2BUserService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupAssignedUserListService extends UserGroupUserListService {
    constructor() {
        super(...arguments);
        this.tableType = OrganizationTableType.USER_GROUP_ASSIGNED_USERS;
    }
    /**
     * @override
     * Load all b2b users assigned to the given user group
     */
    load(pagination, code) {
        return super
            .load(pagination, code)
            .pipe(map((users) => this.filterSelected(users)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupAssignedUserListService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupAssignedUserListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupAssignedUserListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupAssignedUserListComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupAssignedUserListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UserGroupAssignedUserListComponent, isStandalone: true, selector: "cx-org-user-group-assigned-user-list", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: UserGroupAssignedUserListService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list>\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"assign\">\n    {{ 'organization.assign' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupAssignedUserListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-user-group-assigned-user-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: UserGroupAssignedUserListService,
                        },
                    ], imports: [SubListComponent, RouterLink, TranslatePipe], template: "<cx-org-sub-list>\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"assign\">\n    {{ 'organization.assign' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupUserListComponent {
    constructor(currentUserGroupService, userGroupUserListService) {
        this.currentUserGroupService = currentUserGroupService;
        this.userGroupUserListService = userGroupUserListService;
    }
    unassignAll() {
        this.currentUserGroupService.key$
            .pipe(first(), switchMap((key) => this.userGroupUserListService.unassignAllMembers(key).pipe(take(1), filter((data) => data.status === LoadStatus.SUCCESS))))
            .subscribe((data) => {
            this.notify(data.item);
        });
    }
    notify(item) {
        this.subList.messageService.add({
            message: {
                key: `orgUserGroupUsers.unassignAllConfirmation`,
                params: {
                    item,
                },
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupUserListComponent, deps: [{ token: CurrentUserGroupService }, { token: UserGroupUserListService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UserGroupUserListComponent, isStandalone: true, selector: "cx-org-user-group-user-list", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: UserGroupUserListService,
            },
        ], viewQueries: [{ propertyName: "subList", first: true, predicate: ["subList"], descendants: true }], ngImport: i0, template: "<cx-org-sub-list [previous]=\"false\" #subList>\n  <button actions (click)=\"unassignAll()\" class=\"link\">\n    {{ 'orgUserGroupUsers.unassignAll' | cxTranslate }}\n  </button>\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"../\">\n    {{ 'organization.done' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupUserListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-user-group-user-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: UserGroupUserListService,
                        },
                    ], imports: [SubListComponent, RouterLink, TranslatePipe], template: "<cx-org-sub-list [previous]=\"false\" #subList>\n  <button actions (click)=\"unassignAll()\" class=\"link\">\n    {{ 'orgUserGroupUsers.unassignAll' | cxTranslate }}\n  </button>\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"../\">\n    {{ 'organization.done' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n" }]
        }], ctorParameters: () => [{ type: CurrentUserGroupService }, { type: UserGroupUserListService }], propDecorators: { subList: [{
                type: ViewChild,
                args: ['subList']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const userGroupCmsConfig = {
    cmsComponents: {
        ManageUserGroupsListComponent: {
            component: ListComponent,
            providers: [
                {
                    provide: ListService,
                    useExisting: UserGroupListService,
                },
                {
                    provide: ItemService,
                    useExisting: UserGroupItemService,
                },
            ],
            childRoutes: {
                parent: {
                    data: {
                        cxPageMeta: {
                            breadcrumb: 'orgUserGroup.breadcrumbs.list',
                            resolver: UserGroupRoutePageMetaResolver,
                        },
                    },
                },
                children: [
                    {
                        path: 'create',
                        component: UserGroupFormComponent,
                    },
                    {
                        path: `:${ROUTE_PARAMS.userGroupCode}`,
                        component: UserGroupDetailsComponent,
                        data: {
                            cxPageMeta: { breadcrumb: 'orgUserGroup.breadcrumbs.details' },
                        },
                        children: [
                            {
                                path: 'edit',
                                component: UserGroupFormComponent,
                            },
                            {
                                path: 'users',
                                data: {
                                    cxPageMeta: { breadcrumb: 'orgUserGroup.breadcrumbs.users' },
                                },
                                children: [
                                    {
                                        path: '',
                                        component: UserGroupAssignedUserListComponent,
                                    },
                                    {
                                        path: 'assign',
                                        component: UserGroupUserListComponent,
                                    },
                                ],
                            },
                            {
                                path: 'purchase-limits',
                                data: {
                                    cxPageMeta: {
                                        breadcrumb: 'orgUserGroup.breadcrumbs.permissions',
                                    },
                                },
                                children: [
                                    {
                                        path: '',
                                        component: UserGroupAssignedPermissionListComponent,
                                    },
                                    {
                                        path: 'assign',
                                        component: UserGroupPermissionListComponent,
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },
            guards: [AuthGuard, AdminGuard],
        },
    },
};
function userGroupTableConfigFactory() {
    return userGroupTableConfig;
}
const userGroupTableConfig = {
    table: {
        [OrganizationTableType.USER_GROUP]: {
            cells: ['name', 'uid', 'unit'],
            options: {
                dataComponent: CellComponent,
                cells: {
                    name: {
                        dataComponent: ActiveLinkCellComponent,
                        linkable: true,
                    },
                    uid: {
                        dataComponent: CellComponent,
                    },
                    unit: {
                        dataComponent: UnitCellComponent,
                    },
                },
            },
        },
        [OrganizationTableType.USER_GROUP_ASSIGNED_USERS]: {
            cells: ['name', 'actions'],
            options: {
                cells: {
                    name: {
                        dataComponent: UserDetailsCellComponent,
                    },
                    actions: {
                        dataComponent: AssignCellComponent,
                    },
                },
                pagination: {
                    pageSize: MAX_OCC_INTEGER_VALUE,
                },
            },
        },
        [OrganizationTableType.USER_GROUP_USERS]: {
            cells: ['name', 'actions'],
            options: {
                cells: {
                    name: {
                        dataComponent: UserDetailsCellComponent,
                    },
                    actions: {
                        dataComponent: AssignCellComponent,
                    },
                },
            },
        },
        [OrganizationTableType.USER_GROUP_PERMISSIONS]: {
            cells: ['code', 'actions'],
            options: {
                cells: {
                    code: {
                        dataComponent: PermissionDetailsCellComponent,
                    },
                    actions: {
                        dataComponent: AssignCellComponent,
                    },
                },
            },
        },
        [OrganizationTableType.USER_GROUP_ASSIGNED_PERMISSIONS]: {
            cells: ['code', 'actions'],
            options: {
                cells: {
                    code: {
                        dataComponent: PermissionDetailsCellComponent,
                    },
                    actions: {
                        dataComponent: AssignCellComponent,
                    },
                },
                pagination: {
                    pageSize: MAX_OCC_INTEGER_VALUE,
                },
            },
        },
    },
};
/**
 * @deprecated Use `userGroupTableConfig` instead.
 */
const newUserGroupTableConfig = userGroupTableConfig;

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupUserModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupUserModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserGroupUserModule, imports: [CommonModule,
            I18nModule,
            RouterModule,
            SubListModule,
            UserGroupAssignedUserListComponent,
            UserGroupUserListComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupUserModule, imports: [CommonModule,
            I18nModule,
            RouterModule,
            SubListModule,
            UserGroupAssignedUserListComponent,
            UserGroupUserListComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupUserModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        RouterModule,
                        SubListModule,
                        UserGroupAssignedUserListComponent,
                        UserGroupUserListComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserGroupComponentsModule, imports: [SharedOrganizationModule,
            UserGroupDetailsModule,
            UserGroupFormModule,
            UserGroupPermissionModule,
            UserGroupUserModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupComponentsModule, providers: [
            provideDefaultConfig(userGroupCmsConfig),
            provideDefaultConfigFactory(userGroupTableConfigFactory),
        ], imports: [SharedOrganizationModule,
            UserGroupDetailsModule,
            UserGroupFormModule,
            UserGroupPermissionModule,
            UserGroupUserModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        SharedOrganizationModule,
                        UserGroupDetailsModule,
                        UserGroupFormModule,
                        UserGroupPermissionModule,
                        UserGroupUserModule,
                    ],
                    providers: [
                        provideDefaultConfig(userGroupCmsConfig),
                        provideDefaultConfigFactory(userGroupTableConfigFactory),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserApproverListService extends SubListService {
    constructor(tableService, userService) {
        super(tableService);
        this.tableService = tableService;
        this.userService = userService;
        this.tableType = OrganizationTableType.USER_APPROVERS;
        this._domainType = OrganizationTableType.USER_GROUP;
    }
    load(pagination, code) {
        return this.userService.getApprovers(code, pagination);
    }
    /**
     * @override
     * Assign approver to the user.
     */
    assign(userCode, approverId) {
        this.userService.assignApprover(userCode, approverId);
        return this.userService.getLoadingStatus(approverId);
    }
    /**
     * @override
     * Unassign the approver from the user.
     */
    unassign(userCode, approverId) {
        this.userService.unassignApprover(userCode, approverId);
        return this.userService.getLoadingStatus(approverId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserApproverListService, deps: [{ token: i1$1.TableService }, { token: i2.B2BUserService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserApproverListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserApproverListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.B2BUserService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAssignedApproverListService extends UserApproverListService {
    constructor() {
        super(...arguments);
        this.tableType = OrganizationTableType.USER_ASSIGNED_APPROVERS;
    }
    load(pagination, code) {
        return super
            .load(pagination, code)
            .pipe(map((users) => this.filterSelected(users)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAssignedApproverListService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAssignedApproverListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAssignedApproverListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAssignedApproverListComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAssignedApproverListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UserAssignedApproverListComponent, isStandalone: true, selector: "cx-org-user-assigned-approver-list", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: UserAssignedApproverListService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list>\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"assign\">\n    {{ 'organization.assign' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAssignedApproverListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-user-assigned-approver-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: UserAssignedApproverListService,
                        },
                    ], imports: [SubListComponent, RouterLink, TranslatePipe], template: "<cx-org-sub-list>\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"assign\">\n    {{ 'organization.assign' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserApproverListComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserApproverListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UserApproverListComponent, isStandalone: true, selector: "cx-org-user-approver-list", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: UserApproverListService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list [previous]=\"false\">\n  <button actions class=\"link btn btn-link btn-sm\" routerLink=\"../\">\n    {{ 'organization.done' | cxTranslate }}\n  </button>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserApproverListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-user-approver-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: UserApproverListService,
                        },
                    ], imports: [SubListComponent, RouterLink, TranslatePipe], template: "<cx-org-sub-list [previous]=\"false\">\n  <button actions class=\"link btn btn-link btn-sm\" routerLink=\"../\">\n    {{ 'organization.done' | cxTranslate }}\n  </button>\n</cx-org-sub-list>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserApproverListModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserApproverListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserApproverListModule, imports: [ListModule,
            I18nModule,
            RouterModule,
            SubListModule,
            UserApproverListComponent,
            UserAssignedApproverListComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserApproverListModule, imports: [ListModule,
            I18nModule,
            RouterModule,
            SubListModule,
            UserApproverListComponent,
            UserAssignedApproverListComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserApproverListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        ListModule,
                        I18nModule,
                        RouterModule,
                        SubListModule,
                        UserApproverListComponent,
                        UserAssignedApproverListComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserChangePasswordFormService extends FormService {
    /**
     * @override
     * Adds the password and confirmPassword field. Also adds the customerId field,
     * so that the customerId can be used during persistent.
     */
    build() {
        const passwordValidators = CustomFormValidators.passwordValidators;
        const form = new UntypedFormGroup({});
        form.setControl('customerId', new UntypedFormControl(''));
        form.setControl('password', new UntypedFormControl('', [Validators.required, ...passwordValidators]));
        form.setControl('confirmPassword', new UntypedFormControl('', [Validators.required, ...passwordValidators]));
        form.setValidators(CustomFormValidators.passwordsMustMatch('password', 'confirmPassword'));
        this.form = form;
    }
    getForm(item) {
        // we need do cleanup, to avoid have filled form after next open of that
        this.form = null;
        return super.getForm(item);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserChangePasswordFormService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserChangePasswordFormService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserChangePasswordFormService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserChangePasswordFormComponent {
    constructor(itemService, formService, messageService) {
        this.itemService = itemService;
        this.formService = formService;
        this.messageService = messageService;
        this.form$ = this.itemService.current$.pipe(map((item) => this.formService.getForm(item)));
    }
    save(form) {
        this.itemService.current$
            .pipe(first(), switchMap((item) => this.itemService.save(form, form.value.customerId).pipe(take(1), filter((data) => data.status === LoadStatus.SUCCESS), map((data) => ({
            ...item,
            ...data.item,
        })))))
            .subscribe((data) => {
            this.notify(data);
            this.itemService.launchDetails(data);
        });
    }
    notify(item) {
        this.messageService.add({
            message: {
                key: `orgUser.messages.updatePassword`,
                params: {
                    item,
                },
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserChangePasswordFormComponent, deps: [{ token: UserItemService }, { token: UserChangePasswordFormService }, { token: MessageService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UserChangePasswordFormComponent, isStandalone: true, selector: "cx-org-user-change-password-form", host: { attributes: { "ngSkipHydration": "true" }, classAttribute: "content-wrapper" }, ngImport: i0, template: "<form *ngIf=\"form$ | async as form\" [formGroup]=\"form\" (submit)=\"save(form)\">\n  <cx-org-card\n    [previous]=\"false\"\n    i18nRoot=\"orgUser.password\"\n    [cxFocus]=\"{ autofocus: 'input', refreshFocus: form }\"\n  >\n    <button actions class=\"button btn btn-sm primary btn-primary\">\n      {{ 'organization.save' | cxTranslate }}\n    </button>\n    <button\n      actions\n      class=\"link btn btn-link btn-sm\"\n      routerLink=\"../\"\n      type=\"button\"\n    >\n      {{ 'organization.cancel' | cxTranslate }}\n    </button>\n\n    <section main class=\"details\">\n      <cx-form-required-legend />\n\n      <label class=\"full-width\">\n        <span class=\"label-content\"\n          >{{ 'orgUser.password.newPassword' | cxTranslate }}\n          <cx-form-required-asterisks />\n        </span>\n        <input\n          required=\"true\"\n          class=\"form-control\"\n          type=\"password\"\n          name=\"password\"\n          placeholder=\"{{ 'orgUser.password.newPassword' | cxTranslate }}\"\n          formControlName=\"password\"\n          [attr.aria-label]=\"'orgUser.password.newPassword' | cxTranslate\"\n          cxPasswordVisibilitySwitch\n          [attr.aria-invalid]=\"\n            form.get('password')?.touched && form.get('password')?.invalid\n          \"\n          [attr.aria-errormessage]=\"'passwordError'\"\n        />\n\n        <cx-form-errors\n          id=\"passwordError\"\n          [translationParams]=\"{\n            label: 'orgUser.password.newPassword' | cxTranslate,\n          }\"\n          [control]=\"form.get('password')\"\n        ></cx-form-errors>\n      </label>\n      <label>\n        <span class=\"label-content\"\n          >{{ 'orgUser.password.confirmPassword' | cxTranslate }}\n          <cx-form-required-asterisks />\n        </span>\n        <input\n          required=\"true\"\n          class=\"form-control\"\n          type=\"password\"\n          name=\"confirmPassword\"\n          placeholder=\"{{ 'orgUser.password.confirmPassword' | cxTranslate }}\"\n          formControlName=\"confirmPassword\"\n          [attr.aria-label]=\"'orgUser.password.confirmPassword' | cxTranslate\"\n          [attr.aria-invalid]=\"\n            form.get('confirmPassword')?.touched &&\n            form.get('confirmPassword')?.invalid\n          \"\n          [attr.aria-errormessage]=\"'confirmPasswordError'\"\n          cxPasswordVisibilitySwitch\n        />\n\n        <cx-form-errors\n          id=\"confirmPasswordError\"\n          [translationParams]=\"{\n            label: 'orgUser.password.confirmPassword' | cxTranslate,\n          }\"\n          [control]=\"form.get('confirmPassword')\"\n        ></cx-form-errors>\n      </label>\n    </section>\n  </cx-org-card>\n</form>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i4.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i4.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i4.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i4.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: CardComponent, selector: "cx-org-card", inputs: ["i18nRoot", "previous", "subtitle", "showHint"] }, { kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: FormRequiredLegendComponent, selector: "cx-form-required-legend", inputs: ["formLegendTranslation"] }, { kind: "component", type: FormRequiredAsterisksComponent, selector: "cx-form-required-asterisks", inputs: ["titleTranslation"] }, { kind: "directive", type: PasswordVisibilityToggleDirective, selector: "[cxPasswordVisibilitySwitch][type=\"password\"]" }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserChangePasswordFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-user-change-password-form', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper', ngSkipHydration: 'true' }, imports: [
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        CardComponent,
                        FocusDirective,
                        RouterLink,
                        FormRequiredLegendComponent,
                        FormRequiredAsterisksComponent,
                        PasswordVisibilityToggleDirective,
                        FormErrorsComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<form *ngIf=\"form$ | async as form\" [formGroup]=\"form\" (submit)=\"save(form)\">\n  <cx-org-card\n    [previous]=\"false\"\n    i18nRoot=\"orgUser.password\"\n    [cxFocus]=\"{ autofocus: 'input', refreshFocus: form }\"\n  >\n    <button actions class=\"button btn btn-sm primary btn-primary\">\n      {{ 'organization.save' | cxTranslate }}\n    </button>\n    <button\n      actions\n      class=\"link btn btn-link btn-sm\"\n      routerLink=\"../\"\n      type=\"button\"\n    >\n      {{ 'organization.cancel' | cxTranslate }}\n    </button>\n\n    <section main class=\"details\">\n      <cx-form-required-legend />\n\n      <label class=\"full-width\">\n        <span class=\"label-content\"\n          >{{ 'orgUser.password.newPassword' | cxTranslate }}\n          <cx-form-required-asterisks />\n        </span>\n        <input\n          required=\"true\"\n          class=\"form-control\"\n          type=\"password\"\n          name=\"password\"\n          placeholder=\"{{ 'orgUser.password.newPassword' | cxTranslate }}\"\n          formControlName=\"password\"\n          [attr.aria-label]=\"'orgUser.password.newPassword' | cxTranslate\"\n          cxPasswordVisibilitySwitch\n          [attr.aria-invalid]=\"\n            form.get('password')?.touched && form.get('password')?.invalid\n          \"\n          [attr.aria-errormessage]=\"'passwordError'\"\n        />\n\n        <cx-form-errors\n          id=\"passwordError\"\n          [translationParams]=\"{\n            label: 'orgUser.password.newPassword' | cxTranslate,\n          }\"\n          [control]=\"form.get('password')\"\n        ></cx-form-errors>\n      </label>\n      <label>\n        <span class=\"label-content\"\n          >{{ 'orgUser.password.confirmPassword' | cxTranslate }}\n          <cx-form-required-asterisks />\n        </span>\n        <input\n          required=\"true\"\n          class=\"form-control\"\n          type=\"password\"\n          name=\"confirmPassword\"\n          placeholder=\"{{ 'orgUser.password.confirmPassword' | cxTranslate }}\"\n          formControlName=\"confirmPassword\"\n          [attr.aria-label]=\"'orgUser.password.confirmPassword' | cxTranslate\"\n          [attr.aria-invalid]=\"\n            form.get('confirmPassword')?.touched &&\n            form.get('confirmPassword')?.invalid\n          \"\n          [attr.aria-errormessage]=\"'confirmPasswordError'\"\n          cxPasswordVisibilitySwitch\n        />\n\n        <cx-form-errors\n          id=\"confirmPasswordError\"\n          [translationParams]=\"{\n            label: 'orgUser.password.confirmPassword' | cxTranslate,\n          }\"\n          [control]=\"form.get('confirmPassword')\"\n        ></cx-form-errors>\n      </label>\n    </section>\n  </cx-org-card>\n</form>\n" }]
        }], ctorParameters: () => [{ type: UserItemService }, { type: UserChangePasswordFormService }, { type: MessageService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserChangePasswordFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserChangePasswordFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserChangePasswordFormModule, imports: [CommonModule,
            RouterModule,
            NgSelectModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            FormErrorsModule,
            CardModule,
            KeyboardFocusModule,
            PasswordVisibilityToggleModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            UserChangePasswordFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserChangePasswordFormModule, imports: [CommonModule,
            RouterModule,
            NgSelectModule,
            UrlModule,
            I18nModule,
            ReactiveFormsModule,
            FormErrorsModule,
            CardModule,
            KeyboardFocusModule,
            PasswordVisibilityToggleModule,
            FeaturesConfigModule,
            FormRequiredAsterisksComponent,
            FormRequiredLegendComponent,
            UserChangePasswordFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserChangePasswordFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        NgSelectModule,
                        UrlModule,
                        I18nModule,
                        ReactiveFormsModule,
                        FormErrorsModule,
                        CardModule,
                        KeyboardFocusModule,
                        PasswordVisibilityToggleModule,
                        FeaturesConfigModule,
                        FormRequiredAsterisksComponent,
                        FormRequiredLegendComponent,
                        UserChangePasswordFormComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserDetailsComponent {
    constructor(itemService, b2bUserService) {
        this.itemService = itemService;
        this.b2bUserService = b2bUserService;
        this.model$ = this.itemService.key$.pipe(switchMap((code) => this.itemService.load(code)), startWith({}));
        this.isInEditMode$ = this.itemService.isInEditMode$;
        this.isUpdatingUserAllowed = this.b2bUserService.isUpdatingUserAllowed();
        this.availableRoles = this.b2bUserService
            .getAllRoles()
            .map((role) => role.toString());
        this.availableRights = this.b2bUserService
            .getAllRights()
            .map((right) => right.toString());
    }
    hasRight(model) {
        return (model.roles ?? []).some((role) => this.availableRights.includes(role));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserDetailsComponent, deps: [{ token: ItemService }, { token: i2.B2BUserService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UserDetailsComponent, isStandalone: true, selector: "cx-org-user-details", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ItemService,
                useExisting: UserItemService,
            },
        ], ngImport: i0, template: "<cx-org-card\n  *ngIf=\"model$ | async as model\"\n  i18nRoot=\"orgUser.details\"\n  [cxFocus]=\"{ refreshFocus: model }\"\n>\n  <a\n    actions\n    *ngIf=\"isUpdatingUserAllowed\"\n    class=\"link btn btn-link btn-sm edit\"\n    [class.disabled]=\"!model.active || (isInEditMode$ | async)\"\n    [routerLink]=\"{ cxRoute: 'orgUserEdit', params: model } | cxUrl\"\n  >\n    {{ 'organization.edit' | cxTranslate }}\n  </a>\n\n  <cx-org-toggle-status\n    actions\n    *ngIf=\"isUpdatingUserAllowed\"\n    key=\"customerId\"\n    i18nRoot=\"orgUser\"\n  ></cx-org-toggle-status>\n\n  <cx-org-disable-info info i18nRoot=\"orgUser\"> </cx-org-disable-info>\n\n  <section main class=\"details\" cxOrgItemExists>\n    <div class=\"property\">\n      <label>{{ 'orgUser.name' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.name }}\n      </span>\n    </div>\n\n    <div class=\"property full-width\">\n      <label>{{ 'orgUser.uid' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.displayUid }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUser.roles' | cxTranslate }}</label>\n      <ul class=\"value\">\n        <ng-container *ngFor=\"let role of model.roles\">\n          <li\n            *ngIf=\"availableRoles.includes(role)\"\n            [innerText]=\"'organization.userRoles.' + role | cxTranslate\"\n          ></li>\n        </ng-container>\n        <li *ngIf=\"model.roles?.length === 0\">-</li>\n      </ul>\n    </div>\n\n    <ng-container *ngIf=\"hasRight(model)\">\n      <div class=\"property\">\n        <label>{{ 'orgUser.rights' | cxTranslate }}</label>\n        <ul class=\"value\">\n          <ng-container *ngFor=\"let role of model.roles\">\n            <li\n              *ngIf=\"availableRights.includes(role)\"\n              [innerText]=\"'organization.userRights.' + role | cxTranslate\"\n            ></li>\n          </ng-container>\n          <li *ngIf=\"model.roles?.length === 0\">-</li>\n        </ul>\n      </div>\n    </ng-container>\n\n    <div class=\"property\">\n      <label>{{ 'orgUser.orgUnit' | cxTranslate }}</label>\n      <a\n        *ngIf=\"isUpdatingUserAllowed; else showOrgUnitValueWithoutNavigation\"\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.orgUnit,\n          } | cxUrl\n        \"\n      >\n        {{ model.orgUnit?.name }}\n      </a>\n      <ng-template #showOrgUnitValueWithoutNavigation>\n        <div class=\"orgUnit\">{{ model.orgUnit?.name }}</div>\n      </ng-template>\n    </div>\n    <div class=\"property full-width\">\n      <a\n        *ngIf=\"model.customerId && isUpdatingUserAllowed\"\n        class=\"link btn btn-link btn-sm\"\n        [class.disabled]=\"!model.active\"\n        [routerLink]=\"\n          { cxRoute: 'orgUserChangePassword', params: model } | cxUrl\n        \"\n      >\n        {{ 'orgUser.links.password' | cxTranslate }}\n      </a>\n    </div>\n  </section>\n\n  <section main class=\"link-list\">\n    <ng-container *ngIf=\"model.customerId\">\n      <a\n        class=\"link btn btn-link btn-sm\"\n        [routerLink]=\"{ cxRoute: 'orgUserApprovers', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUser.links.approvers' | cxTranslate }}\n      </a>\n      <a\n        class=\"link btn btn-link btn-sm\"\n        [routerLink]=\"{ cxRoute: 'orgUserUserGroups', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUser.links.userGroup' | cxTranslate }}\n      </a>\n\n      <a\n        class=\"link btn btn-link btn-sm\"\n        [routerLink]=\"{ cxRoute: 'orgUserPermissions', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUser.links.permission' | cxTranslate }}\n      </a>\n    </ng-container>\n  </section>\n</cx-org-card>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CardComponent, selector: "cx-org-card", inputs: ["i18nRoot", "previous", "subtitle", "showHint"] }, { kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: ToggleStatusComponent, selector: "cx-org-toggle-status", inputs: ["i18nRoot", "key", "disabled"] }, { kind: "component", type: DisableInfoComponent, selector: "cx-org-disable-info", inputs: ["i18nRoot", "displayInfoConfig", "displayCustomInfo"] }, { kind: "directive", type: ItemExistsDirective, selector: "[cxOrgItemExists]" }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-user-details', changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: ItemService,
                            useExisting: UserItemService,
                        },
                    ], host: { class: 'content-wrapper' }, imports: [
                        NgIf,
                        CardComponent,
                        FocusDirective,
                        RouterLink,
                        ToggleStatusComponent,
                        DisableInfoComponent,
                        ItemExistsDirective,
                        NgFor,
                        RouterLinkActive,
                        AsyncPipe,
                        UrlPipe,
                        TranslatePipe,
                    ], template: "<cx-org-card\n  *ngIf=\"model$ | async as model\"\n  i18nRoot=\"orgUser.details\"\n  [cxFocus]=\"{ refreshFocus: model }\"\n>\n  <a\n    actions\n    *ngIf=\"isUpdatingUserAllowed\"\n    class=\"link btn btn-link btn-sm edit\"\n    [class.disabled]=\"!model.active || (isInEditMode$ | async)\"\n    [routerLink]=\"{ cxRoute: 'orgUserEdit', params: model } | cxUrl\"\n  >\n    {{ 'organization.edit' | cxTranslate }}\n  </a>\n\n  <cx-org-toggle-status\n    actions\n    *ngIf=\"isUpdatingUserAllowed\"\n    key=\"customerId\"\n    i18nRoot=\"orgUser\"\n  ></cx-org-toggle-status>\n\n  <cx-org-disable-info info i18nRoot=\"orgUser\"> </cx-org-disable-info>\n\n  <section main class=\"details\" cxOrgItemExists>\n    <div class=\"property\">\n      <label>{{ 'orgUser.name' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.name }}\n      </span>\n    </div>\n\n    <div class=\"property full-width\">\n      <label>{{ 'orgUser.uid' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.displayUid }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUser.roles' | cxTranslate }}</label>\n      <ul class=\"value\">\n        <ng-container *ngFor=\"let role of model.roles\">\n          <li\n            *ngIf=\"availableRoles.includes(role)\"\n            [innerText]=\"'organization.userRoles.' + role | cxTranslate\"\n          ></li>\n        </ng-container>\n        <li *ngIf=\"model.roles?.length === 0\">-</li>\n      </ul>\n    </div>\n\n    <ng-container *ngIf=\"hasRight(model)\">\n      <div class=\"property\">\n        <label>{{ 'orgUser.rights' | cxTranslate }}</label>\n        <ul class=\"value\">\n          <ng-container *ngFor=\"let role of model.roles\">\n            <li\n              *ngIf=\"availableRights.includes(role)\"\n              [innerText]=\"'organization.userRights.' + role | cxTranslate\"\n            ></li>\n          </ng-container>\n          <li *ngIf=\"model.roles?.length === 0\">-</li>\n        </ul>\n      </div>\n    </ng-container>\n\n    <div class=\"property\">\n      <label>{{ 'orgUser.orgUnit' | cxTranslate }}</label>\n      <a\n        *ngIf=\"isUpdatingUserAllowed; else showOrgUnitValueWithoutNavigation\"\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.orgUnit,\n          } | cxUrl\n        \"\n      >\n        {{ model.orgUnit?.name }}\n      </a>\n      <ng-template #showOrgUnitValueWithoutNavigation>\n        <div class=\"orgUnit\">{{ model.orgUnit?.name }}</div>\n      </ng-template>\n    </div>\n    <div class=\"property full-width\">\n      <a\n        *ngIf=\"model.customerId && isUpdatingUserAllowed\"\n        class=\"link btn btn-link btn-sm\"\n        [class.disabled]=\"!model.active\"\n        [routerLink]=\"\n          { cxRoute: 'orgUserChangePassword', params: model } | cxUrl\n        \"\n      >\n        {{ 'orgUser.links.password' | cxTranslate }}\n      </a>\n    </div>\n  </section>\n\n  <section main class=\"link-list\">\n    <ng-container *ngIf=\"model.customerId\">\n      <a\n        class=\"link btn btn-link btn-sm\"\n        [routerLink]=\"{ cxRoute: 'orgUserApprovers', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUser.links.approvers' | cxTranslate }}\n      </a>\n      <a\n        class=\"link btn btn-link btn-sm\"\n        [routerLink]=\"{ cxRoute: 'orgUserUserGroups', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUser.links.userGroup' | cxTranslate }}\n      </a>\n\n      <a\n        class=\"link btn btn-link btn-sm\"\n        [routerLink]=\"{ cxRoute: 'orgUserPermissions', params: model } | cxUrl\"\n        routerLinkActive=\"is-current\"\n      >\n        {{ 'orgUser.links.permission' | cxTranslate }}\n      </a>\n    </ng-container>\n  </section>\n</cx-org-card>\n" }]
        }], ctorParameters: () => [{ type: ItemService }, { type: i2.B2BUserService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserDetailsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserDetailsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserDetailsModule, imports: [CommonModule,
            CardModule,
            RouterModule,
            UrlModule,
            I18nModule,
            ToggleStatusModule,
            ItemExistsModule,
            DisableInfoModule,
            KeyboardFocusModule,
            UserDetailsComponent], exports: [UserDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserDetailsModule, imports: [CommonModule,
            CardModule,
            RouterModule,
            UrlModule,
            I18nModule,
            ToggleStatusModule,
            ItemExistsModule,
            DisableInfoModule,
            KeyboardFocusModule,
            UserDetailsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserDetailsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        CardModule,
                        RouterModule,
                        UrlModule,
                        I18nModule,
                        ToggleStatusModule,
                        ItemExistsModule,
                        DisableInfoModule,
                        KeyboardFocusModule,
                        UserDetailsComponent,
                    ],
                    exports: [UserDetailsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserPermissionListService extends SubListService {
    constructor(tableService, userService, permissionService) {
        super(tableService);
        this.tableService = tableService;
        this.userService = userService;
        this.permissionService = permissionService;
        this.tableType = OrganizationTableType.USER_PERMISSIONS;
        this._domainType = OrganizationTableType.PERMISSION;
    }
    load(pagination, code) {
        return this.userService.getPermissions(code, pagination);
    }
    /**
     * @override
     * Assign permission to the user.
     */
    assign(userCode, code) {
        this.userService.assignPermission(userCode, code);
        return this.permissionService.getLoadingStatus(code);
    }
    /**
     * @override
     * Unassign the permission from the user.
     */
    unassign(userCode, code) {
        this.userService.unassignPermission(userCode, code);
        return this.permissionService.getLoadingStatus(code);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserPermissionListService, deps: [{ token: i1$1.TableService }, { token: i2.B2BUserService }, { token: i2.PermissionService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserPermissionListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserPermissionListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.B2BUserService }, { type: i2.PermissionService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAssignedPermissionListService extends UserPermissionListService {
    constructor() {
        super(...arguments);
        this.tableType = OrganizationTableType.USER_ASSIGNED_PERMISSIONS;
    }
    load(pagination, code) {
        return super
            .load(pagination, code)
            .pipe(map((result) => this.filterSelected(result)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAssignedPermissionListService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAssignedPermissionListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAssignedPermissionListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAssignedPermissionListComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAssignedPermissionListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UserAssignedPermissionListComponent, isStandalone: true, selector: "cx-org-user-assigned-permission-list", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: UserAssignedPermissionListService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list>\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"assign\">\n    {{ 'organization.assign' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAssignedPermissionListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-user-assigned-permission-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: UserAssignedPermissionListService,
                        },
                    ], imports: [SubListComponent, RouterLink, TranslatePipe], template: "<cx-org-sub-list>\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"assign\">\n    {{ 'organization.assign' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserPermissionListComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserPermissionListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UserPermissionListComponent, isStandalone: true, selector: "cx-org-user-permission-list", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: UserPermissionListService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list [previous]=\"false\">\n  <button actions class=\"link btn btn-link btn-sm\" routerLink=\"../\">\n    {{ 'organization.done' | cxTranslate }}\n  </button>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserPermissionListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-user-permission-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: UserPermissionListService,
                        },
                    ], imports: [SubListComponent, RouterLink, TranslatePipe], template: "<cx-org-sub-list [previous]=\"false\">\n  <button actions class=\"link btn btn-link btn-sm\" routerLink=\"../\">\n    {{ 'organization.done' | cxTranslate }}\n  </button>\n</cx-org-sub-list>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserPermissionListModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserPermissionListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserPermissionListModule, imports: [ListModule,
            I18nModule,
            RouterModule,
            SubListModule,
            UserPermissionListComponent,
            UserAssignedPermissionListComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserPermissionListModule, imports: [ListModule,
            I18nModule,
            RouterModule,
            SubListModule,
            UserPermissionListComponent,
            UserAssignedPermissionListComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserPermissionListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        ListModule,
                        I18nModule,
                        RouterModule,
                        SubListModule,
                        UserPermissionListComponent,
                        UserAssignedPermissionListComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserUserGroupListService extends SubListService {
    constructor(tableService, userService, userGroupService) {
        super(tableService);
        this.tableService = tableService;
        this.userService = userService;
        this.userGroupService = userGroupService;
        this.tableType = OrganizationTableType.USER_USER_GROUPS;
        this._domainType = OrganizationTableType.USER_GROUP;
    }
    load(pagination, code) {
        return this.userService.getUserGroups(code, pagination);
    }
    /**
     * @override
     * Assign user group to the user.
     */
    assign(userCode, userGroupCode) {
        this.userService.assignUserGroup(userCode, userGroupCode);
        return this.userGroupService.getLoadingStatus(userGroupCode);
    }
    /**
     * @override
     * Unassign the user group from the user.
     */
    unassign(userCode, userGroupCode) {
        this.userService.unassignUserGroup(userCode, userGroupCode);
        return this.userGroupService.getLoadingStatus(userGroupCode);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserUserGroupListService, deps: [{ token: i1$1.TableService }, { token: i2.B2BUserService }, { token: i2.UserGroupService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserUserGroupListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserUserGroupListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.B2BUserService }, { type: i2.UserGroupService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAssignedUserGroupListService extends UserUserGroupListService {
    constructor() {
        super(...arguments);
        this.tableType = OrganizationTableType.USER_ASSIGNED_USER_GROUPS;
    }
    load(pagination, code) {
        return super.load(pagination, code).pipe(filter((list) => Boolean(list)), map((userGroups) => this.filterSelected(userGroups)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAssignedUserGroupListService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAssignedUserGroupListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAssignedUserGroupListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAssignedUserGroupListComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAssignedUserGroupListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UserAssignedUserGroupListComponent, isStandalone: true, selector: "cx-org-user-assigned-user-group-list", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: UserAssignedUserGroupListService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list>\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"assign\">\n    {{ 'organization.assign' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserAssignedUserGroupListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-user-assigned-user-group-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: UserAssignedUserGroupListService,
                        },
                    ], imports: [SubListComponent, RouterLink, TranslatePipe], template: "<cx-org-sub-list>\n  <a actions class=\"link btn btn-link btn-sm\" routerLink=\"assign\">\n    {{ 'organization.assign' | cxTranslate }}\n  </a>\n</cx-org-sub-list>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserUserGroupListComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserUserGroupListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UserUserGroupListComponent, isStandalone: true, selector: "cx-org-user-user-group-list", host: { classAttribute: "content-wrapper" }, providers: [
            {
                provide: ListService,
                useExisting: UserUserGroupListService,
            },
        ], ngImport: i0, template: "<cx-org-sub-list [previous]=\"false\">\n  <button actions class=\"link btn btn-link btn-sm\" routerLink=\"../\">\n    {{ 'organization.done' | cxTranslate }}\n  </button>\n</cx-org-sub-list>\n", dependencies: [{ kind: "component", type: SubListComponent, selector: "cx-org-sub-list", inputs: ["previous", "key", "showHint", "routerKey"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserUserGroupListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-user-user-group-list', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'content-wrapper' }, providers: [
                        {
                            provide: ListService,
                            useExisting: UserUserGroupListService,
                        },
                    ], imports: [SubListComponent, RouterLink, TranslatePipe], template: "<cx-org-sub-list [previous]=\"false\">\n  <button actions class=\"link btn btn-link btn-sm\" routerLink=\"../\">\n    {{ 'organization.done' | cxTranslate }}\n  </button>\n</cx-org-sub-list>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserUserGroupsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserUserGroupsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserUserGroupsModule, imports: [ListModule,
            I18nModule,
            RouterModule,
            SubListModule,
            UserUserGroupListComponent,
            UserAssignedUserGroupListComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserUserGroupsModule, imports: [ListModule,
            I18nModule,
            RouterModule,
            SubListModule,
            UserUserGroupListComponent,
            UserAssignedUserGroupListComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserUserGroupsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        ListModule,
                        I18nModule,
                        RouterModule,
                        SubListModule,
                        UserUserGroupListComponent,
                        UserAssignedUserGroupListComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupDetailsCellComponent extends CellComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupDetailsCellComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.19", type: UserGroupDetailsCellComponent, isStandalone: true, selector: "cx-org-user-group-details-cell", usesInheritance: true, ngImport: i0, template: "<ng-template #details>\n  <div class=\"popover-details\">\n    <div class=\"property\">\n      <label>{{ 'orgUserGroup.name' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUserGroupDetails',\n            params: model,\n          } | cxUrl\n        \"\n        >{{ model.name }}</a\n      >\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUserGroup.uid' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.uid }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUserGroup.orgUnit' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.orgUnit,\n          } | cxUrl\n        \"\n      >\n        {{ model.orgUnit?.name }}\n      </a>\n    </div>\n  </div>\n</ng-template>\n\n<button\n  class=\"button btn btn-sm text\"\n  [cxPopover]=\"details\"\n  [cxPopoverOptions]=\"{\n    placement: 'auto',\n    class: 'my-company-popover',\n    appendToBody: true,\n    displayCloseButton: true,\n  }\"\n>\n  {{ model?.name }}\n</button>\n", dependencies: [{ kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: PopoverDirective, selector: "[cxPopover]", inputs: ["cxPopover", "cxPopoverOptions"], outputs: ["openPopover", "closePopover"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupDetailsCellComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-org-user-group-details-cell', changeDetection: ChangeDetectionStrategy.OnPush, imports: [RouterLink, PopoverDirective, TranslatePipe, UrlPipe], template: "<ng-template #details>\n  <div class=\"popover-details\">\n    <div class=\"property\">\n      <label>{{ 'orgUserGroup.name' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUserGroupDetails',\n            params: model,\n          } | cxUrl\n        \"\n        >{{ model.name }}</a\n      >\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUserGroup.uid' | cxTranslate }}</label>\n      <span class=\"value\">\n        {{ model.uid }}\n      </span>\n    </div>\n\n    <div class=\"property\">\n      <label>{{ 'orgUserGroup.orgUnit' | cxTranslate }}</label>\n      <a\n        class=\"value\"\n        [routerLink]=\"\n          {\n            cxRoute: 'orgUnitDetails',\n            params: model.orgUnit,\n          } | cxUrl\n        \"\n      >\n        {{ model.orgUnit?.name }}\n      </a>\n    </div>\n  </div>\n</ng-template>\n\n<button\n  class=\"button btn btn-sm text\"\n  [cxPopover]=\"details\"\n  [cxPopoverOptions]=\"{\n    placement: 'auto',\n    class: 'my-company-popover',\n    appendToBody: true,\n    displayCloseButton: true,\n  }\"\n>\n  {{ model?.name }}\n</button>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Service to populate User data to `Table` data. The user
 * data is driven by the table configuration, using the `OrganizationTables.USER`.
 */
class UserListService extends ListService {
    constructor(tableService, userService) {
        super(tableService);
        this.tableService = tableService;
        this.userService = userService;
        this.tableType = OrganizationTableType.USER;
        this.featureConfigService = inject(FeatureConfigService);
    }
    key() {
        return 'customerId';
    }
    load(pagination) {
        return this.userService.getList(pagination).pipe(filter(isNotUndefined), map((raw) => this.convertUsers(raw)));
    }
    /**
     * Populates the cost center data to a convenient table data model, so that we
     * can skip specific conversion in the view logic where possible.
     */
    convertUsers({ pagination, sorts, values, }) {
        const availableRoles = this.userService.getAllRoles();
        const userModels = {
            pagination,
            sorts,
            values: values.map((value) => ({
                ...value,
                unit: value.orgUnit,
                roles: value.roles?.filter((role) => availableRoles.includes(role)),
            })),
        };
        return userModels;
    }
    /**
     * Enable search functionality for user list based on feature toggle.
     */
    isSearchEnabled() {
        return this.featureConfigService.isEnabled('enableB2BCustomerSearch');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserListService, deps: [{ token: i1$1.TableService }, { token: i2.B2BUserService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserListService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserListService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1$1.TableService }, { type: i2.B2BUserService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserRoutePageMetaResolver extends DefaultRoutePageMetaResolver {
    constructor(translation, currentItemService) {
        super(translation);
        this.currentItemService = currentItemService;
    }
    getParams() {
        return this.currentItemService.item$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserRoutePageMetaResolver, deps: [{ token: i1.TranslationService }, { token: CurrentUserService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserRoutePageMetaResolver, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserRoutePageMetaResolver, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1.TranslationService }, { type: CurrentUserService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const userCmsConfig = {
    cmsComponents: {
        ManageUsersListComponent: {
            component: ListComponent,
            providers: [
                {
                    provide: ListService,
                    useExisting: UserListService,
                },
                {
                    provide: ItemService,
                    useExisting: UserItemService,
                },
            ],
            childRoutes: {
                parent: {
                    data: {
                        cxPageMeta: {
                            breadcrumb: 'orgUser.breadcrumbs.list',
                            resolver: UserRoutePageMetaResolver,
                        },
                    },
                },
                children: [
                    {
                        path: 'create',
                        component: UserFormComponent,
                        canActivate: [UserGuard],
                    },
                    {
                        path: `:${ROUTE_PARAMS.userCode}`,
                        component: UserDetailsComponent,
                        data: {
                            cxPageMeta: { breadcrumb: 'orgUser.breadcrumbs.details' },
                        },
                        children: [
                            {
                                path: `edit`,
                                component: UserFormComponent,
                                canActivate: [UserGuard],
                            },
                            {
                                path: `change-password`,
                                component: UserChangePasswordFormComponent,
                                canActivate: [UserGuard],
                            },
                            {
                                path: 'user-groups',
                                data: {
                                    cxPageMeta: { breadcrumb: 'orgUser.breadcrumbs.userGroups' },
                                },
                                children: [
                                    {
                                        path: '',
                                        component: UserAssignedUserGroupListComponent,
                                    },
                                    {
                                        path: 'assign',
                                        component: UserUserGroupListComponent,
                                    },
                                ],
                            },
                            {
                                path: 'approvers',
                                data: {
                                    cxPageMeta: { breadcrumb: 'orgUser.breadcrumbs.approvers' },
                                },
                                children: [
                                    {
                                        path: '',
                                        component: UserAssignedApproverListComponent,
                                    },
                                    {
                                        path: 'assign',
                                        component: UserApproverListComponent,
                                    },
                                ],
                            },
                            {
                                path: 'purchase-limits',
                                data: {
                                    cxPageMeta: { breadcrumb: 'orgUser.breadcrumbs.permissions' },
                                },
                                children: [
                                    {
                                        path: '',
                                        component: UserAssignedPermissionListComponent,
                                    },
                                    {
                                        path: 'assign',
                                        component: UserPermissionListComponent,
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },
            guards: [AuthGuard, AdminGuard],
        },
    },
};
function userTableConfigFactory() {
    return userTableConfig;
}
const actions = {
    dataComponent: AssignCellComponent,
};
const pagination = {
    pageSize: MAX_OCC_INTEGER_VALUE,
};
const userTableConfig = {
    table: {
        [OrganizationTableType.USER]: {
            cells: ['name', 'active', 'uid', 'roles', 'unit'],
            options: {
                cells: {
                    name: {
                        dataComponent: ActiveLinkCellComponent,
                        linkable: true,
                    },
                    active: {
                        dataComponent: StatusCellComponent,
                    },
                    uid: {
                        dataComponent: CellComponent,
                    },
                    roles: {
                        dataComponent: RolesCellComponent,
                    },
                    unit: {
                        dataComponent: UnitCellComponent,
                    },
                },
            },
        },
        [OrganizationTableType.USER_APPROVERS]: {
            cells: ['name', 'actions'],
            options: {
                cells: {
                    name: {
                        dataComponent: UserDetailsCellComponent,
                    },
                    actions,
                },
            },
        },
        [OrganizationTableType.USER_ASSIGNED_APPROVERS]: {
            cells: ['name', 'actions'],
            options: {
                cells: {
                    name: {
                        dataComponent: UserDetailsCellComponent,
                    },
                    actions,
                },
                pagination,
            },
        },
        [OrganizationTableType.USER_USER_GROUPS]: {
            cells: ['name', 'actions'],
            options: {
                cells: {
                    name: {
                        dataComponent: UserGroupDetailsCellComponent,
                    },
                    actions,
                },
            },
        },
        [OrganizationTableType.USER_ASSIGNED_USER_GROUPS]: {
            cells: ['name', 'actions'],
            options: {
                cells: {
                    name: {
                        dataComponent: UserGroupDetailsCellComponent,
                    },
                    actions,
                },
                pagination,
            },
        },
        [OrganizationTableType.USER_PERMISSIONS]: {
            cells: ['code', 'actions'],
            options: {
                cells: {
                    code: {
                        dataComponent: PermissionDetailsCellComponent,
                    },
                    actions,
                },
            },
        },
        [OrganizationTableType.USER_ASSIGNED_PERMISSIONS]: {
            cells: ['code', 'actions'],
            options: {
                cells: {
                    code: {
                        dataComponent: PermissionDetailsCellComponent,
                    },
                    actions,
                },
                pagination,
            },
        },
    },
};
/**
 * @deprecated Use `userTableConfig` instead.
 */
const newUserTableConfig = userTableConfig;

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserComponentsModule, imports: [ListModule,
            UserChangePasswordFormModule,
            UserDetailsModule,
            UserFormModule,
            UserPermissionListModule,
            UserUserGroupsModule,
            UserApproverListModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserComponentsModule, providers: [
            provideDefaultConfig(userCmsConfig),
            provideDefaultConfigFactory(userTableConfigFactory),
        ], imports: [ListModule,
            UserChangePasswordFormModule,
            UserDetailsModule,
            UserFormModule,
            UserPermissionListModule,
            UserUserGroupsModule,
            UserApproverListModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        ListModule,
                        UserChangePasswordFormModule,
                        UserDetailsModule,
                        UserFormModule,
                        UserPermissionListModule,
                        UserUserGroupsModule,
                        UserApproverListModule,
                    ],
                    providers: [
                        provideDefaultConfig(userCmsConfig),
                        provideDefaultConfigFactory(userTableConfigFactory),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class AdministrationComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AdministrationComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: AdministrationComponentsModule, imports: [BudgetComponentsModule,
            CostCenterComponentsModule,
            UnitsComponentsModule,
            UserGroupComponentsModule,
            UserComponentsModule,
            PermissionComponentsModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AdministrationComponentsModule, imports: [BudgetComponentsModule,
            CostCenterComponentsModule,
            UnitsComponentsModule,
            UserGroupComponentsModule,
            UserComponentsModule,
            PermissionComponentsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: AdministrationComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        BudgetComponentsModule,
                        CostCenterComponentsModule,
                        UnitsComponentsModule,
                        UserGroupComponentsModule,
                        UserComponentsModule,
                        PermissionComponentsModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CostCenterDetailsCellModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterDetailsCellModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: CostCenterDetailsCellModule, imports: [CommonModule,
            PopoverModule,
            RouterModule,
            I18nModule,
            UrlModule,
            CostCenterDetailsCellComponent], exports: [CostCenterDetailsCellComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterDetailsCellModule, imports: [CommonModule,
            PopoverModule,
            RouterModule,
            I18nModule,
            UrlModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: CostCenterDetailsCellModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        PopoverModule,
                        RouterModule,
                        I18nModule,
                        UrlModule,
                        CostCenterDetailsCellComponent,
                    ],
                    exports: [CostCenterDetailsCellComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PermissionDetailsCellModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionDetailsCellModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: PermissionDetailsCellModule, imports: [CommonModule,
            PopoverModule,
            RouterModule,
            I18nModule,
            UrlModule,
            PermissionDetailsCellComponent], exports: [PermissionDetailsCellComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionDetailsCellModule, imports: [CommonModule,
            PopoverModule,
            RouterModule,
            I18nModule,
            UrlModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: PermissionDetailsCellModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        PopoverModule,
                        RouterModule,
                        I18nModule,
                        UrlModule,
                        PermissionDetailsCellComponent,
                    ],
                    exports: [PermissionDetailsCellComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UnitDetailsCellModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitDetailsCellModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UnitDetailsCellModule, imports: [CommonModule,
            PopoverModule,
            RouterModule,
            I18nModule,
            UrlModule,
            UnitDetailsCellComponent], exports: [UnitDetailsCellComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitDetailsCellModule, imports: [CommonModule,
            PopoverModule,
            RouterModule,
            I18nModule,
            UrlModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UnitDetailsCellModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        PopoverModule,
                        RouterModule,
                        I18nModule,
                        UrlModule,
                        UnitDetailsCellComponent,
                    ],
                    exports: [UnitDetailsCellComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserGroupDetailsCellModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupDetailsCellModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserGroupDetailsCellModule, imports: [CommonModule,
            PopoverModule,
            RouterModule,
            I18nModule,
            UrlModule,
            UserGroupDetailsCellComponent], exports: [UserGroupDetailsCellComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupDetailsCellModule, imports: [CommonModule,
            PopoverModule,
            RouterModule,
            I18nModule,
            UrlModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserGroupDetailsCellModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        PopoverModule,
                        RouterModule,
                        I18nModule,
                        UrlModule,
                        UserGroupDetailsCellComponent,
                    ],
                    exports: [UserGroupDetailsCellComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserDetailsCellModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserDetailsCellModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: UserDetailsCellModule, imports: [CommonModule,
            PopoverModule,
            RouterModule,
            I18nModule,
            UrlModule,
            UserDetailsCellComponent], exports: [UserDetailsCellComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserDetailsCellModule, imports: [CommonModule,
            PopoverModule,
            RouterModule,
            I18nModule,
            UrlModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: UserDetailsCellModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        PopoverModule,
                        RouterModule,
                        I18nModule,
                        UrlModule,
                        UserDetailsCellComponent,
                    ],
                    exports: [UserDetailsCellComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/** AUGMENTABLE_TYPES_END */

/**
 * Generated bundle index. Do not edit.
 */

export { ActiveLinkCellComponent, AdministrationComponentsModule, AmountCellComponent, AssignCellComponent, BaseMessageComponent, BudgetComponentsModule, BudgetCostCenterListComponent, BudgetCostCenterListModule, BudgetCostCenterListService, BudgetDetailsCellComponent, BudgetDetailsCellModule, BudgetDetailsComponent, BudgetDetailsModule, BudgetFormComponent, BudgetFormModule, BudgetFormService, BudgetItemService, BudgetListService, CardComponent, CardModule, CellComponent, CellModule, ConfirmationMessageComponent, ConfirmationMessageModule, CostCenterAssignedBudgetListComponent, CostCenterAssignedBudgetListService, CostCenterBudgetListComponent, CostCenterBudgetListModule, CostCenterBudgetListService, CostCenterComponentsModule, CostCenterDetailsCellComponent, CostCenterDetailsCellModule, CostCenterDetailsComponent, CostCenterDetailsModule, CostCenterFormComponent, CostCenterFormModule, CostCenterFormService, CostCenterListService, CreateButtonType, CurrentBudgetService, CurrentCostCenterService, CurrentItemService, CurrentPermissionService, CurrentUnitAddressService, CurrentUnitChildService, CurrentUnitService, CurrentUnitUserService, CurrentUserGroupService, CurrentUserService, DateRangeCellComponent, DeleteItemComponent, DeleteItemModule, DisableInfoComponent, DisableInfoModule, DisableInfoService, FormComponent, FormModule, FormService, ItemActiveDirective, ItemExistsDirective, ItemService, LimitCellComponent, LinkCellComponent, ListComponent, ListModule, ListService, MessageComponent, MessageData, MessageModule, MessageRenderService, MessageService, NotificationMessageComponent, NotificationMessageModule, OrganizationTableType, PermissionComponentsModule, PermissionDetailsCellComponent, PermissionDetailsCellModule, PermissionDetailsComponent, PermissionDetailsModule, PermissionFormComponent, PermissionFormModule, PermissionFormService, PermissionItemService, PermissionListService, PermissionType, RolesCellComponent, SharedOrganizationModule, StatusCellComponent, SubListComponent, SubListModule, SubListService, ToggleLinkCellComponent, ToggleStatusComponent, ToggleStatusModule, UnitAddressDetailsComponent, UnitAddressDetailsModule, UnitAddressFormComponent, UnitAddressFormModule, UnitAddressFormService, UnitAddressItemService, UnitAddressListComponent, UnitAddressListModule, UnitAddressListService, UnitAddressModule, UnitApproverListComponent, UnitApproverListModule, UnitApproverListService, UnitAssignedApproverListComponent, UnitAssignedApproverListService, UnitCellComponent, UnitChildCreateComponent, UnitChildCreateModule, UnitChildItemService, UnitChildrenComponent, UnitChildrenModule, UnitChildrenService, UnitCostCenterCreateComponent, UnitCostCenterCreateModule, UnitCostCenterItemService, UnitCostCenterListComponent, UnitCostCenterListModule, UnitCostCenterListService, UnitDetailsCellComponent, UnitDetailsCellModule, UnitDetailsComponent, UnitDetailsModule, UnitFormComponent, UnitFormModule, UnitFormService, UnitItemService, UnitListComponent, UnitListModule, UnitListService, UnitTreeService, UnitUserCreateComponent, UnitUserCreateModule, UnitUserListComponent, UnitUserListModule, UnitUserListService, UnitUserRolesCellComponent, UnitUserRolesFormComponent, UnitUserRolesFormService, UnitUserRolesItemService, UnitUserRolesModule, UnitUsersModule, UnitsComponentsModule, UserApproverListComponent, UserApproverListModule, UserApproverListService, UserAssignedApproverListComponent, UserAssignedApproverListService, UserAssignedPermissionListComponent, UserAssignedPermissionListService, UserAssignedUserGroupListComponent, UserAssignedUserGroupListService, UserChangePasswordFormComponent, UserChangePasswordFormModule, UserChangePasswordFormService, UserComponentsModule, UserDetailsCellComponent, UserDetailsCellModule, UserDetailsComponent, UserDetailsModule, UserFormComponent, UserFormModule, UserFormService, UserGroupAssignedPermissionListComponent, UserGroupAssignedPermissionsListService, UserGroupAssignedUserListComponent, UserGroupAssignedUserListService, UserGroupComponentsModule, UserGroupDetailsCellComponent, UserGroupDetailsCellModule, UserGroupDetailsComponent, UserGroupDetailsModule, UserGroupFormComponent, UserGroupFormModule, UserGroupFormService, UserGroupItemService, UserGroupListService, UserGroupPermissionListComponent, UserGroupPermissionListService, UserGroupPermissionModule, UserGroupUserListComponent, UserGroupUserListService, UserGroupUserModule, UserItemService, UserListService, UserPermissionListComponent, UserPermissionListModule, UserPermissionListService, UserUserGroupListComponent, UserUserGroupListService, UserUserGroupsModule, budgetCmsConfig, budgetTableConfig, budgetTableConfigFactory, costCenterCmsConfig, costCenterTableConfig, costCenterTableConfigFactory, newBudgetTableConfig, newCostCenterTableConfig, newPermissionTableConfig, newUnitsTableConfig, newUserGroupTableConfig, newUserTableConfig, permisionTableConfig, permissionCmsConfig, permissionTableConfigFactory, unitsCmsConfig, unitsTableConfig, unitsTableConfigFactory, userCmsConfig, userGroupCmsConfig, userGroupTableConfig, userGroupTableConfigFactory, userTableConfig, userTableConfigFactory };
//# sourceMappingURL=spartacus-organization-administration-components.mjs.map
