import * as i0 from '@angular/core';
import { Injectable, inject, NgModule } from '@angular/core';
import * as i1 from '@spartacus/core';
import { facadeFactory, HttpErrorHandler, HttpResponseStatus, Priority, GlobalMessageType, RoutingService, AuthGuard, provideDefaultConfigFactory, provideDefaultConfig } from '@spartacus/core';
import { LAUNCH_CALLER, PageLayoutComponent, CmsPageGuard } from '@spartacus/storefront';
import * as i1$1 from '@angular/router';
import { RouterModule } from '@angular/router';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const QUOTE_FEATURE = 'quote';
const QUOTE_CART_GUARD_FEATURE = 'quote_cart_guard';
const QUOTE_REQUEST_FEATURE = 'quote_request';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: QuoteFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: QuoteFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: QuoteFacade,
            feature: QUOTE_FEATURE,
            methods: [
                'getQuotesState',
                'getQuoteDetailsQueryState',
                'getQuoteDetails',
                'createQuote',
                'editQuote',
                'performQuoteAction',
                'addQuoteComment',
                'addDiscount',
            ],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: QuoteFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: QuoteFacade,
                        feature: QUOTE_FEATURE,
                        methods: [
                            'getQuotesState',
                            'getQuoteDetailsQueryState',
                            'getQuoteDetails',
                            'createQuote',
                            'editQuote',
                            'performQuoteAction',
                            'addQuoteComment',
                            'addDiscount',
                        ],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

class QuoteBadRequestHandler extends HttpErrorHandler {
    constructor(globalMessageService) {
        super(globalMessageService);
        this.globalMessageService = globalMessageService;
        this.responseStatus = HttpResponseStatus.BAD_REQUEST;
    }
    hasMatch(errorResponse) {
        return (super.hasMatch(errorResponse) && this.isRelatedToQuotes(errorResponse));
    }
    handleError(_request, response) {
        if (this.isNotEmpty(this.getQuoteThresholdErrors(response))) {
            this.handleQuoteThresholdErrors();
        }
        this.getIllegalArgumentErrorsRelatedToQuote(response).forEach(({ message }) => {
            this.handleIllegalArgumentIssues(message);
        });
        if (this.isNotEmpty(this.getCartValidationErrors(response))) {
            this.handleCartValidationIssues();
        }
        if (this.isNotEmpty(this.getCartQuoteAccessErrors(response))) {
            this.handleCartQuoteAccessErrors();
        }
    }
    getPriority() {
        return Priority.NORMAL;
    }
    isNotEmpty(errors) {
        return errors.length > 0;
    }
    isRelatedToQuotes(response) {
        const isThresHoldError = this.isNotEmpty(this.getQuoteThresholdErrors(response));
        const isCartValidationError = this.isNotEmpty(this.getCartValidationErrors(response));
        const isQuoteAccessError = this.isNotEmpty(this.getCartQuoteAccessErrors(response));
        const isQuoteIllegalArgumentError = this.isNotEmpty(this.getIllegalArgumentErrorsRelatedToQuote(response));
        return (isThresHoldError ||
            isCartValidationError ||
            isQuoteAccessError ||
            isQuoteIllegalArgumentError);
    }
    getQuoteThresholdErrors(response) {
        return (response.error?.errors ?? []).filter((error) => error.type === 'QuoteUnderThresholdError');
    }
    getCartValidationErrors(response) {
        return (response.error?.errors ?? []).filter((error) => error.type === 'CartValidationError');
    }
    getCartQuoteAccessErrors(response) {
        return (response.error?.errors ?? []).filter((error) => error.type === 'CartQuoteAccessError');
    }
    getIllegalArgumentErrorsRelatedToQuote(response) {
        return (response.error?.errors ?? [])
            .filter((error) => error.type === 'IllegalArgumentError')
            .filter((error) => this.isIllegalArgumentErrorRelatedToQuote(error.message));
    }
    isIllegalArgumentErrorRelatedToQuote(message) {
        return (message &&
            (this.isIllegalArgumentErrorRelatedToQuoteDiscount(message) ||
                this.isIllegalArgumentErrorRelatedToQuoteExpiration(message)));
    }
    isIllegalArgumentErrorRelatedToQuoteDiscount(message) {
        const discountMask = /Discount type is absolute/;
        return message.match(discountMask) !== null;
    }
    isIllegalArgumentErrorRelatedToQuoteExpiration(message) {
        const expirationMask = /Invalid quote expiration time/;
        return message.match(expirationMask) !== null;
    }
    handleQuoteThresholdErrors() {
        this.globalMessageService.add({
            key: 'quote.httpHandlers.threshold.underThresholdError',
        }, GlobalMessageType.MSG_TYPE_ERROR);
    }
    handleCartValidationIssues() {
        this.globalMessageService.add({
            key: 'quote.httpHandlers.cartValidationIssue',
        }, GlobalMessageType.MSG_TYPE_ERROR);
    }
    handleCartQuoteAccessErrors() {
        this.globalMessageService.add({
            key: 'quote.httpHandlers.quoteCartIssue',
        }, GlobalMessageType.MSG_TYPE_ERROR);
    }
    handleIllegalArgumentIssues(message) {
        if (this.isIllegalArgumentErrorRelatedToQuoteDiscount(message)) {
            this.globalMessageService.add({
                key: 'quote.httpHandlers.absoluteDiscountIssue',
            }, GlobalMessageType.MSG_TYPE_ERROR);
        }
        if (this.isIllegalArgumentErrorRelatedToQuoteExpiration(message)) {
            this.globalMessageService.add({
                key: 'quote.httpHandlers.expirationDateIssue',
            }, GlobalMessageType.MSG_TYPE_ERROR);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: QuoteBadRequestHandler, deps: [{ token: i1.GlobalMessageService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: QuoteBadRequestHandler, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: QuoteBadRequestHandler, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.GlobalMessageService }] });

class QuoteNotFoundHandler extends HttpErrorHandler {
    constructor(globalMessageService) {
        super(globalMessageService);
        this.globalMessageService = globalMessageService;
        this.routingService = inject(RoutingService);
        this.responseStatus = HttpResponseStatus.NOT_FOUND;
    }
    hasMatch(errorResponse) {
        return (super.hasMatch(errorResponse) &&
            this.getQuoteNotFoundErrors(errorResponse).length > 0);
    }
    handleError(_request) {
        this.navigateToQuoteList();
    }
    getPriority() {
        return Priority.NORMAL;
    }
    /**
     * This situation can happen e.g. if one ends an ASM emulation while viewing a quote and afterwards emulates a session
     * for a different user.
     *
     * @param response - HTTP response
     * @returns Array of error models or empty array if no issues occurred
     */
    getQuoteNotFoundErrors(response) {
        return (response.error?.errors ?? []).filter((error) => error.type === 'NotFoundError' && error.message === 'Quote not found');
    }
    navigateToQuoteList() {
        this.routingService.go({ cxRoute: 'quotes' });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: QuoteNotFoundHandler, deps: [{ token: i1.GlobalMessageService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: QuoteNotFoundHandler, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: QuoteNotFoundHandler, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.GlobalMessageService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
LAUNCH_CALLER['QUOTE_ACTION_CONFIRMATION'] =
    'QUOTE_ACTION_CONFIRMATION';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var QuoteActionType;
(function (QuoteActionType) {
    QuoteActionType["CREATE"] = "CREATE";
    QuoteActionType["VIEW"] = "VIEW";
    QuoteActionType["SUBMIT"] = "SUBMIT";
    QuoteActionType["SAVE"] = "SAVE";
    QuoteActionType["EDIT"] = "EDIT";
    QuoteActionType["DISCOUNT"] = "DISCOUNT";
    QuoteActionType["CANCEL"] = "CANCEL";
    QuoteActionType["CHECKOUT"] = "CHECKOUT";
    QuoteActionType["ORDER"] = "ORDER";
    QuoteActionType["APPROVE"] = "APPROVE";
    QuoteActionType["REJECT"] = "REJECT";
    QuoteActionType["EXPIRED"] = "EXPIRED";
    QuoteActionType["REQUOTE"] = "REQUOTE";
    QuoteActionType["DOWNLOAD_QUOTE_PROPOSAL_DOCUMENT"] = "DOWNLOAD_QUOTE_PROPOSAL_DOCUMENT";
})(QuoteActionType || (QuoteActionType = {}));
var QuoteState;
(function (QuoteState) {
    QuoteState["BUYER_DRAFT"] = "BUYER_DRAFT";
    QuoteState["BUYER_SUBMITTED"] = "BUYER_SUBMITTED";
    QuoteState["BUYER_ACCEPTED"] = "BUYER_ACCEPTED";
    QuoteState["BUYER_APPROVED"] = "BUYER_APPROVED";
    QuoteState["BUYER_REJECTED"] = "BUYER_REJECTED";
    QuoteState["BUYER_OFFER"] = "BUYER_OFFER";
    QuoteState["BUYER_ORDERED"] = "BUYER_ORDERED";
    QuoteState["SELLER_DRAFT"] = "SELLER_DRAFT";
    QuoteState["SELLER_REQUEST"] = "SELLER_REQUEST";
    QuoteState["SELLER_SUBMITTED"] = "SELLER_SUBMITTED";
    QuoteState["SELLERAPPROVER_DRAFT"] = "SELLERAPPROVER_DRAFT";
    QuoteState["SELLERAPPROVER_PENDING"] = "SELLERAPPROVER_PENDING";
    QuoteState["SELLERAPPROVER_APPROVED"] = "SELLERAPPROVER_APPROVED";
    QuoteState["SELLERAPPROVER_REJECTED"] = "SELLERAPPROVER_REJECTED";
    QuoteState["CREATED"] = "CREATED";
    QuoteState["CANCELLED"] = "CANCELLED";
    QuoteState["EXPIRED"] = "EXPIRED";
})(QuoteState || (QuoteState = {}));
var QuoteDiscountType;
(function (QuoteDiscountType) {
    QuoteDiscountType["PERCENT"] = "PERCENT";
    QuoteDiscountType["ABSOLUTE"] = "ABSOLUTE";
})(QuoteDiscountType || (QuoteDiscountType = {}));
var QuoteRoleType;
(function (QuoteRoleType) {
    QuoteRoleType["ALL"] = "ALL";
    QuoteRoleType["BUYER"] = "BUYER";
    QuoteRoleType["SELLER"] = "SELLER";
    QuoteRoleType["SELLERAPPROVER"] = "SELLERAPPROVER";
})(QuoteRoleType || (QuoteRoleType = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
function defaultQuoteComponentsConfig() {
    return {
        featureModules: {
            [QUOTE_FEATURE]: {
                cmsComponents: [
                    'AccountMyQuotesComponent',
                    'QuoteLinksComponent',
                    'QuoteCommentsComponent',
                    'QuoteHeaderOverviewComponent',
                    'QuoteItemsComponent',
                    'QuoteSummaryComponent',
                ],
            },
        },
    };
}
function defaultQuoteCartGuardComponentConfig() {
    return {
        featureModules: {
            [QUOTE_CART_GUARD_FEATURE]: {
                cmsComponents: ['QuoteCartGuardComponent'],
            },
        },
    };
}
function defaultQuoteRequestComponentsConfig() {
    return {
        featureModules: {
            [QUOTE_REQUEST_FEATURE]: {
                cmsComponents: ['QuoteRequestComponent'],
            },
        },
    };
}
const defaultQuoteRoutingConfig = {
    routing: {
        routes: {
            quotes: {
                paths: ['my-account/quotes'],
            },
            quoteDetails: {
                paths: ['my-account/quote/:quoteId'],
                paramsMapping: { quoteId: 'quoteId' },
            },
        },
    },
};
const defaultQuoteConfigLayoutConfig = {
    layoutSlots: {
        QuoteDetailsPageTemplate: {
            slots: ['BodyContent', 'CenterRightContent'],
        },
    },
};
/**
 * The ng route corresponding to the cxRoute 'quotes' is not defined here
 * as it is provided via CMS.
 * For the 'quoteDetails' route we need to provide an additional
 * corresponding ng route because of its parameter
 */
class QuoteRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: QuoteRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.19", ngImport: i0, type: QuoteRootModule, imports: [i1$1.RouterModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: QuoteRootModule, providers: [
            {
                provide: HttpErrorHandler,
                useExisting: QuoteBadRequestHandler,
                multi: true,
            },
            {
                provide: HttpErrorHandler,
                useExisting: QuoteNotFoundHandler,
                multi: true,
            },
            provideDefaultConfigFactory(defaultQuoteComponentsConfig),
            provideDefaultConfigFactory(defaultQuoteCartGuardComponentConfig),
            provideDefaultConfigFactory(defaultQuoteRequestComponentsConfig),
            provideDefaultConfig(defaultQuoteRoutingConfig),
            provideDefaultConfig(defaultQuoteConfigLayoutConfig),
        ], imports: [RouterModule.forChild([
                {
                    // @ts-ignore
                    path: null,
                    canActivate: [AuthGuard, CmsPageGuard],
                    component: PageLayoutComponent,
                    data: {
                        cxRoute: 'quoteDetails',
                    },
                },
            ])] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.19", ngImport: i0, type: QuoteRootModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        RouterModule.forChild([
                            {
                                // @ts-ignore
                                path: null,
                                canActivate: [AuthGuard, CmsPageGuard],
                                component: PageLayoutComponent,
                                data: {
                                    cxRoute: 'quoteDetails',
                                },
                            },
                        ]),
                    ],
                    providers: [
                        {
                            provide: HttpErrorHandler,
                            useExisting: QuoteBadRequestHandler,
                            multi: true,
                        },
                        {
                            provide: HttpErrorHandler,
                            useExisting: QuoteNotFoundHandler,
                            multi: true,
                        },
                        provideDefaultConfigFactory(defaultQuoteComponentsConfig),
                        provideDefaultConfigFactory(defaultQuoteCartGuardComponentConfig),
                        provideDefaultConfigFactory(defaultQuoteRequestComponentsConfig),
                        provideDefaultConfig(defaultQuoteRoutingConfig),
                        provideDefaultConfig(defaultQuoteConfigLayoutConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/** AUGMENTABLE_TYPES_END */

/**
 * Generated bundle index. Do not edit.
 */

export { QUOTE_CART_GUARD_FEATURE, QUOTE_FEATURE, QUOTE_REQUEST_FEATURE, QuoteActionType, QuoteBadRequestHandler, QuoteDiscountType, QuoteFacade, QuoteNotFoundHandler, QuoteRoleType, QuoteRootModule, QuoteState, defaultQuoteCartGuardComponentConfig, defaultQuoteComponentsConfig, defaultQuoteConfigLayoutConfig, defaultQuoteRequestComponentsConfig, defaultQuoteRoutingConfig };
//# sourceMappingURL=spartacus-quote-root.mjs.map
