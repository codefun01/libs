import { NgIf, AsyncPipe, CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { inject, Input, ChangeDetectionStrategy, Component, ViewChild, NgModule } from '@angular/core';
import { TranslatePipe, GlobalMessageService, GlobalMessageType, I18nModule, provideDefaultConfig } from '@spartacus/core';
import { PunchoutUiRestrictionService, PunchoutFacade } from '@spartacus/punchout/root';
import * as i1 from '@angular/forms';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CartItemListComponent, OrderSummaryComponent, CartSharedModule } from '@spartacus/cart/base/components';
import { ICON_TYPE, IconComponent, IconModule } from '@spartacus/storefront';
import { ActiveCartFacade } from '@spartacus/cart/base/root';
import { filter, take, tap, switchMap, timer, map } from 'rxjs';
import { ActivatedRoute } from '@angular/router';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutButtonsComponent {
    constructor() {
        this.removeCancelButton = false;
        this.punchoutUiRestrictionService = inject(PunchoutUiRestrictionService);
        this.punchoutFacade = inject(PunchoutFacade);
        this.isPunchoutSessionActive$ = this.punchoutUiRestrictionService.isPunchoutSessionActive();
    }
    submitRequisition(cancelRequisition = false) {
        this.punchoutFacade.submitRequisition(cancelRequisition);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutButtonsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: PunchoutButtonsComponent, isStandalone: true, selector: "cx-punchout-buttons", inputs: { removeCancelButton: "removeCancelButton" }, ngImport: i0, template: "<ng-container *ngIf=\"(isPunchoutSessionActive$ | async) === true\">\n  <button\n    type=\"button\"\n    class=\"btn btn-block btn-primary\"\n    (click)=\"submitRequisition(false)\"\n  >\n    {{ 'punchout.backToRequisition' | cxTranslate }}\n  </button>\n  <button\n    *ngIf=\"!removeCancelButton\"\n    type=\"button\"\n    class=\"btn btn-block btn-primary\"\n    (click)=\"submitRequisition(true)\"\n  >\n    {{ 'punchout.cancel' | cxTranslate }}\n  </button>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutButtonsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-punchout-buttons', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"(isPunchoutSessionActive$ | async) === true\">\n  <button\n    type=\"button\"\n    class=\"btn btn-block btn-primary\"\n    (click)=\"submitRequisition(false)\"\n  >\n    {{ 'punchout.backToRequisition' | cxTranslate }}\n  </button>\n  <button\n    *ngIf=\"!removeCancelButton\"\n    type=\"button\"\n    class=\"btn btn-block btn-primary\"\n    (click)=\"submitRequisition(true)\"\n  >\n    {{ 'punchout.cancel' | cxTranslate }}\n  </button>\n</ng-container>\n" }]
        }], propDecorators: { removeCancelButton: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutCloseSessionComponent {
    constructor() {
        this.punchoutFacade = inject(PunchoutFacade);
        this.punchoutUiRestrictionService = inject(PunchoutUiRestrictionService);
        this.isPunchoutSessionActive$ = this.punchoutUiRestrictionService.isPunchoutSessionActive();
    }
    clickCloseSessionButton() {
        this.punchoutFacade.closePunchoutSession().subscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutCloseSessionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: PunchoutCloseSessionComponent, isStandalone: true, selector: "cx-punchout-close-session", ngImport: i0, template: "<ng-container *ngIf=\"(isPunchoutSessionActive$ | async) === true\">\n  <div class=\"cx-punchout-close-session\" (click)=\"clickCloseSessionButton()\">\n    {{ 'punchout.closeSession' | cxTranslate }}\n  </div>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutCloseSessionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-punchout-close-session', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"(isPunchoutSessionActive$ | async) === true\">\n  <div class=\"cx-punchout-close-session\" (click)=\"clickCloseSessionButton()\">\n    {{ 'punchout.closeSession' | cxTranslate }}\n  </div>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutErrorComponent {
    constructor() {
        this.iconTypes = ICON_TYPE;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutErrorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: PunchoutErrorComponent, isStandalone: true, selector: "cx-punchout-error", ngImport: i0, template: "<div class=\"alert\">\n  <span class=\"alert-icon\">\n    <cx-icon [type]=\"iconTypes.ERROR\" />\n  </span>\n  {{ 'punchout.error' | cxTranslate }}\n</div>\n", dependencies: [{ kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutErrorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-punchout-error', imports: [IconComponent, TranslatePipe], template: "<div class=\"alert\">\n  <span class=\"alert-icon\">\n    <cx-icon [type]=\"iconTypes.ERROR\" />\n  </span>\n  {{ 'punchout.error' | cxTranslate }}\n</div>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutInspectCartComponent {
    constructor() {
        this.activeCartService = inject(ActiveCartFacade);
        this.punchoutComponentsService = inject(PunchoutUiRestrictionService);
        this.isPunchoutSessionActive$ = this.punchoutComponentsService.isPunchoutSessionActive();
        this.cart$ = this.activeCartService.getActive();
        this.entries$ = this.activeCartService
            .getEntries()
            .pipe(filter((entries) => entries.length > 0));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutInspectCartComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: PunchoutInspectCartComponent, isStandalone: true, selector: "cx-punchout-inspect-cart", ngImport: i0, template: "<ng-container *ngIf=\"isPunchoutSessionActive$ | async\">\n  <ng-container *ngIf=\"cart$ | async as cart\">\n    <ng-container *ngIf=\"entries$ | async as entries\">\n      <div class=\"punchoutStartSection\">\n        <cx-cart-item-list\n          [readonly]=\"true\"\n          [items]=\"entries\"\n          [options]=\"{\n            isSaveForLater: false,\n            disableItemLink: true,\n          }\"\n        />\n      </div>\n      <div class=\"punchoutEndSection\">\n        <cx-order-summary [cart]=\"cart\" />\n\n        <cx-punchout-buttons [removeCancelButton]=\"true\" />\n      </div>\n    </ng-container>\n  </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CartItemListComponent, selector: "cx-cart-item-list", inputs: ["readonly", "hasHeader", "options", "cartId", "items", "promotionLocation", "cartIsLoading"] }, { kind: "component", type: OrderSummaryComponent, selector: "cx-order-summary", inputs: ["cart"] }, { kind: "component", type: PunchoutButtonsComponent, selector: "cx-punchout-buttons", inputs: ["removeCancelButton"] }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutInspectCartComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-punchout-inspect-cart', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        CartItemListComponent,
                        OrderSummaryComponent,
                        PunchoutButtonsComponent,
                        AsyncPipe,
                    ], template: "<ng-container *ngIf=\"isPunchoutSessionActive$ | async\">\n  <ng-container *ngIf=\"cart$ | async as cart\">\n    <ng-container *ngIf=\"entries$ | async as entries\">\n      <div class=\"punchoutStartSection\">\n        <cx-cart-item-list\n          [readonly]=\"true\"\n          [items]=\"entries\"\n          [options]=\"{\n            isSaveForLater: false,\n            disableItemLink: true,\n          }\"\n        />\n      </div>\n      <div class=\"punchoutEndSection\">\n        <cx-order-summary [cart]=\"cart\" />\n\n        <cx-punchout-buttons [removeCancelButton]=\"true\" />\n      </div>\n    </ng-container>\n  </ng-container>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutRequisitionComponent {
    constructor() {
        this.punchoutFacade = inject(PunchoutFacade);
        this.formBuilder = inject(FormBuilder);
        this.FORM_CONTROL_NAME = {
            ORDER: 'order',
        };
        this.punchoutRequisition$ = this.punchoutFacade.getPunchoutSessionRequisition().pipe(take(1), tap((punchoutRequisition) => {
            this.listenAndSubmitForm(punchoutRequisition).subscribe({
                next: () => {
                    this.punchoutFormElement.nativeElement.submit();
                },
                error: () => {
                    this.punchoutFacade.endPunchoutSession();
                },
            });
            this.punchoutFormGroup.setValue({
                [this.FORM_CONTROL_NAME.ORDER]: punchoutRequisition?.orderAsCXML,
            });
        }));
    }
    ngOnInit() {
        this.punchoutFormGroup = this.formBuilder.group({
            [this.FORM_CONTROL_NAME.ORDER]: [''],
        });
    }
    listenAndSubmitForm(req) {
        return this.punchoutFormGroup.controls[this.FORM_CONTROL_NAME.ORDER].valueChanges.pipe(filter((value) => value === req?.orderAsCXML), take(1), switchMap(() => {
            return this.isFormNativeElementAccessible();
        }), switchMap(() => {
            return this.punchoutFacade.logoutPunchoutUser();
        }), take(1));
    }
    isFormNativeElementAccessible() {
        // timer(0) wait for next Javascript event loop, this way DOM native elements becomes accessible.
        return timer(0).pipe(map(() => {
            if (!this.punchoutFormElement?.nativeElement) {
                throw new Error('Form native element not accessible');
            }
            else {
                return true;
            }
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutRequisitionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: PunchoutRequisitionComponent, isStandalone: true, selector: "cx-punchout-requsition", viewQueries: [{ propertyName: "punchoutFormElement", first: true, predicate: ["punchoutFormElement"], descendants: true }], ngImport: i0, template: "<ng-container *ngIf=\"punchoutRequisition$ | async as pchtReq\">\n  <form\n    *ngIf=\"pchtReq?.orderAsCXML && pchtReq?.browseFormPostUrl\"\n    action=\"{{ pchtReq.browseFormPostUrl }}\"\n    method=\"POST\"\n    [formGroup]=\"punchoutFormGroup\"\n    #punchoutFormElement\n  >\n    <input\n      name=\"cxml-base64\"\n      formControlName=\"{{ FORM_CONTROL_NAME.ORDER }}\"\n      type=\"hidden\"\n      value=\"\"\n    />\n  </form>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutRequisitionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-punchout-requsition', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, FormsModule, ReactiveFormsModule, AsyncPipe], template: "<ng-container *ngIf=\"punchoutRequisition$ | async as pchtReq\">\n  <form\n    *ngIf=\"pchtReq?.orderAsCXML && pchtReq?.browseFormPostUrl\"\n    action=\"{{ pchtReq.browseFormPostUrl }}\"\n    method=\"POST\"\n    [formGroup]=\"punchoutFormGroup\"\n    #punchoutFormElement\n  >\n    <input\n      name=\"cxml-base64\"\n      formControlName=\"{{ FORM_CONTROL_NAME.ORDER }}\"\n      type=\"hidden\"\n      value=\"\"\n    />\n  </form>\n</ng-container>\n" }]
        }], propDecorators: { punchoutFormElement: [{
                type: ViewChild,
                args: ['punchoutFormElement']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutSessionComponent {
    constructor() {
        this.activatedRoute = inject(ActivatedRoute);
        this.punchoutFacade = inject(PunchoutFacade);
        this.globalMessageService = inject(GlobalMessageService);
        this.PUNCHOUT_SESSION_KEY = 'sid';
    }
    ngOnInit() {
        this.activatedRoute.queryParams
            .pipe(take(1), switchMap((params) => {
            this.globalMessageService.add({
                key: 'punchout.initiatingUserSession',
            }, GlobalMessageType.MSG_TYPE_INFO);
            return this.punchoutFacade.initPunchoutSession({
                punchoutSessionId: params?.[this.PUNCHOUT_SESSION_KEY],
            });
        }), take(1))
            .subscribe({
            complete: () => {
                this.globalMessageService.remove(GlobalMessageType.MSG_TYPE_INFO);
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutSessionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: PunchoutSessionComponent, isStandalone: true, selector: "cx-punchout-session", ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutSessionComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'cx-punchout-session',
                    template: '',
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class PunchoutComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: PunchoutComponentsModule, imports: [CommonModule,
            ReactiveFormsModule,
            I18nModule,
            CartSharedModule,
            IconModule,
            PunchoutSessionComponent,
            PunchoutErrorComponent,
            PunchoutRequisitionComponent,
            PunchoutButtonsComponent,
            PunchoutCloseSessionComponent,
            PunchoutInspectCartComponent], exports: [PunchoutSessionComponent,
            PunchoutErrorComponent,
            PunchoutRequisitionComponent,
            PunchoutButtonsComponent,
            PunchoutCloseSessionComponent,
            PunchoutInspectCartComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutComponentsModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    PunchoutSessionComponent: {
                        component: PunchoutSessionComponent,
                    },
                    PunchoutErrorComponent: {
                        component: PunchoutErrorComponent,
                    },
                    PunchoutButtonsComponent: {
                        component: PunchoutButtonsComponent,
                    },
                    PunchoutRequisitionComponent: {
                        component: PunchoutRequisitionComponent,
                    },
                    PunchoutCloseSessionComponent: {
                        component: PunchoutCloseSessionComponent,
                    },
                    PunchoutInspectCartComponent: {
                        component: PunchoutInspectCartComponent,
                    },
                },
            }),
        ], imports: [CommonModule,
            ReactiveFormsModule,
            I18nModule,
            CartSharedModule,
            IconModule,
            PunchoutErrorComponent,
            PunchoutRequisitionComponent,
            PunchoutInspectCartComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: PunchoutComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    exports: [
                        PunchoutSessionComponent,
                        PunchoutErrorComponent,
                        PunchoutRequisitionComponent,
                        PunchoutButtonsComponent,
                        PunchoutCloseSessionComponent,
                        PunchoutInspectCartComponent,
                    ],
                    imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        I18nModule,
                        CartSharedModule,
                        IconModule,
                        PunchoutSessionComponent,
                        PunchoutErrorComponent,
                        PunchoutRequisitionComponent,
                        PunchoutButtonsComponent,
                        PunchoutCloseSessionComponent,
                        PunchoutInspectCartComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                PunchoutSessionComponent: {
                                    component: PunchoutSessionComponent,
                                },
                                PunchoutErrorComponent: {
                                    component: PunchoutErrorComponent,
                                },
                                PunchoutButtonsComponent: {
                                    component: PunchoutButtonsComponent,
                                },
                                PunchoutRequisitionComponent: {
                                    component: PunchoutRequisitionComponent,
                                },
                                PunchoutCloseSessionComponent: {
                                    component: PunchoutCloseSessionComponent,
                                },
                                PunchoutInspectCartComponent: {
                                    component: PunchoutInspectCartComponent,
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { PunchoutButtonsComponent, PunchoutCloseSessionComponent, PunchoutComponentsModule, PunchoutErrorComponent, PunchoutInspectCartComponent, PunchoutRequisitionComponent, PunchoutSessionComponent };
//# sourceMappingURL=spartacus-punchout-components.mjs.map
