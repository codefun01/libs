import * as i0 from '@angular/core';
import { InjectionToken, OnDestroy } from '@angular/core';
import { Converter, HttpErrorHandler, HttpResponseStatus, ErrorModel, Priority, RoutingService, UserIdService } from '@spartacus/core';
import { OrderInvoiceList, InvoiceQueryParams, PDFInvoicesFacade } from '@spartacus/pdf-invoices/root';
import { Observable, Subscription } from 'rxjs';
import { HttpErrorResponse, HttpRequest } from '@angular/common/http';

declare const PDF_INVOICES_LIST_INVOICES_NORMALIZER: InjectionToken<Converter<any, OrderInvoiceList>>;

declare abstract class PDFInvoicesAdapter {
    /**
     * Abstract method used to get the PDF invoices for an order
     * @param userId Logged in user id
     * @param orderId If provided, it will be used, otherwise it will use orderId from router state.
     * @param queryParams Additional query parameters used in the API request
     */
    abstract getInvoicesForOrder(userId: string, orderId: string, queryParams: InvoiceQueryParams): Observable<OrderInvoiceList>;
    /**
     * Returns the document blob for given invoiceId, orderId and externalSystemId
     * @param userId Logged in user id
     * @param orderId If provided, it will be used, otherwise it will use orderId from router state.
     * @param invoiceId The id of the invoice to be downloaded
     * @param externalSystemId External system that provides the invoice PDF
     */
    abstract getInvoicePDF(userId: string, orderId: string, invoiceId: string, externalSystemId?: string): Observable<Blob>;
}

declare class PDFInvoicesConnector {
    protected adapter: PDFInvoicesAdapter;
    constructor(adapter: PDFInvoicesAdapter);
    getInvoicesForOrder(userId: string, orderId: string, queryParams: InvoiceQueryParams): Observable<OrderInvoiceList>;
    getInvoicePDF(userId: string, orderId: string, invoiceId: string, externalSystemId?: string): Observable<Blob>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PDFInvoicesConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PDFInvoicesConnector>;
}

declare class PDFInvoicesBadRequestHandler extends HttpErrorHandler {
    responseStatus: HttpResponseStatus;
    hasMatch(errorResponse: HttpErrorResponse): boolean;
    handleError(request: HttpRequest<any>, response: HttpErrorResponse): void;
    protected handleInvoicesListError(_request: HttpRequest<any>, response: HttpErrorResponse): void;
    protected handlePDFDownloadError(_request: HttpRequest<any>, response: HttpErrorResponse): void;
    protected isInvoicesListNotFoundError(error: ErrorModel): boolean;
    protected isDownloadInvoiceError(error: ErrorModel): boolean;
    protected getErrors(response: HttpErrorResponse): ErrorModel[];
    getPriority(): Priority;
    static ɵfac: i0.ɵɵFactoryDeclaration<PDFInvoicesBadRequestHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PDFInvoicesBadRequestHandler>;
}

declare class PDFInvoicesCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PDFInvoicesCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PDFInvoicesCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PDFInvoicesCoreModule>;
}

declare class PDFInvoicesService implements PDFInvoicesFacade, OnDestroy {
    private routingService;
    private userIdService;
    protected pdfInvoicesConnector: PDFInvoicesConnector;
    protected subscriptions: Subscription;
    userId: string;
    orderId: string;
    constructor(routingService: RoutingService, userIdService: UserIdService, pdfInvoicesConnector: PDFInvoicesConnector);
    getInvoicesForOrder(queryParams: InvoiceQueryParams, userId?: string, orderId?: string): Observable<OrderInvoiceList>;
    getInvoicePDF(invoiceId: string, externalSystemId?: string, userId?: string, orderId?: string): Observable<Blob>;
    protected getOrderId(): Observable<string>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PDFInvoicesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PDFInvoicesService>;
}

export { PDFInvoicesAdapter, PDFInvoicesBadRequestHandler, PDFInvoicesConnector, PDFInvoicesCoreModule, PDFInvoicesService, PDF_INVOICES_LIST_INVOICES_NORMALIZER };
