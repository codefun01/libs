import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import { CmsConfig } from '@spartacus/core';

interface Amount {
    currencyIso?: string;
    value?: number;
    formattedValue?: string;
}
declare enum InvoicesFields {
    BASIC = "BASIC",
    DEFAULT = "DEFAULT",
    FULL = "FULL"
}
interface OrderInvoice {
    invoiceId: string;
    externalSystemId?: string;
    createdAt: Date;
    netAmount: Amount;
    totalAmount: Amount;
}
interface OrderInvoiceList {
    invoices?: OrderInvoice[];
    pagination?: Pagination;
    sorts?: Sort[];
}
interface InvoiceQueryParams {
    currentPage?: number;
    pageSize?: number;
    sort?: string;
    fields?: InvoicesFields;
}
interface Sort {
    asc?: boolean;
    code?: string;
}
interface Pagination {
    count?: number;
    page?: number;
    totalCount?: number;
    totalPages?: number;
}

declare function pdfInvoicesFacadeFactory(): PDFInvoicesFacade;
declare abstract class PDFInvoicesFacade {
    /**
     * Abstract method used to get the PDF invoices for an order
     * @param userId Logged in user id
     * @param orderId If provided, it will be used, otherwise it will use orderId from router state.
     * @param queryParams Additional query parameters used in the API request
     */
    abstract getInvoicesForOrder(queryParams: InvoiceQueryParams, userId?: string, orderId?: string): Observable<OrderInvoiceList>;
    /**
     * Returns the document blob for given invoiceId, orderId and externalSystemId
     * @param userId Logged in user id
     * @param orderId If provided, it will be used, otherwise it will use orderId from router state.
     * @param invoiceId The id of the invoice to be downloaded
     * @param externalSystemId External system that provides the invoice PDF
     */
    abstract getInvoicePDF(invoiceId: string, externalSystemId?: string, userId?: string, orderId?: string): Observable<Blob>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PDFInvoicesFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PDFInvoicesFacade>;
}

declare const PDF_INVOICES_FEATURE = "pdfInvoices";
declare const PDF_INVOICES_CORE_FEATURE = "pdfInvoicesCore";

declare function defaultRequestedDeliveryDateComponentsConfig(): CmsConfig;
declare class PDFInvoicesRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PDFInvoicesRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PDFInvoicesRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PDFInvoicesRootModule>;
}

export { InvoicesFields, PDFInvoicesFacade, PDFInvoicesRootModule, PDF_INVOICES_CORE_FEATURE, PDF_INVOICES_FEATURE, defaultRequestedDeliveryDateComponentsConfig, pdfInvoicesFacadeFactory };
export type { InvoiceQueryParams, OrderInvoice, OrderInvoiceList };
