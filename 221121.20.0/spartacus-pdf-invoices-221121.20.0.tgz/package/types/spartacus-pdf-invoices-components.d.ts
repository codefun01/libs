import * as i0 from '@angular/core';
import { OnInit, OnDestroy } from '@angular/core';
import * as i3 from '@spartacus/core';
import { TranslationService, LanguageService, GlobalMessageService, SortModel, PaginationModel, HttpErrorModel, ErrorModel } from '@spartacus/core';
import { PDFInvoicesFacade, InvoiceQueryParams, OrderInvoiceList } from '@spartacus/pdf-invoices/root';
import * as i2 from '@spartacus/storefront';
import { FileDownloadService, ICON_TYPE } from '@spartacus/storefront';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
import * as i1 from '@angular/common';
import * as i4 from '@angular/forms';

declare class InvoicesListComponent implements OnInit, OnDestroy {
    protected pdfInvoicesFacade: PDFInvoicesFacade;
    protected translationService: TranslationService;
    protected downloadService: FileDownloadService;
    protected languageService: LanguageService;
    protected globalMessageService: GlobalMessageService;
    ICON_TYPE: typeof ICON_TYPE;
    protected PAGE_SIZE: number;
    sortOptions: SortModel[];
    sort: string;
    protected sortMapping: {
        [key: string]: string;
    };
    pagination: PaginationModel;
    _initQueryParams: InvoiceQueryParams;
    queryParams$: BehaviorSubject<InvoiceQueryParams>;
    invoicesList$: Observable<OrderInvoiceList>;
    protected subscription: Subscription;
    constructor(pdfInvoicesFacade: PDFInvoicesFacade, translationService: TranslationService, downloadService: FileDownloadService, languageService: LanguageService, globalMessageService: GlobalMessageService);
    ngOnInit(): void;
    protected updateQueryParams(partialParams: InvoiceQueryParams): void;
    pageChange(currentPage: number): void;
    sortChange(sortCode: string): void;
    downloadPDFInvoice(invoiceId: string, externalSystemId?: string): void;
    getSortOptions(): void;
    getNotEnabledError(response: HttpErrorModel): ErrorModel[];
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InvoicesListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InvoicesListComponent, "cx-invoices-list", never, {}, {}, never, never, true, never>;
}

declare class PDFInvoicesComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PDFInvoicesComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PDFInvoicesComponentsModule, never, [typeof i1.CommonModule, typeof i2.DatePickerModule, typeof i3.I18nModule, typeof i4.ReactiveFormsModule, typeof i2.ListNavigationModule, typeof i3.UrlModule, typeof i2.IconModule, typeof i2.MediaModule, typeof i2.SpinnerModule, typeof i3.FeaturesConfigModule, typeof InvoicesListComponent], [typeof InvoicesListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PDFInvoicesComponentsModule>;
}

export { InvoicesListComponent, PDFInvoicesComponentsModule };
