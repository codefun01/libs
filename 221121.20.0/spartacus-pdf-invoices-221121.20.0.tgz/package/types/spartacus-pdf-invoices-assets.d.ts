import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    pdfInvoices: {
        pdfInvoices: {
            featureNotEnabled: string;
            invoicesLoadingError: string;
            invoicesTable: {
                header: string;
                label: string;
                invoiceId: string;
                createdAt: string;
                netAmount: string;
                totalAmount: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            downloadPDFError: string;
            sortBy: string;
            sortInvoices: string;
            sorts: {
                byCreatedAtAsc: string;
                byCreatedAtDesc: string;
                byInvoiceIdAsc: string;
                byInvoiceIdDesc: string;
                byNetAmountAsc: string;
                byNetAmountDesc: string;
                byTotalAmountAsc: string;
                byTotalAmountDesc: string;
            };
        };
    };
};

declare const de: {
    pdfInvoices: {
        pdfInvoices: {
            featureNotEnabled: string;
            invoicesLoadingError: string;
            invoicesTable: {
                header: string;
                label: string;
                invoiceId: string;
                createdAt: string;
                netAmount: string;
                totalAmount: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            downloadPDFError: string;
            sortBy: string;
            sortInvoices: string;
            sorts: {
                byCreatedAtAsc: string;
                byCreatedAtDesc: string;
                byInvoiceIdAsc: string;
                byInvoiceIdDesc: string;
                byNetAmountAsc: string;
                byNetAmountDesc: string;
                byTotalAmountAsc: string;
                byTotalAmountDesc: string;
            };
        };
    };
};

declare const en: {
    pdfInvoices: {
        pdfInvoices: {
            featureNotEnabled: string;
            invoicesLoadingError: string;
            invoicesTable: {
                header: string;
                label: string;
                invoiceId: string;
                createdAt: string;
                netAmount: string;
                totalAmount: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            downloadPDFError: string;
            sortBy: string;
            sortInvoices: string;
            sorts: {
                byCreatedAtAsc: string;
                byCreatedAtDesc: string;
                byInvoiceIdAsc: string;
                byInvoiceIdDesc: string;
                byNetAmountAsc: string;
                byNetAmountDesc: string;
                byTotalAmountAsc: string;
                byTotalAmountDesc: string;
            };
        };
    };
};

declare const es: {
    pdfInvoices: {
        pdfInvoices: {
            featureNotEnabled: string;
            invoicesLoadingError: string;
            invoicesTable: {
                header: string;
                label: string;
                invoiceId: string;
                createdAt: string;
                netAmount: string;
                totalAmount: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            downloadPDFError: string;
            sortBy: string;
            sortInvoices: string;
            sorts: {
                byCreatedAtAsc: string;
                byCreatedAtDesc: string;
                byInvoiceIdAsc: string;
                byInvoiceIdDesc: string;
                byNetAmountAsc: string;
                byNetAmountDesc: string;
                byTotalAmountAsc: string;
                byTotalAmountDesc: string;
            };
        };
    };
};

declare const es_CO: {
    pdfInvoices: {
        pdfInvoices: {
            featureNotEnabled: string;
            invoicesLoadingError: string;
            invoicesTable: {
                header: string;
                label: string;
                invoiceId: string;
                createdAt: string;
                netAmount: string;
                totalAmount: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            downloadPDFError: string;
            sortBy: string;
            sortInvoices: string;
            sorts: {
                byCreatedAtAsc: string;
                byCreatedAtDesc: string;
                byInvoiceIdAsc: string;
                byInvoiceIdDesc: string;
                byNetAmountAsc: string;
                byNetAmountDesc: string;
                byTotalAmountAsc: string;
                byTotalAmountDesc: string;
            };
        };
    };
};

declare const fr: {
    pdfInvoices: {
        pdfInvoices: {
            featureNotEnabled: string;
            invoicesLoadingError: string;
            invoicesTable: {
                header: string;
                label: string;
                invoiceId: string;
                createdAt: string;
                netAmount: string;
                totalAmount: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            downloadPDFError: string;
            sortBy: string;
            sortInvoices: string;
            sorts: {
                byCreatedAtAsc: string;
                byCreatedAtDesc: string;
                byInvoiceIdAsc: string;
                byInvoiceIdDesc: string;
                byNetAmountAsc: string;
                byNetAmountDesc: string;
                byTotalAmountAsc: string;
                byTotalAmountDesc: string;
            };
        };
    };
};

declare const hi: {
    pdfInvoices: {
        pdfInvoices: {
            featureNotEnabled: string;
            invoicesLoadingError: string;
            invoicesTable: {
                header: string;
                label: string;
                invoiceId: string;
                createdAt: string;
                netAmount: string;
                totalAmount: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            downloadPDFError: string;
            sortBy: string;
            sortInvoices: string;
            sorts: {
                byCreatedAtAsc: string;
                byCreatedAtDesc: string;
                byInvoiceIdAsc: string;
                byInvoiceIdDesc: string;
                byNetAmountAsc: string;
                byNetAmountDesc: string;
                byTotalAmountAsc: string;
                byTotalAmountDesc: string;
            };
        };
    };
};

declare const hu: {
    pdfInvoices: {
        pdfInvoices: {
            featureNotEnabled: string;
            invoicesLoadingError: string;
            invoicesTable: {
                header: string;
                label: string;
                invoiceId: string;
                createdAt: string;
                netAmount: string;
                totalAmount: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            downloadPDFError: string;
            sortBy: string;
            sortInvoices: string;
            sorts: {
                byCreatedAtAsc: string;
                byCreatedAtDesc: string;
                byInvoiceIdAsc: string;
                byInvoiceIdDesc: string;
                byNetAmountAsc: string;
                byNetAmountDesc: string;
                byTotalAmountAsc: string;
                byTotalAmountDesc: string;
            };
        };
    };
};

declare const id: {
    pdfInvoices: {
        pdfInvoices: {
            featureNotEnabled: string;
            invoicesLoadingError: string;
            invoicesTable: {
                header: string;
                label: string;
                invoiceId: string;
                createdAt: string;
                netAmount: string;
                totalAmount: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            downloadPDFError: string;
            sortBy: string;
            sortInvoices: string;
            sorts: {
                byCreatedAtAsc: string;
                byCreatedAtDesc: string;
                byInvoiceIdAsc: string;
                byInvoiceIdDesc: string;
                byNetAmountAsc: string;
                byNetAmountDesc: string;
                byTotalAmountAsc: string;
                byTotalAmountDesc: string;
            };
        };
    };
};

declare const it: {
    pdfInvoices: {
        pdfInvoices: {
            featureNotEnabled: string;
            invoicesLoadingError: string;
            invoicesTable: {
                header: string;
                label: string;
                invoiceId: string;
                createdAt: string;
                netAmount: string;
                totalAmount: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            downloadPDFError: string;
            sortBy: string;
            sortInvoices: string;
            sorts: {
                byCreatedAtAsc: string;
                byCreatedAtDesc: string;
                byInvoiceIdAsc: string;
                byInvoiceIdDesc: string;
                byNetAmountAsc: string;
                byNetAmountDesc: string;
                byTotalAmountAsc: string;
                byTotalAmountDesc: string;
            };
        };
    };
};

declare const ja: {
    pdfInvoices: {
        pdfInvoices: {
            featureNotEnabled: string;
            invoicesLoadingError: string;
            invoicesTable: {
                header: string;
                label: string;
                invoiceId: string;
                createdAt: string;
                netAmount: string;
                totalAmount: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            downloadPDFError: string;
            sortBy: string;
            sortInvoices: string;
            sorts: {
                byCreatedAtAsc: string;
                byCreatedAtDesc: string;
                byInvoiceIdAsc: string;
                byInvoiceIdDesc: string;
                byNetAmountAsc: string;
                byNetAmountDesc: string;
                byTotalAmountAsc: string;
                byTotalAmountDesc: string;
            };
        };
    };
};

declare const ko: {
    pdfInvoices: {
        pdfInvoices: {
            featureNotEnabled: string;
            invoicesLoadingError: string;
            invoicesTable: {
                header: string;
                label: string;
                invoiceId: string;
                createdAt: string;
                netAmount: string;
                totalAmount: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            downloadPDFError: string;
            sortBy: string;
            sortInvoices: string;
            sorts: {
                byCreatedAtAsc: string;
                byCreatedAtDesc: string;
                byInvoiceIdAsc: string;
                byInvoiceIdDesc: string;
                byNetAmountAsc: string;
                byNetAmountDesc: string;
                byTotalAmountAsc: string;
                byTotalAmountDesc: string;
            };
        };
    };
};

declare const pl: {
    pdfInvoices: {
        pdfInvoices: {
            featureNotEnabled: string;
            invoicesLoadingError: string;
            invoicesTable: {
                header: string;
                label: string;
                invoiceId: string;
                createdAt: string;
                netAmount: string;
                totalAmount: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            downloadPDFError: string;
            sortBy: string;
            sortInvoices: string;
            sorts: {
                byCreatedAtAsc: string;
                byCreatedAtDesc: string;
                byInvoiceIdAsc: string;
                byInvoiceIdDesc: string;
                byNetAmountAsc: string;
                byNetAmountDesc: string;
                byTotalAmountAsc: string;
                byTotalAmountDesc: string;
            };
        };
    };
};

declare const pt: {
    pdfInvoices: {
        pdfInvoices: {
            featureNotEnabled: string;
            invoicesLoadingError: string;
            invoicesTable: {
                header: string;
                label: string;
                invoiceId: string;
                createdAt: string;
                netAmount: string;
                totalAmount: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            downloadPDFError: string;
            sortBy: string;
            sortInvoices: string;
            sorts: {
                byCreatedAtAsc: string;
                byCreatedAtDesc: string;
                byInvoiceIdAsc: string;
                byInvoiceIdDesc: string;
                byNetAmountAsc: string;
                byNetAmountDesc: string;
                byTotalAmountAsc: string;
                byTotalAmountDesc: string;
            };
        };
    };
};

declare const ru: {
    pdfInvoices: {
        pdfInvoices: {
            featureNotEnabled: string;
            invoicesLoadingError: string;
            invoicesTable: {
                header: string;
                label: string;
                invoiceId: string;
                createdAt: string;
                netAmount: string;
                totalAmount: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            downloadPDFError: string;
            sortBy: string;
            sortInvoices: string;
            sorts: {
                byCreatedAtAsc: string;
                byCreatedAtDesc: string;
                byInvoiceIdAsc: string;
                byInvoiceIdDesc: string;
                byNetAmountAsc: string;
                byNetAmountDesc: string;
                byTotalAmountAsc: string;
                byTotalAmountDesc: string;
            };
        };
    };
};

declare const zh: {
    pdfInvoices: {
        pdfInvoices: {
            featureNotEnabled: string;
            invoicesLoadingError: string;
            invoicesTable: {
                header: string;
                label: string;
                invoiceId: string;
                createdAt: string;
                netAmount: string;
                totalAmount: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            downloadPDFError: string;
            sortBy: string;
            sortInvoices: string;
            sorts: {
                byCreatedAtAsc: string;
                byCreatedAtDesc: string;
                byInvoiceIdAsc: string;
                byInvoiceIdDesc: string;
                byNetAmountAsc: string;
                byNetAmountDesc: string;
                byTotalAmountAsc: string;
                byTotalAmountDesc: string;
            };
        };
    };
};

declare const zh_TW: {
    pdfInvoices: {
        pdfInvoices: {
            featureNotEnabled: string;
            invoicesLoadingError: string;
            invoicesTable: {
                header: string;
                label: string;
                invoiceId: string;
                createdAt: string;
                netAmount: string;
                totalAmount: string;
                attachment: string;
                download: string;
                attachmentDescription: string;
                noneFound: string;
            };
            downloadPDFError: string;
            sortBy: string;
            sortInvoices: string;
            sorts: {
                byCreatedAtAsc: string;
                byCreatedAtDesc: string;
                byInvoiceIdAsc: string;
                byInvoiceIdDesc: string;
                byNetAmountAsc: string;
                byNetAmountDesc: string;
                byTotalAmountAsc: string;
                byTotalAmountDesc: string;
            };
        };
    };
};

declare const pdfInvoicesTranslationChunksConfig: TranslationChunksConfig;

export { pdfInvoicesTranslationChunksConfig, cs as pdfInvoicesTranslationsCs, de as pdfInvoicesTranslationsDe, en as pdfInvoicesTranslationsEn, es as pdfInvoicesTranslationsEs, es_CO as pdfInvoicesTranslationsEs_CO, fr as pdfInvoicesTranslationsFr, hi as pdfInvoicesTranslationsHi, hu as pdfInvoicesTranslationsHu, id as pdfInvoicesTranslationsId, it as pdfInvoicesTranslationsIt, ja as pdfInvoicesTranslationsJa, ko as pdfInvoicesTranslationsKo, pl as pdfInvoicesTranslationsPl, pt as pdfInvoicesTranslationsPt, ru as pdfInvoicesTranslationsRu, zh as pdfInvoicesTranslationsZh, zh_TW as pdfInvoicesTranslationsZh_TW };
