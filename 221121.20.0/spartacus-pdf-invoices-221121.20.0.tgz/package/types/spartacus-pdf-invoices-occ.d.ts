import { HttpClient } from '@angular/common/http';
import { OccEndpointsService, ConverterService, LoggerService, OccEndpoint } from '@spartacus/core';
import { PDFInvoicesAdapter } from '@spartacus/pdf-invoices/core';
import { InvoiceQueryParams, OrderInvoiceList } from '@spartacus/pdf-invoices/root';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare class OccPDFInvoicesAdapter implements PDFInvoicesAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    getInvoicesForOrder(userId: string, orderId: string, queryParams: InvoiceQueryParams): Observable<OrderInvoiceList>;
    getInvoicePDF(userId: string, orderId: string, invoiceId: string, externalSystemId?: string): Observable<Blob>;
    private buildInvoiceListUrl;
    private buildInvoicePDFUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccPDFInvoicesAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccPDFInvoicesAdapter>;
}

declare module '@spartacus/core' {
    interface OccEndpoints {
        /**
         * Get the list of invoices for an order
         *
         * @member {string} [pdfInvoicesListInvoices]
         */
        pdfInvoicesListInvoices?: string | OccEndpoint;
        /**
         * Get the invoice document as a PDF file
         *
         * @member {string} [pdfInvoicesDownloadInvoicePDF]
         */
        pdfInvoicesDownloadInvoicePDF?: string | OccEndpoint;
    }
}

declare class PDFInvoicesOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PDFInvoicesOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PDFInvoicesOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PDFInvoicesOccModule>;
}

export { OccPDFInvoicesAdapter, PDFInvoicesOccModule };
