import { CmsConfig } from '@spartacus/core';
import * as i0 from '@angular/core';

declare const QUALTRICS_FEATURE = "qualtrics";

declare function defaultQualtricsComponentsConfig(): CmsConfig;
declare class QualtricsRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QualtricsRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QualtricsRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QualtricsRootModule>;
}

export { QUALTRICS_FEATURE, QualtricsRootModule, defaultQualtricsComponentsConfig };
