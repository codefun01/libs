import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { QualtricsComponentsModule } from '@spartacus/qualtrics/components';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QualtricsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QualtricsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QualtricsModule, imports: [QualtricsComponentsModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QualtricsModule, imports: [QualtricsComponentsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QualtricsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [QualtricsComponentsModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/*
 * Public API Surface of qualtrics
 */

/**
 * Generated bundle index. Do not edit.
 */

export { QualtricsModule };
//# sourceMappingURL=spartacus-qualtrics.mjs.map
