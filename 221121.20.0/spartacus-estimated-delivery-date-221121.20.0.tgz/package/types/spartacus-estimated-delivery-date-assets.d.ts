import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    estimatedDeliveryDate: {
        estimatedDeliveryDate: {
            quantity: string;
            quantityFull: string;
            ETA: string;
            estimatedDeliveryDateEntryInfo: string;
        };
    };
};

declare const de: {
    estimatedDeliveryDate: {
        estimatedDeliveryDate: {
            quantity: string;
            quantityFull: string;
            ETA: string;
            estimatedDeliveryDateEntryInfo: string;
        };
    };
};

declare const en: {
    estimatedDeliveryDate: {
        estimatedDeliveryDate: {
            quantity: string;
            quantityFull: string;
            ETA: string;
            estimatedDeliveryDateEntryInfo: string;
        };
    };
};

declare const es: {
    estimatedDeliveryDate: {
        estimatedDeliveryDate: {
            quantity: string;
            quantityFull: string;
            ETA: string;
            estimatedDeliveryDateEntryInfo: string;
        };
    };
};

declare const es_CO: {
    estimatedDeliveryDate: {
        estimatedDeliveryDate: {
            quantity: string;
            quantityFull: string;
            ETA: string;
            estimatedDeliveryDateEntryInfo: string;
        };
    };
};

declare const fr: {
    estimatedDeliveryDate: {
        estimatedDeliveryDate: {
            quantity: string;
            quantityFull: string;
            ETA: string;
            estimatedDeliveryDateEntryInfo: string;
        };
    };
};

declare const hi: {
    estimatedDeliveryDate: {
        estimatedDeliveryDate: {
            quantity: string;
            quantityFull: string;
            ETA: string;
            estimatedDeliveryDateEntryInfo: string;
        };
    };
};

declare const hu: {
    estimatedDeliveryDate: {
        estimatedDeliveryDate: {
            quantity: string;
            quantityFull: string;
            ETA: string;
            estimatedDeliveryDateEntryInfo: string;
        };
    };
};

declare const id: {
    estimatedDeliveryDate: {
        estimatedDeliveryDate: {
            quantity: string;
            quantityFull: string;
            ETA: string;
            estimatedDeliveryDateEntryInfo: string;
        };
    };
};

declare const it: {
    estimatedDeliveryDate: {
        estimatedDeliveryDate: {
            quantity: string;
            quantityFull: string;
            ETA: string;
            estimatedDeliveryDateEntryInfo: string;
        };
    };
};

declare const ja: {
    estimatedDeliveryDate: {
        estimatedDeliveryDate: {
            quantity: string;
            quantityFull: string;
            ETA: string;
            estimatedDeliveryDateEntryInfo: string;
        };
    };
};

declare const ko: {
    estimatedDeliveryDate: {
        estimatedDeliveryDate: {
            quantity: string;
            quantityFull: string;
            ETA: string;
            estimatedDeliveryDateEntryInfo: string;
        };
    };
};

declare const pl: {
    estimatedDeliveryDate: {
        estimatedDeliveryDate: {
            quantity: string;
            quantityFull: string;
            ETA: string;
            estimatedDeliveryDateEntryInfo: string;
        };
    };
};

declare const pt: {
    estimatedDeliveryDate: {
        estimatedDeliveryDate: {
            quantity: string;
            quantityFull: string;
            ETA: string;
            estimatedDeliveryDateEntryInfo: string;
        };
    };
};

declare const ru: {
    estimatedDeliveryDate: {
        estimatedDeliveryDate: {
            quantity: string;
            quantityFull: string;
            ETA: string;
            estimatedDeliveryDateEntryInfo: string;
        };
    };
};

declare const zh: {
    estimatedDeliveryDate: {
        estimatedDeliveryDate: {
            quantity: string;
            quantityFull: string;
            ETA: string;
            estimatedDeliveryDateEntryInfo: string;
        };
    };
};

declare const zh_TW: {
    estimatedDeliveryDate: {
        estimatedDeliveryDate: {
            quantity: string;
            quantityFull: string;
            ETA: string;
            estimatedDeliveryDateEntryInfo: string;
        };
    };
};

declare const estimatedDeliveryDateTranslationChunksConfig: TranslationChunksConfig;

export { estimatedDeliveryDateTranslationChunksConfig, cs as estimatedDeliveryDateTranslationsCs, de as estimatedDeliveryDateTranslationsDe, en as estimatedDeliveryDateTranslationsEn, es as estimatedDeliveryDateTranslationsEs, es_CO as estimatedDeliveryDateTranslationsEs_CO, fr as estimatedDeliveryDateTranslationsFr, hi as estimatedDeliveryDateTranslationsHi, hu as estimatedDeliveryDateTranslationsHu, id as estimatedDeliveryDateTranslationsId, it as estimatedDeliveryDateTranslationsIt, ja as estimatedDeliveryDateTranslationsJa, ko as estimatedDeliveryDateTranslationsKo, pl as estimatedDeliveryDateTranslationsPl, pt as estimatedDeliveryDateTranslationsPt, ru as estimatedDeliveryDateTranslationsRu, zh as estimatedDeliveryDateTranslationsZh, zh_TW as estimatedDeliveryDateTranslationsZh_TW };
