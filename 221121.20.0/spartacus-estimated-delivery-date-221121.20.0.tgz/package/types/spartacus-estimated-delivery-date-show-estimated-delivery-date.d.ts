import * as i0 from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/core';
import { TranslationService, CxDatePipe } from '@spartacus/core';
import * as i3 from '@spartacus/storefront';
import { CartItemContext, OrderEntry } from '@spartacus/cart/base/root';
import { OrderHistoryFacade, Consignment } from '@spartacus/order/root';
import { Observable } from 'rxjs';

declare class EstimatedDeliveryDateComponent {
    protected cartItemContext: CartItemContext;
    protected orderHistoryFacade: OrderHistoryFacade;
    protected translationService: TranslationService;
    protected datePipe: CxDatePipe;
    readonly orderEntry$: Observable<OrderEntry>;
    readonly consignments$: Observable<Consignment>;
    /**
     * Verifies whether the arrival slots infos (from Order Entry) have any entries.
     * Only in this case we want to display the arrival slot summary
     *
     * @param {OrderEntry} item - Cart item
     * @returns {boolean} - whether the arrival slot information is present for the order
     */
    hasOrderEntryArrivalSlots(item: OrderEntry): boolean;
    /**
     * Verifies whether the arrival slot infos (from Consignment) have any entries.
     * Only in this case we want to display the arrival slot summary
     *
     * @param {Consignment} item - Consignment item
     * @returns {boolean} - whether the arrival slot information is present for the order
     */
    hasConsignmentEntryArrivalSlot(item: Consignment): boolean;
    getArrivalSlotInfoId(index: number): string;
    getLongDate(date?: Date): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<EstimatedDeliveryDateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EstimatedDeliveryDateComponent, "cx-estimated-delivery-date", never, {}, {}, never, never, true, never>;
}

declare class ShowEstimatedDeliveryDateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ShowEstimatedDeliveryDateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ShowEstimatedDeliveryDateModule, never, [typeof i1.CommonModule, typeof i2.UrlModule, typeof i2.I18nModule, typeof i3.IconModule, typeof EstimatedDeliveryDateComponent], [typeof EstimatedDeliveryDateComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ShowEstimatedDeliveryDateModule>;
}

export { EstimatedDeliveryDateComponent, ShowEstimatedDeliveryDateModule };
