import * as i0 from '@angular/core';

interface ArrivalSlots {
    at?: Date;
    quantity?: number;
}
interface ArrivalSlot {
    at?: Date;
}

declare module '@spartacus/cart/base/root' {
    interface OrderEntry {
        arrivalSlots?: ArrivalSlots[];
    }
}
declare module '@spartacus/order/root' {
    interface Consignment {
        arrivalSlot?: ArrivalSlot;
    }
}

declare class EstimatedDeliveryDateRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<EstimatedDeliveryDateRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EstimatedDeliveryDateRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EstimatedDeliveryDateRootModule>;
}

declare const ESTIMATED_DELIVERY_DATE_FEATURE = "estimatedDeliveryDate";

export { ESTIMATED_DELIVERY_DATE_FEATURE, EstimatedDeliveryDateRootModule };
export type { ArrivalSlot, ArrivalSlots };
