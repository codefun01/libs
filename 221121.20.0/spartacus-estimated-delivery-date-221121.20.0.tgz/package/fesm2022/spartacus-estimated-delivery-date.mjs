import * as i0 from '@angular/core';
import { inject, Optional, Component, NgModule } from '@angular/core';
import { NgIf, NgFor, AsyncPipe, CommonModule } from '@angular/common';
import { CartItemContext, CartOutlets } from '@spartacus/cart/base/root';
import { TranslationService, CxDatePipe, TranslatePipe, UrlModule, I18nModule, provideDefaultConfig } from '@spartacus/core';
import { IconModule, provideOutlet, OutletPosition } from '@spartacus/storefront';
import { OrderHistoryFacade } from '@spartacus/order/root';
import { EMPTY } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class EstimatedDeliveryDateComponent {
    constructor() {
        this.cartItemContext = inject(CartItemContext);
        this.orderHistoryFacade = inject(OrderHistoryFacade);
        this.translationService = inject(TranslationService);
        this.datePipe = inject(CxDatePipe);
        this.orderEntry$ = this.cartItemContext?.item$ ?? EMPTY;
        this.consignments$ = this.orderHistoryFacade
            .getOrderDetails()
            .pipe(map((order) => order?.consignments ?? []))
            .pipe(switchMap((consignments) => consignments));
    }
    /**
     * Verifies whether the arrival slots infos (from Order Entry) have any entries.
     * Only in this case we want to display the arrival slot summary
     *
     * @param {OrderEntry} item - Cart item
     * @returns {boolean} - whether the arrival slot information is present for the order
     */
    hasOrderEntryArrivalSlots(item) {
        const arrivalSlots = item.arrivalSlots;
        return arrivalSlots != null && arrivalSlots.length > 0;
    }
    /**
     * Verifies whether the arrival slot infos (from Consignment) have any entries.
     * Only in this case we want to display the arrival slot summary
     *
     * @param {Consignment} item - Consignment item
     * @returns {boolean} - whether the arrival slot information is present for the order
     */
    hasConsignmentEntryArrivalSlot(item) {
        const arrivalSlot = item.arrivalSlot;
        return arrivalSlot != null && arrivalSlot.at != null;
    }
    getArrivalSlotInfoId(index) {
        return 'cx-estimated-delivery-date-info-' + index.toString();
    }
    getLongDate(date) {
        if (!date) {
            return '';
        }
        return this.datePipe.transform(date);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: EstimatedDeliveryDateComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: EstimatedDeliveryDateComponent, isStandalone: true, selector: "cx-estimated-delivery-date", providers: [CxDatePipe], ngImport: i0, template: "<ng-container *ngIf=\"orderEntry$ | async as orderEntry\">\n  <ng-container *ngIf=\"hasOrderEntryArrivalSlots(orderEntry)\">\n    <div class=\"cx-code\">\n      <div\n        *ngFor=\"let arrivalSlot of orderEntry.arrivalSlots; let i = index\"\n        class=\"cx-estimated-delivery-date-info\"\n        [attr.aria-describedby]=\"getArrivalSlotInfoId(i)\"\n      >\n        <div [id]=\"getArrivalSlotInfoId(i)\" class=\"cx-visually-hidden\">\n          {{\n            'estimatedDeliveryDate.estimatedDeliveryDateEntryInfo'\n              | cxTranslate\n                : {\n                    quantity: arrivalSlot.quantity,\n                    date: getLongDate(arrivalSlot.at),\n                  }\n          }}\n        </div>\n        <div class=\"cx-value\" aria-hidden=\"true\" *ngIf=\"arrivalSlot?.quantity\">\n          {{ 'estimatedDeliveryDate.ETA' | cxTranslate }}\n          {{ arrivalSlot?.at | cxDate: 'M/d/yyyy' }}\n        </div>\n        <ng-container *ngIf=\"arrivalSlot?.quantity\">\n          <div class=\"cx-value\" aria-hidden=\"true\">\n            {{ 'estimatedDeliveryDate.quantityFull' | cxTranslate }}\n            {{ arrivalSlot?.quantity }}\n          </div>\n        </ng-container>\n      </div>\n      <div\n        class=\"cx-label\"\n        aria-hidden=\"true\"\n        *ngIf=\"!orderEntry.arrivalSlots?.at(0)?.quantity\"\n      >\n        {{ 'estimatedDeliveryDate.ETA' | cxTranslate }}\n        {{ orderEntry.arrivalSlots?.at(0)?.at | cxDate: 'M/d/yyyy' }}\n      </div>\n    </div>\n  </ng-container>\n</ng-container>\n\n<ng-container *ngIf=\"consignments$ | async as consignments\">\n  <ng-container *ngIf=\"orderEntry$ | async as orderEntry\">\n    <ng-container\n      *ngIf=\"\n        hasConsignmentEntryArrivalSlot(consignments) &&\n        !hasOrderEntryArrivalSlots(orderEntry)\n      \"\n    >\n      <div class=\"cx-code\" aria-hidden=\"true\">\n        {{ 'estimatedDeliveryDate.ETA' | cxTranslate }}\n        {{ consignments.arrivalSlot?.at | cxDate: 'M/d/yyyy' }}\n      </div>\n    </ng-container>\n  </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: CxDatePipe, name: "cxDate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: EstimatedDeliveryDateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-estimated-delivery-date', providers: [CxDatePipe], imports: [NgIf, NgFor, AsyncPipe, TranslatePipe, CxDatePipe], template: "<ng-container *ngIf=\"orderEntry$ | async as orderEntry\">\n  <ng-container *ngIf=\"hasOrderEntryArrivalSlots(orderEntry)\">\n    <div class=\"cx-code\">\n      <div\n        *ngFor=\"let arrivalSlot of orderEntry.arrivalSlots; let i = index\"\n        class=\"cx-estimated-delivery-date-info\"\n        [attr.aria-describedby]=\"getArrivalSlotInfoId(i)\"\n      >\n        <div [id]=\"getArrivalSlotInfoId(i)\" class=\"cx-visually-hidden\">\n          {{\n            'estimatedDeliveryDate.estimatedDeliveryDateEntryInfo'\n              | cxTranslate\n                : {\n                    quantity: arrivalSlot.quantity,\n                    date: getLongDate(arrivalSlot.at),\n                  }\n          }}\n        </div>\n        <div class=\"cx-value\" aria-hidden=\"true\" *ngIf=\"arrivalSlot?.quantity\">\n          {{ 'estimatedDeliveryDate.ETA' | cxTranslate }}\n          {{ arrivalSlot?.at | cxDate: 'M/d/yyyy' }}\n        </div>\n        <ng-container *ngIf=\"arrivalSlot?.quantity\">\n          <div class=\"cx-value\" aria-hidden=\"true\">\n            {{ 'estimatedDeliveryDate.quantityFull' | cxTranslate }}\n            {{ arrivalSlot?.quantity }}\n          </div>\n        </ng-container>\n      </div>\n      <div\n        class=\"cx-label\"\n        aria-hidden=\"true\"\n        *ngIf=\"!orderEntry.arrivalSlots?.at(0)?.quantity\"\n      >\n        {{ 'estimatedDeliveryDate.ETA' | cxTranslate }}\n        {{ orderEntry.arrivalSlots?.at(0)?.at | cxDate: 'M/d/yyyy' }}\n      </div>\n    </div>\n  </ng-container>\n</ng-container>\n\n<ng-container *ngIf=\"consignments$ | async as consignments\">\n  <ng-container *ngIf=\"orderEntry$ | async as orderEntry\">\n    <ng-container\n      *ngIf=\"\n        hasConsignmentEntryArrivalSlot(consignments) &&\n        !hasOrderEntryArrivalSlots(orderEntry)\n      \"\n    >\n      <div class=\"cx-code\" aria-hidden=\"true\">\n        {{ 'estimatedDeliveryDate.ETA' | cxTranslate }}\n        {{ consignments.arrivalSlot?.at | cxDate: 'M/d/yyyy' }}\n      </div>\n    </ng-container>\n  </ng-container>\n</ng-container>\n" }]
        }], propDecorators: { cartItemContext: [{
                type: Optional
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultEddOccEndpoints = {
    carts: 'users/${userId}/carts?fields=carts(DEFAULT,potentialProductPromotions,appliedProductPromotions,potentialOrderPromotions,appliedOrderPromotions,entries(totalPrice(formattedValue),product(images(FULL),stock(FULL)),arrivalSlots,basePrice(formattedValue,value),updateable),totalPrice(formattedValue),totalItems,totalPriceWithTax(formattedValue),totalDiscounts(value,formattedValue),subTotal(formattedValue),totalUnitCount,deliveryItemsQuantity,deliveryCost(formattedValue),totalTax(formattedValue, value),pickupItemsQuantity,net,appliedVouchers,productDiscounts(formattedValue),user,saveTime,name,description)',
    cart: 'users/${userId}/carts/${cartId}?fields=DEFAULT,potentialProductPromotions,appliedProductPromotions,potentialOrderPromotions,appliedOrderPromotions,entries(totalPrice(formattedValue),product(images(FULL),stock(FULL)),arrivalSlots,basePrice(formattedValue,value),updateable),totalPrice(formattedValue),totalItems,totalPriceWithTax(formattedValue),totalDiscounts(value,formattedValue),subTotal(formattedValue),totalUnitCount,deliveryItemsQuantity,deliveryCost(formattedValue),totalTax(formattedValue, value),pickupItemsQuantity,net,appliedVouchers,productDiscounts(formattedValue),user,saveTime,name,description',
    createCart: 'users/${userId}/carts?fields=DEFAULT,potentialProductPromotions,appliedProductPromotions,potentialOrderPromotions,appliedOrderPromotions,entries(totalPrice(formattedValue),product(images(FULL),stock(FULL)),arrivalSlots,basePrice(formattedValue,value),updateable),totalPrice(formattedValue),totalItems,totalPriceWithTax(formattedValue),totalDiscounts(value,formattedValue),subTotal(formattedValue),totalUnitCount,deliveryItemsQuantity,deliveryCost(formattedValue),totalTax(formattedValue, value),pickupItemsQuantity,net,appliedVouchers,productDiscounts(formattedValue),user',
};
const defaultOccCartWithEddConfig = {
    backend: {
        occ: {
            endpoints: {
                /* eslint-disable max-len */
                ...defaultEddOccEndpoints,
                /* eslint-enable */
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ShowEstimatedDeliveryDateModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ShowEstimatedDeliveryDateModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: ShowEstimatedDeliveryDateModule, imports: [CommonModule,
            UrlModule,
            I18nModule,
            IconModule,
            EstimatedDeliveryDateComponent], exports: [EstimatedDeliveryDateComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ShowEstimatedDeliveryDateModule, providers: [
            provideDefaultConfig(defaultOccCartWithEddConfig),
            provideOutlet({
                id: CartOutlets.ITEM_DETAILS,
                position: OutletPosition.AFTER,
                component: EstimatedDeliveryDateComponent,
            }),
        ], imports: [CommonModule,
            UrlModule,
            I18nModule,
            IconModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ShowEstimatedDeliveryDateModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        UrlModule,
                        I18nModule,
                        IconModule,
                        EstimatedDeliveryDateComponent,
                    ],
                    exports: [EstimatedDeliveryDateComponent],
                    providers: [
                        provideDefaultConfig(defaultOccCartWithEddConfig),
                        provideOutlet({
                            id: CartOutlets.ITEM_DETAILS,
                            position: OutletPosition.AFTER,
                            component: EstimatedDeliveryDateComponent,
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class EstimatedDeliveryDateModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: EstimatedDeliveryDateModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: EstimatedDeliveryDateModule, imports: [ShowEstimatedDeliveryDateModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: EstimatedDeliveryDateModule, imports: [ShowEstimatedDeliveryDateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: EstimatedDeliveryDateModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [ShowEstimatedDeliveryDateModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/*
 * Public API Surface of estimated-delivery-date
 */

/**
 * Generated bundle index. Do not edit.
 */

export { EstimatedDeliveryDateComponent, EstimatedDeliveryDateModule, ShowEstimatedDeliveryDateModule };
//# sourceMappingURL=spartacus-estimated-delivery-date.mjs.map
