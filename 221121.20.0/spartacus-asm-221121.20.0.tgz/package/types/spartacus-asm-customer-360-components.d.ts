import * as i0 from '@angular/core';
import { EventEmitter, OnInit, TemplateRef, OnChanges, AfterViewChecked, ElementRef, SimpleChanges, OnDestroy, ChangeDetectorRef, QueryList, Type } from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/storefront';
import { BreakpointService, FocusConfig, ICON_TYPE, Card, DirectionService, LaunchDialogService, LayoutConfig } from '@spartacus/storefront';
import * as i3 from '@spartacus/core';
import { Product, User, UrlCommand, ProductService, TranslationService, PointOfService, WeekdayOpeningDay, CxDatePipe, GlobalMessageType, UserIdService, CustomerCouponService, Image } from '@spartacus/core';
import * as i3$1 from '@spartacus/asm/core';
import { SortOrder } from '@spartacus/asm/core';
import { Observable, Observer, BehaviorSubject, Subscription, ReplaySubject, Subject } from 'rxjs';
import { AsmCustomer360SectionConfig, AsmCustomer360ActiveCart, CustomerCart, AsmCustomer360ProductInterestList, AsmCustomer360SavedCart, AsmCustomer360CustomerProfile, AsmCustomer360Profile, AsmCustomer360PaymentDetail, AsmCustomer360TabsConfig, AsmCustomer360Activity, AsmCustomer360ActivityList, AsmCustomer360StoreLocation, AsmCustomer360Review, AsmCustomer360ReviewList, AsmCustomer360SupportTicket, AsmCustomer360SupportTicketList, AsmCustomer360CouponList, AsmCustomer360Facade, AsmCustomer360Coupon, AsmCustomer360PromotionList, AsmCustomer360Promotion, AsmCustomer360CustomerCouponList, AsmCustomer360TabConfig, AsmCustomer360Data, AsmCustomerOverview } from '@spartacus/asm/customer-360/root';
import { Cart, CartVoucherFacade, ActiveCartFacade } from '@spartacus/cart/base/root';
import { OrderHistoryList } from '@spartacus/order/root';
import { StoreFinderService, StoreFinderConfig, StoreFinderSearchPage } from '@spartacus/storefinder/core';
import { CsAgentAuthService } from '@spartacus/asm/root';

interface ProductItem extends Product {
    quantity?: number;
    basePrice?: string;
    totalPrice?: string;
}

declare class AsmCustomer360ProductItemComponent {
    product: ProductItem;
    quantity: number;
    isOrderEntry: boolean;
    selectProduct: EventEmitter<Product>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360ProductItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCustomer360ProductItemComponent, "cx-asm-customer-360-product-item", never, { "product": { "alias": "product"; "required": false; }; "quantity": { "alias": "quantity"; "required": false; }; "isOrderEntry": { "alias": "isOrderEntry"; "required": false; }; }, { "selectProduct": "selectProduct"; }, never, never, true, never>;
}

declare class AsmCustomer360ProductItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360ProductItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360ProductItemModule, never, [typeof i1.CommonModule, typeof i2.MediaModule, typeof i3.I18nModule, typeof AsmCustomer360ProductItemComponent], [typeof AsmCustomer360ProductItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360ProductItemModule>;
}

declare class AsmCustomer360ProductListingComponent implements OnInit {
    protected breakpointService: BreakpointService;
    emptyResultDescription: string;
    headerInactive: boolean;
    headerText: string;
    products: Array<ProductItem | Product>;
    headerTemplate: TemplateRef<void>;
    clickHeader: EventEmitter<void>;
    selectProduct: EventEmitter<Product>;
    numberofColumns$: Observable<number>;
    showMore: boolean;
    constructor(breakpointService: BreakpointService);
    ngOnInit(): void;
    toggleShowMore(): void;
    protected getNumberofColumns(): Observable<number>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360ProductListingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCustomer360ProductListingComponent, "cx-asm-customer-360-product-listing", never, { "emptyResultDescription": { "alias": "emptyResultDescription"; "required": false; }; "headerInactive": { "alias": "headerInactive"; "required": false; }; "headerText": { "alias": "headerText"; "required": false; }; "products": { "alias": "products"; "required": false; }; "headerTemplate": { "alias": "headerTemplate"; "required": false; }; }, { "clickHeader": "clickHeader"; "selectProduct": "selectProduct"; }, never, never, true, never>;
}

declare class AsmCustomer360ProductListingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360ProductListingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360ProductListingModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof i2.MediaModule, typeof AsmCustomer360ProductItemModule, typeof AsmCustomer360ProductListingComponent], [typeof AsmCustomer360ProductListingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360ProductListingModule>;
}

declare abstract class AsmCustomer360SectionContext<Data> {
    readonly customer$: Observable<User>;
    readonly config$: Observable<AsmCustomer360SectionConfig>;
    readonly navigate$: Observer<UrlCommand>;
    readonly data$: Observable<Data>;
    readonly savedCarts$: Observable<Array<Cart>>;
    readonly activeCart$: Observable<Cart>;
    readonly orderHistory$: Observable<OrderHistoryList>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360SectionContext<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmCustomer360SectionContext<any>>;
}

declare class AsmCustomer360ActiveCartComponent {
    sectionContext: AsmCustomer360SectionContext<AsmCustomer360ActiveCart>;
    protected productService: ProductService;
    productItems$: Observable<Array<ProductItem>>;
    activeCart$: Observable<CustomerCart | undefined>;
    constructor(sectionContext: AsmCustomer360SectionContext<AsmCustomer360ActiveCart>, productService: ProductService);
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360ActiveCartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCustomer360ActiveCartComponent, "cx-asm-customer-360-active-cart", never, {}, {}, never, never, true, never>;
}

declare class AsmCustomer360ActiveCartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360ActiveCartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360ActiveCartModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof AsmCustomer360ProductListingModule, typeof AsmCustomer360ActiveCartComponent], [typeof AsmCustomer360ActiveCartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360ActiveCartModule>;
}

declare class AsmCustomer360ProductInterestsComponent {
    sectionContext: AsmCustomer360SectionContext<AsmCustomer360ProductInterestList>;
    protected productService: ProductService;
    products$: Observable<Array<Product>>;
    constructor(sectionContext: AsmCustomer360SectionContext<AsmCustomer360ProductInterestList>, productService: ProductService);
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360ProductInterestsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCustomer360ProductInterestsComponent, "cx-asm-customer-360-product-interests", never, {}, {}, never, never, true, never>;
}

declare class AsmCustomer360ProductInterestsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360ProductInterestsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360ProductInterestsModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof AsmCustomer360ProductListingModule, typeof AsmCustomer360ProductInterestsComponent], [typeof AsmCustomer360ProductInterestsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360ProductInterestsModule>;
}

declare class AsmCustomer360SavedCartComponent {
    protected sectionContext: AsmCustomer360SectionContext<AsmCustomer360SavedCart>;
    protected productService: ProductService;
    savedCart$: Observable<CustomerCart | undefined>;
    productItems$: Observable<Array<ProductItem>>;
    constructor(sectionContext: AsmCustomer360SectionContext<AsmCustomer360SavedCart>, productService: ProductService);
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360SavedCartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCustomer360SavedCartComponent, "cx-asm-customer-360-saved-cart", never, {}, {}, never, never, true, never>;
}

declare class AsmCustomer360SavedCartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360SavedCartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360SavedCartModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof AsmCustomer360ProductListingModule, typeof AsmCustomer360SavedCartComponent], [typeof AsmCustomer360SavedCartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360SavedCartModule>;
}

declare class AsmCustomer360ProfileComponent implements OnInit {
    sectionContext: AsmCustomer360SectionContext<AsmCustomer360CustomerProfile>;
    protected translation: TranslationService;
    focusConfig: FocusConfig;
    iconTypes: typeof ICON_TYPE;
    customerProfileData$: Observable<AsmCustomer360Profile | undefined>;
    constructor(sectionContext: AsmCustomer360SectionContext<AsmCustomer360CustomerProfile>, translation: TranslationService);
    ngOnInit(): void;
    getCardContent({ defaultPayment, expiryMonth, expiryYear, cardNumber, cardType, }: AsmCustomer360PaymentDetail): Observable<Card>;
    getCardIcon(code: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360ProfileComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCustomer360ProfileComponent, "cx-asm-customer-360-profile", never, {}, {}, never, never, true, never>;
}

declare class AsmCustomer360ProfileModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360ProfileModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360ProfileModule, never, [typeof i2.CardModule, typeof i1.CommonModule, typeof i3.I18nModule, typeof AsmCustomer360ProfileComponent], [typeof AsmCustomer360ProfileComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360ProfileModule>;
}

declare abstract class AsmCustomer360Config {
    asmCustomer360?: AsmCustomer360TabsConfig;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360Config, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmCustomer360Config>;
}
declare module '@spartacus/core' {
    interface Config extends AsmCustomer360Config {
    }
}

declare enum CustomerTableTextAlign {
    START = "START",
    CENTER = "CENTER",
    END = "END"
}
interface CustomerTableColumn {
    text?: string;
    i18nTextKey?: string;
    property: string;
    renderAsStarRating?: boolean;
    isDate?: boolean;
    navigatable?: boolean;
    textAlign?: CustomerTableTextAlign;
    headerTextAlign?: CustomerTableTextAlign;
}
interface TableEntry {
    [key: string]: string | number | undefined;
}

declare class AsmCustomer360TableComponent implements OnChanges, AfterViewChecked {
    protected asmCustomer360Config: AsmCustomer360Config;
    protected directionService: DirectionService;
    table: ElementRef;
    columns: Array<CustomerTableColumn>;
    emptyStateText: string;
    entries: Array<TableEntry>;
    headerText: string;
    pageSize: number;
    sortProperty: keyof TableEntry;
    selectItem: EventEmitter<TableEntry>;
    SortOrder: typeof SortOrder;
    CustomerTableTextAlign: typeof CustomerTableTextAlign;
    currentPageNumber: number;
    currentPage$: BehaviorSubject<TableEntry[] | undefined>;
    listSortOrder: SortOrder;
    entryPages: Array<Array<TableEntry>>;
    focusedTableColumnIndex: number;
    focusedTableRowIndex: number;
    setFocusOnStartTableItem: boolean;
    constructor(asmCustomer360Config: AsmCustomer360Config, directionService: DirectionService);
    ngOnChanges(changes?: SimpleChanges): void;
    ngAfterViewChecked(): void;
    sortEntriesAndUpdatePages(sortProperty: string): void;
    setPageNumber(pageNumber: number, selectFirstRecord?: boolean): void;
    /**
     * returns sort direction
     * @param columnProperty column property
     * @param sortProperty current sort property
     * @param listSortOrder current sort order
     */
    sortDirection(columnProperty: string, sortProperty: keyof TableEntry, listSortOrder: SortOrder): string;
    /**
     * returns tabIndex value
     * @param focusedTableColumnIndex saved column index
     * @param focusedTableRowIndex saved row index
     * @param columnIndex selected column index
     */
    tabIndexValue(focusedTableColumnIndex: number, focusedTableRowIndex: number, columnIndex: number): number;
    /**
     * Update cell's focus When keyboard key is pressed:
     * handles arrowUp, arrowDown, arrowRight, arrowLeft, Home, End, Home+Ctrl, End+Ctrl
     * PageDown, PageUp
     * @param event KeyboardEvent
     * @param columnIndex selected column index of table
     * @param rowIndex selected row index of table
     */
    onKeyDownCell(event: KeyboardEvent, columnIndex: number, rowIndex: number): void;
    /**
     * Update selected cell's tabIndex (change tabIndex to 0).
     * if cell contains link(button) then update link
     * @param columnIndex selected column index of table
     * @param rowIndex selected row index of table
     */
    setSelectedTabIndex(columnIndex: number, rowIndex: number): void;
    protected handlePageUp(): void;
    protected handlePageDown(): void;
    protected moveFocusEnd(event: KeyboardEvent, rowIndex: number): void;
    protected moveFocusHome(event: KeyboardEvent, rowIndex: number): void;
    protected moveFocusUp(columnIndex: number, rowIndex: number): void;
    protected moveFocusDown(columnIndex: number, rowIndex: number): void;
    protected moveFocusLeftRight(event: KeyboardEvent, columnIndex: number, rowIndex: number): void;
    /**
     * Removes tabindex and CSS focus class from a cell in the table.
     * @param columnIndex The index of the column containing the cell.
     * @param rowIndex The index of the row containing the cell.
     */
    protected removeCellTabIndex(columnIndex: number, rowIndex: number): void;
    /**
     * Verifies whether the user navigates from a subgroup back to the main group menu.
     * @param {KeyboardEvent} event - Keyboard event
     * @returns {boolean} -'true' if the user navigates back into the main group menu, otherwise 'false'.
     * @protected
     */
    protected isBackNavigation(event: KeyboardEvent): boolean;
    protected isLTRDirection(): boolean;
    protected isRTLDirection(): boolean;
    protected updateEntryPages(entries: Array<TableEntry>): Array<Array<TableEntry>>;
    protected sortEntries(entries: Array<TableEntry>, sortByProperty: keyof TableEntry, sortOrder: SortOrder): Array<TableEntry>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360TableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCustomer360TableComponent, "cx-asm-customer-360-table", never, { "columns": { "alias": "columns"; "required": false; }; "emptyStateText": { "alias": "emptyStateText"; "required": false; }; "entries": { "alias": "entries"; "required": false; }; "headerText": { "alias": "headerText"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; "sortProperty": { "alias": "sortProperty"; "required": false; }; }, { "selectItem": "selectItem"; }, never, never, true, never>;
}

declare class AsmCustomer360TableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360TableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360TableModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof i3$1.ArgsModule, typeof i2.StarRatingModule, typeof AsmCustomer360TableComponent], [typeof AsmCustomer360TableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360TableModule>;
}

interface ActivityEntry extends AsmCustomer360Activity {
    typeLabel?: string;
    statusLabel?: string;
}

declare class AsmCustomer360ActivityComponent implements OnInit {
    protected context: AsmCustomer360SectionContext<AsmCustomer360ActivityList>;
    entries$: Observable<Array<ActivityEntry>>;
    columns: Array<CustomerTableColumn>;
    constructor(context: AsmCustomer360SectionContext<AsmCustomer360ActivityList>);
    ngOnInit(): void;
    itemSelected(entry: ActivityEntry | undefined): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360ActivityComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCustomer360ActivityComponent, "cx-asm-customer-360-activity", never, {}, {}, never, never, true, never>;
}

declare class AsmCustomer360ActivityModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360ActivityModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360ActivityModule, never, [typeof i1.CommonModule, typeof AsmCustomer360TableModule, typeof i3.I18nModule, typeof AsmCustomer360ActivityComponent], [typeof AsmCustomer360ActivityComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360ActivityModule>;
}

declare class AsmCustomer360MapComponent implements OnDestroy, OnInit {
    source: AsmCustomer360SectionContext<AsmCustomer360StoreLocation>;
    protected changeDetectorRef: ChangeDetectorRef;
    protected storeFinderService: StoreFinderService;
    protected translationService: TranslationService;
    protected storeFinderConfig: StoreFinderConfig;
    storeData: StoreFinderSearchPage;
    selectedStore: PointOfService | undefined;
    apiKey: string;
    dataSource$: Observable<[
        AsmCustomer360SectionConfig,
        AsmCustomer360StoreLocation
    ]>;
    protected subscription: Subscription;
    constructor(source: AsmCustomer360SectionContext<AsmCustomer360StoreLocation>, changeDetectorRef: ChangeDetectorRef, storeFinderService: StoreFinderService, translationService: TranslationService, storeFinderConfig: StoreFinderConfig);
    ngOnInit(): void;
    ngOnDestroy(): void;
    selectStore(store: PointOfService): void;
    getStoreOpening(opening: WeekdayOpeningDay): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360MapComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCustomer360MapComponent, "cx-asm-customer-360-map", never, {}, {}, never, never, true, never>;
}

declare class AsmCustomer360MapComponentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360MapComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360MapComponentModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof AsmCustomer360MapComponent], [typeof AsmCustomer360MapComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360MapComponentModule>;
}

interface ReviewEntry extends AsmCustomer360Review {
    item?: string;
    dateAndStatus?: string;
}

declare class AsmCustomer360ProductReviewsComponent implements OnInit {
    protected asmCustomer360Config: AsmCustomer360Config;
    protected context: AsmCustomer360SectionContext<AsmCustomer360ReviewList>;
    protected datePipe: CxDatePipe;
    protected translation: TranslationService;
    reviewColumns: Array<CustomerTableColumn>;
    reviewEntries$: Observable<Array<ReviewEntry>>;
    protected subscription: Subscription;
    constructor(asmCustomer360Config: AsmCustomer360Config, context: AsmCustomer360SectionContext<AsmCustomer360ReviewList>, datePipe: CxDatePipe, translation: TranslationService);
    ngOnInit(): void;
    navigateTo(entry: TableEntry): void;
    protected getLongDate(date: Date): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360ProductReviewsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCustomer360ProductReviewsComponent, "cx-asm-customer-360-product-reviews", never, {}, {}, never, never, true, never>;
}

declare class AsmCustomer360ProductReviewsComponentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360ProductReviewsComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360ProductReviewsComponentModule, never, [typeof i1.CommonModule, typeof AsmCustomer360TableModule, typeof i3.I18nModule, typeof AsmCustomer360ProductReviewsComponent], [typeof AsmCustomer360ProductReviewsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360ProductReviewsComponentModule>;
}

interface SupportTicketEntry extends AsmCustomer360SupportTicket {
    categoryLabel?: string;
    statusLabel?: string;
}

declare class AsmCustomer360SupportTicketsComponent implements OnInit {
    protected context: AsmCustomer360SectionContext<AsmCustomer360SupportTicketList>;
    supportTicketsColumns: Array<CustomerTableColumn>;
    supportTicketsEntries$: Observable<Array<SupportTicketEntry>>;
    constructor(context: AsmCustomer360SectionContext<AsmCustomer360SupportTicketList>);
    ngOnInit(): void;
    navigateTo(entry: SupportTicketEntry): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360SupportTicketsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCustomer360SupportTicketsComponent, "cx-asm-customer-360-support-tickets", never, {}, {}, never, never, true, never>;
}

declare class AsmCustomer360SupportTicketsComponentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360SupportTicketsComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360SupportTicketsComponentModule, never, [typeof i1.CommonModule, typeof AsmCustomer360TableModule, typeof i3.I18nModule, typeof AsmCustomer360SupportTicketsComponent], [typeof AsmCustomer360SupportTicketsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360SupportTicketsComponentModule>;
}

interface PromotionListEntry {
    [key: string]: string | boolean | undefined;
}

declare class AsmCustomer360PromotionListingComponent {
    headerText: string;
    emptyStateText: string;
    applyButtonText: string;
    applied: string;
    removeButtonText: string;
    entries: Array<PromotionListEntry> | null;
    showAlert: boolean | null;
    showAlertForApplyAction: boolean | null;
    showRemoveButton: boolean;
    showApplyButton: boolean;
    isCustomerCoupon: boolean;
    apply: EventEmitter<PromotionListEntry>;
    remove: EventEmitter<PromotionListEntry>;
    removeAlert: EventEmitter<any>;
    removeAlertForApplyAction: EventEmitter<any>;
    globalMessageType: typeof GlobalMessageType;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360PromotionListingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCustomer360PromotionListingComponent, "cx-asm-customer-360-promotion-listing", never, { "headerText": { "alias": "headerText"; "required": false; }; "emptyStateText": { "alias": "emptyStateText"; "required": false; }; "applyButtonText": { "alias": "applyButtonText"; "required": false; }; "applied": { "alias": "applied"; "required": false; }; "removeButtonText": { "alias": "removeButtonText"; "required": false; }; "entries": { "alias": "entries"; "required": false; }; "showAlert": { "alias": "showAlert"; "required": false; }; "showAlertForApplyAction": { "alias": "showAlertForApplyAction"; "required": false; }; "showRemoveButton": { "alias": "showRemoveButton"; "required": false; }; "showApplyButton": { "alias": "showApplyButton"; "required": false; }; "isCustomerCoupon": { "alias": "isCustomerCoupon"; "required": false; }; }, { "apply": "apply"; "remove": "remove"; "removeAlert": "removeAlert"; "removeAlertForApplyAction": "removeAlertForApplyAction"; }, never, ["*"], true, never>;
}

declare class AsmCustomer360PromotionListingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360PromotionListingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360PromotionListingModule, never, [typeof i1.CommonModule, typeof i3.I18nModule, typeof i3$1.ArgsModule, typeof i2.StarRatingModule, typeof i2.MessageComponentModule, typeof i2.IconModule, typeof AsmCustomer360PromotionListingComponent], [typeof AsmCustomer360PromotionListingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360PromotionListingModule>;
}

declare class AsmCustomer360CouponComponent implements OnInit, OnDestroy {
    protected context: AsmCustomer360SectionContext<AsmCustomer360CouponList>;
    protected cartVoucherService: CartVoucherFacade;
    protected userIdService: UserIdService;
    protected activeCartFacade: ActiveCartFacade;
    protected asmCustomer360Facade: AsmCustomer360Facade;
    showErrorAlert$: BehaviorSubject<boolean>;
    showErrorAlertForApplyAction$: BehaviorSubject<boolean>;
    currentCartId: string | undefined;
    userId: string;
    entries$: Observable<Array<AsmCustomer360Coupon>>;
    subscription: Subscription;
    constructor(context: AsmCustomer360SectionContext<AsmCustomer360CouponList>, cartVoucherService: CartVoucherFacade, userIdService: UserIdService, activeCartFacade: ActiveCartFacade, asmCustomer360Facade: AsmCustomer360Facade);
    ngOnInit(): void;
    fetchCoupons(): void;
    closeErrorAlert(): void;
    closeErrorAlertForApplyAction(): void;
    refreshComponent(): void;
    applyCouponToCustomer(entry: AsmCustomer360Coupon): void;
    removeCouponToCustomer(entry: AsmCustomer360Coupon): void;
    refreshActionButton(state: boolean, voucherCode: string): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360CouponComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCustomer360CouponComponent, "cx-asm-customer-360-coupon", never, {}, {}, never, never, true, never>;
}

declare class AsmCustomer360CouponComponentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360CouponComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360CouponComponentModule, never, [typeof i1.CommonModule, typeof AsmCustomer360PromotionListingModule, typeof i3.I18nModule, typeof AsmCustomer360CouponComponent], [typeof AsmCustomer360CouponComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360CouponComponentModule>;
}

declare class AsmCustomer360PromotionComponent implements OnInit, OnDestroy {
    protected context: AsmCustomer360SectionContext<AsmCustomer360PromotionList>;
    protected asmCustomer360Facade: AsmCustomer360Facade;
    protected activeCartFacade: ActiveCartFacade;
    showErrorAlert$: BehaviorSubject<boolean>;
    entries$: BehaviorSubject<AsmCustomer360Promotion[]>;
    subscription: Subscription;
    userId: string;
    constructor(context: AsmCustomer360SectionContext<AsmCustomer360PromotionList>, asmCustomer360Facade: AsmCustomer360Facade, activeCartFacade: ActiveCartFacade);
    ngOnInit(): void;
    refreshPromotions(): void;
    fetchPromotions(): void;
    closeErrorAlert(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360PromotionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCustomer360PromotionComponent, "cx-asm-customer-360-promotion", never, {}, {}, never, never, true, never>;
}

declare class AsmCustomer360PromotionComponentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360PromotionComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360PromotionComponentModule, never, [typeof i1.CommonModule, typeof AsmCustomer360PromotionListingModule, typeof i3.I18nModule, typeof AsmCustomer360PromotionComponent], [typeof AsmCustomer360PromotionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360PromotionComponentModule>;
}

interface CustomerCouponEntry {
    code: string | undefined;
    name: string | undefined;
    applied: boolean;
    codeForApplyAction: string;
}

declare class AsmCustomer360CustomerCouponComponent implements OnInit, OnDestroy {
    protected context: AsmCustomer360SectionContext<AsmCustomer360CustomerCouponList>;
    protected asmCustomer360Facade: AsmCustomer360Facade;
    protected customerCouponService: CustomerCouponService;
    showErrorAlert$: BehaviorSubject<boolean>;
    showErrorAlertForApplyAction$: BehaviorSubject<boolean>;
    entries$: Observable<Array<CustomerCouponEntry>>;
    subscription: Subscription;
    currentTabIsAssignable: boolean;
    iconTypes: typeof ICON_TYPE;
    activeTab: number;
    constructor(context: AsmCustomer360SectionContext<AsmCustomer360CustomerCouponList>, asmCustomer360Facade: AsmCustomer360Facade, customerCouponService: CustomerCouponService);
    ngOnInit(): void;
    fetchCustomerCoupons(): void;
    changeTab(assignable: boolean): void;
    searchCustomerCoupon(searchQuery: string): void;
    private hideAllErrorAlert;
    private mapParams;
    closeErrorAlert(): void;
    closeErrorAlertForApplyAction(): void;
    claimCouponToCustomer(entry: CustomerCouponEntry): void;
    disclaimCouponToCustomer(entry: CustomerCouponEntry): void;
    refreshActionButton(couponCode: string): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360CustomerCouponComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCustomer360CustomerCouponComponent, "cx-asm-customer-360-customer-coupon", never, {}, {}, never, never, true, never>;
}

declare class AsmCustomer360CustomerCouponComponentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360CustomerCouponComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360CustomerCouponComponentModule, never, [typeof i1.CommonModule, typeof AsmCustomer360PromotionListingModule, typeof i3.I18nModule, typeof i2.IconModule, typeof i2.SearchBoxModule, typeof AsmCustomer360CustomerCouponComponent], [typeof AsmCustomer360CustomerCouponComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360CustomerCouponComponentModule>;
}

declare class AsmCustomer360Component implements OnDestroy, OnInit {
    protected asmCustomer360Config: AsmCustomer360Config;
    protected asmCustomer360Facade: AsmCustomer360Facade;
    protected launchDialogService: LaunchDialogService;
    protected csAgentAuthService: CsAgentAuthService;
    protected directionService: DirectionService;
    role: string;
    modal: boolean;
    labelledby: string;
    describedby: string;
    tabHeaderItems: QueryList<ElementRef<HTMLElement>>;
    readonly cartIcon = ICON_TYPE.CART;
    readonly closeIcon = ICON_TYPE.CLOSE;
    readonly orderIcon = ICON_TYPE.ORDER;
    readonly ticketIcon = ICON_TYPE.FILE;
    globalMessageType: typeof GlobalMessageType;
    focusConfig: FocusConfig;
    tabs: Array<AsmCustomer360TabConfig>;
    activeTab: number;
    currentTab: AsmCustomer360TabConfig;
    customer: User;
    asmCustomer360Tabs$: Observable<Array<AsmCustomer360Data | undefined>>;
    customerOverview$: Observable<AsmCustomerOverview | undefined>;
    protected subscription: Subscription;
    protected showErrorAlert$: BehaviorSubject<boolean>;
    protected showErrorTab$: BehaviorSubject<boolean>;
    constructor(asmCustomer360Config: AsmCustomer360Config, asmCustomer360Facade: AsmCustomer360Facade, launchDialogService: LaunchDialogService, csAgentAuthService: CsAgentAuthService, directionService: DirectionService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    errorAlert$: Observable<boolean>;
    errorTab$: Observable<boolean>;
    /**
     * Triggered when a tab is selected.
     * @param {number} selectedTab selected tab index
     */
    selectTab(selectedTab: number): void;
    /**
     *  Update tab focus when key is pressed
     * @param {KeyboardEvent} event
     * @param {number} selectedIndex current tab index
     */
    switchTab(event: KeyboardEvent, selectedIndex: number): void;
    /**
     * If there is a link within the modal, use this method to redirect the user and close the modal.
     */
    navigateTo(route: UrlCommand): void;
    closeErrorAlert(): void;
    closeModal(reason?: any): void;
    getAvatarText(customer?: User): string;
    getAvatarImage(overview?: AsmCustomerOverview): Image | undefined;
    /**
     * Update tabIndex for each tab: select tab becomes 0 and other tabs will be -1
     * this is for prevent tabbing within tabs
     * @param {number} selectedIndex - selected tab index
     */
    protected updateTabIndex(selectedIndex: number): void;
    protected setTabData(): void;
    /**
     * Verifies whether the user navigates into a subgroup of the main group menu.
     *
     * @param {KeyboardEvent} event - Keyboard event
     * @returns {boolean} -'true' if the user navigates into the subgroup, otherwise 'false'.
     * @protected
     */
    protected isForwardsNavigation(event: KeyboardEvent): boolean;
    /**
     * Verifies whether the user navigates from a subgroup back to the main group menu.
     *
     * @param {KeyboardEvent} event - Keyboard event
     * @returns {boolean} -'true' if the user navigates back into the main group menu, otherwise 'false'.
     * @protected
     */
    protected isBackNavigation(event: KeyboardEvent): boolean;
    protected isLTRDirection(): boolean;
    protected isRTLDirection(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360Component, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCustomer360Component, "cx-asm-customer-360", never, {}, {}, never, never, true, never>;
}

declare class AsmCustomer360SectionContextSource<Data> extends AsmCustomer360SectionContext<Data> {
    readonly customer$: ReplaySubject<User>;
    readonly config$: ReplaySubject<AsmCustomer360SectionConfig>;
    readonly navigate$: Subject<UrlCommand>;
    readonly data$: ReplaySubject<Data>;
    readonly savedCarts$: ReplaySubject<Cart[]>;
    readonly activeCart$: ReplaySubject<Cart>;
    readonly orderHistory$: ReplaySubject<OrderHistoryList>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360SectionContextSource<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmCustomer360SectionContextSource<any>>;
}

declare class AsmCustomer360SectionComponent implements OnDestroy {
    protected source: AsmCustomer360SectionContextSource<unknown>;
    component: Type<unknown>;
    set customer(customer: User);
    set config(config: AsmCustomer360SectionConfig);
    set data(data: Observable<unknown>);
    navigate: EventEmitter<UrlCommand>;
    protected subscription: Subscription;
    constructor(source: AsmCustomer360SectionContextSource<unknown>);
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360SectionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCustomer360SectionComponent, "cx-asm-customer-360-section", never, { "component": { "alias": "component"; "required": false; }; "customer": { "alias": "customer"; "required": false; }; "config": { "alias": "config"; "required": false; }; "data": { "alias": "data"; "required": false; }; }, { "navigate": "navigate"; }, never, never, true, never>;
}

declare class AsmCustomer360ComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360ComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360ComponentsModule, never, [typeof i1.CommonModule, typeof i2.StarRatingModule, typeof i3.I18nModule, typeof i3$1.ArgsModule, typeof i2.MediaModule, typeof i2.IconModule, typeof i2.KeyboardFocusModule, typeof i2.PageComponentModule, typeof i2.MessageComponentModule, typeof AsmCustomer360ActiveCartModule, typeof AsmCustomer360ProductInterestsModule, typeof AsmCustomer360SavedCartModule, typeof AsmCustomer360ProfileModule, typeof AsmCustomer360ActivityModule, typeof AsmCustomer360MapComponentModule, typeof AsmCustomer360ProductReviewsComponentModule, typeof AsmCustomer360SupportTicketsComponentModule, typeof AsmCustomer360CouponComponentModule, typeof AsmCustomer360PromotionComponentModule, typeof AsmCustomer360CustomerCouponComponentModule, typeof AsmCustomer360Component, typeof AsmCustomer360SectionComponent], [typeof AsmCustomer360Component]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360ComponentsModule>;
}

declare const defaultAsmCustomer360Config: AsmCustomer360Config;

declare const defaultAsmCustomer360LayoutConfig: LayoutConfig;

export { AsmCustomer360ActiveCartComponent, AsmCustomer360ActivityComponent, AsmCustomer360Component, AsmCustomer360ComponentsModule, AsmCustomer360Config, AsmCustomer360CouponComponent, AsmCustomer360CustomerCouponComponent, AsmCustomer360MapComponent, AsmCustomer360ProductInterestsComponent, AsmCustomer360ProductReviewsComponent, AsmCustomer360ProfileComponent, AsmCustomer360PromotionComponent, AsmCustomer360SavedCartComponent, AsmCustomer360SupportTicketsComponent, defaultAsmCustomer360Config, defaultAsmCustomer360LayoutConfig };
