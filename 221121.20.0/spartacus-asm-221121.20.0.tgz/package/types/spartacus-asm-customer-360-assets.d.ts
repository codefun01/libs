import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    asmCustomer360: {
        asmCustomer360: {
            alertErrorMessage: string;
            errorMessageHeader: string;
            applyActionAlter: string;
            header: {
                title: string;
                newTitle: string;
                subTitle: string;
                newSubTitle: string;
                activeCartLabel: string;
                recentOrderLabel: string;
                recentTicketLabel: string;
                signedUpAt: string;
            };
            productListing: {
                totalNoItems: string;
                totalPrice: string;
                showMore: string;
                showLess: string;
            };
            productItem: {
                outOfStock: string;
                quantity: string;
                itemPrice: string;
            };
            activeCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            savedCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            productInterests: {
                header: string;
                emptyDescription: string;
            };
            profile: {
                address: string;
                billingAddress: string;
                deliveryAddress: string;
                phone1: string;
                phone2: string;
                paymentMethodHeader: string;
            };
            activity: {
                type: string;
                id: string;
                description: string;
                status: string;
                created: string;
                updated: string;
                numberOfCartItems: string;
                cart: string;
                order: string;
                savedCart: string;
                emptyStateText: string;
                headerText: string;
            };
            productReviews: {
                columnHeaders: {
                    item: string;
                    dateAndStatus: string;
                    rating: string;
                    review: string;
                };
                header: string;
                emptyDescription: string;
                sku: string;
            };
            supportTickets: {
                columnHeaders: {
                    id: string;
                    headline: string;
                    category: string;
                };
                header: string;
                emptyDescription: string;
            };
            coupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                applied: string;
                removeButtonText: string;
            };
            promotions: {
                headerText: string;
                emptyDescription: string;
                applied: string;
                headerName: string;
                headerAction: string;
            };
            customerCoupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                removeButtonText: string;
                availableTab: string;
                sentTab: string;
                searchBox: string;
            };
            maps: {
                storeClosed: string;
                storesFound: string;
            };
            overviewTab: string;
            profileTab: string;
            activityTab: string;
            feedbackTab: string;
            promotionsTab: string;
            mapsTab: string;
            storeLocationsTab: string;
            aria: {
                activeCartCode: string;
                recentOrderCode: string;
            };
            pagination: string;
            page: string;
            emptyCellValue: string;
        };
    };
};

declare const de: {
    asmCustomer360: {
        asmCustomer360: {
            alertErrorMessage: string;
            errorMessageHeader: string;
            applyActionAlter: string;
            header: {
                title: string;
                newTitle: string;
                subTitle: string;
                newSubTitle: string;
                activeCartLabel: string;
                recentOrderLabel: string;
                recentTicketLabel: string;
                signedUpAt: string;
            };
            productListing: {
                totalNoItems: string;
                totalPrice: string;
                showMore: string;
                showLess: string;
            };
            productItem: {
                outOfStock: string;
                quantity: string;
                itemPrice: string;
            };
            activeCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            savedCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            productInterests: {
                header: string;
                emptyDescription: string;
            };
            profile: {
                address: string;
                billingAddress: string;
                deliveryAddress: string;
                phone1: string;
                phone2: string;
                paymentMethodHeader: string;
            };
            activity: {
                type: string;
                id: string;
                description: string;
                status: string;
                created: string;
                updated: string;
                numberOfCartItems: string;
                cart: string;
                order: string;
                savedCart: string;
                emptyStateText: string;
                headerText: string;
            };
            productReviews: {
                columnHeaders: {
                    item: string;
                    dateAndStatus: string;
                    rating: string;
                    review: string;
                };
                header: string;
                emptyDescription: string;
                sku: string;
            };
            supportTickets: {
                columnHeaders: {
                    id: string;
                    headline: string;
                    category: string;
                };
                header: string;
                emptyDescription: string;
            };
            coupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                applied: string;
                removeButtonText: string;
            };
            promotions: {
                headerText: string;
                emptyDescription: string;
                applied: string;
                headerName: string;
                headerAction: string;
            };
            customerCoupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                removeButtonText: string;
                availableTab: string;
                sentTab: string;
                searchBox: string;
            };
            maps: {
                storeClosed: string;
                storesFound: string;
            };
            overviewTab: string;
            profileTab: string;
            activityTab: string;
            feedbackTab: string;
            promotionsTab: string;
            mapsTab: string;
            storeLocationsTab: string;
            aria: {
                activeCartCode: string;
                recentOrderCode: string;
            };
            pagination: string;
            page: string;
            emptyCellValue: string;
        };
    };
};

declare const en: {
    asmCustomer360: {
        asmCustomer360: {
            alertErrorMessage: string;
            errorMessageHeader: string;
            applyActionAlter: string;
            header: {
                title: string;
                newTitle: string;
                subTitle: string;
                newSubTitle: string;
                activeCartLabel: string;
                recentOrderLabel: string;
                recentTicketLabel: string;
                signedUpAt: string;
            };
            productListing: {
                totalNoItems: string;
                totalPrice: string;
                showMore: string;
                showLess: string;
            };
            productItem: {
                outOfStock: string;
                quantity: string;
                itemPrice: string;
            };
            activeCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            savedCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            productInterests: {
                header: string;
                emptyDescription: string;
            };
            profile: {
                address: string;
                billingAddress: string;
                deliveryAddress: string;
                phone1: string;
                phone2: string;
                paymentMethodHeader: string;
            };
            activity: {
                type: string;
                id: string;
                description: string;
                status: string;
                created: string;
                updated: string;
                numberOfCartItems: string;
                cart: string;
                order: string;
                savedCart: string;
                emptyStateText: string;
                headerText: string;
            };
            productReviews: {
                columnHeaders: {
                    item: string;
                    dateAndStatus: string;
                    rating: string;
                    review: string;
                };
                header: string;
                emptyDescription: string;
                sku: string;
            };
            supportTickets: {
                columnHeaders: {
                    id: string;
                    headline: string;
                    category: string;
                };
                header: string;
                emptyDescription: string;
            };
            coupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                applied: string;
                removeButtonText: string;
            };
            promotions: {
                headerText: string;
                emptyDescription: string;
                applied: string;
                headerName: string;
                headerAction: string;
            };
            customerCoupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                removeButtonText: string;
                availableTab: string;
                sentTab: string;
                searchBox: string;
            };
            maps: {
                storeClosed: string;
                storesFound: string;
            };
            overviewTab: string;
            profileTab: string;
            activityTab: string;
            feedbackTab: string;
            promotionsTab: string;
            mapsTab: string;
            storeLocationsTab: string;
            aria: {
                activeCartCode: string;
                recentOrderCode: string;
            };
            pagination: string;
            page: string;
            emptyCellValue: string;
        };
    };
};

declare const es: {
    asmCustomer360: {
        asmCustomer360: {
            alertErrorMessage: string;
            errorMessageHeader: string;
            applyActionAlter: string;
            header: {
                title: string;
                newTitle: string;
                subTitle: string;
                newSubTitle: string;
                activeCartLabel: string;
                recentOrderLabel: string;
                recentTicketLabel: string;
                signedUpAt: string;
            };
            productListing: {
                totalNoItems: string;
                totalPrice: string;
                showMore: string;
                showLess: string;
            };
            productItem: {
                outOfStock: string;
                quantity: string;
                itemPrice: string;
            };
            activeCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            savedCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            productInterests: {
                header: string;
                emptyDescription: string;
            };
            profile: {
                address: string;
                billingAddress: string;
                deliveryAddress: string;
                phone1: string;
                phone2: string;
                paymentMethodHeader: string;
            };
            activity: {
                type: string;
                id: string;
                description: string;
                status: string;
                created: string;
                updated: string;
                numberOfCartItems: string;
                cart: string;
                order: string;
                savedCart: string;
                emptyStateText: string;
                headerText: string;
            };
            productReviews: {
                columnHeaders: {
                    item: string;
                    dateAndStatus: string;
                    rating: string;
                    review: string;
                };
                header: string;
                emptyDescription: string;
                sku: string;
            };
            supportTickets: {
                columnHeaders: {
                    id: string;
                    headline: string;
                    category: string;
                };
                header: string;
                emptyDescription: string;
            };
            coupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                applied: string;
                removeButtonText: string;
            };
            promotions: {
                headerText: string;
                emptyDescription: string;
                applied: string;
                headerName: string;
                headerAction: string;
            };
            customerCoupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                removeButtonText: string;
                availableTab: string;
                sentTab: string;
                searchBox: string;
            };
            maps: {
                storeClosed: string;
                storesFound: string;
            };
            overviewTab: string;
            profileTab: string;
            activityTab: string;
            feedbackTab: string;
            promotionsTab: string;
            mapsTab: string;
            storeLocationsTab: string;
            aria: {
                activeCartCode: string;
                recentOrderCode: string;
            };
            pagination: string;
            page: string;
            emptyCellValue: string;
        };
    };
};

declare const es_CO: {
    asmCustomer360: {
        asmCustomer360: {
            alertErrorMessage: string;
            errorMessageHeader: string;
            applyActionAlter: string;
            header: {
                title: string;
                newTitle: string;
                subTitle: string;
                newSubTitle: string;
                activeCartLabel: string;
                recentOrderLabel: string;
                recentTicketLabel: string;
                signedUpAt: string;
            };
            productListing: {
                totalNoItems: string;
                totalPrice: string;
                showMore: string;
                showLess: string;
            };
            productItem: {
                outOfStock: string;
                quantity: string;
                itemPrice: string;
            };
            activeCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            savedCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            productInterests: {
                header: string;
                emptyDescription: string;
            };
            profile: {
                address: string;
                billingAddress: string;
                deliveryAddress: string;
                phone1: string;
                phone2: string;
                paymentMethodHeader: string;
            };
            activity: {
                type: string;
                id: string;
                description: string;
                status: string;
                created: string;
                updated: string;
                numberOfCartItems: string;
                cart: string;
                order: string;
                savedCart: string;
                emptyStateText: string;
                headerText: string;
            };
            productReviews: {
                columnHeaders: {
                    item: string;
                    dateAndStatus: string;
                    rating: string;
                    review: string;
                };
                header: string;
                emptyDescription: string;
                sku: string;
            };
            supportTickets: {
                columnHeaders: {
                    id: string;
                    headline: string;
                    category: string;
                };
                header: string;
                emptyDescription: string;
            };
            coupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                applied: string;
                removeButtonText: string;
            };
            promotions: {
                headerText: string;
                emptyDescription: string;
                applied: string;
                headerName: string;
                headerAction: string;
            };
            customerCoupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                removeButtonText: string;
                availableTab: string;
                sentTab: string;
                searchBox: string;
            };
            maps: {
                storeClosed: string;
                storesFound: string;
            };
            overviewTab: string;
            profileTab: string;
            activityTab: string;
            feedbackTab: string;
            promotionsTab: string;
            mapsTab: string;
            storeLocationsTab: string;
            aria: {
                activeCartCode: string;
                recentOrderCode: string;
            };
            pagination: string;
            page: string;
            emptyCellValue: string;
        };
    };
};

declare const fr: {
    asmCustomer360: {
        asmCustomer360: {
            alertErrorMessage: string;
            errorMessageHeader: string;
            applyActionAlter: string;
            header: {
                title: string;
                newTitle: string;
                subTitle: string;
                newSubTitle: string;
                activeCartLabel: string;
                recentOrderLabel: string;
                recentTicketLabel: string;
                signedUpAt: string;
            };
            productListing: {
                totalNoItems: string;
                totalPrice: string;
                showMore: string;
                showLess: string;
            };
            productItem: {
                outOfStock: string;
                quantity: string;
                itemPrice: string;
            };
            activeCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            savedCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            productInterests: {
                header: string;
                emptyDescription: string;
            };
            profile: {
                address: string;
                billingAddress: string;
                deliveryAddress: string;
                phone1: string;
                phone2: string;
                paymentMethodHeader: string;
            };
            activity: {
                type: string;
                id: string;
                description: string;
                status: string;
                created: string;
                updated: string;
                numberOfCartItems: string;
                cart: string;
                order: string;
                savedCart: string;
                emptyStateText: string;
                headerText: string;
            };
            productReviews: {
                columnHeaders: {
                    item: string;
                    dateAndStatus: string;
                    rating: string;
                    review: string;
                };
                header: string;
                emptyDescription: string;
                sku: string;
            };
            supportTickets: {
                columnHeaders: {
                    id: string;
                    headline: string;
                    category: string;
                };
                header: string;
                emptyDescription: string;
            };
            coupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                applied: string;
                removeButtonText: string;
            };
            promotions: {
                headerText: string;
                emptyDescription: string;
                applied: string;
                headerName: string;
                headerAction: string;
            };
            customerCoupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                removeButtonText: string;
                availableTab: string;
                sentTab: string;
                searchBox: string;
            };
            maps: {
                storeClosed: string;
                storesFound: string;
            };
            overviewTab: string;
            profileTab: string;
            activityTab: string;
            feedbackTab: string;
            promotionsTab: string;
            mapsTab: string;
            storeLocationsTab: string;
            aria: {
                activeCartCode: string;
                recentOrderCode: string;
            };
            pagination: string;
            page: string;
            emptyCellValue: string;
        };
    };
};

declare const hi: {
    asmCustomer360: {
        asmCustomer360: {
            alertErrorMessage: string;
            errorMessageHeader: string;
            applyActionAlter: string;
            header: {
                title: string;
                newTitle: string;
                subTitle: string;
                newSubTitle: string;
                activeCartLabel: string;
                recentOrderLabel: string;
                recentTicketLabel: string;
                signedUpAt: string;
            };
            productListing: {
                totalNoItems: string;
                totalPrice: string;
                showMore: string;
                showLess: string;
            };
            productItem: {
                outOfStock: string;
                quantity: string;
                itemPrice: string;
            };
            activeCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            savedCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            productInterests: {
                header: string;
                emptyDescription: string;
            };
            profile: {
                address: string;
                billingAddress: string;
                deliveryAddress: string;
                phone1: string;
                phone2: string;
                paymentMethodHeader: string;
            };
            activity: {
                type: string;
                id: string;
                description: string;
                status: string;
                created: string;
                updated: string;
                numberOfCartItems: string;
                cart: string;
                order: string;
                savedCart: string;
                emptyStateText: string;
                headerText: string;
            };
            productReviews: {
                columnHeaders: {
                    item: string;
                    dateAndStatus: string;
                    rating: string;
                    review: string;
                };
                header: string;
                emptyDescription: string;
                sku: string;
            };
            supportTickets: {
                columnHeaders: {
                    id: string;
                    headline: string;
                    category: string;
                };
                header: string;
                emptyDescription: string;
            };
            coupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                applied: string;
                removeButtonText: string;
            };
            promotions: {
                headerText: string;
                emptyDescription: string;
                applied: string;
                headerName: string;
                headerAction: string;
            };
            customerCoupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                removeButtonText: string;
                availableTab: string;
                sentTab: string;
                searchBox: string;
            };
            maps: {
                storeClosed: string;
                storesFound: string;
            };
            overviewTab: string;
            profileTab: string;
            activityTab: string;
            feedbackTab: string;
            promotionsTab: string;
            mapsTab: string;
            storeLocationsTab: string;
            aria: {
                activeCartCode: string;
                recentOrderCode: string;
            };
            pagination: string;
            page: string;
            emptyCellValue: string;
        };
    };
};

declare const hu: {
    asmCustomer360: {
        asmCustomer360: {
            alertErrorMessage: string;
            errorMessageHeader: string;
            applyActionAlter: string;
            header: {
                title: string;
                newTitle: string;
                subTitle: string;
                newSubTitle: string;
                activeCartLabel: string;
                recentOrderLabel: string;
                recentTicketLabel: string;
                signedUpAt: string;
            };
            productListing: {
                totalNoItems: string;
                totalPrice: string;
                showMore: string;
                showLess: string;
            };
            productItem: {
                outOfStock: string;
                quantity: string;
                itemPrice: string;
            };
            activeCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            savedCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            productInterests: {
                header: string;
                emptyDescription: string;
            };
            profile: {
                address: string;
                billingAddress: string;
                deliveryAddress: string;
                phone1: string;
                phone2: string;
                paymentMethodHeader: string;
            };
            activity: {
                type: string;
                id: string;
                description: string;
                status: string;
                created: string;
                updated: string;
                numberOfCartItems: string;
                cart: string;
                order: string;
                savedCart: string;
                emptyStateText: string;
                headerText: string;
            };
            productReviews: {
                columnHeaders: {
                    item: string;
                    dateAndStatus: string;
                    rating: string;
                    review: string;
                };
                header: string;
                emptyDescription: string;
                sku: string;
            };
            supportTickets: {
                columnHeaders: {
                    id: string;
                    headline: string;
                    category: string;
                };
                header: string;
                emptyDescription: string;
            };
            coupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                applied: string;
                removeButtonText: string;
            };
            promotions: {
                headerText: string;
                emptyDescription: string;
                applied: string;
                headerName: string;
                headerAction: string;
            };
            customerCoupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                removeButtonText: string;
                availableTab: string;
                sentTab: string;
                searchBox: string;
            };
            maps: {
                storeClosed: string;
                storesFound: string;
            };
            overviewTab: string;
            profileTab: string;
            activityTab: string;
            feedbackTab: string;
            promotionsTab: string;
            mapsTab: string;
            storeLocationsTab: string;
            aria: {
                activeCartCode: string;
                recentOrderCode: string;
            };
            pagination: string;
            page: string;
            emptyCellValue: string;
        };
    };
};

declare const id: {
    asmCustomer360: {
        asmCustomer360: {
            alertErrorMessage: string;
            errorMessageHeader: string;
            applyActionAlter: string;
            header: {
                title: string;
                newTitle: string;
                subTitle: string;
                newSubTitle: string;
                activeCartLabel: string;
                recentOrderLabel: string;
                recentTicketLabel: string;
                signedUpAt: string;
            };
            productListing: {
                totalNoItems: string;
                totalPrice: string;
                showMore: string;
                showLess: string;
            };
            productItem: {
                outOfStock: string;
                quantity: string;
                itemPrice: string;
            };
            activeCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            savedCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            productInterests: {
                header: string;
                emptyDescription: string;
            };
            profile: {
                address: string;
                billingAddress: string;
                deliveryAddress: string;
                phone1: string;
                phone2: string;
                paymentMethodHeader: string;
            };
            activity: {
                type: string;
                id: string;
                description: string;
                status: string;
                created: string;
                updated: string;
                numberOfCartItems: string;
                cart: string;
                order: string;
                savedCart: string;
                emptyStateText: string;
                headerText: string;
            };
            productReviews: {
                columnHeaders: {
                    item: string;
                    dateAndStatus: string;
                    rating: string;
                    review: string;
                };
                header: string;
                emptyDescription: string;
                sku: string;
            };
            supportTickets: {
                columnHeaders: {
                    id: string;
                    headline: string;
                    category: string;
                };
                header: string;
                emptyDescription: string;
            };
            coupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                applied: string;
                removeButtonText: string;
            };
            promotions: {
                headerText: string;
                emptyDescription: string;
                applied: string;
                headerName: string;
                headerAction: string;
            };
            customerCoupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                removeButtonText: string;
                availableTab: string;
                sentTab: string;
                searchBox: string;
            };
            maps: {
                storeClosed: string;
                storesFound: string;
            };
            overviewTab: string;
            profileTab: string;
            activityTab: string;
            feedbackTab: string;
            promotionsTab: string;
            mapsTab: string;
            storeLocationsTab: string;
            aria: {
                activeCartCode: string;
                recentOrderCode: string;
            };
            pagination: string;
            page: string;
            emptyCellValue: string;
        };
    };
};

declare const it: {
    asmCustomer360: {
        asmCustomer360: {
            alertErrorMessage: string;
            errorMessageHeader: string;
            applyActionAlter: string;
            header: {
                title: string;
                newTitle: string;
                subTitle: string;
                newSubTitle: string;
                activeCartLabel: string;
                recentOrderLabel: string;
                recentTicketLabel: string;
                signedUpAt: string;
            };
            productListing: {
                totalNoItems: string;
                totalPrice: string;
                showMore: string;
                showLess: string;
            };
            productItem: {
                outOfStock: string;
                quantity: string;
                itemPrice: string;
            };
            activeCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            savedCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            productInterests: {
                header: string;
                emptyDescription: string;
            };
            profile: {
                address: string;
                billingAddress: string;
                deliveryAddress: string;
                phone1: string;
                phone2: string;
                paymentMethodHeader: string;
            };
            activity: {
                type: string;
                id: string;
                description: string;
                status: string;
                created: string;
                updated: string;
                numberOfCartItems: string;
                cart: string;
                order: string;
                savedCart: string;
                emptyStateText: string;
                headerText: string;
            };
            productReviews: {
                columnHeaders: {
                    item: string;
                    dateAndStatus: string;
                    rating: string;
                    review: string;
                };
                header: string;
                emptyDescription: string;
                sku: string;
            };
            supportTickets: {
                columnHeaders: {
                    id: string;
                    headline: string;
                    category: string;
                };
                header: string;
                emptyDescription: string;
            };
            coupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                applied: string;
                removeButtonText: string;
            };
            promotions: {
                headerText: string;
                emptyDescription: string;
                applied: string;
                headerName: string;
                headerAction: string;
            };
            customerCoupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                removeButtonText: string;
                availableTab: string;
                sentTab: string;
                searchBox: string;
            };
            maps: {
                storeClosed: string;
                storesFound: string;
            };
            overviewTab: string;
            profileTab: string;
            activityTab: string;
            feedbackTab: string;
            promotionsTab: string;
            mapsTab: string;
            storeLocationsTab: string;
            aria: {
                activeCartCode: string;
                recentOrderCode: string;
            };
            pagination: string;
            page: string;
            emptyCellValue: string;
        };
    };
};

declare const ja: {
    asmCustomer360: {
        asmCustomer360: {
            alertErrorMessage: string;
            errorMessageHeader: string;
            applyActionAlter: string;
            header: {
                title: string;
                newTitle: string;
                subTitle: string;
                newSubTitle: string;
                activeCartLabel: string;
                recentOrderLabel: string;
                recentTicketLabel: string;
                signedUpAt: string;
            };
            productListing: {
                totalNoItems: string;
                totalPrice: string;
                showMore: string;
                showLess: string;
            };
            productItem: {
                outOfStock: string;
                quantity: string;
                itemPrice: string;
            };
            activeCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            savedCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            productInterests: {
                header: string;
                emptyDescription: string;
            };
            profile: {
                address: string;
                billingAddress: string;
                deliveryAddress: string;
                phone1: string;
                phone2: string;
                paymentMethodHeader: string;
            };
            activity: {
                type: string;
                id: string;
                description: string;
                status: string;
                created: string;
                updated: string;
                numberOfCartItems: string;
                cart: string;
                order: string;
                savedCart: string;
                emptyStateText: string;
                headerText: string;
            };
            productReviews: {
                columnHeaders: {
                    item: string;
                    dateAndStatus: string;
                    rating: string;
                    review: string;
                };
                header: string;
                emptyDescription: string;
                sku: string;
            };
            supportTickets: {
                columnHeaders: {
                    id: string;
                    headline: string;
                    category: string;
                };
                header: string;
                emptyDescription: string;
            };
            coupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                applied: string;
                removeButtonText: string;
            };
            promotions: {
                headerText: string;
                emptyDescription: string;
                applied: string;
                headerName: string;
                headerAction: string;
            };
            customerCoupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                removeButtonText: string;
                availableTab: string;
                sentTab: string;
                searchBox: string;
            };
            maps: {
                storeClosed: string;
                storesFound: string;
            };
            overviewTab: string;
            profileTab: string;
            activityTab: string;
            feedbackTab: string;
            promotionsTab: string;
            mapsTab: string;
            storeLocationsTab: string;
            aria: {
                activeCartCode: string;
                recentOrderCode: string;
            };
            pagination: string;
            page: string;
            emptyCellValue: string;
        };
    };
};

declare const ko: {
    asmCustomer360: {
        asmCustomer360: {
            alertErrorMessage: string;
            errorMessageHeader: string;
            applyActionAlter: string;
            header: {
                title: string;
                newTitle: string;
                subTitle: string;
                newSubTitle: string;
                activeCartLabel: string;
                recentOrderLabel: string;
                recentTicketLabel: string;
                signedUpAt: string;
            };
            productListing: {
                totalNoItems: string;
                totalPrice: string;
                showMore: string;
                showLess: string;
            };
            productItem: {
                outOfStock: string;
                quantity: string;
                itemPrice: string;
            };
            activeCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            savedCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            productInterests: {
                header: string;
                emptyDescription: string;
            };
            profile: {
                address: string;
                billingAddress: string;
                deliveryAddress: string;
                phone1: string;
                phone2: string;
                paymentMethodHeader: string;
            };
            activity: {
                type: string;
                id: string;
                description: string;
                status: string;
                created: string;
                updated: string;
                numberOfCartItems: string;
                cart: string;
                order: string;
                savedCart: string;
                emptyStateText: string;
                headerText: string;
            };
            productReviews: {
                columnHeaders: {
                    item: string;
                    dateAndStatus: string;
                    rating: string;
                    review: string;
                };
                header: string;
                emptyDescription: string;
                sku: string;
            };
            supportTickets: {
                columnHeaders: {
                    id: string;
                    headline: string;
                    category: string;
                };
                header: string;
                emptyDescription: string;
            };
            coupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                applied: string;
                removeButtonText: string;
            };
            promotions: {
                headerText: string;
                emptyDescription: string;
                applied: string;
                headerName: string;
                headerAction: string;
            };
            customerCoupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                removeButtonText: string;
                availableTab: string;
                sentTab: string;
                searchBox: string;
            };
            maps: {
                storeClosed: string;
                storesFound: string;
            };
            overviewTab: string;
            profileTab: string;
            activityTab: string;
            feedbackTab: string;
            promotionsTab: string;
            mapsTab: string;
            storeLocationsTab: string;
            aria: {
                activeCartCode: string;
                recentOrderCode: string;
            };
            pagination: string;
            page: string;
            emptyCellValue: string;
        };
    };
};

declare const pl: {
    asmCustomer360: {
        asmCustomer360: {
            alertErrorMessage: string;
            errorMessageHeader: string;
            applyActionAlter: string;
            header: {
                title: string;
                newTitle: string;
                subTitle: string;
                newSubTitle: string;
                activeCartLabel: string;
                recentOrderLabel: string;
                recentTicketLabel: string;
                signedUpAt: string;
            };
            productListing: {
                totalNoItems: string;
                totalPrice: string;
                showMore: string;
                showLess: string;
            };
            productItem: {
                outOfStock: string;
                quantity: string;
                itemPrice: string;
            };
            activeCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            savedCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            productInterests: {
                header: string;
                emptyDescription: string;
            };
            profile: {
                address: string;
                billingAddress: string;
                deliveryAddress: string;
                phone1: string;
                phone2: string;
                paymentMethodHeader: string;
            };
            activity: {
                type: string;
                id: string;
                description: string;
                status: string;
                created: string;
                updated: string;
                numberOfCartItems: string;
                cart: string;
                order: string;
                savedCart: string;
                emptyStateText: string;
                headerText: string;
            };
            productReviews: {
                columnHeaders: {
                    item: string;
                    dateAndStatus: string;
                    rating: string;
                    review: string;
                };
                header: string;
                emptyDescription: string;
                sku: string;
            };
            supportTickets: {
                columnHeaders: {
                    id: string;
                    headline: string;
                    category: string;
                };
                header: string;
                emptyDescription: string;
            };
            coupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                applied: string;
                removeButtonText: string;
            };
            promotions: {
                headerText: string;
                emptyDescription: string;
                applied: string;
                headerName: string;
                headerAction: string;
            };
            customerCoupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                removeButtonText: string;
                availableTab: string;
                sentTab: string;
                searchBox: string;
            };
            maps: {
                storeClosed: string;
                storesFound: string;
            };
            overviewTab: string;
            profileTab: string;
            activityTab: string;
            feedbackTab: string;
            promotionsTab: string;
            mapsTab: string;
            storeLocationsTab: string;
            aria: {
                activeCartCode: string;
                recentOrderCode: string;
            };
            pagination: string;
            page: string;
            emptyCellValue: string;
        };
    };
};

declare const pt: {
    asmCustomer360: {
        asmCustomer360: {
            alertErrorMessage: string;
            errorMessageHeader: string;
            applyActionAlter: string;
            header: {
                title: string;
                newTitle: string;
                subTitle: string;
                newSubTitle: string;
                activeCartLabel: string;
                recentOrderLabel: string;
                recentTicketLabel: string;
                signedUpAt: string;
            };
            productListing: {
                totalNoItems: string;
                totalPrice: string;
                showMore: string;
                showLess: string;
            };
            productItem: {
                outOfStock: string;
                quantity: string;
                itemPrice: string;
            };
            activeCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            savedCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            productInterests: {
                header: string;
                emptyDescription: string;
            };
            profile: {
                address: string;
                billingAddress: string;
                deliveryAddress: string;
                phone1: string;
                phone2: string;
                paymentMethodHeader: string;
            };
            activity: {
                type: string;
                id: string;
                description: string;
                status: string;
                created: string;
                updated: string;
                numberOfCartItems: string;
                cart: string;
                order: string;
                savedCart: string;
                emptyStateText: string;
                headerText: string;
            };
            productReviews: {
                columnHeaders: {
                    item: string;
                    dateAndStatus: string;
                    rating: string;
                    review: string;
                };
                header: string;
                emptyDescription: string;
                sku: string;
            };
            supportTickets: {
                columnHeaders: {
                    id: string;
                    headline: string;
                    category: string;
                };
                header: string;
                emptyDescription: string;
            };
            coupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                applied: string;
                removeButtonText: string;
            };
            promotions: {
                headerText: string;
                emptyDescription: string;
                applied: string;
                headerName: string;
                headerAction: string;
            };
            customerCoupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                removeButtonText: string;
                availableTab: string;
                sentTab: string;
                searchBox: string;
            };
            maps: {
                storeClosed: string;
                storesFound: string;
            };
            overviewTab: string;
            profileTab: string;
            activityTab: string;
            feedbackTab: string;
            promotionsTab: string;
            mapsTab: string;
            storeLocationsTab: string;
            aria: {
                activeCartCode: string;
                recentOrderCode: string;
            };
            pagination: string;
            page: string;
            emptyCellValue: string;
        };
    };
};

declare const ru: {
    asmCustomer360: {
        asmCustomer360: {
            alertErrorMessage: string;
            errorMessageHeader: string;
            applyActionAlter: string;
            header: {
                title: string;
                newTitle: string;
                subTitle: string;
                newSubTitle: string;
                activeCartLabel: string;
                recentOrderLabel: string;
                recentTicketLabel: string;
                signedUpAt: string;
            };
            productListing: {
                totalNoItems: string;
                totalPrice: string;
                showMore: string;
                showLess: string;
            };
            productItem: {
                outOfStock: string;
                quantity: string;
                itemPrice: string;
            };
            activeCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            savedCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            productInterests: {
                header: string;
                emptyDescription: string;
            };
            profile: {
                address: string;
                billingAddress: string;
                deliveryAddress: string;
                phone1: string;
                phone2: string;
                paymentMethodHeader: string;
            };
            activity: {
                type: string;
                id: string;
                description: string;
                status: string;
                created: string;
                updated: string;
                numberOfCartItems: string;
                cart: string;
                order: string;
                savedCart: string;
                emptyStateText: string;
                headerText: string;
            };
            productReviews: {
                columnHeaders: {
                    item: string;
                    dateAndStatus: string;
                    rating: string;
                    review: string;
                };
                header: string;
                emptyDescription: string;
                sku: string;
            };
            supportTickets: {
                columnHeaders: {
                    id: string;
                    headline: string;
                    category: string;
                };
                header: string;
                emptyDescription: string;
            };
            coupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                applied: string;
                removeButtonText: string;
            };
            promotions: {
                headerText: string;
                emptyDescription: string;
                applied: string;
                headerName: string;
                headerAction: string;
            };
            customerCoupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                removeButtonText: string;
                availableTab: string;
                sentTab: string;
                searchBox: string;
            };
            maps: {
                storeClosed: string;
                storesFound: string;
            };
            overviewTab: string;
            profileTab: string;
            activityTab: string;
            feedbackTab: string;
            promotionsTab: string;
            mapsTab: string;
            storeLocationsTab: string;
            aria: {
                activeCartCode: string;
                recentOrderCode: string;
            };
            pagination: string;
            page: string;
            emptyCellValue: string;
        };
    };
};

declare const zh: {
    asmCustomer360: {
        asmCustomer360: {
            alertErrorMessage: string;
            errorMessageHeader: string;
            applyActionAlter: string;
            header: {
                title: string;
                newTitle: string;
                subTitle: string;
                newSubTitle: string;
                activeCartLabel: string;
                recentOrderLabel: string;
                recentTicketLabel: string;
                signedUpAt: string;
            };
            productListing: {
                totalNoItems: string;
                totalPrice: string;
                showMore: string;
                showLess: string;
            };
            productItem: {
                outOfStock: string;
                quantity: string;
                itemPrice: string;
            };
            activeCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            savedCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            productInterests: {
                header: string;
                emptyDescription: string;
            };
            profile: {
                address: string;
                billingAddress: string;
                deliveryAddress: string;
                phone1: string;
                phone2: string;
                paymentMethodHeader: string;
            };
            activity: {
                type: string;
                id: string;
                description: string;
                status: string;
                created: string;
                updated: string;
                numberOfCartItems: string;
                cart: string;
                order: string;
                savedCart: string;
                emptyStateText: string;
                headerText: string;
            };
            productReviews: {
                columnHeaders: {
                    item: string;
                    dateAndStatus: string;
                    rating: string;
                    review: string;
                };
                header: string;
                emptyDescription: string;
                sku: string;
            };
            supportTickets: {
                columnHeaders: {
                    id: string;
                    headline: string;
                    category: string;
                };
                header: string;
                emptyDescription: string;
            };
            coupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                applied: string;
                removeButtonText: string;
            };
            promotions: {
                headerText: string;
                emptyDescription: string;
                applied: string;
                headerName: string;
                headerAction: string;
            };
            customerCoupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                removeButtonText: string;
                availableTab: string;
                sentTab: string;
                searchBox: string;
            };
            maps: {
                storeClosed: string;
                storesFound: string;
            };
            overviewTab: string;
            profileTab: string;
            activityTab: string;
            feedbackTab: string;
            promotionsTab: string;
            mapsTab: string;
            storeLocationsTab: string;
            aria: {
                activeCartCode: string;
                recentOrderCode: string;
            };
            pagination: string;
            page: string;
            emptyCellValue: string;
        };
    };
};

declare const zh_TW: {
    asmCustomer360: {
        asmCustomer360: {
            alertErrorMessage: string;
            errorMessageHeader: string;
            applyActionAlter: string;
            header: {
                title: string;
                newTitle: string;
                subTitle: string;
                newSubTitle: string;
                activeCartLabel: string;
                recentOrderLabel: string;
                recentTicketLabel: string;
                signedUpAt: string;
            };
            productListing: {
                totalNoItems: string;
                totalPrice: string;
                showMore: string;
                showLess: string;
            };
            productItem: {
                outOfStock: string;
                quantity: string;
                itemPrice: string;
            };
            activeCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            savedCart: {
                header: string;
                emptyDescription: string;
                aria: {
                    linkLabel: string;
                };
            };
            productInterests: {
                header: string;
                emptyDescription: string;
            };
            profile: {
                address: string;
                billingAddress: string;
                deliveryAddress: string;
                phone1: string;
                phone2: string;
                paymentMethodHeader: string;
            };
            activity: {
                type: string;
                id: string;
                description: string;
                status: string;
                created: string;
                updated: string;
                numberOfCartItems: string;
                cart: string;
                order: string;
                savedCart: string;
                emptyStateText: string;
                headerText: string;
            };
            productReviews: {
                columnHeaders: {
                    item: string;
                    dateAndStatus: string;
                    rating: string;
                    review: string;
                };
                header: string;
                emptyDescription: string;
                sku: string;
            };
            supportTickets: {
                columnHeaders: {
                    id: string;
                    headline: string;
                    category: string;
                };
                header: string;
                emptyDescription: string;
            };
            coupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                applied: string;
                removeButtonText: string;
            };
            promotions: {
                headerText: string;
                emptyDescription: string;
                applied: string;
                headerName: string;
                headerAction: string;
            };
            customerCoupons: {
                headerText: string;
                emptyDescription: string;
                applyButtonText: string;
                removeButtonText: string;
                availableTab: string;
                sentTab: string;
                searchBox: string;
            };
            maps: {
                storeClosed: string;
                storesFound: string;
            };
            overviewTab: string;
            profileTab: string;
            activityTab: string;
            feedbackTab: string;
            promotionsTab: string;
            mapsTab: string;
            storeLocationsTab: string;
            aria: {
                activeCartCode: string;
                recentOrderCode: string;
            };
            pagination: string;
            page: string;
            emptyCellValue: string;
        };
    };
};

declare const asmCustomer360TranslationChunksConfig: TranslationChunksConfig;

export { asmCustomer360TranslationChunksConfig, cs as asmCustomer360TranslationsCs, de as asmCustomer360TranslationsDe, en as asmCustomer360TranslationsEn, es as asmCustomer360TranslationsEs, es_CO as asmCustomer360TranslationsEs_CO, fr as asmCustomer360TranslationsFr, hi as asmCustomer360TranslationsHi, hu as asmCustomer360TranslationsHu, id as asmCustomer360TranslationsId, it as asmCustomer360TranslationsIt, ja as asmCustomer360TranslationsJa, ko as asmCustomer360TranslationsKo, pl as asmCustomer360TranslationsPl, pt as asmCustomer360TranslationsPt, ru as asmCustomer360TranslationsRu, zh as asmCustomer360TranslationsZh, zh_TW as asmCustomer360TranslationsZh_TW };
