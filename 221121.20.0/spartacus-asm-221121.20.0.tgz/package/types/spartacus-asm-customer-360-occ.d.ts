import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AsmCustomer360Adapter } from '@spartacus/asm/customer-360/core';
import { AsmCustomer360Request, AsmCustomer360Response } from '@spartacus/asm/customer-360/root';
import { OccEndpointsService, ConverterService, BaseSiteService, LoggerService, OccEndpoint } from '@spartacus/core';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare class OccAsmCustomer360Adapter implements AsmCustomer360Adapter {
    protected http: HttpClient;
    protected occEndpointsService: OccEndpointsService;
    protected converterService: ConverterService;
    protected baseSiteService: BaseSiteService;
    protected logger: LoggerService;
    private activeBaseSite;
    constructor(http: HttpClient, occEndpointsService: OccEndpointsService, converterService: ConverterService, baseSiteService: BaseSiteService);
    protected getHeaders(): HttpHeaders;
    getAsmCustomer360Data(request: AsmCustomer360Request): Observable<AsmCustomer360Response>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccAsmCustomer360Adapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccAsmCustomer360Adapter>;
}

declare class AsmCustomer360OccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360OccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360OccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360OccModule>;
}

declare module '@spartacus/core' {
    interface OccEndpoints {
        /**
         * Endpoint for customer 360
         *
         * @member {string}
         */
        asmCustomer360?: string | OccEndpoint;
    }
}

export { AsmCustomer360OccModule, OccAsmCustomer360Adapter };
