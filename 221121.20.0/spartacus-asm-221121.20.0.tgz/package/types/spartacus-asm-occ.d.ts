import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AsmAdapter } from '@spartacus/asm/core';
import { AsmConfig, AsmSessionCreationOptions, CustomerListsPage, CustomerSearchOptions, CustomerSearchPage, BindCartParams, CustomerRegistrationForm } from '@spartacus/asm/root';
import { OccEndpointsService, ConverterService, BaseSiteService, LoggerService, UserIdService, User, OccEndpoint } from '@spartacus/core';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare class OccAsmAdapter implements AsmAdapter {
    protected http: HttpClient;
    protected occEndpointsService: OccEndpointsService;
    protected converterService: ConverterService;
    protected config: AsmConfig;
    protected baseSiteService: BaseSiteService;
    private activeBaseSite;
    private currentUserId;
    protected logger: LoggerService;
    protected userIdService: UserIdService;
    constructor(http: HttpClient, occEndpointsService: OccEndpointsService, converterService: ConverterService, config: AsmConfig, baseSiteService: BaseSiteService);
    createAsmSessionEvent(options: AsmSessionCreationOptions): Observable<void>;
    protected getHeaders(): HttpHeaders;
    customerLists(): Observable<CustomerListsPage>;
    customerSearch(options: CustomerSearchOptions): Observable<CustomerSearchPage>;
    bindCart({ cartId, customerId }: BindCartParams): Observable<unknown>;
    createCustomer(user: CustomerRegistrationForm): Observable<User>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccAsmAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccAsmAdapter>;
}

declare class AsmOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmOccModule>;
}

declare module '@spartacus/core' {
    interface OccEndpoints {
        /**
         * Endpoint for asm customer search
         *
         * @member {string}
         */
        asmCustomerSearch?: string | OccEndpoint;
        asmCustomerLists?: string | OccEndpoint;
        asmBindCart?: string | OccEndpoint;
        asmCreateCustomer?: string | OccEndpoint;
        asmSessionEvent?: string | OccEndpoint;
    }
}

export { AsmOccModule, OccAsmAdapter };
