import * as i4 from '@spartacus/storefront';
import { LaunchDialogService, FocusConfig, ICON_TYPE, BreakpointService, BREAKPOINT, DirectionService } from '@spartacus/storefront';
import * as i0 from '@angular/core';
import { OnInit, OnDestroy, ElementRef, EventEmitter, QueryList, ChangeDetectorRef, PipeTransform } from '@angular/core';
import * as _angular_forms from '@angular/forms';
import { ValidatorFn, FormControl, UntypedFormBuilder, UntypedFormGroup, UntypedFormControl, FormBuilder } from '@angular/forms';
import { CsAgentAuthService, AsmEnablerService, AsmDeepLinkService, AsmDeepLinkParameters, AsmBindCartFacade, AsmConfig, AsmCustomerListFacade, CustomerSearchPage, CustomerListsPage, CustomerListColumnActionType, AsmCreateCustomerFacade, CustomerRegistrationForm } from '@spartacus/asm/root';
import { ActiveCartFacade, MultiCartFacade, Cart } from '@spartacus/cart/base/root';
import { SavedCartFacade } from '@spartacus/cart/saved-cart/root';
import * as i3 from '@spartacus/core';
import { AuthService, WindowRef, RoutingService, GlobalMessageService, GlobalMessageType, User, HttpResponseStatus, FeatureModulesService, OAuthLibWrapperService, TranslationService, OccConfig, SortModel, UserIdService, HttpErrorModel } from '@spartacus/core';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
import { AsmDialogActionEvent } from '@spartacus/asm/customer-360/root';
import * as i1 from '@angular/common';
import * as i5 from '@ng-select/ng-select';
import { AsmService } from '@spartacus/asm/core';
import { UserAccountFacade } from '@spartacus/user/account/root';

declare enum BIND_CART_DIALOG_ACTION {
    CANCEL = "CANCEL",
    REPLACE = "REPLACE"
}
declare class AsmBindCartDialogComponent {
    protected launchDialogService: LaunchDialogService;
    BIND_CART_ACTION: typeof BIND_CART_DIALOG_ACTION;
    focusConfig: FocusConfig;
    constructor(launchDialogService: LaunchDialogService);
    closeModal(reason: BIND_CART_DIALOG_ACTION): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmBindCartDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmBindCartDialogComponent, "cx-asm-bind-cart-dialog", never, {}, {}, never, never, true, never>;
}

declare class AsmComponentService {
    protected authService: AuthService;
    protected csAgentAuthService: CsAgentAuthService;
    protected winRef: WindowRef;
    protected asmEnablerService?: AsmEnablerService | undefined;
    protected asmDeepLinkService?: AsmDeepLinkService | undefined;
    protected searchparam: URLSearchParams;
    isEmulatedByDeepLink$: BehaviorSubject<boolean>;
    protected showDeeplinkCartInfoAlert$: BehaviorSubject<boolean>;
    protected routingService: RoutingService;
    constructor(authService: AuthService, csAgentAuthService: CsAgentAuthService, winRef: WindowRef, asmEnablerService?: AsmEnablerService | undefined, asmDeepLinkService?: AsmDeepLinkService | undefined);
    /**
     * Returns a deep link parameter value if it is in the url.
     */
    getSearchParameter(key: string): string | undefined | null;
    isEmulatedByDeepLink(): BehaviorSubject<boolean>;
    setEmulatedByDeepLink(emulated: boolean): void;
    setShowDeeplinkCartInfoAlert(display: boolean): void;
    shouldShowDeeplinkCartInfoAlert(): Observable<boolean>;
    logoutCustomerSupportAgentAndCustomer(): void;
    logoutCustomer(): void;
    isCustomerEmulationSessionInProgress(): Observable<boolean>;
    /**
     * We're currently only removing the persisted storage in the browser
     * to ensure the ASM experience isn't loaded on the next visit. There are a few
     * optimizations we could think of:
     * - drop the `asm` parameter from the URL, in case it's still there
     * - remove the generated UI from the DOM (outlets currently do not support this)
     */
    unload(): void;
    /**
     * check whether try to emulate customer from deeplink
     */
    isEmulateInURL(): boolean;
    /**
     * Returns valid deep link parameters in the url.
     */
    getDeepLinkUrlParams(): AsmDeepLinkParameters | undefined;
    /**
     * Handles the navigation based on deep link parameters in the URL
     * or passed parameter.
     */
    handleDeepLinkNavigation(parameters?: AsmDeepLinkParameters | undefined): void;
    handleAsmDialogAction(event: AsmDialogActionEvent | string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmComponentService>;
}

declare class AsmBindCartComponent implements OnInit, OnDestroy {
    protected globalMessageService: GlobalMessageService;
    protected activeCartFacade: ActiveCartFacade;
    protected multiCartFacade: MultiCartFacade;
    protected asmBindCartFacade: AsmBindCartFacade;
    protected launchDialogService: LaunchDialogService;
    protected savedCartFacade: SavedCartFacade;
    protected asmComponentService?: AsmComponentService | undefined;
    protected routing?: RoutingService | undefined;
    activeCartValidator: ValidatorFn;
    cartId: FormControl<string | null>;
    loading$: BehaviorSubject<boolean>;
    valid$: Observable<boolean>;
    activeCartId: string;
    deepLinkCartId: string;
    displayBindCartBtn$: BehaviorSubject<boolean>;
    displaySaveCartBtn$: BehaviorSubject<boolean>;
    bindToCartElemRef: ElementRef<HTMLButtonElement>;
    saveInactiveCartElemRef: ElementRef<HTMLButtonElement>;
    protected subscription: Subscription;
    constructor(globalMessageService: GlobalMessageService, activeCartFacade: ActiveCartFacade, multiCartFacade: MultiCartFacade, asmBindCartFacade: AsmBindCartFacade, launchDialogService: LaunchDialogService, savedCartFacade: SavedCartFacade, asmComponentService?: AsmComponentService | undefined, routing?: RoutingService | undefined);
    ngOnInit(): void;
    /**
     * Bind the input cart number to the customer
     */
    bindCartToCustomer(): void;
    onSaveInactiveCart(): void;
    clearText(): void;
    protected resetDeeplinkCart(): void;
    ngOnDestroy(): void;
    /**
     * Binds cart on subscription and reloads cart
     */
    protected simpleBindCart(anonymousCartId: string): Observable<unknown>;
    /**
     * Opens dialog and passes non-cancel result to select action
     */
    protected openDialog(activeCartId: string, anonymousCartId: string): Observable<unknown>;
    protected selectBindAction(activeCartId: string, anonymousCartId: string, action: BIND_CART_DIALOG_ACTION): Observable<unknown>;
    protected replaceCart(previousActiveCartId: string, anonymousCartId: string): Observable<unknown>;
    protected subscribeForDeeplinkCart(): void;
    protected openASMSaveCartDialog(inactiveCart: Cart): void;
    protected afterCloseASMSaveCartDialog(): void;
    protected goToSavedCartDetails(cartId: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmBindCartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmBindCartComponent, "cx-asm-bind-cart", never, {}, {}, never, never, true, never>;
}

declare enum SAVE_CART_DIALOG_ACTION {
    CANCEL = "CANCEL",
    SAVE = "SAVE"
}
declare class AsmSaveCartDialogComponent implements OnInit {
    protected launchDialogService: LaunchDialogService;
    protected savedCartFacade: SavedCartFacade;
    BIND_CART_ACTION: typeof SAVE_CART_DIALOG_ACTION;
    showDialogAlert$: BehaviorSubject<boolean>;
    globalMessageType: typeof GlobalMessageType;
    cart: Cart;
    cartQty: number;
    focusConfig: FocusConfig;
    constructor(launchDialogService: LaunchDialogService, savedCartFacade: SavedCartFacade);
    ngOnInit(): void;
    setCartTotalQty(): void;
    closeDialogAlert(): void;
    closeModal(reason: SAVE_CART_DIALOG_ACTION): void;
    protected saveCart(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmSaveCartDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmSaveCartDialogComponent, "cx-asm-save-cart-dialog", never, {}, {}, never, never, true, never>;
}

interface CartTypeKey {
    [key: string]: string;
}
declare const CART_TYPE_KEY: CartTypeKey;
declare class AsmMainUiComponent implements OnInit, OnDestroy {
    protected authService: AuthService;
    protected csAgentAuthService: CsAgentAuthService;
    protected asmComponentService: AsmComponentService;
    protected globalMessageService: GlobalMessageService;
    protected routingService: RoutingService;
    protected asmService: AsmService;
    protected userAccountFacade: UserAccountFacade;
    protected launchDialogService: LaunchDialogService;
    customerSupportAgentLoggedIn$: Observable<boolean>;
    csAgentTokenLoading$: Observable<boolean>;
    customer$: Observable<User | undefined>;
    isCollapsed$: Observable<boolean> | undefined;
    iconTypes: typeof ICON_TYPE;
    forbiddenResponseStatus: HttpResponseStatus;
    showDeeplinkCartInfoAlert$: Observable<boolean>;
    deeplinkCartAlertKey: string;
    showCreateCustomerSuccessfullyAlert: boolean;
    globalMessageType: typeof GlobalMessageType;
    disabled: boolean;
    protected startingCustomerSession: boolean;
    showCustomerEmulationInfoAlert: boolean;
    subscription: Subscription;
    element: ElementRef;
    addNewCustomerLink: ElementRef;
    isAsmCustomer360Configured: boolean | undefined;
    isAsmCustomer360Loaded$: BehaviorSubject<boolean>;
    protected featureModules: FeatureModulesService;
    protected asmConfig: AsmConfig;
    protected oAuthLibWrapperService: OAuthLibWrapperService;
    isAsmSessionConfigured: boolean;
    constructor(authService: AuthService, csAgentAuthService: CsAgentAuthService, asmComponentService: AsmComponentService, globalMessageService: GlobalMessageService, routingService: RoutingService, asmService: AsmService, userAccountFacade: UserAccountFacade, launchDialogService: LaunchDialogService);
    ngOnInit(): void;
    protected showC360Dialog(customer: User | undefined): void;
    /**
     * When agent is logged in and deep link has customerID,
     * call logout if has customer emulated(userLoggedin) but not emulated by deep link.
     * call startSessionWithParameters
     */
    protected subscribeForDeeplink(): void;
    protected confirmSwitchCustomer(switchCustomerId: string): void;
    /**
     * If url contains customerId and we haven't emulatedFromURL, we'll change the isEmulatedByDeepLink flag and
     * start emulate customer in URL.
     */
    protected startSessionWithParameters(parameters: any): void;
    protected handleCustomerSessionStartRedirection(): void;
    loginCustomerSupportAgent({ userId, password, }: {
        userId: string;
        password: string;
    }): void;
    loginCustomerSupportAgentWithAuthorizationCodeFlow(): void;
    logout(): void;
    startCustomerEmulationSession({ customerId }: {
        customerId?: string;
    }, parameters?: AsmDeepLinkParameters): void;
    hideUi(): void;
    showCustomList(): void;
    closeModal(): void;
    createCustomer(): void;
    closeDialogConfirmationAlert(): void;
    closeDeeplinkCartInfoAlert(): void;
    closeCustomerEmulationInfoAlert(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmMainUiComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmMainUiComponent, "cx-asm-main-ui", never, {}, {}, never, never, true, never>;
}

declare class CSAgentLoginFormComponent implements OnInit {
    protected fb: UntypedFormBuilder;
    csAgentLoginForm: UntypedFormGroup;
    csAgentTokenLoading: boolean;
    submitEvent: EventEmitter<{
        userId: string;
        password: string;
    }>;
    constructor(fb: UntypedFormBuilder);
    ngOnInit(): void;
    onSubmit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CSAgentLoginFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CSAgentLoginFormComponent, "cx-csagent-login-form", never, { "csAgentTokenLoading": { "alias": "csAgentTokenLoading"; "required": false; }; }, { "submitEvent": "submitEvent"; }, never, never, true, never>;
}

declare class CustomerListComponent implements OnInit, OnDestroy {
    protected launchDialogService: LaunchDialogService;
    protected breakpointService: BreakpointService;
    protected asmConfig: AsmConfig;
    protected translation: TranslationService;
    protected asmCustomerListFacade: AsmCustomerListFacade;
    protected occConfig?: OccConfig | undefined;
    protected DEFAULT_PAGE_SIZE: number;
    focusConfig: FocusConfig;
    iconTypes: typeof ICON_TYPE;
    BREAKPOINT: typeof BREAKPOINT;
    selectedUserGroupId: string | undefined;
    customerSearchPage$: Observable<CustomerSearchPage | undefined>;
    customerListsPage$: Observable<CustomerListsPage | undefined>;
    selectedCustomer: User;
    currentPage: number;
    maxPage: number;
    loaded: boolean;
    sorts: SortModel[] | null;
    sortCode: string | undefined;
    breakpoint$: Observable<BREAKPOINT>;
    customerListConfig: Required<AsmConfig>['asm']['customerList'];
    customerSearchLoading$: Observable<boolean>;
    customerSearchError$: Observable<boolean>;
    pageSize: number;
    listsError: boolean;
    listsEmpty: boolean;
    enableAsmB2bCustomerList: boolean;
    customerListColumnActionType: typeof CustomerListColumnActionType;
    searchBox: UntypedFormControl;
    forbiddenResponseStatus: HttpResponseStatus;
    protected teardown: Subscription;
    addNewCustomerLink: ElementRef;
    isAsmCustomer360Configured: boolean | undefined;
    protected featureModules: FeatureModulesService;
    constructor(launchDialogService: LaunchDialogService, breakpointService: BreakpointService, asmConfig: AsmConfig, translation: TranslationService, asmCustomerListFacade: AsmCustomerListFacade, occConfig?: OccConfig | undefined);
    ngOnInit(): void;
    ngOnDestroy(): void;
    changePage(page: number): void;
    fetchCustomers(): void;
    private updateCustomerListColumns;
    onChangeCustomerGroup(): void;
    getGroupName(customerListsPage: CustomerListsPage, id: string | undefined): string;
    getBadgeText(customerEntry: User): string;
    startColumnAction(customerEntry: User, action: CustomerListColumnActionType): void;
    onKey(event: KeyboardEvent): void;
    searchCustomers(): void;
    isRequired(customerEntry: User, type: string): boolean;
    changeSortCode(sortCode: string): void;
    goToNextPage(): void;
    goToPreviousPage(): void;
    closeModal(reason?: any): void;
    getSortLabels(): Observable<{
        byNameAsc: string;
        byNameDesc: string;
        byOrderDateAsc: string;
        byOrderDateDesc: string;
        byDateAsc: string;
        byDateDesc: string;
    }>;
    createCustomer(): void;
    private getBreakpoint;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerListComponent, "cx-customer-list", never, {}, {}, never, never, true, never>;
}

declare class CustomerSelectionComponent implements OnInit, OnDestroy {
    protected fb: UntypedFormBuilder;
    protected asmService: AsmService;
    protected config: AsmConfig;
    protected directionService: DirectionService;
    protected launchDialogService: LaunchDialogService;
    customerSelectionForm: UntypedFormGroup;
    protected subscription: Subscription;
    searchResultsLoading$: Observable<boolean>;
    searchResults: Observable<CustomerSearchPage>;
    selectedCustomer: User | undefined;
    searchByCustomer: boolean;
    searchByOrder: boolean;
    isLoading: boolean;
    activeFocusedButtonIndex: number;
    submitEvent: EventEmitter<{
        customerId?: string;
        parameters?: AsmDeepLinkParameters;
    }>;
    resultList: ElementRef;
    searchTerm: ElementRef;
    searchOrder: ElementRef;
    createCustomerLink: ElementRef;
    searchResultItems: QueryList<ElementRef<HTMLElement>>;
    constructor(fb: UntypedFormBuilder, asmService: AsmService, config: AsmConfig, directionService: DirectionService, launchDialogService: LaunchDialogService);
    ngOnInit(): void;
    protected handleSearchTerm(searchTermValue: string): void;
    protected handleSearchByCustomer(searchTermValue: string): void;
    protected handleSearchByOrder(searchOrderValue: string): void;
    isNoResultMessageInfoVisible(results: any, searchFlag: boolean, searchElement: HTMLInputElement): boolean;
    isSearchResultsVisible(results: any, searchFlag: boolean): boolean;
    selectCustomerFromList(event: UIEvent, customer: User): void;
    onSubmit(): void;
    onDocumentClick(event: UIEvent): void;
    closeResults(event: UIEvent): void;
    closeOrderSearchResults(event: UIEvent): void;
    ngOnDestroy(): void;
    /**
     * set focus to the first searched item
     * @param event keyboard event
     */
    focusFirstItem(event: UIEvent): void;
    /**
     * set mouse cursor to the end of search text
     * @param event keyboard event
     */
    setSelectionEnd(event: UIEvent): void;
    /**
     * set mouse cursor to the end of search order text
     * @param event keyboard event
     */
    setOrderSearchSelectionEnd(event: UIEvent): void;
    /**
     * set focus on previous searh result item.  If no previous item then go to end of item.
     * @param event keyboard event
     */
    focusPreviousChild(event: UIEvent): void;
    /**
     * set focus on next searh result item.  if no next item then go to the first item
     * @param event keyboard event
     */
    focusNextChild(event: UIEvent): void;
    /**
     * set focus to input search text
     * @param event keyboard event
     */
    focusInputText(event: KeyboardEvent): void;
    /**
     * set focus to order search input search text
     * @param event keyboard event
     */
    focusOrderSearchInputText(event: KeyboardEvent): void;
    /**
     * set focus to selected item
     * @param {number} selectedIndex - current selected item index
     */
    updateItemIndex(selectedIndex: number): void;
    createCustomer(): void;
    /**
     * Verifies whether the user navigates into a subgroup of the main group menu.
     *
     * @param {KeyboardEvent} event - Keyboard event
     * @returns {boolean} -'true' if the user navigates into the subgroup, otherwise 'false'.
     * @protected
     */
    protected isForwardsNavigation(event: KeyboardEvent): boolean;
    /**
     * Verifies whether the user navigates from a subgroup back to the main group menu.
     *
     * @param {KeyboardEvent} event - Keyboard event
     * @returns {boolean} -'true' if the user navigates back into the main group menu, otherwise 'false'.
     * @protected
     */
    protected isBackNavigation(event: KeyboardEvent): boolean;
    protected isLTRDirection(): boolean;
    protected isRTLDirection(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerSelectionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerSelectionComponent, "cx-customer-selection", never, {}, { "submitEvent": "submitEvent"; }, never, never, true, never>;
}

declare class AsmSessionTimerComponent implements OnInit, OnDestroy {
    protected config: AsmConfig;
    protected asmComponentService: AsmComponentService;
    protected routingService: RoutingService;
    protected changeDetectorRef: ChangeDetectorRef;
    protected userIdService: UserIdService;
    protected subscriptions: Subscription;
    protected interval: any;
    protected maxStartDelayInSeconds: number;
    timeLeft: number;
    expiredTime: number;
    constructor(config: AsmConfig, asmComponentService: AsmComponentService, routingService: RoutingService, changeDetectorRef: ChangeDetectorRef, userIdService: UserIdService);
    ngOnInit(): void;
    protected resetOnNavigate(): void;
    protected resetOnCustomerSessionChange(): void;
    protected initTimer(): void;
    resetTimer(): void;
    protected getTimerStartDelayInSeconds(): number;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmSessionTimerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmSessionTimerComponent, "cx-asm-session-timer", never, {}, {}, never, never, true, never>;
}

declare class FormatTimerPipe implements PipeTransform {
    transform(totalSeconds: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormatTimerPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FormatTimerPipe, "formatTimer", true>;
}

declare class CustomerEmulationComponent implements OnInit, OnDestroy {
    protected asmComponentService: AsmComponentService;
    protected userAccountFacade: UserAccountFacade;
    protected launchDialogService?: LaunchDialogService | undefined;
    protected featureModules?: FeatureModulesService | undefined;
    customer: User;
    isCustomerEmulationSessionInProgress$: Observable<boolean>;
    isAsmCustomer360Configured: boolean | undefined;
    isAsmCustomer360Loaded$: BehaviorSubject<boolean>;
    asmCustomer360LauncherElement: ElementRef;
    protected subscription: Subscription;
    constructor(asmComponentService: AsmComponentService, userAccountFacade: UserAccountFacade, launchDialogService?: LaunchDialogService | undefined, featureModules?: FeatureModulesService | undefined);
    ngOnInit(): void;
    logoutCustomer(): void;
    openAsmCustomer360(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerEmulationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerEmulationComponent, "cx-customer-emulation", never, {}, {}, never, never, true, never>;
}

declare class AsmToggleUiComponent implements OnInit, OnDestroy {
    protected asmService: AsmService;
    protected subscription: Subscription;
    isCollapsed: boolean;
    constructor(asmService: AsmService);
    ngOnInit(): void;
    toggleUi(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmToggleUiComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmToggleUiComponent, "cx-asm-toggle-ui", never, {}, {}, never, never, true, never>;
}

declare enum SWITCH_CUSTOMER_DIALOG_ACTION {
    CANCEL = "CANCEL",
    SWITCH = "SWITCH"
}
interface SwitchCustomerData {
    curCustomer: User;
    switchCustomer: User;
}
declare class AsmSwitchCustomerDialogComponent implements OnInit {
    protected launchDialogService: LaunchDialogService;
    protected asmComponentService: AsmComponentService;
    SWITCH_CUSTOMER_DIALOG_ACTION: typeof SWITCH_CUSTOMER_DIALOG_ACTION;
    focusConfig: FocusConfig;
    curCustomerName: string;
    switchCustomerName: string;
    iconTypes: any;
    constructor(launchDialogService: LaunchDialogService, asmComponentService: AsmComponentService);
    ngOnInit(): void;
    closeModal(reason: SWITCH_CUSTOMER_DIALOG_ACTION): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmSwitchCustomerDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmSwitchCustomerDialogComponent, "cx-asm-switch-customer-dialog", never, {}, {}, never, never, true, never>;
}

declare class DotSpinnerComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<DotSpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DotSpinnerComponent, "cx-dot-spinner", never, {}, {}, never, never, true, never>;
}

interface CreatedCustomer {
    firstName: string;
    lastName: string;
    email: string;
}

declare class AsmCreateCustomerFormComponent {
    protected launchDialogService: LaunchDialogService;
    protected fb: FormBuilder;
    protected asmCreateCustomerFacade: AsmCreateCustomerFacade;
    protected translationService: TranslationService;
    createdCustomer: CreatedCustomer;
    iconTypes: typeof ICON_TYPE;
    isLoading$: BehaviorSubject<boolean>;
    showDialogInfoAlert: boolean;
    globalMessageType: typeof GlobalMessageType;
    showDialogBackendErrorAlerts: boolean[];
    backendErrorMessages: string[];
    focusConfig: FocusConfig;
    registerForm: _angular_forms.FormGroup<{
        firstName: _angular_forms.FormControl<string | null>;
        lastName: _angular_forms.FormControl<string | null>;
        email: _angular_forms.FormControl<string | null>;
    }>;
    constructor(launchDialogService: LaunchDialogService, fb: FormBuilder, asmCreateCustomerFacade: AsmCreateCustomerFacade, translationService: TranslationService);
    submitForm(): void;
    registerUser(): void;
    collectDataFromRegisterForm(): CustomerRegistrationForm;
    closeModal(reason?: unknown): void;
    closeDialogInfoAlert(): void;
    closeDialogBackendErroAlert(index: number): void;
    protected onRegisterUserSuccess(user: User): void;
    protected onRegisterUserFail(error: HttpErrorModel): void;
    protected addErrorMessage(key: string, options?: unknown): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCreateCustomerFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AsmCreateCustomerFormComponent, "cx-asm-create-customer-form", never, {}, {}, never, never, true, never>;
}

declare class AsmComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmComponentsModule, never, [typeof i1.CommonModule, typeof _angular_forms.ReactiveFormsModule, typeof i3.I18nModule, typeof i4.FormErrorsModule, typeof i4.IconModule, typeof i5.NgSelectModule, typeof _angular_forms.FormsModule, typeof i4.SpinnerModule, typeof i4.PasswordVisibilityToggleModule, typeof i4.KeyboardFocusModule, typeof i4.NgSelectA11yModule, typeof i4.SortingModule, typeof i4.PaginationModule, typeof i4.MessageComponentModule, typeof i3.FeaturesConfigModule, typeof AsmBindCartDialogComponent, typeof AsmSaveCartDialogComponent, typeof AsmMainUiComponent, typeof CSAgentLoginFormComponent, typeof CustomerListComponent, typeof CustomerSelectionComponent, typeof AsmSessionTimerComponent, typeof FormatTimerPipe, typeof CustomerEmulationComponent, typeof AsmToggleUiComponent, typeof AsmBindCartComponent, typeof AsmSwitchCustomerDialogComponent, typeof DotSpinnerComponent, typeof AsmCreateCustomerFormComponent], [typeof AsmBindCartDialogComponent, typeof AsmSaveCartDialogComponent, typeof AsmMainUiComponent, typeof CSAgentLoginFormComponent, typeof CustomerListComponent, typeof CustomerSelectionComponent, typeof AsmSessionTimerComponent, typeof FormatTimerPipe, typeof CustomerEmulationComponent, typeof AsmToggleUiComponent, typeof AsmBindCartComponent, typeof AsmSwitchCustomerDialogComponent, typeof DotSpinnerComponent, typeof AsmCreateCustomerFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmComponentsModule>;
}

export { AsmBindCartComponent, AsmBindCartDialogComponent, AsmComponentService, AsmComponentsModule, AsmCreateCustomerFormComponent, AsmMainUiComponent, AsmSaveCartDialogComponent, AsmSessionTimerComponent, AsmSwitchCustomerDialogComponent, AsmToggleUiComponent, BIND_CART_DIALOG_ACTION, CART_TYPE_KEY, CSAgentLoginFormComponent, CustomerEmulationComponent, CustomerListComponent, CustomerSelectionComponent, DotSpinnerComponent, FormatTimerPipe, SAVE_CART_DIALOG_ACTION, SWITCH_CUSTOMER_DIALOG_ACTION };
export type { SwitchCustomerData };
