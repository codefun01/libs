import { User, WindowRef, FeatureModulesService, PaginationModel, SortModel, QueryState, AuthStorageService, StatePersistenceService, AuthToken, AuthService, UserIdService, OAuthLibWrapperService, AuthHttpHeaderService, RoutingService, GlobalMessageService, OccEndpointsService, AuthRedirectService, StateWithClientAuth, AuthMultisiteIsolationService, ProtectedRoutesService, RoutingConfig, UrlParsingService } from '@spartacus/core';
import * as i2 from '@spartacus/storefront';
import { ICON_TYPE, LaunchDialogService } from '@spartacus/storefront';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';
import { Location } from '@angular/common';
import * as i3 from '@angular/router';
import { Observable, BehaviorSubject } from 'rxjs';
import { User as User$1, UserAccountFacade } from '@spartacus/user/account/root';
import { HttpRequest } from '@angular/common/http';
import { Store } from '@ngrx/store';

interface Member {
    name?: string;
    uid?: string;
}
interface UserGroup {
    members?: Array<Member>;
    membersCount?: number;
    name?: string;
    subGroups?: Array<UserGroup>;
    uid?: string;
}
interface CustomerListsPage {
    currentPage?: number;
    numberOfPages?: number;
    pageSize?: number;
    totalNumber?: number;
    userGroups?: Array<UserGroup>;
}
declare enum CustomerListColumnActionType {
    START_SESSION = "START_SESSION",
    ORDER_HISTORY = "ORDER_HISTORY",
    ACTIVE_CART = "ACTIVE_CART",
    CUSTOMER_360 = "CUSTOMER_360"
}

declare abstract class AsmConfig {
    asm?: {
        agentSessionTimer?: {
            startingDelayInSeconds?: number;
        };
        customerSearch?: {
            maxResults?: number;
        };
        customerList?: {
            pageSize?: number;
            showAvatar?: boolean;
            columns?: {
                headerLocalizationKey: string;
                icon?: {
                    symbol?: ICON_TYPE;
                    captionLocalizationKey?: string;
                };
                renderer?: (customer: User) => string;
                actionType?: CustomerListColumnActionType;
            }[];
        };
        asmSessionSupport?: {
            enabled?: boolean;
        };
        userIdHttpHeader?: {
            /**
             * To fix certain features when a customer agent is emulating a user, we must send a header called
             * "sap-commerce-cloud-user-id" to the backend fetching certain data as the user, rather than the
             * agent. However, the header will break instances of Commerce Cloud who do not allow requests with
             * this header. (For example, the configuration "corsfilter.commercewebservices.allowedHeaders" will
             * need to allow it.)
             *
             * Enabling this feature will send the emulated user's IDs on requests that need it as context.
             */
            enable?: boolean;
        };
        createCustomer?: {
            enable?: boolean;
        };
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmConfig>;
}
declare module '@spartacus/core' {
    interface Config extends AsmConfig {
    }
}

declare const ASM_ENABLED_LOCAL_STORAGE_KEY = "asm_enabled";

/**
 * The AsmEnablerService is used to enable ASM for those scenario's
 * where it's actually used. This service is added to avoid any polution
 * of the UI and runtime performance for the ordinary production user.
 */
declare class AsmEnablerService {
    protected location: Location;
    protected winRef: WindowRef;
    protected launchDialogService: LaunchDialogService;
    protected featureModules: FeatureModulesService;
    constructor(location: Location, winRef: WindowRef, launchDialogService: LaunchDialogService, featureModules: FeatureModulesService);
    /**
     * Loads the ASM UI if needed. The ASM UI will be added based on the
     * existence of a URL parameter or previous usage given by local storage.
     */
    load(): void;
    /**
     * Indicates whether the ASM module is enabled.
     */
    isEnabled(): boolean;
    /**
     * Indicates whether ASM is launched through the URL,
     * using the asm flag in the URL.
     */
    protected isLaunched(): boolean;
    /**
     * check whether try to emulate customer from deeplink
     * */
    isEmulateInURL(): boolean;
    /**
     * Evaluates local storage where we persist the usage of ASM.
     */
    protected isUsedBefore(): boolean;
    /**
     * Adds the ASM UI by using the `cx-storefront` outlet.
     */
    protected addUi(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmEnablerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmEnablerService>;
}

/**
 * The ASM loader module takes care of loading the ASM UI
 * only in case there's a reason to do so.
 */
declare class AsmLoaderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmLoaderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmLoaderModule, never, [typeof i1.CommonModule, typeof i2.PageComponentModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmLoaderModule>;
}
/**
 *
 * We do not like to block the UI, which is why we delgate loading of ASM
 * to a real component; the router and state aren't available in an optimized
 * way during the APP_INITIALIZER.
 */
declare function asmFactory(asmEnablerService: AsmEnablerService): () => void;

declare class AsmRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmRootModule, never, [typeof AsmLoaderModule, typeof i2.PageLayoutModule, typeof i3.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmRootModule>;
}

declare abstract class AsmBindCartFacade {
    /**
     * Bind an anonymous cart to the current registered user
     */
    abstract bindCart(cartId: string): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmBindCartFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmBindCartFacade>;
}

interface CustomerRegistrationForm {
    firstName: string;
    lastName: string;
    emailAddress: string;
}

declare abstract class AsmCreateCustomerFacade {
    abstract createCustomer(user: CustomerRegistrationForm): Observable<User$1>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCreateCustomerFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmCreateCustomerFacade>;
}

interface CustomerSearchPage {
    entries: User[];
    pagination?: PaginationModel;
    sorts?: SortModel[];
}
interface CustomerSearchOptions {
    query?: string;
    orderId?: string;
    pageSize?: number;
    customerListId?: string;
    currentPage?: number;
    page?: number;
    sort?: string;
}
interface AsmUi {
    status?: number;
    collapsed?: boolean;
}
declare const CLOSE_DIALOG_REASON: {
    FORBIDDEN: string;
};
interface AsmDeepLinkParameters {
    customerId?: string;
    orderId?: string;
    ticketId?: string;
    cartId?: string;
    cartType?: string;
}
interface AsmSessionCreationOptions {
    eventType: string;
}

declare abstract class AsmCustomerListFacade {
    abstract getCustomerLists(): Observable<CustomerListsPage | undefined>;
    abstract getCustomerListsState(): Observable<QueryState<CustomerListsPage>>;
    abstract customerListCustomersSearch(options: CustomerSearchOptions): void;
    abstract getCustomerListCustomersSearchResults(): Observable<CustomerSearchPage>;
    abstract getCustomerListCustomersSearchResultsLoading(): Observable<boolean>;
    abstract customerListCustomersSearchReset(): void;
    abstract getCustomerListCustomersSearchResultsError(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomerListFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmCustomerListFacade>;
}

declare const ASM_FEATURE = "asm";

declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        ASM_CUSTOMER_LIST = "ASM_CUSTOMER_LIST",
        ASM_BIND_CART = "ASM_BIND_CART",
        ASM_SAVE_CART = "ASM_SAVE_CART",
        ASM_SWITCH_CUSTOMER = "ASM_SWITCH_CUSTOMER",
        ASM_CREATE_CUSTOMER_FORM = "ASM_CREATE_CUSTOMER_FORM"
    }
}

interface BindCartParams {
    cartId: string;
    customerId: string;
}

/**
 * Indicates if auth token is for regular user or CS Agent.
 */
declare enum TokenTarget {
    CSAgent = "CSAgent",
    User = "User"
}
/**
 * With AsmAuthStorageService apart from storing the token we also need to store
 * information for which user is the token (regular user or CS Agent).
 *
 * Overrides `AuthStorageService`.
 */
declare class AsmAuthStorageService extends AuthStorageService {
    protected statePersistenceService?: StatePersistenceService | undefined;
    protected _tokenTarget$: Observable<TokenTarget>;
    /**
     * When CS Agent logs in during regular user session we store the regular
     * user token to restore the session after CS Agent logout.
     *
     * This supports in-store use case when CS Agent want's to quickly help
     * customer and then give an option to customer to continue the process.
     */
    protected emulatedUserToken$: BehaviorSubject<AuthToken | undefined>;
    constructor(statePersistenceService?: StatePersistenceService | undefined);
    protected restorePersistedAsmAuthState(): void;
    /**
     * Get target user for current auth token.
     *
     * @return observable with TokenTarget
     */
    getTokenTarget(): Observable<TokenTarget>;
    /**
     * Set new token target.
     *
     * @param tokenTarget
     */
    setTokenTarget(tokenTarget: TokenTarget): void;
    /**
     * Get token for previously user session, when it was interrupted by CS agent login.
     *
     * @return previously logged in user token.
     */
    getEmulatedUserToken(): AuthToken | undefined;
    /**
     * Get token for previously interrupted user session as observable state.
     *
     * @return observable with previously logged in user token.
     */
    getEmulatedUserTokenState(): Observable<AuthToken | undefined>;
    /**
     * Save user token on CS agent login.
     *
     * @param token
     */
    setEmulatedUserToken(token: AuthToken): void;
    /**
     * Change token target to CS Agent.
     */
    switchTokenTargetToCSAgent(): void;
    /**
     * Change token target to user.
     */
    switchTokenTargetToUser(): void;
    /**
     * When we start emulation from the UI (not by ASM login) we can't restore user session on cs agent logout.
     * Only available solution is to drop session we could restore, to avoid account hijack.
     */
    clearEmulatedUserToken(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmAuthStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmAuthStorageService>;
}

/**
 * Auth service for CS agent. Useful to login/logout agent, start emulation
 * or get information about the status of emulation.
 */
declare class CsAgentAuthService {
    protected authService: AuthService;
    protected authStorageService: AsmAuthStorageService;
    protected userIdService: UserIdService;
    protected oAuthLibWrapperService: OAuthLibWrapperService;
    protected store: Store;
    protected userAccountFacade: UserAccountFacade;
    constructor(authService: AuthService, authStorageService: AsmAuthStorageService, userIdService: UserIdService, oAuthLibWrapperService: OAuthLibWrapperService, store: Store, userAccountFacade: UserAccountFacade);
    /**
     * Loads access token for a customer support agent.
     * @param userId
     * @param password
     */
    authorizeCustomerSupportAgent(userId: string, password: string): Promise<void>;
    /**
     * Loads access token for a customer support agent with authorization code flow.
     */
    authorizeCustomerSupportAgentWhenUseCodeFlow(): Promise<void>;
    /**
     * Starts an ASM customer emulation session.
     * A customer emulation session is stopped by calling logout().
     * @param customerId
     */
    startCustomerEmulationSession(customerId: string): void;
    /**
     * Check if CS agent is currently logged in.
     *
     * @returns observable emitting true when CS agent is logged in or false when not.
     */
    isCustomerSupportAgentLoggedIn(): Observable<boolean>;
    /**
     * Utility function to determine if customer is emulated.
     *
     * @returns observable emitting true when there is active emulation session or false when not.
     */
    isCustomerEmulated(): Observable<boolean>;
    /**
     * Returns the customer support agent's token loading status
     */
    getCustomerSupportAgentTokenLoading(): Observable<boolean>;
    /**
     * Logout a customer support agent.
     */
    logoutCustomerSupportAgent(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CsAgentAuthService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CsAgentAuthService>;
}

/**
 * Overrides `AuthHttpHeaderService` to handle asm calls as well (not only OCC)
 * in cases of normal user session and on customer emulation.
 */
declare class AsmAuthHttpHeaderService extends AuthHttpHeaderService {
    protected authService: AuthService;
    protected authStorageService: AsmAuthStorageService;
    protected csAgentAuthService: CsAgentAuthService;
    protected oAuthLibWrapperService: OAuthLibWrapperService;
    protected routingService: RoutingService;
    protected globalMessageService: GlobalMessageService;
    protected occEndpointsService: OccEndpointsService;
    protected authRedirectService: AuthRedirectService;
    constructor(authService: AuthService, authStorageService: AsmAuthStorageService, csAgentAuthService: CsAgentAuthService, oAuthLibWrapperService: OAuthLibWrapperService, routingService: RoutingService, globalMessageService: GlobalMessageService, occEndpointsService: OccEndpointsService, authRedirectService: AuthRedirectService);
    /**
     * Checks if the authorization header should be added to the request
     *
     *  @override
     */
    shouldAddAuthorizationHeader(request: HttpRequest<any>): boolean;
    /**
     * @override
     *
     * Checks if particular request should be handled by this service.
     */
    shouldCatchError(request: HttpRequest<any>): boolean;
    /**
     * @override
     *
     * Adds `Authorization` header to occ and CS agent requests.
     * For CS agent requests also removes the `cx-use-csagent-token` header (to avoid problems with CORS).
     */
    alterRequest(request: HttpRequest<any>, token?: AuthToken): HttpRequest<any>;
    protected getTokenForRequest(request: HttpRequest<any>, token?: AuthToken): AuthToken | undefined;
    protected shouldUseEmulatedUserToken(request: HttpRequest<any>): boolean;
    protected isCSAgentTokenRequest(request: HttpRequest<any>): boolean;
    /**
     * @override
     *
     * On backend errors indicating expired `refresh_token` we need to logout
     * currently logged in user and CS agent.
     */
    handleExpiredRefreshToken(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmAuthHttpHeaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmAuthHttpHeaderService>;
}

/**
 * Version of AuthService that is working for both user na CS agent.
 * Overrides AuthService when ASM module is enabled.
 */
declare class AsmAuthService extends AuthService {
    protected store: Store<StateWithClientAuth>;
    protected userIdService: UserIdService;
    protected oAuthLibWrapperService: OAuthLibWrapperService;
    protected authStorageService: AsmAuthStorageService;
    protected authRedirectService: AuthRedirectService;
    protected globalMessageService: GlobalMessageService;
    protected routingService: RoutingService;
    protected authMultisiteIsolationService?: AuthMultisiteIsolationService | undefined;
    constructor(store: Store<StateWithClientAuth>, userIdService: UserIdService, oAuthLibWrapperService: OAuthLibWrapperService, authStorageService: AsmAuthStorageService, authRedirectService: AuthRedirectService, globalMessageService: GlobalMessageService, routingService: RoutingService, authMultisiteIsolationService?: AuthMultisiteIsolationService | undefined);
    /**
     * After being redirected back from the authorization server, processes the OAuth
     * callback. When using the ASM client (agent login flow triggered by early login /
     * route guard), the token is set as a CS Agent token and the agent is considered
     * logged in without requiring a second "Sign In as Agent" click.
     */
    checkOAuthParamsInUrl(): Promise<void>;
    protected canUserLogin(): boolean;
    protected warnAboutLoggedCSAgent(): void;
    /**
     * Loads a new user token with Resource Owner Password Flow when CS agent is not logged in.
     * @param userId
     * @param password
     */
    loginWithCredentials(userId: string, password: string): Promise<void>;
    /**
     * Initialize Implicit/Authorization Code flow by redirecting to OAuth server when CS agent is not logged in.
     *
     * When a CS Agent is already logged in but not emulating a customer, guards
     * that check `isUserLoggedIn()` (e.g. CheckoutAuthGuard) may still route the
     * user through /login. In that case, redirect to the homepage instead of
     * showing "Cannot login as user" — the CS Agent is authenticated and should
     * proceed from the home page (they can emulate a customer via the ASM banner).
     */
    loginWithRedirect(): boolean;
    /**
     * True when there is an active CS Agent session (token present + tokenTarget=CSAgent).
     */
    protected isCsAgentActive(): boolean;
    /**
     * Revokes tokens and clears state for logged user (tokens, userId).
     * To perform logout it is best to use `logout` method. Use this method with caution.
     */
    coreLogout(): Promise<any>;
    /**
     * Returns `true` if user is logged in or being emulated.
     */
    isUserLoggedIn(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmAuthService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmAuthService>;
}

declare class AsmDeepLinkService {
    protected routingService: RoutingService;
    protected winRef: WindowRef;
    protected asmEnablerService: AsmEnablerService;
    protected searchParams: URLSearchParams;
    constructor(routingService: RoutingService, winRef: WindowRef, asmEnablerService: AsmEnablerService);
    /**
     * check whether try to emulate customer from deeplink
     */
    isEmulateInURL(): boolean;
    /**
     * Returns a deep link parameter value if it is in the url.
     */
    getSearchParameter(key: string): string | undefined;
    /**
     * Handles the navigation based on deep link parameters in the URL
     * or passed parameters.
     */
    handleNavigation(parameters?: AsmDeepLinkParameters): void;
    /**
     * Returns valid deep link parameters in the url.
     */
    getParamsInUrl(): AsmDeepLinkParameters;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmDeepLinkService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmDeepLinkService>;
}

/**
 * Extends `ProtectedRoutesService` to allow CS Agent to bypass URL protection.
 *
 * When CS Agent is logged in, all URLs are considered non-protected,
 * allowing access to CMS pages without customer emulation.
 *
 * Overrides `ProtectedRoutesService` when ASM module is enabled.
 */
declare class AsmProtectedRoutesService extends ProtectedRoutesService {
    protected config: RoutingConfig;
    protected urlParsingService: UrlParsingService;
    protected csAgentAuthService: CsAgentAuthService;
    /**
     * When CS Agent is logged in, URLs are not protected.
     * Otherwise, delegates to the parent implementation.
     */
    isUrlProtected(urlSegments: string[]): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmProtectedRoutesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmProtectedRoutesService>;
}

export { ASM_ENABLED_LOCAL_STORAGE_KEY, ASM_FEATURE, AsmAuthHttpHeaderService, AsmAuthService, AsmAuthStorageService, AsmBindCartFacade, AsmConfig, AsmCreateCustomerFacade, AsmCustomerListFacade, AsmDeepLinkService, AsmEnablerService, AsmLoaderModule, AsmProtectedRoutesService, AsmRootModule, CLOSE_DIALOG_REASON, CsAgentAuthService, CustomerListColumnActionType, TokenTarget, asmFactory };
export type { AsmDeepLinkParameters, AsmSessionCreationOptions, AsmUi, BindCartParams, CustomerListsPage, CustomerRegistrationForm, CustomerSearchOptions, CustomerSearchPage, Member, UserGroup };
