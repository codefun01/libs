import * as i0 from '@angular/core';
import { Type } from '@angular/core';
import * as i1 from '@spartacus/storefront';
import { Observable } from 'rxjs';
import { Region, Country, Address, User, UrlCommand } from '@spartacus/core';

declare class AsmCustomer360RootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360RootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360RootModule, never, [typeof i1.PageComponentModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360RootModule>;
}

declare abstract class AsmCustomer360SectionConfig {
    pageSize?: number;
}

declare class AsmCustomer360SectionData<Data> {
    data: Data;
    constructor(data: Data);
}

interface AsmCustomer360Review {
    productName: string;
    productCode: string;
    createdAt: string;
    updatedAt: string;
    rating: string;
    reviewStatus: string;
    reviewText: string;
    localizedReviewStatus: string;
}
interface AsmCustomer360ActivityStatus {
    code: string;
    name: string;
}
interface AsmCustomer360ActivityType {
    code: string;
    name: string;
}
interface AsmCustomer360Activity {
    type: AsmCustomer360ActivityType;
    associatedTypeId: string;
    description: string;
    status?: AsmCustomer360ActivityStatus;
    createdAt: string;
    updatedAt: string;
}
interface AsmCustomer360Coupon {
    applied: boolean;
    code: string;
    name?: string;
}
interface AsmCustomer360Promotion {
    applied: boolean;
    code: string;
    name?: string;
    message?: string;
}
interface AsmCustomer360CustomerCoupon {
    code: string;
    name?: string;
    description?: string;
}
interface C360TicketStatus {
    code: string;
    name: string;
}
interface C360TicketCategory {
    code: string;
    name: string;
}
interface AsmCustomer360SupportTicket {
    id: string;
    subject: string;
    category: C360TicketCategory;
    createdAt: string;
    updatedAt: string;
    status: C360TicketStatus;
}
declare enum AsmCustomer360Type {
    REVIEW_LIST = "c360ReviewList",
    STORE_LOCATION = "c360StoreLocation",
    PRODUCT_INTEREST_LIST = "c360CustomerProductInterestList",
    SUPPORT_TICKET_LIST = "c360TicketList",
    CUSTOMER_PROFILE = "c360CustomerProfile",
    ACTIVE_CART = "c360Cart",
    SAVED_CART = "c360SavedCart",
    OVERVIEW = "c360Overview",
    ACTIVITY_LIST = "c360ActivityList",
    COUPON_LIST = "c360CouponList",
    PROMOTION_LIST = "c360PromotionList",
    CUSTOMER_COUPON_LIST = "c360CustomerCouponList"
}
interface AsmCustomer360SupportTicketList {
    type: AsmCustomer360Type.SUPPORT_TICKET_LIST;
    tickets: Array<AsmCustomer360SupportTicket>;
}
interface AsmCustomer360ReviewList {
    type: AsmCustomer360Type.REVIEW_LIST;
    reviews: Array<AsmCustomer360Review>;
}
interface AsmCustomer360StoreLocation {
    type: AsmCustomer360Type.STORE_LOCATION;
    address: string;
}
interface AsmCustomer360Address {
    id?: string;
    line1?: string;
    line2?: string;
    town?: string;
    region?: Region;
    country?: Country;
}
interface AsmCustomerCardType {
    code?: string;
    name?: string;
}
interface AsmCustomer360PaymentDetail {
    id?: string;
    cardType?: AsmCustomerCardType;
    cardNumber?: string;
    expiryMonth?: string;
    expiryYear?: string;
    defaultPayment?: boolean;
}
declare enum PaymentCardCode {
    VISA = "visa",
    MASTER = "master",
    MASTERCARD_EUROCARD = "mastercard_eurocard",
    DINERS = "diners",
    AMEX = "amex"
}
declare enum KeyBoardEventCode {
    ARROW_LEFT = "ArrowLeft",
    ARROW_RIGHT = "ArrowRight",
    ARROW_DOWN = "ArrowDown",
    ARROW_UP = "ArrowUp",
    HOME = "Home",
    END = "End",
    PAGE_DOWN = "PageDown",
    PAGE_UP = "PageUp"
}
interface AsmCustomer360Profile {
    billingAddress?: AsmCustomer360Address;
    deliveryAddress?: AsmCustomer360Address;
    phone1?: string;
    phone2?: string;
    paymentDetails?: AsmCustomer360PaymentDetail[];
}
interface AsmCustomer360CustomerProfile {
    type: AsmCustomer360Type.CUSTOMER_PROFILE;
    profile?: AsmCustomer360Profile;
}
interface AsmCustomer360ProductInterestList {
    type: AsmCustomer360Type.PRODUCT_INTEREST_LIST;
    customerProductInterests: Array<{
        product: {
            code: string;
        };
    }>;
}
interface AsmCustomer360CartEntry {
    quantity: number;
    basePrice: string;
    totalPrice: string;
    productCode: string;
}
interface CustomerCart {
    code?: string;
    totalPrice?: string;
    totalItemCount?: number;
    entries?: Array<AsmCustomer360CartEntry>;
}
interface AsmCustomer360ActiveCart {
    type: AsmCustomer360Type.ACTIVE_CART;
    cart?: CustomerCart;
}
interface AsmCustomer360SavedCart {
    type: AsmCustomer360Type.SAVED_CART;
    savedCart?: CustomerCart;
}
interface AsmCustomer360Avatar {
    url?: string;
    format?: string;
}
interface AsmCustomerOverview {
    address?: Address;
    name?: string;
    cartSize?: number;
    cartCode?: string;
    latestOrderTotal?: string;
    latestOrderCode?: string;
    latestOrderTime?: string;
    latestOpenedTicketId?: string;
    latestOpenedTicketCreatedAt?: string;
    email?: string;
    signedUpAt?: string;
    defaultShippingAddress?: Address;
    userAvatar?: AsmCustomer360Avatar;
}
interface AsmCustomer360Overview {
    type: AsmCustomer360Type.OVERVIEW;
    overview?: AsmCustomerOverview;
}
interface AsmCustomer360ActivityList {
    type: AsmCustomer360Type.ACTIVITY_LIST;
    activities: Array<AsmCustomer360Activity>;
}
interface AsmCustomer360CouponList {
    type: AsmCustomer360Type.COUPON_LIST;
    coupons: Array<AsmCustomer360Coupon>;
}
interface AsmCustomer360PromotionList {
    type: AsmCustomer360Type.PROMOTION_LIST;
    promotions: Array<AsmCustomer360Promotion>;
}
interface AsmCustomer360CustomerCouponList {
    type: AsmCustomer360Type.CUSTOMER_COUPON_LIST;
    customerCoupons: Array<AsmCustomer360CustomerCoupon>;
}
interface AsmCustomer360Params {
    userId: string;
}
interface AdditionalRequestParameters {
    timeout?: number;
    listSize?: number;
    searchQuery?: string;
    assignable?: boolean;
}
interface AsmCustomer360Query {
    type?: AsmCustomer360Type | string;
    additionalRequestParameters?: AdditionalRequestParameters;
}
interface AsmCustomer360Request {
    queries: Array<AsmCustomer360Query>;
    options: AsmCustomer360Params;
}
type AsmCustomer360Data = AsmCustomer360ActiveCart | AsmCustomer360ProductInterestList | AsmCustomer360ReviewList | AsmCustomer360StoreLocation | AsmCustomer360SupportTicketList | AsmCustomer360CustomerProfile | AsmCustomer360SavedCart | AsmCustomer360Overview | AsmCustomer360ActivityList | AsmCustomer360CouponList | AsmCustomer360PromotionList | AsmCustomer360CustomerCouponList;
interface AsmCustomer360Response {
    value: Array<AsmCustomer360Data>;
}
declare enum AsmDialogActionType {
    NAVIGATE = "NAVIGATE"
}
interface AsmDialogActionEvent {
    selectedUser: User;
    actionType: AsmDialogActionType;
    route?: UrlCommand;
}

interface AsmCustomer360TabComponent {
    component?: Type<unknown>;
    /** Data that can be associated to a component used to fetch information from a backend. */
    requestData?: AsmCustomer360Query;
    config?: AsmCustomer360SectionConfig;
}
declare abstract class AsmCustomer360TabConfig {
    components: Array<AsmCustomer360TabComponent>;
    i18nNameKey: string;
}

declare abstract class AsmCustomer360TabsConfig {
    tabs?: Array<AsmCustomer360TabConfig>;
    dateFormat?: string;
    dateTimeFormat?: string;
}

declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        ASM_CUSTOMER_360 = "ASM_CUSTOMER_360"
    }
}

declare abstract class AsmCustomer360Facade {
    abstract get360Data(components: Array<AsmCustomer360TabComponent>): Observable<AsmCustomer360Response | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360Facade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmCustomer360Facade>;
}

declare const ASM_CUSTOMER_360_FEATURE = "asmCustomer360";
declare const ASM_CUSTOMER_360_CORE_FEATURE = "asmCustomer360Core";

export { ASM_CUSTOMER_360_CORE_FEATURE, ASM_CUSTOMER_360_FEATURE, AsmCustomer360Facade, AsmCustomer360RootModule, AsmCustomer360SectionConfig, AsmCustomer360SectionData, AsmCustomer360TabConfig, AsmCustomer360TabsConfig, AsmCustomer360Type, AsmDialogActionType, KeyBoardEventCode, PaymentCardCode };
export type { AdditionalRequestParameters, AsmCustomer360ActiveCart, AsmCustomer360Activity, AsmCustomer360ActivityList, AsmCustomer360ActivityStatus, AsmCustomer360ActivityType, AsmCustomer360Address, AsmCustomer360Avatar, AsmCustomer360CartEntry, AsmCustomer360Coupon, AsmCustomer360CouponList, AsmCustomer360CustomerCoupon, AsmCustomer360CustomerCouponList, AsmCustomer360CustomerProfile, AsmCustomer360Data, AsmCustomer360Overview, AsmCustomer360Params, AsmCustomer360PaymentDetail, AsmCustomer360ProductInterestList, AsmCustomer360Profile, AsmCustomer360Promotion, AsmCustomer360PromotionList, AsmCustomer360Query, AsmCustomer360Request, AsmCustomer360Response, AsmCustomer360Review, AsmCustomer360ReviewList, AsmCustomer360SavedCart, AsmCustomer360StoreLocation, AsmCustomer360SupportTicket, AsmCustomer360SupportTicketList, AsmCustomer360TabComponent, AsmCustomerCardType, AsmCustomerOverview, AsmDialogActionEvent, C360TicketCategory, C360TicketStatus, CustomerCart };
