import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import { AsmCustomer360Response, AsmCustomer360Request, AsmCustomer360Facade, AsmCustomer360TabComponent, AsmDialogActionType, AsmDialogActionEvent } from '@spartacus/asm/customer-360/root';
import { Converter, CommandService, Command, User, UrlCommand } from '@spartacus/core';
import { Observable } from 'rxjs';
import * as i1 from '@spartacus/storefinder';
import { UserAccountFacade } from '@spartacus/user/account/root';

declare const ASM_CUSTOMER_360_NORMALIZER: InjectionToken<Converter<any, AsmCustomer360Response>>;

declare abstract class AsmCustomer360Adapter {
    /**
     * Fetches data needed for certain ASM components.
     */
    abstract getAsmCustomer360Data(request: AsmCustomer360Request): Observable<AsmCustomer360Response>;
}

declare class AsmCustomer360Connector {
    protected asmCustomer360Adapter: AsmCustomer360Adapter;
    constructor(asmCustomer360Adapter: AsmCustomer360Adapter);
    getAsmCustomer360Data(request: AsmCustomer360Request): Observable<AsmCustomer360Response>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360Connector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmCustomer360Connector>;
}

declare class AsmCustomer360CoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360CoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCustomer360CoreModule, never, [typeof i1.StoreFinderModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCustomer360CoreModule>;
}

declare class AsmCustomer360Service implements AsmCustomer360Facade {
    protected commandService: CommandService;
    protected asmCustomer360Connector: AsmCustomer360Connector;
    protected userAccountFacade: UserAccountFacade;
    protected asmCustomer360Command$: Command<Array<AsmCustomer360TabComponent>, AsmCustomer360Response>;
    constructor(commandService: CommandService, asmCustomer360Connector: AsmCustomer360Connector, userAccountFacade: UserAccountFacade);
    get360Data(components: Array<AsmCustomer360TabComponent>): Observable<AsmCustomer360Response | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomer360Service, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmCustomer360Service>;
}

/**
 * Return event from ASM dialog action
 */
declare function getAsmDialogActionEvent(customerEntry: User, action: AsmDialogActionType, route?: UrlCommand): AsmDialogActionEvent;

export { ASM_CUSTOMER_360_NORMALIZER, AsmCustomer360Adapter, AsmCustomer360Connector, AsmCustomer360CoreModule, AsmCustomer360Service, getAsmDialogActionEvent };
