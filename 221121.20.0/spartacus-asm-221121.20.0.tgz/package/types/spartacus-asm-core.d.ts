import * as i0 from '@angular/core';
import { InjectionToken, OnDestroy, PipeTransform } from '@angular/core';
import * as i3 from '@ngrx/store';
import { Action, MemoizedSelector, Store } from '@ngrx/store';
import { AsmUi, CustomerSearchOptions, CustomerSearchPage, AsmSessionCreationOptions, CustomerListsPage, BindCartParams, CustomerRegistrationForm, AsmAuthStorageService, TokenTarget, AsmCreateCustomerFacade, AsmCustomerListFacade } from '@spartacus/asm/root';
import * as i2 from '@spartacus/core';
import { StateUtils, ErrorAction, User, Converter, StatePersistenceService, AuthToken, CommandService, Command, QueryService, Query, QueryState } from '@spartacus/core';
import { Observable, Subscription } from 'rxjs';
import * as i1 from '@angular/common';
import * as i4 from '@ngrx/effects';

declare const ASM_UI_UPDATE = "[Asm] UI Update";
declare class AsmUiUpdate implements Action {
    payload: AsmUi;
    readonly type = "[Asm] UI Update";
    constructor(payload: AsmUi);
}
type AsmUiAction = AsmUiUpdate;

declare const CUSTOMER_SEARCH = "[Asm] Customer Search";
declare const CUSTOMER_SEARCH_FAIL = "[Asm] Customer Search Fail";
declare const CUSTOMER_SEARCH_SUCCESS = "[Asm] Customer Search Success";
declare const CUSTOMER_SEARCH_RESET = "[Asm] Customer Search Reset";
declare const CUSTOMER_LIST_CUSTOMERS_SEARCH = "[Asm] Customer List Customers Search";
declare const CUSTOMER_LIST_CUSTOMERS_SEARCH_FAIL = "[Asm] Customer List Customers Search Fail";
declare const CUSTOMER_LIST_CUSTOMERS_SEARCH_SUCCESS = "[Asm] Customer List Customers Search Success";
declare const CUSTOMER_LIST_CUSTOMERS_SEARCH_RESET = "[Asm] Customer List Customers Search Reset";
declare class CustomerSearch extends StateUtils.LoaderLoadAction {
    payload: CustomerSearchOptions;
    readonly type = "[Asm] Customer Search";
    constructor(payload: CustomerSearchOptions);
}
declare class CustomerSearchFail extends StateUtils.LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Asm] Customer Search Fail";
    constructor(payload: any);
}
declare class CustomerSearchSuccess extends StateUtils.LoaderSuccessAction {
    payload: CustomerSearchPage;
    readonly type = "[Asm] Customer Search Success";
    constructor(payload: CustomerSearchPage);
}
declare class CustomerSearchReset extends StateUtils.LoaderResetAction {
    readonly type = "[Asm] Customer Search Reset";
    constructor();
}
declare class CustomerListCustomersSearch extends StateUtils.LoaderLoadAction {
    payload: CustomerSearchOptions;
    readonly type = "[Asm] Customer List Customers Search";
    constructor(payload: CustomerSearchOptions);
}
declare class CustomerListCustomersSearchFail extends StateUtils.LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Asm] Customer List Customers Search Fail";
    constructor(payload: any);
}
declare class CustomerListCustomersSearchSuccess extends StateUtils.LoaderSuccessAction {
    payload: CustomerSearchPage;
    readonly type = "[Asm] Customer List Customers Search Success";
    constructor(payload: CustomerSearchPage);
}
declare class CustomerListCustomersSearchReset extends StateUtils.LoaderResetAction {
    readonly type = "[Asm] Customer List Customers Search Reset";
    constructor();
}
type CustomerAction = CustomerSearch | CustomerSearchFail | CustomerSearchSuccess | CustomerSearchReset | CustomerListCustomersSearch | CustomerListCustomersSearchFail | CustomerListCustomersSearchSuccess | CustomerListCustomersSearchReset;

declare const LOGOUT_CUSTOMER_SUPPORT_AGENT = "[Auth] Logout Customer Support Agent";
/**
 * Action dispatched after customer support agent logout. Used to clear store data (ui, search results)
 */
declare class LogoutCustomerSupportAgent implements Action {
    readonly type = "[Auth] Logout Customer Support Agent";
}

declare const customerGroup_actions_d_ASM_UI_UPDATE: typeof ASM_UI_UPDATE;
type customerGroup_actions_d_AsmUiAction = AsmUiAction;
type customerGroup_actions_d_AsmUiUpdate = AsmUiUpdate;
declare const customerGroup_actions_d_AsmUiUpdate: typeof AsmUiUpdate;
declare const customerGroup_actions_d_CUSTOMER_LIST_CUSTOMERS_SEARCH: typeof CUSTOMER_LIST_CUSTOMERS_SEARCH;
declare const customerGroup_actions_d_CUSTOMER_LIST_CUSTOMERS_SEARCH_FAIL: typeof CUSTOMER_LIST_CUSTOMERS_SEARCH_FAIL;
declare const customerGroup_actions_d_CUSTOMER_LIST_CUSTOMERS_SEARCH_RESET: typeof CUSTOMER_LIST_CUSTOMERS_SEARCH_RESET;
declare const customerGroup_actions_d_CUSTOMER_LIST_CUSTOMERS_SEARCH_SUCCESS: typeof CUSTOMER_LIST_CUSTOMERS_SEARCH_SUCCESS;
declare const customerGroup_actions_d_CUSTOMER_SEARCH: typeof CUSTOMER_SEARCH;
declare const customerGroup_actions_d_CUSTOMER_SEARCH_FAIL: typeof CUSTOMER_SEARCH_FAIL;
declare const customerGroup_actions_d_CUSTOMER_SEARCH_RESET: typeof CUSTOMER_SEARCH_RESET;
declare const customerGroup_actions_d_CUSTOMER_SEARCH_SUCCESS: typeof CUSTOMER_SEARCH_SUCCESS;
type customerGroup_actions_d_CustomerAction = CustomerAction;
type customerGroup_actions_d_CustomerListCustomersSearch = CustomerListCustomersSearch;
declare const customerGroup_actions_d_CustomerListCustomersSearch: typeof CustomerListCustomersSearch;
type customerGroup_actions_d_CustomerListCustomersSearchFail = CustomerListCustomersSearchFail;
declare const customerGroup_actions_d_CustomerListCustomersSearchFail: typeof CustomerListCustomersSearchFail;
type customerGroup_actions_d_CustomerListCustomersSearchReset = CustomerListCustomersSearchReset;
declare const customerGroup_actions_d_CustomerListCustomersSearchReset: typeof CustomerListCustomersSearchReset;
type customerGroup_actions_d_CustomerListCustomersSearchSuccess = CustomerListCustomersSearchSuccess;
declare const customerGroup_actions_d_CustomerListCustomersSearchSuccess: typeof CustomerListCustomersSearchSuccess;
type customerGroup_actions_d_CustomerSearch = CustomerSearch;
declare const customerGroup_actions_d_CustomerSearch: typeof CustomerSearch;
type customerGroup_actions_d_CustomerSearchFail = CustomerSearchFail;
declare const customerGroup_actions_d_CustomerSearchFail: typeof CustomerSearchFail;
type customerGroup_actions_d_CustomerSearchReset = CustomerSearchReset;
declare const customerGroup_actions_d_CustomerSearchReset: typeof CustomerSearchReset;
type customerGroup_actions_d_CustomerSearchSuccess = CustomerSearchSuccess;
declare const customerGroup_actions_d_CustomerSearchSuccess: typeof CustomerSearchSuccess;
declare const customerGroup_actions_d_LOGOUT_CUSTOMER_SUPPORT_AGENT: typeof LOGOUT_CUSTOMER_SUPPORT_AGENT;
type customerGroup_actions_d_LogoutCustomerSupportAgent = LogoutCustomerSupportAgent;
declare const customerGroup_actions_d_LogoutCustomerSupportAgent: typeof LogoutCustomerSupportAgent;
declare namespace customerGroup_actions_d {
  export { customerGroup_actions_d_ASM_UI_UPDATE as ASM_UI_UPDATE, customerGroup_actions_d_AsmUiUpdate as AsmUiUpdate, customerGroup_actions_d_CUSTOMER_LIST_CUSTOMERS_SEARCH as CUSTOMER_LIST_CUSTOMERS_SEARCH, customerGroup_actions_d_CUSTOMER_LIST_CUSTOMERS_SEARCH_FAIL as CUSTOMER_LIST_CUSTOMERS_SEARCH_FAIL, customerGroup_actions_d_CUSTOMER_LIST_CUSTOMERS_SEARCH_RESET as CUSTOMER_LIST_CUSTOMERS_SEARCH_RESET, customerGroup_actions_d_CUSTOMER_LIST_CUSTOMERS_SEARCH_SUCCESS as CUSTOMER_LIST_CUSTOMERS_SEARCH_SUCCESS, customerGroup_actions_d_CUSTOMER_SEARCH as CUSTOMER_SEARCH, customerGroup_actions_d_CUSTOMER_SEARCH_FAIL as CUSTOMER_SEARCH_FAIL, customerGroup_actions_d_CUSTOMER_SEARCH_RESET as CUSTOMER_SEARCH_RESET, customerGroup_actions_d_CUSTOMER_SEARCH_SUCCESS as CUSTOMER_SEARCH_SUCCESS, customerGroup_actions_d_CustomerListCustomersSearch as CustomerListCustomersSearch, customerGroup_actions_d_CustomerListCustomersSearchFail as CustomerListCustomersSearchFail, customerGroup_actions_d_CustomerListCustomersSearchReset as CustomerListCustomersSearchReset, customerGroup_actions_d_CustomerListCustomersSearchSuccess as CustomerListCustomersSearchSuccess, customerGroup_actions_d_CustomerSearch as CustomerSearch, customerGroup_actions_d_CustomerSearchFail as CustomerSearchFail, customerGroup_actions_d_CustomerSearchReset as CustomerSearchReset, customerGroup_actions_d_CustomerSearchSuccess as CustomerSearchSuccess, customerGroup_actions_d_LOGOUT_CUSTOMER_SUPPORT_AGENT as LOGOUT_CUSTOMER_SUPPORT_AGENT, customerGroup_actions_d_LogoutCustomerSupportAgent as LogoutCustomerSupportAgent };
  export type { customerGroup_actions_d_AsmUiAction as AsmUiAction, customerGroup_actions_d_CustomerAction as CustomerAction };
}

declare const ASSISTED_SESSION_CREATION = "[Asm] Assisted Session Event creation";
declare const ASSISTED_SESSION_CREATION_FAIL = "[Asm] Assisted Session Event creation Fail";
declare const ASSISTED_SESSION_CREATION_SUCCESS = "[Asm] Assisted Session Event creation Success";
declare class AsmSessionCreationAction extends StateUtils.LoaderLoadAction {
    payload: AsmSessionCreationOptions;
    readonly type = "[Asm] Assisted Session Event creation";
    constructor(payload: AsmSessionCreationOptions);
}
declare class AsmSessionCreationFail extends StateUtils.LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Asm] Assisted Session Event creation Fail";
    constructor(payload: any);
}
declare class AsmSessionCreationSuccess extends StateUtils.LoaderSuccessAction {
    readonly type = "[Asm] Assisted Session Event creation Success";
    constructor();
}
type AsmSessionAction = AsmSessionCreationAction | AsmSessionCreationFail | AsmSessionCreationSuccess;

declare const asmSessionActions_d_ASSISTED_SESSION_CREATION: typeof ASSISTED_SESSION_CREATION;
declare const asmSessionActions_d_ASSISTED_SESSION_CREATION_FAIL: typeof ASSISTED_SESSION_CREATION_FAIL;
declare const asmSessionActions_d_ASSISTED_SESSION_CREATION_SUCCESS: typeof ASSISTED_SESSION_CREATION_SUCCESS;
type asmSessionActions_d_AsmSessionAction = AsmSessionAction;
type asmSessionActions_d_AsmSessionCreationAction = AsmSessionCreationAction;
declare const asmSessionActions_d_AsmSessionCreationAction: typeof AsmSessionCreationAction;
type asmSessionActions_d_AsmSessionCreationFail = AsmSessionCreationFail;
declare const asmSessionActions_d_AsmSessionCreationFail: typeof AsmSessionCreationFail;
type asmSessionActions_d_AsmSessionCreationSuccess = AsmSessionCreationSuccess;
declare const asmSessionActions_d_AsmSessionCreationSuccess: typeof AsmSessionCreationSuccess;
declare namespace asmSessionActions_d {
  export { asmSessionActions_d_ASSISTED_SESSION_CREATION as ASSISTED_SESSION_CREATION, asmSessionActions_d_ASSISTED_SESSION_CREATION_FAIL as ASSISTED_SESSION_CREATION_FAIL, asmSessionActions_d_ASSISTED_SESSION_CREATION_SUCCESS as ASSISTED_SESSION_CREATION_SUCCESS, asmSessionActions_d_AsmSessionCreationAction as AsmSessionCreationAction, asmSessionActions_d_AsmSessionCreationFail as AsmSessionCreationFail, asmSessionActions_d_AsmSessionCreationSuccess as AsmSessionCreationSuccess };
  export type { asmSessionActions_d_AsmSessionAction as AsmSessionAction };
}

declare const ASM_FEATURE = "asm";
declare const CUSTOMER_SEARCH_DATA = "[asm] Customer search data";
declare const CUSTOMER_LIST_CUSTOMERS_SEARCH_DATA = "[asm] Customer list customers search data";
interface StateWithAsm {
    [ASM_FEATURE]: AsmState;
}
interface AsmState {
    customerSearchResult: StateUtils.LoaderState<CustomerSearchPage>;
    customerListCustomersSearchResult: StateUtils.LoaderState<CustomerSearchPage>;
    asmUi: AsmUi;
}

declare abstract class AsmAdapter {
    /**
     * Abstract function used to search for customers.
     */
    abstract customerSearch(options: CustomerSearchOptions): Observable<CustomerSearchPage>;
    /**
     * Abstract function used to get customer lists.
     */
    abstract customerLists(): Observable<CustomerListsPage>;
    /**
     * Used to bind an anonymous cart to a registered user.
     */
    abstract bindCart(options: BindCartParams): Observable<unknown>;
    /**
     * Abstract function used to create an account for customers.
     */
    abstract createCustomer(user: CustomerRegistrationForm): Observable<User>;
    /**
     * Abstract function used to create ASM session event.
     */
    abstract createAsmSessionEvent(options: AsmSessionCreationOptions): Observable<void>;
}

declare class AsmConnector {
    protected asmAdapter: AsmAdapter;
    constructor(asmAdapter: AsmAdapter);
    customerSearch(options: CustomerSearchOptions): Observable<CustomerSearchPage>;
    customerLists(): Observable<CustomerListsPage>;
    bindCart(options: BindCartParams): Observable<unknown>;
    createCustomer(user: CustomerRegistrationForm): Observable<User>;
    createAsmSessionEvent(options: AsmSessionCreationOptions): Observable<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmConnector>;
}

declare const CUSTOMER_SEARCH_PAGE_NORMALIZER: InjectionToken<Converter<any, CustomerSearchPage>>;
declare const CUSTOMER_LISTS_NORMALIZER: InjectionToken<Converter<any, CustomerListsPage>>;

declare const getAsmUi: MemoizedSelector<StateWithAsm, AsmUi>;

declare const getCustomerSearchResultsLoaderState: MemoizedSelector<StateWithAsm, StateUtils.LoaderState<CustomerSearchPage>>;
declare const getCustomerSearchResults: MemoizedSelector<StateWithAsm, CustomerSearchPage>;
declare const getCustomerSearchResultsLoading: MemoizedSelector<StateWithAsm, boolean>;
declare const getCustomerListCustomersSearchResultsLoaderState: MemoizedSelector<StateWithAsm, StateUtils.LoaderState<CustomerSearchPage>>;
declare const getCustomerListCustomersSearchResults: MemoizedSelector<StateWithAsm, CustomerSearchPage>;
declare const getCustomerListCustomersSearchResultsLoading: MemoizedSelector<StateWithAsm, boolean>;
declare const getCustomerListCustomersSearchResultsError: MemoizedSelector<StateWithAsm, boolean>;

declare const getAsmState: MemoizedSelector<StateWithAsm, AsmState>;

declare const asmGroup_selectors_d_getAsmState: typeof getAsmState;
declare const asmGroup_selectors_d_getAsmUi: typeof getAsmUi;
declare const asmGroup_selectors_d_getCustomerListCustomersSearchResults: typeof getCustomerListCustomersSearchResults;
declare const asmGroup_selectors_d_getCustomerListCustomersSearchResultsError: typeof getCustomerListCustomersSearchResultsError;
declare const asmGroup_selectors_d_getCustomerListCustomersSearchResultsLoaderState: typeof getCustomerListCustomersSearchResultsLoaderState;
declare const asmGroup_selectors_d_getCustomerListCustomersSearchResultsLoading: typeof getCustomerListCustomersSearchResultsLoading;
declare const asmGroup_selectors_d_getCustomerSearchResults: typeof getCustomerSearchResults;
declare const asmGroup_selectors_d_getCustomerSearchResultsLoaderState: typeof getCustomerSearchResultsLoaderState;
declare const asmGroup_selectors_d_getCustomerSearchResultsLoading: typeof getCustomerSearchResultsLoading;
declare namespace asmGroup_selectors_d {
  export {
    asmGroup_selectors_d_getAsmState as getAsmState,
    asmGroup_selectors_d_getAsmUi as getAsmUi,
    asmGroup_selectors_d_getCustomerListCustomersSearchResults as getCustomerListCustomersSearchResults,
    asmGroup_selectors_d_getCustomerListCustomersSearchResultsError as getCustomerListCustomersSearchResultsError,
    asmGroup_selectors_d_getCustomerListCustomersSearchResultsLoaderState as getCustomerListCustomersSearchResultsLoaderState,
    asmGroup_selectors_d_getCustomerListCustomersSearchResultsLoading as getCustomerListCustomersSearchResultsLoading,
    asmGroup_selectors_d_getCustomerSearchResults as getCustomerSearchResults,
    asmGroup_selectors_d_getCustomerSearchResultsLoaderState as getCustomerSearchResultsLoaderState,
    asmGroup_selectors_d_getCustomerSearchResultsLoading as getCustomerSearchResultsLoading,
  };
}

/**
 * ASM state synced to browser storage.
 */
interface SyncedAsmState {
    ui?: AsmUi;
    emulatedUserToken?: AuthToken;
    tokenTarget?: TokenTarget;
}
/**
 * Responsible for storing ASM state in the browser storage.
 * Uses `StatePersistenceService` mechanism.
 */
declare class AsmStatePersistenceService implements OnDestroy {
    protected statePersistenceService: StatePersistenceService;
    protected store: Store<StateWithAsm>;
    protected authStorageService: AsmAuthStorageService;
    protected subscription: Subscription;
    constructor(statePersistenceService: StatePersistenceService, store: Store<StateWithAsm>, authStorageService: AsmAuthStorageService);
    /**
     * Identifier used for storage key.
     */
    protected key: string;
    /**
     * Initializes the synchronization between state and browser storage.
     */
    initSync(): void;
    /**
     * Gets and transforms state from different sources into the form that should
     * be saved in storage.
     */
    protected getAsmState(): Observable<SyncedAsmState>;
    /**
     * Function called on each browser storage read.
     * Used to update state from browser -> state.
     */
    protected onRead(state: SyncedAsmState | undefined): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmStatePersistenceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmStatePersistenceService>;
}

declare class AsmStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmStoreModule, never, [typeof i1.CommonModule, typeof i2.StateModule, typeof i3.StoreFeatureModule, typeof i4.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmStoreModule>;
}

declare function asmStatePersistenceFactory(asmStatePersistenceService: AsmStatePersistenceService): () => void;
declare class AsmCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AsmCoreModule, never, [typeof i1.CommonModule, typeof AsmStoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AsmCoreModule>;
}

declare class AsmCreateCustomerService implements AsmCreateCustomerFacade {
    protected asmConnector: AsmConnector;
    protected command: CommandService;
    protected createCustomerCommand: Command<{
        user: CustomerRegistrationForm;
    }, User>;
    constructor(asmConnector: AsmConnector, command: CommandService);
    createCustomer(user: CustomerRegistrationForm): Observable<User>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCreateCustomerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmCreateCustomerService>;
}

declare class AsmCustomerListService implements AsmCustomerListFacade {
    protected queryService: QueryService;
    protected asmConnector: AsmConnector;
    protected store: Store<StateWithAsm>;
    protected customerListQuery$: Query<CustomerListsPage>;
    constructor(queryService: QueryService, asmConnector: AsmConnector, store: Store<StateWithAsm>);
    getCustomerLists(): Observable<CustomerListsPage | undefined>;
    getCustomerListsState(): Observable<QueryState<CustomerListsPage>>;
    /**
     * Search for customers in a customer list
     */
    customerListCustomersSearch(options: CustomerSearchOptions): void;
    /**
     * Returns the customer search result data for a customer list
     */
    getCustomerListCustomersSearchResults(): Observable<CustomerSearchPage>;
    /**
     * Returns the customer list customers search result loading status.
     */
    getCustomerListCustomersSearchResultsLoading(): Observable<boolean>;
    /**
     * Reset the customer list customers search result data to the initial state.
     */
    customerListCustomersSearchReset(): void;
    /**
     * Returns the customer list customers search result error status.
     */
    getCustomerListCustomersSearchResultsError(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmCustomerListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmCustomerListService>;
}

declare class AsmService {
    protected store: Store<StateWithAsm>;
    constructor(store: Store<StateWithAsm>);
    /**
     * Search for customers
     * @param options
     */
    customerSearch(options: CustomerSearchOptions): void;
    /**
     * Reset the customer search result data to the initial state.
     */
    customerSearchReset(): void;
    /**
     * Returns the customer search result data.
     */
    getCustomerSearchResults(): Observable<CustomerSearchPage>;
    /**
     * Returns the customer search result loading status.
     */
    getCustomerSearchResultsLoading(): Observable<boolean>;
    /**
     * Updates the state of the ASM UI
     */
    updateAsmUiState(asmUi: AsmUi): void;
    /**
     * Get the state of the ASM UI
     */
    getAsmUiState(): Observable<AsmUi>;
    /**
     * Get the state of the ASM UI
     */
    createAsmSessionEvent(options: AsmSessionCreationOptions): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AsmService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AsmService>;
}

/**
 * Use this pipe when you want to apply a (preferably) pure function (i.e. a function that doesn't use "this")
 *
 * Doing so is more efficient than directly calling the function in the template file because
 * the pipe will re-execute during a detection cycle only when the arguments have changed.
 *
 * ex:
 *
 * my-component.component.ts:
 * ```
 *   unfilteredArray = ['a', 'b', 'c', 'd', 'e']
 *   targetStrings = ['a', 'b', 'c'];
 *
 *    filterArrayByString(array: Array<string>, targetString: string): Array<string> {
 *     return array.filter((element) => element === targetString);
 *   }
 * ```
 *
 * my-component.component.html:
 * ```
 *   <div *ngFor="let targetString of targetStrings">
 *     <app-some-component [filteredArray]="filterArrayByString | cxArgs: unfilteredArray : targetString">
 *  </div>
 * ```
 */
declare class ArgsPipe implements PipeTransform {
    transform<A extends Array<any>, R>(projectionFunction: (...arglist: A) => R, ...args: A): R;
    static ɵfac: i0.ɵɵFactoryDeclaration<ArgsPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ArgsPipe, "cxArgs", true>;
}

declare class ArgsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ArgsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ArgsModule, never, [typeof ArgsPipe], [typeof ArgsPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ArgsModule>;
}

type ComparatorResult = -1 | 0 | 1;
/**
 * Comparison function for use in javascript sort algorithms
 *
 * @returns `-1` if item `a` should be first, `0` if they are equal, and `1` if `b` should be first
 */
type Comparator<T> = (a: T, b: T) => -1 | 0 | 1;
declare enum SortOrder {
    /** "Least" first */
    ASC = 1,
    /** "Greatest" first */
    DESC = -1
}

/**
 * Sort using basic comparison. Ascending is true first
 */
declare function byBoolean(ordering?: SortOrder): Comparator<boolean>;
/**
 * True first
 */
declare const byBooleanTrueFirst: Comparator<boolean>;

/**
 * Sort using basic comparison. Ascending is smaller items first
 */
declare function byComparison<T>(ordering?: SortOrder): Comparator<T>;
/**
 * Smaller objects first
 */
declare const byComparisonAscending: Comparator<unknown>;

/**
 * Sorts based on items being nullish or not.  Ascending is nullish items first.
 */
declare function byNullish<T>(ordering?: SortOrder): Comparator<T>;
declare const byNullishFirst: Comparator<unknown>;
declare const byNullishLast: Comparator<unknown>;

/**
 * Compare numbers. Ascending is smaller numbers first
 */
declare function byNumber(ordering?: SortOrder): Comparator<number>;
/**
 * Small numbers first
 */
declare const byNumberAscending: Comparator<number>;
/**
 * Large numbers first
 */
declare const byNumberDescending: Comparator<number>;

/**
 * Compare strings using `String.localeCompare()`.  Ascending is alphabetical (a-z)
 *
 * Note: Nullish items are treated as an empty string.
 */
declare function byString(ordering?: SortOrder, locales?: string | Array<string>, opts?: Intl.CollatorOptions): Comparator<string>;
/**
 * Alphabetical a-z using `String.localeCompare()`
 *
 * Note: Nullish items are treated as an empty string.
 */
declare const byStringAscending: Comparator<string>;

/**
 * Sort an object using multiple sort criteria
 */
declare function itemsWith<T>(...fns: Array<Comparator<T>>): (a: T, b: T) => -1 | 0 | 1;
/**
 * Allows you to compose multiple sort comparators
 */
declare const byMultiple: typeof itemsWith;

/**
 * Sort using specified item's property and comparator
 */
declare function property<T, P extends keyof T>(prop: P, comparator: Comparator<T[P]>): Comparator<T>;
declare function property<T, P1 extends keyof T, P2 extends keyof T[P1]>(prop1: P1, prop2: P2, comparator: Comparator<T[P1][P2]>): Comparator<T>;

declare const isString: (x: unknown) => x is string;
declare const isNumber: (x: unknown) => x is number;
declare const isBoolean: (x: unknown) => x is boolean;

/**
 * Tests both values with type guard and uses comparator if both match the type.
 *
 * If either value fails the type guard, they values are considered equal.
 */
declare function whenType<T, S extends T>(typeGuard: (value: T) => value is S, comparator: Comparator<S>): Comparator<T>;

export { ASM_FEATURE, ArgsModule, ArgsPipe, customerGroup_actions_d as AsmActions, AsmAdapter, AsmConnector, AsmCoreModule, AsmCreateCustomerService, AsmCustomerListService, asmGroup_selectors_d as AsmSelectors, AsmService, asmSessionActions_d as AsmSessionActions, AsmStatePersistenceService, CUSTOMER_LISTS_NORMALIZER, CUSTOMER_LIST_CUSTOMERS_SEARCH_DATA, CUSTOMER_SEARCH_DATA, CUSTOMER_SEARCH_PAGE_NORMALIZER, SortOrder, asmStatePersistenceFactory, byBoolean, byBooleanTrueFirst, byComparison, byComparisonAscending, byMultiple, byNullish, byNullishFirst, byNullishLast, byNumber, byNumberAscending, byNumberDescending, byString, byStringAscending, isBoolean, isNumber, isString, itemsWith, property, whenType };
export type { AsmState, Comparator, ComparatorResult, StateWithAsm, SyncedAsmState };
