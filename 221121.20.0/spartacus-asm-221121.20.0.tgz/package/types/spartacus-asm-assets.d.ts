import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    asm: {
        asm: {
            mainLogoLabel: string;
            mainTitle: string;
            logout: string;
            hideUi: string;
            helpPortalUrl: string;
            customers: string;
            asmCustomer360Button: string;
            asmCustomer360ViewButton: string;
            createCustomerSuccessfullyAlert: string;
            saveInactiveCartAlertInfo: string;
            activeCartAlertInfo: string;
            startCustomerEmulationAlertInfo: string;
            toggleUi: {
                collapse: string;
                expand: string;
            };
            loginForm: {
                submit: string;
                userId: {
                    label: string;
                };
                password: {
                    label: string;
                };
            };
            customerSearch: {
                searchTerm: {
                    label: string;
                };
                searchCustomer: {
                    label: string;
                };
                searchOrder: {
                    label: string;
                };
                submit: string;
                startEmulation: string;
                noMatch: string;
                noMatchResult: string;
                noCustomerMatchResult: string;
                noOrderMatchResult: string;
                createCustomer: string;
                customer: string;
                orderID: string;
            };
            createCustomerForm: {
                title: string;
                createAccount: string;
                cancel: string;
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                emailAddress: {
                    label: string;
                    placeholder: string;
                };
                createAccountAlert: string;
                validationErrors: {
                    firstName: string;
                    lastName: string;
                    emailAddress: string;
                };
                badRequestDuplicatedEmail: string;
            };
            customerList: {
                title: string;
                description: string;
                createCustomer: string;
                cancel: string;
                tableHeader: {
                    customer: string;
                    customerName: string;
                    name: string;
                    email: string;
                    emailId: string;
                    phone: string;
                    account: string;
                    cart: string;
                    order: string;
                    view: string;
                    activeCart: string;
                    viewActiveCart: string;
                    orders: string;
                    viewOrders: string;
                    customer360: string;
                    viewCustomer360: string;
                };
                tableSort: {
                    sortBy: string;
                    byName: string;
                    byNameAsc: string;
                    byNameDesc: string;
                    byDateAsc: string;
                    byDateDesc: string;
                    byOrderDateAsc: string;
                    byOrderDateDesc: string;
                    byUnit: string;
                    byUnitDesc: string;
                };
                page: {
                    page: string;
                    previous: string;
                    next: string;
                };
                noOfCustomers: string;
                oneCustomer: string;
                noCustomers: string;
                noLists: string;
                listsError: string;
                searchBox: string;
                enterSearchBox: string;
            };
            switchCustomer: {
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        switch: string;
                    };
                };
            };
            saveCart: {
                saveCartBtn: string;
                dialog: {
                    saveInfo: string;
                    disableInfo: string;
                    title: string;
                    row: {
                        id: string;
                        qty: string;
                        qtyFull: string;
                        total: string;
                    };
                    actions: {
                        save: string;
                    };
                };
            };
            bindCart: {
                cartNumber: string;
                bindCartToCustomer: string;
                success: string;
                assignCartId: string;
                enterCartId: string;
                resetCartId: string;
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        replace: string;
                    };
                };
            };
            csagentTokenExpired: string;
            endSession: string;
            endEmulation: string;
            agentSessionTimer: {
                label: string;
                minutes: string;
                reset: string;
            };
            auth: {
                agentLoggedInError: string;
            };
            error: {
                noCustomerId: string;
            };
        };
    };
};

declare const de: {
    asm: {
        asm: {
            mainLogoLabel: string;
            mainTitle: string;
            logout: string;
            hideUi: string;
            helpPortalUrl: string;
            customers: string;
            asmCustomer360Button: string;
            asmCustomer360ViewButton: string;
            createCustomerSuccessfullyAlert: string;
            saveInactiveCartAlertInfo: string;
            activeCartAlertInfo: string;
            startCustomerEmulationAlertInfo: string;
            toggleUi: {
                collapse: string;
                expand: string;
            };
            loginForm: {
                submit: string;
                userId: {
                    label: string;
                };
                password: {
                    label: string;
                };
            };
            customerSearch: {
                searchTerm: {
                    label: string;
                };
                searchCustomer: {
                    label: string;
                };
                searchOrder: {
                    label: string;
                };
                submit: string;
                startEmulation: string;
                noMatch: string;
                noMatchResult: string;
                noCustomerMatchResult: string;
                noOrderMatchResult: string;
                createCustomer: string;
                customer: string;
                orderID: string;
            };
            createCustomerForm: {
                title: string;
                createAccount: string;
                cancel: string;
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                emailAddress: {
                    label: string;
                    placeholder: string;
                };
                createAccountAlert: string;
                validationErrors: {
                    firstName: string;
                    lastName: string;
                    emailAddress: string;
                };
                badRequestDuplicatedEmail: string;
            };
            customerList: {
                title: string;
                description: string;
                createCustomer: string;
                cancel: string;
                tableHeader: {
                    customer: string;
                    customerName: string;
                    name: string;
                    email: string;
                    emailId: string;
                    phone: string;
                    account: string;
                    cart: string;
                    order: string;
                    view: string;
                    activeCart: string;
                    viewActiveCart: string;
                    orders: string;
                    viewOrders: string;
                    customer360: string;
                    viewCustomer360: string;
                };
                tableSort: {
                    sortBy: string;
                    byName: string;
                    byNameAsc: string;
                    byNameDesc: string;
                    byDateAsc: string;
                    byDateDesc: string;
                    byOrderDateAsc: string;
                    byOrderDateDesc: string;
                    byUnit: string;
                    byUnitDesc: string;
                };
                page: {
                    page: string;
                    previous: string;
                    next: string;
                };
                noOfCustomers: string;
                oneCustomer: string;
                noCustomers: string;
                noLists: string;
                listsError: string;
                searchBox: string;
                enterSearchBox: string;
            };
            switchCustomer: {
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        switch: string;
                    };
                };
            };
            saveCart: {
                saveCartBtn: string;
                dialog: {
                    saveInfo: string;
                    disableInfo: string;
                    title: string;
                    row: {
                        id: string;
                        qty: string;
                        qtyFull: string;
                        total: string;
                    };
                    actions: {
                        save: string;
                    };
                };
            };
            bindCart: {
                cartNumber: string;
                bindCartToCustomer: string;
                success: string;
                assignCartId: string;
                enterCartId: string;
                resetCartId: string;
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        replace: string;
                    };
                };
            };
            csagentTokenExpired: string;
            endSession: string;
            endEmulation: string;
            agentSessionTimer: {
                label: string;
                minutes: string;
                reset: string;
            };
            auth: {
                agentLoggedInError: string;
            };
            error: {
                noCustomerId: string;
            };
        };
    };
};

declare const en: {
    asm: {
        asm: {
            mainLogoLabel: string;
            mainTitle: string;
            logout: string;
            hideUi: string;
            helpPortalUrl: string;
            customers: string;
            asmCustomer360Button: string;
            asmCustomer360ViewButton: string;
            asmSignIn: string;
            createCustomerSuccessfullyAlert: string;
            saveInactiveCartAlertInfo: string;
            activeCartAlertInfo: string;
            startCustomerEmulationAlertInfo: string;
            toggleUi: {
                collapse: string;
                expand: string;
            };
            loginForm: {
                submit: string;
                userId: {
                    label: string;
                };
                password: {
                    label: string;
                };
            };
            customerSearch: {
                searchTerm: {
                    label: string;
                };
                searchCustomer: {
                    label: string;
                };
                searchOrder: {
                    label: string;
                };
                submit: string;
                startEmulation: string;
                noMatch: string;
                noMatchResult: string;
                noCustomerMatchResult: string;
                noOrderMatchResult: string;
                createCustomer: string;
                customer: string;
                orderID: string;
            };
            createCustomerForm: {
                title: string;
                createAccount: string;
                cancel: string;
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                emailAddress: {
                    label: string;
                    placeholder: string;
                };
                createAccountAlert: string;
                validationErrors: {
                    firstName: string;
                    lastName: string;
                    emailAddress: string;
                };
                badRequestDuplicatedEmail: string;
            };
            customerList: {
                title: string;
                description: string;
                createCustomer: string;
                cancel: string;
                tableHeader: {
                    customer: string;
                    customerName: string;
                    name: string;
                    email: string;
                    emailId: string;
                    phone: string;
                    account: string;
                    cart: string;
                    order: string;
                    view: string;
                    activeCart: string;
                    viewActiveCart: string;
                    orders: string;
                    viewOrders: string;
                    customer360: string;
                    viewCustomer360: string;
                };
                tableSort: {
                    sortBy: string;
                    byName: string;
                    byNameAsc: string;
                    byNameDesc: string;
                    byDateAsc: string;
                    byDateDesc: string;
                    byOrderDateAsc: string;
                    byOrderDateDesc: string;
                    byUnit: string;
                    byUnitDesc: string;
                };
                page: {
                    page: string;
                    previous: string;
                    next: string;
                };
                noOfCustomers: string;
                oneCustomer: string;
                noCustomers: string;
                noLists: string;
                listsError: string;
                searchBox: string;
                enterSearchBox: string;
            };
            switchCustomer: {
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        switch: string;
                    };
                };
            };
            saveCart: {
                saveCartBtn: string;
                dialog: {
                    saveInfo: string;
                    disableInfo: string;
                    title: string;
                    row: {
                        id: string;
                        qty: string;
                        qtyFull: string;
                        total: string;
                    };
                    actions: {
                        save: string;
                    };
                };
            };
            bindCart: {
                cartNumber: string;
                bindCartToCustomer: string;
                success: string;
                assignCartId: string;
                enterCartId: string;
                resetCartId: string;
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        replace: string;
                    };
                };
            };
            csagentTokenExpired: string;
            endSession: string;
            endSessionAriaLabel: string;
            endEmulation: string;
            agentSessionTimer: {
                label: string;
                minutes: string;
                reset: string;
            };
            auth: {
                agentLoggedInError: string;
            };
            error: {
                noCustomerId: string;
            };
        };
    };
};

declare const es: {
    asm: {
        asm: {
            mainLogoLabel: string;
            mainTitle: string;
            logout: string;
            hideUi: string;
            helpPortalUrl: string;
            customers: string;
            asmCustomer360Button: string;
            asmCustomer360ViewButton: string;
            createCustomerSuccessfullyAlert: string;
            saveInactiveCartAlertInfo: string;
            activeCartAlertInfo: string;
            startCustomerEmulationAlertInfo: string;
            toggleUi: {
                collapse: string;
                expand: string;
            };
            loginForm: {
                submit: string;
                userId: {
                    label: string;
                };
                password: {
                    label: string;
                };
            };
            customerSearch: {
                searchTerm: {
                    label: string;
                };
                searchCustomer: {
                    label: string;
                };
                searchOrder: {
                    label: string;
                };
                submit: string;
                startEmulation: string;
                noMatch: string;
                noMatchResult: string;
                noCustomerMatchResult: string;
                noOrderMatchResult: string;
                createCustomer: string;
                customer: string;
                orderID: string;
            };
            createCustomerForm: {
                title: string;
                createAccount: string;
                cancel: string;
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                emailAddress: {
                    label: string;
                    placeholder: string;
                };
                createAccountAlert: string;
                validationErrors: {
                    firstName: string;
                    lastName: string;
                    emailAddress: string;
                };
                badRequestDuplicatedEmail: string;
            };
            customerList: {
                title: string;
                description: string;
                createCustomer: string;
                cancel: string;
                tableHeader: {
                    customer: string;
                    customerName: string;
                    name: string;
                    email: string;
                    emailId: string;
                    phone: string;
                    account: string;
                    cart: string;
                    order: string;
                    view: string;
                    activeCart: string;
                    viewActiveCart: string;
                    orders: string;
                    viewOrders: string;
                    customer360: string;
                    viewCustomer360: string;
                };
                tableSort: {
                    sortBy: string;
                    byName: string;
                    byNameAsc: string;
                    byNameDesc: string;
                    byDateAsc: string;
                    byDateDesc: string;
                    byOrderDateAsc: string;
                    byOrderDateDesc: string;
                    byUnit: string;
                    byUnitDesc: string;
                };
                page: {
                    page: string;
                    previous: string;
                    next: string;
                };
                noOfCustomers: string;
                oneCustomer: string;
                noCustomers: string;
                noLists: string;
                listsError: string;
                searchBox: string;
                enterSearchBox: string;
            };
            switchCustomer: {
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        switch: string;
                    };
                };
            };
            saveCart: {
                saveCartBtn: string;
                dialog: {
                    saveInfo: string;
                    disableInfo: string;
                    title: string;
                    row: {
                        id: string;
                        qty: string;
                        qtyFull: string;
                        total: string;
                    };
                    actions: {
                        save: string;
                    };
                };
            };
            bindCart: {
                cartNumber: string;
                bindCartToCustomer: string;
                success: string;
                assignCartId: string;
                enterCartId: string;
                resetCartId: string;
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        replace: string;
                    };
                };
            };
            csagentTokenExpired: string;
            endSession: string;
            endEmulation: string;
            agentSessionTimer: {
                label: string;
                minutes: string;
                reset: string;
            };
            auth: {
                agentLoggedInError: string;
            };
            error: {
                noCustomerId: string;
            };
        };
    };
};

declare const es_CO: {
    asm: {
        asm: {
            mainLogoLabel: string;
            mainTitle: string;
            logout: string;
            hideUi: string;
            helpPortalUrl: string;
            customers: string;
            asmCustomer360Button: string;
            asmCustomer360ViewButton: string;
            createCustomerSuccessfullyAlert: string;
            saveInactiveCartAlertInfo: string;
            activeCartAlertInfo: string;
            startCustomerEmulationAlertInfo: string;
            toggleUi: {
                collapse: string;
                expand: string;
            };
            loginForm: {
                submit: string;
                userId: {
                    label: string;
                };
                password: {
                    label: string;
                };
            };
            customerSearch: {
                searchTerm: {
                    label: string;
                };
                searchCustomer: {
                    label: string;
                };
                searchOrder: {
                    label: string;
                };
                submit: string;
                startEmulation: string;
                noMatch: string;
                noMatchResult: string;
                noCustomerMatchResult: string;
                noOrderMatchResult: string;
                createCustomer: string;
                customer: string;
                orderID: string;
            };
            createCustomerForm: {
                title: string;
                createAccount: string;
                cancel: string;
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                emailAddress: {
                    label: string;
                    placeholder: string;
                };
                createAccountAlert: string;
                validationErrors: {
                    firstName: string;
                    lastName: string;
                    emailAddress: string;
                };
                badRequestDuplicatedEmail: string;
            };
            customerList: {
                title: string;
                description: string;
                createCustomer: string;
                cancel: string;
                tableHeader: {
                    customer: string;
                    customerName: string;
                    name: string;
                    email: string;
                    emailId: string;
                    phone: string;
                    account: string;
                    cart: string;
                    order: string;
                    view: string;
                    activeCart: string;
                    viewActiveCart: string;
                    orders: string;
                    viewOrders: string;
                    customer360: string;
                    viewCustomer360: string;
                };
                tableSort: {
                    sortBy: string;
                    byName: string;
                    byNameAsc: string;
                    byNameDesc: string;
                    byDateAsc: string;
                    byDateDesc: string;
                    byOrderDateAsc: string;
                    byOrderDateDesc: string;
                    byUnit: string;
                    byUnitDesc: string;
                };
                page: {
                    page: string;
                    previous: string;
                    next: string;
                };
                noOfCustomers: string;
                oneCustomer: string;
                noCustomers: string;
                noLists: string;
                listsError: string;
                searchBox: string;
                enterSearchBox: string;
            };
            switchCustomer: {
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        switch: string;
                    };
                };
            };
            saveCart: {
                saveCartBtn: string;
                dialog: {
                    saveInfo: string;
                    disableInfo: string;
                    title: string;
                    row: {
                        id: string;
                        qty: string;
                        qtyFull: string;
                        total: string;
                    };
                    actions: {
                        save: string;
                    };
                };
            };
            bindCart: {
                cartNumber: string;
                bindCartToCustomer: string;
                success: string;
                assignCartId: string;
                enterCartId: string;
                resetCartId: string;
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        replace: string;
                    };
                };
            };
            csagentTokenExpired: string;
            endSession: string;
            endEmulation: string;
            agentSessionTimer: {
                label: string;
                minutes: string;
                reset: string;
            };
            auth: {
                agentLoggedInError: string;
            };
            error: {
                noCustomerId: string;
            };
        };
    };
};

declare const fr: {
    asm: {
        asm: {
            mainLogoLabel: string;
            mainTitle: string;
            logout: string;
            hideUi: string;
            helpPortalUrl: string;
            customers: string;
            asmCustomer360Button: string;
            asmCustomer360ViewButton: string;
            createCustomerSuccessfullyAlert: string;
            saveInactiveCartAlertInfo: string;
            activeCartAlertInfo: string;
            startCustomerEmulationAlertInfo: string;
            toggleUi: {
                collapse: string;
                expand: string;
            };
            loginForm: {
                submit: string;
                userId: {
                    label: string;
                };
                password: {
                    label: string;
                };
            };
            customerSearch: {
                searchTerm: {
                    label: string;
                };
                searchCustomer: {
                    label: string;
                };
                searchOrder: {
                    label: string;
                };
                submit: string;
                startEmulation: string;
                noMatch: string;
                noMatchResult: string;
                noCustomerMatchResult: string;
                noOrderMatchResult: string;
                createCustomer: string;
                customer: string;
                orderID: string;
            };
            createCustomerForm: {
                title: string;
                createAccount: string;
                cancel: string;
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                emailAddress: {
                    label: string;
                    placeholder: string;
                };
                createAccountAlert: string;
                validationErrors: {
                    firstName: string;
                    lastName: string;
                    emailAddress: string;
                };
                badRequestDuplicatedEmail: string;
            };
            customerList: {
                title: string;
                description: string;
                createCustomer: string;
                cancel: string;
                tableHeader: {
                    customer: string;
                    customerName: string;
                    name: string;
                    email: string;
                    emailId: string;
                    phone: string;
                    account: string;
                    cart: string;
                    order: string;
                    view: string;
                    activeCart: string;
                    viewActiveCart: string;
                    orders: string;
                    viewOrders: string;
                    customer360: string;
                    viewCustomer360: string;
                };
                tableSort: {
                    sortBy: string;
                    byName: string;
                    byNameAsc: string;
                    byNameDesc: string;
                    byDateAsc: string;
                    byDateDesc: string;
                    byOrderDateAsc: string;
                    byOrderDateDesc: string;
                    byUnit: string;
                    byUnitDesc: string;
                };
                page: {
                    page: string;
                    previous: string;
                    next: string;
                };
                noOfCustomers: string;
                oneCustomer: string;
                noCustomers: string;
                noLists: string;
                listsError: string;
                searchBox: string;
                enterSearchBox: string;
            };
            switchCustomer: {
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        switch: string;
                    };
                };
            };
            saveCart: {
                saveCartBtn: string;
                dialog: {
                    saveInfo: string;
                    disableInfo: string;
                    title: string;
                    row: {
                        id: string;
                        qty: string;
                        qtyFull: string;
                        total: string;
                    };
                    actions: {
                        save: string;
                    };
                };
            };
            bindCart: {
                cartNumber: string;
                bindCartToCustomer: string;
                success: string;
                assignCartId: string;
                enterCartId: string;
                resetCartId: string;
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        replace: string;
                    };
                };
            };
            csagentTokenExpired: string;
            endSession: string;
            endEmulation: string;
            agentSessionTimer: {
                label: string;
                minutes: string;
                reset: string;
            };
            auth: {
                agentLoggedInError: string;
            };
            error: {
                noCustomerId: string;
            };
        };
    };
};

declare const hi: {
    asm: {
        asm: {
            mainLogoLabel: string;
            mainTitle: string;
            logout: string;
            hideUi: string;
            helpPortalUrl: string;
            customers: string;
            asmCustomer360Button: string;
            asmCustomer360ViewButton: string;
            createCustomerSuccessfullyAlert: string;
            saveInactiveCartAlertInfo: string;
            activeCartAlertInfo: string;
            startCustomerEmulationAlertInfo: string;
            toggleUi: {
                collapse: string;
                expand: string;
            };
            loginForm: {
                submit: string;
                userId: {
                    label: string;
                };
                password: {
                    label: string;
                };
            };
            customerSearch: {
                searchTerm: {
                    label: string;
                };
                searchCustomer: {
                    label: string;
                };
                searchOrder: {
                    label: string;
                };
                submit: string;
                startEmulation: string;
                noMatch: string;
                noMatchResult: string;
                noCustomerMatchResult: string;
                noOrderMatchResult: string;
                createCustomer: string;
                customer: string;
                orderID: string;
            };
            createCustomerForm: {
                title: string;
                createAccount: string;
                cancel: string;
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                emailAddress: {
                    label: string;
                    placeholder: string;
                };
                createAccountAlert: string;
                validationErrors: {
                    firstName: string;
                    lastName: string;
                    emailAddress: string;
                };
                badRequestDuplicatedEmail: string;
            };
            customerList: {
                title: string;
                description: string;
                createCustomer: string;
                cancel: string;
                tableHeader: {
                    customer: string;
                    customerName: string;
                    name: string;
                    email: string;
                    emailId: string;
                    phone: string;
                    account: string;
                    cart: string;
                    order: string;
                    view: string;
                    activeCart: string;
                    viewActiveCart: string;
                    orders: string;
                    viewOrders: string;
                    customer360: string;
                    viewCustomer360: string;
                };
                tableSort: {
                    sortBy: string;
                    byName: string;
                    byNameAsc: string;
                    byNameDesc: string;
                    byDateAsc: string;
                    byDateDesc: string;
                    byOrderDateAsc: string;
                    byOrderDateDesc: string;
                    byUnit: string;
                    byUnitDesc: string;
                };
                page: {
                    page: string;
                    previous: string;
                    next: string;
                };
                noOfCustomers: string;
                oneCustomer: string;
                noCustomers: string;
                noLists: string;
                listsError: string;
                searchBox: string;
                enterSearchBox: string;
            };
            switchCustomer: {
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        switch: string;
                    };
                };
            };
            saveCart: {
                saveCartBtn: string;
                dialog: {
                    saveInfo: string;
                    disableInfo: string;
                    title: string;
                    row: {
                        id: string;
                        qty: string;
                        qtyFull: string;
                        total: string;
                    };
                    actions: {
                        save: string;
                    };
                };
            };
            bindCart: {
                cartNumber: string;
                bindCartToCustomer: string;
                success: string;
                assignCartId: string;
                enterCartId: string;
                resetCartId: string;
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        replace: string;
                    };
                };
            };
            csagentTokenExpired: string;
            endSession: string;
            endEmulation: string;
            agentSessionTimer: {
                label: string;
                minutes: string;
                reset: string;
            };
            auth: {
                agentLoggedInError: string;
            };
            error: {
                noCustomerId: string;
            };
        };
    };
};

declare const hu: {
    asm: {
        asm: {
            mainLogoLabel: string;
            mainTitle: string;
            logout: string;
            hideUi: string;
            helpPortalUrl: string;
            customers: string;
            asmCustomer360Button: string;
            asmCustomer360ViewButton: string;
            createCustomerSuccessfullyAlert: string;
            saveInactiveCartAlertInfo: string;
            activeCartAlertInfo: string;
            startCustomerEmulationAlertInfo: string;
            toggleUi: {
                collapse: string;
                expand: string;
            };
            loginForm: {
                submit: string;
                userId: {
                    label: string;
                };
                password: {
                    label: string;
                };
            };
            customerSearch: {
                searchTerm: {
                    label: string;
                };
                searchCustomer: {
                    label: string;
                };
                searchOrder: {
                    label: string;
                };
                submit: string;
                startEmulation: string;
                noMatch: string;
                noMatchResult: string;
                noCustomerMatchResult: string;
                noOrderMatchResult: string;
                createCustomer: string;
                customer: string;
                orderID: string;
            };
            createCustomerForm: {
                title: string;
                createAccount: string;
                cancel: string;
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                emailAddress: {
                    label: string;
                    placeholder: string;
                };
                createAccountAlert: string;
                validationErrors: {
                    firstName: string;
                    lastName: string;
                    emailAddress: string;
                };
                badRequestDuplicatedEmail: string;
            };
            customerList: {
                title: string;
                description: string;
                createCustomer: string;
                cancel: string;
                tableHeader: {
                    customer: string;
                    customerName: string;
                    name: string;
                    email: string;
                    emailId: string;
                    phone: string;
                    account: string;
                    cart: string;
                    order: string;
                    view: string;
                    activeCart: string;
                    viewActiveCart: string;
                    orders: string;
                    viewOrders: string;
                    customer360: string;
                    viewCustomer360: string;
                };
                tableSort: {
                    sortBy: string;
                    byName: string;
                    byNameAsc: string;
                    byNameDesc: string;
                    byDateAsc: string;
                    byDateDesc: string;
                    byOrderDateAsc: string;
                    byOrderDateDesc: string;
                    byUnit: string;
                    byUnitDesc: string;
                };
                page: {
                    page: string;
                    previous: string;
                    next: string;
                };
                noOfCustomers: string;
                oneCustomer: string;
                noCustomers: string;
                noLists: string;
                listsError: string;
                searchBox: string;
                enterSearchBox: string;
            };
            switchCustomer: {
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        switch: string;
                    };
                };
            };
            saveCart: {
                saveCartBtn: string;
                dialog: {
                    saveInfo: string;
                    disableInfo: string;
                    title: string;
                    row: {
                        id: string;
                        qty: string;
                        qtyFull: string;
                        total: string;
                    };
                    actions: {
                        save: string;
                    };
                };
            };
            bindCart: {
                cartNumber: string;
                bindCartToCustomer: string;
                success: string;
                assignCartId: string;
                enterCartId: string;
                resetCartId: string;
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        replace: string;
                    };
                };
            };
            csagentTokenExpired: string;
            endSession: string;
            endEmulation: string;
            agentSessionTimer: {
                label: string;
                minutes: string;
                reset: string;
            };
            auth: {
                agentLoggedInError: string;
            };
            error: {
                noCustomerId: string;
            };
        };
    };
};

declare const id: {
    asm: {
        asm: {
            mainLogoLabel: string;
            mainTitle: string;
            logout: string;
            hideUi: string;
            helpPortalUrl: string;
            customers: string;
            asmCustomer360Button: string;
            asmCustomer360ViewButton: string;
            createCustomerSuccessfullyAlert: string;
            saveInactiveCartAlertInfo: string;
            activeCartAlertInfo: string;
            startCustomerEmulationAlertInfo: string;
            toggleUi: {
                collapse: string;
                expand: string;
            };
            loginForm: {
                submit: string;
                userId: {
                    label: string;
                };
                password: {
                    label: string;
                };
            };
            customerSearch: {
                searchTerm: {
                    label: string;
                };
                searchCustomer: {
                    label: string;
                };
                searchOrder: {
                    label: string;
                };
                submit: string;
                startEmulation: string;
                noMatch: string;
                noMatchResult: string;
                noCustomerMatchResult: string;
                noOrderMatchResult: string;
                createCustomer: string;
                customer: string;
                orderID: string;
            };
            createCustomerForm: {
                title: string;
                createAccount: string;
                cancel: string;
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                emailAddress: {
                    label: string;
                    placeholder: string;
                };
                createAccountAlert: string;
                validationErrors: {
                    firstName: string;
                    lastName: string;
                    emailAddress: string;
                };
                badRequestDuplicatedEmail: string;
            };
            customerList: {
                title: string;
                description: string;
                createCustomer: string;
                cancel: string;
                tableHeader: {
                    customer: string;
                    customerName: string;
                    name: string;
                    email: string;
                    emailId: string;
                    phone: string;
                    account: string;
                    cart: string;
                    order: string;
                    view: string;
                    activeCart: string;
                    viewActiveCart: string;
                    orders: string;
                    viewOrders: string;
                    customer360: string;
                    viewCustomer360: string;
                };
                tableSort: {
                    sortBy: string;
                    byName: string;
                    byNameAsc: string;
                    byNameDesc: string;
                    byDateAsc: string;
                    byDateDesc: string;
                    byOrderDateAsc: string;
                    byOrderDateDesc: string;
                    byUnit: string;
                    byUnitDesc: string;
                };
                page: {
                    page: string;
                    previous: string;
                    next: string;
                };
                noOfCustomers: string;
                oneCustomer: string;
                noCustomers: string;
                noLists: string;
                listsError: string;
                searchBox: string;
                enterSearchBox: string;
            };
            switchCustomer: {
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        switch: string;
                    };
                };
            };
            saveCart: {
                saveCartBtn: string;
                dialog: {
                    saveInfo: string;
                    disableInfo: string;
                    title: string;
                    row: {
                        id: string;
                        qty: string;
                        qtyFull: string;
                        total: string;
                    };
                    actions: {
                        save: string;
                    };
                };
            };
            bindCart: {
                cartNumber: string;
                bindCartToCustomer: string;
                success: string;
                assignCartId: string;
                enterCartId: string;
                resetCartId: string;
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        replace: string;
                    };
                };
            };
            csagentTokenExpired: string;
            endSession: string;
            endEmulation: string;
            agentSessionTimer: {
                label: string;
                minutes: string;
                reset: string;
            };
            auth: {
                agentLoggedInError: string;
            };
            error: {
                noCustomerId: string;
            };
        };
    };
};

declare const it: {
    asm: {
        asm: {
            mainLogoLabel: string;
            mainTitle: string;
            logout: string;
            hideUi: string;
            helpPortalUrl: string;
            customers: string;
            asmCustomer360Button: string;
            asmCustomer360ViewButton: string;
            createCustomerSuccessfullyAlert: string;
            saveInactiveCartAlertInfo: string;
            activeCartAlertInfo: string;
            startCustomerEmulationAlertInfo: string;
            toggleUi: {
                collapse: string;
                expand: string;
            };
            loginForm: {
                submit: string;
                userId: {
                    label: string;
                };
                password: {
                    label: string;
                };
            };
            customerSearch: {
                searchTerm: {
                    label: string;
                };
                searchCustomer: {
                    label: string;
                };
                searchOrder: {
                    label: string;
                };
                submit: string;
                startEmulation: string;
                noMatch: string;
                noMatchResult: string;
                noCustomerMatchResult: string;
                noOrderMatchResult: string;
                createCustomer: string;
                customer: string;
                orderID: string;
            };
            createCustomerForm: {
                title: string;
                createAccount: string;
                cancel: string;
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                emailAddress: {
                    label: string;
                    placeholder: string;
                };
                createAccountAlert: string;
                validationErrors: {
                    firstName: string;
                    lastName: string;
                    emailAddress: string;
                };
                badRequestDuplicatedEmail: string;
            };
            customerList: {
                title: string;
                description: string;
                createCustomer: string;
                cancel: string;
                tableHeader: {
                    customer: string;
                    customerName: string;
                    name: string;
                    email: string;
                    emailId: string;
                    phone: string;
                    account: string;
                    cart: string;
                    order: string;
                    view: string;
                    activeCart: string;
                    viewActiveCart: string;
                    orders: string;
                    viewOrders: string;
                    customer360: string;
                    viewCustomer360: string;
                };
                tableSort: {
                    sortBy: string;
                    byName: string;
                    byNameAsc: string;
                    byNameDesc: string;
                    byDateAsc: string;
                    byDateDesc: string;
                    byOrderDateAsc: string;
                    byOrderDateDesc: string;
                    byUnit: string;
                    byUnitDesc: string;
                };
                page: {
                    page: string;
                    previous: string;
                    next: string;
                };
                noOfCustomers: string;
                oneCustomer: string;
                noCustomers: string;
                noLists: string;
                listsError: string;
                searchBox: string;
                enterSearchBox: string;
            };
            switchCustomer: {
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        switch: string;
                    };
                };
            };
            saveCart: {
                saveCartBtn: string;
                dialog: {
                    saveInfo: string;
                    disableInfo: string;
                    title: string;
                    row: {
                        id: string;
                        qty: string;
                        qtyFull: string;
                        total: string;
                    };
                    actions: {
                        save: string;
                    };
                };
            };
            bindCart: {
                cartNumber: string;
                bindCartToCustomer: string;
                success: string;
                assignCartId: string;
                enterCartId: string;
                resetCartId: string;
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        replace: string;
                    };
                };
            };
            csagentTokenExpired: string;
            endSession: string;
            endEmulation: string;
            agentSessionTimer: {
                label: string;
                minutes: string;
                reset: string;
            };
            auth: {
                agentLoggedInError: string;
            };
            error: {
                noCustomerId: string;
            };
        };
    };
};

declare const ja: {
    asm: {
        asm: {
            mainLogoLabel: string;
            mainTitle: string;
            logout: string;
            hideUi: string;
            helpPortalUrl: string;
            customers: string;
            asmCustomer360Button: string;
            asmCustomer360ViewButton: string;
            createCustomerSuccessfullyAlert: string;
            saveInactiveCartAlertInfo: string;
            activeCartAlertInfo: string;
            startCustomerEmulationAlertInfo: string;
            toggleUi: {
                collapse: string;
                expand: string;
            };
            loginForm: {
                submit: string;
                userId: {
                    label: string;
                };
                password: {
                    label: string;
                };
            };
            customerSearch: {
                searchTerm: {
                    label: string;
                };
                searchCustomer: {
                    label: string;
                };
                searchOrder: {
                    label: string;
                };
                submit: string;
                startEmulation: string;
                noMatch: string;
                noMatchResult: string;
                noCustomerMatchResult: string;
                noOrderMatchResult: string;
                createCustomer: string;
                customer: string;
                orderID: string;
            };
            createCustomerForm: {
                title: string;
                createAccount: string;
                cancel: string;
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                emailAddress: {
                    label: string;
                    placeholder: string;
                };
                createAccountAlert: string;
                validationErrors: {
                    firstName: string;
                    lastName: string;
                    emailAddress: string;
                };
                badRequestDuplicatedEmail: string;
            };
            customerList: {
                title: string;
                description: string;
                createCustomer: string;
                cancel: string;
                tableHeader: {
                    customer: string;
                    customerName: string;
                    name: string;
                    email: string;
                    emailId: string;
                    phone: string;
                    account: string;
                    cart: string;
                    order: string;
                    view: string;
                    activeCart: string;
                    viewActiveCart: string;
                    orders: string;
                    viewOrders: string;
                    customer360: string;
                    viewCustomer360: string;
                };
                tableSort: {
                    sortBy: string;
                    byName: string;
                    byNameAsc: string;
                    byNameDesc: string;
                    byDateAsc: string;
                    byDateDesc: string;
                    byOrderDateAsc: string;
                    byOrderDateDesc: string;
                    byUnit: string;
                    byUnitDesc: string;
                };
                page: {
                    page: string;
                    previous: string;
                    next: string;
                };
                noOfCustomers: string;
                oneCustomer: string;
                noCustomers: string;
                noLists: string;
                listsError: string;
                searchBox: string;
                enterSearchBox: string;
            };
            switchCustomer: {
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        switch: string;
                    };
                };
            };
            saveCart: {
                saveCartBtn: string;
                dialog: {
                    saveInfo: string;
                    disableInfo: string;
                    title: string;
                    row: {
                        id: string;
                        qty: string;
                        qtyFull: string;
                        total: string;
                    };
                    actions: {
                        save: string;
                    };
                };
            };
            bindCart: {
                cartNumber: string;
                bindCartToCustomer: string;
                success: string;
                assignCartId: string;
                enterCartId: string;
                resetCartId: string;
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        replace: string;
                    };
                };
            };
            csagentTokenExpired: string;
            endSession: string;
            endEmulation: string;
            agentSessionTimer: {
                label: string;
                minutes: string;
                reset: string;
            };
            auth: {
                agentLoggedInError: string;
            };
            error: {
                noCustomerId: string;
            };
        };
    };
};

declare const ko: {
    asm: {
        asm: {
            mainLogoLabel: string;
            mainTitle: string;
            logout: string;
            hideUi: string;
            helpPortalUrl: string;
            customers: string;
            asmCustomer360Button: string;
            asmCustomer360ViewButton: string;
            createCustomerSuccessfullyAlert: string;
            saveInactiveCartAlertInfo: string;
            activeCartAlertInfo: string;
            startCustomerEmulationAlertInfo: string;
            toggleUi: {
                collapse: string;
                expand: string;
            };
            loginForm: {
                submit: string;
                userId: {
                    label: string;
                };
                password: {
                    label: string;
                };
            };
            customerSearch: {
                searchTerm: {
                    label: string;
                };
                searchCustomer: {
                    label: string;
                };
                searchOrder: {
                    label: string;
                };
                submit: string;
                startEmulation: string;
                noMatch: string;
                noMatchResult: string;
                noCustomerMatchResult: string;
                noOrderMatchResult: string;
                createCustomer: string;
                customer: string;
                orderID: string;
            };
            createCustomerForm: {
                title: string;
                createAccount: string;
                cancel: string;
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                emailAddress: {
                    label: string;
                    placeholder: string;
                };
                createAccountAlert: string;
                validationErrors: {
                    firstName: string;
                    lastName: string;
                    emailAddress: string;
                };
                badRequestDuplicatedEmail: string;
            };
            customerList: {
                title: string;
                description: string;
                createCustomer: string;
                cancel: string;
                tableHeader: {
                    customer: string;
                    customerName: string;
                    name: string;
                    email: string;
                    emailId: string;
                    phone: string;
                    account: string;
                    cart: string;
                    order: string;
                    view: string;
                    activeCart: string;
                    viewActiveCart: string;
                    orders: string;
                    viewOrders: string;
                    customer360: string;
                    viewCustomer360: string;
                };
                tableSort: {
                    sortBy: string;
                    byName: string;
                    byNameAsc: string;
                    byNameDesc: string;
                    byDateAsc: string;
                    byDateDesc: string;
                    byOrderDateAsc: string;
                    byOrderDateDesc: string;
                    byUnit: string;
                    byUnitDesc: string;
                };
                page: {
                    page: string;
                    previous: string;
                    next: string;
                };
                noOfCustomers: string;
                oneCustomer: string;
                noCustomers: string;
                noLists: string;
                listsError: string;
                searchBox: string;
                enterSearchBox: string;
            };
            switchCustomer: {
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        switch: string;
                    };
                };
            };
            saveCart: {
                saveCartBtn: string;
                dialog: {
                    saveInfo: string;
                    disableInfo: string;
                    title: string;
                    row: {
                        id: string;
                        qty: string;
                        qtyFull: string;
                        total: string;
                    };
                    actions: {
                        save: string;
                    };
                };
            };
            bindCart: {
                cartNumber: string;
                bindCartToCustomer: string;
                success: string;
                assignCartId: string;
                enterCartId: string;
                resetCartId: string;
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        replace: string;
                    };
                };
            };
            csagentTokenExpired: string;
            endSession: string;
            endEmulation: string;
            agentSessionTimer: {
                label: string;
                minutes: string;
                reset: string;
            };
            auth: {
                agentLoggedInError: string;
            };
            error: {
                noCustomerId: string;
            };
        };
    };
};

declare const pl: {
    asm: {
        asm: {
            mainLogoLabel: string;
            mainTitle: string;
            logout: string;
            hideUi: string;
            helpPortalUrl: string;
            customers: string;
            asmCustomer360Button: string;
            asmCustomer360ViewButton: string;
            createCustomerSuccessfullyAlert: string;
            saveInactiveCartAlertInfo: string;
            activeCartAlertInfo: string;
            startCustomerEmulationAlertInfo: string;
            toggleUi: {
                collapse: string;
                expand: string;
            };
            loginForm: {
                submit: string;
                userId: {
                    label: string;
                };
                password: {
                    label: string;
                };
            };
            customerSearch: {
                searchTerm: {
                    label: string;
                };
                searchCustomer: {
                    label: string;
                };
                searchOrder: {
                    label: string;
                };
                submit: string;
                startEmulation: string;
                noMatch: string;
                noMatchResult: string;
                noCustomerMatchResult: string;
                noOrderMatchResult: string;
                createCustomer: string;
                customer: string;
                orderID: string;
            };
            createCustomerForm: {
                title: string;
                createAccount: string;
                cancel: string;
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                emailAddress: {
                    label: string;
                    placeholder: string;
                };
                createAccountAlert: string;
                validationErrors: {
                    firstName: string;
                    lastName: string;
                    emailAddress: string;
                };
                badRequestDuplicatedEmail: string;
            };
            customerList: {
                title: string;
                description: string;
                createCustomer: string;
                cancel: string;
                tableHeader: {
                    customer: string;
                    customerName: string;
                    name: string;
                    email: string;
                    emailId: string;
                    phone: string;
                    account: string;
                    cart: string;
                    order: string;
                    view: string;
                    activeCart: string;
                    viewActiveCart: string;
                    orders: string;
                    viewOrders: string;
                    customer360: string;
                    viewCustomer360: string;
                };
                tableSort: {
                    sortBy: string;
                    byName: string;
                    byNameAsc: string;
                    byNameDesc: string;
                    byDateAsc: string;
                    byDateDesc: string;
                    byOrderDateAsc: string;
                    byOrderDateDesc: string;
                    byUnit: string;
                    byUnitDesc: string;
                };
                page: {
                    page: string;
                    previous: string;
                    next: string;
                };
                noOfCustomers: string;
                oneCustomer: string;
                noCustomers: string;
                noLists: string;
                listsError: string;
                searchBox: string;
                enterSearchBox: string;
            };
            switchCustomer: {
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        switch: string;
                    };
                };
            };
            saveCart: {
                saveCartBtn: string;
                dialog: {
                    saveInfo: string;
                    disableInfo: string;
                    title: string;
                    row: {
                        id: string;
                        qty: string;
                        qtyFull: string;
                        total: string;
                    };
                    actions: {
                        save: string;
                    };
                };
            };
            bindCart: {
                cartNumber: string;
                bindCartToCustomer: string;
                success: string;
                assignCartId: string;
                enterCartId: string;
                resetCartId: string;
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        replace: string;
                    };
                };
            };
            csagentTokenExpired: string;
            endSession: string;
            endEmulation: string;
            agentSessionTimer: {
                label: string;
                minutes: string;
                reset: string;
            };
            auth: {
                agentLoggedInError: string;
            };
            error: {
                noCustomerId: string;
            };
        };
    };
};

declare const pt: {
    asm: {
        asm: {
            mainLogoLabel: string;
            mainTitle: string;
            logout: string;
            hideUi: string;
            helpPortalUrl: string;
            customers: string;
            asmCustomer360Button: string;
            asmCustomer360ViewButton: string;
            createCustomerSuccessfullyAlert: string;
            saveInactiveCartAlertInfo: string;
            activeCartAlertInfo: string;
            startCustomerEmulationAlertInfo: string;
            toggleUi: {
                collapse: string;
                expand: string;
            };
            loginForm: {
                submit: string;
                userId: {
                    label: string;
                };
                password: {
                    label: string;
                };
            };
            customerSearch: {
                searchTerm: {
                    label: string;
                };
                searchCustomer: {
                    label: string;
                };
                searchOrder: {
                    label: string;
                };
                submit: string;
                startEmulation: string;
                noMatch: string;
                noMatchResult: string;
                noCustomerMatchResult: string;
                noOrderMatchResult: string;
                createCustomer: string;
                customer: string;
                orderID: string;
            };
            createCustomerForm: {
                title: string;
                createAccount: string;
                cancel: string;
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                emailAddress: {
                    label: string;
                    placeholder: string;
                };
                createAccountAlert: string;
                validationErrors: {
                    firstName: string;
                    lastName: string;
                    emailAddress: string;
                };
                badRequestDuplicatedEmail: string;
            };
            customerList: {
                title: string;
                description: string;
                createCustomer: string;
                cancel: string;
                tableHeader: {
                    customer: string;
                    customerName: string;
                    name: string;
                    email: string;
                    emailId: string;
                    phone: string;
                    account: string;
                    cart: string;
                    order: string;
                    view: string;
                    activeCart: string;
                    viewActiveCart: string;
                    orders: string;
                    viewOrders: string;
                    customer360: string;
                    viewCustomer360: string;
                };
                tableSort: {
                    sortBy: string;
                    byName: string;
                    byNameAsc: string;
                    byNameDesc: string;
                    byDateAsc: string;
                    byDateDesc: string;
                    byOrderDateAsc: string;
                    byOrderDateDesc: string;
                    byUnit: string;
                    byUnitDesc: string;
                };
                page: {
                    page: string;
                    previous: string;
                    next: string;
                };
                noOfCustomers: string;
                oneCustomer: string;
                noCustomers: string;
                noLists: string;
                listsError: string;
                searchBox: string;
                enterSearchBox: string;
            };
            switchCustomer: {
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        switch: string;
                    };
                };
            };
            saveCart: {
                saveCartBtn: string;
                dialog: {
                    saveInfo: string;
                    disableInfo: string;
                    title: string;
                    row: {
                        id: string;
                        qty: string;
                        qtyFull: string;
                        total: string;
                    };
                    actions: {
                        save: string;
                    };
                };
            };
            bindCart: {
                cartNumber: string;
                bindCartToCustomer: string;
                success: string;
                assignCartId: string;
                enterCartId: string;
                resetCartId: string;
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        replace: string;
                    };
                };
            };
            csagentTokenExpired: string;
            endSession: string;
            endEmulation: string;
            agentSessionTimer: {
                label: string;
                minutes: string;
                reset: string;
            };
            auth: {
                agentLoggedInError: string;
            };
            error: {
                noCustomerId: string;
            };
        };
    };
};

declare const ru: {
    asm: {
        asm: {
            mainLogoLabel: string;
            mainTitle: string;
            logout: string;
            hideUi: string;
            helpPortalUrl: string;
            customers: string;
            asmCustomer360Button: string;
            asmCustomer360ViewButton: string;
            createCustomerSuccessfullyAlert: string;
            saveInactiveCartAlertInfo: string;
            activeCartAlertInfo: string;
            startCustomerEmulationAlertInfo: string;
            toggleUi: {
                collapse: string;
                expand: string;
            };
            loginForm: {
                submit: string;
                userId: {
                    label: string;
                };
                password: {
                    label: string;
                };
            };
            customerSearch: {
                searchTerm: {
                    label: string;
                };
                searchCustomer: {
                    label: string;
                };
                searchOrder: {
                    label: string;
                };
                submit: string;
                startEmulation: string;
                noMatch: string;
                noMatchResult: string;
                noCustomerMatchResult: string;
                noOrderMatchResult: string;
                createCustomer: string;
                customer: string;
                orderID: string;
            };
            createCustomerForm: {
                title: string;
                createAccount: string;
                cancel: string;
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                emailAddress: {
                    label: string;
                    placeholder: string;
                };
                createAccountAlert: string;
                validationErrors: {
                    firstName: string;
                    lastName: string;
                    emailAddress: string;
                };
                badRequestDuplicatedEmail: string;
            };
            customerList: {
                title: string;
                description: string;
                createCustomer: string;
                cancel: string;
                tableHeader: {
                    customer: string;
                    customerName: string;
                    name: string;
                    email: string;
                    emailId: string;
                    phone: string;
                    account: string;
                    cart: string;
                    order: string;
                    view: string;
                    activeCart: string;
                    viewActiveCart: string;
                    orders: string;
                    viewOrders: string;
                    customer360: string;
                    viewCustomer360: string;
                };
                tableSort: {
                    sortBy: string;
                    byName: string;
                    byNameAsc: string;
                    byNameDesc: string;
                    byDateAsc: string;
                    byDateDesc: string;
                    byOrderDateAsc: string;
                    byOrderDateDesc: string;
                    byUnit: string;
                    byUnitDesc: string;
                };
                page: {
                    page: string;
                    previous: string;
                    next: string;
                };
                noOfCustomers: string;
                oneCustomer: string;
                noCustomers: string;
                noLists: string;
                listsError: string;
                searchBox: string;
                enterSearchBox: string;
            };
            switchCustomer: {
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        switch: string;
                    };
                };
            };
            saveCart: {
                saveCartBtn: string;
                dialog: {
                    saveInfo: string;
                    disableInfo: string;
                    title: string;
                    row: {
                        id: string;
                        qty: string;
                        qtyFull: string;
                        total: string;
                    };
                    actions: {
                        save: string;
                    };
                };
            };
            bindCart: {
                cartNumber: string;
                bindCartToCustomer: string;
                success: string;
                assignCartId: string;
                enterCartId: string;
                resetCartId: string;
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        replace: string;
                    };
                };
            };
            csagentTokenExpired: string;
            endSession: string;
            endEmulation: string;
            agentSessionTimer: {
                label: string;
                minutes: string;
                reset: string;
            };
            auth: {
                agentLoggedInError: string;
            };
            error: {
                noCustomerId: string;
            };
        };
    };
};

declare const zh: {
    asm: {
        asm: {
            mainLogoLabel: string;
            mainTitle: string;
            logout: string;
            hideUi: string;
            helpPortalUrl: string;
            customers: string;
            asmCustomer360Button: string;
            asmCustomer360ViewButton: string;
            createCustomerSuccessfullyAlert: string;
            saveInactiveCartAlertInfo: string;
            activeCartAlertInfo: string;
            startCustomerEmulationAlertInfo: string;
            toggleUi: {
                collapse: string;
                expand: string;
            };
            loginForm: {
                submit: string;
                userId: {
                    label: string;
                };
                password: {
                    label: string;
                };
            };
            customerSearch: {
                searchTerm: {
                    label: string;
                };
                searchCustomer: {
                    label: string;
                };
                searchOrder: {
                    label: string;
                };
                submit: string;
                startEmulation: string;
                noMatch: string;
                noMatchResult: string;
                noCustomerMatchResult: string;
                noOrderMatchResult: string;
                createCustomer: string;
                customer: string;
                orderID: string;
            };
            createCustomerForm: {
                title: string;
                createAccount: string;
                cancel: string;
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                emailAddress: {
                    label: string;
                    placeholder: string;
                };
                createAccountAlert: string;
                validationErrors: {
                    firstName: string;
                    lastName: string;
                    emailAddress: string;
                };
                badRequestDuplicatedEmail: string;
            };
            customerList: {
                title: string;
                description: string;
                createCustomer: string;
                cancel: string;
                tableHeader: {
                    customer: string;
                    customerName: string;
                    name: string;
                    email: string;
                    emailId: string;
                    phone: string;
                    account: string;
                    cart: string;
                    order: string;
                    view: string;
                    activeCart: string;
                    viewActiveCart: string;
                    orders: string;
                    viewOrders: string;
                    customer360: string;
                    viewCustomer360: string;
                };
                tableSort: {
                    sortBy: string;
                    byName: string;
                    byNameAsc: string;
                    byNameDesc: string;
                    byDateAsc: string;
                    byDateDesc: string;
                    byOrderDateAsc: string;
                    byOrderDateDesc: string;
                    byUnit: string;
                    byUnitDesc: string;
                };
                page: {
                    page: string;
                    previous: string;
                    next: string;
                };
                noOfCustomers: string;
                oneCustomer: string;
                noCustomers: string;
                noLists: string;
                listsError: string;
                searchBox: string;
                enterSearchBox: string;
            };
            switchCustomer: {
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        switch: string;
                    };
                };
            };
            saveCart: {
                saveCartBtn: string;
                dialog: {
                    saveInfo: string;
                    disableInfo: string;
                    title: string;
                    row: {
                        id: string;
                        qty: string;
                        qtyFull: string;
                        total: string;
                    };
                    actions: {
                        save: string;
                    };
                };
            };
            bindCart: {
                cartNumber: string;
                bindCartToCustomer: string;
                success: string;
                assignCartId: string;
                enterCartId: string;
                resetCartId: string;
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        replace: string;
                    };
                };
            };
            csagentTokenExpired: string;
            endSession: string;
            endEmulation: string;
            agentSessionTimer: {
                label: string;
                minutes: string;
                reset: string;
            };
            auth: {
                agentLoggedInError: string;
            };
            error: {
                noCustomerId: string;
            };
        };
    };
};

declare const zh_TW: {
    asm: {
        asm: {
            mainLogoLabel: string;
            mainTitle: string;
            logout: string;
            hideUi: string;
            helpPortalUrl: string;
            customers: string;
            asmCustomer360Button: string;
            asmCustomer360ViewButton: string;
            createCustomerSuccessfullyAlert: string;
            saveInactiveCartAlertInfo: string;
            activeCartAlertInfo: string;
            startCustomerEmulationAlertInfo: string;
            toggleUi: {
                collapse: string;
                expand: string;
            };
            loginForm: {
                submit: string;
                userId: {
                    label: string;
                };
                password: {
                    label: string;
                };
            };
            customerSearch: {
                searchTerm: {
                    label: string;
                };
                searchCustomer: {
                    label: string;
                };
                searchOrder: {
                    label: string;
                };
                submit: string;
                startEmulation: string;
                noMatch: string;
                noMatchResult: string;
                noCustomerMatchResult: string;
                noOrderMatchResult: string;
                createCustomer: string;
                customer: string;
                orderID: string;
            };
            createCustomerForm: {
                title: string;
                createAccount: string;
                cancel: string;
                firstName: {
                    label: string;
                    placeholder: string;
                };
                lastName: {
                    label: string;
                    placeholder: string;
                };
                emailAddress: {
                    label: string;
                    placeholder: string;
                };
                createAccountAlert: string;
                validationErrors: {
                    firstName: string;
                    lastName: string;
                    emailAddress: string;
                };
                badRequestDuplicatedEmail: string;
            };
            customerList: {
                title: string;
                description: string;
                createCustomer: string;
                cancel: string;
                tableHeader: {
                    customer: string;
                    customerName: string;
                    name: string;
                    email: string;
                    emailId: string;
                    phone: string;
                    account: string;
                    cart: string;
                    order: string;
                    view: string;
                    activeCart: string;
                    viewActiveCart: string;
                    orders: string;
                    viewOrders: string;
                    customer360: string;
                    viewCustomer360: string;
                };
                tableSort: {
                    sortBy: string;
                    byName: string;
                    byNameAsc: string;
                    byNameDesc: string;
                    byDateAsc: string;
                    byDateDesc: string;
                    byOrderDateAsc: string;
                    byOrderDateDesc: string;
                    byUnit: string;
                    byUnitDesc: string;
                };
                page: {
                    page: string;
                    previous: string;
                    next: string;
                };
                noOfCustomers: string;
                oneCustomer: string;
                noCustomers: string;
                noLists: string;
                listsError: string;
                searchBox: string;
                enterSearchBox: string;
            };
            switchCustomer: {
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        switch: string;
                    };
                };
            };
            saveCart: {
                saveCartBtn: string;
                dialog: {
                    saveInfo: string;
                    disableInfo: string;
                    title: string;
                    row: {
                        id: string;
                        qty: string;
                        qtyFull: string;
                        total: string;
                    };
                    actions: {
                        save: string;
                    };
                };
            };
            bindCart: {
                cartNumber: string;
                bindCartToCustomer: string;
                success: string;
                assignCartId: string;
                enterCartId: string;
                resetCartId: string;
                dialog: {
                    title: string;
                    body: string;
                    actions: {
                        replace: string;
                    };
                };
            };
            csagentTokenExpired: string;
            endSession: string;
            endEmulation: string;
            agentSessionTimer: {
                label: string;
                minutes: string;
                reset: string;
            };
            auth: {
                agentLoggedInError: string;
            };
            error: {
                noCustomerId: string;
            };
        };
    };
};

declare const asmTranslationChunksConfig: TranslationChunksConfig;

export { asmTranslationChunksConfig, cs as asmTranslationsCs, de as asmTranslationsDe, en as asmTranslationsEn, es as asmTranslationsEs, es_CO as asmTranslationsEs_CO, fr as asmTranslationsFr, hi as asmTranslationsHi, hu as asmTranslationsHu, id as asmTranslationsId, it as asmTranslationsIt, ja as asmTranslationsJa, ko as asmTranslationsKo, pl as asmTranslationsPl, pt as asmTranslationsPt, ru as asmTranslationsRu, zh as asmTranslationsZh, zh_TW as asmTranslationsZh_TW };
