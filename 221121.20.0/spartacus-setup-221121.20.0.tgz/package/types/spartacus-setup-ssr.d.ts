import { CommonEngineRenderOptions, CommonEngineOptions, CommonEngine } from '@angular/ssr/node';
import * as express from 'express';
import { Request, Response, RequestHandler, ErrorRequestHandler } from 'express';
import * as i0 from '@angular/core';
import { InjectionToken, StaticProvider, Provider, ModuleWithProviders } from '@angular/core';
import { LoggerService, MultiErrorHandler } from '@spartacus/core';
import { InspectOptions } from 'node:util';
import * as _spartacus_setup_ssr from '@spartacus/setup/ssr';
import * as qs from 'qs';
import * as express_serve_static_core from 'express-serve-static-core';

/**
 * Options to be used for formatting log messages in NodeJS.
 *
 * They are meant to be passed to `inspect()` or `formatWithOptions()` functions from the `node:util` module
 * for logging purposes.
 *
 * - In dev mode, it's optimized for human-readable output (multi-line output).
 * - In prod mode, it's optimized for machine-readable output (single-line output)
 */
declare function getLoggerInspectOptions(): InspectOptions;

/**
 * ExpressServerLoggerContext is used for log message in server side rendering.
 * It contains optional request object and additional properties that can be used in log message.
 */
interface ExpressServerLoggerContext {
    request?: Request;
    [_key: string]: any;
}
/**
 * ExpressServerLogger is used for log message in server side rendering.
 * It contains methods for logging messages with different levels. Each method accepts message and context.
 * Context is an object that contains additional information about the log message.
 *
 * @property log - logs message with level "log"
 * @property warn - logs message with level "warn"
 * @property error - logs message with level "error"
 * @property info - logs message with level "info"
 * @property debug - logs message with level "debug"
 */
interface ExpressServerLogger {
    log(message: string, context: ExpressServerLoggerContext): void;
    warn(message: string, context: ExpressServerLoggerContext): void;
    error(message: string, context: ExpressServerLoggerContext): void;
    info(message: string, context: ExpressServerLoggerContext): void;
    debug(message: string, context: ExpressServerLoggerContext): void;
}
/**
 * Injection token for ExpressServerLogger used for log message in server side rendering.
 * EXPRESS_SERVER_LOGGER is used to provide proper logger to LoggerService instance.
 *
 * Spartacus is providing one type of server logger:
 * - DefaultExpressServerLogger - default implementation used for logging contextual messages in SSR.
 *
 */
declare const EXPRESS_SERVER_LOGGER: InjectionToken<ExpressServerLogger>;

/**
 *
 * Default logger used in SSR (ExpressJS) to enhance logs visible e.g. in monitoring tools e.g. Kibana.
 * It outputs a JSON with properties "message" and "context",
 * which contains a "timestamp" and details of the "request" ("url", "uuid", "timeReceived")
 *
 * The output "context" JSON will contain also a property "traceContext"
 * with "traceId", "parentId", "version" and "traceFlags",
 * if only the given request has the special header "traceparent" (specifed in
 * the "W3C TraceContext" document. See https://www.w3.org/TR/trace-context/#traceparent-header ).
 */
declare class DefaultExpressServerLogger implements ExpressServerLogger {
    log(message: string, context: ExpressServerLoggerContext): void;
    warn(message: string, context: ExpressServerLoggerContext): void;
    error(message: string, context: ExpressServerLoggerContext): void;
    info(message: string, context: ExpressServerLoggerContext): void;
    debug(message: string, context: ExpressServerLoggerContext): void;
    /**
     * Converts a message and an ExpressServerLoggerContext object into a single JSON string containing both pieces of information, which can be used for logging purposes.
     *
     * In prod mode, it prints a single line stringified JSON that can be easily parsed by
     * monitoring tools e.g. Kibana.
     *
     * In dev mode, it prints human readable multi-line stringified JSON with indentation.
     *
     * @protected
     * @param message - The message to be included in the log entry.
     * @param context - The context object associated with the log entry.
     * @returns A JSON string containing both the message and context information, suitable for logging.
     */
    protected stringifyWithContext(message: string, context: ExpressServerLoggerContext): string;
    /**
     * Map the context for the ExpressServerLogger
     *
     * @protected
     * @param context - The logging context object to be mapped
     * @returns - The mapped context with timestamp and request (if available)
     */
    protected mapContext(context: ExpressServerLoggerContext): Record<string, any>;
    /**
     * Maps a Request object into a JavaScript object with specific properties.
     *
     * @protected
     * @param request - An Express Request object.
     * @returns - A mapped request object. By default, it contains only "url", a random "uuid" and "timeReceived" of the request.
     */
    protected mapRequest(request: Request): Record<string, any>;
    /**
     * Converts an Error object into a detailed string (with message, stack, cause, etc.).
     *
     * Otherwise, the Error instance would not be visible in the logs after passing through `JSON.stringify()`.
     * For more, see https://stackoverflow.com/a/50738205/11734692
     */
    protected stringifyError(error: unknown): string;
}

/**
 * Custom `LoggerService` used in ExpressJS.
 *
 * It converts the input arguments to a final string message similar as the native `console`
 * does (using the native function `format` from `node:util`) and passes this message
 * to a concrete server logger, used in ExpressJS.
 *
 * Besides the message, it also passes the current `request` of ExpressJS as an additional
 * context to the concrete server logger.
 */
declare class ExpressLoggerService implements LoggerService {
    request: express.Request<express_serve_static_core.ParamsDictionary, any, any, qs.ParsedQs, Record<string, any>>;
    serverLogger: _spartacus_setup_ssr.ExpressServerLogger;
    log(...args: Parameters<typeof console.log>): void;
    warn(...args: Parameters<typeof console.warn>): void;
    error(...args: Parameters<typeof console.error>): void;
    info(...args: Parameters<typeof console.info>): void;
    debug(...args: Parameters<typeof console.debug>): void;
    protected formatLogMessage(message?: any, ...optionalParams: any[]): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExpressLoggerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ExpressLoggerService>;
}

/**
 * Custom `LoggerService` used in pre-rendering in the server environment.
 *
 * It simply forwards the arguments to the native `console` methods.
 */
declare class PrerenderingLoggerService extends LoggerService {
    log(...args: Parameters<typeof console.log>): void;
    warn(...args: Parameters<typeof console.warn>): void;
    error(...args: Parameters<typeof console.error>): void;
    info(...args: Parameters<typeof console.info>): void;
    debug(...args: Parameters<typeof console.debug>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PrerenderingLoggerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PrerenderingLoggerService>;
}

declare const serverLoggerServiceFactory: () => PrerenderingLoggerService | ExpressLoggerService;

declare function getRequestUrl(req: Request): string;

/**
 * Represents a rendering entry in the rendering cache.
 */
interface RenderingEntry {
    html?: any;
    err?: any;
    time?: number;
    rendering?: boolean;
    /**
     * Approximate size of the entry in bytes.
     */
    _size?: number;
}
/**
 * Custom strategy for calculating the size of a cache entry.
 * It's needed to keep track of the used cache size.
 */
interface CacheEntrySizeCalculator {
    calculateSize(entry: RenderingEntry): number;
}

interface SsrOptimizationOptions {
    /**
     * Time in milliseconds to wait for SSR rendering to happen.
     */
    timeout?: number;
    /**
     * Enable in-memory cache for pre-rendered urls.
     *
     * If disabled, the cache will still be used to temporarily store
     * renders finished after csr fallback in order to serve them with
     * next request only.
     */
    cache?: boolean;
    /**
     * Limits the cache size memory in bytes.
     *
     * Specifies the maximum memory (in bytes) allocated for cached entries,
     * helping to keep memory usage under control.
     *
     * The default value is set to 800 MB (meaning 800 000 000 in International System of Units).
     *
     * **IMPORTANT**: Your server should have much more available memory than the configured `cacheSizeMemory`,
     *            because the NodeJS process needs a lot of operational memory also for the rendering activities,
     *            such as creating instances of the Angular applications for each incoming requests.
     *            The more parallel requests are allowed (which can be limited with the `concurrency` option),
     *            the more operational memory is needed.
     *
     * *Note*: for calculating the size of the cache entry, the `cacheEntrySizeCalculator` option is used.
     */
    cacheSizeMemory?: number;
    /**
     * Strategy for calculating the size of a cache entry. It's needed to keep track of the used cache size,
     * so the oldest entries can be removed when the cache size memory limit is reached.
     *
     * For details on how each entry's size is calculated by default, see {@link DefaultCacheEntrySizeCalculator}.
     */
    cacheEntrySizeCalculator?: CacheEntrySizeCalculator;
    /**
     * Limit number of concurrent rendering
     */
    concurrency?: number;
    /**
     * Time in milliseconds after prerendered page is becoming stale and should
     * be rendered again.
     */
    ttl?: number | undefined;
    /**
     * Allows overriding default key generator for custom differentiating
     * between rendered pages. By default it uses the full request URL.
     *
     * @param req
     */
    renderKeyResolver?: (req: Request) => string;
    /**
     * This function allows for the definition of a custom rendering strategy on a per-request basis.
     * By default, we provide a defaultRenderingStrategyResolver,
     * which has a default parameter defaultRenderingStrategyResolverOptions.
     * This default option disables server-side rendering (SSR) on pages such as 'checkout' and 'my-account'.
     *
     * @param req
     */
    renderingStrategyResolver?: (req: Request) => RenderingStrategy;
    /**
     * Time in milliseconds to wait for rendering when SSR_ALWAYS render strategy is set for the request.
     * Default value is 60000 milliseconds (1 minute).
     */
    forcedSsrTimeout?: number;
    /**
     * The time for how long the render is expected to finish in.
     * Exceeding this timeout will decrease the concurrency limit
     * and allow for the new request to be server-side rendered.
     * However, this may not release the rendering resources for the hanging render,
     * which may cause additional memory usage on the server.
     *
     * It will log which render is exceeding the render time,
     * which is useful for debugging issues.
     *
     * The value should always be higher than `timeout` and `forcedSsrTimeout`.
     *
     * Default value is 300000 milliseconds (5 minutes).
     */
    maxRenderTime?: number;
    /**
     * Instead of immediately falling back to CSR
     * while a render for the same key is in progress, this option will make
     * the subsequent requests for this key wait for the current render.
     *
     * All pending requests that for the same rendering key will
     * take up only _one_ concurrency slot, because there is only
     * one actual rendering task being performed.
     *
     * Each request independently honors the `timeout` option.
     * E.g., consider the following setup where `timeout` option
     * is set to 3s, and the given request takes 4s to render.
     * The flow is as follows:
     *
     * - 1st request arrives and triggers the SSR.
     * - 2nd request for the same URL arrives 2s after the 1st one.
     *    Instead of falling back to CSR, it waits (with its own timeout)
     *    for the render of the first request.
     * - 1st request times out after 3s, and falls back to CSR.
     * - one second after the timeout, the current render finishes.
     * - the 2nd request returns SSR after only 2s of waiting.
     */
    reuseCurrentRendering?: boolean;
    /**
     * @deprecated - This flag is not used anymore since v2211.27.
     *
     * Now all the information about the traffic and rendering is logged unconditionally:
     * - receiving requests
     * - responding to requests (either with HTML result, error or fallback to CSR)
     * - start and end of renders
     * - timeout of renders (due to passing `maxRenderTime`)
     */
    debug?: boolean;
    /**
     * Config for improving logged messages with context and JSON structure.
     *
     * It enhances the logs in SSR by adding context, including the request's details,
     * and structuring them as JSON.
     *
     * The `logger` property is optional and accepts:
     * - `ExpressServerLogger`: Interprets the given `ExpressServerLogger` as a custom logger
     *
     * By default, the DefaultExpressServerLogger is used.
     */
    logger?: ExpressServerLogger;
    /**
     * When caching is enabled, this function tells whether the given rendering result
     * (html or error) should be cached.
     *
     * By default, all html rendering results are cached. By default, errors are not cached.
     */
    shouldCacheRenderingResult?: ({ options, entry, }: {
        options: SsrOptimizationOptions;
        entry: Pick<RenderingEntry, 'err' | 'html'>;
    }) => boolean;
    /**
     * Toggles providing granular adaptation to breaking changes in OptimizedSsrEngine.
     * They are temporary and will be removed in the future.
     * Each toggle has its own lifespan.
     *
     * Note: They are related only to the `OptimizedSsrEngine`. In particular, they
     * are different from Spartacus's regular feature toggles provided in the Angular app.
     */
    ssrFeatureToggles?: {};
}
declare enum RenderingStrategy {
    ALWAYS_CSR = -1,
    DEFAULT = 0,
    ALWAYS_SSR = 1
}
/**
 * Deeply required type for `featureToggles` property.
 */
type DeepRequired<T> = {
    [P in keyof T]-?: DeepRequired<T[P]>;
};
/**
 * Returns the full url for the given SSR Request.
 */
declare const getDefaultRenderKey: typeof getRequestUrl;
/**
 * The type of `defaultSsrOptimizationOptions` ensures that all properties are set to a default value.
 * Thanks to this, all options are well-defined and can be printed to logs on the SSR server start.
 */
type DefaultSsrOptimizationOptions = Omit<Required<SsrOptimizationOptions>, 'debug' | 'ttl'> & {
    ttl: number | undefined;
} & DeepRequired<Pick<SsrOptimizationOptions, 'ssrFeatureToggles'>>;
declare const defaultSsrOptimizationOptions: DefaultSsrOptimizationOptions;

declare class RenderingCache {
    private options?;
    protected renders: Map<string, RenderingEntry>;
    constructor(options?: SsrOptimizationOptions | undefined);
    private _sizeManager;
    private get sizeManager();
    setAsRendering(key: string): void;
    isRendering(key: string): boolean;
    /**
     * Store the entry, respecting the cache limit.
     */
    store(key: string, err?: Error | null, html?: string): void;
    /**
     * Store the entry, respecting the bytes limit.
     *
     * If needed, removes oldest entries until there's enough space for the new entry.
     */
    private storeUsingMemoryLimit;
    /**
     * Clear oldest entries until there's enough space for the new entry.
     */
    private clearOldestEntriesForSize;
    get(key: string): RenderingEntry | undefined;
    clear(key: string): void;
    isReady(key: string): boolean;
    isFresh(key: string): boolean;
}

type SsrCallbackFn = (
/**
 * Error that might've occurred while rendering.
 */
err?: Error | null | undefined, 
/**
 * HTML response.
 */
html?: string | undefined) => void;
/**
 * The rendered pages are kept in memory to be served on next request. If the `cache` is set to `false`, the
 * response is evicted as soon as the first successful response is successfully returned.
 */
declare class OptimizedSsrEngine {
    protected expressEngine: NgExpressEngineInstance;
    protected ssrOptions?: SsrOptimizationOptions | undefined;
    protected currentConcurrency: number;
    protected renderingCache: RenderingCache;
    protected logger: ExpressServerLogger;
    private templateCache;
    /**
     * When the config `reuseCurrentRendering` is enabled, we want perform
     * only one render for one rendering key and reuse the html result
     * for all the pending requests for the same rendering key.
     * Therefore we need to store the callbacks for all the pending requests
     * and invoke them with the html after the render completes.
     *
     * This Map should be used only when `reuseCurrentRendering` config is enabled.
     * It's indexed by the rendering keys.
     */
    private renderCallbacks;
    get engineInstance(): NgExpressEngineInstance;
    constructor(expressEngine: NgExpressEngineInstance, ssrOptions?: SsrOptimizationOptions | undefined);
    protected logOptions(): void;
    /**
     * When SSR page can not be returned in time, we're returning index.html of
     * the CSR application.
     * The CSR application is returned with the "Cache-Control: no-store" response-header. This notifies external cache systems to not use the CSR application for the subsequent request.
     */
    protected fallbackToCsr(response: Response, filePath: string, callback: SsrCallbackFn): void;
    protected getRenderingKey(request: Request): string;
    protected getRenderingStrategy(request: Request): RenderingStrategy;
    /**
     * When returns true, the server side rendering should be performed.
     * When returns false, the CSR fallback should be returned.
     *
     * We should not render, when there is already
     * a pending rendering for the same rendering key
     * (unless the `reuseCurrentRendering` config option is enabled)
     * OR when the concurrency limit is exceeded.
     */
    protected shouldRender(request: Request): boolean;
    /**
     * Checks for the concurrency limit
     *
     * @returns true if rendering this request would exceed the concurrency limit
     */
    private isConcurrencyLimitExceeded;
    /**
     * Returns true, when the `timeout` option has been configured to non-zero value OR
     * when the rendering strategy for the given request is ALWAYS_SSR.
     * Otherwise, it returns false.
     */
    protected shouldTimeout(request: Request): boolean;
    /**
     * Returns the timeout value.
     *
     * In case of the rendering strategy ALWAYS_SSR, it returns the config `forcedSsrTimeout`.
     * Otherwise, it returns the config `timeout`.
     */
    protected getTimeout(request: Request): number;
    /**
     * If there is an available cached response for this rendering key,
     * it invokes the given render callback with the response and returns true.
     *
     * Otherwise, it returns false.
     */
    protected returnCachedRender(request: Request, callback: SsrCallbackFn): boolean;
    /**
     * Handles the request and invokes the given `callback` with the result html / error.
     *
     * The result might be ether:
     * - a CSR fallback with a basic `index.html` content
     * - a result rendered by the original Angular Universal express engine
     * - a result from the in-memory cache (which was previously rendered by Angular Universal express engine).
     */
    protected renderResponse(filePath: string, options: any, callback: SsrCallbackFn): void;
    /** Retrieve the document from the cache or the filesystem */
    protected getDocument(filePath: string): string;
    /**
     * Delegates the render to the original _Angular Universal express engine_.
     *
     * In case when the config `reuseCurrentRendering` is enabled and **if there is already a pending
     * render task for the same rendering key**, it doesn't delegate a new render to Angular Universal.
     * Instead, it waits for the current rendering to complete and then reuse the result for all waiting requests.
     */
    private handleRender;
    /**
     * Delegates the render to the original _Angular Universal express engine_.
     *
     * There is no way to abort the running render of Angular Universal.
     * So if the render doesn't complete in the configured `maxRenderTime`,
     * we just consider the render task as hanging (note: it's a potential memory leak!).
     * Later on, even if the render completes somewhen in the future, we will ignore
     * its result.
     */
    private startRender;
    /**
     * Logs the result of the render.
     */
    private logForRenderResult;
}

type NgExpressEngineInstance = (filePath: string, options: object, callback: SsrCallbackFn) => void;
type NgExpressEngine = (setupOptions: Readonly<CommonEngineRenderOptions & CommonEngineOptions>) => NgExpressEngineInstance;
/**
 * The wrapper over the standard ngExpressEngine, that provides tokens for Spartacus
 * @param ngExpressEngine
 */
declare class NgExpressEngineDecorator {
    /**
     * Returns the higher order ngExpressEngine with provided tokens for Spartacus
     *
     * @param ngExpressEngine
     * @param optimizationOptions SSR optimization options
     */
    static get(ngExpressEngine: NgExpressEngine, optimizationOptions?: SsrOptimizationOptions | null): NgExpressEngine;
}

interface OriginValidationOptions {
    allowedOrigins?: string[] | string;
}
/**
 * Returns an Express middleware that guards against Host header injection and
 * cache poisoning by validating the resolved request origin against an
 * operator-provided allowlist.
 *
 * When the resolved origin is not in the allowlist, the request is rejected
 * with a 400 Bad Request response and a `Cache-Control: no-store` header so
 * intermediary caches don't retain the rejection.
 *
 * When `allowedOrigins` is absent or empty, a no-op middleware is returned and
 * the default Express `trust proxy` behavior is preserved.
 *
 * `allowedOrigins` accepts either an array or a comma-separated string. It is
 * typically read from the `SSR_ALLOWED_ORIGINS` environment variable so it can
 * be configured per environment without code changes; if your deployment
 * environment does not support environment variables, pass the array directly
 * instead.
 *
 * Each entry must be a full origin (`protocol://host`) with no trailing slash,
 * e.g. `"https://my.domain.com"`. Matching is case-insensitive. A `*` wildcard
 * matches exactly one host label: it never crosses a dot and never matches the
 * apex domain (e.g. `"https://*.my.domain.com"` matches
 * `"https://shop.my.domain.com"` but not `"https://my.domain.com"`).
 *
 * Usage in server.ts:
 * ```ts
 * import { getOriginValidationMiddleware } from '@spartacus/setup/ssr';
 * // from an environment variable (comma-separated):
 * server.use(getOriginValidationMiddleware({
 *   allowedOrigins: process.env['SSR_ALLOWED_ORIGINS']
 * }));
 * // or, when env vars are unavailable, as an explicit array:
 * server.use(getOriginValidationMiddleware({
 *   allowedOrigins: ['https://my.domain.com', 'https://*.my.domain.com']
 * }));
 * ```
 */
declare function getOriginValidationMiddleware(options: OriginValidationOptions): RequestHandler;

/**
 * The Spartacus extension of the Angular's `CommonEngine`. It is able to handle the propagated server responses caught during server-side rendering of a Spartacus app.
 * For reference, see Angular's source code: https://github.com/angular/angular-cli/blob/6cf866225ab09f8b4b3803c000b632bed8448ce4/packages/angular/ssr/src/common-engine.ts#L56
 *
 * @extends {CommonEngine}
 */
declare class CxCommonEngine extends CommonEngine {
    constructor(options?: CommonEngineOptions);
    /**
     * @override
     * Renders for the given options.
     * If an error is populated from the rendered applications
     * (via `PROPAGATE_ERROR_TO_SERVER` callback), then such an error
     * will be thrown and the result promise rejected - but only AFTER the rendering is complete.
     * In other words, at first an error occurs and it's captured, then we wait until the rendering completes
     * and ONLY then we reject the promise with the payload being the encountered error.
     *
     * Note: if more errors are captured during the rendering, only the first one will be used
     *       as the payload of the rejected promise, others won't.
     *
     * @param {CommonEngineRenderOptions} options - The options to render.
     * @returns {Promise<string>} Promise which resolves with the rendered HTML as a string
     *                            OR rejects with the error, if any is propagated from the rendered app.
     */
    render(options: CommonEngineRenderOptions): Promise<string>;
}

/**
 * @license
 * The MIT License
 * Copyright (c) 2010-2023 Google LLC. http://angular.io/license
 *
 * See:
 * - https://github.com/angular/universal/blob/e798d256de5e4377b704e63d993dc56ea35df97d/modules/express-engine/src/main.ts
 */
type NgSetupOptions = Pick<CommonEngineRenderOptions, 'providers' | 'publicPath' | 'inlineCriticalCss'> & CommonEngineOptions;
/**
 * @license
 * The MIT License
 * Copyright (c) 2010-2023 Google LLC. http://angular.io/license
 *
 * See:
 * - https://github.com/angular/universal/blob/e798d256de5e4377b704e63d993dc56ea35df97d/modules/express-engine/src/main.ts
 */
interface RenderOptions extends CommonEngineRenderOptions {
    req: Request;
    res?: Response;
}
/**
 * This is an express engine for handling Angular Applications
 *
 * Function `ngExpressEngine` was originally present in Angular for a long time and was removed in version Angular 17.
 * However, it is needed in Spartacus for backward compatibility reasons.
 * Therefore, we have copied the code from the Angular repository and included it in our Spartacus repository to avoid larger refactors.
 *
 * @license
 * The MIT License
 * Copyright (c) 2010-2023 Google LLC. http://angular.io/license
 *
 * See:
 * - https://github.com/angular/universal/blob/e798d256de5e4377b704e63d993dc56ea35df97d/modules/express-engine/src/main.ts
 */
declare function ngExpressEngine(setupOptions: NgSetupOptions): (filePath: string, options: object, callback: (err?: Error | null, html?: string) => void) => void;

/**
 * Propagates the given error object to the higher layer in the server.
 *
 * It's meant to propagate errors for example to ExpressJS layer when using SSR
 * or to a Prerendering Worker when using Server Prerendering.
 * Currently, it's provided OOTB only in SSR (not prerendering), in the `CxCommonEngine` class.
 *
 * Note: We need it until Angular implements a proper propagation of async errors
 * from an app to the the higher layer in the server.
 * For more, see the Angular issue https://github.com/angular/angular/issues/33642
 */
declare const PROPAGATE_ERROR_TO_SERVER: InjectionToken<(error: unknown) => void>;

/**
 * Returns default handlers which results in a fallback to client side rendering.
 * - If cms page not found, the document content is sent to the client with the appropriate 404 status code.
 * - For rest of errors, the document content is sent to the client with the appropriate status 500 code.
 *
 * @param documentContent The document content to be sent to the client.
 * @returns The error request handler.
 */
declare const defaultExpressErrorHandlers: (documentContent: string) => ErrorRequestHandler;

/**
 * Propagates the given error object to the higher layer in the server.
 *
 * It's meant to propagate errors for example to ExpressJS layer when using SSR
 * or to a Prerendering Worker when using Server Prerendering.
 * Currently, it's provided OOTB only in SSR (not prerendering), in the `CxCommonEngine` class.
 *
 * Note: We need it until Angular implements a proper propagation of async errors
 * from an app to the the higher layer in the server.
 * For more, see the Angular issue https://github.com/angular/angular/issues/33642
 *
 * Intended to be used as part of a multi-error handler strategy.
 *
 * @see MultiErrorHandler
 */
declare class PropagatingToServerErrorHandler implements MultiErrorHandler {
    protected propagateErrorToServer: (error: unknown) => void;
    handleError(error: unknown): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PropagatingToServerErrorHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PropagatingToServerErrorHandler>;
}

/**
 * Default implementation of the cache entry size calculator.
 *
 * For HTML string, it returns the size of the string in bytes, assuming 2 bytes per each character
 * (an upper-bound estimation assuming V8 is using `SeqTwoByteString` for string cache entries).
 *
 * For error object, it only roughly approximates the size - it sums sizes of the `name`, `message` and `stack` string properties.
 *
 * **CAUTION**: the error object can be potentially anything and can have more properties (not necessarily strings),
 *          so it's prone to under-estimation!
 *          It's not recommended to cache error objects.
 */
declare class DefaultCacheEntrySizeCalculator implements CacheEntrySizeCalculator {
    calculateSize(entry: RenderingEntry): number;
    /**
     * Calculates the size of the rendered HTML.
     */
    protected calculateHtmlSize(html: string): number;
    /**
     * Roughly approximates the size of the error, by calculating the size of 3 string properties:
     * - name
     * - message
     * - stack
     */
    protected calculateErrorSize(error: any): number;
    /**
     * Returns string size in bytes for NodeJS V8 engine.
     * Uses 2 bytes per character as an upper-bound estimate.
     *
     * V8 can use either one or two bytes per character, but for Spartacus SSR
     * it consistently uses two-byte-per-character strings (`SeqTwoByteString`)
     * which was verified through heap snapshots and memory measurements.
     *
     * For more on V8's `SeqTwoByteString`, see https://github.com/v8/v8/blob/c865b8257a/src/objects/string.h#L921-L923
     */
    protected getStringSize(str: string): number;
}

/**
 * It keeps track of the used cache size and helps making sure that adding new entries
 * doesn't cause exceeding the cache size limit.
 */
declare class RenderingCacheSizeManager {
    private options?;
    /**
     * The total size of the used cache in bytes.
     * This value will change as we add or remove entries from the cache.
     */
    private usedSize;
    /**
     * The maximum size of the cache in bytes, configured in the SSR options.
     */
    protected readonly CACHE_SIZE_LIMIT: number;
    constructor(options?: SsrOptimizationOptions | undefined);
    /**
     * Validates the `SsrOptimizationOptions` needed for this class to work properly.
     * In case of invalid options, it will log an error using the configured logger.
     */
    private validateOptions;
    /**
     * Calculates the size of the entry using the calculator provided in the options.
     */
    calculateEntrySize(entry: RenderingEntry): number;
    /**
     * Tells whether there's enough space for the given entry size.
     */
    hasSpaceForEntrySize(entrySize: number): boolean;
    /**
     * Tells whether the entry is too large to ever fit in the cache
     * (i.e. this single entry is larger than the total possible cache size).
     */
    isEntryLargerThanCacheLimit(entrySize: number): boolean;
    /**
     * Adds the size of the entry to the total tracked used size.
     */
    trackEntrySize(entrySize: number): void;
    /**
     * Subtracts the size of the entry from the total tracked used size.
     */
    untrackEntrySize(entrySize: number): void;
}

interface RenderingStrategyResolverOptions {
    excludedUrls?: string[];
    excludedParams?: string[];
}
declare const defaultRenderingStrategyResolverOptions: RenderingStrategyResolverOptions;

/**
 * Creates a rendering strategy resolver function with the specified options.
 *
 * @function
 * @param  options - The options to configure the rendering strategy resolver.
 * @param [options.excludedUrls] - An optional array of URLs for which server-side rendering (SSR) should be disabled.
 * @param [options.excludedParams] - An optional array of Query parameters for which SSR should be disabled.
 * @returns A rendering strategy resolver function that takes a Request object
 * as a parameter and returns the rendering strategy to be applied for the request, which can be either
 * `RenderingStrategy.ALWAYS_CSR` or `RenderingStrategy.DEFAULT`.
 */
declare const defaultRenderingStrategyResolver: (options: RenderingStrategyResolverOptions) => (request: Request) => RenderingStrategy;

/**
 * W3cTraceContext is used for log message in server side rendering.
 * It contains values of traceparent header.
 *
 * @property version - version of traceparent header
 * @property traceId - traceId of traceparent header
 * @property parentId - spanId of traceparent header
 * @property traceFlags - traceFlags of traceparent header
 *
 * @see https://www.w3.org/TR/trace-context/#traceparent-header-field
 */
interface W3cTraceContext {
    version: string;
    traceId: string;
    parentId: string;
    traceFlags: string;
}

/**
 * RequestContext is used for log message in server side rendering.
 * It contains request's UUID, time of receiving the request and the W3C Trace Context if `traceparent` header is available and valid.
 */
interface RequestContext {
    uuid: string;
    timeReceived: string;
    traceContext?: W3cTraceContext;
}
/**
 * Returns the request context from the request object.
 * @param request - the request object
 * @returns the context of the request
 */
declare const getRequestContext: (request: Request) => RequestContext;
declare module 'express' {
    interface Locals {
        cx: {
            request: RequestContext;
        };
    }
}

/**
 * Server options
 */
interface ServerOptions {
    /**
     * Specify a domain (origin) from which the HTTP requests are being made.
     * Should be without the trailing slash, e.g. "https://my.domain.com".
     *
     * In SSR mode, it will be automatically resolved from the express server,
     * therefore it doesn't have to be set via this option.
     * If explicitly set, this option will take precedence over the express server.
     *
     * It is _mandatory_ to provide it for the prerendering, as it can not be
     * automatically resolved.
     */
    serverRequestOrigin?: string;
}

/**
 * Returns the providers used for SSR and pre-rendering processes.
 */
declare function provideServer(options?: ServerOptions): Provider[];
/**
 * Returns Spartacus providers to be passed to the Angular express engine (in SSR)
 *
 * @param options
 */
declare function getServerRequestProviders(): StaticProvider[];

/**
 * A counterpart of the `TestConfigModule` from `@spartacus/core`,
 * but for the Server platform.
 * @see {@link TestConfigModule}
 *
 * - It uses the cookie from the REQUEST object (but not from `document.cookie`).
 * - The `TestConfigModule` must be imported in the app module anyway.
 *
 * CAUTION: DON'T USE IT IN PRODUCTION! IT HASN'T BEEN REVIEWED FOR SECURITY ISSUES.
 */
declare class TestConfigServerModule {
    static forRoot(): ModuleWithProviders<TestConfigServerModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TestConfigServerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TestConfigServerModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TestConfigServerModule>;
}

/**
 * Represents an injection token for the Request object of ExpressJS in server-side rendering.
 * This token is used to provide the request object to components and services.
 * It's a replacement for the `REQUEST` token from `@nguniversal/express-engine` that was removed only in Angular 17. Now this token is provided by Spartacus.
 */
declare const REQUEST: InjectionToken<Request>;
/**
 * Represents an injection token for the Response object of ExpressJS in server-side rendering.
 * This token is used to provide the response object to components and services.
 * It's a replacement for the `RESPONSE` token from `@nguniversal/express-engine` that was removed only in Angular 17. Now this token is provided by Spartacus.
 */
declare const RESPONSE: InjectionToken<Response>;

export { CxCommonEngine, DefaultCacheEntrySizeCalculator, DefaultExpressServerLogger, EXPRESS_SERVER_LOGGER, ExpressLoggerService, NgExpressEngineDecorator, OptimizedSsrEngine, PROPAGATE_ERROR_TO_SERVER, PrerenderingLoggerService, PropagatingToServerErrorHandler, REQUEST, RESPONSE, RenderingCache, RenderingCacheSizeManager, RenderingStrategy, TestConfigServerModule, defaultExpressErrorHandlers, defaultRenderingStrategyResolver, defaultRenderingStrategyResolverOptions, defaultSsrOptimizationOptions, getDefaultRenderKey, getLoggerInspectOptions, getOriginValidationMiddleware, getRequestContext, getServerRequestProviders, ngExpressEngine, provideServer, serverLoggerServiceFactory };
export type { CacheEntrySizeCalculator, ExpressServerLogger, ExpressServerLoggerContext, NgSetupOptions, OriginValidationOptions, RenderOptions, RenderingEntry, RenderingStrategyResolverOptions, RequestContext, ServerOptions, SsrCallbackFn, SsrOptimizationOptions };
