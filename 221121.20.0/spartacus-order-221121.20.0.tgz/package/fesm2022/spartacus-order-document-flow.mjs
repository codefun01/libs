import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { OrderDocumentFlowComponentsModule } from '@spartacus/order/document-flow/components';
import { OrderDocumentFlowOccModule } from '@spartacus/order/document-flow/occ';
import { OrderDocumentFlowCoreModule } from '@spartacus/order/document-flow/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OrderDocumentFlowModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowModule, imports: [OrderDocumentFlowCoreModule,
            OrderDocumentFlowComponentsModule,
            OrderDocumentFlowOccModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowModule, imports: [OrderDocumentFlowCoreModule,
            OrderDocumentFlowComponentsModule,
            OrderDocumentFlowOccModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        OrderDocumentFlowCoreModule,
                        OrderDocumentFlowComponentsModule,
                        OrderDocumentFlowOccModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OrderDocumentFlowModule };
//# sourceMappingURL=spartacus-order-document-flow.mjs.map
