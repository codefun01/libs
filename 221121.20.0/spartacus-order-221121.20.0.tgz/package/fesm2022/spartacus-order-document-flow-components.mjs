import { NgIf, AsyncPipe, NgFor, NgClass, CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { inject, ViewContainerRef, DestroyRef, ViewChild, ChangeDetectionStrategy, Component, EventEmitter, Output, Input, ChangeDetectorRef, signal, NgModule } from '@angular/core';
import { QueryService, UserIdService, TranslatePipe, CxDatePipe, TranslationService, GlobalMessageType, isNotNullable, I18nModule, UrlModule, provideDefaultConfig, AuthGuard } from '@spartacus/core';
import { OrderDetailsService } from '@spartacus/order/components';
import { LaunchDialogService, LAUNCH_CALLER, ICON_TYPE, IconComponent, FocusDirective, MessageComponent, SpinnerComponent, DIALOG_TYPE, SpinnerModule, KeyboardFocusModule, IconModule, MessageComponentModule } from '@spartacus/storefront';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { OrderDocumentFlowFacade } from '@spartacus/order/document-flow/root';
import { of, BehaviorSubject } from 'rxjs';
import { map, switchMap, catchError, shareReplay, filter, withLatestFrom, tap } from 'rxjs/operators';
import { RouterModule } from '@angular/router';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OrderDocumentFlowComponent {
    constructor() {
        this.orderDetailsService = inject(OrderDetailsService);
        this.launchDialogService = inject(LaunchDialogService);
        this.vcr = inject(ViewContainerRef);
        this.destroyRef = inject(DestroyRef);
        this.queryService = inject(QueryService);
        this.userIdService = inject(UserIdService);
        this.order$ = this.orderDetailsService.getOrderDetails();
    }
    onOrderDocumentFlowClick(orderCode) {
        this.launchDialogService.openDialogAndSubscribe(LAUNCH_CALLER.ORDER_DOCUMENT_FLOW, this.element, { orderCode });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OrderDocumentFlowComponent, isStandalone: true, selector: "cx-order-document-flow", viewQueries: [{ propertyName: "element", first: true, predicate: ["element"], descendants: true }], ngImport: i0, template: "<div class=\"row justify-content-end\" *ngIf=\"(order$ | async)?.code as code\">\n  <div class=\"col-sm-12 col-md-6 col-lg-5 col-xl-4\">\n    <button\n      #element\n      class=\"btn btn-secondary w-100 order-document-flow-dialog-btn\"\n      (click)=\"onOrderDocumentFlowClick(code)\"\n    >\n      {{ 'documentFlow.button' | cxTranslate }}\n    </button>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-order-document-flow', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, AsyncPipe, TranslatePipe], template: "<div class=\"row justify-content-end\" *ngIf=\"(order$ | async)?.code as code\">\n  <div class=\"col-sm-12 col-md-6 col-lg-5 col-xl-4\">\n    <button\n      #element\n      class=\"btn btn-secondary w-100 order-document-flow-dialog-btn\"\n      (click)=\"onOrderDocumentFlowClick(code)\"\n    >\n      {{ 'documentFlow.button' | cxTranslate }}\n    </button>\n  </div>\n</div>\n" }]
        }], propDecorators: { element: [{
                type: ViewChild,
                args: ['element']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OrderSubsequentDocumentNodeComponent {
    constructor() {
        this.iconTypes = ICON_TYPE;
        this.depth = 0;
        this.documentSelected = new EventEmitter();
    }
    haveSubNodes(document) {
        return (!!document.sapSubsequentDocuments &&
            document.sapSubsequentDocuments.length > 0);
    }
    onDocumentSelection(document) {
        this.documentSelected.emit(document);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderSubsequentDocumentNodeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OrderSubsequentDocumentNodeComponent, isStandalone: true, selector: "cx-order-subsequent-document-node", inputs: { documents: "documents", selectedDocument: "selectedDocument", depth: "depth" }, outputs: { documentSelected: "documentSelected" }, ngImport: i0, template: "<ng-container *ngFor=\"let document of documents\">\n  <tr [ngClass]=\"{ selected: document === selectedDocument }\">\n    <td [style.padding-left.rem]=\"depth + 1\">\n      <div>\n        <span>{{\n          document.sapDocumentEntryIdColumnName + ' ' + document.sapDocumentId\n        }}</span>\n      </div>\n      <div class=\"d-md-none\">\n        <span class=\"cx-mobile-header\">{{\n          'documentFlow.dialog.date' | cxTranslate\n        }}</span>\n        <span class=\"cx-date\">{{\n          document.sapCreatedAt | cxDate: 'shortDate'\n        }}</span>\n      </div>\n      <div class=\"d-block d-sm-none\">\n        <span class=\"cx-mobile-header\">{{\n          'documentFlow.dialog.time' | cxTranslate\n        }}</span>\n        <span class=\"cx-time\">{{\n          document.sapCreatedAt | cxDate: 'shortTime'\n        }}</span>\n      </div>\n      <div class=\"d-block d-sm-none\">\n        <span class=\"cx-mobile-header\">{{\n          'documentFlow.dialog.status' | cxTranslate\n        }}</span>\n        <span class=\"cx-status\">{{\n          'documentFlow.dialog.status_' + document.sapStatus | cxTranslate\n        }}</span>\n      </div>\n    </td>\n    <td class=\"d-none d-md-table-cell\">\n      {{ document.sapCreatedAt | cxDate: 'shortDate' }}\n    </td>\n    <td class=\"d-none d-sm-table-cell\">\n      {{ document.sapCreatedAt | cxDate: 'shortTime' }}\n    </td>\n    <td class=\"d-none d-sm-table-cell\">\n      {{ 'documentFlow.dialog.status_' + document.sapStatus | cxTranslate }}\n    </td>\n    <td class=\"text-center p-0\">\n      <button\n        *ngIf=\"haveSubNodes(document)\"\n        class=\"btn btn-tertiary action\"\n        title=\"{{ 'documentFlow.dialog.orderItems' | cxTranslate }}\"\n        (click)=\"onDocumentSelection(document)\"\n      >\n        <cx-icon [type]=\"iconTypes.CARET_RIGHT\" />\n      </button>\n    </td>\n  </tr>\n  <cx-order-subsequent-document-node\n    *ngIf=\"haveSubNodes(document)\"\n    [documents]=\"document.sapSubsequentDocuments\"\n    [selectedDocument]=\"selectedDocument\"\n    [depth]=\"depth + 1\"\n    (documentSelected)=\"onDocumentSelection($event)\"\n  />\n</ng-container>\n", dependencies: [{ kind: "component", type: OrderSubsequentDocumentNodeComponent, selector: "cx-order-subsequent-document-node", inputs: ["documents", "selectedDocument", "depth"], outputs: ["documentSelected"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: CxDatePipe, name: "cxDate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderSubsequentDocumentNodeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-order-subsequent-document-node', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgFor, NgClass, NgIf, IconComponent, TranslatePipe, CxDatePipe], template: "<ng-container *ngFor=\"let document of documents\">\n  <tr [ngClass]=\"{ selected: document === selectedDocument }\">\n    <td [style.padding-left.rem]=\"depth + 1\">\n      <div>\n        <span>{{\n          document.sapDocumentEntryIdColumnName + ' ' + document.sapDocumentId\n        }}</span>\n      </div>\n      <div class=\"d-md-none\">\n        <span class=\"cx-mobile-header\">{{\n          'documentFlow.dialog.date' | cxTranslate\n        }}</span>\n        <span class=\"cx-date\">{{\n          document.sapCreatedAt | cxDate: 'shortDate'\n        }}</span>\n      </div>\n      <div class=\"d-block d-sm-none\">\n        <span class=\"cx-mobile-header\">{{\n          'documentFlow.dialog.time' | cxTranslate\n        }}</span>\n        <span class=\"cx-time\">{{\n          document.sapCreatedAt | cxDate: 'shortTime'\n        }}</span>\n      </div>\n      <div class=\"d-block d-sm-none\">\n        <span class=\"cx-mobile-header\">{{\n          'documentFlow.dialog.status' | cxTranslate\n        }}</span>\n        <span class=\"cx-status\">{{\n          'documentFlow.dialog.status_' + document.sapStatus | cxTranslate\n        }}</span>\n      </div>\n    </td>\n    <td class=\"d-none d-md-table-cell\">\n      {{ document.sapCreatedAt | cxDate: 'shortDate' }}\n    </td>\n    <td class=\"d-none d-sm-table-cell\">\n      {{ document.sapCreatedAt | cxDate: 'shortTime' }}\n    </td>\n    <td class=\"d-none d-sm-table-cell\">\n      {{ 'documentFlow.dialog.status_' + document.sapStatus | cxTranslate }}\n    </td>\n    <td class=\"text-center p-0\">\n      <button\n        *ngIf=\"haveSubNodes(document)\"\n        class=\"btn btn-tertiary action\"\n        title=\"{{ 'documentFlow.dialog.orderItems' | cxTranslate }}\"\n        (click)=\"onDocumentSelection(document)\"\n      >\n        <cx-icon [type]=\"iconTypes.CARET_RIGHT\" />\n      </button>\n    </td>\n  </tr>\n  <cx-order-subsequent-document-node\n    *ngIf=\"haveSubNodes(document)\"\n    [documents]=\"document.sapSubsequentDocuments\"\n    [selectedDocument]=\"selectedDocument\"\n    [depth]=\"depth + 1\"\n    (documentSelected)=\"onDocumentSelection($event)\"\n  />\n</ng-container>\n" }]
        }], propDecorators: { documents: [{
                type: Input
            }], selectedDocument: [{
                type: Input
            }], depth: [{
                type: Input
            }], documentSelected: [{
                type: Output
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OrderSubsequentDocumentListComponent {
    constructor() {
        this.iconTypes = ICON_TYPE;
        this.documentSelected = new EventEmitter();
    }
    onDocumentSelection(document) {
        this.documentSelected.emit(document);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderSubsequentDocumentListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OrderSubsequentDocumentListComponent, isStandalone: true, selector: "cx-order-subsequent-document-list", inputs: { documents: "documents", selectedDocument: "selectedDocument" }, outputs: { documentSelected: "documentSelected" }, ngImport: i0, template: "<table class=\"table\">\n  <thead>\n    <tr>\n      <th>\n        {{ 'documentFlow.dialog.name' | cxTranslate }}\n      </th>\n      <th class=\"d-none d-md-table-cell\">\n        {{ 'documentFlow.dialog.date' | cxTranslate }}\n      </th>\n      <th class=\"d-none d-sm-table-cell\">\n        {{ 'documentFlow.dialog.time' | cxTranslate }}\n      </th>\n      <th class=\"d-none d-sm-table-cell\">\n        {{ 'documentFlow.dialog.status' | cxTranslate }}\n      </th>\n      <th class=\"\">\n        {{ 'documentFlow.dialog.orderItems' | cxTranslate }}\n      </th>\n    </tr>\n  </thead>\n  <tbody>\n    <cx-order-subsequent-document-node\n      *ngIf=\"documents\"\n      [documents]=\"documents\"\n      [selectedDocument]=\"selectedDocument\"\n      (documentSelected)=\"onDocumentSelection($event)\"\n    />\n  </tbody>\n</table>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: OrderSubsequentDocumentNodeComponent, selector: "cx-order-subsequent-document-node", inputs: ["documents", "selectedDocument", "depth"], outputs: ["documentSelected"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderSubsequentDocumentListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-order-subsequent-document-list', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, OrderSubsequentDocumentNodeComponent, TranslatePipe], template: "<table class=\"table\">\n  <thead>\n    <tr>\n      <th>\n        {{ 'documentFlow.dialog.name' | cxTranslate }}\n      </th>\n      <th class=\"d-none d-md-table-cell\">\n        {{ 'documentFlow.dialog.date' | cxTranslate }}\n      </th>\n      <th class=\"d-none d-sm-table-cell\">\n        {{ 'documentFlow.dialog.time' | cxTranslate }}\n      </th>\n      <th class=\"d-none d-sm-table-cell\">\n        {{ 'documentFlow.dialog.status' | cxTranslate }}\n      </th>\n      <th class=\"\">\n        {{ 'documentFlow.dialog.orderItems' | cxTranslate }}\n      </th>\n    </tr>\n  </thead>\n  <tbody>\n    <cx-order-subsequent-document-node\n      *ngIf=\"documents\"\n      [documents]=\"documents\"\n      [selectedDocument]=\"selectedDocument\"\n      (documentSelected)=\"onDocumentSelection($event)\"\n    />\n  </tbody>\n</table>\n" }]
        }], propDecorators: { documents: [{
                type: Input
            }], selectedDocument: [{
                type: Input
            }], documentSelected: [{
                type: Output
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OrderDocumentOrderEntryListComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentOrderEntryListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OrderDocumentOrderEntryListComponent, isStandalone: true, selector: "cx-order-document-order-entry-list", inputs: { entries: "entries" }, ngImport: i0, template: "<table class=\"table\">\n  <thead>\n    <tr>\n      <th>\n        {{ 'documentFlow.dialog.deliveryItemId' | cxTranslate }}\n      </th>\n      <th class=\"d-none d-sm-table-cell\">\n        {{ 'documentFlow.dialog.orderItemId' | cxTranslate }}\n      </th>\n      <th class=\"d-none d-sm-table-cell text-center\">\n        {{ 'documentFlow.dialog.date' | cxTranslate }}\n      </th>\n      <th class=\"d-none d-sm-table-cell text-center\">\n        {{ 'documentFlow.dialog.time' | cxTranslate }}\n      </th>\n      <th class=\"text-center\">\n        {{ 'documentFlow.dialog.status' | cxTranslate }}\n      </th>\n    </tr>\n  </thead>\n  <tbody>\n    <tr *ngFor=\"let entry of entries\">\n      <td class=\"cx-delivery-item-id\">\n        <div>\n          {{ entry.sapOrderEntryNumber }}\n        </div>\n        <div class=\"d-block d-sm-none\">\n          <span class=\"cx-mobile-header\">{{\n            'documentFlow.dialog.orderItemId' | cxTranslate\n          }}</span>\n          <span class=\"cx-order-item-id\">{{\n            entry.sapSubsequentDocumentEntryNumber\n          }}</span>\n        </div>\n        <div class=\"d-block d-sm-none\">\n          <span class=\"cx-mobile-header\">{{\n            'documentFlow.dialog.date' | cxTranslate\n          }}</span>\n          <span class=\"cx-date\">{{\n            entry.sapCreatedAt | cxDate: 'shortDate'\n          }}</span>\n        </div>\n        <div class=\"d-block d-sm-none\">\n          <span class=\"cx-mobile-header\">{{\n            'documentFlow.dialog.time' | cxTranslate\n          }}</span>\n          <span class=\"cx-time\">{{\n            entry.sapCreatedAt | cxDate: 'shortTime'\n          }}</span>\n        </div>\n      </td>\n      <td class=\"cx-order-item-id d-none d-sm-table-cell\">\n        {{ entry.sapSubsequentDocumentEntryNumber }}\n      </td>\n      <td class=\"d-none d-sm-table-cell text-center\">\n        {{ entry.sapCreatedAt | cxDate: 'shortDate' }}\n      </td>\n      <td class=\"d-none d-sm-table-cell text-center\">\n        {{ entry.sapCreatedAt | cxDate: 'shortTime' }}\n      </td>\n      <td class=\"text-center\">\n        {{ 'documentFlow.dialog.status_' + entry.sapStatus | cxTranslate }}\n      </td>\n    </tr>\n  </tbody>\n</table>\n", dependencies: [{ kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: CxDatePipe, name: "cxDate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentOrderEntryListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-order-document-order-entry-list', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgFor, TranslatePipe, CxDatePipe], template: "<table class=\"table\">\n  <thead>\n    <tr>\n      <th>\n        {{ 'documentFlow.dialog.deliveryItemId' | cxTranslate }}\n      </th>\n      <th class=\"d-none d-sm-table-cell\">\n        {{ 'documentFlow.dialog.orderItemId' | cxTranslate }}\n      </th>\n      <th class=\"d-none d-sm-table-cell text-center\">\n        {{ 'documentFlow.dialog.date' | cxTranslate }}\n      </th>\n      <th class=\"d-none d-sm-table-cell text-center\">\n        {{ 'documentFlow.dialog.time' | cxTranslate }}\n      </th>\n      <th class=\"text-center\">\n        {{ 'documentFlow.dialog.status' | cxTranslate }}\n      </th>\n    </tr>\n  </thead>\n  <tbody>\n    <tr *ngFor=\"let entry of entries\">\n      <td class=\"cx-delivery-item-id\">\n        <div>\n          {{ entry.sapOrderEntryNumber }}\n        </div>\n        <div class=\"d-block d-sm-none\">\n          <span class=\"cx-mobile-header\">{{\n            'documentFlow.dialog.orderItemId' | cxTranslate\n          }}</span>\n          <span class=\"cx-order-item-id\">{{\n            entry.sapSubsequentDocumentEntryNumber\n          }}</span>\n        </div>\n        <div class=\"d-block d-sm-none\">\n          <span class=\"cx-mobile-header\">{{\n            'documentFlow.dialog.date' | cxTranslate\n          }}</span>\n          <span class=\"cx-date\">{{\n            entry.sapCreatedAt | cxDate: 'shortDate'\n          }}</span>\n        </div>\n        <div class=\"d-block d-sm-none\">\n          <span class=\"cx-mobile-header\">{{\n            'documentFlow.dialog.time' | cxTranslate\n          }}</span>\n          <span class=\"cx-time\">{{\n            entry.sapCreatedAt | cxDate: 'shortTime'\n          }}</span>\n        </div>\n      </td>\n      <td class=\"cx-order-item-id d-none d-sm-table-cell\">\n        {{ entry.sapSubsequentDocumentEntryNumber }}\n      </td>\n      <td class=\"d-none d-sm-table-cell text-center\">\n        {{ entry.sapCreatedAt | cxDate: 'shortDate' }}\n      </td>\n      <td class=\"d-none d-sm-table-cell text-center\">\n        {{ entry.sapCreatedAt | cxDate: 'shortTime' }}\n      </td>\n      <td class=\"text-center\">\n        {{ 'documentFlow.dialog.status_' + entry.sapStatus | cxTranslate }}\n      </td>\n    </tr>\n  </tbody>\n</table>\n" }]
        }], propDecorators: { entries: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OrderDocumentFlowDialogComponent {
    constructor() {
        this.launchDialogService = inject(LaunchDialogService);
        this.orderDocumentFlowFacade = inject(OrderDocumentFlowFacade);
        this.translation = inject(TranslationService);
        this.cd = inject(ChangeDetectorRef);
        this.destroyRef = inject(DestroyRef);
        this.savedScrollPosition = 0;
        this.globalMessageType = GlobalMessageType;
        this.iconTypes = ICON_TYPE;
        this.focusConfig = {
            trap: true,
            block: true,
            autofocus: true,
            focusOnEscape: true,
        };
        this.displayDocumentEntries = signal(false, ...(ngDevMode ? [{ debugName: "displayDocumentEntries" }] : /* istanbul ignore next */ []));
        this.orderCode$ = this.launchDialogService.data$.pipe(map((data) => data.orderCode));
        this.documents$ = this.orderCode$.pipe(switchMap((orderId) => {
            return this.orderDocumentFlowFacade.getOrderSubsequentDocuments(orderId);
        }), catchError(() => {
            this.loadError.set(true);
            return of([]);
        }), takeUntilDestroyed(this.destroyRef), shareReplay());
        this.loadError = signal(false, ...(ngDevMode ? [{ debugName: "loadError" }] : /* istanbul ignore next */ []));
        this.selectedDocumentSubject = new BehaviorSubject(undefined);
        this.selectedDocument$ = this.selectedDocumentSubject.asObservable();
        this.documentEntriesCache = new Map();
        this.selectedDocumentEntries$ = this.selectedDocument$.pipe(filter(isNotNullable), withLatestFrom(this.orderCode$), switchMap(([document, orderCode]) => {
            const cachedEntries = this.documentEntriesCache.get(document);
            if (cachedEntries) {
                return of(cachedEntries);
            }
            return this.orderDocumentFlowFacade
                .getOrderSubsequentDocumentEntries(orderCode, document.sapDocumentCategory ?? '', document.sapDocumentId ?? '')
                .pipe(tap((entries) => this.cacheDocumentEntries(document, entries)));
        }), catchError(() => {
            this.loadError.set(true);
            return of([]);
        }));
    }
    getDocumentTitle(document) {
        return document.sapDocumentEntryIdColumnName + ' ' + document.sapDocumentId;
    }
    onDocumentSelection(document) {
        this.saveScrollPosition();
        this.selectedDocumentSubject.next(document);
        this.displayDocumentEntries.set(true);
    }
    goBack() {
        this.displayDocumentEntries.set(false);
        this.loadError.set(false);
        this.restoreScrollPosition();
    }
    close(reason) {
        this.launchDialogService.closeDialog(reason);
    }
    cacheDocumentEntries(document, entries) {
        if (entries.length > 0) {
            this.documentEntriesCache.set(document, entries);
        }
    }
    saveScrollPosition() {
        this.savedScrollPosition = this.scrollContainerRef.nativeElement.scrollTop;
    }
    restoreScrollPosition() {
        setTimeout(() => {
            this.scrollContainerRef.nativeElement.scrollTop =
                this.savedScrollPosition;
        }, 0);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OrderDocumentFlowDialogComponent, isStandalone: true, selector: "cx-order-document-flow-dialog", viewQueries: [{ propertyName: "scrollContainerRef", first: true, predicate: ["scrollContainer"], descendants: true }], ngImport: i0, template: "<div\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"close('Escape clicked')\"\n  class=\"cx-modal-container\"\n  role=\"dialog\"\n  aria-labelledby=\"dialogTitle\"\n  aria-modal=\"true\"\n>\n  <div class=\"cx-modal-content\">\n    <div class=\"cx-dialog-header modal-header\">\n      <div id=\"dialogTitle\" class=\"cx-dialog-title modal-title\">\n        <ng-container *ngIf=\"displayDocumentEntries(); else defaultTitle\">\n          <span>\n            <button\n              class=\"btn-tertiary back\"\n              title=\"{{ 'common.back' | cxTranslate }}\"\n              (click)=\"goBack()\"\n            >\n              <cx-icon [type]=\"iconTypes.CARET_LEFT\" />\n            </button>\n          </span>\n          <span *ngIf=\"selectedDocument$ | async as document\">\n            {{ getDocumentTitle(document) }}\n          </span>\n        </ng-container>\n        <ng-template #defaultTitle>\n          <span>{{ 'documentFlow.dialog.title' | cxTranslate }}</span>\n        </ng-template>\n      </div>\n      <button\n        type=\"button\"\n        class=\"close\"\n        attr.aria-label=\"{{ 'documentFlow.dialog.closeModal' | cxTranslate }}\"\n        title=\"{{ 'documentFlow.dialog.closeModal' | cxTranslate }}\"\n        (click)=\"close('Close dialog')\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\" />\n        </span>\n      </button>\n    </div>\n\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\" #scrollContainer>\n      <cx-message\n        *ngIf=\"loadError(); else content\"\n        [text]=\"'documentFlow.dialog.error' | cxTranslate\"\n        [type]=\"globalMessageType.MSG_TYPE_ERROR\"\n        [isVisibleCloseButton]=\"false\"\n        class=\"cx-dialog-message error-message\"\n      />\n      <ng-template #content>\n        <ng-container *ngIf=\"displayDocumentEntries(); else documentsView\">\n          <ng-container\n            *ngIf=\"selectedDocumentEntries$ | async as entries; else spinner\"\n          >\n            <cx-order-document-order-entry-list\n              *ngIf=\"entries.length > 0; else empty\"\n              [entries]=\"entries\"\n            />\n          </ng-container>\n        </ng-container>\n        <ng-template #documentsView>\n          <ng-container *ngIf=\"documents$ | async as documents; else spinner\">\n            <cx-order-subsequent-document-list\n              *ngIf=\"documents.length > 0; else empty\"\n              [documents]=\"documents\"\n              [selectedDocument]=\"selectedDocument$ | async\"\n              (documentSelected)=\"onDocumentSelection($event)\"\n            />\n          </ng-container>\n        </ng-template>\n      </ng-template>\n    </div>\n\n    <!-- Modal Footer -->\n    <div class=\"cx-dialog-footer modal-footer\">\n      <button\n        (click)=\"close('Cancel dialog')\"\n        [attr.aria-label]=\"'common.cancel' | cxTranslate\"\n        class=\"btn btn-secondary cancel-button\"\n        type=\"button\"\n      >\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n\n<ng-template #empty>\n  <cx-message\n    [text]=\"'documentFlow.dialog.empty' | cxTranslate\"\n    [type]=\"globalMessageType.MSG_TYPE_INFO\"\n    [isVisibleCloseButton]=\"false\"\n    class=\"cx-dialog-message info-message\"\n  />\n</ng-template>\n<ng-template #spinner>\n  <div class=\"cx-spinner\">\n    <cx-spinner />\n  </div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "component", type: MessageComponent, selector: "cx-message", inputs: ["text", "actionButtonText", "actionButtonMessage", "accordionText", "showBody", "isVisibleCloseButton", "type"], outputs: ["closeMessage", "buttonAction"] }, { kind: "component", type: OrderDocumentOrderEntryListComponent, selector: "cx-order-document-order-entry-list", inputs: ["entries"] }, { kind: "component", type: OrderSubsequentDocumentListComponent, selector: "cx-order-subsequent-document-list", inputs: ["documents", "selectedDocument"], outputs: ["documentSelected"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-order-document-flow-dialog', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        FocusDirective,
                        NgIf,
                        IconComponent,
                        MessageComponent,
                        OrderDocumentOrderEntryListComponent,
                        OrderSubsequentDocumentListComponent,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<div\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"close('Escape clicked')\"\n  class=\"cx-modal-container\"\n  role=\"dialog\"\n  aria-labelledby=\"dialogTitle\"\n  aria-modal=\"true\"\n>\n  <div class=\"cx-modal-content\">\n    <div class=\"cx-dialog-header modal-header\">\n      <div id=\"dialogTitle\" class=\"cx-dialog-title modal-title\">\n        <ng-container *ngIf=\"displayDocumentEntries(); else defaultTitle\">\n          <span>\n            <button\n              class=\"btn-tertiary back\"\n              title=\"{{ 'common.back' | cxTranslate }}\"\n              (click)=\"goBack()\"\n            >\n              <cx-icon [type]=\"iconTypes.CARET_LEFT\" />\n            </button>\n          </span>\n          <span *ngIf=\"selectedDocument$ | async as document\">\n            {{ getDocumentTitle(document) }}\n          </span>\n        </ng-container>\n        <ng-template #defaultTitle>\n          <span>{{ 'documentFlow.dialog.title' | cxTranslate }}</span>\n        </ng-template>\n      </div>\n      <button\n        type=\"button\"\n        class=\"close\"\n        attr.aria-label=\"{{ 'documentFlow.dialog.closeModal' | cxTranslate }}\"\n        title=\"{{ 'documentFlow.dialog.closeModal' | cxTranslate }}\"\n        (click)=\"close('Close dialog')\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\" />\n        </span>\n      </button>\n    </div>\n\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\" #scrollContainer>\n      <cx-message\n        *ngIf=\"loadError(); else content\"\n        [text]=\"'documentFlow.dialog.error' | cxTranslate\"\n        [type]=\"globalMessageType.MSG_TYPE_ERROR\"\n        [isVisibleCloseButton]=\"false\"\n        class=\"cx-dialog-message error-message\"\n      />\n      <ng-template #content>\n        <ng-container *ngIf=\"displayDocumentEntries(); else documentsView\">\n          <ng-container\n            *ngIf=\"selectedDocumentEntries$ | async as entries; else spinner\"\n          >\n            <cx-order-document-order-entry-list\n              *ngIf=\"entries.length > 0; else empty\"\n              [entries]=\"entries\"\n            />\n          </ng-container>\n        </ng-container>\n        <ng-template #documentsView>\n          <ng-container *ngIf=\"documents$ | async as documents; else spinner\">\n            <cx-order-subsequent-document-list\n              *ngIf=\"documents.length > 0; else empty\"\n              [documents]=\"documents\"\n              [selectedDocument]=\"selectedDocument$ | async\"\n              (documentSelected)=\"onDocumentSelection($event)\"\n            />\n          </ng-container>\n        </ng-template>\n      </ng-template>\n    </div>\n\n    <!-- Modal Footer -->\n    <div class=\"cx-dialog-footer modal-footer\">\n      <button\n        (click)=\"close('Cancel dialog')\"\n        [attr.aria-label]=\"'common.cancel' | cxTranslate\"\n        class=\"btn btn-secondary cancel-button\"\n        type=\"button\"\n      >\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n\n<ng-template #empty>\n  <cx-message\n    [text]=\"'documentFlow.dialog.empty' | cxTranslate\"\n    [type]=\"globalMessageType.MSG_TYPE_INFO\"\n    [isVisibleCloseButton]=\"false\"\n    class=\"cx-dialog-message info-message\"\n  />\n</ng-template>\n<ng-template #spinner>\n  <div class=\"cx-spinner\">\n    <cx-spinner />\n  </div>\n</ng-template>\n" }]
        }], propDecorators: { scrollContainerRef: [{
                type: ViewChild,
                args: ['scrollContainer']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOrderDocumentFlowDialogLayoutConfig = {
    launch: {
        ORDER_DOCUMENT_FLOW: {
            inlineRoot: true,
            component: OrderDocumentFlowDialogComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OrderDocumentFlowComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowComponentsModule, imports: [CommonModule,
            I18nModule,
            UrlModule,
            SpinnerModule,
            RouterModule,
            KeyboardFocusModule,
            IconModule,
            MessageComponentModule,
            OrderDocumentFlowComponent,
            OrderDocumentFlowDialogComponent,
            OrderSubsequentDocumentListComponent,
            OrderSubsequentDocumentNodeComponent,
            OrderDocumentOrderEntryListComponent], exports: [OrderDocumentFlowComponent,
            OrderDocumentFlowDialogComponent,
            OrderSubsequentDocumentListComponent,
            OrderSubsequentDocumentNodeComponent,
            OrderDocumentOrderEntryListComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowComponentsModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    AccountOrderDocumentFlowComponent: {
                        component: OrderDocumentFlowComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
            provideDefaultConfig(defaultOrderDocumentFlowDialogLayoutConfig),
        ], imports: [CommonModule,
            I18nModule,
            UrlModule,
            SpinnerModule,
            RouterModule,
            KeyboardFocusModule,
            IconModule,
            MessageComponentModule,
            OrderDocumentFlowDialogComponent,
            OrderSubsequentDocumentListComponent,
            OrderSubsequentDocumentNodeComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        UrlModule,
                        SpinnerModule,
                        RouterModule,
                        KeyboardFocusModule,
                        IconModule,
                        MessageComponentModule,
                        OrderDocumentFlowComponent,
                        OrderDocumentFlowDialogComponent,
                        OrderSubsequentDocumentListComponent,
                        OrderSubsequentDocumentNodeComponent,
                        OrderDocumentOrderEntryListComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                AccountOrderDocumentFlowComponent: {
                                    component: OrderDocumentFlowComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                        provideDefaultConfig(defaultOrderDocumentFlowDialogLayoutConfig),
                    ],
                    exports: [
                        OrderDocumentFlowComponent,
                        OrderDocumentFlowDialogComponent,
                        OrderSubsequentDocumentListComponent,
                        OrderSubsequentDocumentNodeComponent,
                        OrderDocumentOrderEntryListComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OrderDocumentFlowComponent, OrderDocumentFlowComponentsModule, OrderDocumentFlowDialogComponent, OrderDocumentOrderEntryListComponent, OrderSubsequentDocumentListComponent, OrderSubsequentDocumentNodeComponent };
//# sourceMappingURL=spartacus-order-document-flow-components.mjs.map
