import { HttpClient, HttpHeaders } from '@angular/common/http';
import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { LoggerService, OccEndpointsService, ConverterService, tryNormalizeHttpError, provideDefaultConfig } from '@spartacus/core';
import { catchError } from 'rxjs/operators';
import { CommonModule } from '@angular/common';
import { OrderDocumentFlowAdapter } from '@spartacus/order/document-flow/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccOrderDocumentFlowAdapter {
    constructor() {
        this.logger = inject(LoggerService);
        this.http = inject(HttpClient);
        this.occEndpoints = inject(OccEndpointsService);
        this.converter = inject(ConverterService);
    }
    getOrderSubsequentDocuments(userId, orderId) {
        const headers = new HttpHeaders().set('Content-Type', 'application/json');
        return this.http
            .get(this.getSubsequentDocumentsUrl(orderId, userId), { headers })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    getOrderSubsequentDocumentEntries(userId, orderId, documentCategory, documentId) {
        const headers = new HttpHeaders().set('Content-Type', 'application/json');
        return this.http
            .get(this.getSubsequentDocumentsEntriesUrl(orderId, userId, documentCategory, documentId), { headers })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    getSubsequentDocumentsUrl(orderId, userId) {
        return this.occEndpoints.buildUrl('subsequentDocuments', {
            urlParams: {
                userId,
                orderId,
            },
        });
    }
    getSubsequentDocumentsEntriesUrl(orderId, userId, documentCategory, documentId) {
        return this.occEndpoints.buildUrl('subsequentDocumentsEntries', {
            urlParams: {
                userId,
                orderId,
                documentCategory,
                documentId,
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccOrderDocumentFlowAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccOrderDocumentFlowAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccOrderDocumentFlowAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const documentFlowOccEndpoints = {
    subsequentDocuments: 'users/${userId}/orders/${orderId}/subsequentDocuments',
    subsequentDocumentsEntries: 'users/${userId}/orders/${orderId}/subsequentDocuments/${documentCategory}/${documentId}/entries',
};
const defaultOccDocumentFlowConfigFactory = {
    backend: {
        occ: {
            endpoints: {
                ...documentFlowOccEndpoints,
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OrderDocumentFlowOccModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowOccModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowOccModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowOccModule, providers: [
            provideDefaultConfig(defaultOccDocumentFlowConfigFactory),
            {
                provide: OrderDocumentFlowAdapter,
                useClass: OccOrderDocumentFlowAdapter,
            },
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowOccModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [
                        provideDefaultConfig(defaultOccDocumentFlowConfigFactory),
                        {
                            provide: OrderDocumentFlowAdapter,
                            useClass: OccOrderDocumentFlowAdapter,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
// Imported for side effects (module augmentation)

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OccOrderDocumentFlowAdapter, OrderDocumentFlowOccModule };
//# sourceMappingURL=spartacus-order-document-flow-occ.mjs.map
