import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { UserIdService } from '@spartacus/core';
import { switchMap } from 'rxjs';
import { OrderDocumentFlowFacade } from '@spartacus/order/document-flow/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OrderDocumentFlowAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OrderDocumentFlowConnector {
    constructor() {
        this.adapter = inject(OrderDocumentFlowAdapter);
    }
    getOrderSubsequentDocuments(userId, orderId) {
        return this.adapter.getOrderSubsequentDocuments(userId, orderId);
    }
    getOrderSubsequentDocumentEntries(userId, orderId, documentCategory, documentId) {
        return this.adapter.getOrderSubsequentDocumentEntries(userId, orderId, documentCategory, documentId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OrderDocumentFlowService {
    constructor() {
        this.orderAttachmentsConnector = inject(OrderDocumentFlowConnector);
        this.userIdService = inject(UserIdService);
    }
    getOrderSubsequentDocuments(orderId) {
        return this.userIdService
            .takeUserId()
            .pipe(switchMap((userId) => this.orderAttachmentsConnector.getOrderSubsequentDocuments(userId, orderId)));
    }
    getOrderSubsequentDocumentEntries(orderId, documentCategory, documentId) {
        return this.userIdService
            .takeUserId()
            .pipe(switchMap((userId) => this.orderAttachmentsConnector.getOrderSubsequentDocumentEntries(userId, orderId, documentCategory, documentId)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const facadeProviders = [
    OrderDocumentFlowService,
    {
        provide: OrderDocumentFlowFacade,
        useExisting: OrderDocumentFlowService,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OrderDocumentFlowCoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowCoreModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowCoreModule, providers: [...facadeProviders, OrderDocumentFlowConnector] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [...facadeProviders, OrderDocumentFlowConnector],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OrderDocumentFlowAdapter, OrderDocumentFlowConnector, OrderDocumentFlowCoreModule, OrderDocumentFlowService };
//# sourceMappingURL=spartacus-order-document-flow-core.mjs.map
