var documentFlow = {
	button: "View Document Flow",
	dialog: {
		title: "Document",
		closeModal: "Close",
		name: "Document name",
		date: "Date",
		time: "Time",
		status: "Status",
		status_OPEN: "Open",
		status_IN_PROCESS: "In process",
		status_COMPLETED: "Completed",
		status_NOT_RELEVANT: "Not relevant",
		orderItems: "Order Items",
		deliveryItemId: "Delivery Item ID",
		orderItemId: "Order Item ID",
		error: "Please try again later as an error occurred while retrieving the documents.",
		empty: "Documents are available here after they are added to an order in the backend SAP S/4HANA system."
	}
};
var documentFlow$1 = {
	documentFlow: documentFlow
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const en = {
    documentFlow: documentFlow$1,
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const orderDocumentFlowTranslationChunksConfig = {
    documentFlow: ['documentFlow'],
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { en as documentFlowTranslationsEn, orderDocumentFlowTranslationChunksConfig };
//# sourceMappingURL=spartacus-order-document-flow-assets.mjs.map
