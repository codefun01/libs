import * as i0 from '@angular/core';
import { NgModule, Injectable } from '@angular/core';
import { provideDefaultConfig, facadeFactory } from '@spartacus/core';
import { LAUNCH_CALLER } from '@spartacus/storefront';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const ORDER_DOCUMENT_FLOW_FEATURE = 'orderDocumentFlow';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OrderDocumentFlowRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowRootModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowRootModule, providers: [
            provideDefaultConfig({
                featureModules: {
                    [ORDER_DOCUMENT_FLOW_FEATURE]: {
                        cmsComponents: ['AccountOrderDocumentFlowComponent'],
                    },
                },
            }),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowRootModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        provideDefaultConfig({
                            featureModules: {
                                [ORDER_DOCUMENT_FLOW_FEATURE]: {
                                    cmsComponents: ['AccountOrderDocumentFlowComponent'],
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
LAUNCH_CALLER['ORDER_DOCUMENT_FLOW'] = 'ORDER_DOCUMENT_FLOW';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OrderDocumentFlowFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: OrderDocumentFlowFacade,
            feature: ORDER_DOCUMENT_FLOW_FEATURE,
            methods: [
                'getOrderSubsequentDocuments',
                'getOrderSubsequentDocumentEntries',
            ],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OrderDocumentFlowFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: OrderDocumentFlowFacade,
                        feature: ORDER_DOCUMENT_FLOW_FEATURE,
                        methods: [
                            'getOrderSubsequentDocuments',
                            'getOrderSubsequentDocumentEntries',
                        ],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ORDER_DOCUMENT_FLOW_FEATURE, OrderDocumentFlowFacade, OrderDocumentFlowRootModule };
//# sourceMappingURL=spartacus-order-document-flow-root.mjs.map
