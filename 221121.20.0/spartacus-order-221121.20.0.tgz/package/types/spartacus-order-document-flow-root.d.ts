import * as i0 from '@angular/core';
import { Observable } from 'rxjs';

declare const ORDER_DOCUMENT_FLOW_FEATURE = "orderDocumentFlow";

declare class OrderDocumentFlowRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDocumentFlowRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderDocumentFlowRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderDocumentFlowRootModule>;
}

declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        ORDER_DOCUMENT_FLOW = "ORDER_DOCUMENT_FLOW"
    }
}

interface OrderSubsequentDocument {
    sapDocumentId?: string;
    sapDocumentCategory?: string;
    sapDocumentEntryIdColumnName?: string;
    sapSubsequentDocuments?: OrderSubsequentDocument[];
    sapCreatedAt?: Date;
    sapStatus?: string;
}
interface OrderSubsequentDocumentEntry {
    sapSubsequentDocumentEntryNumber?: string;
    sapOrderEntryNumber?: string;
    sapCreatedAt?: Date;
    sapStatus?: string;
}

declare abstract class OrderDocumentFlowFacade {
    /**
     * Get order document flow
     */
    abstract getOrderSubsequentDocuments(orderId: string): Observable<OrderSubsequentDocument[]>;
    /**
     * Get order document entries
     */
    abstract getOrderSubsequentDocumentEntries(orderId: string, documentCategory: string, documentId: string): Observable<OrderSubsequentDocumentEntry[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDocumentFlowFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderDocumentFlowFacade>;
}

export { ORDER_DOCUMENT_FLOW_FEATURE, OrderDocumentFlowFacade, OrderDocumentFlowRootModule };
export type { OrderSubsequentDocument, OrderSubsequentDocumentEntry };
