import { PointOfService, Address, CostCenter, Price, B2BUser, B2BUnit, PaymentDetails, Principal, PaginationModel, SortModel, CxEvent, CmsConfig, Converter } from '@spartacus/core';
import { ConsignmentEntry, PromotionResult, Voucher, DeliveryMode, DeliveryOrderEntryGroup, OrderEntry, PickupOrderEntryGroup, PaymentType, CartModificationList } from '@spartacus/cart/base/root';
import { Observable } from 'rxjs';
import * as i1 from '@angular/router';
import { Params } from '@angular/router';
import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import { Card } from '@spartacus/storefront';

interface CancelOrReturnRequestEntryInput {
    orderEntryNumber?: number;
    quantity?: number;
}
interface ReturnRequestEntryInputList {
    orderCode?: string;
    returnRequestEntryInputs?: CancelOrReturnRequestEntryInput[];
}
interface CancellationRequestEntryInputList {
    cancellationRequestEntryInputs?: CancelOrReturnRequestEntryInput[];
}
interface ReturnRequestEntry {
    orderEntry?: OrderEntry;
    expectedQuantity?: number;
    refundAmount?: Price;
}
interface ReturnRequest {
    cancellable?: boolean;
    code?: string;
    creationTime?: Date;
    deliveryCost?: Price;
    order?: Order;
    refundDeliveryCost?: boolean;
    returnEntries?: ReturnRequestEntry[];
    returnLabelDownloadUrl?: string;
    rma?: string;
    status?: string;
    subTotal?: Price;
    totalPrice?: Price;
}
interface ReturnRequestList {
    returnRequests?: ReturnRequest[];
    pagination?: PaginationModel;
    sorts?: SortModel[];
}
interface ReturnRequestModification {
    status?: string;
}
interface Consignment {
    code?: string;
    deliveryPointOfService?: PointOfService;
    entries?: ConsignmentEntry[];
    shippingAddress?: Address;
    status?: string;
    statusDate?: Date;
    trackingID?: string;
}
interface OrderHistory {
    code?: string;
    guid?: string;
    placed?: Date;
    status?: string;
    statusDisplay?: string;
    total?: Price;
    costCenter?: CostCenter;
    purchaseOrderNumber?: string;
    orgUnit?: B2BUnit;
    orgCustomer?: B2BUser;
}
interface OrderHistoryList {
    orders?: OrderHistory[];
    pagination?: PaginationModel;
    sorts?: SortModel[];
}
interface Order {
    appliedOrderPromotions?: PromotionResult[];
    appliedProductPromotions?: PromotionResult[];
    appliedVouchers?: Voucher[];
    calculated?: boolean;
    code?: string;
    consignments?: Consignment[];
    costCenter?: CostCenter;
    created?: Date;
    deliveryAddress?: Address;
    deliveryCost?: Price;
    deliveryItemsQuantity?: number;
    deliveryMode?: DeliveryMode;
    deliveryOrderGroups?: DeliveryOrderEntryGroup[];
    deliveryStatus?: string;
    deliveryStatusDisplay?: string;
    entries?: OrderEntry[];
    guestCustomer?: boolean;
    guid?: string;
    net?: boolean;
    orderDiscounts?: Price;
    orgCustomer?: B2BUser;
    orgUnit?: B2BUnit;
    paymentInfo?: PaymentDetails;
    pickupItemsQuantity?: number;
    pickupOrderGroups?: PickupOrderEntryGroup[];
    productDiscounts?: Price;
    purchaseOrderNumber?: string;
    site?: string;
    status?: string;
    statusDisplay?: string;
    store?: string;
    subTotal?: Price;
    totalDiscounts?: Price;
    totalItems?: number;
    totalPrice?: Price;
    totalPriceWithTax?: Price;
    totalTax?: Price;
    unconsignedEntries?: OrderEntry[];
    user?: Principal;
    returnable?: boolean;
    cancellable?: boolean;
    sapQuoteCode?: string;
}

interface ReplenishmentOrder {
    active?: boolean;
    appliedOrderPromotions?: PromotionResult[];
    appliedProductPromotions?: PromotionResult[];
    appliedVouchers?: Voucher[];
    calculated?: boolean;
    code?: string;
    costCenter?: CostCenter;
    deliveryAddress?: Address;
    deliveryCost?: Price;
    deliveryItemsQuantity?: number;
    deliveryMode?: DeliveryMode;
    deliveryOrderGroups?: DeliveryOrderEntryGroup[];
    description?: string;
    entries?: OrderEntry[];
    expirationTime?: string;
    firstDate?: string;
    guid?: string;
    name?: string;
    net?: boolean;
    orderDiscounts?: Price;
    paymentInfo?: PaymentDetails;
    paymentStatus?: string;
    paymentType?: PaymentType;
    pickupItemsQuantity?: number;
    pickupOrderGroups?: PickupOrderEntryGroup[];
    potentialOrderPromotions?: PromotionResult[];
    potentialProductPromotions?: PromotionResult[];
    productDiscounts?: Price;
    purchaseOrderNumber?: string;
    replenishmentOrderCode?: string;
    saveTime?: string;
    savedBy?: Principal;
    site?: string;
    store?: string;
    subTotal?: Price;
    totalDiscounts?: Price;
    totalItems?: number;
    totalPrice?: Price;
    totalPriceWithTax?: Price;
    totalTax?: Price;
    totalUnitCount?: number;
    trigger?: Trigger;
    user?: Principal;
}
interface ReplenishmentOrderList {
    replenishmentOrders?: ReplenishmentOrder[];
    pagination?: PaginationModel;
    sorts?: SortModel[];
}
interface Trigger {
    activationTime?: string;
    displayTimeTable?: string;
}

/**
 * An abstract event for all the order events.
 */
declare abstract class OrderEvent extends CxEvent {
    userId?: string;
    /**
     * Usually set via `getCartIdByUserId()` util method,
     * It is an abstraction over the different properties
     * used for anonymous and logged-in users' carts:
     * - `code` for logged-in users
     * - `guid` for anonymous users
     */
    cartId?: string;
    /**
     * All carts have the `code` property assigned to them,
     * regardless of whether they are anonymous or logged-in.
     * In case of logged-in users, the `cartCode` and `cartId` are the same.
     */
    cartCode?: string;
}
/**
 * Indicates that a user has successfully placed an order.
 */
declare class OrderPlacedEvent extends OrderEvent {
    /**
     * Event's type
     */
    static readonly type = "OrderPlacedEvent";
    /**
     * Order
     */
    order: Order;
}
/**
 * Indicates that a user has successfully placed scheduled an order.
 */
declare class ReplenishmentOrderScheduledEvent extends OrderEvent {
    /**
     * Event's type
     */
    static readonly type = "ReplenishmentOrderScheduledEvent";
    /**
     * Replenishment Order
     */
    replenishmentOrder: ReplenishmentOrder;
}
/**
 * Indicates that a user has click on 'Download Invoices' button on Order details page
 */
declare class DownloadOrderInvoicesEvent extends CxEvent {
    /**
     * Event's type
     */
    static readonly type = "DownloadOrderInvoicesEvent";
    /**
     * Order
     */
    order: Order;
}

interface ConsignmentTrackingEvent {
    eventDate?: string;
    detail?: string;
    location?: string;
    referenceCode?: string;
}
interface Carrier {
    code?: string;
    name?: string;
}
interface ConsignmentTracking {
    statusDisplay?: string;
    carrierDetails?: Carrier;
    trackingID?: string;
    trackingUrl?: string;
    targetArrivalDate?: string;
    trackingEvents?: ConsignmentTrackingEvent[];
}

declare function orderHistoryFacadeFactory(): OrderHistoryFacade;
declare abstract class OrderHistoryFacade {
    /**
     * Returns an order's detail
     */
    abstract getOrderDetails(): Observable<Order>;
    /**
     * Retrieves order's details
     *
     * @param orderCode an order code
     */
    abstract loadOrderDetails(orderCode: string): void;
    /**
     * Clears order's details
     */
    abstract clearOrderDetails(): void;
    /**
     * Returns order history list
     */
    abstract getOrderHistoryList(pageSize: number): Observable<OrderHistoryList | undefined>;
    /**
     * Returns a loaded flag for order history list
     */
    abstract getOrderHistoryListLoaded(): Observable<boolean>;
    /**
     * Retrieves an order list
     * @param pageSize page size
     * @param currentPage current page
     * @param sort sort
     */
    abstract loadOrderList(pageSize: number, currentPage?: number, sort?: string): void;
    /**
     * Cleaning order list
     */
    abstract clearOrderList(): void;
    /**
     *  Returns a consignment tracking detail
     */
    abstract getConsignmentTracking(): Observable<ConsignmentTracking>;
    /**
     * Retrieves consignment tracking details
     * @param orderCode an order code
     * @param consignmentCode a consignment code
     */
    abstract loadConsignmentTracking(orderCode: string, consignmentCode: string): void;
    /**
     * Cleaning consignment tracking
     */
    abstract clearConsignmentTracking(): void;
    abstract cancelOrder(orderCode: string, cancelRequestInput: CancellationRequestEntryInputList): void;
    /**
     * Returns the cancel order loading flag
     */
    abstract getCancelOrderLoading(): Observable<boolean>;
    /**
     * Returns the cancel order success flag
     */
    abstract getCancelOrderSuccess(): Observable<boolean>;
    /**
     * Resets the cancel order process flags
     */
    abstract resetCancelOrderProcessState(): void;
    /**
     * Returns an order details loading flag
     */
    abstract getOrderDetailsLoading(): Observable<boolean>;
    /**
     * @deprecated: Method doesn't pass facade method's requirements (returns void or Observable)
     * Returns query parameters needed for order details route
     */
    abstract getQueryParams(order: Order): Params | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderHistoryFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderHistoryFacade>;
}

declare function orderReturnRequestFacadeFactory(): OrderReturnRequestFacade;
declare abstract class OrderReturnRequestFacade {
    /**
     * Create order return request
     * @param orderCode an order code
     * @param returnRequestInput order return request entry input
     */
    abstract createOrderReturnRequest(returnRequestInput: ReturnRequestEntryInputList): void;
    /**
     * Return an order return request
     */
    abstract getOrderReturnRequest(): Observable<ReturnRequest>;
    /**
     * Gets order return request list
     */
    abstract getOrderReturnRequestList(pageSize: number): Observable<ReturnRequestList | undefined>;
    /**
     * Loads order return request detail
     * @param returnRequestCode
     */
    abstract loadOrderReturnRequestDetail(returnRequestCode: string): void;
    /**
     * Loads order return request list
     * @param pageSize page size
     * @param currentPage current page
     * @param sort sort
     */
    abstract loadOrderReturnRequestList(pageSize: number, currentPage?: number, sort?: string): void;
    /**
     * Cleaning order return request list
     */
    abstract clearOrderReturnRequestList(): void;
    /**
     * Get the order return request loading flag
     */
    abstract getReturnRequestLoading(): Observable<boolean>;
    /**
     * Get the order return request success flag
     */
    abstract getReturnRequestSuccess(): Observable<boolean>;
    /**
     * Cleaning order return request details
     */
    abstract clearOrderReturnRequestDetail(): void;
    abstract cancelOrderReturnRequest(returnRequestCode: string, returnRequestModification: ReturnRequestModification): void;
    /**
     * Returns the cancel return request loading flag
     */
    abstract getCancelReturnRequestLoading(): Observable<boolean>;
    /**
     * Returns the cancel return request success flag
     */
    abstract getCancelReturnRequestSuccess(): Observable<boolean>;
    /**
     * Resets the cancel return request process flags
     */
    abstract resetCancelReturnRequestProcessState(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderReturnRequestFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderReturnRequestFacade>;
}

declare abstract class OrderFacade {
    /**
     * Returns the current order
     */
    abstract getOrderDetails(): Observable<Order | undefined>;
    /**
     * Clears the current order
     */
    abstract clearPlacedOrder(): void;
    /**
     * Sets the provided order as current
     */
    abstract setPlacedOrder(order: Order): void;
    /**
     * Places an order
     */
    abstract placeOrder(termsChecked: boolean): Observable<Order>;
    /**
     * Places an order after the payment was authorized
     */
    abstract placePaymentAuthorizedOrder(termsChecked: boolean, cartId?: string): Observable<Order>;
    /**
     * Return order's pickup entries
     */
    abstract getPickupEntries(): Observable<OrderEntry[]>;
    /**
     * Return order's delivery entries
     */
    abstract getDeliveryEntries(): Observable<OrderEntry[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderFacade>;
}

declare abstract class ReorderOrderFacade {
    /**
     * Create cart from an existing order
     */
    abstract reorder(orderId: string): Observable<CartModificationList>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReorderOrderFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ReorderOrderFacade>;
}

declare function replenishmentOrderHistoryFacadeFactory(): ReplenishmentOrderHistoryFacade;
declare abstract class ReplenishmentOrderHistoryFacade {
    /**
     * Returns replenishment order details for a given 'current' user
     *
     * @param replenishmentOrderCode a replenishment order code
     */
    abstract loadReplenishmentOrderDetails(replenishmentOrderCode: string): void;
    /**
     * Returns a replenishment order details
     */
    abstract getReplenishmentOrderDetails(): Observable<ReplenishmentOrder>;
    /**
     * Returns a replenishment order details loading flag
     */
    abstract getReplenishmentOrderDetailsLoading(): Observable<boolean>;
    /**
     * Returns a replenishment order details success flag
     */
    abstract getReplenishmentOrderDetailsSuccess(): Observable<boolean>;
    /**
     * Returns a replenishment order details error flag
     */
    abstract getReplenishmentOrderDetailsError(): Observable<boolean>;
    /**
     * Clears the replenishment orders details state
     */
    abstract clearReplenishmentOrderDetails(): void;
    /**
     * Cancels a specific replenishment order for a given 'current' user
     *
     * @param replenishmentOrderCode a replenishment order code
     */
    abstract cancelReplenishmentOrder(replenishmentOrderCode: string): void;
    /**
     * Returns the cancel replenishment order loading flag
     */
    abstract getCancelReplenishmentOrderLoading(): Observable<boolean>;
    /**
     * Returns the cancel replenishment order success flag
     */
    abstract getCancelReplenishmentOrderSuccess(): Observable<boolean>;
    /**
     * Returns the cancel replenishment order error flag
     */
    abstract getCancelReplenishmentOrderError(): Observable<boolean>;
    /**
     * Clears the cancel replenishment order processing state
     */
    abstract clearCancelReplenishmentOrderProcessState(): void;
    /**
     * Returns replenishment order history list
     */
    abstract getReplenishmentOrderHistoryList(pageSize: number): Observable<ReplenishmentOrderList | undefined>;
    /**
     * Returns a loading flag for replenishment order history list
     */
    abstract getReplenishmentOrderHistoryListLoading(): Observable<boolean>;
    /**
     * Returns a error flag for replenishment order history list
     */
    abstract getReplenishmentOrderHistoryListError(): Observable<boolean>;
    /**
     * Returns a success flag for replenishment order history list
     */
    abstract getReplenishmentOrderHistoryListSuccess(): Observable<boolean>;
    /**
     * Retrieves a replenishment order list
     * @param pageSize page size
     * @param currentPage current page
     * @param sort sort
     */
    abstract loadReplenishmentOrderList(pageSize?: number, currentPage?: number, sort?: string): void;
    /**
     * Cleaning replenishment order list
     */
    abstract clearReplenishmentOrderList(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReplenishmentOrderHistoryFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ReplenishmentOrderHistoryFacade>;
}

declare const recurrencePeriod: {
    DAILY: string;
    WEEKLY: string;
    MONTHLY: string;
};
declare enum DaysOfWeek {
    MONDAY = "MONDAY",
    TUESDAY = "TUESDAY",
    WEDNESDAY = "WEDNESDAY",
    THURSDAY = "THURSDAY",
    FRIDAY = "FRIDAY",
    SATURDAY = "SATURDAY",
    SUNDAY = "SUNDAY"
}
interface ScheduleReplenishmentForm {
    daysOfWeek?: DaysOfWeek[];
    nthDayOfMonth?: string;
    numberOfDays?: string;
    numberOfWeeks?: string;
    recurrencePeriod?: string;
    replenishmentStartDate?: string;
}
declare enum ORDER_TYPE {
    PLACE_ORDER = "PLACE_ORDER",
    SCHEDULE_REPLENISHMENT_ORDER = "SCHEDULE_REPLENISHMENT_ORDER"
}

declare abstract class ScheduledReplenishmentOrderFacade {
    /**
     * Schedule a replenishment order
     */
    abstract scheduleReplenishmentOrder(scheduleReplenishmentForm: ScheduleReplenishmentForm, termsChecked: boolean): Observable<ReplenishmentOrder>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScheduledReplenishmentOrderFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ScheduledReplenishmentOrderFacade>;
}

declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        CONSIGNMENT_TRACKING = "CONSIGNMENT_TRACKING",
        REORDER = "REORDER",
        DOWNLOAD_ORDER_INVOICES = "DOWNLOAD_ORDER_INVOICES",
        ORDER_ATTACHMENTS = "ORDER_ATTACHMENTS"
    }
}

/**
 * Identifiers of outlets for the order consignment.
 */
declare enum OrderOutlets {
    ORDER_CONSIGNMENT = "cx-order-consignment",
    CONSIGNMENT_DELIVERY_INFO = "cx-order-consignment-delivery-info",
    SERVICE_DETAILS = "cx-service-details-card"
}

interface ConsignmentView extends Consignment {
    consignmentTracking?: ConsignmentTracking;
}
interface OrderHistoryView extends OrderHistory {
    entries?: OrderEntry[];
    consignments?: ConsignmentView[];
    unconsignedEntries?: OrderEntry[];
    returnRequests?: ReturnRequest[];
    totalItems?: number;
    returnable?: boolean;
}
interface OrderHistoryListView extends OrderHistoryList {
    orders?: OrderHistoryView[];
}
interface OrderView extends Order {
    consignments?: ConsignmentView[];
}

interface OrderAttachments {
    sapAttachments?: OrderAttachment[];
}
interface OrderAttachment {
    sapAttachmentId?: string;
    sapFileName?: string;
}

declare abstract class OrderAttachmentsFacade {
    /**
     * Get all order attachments
     */
    abstract getOrderAttachments(orderId: string): Observable<OrderAttachments>;
    /**
     * Download order attachment blob
     */
    abstract downloadOrderAttachment(orderId: string, attachmentId: string): Observable<Blob>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderAttachmentsFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderAttachmentsFacade>;
}

declare const ORDER_FEATURE = "order";
declare const ORDER_CORE_FEATURE = "orderCore";

declare const ORDER_CMS_COMPONENTS: string[];
declare function defaultOrderComponentsConfig(): CmsConfig;
declare class OrderRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderRootModule, never, [typeof i1.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderRootModule>;
}

declare const OrderDetailsOrderEntriesContextToken: InjectionToken<unknown>;
declare const OrderConfirmationOrderEntriesContextToken: InjectionToken<unknown>;
declare const USE_MY_ACCOUNT_V2_ORDER: InjectionToken<boolean>;

declare const ORDER_NORMALIZER: InjectionToken<Converter<any, Order>>;
declare const REPLENISHMENT_ORDER_NORMALIZER: InjectionToken<Converter<any, ReplenishmentOrder>>;
declare const REORDER_ORDER_NORMALIZER: InjectionToken<Converter<any, CartModificationList>>;
declare const ORDER_HISTORY_NORMALIZER: InjectionToken<Converter<any, OrderHistoryList>>;
declare const CONSIGNMENT_TRACKING_NORMALIZER: InjectionToken<Converter<any, ConsignmentTracking>>;
declare const ORDER_RETURN_REQUEST_NORMALIZER: InjectionToken<Converter<any, ReturnRequest>>;
declare const ORDER_RETURN_REQUEST_INPUT_SERIALIZER: InjectionToken<Converter<ReturnRequestEntryInputList, any>>;
declare const ORDER_RETURNS_NORMALIZER: InjectionToken<Converter<any, ReturnRequestList>>;
declare const REPLENISHMENT_ORDER_HISTORY_NORMALIZER: InjectionToken<Converter<any, ReplenishmentOrderList>>;
declare const REPLENISHMENT_ORDER_FORM_SERIALIZER: InjectionToken<Converter<ScheduleReplenishmentForm, any>>;

/**
 * Get card for delivery address
 */
declare function deliveryAddressCard(textTitle: string, textPhone: string, textMobile: string, deliveryAddress: Address, countryName?: string): Card;
/**
 * Get card for delivery mode
 */
declare function deliveryModeCard(textTitle: string, deliveryMode: DeliveryMode): Card;
/**
 * Get card for payment method
 */
declare function paymentMethodCard(textTitle: string, textExpires: string, paymentDetails: PaymentDetails): Card;
/**
 * Get card for billing address
 */
declare function billingAddressCard(textTitle: string, textBillTo: string, paymentDetails: PaymentDetails): Card;

declare abstract class OrderConfig {
    orderAttachments?: {
        previewMimeTypes: string[];
    };
    showOrderQuoteLink?: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderConfig>;
}
declare module '@spartacus/core' {
    interface Config extends OrderConfig {
    }
}

export { CONSIGNMENT_TRACKING_NORMALIZER, DaysOfWeek, DownloadOrderInvoicesEvent, ORDER_CMS_COMPONENTS, ORDER_CORE_FEATURE, ORDER_FEATURE, ORDER_HISTORY_NORMALIZER, ORDER_NORMALIZER, ORDER_RETURNS_NORMALIZER, ORDER_RETURN_REQUEST_INPUT_SERIALIZER, ORDER_RETURN_REQUEST_NORMALIZER, ORDER_TYPE, OrderAttachmentsFacade, OrderConfig, OrderConfirmationOrderEntriesContextToken, OrderDetailsOrderEntriesContextToken, OrderEvent, OrderFacade, OrderHistoryFacade, OrderOutlets, OrderPlacedEvent, OrderReturnRequestFacade, OrderRootModule, REORDER_ORDER_NORMALIZER, REPLENISHMENT_ORDER_FORM_SERIALIZER, REPLENISHMENT_ORDER_HISTORY_NORMALIZER, REPLENISHMENT_ORDER_NORMALIZER, ReorderOrderFacade, ReplenishmentOrderHistoryFacade, ReplenishmentOrderScheduledEvent, ScheduledReplenishmentOrderFacade, USE_MY_ACCOUNT_V2_ORDER, billingAddressCard, defaultOrderComponentsConfig, deliveryAddressCard, deliveryModeCard, orderHistoryFacadeFactory, orderReturnRequestFacadeFactory, paymentMethodCard, recurrencePeriod, replenishmentOrderHistoryFacadeFactory };
export type { CancelOrReturnRequestEntryInput, CancellationRequestEntryInputList, Carrier, Consignment, ConsignmentTracking, ConsignmentTrackingEvent, ConsignmentView, Order, OrderAttachment, OrderAttachments, OrderHistory, OrderHistoryList, OrderHistoryListView, OrderHistoryView, OrderView, ReplenishmentOrder, ReplenishmentOrderList, ReturnRequest, ReturnRequestEntry, ReturnRequestEntryInputList, ReturnRequestList, ReturnRequestModification, ScheduleReplenishmentForm, Trigger };
