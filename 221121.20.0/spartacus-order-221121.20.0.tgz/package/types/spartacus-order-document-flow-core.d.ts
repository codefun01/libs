import { Observable } from 'rxjs';
import { OrderSubsequentDocument, OrderSubsequentDocumentEntry, OrderDocumentFlowFacade } from '@spartacus/order/document-flow/root';
import * as i0 from '@angular/core';
import { UserIdService } from '@spartacus/core';

declare abstract class OrderDocumentFlowAdapter {
    /**
     * Abstract method used to fetch subsequent documents.
     *
     * @param userId The `userId` for given user
     * @param orderId The `orderId` of an existing order
     */
    abstract getOrderSubsequentDocuments(userId: string, orderId: string): Observable<OrderSubsequentDocument[]>;
    /**
     * Abstract method used to fetch subsequent document entries.
     *
     * @param userId The `userId` for given user
     * @param orderId The `orderId` of an existing order
     * @param documentId The 'documentId' for which entries are fetched
     */
    abstract getOrderSubsequentDocumentEntries(userId: string, orderId: string, documentCategory: string, documentId: string): Observable<OrderSubsequentDocumentEntry[]>;
}

declare class OrderDocumentFlowConnector {
    protected adapter: OrderDocumentFlowAdapter;
    getOrderSubsequentDocuments(userId: string, orderId: string): Observable<OrderSubsequentDocument[]>;
    getOrderSubsequentDocumentEntries(userId: string, orderId: string, documentCategory: string, documentId: string): Observable<OrderSubsequentDocumentEntry[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDocumentFlowConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderDocumentFlowConnector>;
}

declare class OrderDocumentFlowService implements OrderDocumentFlowFacade {
    protected orderAttachmentsConnector: OrderDocumentFlowConnector;
    protected userIdService: UserIdService;
    getOrderSubsequentDocuments(orderId: string): Observable<OrderSubsequentDocument[]>;
    getOrderSubsequentDocumentEntries(orderId: string, documentCategory: string, documentId: string): Observable<OrderSubsequentDocumentEntry[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDocumentFlowService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderDocumentFlowService>;
}

declare class OrderDocumentFlowCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDocumentFlowCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderDocumentFlowCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderDocumentFlowCoreModule>;
}

export { OrderDocumentFlowAdapter, OrderDocumentFlowConnector, OrderDocumentFlowCoreModule, OrderDocumentFlowService };
