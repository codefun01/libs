import * as i0 from '@angular/core';
import * as i1 from '@spartacus/order/document-flow/core';
import * as i2 from '@spartacus/order/document-flow/components';
import * as i3 from '@spartacus/order/document-flow/occ';

declare class OrderDocumentFlowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDocumentFlowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderDocumentFlowModule, never, [typeof i1.OrderDocumentFlowCoreModule, typeof i2.OrderDocumentFlowComponentsModule, typeof i3.OrderDocumentFlowOccModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderDocumentFlowModule>;
}

export { OrderDocumentFlowModule };
