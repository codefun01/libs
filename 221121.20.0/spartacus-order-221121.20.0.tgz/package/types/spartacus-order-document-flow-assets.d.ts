import { TranslationChunksConfig } from '@spartacus/core';

declare const en: {
    documentFlow: {
        documentFlow: {
            button: string;
            dialog: {
                title: string;
                closeModal: string;
                name: string;
                date: string;
                time: string;
                status: string;
                status_OPEN: string;
                status_IN_PROCESS: string;
                status_COMPLETED: string;
                status_NOT_RELEVANT: string;
                orderItems: string;
                deliveryItemId: string;
                orderItemId: string;
                error: string;
                empty: string;
            };
        };
    };
};

declare const orderDocumentFlowTranslationChunksConfig: TranslationChunksConfig;

export { en as documentFlowTranslationsEn, orderDocumentFlowTranslationChunksConfig };
