import { Converter, Occ, ConverterService, OccEndpointsService, LoggerService, OccEndpoint } from '@spartacus/core';
import { Order, ReplenishmentOrder, ReturnRequest, ScheduleReplenishmentForm, OrderConfig, OrderHistoryList, ConsignmentTracking, CancellationRequestEntryInputList, ReturnRequestEntryInputList, ReturnRequestList, ReturnRequestModification, ReplenishmentOrderList, OrderAttachments } from '@spartacus/order/root';
import * as i0 from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { OrderHistoryAdapter, OrderAdapter, ReplenishmentOrderHistoryAdapter, ScheduledReplenishmentOrderAdapter, OrderAttachmentsAdapter } from '@spartacus/order/core';
import { Observable } from 'rxjs';
import * as i1 from '@angular/common';

declare class OccOrderNormalizer implements Converter<Occ.Order, Order> {
    private converter;
    constructor(converter: ConverterService);
    convert(source: Occ.Order, target?: Order): Order;
    private convertOrderEntry;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOrderNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOrderNormalizer>;
}

declare class OccReplenishmentOrderNormalizer implements Converter<Occ.ReplenishmentOrder, ReplenishmentOrder> {
    private converter;
    constructor(converter: ConverterService);
    convert(source: Occ.ReplenishmentOrder, target?: ReplenishmentOrder): ReplenishmentOrder;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccReplenishmentOrderNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccReplenishmentOrderNormalizer>;
}

declare class OccReturnRequestNormalizer implements Converter<Occ.ReturnRequest, ReturnRequest> {
    private converter;
    constructor(converter: ConverterService);
    convert(source: Occ.ReturnRequest, target?: ReturnRequest): ReturnRequest;
    private convertOrderEntry;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccReturnRequestNormalizer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccReturnRequestNormalizer>;
}

declare class OccScheduledReplenishmentOrderFormSerializer implements Converter<Occ.ScheduleReplenishmentForm, ScheduleReplenishmentForm> {
    convert(source: Occ.ScheduleReplenishmentForm, target?: ScheduleReplenishmentForm): ScheduleReplenishmentForm;
    /**
     * Adds the current timestamp (including timezone offset) to a date string in the format YYYY-mm-dd
     * @Example
     * Converts 2021-10-15 to 2021-10-15T15:38:05-05:00
     */
    private convertDate;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccScheduledReplenishmentOrderFormSerializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccScheduledReplenishmentOrderFormSerializer>;
}

declare class OccOrderHistoryAdapter implements OrderHistoryAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    private occFieldsService;
    protected orderConfig: OrderConfig;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    load(userId: string, orderCode: string): Observable<Order>;
    loadHistory(userId: string, pageSize?: number, currentPage?: number, sort?: string): Observable<OrderHistoryList>;
    getConsignmentTracking(orderCode: string, consignmentCode: string, userId?: string): Observable<ConsignmentTracking>;
    cancel(userId: string, orderCode: string, cancelRequestInput: CancellationRequestEntryInputList): Observable<{}>;
    createReturnRequest(userId: string, returnRequestInput: ReturnRequestEntryInputList): Observable<ReturnRequest>;
    loadReturnRequestList(userId: string, pageSize?: number, currentPage?: number, sort?: string): Observable<ReturnRequestList>;
    loadReturnRequestDetail(userId: string, returnRequestCode: string): Observable<ReturnRequest>;
    cancelReturnRequest(userId: string, returnRequestCode: string, returnRequestModification: ReturnRequestModification): Observable<{}>;
    protected getOrderDetailUrl(userId: string, orderCode: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOrderHistoryAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOrderHistoryAdapter>;
}

declare class OccOrderAdapter implements OrderAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    placeOrder(userId: string, cartId: string, termsChecked: boolean): Observable<Order>;
    placePaymentAuthorizedOrder(userId: string, cartId: string, termsChecked: boolean): Observable<Order>;
    protected getPlaceOrderEndpoint(userId: string, cartId: string, termsChecked: string): string;
    protected getPlacePaymentAuthorizedOrderEndpoint(userId: string, cartId: string, termsChecked: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOrderAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOrderAdapter>;
}

declare class OccReplenishmentOrderHistoryAdapter implements ReplenishmentOrderHistoryAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    load(userId: string, replenishmentOrderCode: string): Observable<ReplenishmentOrder>;
    loadReplenishmentDetailsHistory(userId: string, replenishmentOrderCode: string, pageSize?: number, currentPage?: number, sort?: string): Observable<OrderHistoryList>;
    cancelReplenishmentOrder(userId: string, replenishmentOrderCode: string): Observable<ReplenishmentOrder>;
    loadHistory(userId: string, pageSize?: number, currentPage?: number, sort?: string): Observable<ReplenishmentOrderList>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccReplenishmentOrderHistoryAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccReplenishmentOrderHistoryAdapter>;
}

declare class OccScheduledReplenishmentOrderAdapter implements ScheduledReplenishmentOrderAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    scheduleReplenishmentOrder(cartId: string, scheduleReplenishmentForm: ScheduleReplenishmentForm, termsChecked: boolean, userId: string): Observable<ReplenishmentOrder>;
    protected getScheduleReplenishmentOrderEndpoint(userId: string, cartId: string, termsChecked: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccScheduledReplenishmentOrderAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccScheduledReplenishmentOrderAdapter>;
}

declare class OccOrderAttachmentsAdapter implements OrderAttachmentsAdapter {
    protected logger: LoggerService;
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    getOrderAttachments(userId: string, orderId: string): Observable<OrderAttachments>;
    downloadOrderAttachment(userId: string, orderId: string, attachmentId: string): Observable<Blob>;
    protected getOrderAttachmentsUrl(orderId: string, userId: string): string;
    protected getDownloadOrderAttachmentUrl(userId: string, orderId: string, attachmentId: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOrderAttachmentsAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOrderAttachmentsAdapter>;
}

interface OrderOccEndpoints {
    /**
     * Endpoint for the list of one user's orders
     *
     * @member {string}
     */
    orderHistory?: string | OccEndpoint;
    /**
     * Endpoint for the details of one user's order
     *
     * @member {string}
     */
    orderDetail?: string | OccEndpoint;
    /**
     * Endpoint for Quote Code associated with the Order. The Quote Code is present if the order was placed from a quote.
     *
     * @member {string}
     */
    quoteCode?: string | OccEndpoint;
    /**
     * Endpoint for consignment tracking
     *
     * @member {string}
     */
    consignmentTracking?: string | OccEndpoint;
    /**
     * Endpoint for cancel an order
     */
    cancelOrder?: string | OccEndpoint;
    /**
     * Endpoint for creating order return request
     */
    returnOrder?: string | OccEndpoint;
    /**
     * Endpoint for user's order return requests
     */
    orderReturns?: string | OccEndpoint;
    /**
     * Endpoint for order return request details
     */
    orderReturnDetail?: string | OccEndpoint;
    /**
     * Endpoint for cancelling return request
     */
    cancelReturn?: string | OccEndpoint;
    /**
     * Endpoint for the list of one user's replenishment orders
     *
     * @member {string}
     */
    replenishmentOrderHistory?: string | OccEndpoint;
    /**
     * Endpoint to get a replenishment order details
     *
     * @member {string}
     */
    replenishmentOrderDetails?: string | OccEndpoint;
    /**
     * Endpoint to get a replenishment order history for a replenishment
     *
     * @member {string}
     */
    replenishmentOrderDetailsHistory?: string | OccEndpoint;
    /**
     * Endpoint to get a replenishment order history for a replenishment
     *
     * @member {string}
     */
    cancelReplenishmentOrder?: string | OccEndpoint;
    /**
     * Endpoint for place order
     */
    placeOrder?: string | OccEndpoint;
    /**
     * Endpoint for place order after the payment authorization
     */
    placePaymentAuthorizedOrder?: string | OccEndpoint;
    /**
     * Endpoint for scheduling a replenishment order
     */
    scheduleReplenishmentOrder?: string | OccEndpoint;
    /**
     * Endpoint to create a new cart from an existing order
     */
    reorder?: string | OccEndpoint;
    /**
     * Get order attachments
     */
    orderAttachments?: string | OccEndpoint;
    /**
     * Download order attachment blob
     */
    downloadOrderAttachment?: string | OccEndpoint;
}
declare module '@spartacus/core' {
    interface OccEndpoints extends OrderOccEndpoints {
    }
}

declare class OrderOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderOccModule>;
}

export { OccOrderAdapter, OccOrderAttachmentsAdapter, OccOrderHistoryAdapter, OccOrderNormalizer, OccReplenishmentOrderHistoryAdapter, OccReplenishmentOrderNormalizer, OccReturnRequestNormalizer, OccScheduledReplenishmentOrderAdapter, OccScheduledReplenishmentOrderFormSerializer, OrderOccModule };
export type { OrderOccEndpoints };
