import { HttpClient } from '@angular/common/http';
import { LoggerService, OccEndpointsService, ConverterService, OccEndpoint } from '@spartacus/core';
import { Observable } from 'rxjs';
import { OrderDocumentFlowAdapter } from '@spartacus/order/document-flow/core';
import { OrderSubsequentDocument, OrderSubsequentDocumentEntry } from '@spartacus/order/document-flow/root';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare class OccOrderDocumentFlowAdapter implements OrderDocumentFlowAdapter {
    protected logger: LoggerService;
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    getOrderSubsequentDocuments(userId: string, orderId: string): Observable<OrderSubsequentDocument[]>;
    getOrderSubsequentDocumentEntries(userId: string, orderId: string, documentCategory: string, documentId: string): Observable<OrderSubsequentDocumentEntry[]>;
    protected getSubsequentDocumentsUrl(orderId: string, userId: string): string;
    protected getSubsequentDocumentsEntriesUrl(orderId: string, userId: string, documentCategory: string, documentId: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOrderDocumentFlowAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOrderDocumentFlowAdapter>;
}

declare class OrderDocumentFlowOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDocumentFlowOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderDocumentFlowOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderDocumentFlowOccModule>;
}

interface DocumentFlowOccEndpoints {
    /**
     * Get order subsequent documents
     */
    subsequentDocuments?: string | OccEndpoint;
    /**
     * Get order subsequent document entries
     */
    subsequentDocumentsEntries?: string | OccEndpoint;
}
declare module '@spartacus/core' {
    interface OccEndpoints extends DocumentFlowOccEndpoints {
    }
}

export { OccOrderDocumentFlowAdapter, OrderDocumentFlowOccModule };
