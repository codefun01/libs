import * as i0 from '@angular/core';
import { ViewContainerRef, DestroyRef, ElementRef, ChangeDetectorRef, EventEmitter } from '@angular/core';
import * as i2 from '@spartacus/core';
import { QueryService, UserIdService, TranslationService, GlobalMessageType } from '@spartacus/core';
import { OrderDetailsService } from '@spartacus/order/components';
import { Order } from '@spartacus/order/root';
import * as i3 from '@spartacus/storefront';
import { LaunchDialogService, ICON_TYPE, FocusConfig } from '@spartacus/storefront';
import { Observable, BehaviorSubject } from 'rxjs';
import { OrderDocumentFlowFacade, OrderSubsequentDocument, OrderSubsequentDocumentEntry } from '@spartacus/order/document-flow/root';
import * as i1 from '@angular/common';
import * as i4 from '@angular/router';

declare class OrderDocumentFlowComponent {
    protected orderDetailsService: OrderDetailsService;
    protected launchDialogService: LaunchDialogService;
    protected vcr: ViewContainerRef;
    protected destroyRef: DestroyRef;
    protected queryService: QueryService;
    protected userIdService: UserIdService;
    element: ElementRef;
    order$: Observable<Order>;
    onOrderDocumentFlowClick(orderCode: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDocumentFlowComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderDocumentFlowComponent, "cx-order-document-flow", never, {}, {}, never, never, true, never>;
}

declare class OrderDocumentFlowDialogComponent {
    protected launchDialogService: LaunchDialogService;
    protected orderDocumentFlowFacade: OrderDocumentFlowFacade;
    protected translation: TranslationService;
    protected cd: ChangeDetectorRef;
    protected destroyRef: DestroyRef;
    scrollContainerRef: ElementRef;
    protected savedScrollPosition: number;
    globalMessageType: typeof GlobalMessageType;
    iconTypes: typeof ICON_TYPE;
    focusConfig: FocusConfig;
    displayDocumentEntries: i0.WritableSignal<boolean>;
    protected orderCode$: Observable<string>;
    documents$: Observable<OrderSubsequentDocument[]>;
    loadError: i0.WritableSignal<boolean>;
    protected selectedDocumentSubject: BehaviorSubject<OrderSubsequentDocument | undefined>;
    selectedDocument$: Observable<OrderSubsequentDocument | undefined>;
    protected documentEntriesCache: Map<OrderSubsequentDocument, OrderSubsequentDocumentEntry[]>;
    selectedDocumentEntries$: Observable<OrderSubsequentDocumentEntry[]>;
    getDocumentTitle(document: OrderSubsequentDocument): string;
    onDocumentSelection(document: OrderSubsequentDocument): void;
    goBack(): void;
    close(reason: string): void;
    protected cacheDocumentEntries(document: OrderSubsequentDocument, entries: OrderSubsequentDocumentEntry[]): void;
    protected saveScrollPosition(): void;
    protected restoreScrollPosition(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDocumentFlowDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderDocumentFlowDialogComponent, "cx-order-document-flow-dialog", never, {}, {}, never, never, true, never>;
}

declare class OrderSubsequentDocumentListComponent {
    iconTypes: typeof ICON_TYPE;
    documents: OrderSubsequentDocument[];
    selectedDocument?: OrderSubsequentDocument;
    documentSelected: EventEmitter<OrderSubsequentDocument>;
    onDocumentSelection(document: OrderSubsequentDocument): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderSubsequentDocumentListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderSubsequentDocumentListComponent, "cx-order-subsequent-document-list", never, { "documents": { "alias": "documents"; "required": false; }; "selectedDocument": { "alias": "selectedDocument"; "required": false; }; }, { "documentSelected": "documentSelected"; }, never, never, true, never>;
}

declare class OrderSubsequentDocumentNodeComponent {
    iconTypes: typeof ICON_TYPE;
    documents: OrderSubsequentDocument[];
    selectedDocument?: OrderSubsequentDocument;
    depth: number;
    documentSelected: EventEmitter<OrderSubsequentDocument>;
    haveSubNodes(document: OrderSubsequentDocument): boolean;
    onDocumentSelection(document: OrderSubsequentDocument): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderSubsequentDocumentNodeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderSubsequentDocumentNodeComponent, "cx-order-subsequent-document-node", never, { "documents": { "alias": "documents"; "required": false; }; "selectedDocument": { "alias": "selectedDocument"; "required": false; }; "depth": { "alias": "depth"; "required": false; }; }, { "documentSelected": "documentSelected"; }, never, never, true, never>;
}

declare class OrderDocumentOrderEntryListComponent {
    entries?: OrderSubsequentDocumentEntry[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDocumentOrderEntryListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OrderDocumentOrderEntryListComponent, "cx-order-document-order-entry-list", never, { "entries": { "alias": "entries"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OrderDocumentFlowComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderDocumentFlowComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderDocumentFlowComponentsModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i2.UrlModule, typeof i3.SpinnerModule, typeof i4.RouterModule, typeof i3.KeyboardFocusModule, typeof i3.IconModule, typeof i3.MessageComponentModule, typeof OrderDocumentFlowComponent, typeof OrderDocumentFlowDialogComponent, typeof OrderSubsequentDocumentListComponent, typeof OrderSubsequentDocumentNodeComponent, typeof OrderDocumentOrderEntryListComponent], [typeof OrderDocumentFlowComponent, typeof OrderDocumentFlowDialogComponent, typeof OrderSubsequentDocumentListComponent, typeof OrderSubsequentDocumentNodeComponent, typeof OrderDocumentOrderEntryListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderDocumentFlowComponentsModule>;
}

export { OrderDocumentFlowComponent, OrderDocumentFlowComponentsModule, OrderDocumentFlowDialogComponent, OrderDocumentOrderEntryListComponent, OrderSubsequentDocumentListComponent, OrderSubsequentDocumentNodeComponent };
