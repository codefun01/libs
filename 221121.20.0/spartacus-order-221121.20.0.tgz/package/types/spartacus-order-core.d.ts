import { Order, OrderHistoryList, ConsignmentTracking, ReturnRequestEntryInputList, ReturnRequest, ReturnRequestList, CancellationRequestEntryInputList, ReturnRequestModification, ReplenishmentOrder, ReplenishmentOrderList, ScheduleReplenishmentForm, OrderAttachments, OrderHistoryFacade, OrderReturnRequestFacade, OrderFacade, ReorderOrderFacade, ReplenishmentOrderHistoryFacade, ScheduledReplenishmentOrderFacade, OrderView, OrderHistoryListView, OrderAttachmentsFacade } from '@spartacus/order/root';
import { Observable, BehaviorSubject } from 'rxjs';
import * as i0 from '@angular/core';
import { CartModificationList, ActiveCartFacade, OrderEntry, MultiCartFacade } from '@spartacus/cart/base/root';
import * as i2 from '@ngrx/store';
import { Store, Action, MemoizedSelector } from '@ngrx/store';
import { StateUtils, StateWithProcess, UserIdService, RoutingService, CommandService, EventService, Command, ErrorAction } from '@spartacus/core';
import { Params } from '@angular/router';
import * as i1 from '@ngrx/effects';

declare abstract class OrderHistoryAdapter {
    /**
     * Abstract method used to load order data.
     *
     * @param userId The `userId` for given user
     * @param orderCode The `orderCode` for given order
     */
    abstract load(userId: string, orderCode: string): Observable<Order>;
    /**
     * Abstract method used to load order history for an user.
     *
     * @param userId The `userId` for given user
     * @param pageSize
     * @param currentPage
     * @param sort Sorting method
     */
    abstract loadHistory(userId: string, pageSize?: number, currentPage?: number, sort?: string): Observable<OrderHistoryList>;
    /**
     * Abstract method used to get consignment tracking details
     * @param orderCode an order code
     * @param consignmentCode a consignment code
     * @param userId user id related to order
     */
    abstract getConsignmentTracking(orderCode: string, consignmentCode: string, userId?: string): Observable<ConsignmentTracking>;
    /**
     * Abstract method used to create return request
     * @param userId The `userId` for given user
     * @param returnRequestInput Return request entry input list
     */
    abstract createReturnRequest(userId: string, returnRequestInput: ReturnRequestEntryInputList): Observable<ReturnRequest>;
    /**
     * Abstract method used to load order return request details
     * @param userId
     * @param returnRequestCode
     */
    abstract loadReturnRequestDetail(userId: string, returnRequestCode: string): Observable<ReturnRequest>;
    /**
     * Abstract method used to load order return request list for an user.
     * @param userId
     * @param pageSize
     * @param currentPage
     * @param sort
     */
    abstract loadReturnRequestList(userId: string, pageSize?: number, currentPage?: number, sort?: string): Observable<ReturnRequestList>;
    /**
     * Abstract method used to cancel order
     * @param userId
     * @param orderCode
     * @param cancelRequestInput Cancel request entry input list
     */
    abstract cancel(userId: string, orderCode: string, cancelRequestInput: CancellationRequestEntryInputList): Observable<{}>;
    /**
     * Abstract method used to cancel one return request
     * @param userId
     * @param returnRequestCode
     * @param returnRequestModification
     */
    abstract cancelReturnRequest(userId: string, returnRequestCode: string, returnRequestModification: ReturnRequestModification): Observable<{}>;
}

declare class OrderHistoryConnector {
    protected adapter: OrderHistoryAdapter;
    constructor(adapter: OrderHistoryAdapter);
    get(userId: string, orderCode: string): Observable<Order>;
    getHistory(userId: string, pageSize?: number, currentPage?: number, sort?: string): Observable<OrderHistoryList>;
    getConsignmentTracking(orderCode: string, consignmentCode: string, userId?: string): Observable<ConsignmentTracking>;
    cancel(userId: string, orderCode: string, cancelRequestInput: CancellationRequestEntryInputList): Observable<{}>;
    return(userId: string, returnRequestInput: ReturnRequestEntryInputList): Observable<ReturnRequest>;
    getReturnRequestDetail(userId: string, returnRequestCode: string): Observable<ReturnRequest>;
    getReturnRequestList(userId: string, pageSize?: number, currentPage?: number, sort?: string): Observable<ReturnRequestList>;
    cancelReturnRequest(userId: string, returnRequestCode: string, returnRequestModification: ReturnRequestModification): Observable<{}>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderHistoryConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderHistoryConnector>;
}

declare abstract class OrderAdapter {
    /**
     * Abstract method used to place an order.
     *
     * @param userId The `userId` for given user
     * @param cartId The `cartId` for cart used for placing order
     * @param termsChecked The `boolean value` whether the terms were accepted or not
     */
    abstract placeOrder(userId: string, cartId: string, termsChecked: boolean): Observable<Order>;
    /**
     * Abstract method used to place an order with previous payment authorization.
     *
     * @param userId The `userId` for given user
     * @param cartId The `cartId` for cart used for placing order
     * @param termsChecked The `boolean value` whether the terms were accepted or not
     */
    abstract placePaymentAuthorizedOrder(userId: string, cartId: string, termsChecked: boolean): Observable<Order>;
}

declare class OrderConnector {
    protected adapter: OrderAdapter;
    constructor(adapter: OrderAdapter);
    placeOrder(userId: string, cartId: string, termsChecked: boolean): Observable<Order>;
    placePaymentAuthorizedOrder(userId: string, cartId: string, termsChecked: boolean): Observable<Order>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderConnector>;
}

declare abstract class ReorderOrderAdapter {
    /**
     * Abstract method used to reorder an order.
     *
     * @param orderId The `orderId` of an existing order to update the cart
     * @param userId The `userId` for given user
     */
    abstract reorder(orderId: string, userId: string): Observable<CartModificationList>;
}

declare class ReorderOrderConnector {
    protected adapter: ReorderOrderAdapter;
    constructor(adapter: ReorderOrderAdapter);
    reorder(orderId: string, userId: string): Observable<CartModificationList>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReorderOrderConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ReorderOrderConnector>;
}

declare abstract class ReplenishmentOrderHistoryAdapter {
    /**
     * Abstract method used to load replenishment order details.
     *
     * @param userId The `userId` for given user
     * @param replenishmentOrderCode The `replenishmentOrderCode` for a given scheduled replenishment
     */
    abstract load(userId: string, replenishmentOrderCode: string): Observable<ReplenishmentOrder>;
    /**
     * Abstract method used to load order history from a replenishment order.
     *
     * @param userId The `userId` for given user
     * @param replenishmentOrderCode The `replenishmentOrderCode` for a given scheduled replenishment
     * @param pageSize The `pageSize` to display number of data as order history
     * @param currentPage The `currentPage` of the order history list
     * @param sort The `sort` for a sorting method
     */
    abstract loadReplenishmentDetailsHistory(userId: string, replenishmentOrderCode: string, pageSize?: number, currentPage?: number, sort?: string): Observable<OrderHistoryList>;
    /**
     * Abstract method used to cancel a replenishment order.
     *
     * @param userId The `userId` for given user
     * @param replenishmentOrderCode The `replenishmentOrderCode` for a given scheduled replenishment
     */
    abstract cancelReplenishmentOrder(userId: string, replenishmentOrderCode: string): Observable<ReplenishmentOrder>;
    /**
     * Abstract method used to load replenishment order history for an user.
     *
     * @param userId The `userId` for given user
     * @param pageSize
     * @param currentPage
     * @param sort Sorting method
     */
    abstract loadHistory(userId: string, pageSize?: number, currentPage?: number, sort?: string): Observable<ReplenishmentOrderList>;
}

declare class ReplenishmentOrderHistoryConnector {
    protected adapter: ReplenishmentOrderHistoryAdapter;
    constructor(adapter: ReplenishmentOrderHistoryAdapter);
    load(userId: string, replenishmentOrderCode: string): Observable<ReplenishmentOrder>;
    loadReplenishmentDetailsHistory(userId: string, replenishmentOrderCode: string, pageSize?: number, currentPage?: number, sort?: string): Observable<OrderHistoryList>;
    cancelReplenishmentOrder(userId: string, replenishmentOrderCode: string): Observable<ReplenishmentOrder>;
    loadHistory(userId: string, pageSize?: number, currentPage?: number, sort?: string): Observable<ReplenishmentOrderList>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReplenishmentOrderHistoryConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ReplenishmentOrderHistoryConnector>;
}

declare abstract class ScheduledReplenishmentOrderAdapter {
    /**
     * Abstract method used to schedule a replenishment order.
     *
     * @param cartId The `cartId` for cart used for scheduling a replenishment order
     * @param scheduleReplenishmentForm The `object` that contains the form data for replenishment
     * @param termsChecked The `boolean value` whether the terms were accepted or not
     * @param userId The `userId` for given user
     */
    abstract scheduleReplenishmentOrder(cartId: string, scheduleReplenishmentForm: ScheduleReplenishmentForm, termsChecked: boolean, userId: string): Observable<ReplenishmentOrder>;
}

declare class ScheduledReplenishmentOrderConnector {
    protected adapter: ScheduledReplenishmentOrderAdapter;
    constructor(adapter: ScheduledReplenishmentOrderAdapter);
    scheduleReplenishmentOrder(cartId: string, scheduleReplenishmentForm: ScheduleReplenishmentForm, termsChecked: boolean, userId: string): Observable<ReplenishmentOrder>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScheduledReplenishmentOrderConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ScheduledReplenishmentOrderConnector>;
}

declare abstract class OrderAttachmentsAdapter {
    /**
     * Abstract method used to fetch order attachments.
     *
     * @param userId The `userId` for given user
     * @param orderId The `orderId` of an existing order
     */
    abstract getOrderAttachments(userId: string, orderId: string): Observable<OrderAttachments>;
    /**
     * Abstract method used to download order attachment.
     *
     * @param userId The `userId` for given user
     * @param orderId The `orderId` of an existing order
     * @param attachmentId The `attachmentId` of an existing attachment
     */
    abstract downloadOrderAttachment(userId: string, orderId: string, attachmentId: string): Observable<Blob>;
}

declare class OrderAttachmentsConnector {
    protected adapter: OrderAttachmentsAdapter;
    getOrderAttachments(userId: string, orderId: string): Observable<OrderAttachments>;
    downloadOrderAttachment(userId: string, orderId: string, attachmentId: string): Observable<Blob>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderAttachmentsConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderAttachmentsConnector>;
}

declare const ORDER_FEATURE = "order";
declare const CANCEL_ORDER_PROCESS_ID = "cancelOrder";
declare const CANCEL_RETURN_PROCESS_ID = "cancelReturn";
declare const CANCEL_REPLENISHMENT_ORDER_PROCESS_ID = "cancelReplenishmentOrder";
declare const ORDERS = "[Order] User Orders";
declare const RETURN_REQUESTS = "[Order] Order Return Requests";
declare const RETURN_REQUEST_DETAILS = "[Order] Return Request Details";
declare const ORDER_DETAILS = "[Order] User Order Details";
declare const REPLENISHMENT_ORDERS = "[Order] User Replenishment Orders";
declare const REPLENISHMENT_ORDER_DETAILS = "[Order] User Replenishment Order Details";
declare const CONSIGNMENT_TRACKING_BY_ID_ENTITIES = "consignment-tracking-by-id-entities";
declare const ORDER_BY_ID_ENTITIES = "order-by-id-entities";
interface StateWithOrder {
    [ORDER_FEATURE]: OrderState;
}
interface OrderState {
    orders: StateUtils.LoaderState<OrderHistoryList>;
    orderDetail: StateUtils.LoaderState<Order>;
    replenishmentOrders: StateUtils.LoaderState<ReplenishmentOrderList>;
    orderReturn: StateUtils.LoaderState<ReturnRequest>;
    orderReturnList: StateUtils.LoaderState<ReturnRequestList>;
    consignmentTracking: ConsignmentTrackingState;
    replenishmentOrder: StateUtils.LoaderState<ReplenishmentOrder>;
    consignmentTrackingById: StateUtils.EntityLoaderState<ConsignmentTracking>;
    orderById: StateUtils.EntityLoaderState<Order>;
}
interface ConsignmentTrackingState {
    tracking: ConsignmentTracking;
}
declare function getConsignmentTrackingByIdEntityKey(orderCode: string, consignmentCode: string): string;

declare class OrderHistoryService implements OrderHistoryFacade {
    protected store: Store<StateWithOrder>;
    protected processStateStore: Store<StateWithProcess<void>>;
    protected userIdService: UserIdService;
    protected routingService: RoutingService;
    constructor(store: Store<StateWithOrder>, processStateStore: Store<StateWithProcess<void>>, userIdService: UserIdService, routingService: RoutingService);
    /**
     * Returns an order's detail
     */
    getOrderDetails(): Observable<Order>;
    /**
     * Retrieves order's details
     *
     * @param orderCode an order code
     */
    loadOrderDetails(orderCode: string): void;
    /**
     * Clears order's details
     */
    clearOrderDetails(): void;
    /**
     * Returns order history list
     */
    getOrderHistoryList(pageSize: number): Observable<OrderHistoryList | undefined>;
    /**
     * Returns a loaded flag for order history list
     */
    getOrderHistoryListLoaded(): Observable<boolean>;
    /**
     * Retrieves an order list
     * @param pageSize page size
     * @param currentPage current page
     * @param sort sort
     */
    loadOrderList(pageSize: number, currentPage?: number, sort?: string): void;
    /**
     * Cleaning order list
     */
    clearOrderList(): void;
    /**
     *  Returns a consignment tracking detail
     */
    getConsignmentTracking(): Observable<ConsignmentTracking>;
    /**
     * Retrieves consignment tracking details
     * @param orderCode an order code
     * @param consignmentCode a consignment code
     */
    loadConsignmentTracking(orderCode: string, consignmentCode: string): void;
    /**
     * Cleaning consignment tracking
     */
    clearConsignmentTracking(): void;
    cancelOrder(orderCode: string, cancelRequestInput: CancellationRequestEntryInputList): void;
    /**
     * Returns the cancel order loading flag
     */
    getCancelOrderLoading(): Observable<boolean>;
    /**
     * Returns the cancel order success flag
     */
    getCancelOrderSuccess(): Observable<boolean>;
    /**
     * Resets the cancel order process flags
     */
    resetCancelOrderProcessState(): void;
    /**
     * Returns the order details loading flag
     */
    getOrderDetailsLoading(): Observable<boolean>;
    /**
     * @deprecated: Method doesn't pass facade method's requirements (returns void or Observable)
     */
    getQueryParams(_order: Order): Params | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderHistoryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderHistoryService>;
}

declare class OrderReturnRequestService implements OrderReturnRequestFacade {
    protected store: Store<StateWithOrder>;
    protected processStateStore: Store<StateWithProcess<void>>;
    protected userIdService: UserIdService;
    constructor(store: Store<StateWithOrder>, processStateStore: Store<StateWithProcess<void>>, userIdService: UserIdService);
    /**
     * Create order return request
     * @param orderCode an order code
     * @param returnRequestInput order return request entry input
     */
    createOrderReturnRequest(returnRequestInput: ReturnRequestEntryInputList): void;
    /**
     * Return an order return request
     */
    getOrderReturnRequest(): Observable<ReturnRequest>;
    /**
     * Gets order return request list
     */
    getOrderReturnRequestList(pageSize?: number): Observable<ReturnRequestList | undefined>;
    /**
     * Loads order return request detail
     * @param returnRequestCode
     */
    loadOrderReturnRequestDetail(returnRequestCode: string): void;
    /**
     * Loads order return request list
     * @param pageSize page size
     * @param currentPage current page
     * @param sort sort
     */
    loadOrderReturnRequestList(pageSize?: number, currentPage?: number, sort?: string): void;
    /**
     * Cleaning order return request list
     */
    clearOrderReturnRequestList(): void;
    /**
     * Get the order return request loading flag
     */
    getReturnRequestLoading(): Observable<boolean>;
    /**
     * Get the order return request success flag
     */
    getReturnRequestSuccess(): Observable<boolean>;
    /**
     * Cleaning order return request details
     */
    clearOrderReturnRequestDetail(): void;
    cancelOrderReturnRequest(returnRequestCode: string, returnRequestModification: ReturnRequestModification): void;
    /**
     * Returns the cancel return request loading flag
     */
    getCancelReturnRequestLoading(): Observable<boolean>;
    /**
     * Returns the cancel return request success flag
     */
    getCancelReturnRequestSuccess(): Observable<boolean>;
    /**
     * Resets the cancel return request process flags
     */
    resetCancelReturnRequestProcessState(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderReturnRequestService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderReturnRequestService>;
}

declare class OrderService implements OrderFacade {
    protected activeCartFacade: ActiveCartFacade;
    protected userIdService: UserIdService;
    protected commandService: CommandService;
    protected orderConnector: OrderConnector;
    protected eventService: EventService;
    protected placedOrder$: BehaviorSubject<Order | undefined>;
    protected placeOrderCommand: Command<boolean, Order>;
    protected placePaymentAuthorizedOrderCommand: Command<boolean, Order>;
    constructor(activeCartFacade: ActiveCartFacade, userIdService: UserIdService, commandService: CommandService, orderConnector: OrderConnector, eventService: EventService);
    /**
     * Performs the necessary checkout preconditions.
     */
    protected checkoutPreconditions(): Observable<[string, string]>;
    placeOrder(termsChecked: boolean): Observable<Order>;
    placePaymentAuthorizedOrder(termsChecked: boolean, cartId?: string): Observable<Order>;
    getOrderDetails(): Observable<Order | undefined>;
    clearPlacedOrder(): void;
    setPlacedOrder(order: Order): void;
    getPickupEntries(): Observable<OrderEntry[]>;
    getDeliveryEntries(): Observable<OrderEntry[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderService>;
}

declare class ReorderOrderService implements ReorderOrderFacade {
    protected commandService: CommandService;
    protected reorderOrderConnector: ReorderOrderConnector;
    protected userIdService: UserIdService;
    protected activeCartFacade: ActiveCartFacade;
    protected multiCartFacade: MultiCartFacade;
    protected reorderCommand: Command<{
        orderId: string;
    }, CartModificationList>;
    constructor(commandService: CommandService, reorderOrderConnector: ReorderOrderConnector, userIdService: UserIdService, activeCartFacade: ActiveCartFacade, multiCartFacade: MultiCartFacade);
    /**
     * Create cart from an existing order
     */
    reorder(orderId: string): Observable<CartModificationList>;
    protected reorderPreconditions(): Observable<string>;
    protected deleteCartAndWait(cartId: string, userId: string): Observable<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReorderOrderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ReorderOrderService>;
}

declare class ReplenishmentOrderHistoryService implements ReplenishmentOrderHistoryFacade {
    protected store: Store<StateWithOrder>;
    protected processStateStore: Store<StateWithProcess<void>>;
    protected userIdService: UserIdService;
    constructor(store: Store<StateWithOrder>, processStateStore: Store<StateWithProcess<void>>, userIdService: UserIdService);
    /**
     * Returns replenishment order details for a given 'current' user
     *
     * @param replenishmentOrderCode a replenishment order code
     */
    loadReplenishmentOrderDetails(replenishmentOrderCode: string): void;
    /**
     * Returns a replenishment order details
     */
    getReplenishmentOrderDetails(): Observable<ReplenishmentOrder>;
    /**
     * Returns a replenishment order details loading flag
     */
    getReplenishmentOrderDetailsLoading(): Observable<boolean>;
    /**
     * Returns a replenishment order details success flag
     */
    getReplenishmentOrderDetailsSuccess(): Observable<boolean>;
    /**
     * Returns a replenishment order details error flag
     */
    getReplenishmentOrderDetailsError(): Observable<boolean>;
    /**
     * Clears the replenishment orders details state
     */
    clearReplenishmentOrderDetails(): void;
    /**
     * Cancels a specific replenishment order for a given 'current' user
     *
     * @param replenishmentOrderCode a replenishment order code
     */
    cancelReplenishmentOrder(replenishmentOrderCode: string): void;
    /**
     * Returns the cancel replenishment order loading flag
     */
    getCancelReplenishmentOrderLoading(): Observable<boolean>;
    /**
     * Returns the cancel replenishment order success flag
     */
    getCancelReplenishmentOrderSuccess(): Observable<boolean>;
    /**
     * Returns the cancel replenishment order error flag
     */
    getCancelReplenishmentOrderError(): Observable<boolean>;
    /**
     * Clears the cancel replenishment order processing state
     */
    clearCancelReplenishmentOrderProcessState(): void;
    /**
     * Returns replenishment order history list
     */
    getReplenishmentOrderHistoryList(pageSize: number): Observable<ReplenishmentOrderList | undefined>;
    /**
     * Returns a loading flag for replenishment order history list
     */
    getReplenishmentOrderHistoryListLoading(): Observable<boolean>;
    /**
     * Returns a error flag for replenishment order history list
     */
    getReplenishmentOrderHistoryListError(): Observable<boolean>;
    /**
     * Returns a success flag for replenishment order history list
     */
    getReplenishmentOrderHistoryListSuccess(): Observable<boolean>;
    /**
     * Retrieves a replenishment order list
     * @param pageSize page size
     * @param currentPage current page
     * @param sort sort
     */
    loadReplenishmentOrderList(pageSize?: number, currentPage?: number, sort?: string): void;
    /**
     * Cleaning replenishment order list
     */
    clearReplenishmentOrderList(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReplenishmentOrderHistoryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ReplenishmentOrderHistoryService>;
}

declare class ScheduledReplenishmentOrderService implements ScheduledReplenishmentOrderFacade {
    protected activeCartFacade: ActiveCartFacade;
    protected userIdService: UserIdService;
    protected commandService: CommandService;
    protected scheduledReplenishmentOrderConnector: ScheduledReplenishmentOrderConnector;
    protected eventService: EventService;
    protected orderFacade: OrderFacade;
    protected scheduleReplenishmentOrderCommand: Command<{
        termsChecked: boolean;
        form: ScheduleReplenishmentForm;
    }, ReplenishmentOrder>;
    constructor(activeCartFacade: ActiveCartFacade, userIdService: UserIdService, commandService: CommandService, scheduledReplenishmentOrderConnector: ScheduledReplenishmentOrderConnector, eventService: EventService, orderFacade: OrderFacade);
    protected checkoutPreconditions(): Observable<[string, string]>;
    /**
     * Schedule a replenishment order
     */
    scheduleReplenishmentOrder(scheduleReplenishmentForm: ScheduleReplenishmentForm, termsChecked: boolean): Observable<ReplenishmentOrder>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScheduledReplenishmentOrderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ScheduledReplenishmentOrderService>;
}

declare class MyAccountV2OrderHistoryService {
    protected orderReturnRequestService: OrderReturnRequestService;
    protected store: Store<any>;
    protected userIdService: UserIdService;
    protected orderHistoryService: OrderHistoryService;
    clearOrderList(): void;
    getOrderDetailsWithTracking(orderCode: string): Observable<OrderView | undefined>;
    getOrderHistoryListWithDetails(pageSize: number): Observable<OrderHistoryListView | undefined>;
    getOrderHistoryList(pageSize: number): Observable<OrderHistoryListView | undefined>;
    protected getOrderDetailsValue(code: string): Observable<Order>;
    protected getOrderDetailsState(code: string): Observable<StateUtils.LoaderState<Order>>;
    protected loadOrderDetails(code: string): void;
    getOrderDetailsV2(code: string): Observable<Order | undefined>;
    protected getConsignmentTrackingValue(orderCode: string, consignmentCode: string): Observable<ConsignmentTracking>;
    protected getConsignmentTrackingState(orderCode: string, consignmentCode: string): Observable<StateUtils.LoaderState<ConsignmentTracking>>;
    protected loadConsignmentTracking(orderCode: string, consignmentCode: string): void;
    getConsignmentTracking(orderCode: string, consignmentCode: string): Observable<ConsignmentTracking>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2OrderHistoryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MyAccountV2OrderHistoryService>;
}

declare class OrderAttachmentsService implements OrderAttachmentsFacade {
    protected orderAttachmentsConnector: OrderAttachmentsConnector;
    protected userIdService: UserIdService;
    getOrderAttachments(orderId: string): Observable<OrderAttachments>;
    downloadOrderAttachment(orderId: string, attachmentId: string): Observable<Blob>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderAttachmentsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderAttachmentsService>;
}

declare class OrderStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderStoreModule, never, [typeof i1.EffectsFeatureModule, typeof i2.StoreFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderStoreModule>;
}

declare class OrderCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OrderCoreModule, never, [typeof OrderStoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OrderCoreModule>;
}

declare const LOAD_CONSIGNMENT_TRACKING = "[Order] Load Consignment Tracking";
declare const LOAD_CONSIGNMENT_TRACKING_FAIL = "[Order] Load Consignment Tracking Fail";
declare const LOAD_CONSIGNMENT_TRACKING_SUCCESS = "[Order] Load Consignment Tracking Success";
declare const CLEAR_CONSIGNMENT_TRACKING = "[Order] Clear Consignment Tracking";
declare class LoadConsignmentTracking implements Action {
    payload: {
        userId?: string;
        orderCode: string;
        consignmentCode: string;
    };
    readonly type = "[Order] Load Consignment Tracking";
    constructor(payload: {
        userId?: string;
        orderCode: string;
        consignmentCode: string;
    });
}
declare class LoadConsignmentTrackingFail implements ErrorAction {
    payload: any;
    readonly type = "[Order] Load Consignment Tracking Fail";
    error: any;
    constructor(payload: any);
}
declare class LoadConsignmentTrackingSuccess implements Action {
    payload: ConsignmentTracking;
    readonly type = "[Order] Load Consignment Tracking Success";
    constructor(payload: ConsignmentTracking);
}
declare class ClearConsignmentTracking {
    readonly type = "[Order] Clear Consignment Tracking";
    constructor();
}
type ConsignmentTrackingAction = LoadConsignmentTracking | LoadConsignmentTrackingFail | LoadConsignmentTrackingSuccess | ClearConsignmentTracking;

declare const LOAD_ORDER_DETAILS = "[Order] Load Order Details";
declare const LOAD_ORDER_DETAILS_FAIL = "[Order] Load Order Details Fail";
declare const LOAD_ORDER_DETAILS_SUCCESS = "[Order] Load Order Details Success";
declare const CLEAR_ORDER_DETAILS = "[Order] Clear Order Details";
declare const CANCEL_ORDER = "[Order] Cancel Order";
declare const CANCEL_ORDER_FAIL = "[Order] Cancel Order Fail";
declare const CANCEL_ORDER_SUCCESS = "[Order] Cancel Order Success";
declare const RESET_CANCEL_ORDER_PROCESS = "[Order] Reset Cancel Order Process";
declare class LoadOrderDetails extends StateUtils.LoaderLoadAction {
    payload: {
        userId: string;
        orderCode: string;
    };
    readonly type = "[Order] Load Order Details";
    constructor(payload: {
        userId: string;
        orderCode: string;
    });
}
declare class LoadOrderDetailsFail extends StateUtils.LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Order] Load Order Details Fail";
    constructor(payload: any);
}
declare class LoadOrderDetailsSuccess extends StateUtils.LoaderSuccessAction {
    payload: Order;
    readonly type = "[Order] Load Order Details Success";
    constructor(payload: Order);
}
declare class ClearOrderDetails extends StateUtils.LoaderResetAction {
    readonly type = "[Order] Clear Order Details";
    constructor();
}
declare class CancelOrder extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        orderCode: string;
        cancelRequestInput: CancellationRequestEntryInputList;
    };
    readonly type = "[Order] Cancel Order";
    constructor(payload: {
        userId: string;
        orderCode: string;
        cancelRequestInput: CancellationRequestEntryInputList;
    });
}
declare class CancelOrderFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Order] Cancel Order Fail";
    constructor(payload: any);
}
declare class CancelOrderSuccess extends StateUtils.EntitySuccessAction {
    readonly type = "[Order] Cancel Order Success";
    constructor();
}
declare class ResetCancelOrderProcess extends StateUtils.EntityLoaderResetAction {
    readonly type = "[Order] Reset Cancel Order Process";
    constructor();
}
type OrderDetailsAction = LoadOrderDetails | LoadOrderDetailsFail | LoadOrderDetailsSuccess | ClearOrderDetails | CancelOrder | CancelOrderFail | CancelOrderSuccess;

declare const CREATE_ORDER_RETURN_REQUEST = "[Order] Create Order Return Request";
declare const CREATE_ORDER_RETURN_REQUEST_FAIL = "[Order] Create Order Return Request Fail";
declare const CREATE_ORDER_RETURN_REQUEST_SUCCESS = "[Order] Create Order Return Request Success";
declare const LOAD_ORDER_RETURN_REQUEST = "[Order] Load Order Return Request details";
declare const LOAD_ORDER_RETURN_REQUEST_FAIL = "[Order] Load Order Return Request details Fail";
declare const LOAD_ORDER_RETURN_REQUEST_SUCCESS = "[Order] Load Order Return Request details Success";
declare const CANCEL_ORDER_RETURN_REQUEST = "[Order] Cancel Order Return Request";
declare const CANCEL_ORDER_RETURN_REQUEST_FAIL = "[Order] Cancel Order Return Request Fail";
declare const CANCEL_ORDER_RETURN_REQUEST_SUCCESS = "[Order] Cancel Order Return Request Success";
declare const LOAD_ORDER_RETURN_REQUEST_LIST = "[Order] Load User Order Return Request List";
declare const LOAD_ORDER_RETURN_REQUEST_LIST_FAIL = "[Order] Load User Order Return Request List Fail";
declare const LOAD_ORDER_RETURN_REQUEST_LIST_SUCCESS = "[Order] Load User Order Return Request List Success";
declare const CLEAR_ORDER_RETURN_REQUEST = "[Order] Clear Order Return Request Details";
declare const CLEAR_ORDER_RETURN_REQUEST_LIST = "[Order] Clear Order Return Request List";
declare const RESET_CANCEL_RETURN_PROCESS = "[Order] Reset Cancel Return Request Process";
declare class CreateOrderReturnRequest extends StateUtils.LoaderLoadAction {
    payload: {
        userId: string;
        returnRequestInput: ReturnRequestEntryInputList;
    };
    readonly type = "[Order] Create Order Return Request";
    constructor(payload: {
        userId: string;
        returnRequestInput: ReturnRequestEntryInputList;
    });
}
declare class CreateOrderReturnRequestFail extends StateUtils.LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Order] Create Order Return Request Fail";
    constructor(payload: any);
}
declare class CreateOrderReturnRequestSuccess extends StateUtils.LoaderSuccessAction {
    payload: ReturnRequest;
    readonly type = "[Order] Create Order Return Request Success";
    constructor(payload: ReturnRequest);
}
declare class LoadOrderReturnRequest extends StateUtils.LoaderLoadAction {
    payload: {
        userId: string;
        returnRequestCode: string;
    };
    readonly type = "[Order] Load Order Return Request details";
    constructor(payload: {
        userId: string;
        returnRequestCode: string;
    });
}
declare class LoadOrderReturnRequestFail extends StateUtils.LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Order] Load Order Return Request details Fail";
    constructor(payload: any);
}
declare class LoadOrderReturnRequestSuccess extends StateUtils.LoaderSuccessAction {
    payload: ReturnRequest;
    readonly type = "[Order] Load Order Return Request details Success";
    constructor(payload: ReturnRequest);
}
declare class CancelOrderReturnRequest extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        returnRequestCode: string;
        returnRequestModification: ReturnRequestModification;
    };
    readonly type = "[Order] Cancel Order Return Request";
    constructor(payload: {
        userId: string;
        returnRequestCode: string;
        returnRequestModification: ReturnRequestModification;
    });
}
declare class CancelOrderReturnRequestFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Order] Cancel Order Return Request Fail";
    constructor(payload: any);
}
declare class CancelOrderReturnRequestSuccess extends StateUtils.EntitySuccessAction {
    readonly type = "[Order] Cancel Order Return Request Success";
    constructor();
}
declare class LoadOrderReturnRequestList extends StateUtils.LoaderLoadAction {
    payload: {
        userId: string;
        pageSize?: number;
        currentPage?: number;
        sort?: string;
    };
    readonly type = "[Order] Load User Order Return Request List";
    constructor(payload: {
        userId: string;
        pageSize?: number;
        currentPage?: number;
        sort?: string;
    });
}
declare class LoadOrderReturnRequestListFail extends StateUtils.LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Order] Load User Order Return Request List Fail";
    constructor(payload: any);
}
declare class LoadOrderReturnRequestListSuccess extends StateUtils.LoaderSuccessAction {
    payload: ReturnRequestList;
    readonly type = "[Order] Load User Order Return Request List Success";
    constructor(payload: ReturnRequestList);
}
declare class ClearOrderReturnRequest extends StateUtils.LoaderResetAction {
    readonly type = "[Order] Clear Order Return Request Details";
    constructor();
}
declare class ClearOrderReturnRequestList extends StateUtils.LoaderResetAction {
    readonly type = "[Order] Clear Order Return Request List";
    constructor();
}
declare class ResetCancelReturnProcess extends StateUtils.EntityLoaderResetAction {
    readonly type = "[Order] Reset Cancel Return Request Process";
    constructor();
}
type OrderReturnRequestAction = CreateOrderReturnRequest | CreateOrderReturnRequestFail | CreateOrderReturnRequestSuccess | LoadOrderReturnRequest | LoadOrderReturnRequestFail | LoadOrderReturnRequestSuccess | CancelOrderReturnRequest | CancelOrderReturnRequestFail | CancelOrderReturnRequestSuccess | LoadOrderReturnRequestList | LoadOrderReturnRequestListFail | LoadOrderReturnRequestListSuccess | ClearOrderReturnRequest | ClearOrderReturnRequestList | ResetCancelReturnProcess;

declare const LOAD_USER_ORDERS = "[Order] Load User Orders";
declare const LOAD_USER_ORDERS_FAIL = "[Order] Load User Orders Fail";
declare const LOAD_USER_ORDERS_SUCCESS = "[Order] Load User Orders Success";
declare const CLEAR_USER_ORDERS = "[Order] Clear User Orders";
declare class LoadUserOrders extends StateUtils.LoaderLoadAction {
    payload: {
        userId: string;
        pageSize?: number;
        currentPage?: number;
        sort?: string;
        replenishmentOrderCode?: string;
    };
    readonly type = "[Order] Load User Orders";
    constructor(payload: {
        userId: string;
        pageSize?: number;
        currentPage?: number;
        sort?: string;
        replenishmentOrderCode?: string;
    });
}
declare class LoadUserOrdersFail extends StateUtils.LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Order] Load User Orders Fail";
    constructor(payload: any);
}
declare class LoadUserOrdersSuccess extends StateUtils.LoaderSuccessAction {
    payload: OrderHistoryList;
    readonly type = "[Order] Load User Orders Success";
    constructor(payload: OrderHistoryList);
}
declare class ClearUserOrders extends StateUtils.LoaderResetAction {
    readonly type = "[Order] Clear User Orders";
    constructor();
}
type UserOrdersAction = LoadUserOrders | LoadUserOrdersFail | LoadUserOrdersSuccess | ClearUserOrders;

declare const LOAD_REPLENISHMENT_ORDER_DETAILS = "[Order] Load Replenishment Order Details";
declare const LOAD_REPLENISHMENT_ORDER_DETAILS_SUCCESS = "[Order] Load Replenishment Order Details Success";
declare const LOAD_REPLENISHMENT_ORDER_DETAILS_FAIL = "[Order] Load Replenishment Order Details Fail";
declare const ClEAR_REPLENISHMENT_ORDER_DETAILS = "[Order] Clear Replenishment Order Details";
declare const CANCEL_REPLENISHMENT_ORDER = "[Order] Cancel Replenishment Order";
declare const CANCEL_REPLENISHMENT_ORDER_SUCCESS = "[Order] Cancel Replenishment Order Success";
declare const CANCEL_REPLENISHMENT_ORDER_FAIL = "[Order] Cancel Replenishment Order Fail";
declare const CLEAR_CANCEL_REPLENISHMENT_ORDER = "[Order] Clear Cancel Replenishment Order";
declare class LoadReplenishmentOrderDetails extends StateUtils.LoaderLoadAction {
    payload: {
        userId: string;
        replenishmentOrderCode: string;
    };
    readonly type = "[Order] Load Replenishment Order Details";
    constructor(payload: {
        userId: string;
        replenishmentOrderCode: string;
    });
}
declare class LoadReplenishmentOrderDetailsSuccess extends StateUtils.LoaderSuccessAction {
    payload: ReplenishmentOrder;
    readonly type = "[Order] Load Replenishment Order Details Success";
    constructor(payload: ReplenishmentOrder);
}
declare class LoadReplenishmentOrderDetailsFail extends StateUtils.LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Order] Load Replenishment Order Details Fail";
    constructor(payload: any);
}
declare class ClearReplenishmentOrderDetails extends StateUtils.LoaderResetAction {
    readonly type = "[Order] Clear Replenishment Order Details";
    constructor();
}
declare class CancelReplenishmentOrder extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        replenishmentOrderCode: string;
    };
    readonly type = "[Order] Cancel Replenishment Order";
    constructor(payload: {
        userId: string;
        replenishmentOrderCode: string;
    });
}
declare class CancelReplenishmentOrderSuccess extends StateUtils.EntitySuccessAction {
    payload: ReplenishmentOrder;
    readonly type = "[Order] Cancel Replenishment Order Success";
    constructor(payload: ReplenishmentOrder);
}
declare class CancelReplenishmentOrderFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Order] Cancel Replenishment Order Fail";
    constructor(payload: any);
}
declare class ClearCancelReplenishmentOrder extends StateUtils.EntityLoaderResetAction {
    readonly type = "[Order] Clear Cancel Replenishment Order";
    constructor();
}
type ReplenishmentOrderDetailsAction = LoadReplenishmentOrderDetails | LoadReplenishmentOrderDetailsSuccess | LoadReplenishmentOrderDetailsFail | ClearReplenishmentOrderDetails | CancelReplenishmentOrder | CancelReplenishmentOrderSuccess | CancelReplenishmentOrderFail | ClearCancelReplenishmentOrder;

declare const LOAD_USER_REPLENISHMENT_ORDERS = "[Order] Load User Replenishment Orders";
declare const LOAD_USER_REPLENISHMENT_ORDERS_FAIL = "[Order] Load User Replenishment Orders Fail";
declare const LOAD_USER_REPLENISHMENT_ORDERS_SUCCESS = "[Order] Load User Replenishment Orders Success";
declare const CLEAR_USER_REPLENISHMENT_ORDERS = "[Order] Clear User Replenishment Orders";
declare class LoadUserReplenishmentOrders extends StateUtils.LoaderLoadAction {
    payload: {
        userId: string;
        pageSize?: number;
        currentPage?: number;
        sort?: string;
    };
    readonly type = "[Order] Load User Replenishment Orders";
    constructor(payload: {
        userId: string;
        pageSize?: number;
        currentPage?: number;
        sort?: string;
    });
}
declare class LoadUserReplenishmentOrdersFail extends StateUtils.LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[Order] Load User Replenishment Orders Fail";
    constructor(payload: any);
}
declare class LoadUserReplenishmentOrdersSuccess extends StateUtils.LoaderSuccessAction {
    payload: ReplenishmentOrderList;
    readonly type = "[Order] Load User Replenishment Orders Success";
    constructor(payload: ReplenishmentOrderList);
}
declare class ClearUserReplenishmentOrders extends StateUtils.LoaderResetAction {
    readonly type = "[Order] Clear User Replenishment Orders";
    constructor();
}
type UserReplenishmentOrdersAction = LoadUserReplenishmentOrders | LoadUserReplenishmentOrdersFail | LoadUserReplenishmentOrdersSuccess | ClearUserReplenishmentOrders;

declare const LOAD_CONSIGNMENT_TRACKING_BY_ID = "[Order] Load Consignment Tracking By ID Data";
declare const LOAD_CONSIGNMENT_TRACKING_BY_ID_FAIL = "[Order] Load  Consignment Tracking By ID Data Fail";
declare const LOAD_CONSIGNMENT_TRACKING_BY_ID_SUCCESS = "[Order] Load Consignment Tracking By ID Data Success";
declare class LoadConsignmentTrackingById extends StateUtils.EntityLoadAction {
    payload: {
        orderCode: string;
        consignmentCode: string;
        userId: string;
    };
    readonly type = "[Order] Load Consignment Tracking By ID Data";
    constructor(payload: {
        orderCode: string;
        consignmentCode: string;
        userId: string;
    });
}
declare class LoadConsignmentTrackingByIdFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        orderCode: string;
        consignmentCode: string;
        error: any;
    };
    readonly type = "[Order] Load  Consignment Tracking By ID Data Fail";
    constructor(payload: {
        orderCode: string;
        consignmentCode: string;
        error: any;
    });
}
declare class LoadConsignmentTrackingByIdSuccess extends StateUtils.EntitySuccessAction {
    payload: {
        orderCode: string;
        consignmentCode: string;
        consignmentTracking: ConsignmentTracking;
    };
    readonly type = "[Order] Load Consignment Tracking By ID Data Success";
    constructor(payload: {
        orderCode: string;
        consignmentCode: string;
        consignmentTracking: ConsignmentTracking;
    });
}
type ConsignmentTrackingByIdAction = LoadConsignmentTrackingById | LoadConsignmentTrackingByIdFail | LoadConsignmentTrackingByIdSuccess;

declare const LOAD_ORDER_BY_ID = "[Order] Load Order By ID Data";
declare const LOAD_ORDER_BY_ID_FAIL = "[Order] Load Order By ID Data Fail";
declare const LOAD_ORDER_BY_ID_SUCCESS = "[Order] Load Order By ID Data Success";
declare class LoadOrderById extends StateUtils.EntityLoadAction {
    payload: {
        userId: string;
        code: string;
    };
    readonly type = "[Order] Load Order By ID Data";
    constructor(payload: {
        userId: string;
        code: string;
    });
}
declare class LoadOrderByIdFail extends StateUtils.EntityFailAction implements ErrorAction {
    payload: {
        code: string;
        error: any;
    };
    readonly type = "[Order] Load Order By ID Data Fail";
    constructor(payload: {
        code: string;
        error: any;
    });
}
declare class LoadOrderByIdSuccess extends StateUtils.EntitySuccessAction {
    payload: Order;
    readonly type = "[Order] Load Order By ID Data Success";
    constructor(payload: Order);
}
type OrderByIdAction = LoadOrderById | LoadOrderByIdFail | LoadOrderByIdSuccess;

declare const orderGroup_actions_d_CANCEL_ORDER: typeof CANCEL_ORDER;
declare const orderGroup_actions_d_CANCEL_ORDER_FAIL: typeof CANCEL_ORDER_FAIL;
declare const orderGroup_actions_d_CANCEL_ORDER_RETURN_REQUEST: typeof CANCEL_ORDER_RETURN_REQUEST;
declare const orderGroup_actions_d_CANCEL_ORDER_RETURN_REQUEST_FAIL: typeof CANCEL_ORDER_RETURN_REQUEST_FAIL;
declare const orderGroup_actions_d_CANCEL_ORDER_RETURN_REQUEST_SUCCESS: typeof CANCEL_ORDER_RETURN_REQUEST_SUCCESS;
declare const orderGroup_actions_d_CANCEL_ORDER_SUCCESS: typeof CANCEL_ORDER_SUCCESS;
declare const orderGroup_actions_d_CANCEL_REPLENISHMENT_ORDER: typeof CANCEL_REPLENISHMENT_ORDER;
declare const orderGroup_actions_d_CANCEL_REPLENISHMENT_ORDER_FAIL: typeof CANCEL_REPLENISHMENT_ORDER_FAIL;
declare const orderGroup_actions_d_CANCEL_REPLENISHMENT_ORDER_SUCCESS: typeof CANCEL_REPLENISHMENT_ORDER_SUCCESS;
declare const orderGroup_actions_d_CLEAR_CANCEL_REPLENISHMENT_ORDER: typeof CLEAR_CANCEL_REPLENISHMENT_ORDER;
declare const orderGroup_actions_d_CLEAR_CONSIGNMENT_TRACKING: typeof CLEAR_CONSIGNMENT_TRACKING;
declare const orderGroup_actions_d_CLEAR_ORDER_DETAILS: typeof CLEAR_ORDER_DETAILS;
declare const orderGroup_actions_d_CLEAR_ORDER_RETURN_REQUEST: typeof CLEAR_ORDER_RETURN_REQUEST;
declare const orderGroup_actions_d_CLEAR_ORDER_RETURN_REQUEST_LIST: typeof CLEAR_ORDER_RETURN_REQUEST_LIST;
declare const orderGroup_actions_d_CLEAR_USER_ORDERS: typeof CLEAR_USER_ORDERS;
declare const orderGroup_actions_d_CLEAR_USER_REPLENISHMENT_ORDERS: typeof CLEAR_USER_REPLENISHMENT_ORDERS;
declare const orderGroup_actions_d_CREATE_ORDER_RETURN_REQUEST: typeof CREATE_ORDER_RETURN_REQUEST;
declare const orderGroup_actions_d_CREATE_ORDER_RETURN_REQUEST_FAIL: typeof CREATE_ORDER_RETURN_REQUEST_FAIL;
declare const orderGroup_actions_d_CREATE_ORDER_RETURN_REQUEST_SUCCESS: typeof CREATE_ORDER_RETURN_REQUEST_SUCCESS;
type orderGroup_actions_d_CancelOrder = CancelOrder;
declare const orderGroup_actions_d_CancelOrder: typeof CancelOrder;
type orderGroup_actions_d_CancelOrderFail = CancelOrderFail;
declare const orderGroup_actions_d_CancelOrderFail: typeof CancelOrderFail;
type orderGroup_actions_d_CancelOrderReturnRequest = CancelOrderReturnRequest;
declare const orderGroup_actions_d_CancelOrderReturnRequest: typeof CancelOrderReturnRequest;
type orderGroup_actions_d_CancelOrderReturnRequestFail = CancelOrderReturnRequestFail;
declare const orderGroup_actions_d_CancelOrderReturnRequestFail: typeof CancelOrderReturnRequestFail;
type orderGroup_actions_d_CancelOrderReturnRequestSuccess = CancelOrderReturnRequestSuccess;
declare const orderGroup_actions_d_CancelOrderReturnRequestSuccess: typeof CancelOrderReturnRequestSuccess;
type orderGroup_actions_d_CancelOrderSuccess = CancelOrderSuccess;
declare const orderGroup_actions_d_CancelOrderSuccess: typeof CancelOrderSuccess;
type orderGroup_actions_d_CancelReplenishmentOrder = CancelReplenishmentOrder;
declare const orderGroup_actions_d_CancelReplenishmentOrder: typeof CancelReplenishmentOrder;
type orderGroup_actions_d_CancelReplenishmentOrderFail = CancelReplenishmentOrderFail;
declare const orderGroup_actions_d_CancelReplenishmentOrderFail: typeof CancelReplenishmentOrderFail;
type orderGroup_actions_d_CancelReplenishmentOrderSuccess = CancelReplenishmentOrderSuccess;
declare const orderGroup_actions_d_CancelReplenishmentOrderSuccess: typeof CancelReplenishmentOrderSuccess;
declare const orderGroup_actions_d_ClEAR_REPLENISHMENT_ORDER_DETAILS: typeof ClEAR_REPLENISHMENT_ORDER_DETAILS;
type orderGroup_actions_d_ClearCancelReplenishmentOrder = ClearCancelReplenishmentOrder;
declare const orderGroup_actions_d_ClearCancelReplenishmentOrder: typeof ClearCancelReplenishmentOrder;
type orderGroup_actions_d_ClearConsignmentTracking = ClearConsignmentTracking;
declare const orderGroup_actions_d_ClearConsignmentTracking: typeof ClearConsignmentTracking;
type orderGroup_actions_d_ClearOrderDetails = ClearOrderDetails;
declare const orderGroup_actions_d_ClearOrderDetails: typeof ClearOrderDetails;
type orderGroup_actions_d_ClearOrderReturnRequest = ClearOrderReturnRequest;
declare const orderGroup_actions_d_ClearOrderReturnRequest: typeof ClearOrderReturnRequest;
type orderGroup_actions_d_ClearOrderReturnRequestList = ClearOrderReturnRequestList;
declare const orderGroup_actions_d_ClearOrderReturnRequestList: typeof ClearOrderReturnRequestList;
type orderGroup_actions_d_ClearReplenishmentOrderDetails = ClearReplenishmentOrderDetails;
declare const orderGroup_actions_d_ClearReplenishmentOrderDetails: typeof ClearReplenishmentOrderDetails;
type orderGroup_actions_d_ClearUserOrders = ClearUserOrders;
declare const orderGroup_actions_d_ClearUserOrders: typeof ClearUserOrders;
type orderGroup_actions_d_ClearUserReplenishmentOrders = ClearUserReplenishmentOrders;
declare const orderGroup_actions_d_ClearUserReplenishmentOrders: typeof ClearUserReplenishmentOrders;
type orderGroup_actions_d_ConsignmentTrackingAction = ConsignmentTrackingAction;
type orderGroup_actions_d_ConsignmentTrackingByIdAction = ConsignmentTrackingByIdAction;
type orderGroup_actions_d_CreateOrderReturnRequest = CreateOrderReturnRequest;
declare const orderGroup_actions_d_CreateOrderReturnRequest: typeof CreateOrderReturnRequest;
type orderGroup_actions_d_CreateOrderReturnRequestFail = CreateOrderReturnRequestFail;
declare const orderGroup_actions_d_CreateOrderReturnRequestFail: typeof CreateOrderReturnRequestFail;
type orderGroup_actions_d_CreateOrderReturnRequestSuccess = CreateOrderReturnRequestSuccess;
declare const orderGroup_actions_d_CreateOrderReturnRequestSuccess: typeof CreateOrderReturnRequestSuccess;
declare const orderGroup_actions_d_LOAD_CONSIGNMENT_TRACKING: typeof LOAD_CONSIGNMENT_TRACKING;
declare const orderGroup_actions_d_LOAD_CONSIGNMENT_TRACKING_BY_ID: typeof LOAD_CONSIGNMENT_TRACKING_BY_ID;
declare const orderGroup_actions_d_LOAD_CONSIGNMENT_TRACKING_BY_ID_FAIL: typeof LOAD_CONSIGNMENT_TRACKING_BY_ID_FAIL;
declare const orderGroup_actions_d_LOAD_CONSIGNMENT_TRACKING_BY_ID_SUCCESS: typeof LOAD_CONSIGNMENT_TRACKING_BY_ID_SUCCESS;
declare const orderGroup_actions_d_LOAD_CONSIGNMENT_TRACKING_FAIL: typeof LOAD_CONSIGNMENT_TRACKING_FAIL;
declare const orderGroup_actions_d_LOAD_CONSIGNMENT_TRACKING_SUCCESS: typeof LOAD_CONSIGNMENT_TRACKING_SUCCESS;
declare const orderGroup_actions_d_LOAD_ORDER_BY_ID: typeof LOAD_ORDER_BY_ID;
declare const orderGroup_actions_d_LOAD_ORDER_BY_ID_FAIL: typeof LOAD_ORDER_BY_ID_FAIL;
declare const orderGroup_actions_d_LOAD_ORDER_BY_ID_SUCCESS: typeof LOAD_ORDER_BY_ID_SUCCESS;
declare const orderGroup_actions_d_LOAD_ORDER_DETAILS: typeof LOAD_ORDER_DETAILS;
declare const orderGroup_actions_d_LOAD_ORDER_DETAILS_FAIL: typeof LOAD_ORDER_DETAILS_FAIL;
declare const orderGroup_actions_d_LOAD_ORDER_DETAILS_SUCCESS: typeof LOAD_ORDER_DETAILS_SUCCESS;
declare const orderGroup_actions_d_LOAD_ORDER_RETURN_REQUEST: typeof LOAD_ORDER_RETURN_REQUEST;
declare const orderGroup_actions_d_LOAD_ORDER_RETURN_REQUEST_FAIL: typeof LOAD_ORDER_RETURN_REQUEST_FAIL;
declare const orderGroup_actions_d_LOAD_ORDER_RETURN_REQUEST_LIST: typeof LOAD_ORDER_RETURN_REQUEST_LIST;
declare const orderGroup_actions_d_LOAD_ORDER_RETURN_REQUEST_LIST_FAIL: typeof LOAD_ORDER_RETURN_REQUEST_LIST_FAIL;
declare const orderGroup_actions_d_LOAD_ORDER_RETURN_REQUEST_LIST_SUCCESS: typeof LOAD_ORDER_RETURN_REQUEST_LIST_SUCCESS;
declare const orderGroup_actions_d_LOAD_ORDER_RETURN_REQUEST_SUCCESS: typeof LOAD_ORDER_RETURN_REQUEST_SUCCESS;
declare const orderGroup_actions_d_LOAD_REPLENISHMENT_ORDER_DETAILS: typeof LOAD_REPLENISHMENT_ORDER_DETAILS;
declare const orderGroup_actions_d_LOAD_REPLENISHMENT_ORDER_DETAILS_FAIL: typeof LOAD_REPLENISHMENT_ORDER_DETAILS_FAIL;
declare const orderGroup_actions_d_LOAD_REPLENISHMENT_ORDER_DETAILS_SUCCESS: typeof LOAD_REPLENISHMENT_ORDER_DETAILS_SUCCESS;
declare const orderGroup_actions_d_LOAD_USER_ORDERS: typeof LOAD_USER_ORDERS;
declare const orderGroup_actions_d_LOAD_USER_ORDERS_FAIL: typeof LOAD_USER_ORDERS_FAIL;
declare const orderGroup_actions_d_LOAD_USER_ORDERS_SUCCESS: typeof LOAD_USER_ORDERS_SUCCESS;
declare const orderGroup_actions_d_LOAD_USER_REPLENISHMENT_ORDERS: typeof LOAD_USER_REPLENISHMENT_ORDERS;
declare const orderGroup_actions_d_LOAD_USER_REPLENISHMENT_ORDERS_FAIL: typeof LOAD_USER_REPLENISHMENT_ORDERS_FAIL;
declare const orderGroup_actions_d_LOAD_USER_REPLENISHMENT_ORDERS_SUCCESS: typeof LOAD_USER_REPLENISHMENT_ORDERS_SUCCESS;
type orderGroup_actions_d_LoadConsignmentTracking = LoadConsignmentTracking;
declare const orderGroup_actions_d_LoadConsignmentTracking: typeof LoadConsignmentTracking;
type orderGroup_actions_d_LoadConsignmentTrackingById = LoadConsignmentTrackingById;
declare const orderGroup_actions_d_LoadConsignmentTrackingById: typeof LoadConsignmentTrackingById;
type orderGroup_actions_d_LoadConsignmentTrackingByIdFail = LoadConsignmentTrackingByIdFail;
declare const orderGroup_actions_d_LoadConsignmentTrackingByIdFail: typeof LoadConsignmentTrackingByIdFail;
type orderGroup_actions_d_LoadConsignmentTrackingByIdSuccess = LoadConsignmentTrackingByIdSuccess;
declare const orderGroup_actions_d_LoadConsignmentTrackingByIdSuccess: typeof LoadConsignmentTrackingByIdSuccess;
type orderGroup_actions_d_LoadConsignmentTrackingFail = LoadConsignmentTrackingFail;
declare const orderGroup_actions_d_LoadConsignmentTrackingFail: typeof LoadConsignmentTrackingFail;
type orderGroup_actions_d_LoadConsignmentTrackingSuccess = LoadConsignmentTrackingSuccess;
declare const orderGroup_actions_d_LoadConsignmentTrackingSuccess: typeof LoadConsignmentTrackingSuccess;
type orderGroup_actions_d_LoadOrderById = LoadOrderById;
declare const orderGroup_actions_d_LoadOrderById: typeof LoadOrderById;
type orderGroup_actions_d_LoadOrderByIdFail = LoadOrderByIdFail;
declare const orderGroup_actions_d_LoadOrderByIdFail: typeof LoadOrderByIdFail;
type orderGroup_actions_d_LoadOrderByIdSuccess = LoadOrderByIdSuccess;
declare const orderGroup_actions_d_LoadOrderByIdSuccess: typeof LoadOrderByIdSuccess;
type orderGroup_actions_d_LoadOrderDetails = LoadOrderDetails;
declare const orderGroup_actions_d_LoadOrderDetails: typeof LoadOrderDetails;
type orderGroup_actions_d_LoadOrderDetailsFail = LoadOrderDetailsFail;
declare const orderGroup_actions_d_LoadOrderDetailsFail: typeof LoadOrderDetailsFail;
type orderGroup_actions_d_LoadOrderDetailsSuccess = LoadOrderDetailsSuccess;
declare const orderGroup_actions_d_LoadOrderDetailsSuccess: typeof LoadOrderDetailsSuccess;
type orderGroup_actions_d_LoadOrderReturnRequest = LoadOrderReturnRequest;
declare const orderGroup_actions_d_LoadOrderReturnRequest: typeof LoadOrderReturnRequest;
type orderGroup_actions_d_LoadOrderReturnRequestFail = LoadOrderReturnRequestFail;
declare const orderGroup_actions_d_LoadOrderReturnRequestFail: typeof LoadOrderReturnRequestFail;
type orderGroup_actions_d_LoadOrderReturnRequestList = LoadOrderReturnRequestList;
declare const orderGroup_actions_d_LoadOrderReturnRequestList: typeof LoadOrderReturnRequestList;
type orderGroup_actions_d_LoadOrderReturnRequestListFail = LoadOrderReturnRequestListFail;
declare const orderGroup_actions_d_LoadOrderReturnRequestListFail: typeof LoadOrderReturnRequestListFail;
type orderGroup_actions_d_LoadOrderReturnRequestListSuccess = LoadOrderReturnRequestListSuccess;
declare const orderGroup_actions_d_LoadOrderReturnRequestListSuccess: typeof LoadOrderReturnRequestListSuccess;
type orderGroup_actions_d_LoadOrderReturnRequestSuccess = LoadOrderReturnRequestSuccess;
declare const orderGroup_actions_d_LoadOrderReturnRequestSuccess: typeof LoadOrderReturnRequestSuccess;
type orderGroup_actions_d_LoadReplenishmentOrderDetails = LoadReplenishmentOrderDetails;
declare const orderGroup_actions_d_LoadReplenishmentOrderDetails: typeof LoadReplenishmentOrderDetails;
type orderGroup_actions_d_LoadReplenishmentOrderDetailsFail = LoadReplenishmentOrderDetailsFail;
declare const orderGroup_actions_d_LoadReplenishmentOrderDetailsFail: typeof LoadReplenishmentOrderDetailsFail;
type orderGroup_actions_d_LoadReplenishmentOrderDetailsSuccess = LoadReplenishmentOrderDetailsSuccess;
declare const orderGroup_actions_d_LoadReplenishmentOrderDetailsSuccess: typeof LoadReplenishmentOrderDetailsSuccess;
type orderGroup_actions_d_LoadUserOrders = LoadUserOrders;
declare const orderGroup_actions_d_LoadUserOrders: typeof LoadUserOrders;
type orderGroup_actions_d_LoadUserOrdersFail = LoadUserOrdersFail;
declare const orderGroup_actions_d_LoadUserOrdersFail: typeof LoadUserOrdersFail;
type orderGroup_actions_d_LoadUserOrdersSuccess = LoadUserOrdersSuccess;
declare const orderGroup_actions_d_LoadUserOrdersSuccess: typeof LoadUserOrdersSuccess;
type orderGroup_actions_d_LoadUserReplenishmentOrders = LoadUserReplenishmentOrders;
declare const orderGroup_actions_d_LoadUserReplenishmentOrders: typeof LoadUserReplenishmentOrders;
type orderGroup_actions_d_LoadUserReplenishmentOrdersFail = LoadUserReplenishmentOrdersFail;
declare const orderGroup_actions_d_LoadUserReplenishmentOrdersFail: typeof LoadUserReplenishmentOrdersFail;
type orderGroup_actions_d_LoadUserReplenishmentOrdersSuccess = LoadUserReplenishmentOrdersSuccess;
declare const orderGroup_actions_d_LoadUserReplenishmentOrdersSuccess: typeof LoadUserReplenishmentOrdersSuccess;
type orderGroup_actions_d_OrderByIdAction = OrderByIdAction;
type orderGroup_actions_d_OrderDetailsAction = OrderDetailsAction;
type orderGroup_actions_d_OrderReturnRequestAction = OrderReturnRequestAction;
declare const orderGroup_actions_d_RESET_CANCEL_ORDER_PROCESS: typeof RESET_CANCEL_ORDER_PROCESS;
declare const orderGroup_actions_d_RESET_CANCEL_RETURN_PROCESS: typeof RESET_CANCEL_RETURN_PROCESS;
type orderGroup_actions_d_ReplenishmentOrderDetailsAction = ReplenishmentOrderDetailsAction;
type orderGroup_actions_d_ResetCancelOrderProcess = ResetCancelOrderProcess;
declare const orderGroup_actions_d_ResetCancelOrderProcess: typeof ResetCancelOrderProcess;
type orderGroup_actions_d_ResetCancelReturnProcess = ResetCancelReturnProcess;
declare const orderGroup_actions_d_ResetCancelReturnProcess: typeof ResetCancelReturnProcess;
type orderGroup_actions_d_UserOrdersAction = UserOrdersAction;
type orderGroup_actions_d_UserReplenishmentOrdersAction = UserReplenishmentOrdersAction;
declare namespace orderGroup_actions_d {
  export { orderGroup_actions_d_CANCEL_ORDER as CANCEL_ORDER, orderGroup_actions_d_CANCEL_ORDER_FAIL as CANCEL_ORDER_FAIL, orderGroup_actions_d_CANCEL_ORDER_RETURN_REQUEST as CANCEL_ORDER_RETURN_REQUEST, orderGroup_actions_d_CANCEL_ORDER_RETURN_REQUEST_FAIL as CANCEL_ORDER_RETURN_REQUEST_FAIL, orderGroup_actions_d_CANCEL_ORDER_RETURN_REQUEST_SUCCESS as CANCEL_ORDER_RETURN_REQUEST_SUCCESS, orderGroup_actions_d_CANCEL_ORDER_SUCCESS as CANCEL_ORDER_SUCCESS, orderGroup_actions_d_CANCEL_REPLENISHMENT_ORDER as CANCEL_REPLENISHMENT_ORDER, orderGroup_actions_d_CANCEL_REPLENISHMENT_ORDER_FAIL as CANCEL_REPLENISHMENT_ORDER_FAIL, orderGroup_actions_d_CANCEL_REPLENISHMENT_ORDER_SUCCESS as CANCEL_REPLENISHMENT_ORDER_SUCCESS, orderGroup_actions_d_CLEAR_CANCEL_REPLENISHMENT_ORDER as CLEAR_CANCEL_REPLENISHMENT_ORDER, orderGroup_actions_d_CLEAR_CONSIGNMENT_TRACKING as CLEAR_CONSIGNMENT_TRACKING, orderGroup_actions_d_CLEAR_ORDER_DETAILS as CLEAR_ORDER_DETAILS, orderGroup_actions_d_CLEAR_ORDER_RETURN_REQUEST as CLEAR_ORDER_RETURN_REQUEST, orderGroup_actions_d_CLEAR_ORDER_RETURN_REQUEST_LIST as CLEAR_ORDER_RETURN_REQUEST_LIST, orderGroup_actions_d_CLEAR_USER_ORDERS as CLEAR_USER_ORDERS, orderGroup_actions_d_CLEAR_USER_REPLENISHMENT_ORDERS as CLEAR_USER_REPLENISHMENT_ORDERS, orderGroup_actions_d_CREATE_ORDER_RETURN_REQUEST as CREATE_ORDER_RETURN_REQUEST, orderGroup_actions_d_CREATE_ORDER_RETURN_REQUEST_FAIL as CREATE_ORDER_RETURN_REQUEST_FAIL, orderGroup_actions_d_CREATE_ORDER_RETURN_REQUEST_SUCCESS as CREATE_ORDER_RETURN_REQUEST_SUCCESS, orderGroup_actions_d_CancelOrder as CancelOrder, orderGroup_actions_d_CancelOrderFail as CancelOrderFail, orderGroup_actions_d_CancelOrderReturnRequest as CancelOrderReturnRequest, orderGroup_actions_d_CancelOrderReturnRequestFail as CancelOrderReturnRequestFail, orderGroup_actions_d_CancelOrderReturnRequestSuccess as CancelOrderReturnRequestSuccess, orderGroup_actions_d_CancelOrderSuccess as CancelOrderSuccess, orderGroup_actions_d_CancelReplenishmentOrder as CancelReplenishmentOrder, orderGroup_actions_d_CancelReplenishmentOrderFail as CancelReplenishmentOrderFail, orderGroup_actions_d_CancelReplenishmentOrderSuccess as CancelReplenishmentOrderSuccess, orderGroup_actions_d_ClEAR_REPLENISHMENT_ORDER_DETAILS as ClEAR_REPLENISHMENT_ORDER_DETAILS, orderGroup_actions_d_ClearCancelReplenishmentOrder as ClearCancelReplenishmentOrder, orderGroup_actions_d_ClearConsignmentTracking as ClearConsignmentTracking, orderGroup_actions_d_ClearOrderDetails as ClearOrderDetails, orderGroup_actions_d_ClearOrderReturnRequest as ClearOrderReturnRequest, orderGroup_actions_d_ClearOrderReturnRequestList as ClearOrderReturnRequestList, orderGroup_actions_d_ClearReplenishmentOrderDetails as ClearReplenishmentOrderDetails, orderGroup_actions_d_ClearUserOrders as ClearUserOrders, orderGroup_actions_d_ClearUserReplenishmentOrders as ClearUserReplenishmentOrders, orderGroup_actions_d_CreateOrderReturnRequest as CreateOrderReturnRequest, orderGroup_actions_d_CreateOrderReturnRequestFail as CreateOrderReturnRequestFail, orderGroup_actions_d_CreateOrderReturnRequestSuccess as CreateOrderReturnRequestSuccess, orderGroup_actions_d_LOAD_CONSIGNMENT_TRACKING as LOAD_CONSIGNMENT_TRACKING, orderGroup_actions_d_LOAD_CONSIGNMENT_TRACKING_BY_ID as LOAD_CONSIGNMENT_TRACKING_BY_ID, orderGroup_actions_d_LOAD_CONSIGNMENT_TRACKING_BY_ID_FAIL as LOAD_CONSIGNMENT_TRACKING_BY_ID_FAIL, orderGroup_actions_d_LOAD_CONSIGNMENT_TRACKING_BY_ID_SUCCESS as LOAD_CONSIGNMENT_TRACKING_BY_ID_SUCCESS, orderGroup_actions_d_LOAD_CONSIGNMENT_TRACKING_FAIL as LOAD_CONSIGNMENT_TRACKING_FAIL, orderGroup_actions_d_LOAD_CONSIGNMENT_TRACKING_SUCCESS as LOAD_CONSIGNMENT_TRACKING_SUCCESS, orderGroup_actions_d_LOAD_ORDER_BY_ID as LOAD_ORDER_BY_ID, orderGroup_actions_d_LOAD_ORDER_BY_ID_FAIL as LOAD_ORDER_BY_ID_FAIL, orderGroup_actions_d_LOAD_ORDER_BY_ID_SUCCESS as LOAD_ORDER_BY_ID_SUCCESS, orderGroup_actions_d_LOAD_ORDER_DETAILS as LOAD_ORDER_DETAILS, orderGroup_actions_d_LOAD_ORDER_DETAILS_FAIL as LOAD_ORDER_DETAILS_FAIL, orderGroup_actions_d_LOAD_ORDER_DETAILS_SUCCESS as LOAD_ORDER_DETAILS_SUCCESS, orderGroup_actions_d_LOAD_ORDER_RETURN_REQUEST as LOAD_ORDER_RETURN_REQUEST, orderGroup_actions_d_LOAD_ORDER_RETURN_REQUEST_FAIL as LOAD_ORDER_RETURN_REQUEST_FAIL, orderGroup_actions_d_LOAD_ORDER_RETURN_REQUEST_LIST as LOAD_ORDER_RETURN_REQUEST_LIST, orderGroup_actions_d_LOAD_ORDER_RETURN_REQUEST_LIST_FAIL as LOAD_ORDER_RETURN_REQUEST_LIST_FAIL, orderGroup_actions_d_LOAD_ORDER_RETURN_REQUEST_LIST_SUCCESS as LOAD_ORDER_RETURN_REQUEST_LIST_SUCCESS, orderGroup_actions_d_LOAD_ORDER_RETURN_REQUEST_SUCCESS as LOAD_ORDER_RETURN_REQUEST_SUCCESS, orderGroup_actions_d_LOAD_REPLENISHMENT_ORDER_DETAILS as LOAD_REPLENISHMENT_ORDER_DETAILS, orderGroup_actions_d_LOAD_REPLENISHMENT_ORDER_DETAILS_FAIL as LOAD_REPLENISHMENT_ORDER_DETAILS_FAIL, orderGroup_actions_d_LOAD_REPLENISHMENT_ORDER_DETAILS_SUCCESS as LOAD_REPLENISHMENT_ORDER_DETAILS_SUCCESS, orderGroup_actions_d_LOAD_USER_ORDERS as LOAD_USER_ORDERS, orderGroup_actions_d_LOAD_USER_ORDERS_FAIL as LOAD_USER_ORDERS_FAIL, orderGroup_actions_d_LOAD_USER_ORDERS_SUCCESS as LOAD_USER_ORDERS_SUCCESS, orderGroup_actions_d_LOAD_USER_REPLENISHMENT_ORDERS as LOAD_USER_REPLENISHMENT_ORDERS, orderGroup_actions_d_LOAD_USER_REPLENISHMENT_ORDERS_FAIL as LOAD_USER_REPLENISHMENT_ORDERS_FAIL, orderGroup_actions_d_LOAD_USER_REPLENISHMENT_ORDERS_SUCCESS as LOAD_USER_REPLENISHMENT_ORDERS_SUCCESS, orderGroup_actions_d_LoadConsignmentTracking as LoadConsignmentTracking, orderGroup_actions_d_LoadConsignmentTrackingById as LoadConsignmentTrackingById, orderGroup_actions_d_LoadConsignmentTrackingByIdFail as LoadConsignmentTrackingByIdFail, orderGroup_actions_d_LoadConsignmentTrackingByIdSuccess as LoadConsignmentTrackingByIdSuccess, orderGroup_actions_d_LoadConsignmentTrackingFail as LoadConsignmentTrackingFail, orderGroup_actions_d_LoadConsignmentTrackingSuccess as LoadConsignmentTrackingSuccess, orderGroup_actions_d_LoadOrderById as LoadOrderById, orderGroup_actions_d_LoadOrderByIdFail as LoadOrderByIdFail, orderGroup_actions_d_LoadOrderByIdSuccess as LoadOrderByIdSuccess, orderGroup_actions_d_LoadOrderDetails as LoadOrderDetails, orderGroup_actions_d_LoadOrderDetailsFail as LoadOrderDetailsFail, orderGroup_actions_d_LoadOrderDetailsSuccess as LoadOrderDetailsSuccess, orderGroup_actions_d_LoadOrderReturnRequest as LoadOrderReturnRequest, orderGroup_actions_d_LoadOrderReturnRequestFail as LoadOrderReturnRequestFail, orderGroup_actions_d_LoadOrderReturnRequestList as LoadOrderReturnRequestList, orderGroup_actions_d_LoadOrderReturnRequestListFail as LoadOrderReturnRequestListFail, orderGroup_actions_d_LoadOrderReturnRequestListSuccess as LoadOrderReturnRequestListSuccess, orderGroup_actions_d_LoadOrderReturnRequestSuccess as LoadOrderReturnRequestSuccess, orderGroup_actions_d_LoadReplenishmentOrderDetails as LoadReplenishmentOrderDetails, orderGroup_actions_d_LoadReplenishmentOrderDetailsFail as LoadReplenishmentOrderDetailsFail, orderGroup_actions_d_LoadReplenishmentOrderDetailsSuccess as LoadReplenishmentOrderDetailsSuccess, orderGroup_actions_d_LoadUserOrders as LoadUserOrders, orderGroup_actions_d_LoadUserOrdersFail as LoadUserOrdersFail, orderGroup_actions_d_LoadUserOrdersSuccess as LoadUserOrdersSuccess, orderGroup_actions_d_LoadUserReplenishmentOrders as LoadUserReplenishmentOrders, orderGroup_actions_d_LoadUserReplenishmentOrdersFail as LoadUserReplenishmentOrdersFail, orderGroup_actions_d_LoadUserReplenishmentOrdersSuccess as LoadUserReplenishmentOrdersSuccess, orderGroup_actions_d_RESET_CANCEL_ORDER_PROCESS as RESET_CANCEL_ORDER_PROCESS, orderGroup_actions_d_RESET_CANCEL_RETURN_PROCESS as RESET_CANCEL_RETURN_PROCESS, orderGroup_actions_d_ResetCancelOrderProcess as ResetCancelOrderProcess, orderGroup_actions_d_ResetCancelReturnProcess as ResetCancelReturnProcess };
  export type { orderGroup_actions_d_ConsignmentTrackingAction as ConsignmentTrackingAction, orderGroup_actions_d_ConsignmentTrackingByIdAction as ConsignmentTrackingByIdAction, orderGroup_actions_d_OrderByIdAction as OrderByIdAction, orderGroup_actions_d_OrderDetailsAction as OrderDetailsAction, orderGroup_actions_d_OrderReturnRequestAction as OrderReturnRequestAction, orderGroup_actions_d_ReplenishmentOrderDetailsAction as ReplenishmentOrderDetailsAction, orderGroup_actions_d_UserOrdersAction as UserOrdersAction, orderGroup_actions_d_UserReplenishmentOrdersAction as UserReplenishmentOrdersAction };
}

declare const getConsignmentTrackingState: MemoizedSelector<StateWithOrder, ConsignmentTrackingState>;
declare const getConsignmentTracking: MemoizedSelector<StateWithOrder, ConsignmentTracking>;

declare const getOrderState: MemoizedSelector<StateWithOrder, OrderState>;

declare const getOrderDetailState: MemoizedSelector<StateWithOrder, StateUtils.LoaderState<Order>>;
declare const getOrderDetails: MemoizedSelector<StateWithOrder, Order>;
declare const getOrderDetailsLoading: MemoizedSelector<StateWithOrder, boolean>;

declare const getOrderReturnRequestState: MemoizedSelector<StateWithOrder, StateUtils.LoaderState<ReturnRequest>>;
declare const getOrderReturnRequest: MemoizedSelector<StateWithOrder, ReturnRequest>;
declare const getOrderReturnRequestLoading: MemoizedSelector<StateWithOrder, boolean>;
declare const getOrderReturnRequestSuccess: MemoizedSelector<StateWithOrder, boolean>;
declare const getOrderReturnRequestListState: MemoizedSelector<StateWithOrder, StateUtils.LoaderState<ReturnRequestList>>;
declare const getOrderReturnRequestList: MemoizedSelector<StateWithOrder, ReturnRequestList>;

declare const getOrdersState: MemoizedSelector<StateWithOrder, StateUtils.LoaderState<OrderHistoryList>>;
declare const getOrdersLoaded: MemoizedSelector<StateWithOrder, boolean>;
declare const getOrders: MemoizedSelector<StateWithOrder, OrderHistoryList>;

declare const getReplenishmentOrderState: MemoizedSelector<StateWithOrder, StateUtils.LoaderState<ReplenishmentOrder>>;
declare const getReplenishmentOrderDetailsValue: MemoizedSelector<StateWithOrder, ReplenishmentOrder>;
declare const getReplenishmentOrderDetailsLoading: MemoizedSelector<StateWithOrder, boolean>;
declare const getReplenishmentOrderDetailsSuccess: MemoizedSelector<StateWithOrder, boolean>;
declare const getReplenishmentOrderDetailsError: MemoizedSelector<StateWithOrder, boolean>;

declare const getReplenishmentOrdersState: MemoizedSelector<StateWithOrder, StateUtils.LoaderState<ReplenishmentOrderList>>;
declare const getReplenishmentOrders: MemoizedSelector<StateWithOrder, ReplenishmentOrderList>;
declare const getReplenishmentOrdersLoading: MemoizedSelector<StateWithOrder, boolean>;
declare const getReplenishmentOrdersError: MemoizedSelector<StateWithOrder, boolean>;
declare const getReplenishmentOrdersSuccess: MemoizedSelector<StateWithOrder, boolean>;

declare const getConsignmentTrackingByIdEntities: MemoizedSelector<StateWithOrder, StateUtils.EntityLoaderState<ConsignmentTracking>>;
declare const getConsignmentTrackingByIdEntity: (orderCode: string, consignmentCode: string) => MemoizedSelector<StateWithOrder, StateUtils.LoaderState<ConsignmentTracking>>;
declare const getConsignmentTrackingById: (orderCode: string, consignmentCode: string) => MemoizedSelector<StateWithOrder, ConsignmentTracking>;
declare const getConsignmentTrackingByIdLoading: (orderCode: string, consignmentCode: string) => MemoizedSelector<StateWithOrder, boolean>;
declare const getConsignmentTrackingByIdSuccess: (orderCode: string, consignmentCode: string) => MemoizedSelector<StateWithOrder, boolean>;

declare const getOrderByIdEntities: MemoizedSelector<StateWithOrder, StateUtils.EntityLoaderState<Order>>;
declare const getOrderByIdEntity: (code: string) => MemoizedSelector<StateWithOrder, StateUtils.LoaderState<Order>>;
declare const getOrderById: (code: string) => MemoizedSelector<StateWithOrder, Order>;
declare const getOrderByIdLoading: (code: string) => MemoizedSelector<StateWithOrder, boolean>;
declare const getOrderByIdSuccess: (code: string) => MemoizedSelector<StateWithOrder, boolean>;

declare const orderGroup_selectors_d_getConsignmentTracking: typeof getConsignmentTracking;
declare const orderGroup_selectors_d_getConsignmentTrackingById: typeof getConsignmentTrackingById;
declare const orderGroup_selectors_d_getConsignmentTrackingByIdEntities: typeof getConsignmentTrackingByIdEntities;
declare const orderGroup_selectors_d_getConsignmentTrackingByIdEntity: typeof getConsignmentTrackingByIdEntity;
declare const orderGroup_selectors_d_getConsignmentTrackingByIdLoading: typeof getConsignmentTrackingByIdLoading;
declare const orderGroup_selectors_d_getConsignmentTrackingByIdSuccess: typeof getConsignmentTrackingByIdSuccess;
declare const orderGroup_selectors_d_getConsignmentTrackingState: typeof getConsignmentTrackingState;
declare const orderGroup_selectors_d_getOrderById: typeof getOrderById;
declare const orderGroup_selectors_d_getOrderByIdEntities: typeof getOrderByIdEntities;
declare const orderGroup_selectors_d_getOrderByIdEntity: typeof getOrderByIdEntity;
declare const orderGroup_selectors_d_getOrderByIdLoading: typeof getOrderByIdLoading;
declare const orderGroup_selectors_d_getOrderByIdSuccess: typeof getOrderByIdSuccess;
declare const orderGroup_selectors_d_getOrderDetailState: typeof getOrderDetailState;
declare const orderGroup_selectors_d_getOrderDetails: typeof getOrderDetails;
declare const orderGroup_selectors_d_getOrderDetailsLoading: typeof getOrderDetailsLoading;
declare const orderGroup_selectors_d_getOrderReturnRequest: typeof getOrderReturnRequest;
declare const orderGroup_selectors_d_getOrderReturnRequestList: typeof getOrderReturnRequestList;
declare const orderGroup_selectors_d_getOrderReturnRequestListState: typeof getOrderReturnRequestListState;
declare const orderGroup_selectors_d_getOrderReturnRequestLoading: typeof getOrderReturnRequestLoading;
declare const orderGroup_selectors_d_getOrderReturnRequestState: typeof getOrderReturnRequestState;
declare const orderGroup_selectors_d_getOrderReturnRequestSuccess: typeof getOrderReturnRequestSuccess;
declare const orderGroup_selectors_d_getOrderState: typeof getOrderState;
declare const orderGroup_selectors_d_getOrders: typeof getOrders;
declare const orderGroup_selectors_d_getOrdersLoaded: typeof getOrdersLoaded;
declare const orderGroup_selectors_d_getOrdersState: typeof getOrdersState;
declare const orderGroup_selectors_d_getReplenishmentOrderDetailsError: typeof getReplenishmentOrderDetailsError;
declare const orderGroup_selectors_d_getReplenishmentOrderDetailsLoading: typeof getReplenishmentOrderDetailsLoading;
declare const orderGroup_selectors_d_getReplenishmentOrderDetailsSuccess: typeof getReplenishmentOrderDetailsSuccess;
declare const orderGroup_selectors_d_getReplenishmentOrderDetailsValue: typeof getReplenishmentOrderDetailsValue;
declare const orderGroup_selectors_d_getReplenishmentOrderState: typeof getReplenishmentOrderState;
declare const orderGroup_selectors_d_getReplenishmentOrders: typeof getReplenishmentOrders;
declare const orderGroup_selectors_d_getReplenishmentOrdersError: typeof getReplenishmentOrdersError;
declare const orderGroup_selectors_d_getReplenishmentOrdersLoading: typeof getReplenishmentOrdersLoading;
declare const orderGroup_selectors_d_getReplenishmentOrdersState: typeof getReplenishmentOrdersState;
declare const orderGroup_selectors_d_getReplenishmentOrdersSuccess: typeof getReplenishmentOrdersSuccess;
declare namespace orderGroup_selectors_d {
  export {
    orderGroup_selectors_d_getConsignmentTracking as getConsignmentTracking,
    orderGroup_selectors_d_getConsignmentTrackingById as getConsignmentTrackingById,
    orderGroup_selectors_d_getConsignmentTrackingByIdEntities as getConsignmentTrackingByIdEntities,
    orderGroup_selectors_d_getConsignmentTrackingByIdEntity as getConsignmentTrackingByIdEntity,
    orderGroup_selectors_d_getConsignmentTrackingByIdLoading as getConsignmentTrackingByIdLoading,
    orderGroup_selectors_d_getConsignmentTrackingByIdSuccess as getConsignmentTrackingByIdSuccess,
    orderGroup_selectors_d_getConsignmentTrackingState as getConsignmentTrackingState,
    orderGroup_selectors_d_getOrderById as getOrderById,
    orderGroup_selectors_d_getOrderByIdEntities as getOrderByIdEntities,
    orderGroup_selectors_d_getOrderByIdEntity as getOrderByIdEntity,
    orderGroup_selectors_d_getOrderByIdLoading as getOrderByIdLoading,
    orderGroup_selectors_d_getOrderByIdSuccess as getOrderByIdSuccess,
    orderGroup_selectors_d_getOrderDetailState as getOrderDetailState,
    orderGroup_selectors_d_getOrderDetails as getOrderDetails,
    orderGroup_selectors_d_getOrderDetailsLoading as getOrderDetailsLoading,
    orderGroup_selectors_d_getOrderReturnRequest as getOrderReturnRequest,
    orderGroup_selectors_d_getOrderReturnRequestList as getOrderReturnRequestList,
    orderGroup_selectors_d_getOrderReturnRequestListState as getOrderReturnRequestListState,
    orderGroup_selectors_d_getOrderReturnRequestLoading as getOrderReturnRequestLoading,
    orderGroup_selectors_d_getOrderReturnRequestState as getOrderReturnRequestState,
    orderGroup_selectors_d_getOrderReturnRequestSuccess as getOrderReturnRequestSuccess,
    orderGroup_selectors_d_getOrderState as getOrderState,
    orderGroup_selectors_d_getOrders as getOrders,
    orderGroup_selectors_d_getOrdersLoaded as getOrdersLoaded,
    orderGroup_selectors_d_getOrdersState as getOrdersState,
    orderGroup_selectors_d_getReplenishmentOrderDetailsError as getReplenishmentOrderDetailsError,
    orderGroup_selectors_d_getReplenishmentOrderDetailsLoading as getReplenishmentOrderDetailsLoading,
    orderGroup_selectors_d_getReplenishmentOrderDetailsSuccess as getReplenishmentOrderDetailsSuccess,
    orderGroup_selectors_d_getReplenishmentOrderDetailsValue as getReplenishmentOrderDetailsValue,
    orderGroup_selectors_d_getReplenishmentOrderState as getReplenishmentOrderState,
    orderGroup_selectors_d_getReplenishmentOrders as getReplenishmentOrders,
    orderGroup_selectors_d_getReplenishmentOrdersError as getReplenishmentOrdersError,
    orderGroup_selectors_d_getReplenishmentOrdersLoading as getReplenishmentOrdersLoading,
    orderGroup_selectors_d_getReplenishmentOrdersState as getReplenishmentOrdersState,
    orderGroup_selectors_d_getReplenishmentOrdersSuccess as getReplenishmentOrdersSuccess,
  };
}

export { CANCEL_ORDER_PROCESS_ID, CANCEL_REPLENISHMENT_ORDER_PROCESS_ID, CANCEL_RETURN_PROCESS_ID, CONSIGNMENT_TRACKING_BY_ID_ENTITIES, MyAccountV2OrderHistoryService, ORDERS, ORDER_BY_ID_ENTITIES, ORDER_DETAILS, ORDER_FEATURE, orderGroup_actions_d as OrderActions, OrderAdapter, OrderAttachmentsAdapter, OrderAttachmentsConnector, OrderAttachmentsService, OrderConnector, OrderCoreModule, OrderHistoryAdapter, OrderHistoryConnector, OrderHistoryService, OrderReturnRequestService, orderGroup_selectors_d as OrderSelectors, OrderService, REPLENISHMENT_ORDERS, REPLENISHMENT_ORDER_DETAILS, RETURN_REQUESTS, RETURN_REQUEST_DETAILS, ReorderOrderAdapter, ReorderOrderConnector, ReorderOrderService, ReplenishmentOrderHistoryAdapter, ReplenishmentOrderHistoryConnector, ReplenishmentOrderHistoryService, ScheduledReplenishmentOrderAdapter, ScheduledReplenishmentOrderConnector, ScheduledReplenishmentOrderService, getConsignmentTrackingByIdEntityKey };
export type { ConsignmentTrackingState, OrderState, StateWithOrder };
