import * as i0 from '@angular/core';
import { Injectable, inject, NgModule, isDevMode } from '@angular/core';
import { Config, WindowRef, OccEndpointsService, provideLocationInitializerFactory, SemanticPathService, AuthRedirectService, AuthService, LoggerService, provideDefaultConfig } from '@spartacus/core';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { BEFORE_CMS_PAGE_GUARD } from '@spartacus/storefront';
import { Router } from '@angular/router';
import { take, switchMap, of } from 'rxjs';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOppsConfig = {
    opps: {
        couponcodes: {
            httpHeaderName: 'couponcodes',
            urlParameter: 'couponcodes',
            localStorageKey: 'opps-couponcodes',
        },
        loginRequired: {
            urlParameter: 'loginRequired',
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OppsConfig {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsConfig, providedIn: 'root', useExisting: Config }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useExisting: Config,
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OppsCouponCodesService {
    constructor() {
        this.winRef = inject(WindowRef);
        this.config = inject(OppsConfig);
        this.localStorageKey = this.config.opps?.couponcodes?.localStorageKey ?? '';
    }
    saveUrlCouponCodes() {
        const urlParam = this.config.opps?.couponcodes?.urlParameter ?? '';
        const url = this.winRef.location.href ?? '';
        const queryParams = new URLSearchParams(url.substring(url.indexOf('?')));
        const oppsCoupon = queryParams.get(urlParam);
        if (oppsCoupon) {
            this.setCouponCodes(oppsCoupon);
        }
    }
    setCouponCodes(couponCodes) {
        if (this.localStorageKey && couponCodes) {
            this.winRef.localStorage?.setItem(this.localStorageKey, couponCodes);
        }
    }
    getCouponCodes() {
        if (this.localStorageKey) {
            return this.winRef.localStorage?.getItem(this.localStorageKey);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsCouponCodesService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsCouponCodesService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsCouponCodesService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class OccOppsCouponCodesInterceptor {
    constructor() {
        this.config = inject(OppsConfig);
        this.occEndpoints = inject(OccEndpointsService);
        this.winRef = inject(WindowRef);
        this.service = inject(OppsCouponCodesService);
        this.initialize();
    }
    initialize() {
        this.oppsCoupon = this.service.getCouponCodes();
        if (this.winRef.isBrowser()) {
            this.requestHeader =
                this.config.opps?.couponcodes?.httpHeaderName?.toLowerCase?.();
        }
    }
    /**
     * Adds a new request header 'opps' to the given HTTP request.
     * @param request The outgoing request object to handle.
     * @param next The next interceptor in the chain, or the backend
     * if no interceptors remain in the chain.
     * @returns An observable of the event stream.
     */
    intercept(request, next) {
        if (this.winRef.isBrowser() &&
            this.requestHeader &&
            this.oppsCoupon &&
            request.url.includes(this.occEndpoints.getBaseUrl())) {
            request = request.clone({
                setHeaders: {
                    [this.requestHeader]: this.oppsCoupon,
                },
            });
        }
        return next.handle(request);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccOppsCouponCodesInterceptor, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccOppsCouponCodesInterceptor, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccOppsCouponCodesInterceptor, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const oppsCouponCodesInterceptors = [
    {
        provide: HTTP_INTERCEPTORS,
        useExisting: OccOppsCouponCodesInterceptor,
        multi: true,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
function saveCouponCodesFactory() {
    const service = inject(OppsCouponCodesService);
    return () => {
        service.saveUrlCouponCodes();
    };
}
class OppsCouponCodesModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsCouponCodesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OppsCouponCodesModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsCouponCodesModule, providers: [
            ...oppsCouponCodesInterceptors,
            provideLocationInitializerFactory(() => {
                // convert incorrect type `() => void` to `() => Promise<void>`
                const locationInitializer = saveCouponCodesFactory();
                return () => Promise.resolve(locationInitializer());
            }),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsCouponCodesModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        ...oppsCouponCodesInterceptors,
                        provideLocationInitializerFactory(() => {
                            // convert incorrect type `() => void` to `() => Promise<void>`
                            const locationInitializer = saveCouponCodesFactory();
                            return () => Promise.resolve(locationInitializer());
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OppsLoginRequiredGuard {
    constructor() {
        this.router = inject(Router);
        this.semanticPathService = inject(SemanticPathService);
        this.authRedirectService = inject(AuthRedirectService);
        this.authService = inject(AuthService);
        this.logger = inject(LoggerService);
        this.config = inject(OppsConfig);
    }
    canActivate(route, _state) {
        const navigation = this.router.currentNavigation();
        return this.authService.isUserLoggedIn().pipe(take(1), switchMap((isUserLoggedIn) => {
            if (!isUserLoggedIn) {
                if (!this.config.opps?.loginRequired?.urlParameter && isDevMode()) {
                    this.logger.warn(`There is no url query parameter configured for OPPS login-required feature`);
                }
                const urlParameter = this.config.opps?.loginRequired?.urlParameter ?? '';
                if (route.queryParams[urlParameter] === 'true' &&
                    navigation?.finalUrl) {
                    const url = this.router.serializeUrl(navigation.finalUrl);
                    this.authRedirectService.setRedirectUrl(url);
                    return of(this.router.parseUrl(this.semanticPathService.get('login') ?? ''));
                }
                return of(true);
            }
            else {
                return of(true);
            }
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsLoginRequiredGuard, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsLoginRequiredGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsLoginRequiredGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OppsLoginRequiredModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsLoginRequiredModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OppsLoginRequiredModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsLoginRequiredModule, providers: [
            {
                provide: BEFORE_CMS_PAGE_GUARD,
                useClass: OppsLoginRequiredGuard,
                multi: true,
            },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsLoginRequiredModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        {
                            provide: BEFORE_CMS_PAGE_GUARD,
                            useClass: OppsLoginRequiredGuard,
                            multi: true,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OppsRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OppsRootModule, imports: [OppsCouponCodesModule, OppsLoginRequiredModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsRootModule, providers: [provideDefaultConfig(defaultOppsConfig)], imports: [OppsCouponCodesModule, OppsLoginRequiredModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OppsRootModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OppsCouponCodesModule, OppsLoginRequiredModule],
                    providers: [provideDefaultConfig(defaultOppsConfig)],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OccOppsCouponCodesInterceptor, OppsConfig, OppsCouponCodesModule, OppsLoginRequiredGuard, OppsLoginRequiredModule, OppsRootModule, defaultOppsConfig, oppsCouponCodesInterceptors, saveCouponCodesFactory };
//# sourceMappingURL=spartacus-opps-root.mjs.map
