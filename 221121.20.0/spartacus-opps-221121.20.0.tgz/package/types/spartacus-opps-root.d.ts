import * as i0 from '@angular/core';
import { Provider } from '@angular/core';
import { Router, RouterStateSnapshot, GuardResult } from '@angular/router';
import { WindowRef, OccEndpointsService, SemanticPathService, AuthRedirectService, AuthService, LoggerService, CmsActivatedRouteSnapshot } from '@spartacus/core';
import { Observable } from 'rxjs';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';

declare abstract class OppsConfig {
    opps?: {
        couponcodes?: {
            httpHeaderName?: string;
            urlParameter?: string;
            localStorageKey?: string;
        };
        loginRequired?: {
            urlParameter?: string;
        };
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<OppsConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OppsConfig>;
}
declare module '@spartacus/core' {
    interface Config extends OppsConfig {
    }
}

declare const defaultOppsConfig: OppsConfig;

declare function saveCouponCodesFactory(): () => void;
declare class OppsCouponCodesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OppsCouponCodesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OppsCouponCodesModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OppsCouponCodesModule>;
}

declare class OppsLoginRequiredModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OppsLoginRequiredModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OppsLoginRequiredModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OppsLoginRequiredModule>;
}

declare class OppsRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OppsRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OppsRootModule, never, [typeof OppsCouponCodesModule, typeof OppsLoginRequiredModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OppsRootModule>;
}

declare class OppsCouponCodesService {
    protected winRef: WindowRef;
    protected config: OppsConfig;
    protected localStorageKey: string;
    saveUrlCouponCodes(): void;
    setCouponCodes(couponCodes: string): void;
    getCouponCodes(): string | undefined | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<OppsCouponCodesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OppsCouponCodesService>;
}

declare class OccOppsCouponCodesInterceptor implements HttpInterceptor {
    private oppsCoupon?;
    private requestHeader?;
    protected config: OppsConfig;
    protected occEndpoints: OccEndpointsService;
    protected winRef: WindowRef;
    protected service: OppsCouponCodesService;
    constructor();
    protected initialize(): void;
    /**
     * Adds a new request header 'opps' to the given HTTP request.
     * @param request The outgoing request object to handle.
     * @param next The next interceptor in the chain, or the backend
     * if no interceptors remain in the chain.
     * @returns An observable of the event stream.
     */
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOppsCouponCodesInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOppsCouponCodesInterceptor>;
}

declare const oppsCouponCodesInterceptors: Provider[];

declare class OppsLoginRequiredGuard {
    protected router: Router;
    protected semanticPathService: SemanticPathService;
    protected authRedirectService: AuthRedirectService;
    protected authService: AuthService;
    protected logger: LoggerService;
    protected config: OppsConfig;
    canActivate(route: CmsActivatedRouteSnapshot, _state: RouterStateSnapshot): Observable<GuardResult>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OppsLoginRequiredGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OppsLoginRequiredGuard>;
}

export { OccOppsCouponCodesInterceptor, OppsConfig, OppsCouponCodesModule, OppsLoginRequiredGuard, OppsLoginRequiredModule, OppsRootModule, defaultOppsConfig, oppsCouponCodesInterceptors, saveCouponCodesFactory };
