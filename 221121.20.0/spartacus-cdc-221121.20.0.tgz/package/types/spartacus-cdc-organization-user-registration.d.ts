import * as i2 from '@angular/forms';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CdcJsService } from '@spartacus/cdc/root';
import * as i4 from '@spartacus/core';
import { CommandService, AuthService, EventService, UserAddressService, TranslationService, GlobalMessageService, AuthConfigService, RoutingService, Command } from '@spartacus/core';
import { UserRegistrationFormService } from '@spartacus/organization/user-registration/components';
import { UserRegistrationFacade, OrganizationUserRegistrationForm } from '@spartacus/organization/user-registration/root';
import { UserRegisterFacade } from '@spartacus/user/profile/root';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';
import * as i3 from '@angular/router';
import * as i5 from '@spartacus/storefront';
import * as i6 from '@ng-select/ng-select';

declare class CDCB2BRegisterComponentService extends UserRegistrationFormService {
    protected command: CommandService;
    protected cdcJSService: CdcJsService;
    protected authService: AuthService;
    protected eventService: EventService;
    protected userRegisterFacade: UserRegisterFacade;
    protected userAddressService: UserAddressService;
    protected organizationUserRegistrationFacade: UserRegistrationFacade;
    protected translationService: TranslationService;
    protected globalMessageService: GlobalMessageService;
    protected authConfigService: AuthConfigService;
    protected routingService: RoutingService;
    protected formBuilder: FormBuilder;
    protected registerCommand: Command<{
        orgInfo: OrganizationUserRegistrationForm;
    }, OrganizationUserRegistrationForm>;
    protected loadUserTokenFailed$: Observable<boolean>;
    constructor(command: CommandService, cdcJSService: CdcJsService, authService: AuthService, eventService: EventService, userRegisterFacade: UserRegisterFacade, userAddressService: UserAddressService, organizationUserRegistrationFacade: UserRegistrationFacade, translationService: TranslationService, globalMessageService: GlobalMessageService, authConfigService: AuthConfigService, routingService: RoutingService, formBuilder: FormBuilder);
    /**
     * Register a new user using CDC SDK.
     *
     * @param form as FormGroup
     */
    registerUser(form: FormGroup): Observable<OrganizationUserRegistrationForm>;
    postRegisterMessage(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CDCB2BRegisterComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CDCB2BRegisterComponentService>;
}

declare class CDCB2BRegisterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CDCB2BRegisterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CDCB2BRegisterModule, never, [typeof i1.CommonModule, typeof i2.ReactiveFormsModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i5.SpinnerModule, typeof i5.FormErrorsModule, typeof i6.NgSelectModule, typeof i5.NgSelectA11yModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CDCB2BRegisterModule>;
}

export { CDCB2BRegisterComponentService, CDCB2BRegisterModule };
