import { B2BUserService, OrgUnitService } from '@spartacus/organization/administration/core';
import * as i0 from '@angular/core';
import { OnDestroy } from '@angular/core';
import { CdcJsService } from '@spartacus/cdc/root';
import { GlobalMessageService, WindowRef, Translatable } from '@spartacus/core';
import { UserListService, CreateButtonType } from '@spartacus/organization/administration/components';
import { TableService } from '@spartacus/storefront';
import { Subscription } from 'rxjs';

declare class CdcB2BUserService extends B2BUserService {
    isUpdatingUserAllowed(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcB2BUserService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcB2BUserService>;
}

declare class CdcUserListService extends UserListService implements OnDestroy {
    protected tableService: TableService;
    protected userService: B2BUserService;
    protected globalMessageService: GlobalMessageService;
    protected winRef: WindowRef;
    protected cdcJsService: CdcJsService;
    constructor(tableService: TableService, userService: B2BUserService, globalMessageService: GlobalMessageService, winRef: WindowRef, cdcJsService: CdcJsService);
    protected subscription: Subscription;
    onCreateButtonClick(): void;
    getCreateButtonType(): CreateButtonType;
    getCreateButtonLabel(): Translatable;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcUserListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcUserListService>;
}

declare class CdcOrgUnitService extends OrgUnitService {
    isUpdatingUnitAllowed(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcOrgUnitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcOrgUnitService>;
}

declare class CdcAdministrationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcAdministrationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CdcAdministrationModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CdcAdministrationModule>;
}

export { CdcAdministrationModule, CdcB2BUserService, CdcOrgUnitService, CdcUserListService };
