import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    cdc: {
        reconsent: {
            dialog: {
                title: string;
                description: string;
            };
        };
        cdcProfile: {
            profileUpdateSuccess: string;
            profileUpdateFailure: string;
        };
    };
};

declare const de: {
    cdc: {
        reconsent: {
            dialog: {
                title: string;
                description: string;
            };
        };
        cdcProfile: {
            profileUpdateSuccess: string;
            profileUpdateFailure: string;
        };
    };
};

declare const en: {
    cdc: {
        reconsent: {
            dialog: {
                title: string;
                description: string;
            };
        };
        cdcProfile: {
            profileUpdateSuccess: string;
            profileUpdateFailure: string;
        };
    };
};

declare const es: {
    cdc: {
        reconsent: {
            dialog: {
                title: string;
                description: string;
            };
        };
        cdcProfile: {
            profileUpdateSuccess: string;
            profileUpdateFailure: string;
        };
    };
};

declare const es_CO: {
    cdc: {
        reconsent: {
            dialog: {
                title: string;
                description: string;
            };
        };
        cdcProfile: {
            profileUpdateSuccess: string;
            profileUpdateFailure: string;
        };
    };
};

declare const fr: {
    cdc: {
        reconsent: {
            dialog: {
                title: string;
                description: string;
            };
        };
        cdcProfile: {
            profileUpdateSuccess: string;
            profileUpdateFailure: string;
        };
    };
};

declare const hi: {
    cdc: {
        reconsent: {
            dialog: {
                title: string;
                description: string;
            };
        };
        cdcProfile: {
            profileUpdateSuccess: string;
            profileUpdateFailure: string;
        };
    };
};

declare const hu: {
    cdc: {
        reconsent: {
            dialog: {
                title: string;
                description: string;
            };
        };
        cdcProfile: {
            profileUpdateSuccess: string;
            profileUpdateFailure: string;
        };
    };
};

declare const id: {
    cdc: {
        reconsent: {
            dialog: {
                title: string;
                description: string;
            };
        };
        cdcProfile: {
            profileUpdateSuccess: string;
            profileUpdateFailure: string;
        };
    };
};

declare const it: {
    cdc: {
        reconsent: {
            dialog: {
                title: string;
                description: string;
            };
        };
        cdcProfile: {
            profileUpdateSuccess: string;
            profileUpdateFailure: string;
        };
    };
};

declare const ja: {
    cdc: {
        reconsent: {
            dialog: {
                title: string;
                description: string;
            };
        };
        cdcProfile: {
            profileUpdateSuccess: string;
            profileUpdateFailure: string;
        };
    };
};

declare const ko: {
    cdc: {
        reconsent: {
            dialog: {
                title: string;
                description: string;
            };
        };
        cdcProfile: {
            profileUpdateSuccess: string;
            profileUpdateFailure: string;
        };
    };
};

declare const pl: {
    cdc: {
        reconsent: {
            dialog: {
                title: string;
                description: string;
            };
        };
        cdcProfile: {
            profileUpdateSuccess: string;
            profileUpdateFailure: string;
        };
    };
};

declare const pt: {
    cdc: {
        reconsent: {
            dialog: {
                title: string;
                description: string;
            };
        };
        cdcProfile: {
            profileUpdateSuccess: string;
            profileUpdateFailure: string;
        };
    };
};

declare const ru: {
    cdc: {
        reconsent: {
            dialog: {
                title: string;
                description: string;
            };
        };
        cdcProfile: {
            profileUpdateSuccess: string;
            profileUpdateFailure: string;
        };
    };
};

declare const zh: {
    cdc: {
        reconsent: {
            dialog: {
                title: string;
                description: string;
            };
        };
        cdcProfile: {
            profileUpdateSuccess: string;
            profileUpdateFailure: string;
        };
    };
};

declare const zh_TW: {
    cdc: {
        reconsent: {
            dialog: {
                title: string;
                description: string;
            };
        };
        cdcProfile: {
            profileUpdateSuccess: string;
            profileUpdateFailure: string;
        };
    };
};

declare const cdcTranslationChunksConfig: TranslationChunksConfig;

export { cdcTranslationChunksConfig, cs as cdcTranslationsCs, de as cdcTranslationsDe, en as cdcTranslationsEn, es as cdcTranslationsEs, es_CO as cdcTranslationsEs_CO, fr as cdcTranslationsFr, hi as cdcTranslationsHi, hu as cdcTranslationsHu, id as cdcTranslationsId, it as cdcTranslationsIt, ja as cdcTranslationsJa, ko as cdcTranslationsKo, pl as cdcTranslationsPl, pt as cdcTranslationsPt, ru as cdcTranslationsRu, zh as cdcTranslationsZh, zh_TW as cdcTranslationsZh_TW };
