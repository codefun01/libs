import * as i2 from '@spartacus/core';
import { StatePersistenceService, LanguageService, ConverterService, OccUserConsentAdapter, OccEndpointsService, ConsentTemplate, Converter, AuthToken, BaseSiteService, ScriptLoader, WindowRef, AuthService, GlobalMessageService, EventService, User, ConfigInitializerService, Config, CmsConfig, CxEvent, CmsService, SemanticPathService, ProtectedRoutesService, AuthConfigService } from '@spartacus/core';
import * as i0 from '@angular/core';
import { OnDestroy, InjectionToken, NgZone } from '@angular/core';
import { OrganizationUserRegistrationForm } from '@spartacus/organization/user-registration/root';
import { UserProfileFacade, UserSignUp } from '@spartacus/user/profile/root';
import { Subscription, Observable, ReplaySubject } from 'rxjs';
import * as i1 from '@angular/common';
import { Router } from '@angular/router';
import { ConsentManagementComponentService, LogoutGuard, LoginGuard, CmsPageGuard } from '@spartacus/storefront';
import { LoginAsGuestGuard } from '@spartacus/user/account/components';
import { HttpClient } from '@angular/common/http';

declare abstract class CdcConfig {
    cdc?: {
        baseSite: string;
        javascriptUrl: string;
        sessionExpiration: number;
    }[];
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcConfig>;
}
declare module '@spartacus/core' {
    interface Config extends CdcConfig {
    }
}

declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        CDC_RECONSENT = "CDC_RECONSENT"
    }
}
declare module '@spartacus/user/profile/root' {
    interface UserSignUp {
        firstName?: string;
        lastName?: string;
        password?: string;
        titleCode?: string;
        uid?: string;
        preferences?: any;
    }
}
interface CdcSiteConsentTemplate {
    siteConsentDetails: {
        [key: string]: {
            isMandatory: boolean;
            isActive: boolean;
        };
    };
}
interface CdcConsent {
    id?: string;
    isConsentGranted?: boolean;
}
interface CdcLocalStorageTemplate {
    id: string;
    required: boolean;
}

declare class CdcConsentsLocalStorageService implements OnDestroy {
    protected statePersistenceService: StatePersistenceService;
    constructor(statePersistenceService: StatePersistenceService);
    protected subscription: Subscription;
    /**
     * saves active cdc consents to storage
     * @param siteConsent - cdc site consent details
     */
    persistCdcConsentsToStorage(siteConsent: CdcSiteConsentTemplate): void;
    /**
     * Returns cdc consents from storage
     * @returns cdc consents
     */
    readCdcConsentsFromStorage(): CdcLocalStorageTemplate[];
    /**
     * Returns true if input consent is present in storage, else returns false
     * @param consentId - cdc consent id
     * @returns - returns true/false
     */
    checkIfConsentExists(consentId: string): boolean;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcConsentsLocalStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcConsentsLocalStorageService>;
}

declare class CdcUserConsentService {
    protected languageService: LanguageService;
    protected userProfileFacade: UserProfileFacade;
    protected cdcJsService: CdcJsService;
    protected converter: ConverterService;
    protected cdcConsentsStorage: CdcConsentsLocalStorageService;
    constructor(languageService: LanguageService, userProfileFacade: UserProfileFacade, cdcJsService: CdcJsService, converter: ConverterService, cdcConsentsStorage: CdcConsentsLocalStorageService);
    /**
     *
     * @param consentCodes an array of consent ID with status
     * @param user If user is not passed, the logged in user id will be fetched and used. If passed, it will be considered.
     * @param regToken token
     * @returns returns Observable with error code and status
     */
    updateCdcUserPreferences(consentCodes: CdcConsent[], user?: string, regToken?: string): Observable<{
        errorCode: number;
        errorMessage: string;
    }>;
    /**
     * Returns logged in User ID
     * @returns user id
     */
    getUserID(): string | undefined;
    /**
     * Returns current language of the current site
     * @returns language iso code
     */
    getActiveLanguage(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcUserConsentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcUserConsentService>;
}

declare class CdcUserConsentAdapter extends OccUserConsentAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected cdcUserConsentService: CdcUserConsentService;
    protected cdcConsentsStorage: CdcConsentsLocalStorageService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService, cdcUserConsentService: CdcUserConsentService, cdcConsentsStorage: CdcConsentsLocalStorageService);
    loadConsents(userId: string): Observable<ConsentTemplate[]>;
    giveConsent(userId: string, consentTemplateId: string, consentTemplateVersion: number): Observable<ConsentTemplate>;
    withdrawConsent(userId: string, consentCode: string, consentId?: string): Observable<{}>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcUserConsentAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcUserConsentAdapter>;
}

declare class CdcConsentManagementModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcConsentManagementModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CdcConsentManagementModule, never, [typeof i1.CommonModule, typeof i2.I18nModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CdcConsentManagementModule>;
}

declare class CdcConsentManagementComponentService extends ConsentManagementComponentService {
    protected store: CdcConsentsLocalStorageService;
    constructor(store: CdcConsentsLocalStorageService);
    getRequiredConsents(templateList: ConsentTemplate[]): string[];
    /**
     * Returns cdc consents from store
     * @param mandatoryConsents - if passed true, only mandatory consents will be returned.
     * if passed false, all active consents (irrespective of whether they are mandatory or not)
     * @returns array of consents
     */
    getCdcConsentIDs(mandatoryConsents?: boolean): string[];
    isConsentMandatory(id: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcConsentManagementComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcConsentManagementComponentService>;
}

declare class CdcPreferenceSerializer implements Converter<CdcConsent[], any> {
    /**
     * Generate CDC preferences from consent objects
     * @param cdcConsents List of consents with their statuses
     * @returns Serialized and deeply nested preferences object
     */
    convert(source: CdcConsent[], _target?: any): any;
    /**
     * Converts a dot-separated string to a deeply nested object.
     * @param path Dot-separated string representing keys
     * @param value Value to set
     * @returns Nested object
     */
    private convertToCdcPreference;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcPreferenceSerializer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcPreferenceSerializer>;
}

declare const CDC_PREFERENCE_SERIALIZER: InjectionToken<Converter<CdcConsent[], any>>;

declare abstract class CdcAuthFacade {
    abstract loginWithCustomCdcFlow(UID: string, UIDSignature: string, signatureTimestamp: string, idToken: string, baseSite: string): void;
    abstract loginWithToken(token: Partial<AuthToken> & {
        expires_in?: number;
    }): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcAuthFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcAuthFacade>;
}

declare class CdcJsService implements OnDestroy {
    protected cdcConfig: CdcConfig;
    protected baseSiteService: BaseSiteService;
    protected languageService: LanguageService;
    protected scriptLoader: ScriptLoader;
    protected winRef: WindowRef;
    protected cdcAuth: CdcAuthFacade;
    protected auth: AuthService;
    protected zone: NgZone;
    protected userProfileFacade: UserProfileFacade;
    protected platform: any;
    protected globalMessageService: GlobalMessageService;
    protected eventService: EventService;
    protected consentStore: CdcConsentsLocalStorageService;
    protected loaded$: ReplaySubject<boolean>;
    protected errorLoading$: ReplaySubject<boolean>;
    protected subscription: Subscription;
    protected gigyaSDK: {
        [key: string]: any;
    };
    constructor(cdcConfig: CdcConfig, baseSiteService: BaseSiteService, languageService: LanguageService, scriptLoader: ScriptLoader, winRef: WindowRef, cdcAuth: CdcAuthFacade, auth: AuthService, zone: NgZone, userProfileFacade: UserProfileFacade, platform: any, globalMessageService: GlobalMessageService, eventService: EventService, consentStore: CdcConsentsLocalStorageService);
    /**
     * Initialize CDC script
     */
    initialize(): void;
    /**
     * Returns observable with the information if CDC script is loaded.
     */
    didLoad(): Observable<boolean>;
    /**
     * Returns observable with the information if CDC script failed to load.
     */
    didScriptFailToLoad(): Observable<boolean>;
    /**
     * Method which loads the CDC Script
     */
    loadCdcJavascript(): void;
    /**
     * Method obtains the CDC SDK URL for a base site
     * @param baseSite
     * @returns CDC SDK URL
     */
    private getJavascriptUrlForCurrentSite;
    /**
     * Register login event listeners for CDC login
     *
     * @param baseSite
     */
    protected registerEventListeners(baseSite: string): void;
    /**
     * Method to register CDC event handlers
     *
     * @param baseSite
     */
    protected addCdcEventHandlers(baseSite: string): void;
    /**
     * Trigger login to Commerce once an onLogin event is triggered by CDC Screen Set.
     *
     * @param baseSite
     * @param response
     */
    protected onLoginEventHandler(baseSite: string, response?: any): void;
    /**
     * Trigger CDC User registration and log in using CDC APIs.
     *
     * @param user: UserSignUp
     */
    registerUserWithoutScreenSet(user: UserSignUp): Observable<{
        status: string;
    }>;
    /**
     * Trigger CDC User registration using CDC APIs.
     *
     * @param user
     * @param response
     */
    protected onInitRegistrationHandler(user: UserSignUp, response: any): Observable<{
        status: string;
    }>;
    /**
     * Trigger CDC User log in using CDC APIs.
     *
     * @param email
     * @param password
     * @param context (optional) - indicates the user flow
     */
    loginUserWithoutScreenSet(email: string, password: string, context?: any): Observable<{
        status: string;
    }>;
    /**
     * Trigger CDC Organisation registration using CDC APIs.
     *
     * @param orgInfo
     */
    registerOrganisationWithoutScreenSet(orgInfo: OrganizationUserRegistrationForm): Observable<{
        status: string;
    }>;
    /**
     * Retrieves the organization selected by the logged in user
     *
     */
    getOrganizationContext(): Observable<{
        orgId: string;
    }>;
    /**
     * Opens the Organization Management dashboard and logs in the user
     * if they currently have a valid Gigya session on the site
     *
     * @param orgId
     */
    openDelegatedAdminLogin(orgId: string): any;
    /**
     * Show failure message to the user in case registration fails.
     *
     * @param response
     */
    protected handleRegisterError(response: any): void;
    /**
     * Show failure message to the user in case login fails.
     *
     * @param response
     */
    protected handleLoginError(response: any): void;
    protected getSessionExpirationValue(): Observable<number>;
    private parseMessage;
    private getCurrentBaseSite;
    private getCurrentBaseSiteChannel;
    /**
     * Trigger CDC forgot password using CDC APIs.
     *
     * @param email
     */
    resetPasswordWithoutScreenSet(email: string): Observable<{
        status: string;
    }>;
    /**
     * Response handler for forgot password
     * @param response
     */
    protected handleResetPassResponse(response: any): void;
    /**
     * Trigger CDC Profile update.
     *
     * @param firstName
     * @param lastName
     */
    updateProfileWithoutScreenSet(user: User): Observable<{
        status: string;
    }>;
    /**
     * Trigger CDC User Password update.
     *
     * @param oldPassword
     * @param newPassword
     */
    updateUserPasswordWithoutScreenSet(oldPassword: string, newPassword: string): Observable<{
        status: string;
    }>;
    /**
     * Updates user details using the existing User API
     *
     * @param response
     */
    onProfileUpdateEventHandler(response?: any, isPasswordReset?: boolean): void;
    /**
     * handle toast message on profile update
     * @param response
     *
     */
    protected handleProfileUpdateResponse(response?: any): void;
    /**
     * Trigger CDC user email update.
     *
     * @param password
     * @param newEmail
     */
    updateUserEmailWithoutScreenSet(password: string, newEmail: string): Observable<{
        status: string;
    }>;
    /**
     * Obtain the email of the currently logged in user
     * @returns emailID of the loggedIn user
     */
    protected getLoggedInUserEmail(): Observable<User>;
    /**
     * Trigger CDC address update.
     *
     * @param address
     */
    updateAddressWithoutScreenSet(formattedAddress: string, zipCode?: string, city?: string, country?: string): Observable<{
        status: string;
    }>;
    /**
     * Obtain the CDC SDK Method from the input method name as string
     * @param methodName
     * @returns CDC SDK Function
     */
    protected getSdkFunctionFromName(methodName: string): (payload: Object) => void;
    /**
     * Invoke the CDC SDK Method and convert the callback to an Observable
     * @param methodName - method to be invoked
     * @param payload - Object payload
     * @returns - Observable with the response
     */
    protected invokeAPI(methodName: string, payload: Object): Observable<any>;
    /**
     * Retrieves consent statements for logged in CDC site (based on CDC site API Key)
     * @param persistToLocalStorage - set this to true, if you want to save the fetched CDC consents to a local storage
     * @returns - Observable with site consent details
     */
    getSiteConsentDetails(persistToLocalStorage?: boolean): Observable<CdcSiteConsentTemplate>;
    /**
     * Triggers the update (give/withdraw) of a CDC consent for a user
     * @param uid - user ID of the logged in user
     * @param lang - current storefront language
     * @param preferences - object containing the preference details
     * @param regToken - optional parameter, which is necessary when reconsent is provided during login scenario
     * @returns - returns Observable with error code and status
     */
    setUserConsentPreferences(uid: string, lang: string, preferences: any, regToken?: string): Observable<{
        errorCode: number;
        errorMessage: string;
    }>;
    /**
     * Dispatch an event when reconsent is required during login. This will be listened
     * by reconsent module to show reconsent pop-up
     * @param user - user ID provided in login screen
     * @param password - password provided in login screen
     * @param reconsentIds - missing required cdc consent IDs
     * @param errorMessage - error message indicating that reconsent is required
     * @param regToken - token of the login session
     */
    raiseCdcReconsentEvent(user: string, password: string, reconsentIds: string[], errorMessage: string, regToken: string, preferences?: any): void;
    protected logoutUser(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcJsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcJsService>;
}

declare function cdcJsFactory(cdcJsService: CdcJsService, configInit: ConfigInitializerService): () => Promise<Config>;
declare function defaultCdcComponentsConfig(): CmsConfig;
declare class CdcRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CdcRootModule, never, [typeof CdcConsentManagementModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CdcRootModule>;
}

/**
 * Indicates the failure during the loading of the user token.
 */
declare class CdcLoadUserTokenFailEvent extends CxEvent {
    /**
     * Event's type
     */
    static readonly type = "CdcLoadUserTokenFailEvent";
}
declare class CdcReConsentEvent extends CxEvent {
    /**
     * Event's type
     */
    static readonly type = "CdcReConsentEvent";
    user: string;
    password: string;
    consentIds: string[];
    errorMessage: string;
    regToken: string;
    preferences?: Record<string, CdcConsent>;
}

declare const CDC_FEATURE = "cdc";
declare const CDC_CORE_FEATURE = "cdcCore";

/**
 * @override
 *
 * CDC version of logout guard. In addition to token revocation we invoke logout method from CDC JS lib.
 */
declare class CdcLogoutGuard extends LogoutGuard {
    protected auth: AuthService;
    protected cms: CmsService;
    protected semanticPathService: SemanticPathService;
    protected protectedRoutes: ProtectedRoutesService;
    protected router: Router;
    protected winRef: WindowRef;
    constructor(auth: AuthService, cms: CmsService, semanticPathService: SemanticPathService, protectedRoutes: ProtectedRoutesService, router: Router, winRef: WindowRef);
    /**
     * Logout user from CDC
     */
    protected logoutFromCdc(): void;
    /**
     * @override
     * @returns promise to resolve after complete logout
     */
    protected logout(): Promise<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcLogoutGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcLogoutGuard>;
}

/**
 * @override
 *
 * CDC version of login guard.
 */
declare class CdcLoginGuard extends LoginGuard {
    protected authService: AuthService;
    protected authConfigService: AuthConfigService;
    protected cmsPageGuard: CmsPageGuard;
    constructor(authService: AuthService, authConfigService: AuthConfigService, cmsPageGuard: CmsPageGuard);
    protected shouldRenderCMSPage(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcLoginGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcLoginGuard>;
}

declare class CdcLoginAsGuestGuard extends LoginAsGuestGuard {
    protected getPath(): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcLoginAsGuestGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcLoginAsGuestGuard>;
}

export { CDC_CORE_FEATURE, CDC_FEATURE, CDC_PREFERENCE_SERIALIZER, CdcAuthFacade, CdcConfig, CdcConsentManagementComponentService, CdcConsentManagementModule, CdcConsentsLocalStorageService, CdcJsService, CdcLoadUserTokenFailEvent, CdcLoginAsGuestGuard, CdcLoginGuard, CdcLogoutGuard, CdcPreferenceSerializer, CdcReConsentEvent, CdcRootModule, CdcUserConsentAdapter, CdcUserConsentService, cdcJsFactory, defaultCdcComponentsConfig };
export type { CdcConsent, CdcLocalStorageTemplate, CdcSiteConsentTemplate };
