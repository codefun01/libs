import * as i2 from '@angular/forms';
import { UntypedFormBuilder, UntypedFormArray } from '@angular/forms';
import { Store } from '@ngrx/store';
import { CdcJsService, CdcConsentManagementComponentService } from '@spartacus/cdc/root';
import * as i4 from '@spartacus/core';
import { CommandService, GlobalMessageService, AuthService, EventService, ConverterService, AnonymousConsentsService, Command, ConsentTemplate, RoutingService, AuthConfigService } from '@spartacus/core';
import { User } from '@spartacus/user/account/root';
import { RegisterComponentService, ForgotPasswordComponentService } from '@spartacus/user/profile/components';
import { UserRegisterFacade, UserProfileFacade, UserSignUp, UserPasswordFacade } from '@spartacus/user/profile/root';
import { Observable, Subscription } from 'rxjs';
import * as i0 from '@angular/core';
import { OnDestroy } from '@angular/core';
import * as i1 from '@angular/common';
import * as i5 from '@angular/router';
import * as i3 from '@spartacus/storefront';
import * as i6 from '@ng-select/ng-select';

declare class CDCRegisterComponentService extends RegisterComponentService {
    protected userRegisterFacade: UserRegisterFacade;
    protected command: CommandService;
    protected store: Store;
    protected cdcJSService: CdcJsService;
    protected globalMessageService: GlobalMessageService;
    protected authService: AuthService;
    protected eventService: EventService;
    protected userProfileFacade: UserProfileFacade;
    protected cdcConsentManagementService: CdcConsentManagementComponentService;
    protected converter: ConverterService;
    protected fb: UntypedFormBuilder;
    protected anonymousConsentsService: AnonymousConsentsService;
    protected registerCommand: Command<{
        user: UserSignUp;
    }, User>;
    protected loadUserTokenFailed$: Observable<boolean>;
    protected isLoggedIn$: Observable<boolean>;
    constructor(userRegisterFacade: UserRegisterFacade, command: CommandService, store: Store, cdcJSService: CdcJsService, globalMessageService: GlobalMessageService, authService: AuthService, eventService: EventService, userProfileFacade: UserProfileFacade, cdcConsentManagementService: CdcConsentManagementComponentService, converter: ConverterService, fb: UntypedFormBuilder, anonymousConsentsService: AnonymousConsentsService);
    /**
     * Register a new user using CDC SDK.
     *
     * @param user as UserSignUp
     */
    register(user: UserSignUp): Observable<User>;
    postRegisterMessage(): void;
    /**
     * fetch consents that exist in commerce and is active in cdc
     * @returns array of consent templates
     */
    fetchCdcConsentsForRegistration(): ConsentTemplate[];
    /**
     * generates a form array with form control for each consent
     * @returns a form array
     */
    generateAdditionalConsentsFormControl(): UntypedFormArray;
    /**
     * creates an array of active cdc consents and makes them mandatory to be provided during registration
     * @returns consent templates in the necessary format for the component
     */
    getAdditionalConsents(): {
        template: ConsentTemplate;
        required: boolean;
    }[];
    collectDataFromRegisterForm(formData: any): UserSignUp;
    static ɵfac: i0.ɵɵFactoryDeclaration<CDCRegisterComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CDCRegisterComponentService>;
}

declare class CDCRegisterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CDCRegisterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CDCRegisterModule, never, [typeof i1.CommonModule, typeof i2.ReactiveFormsModule, typeof i5.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i3.SpinnerModule, typeof i3.FormErrorsModule, typeof i6.NgSelectModule, typeof i3.NgSelectA11yModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CDCRegisterModule>;
}

declare class CDCForgotPasswordComponentService extends ForgotPasswordComponentService implements OnDestroy {
    protected userPasswordService: UserPasswordFacade;
    protected routingService: RoutingService;
    protected authConfigService: AuthConfigService;
    protected globalMessage: GlobalMessageService;
    protected cdcJsService: CdcJsService;
    protected subscription: Subscription;
    constructor(userPasswordService: UserPasswordFacade, routingService: RoutingService, authConfigService: AuthConfigService, globalMessage: GlobalMessageService, cdcJsService: CdcJsService);
    /**
     * Sends an email to through CDC SDK to reset the password.
     */
    requestEmail(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CDCForgotPasswordComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CDCForgotPasswordComponentService>;
}

declare class CDCForgotPasswordModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CDCForgotPasswordModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CDCForgotPasswordModule, never, [typeof i1.CommonModule, typeof i2.ReactiveFormsModule, typeof i5.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i3.FormErrorsModule, typeof i3.SpinnerModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CDCForgotPasswordModule>;
}

declare class CDCUpdateProfileModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CDCUpdateProfileModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CDCUpdateProfileModule, never, [typeof i1.CommonModule, typeof i2.FormsModule, typeof i2.ReactiveFormsModule, typeof i3.SpinnerModule, typeof i4.I18nModule, typeof i3.FormErrorsModule, typeof i5.RouterModule, typeof i4.UrlModule, typeof i6.NgSelectModule, typeof i3.NgSelectA11yModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CDCUpdateProfileModule>;
}

declare class CDCUpdatePasswordModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CDCUpdatePasswordModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CDCUpdatePasswordModule, never, [typeof i1.CommonModule, typeof i2.FormsModule, typeof i2.ReactiveFormsModule, typeof i3.SpinnerModule, typeof i4.I18nModule, typeof i3.FormErrorsModule, typeof i4.UrlModule, typeof i5.RouterModule, typeof i3.PasswordVisibilityToggleModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CDCUpdatePasswordModule>;
}

declare class CDCUpdateEmailModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CDCUpdateEmailModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CDCUpdateEmailModule, never, [typeof i1.CommonModule, typeof i2.FormsModule, typeof i2.ReactiveFormsModule, typeof i3.SpinnerModule, typeof i4.UrlModule, typeof i5.RouterModule, typeof i4.I18nModule, typeof i3.FormErrorsModule, typeof i3.PasswordVisibilityToggleModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CDCUpdateEmailModule>;
}

declare class CDCUserProfileModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CDCUserProfileModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CDCUserProfileModule, never, [typeof CDCRegisterModule, typeof CDCForgotPasswordModule, typeof CDCUpdateProfileModule, typeof CDCUpdatePasswordModule, typeof CDCUpdateEmailModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CDCUserProfileModule>;
}

export { CDCForgotPasswordComponentService, CDCForgotPasswordModule, CDCRegisterComponentService, CDCRegisterModule, CDCUserProfileModule };
