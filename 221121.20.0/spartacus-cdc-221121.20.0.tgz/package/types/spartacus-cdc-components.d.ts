import * as i0 from '@angular/core';
import { OnInit, NgZone } from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/core';
import { BaseSiteService, LanguageService, WindowRef, RoutingService, CmsService, AuthGuard, NotAuthGuard } from '@spartacus/core';
import { GigyaRaasComponentData } from '@spartacus/cdc/core';
import { CdcConfig, CdcJsService } from '@spartacus/cdc/root';
import { CmsComponentData } from '@spartacus/storefront';
import { Observable } from 'rxjs';
import { CanActivate, GuardResult } from '@angular/router';

declare class GigyaRaasComponent implements OnInit {
    component: CmsComponentData<GigyaRaasComponentData>;
    private baseSiteService;
    private languageService;
    private cdcConfig;
    private winRef;
    private cdcJSService;
    private zone;
    protected renderScreenSet: boolean;
    language$: Observable<string>;
    jsError$: Observable<boolean>;
    jsLoaded$: Observable<boolean>;
    protected isPasswordReset: boolean;
    constructor(component: CmsComponentData<GigyaRaasComponentData>, baseSiteService: BaseSiteService, languageService: LanguageService, cdcConfig: CdcConfig, winRef: WindowRef, cdcJSService: CdcJsService, zone: NgZone);
    ngOnInit(): void;
    /**
     * Display screen set in embed mode
     *
     * @param data - GigyaRaasComponentData
     * @param lang - language
     */
    displayScreenSet(data: GigyaRaasComponentData, lang: string): void;
    /**
     * Show screen set
     *
     * @param data - GigyaRaasComponentData
     * @param lang - language
     */
    showScreenSet(data: GigyaRaasComponentData, lang: string): void;
    protected isLoginScreenSet(data: GigyaRaasComponentData): boolean;
    protected getSessionExpirationValue(): number;
    private getCurrentBaseSite;
    /**
     * Check if the component should be displayed in embed mode
     *
     * @param data - GigyaRaasComponentData
     */
    displayInEmbedMode(data: GigyaRaasComponentData): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<GigyaRaasComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GigyaRaasComponent, "cx-gigya-raas", never, {}, {}, never, never, true, never>;
}

declare class GigyaRaasModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GigyaRaasModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GigyaRaasModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i2.ConfigModule, typeof GigyaRaasComponent], [typeof GigyaRaasComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GigyaRaasModule>;
}

declare class CdcComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CdcComponentsModule, never, [typeof i1.CommonModule, typeof GigyaRaasModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CdcComponentsModule>;
}

declare class GigyaRaasGuard implements CanActivate {
    protected routingService: RoutingService;
    protected cmsService: CmsService;
    protected authGuard: AuthGuard;
    protected notAuthGuard: NotAuthGuard;
    canActivate(): Observable<GuardResult>;
    private checksToProcess;
    private getComponentsByType;
    private getComponentData;
    static ɵfac: i0.ɵɵFactoryDeclaration<GigyaRaasGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GigyaRaasGuard>;
}

export { CdcComponentsModule, GigyaRaasComponent, GigyaRaasGuard, GigyaRaasModule };
