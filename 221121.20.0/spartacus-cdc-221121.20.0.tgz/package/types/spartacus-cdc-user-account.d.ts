import * as i0 from '@angular/core';
import { OnDestroy, OnInit } from '@angular/core';
import { CdcJsService, CdcReConsentEvent, CdcUserConsentService, CdcConsent, CdcConsentManagementComponentService } from '@spartacus/cdc/root';
import * as i4 from '@spartacus/core';
import { AuthService, GlobalMessageService, WindowRef, EventService, AnonymousConsentsService, ConsentTemplate } from '@spartacus/core';
import { LoginFormComponentService } from '@spartacus/user/account/components';
import { Subscription, Observable } from 'rxjs';
import * as i1 from '@angular/common';
import * as i2$1 from '@angular/forms';
import { UntypedFormGroup } from '@angular/forms';
import * as i3 from '@angular/router';
import * as i2 from '@spartacus/storefront';
import { LaunchDialogService, ICON_TYPE, FocusConfig, LayoutConfig } from '@spartacus/storefront';

declare class CdcLoginFormComponentService extends LoginFormComponentService implements OnDestroy {
    protected auth: AuthService;
    protected globalMessageService: GlobalMessageService;
    protected winRef: WindowRef;
    protected cdcJsService: CdcJsService;
    constructor(auth: AuthService, globalMessageService: GlobalMessageService, winRef: WindowRef, cdcJsService: CdcJsService);
    protected subscription: Subscription;
    login(): void;
    protected initCustomLogin(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcLoginFormComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcLoginFormComponentService>;
}

declare class CdcReconsentDialogEventListener implements OnDestroy {
    protected eventService: EventService;
    protected launchDialogService: LaunchDialogService;
    protected subscription: Subscription;
    constructor(eventService: EventService, launchDialogService: LaunchDialogService);
    protected onReconsent(): void;
    protected openDialog(event: CdcReConsentEvent): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcReconsentDialogEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcReconsentDialogEventListener>;
}

declare class CdcReconsentComponentService implements OnDestroy {
    protected cdcUserConsentService: CdcUserConsentService;
    protected cdcJsService: CdcJsService;
    protected globalMessageService: GlobalMessageService;
    protected launchDialogService: LaunchDialogService;
    constructor(cdcUserConsentService: CdcUserConsentService, cdcJsService: CdcJsService, globalMessageService: GlobalMessageService, launchDialogService: LaunchDialogService);
    protected subscription: Subscription;
    /**
     * saves the preferences given in reconsent pop-up and triggers a re-login
     * @param consents array of consent ID with status
     * @param userParams data from login session
     */
    savePreferencesAndLogin(consents: CdcConsent[], userParams: any): void;
    /**
     * Displays error message after closing reconsent dialog
     */
    handleReconsentUpdateError(reason?: string, errorMessage?: string): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcReconsentComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcReconsentComponentService>;
}

declare class CdcReconsentComponent implements OnInit, OnDestroy {
    protected launchDialogService: LaunchDialogService;
    protected anonymousConsentsService: AnonymousConsentsService;
    protected cdcReconsentService: CdcReconsentComponentService;
    protected subscription: Subscription;
    protected cdcConsentManagementComponentService: CdcConsentManagementComponentService;
    form: UntypedFormGroup;
    iconTypes: typeof ICON_TYPE;
    loaded$: Observable<boolean>;
    templateList$: Observable<ConsentTemplate[]>;
    reconsentEvent: any;
    requiredReconsents: string[];
    selectedConsents: string[];
    disableSubmitButton: boolean;
    focusConfig: FocusConfig;
    constructor(launchDialogService: LaunchDialogService, anonymousConsentsService: AnonymousConsentsService, cdcReconsentService: CdcReconsentComponentService);
    ngOnInit(): void;
    loadConsents(reconsentIds: string[]): void;
    onConsentChange(event: {
        given: boolean;
        template: ConsentTemplate;
    }): void;
    dismissDialog(reason?: any, message?: string): void;
    private buildPreferenceList;
    private areAllMandatoryConsentsGiven;
    private updateSelectedConsents;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcReconsentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CdcReconsentComponent, "cx-anonymous-consent-dialog", never, {}, {}, never, never, true, never>;
}

declare class CdcReconsentModule {
    constructor(_cdcReconsentDialogEventListener: CdcReconsentDialogEventListener);
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcReconsentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CdcReconsentModule, never, [typeof i1.CommonModule, typeof i2.SpinnerModule, typeof i2.IconModule, typeof i4.I18nModule, typeof i2.KeyboardFocusModule, typeof i2.ConsentManagementModule, typeof i2.BtnLikeLinkModule, typeof CdcReconsentComponent], [typeof CdcReconsentComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CdcReconsentModule>;
}

declare class CDCLoginFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CDCLoginFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CDCLoginFormModule, never, [typeof i1.CommonModule, typeof i2$1.FormsModule, typeof i2$1.ReactiveFormsModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i2.FormErrorsModule, typeof i2.SpinnerModule, typeof CdcReconsentModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CDCLoginFormModule>;
}

declare const defaultCdcReconsentLayoutConfig: LayoutConfig;

declare class CDCUserAccountModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CDCUserAccountModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CDCUserAccountModule, never, [typeof CDCLoginFormModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CDCUserAccountModule>;
}

export { CDCLoginFormModule, CDCUserAccountModule, CdcLoginFormComponentService, CdcReconsentComponent, CdcReconsentComponentService, CdcReconsentDialogEventListener, CdcReconsentModule, defaultCdcReconsentLayoutConfig };
