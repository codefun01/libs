import * as i0 from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/core';
import { AuthStorageService, UserIdService, GlobalMessageService, AuthRedirectService, AuthToken, AuthConfigService, LoggerService, StateEventService, EventService, CmsComponent } from '@spartacus/core';
import { Store } from '@ngrx/store';
import { CdcAuthFacade } from '@spartacus/cdc/root';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as i3 from '@ngrx/effects';

declare class CdcAuthModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcAuthModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CdcAuthModule, never, [typeof i1.CommonModule, typeof i2.AuthModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CdcAuthModule>;
}

/**
 * Service to support custom CDC OAuth flow.
 */
declare class CdcAuthService implements CdcAuthFacade {
    protected store: Store;
    protected authStorageService: AuthStorageService;
    protected userIdService: UserIdService;
    protected globalMessageService: GlobalMessageService;
    protected authRedirectService: AuthRedirectService;
    constructor(store: Store, authStorageService: AuthStorageService, userIdService: UserIdService, globalMessageService: GlobalMessageService, authRedirectService: AuthRedirectService);
    /**
     * Loads a new user token using custom oauth flow
     *
     * @param UID
     * @param UIDSignature
     * @param signatureTimestamp
     * @param idToken
     * @param baseSite
     */
    loginWithCustomCdcFlow(UID: string, UIDSignature: string, signatureTimestamp: string, idToken: string, baseSite: string): void;
    /**
     * Utility to differentiate between AuthStorageService and AsmAuthStorageService
     */
    private isAsmAuthStorageService;
    /**
     * Transform and store the token received from custom flow to library format and login user.
     *
     * @param token
     */
    loginWithToken(token: Partial<AuthToken> & {
        expires_in?: number;
    }): void;
    protected setTokenData(token: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcAuthService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcAuthService>;
}

declare class CdcUserAuthenticationTokenService {
    protected http: HttpClient;
    protected authConfigService: AuthConfigService;
    protected logger: LoggerService;
    constructor(http: HttpClient, authConfigService: AuthConfigService);
    /**
     * Load User token using custom oauth flow
     *
     * @param UID - UID received from CDC on login event
     * @param UIDSignature - UIDSignature received from CDC on login event
     * @param signatureTimestamp - signatureTimestamp received from CDC on login event
     * @param idToken - idToken received from CDC on login event
     * @param baseSite - baseSite received from CDC on login event
     */
    loadTokenUsingCustomFlow(UID: string, UIDSignature: string, signatureTimestamp: string, idToken: string, baseSite: string): Observable<Partial<AuthToken> & {
        expires_in?: number;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcUserAuthenticationTokenService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcUserAuthenticationTokenService>;
}

declare class CdcEventBuilder {
    protected stateEventService: StateEventService;
    protected eventService: EventService;
    constructor(stateEventService: StateEventService, eventService: EventService);
    /**
     * Registers CDC events
     */
    protected register(): void;
    /**
     * Register the load user token fail event.
     */
    protected registerLoadUserTokenFail(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcEventBuilder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdcEventBuilder>;
}

declare class CdcEventModule {
    constructor(_cdcEventBuilder: CdcEventBuilder);
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CdcEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CdcEventModule>;
}

declare class CdcStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CdcStoreModule, never, [typeof i1.CommonModule, typeof CdcAuthModule, typeof i3.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CdcStoreModule>;
}

declare class CdcCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CdcCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CdcCoreModule, never, [typeof CdcAuthModule, typeof CdcEventModule, typeof CdcStoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CdcCoreModule>;
}

interface GigyaRaasComponentData extends CmsComponent {
    /** Unique identifier of the Component */
    uid?: string;
    /** Name of the Component */
    name?: string;
    /** Name of the Screen set which is to be displayed */
    screenSet?: string;
    /** Determines if screen is for profile edit */
    profileEdit?: string;
    /** Display screen in embed way */
    embed?: string;
    /** Starting screen which will be displayed on rendering the screen set */
    startScreen?: string;
    /** Container name in which CDC screen will be displayed */
    containerID?: string;
    /** Text of the button for the screen set when rendered in pop-up way */
    linkText?: string;
    /** Advanced configuration for the screen set */
    advancedConfiguration?: string;
    /** Decides whether screenset should be visible for anonymous user */
    showAnonymous?: string;
    /** Decides whether screenset should be visible for logged in user */
    showLoggedIn?: string;
}

export { CdcAuthModule, CdcAuthService, CdcCoreModule, CdcEventBuilder, CdcEventModule, CdcUserAuthenticationTokenService };
export type { GigyaRaasComponentData };
