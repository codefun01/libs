import * as i0 from '@angular/core';
import { inject, Injectable, NgModule, computed, Component } from '@angular/core';
import * as i2 from '@spartacus/core';
import { CxEvent, EventService, LanguageSetEvent, CurrencySetEvent, ProductService, ProductScope, I18nModule, provideDefaultConfigFactory, provideDefaultConfig, facadeFactory, Config } from '@spartacus/core';
import { Subscription, merge, EMPTY } from 'rxjs';
import { CurrentProductService, OutletContextData, provideOutlet, OutletPosition, LAUNCH_CALLER } from '@spartacus/storefront';
import { CartOutlets } from '@spartacus/cart/base/root';
import * as i1 from '@angular/common';
import { CommonModule, NgIf, NgFor, NgTemplateOutlet } from '@angular/common';
import { toSignal } from '@angular/core/rxjs-interop';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const SUBSCRIPTION_BILLING_FEATURE = 'subscriptionBilling';
const SUBSCRIPTION_BILLING_CORE_FEATURE = 'subscriptionBillingCore';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultSubscriptionBillingRoutingConfig = {
    routing: {
        routes: {
            subscriptions: {
                paths: ['my-account/subscriptions'],
            },
            subscriptionDetails: {
                paths: ['my-account/subscription/:subscriptionId'],
                paramsMapping: { subscriptionId: 'subscriptionId' },
            },
            subscriptionBills: {
                paths: ['my-account/subscription-bills'],
            },
            subscriptionBillingDetails: {
                paths: ['my-account/subscription-bill/:subscriptionBillId'],
                paramsMapping: { subscriptionBillId: 'subscriptionBillId' },
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class GetSubscriptionByCodeReloadEvent extends CxEvent {
    static { this.type = 'GetSubscriptionByCodeReloadEvent'; }
}
class GetSubscriptionListReloadEvent extends CxEvent {
    static { this.type = 'GetSubscriptionListReloadEvent'; }
}
class GetSubscriptionBillsListReloadEvent extends CxEvent {
    static { this.type = 'GetSubscriptionBillsListReloadEvent'; }
}
class GetSubscriptionBillByCodeReloadEvent extends CxEvent {
    static { this.type = 'GetSubscriptionBillByCodeReloadEvent'; }
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionBillingEventListener {
    constructor() {
        this.subscriptions = new Subscription();
        this.eventService = inject(EventService);
        this.onLanguageAndCurrencySetEvent();
    }
    onLanguageAndCurrencySetEvent() {
        this.subscriptions.add(merge(this.eventService.get(LanguageSetEvent), this.eventService.get(CurrencySetEvent)).subscribe(() => {
            this.eventService.dispatch({}, GetSubscriptionByCodeReloadEvent);
            this.eventService.dispatch({}, GetSubscriptionListReloadEvent);
        }));
    }
    ngOnDestroy() {
        this.subscriptions.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingEventListener, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingEventListener, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingEventListener, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionBillingEventModule {
    constructor(_subscriptionBillingEventListener) {
        // Intentional empty constructor
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingEventModule, deps: [{ token: SubscriptionBillingEventListener }], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingEventModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingEventModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingEventModule, decorators: [{
            type: NgModule,
            args: [{}]
        }], ctorParameters: () => [{ type: SubscriptionBillingEventListener }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionProductService {
    constructor() {
        this.currentProductService = inject(CurrentProductService);
        this.productService = inject(ProductService);
    }
    isSubscription(product) {
        return Boolean(product?.sapSubscriptionTerm && product?.sapPricePlan);
    }
    getSubscriptionData(productCode) {
        return productCode
            ? this.productService.get(productCode, [ProductScope.SUBSCRIPTION])
            : this.currentProductService.getProduct([ProductScope.SUBSCRIPTION]);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionProductService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionProductService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionProductService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionCartPriceHeadingComponent {
    constructor() {
        this.outletData = inject(OutletContextData, { optional: true });
        this.productService = inject(SubscriptionProductService);
        this.cartItems = toSignal(this.outletData?.context$ ?? EMPTY);
        this.subscriptionItem = computed(() => {
            return this.cartItems()?.items?.find((item) => item.product ? this.productService.isSubscription(item.product) : false);
        }, ...(ngDevMode ? [{ debugName: "subscriptionItem" }] : /* istanbul ignore next */ []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionCartPriceHeadingComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: SubscriptionCartPriceHeadingComponent, isStandalone: true, selector: "cx-subscription-cart-price-heading", ngImport: i0, template: "<ng-container *ngIf=\"subscriptionItem()\">\n  <th role=\"columnheader\" scope=\"col\" class=\"cx-item-list-charges\">\n    <span>{{ 'subscriptionCartItemList.itemPriceHeader' | cxTranslate }}</span>\n  </th>\n</ng-container>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: I18nModule }, { kind: "pipe", type: i2.TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionCartPriceHeadingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-subscription-cart-price-heading', standalone: true, imports: [CommonModule, I18nModule, NgIf], template: "<ng-container *ngIf=\"subscriptionItem()\">\n  <th role=\"columnheader\" scope=\"col\" class=\"cx-item-list-charges\">\n    <span>{{ 'subscriptionCartItemList.itemPriceHeader' | cxTranslate }}</span>\n  </th>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class SubscriptionCartPriceBodyComponent {
    constructor() {
        this.outletContext = inject(OutletContextData, { optional: true });
        this.productService = inject(SubscriptionProductService);
        this.outletData = toSignal(this.outletContext?.context$ ?? EMPTY);
        this.parent = computed(() => this.outletData().parent, ...(ngDevMode ? [{ debugName: "parent" }] : /* istanbul ignore next */ []));
        this.subscriptionItemExists = computed(() => {
            return this.outletData().items?.find((item) => item.product ? this.productService.isSubscription(item.product) : false);
        }, ...(ngDevMode ? [{ debugName: "subscriptionItemExists" }] : /* istanbul ignore next */ []));
        this.item = computed(() => {
            return this.outletData().item;
        }, ...(ngDevMode ? [{ debugName: "item" }] : /* istanbul ignore next */ []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionCartPriceBodyComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: SubscriptionCartPriceBodyComponent, isStandalone: true, selector: "cx-subscription-cart-price-body", ngImport: i0, template: "<ng-container *ngIf=\"subscriptionItemExists()\">\n  <td role=\"cell\" class=\"cx-item-list-charges\">\n    <div class=\"cx-item-list-charges\">\n      <ng-container\n        *ngIf=\"\n          this.productService.isSubscription(item().product);\n          else noSubscriptions\n        \"\n      >\n        <ng-container *ngTemplateOutlet=\"charges\" />\n      </ng-container>\n\n      <ng-template #noSubscriptions>\n        <span class=\"cx-value\">\n          {{ item().basePrice?.formattedValue }}\n        </span>\n      </ng-template>\n    </div>\n  </td>\n</ng-container>\n\n<ng-container *ngIf=\"parent() === 'minicart'\">\n  <ng-container *ngIf=\"this.productService.isSubscription(item().product)\">\n    <ng-container *ngTemplateOutlet=\"charges\" />\n  </ng-container>\n</ng-container>\n\n<ng-template #charges>\n  <div class=\"cx-recurring-charges\">\n    <ng-container\n      *ngFor=\"\n        let recurringCharge of item().product?.sapPricePlan?.recurringCharges\n      \"\n    >\n      <div class=\"cx-value\">\n        <span class=\"cx-billing-value\"\n          >{{ recurringCharge.price?.formattedValue }}/</span\n        >\n        <span class=\"cx-billing-name\">{{\n          item().product?.sapSubscriptionTerm?.billingPlan?.billingTime?.name\n        }}</span>\n      </div>\n    </ng-container>\n  </div>\n  <div class=\"cx-one-time-charges\">\n    <ng-container\n      *ngFor=\"let oneTimeCharge of item().product?.sapPricePlan?.oneTimeCharges\"\n    >\n      <div class=\"cx-value\">\n        <span class=\"cx-billing-value\">\n          {{ oneTimeCharge.price?.formattedValue }}\n        </span>\n        <span class=\"cx-billing-name\">\n          {{ oneTimeCharge.billingTime?.name | lowercase }}\n        </span>\n      </div>\n    </ng-container>\n  </div>\n</ng-template>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: i1.LowerCasePipe, name: "lowercase" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionCartPriceBodyComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-subscription-cart-price-body', imports: [CommonModule, NgIf, NgFor, NgTemplateOutlet], standalone: true, template: "<ng-container *ngIf=\"subscriptionItemExists()\">\n  <td role=\"cell\" class=\"cx-item-list-charges\">\n    <div class=\"cx-item-list-charges\">\n      <ng-container\n        *ngIf=\"\n          this.productService.isSubscription(item().product);\n          else noSubscriptions\n        \"\n      >\n        <ng-container *ngTemplateOutlet=\"charges\" />\n      </ng-container>\n\n      <ng-template #noSubscriptions>\n        <span class=\"cx-value\">\n          {{ item().basePrice?.formattedValue }}\n        </span>\n      </ng-template>\n    </div>\n  </td>\n</ng-container>\n\n<ng-container *ngIf=\"parent() === 'minicart'\">\n  <ng-container *ngIf=\"this.productService.isSubscription(item().product)\">\n    <ng-container *ngTemplateOutlet=\"charges\" />\n  </ng-container>\n</ng-container>\n\n<ng-template #charges>\n  <div class=\"cx-recurring-charges\">\n    <ng-container\n      *ngFor=\"\n        let recurringCharge of item().product?.sapPricePlan?.recurringCharges\n      \"\n    >\n      <div class=\"cx-value\">\n        <span class=\"cx-billing-value\"\n          >{{ recurringCharge.price?.formattedValue }}/</span\n        >\n        <span class=\"cx-billing-name\">{{\n          item().product?.sapSubscriptionTerm?.billingPlan?.billingTime?.name\n        }}</span>\n      </div>\n    </ng-container>\n  </div>\n  <div class=\"cx-one-time-charges\">\n    <ng-container\n      *ngFor=\"let oneTimeCharge of item().product?.sapPricePlan?.oneTimeCharges\"\n    >\n      <div class=\"cx-value\">\n        <span class=\"cx-billing-value\">\n          {{ oneTimeCharge.price?.formattedValue }}\n        </span>\n        <span class=\"cx-billing-name\">\n          {{ oneTimeCharge.billingTime?.name | lowercase }}\n        </span>\n      </div>\n    </ng-container>\n  </div>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
function defaultSubscriptionBillingComponentsConfig() {
    const config = {
        featureModules: {
            [SUBSCRIPTION_BILLING_FEATURE]: {
                cmsComponents: [
                    'SubscriptionHistoryComponent',
                    'SubscriptionProductPriceComponent',
                    'SubscriptionDetailsComponent',
                    'SubscriptionBillsHistoryComponent',
                    'SubscriptionBillDetailsComponent',
                ],
            },
            [SUBSCRIPTION_BILLING_CORE_FEATURE]: SUBSCRIPTION_BILLING_FEATURE,
        },
    };
    return config;
}
class SubscriptionBillingRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingRootModule, imports: [SubscriptionBillingEventModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingRootModule, providers: [
            provideDefaultConfigFactory(defaultSubscriptionBillingComponentsConfig),
            provideDefaultConfig(defaultSubscriptionBillingRoutingConfig),
            provideOutlet({
                id: CartOutlets.SUBSCRIPTION_PRICE_HEADING,
                position: OutletPosition.AFTER,
                component: SubscriptionCartPriceHeadingComponent,
            }),
            provideOutlet({
                id: CartOutlets.SUBSCRIPTION_PRICE_BODY,
                position: OutletPosition.AFTER,
                component: SubscriptionCartPriceBodyComponent,
            }),
        ], imports: [SubscriptionBillingEventModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingRootModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [SubscriptionBillingEventModule],
                    providers: [
                        provideDefaultConfigFactory(defaultSubscriptionBillingComponentsConfig),
                        provideDefaultConfig(defaultSubscriptionBillingRoutingConfig),
                        provideOutlet({
                            id: CartOutlets.SUBSCRIPTION_PRICE_HEADING,
                            position: OutletPosition.AFTER,
                            component: SubscriptionCartPriceHeadingComponent,
                        }),
                        provideOutlet({
                            id: CartOutlets.SUBSCRIPTION_PRICE_BODY,
                            position: OutletPosition.AFTER,
                            component: SubscriptionCartPriceBodyComponent,
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var UsageChargeType;
(function (UsageChargeType) {
    UsageChargeType["BLOCK"] = "block_usage_charge";
    UsageChargeType["PERCENTAGE"] = "percentage_usage_charge";
    UsageChargeType["TIER"] = "each_respective_tier";
})(UsageChargeType || (UsageChargeType = {}));
ProductScope['SUBSCRIPTION'] = 'subscription';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
LAUNCH_CALLER['SUBSCRIPTION_ACTION_CONFIRMATION'] =
    'SUBSCRIPTION_ACTION_CONFIRMATION';
LAUNCH_CALLER['DATE_RANGE_MODAL'] = 'DATE_RANGE_MODAL';

/*
 * SPDX-FileCopyrightText: 2025 SAP Spartacus team <spartacus-team@sap.com>
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var SubscriptionBillStatus;
(function (SubscriptionBillStatus) {
    SubscriptionBillStatus["PAID"] = "Paid";
    SubscriptionBillStatus["DUE"] = "Due";
})(SubscriptionBillStatus || (SubscriptionBillStatus = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

class SubscriptionFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: SubscriptionFacade,
            feature: SUBSCRIPTION_BILLING_FEATURE,
            methods: [
                'getSubscriptionByCodeState',
                'getSubscriptionByCode',
                'getSubscriptionListState',
                'getSubscriptionList',
                'getSubscriptionCodeFromRoute',
            ],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: SubscriptionFacade,
                        feature: SUBSCRIPTION_BILLING_FEATURE,
                        methods: [
                            'getSubscriptionByCodeState',
                            'getSubscriptionByCode',
                            'getSubscriptionListState',
                            'getSubscriptionList',
                            'getSubscriptionCodeFromRoute',
                        ],
                    }),
                }]
        }] });

class SubscriptionActionsFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: SubscriptionActionsFacade,
            feature: SUBSCRIPTION_BILLING_FEATURE,
            methods: [
                'cancelSubscription',
                'getEffectiveCancellationDate',
                'reverseCancellation',
                'withdrawSubscription',
                'getExtensionEffectiveDate',
                'extendSubscription',
            ],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionActionsFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: SubscriptionActionsFacade,
                        feature: SUBSCRIPTION_BILLING_FEATURE,
                        methods: [
                            'cancelSubscription',
                            'getEffectiveCancellationDate',
                            'reverseCancellation',
                            'withdrawSubscription',
                            'getExtensionEffectiveDate',
                            'extendSubscription',
                        ],
                    }),
                }]
        }] });

class SubscriptionBillingFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: SubscriptionBillingFacade,
            feature: SUBSCRIPTION_BILLING_FEATURE,
            methods: [
                'getSubscriptionBillByCodeState',
                'getSubscriptionBillByCode',
                'getSubscriptionBillsListState',
                'getSubscriptionBillsList',
                'getSubscriptionBillCodeFromRoute',
            ],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: SubscriptionBillingFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: SubscriptionBillingFacade,
                        feature: SUBSCRIPTION_BILLING_FEATURE,
                        methods: [
                            'getSubscriptionBillByCodeState',
                            'getSubscriptionBillByCode',
                            'getSubscriptionBillsListState',
                            'getSubscriptionBillsList',
                            'getSubscriptionBillCodeFromRoute',
                        ],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultExtendDropdownOptions = {
    Months: 12,
    Years: 5,
    Days: 30,
    Weeks: 4,
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ExtendSubscriptionFrequencyDropdownOptionsConfig {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ExtendSubscriptionFrequencyDropdownOptionsConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ExtendSubscriptionFrequencyDropdownOptionsConfig, providedIn: 'root', useExisting: Config }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ExtendSubscriptionFrequencyDropdownOptionsConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useExisting: Config,
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ExtendSubscriptionFrequencyDropdownOptionsConfig, GetSubscriptionBillByCodeReloadEvent, GetSubscriptionBillsListReloadEvent, GetSubscriptionByCodeReloadEvent, GetSubscriptionListReloadEvent, SUBSCRIPTION_BILLING_CORE_FEATURE, SUBSCRIPTION_BILLING_FEATURE, SubscriptionActionsFacade, SubscriptionBillStatus, SubscriptionBillingEventListener, SubscriptionBillingEventModule, SubscriptionBillingFacade, SubscriptionBillingRootModule, SubscriptionCartPriceBodyComponent, SubscriptionCartPriceHeadingComponent, SubscriptionFacade, SubscriptionProductService, UsageChargeType, defaultExtendDropdownOptions, defaultSubscriptionBillingComponentsConfig, defaultSubscriptionBillingRoutingConfig };
//# sourceMappingURL=spartacus-subscription-billing-root.mjs.map
