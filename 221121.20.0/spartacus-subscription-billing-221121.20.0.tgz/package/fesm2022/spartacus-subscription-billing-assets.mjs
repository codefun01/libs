var subscriptionProduct = {
	subscriptionTerms: "Subscription Terms:",
	minimumTerm: "Minimum Subscription duration is {{ term }}",
	renewalTerm: "Renewal after {{ term }}",
	usageCharges: "Pricing Details",
	volumeUsage: "For {{ from }} to {{ to }}: {{ fixed }} plus {{ price }} per {{ usage }}",
	volumeOverageUsage: "For {{ from }} to Unlimited: {{ fixed }} plus {{ price }} per {{ usage }}",
	volumeUsageMessage: "*You will be charged as per the highest applicable tier",
	tierOverageUsage: "From {{ from }} to Unlimited: {{ price }} per {{ usage }}",
	tierUsageMessage: "*You will be charged as per each applicable tier",
	tierUsage: "From {{ from }} to {{ to }}: {{ price }} per {{ usage }}",
	includedQuantity: "Included Quantity: {{ quantity }}",
	oneBlockUsage: " {{ price }} per {{ usage }} ",
	multiBlockUsage: "{{ price }} for every {{ block }}",
	percentageUsage: "Included Ratio {{ ratio }} at {{ price }} per {{ usage }}"
};
var subscriptionList = {
	id: "Subscription ID: {{ id }}",
	product: "Subscription Product",
	title: "All Subscriptions",
	sortSubtitle: "Sort By",
	startDate: "Subscription Start Date: {{ date }}",
	status: "Status: ",
	noSubscriptions: "You don't have any subscriptions",
	sortOrders: "Sort orders",
	manageService: "Manage Service",
	amount: "Billing Amount: {{ amount }} {{ time }}",
	sorts: {
		byDocumentNumberDesc: "Document Number Descending",
		byDocumentNumberAsc: "Document Number Ascending"
	}
};
var subscriptionDetails = {
	info: "Subscription Product Details:",
	productCode: "Subscription Service (Product) Code:",
	endDate: "Subscription End Date: {{ date }}",
	cancelSubscription: "Cancel Subscription",
	extendSubscription: "Extend Subscription",
	withdrawSubscription: "Withdraw Subscription",
	reSubscribe: "Renew Subscription",
	back: "View All Subscriptions",
	withdrawalEnd: "Withdrawal Period End Date: {{ date }}",
	orderCode: "Order Number:"
};
var subscriptionActions = {
	cancel: "Cancel",
	confirm: "Confirm",
	cancelSuccess: "The subscription has been cancelled successfully.",
	withdrawSuccess: "The subscription has been withdrawn successfully.",
	reverseCancellationSuccess: "The subscription has been reversed successfully.",
	unknownError: "An unknown error occurred. Please contact support.",
	askConfirm: "{{ action }} your subscription?",
	closeModal: "Close modal",
	loseSubscription: "If you confirm, you will lose access to the subscription features on {{ date }}. You won't be charged again.",
	changeMind: "If you change your mind, you can reactivate your subscription before the end of the billing period.",
	withdrawConfirm: "By confirming, you are ending your trial period.You will lose access to subscription features on by the end of today.No additional charges apply.",
	resubscribeConfirm: "By confirming, you are renewing your subscription and will gain access to our subscription features. ",
	changeMindresubscribe: "You can manage your subscription anytime later.",
	extend: "Extend",
	durationInputLabel: "Extend Subscription By",
	durationInputPlaceholder: "Enter duration in {{ frequency }}",
	disclaimer: "You are about to extend your subscription under the same Terms & Conditions and Cancellation Policy.",
	disclaimerWithExtensionEndDate: "You are about to extend your subscription until {{ endDate }} under the same Terms & Conditions and Cancellation Policy.",
	noActionMessage: "No further action is required unless, you wish to make changes to your subscription.",
	confirmExtensionTitle: "Confirm Extension Period",
	extendedSuccessfully: "Your subscription has been extended successfully"
};
var subscriptionCartItemList = {
	itemPriceHeader: "Item Price",
	dueNowHeader: "Due Now"
};
var subscriptionBillsList = {
	title: "All Subscription Bills",
	dateRangeLabel: "Select Date Range",
	filterFromDateLabel: "From",
	filterToDateLabel: "To",
	sortLabel: "Sort By",
	noSubscriptionBills: "You don't have any subscription bills",
	tableHeaderColId: "Bill ID/Number",
	tableHeaderColDate: "Billing Date",
	tableHeaderColSubscriptions: "Subscriptions",
	tableHeaderColTotal: "Total",
	tableViewBillCol: "View Bill",
	reset: "Reset",
	submit: "Submit",
	cancel: "Cancel",
	clear: "Clear",
	descriptionSuffix: "{{ numberOfItems }} more",
	dateRangeInputPlaceholder: "Click to select the dates",
	dateRangeModalTitle: "Set The Date Range"
};
var subscriptionBillingDetails = {
	billId: "Subscription Bill ID: ",
	totalAmount: "Total Amount: ",
	subscriptionProduct: "Subscription Product",
	billingPeriod: "Billing Period: {{ startDate }} - {{ endDate }}"
};
var subscriptionPageBreadcrumb = {
	home: "Home",
	subscriptions: "Subscriptions",
	subscriptionBills: "Subscription Bills"
};
var subscriptionBilling = {
	subscriptionProduct: subscriptionProduct,
	subscriptionList: subscriptionList,
	subscriptionDetails: subscriptionDetails,
	subscriptionActions: subscriptionActions,
	subscriptionCartItemList: subscriptionCartItemList,
	subscriptionBillsList: subscriptionBillsList,
	subscriptionBillingDetails: subscriptionBillingDetails,
	subscriptionPageBreadcrumb: subscriptionPageBreadcrumb
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const en = {
    subscriptionBilling,
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const subscriptionBillingTranslationChunksConfig = {
    subscriptionBilling: [
        'subscriptionProduct',
        'subscriptionList',
        'subscriptionDetails',
        'subscriptionActions',
        'subscriptionCartItemList',
        'subscriptionBillsList',
        'subscriptionBillingDetails',
        'subscriptionPageBreadcrumb',
    ],
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { subscriptionBillingTranslationChunksConfig, en as subscriptionBillingTranslationsEn };
//# sourceMappingURL=spartacus-subscription-billing-assets.mjs.map
