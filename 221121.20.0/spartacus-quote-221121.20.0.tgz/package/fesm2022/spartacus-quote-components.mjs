import { DOCUMENT, NgIf, AsyncPipe, CommonModule, NgTemplateOutlet, NgFor, NgClass, getLocaleNumberSymbol, NumberSymbol } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, inject, ViewChild, Component, NgModule, ChangeDetectionStrategy, EventEmitter, Input, Output, ViewContainerRef, HostListener } from '@angular/core';
import { Config, UserIdService, EventService, TranslationService, TranslatePipe, I18nModule, provideDefaultConfig, AuthGuard, CxDatePipe, UrlModule, FeaturesConfigModule, FeatureToggles, GlobalMessageService, GlobalMessageType, UrlPipe, LanguageService, TimeUtils } from '@spartacus/core';
import { QuoteDetailsReloadQueryEvent, QuoteCoreConfig, CartUtilsService, QuoteStorefrontUtilsService } from '@spartacus/quote/core';
import { QuoteFacade, QuoteState, QuoteActionType, QuoteRoleType, QuoteDiscountType } from '@spartacus/quote/root';
import { ICON_TYPE, IconComponent, MessagingComponent, IconModule, ChatMessagingModule, LaunchDialogService, FocusDirective, DIALOG_TYPE, FormErrorsModule, KeyboardFocusModule, SpinnerModule, CardComponent, CardModule, OutletDirective, OutletModule, FileDownloadService, SortingComponent, PaginationComponent, ListNavigationModule, IntersectionService, LAUNCH_CALLER, DatePickerComponent, DatePickerModule } from '@spartacus/storefront';
import { ReplaySubject, combineLatest, of, zip, BehaviorSubject, Subscription, Subject } from 'rxjs';
import { switchMap, tap, filter, map, take, finalize, delay, distinctUntilChanged, debounceTime } from 'rxjs/operators';
import { ActiveCartFacade, MultiCartFacade, AbstractOrderType, CartOutlets } from '@spartacus/cart/base/root';
import * as i1 from '@angular/forms';
import { FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { RouterModule, RouterLink } from '@angular/router';
import { AbstractOrderContextDirective, AbstractOrderContextModule } from '@spartacus/cart/base/components';
import { OrderConfig } from '@spartacus/order/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteUIConfig {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteUIConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteUIConfig, providedIn: 'root', useExisting: Config }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteUIConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useExisting: Config,
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteItemsComponentService {
    constructor() {
        this.quoteFacade = inject(QuoteFacade);
        this.userIdService = inject(UserIdService);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.multiCartFacade = inject(MultiCartFacade);
        this._quoteEntriesExpanded$ = new ReplaySubject(1);
        this._quoteEntriesExpanded$.next(true);
    }
    /**
     * Signals that the quote entry section is expanded.
     *
     * @param expanded Quote entry section expanded?
     */
    setQuoteEntriesExpanded(expanded) {
        this._quoteEntriesExpanded$.next(expanded);
    }
    /**
     * Emits expanded state of the quote entries section.
     *
     * @returns Observable of boolean values telling if the quote entry section is expanded
     */
    getQuoteEntriesExpanded() {
        return this._quoteEntriesExpanded$;
    }
    /**
     * Retrieves observable of current quote entries (which can be read from a quote,
     * a saved cart or an active cart, depending on the quote state and its edit status).
     *
     * @returns Observable of quote items data. The return structure also contains information
     * about the type of the hosting document (quote, saved cart or active cart) and its edit status.
     */
    retrieveQuoteEntries() {
        return this.userIdService.takeUserId().pipe(switchMap((userId) => combineLatest([this.quoteFacade.getQuoteDetails(), of(userId)])), tap(([quote, userId]) => {
            this.loadQuoteCartIfNeeded(quote, userId);
        }), switchMap(([quote, _userId]) => {
            if (!quote.cartId) {
                return this.prepareQuote(quote);
            }
            else {
                const quoteCartId = quote.cartId;
                if (!quote.isEditable) {
                    return this.prepareSavedCart(quoteCartId);
                }
                else {
                    return this.prepareActiveCart();
                }
            }
        }), filter(([abstractOrder, _editState]) => abstractOrder !== undefined), map(([abstractOrder, editState, abstractOrderType]) => {
            return {
                entries: abstractOrder.entries,
                readOnly: editState.readOnly,
                abstractOrderId: abstractOrder.code,
                abstractOrderType: abstractOrderType,
            };
        }));
    }
    prepareActiveCart() {
        return combineLatest([
            this.activeCartFacade.isStable().pipe(filter((stable) => stable), switchMap(() => this.activeCartFacade.getActive())),
            of({ readOnly: false }),
            of(AbstractOrderType.CART),
        ]);
    }
    prepareSavedCart(quoteCartId) {
        return combineLatest([
            this.multiCartFacade.isStable(quoteCartId).pipe(filter((stable) => stable), switchMap(() => this.multiCartFacade.getCart(quoteCartId))),
            of({ readOnly: true }),
            of(AbstractOrderType.SAVED_CART),
        ]);
    }
    prepareQuote(quote) {
        return zip(of(quote), of({ readOnly: true }), of(AbstractOrderType.QUOTE));
    }
    loadQuoteCartIfNeeded(quote, userId) {
        if (quote.cartId && !quote.isEditable) {
            this.multiCartFacade.loadCart({
                userId,
                cartId: quote.cartId,
                extraData: { active: false },
            });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteItemsComponentService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteItemsComponentService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteItemsComponentService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const DEFAULT_COMMENT_MAX_CHARS = 1000;
const ALL_PRODUCTS_ID = '';
class QuoteCommentsComponent {
    constructor() {
        this.quoteFacade = inject(QuoteFacade);
        this.quoteItemsComponentService = inject(QuoteItemsComponentService);
        this.eventService = inject(EventService);
        this.translationService = inject(TranslationService);
        this.quoteUIConfig = inject(QuoteUIConfig);
        this.document = inject(DOCUMENT);
        this.expandComments = true;
        this.iconTypes = ICON_TYPE;
        this.quoteDetails$ = this.quoteFacade.getQuoteDetails();
        this.messageEvents$ = this.prepareMessageEvents();
        this.messagingConfigs = this.prepareMessagingConfigs();
    }
    /**
     * Creates a quote comment based on the provided message event.
     * In case it contains an itemId the comment will be associated with this item, otherwise a header comment is created.
     *
     * @param event - message event
     * @param code - quote code
     */
    onSend(event, code) {
        this.quoteFacade
            .addQuoteComment(code, { text: event.message }, event.itemId)
            .pipe(take(1), 
        // do for error and success
        finalize(() => this.commentsComponent.resetForm()))
            .subscribe(
        // success
        () => {
            this.eventService.dispatch({}, QuoteDetailsReloadQueryEvent);
            this.messagingConfigs.newMessagePlaceHolder = undefined;
        }, 
        // error
        () => {
            this.translationService
                .translate('quote.comments.invalidComment')
                .pipe(take(1))
                .subscribe((text) => (this.messagingConfigs.newMessagePlaceHolder = text));
        });
    }
    /**
     * Ensures that the quote item list is expanded, before scrolling to the corresponding item.
     *
     * @param event - click event containing the target item
     */
    onItemClicked(event) {
        this.quoteItemsComponentService.setQuoteEntriesExpanded(true);
        this.quoteItemsComponentService
            .getQuoteEntriesExpanded()
            .pipe(take(1), delay(0)) // delay this task until the UI has expanded
            .subscribe(() => {
            const aTags = Array.from(this.document.getElementsByTagName('a'));
            for (const aTag of aTags) {
                if (aTag.textContent === event.item.name) {
                    aTag.scrollIntoView({ block: 'center' });
                    return;
                }
            }
        });
    }
    /**
     * Checks whether the comment section shall be shown at all.
     * In case the quote is in readonly mode and no comments are present, comment section is hidden, as there is nothing to display.
     * In case the quote is editable the comment section is always shown, as you could at least add comments from it.
     *
     * @param quote - quote
     * @returns true, only is the comment section shall be shown
     */
    showComments(quote) {
        let numItemComments = 0;
        quote.entries?.forEach((entry) => (numItemComments += entry.comments?.length ?? 0));
        return (quote.isEditable ||
            (quote.comments?.length ?? 0) > 0 ||
            numItemComments > 0);
    }
    prepareMessagingConfigs() {
        return {
            charactersLimit: this.quoteUIConfig.quote?.maxCharsForComments ??
                DEFAULT_COMMENT_MAX_CHARS,
            displayAddMessageSection: this.quoteDetails$.pipe(map((quote) => quote.isEditable)),
            dateFormat: 'MMMM d, yyyy h:mm aa',
            defaultItemId: ALL_PRODUCTS_ID,
            itemList$: this.prepareItemList(),
            sendBtnIsNotPrimary: true,
        };
    }
    prepareItemList() {
        return combineLatest([
            this.quoteDetails$.pipe(),
            this.translationService.translate('quote.comments.allProducts'),
        ]).pipe(map(([quote, allProductsLabel]) => {
            const itemList = [
                { id: ALL_PRODUCTS_ID, name: allProductsLabel },
            ];
            quote.entries?.forEach((entry) => {
                itemList.push(this.convertToItem(entry));
            });
            return itemList;
        }));
    }
    convertToItem(entry) {
        if (entry.entryNumber === undefined) {
            throw Error('entryNumber may not be undefined, entry: ' + JSON.stringify(entry));
        }
        return {
            id: entry.entryNumber.toString(),
            name: entry.product?.name ??
                entry.product?.code ??
                entry.entryNumber.toString(),
        };
    }
    prepareMessageEvents() {
        return this.quoteDetails$.pipe(map((quote) => {
            const messageEvents = [];
            quote.comments?.forEach((comment) => messageEvents.push(this.mapCommentToMessageEvent(comment)));
            quote.entries?.forEach((entry) => {
                entry.comments?.forEach((comment) => messageEvents.push(this.mapCommentToMessageEvent(comment, entry)));
            });
            messageEvents.sort((eventA, eventB) => {
                return (new Date(eventA?.createdAt ?? 0).getTime() -
                    new Date(eventB?.createdAt ?? 0).getTime());
            });
            return messageEvents;
        }));
    }
    mapCommentToMessageEvent(comment, entry) {
        const messages = {
            author: comment.author?.name,
            text: comment.text,
            createdAt: comment.creationDate?.toString(),
            rightAlign: !comment.fromCustomer,
            item: entry ? this.convertToItem(entry) : undefined,
        };
        return messages;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCommentsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: QuoteCommentsComponent, isStandalone: true, selector: "cx-quote-comments", viewQueries: [{ propertyName: "commentsComponent", first: true, predicate: MessagingComponent, descendants: true }], ngImport: i0, template: "<ng-container *ngIf=\"quoteDetails$ | async as quoteDetails; else ghostComment\">\n  <div\n    role=\"region\"\n    tabindex=\"-1\"\n    [attr.aria-label]=\"'quote.comments.regionTitle' | cxTranslate\"\n  >\n    <ng-container *ngIf=\"showComments(quoteDetails)\">\n      <div\n        class=\"cx-toggle\"\n        #commentToggle\n        (keydown.enter)=\"commentToggle.click()\"\n        (click)=\"expandComments = !expandComments\"\n        tabindex=\"0\"\n      >\n        <cx-icon\n          aria-hidden=\"false\"\n          [type]=\"expandComments ? iconTypes.CARET_UP : iconTypes.CARET_DOWN\"\n        />\n        <span class=\"cx-text\">{{ 'quote.comments.title' | cxTranslate }}</span>\n      </div>\n      <cx-messaging\n        *ngIf=\"expandComments\"\n        [messageEvents$]=\"messageEvents$\"\n        [messagingConfigs]=\"messagingConfigs\"\n        (send)=\"onSend($event, quoteDetails.code)\"\n        (itemClicked)=\"onItemClicked($event)\"\n      />\n    </ng-container>\n  </div>\n</ng-container>\n\n<ng-template #ghostComment>\n  <div class=\"cx-ghost-comment\">\n    <div class=\"cx-ghost-input-title ghost\"></div>\n    <div class=\"cx-ghost-input ghost\"></div>\n  </div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "component", type: MessagingComponent, selector: "cx-messaging", inputs: ["messageEvents$", "scrollToInput", "messagingConfigs"], outputs: ["send", "itemClicked", "downloadAttachment"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCommentsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-quote-comments', imports: [NgIf, IconComponent, MessagingComponent, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"quoteDetails$ | async as quoteDetails; else ghostComment\">\n  <div\n    role=\"region\"\n    tabindex=\"-1\"\n    [attr.aria-label]=\"'quote.comments.regionTitle' | cxTranslate\"\n  >\n    <ng-container *ngIf=\"showComments(quoteDetails)\">\n      <div\n        class=\"cx-toggle\"\n        #commentToggle\n        (keydown.enter)=\"commentToggle.click()\"\n        (click)=\"expandComments = !expandComments\"\n        tabindex=\"0\"\n      >\n        <cx-icon\n          aria-hidden=\"false\"\n          [type]=\"expandComments ? iconTypes.CARET_UP : iconTypes.CARET_DOWN\"\n        />\n        <span class=\"cx-text\">{{ 'quote.comments.title' | cxTranslate }}</span>\n      </div>\n      <cx-messaging\n        *ngIf=\"expandComments\"\n        [messageEvents$]=\"messageEvents$\"\n        [messagingConfigs]=\"messagingConfigs\"\n        (send)=\"onSend($event, quoteDetails.code)\"\n        (itemClicked)=\"onItemClicked($event)\"\n      />\n    </ng-container>\n  </div>\n</ng-container>\n\n<ng-template #ghostComment>\n  <div class=\"cx-ghost-comment\">\n    <div class=\"cx-ghost-input-title ghost\"></div>\n    <div class=\"cx-ghost-input ghost\"></div>\n  </div>\n</ng-template>\n" }]
        }], propDecorators: { commentsComponent: [{
                type: ViewChild,
                args: [MessagingComponent]
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteCommentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCommentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QuoteCommentsModule, imports: [CommonModule,
            I18nModule,
            IconModule,
            ChatMessagingModule,
            QuoteCommentsComponent], exports: [QuoteCommentsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCommentsModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    QuoteCommentsComponent: {
                        component: QuoteCommentsComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            IconModule,
            ChatMessagingModule,
            QuoteCommentsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteCommentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        IconModule,
                        ChatMessagingModule,
                        QuoteCommentsComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                QuoteCommentsComponent: {
                                    component: QuoteCommentsComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                    ],
                    exports: [QuoteCommentsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteConfirmDialogComponent {
    constructor() {
        this.launchDialogService = inject(LaunchDialogService);
        this.quoteCoreConfig = inject(QuoteCoreConfig);
        this.translationService = inject(TranslationService);
        this.cxDatePipe = inject(CxDatePipe);
        this.iconTypes = ICON_TYPE;
        this.focusConfig = {
            trap: true,
            block: true,
            autofocus: 'button',
            focusOnEscape: true,
        };
    }
    ngOnInit() {
        this.confirmationContext$ = this.launchDialogService.data$.pipe(filter((data) => !!data), map((data) => data.confirmationContext));
    }
    /**
     * Closes a modal with a certain reason.
     *
     * @param reason - Reason
     */
    dismissModal(reason) {
        this.launchDialogService.closeDialog(reason);
    }
    isNotEmpty(value) {
        return value && value.trim()?.length !== 0 ? true : false;
    }
    /**
     * Retrieves an accessibility text for the confirmation modal.
     *
     * @param context - confirmation context
     */
    getA11yModalText(context) {
        let translatedText = '';
        if (context.warningNote && this.isNotEmpty(context.warningNote)) {
            this.translationService
                .translate(context.warningNote)
                .pipe(take(1))
                .subscribe((text) => (translatedText += text));
        }
        if (context.validity &&
            this.isNotEmpty(context.validity) &&
            context.quote.expirationTime) {
            this.translationService
                .translate(context.validity)
                .pipe(take(1))
                .subscribe((text) => (translatedText += text));
            const date = new Date(context.quote.expirationTime);
            translatedText += this.cxDatePipe.transform(date);
        }
        this.translationService
            .translate(context.confirmNote)
            .pipe(take(1))
            .subscribe((text) => (translatedText += text));
        return translatedText;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteConfirmDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: QuoteConfirmDialogComponent, isStandalone: true, selector: "cx-quote-confirm-dialog", providers: [CxDatePipe], ngImport: i0, template: "<div\n  #dialog\n  class=\"cx-modal-container\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"dismissModal('Escape clicked')\"\n  role=\"dialog\"\n  aria-modal=\"true\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <div\n    class=\"cx-modal-content\"\n    *ngIf=\"confirmationContext$ | async as confirmationContext\"\n  >\n    <!-- Modal Header -->\n    <div class=\"cx-dialog-header modal-header\">\n      <h3 id=\"dialogTitle\" class=\"cx-dialog-title modal-title\">\n        {{\n          confirmationContext.title\n            | cxTranslate: { code: confirmationContext.quote.code }\n        }}\n      </h3>\n      <button\n        type=\"button\"\n        class=\"close\"\n        title=\"{{ confirmationContext.a11y.close | cxTranslate }}\"\n        [attr.aria-label]=\"confirmationContext.a11y.close | cxTranslate\"\n        (click)=\"dismissModal('Cross click')\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\" />\n        </span>\n      </button>\n    </div>\n\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\">\n      <div class=\"cx-content-container\">\n        <div class=\"cx-name\">\n          <div class=\"cx-heading\">\n            {{ 'quote.confirmDialog.name' | cxTranslate }}\n          </div>\n          <div class=\"cx-content\">\n            {{ confirmationContext.quote.name }}\n          </div>\n        </div>\n        <div\n          class=\"cx-description\"\n          *ngIf=\"confirmationContext.quote.description\"\n        >\n          <div class=\"cx-heading\">\n            {{ 'quote.confirmDialog.description' | cxTranslate }}\n          </div>\n          <div class=\"cx-content\">\n            {{ confirmationContext.quote.description }}\n          </div>\n        </div>\n      </div>\n      <div class=\"cx-notes-container\">\n        <p *ngIf=\"confirmationContext.warningNote\">\n          {{ confirmationContext.warningNote | cxTranslate }}\n        </p>\n        <p\n          *ngIf=\"\n            confirmationContext.validity &&\n            confirmationContext.quote.expirationTime\n          \"\n        >\n          {{\n            confirmationContext.validity\n              | cxTranslate\n                : {\n                    expirationTime:\n                      confirmationContext.quote.expirationTime | cxDate,\n                  }\n          }}\n        </p>\n        <p>\n          {{ confirmationContext.confirmNote | cxTranslate }}\n        </p>\n      </div>\n      <div class=\"cx-buttons-container\">\n        <button class=\"btn btn-secondary\" (click)=\"dismissModal('no')\">\n          {{ 'quote.confirmDialog.option.no' | cxTranslate }}\n        </button>\n        <button class=\"btn btn-primary\" (click)=\"dismissModal('yes')\">\n          {{ 'quote.confirmDialog.option.yes' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n\n    <!-- For screen reader purposes (not visual)-->\n    <div\n      class=\"cx-visually-hidden\"\n      aria-live=\"polite\"\n      role=\"alert\"\n      aria-atomic=\"true\"\n    >\n      {{ getA11yModalText(confirmationContext) }}\n    </div>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: CxDatePipe, name: "cxDate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteConfirmDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-quote-confirm-dialog', changeDetection: ChangeDetectionStrategy.OnPush, providers: [CxDatePipe], imports: [
                        FocusDirective,
                        NgIf,
                        IconComponent,
                        AsyncPipe,
                        TranslatePipe,
                        CxDatePipe,
                    ], template: "<div\n  #dialog\n  class=\"cx-modal-container\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"dismissModal('Escape clicked')\"\n  role=\"dialog\"\n  aria-modal=\"true\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <div\n    class=\"cx-modal-content\"\n    *ngIf=\"confirmationContext$ | async as confirmationContext\"\n  >\n    <!-- Modal Header -->\n    <div class=\"cx-dialog-header modal-header\">\n      <h3 id=\"dialogTitle\" class=\"cx-dialog-title modal-title\">\n        {{\n          confirmationContext.title\n            | cxTranslate: { code: confirmationContext.quote.code }\n        }}\n      </h3>\n      <button\n        type=\"button\"\n        class=\"close\"\n        title=\"{{ confirmationContext.a11y.close | cxTranslate }}\"\n        [attr.aria-label]=\"confirmationContext.a11y.close | cxTranslate\"\n        (click)=\"dismissModal('Cross click')\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\" />\n        </span>\n      </button>\n    </div>\n\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\">\n      <div class=\"cx-content-container\">\n        <div class=\"cx-name\">\n          <div class=\"cx-heading\">\n            {{ 'quote.confirmDialog.name' | cxTranslate }}\n          </div>\n          <div class=\"cx-content\">\n            {{ confirmationContext.quote.name }}\n          </div>\n        </div>\n        <div\n          class=\"cx-description\"\n          *ngIf=\"confirmationContext.quote.description\"\n        >\n          <div class=\"cx-heading\">\n            {{ 'quote.confirmDialog.description' | cxTranslate }}\n          </div>\n          <div class=\"cx-content\">\n            {{ confirmationContext.quote.description }}\n          </div>\n        </div>\n      </div>\n      <div class=\"cx-notes-container\">\n        <p *ngIf=\"confirmationContext.warningNote\">\n          {{ confirmationContext.warningNote | cxTranslate }}\n        </p>\n        <p\n          *ngIf=\"\n            confirmationContext.validity &&\n            confirmationContext.quote.expirationTime\n          \"\n        >\n          {{\n            confirmationContext.validity\n              | cxTranslate\n                : {\n                    expirationTime:\n                      confirmationContext.quote.expirationTime | cxDate,\n                  }\n          }}\n        </p>\n        <p>\n          {{ confirmationContext.confirmNote | cxTranslate }}\n        </p>\n      </div>\n      <div class=\"cx-buttons-container\">\n        <button class=\"btn btn-secondary\" (click)=\"dismissModal('no')\">\n          {{ 'quote.confirmDialog.option.no' | cxTranslate }}\n        </button>\n        <button class=\"btn btn-primary\" (click)=\"dismissModal('yes')\">\n          {{ 'quote.confirmDialog.option.yes' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n\n    <!-- For screen reader purposes (not visual)-->\n    <div\n      class=\"cx-visually-hidden\"\n      aria-live=\"polite\"\n      role=\"alert\"\n      aria-atomic=\"true\"\n    >\n      {{ getA11yModalText(confirmationContext) }}\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultQuoteActionDialogConfig = {
    launch: {
        QUOTE_ACTION_CONFIRMATION: {
            inline: true,
            component: QuoteConfirmDialogComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteConfirmDialogModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteConfirmDialogModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QuoteConfirmDialogModule, imports: [CommonModule,
            I18nModule,
            UrlModule,
            IconModule,
            FormsModule,
            ReactiveFormsModule,
            FormErrorsModule,
            RouterModule,
            KeyboardFocusModule,
            SpinnerModule,
            FeaturesConfigModule,
            QuoteConfirmDialogComponent], exports: [QuoteConfirmDialogComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteConfirmDialogModule, providers: [provideDefaultConfig(defaultQuoteActionDialogConfig)], imports: [CommonModule,
            I18nModule,
            UrlModule,
            IconModule,
            FormsModule,
            ReactiveFormsModule,
            FormErrorsModule,
            RouterModule,
            KeyboardFocusModule,
            SpinnerModule,
            FeaturesConfigModule,
            QuoteConfirmDialogComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteConfirmDialogModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        UrlModule,
                        IconModule,
                        FormsModule,
                        ReactiveFormsModule,
                        FormErrorsModule,
                        RouterModule,
                        KeyboardFocusModule,
                        SpinnerModule,
                        FeaturesConfigModule,
                        QuoteConfirmDialogComponent,
                    ],
                    providers: [provideDefaultConfig(defaultQuoteActionDialogConfig)],
                    exports: [QuoteConfirmDialogComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteHeaderBuyerEditComponent {
    constructor() {
        this.iconTypes = ICON_TYPE;
        this.editForm = new FormGroup({});
        this.saveCard = new EventEmitter();
        this.cancelCard = new EventEmitter();
        this.featureToggles = inject(FeatureToggles);
        this.enablePurchaseOrderNumber = this.featureToggles.enableQuotePurchaseOrderNumber;
    }
    /**
     * Cancels the view of the edit card tile.
     */
    cancel() {
        this.cancelCard.emit();
    }
    /**
     * Saves the edited card tile by throwing the save event
     * with the edit mode set to 'false' and the edited data.
     */
    save() {
        const event = {};
        Object.keys(this.editForm.controls).forEach((control) => {
            if (this.editForm.get(control)?.dirty) {
                const value = this.editForm.get(control)?.value;
                Object.defineProperty(event, control, {
                    value: value,
                });
            }
        });
        this.saveCard.emit(event);
    }
    getCharactersLeft(formControlName, charactersLimit) {
        return (charactersLimit - (this.editForm.get(formControlName)?.value?.length || 0));
    }
    defineFormControl(formControlName, value) {
        this.editForm.addControl(formControlName, new FormControl(null));
        this.editForm.get(formControlName)?.setValue(value);
    }
    ngOnInit() {
        this.defineFormControl('name', this.content.name);
        this.defineFormControl('description', this.content.description);
        if (this.enablePurchaseOrderNumber) {
            this.defineFormControl('purchaseOrderNumber', this.content.purchaseOrderNumber ?? '');
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteHeaderBuyerEditComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: QuoteHeaderBuyerEditComponent, isStandalone: true, selector: "cx-quote-header-buyer-edit", inputs: { content: "content" }, outputs: { saveCard: "saveCard", cancelCard: "cancelCard" }, ngImport: i0, template: "<div *ngIf=\"content\" class=\"cx-card\">\n  <!-- Card Body -->\n  <div class=\"card-body cx-card-body cx-card-edit\">\n    <!-- Card title -->\n    <span class=\"cx-card-title\">\n      {{ 'quote.header.overview.information' | cxTranslate }}\n    </span>\n    <!-- Card Content -->\n    <div class=\"cx-card-container\">\n      <!-- Card Label -->\n      <div class=\"cx-card-label-container\">\n        <form [formGroup]=\"editForm\">\n          <div class=\"cx-card-paragraph\">\n            <div\n              class=\"cx-card-paragraph-title\"\n              id=\"cx-quote-header-buyer-edit-name\"\n            >\n              {{ 'quote.header.overview.name' | cxTranslate }}\n            </div>\n            <div class=\"form-group\">\n              <input\n                aria-labelledby=\"cx-quote-header-buyer-edit-name\"\n                class=\"form-control\"\n                [maxLength]=\"content.charactersLimit\"\n                type=\"text\"\n                name=\"name\"\n                formControlName=\"name\"\n              />\n              <ng-container\n                *ngTemplateOutlet=\"\n                  showInfoText;\n                  context: {\n                    formControlName: 'name',\n                    charactersLimit: content.charactersLimit,\n                  }\n                \"\n              />\n            </div>\n          </div>\n          <div class=\"cx-card-paragraph\">\n            <div\n              class=\"cx-card-paragraph-title\"\n              id=\"cx-quote-header-buyer-edit-description\"\n            >\n              {{ 'quote.header.overview.description' | cxTranslate }}\n            </div>\n            <div class=\"form-group\">\n              <textarea\n                aria-labelledby=\"cx-quote-header-buyer-edit-description\"\n                class=\"form-control\"\n                [maxLength]=\"content.charactersLimit\"\n                rows=\"4\"\n                name=\"description\"\n                formControlName=\"description\"\n              ></textarea>\n              <ng-container\n                *ngTemplateOutlet=\"\n                  showInfoText;\n                  context: {\n                    formControlName: 'description',\n                    charactersLimit: content.charactersLimit,\n                  }\n                \"\n              />\n            </div>\n          </div>\n          <div class=\"cx-card-paragraph\" *ngIf=\"enablePurchaseOrderNumber\">\n            <div\n              class=\"cx-card-paragraph-title\"\n              id=\"cx-quote-header-buyer-edit-purchase-order-number\"\n            >\n              {{ 'quote.header.overview.purchaseOrderNumber' | cxTranslate }}\n              ({{ 'quote.header.overview.optional' | cxTranslate }})\n            </div>\n            <div class=\"form-group\">\n              <input\n                aria-labelledby=\"cx-quote-header-buyer-edit-purchase-order-number\"\n                class=\"form-control\"\n                type=\"text\"\n                name=\"purchaseOrderNumber\"\n                formControlName=\"purchaseOrderNumber\"\n              />\n            </div>\n          </div>\n        </form>\n      </div>\n    </div>\n    <!-- Edit Mode Actions -->\n    <div class=\"cx-card-button-container\">\n      <button\n        [attr.aria-label]=\"'quote.header.buyerEdit.a11y.cancel' | cxTranslate\"\n        class=\"btn btn-tertiary\"\n        (click)=\"cancel()\"\n      >\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n      <button\n        [attr.aria-label]=\"'quote.header.buyerEdit.a11y.save' | cxTranslate\"\n        class=\"btn btn-block btn-secondary\"\n        (click)=\"save()\"\n      >\n        {{ 'common.save' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n\n<ng-template\n  #showInfoText\n  let-formControlName=\"formControlName\"\n  let-charactersLimit=\"charactersLimit\"\n>\n  <p *ngIf=\"charactersLimit\" class=\"cx-info-text\">\n    {{\n      'quote.header.overview.charactersLeft'\n        | cxTranslate\n          : {\n              count: getCharactersLeft(formControlName, charactersLimit),\n            }\n    }}\n  </p>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteHeaderBuyerEditComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-quote-header-buyer-edit', imports: [
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        NgTemplateOutlet,
                        TranslatePipe,
                    ], template: "<div *ngIf=\"content\" class=\"cx-card\">\n  <!-- Card Body -->\n  <div class=\"card-body cx-card-body cx-card-edit\">\n    <!-- Card title -->\n    <span class=\"cx-card-title\">\n      {{ 'quote.header.overview.information' | cxTranslate }}\n    </span>\n    <!-- Card Content -->\n    <div class=\"cx-card-container\">\n      <!-- Card Label -->\n      <div class=\"cx-card-label-container\">\n        <form [formGroup]=\"editForm\">\n          <div class=\"cx-card-paragraph\">\n            <div\n              class=\"cx-card-paragraph-title\"\n              id=\"cx-quote-header-buyer-edit-name\"\n            >\n              {{ 'quote.header.overview.name' | cxTranslate }}\n            </div>\n            <div class=\"form-group\">\n              <input\n                aria-labelledby=\"cx-quote-header-buyer-edit-name\"\n                class=\"form-control\"\n                [maxLength]=\"content.charactersLimit\"\n                type=\"text\"\n                name=\"name\"\n                formControlName=\"name\"\n              />\n              <ng-container\n                *ngTemplateOutlet=\"\n                  showInfoText;\n                  context: {\n                    formControlName: 'name',\n                    charactersLimit: content.charactersLimit,\n                  }\n                \"\n              />\n            </div>\n          </div>\n          <div class=\"cx-card-paragraph\">\n            <div\n              class=\"cx-card-paragraph-title\"\n              id=\"cx-quote-header-buyer-edit-description\"\n            >\n              {{ 'quote.header.overview.description' | cxTranslate }}\n            </div>\n            <div class=\"form-group\">\n              <textarea\n                aria-labelledby=\"cx-quote-header-buyer-edit-description\"\n                class=\"form-control\"\n                [maxLength]=\"content.charactersLimit\"\n                rows=\"4\"\n                name=\"description\"\n                formControlName=\"description\"\n              ></textarea>\n              <ng-container\n                *ngTemplateOutlet=\"\n                  showInfoText;\n                  context: {\n                    formControlName: 'description',\n                    charactersLimit: content.charactersLimit,\n                  }\n                \"\n              />\n            </div>\n          </div>\n          <div class=\"cx-card-paragraph\" *ngIf=\"enablePurchaseOrderNumber\">\n            <div\n              class=\"cx-card-paragraph-title\"\n              id=\"cx-quote-header-buyer-edit-purchase-order-number\"\n            >\n              {{ 'quote.header.overview.purchaseOrderNumber' | cxTranslate }}\n              ({{ 'quote.header.overview.optional' | cxTranslate }})\n            </div>\n            <div class=\"form-group\">\n              <input\n                aria-labelledby=\"cx-quote-header-buyer-edit-purchase-order-number\"\n                class=\"form-control\"\n                type=\"text\"\n                name=\"purchaseOrderNumber\"\n                formControlName=\"purchaseOrderNumber\"\n              />\n            </div>\n          </div>\n        </form>\n      </div>\n    </div>\n    <!-- Edit Mode Actions -->\n    <div class=\"cx-card-button-container\">\n      <button\n        [attr.aria-label]=\"'quote.header.buyerEdit.a11y.cancel' | cxTranslate\"\n        class=\"btn btn-tertiary\"\n        (click)=\"cancel()\"\n      >\n        {{ 'common.cancel' | cxTranslate }}\n      </button>\n      <button\n        [attr.aria-label]=\"'quote.header.buyerEdit.a11y.save' | cxTranslate\"\n        class=\"btn btn-block btn-secondary\"\n        (click)=\"save()\"\n      >\n        {{ 'common.save' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</div>\n\n<ng-template\n  #showInfoText\n  let-formControlName=\"formControlName\"\n  let-charactersLimit=\"charactersLimit\"\n>\n  <p *ngIf=\"charactersLimit\" class=\"cx-info-text\">\n    {{\n      'quote.header.overview.charactersLeft'\n        | cxTranslate\n          : {\n              count: getCharactersLeft(formControlName, charactersLimit),\n            }\n    }}\n  </p>\n</ng-template>\n" }]
        }], propDecorators: { saveCard: [{
                type: Output
            }], cancelCard: [{
                type: Output
            }], content: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteHeaderBuyerEditModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteHeaderBuyerEditModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QuoteHeaderBuyerEditModule, imports: [CommonModule,
            I18nModule,
            IconModule,
            KeyboardFocusModule,
            ReactiveFormsModule,
            QuoteHeaderBuyerEditComponent], exports: [QuoteHeaderBuyerEditComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteHeaderBuyerEditModule, imports: [CommonModule,
            I18nModule,
            IconModule,
            KeyboardFocusModule,
            ReactiveFormsModule,
            QuoteHeaderBuyerEditComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteHeaderBuyerEditModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        IconModule,
                        KeyboardFocusModule,
                        ReactiveFormsModule,
                        QuoteHeaderBuyerEditComponent,
                    ],
                    exports: [QuoteHeaderBuyerEditComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteHeaderOverviewComponent {
    constructor() {
        this.quoteFacade = inject(QuoteFacade);
        this.eventService = inject(EventService);
        this.translationService = inject(TranslationService);
        this.quoteUIConfig = inject(QuoteUIConfig);
        this.featureToggles = inject(FeatureToggles);
        this.quoteDetails$ = this.quoteFacade.getQuoteDetails();
        this.iconTypes = ICON_TYPE;
        this.editMode = false;
        this.enablePurchaseOrderNumber = this.featureToggles.enableQuotePurchaseOrderNumber;
    }
    static { this.NO_DATA = '-'; }
    static { this.CHARACTERS_LIMIT = 255; }
    static { this.DEFAULT_CARD_TILE_MAX_CHARS = 100; }
    defineQuoteMetaData(event) {
        let metaData = {};
        if (Object.getOwnPropertyNames(event).length >= 1) {
            const { name, description, purchaseOrderNumber } = event;
            metaData = {
                ...metaData,
                ...(event.name && { name }),
                ...{ description },
                ...(event.purchaseOrderNumber && {
                    sapPurchaseOrderNumber: purchaseOrderNumber,
                }),
            };
        }
        return metaData;
    }
    /**
     * Verifies whether the quote is editable and is viewed from a user acting as buyer.
     *
     * @param quote - quote
     * @returns if the quote is editable and its state is 'QuoteState.BUYER_DRAFT' or 'QuoteState.BUYER_OFFER', otherwise returns 'false'.
     */
    isQuoteEditableForBuyer(quote) {
        return (quote.isEditable &&
            (quote.state === QuoteState.BUYER_DRAFT ||
                quote.state === QuoteState.BUYER_OFFER));
    }
    /**
     * Cancels the view of the edit card tile
     * by setting the edit mode to 'false'.
     */
    cancel() {
        this.editMode = false;
    }
    /**
     * Saves the edited card tile.
     *
     * @param quote - Quote
     * @param event - edit event
     */
    save(quote, event) {
        this.editMode = false;
        const metaData = this.defineQuoteMetaData(event);
        if (Object.getOwnPropertyNames(metaData).length >= 1) {
            this.quoteFacade.editQuote(quote.code, metaData);
        }
    }
    /**
     * Toggles the edit mode.
     */
    toggleEditMode() {
        this.editMode = !this.editMode;
    }
    /**
     * Retrieves the card content that represents the quote information with its name and description.
     *
     * @param name - Quote name
     * @param description - Quote description
     * @returns Observable emitting a card content
     */
    getQuoteInformation(name, description, purchaseOrderNumber) {
        return combineLatest([
            this.translationService.translate('quote.header.overview.information'),
            this.translationService.translate('quote.header.overview.name'),
            this.translationService.translate('quote.header.overview.description'),
            this.translationService.translate('quote.header.overview.purchaseOrderNumber'),
        ]).pipe(map(([infoTitle, nameTitle, descriptionTitle, purchaseOrderNumberTitle,]) => {
            return {
                title: infoTitle,
                paragraphs: [
                    {
                        title: nameTitle,
                        text: [name ?? QuoteHeaderOverviewComponent.NO_DATA],
                    },
                    {
                        title: descriptionTitle,
                        text: [description ?? QuoteHeaderOverviewComponent.NO_DATA],
                    },
                    ...(this.enablePurchaseOrderNumber
                        ? [
                            {
                                title: purchaseOrderNumberTitle,
                                text: [
                                    purchaseOrderNumber ??
                                        QuoteHeaderOverviewComponent.NO_DATA,
                                ],
                            },
                        ]
                        : []),
                ],
            };
        }));
    }
    /**
     * Retrieves the edit card content that represents the edit quote information with its name and description.
     *
     * @param name - Quote name
     * @param description - Quote description
     * @returns Observable emitting an edit card content
     */
    getEditQuoteInformation(name, description, purchaseOrderNumber) {
        return {
            name: name,
            description: description,
            charactersLimit: QuoteHeaderOverviewComponent.CHARACTERS_LIMIT,
            ...(this.enablePurchaseOrderNumber && purchaseOrderNumber
                ? { purchaseOrderNumber }
                : {}),
        };
    }
    /**
     * Retrieves the card content that represents the estimated total and expiry date information.
     *
     * @param quote - Quote
     * @param expiryDate -  Expiry date
     * @returns Observable emitting a card content
     */
    getEstimatedTotalAndExpiryDate(quote, expiryDate) {
        return combineLatest([
            this.translationService.translate('quote.header.overview.priceAndExpiry'),
            this.translationService.translate(this.getTotalPriceDescription(quote)),
            this.translationService.translate('quote.header.overview.expirationTime'),
        ]).pipe(map(([firstTitle, secondTitle, thirdTitle]) => {
            return {
                title: firstTitle,
                paragraphs: [
                    {
                        title: secondTitle,
                        text: [
                            this.getTotalPrice(quote) ??
                                QuoteHeaderOverviewComponent.NO_DATA,
                        ],
                    },
                    {
                        title: thirdTitle,
                        text: [expiryDate ?? QuoteHeaderOverviewComponent.NO_DATA],
                    },
                ],
            };
        }));
    }
    /**
     * Retrieves the card content that represents the created and last updated dates.
     *
     * @param createdDate - Created date
     * @param lastUpdatedDate - Last updated date
     * @returns Observable emitting a card content
     */
    getCreatedAndUpdatedDates(createdDate, lastUpdatedDate) {
        return combineLatest([
            this.translationService.translate('quote.header.overview.createdAndUpdated'),
            this.translationService.translate('quote.header.overview.createdDate'),
            this.translationService.translate('quote.header.overview.lastUpdatedDate'),
        ]).pipe(map(([firstTitle, secondTitle, thirdTitle]) => {
            return {
                title: firstTitle,
                paragraphs: [
                    {
                        title: secondTitle,
                        text: [createdDate ?? QuoteHeaderOverviewComponent.NO_DATA],
                    },
                    {
                        title: thirdTitle,
                        text: [lastUpdatedDate ?? QuoteHeaderOverviewComponent.NO_DATA],
                    },
                ],
            };
        }));
    }
    /**
     * Retrieves a characters limit for a card tile.
     * If the card tile contains more characters, they will be truncated.
     *
     * @returns characters limit for a card tile
     */
    getCharactersLimitForCardTile() {
        return (this.quoteUIConfig.quote?.truncateCardTileContentAfterNumChars ??
            QuoteHeaderOverviewComponent.DEFAULT_CARD_TILE_MAX_CHARS);
    }
    /**
     * Returns total price as formatted string.
     *
     * @param quote - Quote
     * @returns Total price formatted format, null if that is not available
     * @protected
     */
    getTotalPrice(quote) {
        return quote.totalPrice.formattedValue ?? null;
    }
    /**
     * Returns total price description.
     *
     * @param quote - Quote
     * @returns 'Total' price if quote is in final state, 'Estimated total' otherwise
     * @protected
     */
    getTotalPriceDescription(quote) {
        const readyToSubmit = quote.allowedActions?.find((action) => action.type === QuoteActionType.CHECKOUT);
        return readyToSubmit
            ? 'quote.header.overview.total'
            : 'quote.header.overview.estimatedTotal';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteHeaderOverviewComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: QuoteHeaderOverviewComponent, isStandalone: true, selector: "cx-quote-header-overview", ngImport: i0, template: "<ng-container *ngIf=\"quoteDetails$ | async as quoteDetails; else ghostDetails\">\n  <div\n    role=\"region\"\n    tabindex=\"-1\"\n    [attr.aria-label]=\"'quote.header.overview.regionTitle' | cxTranslate\"\n  >\n    <div class=\"cx-header-container\">\n      <h2 class=\"cx-header\">\n        {{ 'quote.header.overview.id' | cxTranslate }}:\n        {{ quoteDetails.code }}\n      </h2>\n      <h2 class=\"cx-status\">\n        {{ 'quote.header.overview.status' | cxTranslate }}:\n        {{ 'quote.states.' + quoteDetails.state | cxTranslate }}\n      </h2>\n    </div>\n    <div class=\"cx-container\">\n      <div class=\"cx-summary-card\">\n        <ng-container *ngIf=\"!editMode\">\n          <cx-card\n            [content]=\"\n              getQuoteInformation(\n                quoteDetails.name,\n                quoteDetails.description,\n                quoteDetails.sapPurchaseOrderNumber\n              ) | async\n            \"\n            [truncateParagraphText]=\"true\"\n            [charactersLimit]=\"getCharactersLimitForCardTile()\"\n          />\n          <button\n            [attr.aria-label]=\"'quote.header.overview.a11y.edit' | cxTranslate\"\n            [attr.title]=\"'quote.header.overview.a11y.edit' | cxTranslate\"\n            *ngIf=\"isQuoteEditableForBuyer(quoteDetails)\"\n            class=\"link cx-action-link cx-edit-btn\"\n            (click)=\"toggleEditMode()\"\n          >\n            <cx-icon [type]=\"iconTypes.PENCIL\" />\n          </button>\n        </ng-container>\n        <cx-quote-header-buyer-edit\n          *ngIf=\"editMode\"\n          [content]=\"\n            getEditQuoteInformation(\n              quoteDetails.name,\n              quoteDetails.description,\n              quoteDetails.sapPurchaseOrderNumber\n            )\n          \"\n          (saveCard)=\"save(quoteDetails, $event)\"\n          (cancelCard)=\"cancel()\"\n        />\n      </div>\n      <div class=\"cx-summary-card\">\n        <cx-card\n          [content]=\"\n            getEstimatedTotalAndExpiryDate(\n              quoteDetails,\n              quoteDetails.expirationTime | cxDate\n            ) | async\n          \"\n        />\n      </div>\n      <div class=\"cx-summary-card\">\n        <cx-card\n          [content]=\"\n            getCreatedAndUpdatedDates(\n              quoteDetails.creationTime | cxDate,\n              quoteDetails.updatedTime | cxDate\n            ) | async\n          \"\n        />\n      </div>\n    </div>\n  </div>\n</ng-container>\n\n<ng-template #ghostDetails>\n  <div class=\"cx-ghost-heading\">\n    <div class=\"cx-ghost-column\">\n      <div class=\"cx-ghost-header ghost\"></div>\n      <div class=\"cx-ghost-status ghost\"></div>\n    </div>\n  </div>\n  <div class=\"cx-ghost-cards\">\n    <div class=\"cx-ghost-row\">\n      <ng-container *ngFor=\"let number of [0, 1, 2]\">\n        <div class=\"cx-ghost-card ghost\"></div>\n      </ng-container>\n    </div>\n  </div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CardComponent, selector: "cx-card", inputs: ["border", "editMode", "isDefault", "content", "fitToContainer", "truncateText", "truncateParagraphText", "charactersLimit", "index", "role"], outputs: ["deleteCard", "setDefaultCard", "sendCard", "editCard", "cancelCard"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "component", type: QuoteHeaderBuyerEditComponent, selector: "cx-quote-header-buyer-edit", inputs: ["content"], outputs: ["saveCard", "cancelCard"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: CxDatePipe, name: "cxDate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteHeaderOverviewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-quote-header-overview', imports: [
                        NgIf,
                        CardComponent,
                        IconComponent,
                        QuoteHeaderBuyerEditComponent,
                        NgFor,
                        AsyncPipe,
                        TranslatePipe,
                        CxDatePipe,
                    ], template: "<ng-container *ngIf=\"quoteDetails$ | async as quoteDetails; else ghostDetails\">\n  <div\n    role=\"region\"\n    tabindex=\"-1\"\n    [attr.aria-label]=\"'quote.header.overview.regionTitle' | cxTranslate\"\n  >\n    <div class=\"cx-header-container\">\n      <h2 class=\"cx-header\">\n        {{ 'quote.header.overview.id' | cxTranslate }}:\n        {{ quoteDetails.code }}\n      </h2>\n      <h2 class=\"cx-status\">\n        {{ 'quote.header.overview.status' | cxTranslate }}:\n        {{ 'quote.states.' + quoteDetails.state | cxTranslate }}\n      </h2>\n    </div>\n    <div class=\"cx-container\">\n      <div class=\"cx-summary-card\">\n        <ng-container *ngIf=\"!editMode\">\n          <cx-card\n            [content]=\"\n              getQuoteInformation(\n                quoteDetails.name,\n                quoteDetails.description,\n                quoteDetails.sapPurchaseOrderNumber\n              ) | async\n            \"\n            [truncateParagraphText]=\"true\"\n            [charactersLimit]=\"getCharactersLimitForCardTile()\"\n          />\n          <button\n            [attr.aria-label]=\"'quote.header.overview.a11y.edit' | cxTranslate\"\n            [attr.title]=\"'quote.header.overview.a11y.edit' | cxTranslate\"\n            *ngIf=\"isQuoteEditableForBuyer(quoteDetails)\"\n            class=\"link cx-action-link cx-edit-btn\"\n            (click)=\"toggleEditMode()\"\n          >\n            <cx-icon [type]=\"iconTypes.PENCIL\" />\n          </button>\n        </ng-container>\n        <cx-quote-header-buyer-edit\n          *ngIf=\"editMode\"\n          [content]=\"\n            getEditQuoteInformation(\n              quoteDetails.name,\n              quoteDetails.description,\n              quoteDetails.sapPurchaseOrderNumber\n            )\n          \"\n          (saveCard)=\"save(quoteDetails, $event)\"\n          (cancelCard)=\"cancel()\"\n        />\n      </div>\n      <div class=\"cx-summary-card\">\n        <cx-card\n          [content]=\"\n            getEstimatedTotalAndExpiryDate(\n              quoteDetails,\n              quoteDetails.expirationTime | cxDate\n            ) | async\n          \"\n        />\n      </div>\n      <div class=\"cx-summary-card\">\n        <cx-card\n          [content]=\"\n            getCreatedAndUpdatedDates(\n              quoteDetails.creationTime | cxDate,\n              quoteDetails.updatedTime | cxDate\n            ) | async\n          \"\n        />\n      </div>\n    </div>\n  </div>\n</ng-container>\n\n<ng-template #ghostDetails>\n  <div class=\"cx-ghost-heading\">\n    <div class=\"cx-ghost-column\">\n      <div class=\"cx-ghost-header ghost\"></div>\n      <div class=\"cx-ghost-status ghost\"></div>\n    </div>\n  </div>\n  <div class=\"cx-ghost-cards\">\n    <div class=\"cx-ghost-row\">\n      <ng-container *ngFor=\"let number of [0, 1, 2]\">\n        <div class=\"cx-ghost-card ghost\"></div>\n      </ng-container>\n    </div>\n  </div>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteHeaderOverviewModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteHeaderOverviewModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QuoteHeaderOverviewModule, imports: [CommonModule,
            I18nModule,
            IconModule,
            CardModule,
            QuoteHeaderBuyerEditModule,
            KeyboardFocusModule,
            QuoteHeaderOverviewComponent], exports: [QuoteHeaderOverviewComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteHeaderOverviewModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    QuoteHeaderOverviewComponent: {
                        component: QuoteHeaderOverviewComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            IconModule,
            CardModule,
            QuoteHeaderBuyerEditModule,
            KeyboardFocusModule,
            QuoteHeaderOverviewComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteHeaderOverviewModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        IconModule,
                        CardModule,
                        QuoteHeaderBuyerEditModule,
                        KeyboardFocusModule,
                        QuoteHeaderOverviewComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                QuoteHeaderOverviewComponent: {
                                    component: QuoteHeaderOverviewComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                    ],
                    exports: [QuoteHeaderOverviewComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Renders quote items. These items are either taken from the actual quote,
 * or from the attached quote cart.
 * Specifically if the quote is editable, changes to the entries will be
 * done by changing the attached quote cart's entries.
 *
 * Note that the component makes use of outlet CART_ITEM_LIST in order to
 * render the quote entries. The default implementation of this outlet is
 * in feature lib 'cartBase'. This lib is always loaded, because
 * quoteFacade.getQuoteDetails() always triggers activeCartFacade for checking
 * on the quote/cart link.
 */
class QuoteItemsComponent {
    constructor() {
        this.quoteItemsComponentService = inject(QuoteItemsComponentService);
        this.quoteItemsData$ = this.quoteItemsComponentService.retrieveQuoteEntries();
        this.showCart$ = this.quoteItemsComponentService.getQuoteEntriesExpanded();
        this.iconTypes = ICON_TYPE;
        this.cartOutlets = CartOutlets;
        this.abstractOrderType = AbstractOrderType;
    }
    /**
     * Handler to toggle expanded state of quote entries section.
     *
     * @param showCart - current expanded state, will be inverted
     */
    onToggleShowOrHideCart(showCart) {
        this.quoteItemsComponentService.setQuoteEntriesExpanded(!showCart);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteItemsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: QuoteItemsComponent, isStandalone: true, selector: "cx-quote-items", ngImport: i0, template: "<ng-container *ngIf=\"quoteItemsData$ | async as quoteItemsData; else ghostCart\">\n  <ng-container *ngIf=\"{ showCart: showCart$ | async } as state\">\n    <div\n      role=\"region\"\n      tabindex=\"-1\"\n      [attr.aria-label]=\"'quote.items.regionTitle' | cxTranslate\"\n    >\n      <div\n        class=\"cx-toggle\"\n        #cartToggle\n        (keydown.enter)=\"cartToggle.click()\"\n        (click)=\"onToggleShowOrHideCart(!!state.showCart)\"\n        tabindex=\"0\"\n      >\n        <cx-icon\n          aria-hidden=\"false\"\n          [type]=\"state.showCart ? iconTypes.CARET_UP : iconTypes.CARET_DOWN\"\n        />\n        <span class=\"cx-text\">{{ 'quote.commons.cart' | cxTranslate }}</span>\n      </div>\n      <ng-container *ngIf=\"state.showCart\">\n        <ng-template\n          [cxAbstractOrderContext]=\"{\n            id: quoteItemsData.abstractOrderId,\n            type: quoteItemsData.abstractOrderType,\n          }\"\n          [cxOutlet]=\"cartOutlets.CART_ITEM_LIST\"\n          [cxOutletContext]=\"{\n            items: quoteItemsData.entries ?? [],\n            readonly: quoteItemsData.readOnly,\n          }\"\n        />\n      </ng-container>\n    </div>\n  </ng-container>\n</ng-container>\n\n<ng-template #ghostCart>\n  <div class=\"cx-ghost-table-header\">\n    <div class=\"cx-ghost-title ghost\"></div>\n  </div>\n  <div class=\"cx-ghost-table\">\n    <ng-container *ngFor=\"let number of [0, 1, 2, 3, 4]\">\n      <div class=\"cx-ghost-row\">\n        <div class=\"cx-ghost-image-container\">\n          <div class=\"cx-ghost-image ghost\"></div>\n        </div>\n        <div class=\"cx-ghost-container\">\n          <div class=\"cx-ghost-info-container\">\n            <ng-container *ngFor=\"let number of [0, 1, 2, 3]\">\n              <div class=\"cx-ghost-info ghost\"></div>\n            </ng-container>\n          </div>\n          <div class=\"cx-ghost-qty ghost\"></div>\n          <div class=\"cx-ghost-total ghost\"></div>\n          <div class=\"cx-ghost-action ghost\"></div>\n        </div>\n      </div>\n    </ng-container>\n  </div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "directive", type: AbstractOrderContextDirective, selector: "[cxAbstractOrderContext]", inputs: ["cxAbstractOrderContext"] }, { kind: "directive", type: OutletDirective, selector: "[cxOutlet]", inputs: ["cxOutlet", "cxOutletContext", "cxOutletDefer", "cxComponentRef"], outputs: ["loaded", "cxComponentRefChange"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteItemsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-quote-items', imports: [
                        NgIf,
                        IconComponent,
                        AbstractOrderContextDirective,
                        OutletDirective,
                        NgFor,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<ng-container *ngIf=\"quoteItemsData$ | async as quoteItemsData; else ghostCart\">\n  <ng-container *ngIf=\"{ showCart: showCart$ | async } as state\">\n    <div\n      role=\"region\"\n      tabindex=\"-1\"\n      [attr.aria-label]=\"'quote.items.regionTitle' | cxTranslate\"\n    >\n      <div\n        class=\"cx-toggle\"\n        #cartToggle\n        (keydown.enter)=\"cartToggle.click()\"\n        (click)=\"onToggleShowOrHideCart(!!state.showCart)\"\n        tabindex=\"0\"\n      >\n        <cx-icon\n          aria-hidden=\"false\"\n          [type]=\"state.showCart ? iconTypes.CARET_UP : iconTypes.CARET_DOWN\"\n        />\n        <span class=\"cx-text\">{{ 'quote.commons.cart' | cxTranslate }}</span>\n      </div>\n      <ng-container *ngIf=\"state.showCart\">\n        <ng-template\n          [cxAbstractOrderContext]=\"{\n            id: quoteItemsData.abstractOrderId,\n            type: quoteItemsData.abstractOrderType,\n          }\"\n          [cxOutlet]=\"cartOutlets.CART_ITEM_LIST\"\n          [cxOutletContext]=\"{\n            items: quoteItemsData.entries ?? [],\n            readonly: quoteItemsData.readOnly,\n          }\"\n        />\n      </ng-container>\n    </div>\n  </ng-container>\n</ng-container>\n\n<ng-template #ghostCart>\n  <div class=\"cx-ghost-table-header\">\n    <div class=\"cx-ghost-title ghost\"></div>\n  </div>\n  <div class=\"cx-ghost-table\">\n    <ng-container *ngFor=\"let number of [0, 1, 2, 3, 4]\">\n      <div class=\"cx-ghost-row\">\n        <div class=\"cx-ghost-image-container\">\n          <div class=\"cx-ghost-image ghost\"></div>\n        </div>\n        <div class=\"cx-ghost-container\">\n          <div class=\"cx-ghost-info-container\">\n            <ng-container *ngFor=\"let number of [0, 1, 2, 3]\">\n              <div class=\"cx-ghost-info ghost\"></div>\n            </ng-container>\n          </div>\n          <div class=\"cx-ghost-qty ghost\"></div>\n          <div class=\"cx-ghost-total ghost\"></div>\n          <div class=\"cx-ghost-action ghost\"></div>\n        </div>\n      </div>\n    </ng-container>\n  </div>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteItemsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteItemsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QuoteItemsModule, imports: [CommonModule,
            OutletModule,
            IconModule,
            I18nModule,
            AbstractOrderContextModule,
            QuoteItemsComponent], exports: [QuoteItemsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteItemsModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    QuoteItemsComponent: {
                        component: QuoteItemsComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            OutletModule,
            IconModule,
            I18nModule,
            AbstractOrderContextModule,
            QuoteItemsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteItemsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        OutletModule,
                        IconModule,
                        I18nModule,
                        AbstractOrderContextModule,
                        QuoteItemsComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                QuoteItemsComponent: {
                                    component: QuoteItemsComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                    ],
                    exports: [QuoteItemsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteLinksComponent {
    constructor() {
        this.quoteFacade = inject(QuoteFacade);
        this.cartUtilsService = inject(CartUtilsService);
        this.eventService = inject(EventService);
        this.fileDownloadService = inject(FileDownloadService);
        this.globalMessageService = inject(GlobalMessageService);
        this.orderConfig = inject(OrderConfig);
        this.quoteDetails$ = this.quoteFacade.getQuoteDetails();
    }
    ngOnInit() {
        // Since the quote details page is cached, we need to make sure to reload the quote details
        this.eventService.dispatch({}, QuoteDetailsReloadQueryEvent);
    }
    /**
     * Creates a new cart and navigates according to the 'cart' route.
     */
    goToNewCart() {
        //since from now on, the active cart deviates from the quote, we need to mark
        //the quote details for reload. Otherwise a browser back won't always work.
        this.eventService.dispatch({}, QuoteDetailsReloadQueryEvent);
        this.cartUtilsService.goToNewCart();
    }
    /**
     * Click handler for download button.
     *
     * @param quoteCode - The quote ID (aka code)
     * @param attachments - Array of attachments belonging to the quote. It is expected to contain only 1 entry.
     */
    onDownloadAttachment(quoteCode, attachments) {
        const attachmentId = attachments[0].id;
        const filename = attachments[0].filename || attachmentId;
        this.quoteFacade.downloadAttachment(quoteCode, attachmentId).subscribe({
            next: (res) => {
                const url = URL.createObjectURL(new Blob([res], { type: res.type }));
                this.fileDownloadService.download(url, `${filename}.pdf`);
            },
            error: () => {
                this.globalMessageService.add({ key: 'quote.httpHandlers.downloadPDFError' }, GlobalMessageType.MSG_TYPE_ERROR);
            },
        });
    }
    /**
     * Determines if there is any document attached with the quote.
     *
     * @param attachments - an array of attachments to the quote
     * @returns - if the document is present, returns 'true', otherwise 'false'.
     */
    hasAttachment(attachments) {
        return attachments?.length > 0;
    }
    /**
     * Determines if the feature for showing the download button is enabled.
     *
     * @returns - if the feature is enabled, returns 'true', otherwise 'false'.
     * @deprecated  This method is obsolete since 2211.41
     */
    isShowDownloadProposalButtonFeatureEnabled() {
        return true;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteLinksComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: QuoteLinksComponent, isStandalone: true, selector: "cx-quote-links", ngImport: i0, template: "<ng-container *ngIf=\"quoteDetails$ | async as quoteDetails\">\n  <section>\n    <ul>\n      <li>\n        <a\n          [attr.aria-label]=\"'quote.links.a11y.newCart' | cxTranslate\"\n          (click)=\"goToNewCart()\"\n          class=\"link cx-action-link\"\n          tabindex=\"0\"\n        >\n          {{ 'quote.links.newCart' | cxTranslate }}\n        </a>\n      </li>\n      <li>\n        <a\n          [attr.aria-label]=\"'quote.links.a11y.quotes' | cxTranslate\"\n          [routerLink]=\"{ cxRoute: 'quotes' } | cxUrl\"\n          class=\"link cx-action-link\"\n        >\n          {{ 'quote.links.quotes' | cxTranslate }}\n        </a>\n      </li>\n      <li *ngIf=\"hasAttachment(quoteDetails.sapAttachments!)\">\n        <button\n          [attr.aria-label]=\"'quote.links.a11y.download' | cxTranslate\"\n          type=\"button\"\n          class=\"link cx-action-link\"\n          (click)=\"\n            onDownloadAttachment(\n              quoteDetails.code,\n              quoteDetails.sapAttachments!\n            )\n          \"\n        >\n          {{ 'quote.links.download' | cxTranslate }}\n        </button>\n      </li>\n      <ng-container *ngIf=\"orderConfig.showOrderQuoteLink\">\n        <li *ngIf=\"quoteDetails.sapOrderCode\">\n          <a\n            [attr.aria-label]=\"'quote.links.a11y.order' | cxTranslate\"\n            class=\"link cx-action-link\"\n            [routerLink]=\"\n              {\n                cxRoute: 'orderDetails',\n                params: { code: quoteDetails.sapOrderCode },\n              } | cxUrl\n            \"\n          >\n            {{ 'quote.links.order' | cxTranslate }}</a\n          >\n        </li>\n      </ng-container>\n    </ul>\n  </section>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteLinksComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-quote-links', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, RouterLink, AsyncPipe, TranslatePipe, UrlPipe], template: "<ng-container *ngIf=\"quoteDetails$ | async as quoteDetails\">\n  <section>\n    <ul>\n      <li>\n        <a\n          [attr.aria-label]=\"'quote.links.a11y.newCart' | cxTranslate\"\n          (click)=\"goToNewCart()\"\n          class=\"link cx-action-link\"\n          tabindex=\"0\"\n        >\n          {{ 'quote.links.newCart' | cxTranslate }}\n        </a>\n      </li>\n      <li>\n        <a\n          [attr.aria-label]=\"'quote.links.a11y.quotes' | cxTranslate\"\n          [routerLink]=\"{ cxRoute: 'quotes' } | cxUrl\"\n          class=\"link cx-action-link\"\n        >\n          {{ 'quote.links.quotes' | cxTranslate }}\n        </a>\n      </li>\n      <li *ngIf=\"hasAttachment(quoteDetails.sapAttachments!)\">\n        <button\n          [attr.aria-label]=\"'quote.links.a11y.download' | cxTranslate\"\n          type=\"button\"\n          class=\"link cx-action-link\"\n          (click)=\"\n            onDownloadAttachment(\n              quoteDetails.code,\n              quoteDetails.sapAttachments!\n            )\n          \"\n        >\n          {{ 'quote.links.download' | cxTranslate }}\n        </button>\n      </li>\n      <ng-container *ngIf=\"orderConfig.showOrderQuoteLink\">\n        <li *ngIf=\"quoteDetails.sapOrderCode\">\n          <a\n            [attr.aria-label]=\"'quote.links.a11y.order' | cxTranslate\"\n            class=\"link cx-action-link\"\n            [routerLink]=\"\n              {\n                cxRoute: 'orderDetails',\n                params: { code: quoteDetails.sapOrderCode },\n              } | cxUrl\n            \"\n          >\n            {{ 'quote.links.order' | cxTranslate }}</a\n          >\n        </li>\n      </ng-container>\n    </ul>\n  </section>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteLinksModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteLinksModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QuoteLinksModule, imports: [CommonModule,
            I18nModule,
            RouterModule,
            UrlModule,
            FeaturesConfigModule,
            QuoteLinksComponent], exports: [QuoteLinksComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteLinksModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    QuoteLinksComponent: {
                        component: QuoteLinksComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            RouterModule,
            UrlModule,
            FeaturesConfigModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteLinksModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        RouterModule,
                        UrlModule,
                        FeaturesConfigModule,
                        QuoteLinksComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                QuoteLinksComponent: {
                                    component: QuoteLinksComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                    ],
                    exports: [QuoteLinksComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteListComponentService {
    constructor() {
        this.quoteFacade = inject(QuoteFacade);
        this.translationService = inject(TranslationService);
        this.defaultSortOption = 'byCode';
        this.sort = new BehaviorSubject(this.defaultSortOption);
        this.currentPage = new BehaviorSubject(0);
        //TODO: temporary solution caused by gaps in the API. Refer to
        //https://jira.tools.sap/browse/CXEC-31715
        this.sortOptions = [
            { code: 'byDate' },
            { code: 'byCode' },
            { code: 'byName' },
            { code: 'byState' },
        ];
        this.quotesState$ = this.quoteFacade
            .getQuotesState({
            currentPage$: this.currentPage
                .asObservable()
                .pipe(distinctUntilChanged()),
            sort$: this.sort.asObservable().pipe(distinctUntilChanged()),
        })
            .pipe(tap((quotesState) => {
            if (quotesState.data?.sorts) {
                this.sortOptions = quotesState.data.sorts;
            }
        }));
        this.sortLabels$ = combineLatest([
            this.translationService.translate('sorting.date'),
            this.translationService.translate('quote.list.quoteId'),
            this.translationService.translate('quote.list.name'),
            this.translationService.translate('quote.list.status'),
        ]).pipe(map(([textByQuoteUpdatedDate, textByQuoteCode, textByQuoteName, textByQuoteStatus,]) => {
            return {
                byDate: textByQuoteUpdatedDate,
                byCode: textByQuoteCode,
                byName: textByQuoteName,
                byState: textByQuoteStatus,
            };
        }));
    }
    /**
     * Sets sorting for quote list.
     *
     * @param sort - Code of desired sort option that will be applied to the quote list
     */
    setSorting(sort) {
        this.sort.next(sort);
    }
    /**
     * Sets current page.
     *
     * @param page - number of page that will be applied to the quote list
     */
    setPage(page) {
        this.currentPage.next(page);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteListComponentService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteListComponentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteListComponentService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteListComponent {
    constructor() {
        this.quoteListComponentService = inject(QuoteListComponentService);
        this.translationService = inject(TranslationService);
        this.cxDatePipe = inject(CxDatePipe);
        this.sorts = this.quoteListComponentService.sortOptions;
        this.sortLabels$ = this.quoteListComponentService.sortLabels$;
        this.quotesState$ = this.quoteListComponentService.quotesState$;
        this.dateFormat = 'medium';
        this.iconTypes = ICON_TYPE;
    }
    ngOnInit() {
        this.changePage(0);
        this.changeSorting(this.quoteListComponentService.defaultSortOption);
    }
    /**
     * Changes current sorting.
     *
     * @param sortCode - Identifies sort option that should be applied
     */
    changeSorting(sortCode) {
        this.quoteListComponentService.setSorting(sortCode);
    }
    /**
     * Changes current page.
     *
     * @param page - Desired page number
     */
    changePage(page) {
        this.quoteListComponentService.setPage(page);
    }
    /**
     * Retrieves the class name for the quote state. This class name is composed
     * using 'quote-' as prefix and the last part of the status name in lower case
     * (like e.g. draft for SELLER_DRAFT).
     *
     * @param state - quote state
     * @returns class name corresponding to quote state.
     */
    getQuoteStateClass(state) {
        const stateAsString = state.toString();
        const indexSeparator = stateAsString.indexOf('_');
        //note: in case not found: indexSeparator is -1, lastPart will be stateAsString
        const lastPart = stateAsString.substring(indexSeparator + 1);
        return 'quote-' + lastPart.toLowerCase();
    }
    isPaginationEnabled(pagination) {
        return pagination.totalPages !== undefined && pagination.totalPages > 1;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: QuoteListComponent, isStandalone: true, selector: "cx-quote-list", providers: [CxDatePipe], ngImport: i0, template: "<ng-container *ngIf=\"quotesState$ | async as quotesState; else ghostList\">\n  <div\n    role=\"region\"\n    tabindex=\"-1\"\n    [attr.aria-label]=\"'quote.list.regionTitle' | cxTranslate\"\n  >\n    <ng-container *ngIf=\"quotesState.data; else ghostList\">\n      <ng-container\n        *ngIf=\"\n          quotesState.data.quotes && quotesState.data.quotes.length > 0;\n          else emptyQuoteList\n        \"\n      >\n        <div class=\"cx-sort top\">\n          <label class=\"cx-form-group form-group\"\n            ><span class=\"sortBy-heading\">\n              {{ 'quote.list.sortBy' | cxTranslate }}\n            </span>\n            <cx-sorting\n              [sortOptions]=\"sorts\"\n              [sortLabels]=\"sortLabels$ | async\"\n              (sortListEvent)=\"changeSorting($event)\"\n              [selectedOption]=\"quotesState.data.pagination.sort\"\n              placeholder=\"{{ 'quote.list.sortBy' | cxTranslate }}\"\n              [ariaLabel]=\"'quote.list.sortQuotes' | cxTranslate\"\n              ariaControls=\"quote-list\"\n            />\n          </label>\n          <ng-container\n            *ngIf=\"isPaginationEnabled(quotesState.data.pagination)\"\n          >\n            <cx-pagination\n              [pagination]=\"quotesState.data.pagination\"\n              (viewPageEvent)=\"changePage($event)\"\n              paginationID=\"pagination-top\"\n            />\n          </ng-container>\n        </div>\n        <table id=\"quote-list\" role=\"table\" aria-describedby=\"quote-list-desc\">\n          <caption id=\"quote-list-desc\" class=\"cx-visually-hidden\">\n            {{\n              'quote.list.title' | cxTranslate\n            }}\n          </caption>\n          <thead role=\"rowgroup\">\n            <tr role=\"row\">\n              <th role=\"columnheader\" aria-sort=\"none\">\n                {{ 'quote.list.name' | cxTranslate }}\n              </th>\n              <th role=\"columnheader\" aria-sort=\"none\">\n                {{ 'quote.header.overview.id' | cxTranslate }}\n              </th>\n              <th role=\"columnheader\" aria-sort=\"none\">\n                {{ 'quote.header.overview.status' | cxTranslate }}\n              </th>\n              <th role=\"columnheader\" aria-sort=\"none\">\n                {{ 'quote.list.updated' | cxTranslate }}\n              </th>\n              <th></th>\n            </tr>\n          </thead>\n          <tbody role=\"rowgroup\">\n            <tr\n              role=\"row\"\n              #row\n              *ngFor=\"let quote of quotesState.data.quotes\"\n              [routerLink]=\"\n                {\n                  cxRoute: 'quoteDetails',\n                  params: { quoteId: quote.code },\n                } | cxUrl\n              \"\n              (keydown.enter)=\"row.click()\"\n              attr.aria-label=\"{{ 'quote.list.name' | cxTranslate }}: {{\n                quote.name\n              }} {{ 'quote.header.overview.id' | cxTranslate }}: {{\n                quote.code\n              }} {{ 'quote.header.overview.status' | cxTranslate }}: {{\n                'quote.states.' + quote.state | cxTranslate\n              }} {{ 'quote.list.updated' | cxTranslate }}: {{\n                quote?.updatedTime | cxDate: dateFormat\n              }} {{ 'quote.list.clickableRow' | cxTranslate }}\"\n              attr.title=\"{{ quote.name }}\"\n            >\n              <td role=\"cell\" class=\"cx-name\">\n                <div class=\"cx-mobile-header\">\n                  {{ 'quote.list.name' | cxTranslate }}\n                </div>\n                <span aria-hidden=\"true\">{{ quote.name }}</span>\n              </td>\n              <td role=\"cell\" class=\"cx-code\">\n                <div class=\"cx-mobile-header\">\n                  {{ 'quote.header.overview.id' | cxTranslate }}\n                </div>\n                <span aria-hidden=\"true\">{{ quote.code }}</span>\n              </td>\n              <td role=\"cell\" class=\"cx-status\">\n                <div class=\"cx-mobile-header\">\n                  {{ 'quote.header.overview.status' | cxTranslate }}\n                </div>\n                <span\n                  aria-hidden=\"true\"\n                  [ngClass]=\"getQuoteStateClass(quote.state)\"\n                  >{{ 'quote.states.' + quote.state | cxTranslate }}</span\n                >\n              </td>\n              <td role=\"cell\" class=\"cx-updated-date\">\n                <div class=\"cx-mobile-header\">\n                  {{ 'quote.list.updated' | cxTranslate }}\n                </div>\n                <span aria-hidden=\"true\">{{\n                  quote?.updatedTime | cxDate: dateFormat\n                }}</span>\n              </td>\n              <td role=\"cell\" class=\"cx-nav-caret\">\n                <cx-icon\n                  [type]=\"iconTypes.CARET_RIGHT\"\n                  aria-hidden=\"true\"\n                  [attr.aria-label]=\"'quote.list.clickableRow' | cxTranslate\"\n                />\n              </td>\n            </tr>\n          </tbody>\n        </table>\n        <ng-container *ngIf=\"isPaginationEnabled(quotesState.data.pagination)\">\n          <div class=\"cx-sort bottom\">\n            <cx-pagination\n              [pagination]=\"quotesState.data.pagination\"\n              (viewPageEvent)=\"changePage($event)\"\n              paginationID=\"pagination-bottom\"\n            />\n          </div>\n        </ng-container>\n      </ng-container>\n    </ng-container>\n  </div>\n</ng-container>\n\n<ng-template #ghostList>\n  <div class=\"cx-ghost-sort-top\">\n    <div class=\"cx-ghost-title ghost\"></div>\n    <div class=\"cx-ghost-select ghost\"></div>\n  </div>\n  <div class=\"cx-ghost-table\">\n    <ng-container *ngFor=\"let number of [0, 1, 2, 3, 4, 5, 6, 7]\">\n      <div class=\"cx-ghost-row\">\n        <div class=\"cx-ghost-cell-name\">\n          <div class=\"cx-ghost-name ghost\"></div>\n        </div>\n        <div class=\"cx-ghost-cell-id\">\n          <div class=\"cx-ghost-id ghost\"></div>\n        </div>\n        <div class=\"cx-ghost-cell-status\">\n          <div class=\"cx-ghost-status ghost\"></div>\n        </div>\n        <div class=\"cx-ghost-cell-updated-date\">\n          <div class=\"cx-ghost-updated-date ghost\"></div>\n        </div>\n        <div class=\"cx-ghost-cell-nav-caret\">\n          <div class=\"cx-ghost-nav-caret ghost\"></div>\n        </div>\n      </div>\n    </ng-container>\n  </div>\n  <div class=\"cx-ghost-sort-bottom\">\n    <div class=\"cx-ghost-pagination ghost\"></div>\n  </div>\n</ng-template>\n\n<ng-template #emptyQuoteList>\n  <div class=\"cx-empty\">\n    {{ 'quote.list.empty' | cxTranslate }}\n  </div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SortingComponent, selector: "cx-sorting", inputs: ["sortOptions", "ariaControls", "ariaLabel", "selectedOption", "placeholder", "sortLabels"], outputs: ["sortListEvent"] }, { kind: "component", type: PaginationComponent, selector: "cx-pagination", inputs: ["pageRoute", "queryParam", "defaultPage", "pagination", "paginationID"], outputs: ["viewPageEvent"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: CxDatePipe, name: "cxDate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-quote-list', changeDetection: ChangeDetectionStrategy.OnPush, providers: [CxDatePipe], imports: [
                        NgIf,
                        SortingComponent,
                        PaginationComponent,
                        NgFor,
                        RouterLink,
                        NgClass,
                        IconComponent,
                        AsyncPipe,
                        TranslatePipe,
                        UrlPipe,
                        CxDatePipe,
                    ], template: "<ng-container *ngIf=\"quotesState$ | async as quotesState; else ghostList\">\n  <div\n    role=\"region\"\n    tabindex=\"-1\"\n    [attr.aria-label]=\"'quote.list.regionTitle' | cxTranslate\"\n  >\n    <ng-container *ngIf=\"quotesState.data; else ghostList\">\n      <ng-container\n        *ngIf=\"\n          quotesState.data.quotes && quotesState.data.quotes.length > 0;\n          else emptyQuoteList\n        \"\n      >\n        <div class=\"cx-sort top\">\n          <label class=\"cx-form-group form-group\"\n            ><span class=\"sortBy-heading\">\n              {{ 'quote.list.sortBy' | cxTranslate }}\n            </span>\n            <cx-sorting\n              [sortOptions]=\"sorts\"\n              [sortLabels]=\"sortLabels$ | async\"\n              (sortListEvent)=\"changeSorting($event)\"\n              [selectedOption]=\"quotesState.data.pagination.sort\"\n              placeholder=\"{{ 'quote.list.sortBy' | cxTranslate }}\"\n              [ariaLabel]=\"'quote.list.sortQuotes' | cxTranslate\"\n              ariaControls=\"quote-list\"\n            />\n          </label>\n          <ng-container\n            *ngIf=\"isPaginationEnabled(quotesState.data.pagination)\"\n          >\n            <cx-pagination\n              [pagination]=\"quotesState.data.pagination\"\n              (viewPageEvent)=\"changePage($event)\"\n              paginationID=\"pagination-top\"\n            />\n          </ng-container>\n        </div>\n        <table id=\"quote-list\" role=\"table\" aria-describedby=\"quote-list-desc\">\n          <caption id=\"quote-list-desc\" class=\"cx-visually-hidden\">\n            {{\n              'quote.list.title' | cxTranslate\n            }}\n          </caption>\n          <thead role=\"rowgroup\">\n            <tr role=\"row\">\n              <th role=\"columnheader\" aria-sort=\"none\">\n                {{ 'quote.list.name' | cxTranslate }}\n              </th>\n              <th role=\"columnheader\" aria-sort=\"none\">\n                {{ 'quote.header.overview.id' | cxTranslate }}\n              </th>\n              <th role=\"columnheader\" aria-sort=\"none\">\n                {{ 'quote.header.overview.status' | cxTranslate }}\n              </th>\n              <th role=\"columnheader\" aria-sort=\"none\">\n                {{ 'quote.list.updated' | cxTranslate }}\n              </th>\n              <th></th>\n            </tr>\n          </thead>\n          <tbody role=\"rowgroup\">\n            <tr\n              role=\"row\"\n              #row\n              *ngFor=\"let quote of quotesState.data.quotes\"\n              [routerLink]=\"\n                {\n                  cxRoute: 'quoteDetails',\n                  params: { quoteId: quote.code },\n                } | cxUrl\n              \"\n              (keydown.enter)=\"row.click()\"\n              attr.aria-label=\"{{ 'quote.list.name' | cxTranslate }}: {{\n                quote.name\n              }} {{ 'quote.header.overview.id' | cxTranslate }}: {{\n                quote.code\n              }} {{ 'quote.header.overview.status' | cxTranslate }}: {{\n                'quote.states.' + quote.state | cxTranslate\n              }} {{ 'quote.list.updated' | cxTranslate }}: {{\n                quote?.updatedTime | cxDate: dateFormat\n              }} {{ 'quote.list.clickableRow' | cxTranslate }}\"\n              attr.title=\"{{ quote.name }}\"\n            >\n              <td role=\"cell\" class=\"cx-name\">\n                <div class=\"cx-mobile-header\">\n                  {{ 'quote.list.name' | cxTranslate }}\n                </div>\n                <span aria-hidden=\"true\">{{ quote.name }}</span>\n              </td>\n              <td role=\"cell\" class=\"cx-code\">\n                <div class=\"cx-mobile-header\">\n                  {{ 'quote.header.overview.id' | cxTranslate }}\n                </div>\n                <span aria-hidden=\"true\">{{ quote.code }}</span>\n              </td>\n              <td role=\"cell\" class=\"cx-status\">\n                <div class=\"cx-mobile-header\">\n                  {{ 'quote.header.overview.status' | cxTranslate }}\n                </div>\n                <span\n                  aria-hidden=\"true\"\n                  [ngClass]=\"getQuoteStateClass(quote.state)\"\n                  >{{ 'quote.states.' + quote.state | cxTranslate }}</span\n                >\n              </td>\n              <td role=\"cell\" class=\"cx-updated-date\">\n                <div class=\"cx-mobile-header\">\n                  {{ 'quote.list.updated' | cxTranslate }}\n                </div>\n                <span aria-hidden=\"true\">{{\n                  quote?.updatedTime | cxDate: dateFormat\n                }}</span>\n              </td>\n              <td role=\"cell\" class=\"cx-nav-caret\">\n                <cx-icon\n                  [type]=\"iconTypes.CARET_RIGHT\"\n                  aria-hidden=\"true\"\n                  [attr.aria-label]=\"'quote.list.clickableRow' | cxTranslate\"\n                />\n              </td>\n            </tr>\n          </tbody>\n        </table>\n        <ng-container *ngIf=\"isPaginationEnabled(quotesState.data.pagination)\">\n          <div class=\"cx-sort bottom\">\n            <cx-pagination\n              [pagination]=\"quotesState.data.pagination\"\n              (viewPageEvent)=\"changePage($event)\"\n              paginationID=\"pagination-bottom\"\n            />\n          </div>\n        </ng-container>\n      </ng-container>\n    </ng-container>\n  </div>\n</ng-container>\n\n<ng-template #ghostList>\n  <div class=\"cx-ghost-sort-top\">\n    <div class=\"cx-ghost-title ghost\"></div>\n    <div class=\"cx-ghost-select ghost\"></div>\n  </div>\n  <div class=\"cx-ghost-table\">\n    <ng-container *ngFor=\"let number of [0, 1, 2, 3, 4, 5, 6, 7]\">\n      <div class=\"cx-ghost-row\">\n        <div class=\"cx-ghost-cell-name\">\n          <div class=\"cx-ghost-name ghost\"></div>\n        </div>\n        <div class=\"cx-ghost-cell-id\">\n          <div class=\"cx-ghost-id ghost\"></div>\n        </div>\n        <div class=\"cx-ghost-cell-status\">\n          <div class=\"cx-ghost-status ghost\"></div>\n        </div>\n        <div class=\"cx-ghost-cell-updated-date\">\n          <div class=\"cx-ghost-updated-date ghost\"></div>\n        </div>\n        <div class=\"cx-ghost-cell-nav-caret\">\n          <div class=\"cx-ghost-nav-caret ghost\"></div>\n        </div>\n      </div>\n    </ng-container>\n  </div>\n  <div class=\"cx-ghost-sort-bottom\">\n    <div class=\"cx-ghost-pagination ghost\"></div>\n  </div>\n</ng-template>\n\n<ng-template #emptyQuoteList>\n  <div class=\"cx-empty\">\n    {{ 'quote.list.empty' | cxTranslate }}\n  </div>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteListModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QuoteListModule, imports: [CommonModule,
            I18nModule,
            IconModule,
            UrlModule,
            RouterModule,
            ListNavigationModule,
            QuoteListComponent], exports: [QuoteListComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteListModule, providers: [
            provideDefaultConfig({
                view: {
                    defaultPageSize: 5,
                },
            }),
            provideDefaultConfig({
                cmsComponents: {
                    AccountMyQuotesComponent: {
                        component: QuoteListComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
            QuoteListComponentService,
        ], imports: [CommonModule,
            I18nModule,
            IconModule,
            UrlModule,
            RouterModule,
            ListNavigationModule,
            QuoteListComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        IconModule,
                        UrlModule,
                        RouterModule,
                        ListNavigationModule,
                        QuoteListComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            view: {
                                defaultPageSize: 5,
                            },
                        }),
                        provideDefaultConfig({
                            cmsComponents: {
                                AccountMyQuotesComponent: {
                                    component: QuoteListComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                        QuoteListComponentService,
                    ],
                    exports: [QuoteListComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * default confirm action dialog configuration
 */
const defaultConfirmActionDialogConfig = {
    showWarningNote: false,
    showExpirationDate: false,
    showSuccessMessage: true,
    showOnlyWhenCartIsNotEmpty: false,
};
const defaultDialogMappings = {
    BUYER_OFFER: {
        EDIT: {
            i18nKeyPrefix: 'quote.confirmDialog.buyer_offer.edit',
            showWarningNote: true,
            showExpirationDate: true,
            showSuccessMessage: false,
            showOnlyWhenCartIsNotEmpty: false,
        },
        CANCEL: {
            i18nKeyPrefix: 'quote.confirmDialog.buyer_offer.cancel',
            ...defaultConfirmActionDialogConfig,
        },
        CHECKOUT: {
            i18nKeyPrefix: 'quote.confirmDialog.buyer_offer.checkout',
            ...defaultConfirmActionDialogConfig,
            showSuccessMessage: false,
        },
    },
    EXPIRED: {
        EDIT: {
            i18nKeyPrefix: 'quote.confirmDialog.expired.edit',
            showWarningNote: true,
            showExpirationDate: false,
            showSuccessMessage: false,
            showOnlyWhenCartIsNotEmpty: false,
        },
        REQUOTE: {
            i18nKeyPrefix: 'quote.confirmDialog.expired.requote',
            showWarningNote: true,
            showExpirationDate: false,
            showSuccessMessage: false,
            showOnlyWhenCartIsNotEmpty: false,
        },
    },
    BUYER: {
        SUBMIT: {
            i18nKeyPrefix: 'quote.confirmDialog.buyer.submit',
            ...defaultConfirmActionDialogConfig,
        },
        CANCEL: {
            i18nKeyPrefix: 'quote.confirmDialog.buyer.cancel',
            ...defaultConfirmActionDialogConfig,
        },
    },
    SELLER: {
        SUBMIT: {
            i18nKeyPrefix: 'quote.confirmDialog.seller.submit',
            ...defaultConfirmActionDialogConfig,
            showWarningNote: true,
        },
    },
    SELLERAPPROVER: {
        APPROVE: {
            i18nKeyPrefix: 'quote.confirmDialog.sellerapprover.approve',
            ...defaultConfirmActionDialogConfig,
        },
        REJECT: {
            i18nKeyPrefix: 'quote.confirmDialog.sellerapprover.reject',
            ...defaultConfirmActionDialogConfig,
        },
    },
    CANCELLED: {
        REQUOTE: {
            i18nKeyPrefix: 'quote.confirmDialog.cancelled.requote',
            showWarningNote: true,
            showExpirationDate: false,
            showSuccessMessage: false,
            showOnlyWhenCartIsNotEmpty: true,
        },
    },
    ALL: {
        EDIT: {
            i18nKeyPrefix: 'quote.confirmDialog.all.edit',
            showWarningNote: true,
            showExpirationDate: false,
            showSuccessMessage: false,
            showOnlyWhenCartIsNotEmpty: true,
        },
    },
};
const defaultQuoteUIConfig = {
    quote: {
        maxCharsForComments: 1000,
        truncateCardTileContentAfterNumChars: 100,
        updateDebounceTime: {
            expiryDate: 500,
        },
        confirmActionDialogMapping: defaultDialogMappings,
        maximumDecimalsForPercentageDiscount: 8,
        showSubtotalBeforeDiscounts: true,
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteSummaryActionsComponent {
    constructor() {
        this.quoteFacade = inject(QuoteFacade);
        this.launchDialogService = inject(LaunchDialogService);
        this.viewContainerRef = inject(ViewContainerRef);
        this.globalMessageService = inject(GlobalMessageService);
        this.quoteUIConfig = inject(QuoteUIConfig);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.quoteStorefrontUtilsService = inject(QuoteStorefrontUtilsService);
        this.intersectionService = inject(IntersectionService);
        this.quoteDetails$ = this.quoteFacade.getQuoteDetails();
        this.cartDetails$ = this.activeCartFacade.getActive();
        this.QuoteActionType = QuoteActionType;
        this.subscription = new Subscription();
        this.isFixedPosition = true;
        this.CX_SECTION_SELECTOR = 'cx-quote-summary-actions section';
        this.HEADER_SLOT_SELECTOR = '.BottomHeaderSlot';
        /**
         * Height of a CSS box model of section for action buttons
         * See _quote-summary-actions.scss
         */
        this.ACTION_BUTTONS_HEIGHT = 226;
        this.AMOUNT_OF_ACTION_BUTTONS = 2;
        this.BOTTOM = 'bottom';
        this.featureToggles = inject(FeatureToggles);
    }
    handleResize() {
        this.adjustStyling();
    }
    handleScroll() {
        this.adjustBottomProperty();
    }
    ngAfterViewInit() {
        this.adjustStyling();
    }
    ngOnInit() {
        //submit button present and threshold not reached: Display message
        this.quoteDetails$.pipe(take(1)).subscribe((quote) => {
            const mustDisableAction = quote.allowedActions.find((action) => this.mustDisableAction(action.type, quote));
            if (mustDisableAction) {
                this.globalMessageService.add({
                    key: 'quote.commons.minRequestInitiationNote',
                    params: {
                        minValue: quote.threshold,
                    },
                }, GlobalMessageType.MSG_TYPE_WARNING);
            }
        });
    }
    /**
     * Retrieves the actual height of the action buttons.
     *
     * @returns - Height of the action buttons.
     * @protected
     */
    getActionButtonsHeight() {
        const actionButtonsHeight = this.quoteStorefrontUtilsService.getHeight(this.CX_SECTION_SELECTOR);
        return actionButtonsHeight !== 0
            ? actionButtonsHeight
            : this.ACTION_BUTTONS_HEIGHT;
    }
    /**
     * Adjusts `bottom` property.
     *
     * In case we deal with a desktop device, then the bottom property will be removed.
     *
     * In case we deal with a mobile device.
     * There are 2 cases when the bottom property will be changed accordingly.
     * Firstly, the bottom property will be changed to the value that is less than zero,
     * when the height of the action buttons is greater than the spare viewport height.
     * Secondly, the bottom property will be changed to zero,
     * when the mentioned condition is not met.
     *
     * @protected
     */
    adjustBottomProperty() {
        const headerSlotBottom = this.quoteStorefrontUtilsService.getDomRectValue(this.HEADER_SLOT_SELECTOR, this.BOTTOM);
        const windowHeight = this.quoteStorefrontUtilsService.getWindowHeight();
        const actionButtonsHeight = this.getActionButtonsHeight();
        const spareViewportHeight = headerSlotBottom
            ? windowHeight - headerSlotBottom
            : windowHeight;
        if (actionButtonsHeight > spareViewportHeight) {
            const bottom = spareViewportHeight - actionButtonsHeight;
            this.quoteStorefrontUtilsService.changeStyling(this.CX_SECTION_SELECTOR, this.BOTTOM, bottom + 'px');
        }
        else {
            this.quoteStorefrontUtilsService.changeStyling(this.CX_SECTION_SELECTOR, this.BOTTOM, '0');
        }
    }
    /**
     * Defines the class name for the section that controls the styling to be displayed on mobile.
     *
     * @protected
     */
    defineClassForSection() {
        const options = {
            rootMargin: '9999px 0px -120px 0px',
        };
        const slot = this.quoteStorefrontUtilsService.getElement('cx-page-slot.CenterRightContent');
        if (slot) {
            this.intersectionService
                .isIntersecting(slot, options)
                .subscribe((isIntersecting) => {
                if (isIntersecting) {
                    this.isFixedPosition = false;
                }
                else {
                    this.isFixedPosition = true;
                }
            });
        }
    }
    adjustStyling() {
        this.defineClassForSection();
        this.adjustBottomProperty();
    }
    /**
     * Checks whether the given action must be disabled on the UI based on the details of the quote.
     * For example the SUBMIT action is disabled when the quote threshold is not exceeded.
     *
     * @param type - type of the quote action
     * @param quote - quote
     * @returns true, only of the action shall be disabled
     */
    mustDisableAction(type, quote) {
        if (this.featureToggles.showWarningMessageOnRequoteButtonClick) {
            return ((type === QuoteActionType.SUBMIT || type === QuoteActionType.REQUOTE) &&
                !this.isThresholdReached(quote));
        }
        return type === QuoteActionType.SUBMIT && !this.isThresholdReached(quote);
    }
    isThresholdReached(quote) {
        const requestThreshold = quote.threshold || 0;
        return (quote.totalPrice.value || 0) >= requestThreshold;
    }
    /**
     * Generic click handler for quote action buttons.
     *
     * @param action - the action to be triggered
     * @param quote - quote
     * @param cart - cart
     */
    onClick(action, quote, cart) {
        const cartIsEmptyOrQuoteCart = (cart.entries?.length ?? 0) === 0 || cart.quoteCode !== undefined;
        if (!this.isConfirmationDialogRequired(action, quote.state, cartIsEmptyOrQuoteCart)) {
            this.performAction(action, quote);
            return;
        }
        const context = this.prepareConfirmationContext(action, quote);
        this.launchConfirmationDialog(context);
        this.handleConfirmationDialogClose(action, context);
    }
    performAction(action, quote) {
        if (action === QuoteActionType.REQUOTE) {
            this.requote(quote.code);
        }
        else {
            this.quoteFacade.performQuoteAction(quote, action);
        }
    }
    launchConfirmationDialog(context) {
        this.launchDialogService
            .openDialog(LAUNCH_CALLER.QUOTE_ACTION_CONFIRMATION, this.element, this.viewContainerRef, { confirmationContext: context })
            ?.pipe(take(1))
            .subscribe();
    }
    handleConfirmationDialogClose(action, context) {
        this.subscription.unsubscribe();
        this.subscription = new Subscription();
        this.subscription.add(this.launchDialogService.dialogClose
            .pipe(filter((reason) => reason === 'yes'), tap(() => this.performAction(action, context.quote)), filter(() => !!context.successMessage), tap(() => this.globalMessageService.add({ key: context.successMessage }, this.getMessageType(action))))
            .subscribe());
    }
    getMessageType(action) {
        return action === QuoteActionType.CANCEL ||
            action === QuoteActionType.REJECT
            ? GlobalMessageType.MSG_TYPE_INFO
            : GlobalMessageType.MSG_TYPE_CONFIRMATION;
    }
    requote(quoteId) {
        this.quoteFacade.requote(quoteId);
    }
    /**
     * Verifies whether there are any action buttons.
     *
     * @param allowedActions - currently displayed actions
     * @returns - if there are any action buttons, returns 'true', otherwise 'false'.
     */
    areButtonsRendered(allowedActions) {
        return this.getFilteredActions(allowedActions).length > 0;
    }
    /**
     * Returns the style class to be used for the button, so whether its a primary, secondary or tertiary button.
     *
     * @param allowedActions - currently displayed actions
     * @param action - action associated with this button
     * @returns 'btn-primary' | 'btn-secondary' | 'btn-tertiary'
     */
    getButtonStyle(allowedActions, action) {
        if (action.isPrimary) {
            return 'btn-primary';
        }
        if (this.getFilteredActions(allowedActions).length <=
            this.AMOUNT_OF_ACTION_BUTTONS) {
            return 'btn-secondary';
        }
        return action.type === QuoteActionType.CANCEL
            ? 'btn-tertiary'
            : 'btn-secondary';
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    isConfirmationDialogRequired(action, state, cartIsEmptyOrQuoteCart) {
        const mappingConfig = this.quoteUIConfig.quote?.confirmActionDialogMapping;
        const dialogConfig = mappingConfig?.[state]?.[action] ??
            mappingConfig?.[this.stateToRoleTypeForDialogConfig(state)]?.[action] ??
            mappingConfig?.[QuoteRoleType.ALL]?.[action];
        return (!!dialogConfig &&
            (!cartIsEmptyOrQuoteCart || !dialogConfig.showOnlyWhenCartIsNotEmpty));
    }
    prepareConfirmationContext(action, quote) {
        const dialogConfig = this.getConfirmDialogConfig(action, quote.state);
        const confirmationContext = {
            quote: quote,
            title: dialogConfig.i18nKeyPrefix + '.title',
            confirmNote: dialogConfig.i18nKeyPrefix + '.confirmNote',
            a11y: {
                close: dialogConfig.i18nKeyPrefix + '.a11y.close',
            },
        };
        if (dialogConfig.showWarningNote) {
            confirmationContext.warningNote =
                dialogConfig.i18nKeyPrefix + '.warningNote';
        }
        if (dialogConfig.showExpirationDate) {
            confirmationContext.validity = 'quote.confirmDialog.validity';
        }
        if (dialogConfig.showSuccessMessage) {
            confirmationContext.successMessage =
                dialogConfig.i18nKeyPrefix + '.successMessage';
        }
        return confirmationContext;
    }
    getConfirmDialogConfig(action, state) {
        const mappingConfig = this.quoteUIConfig.quote?.confirmActionDialogMapping;
        const config = mappingConfig?.[state]?.[action] ??
            mappingConfig?.[this.stateToRoleTypeForDialogConfig(state)]?.[action] ??
            mappingConfig?.[QuoteRoleType.ALL]?.[action];
        if (!config) {
            throw new Error(`Dialog Config expected for quote in state ${state} and action ${action}, but none found in config ${mappingConfig}`);
        }
        return config;
    }
    stateToRoleTypeForDialogConfig(state) {
        let foundRole = QuoteRoleType.ALL;
        Object.values(QuoteRoleType).forEach((role) => {
            if (state.startsWith(role + '_')) {
                foundRole = role;
            }
        });
        return foundRole;
    }
    getFilteredActions(allowedActions) {
        return allowedActions.filter((action) => action.type !== 'DOWNLOAD_QUOTE_PROPOSAL_DOCUMENT');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryActionsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: QuoteSummaryActionsComponent, isStandalone: true, selector: "cx-quote-summary-actions", host: { listeners: { "window:resize": "handleResize()", "window:scroll": "handleScroll()" } }, viewQueries: [{ propertyName: "element", first: true, predicate: ["element"], descendants: true }], ngImport: i0, template: "<ng-container *ngIf=\"quoteDetails$ | async as quoteDetails\">\n  <ng-container *ngIf=\"cartDetails$ | async as cartDetails\">\n    <ng-container *ngIf=\"areButtonsRendered(quoteDetails.allowedActions)\">\n      <section [ngClass]=\"isFixedPosition ? 'fixed' : 'sticky'\">\n        <button\n          #element\n          type=\"button\"\n          *ngFor=\"let action of getFilteredActions(quoteDetails.allowedActions)\"\n          class=\"btn\"\n          [ngClass]=\"getButtonStyle(quoteDetails.allowedActions, action)\"\n          [disabled]=\"mustDisableAction(action.type, quoteDetails)\"\n          (click)=\"onClick(action.type, quoteDetails, cartDetails)\"\n        >\n          {{ 'quote.summary.actions.' + action.type | cxTranslate }}\n        </button>\n      </section>\n    </ng-container>\n  </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryActionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-quote-summary-actions', imports: [NgIf, NgClass, NgFor, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"quoteDetails$ | async as quoteDetails\">\n  <ng-container *ngIf=\"cartDetails$ | async as cartDetails\">\n    <ng-container *ngIf=\"areButtonsRendered(quoteDetails.allowedActions)\">\n      <section [ngClass]=\"isFixedPosition ? 'fixed' : 'sticky'\">\n        <button\n          #element\n          type=\"button\"\n          *ngFor=\"let action of getFilteredActions(quoteDetails.allowedActions)\"\n          class=\"btn\"\n          [ngClass]=\"getButtonStyle(quoteDetails.allowedActions, action)\"\n          [disabled]=\"mustDisableAction(action.type, quoteDetails)\"\n          (click)=\"onClick(action.type, quoteDetails, cartDetails)\"\n        >\n          {{ 'quote.summary.actions.' + action.type | cxTranslate }}\n        </button>\n      </section>\n    </ng-container>\n  </ng-container>\n</ng-container>\n" }]
        }], propDecorators: { element: [{
                type: ViewChild,
                args: ['element']
            }], handleResize: [{
                type: HostListener,
                args: ['window:resize']
            }], handleScroll: [{
                type: HostListener,
                args: ['window:scroll']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteSummaryActionsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryActionsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryActionsModule, imports: [CommonModule, I18nModule, QuoteSummaryActionsComponent], exports: [QuoteSummaryActionsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryActionsModule, imports: [CommonModule, I18nModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryActionsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, I18nModule, QuoteSummaryActionsComponent],
                    exports: [QuoteSummaryActionsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteSummaryPricesComponent {
    constructor() {
        this.quoteFacade = inject(QuoteFacade);
        this.quoteUIConfig = inject(QuoteUIConfig);
        this.quoteDetails$ = this.quoteFacade.getQuoteDetails();
    }
    get showSubtotalBeforeDiscounts() {
        return this.quoteUIConfig.quote?.showSubtotalBeforeDiscounts ?? true;
    }
    /**
     * Checks whether the price has a non-zero value.
     *
     * @param price - Price to check
     * @returns true, only if the price has a non zero value
     */
    hasNonZeroPriceValue(price) {
        return !!price && !!price.value && price.value > 0;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryPricesComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: QuoteSummaryPricesComponent, isStandalone: true, selector: "cx-quote-summary-prices", ngImport: i0, template: "<ng-container *ngIf=\"quoteDetails$ | async as quoteDetails\">\n  <div class=\"cx-price-heading\">\n    {{ 'quote.summary.prices.title' | cxTranslate }}\n  </div>\n  <div class=\"cx-price-row\">\n    <div class=\"cx-price-label\">\n      {{ 'quote.summary.prices.subtotal' | cxTranslate }}\n    </div>\n    <div class=\"cx-price-amount\">\n      {{\n        showSubtotalBeforeDiscounts &&\n        quoteDetails.sapSubtotalExcludingOrderLevelDiscount?.formattedValue\n          ? quoteDetails.sapSubtotalExcludingOrderLevelDiscount!.formattedValue\n          : quoteDetails.totalPrice.formattedValue\n      }}\n    </div>\n  </div>\n  <div\n    *ngIf=\"hasNonZeroPriceValue(quoteDetails.productDiscounts)\"\n    class=\"cx-price-row cx-price-savings\"\n  >\n    <div class=\"cx-price-label\">\n      {{ 'quote.summary.prices.productDiscount' | cxTranslate }}\n    </div>\n    <div class=\"cx-price-amount\">\n      {{ quoteDetails.productDiscounts?.formattedValue }}\n    </div>\n  </div>\n  <div\n    *ngIf=\"hasNonZeroPriceValue(quoteDetails.orderDiscounts)\"\n    class=\"cx-price-row cx-price-savings\"\n  >\n    <div class=\"cx-price-label\">\n      {{ 'quote.summary.prices.orderDiscount' | cxTranslate }}\n    </div>\n    <div class=\"cx-price-amount\">\n      {{ quoteDetails.orderDiscounts?.formattedValue }}\n    </div>\n  </div>\n  <div\n    *ngIf=\"hasNonZeroPriceValue(quoteDetails.quoteDiscounts)\"\n    class=\"cx-price-row cx-price-savings\"\n  >\n    <div class=\"cx-price-label\">\n      {{ 'quote.summary.prices.quoteDiscount' | cxTranslate }}\n    </div>\n    <div class=\"cx-price-amount\">\n      {{ quoteDetails.quoteDiscounts?.formattedValue }}\n    </div>\n  </div>\n  <div class=\"cx-price-row cx-price-total\">\n    <div class=\"cx-price-label\">\n      {{ 'quote.summary.prices.total' | cxTranslate }}\n    </div>\n    <div class=\"cx-price-amount\">\n      {{ quoteDetails.totalPrice.formattedValue }}\n    </div>\n  </div>\n  <div class=\"cx-price-footer\">\n    *{{ 'quote.summary.prices.hint' | cxTranslate }}\n  </div>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryPricesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-quote-summary-prices', imports: [NgIf, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"quoteDetails$ | async as quoteDetails\">\n  <div class=\"cx-price-heading\">\n    {{ 'quote.summary.prices.title' | cxTranslate }}\n  </div>\n  <div class=\"cx-price-row\">\n    <div class=\"cx-price-label\">\n      {{ 'quote.summary.prices.subtotal' | cxTranslate }}\n    </div>\n    <div class=\"cx-price-amount\">\n      {{\n        showSubtotalBeforeDiscounts &&\n        quoteDetails.sapSubtotalExcludingOrderLevelDiscount?.formattedValue\n          ? quoteDetails.sapSubtotalExcludingOrderLevelDiscount!.formattedValue\n          : quoteDetails.totalPrice.formattedValue\n      }}\n    </div>\n  </div>\n  <div\n    *ngIf=\"hasNonZeroPriceValue(quoteDetails.productDiscounts)\"\n    class=\"cx-price-row cx-price-savings\"\n  >\n    <div class=\"cx-price-label\">\n      {{ 'quote.summary.prices.productDiscount' | cxTranslate }}\n    </div>\n    <div class=\"cx-price-amount\">\n      {{ quoteDetails.productDiscounts?.formattedValue }}\n    </div>\n  </div>\n  <div\n    *ngIf=\"hasNonZeroPriceValue(quoteDetails.orderDiscounts)\"\n    class=\"cx-price-row cx-price-savings\"\n  >\n    <div class=\"cx-price-label\">\n      {{ 'quote.summary.prices.orderDiscount' | cxTranslate }}\n    </div>\n    <div class=\"cx-price-amount\">\n      {{ quoteDetails.orderDiscounts?.formattedValue }}\n    </div>\n  </div>\n  <div\n    *ngIf=\"hasNonZeroPriceValue(quoteDetails.quoteDiscounts)\"\n    class=\"cx-price-row cx-price-savings\"\n  >\n    <div class=\"cx-price-label\">\n      {{ 'quote.summary.prices.quoteDiscount' | cxTranslate }}\n    </div>\n    <div class=\"cx-price-amount\">\n      {{ quoteDetails.quoteDiscounts?.formattedValue }}\n    </div>\n  </div>\n  <div class=\"cx-price-row cx-price-total\">\n    <div class=\"cx-price-label\">\n      {{ 'quote.summary.prices.total' | cxTranslate }}\n    </div>\n    <div class=\"cx-price-amount\">\n      {{ quoteDetails.totalPrice.formattedValue }}\n    </div>\n  </div>\n  <div class=\"cx-price-footer\">\n    *{{ 'quote.summary.prices.hint' | cxTranslate }}\n  </div>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteSummaryPricesModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryPricesModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryPricesModule, imports: [CommonModule, I18nModule, QuoteSummaryPricesComponent], exports: [QuoteSummaryPricesComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryPricesModule, imports: [CommonModule, I18nModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryPricesModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, I18nModule, QuoteSummaryPricesComponent],
                    exports: [QuoteSummaryPricesComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Provides validation and formatting of numeric input.
 */
class QuoteSummarySellerEditComponentService {
    constructor() {
        this.languageService = inject(LanguageService);
        this.quoteUIConfig = inject(QuoteUIConfig);
        this.maximumDecimalsForPercentageDiscountDefault = 8;
    }
    /**
     * Parses a discount value to numeric format.
     *
     * @param input - Discount as string, can include unit symbol, decimal and grouping separators
     * @returns Observable of discount as number
     */
    parseDiscountValue(input) {
        return this.getLocalizationElements().pipe(map((localizationElements) => {
            if (input) {
                input = input.replace(localizationElements.percentageSign, '');
                return this.parseInput(input, localizationElements.locale);
            }
            else {
                return 0;
            }
        }));
    }
    /**
     * Retrieves formatter according to current locale and unit.
     *
     * @returns Observable of formatters
     */
    getFormatter() {
        return this.getLocalizationElements().pipe(map((localizationElements) => localizationElements.formatter));
    }
    /**
     * Retrieves localization elements according to current locale and unit.
     *
     * @returns Observables of localization elements
     */
    getLocalizationElements() {
        return this.languageService.getActive().pipe(map((locale) => {
            const formatter = new Intl.NumberFormat(locale, {
                style: 'percent',
                maximumFractionDigits: this.retrieveMaxNumberOfDecimalPlaces(),
            });
            const symbol = formatter
                .formatToParts(0)
                .find((x) => x.type === 'percentSign');
            return this.checkAndReportMissingPercentageSign(locale, formatter, symbol?.value);
        }));
    }
    /**
     * Retrieves number format validator according to inputs.
     *
     * @param locale - Current locale
     * @param unit - Unit
     * @returns Formatter that can be attached to a form control
     */
    getNumberFormatValidator(locale, unit) {
        return (control) => {
            const input = control.value?.trim();
            if (input) {
                return this.getValidationErrorsNumericFormat(input, locale, unit);
            }
            return null;
        };
    }
    /**
     * Adds current time and time zone to a date. Result is a timestamp string that can be handed over to OCC.
     *
     * @param date - Date as string
     * @returns Timestamp as string
     */
    addTimeToDate(date) {
        const localTime = new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit',
            hourCycle: 'h23',
        });
        return `${date}T${localTime}:00${TimeUtils.getLocalTimezoneOffset()}`;
    }
    /**
     * Removes time portion from timestamp.
     *
     * @param timestamp - Timestamp as string
     * @returns Date portion of timestamp
     */
    removeTimeFromDate(timestamp) {
        return timestamp?.toString().substring(0, 10);
    }
    /**
     * Verifies if quote state belongs to seller and can be edited.
     *
     * @param quote - Quote
     * @returns Is it for seller?
     */
    isEditable(quote) {
        const quoteState = quote.state;
        return ((quoteState === QuoteState.SELLER_REQUEST ||
            quoteState === QuoteState.SELLER_DRAFT) &&
            quote.isEditable);
    }
    checkAndReportMissingPercentageSign(locale, formatter, percentageSign) {
        if (percentageSign) {
            return { locale, formatter, percentageSign: percentageSign };
        }
        else {
            throw new Error('No percentage sign present');
        }
    }
    parseInput(input, locale) {
        const groupingSeparator = getLocaleNumberSymbol(locale, NumberSymbol.Group);
        const decimalSeparator = getLocaleNumberSymbol(locale, NumberSymbol.Decimal);
        return this.parseInputForSeparators(input, groupingSeparator, decimalSeparator);
    }
    parseInputForSeparators(input, groupingSeparator, decimalSeparator) {
        const escapeString = '\\';
        const search = new RegExp(escapeString + groupingSeparator, 'g');
        const normalizedInput = input
            .replace(search, '')
            .replace(decimalSeparator, '.');
        return parseFloat(normalizedInput);
    }
    getValidationErrorsNumericFormat(input, locale, unit) {
        input = input.replace(unit, '').trim();
        const groupingSeparator = getLocaleNumberSymbol(locale, NumberSymbol.Group);
        const decimalSeparator = getLocaleNumberSymbol(locale, NumberSymbol.Decimal);
        const expressionPrefix = '^';
        const expressionOnlyNumericalInput = new RegExp(expressionPrefix +
            '[0123456789' +
            groupingSeparator +
            decimalSeparator +
            ']*$');
        if (!expressionOnlyNumericalInput.test(input)) {
            return this.createValidationError(true);
        }
        return this.createValidationError(this.performValidationForPercentageValue(input, groupingSeparator, decimalSeparator));
    }
    createValidationError(isError) {
        return isError ? { wrongFormat: {} } : null;
    }
    /**
     * Returns maximum number of decimal places for the percentage discount.
     * The value is read from the configuration, refer to attribute quote/maximumDecimalsForPercentageDiscount.
     * In case this configuration is not present, default value is 8.
     *
     * @returns Maximum number of decimal places for percentage discount
     * @protected
     */
    retrieveMaxNumberOfDecimalPlaces() {
        return (this.quoteUIConfig?.quote?.maximumDecimalsForPercentageDiscount ??
            this.maximumDecimalsForPercentageDiscountDefault);
    }
    performValidationForPercentageValue(input, groupingSeparator, decimalSeparator) {
        const numberOfDecimalPlaces = this.retrieveMaxNumberOfDecimalPlaces();
        const regexEscape = '\\';
        const search = new RegExp(regexEscape + groupingSeparator, 'g');
        const withoutGroupingSeparator = input.replace(search, '');
        const splitParts = withoutGroupingSeparator.split(decimalSeparator);
        if (splitParts.length > 2) {
            return true;
        }
        if (splitParts.length === 1) {
            return Number.parseFloat(withoutGroupingSeparator) > 100;
        }
        return (Number.parseFloat(splitParts[0]) > 100 ||
            splitParts[1].length > numberOfDecimalPlaces);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummarySellerEditComponentService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummarySellerEditComponentService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummarySellerEditComponentService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteSummarySellerEditComponent {
    constructor() {
        this.quoteFacade = inject(QuoteFacade);
        this.quoteHeaderSellerEditComponentService = inject(QuoteSummarySellerEditComponentService);
        this.quoteUIConfig = inject(QuoteUIConfig);
        this.quoteDetailsForSeller$ = combineLatest([
            this.quoteHeaderSellerEditComponentService.getLocalizationElements(),
            this.quoteFacade.getQuoteDetails(),
        ]).pipe(filter(([_localizationElements, quote]) => this.quoteHeaderSellerEditComponentService.isEditable(quote)), tap(([localizationElements, quote]) => {
            this.discountUpdatePerforming$.next(false);
            this.fillFormAttributes(localizationElements, quote);
        }), map(([_localizationElements, quote]) => quote));
        this.form = new FormGroup({
            discount: new FormControl(null),
            validityDate: new FormControl(null),
        });
        this.iconType = ICON_TYPE;
        this.subscription = new Subscription();
        this.dateUpdates = new Subject();
        this.discountUpdatePerforming$ = new BehaviorSubject(false);
    }
    fillFormAttributes(localizationElements, quote) {
        this.discountPlaceholder = localizationElements.percentageSign;
        const numberFormatValidator = this.quoteHeaderSellerEditComponentService.getNumberFormatValidator(localizationElements.locale, localizationElements.percentageSign);
        this.form.controls.discount.addValidators([numberFormatValidator]);
        const discountValue = quote.sapQuoteDiscountsRate &&
            quote.sapQuoteDiscountsType === QuoteDiscountType.PERCENT
            ? quote.sapQuoteDiscountsRate / 100
            : 0;
        if (discountValue) {
            this.form.controls.discount.setValue(localizationElements.formatter.format(discountValue));
        }
        this.form.controls.validityDate.setValue(this.quoteHeaderSellerEditComponentService.removeTimeFromDate(quote.expirationTime?.toString()));
    }
    ngOnInit() {
        this.subscription.add(this.dateUpdates
            .pipe(debounceTime(this.quoteUIConfig.quote?.updateDebounceTime?.expiryDate ?? 500))
            .subscribe((payload) => {
            const quoteMetaData = {
                expirationTime: payload.date,
            };
            this.quoteFacade.editQuote(payload.quoteCode, quoteMetaData);
        }));
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    /**
     * Should the validation message be displayed?
     *
     * @returns True in case discount control has errors
     */
    mustDisplayValidationMessage() {
        return !this.form.controls.discount.valid;
    }
    /**
     * Parses current discount from control and sends absolute discount to the facade layer.
     *
     * @param quoteCode - Quote code
     */
    onApply(quoteCode) {
        if (this.form.controls.discount.valid) {
            combineLatest([
                this.quoteHeaderSellerEditComponentService.parseDiscountValue(this.form.controls.discount.value),
                this.discountUpdatePerforming$,
            ])
                .pipe(take(1))
                .subscribe(([parsedValue, discountUpdatePerforming]) => {
                if (!discountUpdatePerforming) {
                    this.discountUpdatePerforming$.next(true);
                    const discount = {
                        discountRate: parsedValue,
                        discountType: QuoteDiscountType.PERCENT,
                    };
                    this.quoteFacade.addDiscount(quoteCode, discount);
                }
            });
        }
    }
    /**
     * Prepares date for facade layer and sends it.
     *
     * @param quoteCode - Quote code
     */
    onSetDate(quoteCode) {
        const dateWithTime = this.quoteHeaderSellerEditComponentService.addTimeToDate(this.form.controls.validityDate.value);
        this.dateUpdates.next({ quoteCode: quoteCode, date: dateWithTime });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummarySellerEditComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: QuoteSummarySellerEditComponent, isStandalone: true, selector: "cx-quote-summary-seller-edit", viewQueries: [{ propertyName: "element", first: true, predicate: ["element"], descendants: true }], ngImport: i0, template: "<ng-container *ngIf=\"quoteDetailsForSeller$ | async as quoteDetails\">\n  <div class=\"cx-seller-edit-body\">\n    <form (ngSubmit)=\"onApply(quoteDetails.code)\" [formGroup]=\"form\">\n      <label>\n        <span class=\"label-content bold\">{{\n          'quote.summary.sellerEdit.discount' | cxTranslate\n        }}</span>\n        <div class=\"cx-discount-input\">\n          <input\n            [attr.aria-label]=\"\n              'quote.summary.sellerEdit.a11y.discount' | cxTranslate\n            \"\n            type=\"text\"\n            class=\"form-control\"\n            name=\"discount\"\n            placeholder=\"{{ discountPlaceholder }}\"\n            formControlName=\"discount\"\n          />\n          <button\n            [attr.aria-label]=\"\n              'quote.summary.sellerEdit.a11y.apply' | cxTranslate\n            \"\n            class=\"btn btn-block btn-secondary\"\n            (click)=\"onApply(quoteDetails.code)\"\n          >\n            {{ 'quote.summary.sellerEdit.apply' | cxTranslate }}\n          </button>\n        </div>\n\n        <div\n          class=\"cx-validation-msg\"\n          *ngIf=\"mustDisplayValidationMessage()\"\n          aria-live=\"assertive\"\n          aria-atomic=\"true\"\n          role=\"alert\"\n        >\n          <cx-icon [type]=\"iconType.ERROR\" />\n          {{ 'quote.summary.sellerEdit.discountValidationText' | cxTranslate }}\n        </div>\n      </label>\n\n      <label>\n        <span\n          [attr.aria-label]=\"\n            'quote.summary.sellerEdit.a11y.expiryDate' | cxTranslate\n          \"\n          class=\"label-content bold\"\n          >{{ 'quote.summary.sellerEdit.expiryDate' | cxTranslate }}</span\n        >\n        <cx-date-picker\n          [control]=\"$any(form.get('validityDate'))\"\n          [required]=\"true\"\n          (update)=\"onSetDate(quoteDetails.code)\"\n        />\n      </label>\n    </form>\n  </div>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "component", type: DatePickerComponent, selector: "cx-date-picker", inputs: ["control", "min", "max", "required", "label"], outputs: ["update"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummarySellerEditComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-quote-summary-seller-edit', imports: [
                        NgIf,
                        FormsModule,
                        ReactiveFormsModule,
                        IconComponent,
                        DatePickerComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<ng-container *ngIf=\"quoteDetailsForSeller$ | async as quoteDetails\">\n  <div class=\"cx-seller-edit-body\">\n    <form (ngSubmit)=\"onApply(quoteDetails.code)\" [formGroup]=\"form\">\n      <label>\n        <span class=\"label-content bold\">{{\n          'quote.summary.sellerEdit.discount' | cxTranslate\n        }}</span>\n        <div class=\"cx-discount-input\">\n          <input\n            [attr.aria-label]=\"\n              'quote.summary.sellerEdit.a11y.discount' | cxTranslate\n            \"\n            type=\"text\"\n            class=\"form-control\"\n            name=\"discount\"\n            placeholder=\"{{ discountPlaceholder }}\"\n            formControlName=\"discount\"\n          />\n          <button\n            [attr.aria-label]=\"\n              'quote.summary.sellerEdit.a11y.apply' | cxTranslate\n            \"\n            class=\"btn btn-block btn-secondary\"\n            (click)=\"onApply(quoteDetails.code)\"\n          >\n            {{ 'quote.summary.sellerEdit.apply' | cxTranslate }}\n          </button>\n        </div>\n\n        <div\n          class=\"cx-validation-msg\"\n          *ngIf=\"mustDisplayValidationMessage()\"\n          aria-live=\"assertive\"\n          aria-atomic=\"true\"\n          role=\"alert\"\n        >\n          <cx-icon [type]=\"iconType.ERROR\" />\n          {{ 'quote.summary.sellerEdit.discountValidationText' | cxTranslate }}\n        </div>\n      </label>\n\n      <label>\n        <span\n          [attr.aria-label]=\"\n            'quote.summary.sellerEdit.a11y.expiryDate' | cxTranslate\n          \"\n          class=\"label-content bold\"\n          >{{ 'quote.summary.sellerEdit.expiryDate' | cxTranslate }}</span\n        >\n        <cx-date-picker\n          [control]=\"$any(form.get('validityDate'))\"\n          [required]=\"true\"\n          (update)=\"onSetDate(quoteDetails.code)\"\n        />\n      </label>\n    </form>\n  </div>\n</ng-container>\n" }]
        }], propDecorators: { element: [{
                type: ViewChild,
                args: ['element']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteSummaryComponent {
    constructor() {
        this.quoteFacade = inject(QuoteFacade);
        this.quoteDetails$ = this.quoteFacade.getQuoteDetails();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: QuoteSummaryComponent, isStandalone: true, selector: "cx-quote-summary", ngImport: i0, template: "<ng-container\n  *ngIf=\"quoteDetails$ | async as quoteDetails; else ghostOrderSummary\"\n>\n  <div\n    class=\"cx-container\"\n    role=\"region\"\n    tabindex=\"-1\"\n    [attr.aria-label]=\"'quote.summary.regionTitle' | cxTranslate\"\n  >\n    <cx-quote-summary-prices />\n    <cx-quote-summary-seller-edit />\n    <cx-quote-summary-actions />\n  </div>\n</ng-container>\n\n<ng-template #ghostOrderSummary>\n  <div class=\"cx-ghost-summary-heading\">\n    <div class=\"cx-ghost-title ghost\"></div>\n  </div>\n  <div class=\"cx-ghost-summary-partials\">\n    <ng-container *ngFor=\"let number of [0, 1, 2, 3]\">\n      <div class=\"cx-ghost-row\">\n        <div class=\"cx-ghost-summary-label ghost\"></div>\n        <div class=\"cx-ghost-summary-amount ghost\"></div>\n      </div>\n    </ng-container>\n  </div>\n  <div class=\"cx-ghost-actions\">\n    <ng-container *ngFor=\"let number of [0, 1, 2]\">\n      <div class=\"cx-ghost-button ghost\"></div>\n    </ng-container>\n  </div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: QuoteSummaryPricesComponent, selector: "cx-quote-summary-prices" }, { kind: "component", type: QuoteSummarySellerEditComponent, selector: "cx-quote-summary-seller-edit" }, { kind: "component", type: QuoteSummaryActionsComponent, selector: "cx-quote-summary-actions" }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-quote-summary', imports: [
                        NgIf,
                        QuoteSummaryPricesComponent,
                        QuoteSummarySellerEditComponent,
                        QuoteSummaryActionsComponent,
                        NgFor,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<ng-container\n  *ngIf=\"quoteDetails$ | async as quoteDetails; else ghostOrderSummary\"\n>\n  <div\n    class=\"cx-container\"\n    role=\"region\"\n    tabindex=\"-1\"\n    [attr.aria-label]=\"'quote.summary.regionTitle' | cxTranslate\"\n  >\n    <cx-quote-summary-prices />\n    <cx-quote-summary-seller-edit />\n    <cx-quote-summary-actions />\n  </div>\n</ng-container>\n\n<ng-template #ghostOrderSummary>\n  <div class=\"cx-ghost-summary-heading\">\n    <div class=\"cx-ghost-title ghost\"></div>\n  </div>\n  <div class=\"cx-ghost-summary-partials\">\n    <ng-container *ngFor=\"let number of [0, 1, 2, 3]\">\n      <div class=\"cx-ghost-row\">\n        <div class=\"cx-ghost-summary-label ghost\"></div>\n        <div class=\"cx-ghost-summary-amount ghost\"></div>\n      </div>\n    </ng-container>\n  </div>\n  <div class=\"cx-ghost-actions\">\n    <ng-container *ngFor=\"let number of [0, 1, 2]\">\n      <div class=\"cx-ghost-button ghost\"></div>\n    </ng-container>\n  </div>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteSummarySellerEditModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummarySellerEditModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummarySellerEditModule, imports: [CommonModule,
            I18nModule,
            FormsModule,
            ReactiveFormsModule,
            IconModule,
            DatePickerModule,
            QuoteSummarySellerEditComponent], exports: [QuoteSummarySellerEditComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummarySellerEditModule, imports: [CommonModule,
            I18nModule,
            FormsModule,
            ReactiveFormsModule,
            IconModule,
            DatePickerModule,
            QuoteSummarySellerEditComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummarySellerEditModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        FormsModule,
                        ReactiveFormsModule,
                        IconModule,
                        DatePickerModule,
                        QuoteSummarySellerEditComponent,
                    ],
                    exports: [QuoteSummarySellerEditComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteSummaryModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryModule, imports: [CommonModule,
            I18nModule,
            QuoteSummaryPricesModule,
            QuoteSummarySellerEditModule,
            QuoteSummaryActionsModule,
            QuoteSummaryComponent], exports: [QuoteSummaryComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    QuoteSummaryComponent: {
                        component: QuoteSummaryComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            QuoteSummaryPricesModule,
            QuoteSummarySellerEditModule,
            QuoteSummaryActionsModule,
            QuoteSummaryComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteSummaryModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        QuoteSummaryPricesModule,
                        QuoteSummarySellerEditModule,
                        QuoteSummaryActionsModule,
                        QuoteSummaryComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                QuoteSummaryComponent: {
                                    component: QuoteSummaryComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                    ],
                    exports: [QuoteSummaryComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class QuoteComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: QuoteComponentsModule, imports: [CommonModule,
            ListNavigationModule,
            QuoteConfirmDialogModule,
            QuoteLinksModule,
            QuoteCommentsModule,
            QuoteHeaderBuyerEditModule,
            QuoteHeaderOverviewModule,
            QuoteItemsModule,
            QuoteListModule,
            QuoteSummaryModule,
            QuoteSummaryActionsModule,
            QuoteSummaryPricesModule,
            QuoteSummarySellerEditModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteComponentsModule, providers: [provideDefaultConfig(defaultQuoteUIConfig)], imports: [CommonModule,
            ListNavigationModule,
            QuoteConfirmDialogModule,
            QuoteLinksModule,
            QuoteCommentsModule,
            QuoteHeaderBuyerEditModule,
            QuoteHeaderOverviewModule,
            QuoteItemsModule,
            QuoteListModule,
            QuoteSummaryModule,
            QuoteSummaryActionsModule,
            QuoteSummaryPricesModule,
            QuoteSummarySellerEditModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: QuoteComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        ListNavigationModule,
                        QuoteConfirmDialogModule,
                        QuoteLinksModule,
                        QuoteCommentsModule,
                        QuoteHeaderBuyerEditModule,
                        QuoteHeaderOverviewModule,
                        QuoteItemsModule,
                        QuoteListModule,
                        QuoteSummaryModule,
                        QuoteSummaryActionsModule,
                        QuoteSummaryPricesModule,
                        QuoteSummarySellerEditModule,
                    ],
                    providers: [provideDefaultConfig(defaultQuoteUIConfig)],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { QuoteCommentsComponent, QuoteCommentsModule, QuoteComponentsModule, QuoteConfirmDialogComponent, QuoteConfirmDialogModule, QuoteHeaderBuyerEditComponent, QuoteHeaderBuyerEditModule, QuoteHeaderOverviewComponent, QuoteHeaderOverviewModule, QuoteItemsComponent, QuoteItemsComponentService, QuoteItemsModule, QuoteLinksComponent, QuoteLinksModule, QuoteListComponent, QuoteListComponentService, QuoteListModule, QuoteSummaryActionsComponent, QuoteSummaryActionsModule, QuoteSummaryComponent, QuoteSummaryModule, QuoteSummaryPricesComponent, QuoteSummaryPricesModule, QuoteSummarySellerEditComponent, QuoteSummarySellerEditComponentService, QuoteSummarySellerEditModule, QuoteUIConfig };
//# sourceMappingURL=spartacus-quote-components.mjs.map
