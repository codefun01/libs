import { Principal, Price, PaginationModel, SortModel, QueryState, HttpErrorHandler, GlobalMessageService, HttpResponseStatus, Priority, ErrorModel, RoutingService, RoutingConfig } from '@spartacus/core';
import { Observable } from 'rxjs';
import { OrderEntry } from '@spartacus/cart/base/root';
import * as i0 from '@angular/core';
import { HttpErrorResponse, HttpRequest } from '@angular/common/http';
import { LayoutConfig } from '@spartacus/storefront';
import * as i1 from '@angular/router';

interface OccQuote {
    allowedActions?: QuoteActionType[];
    cartId?: string;
    code: string;
    comments?: QuoteComment[];
    creationTime?: Date;
    description: string;
    entries?: OrderEntry[];
    expirationTime?: Date;
    name: string;
    orderDiscounts?: Price;
    previousEstimatedTotal?: Price;
    productDiscounts?: Price;
    quoteDiscounts?: Price;
    sapQuoteDiscountsRate?: number;
    sapQuoteDiscountsType?: QuoteDiscountType;
    sapAttachments?: QuoteAttachment[];
    state: QuoteState;
    sapSubtotalExcludingOrderLevelDiscount?: Price;
    subTotalWithDiscounts?: Price;
    threshold?: number;
    totalItems?: number;
    totalPrice: Price;
    totalPriceWithTax?: Price;
    updatedTime?: Date;
    version?: number;
    sapOrderCode?: string;
    sapPurchaseOrderNumber?: string;
}
type Quote = Omit<OccQuote, 'allowedActions'> & {
    isEditable: boolean;
    allowedActions: QuoteAction[];
};
interface QuoteAction {
    type: QuoteActionType;
    isPrimary: boolean;
}
interface QuoteComment {
    author?: Principal;
    creationDate?: Date;
    fromCustomer?: boolean;
    text?: string;
}
declare enum QuoteActionType {
    CREATE = "CREATE",
    VIEW = "VIEW",
    SUBMIT = "SUBMIT",
    SAVE = "SAVE",
    EDIT = "EDIT",
    DISCOUNT = "DISCOUNT",
    CANCEL = "CANCEL",
    CHECKOUT = "CHECKOUT",
    ORDER = "ORDER",
    APPROVE = "APPROVE",
    REJECT = "REJECT",
    EXPIRED = "EXPIRED",
    REQUOTE = "REQUOTE",
    DOWNLOAD_QUOTE_PROPOSAL_DOCUMENT = "DOWNLOAD_QUOTE_PROPOSAL_DOCUMENT"
}
declare enum QuoteState {
    BUYER_DRAFT = "BUYER_DRAFT",
    BUYER_SUBMITTED = "BUYER_SUBMITTED",
    BUYER_ACCEPTED = "BUYER_ACCEPTED",
    BUYER_APPROVED = "BUYER_APPROVED",
    BUYER_REJECTED = "BUYER_REJECTED",
    BUYER_OFFER = "BUYER_OFFER",
    BUYER_ORDERED = "BUYER_ORDERED",
    SELLER_DRAFT = "SELLER_DRAFT",
    SELLER_REQUEST = "SELLER_REQUEST",
    SELLER_SUBMITTED = "SELLER_SUBMITTED",
    SELLERAPPROVER_DRAFT = "SELLERAPPROVER_DRAFT",
    SELLERAPPROVER_PENDING = "SELLERAPPROVER_PENDING",
    SELLERAPPROVER_APPROVED = "SELLERAPPROVER_APPROVED",
    SELLERAPPROVER_REJECTED = "SELLERAPPROVER_REJECTED",
    CREATED = "CREATED",
    CANCELLED = "CANCELLED",
    EXPIRED = "EXPIRED"
}
declare enum QuoteDiscountType {
    PERCENT = "PERCENT",
    ABSOLUTE = "ABSOLUTE"
}
declare enum QuoteRoleType {
    ALL = "ALL",
    BUYER = "BUYER",
    SELLER = "SELLER",
    SELLERAPPROVER = "SELLERAPPROVER"
}
interface QuoteDiscount {
    discountRate: number;
    discountType: QuoteDiscountType;
}
interface QuoteList {
    pagination: PaginationModel;
    sorts?: SortModel[];
    quotes: Quote[];
}
/**
 * Used for updating quotes
 */
interface QuoteMetadata {
    description?: string;
    expirationTime?: string;
    name?: string;
    purchaseOrderNumber?: string;
}
interface QuoteStarter {
    cartId?: string;
    quoteCode?: string;
}
type QuoteActionsByState = {
    [key in QuoteState]: QuoteActionType[];
};
interface QuotesStateParams {
    currentPage$: Observable<number>;
    sort$: Observable<string>;
}
interface QuoteAttachment {
    id: string;
    filename?: string;
}

declare abstract class QuoteFacade {
    /**
     * Returns the query list state.
     *
     * @param params - QueryStateParams - query state parameters
     * @returns Observable emitting a list of quote states
     */
    abstract getQuotesState(params: QuotesStateParams): Observable<QueryState<QuoteList | undefined>>;
    /**
     * Creates quote with name and comment.
     *
     * @param quoteMetadata - quote meta data
     * @returns Observable emitting a quote
     */
    abstract createQuote(quoteMetadata: QuoteMetadata): Observable<Quote>;
    /**
     * Edits quote name, description or expiry date.
     *
     * @param quoteCode - quote code
     * @param quoteMetadata - quote meta data
     */
    abstract editQuote(quoteCode: string, quoteMetadata: QuoteMetadata): void;
    /**
     * Adds a comment to a quote. If an entry number is provided,
     * it will be added as item comment for this entry, otherwise as header comment.
     *
     * @param quoteCode - quote code
     * @param quoteComment - quote comment
     * @param entryNumber - entry number
     * @returns Observable emitting unknown
     */
    abstract addQuoteComment(quoteCode: string, quoteComment: QuoteComment, entryNumber?: string): Observable<unknown>;
    /**
     * Performs action on quote.
     *
     * @param quote - quote
     * @param quoteAction - quote action
     * @returns Observable emitting unknown
     */
    abstract performQuoteAction(quote: Quote, quoteAction: QuoteActionType): Observable<unknown>;
    /**
     * Re-quotes a quote.
     *
     * @param quoteCode - quote code
     * @returns Observable emitting a quote
     */
    abstract requote(quoteCode: string): Observable<Quote>;
    /**
     * Returns the quote details query state.
     *
     * @returns Observable emitting a query state of quote or unknown
     */
    abstract getQuoteDetailsQueryState(): Observable<QueryState<Quote | undefined>>;
    /**
     * Returns the quote details once it has been fully loaded.
     *
     * @returns Observable emitting a quote
     */
    abstract getQuoteDetails(): Observable<Quote>;
    /**
     * Adds a discount to a quote.
     *
     * @param quoteCode - Unique quote code
     * @param discount - Discount
     */
    abstract addDiscount(quoteCode: string, discount: QuoteDiscount): void;
    /**
     * Downloads the proposal document associated with a quote.
     *
     * @param quoteCode - Unique quote code
     * @param attachmentId - Unique attachment ID
     */
    abstract downloadAttachment(quoteCode: string, attachmentId: string): Observable<Blob>;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuoteFacade>;
}

declare const QUOTE_FEATURE = "quote";
declare const QUOTE_CART_GUARD_FEATURE = "quote_cart_guard";
declare const QUOTE_REQUEST_FEATURE = "quote_request";

declare class QuoteBadRequestHandler extends HttpErrorHandler {
    protected globalMessageService: GlobalMessageService;
    responseStatus: HttpResponseStatus;
    constructor(globalMessageService: GlobalMessageService);
    hasMatch(errorResponse: HttpErrorResponse): boolean;
    handleError(_request: HttpRequest<any>, response: HttpErrorResponse): void;
    getPriority(): Priority;
    protected isNotEmpty(errors: ErrorModel[]): boolean;
    protected isRelatedToQuotes(response: HttpErrorResponse): boolean;
    protected getQuoteThresholdErrors(response: HttpErrorResponse): ErrorModel[];
    protected getCartValidationErrors(response: HttpErrorResponse): ErrorModel[];
    protected getCartQuoteAccessErrors(response: HttpErrorResponse): ErrorModel[];
    protected getIllegalArgumentErrorsRelatedToQuote(response: HttpErrorResponse): ErrorModel[];
    protected isIllegalArgumentErrorRelatedToQuote(message?: string): boolean | "" | undefined;
    protected isIllegalArgumentErrorRelatedToQuoteDiscount(message: string): boolean;
    protected isIllegalArgumentErrorRelatedToQuoteExpiration(message: string): boolean;
    protected handleQuoteThresholdErrors(): void;
    protected handleCartValidationIssues(): void;
    protected handleCartQuoteAccessErrors(): void;
    protected handleIllegalArgumentIssues(message: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteBadRequestHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuoteBadRequestHandler>;
}

declare class QuoteNotFoundHandler extends HttpErrorHandler {
    protected globalMessageService: GlobalMessageService;
    protected routingService: RoutingService;
    responseStatus: HttpResponseStatus;
    constructor(globalMessageService: GlobalMessageService);
    hasMatch(errorResponse: HttpErrorResponse): boolean;
    handleError(_request: HttpRequest<any>): void;
    getPriority(): Priority;
    /**
     * This situation can happen e.g. if one ends an ASM emulation while viewing a quote and afterwards emulates a session
     * for a different user.
     *
     * @param response - HTTP response
     * @returns Array of error models or empty array if no issues occurred
     */
    protected getQuoteNotFoundErrors(response: HttpErrorResponse): ErrorModel[];
    protected navigateToQuoteList(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteNotFoundHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QuoteNotFoundHandler>;
}

declare module '@spartacus/cart/base/root' {
    interface OrderEntry {
        comments?: QuoteComment[];
    }
}
declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        QUOTE_ACTION_CONFIRMATION = "QUOTE_ACTION_CONFIRMATION"
    }
}

declare function defaultQuoteComponentsConfig(): {
    featureModules: {
        quote: {
            cmsComponents: string[];
        };
    };
};
declare function defaultQuoteCartGuardComponentConfig(): {
    featureModules: {
        quote_cart_guard: {
            cmsComponents: string[];
        };
    };
};
declare function defaultQuoteRequestComponentsConfig(): {
    featureModules: {
        quote_request: {
            cmsComponents: string[];
        };
    };
};
declare const defaultQuoteRoutingConfig: RoutingConfig;
declare const defaultQuoteConfigLayoutConfig: LayoutConfig;
/**
 * The ng route corresponding to the cxRoute 'quotes' is not defined here
 * as it is provided via CMS.
 * For the 'quoteDetails' route we need to provide an additional
 * corresponding ng route because of its parameter
 */
declare class QuoteRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<QuoteRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<QuoteRootModule, never, [typeof i1.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<QuoteRootModule>;
}

interface QuoteConfig {
}
declare module '@spartacus/core' {
    interface Config {
        quote?: QuoteConfig;
    }
}

export { QUOTE_CART_GUARD_FEATURE, QUOTE_FEATURE, QUOTE_REQUEST_FEATURE, QuoteActionType, QuoteBadRequestHandler, QuoteDiscountType, QuoteFacade, QuoteNotFoundHandler, QuoteRoleType, QuoteRootModule, QuoteState, defaultQuoteCartGuardComponentConfig, defaultQuoteComponentsConfig, defaultQuoteConfigLayoutConfig, defaultQuoteRequestComponentsConfig, defaultQuoteRoutingConfig };
export type { OccQuote, Quote, QuoteAction, QuoteActionsByState, QuoteAttachment, QuoteComment, QuoteConfig, QuoteDiscount, QuoteList, QuoteMetadata, QuoteStarter, QuotesStateParams };
