import { Rule } from '@angular-devkit/schematics';
/**
 * Creates a rule that updates the server.ts file to use index.server.html
 * instead of index.html when using the application builder.
 */
export declare function updateServerFile(): Rule;
