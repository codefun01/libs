import { Rule } from '@angular-devkit/schematics';
/**
 * Removes the obsolete `index` property from angular.json build configuration.
 *
 * The `index` property is no longer needed in Angular 20+ with the application builder.
 * This migration removes it from the build options to clean up the configuration.
 * For more, see: https://github.com/angular/angular-cli/commit/901ab60d9f63fcff17213dbf7fe17e4a46835974
 */
export declare function migrate(): Rule;
