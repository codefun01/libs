"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrate = migrate;
var workspace_utils_1 = require("../../../shared/utils/workspace-utils");
/**
 * Removes the obsolete `index` property from angular.json build configuration.
 *
 * The `index` property is no longer needed in Angular 20+ with the application builder.
 * This migration removes it from the build options to clean up the configuration.
 * For more, see: https://github.com/angular/angular-cli/commit/901ab60d9f63fcff17213dbf7fe17e4a46835974
 */
function migrate() {
    return function (tree, context) {
        var _a;
        context.logger.info('\n⌛️ Removing obsolete "index" property from angular.json...');
        var _b = (0, workspace_utils_1.getWorkspace)(tree), path = _b.path, angularJson = _b.workspace;
        var projectName = (0, workspace_utils_1.getDefaultProjectNameFromWorkspace)(tree);
        var project = angularJson.projects[projectName];
        var architect = project.architect;
        var build = architect === null || architect === void 0 ? void 0 : architect.build;
        var options = build === null || build === void 0 ? void 0 : build.options;
        // To avoid introducing to the @spartacus/schematics a new library `@angular-devkit/build-angular` where the `BrowserBuilderOptions` is located,
        //`as any` was used to satisfy TS compiler.
        if (!(options === null || options === void 0 ? void 0 : options.index)) {
            context.logger.info('  ↳ No "index" property found to remove');
            return tree;
        }
        context.logger.info('  ↳ Removing "index" property from build options');
        var updatedAngularJson = __assign(__assign({}, angularJson), { projects: __assign(__assign({}, angularJson.projects), (_a = {}, _a[projectName] = __assign(__assign({}, project), { architect: __assign(__assign({}, architect), { build: __assign(__assign({}, build), { options: __assign(__assign({}, options), { index: undefined }) }) }) }), _a)) });
        tree.overwrite(path, JSON.stringify(updatedAngularJson, null, 2));
        context.logger.info('✅ Removed obsolete "index" property from angular.json');
        return tree;
    };
}
//# sourceMappingURL=index.js.map