import { Rule } from '@angular-devkit/schematics';
/**
 * Migration that moves provideZoneChangeDetection from main.ts to app.module.ts.
 * This is a two-step process:
 * 1. Remove provideZoneChangeDetection from main.ts applicationProviders
 * 2. Add provideZoneChangeDetection to app.module.ts providers
 */
export declare function migrate(): Rule;
