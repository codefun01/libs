"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrate = migrate;
var schematics_1 = require("@angular-devkit/schematics");
var index_1 = require("./remove-zone-change-detection-from-main/index");
var index_2 = require("./add-zone-change-detection-to-app-module/index");
/**
 * Migration that moves provideZoneChangeDetection from main.ts to app.module.ts.
 * This is a two-step process:
 * 1. Remove provideZoneChangeDetection from main.ts applicationProviders
 * 2. Add provideZoneChangeDetection to app.module.ts providers
 */
function migrate() {
    return (0, schematics_1.chain)([
        (0, index_1.removeZoneChangeDetectionFromMain)(),
        (0, index_2.addZoneChangeDetectionToAppModule)(),
    ]);
}
//# sourceMappingURL=index.js.map