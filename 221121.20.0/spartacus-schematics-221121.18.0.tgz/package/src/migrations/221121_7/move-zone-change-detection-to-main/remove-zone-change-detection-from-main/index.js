"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeZoneChangeDetectionFromMain = removeZoneChangeDetectionFromMain;
var schematics_1 = require("@angular-devkit/schematics");
var ts_morph_1 = require("ts-morph");
var constants_1 = require("../../../../shared/constants");
var import_utils_1 = require("../../../../shared/utils/import-utils");
var program_1 = require("../../../../shared/utils/program");
var project_tsconfig_paths_1 = require("../../../../shared/utils/project-tsconfig-paths");
var workspace_utils_1 = require("../../../../shared/utils/workspace-utils");
/**
 * Main migration rule that removes provideZoneChangeDetection from main.ts.
 * This is part of the Angular 21 upgrade process to move zone configuration
 * from application providers to module providers.
 */
function removeZoneChangeDetectionFromMain() {
    return function (tree, context) {
        context.logger.info('⌛️ Removing provideZoneChangeDetection from main.ts...');
        var projectName = (0, workspace_utils_1.getDefaultProjectNameFromWorkspace)(tree);
        var buildPaths = (0, project_tsconfig_paths_1.getProjectTsConfigPaths)(tree, projectName).buildPaths;
        if (!buildPaths.length) {
            throw new schematics_1.SchematicsException('Could not find any tsconfig file. Cannot configure main.ts.');
        }
        // Process each tsconfig to find and modify main.ts files
        var basePath = process.cwd();
        for (var _i = 0, buildPaths_1 = buildPaths; _i < buildPaths_1.length; _i++) {
            var tsconfigPath = buildPaths_1[_i];
            removeProviderFromMainTs(tree, tsconfigPath, basePath, context);
        }
        context.logger.info('✅ provideZoneChangeDetection removed from main.ts successfully.');
        return tree;
    };
}
/**
 * Orchestrates the removal of provideZoneChangeDetection from main.ts.
 * Steps: find main.ts → check if provider exists → find bootstrap calls →
 * remove applicationProviders → cleanup imports → save changes.
 */
function removeProviderFromMainTs(tree, tsconfigPath, basePath, context) {
    var appSourceFiles = (0, program_1.createProgram)(tree, basePath, tsconfigPath).appSourceFiles;
    var sourceFile = findMainTsSourceFile(appSourceFiles);
    if (!sourceFile) {
        return;
    }
    // Early exit if the provider is not present in the file
    if (!hasProvideZoneChangeDetection(sourceFile)) {
        context.logger.info("provideZoneChangeDetection is not present in ".concat(constants_1.MAIN_TS, ". Skipping..."));
        return;
    }
    // Find all bootstrapModule calls to process
    var bootstrapCalls = findBootstrapModuleCalls(sourceFile);
    if (bootstrapCalls.length === 0) {
        context.logger.warn("Could not find bootstrapModule call in ".concat(constants_1.MAIN_TS, ". Skipping..."));
        return;
    }
    // Process each bootstrap call and remove applicationProviders
    var modified = processBootstrapCalls(bootstrapCalls, context);
    if (modified) {
        // Clean up unused imports and save the modified file
        cleanupUnusedImport(sourceFile, context);
        (0, program_1.saveAndFormat)(sourceFile);
    }
    else {
        context.logger.info("No applicationProviders property found in ".concat(constants_1.MAIN_TS, ". Skipping..."));
    }
}
/** Locates the main.ts source file from the list of application source files. */
function findMainTsSourceFile(appSourceFiles) {
    return appSourceFiles.find(function (sourceFile) {
        return sourceFile.getFilePath().endsWith("/".concat(constants_1.MAIN_TS));
    });
}
/** Checks if provideZoneChangeDetection is present in the source file. */
function hasProvideZoneChangeDetection(sourceFile) {
    return sourceFile.getFullText().includes(constants_1.PROVIDE_ZONE_CHANGE_DETECTION);
}
/**
 * Finds all bootstrapModule call expressions in the source file.
 * These calls are typically in the form: platformBrowserDynamic().bootstrapModule(AppModule)
 */
function findBootstrapModuleCalls(sourceFile) {
    return sourceFile
        .getDescendantsOfKind(ts_morph_1.SyntaxKind.CallExpression)
        .filter(function (callExpr) {
        var expression = callExpr.getExpression();
        return (expression.getKind() === ts_morph_1.SyntaxKind.PropertyAccessExpression &&
            expression.getText().includes('bootstrapModule'));
    });
}
/**
 * Processes each bootstrapModule call to remove the applicationProviders property.
 * Returns true if any modifications were made.
 */
function processBootstrapCalls(bootstrapCalls, context) {
    var modified = false;
    for (var _i = 0, bootstrapCalls_1 = bootstrapCalls; _i < bootstrapCalls_1.length; _i++) {
        var bootstrapCall = bootstrapCalls_1[_i];
        var args = bootstrapCall.getArguments();
        // Skip if there's no second argument (options object)
        if (args.length < 2) {
            continue;
        }
        var optionsArg = args[1];
        // Skip if the second argument is not an object literal
        if (optionsArg.getKind() !== ts_morph_1.SyntaxKind.ObjectLiteralExpression) {
            continue;
        }
        var objectLiteral = optionsArg.asKindOrThrow(ts_morph_1.SyntaxKind.ObjectLiteralExpression);
        var applicationProvidersProperty = findApplicationProvidersProperty(objectLiteral);
        if (applicationProvidersProperty) {
            // Remove only provideZoneChangeDetection from applicationProviders array
            var removed = removeProviderFromArray(applicationProvidersProperty, context);
            if (removed) {
                modified = true;
                // Remove the property if the array is now empty
                removeEmptyApplicationProviders(applicationProvidersProperty, context);
                // If the options object is now empty, remove it entirely
                removeEmptyOptionsObject(objectLiteral, bootstrapCall, context);
            }
        }
    }
    return modified;
}
/**
 * Finds the applicationProviders property within the bootstrap options object.
 * Only processes PropertyAssignment nodes to avoid errors with spread operators.
 */
function findApplicationProvidersProperty(objectLiteral) {
    return objectLiteral.getProperties().find(function (prop) {
        if (prop.getKind() === ts_morph_1.SyntaxKind.PropertyAssignment) {
            var propertyAssignment = prop.asKind(ts_morph_1.SyntaxKind.PropertyAssignment);
            return (propertyAssignment === null || propertyAssignment === void 0 ? void 0 : propertyAssignment.getName()) === 'applicationProviders';
        }
        return false;
    });
}
/**
 * Removes only provideZoneChangeDetection from the applicationProviders array.
 * Preserves other custom providers that customers might have added.
 * Returns true if the provider was found and removed.
 */
function removeProviderFromArray(applicationProvidersProperty, context) {
    var propertyAssignment = applicationProvidersProperty.asKind(ts_morph_1.SyntaxKind.PropertyAssignment);
    if (!propertyAssignment) {
        return false;
    }
    var initializer = propertyAssignment.getInitializer();
    if (!initializer ||
        initializer.getKind() !== ts_morph_1.SyntaxKind.ArrayLiteralExpression) {
        return false;
    }
    var arrayLiteral = initializer.asKindOrThrow(ts_morph_1.SyntaxKind.ArrayLiteralExpression);
    var elements = arrayLiteral.getElements();
    // Find and remove provideZoneChangeDetection call
    for (var i = 0; i < elements.length; i++) {
        var element = elements[i];
        if (element.getKind() === ts_morph_1.SyntaxKind.CallExpression &&
            element.getText().includes(constants_1.PROVIDE_ZONE_CHANGE_DETECTION)) {
            arrayLiteral.removeElement(i);
            context.logger.info("  \u21B3 Removed ".concat(constants_1.PROVIDE_ZONE_CHANGE_DETECTION, " from applicationProviders array"));
            return true;
        }
    }
    return false;
}
/**
 * Removes the applicationProviders property if its array is empty.
 */
function removeEmptyApplicationProviders(applicationProvidersProperty, context) {
    var propertyAssignment = applicationProvidersProperty.asKind(ts_morph_1.SyntaxKind.PropertyAssignment);
    if (!propertyAssignment) {
        return;
    }
    var initializer = propertyAssignment.getInitializer();
    if (initializer &&
        initializer.getKind() === ts_morph_1.SyntaxKind.ArrayLiteralExpression) {
        var arrayLiteral = initializer.asKindOrThrow(ts_morph_1.SyntaxKind.ArrayLiteralExpression);
        if (arrayLiteral.getElements().length === 0) {
            applicationProvidersProperty.remove();
            context.logger.info("  \u21B3 Removed empty applicationProviders property");
        }
    }
}
/**
 * Removes the entire options object if it's empty after removing applicationProviders.
 * Example: bootstrapModule(AppModule, {}) becomes bootstrapModule(AppModule)
 */
function removeEmptyOptionsObject(objectLiteral, bootstrapCall, context) {
    if (objectLiteral.getProperties().length === 0) {
        bootstrapCall.removeArgument(1);
        context.logger.info("  \u21B3 Removed empty options object from bootstrapModule call");
    }
}
/**
 * Removes the provideZoneChangeDetection import if it's no longer used in the file.
 */
function cleanupUnusedImport(sourceFile, context) {
    var updatedContent = sourceFile.getFullText();
    var isStillUsed = updatedContent.includes(constants_1.PROVIDE_ZONE_CHANGE_DETECTION);
    if (!isStillUsed) {
        (0, import_utils_1.removeImports)(sourceFile, [
            {
                node: constants_1.PROVIDE_ZONE_CHANGE_DETECTION,
                importPath: constants_1.ANGULAR_CORE,
            },
        ]);
        context.logger.info("  \u21B3 Removed unused import of ".concat(constants_1.PROVIDE_ZONE_CHANGE_DETECTION));
    }
}
//# sourceMappingURL=index.js.map