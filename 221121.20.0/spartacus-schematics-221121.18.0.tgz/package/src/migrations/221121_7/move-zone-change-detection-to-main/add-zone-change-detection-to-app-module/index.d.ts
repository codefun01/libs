import { Rule } from '@angular-devkit/schematics';
/**
 * Main migration rule that adds provideZoneChangeDetection to app.module.ts.
 * This is part of the Angular 21 upgrade process to move zone configuration
 * from application providers to module providers.
 */
export declare function addZoneChangeDetectionToAppModule(): Rule;
