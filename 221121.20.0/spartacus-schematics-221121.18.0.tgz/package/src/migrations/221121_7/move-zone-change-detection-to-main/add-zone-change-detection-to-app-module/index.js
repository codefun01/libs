"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addZoneChangeDetectionToAppModule = addZoneChangeDetectionToAppModule;
var schematics_1 = require("@angular-devkit/schematics");
var constants_1 = require("../../../../shared/constants");
var new_module_utils_1 = require("../../../../shared/utils/new-module-utils");
var program_1 = require("../../../../shared/utils/program");
var project_tsconfig_paths_1 = require("../../../../shared/utils/project-tsconfig-paths");
var workspace_utils_1 = require("../../../../shared/utils/workspace-utils");
/**
 * Main migration rule that adds provideZoneChangeDetection to app.module.ts.
 * This is part of the Angular 21 upgrade process to move zone configuration
 * from application providers to module providers.
 */
function addZoneChangeDetectionToAppModule() {
    return function (tree, context) {
        context.logger.info('⌛️ Adding provideZoneChangeDetection to app.module.ts...');
        var projectName = (0, workspace_utils_1.getDefaultProjectNameFromWorkspace)(tree);
        var buildPaths = (0, project_tsconfig_paths_1.getProjectTsConfigPaths)(tree, projectName).buildPaths;
        if (!buildPaths.length) {
            throw new schematics_1.SchematicsException('Could not find any tsconfig file. Cannot configure app.module.ts.');
        }
        // Process each tsconfig to find and modify app.module.ts files
        var basePath = process.cwd();
        for (var _i = 0, buildPaths_1 = buildPaths; _i < buildPaths_1.length; _i++) {
            var tsconfigPath = buildPaths_1[_i];
            addProviderToAppModule(tree, tsconfigPath, basePath, context);
        }
        context.logger.info('✅ provideZoneChangeDetection added successfully.');
        return tree;
    };
}
/**
 * Adds provideZoneChangeDetection({ eventCoalescing: true }) to app.module.ts providers array.
 * Skips if the provider is already present to avoid duplicates.
 */
function addProviderToAppModule(tree, tsconfigPath, basePath, context) {
    var appSourceFiles = (0, program_1.createProgram)(tree, basePath, tsconfigPath).appSourceFiles;
    // Find app.module.ts and add the provider
    for (var _i = 0, appSourceFiles_1 = appSourceFiles; _i < appSourceFiles_1.length; _i++) {
        var sourceFile = appSourceFiles_1[_i];
        if (sourceFile.getFilePath().includes(constants_1.APP_MODULE)) {
            // Skip if provider is already present
            if (isProviderAlreadyAdded(sourceFile)) {
                context.logger.info("provideZoneChangeDetection is already present in ".concat(constants_1.APP_MODULE, ". Skipping..."));
                return;
            }
            // Add the provider and save the file
            addProvider(sourceFile);
            (0, program_1.saveAndFormat)(sourceFile);
            break;
        }
    }
}
/** Checks if provideZoneChangeDetection is already present in the file to avoid duplicates. */
function isProviderAlreadyAdded(sourceFile) {
    var fileContent = sourceFile.getFullText();
    return fileContent.includes(constants_1.PROVIDE_ZONE_CHANGE_DETECTION);
}
/**
 * Adds provideZoneChangeDetection({ eventCoalescing: true }) to the @NgModule providers array.
 * Uses addModuleProvider utility to handle import addition and provider insertion.
 */
function addProvider(sourceFile) {
    (0, new_module_utils_1.addModuleProvider)(sourceFile, {
        import: {
            moduleSpecifier: constants_1.ANGULAR_CORE,
            namedImports: [constants_1.PROVIDE_ZONE_CHANGE_DETECTION],
        },
        content: "".concat(constants_1.PROVIDE_ZONE_CHANGE_DETECTION, "({ eventCoalescing: true })"),
    });
}
//# sourceMappingURL=index.js.map