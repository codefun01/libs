import { Rule } from '@angular-devkit/schematics';
/**
 * Migration to add `build:ssr` script to package.json.
 *
 * This migration only runs for apps that use SSR (Server-Side Rendering).
 * The script is required for CCv2 build process.
 */
export declare function migrate(): Rule;
