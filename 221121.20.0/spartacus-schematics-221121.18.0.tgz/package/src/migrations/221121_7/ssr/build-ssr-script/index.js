"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrate = migrate;
var schematics_1 = require("@angular-devkit/schematics");
var package_utils_1 = require("../../../../shared/utils/package-utils");
/**
 * Adds `build:ssr` script to `package.json` as it's required for CCv2 build - process fails when script is missing.
 *
 * This migration adds the script back if it was removed during Angular 20 migration
 * (by the `use-application-builder` schematic).
 *
 * TODO: CXSPA-6466 Can be removed if Model T adjust their build process to not require this script.
 */
function addBuildSsrScript() {
    return function (tree, context) {
        var _a;
        context.logger.info('\n⌛️ Adding "build:ssr" script to package.json...');
        var pkgPath = '/package.json';
        var pkg = tree.readJson(pkgPath);
        if (pkg === null) {
            throw new schematics_1.SchematicsException('Could not find package.json');
        }
        if ((_a = pkg.scripts) === null || _a === void 0 ? void 0 : _a['build:ssr']) {
            context.logger.info('  ↳ "build:ssr" script already exists - skipping addition');
            return tree;
        }
        pkg.scripts = __assign(__assign({}, pkg.scripts), { 'build:ssr': 'ng build' });
        tree.overwrite(pkgPath, JSON.stringify(pkg, null, 2));
        context.logger.info('✅ Added "build:ssr" script to package.json');
        return tree;
    };
}
/**
 * Migration to add `build:ssr` script to package.json.
 *
 * This migration only runs for apps that use SSR (Server-Side Rendering).
 * The script is required for CCv2 build process.
 */
function migrate() {
    return function (tree, context) {
        if (!(0, package_utils_1.isSsrUsed)(tree)) {
            context.logger.info('\n  ↳ SSR is not configured - skipping build:ssr script migration');
            return (0, schematics_1.noop)();
        }
        return addBuildSsrScript()(tree, context);
    };
}
//# sourceMappingURL=index.js.map