import { Rule } from '@angular-devkit/schematics';
/**
 * Migration to upgrade Express to v5.1.0 and update server.ts for Express 5 compatibility.
 *
 * This migration:
 * 1. Updates Express dependency to ^5.1.0 in package.json
 * 2. Updates server.ts to replace wildcard strings with regex patterns:
 *    - '*.*' becomes regex pattern matching files with extensions
 *    - '*' becomes regex pattern matching all routes
 *
 * This migration only runs for apps that use SSR (Server-Side Rendering).
 */
export declare function migrate(): Rule;
