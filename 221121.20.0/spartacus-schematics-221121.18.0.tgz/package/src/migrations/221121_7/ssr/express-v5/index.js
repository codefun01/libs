"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrate = migrate;
var schematics_1 = require("@angular-devkit/schematics");
var dependencies_1 = require("@schematics/angular/utility/dependencies");
var ts_morph_1 = require("ts-morph");
var package_utils_1 = require("../../../../shared/utils/package-utils");
var program_1 = require("../../../../shared/utils/program");
var project_tsconfig_paths_1 = require("../../../../shared/utils/project-tsconfig-paths");
var workspace_utils_1 = require("../../../../shared/utils/workspace-utils");
function findServerFile(tree, basePath, tsconfigPath, expectedServerPath) {
    var appSourceFiles = (0, program_1.createProgram)(tree, basePath, tsconfigPath).appSourceFiles;
    return appSourceFiles.find(function (sourceFile) {
        return sourceFile.getFilePath().endsWith(expectedServerPath);
    });
}
function getExpressInstanceName(serverFile) {
    var variableDeclarations = serverFile.getDescendantsOfKind(ts_morph_1.SyntaxKind.VariableDeclaration);
    for (var _i = 0, variableDeclarations_1 = variableDeclarations; _i < variableDeclarations_1.length; _i++) {
        var varDecl = variableDeclarations_1[_i];
        var initializer = varDecl.getInitializer();
        if ((initializer === null || initializer === void 0 ? void 0 : initializer.getKind()) !== ts_morph_1.SyntaxKind.CallExpression) {
            continue;
        }
        var callExpr = initializer.asKind(ts_morph_1.SyntaxKind.CallExpression);
        if ((callExpr === null || callExpr === void 0 ? void 0 : callExpr.getExpression().getText()) === 'express') {
            return varDecl.getName();
        }
    }
}
function updateExpressWildcardRoutes(serverFile, expressInstanceName) {
    var callExpressions = serverFile.getDescendantsOfKind(ts_morph_1.SyntaxKind.CallExpression);
    var replacementsMade = false;
    for (var _i = 0, callExpressions_1 = callExpressions; _i < callExpressions_1.length; _i++) {
        var callExpr = callExpressions_1[_i];
        var expression = callExpr.getExpression();
        if (expression.getKind() !== ts_morph_1.SyntaxKind.PropertyAccessExpression) {
            continue;
        }
        var propAccess = expression.asKind(ts_morph_1.SyntaxKind.PropertyAccessExpression);
        if (!propAccess ||
            propAccess.getExpression().getText() !== expressInstanceName ||
            propAccess.getName() !== 'get') {
            continue;
        }
        var args = callExpr.getArguments();
        if (args.length === 0) {
            continue;
        }
        var firstArg = args[0];
        if (firstArg.getKind() !== ts_morph_1.SyntaxKind.StringLiteral) {
            continue;
        }
        var argText = firstArg.getText().slice(1, -1);
        if (argText === '*.*') {
            firstArg.replaceWithText('/.*\\..*/');
            replacementsMade = true;
            continue;
        }
        if (argText === '*') {
            firstArg.replaceWithText('/.*/');
            replacementsMade = true;
        }
    }
    return replacementsMade;
}
/**
 * Updates server.ts file to replace wildcard strings with regex patterns for Express 5 compatibility.
 * Uses ts-morph to parse and manipulate the AST.
 */
function updateServerTsFile() {
    return function (tree, context) {
        context.logger.info('\n⌛️ Updating server.ts for Express 5 compatibility...');
        var project = (0, workspace_utils_1.getDefaultProjectNameFromWorkspace)(tree);
        var buildPaths = (0, project_tsconfig_paths_1.getProjectTsConfigPaths)(tree, project).buildPaths;
        if (!buildPaths.length) {
            context.logger.info('  ↳ No server.ts file found - skipping server.ts updates');
            return;
        }
        var basePath = process.cwd();
        var serverFileFound = false;
        var expectedServerPath = (0, package_utils_1.getServerTsPathForApplicationBuilder)(tree);
        if (!expectedServerPath) {
            context.logger.warn('  ↳ Could not determine server.ts path from angular.json - skipping server.ts updates');
            return;
        }
        for (var _i = 0, buildPaths_1 = buildPaths; _i < buildPaths_1.length; _i++) {
            var tsconfigPath = buildPaths_1[_i];
            var serverFile = findServerFile(tree, basePath, tsconfigPath, expectedServerPath);
            if (!serverFile) {
                continue;
            }
            serverFileFound = true;
            var expressInstanceName = getExpressInstanceName(serverFile);
            if (!expressInstanceName) {
                context.logger.warn("  \u21B3 Could not find Express app instance (e.g., 'const app = express()') in:");
                context.logger.warn("     ".concat(serverFile.getFilePath()));
                context.logger.info("  \u21B3 Skipping server.ts update - please update manually if needed");
                continue;
            }
            var replacementsMade = updateExpressWildcardRoutes(serverFile, expressInstanceName);
            if (replacementsMade) {
                (0, program_1.saveAndFormat)(serverFile);
                context.logger.info("\u2705 Updated ".concat(serverFile.getFilePath(), " for Express 5 compatibility"));
            }
            else {
                context.logger.info("  \u21B3 ".concat(serverFile.getFilePath(), " already uses Express 5 compatible patterns or no changes needed"));
            }
            return;
        }
        if (!serverFileFound) {
            context.logger.info('  ↳ No server.ts file found - skipping server.ts updates');
        }
    };
}
/**
 * Updates Express dependency to version 5.1.0 in package.json.
 */
function updateExpressDependency() {
    return function (tree, context) {
        var _a, _b;
        var packageJson = (0, package_utils_1.readPackageJson)(tree);
        var dependencies = [];
        if ((_a = packageJson.dependencies) === null || _a === void 0 ? void 0 : _a.express) {
            dependencies.push({
                name: 'express',
                version: '^5.1.0',
                type: dependencies_1.NodeDependencyType.Default,
                overwrite: true,
            });
        }
        if ((_b = packageJson.devDependencies) === null || _b === void 0 ? void 0 : _b.express) {
            dependencies.push({
                name: 'express',
                version: '^5.1.0',
                type: dependencies_1.NodeDependencyType.Dev,
                overwrite: true,
            });
        }
        if (dependencies.length === 0) {
            context.logger.info('  ↳ Express is not installed - skipping Express dependency update');
            return (0, schematics_1.noop)();
        }
        return (0, package_utils_1.updatePackageJsonDependencies)(dependencies, packageJson)(tree, context);
    };
}
/**
 * Migration to upgrade Express to v5.1.0 and update server.ts for Express 5 compatibility.
 *
 * This migration:
 * 1. Updates Express dependency to ^5.1.0 in package.json
 * 2. Updates server.ts to replace wildcard strings with regex patterns:
 *    - '*.*' becomes regex pattern matching files with extensions
 *    - '*' becomes regex pattern matching all routes
 *
 * This migration only runs for apps that use SSR (Server-Side Rendering).
 */
function migrate() {
    return function (tree, context) {
        if (!(0, package_utils_1.isSsrUsed)(tree)) {
            context.logger.info('\n  ↳ SSR is not configured - skipping Express 5 migration');
            return (0, schematics_1.noop)();
        }
        return (0, schematics_1.chain)([updateExpressDependency(), updateServerTsFile()])(tree, context);
    };
}
//# sourceMappingURL=index.js.map