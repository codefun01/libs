"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GENERATED_RENAMED_SYMBOLS_DATA = void 0;
//
// Generated file, don't update manually.
//
exports.GENERATED_RENAMED_SYMBOLS_DATA = [
    {
        previousNode: 'cdsTranslationChunksConfig',
        previousImportPath: '@spartacus/cds',
        newImportPath: '@spartacus/cds/assets',
    },
];
//# sourceMappingURL=generated-rename-symbols.migration.js.map