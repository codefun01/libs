"use strict";
/*
 * SPDX-FileCopyrightText: 2025 SAP Spartacus team <spartacus-team@sap.com>
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrate = migrate;
var schematics_1 = require("@angular-devkit/schematics");
var constants_1 = require("../../../shared/constants");
var new_module_utils_1 = require("../../../shared/utils/new-module-utils");
var program_1 = require("../../../shared/utils/program");
var project_tsconfig_paths_1 = require("../../../shared/utils/project-tsconfig-paths");
var workspace_utils_1 = require("../../../shared/utils/workspace-utils");
var PROVIDE_BROWSER_GLOBAL_ERROR_LISTENERS = 'provideBrowserGlobalErrorListeners';
function migrate() {
    return function (tree, context) {
        context.logger.info('⌛️ Adding provideBrowserGlobalErrorListeners to app.module.ts...');
        var projectName = (0, workspace_utils_1.getDefaultProjectNameFromWorkspace)(tree);
        var buildPaths = (0, project_tsconfig_paths_1.getProjectTsConfigPaths)(tree, projectName).buildPaths;
        if (!buildPaths.length) {
            throw new schematics_1.SchematicsException('Could not find any tsconfig file. Cannot configure app.module.ts.');
        }
        var basePath = process.cwd();
        for (var _i = 0, buildPaths_1 = buildPaths; _i < buildPaths_1.length; _i++) {
            var tsconfigPath = buildPaths_1[_i];
            addProviderToAppModule(tree, tsconfigPath, basePath, context);
        }
        context.logger.info('✅ provideBrowserGlobalErrorListeners added successfully.');
        return tree;
    };
}
function addProviderToAppModule(tree, tsconfigPath, basePath, context) {
    var appSourceFiles = (0, program_1.createProgram)(tree, basePath, tsconfigPath).appSourceFiles;
    for (var _i = 0, appSourceFiles_1 = appSourceFiles; _i < appSourceFiles_1.length; _i++) {
        var sourceFile = appSourceFiles_1[_i];
        if (sourceFile.getFilePath().includes(constants_1.APP_MODULE)) {
            if (isProviderAlreadyAdded(sourceFile)) {
                context.logger.info("provideBrowserGlobalErrorListeners is already present in ".concat(constants_1.APP_MODULE, ". Skipping..."));
                return;
            }
            addProvider(sourceFile);
            (0, program_1.saveAndFormat)(sourceFile);
            break;
        }
    }
}
function isProviderAlreadyAdded(sourceFile) {
    var fileContent = sourceFile.getFullText();
    return fileContent.includes(PROVIDE_BROWSER_GLOBAL_ERROR_LISTENERS);
}
function addProvider(sourceFile) {
    (0, new_module_utils_1.addModuleProvider)(sourceFile, {
        import: {
            moduleSpecifier: constants_1.ANGULAR_CORE,
            namedImports: [PROVIDE_BROWSER_GLOBAL_ERROR_LISTENERS],
        },
        content: "".concat(PROVIDE_BROWSER_GLOBAL_ERROR_LISTENERS, "()"),
    });
}
//# sourceMappingURL=index.js.map