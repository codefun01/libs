import { Rule } from '@angular-devkit/schematics';
/**
 * Updates tsconfig.json to be compatible with Angular 21.
 *
 * Changes made:
 * - Removes `outDir` from compilerOptions
 * - Removes `esModuleInterop` from compilerOptions
 * - Removes `moduleResolution` from compilerOptions
 * - Changes `module` from "ES2022" to "preserve"
 * - Adds `files: []` at the root level
 * - Adds `references` array with paths to tsconfig.app.json and tsconfig.spec.json
 *
 * For more, see: https://angular.dev/reference/configs/angular-compiler-options
 */
export declare function migrate(): Rule;
