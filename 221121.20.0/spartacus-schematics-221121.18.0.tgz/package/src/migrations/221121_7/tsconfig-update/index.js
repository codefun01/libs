"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrate = migrate;
var jsonc_parser_1 = require("jsonc-parser");
/**
 * Updates tsconfig.json to be compatible with Angular 21.
 *
 * Changes made:
 * - Removes `outDir` from compilerOptions
 * - Removes `esModuleInterop` from compilerOptions
 * - Removes `moduleResolution` from compilerOptions
 * - Changes `module` from "ES2022" to "preserve"
 * - Adds `files: []` at the root level
 * - Adds `references` array with paths to tsconfig.app.json and tsconfig.spec.json
 *
 * For more, see: https://angular.dev/reference/configs/angular-compiler-options
 */
function migrate() {
    return function (tree, context) {
        var tsconfigPath = '/tsconfig.json';
        if (!tree.exists(tsconfigPath)) {
            return tree;
        }
        var tsconfigBuffer = tree.read(tsconfigPath);
        if (!tsconfigBuffer) {
            return tree;
        }
        var content = tsconfigBuffer.toString();
        var tsconfig = (0, jsonc_parser_1.parse)(content, undefined, { allowTrailingComma: true });
        var options = { formattingOptions: { tabSize: 2, insertSpaces: true } };
        var _a = updateTsconfigProperties(content, tsconfig, options, context), hasChanges = _a.hasChanges, updatedContent = _a.updatedContent;
        if (hasChanges) {
            tree.overwrite(tsconfigPath, updatedContent);
            context.logger.info('✅ Updated tsconfig.json');
        }
        return tree;
    };
}
function updateTsconfigProperties(content, tsconfig, options, context) {
    var _a, _b;
    var updatedContent = content;
    var hasChanges = false;
    // Remove obsolete compiler options
    var propsToRemove = ['outDir', 'esModuleInterop', 'moduleResolution'];
    for (var _i = 0, propsToRemove_1 = propsToRemove; _i < propsToRemove_1.length; _i++) {
        var prop = propsToRemove_1[_i];
        if (((_a = tsconfig.compilerOptions) === null || _a === void 0 ? void 0 : _a[prop]) !== undefined) {
            context.logger.info("  \u21B3 Removing \"".concat(prop, "\" from compilerOptions"));
            updatedContent = (0, jsonc_parser_1.applyEdits)(updatedContent, (0, jsonc_parser_1.modify)(updatedContent, ['compilerOptions', prop], undefined, options));
            hasChanges = true;
        }
    }
    // Update module to "preserve"
    if (((_b = tsconfig.compilerOptions) === null || _b === void 0 ? void 0 : _b.module) &&
        tsconfig.compilerOptions.module !== 'preserve') {
        context.logger.info('  ↳ Updating "module" to "preserve"');
        updatedContent = (0, jsonc_parser_1.applyEdits)(updatedContent, (0, jsonc_parser_1.modify)(updatedContent, ['compilerOptions', 'module'], 'preserve', options));
        hasChanges = true;
    }
    // Add files array if not present
    if (!tsconfig.files) {
        context.logger.info('  ↳ Adding "files" array');
        updatedContent = (0, jsonc_parser_1.applyEdits)(updatedContent, (0, jsonc_parser_1.modify)(updatedContent, ['files'], [], options));
        hasChanges = true;
    }
    // Add references array if not present
    if (!tsconfig.references) {
        context.logger.info('  ↳ Adding "references" array');
        updatedContent = (0, jsonc_parser_1.applyEdits)(updatedContent, (0, jsonc_parser_1.modify)(updatedContent, ['references'], [{ path: './tsconfig.app.json' }, { path: './tsconfig.spec.json' }], options));
        hasChanges = true;
    }
    return { hasChanges: hasChanges, updatedContent: updatedContent };
}
//# sourceMappingURL=index.js.map