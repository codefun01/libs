import { Rule } from '@angular-devkit/schematics';
/**
 * Living migration that runs on every `ng update @spartacus/schematics`.
 * Its `version` in `migrations.json` is updated to match the package version on
 * every release so it always fires, whether the customer is installing for the
 * first time or refreshing existing skills.
 *
 * In a TTY, detects whether skills are already present and prompts accordingly
 * ("Install" vs "Update"). Then does a full delete + copy so no stale files
 * remain. In CI / `--force` it falls back to a printed notice.
 */
export declare function migrate(): Rule;
