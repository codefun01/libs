import { SchematicContext, Tree } from '@angular-devkit/schematics';
import { AiTool } from '../../add-spartacus/schema';
export declare const SKILLS_PACKAGE = "@spartacus/skills";
export declare const SUPPORTED_TOOLS: readonly AiTool[];
export declare const PROMPT_INDENT = "  ";
/**
 * Migrations run non-interactively in CI / `--force`; callers must guard on this
 * before prompting and fall back to a printed notice otherwise.
 */
export declare function isInteractiveTerminal(): boolean;
/** Returns the AI tools for which skills are already present in the tree. */
export declare function detectInstalledTools(tree: Tree): AiTool[];
export declare function promptYesNo(question: string, defaultYes?: boolean): Promise<boolean>;
export declare function promptTools(): Promise<AiTool[]>;
/**
 * Adds `@spartacus/skills` to devDependencies and schedules an npm install
 * followed by the `ai-context` schematic with `deleteBeforeCopy: true`.
 *
 * Copy depends on the install task so it runs only once `@spartacus/skills` is
 * present in `node_modules`.
 */
export declare function scheduleSkillsDeleteAndCopy(tree: Tree, context: SchematicContext, tools: AiTool[]): void;
export declare function printSkillsNotice(context: SchematicContext): void;
