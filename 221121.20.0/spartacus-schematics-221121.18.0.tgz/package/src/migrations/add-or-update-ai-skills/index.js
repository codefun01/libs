"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrate = migrate;
var ai_context_utils_1 = require("./ai-context.utils");
function writePromptLine(line) {
    process.stdout.write("".concat(line ? ai_context_utils_1.PROMPT_INDENT + line : '', "\n"));
}
/**
 * Living migration that runs on every `ng update @spartacus/schematics`.
 * Its `version` in `migrations.json` is updated to match the package version on
 * every release so it always fires, whether the customer is installing for the
 * first time or refreshing existing skills.
 *
 * In a TTY, detects whether skills are already present and prompts accordingly
 * ("Install" vs "Update"). Then does a full delete + copy so no stale files
 * remain. In CI / `--force` it falls back to a printed notice.
 */
function migrate() {
    var _this = this;
    return function (tree, context) { return __awaiter(_this, void 0, void 0, function () {
        var installedTools, isUpdate, verb, confirmed, tools, _a;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    if (!(0, ai_context_utils_1.isInteractiveTerminal)()) {
                        (0, ai_context_utils_1.printSkillsNotice)(context);
                        return [2 /*return*/];
                    }
                    installedTools = (0, ai_context_utils_1.detectInstalledTools)(tree);
                    isUpdate = installedTools.length > 0;
                    verb = isUpdate ? 'Update' : 'Install';
                    writePromptLine('');
                    writePromptLine("\u2728 Spartacus can configure AI-assistant guidance (Claude / .agents) for this project.");
                    return [4 /*yield*/, (0, ai_context_utils_1.promptYesNo)("".concat(ai_context_utils_1.PROMPT_INDENT).concat(verb, " AI skills for Spartacus development?"))];
                case 1:
                    confirmed = _b.sent();
                    if (!confirmed) {
                        writePromptLine("Skipped. Add or update them later with: ng g @spartacus/schematics:ai-context");
                        writePromptLine('');
                        return [2 /*return*/];
                    }
                    if (!isUpdate) return [3 /*break*/, 2];
                    _a = installedTools;
                    return [3 /*break*/, 4];
                case 2: return [4 /*yield*/, (0, ai_context_utils_1.promptTools)()];
                case 3:
                    _a = _b.sent();
                    _b.label = 4;
                case 4:
                    tools = _a;
                    if (tools.length === 0) {
                        writePromptLine("No AI tools selected \u2014 nothing to ".concat(verb.toLowerCase(), "."));
                        writePromptLine('');
                        return [2 /*return*/];
                    }
                    (0, ai_context_utils_1.scheduleSkillsDeleteAndCopy)(tree, context, tools);
                    writePromptLine("AI skills will be ".concat(isUpdate ? 'updated' : 'installed', " once the update finishes."));
                    writePromptLine('');
                    return [2 /*return*/];
            }
        });
    }); };
}
//# sourceMappingURL=index.js.map