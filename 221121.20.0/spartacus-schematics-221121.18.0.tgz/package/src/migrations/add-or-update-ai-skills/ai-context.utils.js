"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PROMPT_INDENT = exports.SUPPORTED_TOOLS = exports.SKILLS_PACKAGE = void 0;
exports.isInteractiveTerminal = isInteractiveTerminal;
exports.detectInstalledTools = detectInstalledTools;
exports.promptYesNo = promptYesNo;
exports.promptTools = promptTools;
exports.scheduleSkillsDeleteAndCopy = scheduleSkillsDeleteAndCopy;
exports.printSkillsNotice = printSkillsNotice;
var tasks_1 = require("@angular-devkit/schematics/tasks");
var dependencies_1 = require("@schematics/angular/utility/dependencies");
var readline = __importStar(require("readline"));
var package_utils_1 = require("../../shared/utils/package-utils");
exports.SKILLS_PACKAGE = '@spartacus/skills';
var SPARTACUS_SCHEMATICS = '@spartacus/schematics';
var AI_CONTEXT_SCHEMATIC = 'ai-context';
var SKILL_DIR = 'spartacus-developer';
exports.SUPPORTED_TOOLS = ['claude', 'agents'];
exports.PROMPT_INDENT = '  ';
var TOOL_LABEL = {
    claude: '.claude (.claude/skills/spartacus-developer/)',
    agents: '.agents (.agents/skills/spartacus-developer/)',
};
var SKILL_SENTINEL = {
    claude: ".claude/skills/".concat(SKILL_DIR, "/SKILL.md"),
    agents: ".agents/skills/".concat(SKILL_DIR, "/SKILL.md"),
};
/**
 * Migrations run non-interactively in CI / `--force`; callers must guard on this
 * before prompting and fall back to a printed notice otherwise.
 */
function isInteractiveTerminal() {
    return Boolean(process.stdin.isTTY && process.stdout.isTTY);
}
/** Returns the AI tools for which skills are already present in the tree. */
function detectInstalledTools(tree) {
    return exports.SUPPORTED_TOOLS.filter(function (tool) { return tree.exists(SKILL_SENTINEL[tool]); });
}
function ask(question) {
    return new Promise(function (resolve) {
        var rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout,
        });
        rl.question(question, function (answer) {
            rl.close();
            resolve(answer.trim());
        });
    });
}
function promptYesNo(question_1) {
    return __awaiter(this, arguments, void 0, function (question, defaultYes) {
        var hint, answer;
        if (defaultYes === void 0) { defaultYes = true; }
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    hint = defaultYes ? '(Y/n)' : '(y/N)';
                    return [4 /*yield*/, ask("".concat(question, " ").concat(hint, " "))];
                case 1:
                    answer = (_a.sent()).toLowerCase();
                    if (!answer) {
                        return [2 /*return*/, defaultYes];
                    }
                    return [2 /*return*/, answer === 'y' || answer === 'yes'];
            }
        });
    });
}
function promptTools() {
    return __awaiter(this, void 0, void 0, function () {
        var tools, _i, SUPPORTED_TOOLS_1, tool;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    tools = [];
                    _i = 0, SUPPORTED_TOOLS_1 = exports.SUPPORTED_TOOLS;
                    _a.label = 1;
                case 1:
                    if (!(_i < SUPPORTED_TOOLS_1.length)) return [3 /*break*/, 4];
                    tool = SUPPORTED_TOOLS_1[_i];
                    return [4 /*yield*/, promptYesNo("".concat(exports.PROMPT_INDENT, "Configure ").concat(TOOL_LABEL[tool], "?"))];
                case 2:
                    if (_a.sent()) {
                        tools.push(tool);
                    }
                    _a.label = 3;
                case 3:
                    _i++;
                    return [3 /*break*/, 1];
                case 4: return [2 /*return*/, tools];
            }
        });
    });
}
/**
 * Adds `@spartacus/skills` to devDependencies and schedules an npm install
 * followed by the `ai-context` schematic with `deleteBeforeCopy: true`.
 *
 * Copy depends on the install task so it runs only once `@spartacus/skills` is
 * present in `node_modules`.
 */
function scheduleSkillsDeleteAndCopy(tree, context, tools) {
    (0, dependencies_1.addPackageJsonDependency)(tree, {
        type: dependencies_1.NodeDependencyType.Dev,
        name: exports.SKILLS_PACKAGE,
        version: (0, package_utils_1.getPrefixedSpartacusSchematicsVersion)(),
        overwrite: true,
    });
    var installTaskId = context.addTask(new tasks_1.NodePackageInstallTask());
    context.addTask(new tasks_1.RunSchematicTask(SPARTACUS_SCHEMATICS, AI_CONTEXT_SCHEMATIC, {
        aiTools: tools,
        deleteBeforeCopy: true,
    }), [installTaskId]);
}
function printSkillsNotice(context) {
    var skillsVersion = (0, package_utils_1.getPrefixedSpartacusSchematicsVersion)();
    context.logger.info([
        '',
        '✨ Install or update AI skills for Spartacus development (Claude / .agents).',
        "   The ".concat(exports.SKILLS_PACKAGE, " package ships guidance that helps AI assistants"),
        '   follow Spartacus best practices. To add or update it in this project:',
        '',
        "     npm install --save-dev ".concat(exports.SKILLS_PACKAGE, "@").concat(skillsVersion),
        "     ng g ".concat(SPARTACUS_SCHEMATICS, ":").concat(AI_CONTEXT_SCHEMATIC),
        '',
        "   The schematic copies the ".concat(SKILL_DIR, " skill into .claude/skills/").concat(SKILL_DIR, "/"),
        "   and/or .agents/skills/".concat(SKILL_DIR, "/."),
        '',
        "   Prefer not to use the schematic? Copy the skill manually \u2014 see the",
        "   ".concat(exports.SKILLS_PACKAGE, " README."),
        '',
    ].join('\n'));
}
//# sourceMappingURL=ai-context.utils.js.map