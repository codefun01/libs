"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateServerFile = updateServerFile;
var core_1 = require("@angular-devkit/core");
var ts = __importStar(require("typescript"));
/**
 * Finds the server.ts file in the project.
 * Checks both root and src directory locations.
 */
function findServerFile(tree) {
    var possiblePaths = ['./server.ts', './src/server.ts'];
    for (var _i = 0, possiblePaths_1 = possiblePaths; _i < possiblePaths_1.length; _i++) {
        var path = possiblePaths_1[_i];
        if (tree.exists((0, core_1.normalize)(path))) {
            return path;
        }
    }
    return null;
}
/**
 * Determines if a string literal uses single or double quotes.
 * @param node - The string literal node to check
 * @returns true for single quotes, false for double quotes
 */
function getQuotePreference(node) {
    return node.getText().startsWith("'");
}
/**
 * Checks if a node is a join() call with 'index.html' as the last argument.
 * Also determines the quote style used in the original code.
 */
function isJoinCallWithIndexHtml(node) {
    if (!ts.isCallExpression(node)) {
        return { isMatch: false };
    }
    if (!ts.isIdentifier(node.expression) || node.expression.text !== 'join') {
        return { isMatch: false };
    }
    var lastArg = node.arguments[node.arguments.length - 1];
    if (!ts.isStringLiteral(lastArg)) {
        return { isMatch: false };
    }
    if (lastArg.text === 'index.html') {
        return {
            isMatch: true,
            quotePreference: getQuotePreference(lastArg),
        };
    }
    return { isMatch: false };
}
/**
 * Visits the node and tries to find recursively the indexHtml const.
 * When found, it updates the indexHtml const to use serverDistFolder and index.server.html.
 */
function visitNodeToUpdateIndexHtmlConst(node, content) {
    var updatedContent = content;
    if (ts.isVariableStatement(node)) {
        var declarations = node.declarationList.declarations;
        if (declarations.length === 1) {
            var declaration = declarations[0];
            if (ts.isIdentifier(declaration.name) &&
                declaration.name.text === 'indexHtml' &&
                declaration.initializer) {
                var _a = isJoinCallWithIndexHtml(declaration.initializer), isMatch = _a.isMatch, quotePreference = _a.quotePreference;
                if (isMatch) {
                    var originalText = node.getText();
                    var quote = quotePreference ? "'" : '"';
                    var newText = "const indexHtml = join(serverDistFolder, ".concat(quote, "index.server.html").concat(quote, ");");
                    updatedContent = updatedContent.replace(originalText, newText);
                }
            }
        }
    }
    // Recursively visit all children
    ts.forEachChild(node, function (childNode) {
        updatedContent = visitNodeToUpdateIndexHtmlConst(childNode, updatedContent);
    });
    return updatedContent;
}
/**
 * Creates a rule that updates the server.ts file to use index.server.html
 * instead of index.html when using the application builder.
 */
function updateServerFile() {
    return function (tree, context) {
        context.logger.info('🔍 Checking if server.ts needs to be updated...');
        var serverFilePath = findServerFile(tree);
        if (!serverFilePath) {
            context.logger.warn('🔍 Could not find server.ts file - skipping update');
            return tree;
        }
        context.logger.info("\uD83D\uDD04 Updating ".concat(serverFilePath, " to use index.server.html"));
        var fileContentBuffer = tree.read(serverFilePath);
        if (!fileContentBuffer) {
            context.logger.warn("\u26A0\uFE0F Could not read ".concat(serverFilePath, " - skipping update"));
            return tree;
        }
        var content = fileContentBuffer.toString('utf-8');
        var sourceFile = ts.createSourceFile('server.ts', content, ts.ScriptTarget.Latest, true);
        var updatedContent = visitNodeToUpdateIndexHtmlConst(sourceFile, content);
        if (updatedContent !== content) {
            tree.overwrite(serverFilePath, updatedContent);
            context.logger.info("\u2705 Successfully updated ".concat(serverFilePath));
        }
        return tree;
    };
}
//# sourceMappingURL=update-server-files.js.map