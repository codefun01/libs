"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrate = migrate;
var schematics_1 = require("@angular-devkit/schematics");
var package_utils_1 = require("../../../shared/utils/package-utils");
var update_server_files_1 = require("./update-ssr/update-server-files");
function migrate() {
    return function (tree, _context) {
        return (0, package_utils_1.isSsrUsed)(tree) ? (0, update_server_files_1.updateServerFile)() : (0, schematics_1.noop)();
    };
}
//# sourceMappingURL=ssr.js.map