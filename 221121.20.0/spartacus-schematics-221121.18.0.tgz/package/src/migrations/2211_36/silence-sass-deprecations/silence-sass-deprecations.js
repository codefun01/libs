"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrate = migrate;
var workspace_utils_1 = require("../../../shared/utils/workspace-utils");
function migrate() {
    return function (tree, context) {
        var _a;
        var _b = (0, workspace_utils_1.getWorkspace)(tree), path = _b.path, angularJson = _b.workspace;
        var projectName = (0, workspace_utils_1.getDefaultProjectNameFromWorkspace)(tree);
        var project = angularJson.projects[projectName];
        var architect = project.architect;
        var buildOptions = (_a = architect === null || architect === void 0 ? void 0 : architect.build) === null || _a === void 0 ? void 0 : _a.options;
        var buildStylePreprocessorOptions = buildOptions.stylePreprocessorOptions;
        buildOptions.stylePreprocessorOptions = __assign(__assign({}, buildStylePreprocessorOptions), (0, workspace_utils_1.createSassSilenceDeprecations)(context, buildStylePreprocessorOptions));
        var JSON_INDENT = 2;
        tree.overwrite(path, JSON.stringify(angularJson, null, JSON_INDENT));
    };
}
//# sourceMappingURL=silence-sass-deprecations.js.map