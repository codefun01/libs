"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrate = migrate;
var schematics_1 = require("@angular-devkit/schematics");
var replace_bootstrap_imports_1 = require("./replace-bootstrap-imports");
var node_child_process_1 = require("node:child_process");
function migrate() {
    return function (tree, context) {
        return (0, schematics_1.chain)([
            uninstallBootstrap(),
            updateMainStylesFileImports(),
            (0, replace_bootstrap_imports_1.replaceBootstrapImports)(),
        ])(tree, context);
    };
}
function uninstallBootstrap() {
    var _this = this;
    return function (tree, context) {
        return function () { return __awaiter(_this, void 0, void 0, function () {
            var packageManager, uninstallCommand;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        packageManager = '';
                        if (tree.exists('yarn.lock')) {
                            packageManager = 'yarn';
                        }
                        else if (tree.exists('pnpm-lock.yaml')) {
                            packageManager = 'pnpm';
                        }
                        else if (tree.exists('package-lock.json')) {
                            packageManager = 'npm';
                        }
                        uninstallCommand = '';
                        if (packageManager === 'yarn') {
                            uninstallCommand = 'yarn remove bootstrap';
                        }
                        else if (packageManager === 'pnpm') {
                            uninstallCommand = 'pnpm remove bootstrap';
                        }
                        else if (packageManager === 'npm') {
                            uninstallCommand = 'npm uninstall bootstrap';
                        }
                        else {
                            context.logger.warn('Could not detect a package manager. Please uninstall Bootstrap manually.');
                            return [2 /*return*/];
                        }
                        context.logger.info("Running uninstall command: ".concat(uninstallCommand));
                        return [4 /*yield*/, new Promise(function (resolve) {
                                var child = (0, node_child_process_1.spawn)(uninstallCommand, { shell: true });
                                child.on('close', function (code) {
                                    if (code === 0) {
                                        context.logger.info('Bootstrap uninstalled successfully.');
                                        resolve();
                                    }
                                    else {
                                        context.logger.error("Bootstrap uninstall failed with exit code ".concat(code, ". Please uninstall Bootstrap manually."));
                                        resolve();
                                    }
                                });
                            })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        }); };
    };
}
function updateMainStylesFileImports() {
    return function (tree, context) {
        var _a;
        var filePath = 'src/styles.scss';
        if (!tree.exists(filePath)) {
            context.logger.warn("File ".concat(filePath, " does not exist."));
            return tree;
        }
        var fileContent = (_a = tree.read(filePath)) === null || _a === void 0 ? void 0 : _a.toString('utf-8');
        if (!fileContent) {
            context.logger.warn("File ".concat(filePath, " is empty or could not be read."));
            return tree;
        }
        context.logger.info("Updating Bootstrap imports in '".concat(filePath, "'..."));
        var styleImportsToInsert = "@import 'styles-config';\n" +
            "\n// ORDER IMPORTANT: Spartacus core first\n" +
            "@import '@spartacus/styles/scss/core';\n\n" +
            "// ORDER IMPORTANT: Copy of Bootstrap files next\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/reboot';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/type';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/grid';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/utilities';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/transitions';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/dropdown';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/card';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/nav';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/buttons';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/forms';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/custom-forms';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/modal';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/close';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/alert';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/tooltip';\n\n" +
            "// ORDER IMPORTANT: Spartacus styles last\n" +
            "@import '@spartacus/styles/index';\n";
        var updatedContent = fileContent
            .replace(/\/\* You can add global styles to this file, and also import other style files \*\//g, '')
            .replace(/@import\s+['"]@spartacus\/styles\/index['"];/g, '')
            .replace(/@import ['"]styles-config['"];/g, styleImportsToInsert);
        tree.overwrite(filePath, updatedContent);
        context.logger.info("Bootstrap imports updated successfully in '".concat(filePath, "'."));
        return tree;
    };
}
//# sourceMappingURL=bootstrap.js.map