"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.addAiContextSchematic = addAiContextSchematic;
var fs = __importStar(require("fs"));
var path = __importStar(require("path"));
var SUPPORTED_TOOLS = ['claude', 'agents'];
var SKILLS_PACKAGE = '@spartacus/skills';
var SKILL_DIR = 'spartacus-developer';
var SKILL_DEST = {
    claude: ".claude/skills/".concat(SKILL_DIR),
    agents: ".agents/skills/".concat(SKILL_DIR),
};
/**
 * Standalone schematic that copies the Spartacus `spartacus-developer` skill
 * from an installed `@spartacus/skills` package into the project, shaped for
 * the selected AI assistants. Run it after installing `@spartacus/skills`:
 *
 *   ng g @spartacus/schematics:ai-context
 *   ng g @spartacus/schematics:ai-context --ai-tools=claude --ai-tools=cursor
 *
 * Note: Angular CLI auto-kebab-cases camelCase schema props (aiTools →
 * ai-tools) and refuses comma-separated values for array flags — repeat
 * the flag once per value.
 */
function addAiContextSchematic(options) {
    return function (tree, context) {
        var targets = normalize(options.aiTools);
        if (targets.length === 0) {
            if (options.debug) {
                context.logger.info("\u2139\uFE0F  Skipping AI context \u2014 no aiTools selected.");
            }
            return;
        }
        var skillsRoot = resolveSkillsRoot();
        if (!skillsRoot) {
            context.logger.warn("Could not find '".concat(SKILLS_PACKAGE, "' in node_modules. Install it first ") +
                "('npm install --save-dev ".concat(SKILLS_PACKAGE, "'), then run ") +
                "'ng generate @spartacus/schematics:ai-context'.");
            return;
        }
        if (options.debug) {
            context.logger.info("\u231B\uFE0F Writing AI context for: ".concat(targets.join(', ')));
        }
        var files = collectFiles(skillsRoot);
        for (var _i = 0, targets_1 = targets; _i < targets_1.length; _i++) {
            var target = targets_1[_i];
            copySkill(tree, files, target, {
                deleteBeforeCopy: options.deleteBeforeCopy,
            });
        }
        if (options.debug) {
            context.logger.info("\u2705 AI context written.");
        }
    };
}
/**
 * Resolves the `spartacus-developer` skill directory inside the installed
 * `@spartacus/skills` package, relative to the consuming project.
 */
function resolveSkillsRoot() {
    var override = process.env.SPARTACUS_SKILLS_DIR;
    if (override !== undefined) {
        return fs.existsSync(override) ? override : null;
    }
    try {
        var packageJsonPath = require.resolve("".concat(SKILLS_PACKAGE, "/package.json"), {
            paths: [process.cwd()],
        });
        var root = path.join(path.dirname(packageJsonPath), 'skills', SKILL_DIR);
        if (fs.existsSync(root)) {
            return root;
        }
    }
    catch (_a) {
        // fall through to the explicit node_modules lookup below
    }
    var fallback = path.join(process.cwd(), 'node_modules', '@spartacus', 'skills', 'skills', SKILL_DIR);
    return fs.existsSync(fallback) ? fallback : null;
}
function collectFiles(root) {
    var out = [];
    walk(root, '', out);
    return out.sort(function (a, b) { return a.relativePath.localeCompare(b.relativePath); });
}
function walk(root, rel, out) {
    var dir = path.join(root, rel);
    for (var _i = 0, _a = fs.readdirSync(dir, { withFileTypes: true }); _i < _a.length; _i++) {
        var entry = _a[_i];
        var next = rel ? "".concat(rel, "/").concat(entry.name) : entry.name;
        if (entry.isDirectory()) {
            walk(root, next, out);
        }
        else if (entry.isFile()) {
            out.push({
                relativePath: next,
                content: fs.readFileSync(path.join(root, next), 'utf8'),
            });
        }
    }
}
function copySkill(tree, files, target, options) {
    var dest = SKILL_DEST[target];
    if (options === null || options === void 0 ? void 0 : options.deleteBeforeCopy) {
        deleteSkillDir(tree, dest);
    }
    writeSkillTree(tree, files, dest);
}
function deleteSkillDir(tree, destBase) {
    tree.getDir(destBase).visit(function (filePath) { return tree.delete(filePath); });
}
function writeSkillTree(tree, files, destBase) {
    for (var _i = 0, files_1 = files; _i < files_1.length; _i++) {
        var file = files_1[_i];
        var dest = "".concat(destBase, "/").concat(file.relativePath);
        if (tree.exists(dest)) {
            tree.overwrite(dest, file.content);
        }
        else {
            tree.create(dest, file.content);
        }
    }
}
function normalize(input) {
    if (!input || input.length === 0) {
        return [];
    }
    var seen = new Set();
    for (var _i = 0, input_1 = input; _i < input_1.length; _i++) {
        var value = input_1[_i];
        if (SUPPORTED_TOOLS.includes(value)) {
            seen.add(value);
        }
    }
    return SUPPORTED_TOOLS.filter(function (tool) { return seen.has(tool); });
}
//# sourceMappingURL=index.js.map