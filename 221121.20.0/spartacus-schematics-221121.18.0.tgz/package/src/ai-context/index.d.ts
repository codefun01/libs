import { Rule } from '@angular-devkit/schematics';
import { Schema } from './schema';
/**
 * Standalone schematic that copies the Spartacus `spartacus-developer` skill
 * from an installed `@spartacus/skills` package into the project, shaped for
 * the selected AI assistants. Run it after installing `@spartacus/skills`:
 *
 *   ng g @spartacus/schematics:ai-context
 *   ng g @spartacus/schematics:ai-context --ai-tools=claude --ai-tools=cursor
 *
 * Note: Angular CLI auto-kebab-cases camelCase schema props (aiTools →
 * ai-tools) and refuses comma-separated values for array flags — repeat
 * the flag once per value.
 */
export declare function addAiContextSchematic(options: Schema): Rule;
