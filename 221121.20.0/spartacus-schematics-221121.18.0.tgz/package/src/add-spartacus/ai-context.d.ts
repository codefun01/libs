import { Rule } from '@angular-devkit/schematics';
import { Schema as SpartacusOptions } from './schema';
/**
 * Adds `@spartacus/skills` as a dev dependency; the copy into the project runs
 * post-install in {@link scheduleAiContext}.
 */
export declare function addAiContext(options: SpartacusOptions): Rule;
/**
 * Runs the `ai-context` copy schematic only after the install task, so
 * `@spartacus/skills` is present in `node_modules`.
 */
export declare function scheduleAiContext(options: SpartacusOptions): Rule;
