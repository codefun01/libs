"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addAiContext = addAiContext;
exports.scheduleAiContext = scheduleAiContext;
var tasks_1 = require("@angular-devkit/schematics/tasks");
var dependencies_1 = require("@schematics/angular/utility/dependencies");
var package_utils_1 = require("../shared/utils/package-utils");
var SUPPORTED_TOOLS = ['claude', 'agents'];
var SKILLS_PACKAGE = '@spartacus/skills';
/**
 * Adds `@spartacus/skills` as a dev dependency; the copy into the project runs
 * post-install in {@link scheduleAiContext}.
 */
function addAiContext(options) {
    return function (tree, context) {
        var targets = normalize(options.aiTools);
        if (targets.length === 0) {
            if (options.debug) {
                context.logger.info("\u2139\uFE0F  Skipping AI context \u2014 no aiTools selected.");
            }
            return;
        }
        (0, dependencies_1.addPackageJsonDependency)(tree, {
            type: dependencies_1.NodeDependencyType.Dev,
            name: SKILLS_PACKAGE,
            version: (0, package_utils_1.getPrefixedSpartacusSchematicsVersion)(),
            overwrite: false,
        });
        if (options.debug) {
            context.logger.info("\u2705\uFE0F Added '".concat(SKILLS_PACKAGE, "' into devDependencies"));
        }
    };
}
/**
 * Runs the `ai-context` copy schematic only after the install task, so
 * `@spartacus/skills` is present in `node_modules`.
 */
function scheduleAiContext(options) {
    return function (_tree, context) {
        var targets = normalize(options.aiTools);
        if (targets.length === 0) {
            return;
        }
        var installTaskId = context.addTask(new tasks_1.NodePackageInstallTask());
        context.addTask(new tasks_1.RunSchematicTask('ai-context', {
            aiTools: targets,
            debug: options.debug,
        }), [installTaskId]);
        context.logger.info("\u2139\uFE0F  Spartacus AI skills (".concat(SKILLS_PACKAGE, ") will be copied into your project after install. ") +
            "Re-run 'ng generate @spartacus/schematics:ai-context' anytime to refresh them after updating the package.");
    };
}
function normalize(input) {
    if (!input || input.length === 0) {
        return [];
    }
    var seen = new Set();
    for (var _i = 0, input_1 = input; _i < input_1.length; _i++) {
        var value = input_1[_i];
        if (SUPPORTED_TOOLS.includes(value)) {
            seen.add(value);
        }
    }
    return SUPPORTED_TOOLS.filter(function (tool) { return seen.has(tool); });
}
//# sourceMappingURL=ai-context.js.map