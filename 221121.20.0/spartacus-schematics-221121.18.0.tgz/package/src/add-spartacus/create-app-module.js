"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAppModule = createAppModule;
var schematics_1 = require("@angular-devkit/schematics");
var constants_1 = require("../shared/constants");
var program_1 = require("../shared/utils/program");
var project_tsconfig_paths_1 = require("../shared/utils/project-tsconfig-paths");
/**
 * Creates app.module.ts file if it doesn't exist (for standalone apps).
 */
function createAppModule(options) {
    return function (tree, context) {
        if (options.debug) {
            context.logger.info("\u231B\uFE0F Checking if ".concat(constants_1.APP_MODULE, " needs to be created..."));
        }
        var project = options.project;
        var buildPaths = (0, project_tsconfig_paths_1.getProjectTsConfigPaths)(tree, project).buildPaths;
        var basePath = process.cwd();
        var appSourceFiles = (0, program_1.createProgram)(tree, basePath, buildPaths[0]).appSourceFiles;
        // Check if app.module.ts already exists
        var appModuleExists = appSourceFiles.some(function (sourceFile) {
            return sourceFile.getFilePath().includes(constants_1.APP_MODULE);
        });
        if (!appModuleExists) {
            if (options.debug) {
                context.logger.info("\u270F\uFE0F Creating app.module.ts for standalone application...");
            }
            // Find the app directory
            var appDir_1 = null;
            tree.visit(function (filePath) {
                if (filePath.endsWith("/app/".concat(constants_1.APP_COMPONENT))) {
                    appDir_1 = filePath.substring(0, filePath.lastIndexOf('/'));
                }
            });
            if (!appDir_1) {
                throw new schematics_1.SchematicsException('Could not find app directory');
            }
            var appModulePath = "".concat(appDir_1, "/").concat(constants_1.APP_MODULE);
            var appModuleContent = "\nimport { NgModule } from '@angular/core';\n\n@NgModule({})\nexport class AppModule {}\n";
            tree.create(appModulePath, appModuleContent);
            if (options.debug) {
                context.logger.info("\u2705 Created ".concat(appModulePath));
            }
        }
        else if (options.debug) {
            context.logger.info("\u2705 ".concat(constants_1.APP_MODULE, " already exists"));
        }
        if (options.debug) {
            context.logger.info("\u2705 App module check complete.");
        }
        return tree;
    };
}
//# sourceMappingURL=create-app-module.js.map