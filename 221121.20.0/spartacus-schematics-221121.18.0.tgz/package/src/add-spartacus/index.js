"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getMainStyleFilePath = getMainStyleFilePath;
exports.createStylePreprocessorOptions = createStylePreprocessorOptions;
exports.addSpartacus = addSpartacus;
var schematics_1 = require("@angular-devkit/schematics");
var constants_1 = require("../shared/constants");
var dependency_utils_1 = require("../shared/utils/dependency-utils");
var feature_utils_1 = require("../shared/utils/feature-utils");
var file_utils_1 = require("../shared/utils/file-utils");
var html_utils_1 = require("../shared/utils/html-utils");
var lib_utils_1 = require("../shared/utils/lib-utils");
var package_utils_1 = require("../shared/utils/package-utils");
var program_1 = require("../shared/utils/program");
var project_tsconfig_paths_1 = require("../shared/utils/project-tsconfig-paths");
var styling_utils_1 = require("../shared/utils/styling-utils");
var workspace_utils_1 = require("../shared/utils/workspace-utils");
var add_storefront_component_to_app_component_1 = require("./add-storefront-component-to-app-component");
// TODO CXSPA-13991: Re-enable once @spartacus/skills passes audit and ships in the release bundle.
// import { addAiContext, scheduleAiContext } from './ai-context';
var configuration_1 = require("./configuration");
var create_app_module_1 = require("./create-app-module");
var spartacus_1 = require("./spartacus");
var spartacus_feature_toggles_1 = require("./spartacus-feature-toggles");
var spartacus_features_1 = require("./spartacus-features");
var store_1 = require("./store");
var update_app_config_1 = require("./update-app-config");
var update_app_module_1 = require("./update-app-module");
function createStylesConfig(options) {
    return function (tree, context) {
        var project = (0, workspace_utils_1.getProjectFromWorkspace)(tree, options);
        var styleConfigFilePath = (0, styling_utils_1.getStylesConfigFilePath)(project.sourceRoot);
        var styleConfigContent = "$styleVersion: ".concat(options.featureLevel || (0, package_utils_1.getSpartacusCurrentFeatureLevel)());
        if (tree.exists(styleConfigFilePath)) {
            context.logger.warn("Skipping styles config file creation. File ".concat(styleConfigFilePath, " already exists."));
        }
        else {
            tree.create(styleConfigFilePath, styleConfigContent);
        }
        return tree;
    };
}
function getMainStyleFilePath(project) {
    var _a, _b, _c, _d;
    var rootStyles = (_d = (_c = (_b = (_a = (0, workspace_utils_1.getProjectTargets)(project)) === null || _a === void 0 ? void 0 : _a.build) === null || _b === void 0 ? void 0 : _b.options) === null || _c === void 0 ? void 0 : _c.styles) === null || _d === void 0 ? void 0 : _d[0];
    var styleFilePath = typeof rootStyles === 'object'
        ? rootStyles === null || rootStyles === void 0 ? void 0 : rootStyles.input
        : rootStyles;
    if (!styleFilePath) {
        throw new Error("Could not find main styling file from the project's angular configuration.");
    }
    return styleFilePath;
}
function installStyles(options) {
    return function (tree, context) {
        if (options.debug) {
            context.logger.info("\u231B\uFE0F Installing styles...");
        }
        var project = (0, workspace_utils_1.getProjectFromWorkspace)(tree, options);
        var styleFilePath = getMainStyleFilePath(project);
        if (!styleFilePath) {
            context.logger.warn("Could not find the default style file for this project.");
            context.logger.warn("Please consider manually setting up spartacus styles");
            return;
        }
        if (styleFilePath.split('.').pop() !== 'scss') {
            context.logger.warn("Could not find the default SCSS style file for this project. ");
            context.logger.warn("Please make sure your project is configured with SCSS and consider manually setting up spartacus styles.");
            return;
        }
        var buffer = tree.read(styleFilePath);
        if (!buffer) {
            context.logger.warn("Could not read the default style file within the project ".concat(styleFilePath));
            context.logger.warn("Please consider manually importing spartacus styles.");
            return;
        }
        var htmlContent = buffer.toString();
        var relativeStyleConfigImportPath = (0, styling_utils_1.getRelativeStyleConfigImportPath)(project, styleFilePath);
        var insertion = "@import '".concat(relativeStyleConfigImportPath, "';\n") +
            "\n// ORDER IMPORTANT: Spartacus core first\n" +
            "@import '@spartacus/styles/scss/core';\n\n" +
            "// ORDER IMPORTANT: Copy of Bootstrap files next\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/reboot';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/type';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/grid';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/utilities';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/transitions';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/dropdown';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/card';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/nav';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/buttons';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/forms';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/custom-forms';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/modal';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/close';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/alert';\n" +
            "@import '@spartacus/styles/vendor/bootstrap/scss/tooltip';\n\n" +
            "// ORDER IMPORTANT: Spartacus styles last\n" +
            "@import '@spartacus/styles/index';\n";
        if (options === null || options === void 0 ? void 0 : options.theme) {
            insertion += "\n@import '@spartacus/styles/scss/theme/".concat(options.theme, "';\n");
        }
        if (htmlContent.includes(insertion)) {
            return;
        }
        var recorder = tree.beginUpdate(styleFilePath);
        recorder.insertLeft(htmlContent.length, insertion);
        tree.commitUpdate(recorder);
        if (options.debug) {
            context.logger.info("\u2705 Style installation complete.");
        }
    };
}
function updateMainComponent(project, options) {
    return function (host, context) {
        if (options.debug) {
            context.logger.info("\u231B\uFE0F Updating main component...");
        }
        var filePath = project.sourceRoot + "/app/".concat(constants_1.APP_COMPONENT_HTML);
        var buffer = host.read(filePath);
        if (!buffer) {
            context.logger.warn("Could not read ".concat(constants_1.APP_COMPONENT_HTML, " file."));
            return;
        }
        var htmlContent = buffer.toString();
        var insertion = "<cx-storefront></cx-storefront>\n";
        if (htmlContent.includes(insertion)) {
            return;
        }
        var recorder = host.beginUpdate(filePath);
        if (options && options.overwriteAppComponent) {
            recorder.remove(0, htmlContent.length);
            recorder.insertLeft(0, insertion);
        }
        else {
            recorder.insertLeft(htmlContent.length, "\n".concat(insertion));
        }
        host.commitUpdate(recorder);
        if (options.debug) {
            context.logger.info("\u2705 Main component update complete.");
        }
        return host;
    };
}
function updateIndexFile(tree, options) {
    return function (host, context) {
        if (options.debug) {
            context.logger.info("\u231B\uFE0F Updating index file...");
        }
        var projectIndexHtmlPath = (0, file_utils_1.getIndexHtmlPath)(tree);
        var baseUrl = options.baseUrl || 'OCC_BACKEND_BASE_URL_VALUE';
        var metaTags = [
            "<meta name=\"occ-backend-base-url\" content=\"".concat(baseUrl, "\" />"),
            "<meta name=\"media-backend-base-url\" content=\"MEDIA_BACKEND_BASE_URL_VALUE\" />",
        ];
        metaTags.forEach(function (metaTag) {
            (0, html_utils_1.appendHtmlElementToHead)(host, projectIndexHtmlPath, metaTag);
        });
        if (options.debug) {
            context.logger.info("\u2705 Index file update complete");
        }
        return host;
    };
}
function increaseBudgets(options) {
    return function (tree, context) {
        var _a;
        var _b;
        if (options.debug) {
            context.logger.info("\u231B\uFE0F Increasing budgets...");
        }
        var _c = (0, workspace_utils_1.getWorkspace)(tree), path = _c.path, angularJson = _c.workspace;
        var projectName = (0, workspace_utils_1.getDefaultProjectNameFromWorkspace)(tree);
        var project = angularJson.projects[projectName];
        var architect = project.architect;
        var build = architect === null || architect === void 0 ? void 0 : architect.build;
        var configurations = build === null || build === void 0 ? void 0 : build.configurations;
        var productionConfiguration = configurations === null || configurations === void 0 ? void 0 : configurations.production;
        var productionBudgets = ((_b = productionConfiguration.budgets) !== null && _b !== void 0 ? _b : []).map(function (budget) {
            if (budget.type === 'initial') {
                return __assign(__assign({}, budget), { maximumError: '3.5mb' });
            }
            return budget;
        });
        var updatedAngularJson = __assign(__assign({}, angularJson), { projects: __assign(__assign({}, angularJson.projects), (_a = {}, _a[projectName] = __assign(__assign({}, project), { architect: __assign(__assign({}, architect), { build: __assign(__assign({}, build), { configurations: __assign(__assign({}, configurations), { production: __assign(__assign({}, productionConfiguration), { budgets: productionBudgets }) }) }) }) }), _a)) });
        tree.overwrite(path, JSON.stringify(updatedAngularJson, null, 2));
        if (options.debug) {
            context.logger.info("\u2705 Budget increase complete.");
        }
        return tree;
    };
}
/**
 * Checks if the app is standalone (by checking existence of app.config.ts).
 * Checks if the app uses Angular 2016 filename convention (by checking `component.ts` suffix in app.component.ts).
 *
 * @param options - The Spartacus options.
 * @returns A Rule function that checks the app structure and sets up accordingly.
 */
function detectAndSetupAppStructure(options) {
    return function (tree, context) {
        if (options.debug) {
            context.logger.info("\u231B\uFE0F Detecting app structure...");
        }
        // get tsconfig file paths
        var buildPaths = (0, project_tsconfig_paths_1.getProjectTsConfigPaths)(tree, options.project).buildPaths;
        var basePath = process.cwd();
        // get project structure based on current path and path of the first found tsconfig file
        var appSourceFiles = (0, program_1.createProgram)(tree, basePath, buildPaths[0]).appSourceFiles;
        // check if app.config.ts exists (standalone indicator)
        var appConfig = appSourceFiles.find(function (sourceFile) {
            return sourceFile.getFilePath().includes(constants_1.APP_CONFIG);
        });
        var advice = "Please re-create your application:\n1. Remove your current application code.\n2. Re-create your app using \"ng new\" with these CLI flags:\n   - Use `--file-name-style-guide=2016`\n   - Avoid using `--standalone=false`\n3. try again installing Spartacus with a command \"ng add @spartacus/schematics\" ...";
        if (!appConfig) {
            throw new schematics_1.SchematicsException("Could not find ".concat(constants_1.APP_CONFIG, " file. ").concat(advice));
        }
        var appComponent = appSourceFiles.find(function (sourceFile) {
            return sourceFile.getFilePath().includes(constants_1.APP_COMPONENT);
        });
        if (!appComponent) {
            throw new schematics_1.SchematicsException("Could not find ".concat(constants_1.APP_COMPONENT, " file. ").concat(advice));
        }
        if (options.debug) {
            context.logger.info("\u2705 App structure detection complete.");
        }
        return tree;
    };
}
function createStylePreprocessorOptions(options) {
    return function (tree, context) {
        var _a;
        var _b, _c;
        if (options === null || options === void 0 ? void 0 : options.debug) {
            context.logger.info("\u231B\uFE0F Updating style preprocessor...");
        }
        var _d = (0, workspace_utils_1.getWorkspace)(tree), path = _d.path, angularJson = _d.workspace;
        var projectName = (0, workspace_utils_1.getDefaultProjectNameFromWorkspace)(tree);
        var project = angularJson.projects[projectName];
        var architect = project.architect;
        // `build` architect section
        var architectBuild = architect === null || architect === void 0 ? void 0 : architect.build;
        var buildStylePreprocessorOptions = createStylePreprocessorOptionsArray((_b = architectBuild === null || architectBuild === void 0 ? void 0 : architectBuild.options) === null || _b === void 0 ? void 0 : _b.stylePreprocessorOptions);
        // Apply silenceDeprecations only for `build` configuration (but not `test` - it's not supported there)
        var buildSassOptions = (0, workspace_utils_1.createSassSilenceDeprecations)(context, buildStylePreprocessorOptions);
        var buildOptions = __assign(__assign({}, architectBuild === null || architectBuild === void 0 ? void 0 : architectBuild.options), { stylePreprocessorOptions: __assign(__assign({}, buildStylePreprocessorOptions), buildSassOptions) });
        // `test` architect section
        var architectTest = architect === null || architect === void 0 ? void 0 : architect.test;
        var testStylePreprocessorOptions = createStylePreprocessorOptionsArray((_c = architectBuild === null || architectBuild === void 0 ? void 0 : architectBuild.options) === null || _c === void 0 ? void 0 : _c.stylePreprocessorOptions);
        var testOptions = __assign(__assign({}, architectTest === null || architectTest === void 0 ? void 0 : architectTest.options), { stylePreprocessorOptions: testStylePreprocessorOptions });
        var updatedAngularJson = __assign(__assign({}, angularJson), { projects: __assign(__assign({}, angularJson.projects), (_a = {}, _a[projectName] = __assign(__assign({}, project), { architect: __assign(__assign({}, architect), { build: __assign(__assign({}, architectBuild), { options: buildOptions }), test: __assign(__assign({}, architectTest), { options: testOptions }) }) }), _a)) });
        tree.overwrite(path, JSON.stringify(updatedAngularJson, null, 2));
        if (options === null || options === void 0 ? void 0 : options.debug) {
            context.logger.info("\u2705 Style preprocessor update complete.");
        }
        return tree;
    };
}
function createStylePreprocessorOptionsArray(angularJsonStylePreprocessorOptions) {
    if (!angularJsonStylePreprocessorOptions) {
        angularJsonStylePreprocessorOptions = {};
    }
    var NODE_MODULES_PATH = 'node_modules/';
    var includePaths = Array.from(new Set(__spreadArray(__spreadArray([], (angularJsonStylePreprocessorOptions.includePaths || []), true), [
        NODE_MODULES_PATH,
    ], false)));
    return __assign(__assign({}, angularJsonStylePreprocessorOptions), { includePaths: includePaths });
}
function prepareDependencies(features) {
    var spartacusDependencies = (0, package_utils_1.prepareSpartacusDependencies)();
    var libraries = (0, dependency_utils_1.analyzeCrossLibraryDependenciesByFeatures)(features);
    var spartacusVersion = (0, package_utils_1.getPrefixedSpartacusSchematicsVersion)();
    var spartacusLibraryDependencies = libraries.map(function (library) {
        return (0, package_utils_1.mapPackageToNodeDependencies)(library, spartacusVersion);
    });
    var dependencies = spartacusDependencies
        .concat(spartacusLibraryDependencies)
        .concat((0, package_utils_1.prepare3rdPartyDependencies)());
    return dependencies;
}
/**
 * Replaces caret (^) with tilde (~) for Spartacus dependencies in package.json.
 *
 * Note: Angular CLI by default puts `^` in customer's `package.json` during `ng add @spartacus/schematics@latest`.
 *       But since 2211.19 we agreed to break SemVer and release breaking changes in "minor" (x.Y.z) versions,
 *       so we need to replace `^` with `~` to prevent breaking changes from being installed automatically
 *       in the future and causing peer dependency conflicts when Spartacus updates e.g. Angular versions.
 */
function replaceCaretWithTildeForSpartacusDependencies(options) {
    return function (tree, context) {
        if (options.debug) {
            context.logger.info("\u231B\uFE0F Replacing ^ with ~ for @spartacus dependencies in package.json");
        }
        var packageJsonFile = (0, package_utils_1.readPackageJson)(tree);
        var DEPENDENCY_TYPES = ['dependencies', 'devDependencies'];
        var TILDE = '~';
        var CARET = '^';
        DEPENDENCY_TYPES.forEach(function (dependencyType) {
            var deps = packageJsonFile[dependencyType] || {};
            var spartacusPackages = Object.keys(deps).filter(function (packageName) {
                return packageName.startsWith('@spartacus');
            });
            spartacusPackages.forEach(function (packageName) {
                var currentVersion = deps[packageName];
                deps[packageName] = currentVersion.replace(CARET, TILDE);
            });
        });
        tree.overwrite('package.json', JSON.stringify(packageJsonFile, null, 2));
        if (options.debug) {
            context.logger.info('✅ Replaced ^ with ~ for all @spartacus dependencies');
        }
        return tree;
    };
}
function addSpartacus(options) {
    return function (tree, context) {
        var _a;
        var features = (0, dependency_utils_1.analyzeCrossFeatureDependencies)((_a = options.features) !== null && _a !== void 0 ? _a : []);
        var dependencies = prepareDependencies(features);
        var spartacusRxjsDependency = [
            dependencies.find(function (dep) { return dep.name === constants_1.RXJS; }),
        ];
        var packageJsonFile = (0, package_utils_1.readPackageJson)(tree);
        return (0, schematics_1.chain)([
            detectAndSetupAppStructure(options),
            (0, create_app_module_1.createAppModule)(options),
            (0, update_app_config_1.updateAppConfig)(options),
            (0, add_storefront_component_to_app_component_1.addStorefrontComponentToAppComponent)(options),
            (0, feature_utils_1.analyzeApplication)(options, features),
            (0, store_1.setupStoreModules)(options),
            (0, workspace_utils_1.scaffoldStructure)(options),
            (0, spartacus_1.setupSpartacusModule)(options),
            (0, spartacus_features_1.setupSpartacusFeaturesModule)(options),
            (0, configuration_1.addSpartacusConfiguration)(options),
            (0, spartacus_feature_toggles_1.addFeatureToggles)(options),
            (0, update_app_module_1.updateAppModule)(options),
            createStylesConfig(options),
            installStyles(options),
            updateMainComponent((0, workspace_utils_1.getProjectFromWorkspace)(tree, options), options),
            options.useMetaTags ? updateIndexFile(tree, options) : (0, schematics_1.noop)(),
            increaseBudgets(options),
            createStylePreprocessorOptions(options),
            (0, feature_utils_1.addFeatures)(options, features),
            // TODO CXSPA-13991: Re-enable once @spartacus/skills passes audit and ships in the release bundle.
            // addAiContext(options),
            (0, schematics_1.chain)([
                (0, lib_utils_1.addPackageJsonDependencies)(prepareDependencies(features), packageJsonFile),
                /**
                 * Force installing versions of dependencies used by Spartacus.
                 * E.g. ng13 uses rxjs 7, but Spartacus uses rxjs 6.
                 */
                (0, package_utils_1.updatePackageJsonDependencies)(spartacusRxjsDependency, packageJsonFile),
                (0, lib_utils_1.installPackageJsonDependencies)(),
                replaceCaretWithTildeForSpartacusDependencies(options),
            ]),
            // TODO CXSPA-13991: Re-enable once @spartacus/skills passes audit and ships in the release bundle.
            // scheduleAiContext(options),
            (0, lib_utils_1.finalizeInstallation)(options, features),
        ])(tree, context);
    };
}
//# sourceMappingURL=index.js.map