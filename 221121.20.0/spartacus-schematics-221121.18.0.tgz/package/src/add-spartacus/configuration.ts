/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Rule,
  SchematicContext,
  SchematicsException,
  Tree,
} from '@angular-devkit/schematics';
import { SourceFile } from 'ts-morph';
import {
  FEATURES_CONFIG,
  I18N_CONFIG,
  OCC_CONFIG,
  PROVIDE_CONFIG_FACTORY_FUNCTION,
  PROVIDE_CONFIG_FUNCTION,
  SITE_CONTEXT_CONFIG,
} from '../shared/constants';
import {
  SPARTACUS_ASSETS,
  SPARTACUS_CONFIGURATION_MODULE,
  SPARTACUS_CORE,
  SPARTACUS_STOREFRONTLIB,
} from '../shared/libs-constants';
import { addModuleProvider } from '../shared/utils/new-module-utils';
import { getSpartacusCurrentFeatureLevel } from '../shared/utils/package-utils';
import { createProgram, saveAndFormat } from '../shared/utils/program';
import { getProjectTsConfigPaths } from '../shared/utils/project-tsconfig-paths';
import { parseCSV } from '../shared/utils/transform-utils';
import { Schema as SpartacusOptions } from './schema';

export function addSpartacusConfiguration(options: SpartacusOptions): Rule {
  return (tree: Tree, context: SchematicContext): Tree => {
    if (options.debug) {
      context.logger.info(`⌛️ Setting up Spartacus configuration module...`);
    }

    const { buildPaths } = getProjectTsConfigPaths(tree, options.project);

    if (!buildPaths.length) {
      throw new SchematicsException(
        'Could not find any tsconfig file. Cannot configure SpartacusConfigurationModule.'
      );
    }

    const basePath = process.cwd();
    for (const tsconfigPath of buildPaths) {
      addConfiguration(tree, tsconfigPath, basePath, options);
    }

    if (options.debug) {
      context.logger.info(`✅ Spartacus configuration module setup complete.`);
    }
    return tree;
  };
}

function addConfiguration(
  tree: Tree,
  tsconfigPath: string,
  basePath: string,
  options: SpartacusOptions
): void {
  const { appSourceFiles } = createProgram(tree, basePath, tsconfigPath);

  for (const sourceFile of appSourceFiles) {
    if (
      sourceFile
        .getFilePath()
        .includes(`${SPARTACUS_CONFIGURATION_MODULE}.module.ts`)
    ) {
      addCommonConfiguration(sourceFile, options);

      saveAndFormat(sourceFile);
      break;
    }
  }
}

function addCommonConfiguration(
  sourceFile: SourceFile,
  options: SpartacusOptions
): void {
  addModuleProvider(sourceFile, {
    import: [
      {
        moduleSpecifier: SPARTACUS_CORE,
        namedImports: [PROVIDE_CONFIG_FACTORY_FUNCTION],
      },
      {
        moduleSpecifier: SPARTACUS_STOREFRONTLIB,
        namedImports: ['layoutConfigFactory'],
      },
    ],
    content: `provideConfigFactory(layoutConfigFactory)`,
  });
  addModuleProvider(sourceFile, {
    import: [
      {
        moduleSpecifier: SPARTACUS_CORE,
        namedImports: [PROVIDE_CONFIG_FUNCTION],
      },
      {
        moduleSpecifier: SPARTACUS_STOREFRONTLIB,
        namedImports: ['mediaConfig'],
      },
    ],
    content: `provideConfig(mediaConfig)`,
  });
  addModuleProvider(sourceFile, {
    import: {
      moduleSpecifier: SPARTACUS_STOREFRONTLIB,
      namedImports: ['defaultCmsContentProviders'],
    },
    content: `...defaultCmsContentProviders`,
  });

  addStorefrontConfig(sourceFile, options);
}

function createSiteContextConfig(options: SpartacusOptions): string {
  let contextConfig = `
      context: {`;

  if (options.currency) {
    const currency = parseCSV(options.currency).toUpperCase();
    contextConfig += `\ncurrency: [${currency}],`;
  }

  if (options.language) {
    const language = parseCSV(options.language).toLowerCase();
    contextConfig += `\nlanguage: [${language}],`;
  }

  if (options.baseSite) {
    const baseSites = parseCSV(options.baseSite);
    contextConfig += `\nbaseSite: [${baseSites}],`;
  }

  if (options.urlParameters) {
    const urlParameters = parseCSV(options.urlParameters);
    contextConfig += `\nurlParameters: [${urlParameters}]`;
  }

  contextConfig += `},`;

  return `provideConfig(<${SITE_CONTEXT_CONFIG}>{${contextConfig}})`;
}

/**
 * Creates and adds a spartacus config based on the provided `options`.
 * @param options
 */
function addStorefrontConfig(
  sourceFile: SourceFile,
  options: SpartacusOptions
): void {
  const backendConfig = createBackendConfiguration(options);
  addModuleProvider(sourceFile, {
    import: [
      {
        moduleSpecifier: SPARTACUS_CORE,
        namedImports: [PROVIDE_CONFIG_FUNCTION, OCC_CONFIG],
      },
    ],
    content: backendConfig,
  });

  const siteContextConfig = createSiteContextConfig(options);
  addModuleProvider(sourceFile, {
    import: [
      {
        moduleSpecifier: SPARTACUS_CORE,
        namedImports: [PROVIDE_CONFIG_FUNCTION, SITE_CONTEXT_CONFIG],
      },
    ],
    content: siteContextConfig,
  });

  const i18nConfig = createI18NConfiguration();
  addModuleProvider(sourceFile, {
    import: [
      {
        moduleSpecifier: SPARTACUS_CORE,
        namedImports: [PROVIDE_CONFIG_FUNCTION, I18N_CONFIG],
      },
      {
        moduleSpecifier: SPARTACUS_ASSETS,
        namedImports: ['translationsEn', 'translationChunksConfig'],
      },
    ],
    content: i18nConfig,
  });

  const featureLevelConfig = createFeatureLevelConfiguration(options);
  addModuleProvider(sourceFile, {
    import: [
      {
        moduleSpecifier: SPARTACUS_CORE,
        namedImports: [PROVIDE_CONFIG_FUNCTION, FEATURES_CONFIG],
      },
    ],
    content: featureLevelConfig,
  });
}

function createBackendConfiguration(options: SpartacusOptions): string {
  const baseUrlPart = `\n          baseUrl: '${options.baseUrl}',`;
  const occPrefixPart = options.occPrefix
    ? `prefix: '${options.occPrefix}'`
    : '';
  return `provideConfig(<${OCC_CONFIG}>{
    backend: {
      occ: {${options.useMetaTags ? '' : baseUrlPart}${occPrefixPart}
      }
    },
  })`;
}

function createI18NConfiguration(): string {
  return `provideConfig(<${I18N_CONFIG}>{
  i18n: {
    resources: { en: translationsEn },
    chunks: translationChunksConfig,
    fallbackLang: 'en'
  },
})`;
}

/**
 * @deprecated - features level is no longer used
 */
function createFeatureLevelConfiguration(options: SpartacusOptions): string {
  const featureLevelConfig = `
  features: {
    level: '${options.featureLevel || getSpartacusCurrentFeatureLevel()}'
  }`;
  return `provideConfig(<${FEATURES_CONFIG}>{${featureLevelConfig}})`;
}
