"use strict";
/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ensureModuleExists = ensureModuleExists;
exports.addModuleImport = addModuleImport;
exports.addModuleExport = addModuleExport;
exports.addModuleProvider = addModuleProvider;
exports.removeModuleImport = removeModuleImport;
exports.getModule = getModule;
exports.getModulePropertyInitializer = getModulePropertyInitializer;
var strings_1 = require("@angular-devkit/core/src/utils/strings");
var schematics_1 = require("@angular-devkit/schematics");
var ast_utils_1 = require("@schematics/angular/utility/ast-utils");
var ts_morph_1 = require("ts-morph");
var constants_1 = require("../constants");
var config_utils_1 = require("./config-utils");
var file_utils_1 = require("./file-utils");
var import_utils_1 = require("./import-utils");
var workspace_utils_1 = require("./workspace-utils");
function ensureModuleExists(options) {
    return function (host) {
        var modulePath = "".concat((0, workspace_utils_1.getSourceRoot)(host, { project: options.project }), "/").concat(options.path);
        var filePath = "".concat(modulePath, "/").concat((0, strings_1.dasherize)(options.name), ".module.ts");
        if (host.exists(filePath)) {
            var moduleFile = (0, file_utils_1.getTsSourceFile)(host, filePath);
            var metadata = (0, ast_utils_1.getDecoratorMetadata)(moduleFile, 'NgModule', constants_1.ANGULAR_CORE)[0];
            if (metadata) {
                return (0, schematics_1.noop)();
            }
        }
        return (0, schematics_1.externalSchematic)(constants_1.ANGULAR_SCHEMATICS, 'module', {
            project: options.project,
            name: (0, strings_1.dasherize)(options.name),
            flat: true,
            commonModule: false,
            path: modulePath,
            module: options.module,
            typeSeparator: '.',
        });
    };
}
/**
 * Adds the given Module (import, content) to the `imports` array
 * of the NgModule in the given source file.
 *
 * If `order` param is provided, the Module will be added at the specified array's index.
 *
 * Moreover, it adds the JS import of this Module in the source file.
 */
function addModuleImport(sourceFile, insertOptions, createIfMissing) {
    if (createIfMissing === void 0) { createIfMissing = true; }
    return addToModuleInternal(sourceFile, 'imports', insertOptions, createIfMissing);
}
function addModuleExport(sourceFile, insertOptions, createIfMissing) {
    if (createIfMissing === void 0) { createIfMissing = true; }
    return addToModuleInternal(sourceFile, 'exports', insertOptions, createIfMissing);
}
function addModuleProvider(sourceFile, insertOptions, createIfMissing) {
    if (createIfMissing === void 0) { createIfMissing = true; }
    return addToModuleInternal(sourceFile, 'providers', insertOptions, createIfMissing);
}
function addToModuleInternal(sourceFile, propertyName, insertOptions, createIfMissing) {
    if (createIfMissing === void 0) { createIfMissing = true; }
    var initializer = getModulePropertyInitializer(sourceFile, propertyName, createIfMissing);
    if (!initializer) {
        return undefined;
    }
    if (isDuplication(initializer, propertyName, insertOptions.content)) {
        return undefined;
    }
    var imports = [].concat(insertOptions.import);
    (0, import_utils_1.createImports)(sourceFile, imports);
    var createdNode;
    if (insertOptions.order || insertOptions.order === 0) {
        var elements = initializer.getElements();
        var maxIndex = elements.length;
        // If the requested order exceeds the current array length, append at the end
        var insertIndex = Math.min(insertOptions.order, maxIndex);
        initializer.insertElement(insertIndex, insertOptions.content);
    }
    else {
        createdNode = initializer.addElement(insertOptions.content);
    }
    return createdNode;
}
/**
 * Removes the given Module (importPath, content) from the `imports` array
 * of the NgModule in the given source file.
 *
 * Moreover, it removes the JS import of this Module from the source file.
 */
function removeModuleImport(sourceFile, removeOptions) {
    return removeFromModuleInternal(sourceFile, 'imports', removeOptions);
}
function removeFromModuleInternal(sourceFile, propertyName, removeOptions) {
    var initializer = getModulePropertyInitializer(sourceFile, propertyName);
    if (!initializer) {
        return undefined;
    }
    (0, import_utils_1.removeImports)(sourceFile, [
        { node: removeOptions.content, importPath: removeOptions.importPath },
    ]);
    var nodeToRemove = initializer
        .getElements()
        .find(function (element) { return element.getText() === removeOptions.content; });
    if (nodeToRemove) {
        initializer.removeElement(nodeToRemove);
    }
    return nodeToRemove;
}
function isDuplication(initializer, propertyName, content) {
    if (propertyName !== 'providers') {
        return isTypeTokenDuplicate(initializer, content);
    }
    return (0, config_utils_1.isSpartacusConfigDuplicate)(content, initializer);
}
function isTypeTokenDuplicate(initializer, typeToken) {
    typeToken = normalizeTypeToken(typeToken);
    for (var _i = 0, _a = initializer.getElements(); _i < _a.length; _i++) {
        var element = _a[_i];
        var elementText = normalizeTypeToken(element.getText());
        if (elementText === typeToken) {
            return true;
        }
    }
    return false;
}
function getModule(sourceFile) {
    var moduleNode;
    function visitor(node) {
        if (ts_morph_1.Node.isCallExpression(node)) {
            var expression = node.getExpression();
            if (ts_morph_1.Node.isIdentifier(expression) &&
                expression.getText() === 'NgModule' &&
                (0, import_utils_1.isImportedFrom)(expression, constants_1.ANGULAR_CORE)) {
                moduleNode = node;
            }
        }
        node.forEachChild(visitor);
    }
    sourceFile.forEachChild(visitor);
    return moduleNode;
}
var COMMENT_REG_EXP = /\/\/.+/gm;
function normalizeTypeToken(token) {
    var newToken = token;
    newToken = newToken.replace(COMMENT_REG_EXP, '');
    newToken = newToken.trim();
    // strip down the trailing comma
    if (newToken.endsWith(',')) {
        newToken = newToken.substring(0, newToken.length - 1);
    }
    return newToken;
}
function getModulePropertyInitializer(source, propertyName, createIfMissing) {
    if (createIfMissing === void 0) { createIfMissing = true; }
    var property = getModuleProperty(source, propertyName, createIfMissing);
    if (!property || !ts_morph_1.Node.isPropertyAssignment(property)) {
        return undefined;
    }
    return property.getInitializerIfKind(ts_morph_1.ts.SyntaxKind.ArrayLiteralExpression);
}
function getModuleProperty(source, propertyName, createIfMissing) {
    if (createIfMissing === void 0) { createIfMissing = true; }
    var moduleNode = getModule(source);
    if (!moduleNode) {
        return undefined;
    }
    var arg = moduleNode.getArguments()[0];
    if (!arg || !ts_morph_1.Node.isObjectLiteralExpression(arg)) {
        return undefined;
    }
    var property = arg.getProperty(propertyName);
    if (!property && createIfMissing) {
        arg.addPropertyAssignment({
            name: propertyName,
            initializer: '[]',
        });
    }
    return arg.getProperty(propertyName);
}
//# sourceMappingURL=new-module-utils.js.map