import * as i0 from '@angular/core';
import { Type, OnInit, ComponentFactoryResolver, ComponentFactory, Injector, AfterViewInit, OnDestroy, ViewContainerRef, ComponentRef, ChangeDetectorRef, ElementRef } from '@angular/core';
import * as i1 from '@angular/common';
import * as i3 from '@angular/router';
import * as i7 from '@spartacus/storefront';
import { ICON_TYPE, TableService, ResponsiveTableConfiguration, TableStructure, TrapFocus, Table, ViewComponent, OutletContextData, TableDataOutletContext, TableFieldOptions, TableConfig, DatePickerService } from '@spartacus/storefront';
import * as i4 from '@spartacus/core';
import { Translatable, GlobalMessageType, RoutingService, B2BUnit, PaginationModel, EntitiesModel, CurrencyService, Currency, CostCenter, B2BApprovalProcess, B2BUser, B2BUserRole, B2BUserRight, Address, UserAddressService, Country, Title, Region, User, OrderApprovalPermissionType, CmsConfig } from '@spartacus/core';
import * as i4$1 from '@ng-select/ng-select';
import * as i6 from '@angular/forms';
import { UntypedFormGroup, AbstractControl, UntypedFormArray, UntypedFormControl } from '@angular/forms';
import * as rxjs from 'rxjs';
import { Subject, ReplaySubject, Observable, Subscription, BehaviorSubject } from 'rxjs';
import { OrganizationItemStatus, Budget, OrgUnitService, B2BUnitNode, B2BUnitTreeNode, B2BUserService, UserGroup, UserGroupService, Permission, PermissionService, BudgetService, CostCenterService } from '@spartacus/organization/administration/core';
import { OrganizationUIConfig } from '@spartacus/organization/administration/root';
import { UserProfileFacade } from '@spartacus/user/profile/root';

declare class MessageData<O extends MessageEventData = MessageEventData, T extends BaseMessageComponent = BaseMessageComponent> {
    /**
     * The message contains the `translatable` message that is rendered
     * inside the message component.
     */
    message?: Translatable;
    messageTitle?: Translatable;
    cancel?: Translatable;
    confirm?: Translatable;
    /**
     * Icon used to display next to the message.
     */
    messageIcon?: ICON_TYPE;
    /**
     * The type of message is used to render the style of the message.
     */
    type?: GlobalMessageType;
    /**
     * The timeout is used to remove the message component automatically
     * without any user interaction.
     */
    timeout?: number;
    /**
     * The (optional) component is rendered inside message component.
     *
     * If no specific component is given, the `NotificationMessageComponent` is used.
     */
    component?: Type<T>;
    /**
     * The event data subject can be used to publish and observe custom events.
     */
    events?: Subject<O>;
}
interface MessageEventData {
    close?: boolean;
}

declare abstract class BaseMessageComponent implements OnInit {
    protected messageData: MessageData;
    protected platformId: any;
    type: string | undefined;
    terminated: boolean;
    message: Translatable;
    messageTitle?: Translatable;
    /**
     * Icon used to display next to the message.
     */
    messageIcon: ICON_TYPE | undefined;
    constructor(messageData: MessageData, platformId: any);
    ngOnInit(): void;
    close(): void;
    protected resolveType(): string | undefined;
    protected handleAutoHide(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseMessageComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseMessageComponent, never, never, {}, {}, never, never, true, never>;
}

declare class NotificationMessageComponent extends BaseMessageComponent {
    closeIcon: ICON_TYPE;
    private featureToggles;
    get isA11yCardNotificationMessageFeatureEnabled(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationMessageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NotificationMessageComponent, "cx-org-notification", never, {}, {}, never, never, true, never>;
}

declare class NotificationMessageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationMessageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NotificationMessageModule, never, [typeof i1.CommonModule, typeof i4.I18nModule, typeof i7.IconModule, typeof i7.KeyboardFocusModule, typeof NotificationMessageComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NotificationMessageModule>;
}

declare class MessageRenderService {
    protected componentFactoryResolver: ComponentFactoryResolver;
    constructor(componentFactoryResolver: ComponentFactoryResolver);
    getComponent(msg: MessageData): ComponentFactory<any>;
    getInjector(componentData: MessageData, parent?: Injector): Injector;
    static ɵfac: i0.ɵɵFactoryDeclaration<MessageRenderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MessageRenderService>;
}

declare class MessageService<O extends MessageEventData = MessageEventData, T extends MessageData<O> = MessageData<O>> {
    protected data$: ReplaySubject<T | undefined>;
    get(): Observable<T | undefined>;
    add(message: T): Subject<O>;
    close(message: Subject<MessageEventData> | null): void;
    /**
     * Sets the message type to INFO, and adds a default timeout
     * for info messages.
     */
    protected getDefaultMessage(message: T): MessageData;
    clear(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MessageService<any, any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MessageService<any, any>>;
}

declare class MessageComponent implements AfterViewInit, OnDestroy {
    protected messageService: MessageService;
    protected renderService: MessageRenderService;
    vcr: ViewContainerRef;
    protected subscription: Subscription;
    constructor(messageService: MessageService, renderService: MessageRenderService);
    ngAfterViewInit(): void;
    protected render(msg: MessageData): void;
    /**
     * Terminates the message component in 2 steps. It starts to toggle the terminate
     * state of the component and shortly after destroys the component completely. The
     * termination state allows the CSS layer to play an animation before destroying.
     */
    protected terminate(ref: ComponentRef<BaseMessageComponent>): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MessageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MessageComponent, "cx-org-message", never, {}, {}, never, never, true, never>;
}

declare class MessageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MessageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MessageModule, never, [typeof i1.CommonModule, typeof NotificationMessageModule, typeof MessageComponent], [typeof MessageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MessageModule>;
}

/**
 * Abstract Base class for all organization entities. This class simplifies
 * the various entity implementation, that only differ by dependencies and
 * data model.
 */
declare abstract class CurrentItemService<T> {
    protected routingService: RoutingService;
    constructor(routingService: RoutingService);
    /**
     * Observes the key for the active organization item. The active key is observed
     * from the list of route parameters. The full route parameter list is evaluated,
     * including child routes.
     *
     * To allow for specific ("semantic") route parameters, the route parameter _key_ is
     * retrieved from the `getParamKey`.
     */
    readonly key$: Observable<string>;
    /**
     * Observes the active item.
     *
     * The active item is loaded by the active `key$`.
     */
    readonly item$: Observable<T | undefined>;
    /**
     * Observes the b2bUnit based on the unitCode route parameter.
     */
    readonly b2bUnit$: Observable<string>;
    /**
     * Returns the route parameter key for the item. The route parameter key differs
     * per item, so that route parameters are distinguished in the route configuration.
     */
    protected abstract getParamKey(): string;
    /**
     * Emits the current model or undefined, if there is no model available
     */
    protected abstract getItem(...params: any[]): Observable<T | undefined>;
    getRouterParam(paramKey: string): Observable<string>;
    abstract getError(_key: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrentItemService<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrentItemService<any>>;
}

declare abstract class FormService<T> {
    protected form: UntypedFormGroup | null;
    /**
     * Builds the form structure.
     */
    protected abstract build(item?: T): void;
    getForm(item?: T): UntypedFormGroup | null;
    protected patchData(item?: T): void;
    private toggleFreeze;
    /**
     * returns the default form value.
     */
    protected get defaultValue(): T;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormService<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormService<any>>;
}

/**
 * Provides CRUD operations for all organization entities.
 *
 * This base class simplifies the various entity implementation, and ensures a consistent
 * component implementation.
 */
declare abstract class ItemService<T> {
    protected currentItemService: CurrentItemService<T>;
    protected routingService: RoutingService;
    protected formService: FormService<T>;
    constructor(currentItemService: CurrentItemService<T>, routingService: RoutingService, formService: FormService<T>);
    key$: Observable<string>;
    current$: Observable<T | undefined>;
    isInEditMode$: Observable<boolean>;
    /**
     * Returns the current business unit code.
     *
     * The current unit is driven by the route parameter.
     */
    unit$: Observable<string>;
    error$: Observable<boolean>;
    save(form: UntypedFormGroup, key?: string): Observable<OrganizationItemStatus<T>>;
    /**
     * Deletes an item.
     */
    delete?(key: string, additionalParam?: string): Observable<OrganizationItemStatus<T>>;
    /**
     * Loads an item.
     */
    abstract load(...params: any[]): Observable<T>;
    /**
     * Creates a new item.
     */
    protected abstract create(value: T): Observable<OrganizationItemStatus<T>>;
    /**
     * Updates an existing item.
     */
    abstract update(key: string, value: T): Observable<OrganizationItemStatus<T>>;
    /**
     * Returns the detailed cxRoute for the organization item.
     */
    protected abstract getDetailsRoute(): string;
    getForm(item?: T): UntypedFormGroup | null;
    /**
     * Launches the detailed route for the given item item.
     */
    launchDetails(item?: T): void;
    /**
     * Returns the route parameters that are used when launching the
     * details page. The route parameters default to the actual item,
     * but can be further populated in implementations.
     *
     * Customized route parameters are useful in case the actual item
     * doesn't match the expected route parameters. You can manipulate
     * the parameter data.
     */
    protected buildRouteParams(item?: T): any;
    getRouterParam(key: string): Observable<string>;
    /**
     * Sets to true when the user is on the entity item form page
     */
    setEditMode(isInEdit: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ItemService<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ItemService<any>>;
}

declare enum OrganizationTableType {
    BUDGET = "orgBudget",
    BUDGET_ASSIGNED_COST_CENTERS = "orgBudgetAssignedCostCenters",
    COST_CENTER = "orgCostCenter",
    COST_CENTER_BUDGETS = "orgCostCenterBudgets",
    COST_CENTER_ASSIGNED_BUDGETS = "orgCostCenterAssignedBudgets",
    UNIT = "orgUnit",
    UNIT_USERS = "orgUnitUsers",
    UNIT_CHILDREN = "orgUnitChildren",
    UNIT_APPROVERS = "orgUnitApprovers",
    UNIT_ASSIGNED_APPROVERS = "orgUnitAssignedApprovers",
    UNIT_ADDRESS = "orgUnitAddress",
    UNIT_COST_CENTERS = "orgUnitCostCenters",
    USER_GROUP = "orgUserGroup",
    USER_GROUP_USERS = "orgUserGroupUsers",
    USER_GROUP_ASSIGNED_USERS = "orgUserGroupAssignedUsers",
    USER_GROUP_PERMISSIONS = "orgUserGroupPermissions",
    USER_GROUP_ASSIGNED_PERMISSIONS = "orgUserGroupAssignedPermissions",
    USER = "orgUser",
    USER_APPROVERS = "orgUserApprovers",
    USER_ASSIGNED_APPROVERS = "orgUserAssignedApprovers",
    USER_PERMISSIONS = "orgUserPermissions",
    USER_ASSIGNED_PERMISSIONS = "orgUserAssignedPermissions",
    USER_USER_GROUPS = "orgUserUserGroups",
    USER_ASSIGNED_USER_GROUPS = "orgUserAssignedUserGroups",
    PERMISSION = "orgPurchaseLimit"
}
type BaseItem = {
    code?: string;
    selected?: boolean;
    customerId?: string;
    uid?: string;
    id?: string;
    active?: boolean;
    orgUnit?: B2BUnit;
    parentOrgUnit?: B2BUnit;
    unit?: B2BUnit;
};

declare enum CreateButtonType {
    LINK = "LINK",
    BUTTON = "BUTTON"
}
/**
 * Extended pagination model that includes search query support.
 */
interface SearchablePaginationModel extends PaginationModel {
    query?: string;
}
/**
 * The `ListService` deals with the table structure, list data and
 * pagination of tables inside the b2b organization.
 *
 * @property {OrganizationTableType} tableType
 *   Used to load the table structure configuration and generate table outlets.
 * @property {PaginationModel} pagination$
 *   The pagination state of the listing.
 */
declare abstract class ListService<T, P = PaginationModel> {
    protected tableService: TableService;
    /**
     * The default table structure is used to add the default configuration for all
     * organization list related tables. This avoids a lot of boilerplate configuration.
     */
    protected defaultTableStructure: ResponsiveTableConfiguration;
    /**
     * The ghost data contains an empty list of objects that is used in the UI
     * to render the HTML elements.
     *
     * This list contains 10 items, so that the ghost will show 10 rows by default.
     */
    protected ghostData: EntitiesModel<T>;
    notification$: Subject<any>;
    /**
     * The `viewType` is used to load the proper table configuration and localizations for the view.
     *
     * TODO: rename to `viewType`
     */
    protected abstract tableType: OrganizationTableType;
    /**
     * The domain type is used to bind fields to localized fields based on the domain.
     * This type differs from the `viewType`, which is related to a specific view
     * configuration.
     */
    protected _domainType: string;
    get viewType(): OrganizationTableType;
    get domainType(): string;
    /**
     * The pagination state of the listing.
     *
     * The pagination size defaults to 10, but can be overridden by the
     * table configuration for each entity type.
     */
    protected pagination$: BehaviorSubject<P>;
    protected config: OrganizationUIConfig;
    constructor(tableService: TableService);
    /**
     * Indicates the unique key for the item model. The key is different for various
     * organizations, i.e. `budget.code`, `user.uid`.
     */
    key(): string;
    /**
     * Loads the data by delegating to the `load` method, which must be implemented
     * in specific implementations of this abstract class.
     *
     * The load method is streamed from the `pagination$` stream, which is initialized
     * with default pagination and structure drive properties.
     *
     * The ghostData is emitted before each load operation (initial load, search,
     * pagination, sort) to show a loading skeleton while waiting for the API response.
     */
    getData(...args: any): Observable<EntitiesModel<T> | undefined>;
    /**
     * Returns the `TableStructure` for the `OrganizationTableType`.
     *
     * The table structure is build by the `TableService` based on configuration.
     * The `defaultTableStructure` is deep merged as a fallback configuration.
     */
    getStructure(): Observable<TableStructure>;
    /**
     * Views the page.
     */
    view(pagination: P, nextPage?: number): void;
    /**
     * Updates the sort code for the PaginationModel.
     *
     * The `currentPage` is reset to 0.
     */
    sort(pagination: P, _obsoleteSort?: string): void;
    /**
     * Indicates whether the given data equals to the ghost data.
     *
     * This is used to validate the initial loading state, which is
     * different from the loading state; the loading state occurs
     * while sorting and paginating, where as the initial loading state
     * only happens at the very first load.
     */
    hasGhostData(data: EntitiesModel<T> | undefined): boolean;
    /**
     * Must be implemented to load the actual listing data. An unknown number of arguments
     * is supported for loading the data. These arguments are passed from the `getData` method.
     */
    protected abstract load(pagination: PaginationModel, ...args: any): Observable<EntitiesModel<T> | undefined>;
    /**
     * This method will return what kind of UI element to be used for create option in UI
     */
    getCreateButtonType(): CreateButtonType;
    /**
     * This method will be called when the button to create new item is clicked.
     */
    onCreateButtonClick(): void;
    /**
     * This method will return the label for create button
     */
    getCreateButtonLabel(): Translatable;
    /**
     * Returns whether search functionality is enabled for this list.
     * Override in subclass to enable search.
     */
    isSearchEnabled(): boolean;
    /**
     * Returns the i18n key for the search input placeholder.
     * Override in subclass to provide a custom placeholder.
     */
    getSearchPlaceholderKey(): string;
    /**
     * Returns the minimum number of characters required to trigger a search.
     * This value can be configured via `organizationUI.listSearch.minCharacters`.
     * Override in subclass to customize.
     */
    getMinSearchCharacters(): number;
    /**
     * Search method to filter the list by query string.
     * Resets to first page when search query changes.
     */
    search(pagination: P, query: string): void;
    /**
     * Clears the search query and resets to first page.
     */
    clearSearch(pagination: P): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListService<any, any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ListService<any, any>>;
}

declare class ListComponent<T = any, P = PaginationModel> implements OnInit, OnDestroy {
    protected service: ListService<T, P>;
    protected organizationItemService: ItemService<T>;
    private searchSubject$;
    private destroy$;
    minSearchCharacters: number;
    ngOnInit(): void;
    ngOnDestroy(): void;
    readonly trapFocus: typeof TrapFocus;
    hasGhostData: boolean;
    constructor(service: ListService<T, P>, organizationItemService: ItemService<T>);
    viewType: OrganizationTableType;
    domainType: string;
    sortCode: string | undefined;
    iconTypes: typeof ICON_TYPE;
    createButtonAllTypes: typeof CreateButtonType;
    createButtonType: CreateButtonType;
    /**
     * Current search query value.
     */
    searchQuery: string;
    /**
     * Whether search is enabled for this list.
     */
    isSearchEnabled: boolean;
    /**
     * The i18n key for the search input placeholder.
     */
    searchPlaceholderKey: string;
    onSearchQueryChange(pagination: P | undefined, query: string): void;
    /**
     * The current key represents the current selected item from the dataset.
     * This key is used to load the item details as well as highlight the item in
     * a list of items.
     */
    readonly currentKey$: Observable<string>;
    readonly structure$: Observable<TableStructure>;
    /**
     * Cached values from the last successful data load.
     * Used to display semi-transparent table during loading.
     */
    cachedValues: T[];
    /**
     * Cached total count from the last successful data load.
     * Used to display count in header during loading.
     */
    cachedTotalCount: number | undefined;
    readonly listData$: Observable<EntitiesModel<T> | undefined>;
    key: string;
    hideAddButton: boolean;
    /**
     * Returns the total number of items.
     */
    getListCount(dataTable: Table | EntitiesModel<T>): number | undefined;
    /**
     * Browses to the given page number
     */
    browse(pagination: P | undefined, pageNumber: number): void;
    /**
     * Navigates to the detailed view of the selected list item.
     */
    launchItem(event: T): void;
    /**
     * Sorts the list.
     */
    sort(pagination: P | undefined): void;
    /**
     * Function to call when 'Manage Users' button is clicked
     */
    onCreateButtonClick(): void;
    /**
     * Returns the label for Create button
     */
    getCreateButtonLabel(): Translatable;
    /**
     * Clears the search query and reloads the list.
     */
    clearSearch(pagination: P | undefined): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListComponent<any, any>, "cx-org-list", never, { "key": { "alias": "key"; "required": false; }; "hideAddButton": { "alias": "hideAddButton"; "required": false; }; }, {}, never, ["[actions]"], true, never>;
}

declare class ListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ListModule, never, [typeof i1.CommonModule, typeof i3.RouterModule, typeof i7.SplitViewModule, typeof i7.TableModule, typeof i7.IconModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i7.PaginationModule, typeof i4$1.NgSelectModule, typeof i6.FormsModule, typeof MessageModule, typeof i7.KeyboardFocusModule, typeof i7.PopoverModule, typeof i4.FeaturesConfigModule, typeof ListComponent], [typeof ListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ListModule>;
}

declare class CardComponent<T extends BaseItem> {
    protected itemService: ItemService<T>;
    protected messageService: MessageService;
    i18nRoot: string;
    previous: boolean | string;
    subtitle?: string;
    showHint?: boolean | undefined;
    protected itemKey: string | undefined;
    iconTypes: typeof ICON_TYPE;
    item$: Observable<T | undefined>;
    view: ViewComponent;
    constructor(itemService: ItemService<T>, messageService: MessageService);
    /**
     * The views are router based, which means if we close a view, the router outlet is
     * cleaned immediately. To prevent this, we're closing the view manually, before
     * navigating back.
     */
    closeView(event: MouseEvent): boolean;
    get previousLabel(): string;
    protected refreshMessages(item: T | undefined): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardComponent<any>, "cx-org-card", never, { "i18nRoot": { "alias": "i18nRoot"; "required": false; }; "previous": { "alias": "previous"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "showHint": { "alias": "showHint"; "required": false; }; }, {}, never, ["[actions]", "[info]", "[main]"], true, never>;
}

/**
 * Provides a reusable card UI component for the organization split views.
 *
 * The component does not intend to provide a complete set of card features, it's just
 * a reusable component inside the organization UI.
 */
declare class CardModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CardModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CardModule, never, [typeof i1.CommonModule, typeof i7.SplitViewModule, typeof i3.RouterModule, typeof i4.I18nModule, typeof i7.IconModule, typeof i4.UrlModule, typeof MessageModule, typeof i7.PopoverModule, typeof i4.FeaturesConfigModule, typeof CardComponent], [typeof CardComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CardModule>;
}

declare class SubListComponent extends ListComponent {
    hostClass: string;
    messageService: MessageService;
    previous: boolean | string;
    key: string;
    showHint?: boolean | undefined;
    set routerKey(key: string);
    hasGhostData: boolean;
    subKey$: Observable<string>;
    readonly listData$: Observable<EntitiesModel<any> | undefined>;
    readonly dataStructure$: Observable<TableStructure>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SubListComponent, "cx-org-sub-list", never, { "previous": { "alias": "previous"; "required": false; }; "key": { "alias": "key"; "required": false; }; "showHint": { "alias": "showHint"; "required": false; }; "routerKey": { "alias": "routerKey"; "required": false; }; }, {}, never, ["[actions]", "[main]", "[info]"], true, never>;
}

declare class CellComponent implements OnInit {
    protected outlet: OutletContextData<TableDataOutletContext>;
    changeDetectorRef: ChangeDetectorRef;
    private featureToggles;
    private destroyRef;
    constructor(outlet: OutletContextData<TableDataOutletContext>);
    ngOnInit(): void;
    get tabIndex(): number;
    get model(): TableDataOutletContext;
    get property(): string | undefined;
    /**
     * Indicates wether the cell is linkable.
     *
     * If the cells is linkable, an anchor link is created to the detailed route
     * of the given `_type`.
     *
     * Defaults to `false`.
     */
    get linkable(): boolean;
    /**
     * Helper method to access the cell options.
     */
    get cellOptions(): TableFieldOptions;
    /**
     * Generates the configurable route to the detail page of the given context item.
     */
    get route(): string;
    get routeModel(): any;
    get type(): string;
    /**
     * Indicates whether the item is loaded.
     */
    get hasItem(): boolean;
    protected get item(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CellComponent, "cx-org-cell", never, {}, {}, never, never, true, never>;
}

declare class AssignCellComponent<T extends BaseItem> extends CellComponent {
    protected outlet: OutletContextData<TableDataOutletContext>;
    protected organizationItemService: ItemService<T>;
    protected messageService: MessageService;
    protected organizationSubListService: ListService<T>;
    constructor(outlet: OutletContextData<TableDataOutletContext>, organizationItemService: ItemService<T>, messageService: MessageService, organizationSubListService: ListService<T>);
    get isAssigned(): boolean;
    toggleAssign(): void;
    protected assign(key: string, linkKey: string): Observable<OrganizationItemStatus<T>>;
    protected unassign(key: string, linkKey: string): Observable<OrganizationItemStatus<T>>;
    /**
     * Returns the key for the linked object.
     *
     * At the moment, we're using a generic approach to assign objects,
     * but the object do not have a normalized shape. Therefor, we need
     * to evaluate the context to return the right key for the associated
     * item.
     */
    protected get link(): string;
    protected notify(item: any, state: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AssignCellComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AssignCellComponent<any>, "cx-org-assign-cell", never, {}, {}, never, never, true, never>;
}

declare class SubListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SubListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SubListModule, never, [typeof i1.CommonModule, typeof i4.I18nModule, typeof CardModule, typeof i7.TableModule, typeof i7.PaginationModule, typeof MessageModule, typeof i7.KeyboardFocusModule, typeof SubListComponent, typeof AssignCellComponent], [typeof SubListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SubListModule>;
}

declare class ItemActiveDirective<T extends BaseItem = BaseItem> implements OnInit, OnDestroy {
    protected itemService: ItemService<T>;
    protected messageService: MessageService;
    protected subscription: Subscription;
    constructor(itemService: ItemService<T>, messageService: MessageService);
    ngOnInit(): void;
    protected handleDisabledItems(item: BaseItem): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ItemActiveDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ItemActiveDirective<any>, "[cxOrgItemActive]", never, {}, {}, never, never, true, never>;
}

declare class ItemActiveModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ItemActiveModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ItemActiveModule, never, [typeof i1.CommonModule, typeof ItemActiveDirective], [typeof ItemActiveDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ItemActiveModule>;
}

/**
 * Reusable component for creating and editing organization items. The component does not
 * know anything about form specific.
 */
declare class FormComponent<T> implements OnInit, OnDestroy {
    protected itemService: ItemService<T>;
    protected messageService: MessageService;
    /**
     * i18n root for all localizations. The i18n root key is suffixed with
     * either `.edit` or `.create`, depending on the usage of the component.
     */
    i18nRoot: string;
    animateBack: boolean;
    subtitle?: string;
    /**
     * i18n key for the localizations.
     */
    i18n: string;
    form$: Observable<UntypedFormGroup | null>;
    /**
     * To handle the case of receiving a negative response during creation an item
     */
    disabled$: Observable<boolean>;
    constructor(itemService: ItemService<T>, messageService: MessageService);
    save(form: UntypedFormGroup): void;
    protected notify(item: T | undefined, action: string): void;
    protected setI18nRoot(item?: T): void;
    back(event: MouseEvent, card: CardComponent<any>): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormComponent<any>, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FormComponent<any>, "cx-org-form", never, { "i18nRoot": { "alias": "i18nRoot"; "required": false; }; "animateBack": { "alias": "animateBack"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; }, {}, never, ["[main]"], true, never>;
}

declare class FormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FormModule, never, [typeof i1.CommonModule, typeof i6.FormsModule, typeof i4.I18nModule, typeof i3.RouterModule, typeof CardModule, typeof MessageModule, typeof ItemActiveModule, typeof i7.KeyboardFocusModule, typeof FormComponent], [typeof FormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FormModule>;
}

declare class SharedOrganizationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SharedOrganizationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SharedOrganizationModule, never, [typeof ListModule, typeof SubListModule, typeof FormModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SharedOrganizationModule>;
}

interface ConfirmationMessageData extends MessageEventData {
    confirm?: boolean;
}

/**
 * Renders a confirmation message and cancel/confirm button in the message component.
 */
declare class ConfirmationMessageComponent extends BaseMessageComponent implements OnInit {
    protected data: MessageData<ConfirmationMessageData>;
    protected platformId: any;
    protected messageService: MessageService;
    cancelText: Translatable;
    confirmText: Translatable;
    constructor(data: MessageData<ConfirmationMessageData>, platformId: any, messageService: MessageService);
    ngOnInit(): void;
    /**
     * Emits a confirmation event to the data events.
     *
     * The original author of the event message or other parties can observe
     * the event data.
     */
    confirm(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmationMessageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfirmationMessageComponent, "cx-org-confirmation", never, {}, {}, never, never, true, never>;
}

declare class ConfirmationMessageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmationMessageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConfirmationMessageModule, never, [typeof i1.CommonModule, typeof i4.I18nModule, typeof i7.IconModule, typeof i7.KeyboardFocusModule, typeof ConfirmationMessageComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConfirmationMessageModule>;
}

declare class DisableInfoService<T extends BaseItem> {
    isItemDisabled(item: T): boolean;
    isParentDisabled(item: T): boolean;
    isRootUnit(item: B2BUnit): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DisableInfoService<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DisableInfoService<any>>;
}

/**
 * Reusable component in the my-company is to toggle the disabled state for
 * my company entities.
 */
declare class ToggleStatusComponent<T extends BaseItem> implements OnDestroy {
    protected itemService: ItemService<T>;
    protected messageService: MessageService<ConfirmationMessageData>;
    protected disableInfoService: DisableInfoService<T>;
    /**
     * The localization of messages is based on the i18n root. Messages are
     * concatenated to the root, such as:
     *
     * `[i18nRoot].messages.deactivate`
     */
    i18nRoot: string;
    /**
     * The key input can be used to add a custom key.
     *
     * Most _organization_ entities use the `code` key, but there is some variations.
     */
    key: string;
    /**
     * The disabled state is calculated but can be provided as well.
     */
    disabled: boolean;
    /**
     * resolves the current item.
     */
    current$: Observable<T | undefined>;
    /**
     * resolves if the user is currently in the edit form.
     */
    isInEditMode$: Observable<boolean>;
    protected subscription: Subscription;
    protected confirmation: Subject<ConfirmationMessageData> | null;
    constructor(itemService: ItemService<T>, messageService: MessageService<ConfirmationMessageData>, disableInfoService: DisableInfoService<T>);
    toggle(item: T): void;
    /**
     * Indicates whether the status can be toggled or not.
     */
    isDisabled(item: T): boolean;
    protected update(item: T): void;
    protected getPatchedItem(item: T): T;
    protected notify(item: T): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToggleStatusComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToggleStatusComponent<any>, "cx-org-toggle-status", never, { "i18nRoot": { "alias": "i18nRoot"; "required": false; }; "key": { "alias": "key"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ToggleStatusModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ToggleStatusModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ToggleStatusModule, never, [typeof i1.CommonModule, typeof i4.I18nModule, typeof MessageModule, typeof ConfirmationMessageModule, typeof ToggleStatusComponent], [typeof ToggleStatusComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ToggleStatusModule>;
}

declare class ItemExistsDirective<T = BaseItem> implements OnInit, OnDestroy {
    protected itemService: ItemService<T>;
    protected messageService: MessageService;
    protected subscription: Subscription;
    constructor(itemService: ItemService<T>, messageService: MessageService);
    ngOnInit(): void;
    protected handleErrorMessage(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ItemExistsDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ItemExistsDirective<any>, "[cxOrgItemExists]", never, {}, {}, never, never, true, never>;
}

declare class ItemExistsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ItemExistsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ItemExistsModule, never, [typeof i1.CommonModule, typeof ItemExistsDirective], [typeof ItemExistsDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ItemExistsModule>;
}

declare class DisableInfoComponent<T extends BaseItem> implements OnInit {
    protected itemService: ItemService<T>;
    protected disableInfoService: DisableInfoService<T>;
    /**
     * The localization of messages is based on the i18n root. Messages are
     * concatenated to the root, such as:
     *
     * `[i18nRoot].info.disabledEdit`
     */
    i18nRoot: string;
    /**
     * To configure the messages to display and override defaultMessageConfig
     */
    displayInfoConfig: {
        disabledCreate?: boolean;
        disabledEdit?: boolean;
        disabledEnable?: boolean;
        disabledDisable?: boolean;
    };
    /**
     * Flag to enable display custom message(s) even if no condition has been met
     */
    displayCustomInfo: boolean;
    /**
     * resolves the current item.
     */
    current$: Observable<T | undefined>;
    iconTypes: typeof ICON_TYPE;
    constructor(itemService: ItemService<T>, disableInfoService: DisableInfoService<T>);
    protected get defaultInfoConfig(): {
        disabledCreate: boolean;
        disabledEdit: boolean;
        disabledEnable: boolean;
        disabledDisable: boolean;
    };
    ngOnInit(): void;
    displayDisabledCreate(item: T): boolean | undefined;
    displayDisabledEdit(item: T): boolean | undefined;
    displayDisabledEnable(item: T): boolean | undefined;
    displayDisabledDisable(item: T): boolean | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<DisableInfoComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DisableInfoComponent<any>, "cx-org-disable-info", never, { "i18nRoot": { "alias": "i18nRoot"; "required": false; }; "displayInfoConfig": { "alias": "displayInfoConfig"; "required": false; }; "displayCustomInfo": { "alias": "displayCustomInfo"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class DisableInfoModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DisableInfoModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DisableInfoModule, never, [typeof i1.CommonModule, typeof i7.IconModule, typeof i4.I18nModule, typeof DisableInfoComponent], [typeof DisableInfoComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DisableInfoModule>;
}

declare class BudgetDetailsComponent implements OnInit {
    protected itemService: ItemService<Budget>;
    model$: Observable<Budget>;
    isInEditMode$: Observable<boolean>;
    ngOnInit(): void;
    constructor(itemService: ItemService<Budget>);
    static ɵfac: i0.ɵɵFactoryDeclaration<BudgetDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BudgetDetailsComponent, "cx-org-budget-details", never, {}, {}, never, never, true, never>;
}

declare class BudgetDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BudgetDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BudgetDetailsModule, never, [typeof i1.CommonModule, typeof CardModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof ToggleStatusModule, typeof ItemExistsModule, typeof DisableInfoModule, typeof i7.KeyboardFocusModule, typeof BudgetDetailsComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BudgetDetailsModule>;
}

declare class BudgetFormComponent implements OnInit {
    protected itemService: ItemService<Budget>;
    protected unitService: OrgUnitService;
    protected currencyService: CurrencyService;
    form: UntypedFormGroup | null;
    units$: Observable<B2BUnitNode[] | undefined>;
    currencies$: Observable<Currency[]>;
    constructor(itemService: ItemService<Budget>, unitService: OrgUnitService, currencyService: CurrencyService);
    ngOnInit(): void;
    createCodeWithName(name: AbstractControl | null, code: AbstractControl | null): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BudgetFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BudgetFormComponent, "cx-org-budget-form", never, {}, {}, never, never, true, never>;
}

declare class BudgetFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BudgetFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BudgetFormModule, never, [typeof i1.CommonModule, typeof i3.RouterModule, typeof FormModule, typeof i4$1.NgSelectModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i6.ReactiveFormsModule, typeof i7.FormErrorsModule, typeof ItemActiveModule, typeof i7.DatePickerModule, typeof i4.FeaturesConfigModule, typeof i7.FormRequiredAsterisksComponent, typeof i7.FormRequiredLegendComponent, typeof BudgetFormComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BudgetFormModule>;
}

declare class BudgetCostCenterListComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BudgetCostCenterListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BudgetCostCenterListComponent, "cx-org-budget-cost-center-list", never, {}, {}, never, never, true, never>;
}

declare class BudgetCostCenterListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BudgetCostCenterListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BudgetCostCenterListModule, never, [typeof i1.CommonModule, typeof SubListModule, typeof BudgetCostCenterListComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BudgetCostCenterListModule>;
}

declare class BudgetComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BudgetComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BudgetComponentsModule, never, [typeof SharedOrganizationModule, typeof BudgetDetailsModule, typeof BudgetFormModule, typeof BudgetCostCenterListModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BudgetComponentsModule>;
}

declare class CostCenterDetailsComponent {
    protected itemService: ItemService<CostCenter>;
    model$: Observable<CostCenter>;
    isInEditMode$: Observable<boolean>;
    constructor(itemService: ItemService<CostCenter>);
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CostCenterDetailsComponent, "cx-org-cost-center-details", never, {}, {}, never, never, true, never>;
}

declare class CostCenterDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CostCenterDetailsModule, never, [typeof i1.CommonModule, typeof CardModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof ToggleStatusModule, typeof ItemExistsModule, typeof DisableInfoModule, typeof i7.KeyboardFocusModule, typeof CostCenterDetailsComponent], [typeof CostCenterDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CostCenterDetailsModule>;
}

declare class CostCenterFormComponent {
    protected itemService: ItemService<CostCenter>;
    protected unitService: OrgUnitService;
    protected currencyService: CurrencyService;
    form: UntypedFormGroup | null;
    /**
     * Initialize the business unit for the cost center.
     *
     * If there's a unit provided, we disable the form control.
     */
    set unitKey(value: string | null);
    units$: Observable<B2BUnitNode[] | undefined>;
    currencies$: Observable<Currency[]>;
    constructor(itemService: ItemService<CostCenter>, unitService: OrgUnitService, currencyService: CurrencyService);
    createCodeWithName(name: AbstractControl | null, code: AbstractControl | null): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CostCenterFormComponent, "cx-org-cost-center-form", never, { "unitKey": { "alias": "unitKey"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CostCenterFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CostCenterFormModule, never, [typeof i1.CommonModule, typeof i3.RouterModule, typeof FormModule, typeof i4$1.NgSelectModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i6.ReactiveFormsModule, typeof i7.FormErrorsModule, typeof ItemActiveModule, typeof i4.FeaturesConfigModule, typeof i7.FormRequiredAsterisksComponent, typeof i7.FormRequiredLegendComponent, typeof CostCenterFormComponent], [typeof CostCenterFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CostCenterFormModule>;
}

declare class CostCenterAssignedBudgetListComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterAssignedBudgetListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CostCenterAssignedBudgetListComponent, "cx-org-cost-center-assigned-budget-list", never, {}, {}, never, never, true, never>;
}

declare class CostCenterBudgetListComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterBudgetListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CostCenterBudgetListComponent, "cx-org-cost-center-budget-list", never, {}, {}, never, never, true, never>;
}

declare class CostCenterBudgetListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterBudgetListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CostCenterBudgetListModule, never, [typeof ListModule, typeof i4.I18nModule, typeof i3.RouterModule, typeof SubListModule, typeof CostCenterAssignedBudgetListComponent, typeof CostCenterBudgetListComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CostCenterBudgetListModule>;
}

/**
 * Reusable component in the my-company is to delete an item (if it's possible)
 */
declare class DeleteItemComponent<T extends BaseItem> implements OnDestroy {
    protected itemService: ItemService<T>;
    protected messageService: MessageService<ConfirmationMessageData>;
    /**
     * The localization of messages is based on the i18n root. Messages are
     * concatenated to the root, such as:
     *
     * `[i18nRoot].messages.deactivate`
     */
    i18nRoot: string;
    /**
     * The key input can be used to add a custom key.
     *
     * Most _organization_ entities use the `code` key, but there is some variations.
     */
    key: string;
    /**
     * The additionalParam input can be used to provide additional data if it's required
     * for API request
     */
    additionalParam?: string;
    /**
     * resolves the current item.
     */
    current$: Observable<T | undefined>;
    /**
     * resolves if the user is currently in the edit form.
     */
    isInEditMode$: Observable<boolean>;
    protected subscription: Subscription;
    protected confirmation: Subject<ConfirmationMessageData> | null;
    constructor(itemService: ItemService<T>, messageService: MessageService<ConfirmationMessageData>);
    delete(item: T): void;
    protected confirmDelete(item: T): void;
    protected notify(item: T): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeleteItemComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeleteItemComponent<any>, "cx-org-delete-item", never, { "i18nRoot": { "alias": "i18nRoot"; "required": false; }; "key": { "alias": "key"; "required": false; }; "additionalParam": { "alias": "additionalParam"; "required": false; }; }, {}, never, never, true, never>;
}

declare class DeleteItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DeleteItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DeleteItemModule, never, [typeof i1.CommonModule, typeof i4.I18nModule, typeof MessageModule, typeof ConfirmationMessageModule, typeof DeleteItemComponent], [typeof DeleteItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DeleteItemModule>;
}

declare abstract class SubListService<T extends BaseItem> extends ListService<T> {
    /**
     * The default table structure for sub lists is only showing tables with vertical layout.
     */
    protected defaultTableStructure: ResponsiveTableConfiguration;
    /**
     * @override This sub list will show 3 items.
     */
    protected ghostData: EntitiesModel<T>;
    assign?(_key: string, ..._args: any): Observable<OrganizationItemStatus<T>>;
    unassign?(_key: string, ..._args: any): Observable<OrganizationItemStatus<T>>;
    /**
     * As we can't filter with the backend API, we do this client side.
     */
    protected filterSelected(list: EntitiesModel<T> | undefined): EntitiesModel<T> | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubListService<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SubListService<any>>;
}

declare class ActiveLinkCellComponent extends CellComponent {
    get tabIndex(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActiveLinkCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActiveLinkCellComponent, "cx-org-active-link-cell", never, {}, {}, never, never, true, never>;
}

declare class AmountCellComponent extends CellComponent {
    get property(): string | undefined;
    protected get budget(): any;
    protected get currency(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<AmountCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AmountCellComponent, "cx-org-amount-cell", never, {}, {}, never, never, true, never>;
}

declare class DateRangeCellComponent extends CellComponent {
    get linkable(): boolean;
    get hasRange(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateRangeCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DateRangeCellComponent, "cx-org-date-range-cell", never, {}, {}, never, never, true, never>;
}

declare class LimitCellComponent extends CellComponent {
    get isTimeSpanThreshold(): boolean;
    get isOrderThreshold(): boolean;
    get isExceedPermission(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<LimitCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LimitCellComponent, "cx-org-limit-cell", never, {}, {}, never, never, true, never>;
}

declare class RolesCellComponent extends CellComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<RolesCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RolesCellComponent, "cx-org-roles-cell", never, {}, {}, never, never, true, never>;
}

declare class StatusCellComponent extends CellComponent {
    get label(): "organization.enabled" | "organization.disabled" | undefined;
    get isActive(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<StatusCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StatusCellComponent, "cx-org-status-cell", never, {}, {}, never, never, true, never>;
}

declare class UnitCellComponent extends CellComponent {
    get property(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitCellComponent, "cx-org-unit-cell", never, {}, {}, never, never, true, never>;
}

declare class CellModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CellModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CellModule, never, [typeof i1.CommonModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i7.IconModule, typeof CellComponent, typeof ActiveLinkCellComponent, typeof AmountCellComponent, typeof DateRangeCellComponent, typeof LimitCellComponent, typeof RolesCellComponent, typeof StatusCellComponent, typeof UnitCellComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CellModule>;
}

declare class BudgetDetailsCellComponent extends CellComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BudgetDetailsCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BudgetDetailsCellComponent, "cx-org-budget-details-cell", never, {}, {}, never, never, true, never>;
}

declare class BudgetDetailsCellModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BudgetDetailsCellModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BudgetDetailsCellModule, never, [typeof i1.CommonModule, typeof i7.PopoverModule, typeof i3.RouterModule, typeof i4.I18nModule, typeof i4.UrlModule, typeof BudgetDetailsCellComponent], [typeof BudgetDetailsCellComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BudgetDetailsCellModule>;
}

declare class CostCenterComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CostCenterComponentsModule, never, [typeof SharedOrganizationModule, typeof CostCenterDetailsModule, typeof CostCenterFormModule, typeof CostCenterBudgetListModule, typeof BudgetDetailsCellModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CostCenterComponentsModule>;
}

declare enum TREE_TOGGLE {
    EXPANDED = 0,
    COLLAPSED = 1
}

/**
 * Service to populate Unit data to `Table` data. Unit
 * data is driven by the table configuration, using the `OrganizationTables.UNIT`.
 */
declare class UnitTreeService {
    /**
     * Indicates the minimum number of (initial) expanded units.
     */
    protected minimalExpanded: number;
    protected globalToggle$: BehaviorSubject<TREE_TOGGLE | undefined>;
    treeToggle$: BehaviorSubject<Map<string, TREE_TOGGLE>>;
    /**
     * Initializes the unit tree with an active unit.
     *
     * The active unit will be collapsed.
     */
    initialize(root: B2BUnitNode, activeUnitId: string): void;
    /**
     * Sets the global toggle state to _collapsed_ and clears the toggle state
     * for individual units.
     */
    collapseAll(): void;
    /**
     * Sets the global toggle state to _expanded_ and clears the toggle state
     * for individual units.
     */
    expandAll(): void;
    /**
     * Indicates whether the give unit is expanded.
     *
     * The returned (boolean) expand state is driven by the global toggle
     * state (expand / collapse all) and the toggle state for individual units.
     * There's also the `minimalExpanded` taken into consideration.
     */
    isExpanded(unitId: string, level: number): boolean;
    toggle(unit: B2BUnitTreeNode): void;
    /**
     * Expands all tree nodes till the active unit, to ensure that the
     * full tree is collapsed till the active item.
     *
     * This is useful while navigating the tree by the router.
     */
    protected expandUntilActiveNode(node: B2BUnitNode, activeUnitId: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitTreeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitTreeService>;
}

declare class UnitListComponent {
    protected unitTreeService: UnitTreeService;
    protected orgUnitService?: OrgUnitService | undefined;
    constructor(unitTreeService: UnitTreeService, orgUnitService?: OrgUnitService | undefined);
    readonly isUpdatingUnitAllowed: boolean;
    expandAll(): void;
    collapseAll(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitListComponent, "cx-org-unit-list", never, {}, {}, never, never, true, never>;
}

declare class ToggleLinkCellComponent extends CellComponent {
    protected outlet: OutletContextData<TableDataOutletContext>;
    protected unitTreeService: UnitTreeService;
    get depthLevel(): any;
    protected elementRef: ElementRef<any>;
    protected routingService: RoutingService;
    private featureService;
    protected readonly isLargeScreen$: rxjs.Observable<boolean>;
    constructor(outlet: OutletContextData<TableDataOutletContext>, unitTreeService: UnitTreeService);
    get combinedName(): string;
    get expanded(): any;
    /**
     * Counts the number of descendants
     */
    get count(): any;
    toggleItem(event: Event): void;
    /**
     * Indicates whether the tree item should have a toggle navigation.
     *
     * The toggle navigation is used in case the tree item has descendants,
     * and if the tree item level is not configured to be shown anyway.
     */
    get isSwitchable(): boolean;
    get hasItem(): boolean;
    protected get item(): B2BUnit | null;
    onKeydown(event: KeyboardEvent): void;
    onSpace(event: KeyboardEvent, siblingElements: HTMLElement[]): void;
    onArrowDown(event: KeyboardEvent, currentSelectedIndex: number, siblingElements: HTMLElement[]): void;
    onArrowUp(event: KeyboardEvent, currentSelectedIndex: number, siblingElements: HTMLElement[]): void;
    onArrowRight(event: KeyboardEvent): void;
    onArrowLeft(event: KeyboardEvent): void;
    /**
     * To be removed when a11yCardNotificationMessage is enabled.
     * @deprecated
     */
    restoreFocus(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToggleLinkCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToggleLinkCellComponent, "cx-org-toggle-link-cell", never, {}, {}, never, never, true, never>;
}

declare class UnitListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitListModule, never, [typeof i1.CommonModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i7.IconModule, typeof ListModule, typeof UnitListComponent, typeof ToggleLinkCellComponent], [typeof ToggleLinkCellComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitListModule>;
}

declare class UnitDetailsComponent {
    protected itemService: ItemService<B2BUnit>;
    protected orgUnitService?: OrgUnitService | undefined;
    private featureToggles;
    get isA11yCardNotificationMessageFeatureEnabled(): boolean;
    model$: Observable<B2BUnit>;
    refreshFocusReference$: Observable<string | B2BUnit>;
    isInEditMode$: Observable<boolean>;
    readonly isUpdatingUnitAllowed: boolean;
    constructor(itemService: ItemService<B2BUnit>, orgUnitService?: OrgUnitService | undefined);
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitDetailsComponent, "cx-org-unit-details", never, {}, {}, never, never, true, never>;
}

declare class UnitDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitDetailsModule, never, [typeof i1.CommonModule, typeof CardModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof ToggleStatusModule, typeof ItemExistsModule, typeof i7.KeyboardFocusModule, typeof DisableInfoModule, typeof UnitDetailsComponent], [typeof UnitDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitDetailsModule>;
}

declare class UnitFormComponent implements OnInit {
    protected itemService: ItemService<B2BUnit>;
    protected unitService: OrgUnitService;
    i18nRoot: string;
    createChildUnit: boolean;
    form: UntypedFormGroup | null;
    units$: Observable<B2BUnitNode[] | undefined>;
    approvalProcess$: Observable<B2BApprovalProcess[]>;
    constructor(itemService: ItemService<B2BUnit>, unitService: OrgUnitService);
    ngOnInit(): void;
    createUidWithName(name: AbstractControl | null, code: AbstractControl | null): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitFormComponent, "cx-org-unit-form", never, { "i18nRoot": { "alias": "i18nRoot"; "required": false; }; "createChildUnit": { "alias": "createChildUnit"; "required": false; }; }, {}, never, never, true, never>;
}

declare class UnitFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitFormModule, never, [typeof i1.CommonModule, typeof i3.RouterModule, typeof FormModule, typeof i4$1.NgSelectModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i6.ReactiveFormsModule, typeof i7.FormErrorsModule, typeof ItemActiveModule, typeof i4.FeaturesConfigModule, typeof i7.NgSelectA11yModule, typeof i7.FormRequiredAsterisksComponent, typeof i7.FormRequiredLegendComponent, typeof UnitFormComponent], [typeof UnitFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitFormModule>;
}

declare class CurrentUnitService extends CurrentItemService<B2BUnit> {
    protected routingService: RoutingService;
    protected orgUnitService: OrgUnitService;
    constructor(routingService: RoutingService, orgUnitService: OrgUnitService);
    protected getParamKey(): string;
    protected getItem(code: string): Observable<B2BUnit>;
    getError(code: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrentUnitService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrentUnitService>;
}

declare class UnitChildrenComponent {
    protected currentUnitService: CurrentUnitService;
    unit$: Observable<B2BUnit | undefined>;
    constructor(currentUnitService: CurrentUnitService);
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitChildrenComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitChildrenComponent, "cx-org-unit-children", never, {}, {}, never, never, true, never>;
}

declare class UnitChildrenModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitChildrenModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitChildrenModule, never, [typeof ListModule, typeof i4.I18nModule, typeof i3.RouterModule, typeof SubListModule, typeof i1.CommonModule, typeof DisableInfoModule, typeof UnitChildrenComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitChildrenModule>;
}

declare class UnitApproverListComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitApproverListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitApproverListComponent, "cx-org-unit-approver-list", never, {}, {}, never, never, true, never>;
}

declare class UnitAssignedApproverListComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitAssignedApproverListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitAssignedApproverListComponent, "cx-org-unit-assigned-approver-list", never, {}, {}, never, never, true, never>;
}

declare class UnitApproverListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitApproverListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitApproverListModule, never, [typeof i4.I18nModule, typeof i3.RouterModule, typeof SubListModule, typeof UnitApproverListComponent, typeof UnitAssignedApproverListComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitApproverListModule>;
}

declare class UnitUserListComponent {
    protected currentUnitService: CurrentUnitService;
    protected b2bUserService: B2BUserService;
    routerKey: string;
    unit$: Observable<B2BUnit | undefined>;
    isUpdatingUserAllowed: boolean;
    constructor(currentUnitService: CurrentUnitService, b2bUserService: B2BUserService);
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitUserListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitUserListComponent, "cx-org-unit-user-list", never, {}, {}, never, never, true, never>;
}

declare class UnitUserRolesCellComponent extends CellComponent {
    protected outlet: OutletContextData<TableDataOutletContext>;
    protected itemService: ItemService<B2BUnit>;
    protected b2bUserService: B2BUserService;
    unitKey$: Observable<string>;
    constructor(outlet: OutletContextData<TableDataOutletContext>, itemService: ItemService<B2BUnit>, b2bUserService: B2BUserService);
    isUpdatingUserAllowed: boolean;
    getRouterModel(uid: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitUserRolesCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitUserRolesCellComponent, "cx-org-unit-user-link-cell", never, {}, {}, never, never, true, never>;
}

declare class UnitUserListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitUserListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitUserListModule, never, [typeof i1.CommonModule, typeof i4.I18nModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof SubListModule, typeof DisableInfoModule, typeof UnitUserListComponent, typeof UnitUserRolesCellComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitUserListModule>;
}

declare class UserFormService extends FormService<B2BUser> {
    protected build(): void;
    protected patchData(item: B2BUser): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserFormService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserFormService>;
}

declare class CurrentUserService extends CurrentItemService<B2BUser> {
    protected routingService: RoutingService;
    protected b2bUserService: B2BUserService;
    readonly name$: Observable<string | undefined>;
    constructor(routingService: RoutingService, b2bUserService: B2BUserService);
    protected getParamKey(): string;
    protected getItem(code: string): Observable<B2BUser>;
    getError(code: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrentUserService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrentUserService>;
}

declare class UserItemService extends ItemService<B2BUser> {
    protected currentItemService: CurrentUserService;
    protected routingService: RoutingService;
    protected formService: UserFormService;
    protected userService: B2BUserService;
    constructor(currentItemService: CurrentUserService, routingService: RoutingService, formService: UserFormService, userService: B2BUserService);
    load(code: string): Observable<B2BUser>;
    update(code: string, value: B2BUser): Observable<OrganizationItemStatus<B2BUser>>;
    protected create(value: B2BUser): Observable<OrganizationItemStatus<B2BUser>>;
    protected getDetailsRoute(): string;
    launchDetails(item: B2BUser): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserItemService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserItemService>;
}

declare class UnitUserRolesFormService extends FormService<B2BUser> {
    protected userService: B2BUserService;
    availableRoles: B2BUserRole[];
    availableRights: B2BUserRight[];
    constructor(userService: B2BUserService);
    getForm(item?: B2BUser): UntypedFormGroup | null;
    protected build(): void;
    protected patchData(item: B2BUser): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitUserRolesFormService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitUserRolesFormService>;
}

declare class UnitUserRolesFormComponent {
    protected itemService: ItemService<B2BUser>;
    protected formService: UnitUserRolesFormService;
    protected userService: B2BUserService;
    protected userItemService: UserItemService;
    protected item: B2BUser | undefined;
    messageService: MessageService;
    form$: Observable<UntypedFormGroup | null>;
    availableRoles: B2BUserRole[];
    availableRights: B2BUserRight[];
    constructor(itemService: ItemService<B2BUser>, formService: UnitUserRolesFormService, userService: B2BUserService, userItemService: UserItemService);
    save(form: UntypedFormGroup): void;
    protected notify(item: B2BUser): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitUserRolesFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitUserRolesFormComponent, "cx-org-unit-user-roles", never, {}, {}, never, never, true, never>;
}

declare class UnitUserRolesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitUserRolesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitUserRolesModule, never, [typeof i1.CommonModule, typeof CardModule, typeof i6.FormsModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i6.ReactiveFormsModule, typeof i7.KeyboardFocusModule, typeof UnitUserRolesFormComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitUserRolesModule>;
}

declare class UnitUsersModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitUsersModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitUsersModule, never, [typeof UnitUserListModule, typeof UnitUserRolesModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitUsersModule>;
}

declare class UnitCostCenterListComponent {
    protected currentUnitService: CurrentUnitService;
    unit$: Observable<B2BUnit | undefined>;
    constructor(currentUnitService: CurrentUnitService);
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitCostCenterListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitCostCenterListComponent, "cx-org-unit-cost-centers", never, {}, {}, never, never, true, never>;
}

declare class UnitCostCenterListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitCostCenterListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitCostCenterListModule, never, [typeof i4.I18nModule, typeof i3.RouterModule, typeof SubListModule, typeof i1.CommonModule, typeof DisableInfoModule, typeof UnitCostCenterListComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitCostCenterListModule>;
}

declare class UnitAddressListComponent {
    routerKey: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitAddressListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitAddressListComponent, "cx-org-unit-address-list", never, {}, {}, never, never, true, never>;
}

declare class LinkCellComponent extends CellComponent {
    protected outlet: OutletContextData<TableDataOutletContext>;
    protected itemService: ItemService<B2BUnit>;
    unitKey$: Observable<string>;
    constructor(outlet: OutletContextData<TableDataOutletContext>, itemService: ItemService<B2BUnit>);
    get tabIndex(): number;
    getRouterModel(uid: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LinkCellComponent, "cx-org-link-cell", never, {}, {}, never, never, true, never>;
}

declare class UnitAddressListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitAddressListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitAddressListModule, never, [typeof i1.CommonModule, typeof i4.I18nModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof SubListModule, typeof UnitAddressListComponent, typeof LinkCellComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitAddressListModule>;
}

declare class UnitAddressDetailsComponent {
    protected itemService: ItemService<Address>;
    protected currentUnitService: CurrentUnitService;
    protected userAddressService: UserAddressService;
    unit$: Observable<B2BUnit | undefined>;
    model$: Observable<Address>;
    getCountry(isoCode: string | undefined): Observable<Country | undefined>;
    constructor(itemService: ItemService<Address>, currentUnitService: CurrentUnitService, userAddressService: UserAddressService);
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitAddressDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitAddressDetailsComponent, "cx-org-unit-address-details", never, {}, {}, never, never, true, never>;
}

declare class UnitAddressDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitAddressDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitAddressDetailsModule, never, [typeof i1.CommonModule, typeof CardModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof DeleteItemModule, typeof i7.KeyboardFocusModule, typeof UnitAddressDetailsComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitAddressDetailsModule>;
}

declare class UnitAddressFormService extends FormService<Address> {
    protected userAddressService: UserAddressService;
    protected userProfileFacade: UserProfileFacade;
    protected readonly maxFieldLength = 256;
    private featureToggles;
    constructor(userAddressService: UserAddressService, userProfileFacade: UserProfileFacade);
    protected build(): void;
    getCountries(): Observable<Country[]>;
    getTitles(): Observable<Title[]>;
    getRegions(): Observable<Region[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitAddressFormService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitAddressFormService>;
}

declare class UnitAddressFormComponent implements OnInit {
    protected itemService: ItemService<Address>;
    protected formService: UnitAddressFormService;
    protected currentUnitService: CurrentUnitService;
    form: UntypedFormGroup | null;
    key$: Observable<string>;
    countries$: Observable<Country[]>;
    titles$: Observable<Title[]>;
    regions$: Observable<Region[]>;
    unit$: Observable<B2BUnit | undefined>;
    constructor(itemService: ItemService<Address>, formService: UnitAddressFormService, currentUnitService: CurrentUnitService);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitAddressFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitAddressFormComponent, "cx-org-unit-address-form", never, {}, {}, never, never, true, never>;
}

declare class UnitAddressFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitAddressFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitAddressFormModule, never, [typeof i1.CommonModule, typeof FormModule, typeof i4$1.NgSelectModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i6.ReactiveFormsModule, typeof i7.FormErrorsModule, typeof i4.FeaturesConfigModule, typeof i7.FormRequiredAsterisksComponent, typeof i7.FormRequiredLegendComponent, typeof UnitAddressFormComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitAddressFormModule>;
}

declare class UnitAddressModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitAddressModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitAddressModule, never, [typeof UnitAddressListModule, typeof UnitAddressDetailsModule, typeof UnitAddressFormModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitAddressModule>;
}

declare class UnitsComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitsComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitsComponentsModule, never, [typeof i3.RouterModule, typeof UnitListModule, typeof UnitDetailsModule, typeof UnitFormModule, typeof UnitChildrenModule, typeof UnitApproverListModule, typeof UnitUsersModule, typeof UnitCostCenterListModule, typeof UnitAddressModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitsComponentsModule>;
}

declare class UserGroupDetailsComponent {
    protected itemService: ItemService<UserGroup>;
    model$: Observable<UserGroup>;
    isInEditMode$: Observable<boolean>;
    constructor(itemService: ItemService<UserGroup>);
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserGroupDetailsComponent, "cx-org-user-group-details", never, {}, {}, never, never, true, never>;
}

declare class UserGroupDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserGroupDetailsModule, never, [typeof i1.CommonModule, typeof CardModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof DeleteItemModule, typeof ItemExistsModule, typeof i7.KeyboardFocusModule, typeof UserGroupDetailsComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserGroupDetailsModule>;
}

declare class UserGroupFormComponent implements OnInit {
    protected itemService: ItemService<UserGroup>;
    protected unitService: OrgUnitService;
    form: UntypedFormGroup | null;
    units$: Observable<B2BUnitNode[] | undefined>;
    constructor(itemService: ItemService<UserGroup>, unitService: OrgUnitService);
    ngOnInit(): void;
    createUidWithName(name: AbstractControl | null, code: AbstractControl | null): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserGroupFormComponent, "cx-org-user-group-form", never, {}, {}, never, never, true, never>;
}

declare class UserGroupFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserGroupFormModule, never, [typeof i1.CommonModule, typeof i3.RouterModule, typeof i4$1.NgSelectModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i6.ReactiveFormsModule, typeof i7.FormErrorsModule, typeof FormModule, typeof i4.FeaturesConfigModule, typeof i7.FormRequiredAsterisksComponent, typeof i7.FormRequiredLegendComponent, typeof UserGroupFormComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserGroupFormModule>;
}

declare class UserGroupPermissionListComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupPermissionListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserGroupPermissionListComponent, "cx-org-user-group-permission-list", never, {}, {}, never, never, true, never>;
}

declare class UserGroupAssignedPermissionListComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupAssignedPermissionListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserGroupAssignedPermissionListComponent, "cx-org-user-group-assigned-permission-list", never, {}, {}, never, never, true, never>;
}

declare class UserGroupPermissionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupPermissionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserGroupPermissionModule, never, [typeof i1.CommonModule, typeof i4.I18nModule, typeof i3.RouterModule, typeof SubListModule, typeof UserGroupPermissionListComponent, typeof UserGroupAssignedPermissionListComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserGroupPermissionModule>;
}

declare class UserGroupAssignedUserListComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupAssignedUserListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserGroupAssignedUserListComponent, "cx-org-user-group-assigned-user-list", never, {}, {}, never, never, true, never>;
}

declare class CurrentUserGroupService extends CurrentItemService<UserGroup> {
    protected routingService: RoutingService;
    protected userGroupService: UserGroupService;
    constructor(routingService: RoutingService, userGroupService: UserGroupService);
    protected getParamKey(): string;
    protected getItem(code: string): Observable<UserGroup>;
    getError(code: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrentUserGroupService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrentUserGroupService>;
}

declare class UserGroupUserListService extends SubListService<B2BUser> {
    protected tableService: TableService;
    protected userGroupService: UserGroupService;
    protected userService: B2BUserService;
    protected tableType: OrganizationTableType;
    protected _domainType: OrganizationTableType;
    constructor(tableService: TableService, userGroupService: UserGroupService, userService: B2BUserService);
    /**
     *
     * @override
     * Loads all b2b users.
     *
     * @param code The user group code.
     */
    protected load(pagination: PaginationModel, code: string): Observable<EntitiesModel<B2BUser> | undefined>;
    /**
     * @override
     * Assign user to the user group.
     */
    assign(userGroupCode: string, customerId: string): Observable<OrganizationItemStatus<B2BUser>>;
    /**
     * @override
     * Unassigns the user from the user group.
     */
    unassign(userGroupCode: string, customerId: string): Observable<OrganizationItemStatus<B2BUser>>;
    unassignAllMembers(userGroupCode: string): Observable<OrganizationItemStatus<UserGroup>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupUserListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserGroupUserListService>;
}

declare class UserGroupUserListComponent {
    protected currentUserGroupService: CurrentUserGroupService;
    protected userGroupUserListService: UserGroupUserListService;
    constructor(currentUserGroupService: CurrentUserGroupService, userGroupUserListService: UserGroupUserListService);
    subList: SubListComponent;
    unassignAll(): void;
    protected notify(item: UserGroup | undefined): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupUserListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserGroupUserListComponent, "cx-org-user-group-user-list", never, {}, {}, never, never, true, never>;
}

declare class UserGroupUserModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupUserModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserGroupUserModule, never, [typeof i1.CommonModule, typeof i4.I18nModule, typeof i3.RouterModule, typeof SubListModule, typeof UserGroupAssignedUserListComponent, typeof UserGroupUserListComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserGroupUserModule>;
}

declare class UserGroupComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserGroupComponentsModule, never, [typeof SharedOrganizationModule, typeof UserGroupDetailsModule, typeof UserGroupFormModule, typeof UserGroupPermissionModule, typeof UserGroupUserModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserGroupComponentsModule>;
}

declare class UserChangePasswordFormService extends FormService<any> {
    /**
     * @override
     * Adds the password and confirmPassword field. Also adds the customerId field,
     * so that the customerId can be used during persistent.
     */
    protected build(): void;
    getForm(item?: User): UntypedFormGroup | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserChangePasswordFormService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserChangePasswordFormService>;
}

declare class UserChangePasswordFormComponent {
    protected itemService: UserItemService;
    protected formService: UserChangePasswordFormService;
    protected messageService: MessageService;
    form$: Observable<UntypedFormGroup | null>;
    constructor(itemService: UserItemService, formService: UserChangePasswordFormService, messageService: MessageService);
    save(form: UntypedFormGroup): void;
    protected notify(item: User): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserChangePasswordFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserChangePasswordFormComponent, "cx-org-user-change-password-form", never, {}, {}, never, never, true, never>;
}

declare class UserChangePasswordFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserChangePasswordFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserChangePasswordFormModule, never, [typeof i1.CommonModule, typeof i3.RouterModule, typeof i4$1.NgSelectModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i6.ReactiveFormsModule, typeof i7.FormErrorsModule, typeof CardModule, typeof i7.KeyboardFocusModule, typeof i7.PasswordVisibilityToggleModule, typeof i4.FeaturesConfigModule, typeof i7.FormRequiredAsterisksComponent, typeof i7.FormRequiredLegendComponent, typeof UserChangePasswordFormComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserChangePasswordFormModule>;
}

declare class UserDetailsComponent {
    protected itemService: ItemService<B2BUser>;
    protected b2bUserService: B2BUserService;
    userGuardSubscription: Subscription;
    model$: Observable<B2BUser>;
    isInEditMode$: Observable<boolean>;
    isUpdatingUserAllowed: boolean;
    availableRoles: string[];
    availableRights: string[];
    constructor(itemService: ItemService<B2BUser>, b2bUserService: B2BUserService);
    hasRight(model: B2BUser): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserDetailsComponent, "cx-org-user-details", never, {}, {}, never, never, true, never>;
}

declare class UserDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserDetailsModule, never, [typeof i1.CommonModule, typeof CardModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof ToggleStatusModule, typeof ItemExistsModule, typeof DisableInfoModule, typeof i7.KeyboardFocusModule, typeof UserDetailsComponent], [typeof UserDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserDetailsModule>;
}

declare class UserFormComponent implements OnInit {
    protected itemService: ItemService<B2BUser>;
    protected unitService: OrgUnitService;
    protected userProfileFacade: UserProfileFacade;
    protected b2bUserService: B2BUserService;
    form: UntypedFormGroup | null;
    /**
     * Initialize the business unit for the user.
     *
     * If there's a unit provided, we disable the unit form control.
     */
    set unitKey(value: string | null);
    units$: Observable<B2BUnitNode[] | undefined>;
    titles$: Observable<Title[]>;
    availableRoles: B2BUserRole[];
    availableRights: B2BUserRight[];
    constructor(itemService: ItemService<B2BUser>, unitService: OrgUnitService, userProfileFacade: UserProfileFacade, b2bUserService: B2BUserService);
    ngOnInit(): void;
    updateRoles(event: MouseEvent): void;
    get roles(): UntypedFormArray;
    get isAssignedToApprovers(): UntypedFormControl;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserFormComponent, "cx-org-user-form", never, { "unitKey": { "alias": "unitKey"; "required": false; }; }, {}, never, never, true, never>;
}

declare class UserFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserFormModule, never, [typeof i1.CommonModule, typeof i3.RouterModule, typeof FormModule, typeof i4$1.NgSelectModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i6.ReactiveFormsModule, typeof i7.FormErrorsModule, typeof i4.FeaturesConfigModule, typeof i7.FormRequiredAsterisksComponent, typeof i7.FormRequiredLegendComponent, typeof UserFormComponent], [typeof UserFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserFormModule>;
}

declare class UserPermissionListComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserPermissionListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserPermissionListComponent, "cx-org-user-permission-list", never, {}, {}, never, never, true, never>;
}

declare class UserAssignedPermissionListComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAssignedPermissionListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserAssignedPermissionListComponent, "cx-org-user-assigned-permission-list", never, {}, {}, never, never, true, never>;
}

declare class UserPermissionListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserPermissionListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserPermissionListModule, never, [typeof ListModule, typeof i4.I18nModule, typeof i3.RouterModule, typeof SubListModule, typeof UserPermissionListComponent, typeof UserAssignedPermissionListComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserPermissionListModule>;
}

declare class UserUserGroupListComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserUserGroupListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserUserGroupListComponent, "cx-org-user-user-group-list", never, {}, {}, never, never, true, never>;
}

declare class UserAssignedUserGroupListComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAssignedUserGroupListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserAssignedUserGroupListComponent, "cx-org-user-assigned-user-group-list", never, {}, {}, never, never, true, never>;
}

declare class UserUserGroupsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserUserGroupsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserUserGroupsModule, never, [typeof ListModule, typeof i4.I18nModule, typeof i3.RouterModule, typeof SubListModule, typeof UserUserGroupListComponent, typeof UserAssignedUserGroupListComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserUserGroupsModule>;
}

declare class UserApproverListComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserApproverListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserApproverListComponent, "cx-org-user-approver-list", never, {}, {}, never, never, true, never>;
}

declare class UserAssignedApproverListComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAssignedApproverListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserAssignedApproverListComponent, "cx-org-user-assigned-approver-list", never, {}, {}, never, never, true, never>;
}

declare class UserApproverListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserApproverListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserApproverListModule, never, [typeof ListModule, typeof i4.I18nModule, typeof i3.RouterModule, typeof SubListModule, typeof UserApproverListComponent, typeof UserAssignedApproverListComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserApproverListModule>;
}

declare class UserComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserComponentsModule, never, [typeof ListModule, typeof UserChangePasswordFormModule, typeof UserDetailsModule, typeof UserFormModule, typeof UserPermissionListModule, typeof UserUserGroupsModule, typeof UserApproverListModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserComponentsModule>;
}

declare class PermissionDetailsComponent {
    protected itemService: ItemService<Permission>;
    model$: Observable<Permission>;
    isInEditMode$: Observable<boolean>;
    constructor(itemService: ItemService<Permission>);
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PermissionDetailsComponent, "cx-org-permission-details", never, {}, {}, never, never, true, never>;
}

declare class PermissionDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PermissionDetailsModule, never, [typeof i1.CommonModule, typeof CardModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof ToggleStatusModule, typeof ItemExistsModule, typeof DisableInfoModule, typeof i7.KeyboardFocusModule, typeof PermissionDetailsComponent], [typeof PermissionDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PermissionDetailsModule>;
}

declare class PermissionFormComponent implements OnInit {
    protected itemService: ItemService<Permission>;
    protected unitService: OrgUnitService;
    protected currencyService: CurrencyService;
    protected permissionService: PermissionService;
    form: UntypedFormGroup | null;
    units$: Observable<B2BUnitNode[] | undefined>;
    currencies$: Observable<Currency[]>;
    types$: Observable<OrderApprovalPermissionType[] | undefined>;
    periods: string[];
    constructor(itemService: ItemService<Permission>, unitService: OrgUnitService, currencyService: CurrencyService, permissionService: PermissionService);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PermissionFormComponent, "cx-org-permission-form", never, {}, {}, never, never, true, never>;
}

declare class PermissionFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PermissionFormModule, never, [typeof i1.CommonModule, typeof i3.RouterModule, typeof i4$1.NgSelectModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i6.ReactiveFormsModule, typeof i7.FormErrorsModule, typeof FormModule, typeof ItemActiveModule, typeof i4.FeaturesConfigModule, typeof i7.FormRequiredAsterisksComponent, typeof i7.FormRequiredLegendComponent, typeof PermissionFormComponent], [typeof PermissionFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PermissionFormModule>;
}

declare class PermissionComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PermissionComponentsModule, never, [typeof SharedOrganizationModule, typeof PermissionDetailsModule, typeof PermissionFormModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PermissionComponentsModule>;
}

declare class AdministrationComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AdministrationComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AdministrationComponentsModule, never, [typeof BudgetComponentsModule, typeof CostCenterComponentsModule, typeof UnitsComponentsModule, typeof UserGroupComponentsModule, typeof UserComponentsModule, typeof PermissionComponentsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AdministrationComponentsModule>;
}

declare const budgetCmsConfig: CmsConfig;
declare function budgetTableConfigFactory(): TableConfig;
declare const budgetTableConfig: TableConfig;
/**
 * @deprecated Use `budgetTableConfig` instead.
 */
declare const newBudgetTableConfig: TableConfig;

declare class BudgetCostCenterListService extends SubListService<Budget> {
    protected tableService: TableService;
    protected budgetService: BudgetService;
    protected tableType: OrganizationTableType;
    protected _domainType: OrganizationTableType;
    constructor(tableService: TableService, budgetService: BudgetService);
    protected load(_pagination: PaginationModel, code: string): Observable<EntitiesModel<CostCenter>>;
    /**
     * As we can't filter with the backend API, we do this client side.
     */
    protected filterSelected({ pagination, sorts, values, }: EntitiesModel<CostCenter>): EntitiesModel<CostCenter>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BudgetCostCenterListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BudgetCostCenterListService>;
}

declare class BudgetFormService extends FormService<Budget> {
    protected datePickerService: DatePickerService;
    constructor(datePickerService: DatePickerService);
    protected build(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BudgetFormService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BudgetFormService>;
}

declare class CurrentBudgetService extends CurrentItemService<Budget> {
    protected routingService: RoutingService;
    protected budgetService: BudgetService;
    constructor(routingService: RoutingService, budgetService: BudgetService);
    protected getDetailsRoute(): string;
    protected getParamKey(): string;
    protected getItem(code: string): Observable<Budget>;
    getError(code: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrentBudgetService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrentBudgetService>;
}

declare class BudgetItemService extends ItemService<Budget> {
    protected currentItemService: CurrentBudgetService;
    protected routingService: RoutingService;
    protected formService: BudgetFormService;
    protected budgetService: BudgetService;
    constructor(currentItemService: CurrentBudgetService, routingService: RoutingService, formService: BudgetFormService, budgetService: BudgetService);
    /**
     * @override
     * Returns the budget for the given code.
     *
     * Loads the budget each time, to ensure accurate data is resolved.
     */
    load(code: string): Observable<Budget>;
    update(code: string, value: Budget): Observable<OrganizationItemStatus<Budget>>;
    protected create(value: Budget): Observable<OrganizationItemStatus<Budget>>;
    /**
     * @override
     * Returns 'budgetDetails'
     */
    protected getDetailsRoute(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<BudgetItemService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BudgetItemService>;
}

/**
 * Service to populate Budget data to `Table` data. Budget
 * data is driven by the table configuration, using the `OrganizationTables.BUDGET`.
 */
declare class BudgetListService extends ListService<Budget> {
    protected tableService: TableService;
    protected budgetService: BudgetService;
    protected tableType: OrganizationTableType;
    constructor(tableService: TableService, budgetService: BudgetService);
    protected load(pagination: PaginationModel): Observable<EntitiesModel<Budget>>;
    /**
     * Populates budget data to a convenient table data model, so that we
     * can skip specific conversion in the view logic where possible.
     */
    protected convertBudgets({ pagination, sorts, values, }: EntitiesModel<Budget>): EntitiesModel<Budget>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BudgetListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BudgetListService>;
}

declare class CostCenterBudgetListService extends SubListService<Budget> {
    protected tableService: TableService;
    protected costCenterService: CostCenterService;
    protected budgetService: BudgetService;
    protected tableType: OrganizationTableType;
    protected _domainType: OrganizationTableType;
    constructor(tableService: TableService, costCenterService: CostCenterService, budgetService: BudgetService);
    protected load(pagination: PaginationModel, code: string): Observable<EntitiesModel<Budget> | undefined>;
    /**
     * @override
     * Assign budget to the cost center.
     */
    assign(costCenterCode: string, budgetCode: string): Observable<OrganizationItemStatus<Budget>>;
    /**
     * @override
     * Unassign the budget from the cost center.
     */
    unassign(costCenterCode: string, budgetCode: string): Observable<OrganizationItemStatus<Budget>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterBudgetListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CostCenterBudgetListService>;
}

declare class CostCenterAssignedBudgetListService extends CostCenterBudgetListService {
    protected tableType: OrganizationTableType;
    protected load(pagination: PaginationModel, code: string): Observable<EntitiesModel<Budget> | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterAssignedBudgetListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CostCenterAssignedBudgetListService>;
}

declare const costCenterCmsConfig: CmsConfig;
declare function costCenterTableConfigFactory(): TableConfig;
declare const costCenterTableConfig: TableConfig;
/**
 * @deprecated Use `costCenterTableConfig` instead.
 */
declare const newCostCenterTableConfig: TableConfig;

declare class CostCenterDetailsCellComponent extends CellComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterDetailsCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CostCenterDetailsCellComponent, "cx-org-cost-center-details-cell", never, {}, {}, never, never, true, never>;
}

declare class CostCenterDetailsCellModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterDetailsCellModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CostCenterDetailsCellModule, never, [typeof i1.CommonModule, typeof i7.PopoverModule, typeof i3.RouterModule, typeof i4.I18nModule, typeof i4.UrlModule, typeof CostCenterDetailsCellComponent], [typeof CostCenterDetailsCellComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CostCenterDetailsCellModule>;
}

declare class CostCenterFormService extends FormService<CostCenter> {
    protected build(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterFormService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CostCenterFormService>;
}

/**
 * The UI model for the cost center, which is a slightly flattened version
 * of the core cost center model.
 */
interface CostCenterModel {
    code?: string;
    name?: string;
    unit?: any;
    currency?: string;
    active?: boolean;
}
/**
 * Service to populate Cost Center data to `Table` data. The cost center
 * data is driven by the table configuration, using the `OrganizationTables.COST_CENTER`.
 */
declare class CostCenterListService extends ListService<CostCenterModel> {
    protected tableService: TableService;
    protected costCenterService: CostCenterService;
    protected tableType: OrganizationTableType;
    private featureToggles;
    constructor(tableService: TableService, costCenterService: CostCenterService);
    /**
     * Enable search functionality for cost center list based on feature toggle.
     */
    isSearchEnabled(): boolean;
    protected load(pagination: PaginationModel): Observable<EntitiesModel<CostCenterModel>>;
    /**
     * Populates the cost center data to a convenient table data model, so that we
     * can skip specific conversion in the view logic where possible.
     */
    protected convertCostCenters({ pagination, sorts, values, }: EntitiesModel<CostCenter>): EntitiesModel<CostCenterModel>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CostCenterListService>;
}

declare class CurrentCostCenterService extends CurrentItemService<CostCenter> {
    protected routingService: RoutingService;
    protected costCenterService: CostCenterService;
    constructor(routingService: RoutingService, costCenterService: CostCenterService);
    protected getParamKey(): string;
    protected getItem(code: string): Observable<CostCenter>;
    getError(code: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrentCostCenterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrentCostCenterService>;
}

declare class PermissionDetailsCellComponent extends CellComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionDetailsCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PermissionDetailsCellComponent, "cx-org-permission-details-cell", never, {}, {}, never, never, true, never>;
}

declare class PermissionDetailsCellModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionDetailsCellModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PermissionDetailsCellModule, never, [typeof i1.CommonModule, typeof i7.PopoverModule, typeof i3.RouterModule, typeof i4.I18nModule, typeof i4.UrlModule, typeof PermissionDetailsCellComponent], [typeof PermissionDetailsCellComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PermissionDetailsCellModule>;
}

declare enum PermissionType {
    ORDER = "B2BOrderThresholdPermission",
    TIME_SPAN = "B2BOrderThresholdTimespanPermission",
    EXCEEDED = "B2BBudgetExceededPermission"
}
declare class PermissionFormService extends FormService<Permission> implements OnDestroy {
    protected subscription: Subscription;
    /**
     * @override
     * Builds a generic sub form for permissions and amends the form
     * based on the for approval permission type.
     */
    protected build(): void;
    /**
     * @override
     * The form is using  `B2BBudgetExceededPermission` by default.
     */
    get defaultValue(): Permission;
    /**
     * Amends the form structure based on the `PermissionType`.
     */
    protected amend(form: UntypedFormGroup, code: PermissionType): void;
    ngOnDestroy(): void;
    protected patchData(item?: Permission): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionFormService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PermissionFormService>;
}

declare const permissionCmsConfig: CmsConfig;
declare function permissionTableConfigFactory(): TableConfig;
declare const permisionTableConfig: TableConfig;
/**
 * @deprecated Use `permisionTableConfig` instead.
 */
declare const newPermissionTableConfig: TableConfig;

declare class CurrentPermissionService extends CurrentItemService<Permission> {
    protected routingService: RoutingService;
    protected permissionService: PermissionService;
    constructor(routingService: RoutingService, permissionService: PermissionService);
    protected getParamKey(): string;
    protected getItem(code: string): Observable<Permission>;
    getError(code: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrentPermissionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrentPermissionService>;
}

declare class PermissionItemService extends ItemService<Permission> {
    protected currentItemService: CurrentPermissionService;
    protected routingService: RoutingService;
    protected formService: PermissionFormService;
    protected permissionService: PermissionService;
    constructor(currentItemService: CurrentPermissionService, routingService: RoutingService, formService: PermissionFormService, permissionService: PermissionService);
    load(code: string): Observable<Permission>;
    update(code: string, value: Permission): Observable<OrganizationItemStatus<Permission>>;
    protected create(value: Permission): Observable<OrganizationItemStatus<Permission>>;
    protected getDetailsRoute(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionItemService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PermissionItemService>;
}

/**
 * The UI model for the permission, which is a slightly flattened version
 * of the permission model.
 */
interface PermissionModel {
    code?: string;
    orderApprovalPermissionType?: {
        name: string;
    };
    threshold?: any;
    periodRange?: any;
    orgUnit?: any;
    currency?: {
        symbol: string;
    };
}
/**
 * Service to populate permission data to `Table` data. The permission
 * data is driven by the table configuration, using the `OrganizationTables.PERMISSION`.
 */
declare class PermissionListService extends ListService<PermissionModel> {
    protected tableService: TableService;
    protected permissionsService: PermissionService;
    protected tableType: OrganizationTableType;
    constructor(tableService: TableService, permissionsService: PermissionService);
    protected load(pagination: PaginationModel): Observable<EntitiesModel<PermissionModel>>;
    /**
     * Populates the permission data to a convenient table data model, so that we
     * can skip specific conversion in the view logic where possible.
     */
    protected convertPermissions({ pagination, sorts, values, }: EntitiesModel<UserGroup>): EntitiesModel<PermissionModel>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PermissionListService>;
}

declare class UnitDetailsCellComponent extends CellComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitDetailsCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitDetailsCellComponent, "cx-org-unit-details-cell", never, {}, {}, never, never, true, never>;
}

declare class UnitDetailsCellModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitDetailsCellModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitDetailsCellModule, never, [typeof i1.CommonModule, typeof i7.PopoverModule, typeof i3.RouterModule, typeof i4.I18nModule, typeof i4.UrlModule, typeof UnitDetailsCellComponent], [typeof UnitDetailsCellComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitDetailsCellModule>;
}

declare class UnitFormService extends FormService<B2BUnit> {
    protected patchData(item?: B2BUnit): void;
    protected build(): void;
    protected toggleParentUnit(item?: B2BUnit): void;
    protected isRootUnit(item: B2BUnit | undefined): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitFormService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitFormService>;
}

declare class UnitAddressListService extends SubListService<Address> {
    protected tableService: TableService;
    protected orgUnitService: OrgUnitService;
    protected tableType: OrganizationTableType;
    protected _domainType: OrganizationTableType;
    constructor(tableService: TableService, orgUnitService: OrgUnitService);
    protected load(_pagination: PaginationModel, code: string): Observable<EntitiesModel<Address> | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitAddressListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitAddressListService>;
}

declare class CurrentUnitAddressService extends CurrentItemService<Address> {
    protected routingService: RoutingService;
    protected unitService: OrgUnitService;
    readonly item$: Observable<Address | undefined>;
    constructor(routingService: RoutingService, unitService: OrgUnitService);
    getDetailsRoute(): string;
    protected getParamKey(): string;
    protected getItem(unitUid: string, addressId: string): Observable<Address | undefined>;
    getError(code: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrentUnitAddressService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrentUnitAddressService>;
}

declare class UnitAddressItemService extends ItemService<Address> {
    protected currentItemService: CurrentUnitAddressService;
    protected routingService: RoutingService;
    protected formService: UnitAddressFormService;
    protected unitService: OrgUnitService;
    constructor(currentItemService: CurrentUnitAddressService, routingService: RoutingService, formService: UnitAddressFormService, unitService: OrgUnitService);
    protected unitRouteParam$: Observable<string>;
    load(unitUid: string, addressId: string): Observable<Address>;
    update(addressCode: string, address: Address): Observable<OrganizationItemStatus<Address>>;
    protected create(value: Address): Observable<OrganizationItemStatus<Address>>;
    protected getDetailsRoute(): string;
    delete(addressId: string, unitUid: string): Observable<OrganizationItemStatus<Address>>;
    launchDetails(item: Address): void;
    protected launchList(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitAddressItemService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitAddressItemService>;
}

declare class UnitApproverListService extends SubListService<B2BUser> {
    protected tableService: TableService;
    protected unitService: OrgUnitService;
    protected userService: B2BUserService;
    protected tableType: OrganizationTableType;
    protected _domainType: OrganizationTableType;
    constructor(tableService: TableService, unitService: OrgUnitService, userService: B2BUserService);
    protected load(pagination: PaginationModel, code: string): Observable<EntitiesModel<B2BUser> | undefined>;
    /**
     * @override
     * Assign budget to the cost center.
     */
    assign(unitId: string, customerId: string): Observable<OrganizationItemStatus<B2BUser>>;
    /**
     * @override
     * Unassign the budget from the cost center.
     */
    unassign(unitId: string, customerId: string): Observable<OrganizationItemStatus<B2BUser>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitApproverListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitApproverListService>;
}

declare class UnitAssignedApproverListService extends UnitApproverListService {
    protected tableType: OrganizationTableType;
    protected load(pagination: PaginationModel, code: string): Observable<EntitiesModel<B2BUser> | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitAssignedApproverListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitAssignedApproverListService>;
}

declare class UnitChildCreateComponent {
    protected unitService: CurrentUnitService;
    unitKey$: Observable<string>;
    constructor(unitService: CurrentUnitService);
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitChildCreateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitChildCreateComponent, "cx-org-unit-child-create", never, {}, {}, never, never, true, never>;
}

declare class UnitChildCreateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitChildCreateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitChildCreateModule, never, [typeof i1.CommonModule, typeof UnitFormModule, typeof UnitChildCreateComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitChildCreateModule>;
}

declare class UnitItemService extends ItemService<B2BUnit> {
    protected currentItemService: CurrentUnitService;
    protected routingService: RoutingService;
    protected formService: UnitFormService;
    protected unitService: OrgUnitService;
    constructor(currentItemService: CurrentUnitService, routingService: RoutingService, formService: UnitFormService, unitService: OrgUnitService);
    /**
     * @override
     * Returns the unit for the given code.
     *
     * Loads the unit each time, to ensure accurate data is resolved.
     */
    load(code: string): Observable<B2BUnit>;
    update(code: string, value: B2BUnit): Observable<OrganizationItemStatus<B2BUnit>>;
    protected create(value: B2BUnit): Observable<OrganizationItemStatus<B2BUnit>>;
    /**
     * @override
     * Returns 'unitDetails'
     */
    protected getDetailsRoute(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitItemService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitItemService>;
}

declare class CurrentUnitChildService extends CurrentUnitService {
    protected getParamKey(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrentUnitChildService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrentUnitChildService>;
}

declare class UnitChildItemService extends UnitItemService {
    protected currentItemService: CurrentUnitChildService;
    protected routingService: RoutingService;
    protected formService: UnitFormService;
    protected unitService: OrgUnitService;
    constructor(currentItemService: CurrentUnitChildService, routingService: RoutingService, formService: UnitFormService, unitService: OrgUnitService);
    save(form: UntypedFormGroup, key?: string): Observable<OrganizationItemStatus<B2BUnit>>;
    /**
     * @override
     * Returns 'unitDetails'
     */
    protected getDetailsRoute(): string;
    protected buildRouteParams(item: B2BUnit): {
        uid: string | undefined;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitChildItemService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitChildItemService>;
}

declare class UnitChildrenService extends SubListService<B2BUnitNode> {
    protected tableService: TableService;
    protected orgUnitService: OrgUnitService;
    protected tableType: OrganizationTableType;
    protected _domainType: OrganizationTableType;
    constructor(tableService: TableService, orgUnitService: OrgUnitService);
    protected load(_pagination: PaginationModel, code: string): Observable<EntitiesModel<B2BUnitNode>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitChildrenService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitChildrenService>;
}

declare class UnitCostCenterCreateComponent {
    protected unitService: CurrentUnitService;
    unitKey$: Observable<string>;
    constructor(unitService: CurrentUnitService);
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitCostCenterCreateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitCostCenterCreateComponent, "cx-org-unit-cost-center-create", never, {}, {}, never, never, true, never>;
}

declare class UnitCostCenterCreateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitCostCenterCreateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitCostCenterCreateModule, never, [typeof i1.CommonModule, typeof CostCenterFormModule, typeof UnitCostCenterCreateComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitCostCenterCreateModule>;
}

declare class CostCenterItemService extends ItemService<CostCenter> {
    protected currentItemService: CurrentCostCenterService;
    protected routingService: RoutingService;
    protected formService: CostCenterFormService;
    protected costCenterService: CostCenterService;
    constructor(currentItemService: CurrentCostCenterService, routingService: RoutingService, formService: CostCenterFormService, costCenterService: CostCenterService);
    load(code: string): Observable<CostCenter>;
    update(code: string, value: CostCenter): Observable<OrganizationItemStatus<CostCenter>>;
    protected create(value: CostCenter): Observable<OrganizationItemStatus<CostCenter>>;
    protected getDetailsRoute(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CostCenterItemService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CostCenterItemService>;
}

declare class UnitCostCenterItemService extends CostCenterItemService {
    save(form: UntypedFormGroup, key?: string): Observable<OrganizationItemStatus<CostCenter>>;
    /**
     * @override
     * Returns 'orgUnitCostCenters'
     */
    protected getDetailsRoute(): string;
    protected buildRouteParams(item: CostCenter): {
        uid: string | undefined;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitCostCenterItemService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitCostCenterItemService>;
}

declare class UnitCostCenterListService extends SubListService<B2BUser> {
    protected tableService: TableService;
    protected unitService: OrgUnitService;
    protected tableType: OrganizationTableType;
    protected _domainType: OrganizationTableType;
    constructor(tableService: TableService, unitService: OrgUnitService);
    protected load(_pagination: PaginationModel, code: string): Observable<EntitiesModel<B2BUser>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitCostCenterListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitCostCenterListService>;
}

declare class UnitUserCreateComponent {
    protected unitService: CurrentUnitService;
    unitKey$: Observable<string>;
    constructor(unitService: CurrentUnitService);
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitUserCreateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnitUserCreateComponent, "cx-org-unit-user-create", never, {}, {}, never, never, true, never>;
}

declare class UnitUserCreateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitUserCreateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UnitUserCreateModule, never, [typeof i1.CommonModule, typeof UserFormModule, typeof UnitUserCreateComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UnitUserCreateModule>;
}

declare class CurrentUnitUserService extends CurrentItemService<B2BUser> {
    protected routingService: RoutingService;
    protected b2bUserService: B2BUserService;
    constructor(routingService: RoutingService, b2bUserService: B2BUserService);
    getDetailsRoute(): string;
    protected getParamKey(): string;
    protected getItem(customerId: string): Observable<B2BUser>;
    getError(code: string): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrentUnitUserService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CurrentUnitUserService>;
}

declare class UnitUserRolesItemService extends ItemService<B2BUser> {
    protected currentItemService: CurrentUnitUserService;
    protected routingService: RoutingService;
    protected formService: UnitUserRolesFormService;
    protected unitService: OrgUnitService;
    protected b2bUserService: B2BUserService;
    constructor(currentItemService: CurrentUnitUserService, routingService: RoutingService, formService: UnitUserRolesFormService, unitService: OrgUnitService, b2bUserService: B2BUserService);
    save(form: UntypedFormGroup, key?: string): Observable<OrganizationItemStatus<B2BUser>>;
    load(unitUid: string): Observable<B2BUser>;
    update(customerId: string, _user: B2BUser): Observable<OrganizationItemStatus<B2BUser>>;
    protected create(_customer: B2BUser): Observable<OrganizationItemStatus<B2BUser>>;
    protected getDetailsRoute(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitUserRolesItemService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitUserRolesItemService>;
}

declare class UnitUserListService extends SubListService<B2BUser> {
    protected tableService: TableService;
    protected unitService: OrgUnitService;
    protected tableType: OrganizationTableType;
    protected _domainType: OrganizationTableType;
    constructor(tableService: TableService, unitService: OrgUnitService);
    protected load(pagination: PaginationModel, code: string): Observable<EntitiesModel<B2BUser> | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitUserListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitUserListService>;
}

/**
 * Service to populate Unit data to `Table` data. Unit
 * data is driven by the table configuration, using the `OrganizationTables.UNIT`.
 */
declare class UnitListService extends ListService<B2BUnitTreeNode> {
    protected tableService: TableService;
    protected unitService: OrgUnitService;
    protected unitItemService: UnitItemService;
    protected unitTreeService: UnitTreeService;
    protected tableType: OrganizationTableType;
    private featureToggles;
    constructor(tableService: TableService, unitService: OrgUnitService, unitItemService: UnitItemService, unitTreeService: UnitTreeService);
    isSearchEnabled(): boolean;
    getSearchPlaceholderKey(): string;
    protected load(pagination: PaginationModel): Observable<EntitiesModel<B2BUnitTreeNode> | undefined>;
    /**
     * Recursively filters the tree based on search query.
     *
     * Rules:
     * - If a node matches -> keep node + ALL children (as-is, collapsed by default)
     * - If only a descendant matches -> keep all ancestors to root + only matching branch.
     *   Ancestors are added to forceExpandIds so they appear expanded in the UI.
     * - Non-matching nodes with no matching descendants are removed.
     *
     * @param forceExpandIds Collects IDs of ancestor nodes that should be
     *   force-expanded in convertListItem(). These are nodes kept only because
     *   their descendants match (not because they match themselves).
     */
    protected filterTree(node: B2BUnitNode | undefined, query: string, forceExpandIds: Set<string>): B2BUnitNode | undefined;
    protected convertListItem(unit: B2BUnitNode | undefined, depthLevel?: number, pagination?: {
        totalResults: number;
    }, forceExpandIds?: Set<string>): EntitiesModel<B2BUnitTreeNode> | undefined;
    key(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnitListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnitListService>;
}

declare const unitsCmsConfig: CmsConfig;
declare function unitsTableConfigFactory(): TableConfig;
declare const unitsTableConfig: TableConfig;
/**
 * @deprecated Use `unitsTableConfig` instead.
 */
declare const newUnitsTableConfig: TableConfig;

declare class UserGroupDetailsCellComponent extends CellComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupDetailsCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserGroupDetailsCellComponent, "cx-org-user-group-details-cell", never, {}, {}, never, never, true, never>;
}

declare class UserGroupDetailsCellModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupDetailsCellModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserGroupDetailsCellModule, never, [typeof i1.CommonModule, typeof i7.PopoverModule, typeof i3.RouterModule, typeof i4.I18nModule, typeof i4.UrlModule, typeof UserGroupDetailsCellComponent], [typeof UserGroupDetailsCellComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserGroupDetailsCellModule>;
}

declare class UserGroupFormService extends FormService<UserGroup> {
    protected build(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupFormService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserGroupFormService>;
}

declare class UserGroupPermissionListService extends SubListService<Permission> {
    protected tableService: TableService;
    protected userGroupService: UserGroupService;
    protected permissionService: PermissionService;
    protected tableType: OrganizationTableType;
    protected _domainType: OrganizationTableType;
    constructor(tableService: TableService, userGroupService: UserGroupService, permissionService: PermissionService);
    /**
     *
     * @override
     * Loads all b2b users.
     *
     * @param code The user group code.
     */
    protected load(pagination: PaginationModel, code: string): Observable<EntitiesModel<Permission> | undefined>;
    /**
     * @override
     * Assign user to the user group.
     */
    assign(userGroupCode: string, permissionCode: string): Observable<OrganizationItemStatus<UserGroup>>;
    /**
     * @override
     * Unassigns the user from the user group.
     */
    unassign(userGroupCode: string, permissionCode: string): Observable<OrganizationItemStatus<UserGroup>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupPermissionListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserGroupPermissionListService>;
}

declare class UserGroupAssignedPermissionsListService extends UserGroupPermissionListService {
    protected tableType: OrganizationTableType;
    /**
     * @override
     * Load all b2b users assigned to the given user group
     */
    protected load(pagination: PaginationModel, code: string): Observable<EntitiesModel<Permission> | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupAssignedPermissionsListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserGroupAssignedPermissionsListService>;
}

declare class UserGroupItemService extends ItemService<UserGroup> {
    protected currentItemService: CurrentUserGroupService;
    protected routingService: RoutingService;
    protected formService: UserGroupFormService;
    protected userGroupService: UserGroupService;
    constructor(currentItemService: CurrentUserGroupService, routingService: RoutingService, formService: UserGroupFormService, userGroupService: UserGroupService);
    load(code: string): Observable<UserGroup>;
    update(code: string, value: UserGroup): Observable<OrganizationItemStatus<UserGroup>>;
    delete(code: string): Observable<OrganizationItemStatus<UserGroup>>;
    protected create(value: UserGroup): Observable<OrganizationItemStatus<UserGroup>>;
    protected getDetailsRoute(): string;
    protected launchList(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupItemService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserGroupItemService>;
}

/**
 * The UI model for the cost center, which is a slightly flattened version
 * of the core cost center model.
 */
interface UserGroupModel {
    uid?: string;
    name?: string;
    orgUnit?: any;
}
/**
 * Service to populate Cost Center data to `Table` data. The cost center
 * data is driven by the table configuration, using the `OrganizationTables.COST_CENTER`.
 */
declare class UserGroupListService extends ListService<UserGroupModel> {
    protected tableService: TableService;
    protected userGroupService: UserGroupService;
    protected tableType: OrganizationTableType;
    constructor(tableService: TableService, userGroupService: UserGroupService);
    key(): string;
    protected load(pagination: PaginationModel): Observable<EntitiesModel<UserGroupModel>>;
    /**
     * Populates the cost center data to a convenient table data model, so that we
     * can skip specific conversion in the view logic where possible.
     */
    protected convertUserGroups({ pagination, sorts, values, }: EntitiesModel<UserGroup>): EntitiesModel<UserGroupModel>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserGroupListService>;
}

declare const userGroupCmsConfig: CmsConfig;
declare function userGroupTableConfigFactory(): TableConfig;
declare const userGroupTableConfig: TableConfig;
/**
 * @deprecated Use `userGroupTableConfig` instead.
 */
declare const newUserGroupTableConfig: TableConfig;

declare class UserGroupAssignedUserListService extends UserGroupUserListService {
    protected tableType: OrganizationTableType;
    /**
     * @override
     * Load all b2b users assigned to the given user group
     */
    protected load(pagination: PaginationModel, code: string): Observable<EntitiesModel<B2BUser> | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserGroupAssignedUserListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserGroupAssignedUserListService>;
}

declare class UserApproverListService extends SubListService<B2BUser> {
    protected tableService: TableService;
    protected userService: B2BUserService;
    protected tableType: OrganizationTableType;
    protected _domainType: OrganizationTableType;
    constructor(tableService: TableService, userService: B2BUserService);
    protected load(pagination: PaginationModel, code: string): Observable<EntitiesModel<B2BUser> | undefined>;
    /**
     * @override
     * Assign approver to the user.
     */
    assign(userCode: string, approverId: string): Observable<OrganizationItemStatus<B2BUser>>;
    /**
     * @override
     * Unassign the approver from the user.
     */
    unassign(userCode: string, approverId: string): Observable<OrganizationItemStatus<B2BUser>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserApproverListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserApproverListService>;
}

declare class UserAssignedApproverListService extends UserApproverListService {
    protected tableType: OrganizationTableType;
    protected load(pagination: PaginationModel, code: string): Observable<EntitiesModel<B2BUser> | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAssignedApproverListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserAssignedApproverListService>;
}

declare class UserDetailsCellComponent extends CellComponent {
    protected b2bUserService: B2BUserService;
    protected outlet: OutletContextData<TableDataOutletContext>;
    b2bUserModel: B2BUser;
    availableRoles: string[];
    availableRights: string[];
    constructor(b2bUserService: B2BUserService, outlet: OutletContextData<TableDataOutletContext>);
    hasRight(model: B2BUser): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserDetailsCellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserDetailsCellComponent, "cx-org-user-details-cell", never, {}, {}, never, never, true, never>;
}

declare class UserDetailsCellModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserDetailsCellModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserDetailsCellModule, never, [typeof i1.CommonModule, typeof i7.PopoverModule, typeof i3.RouterModule, typeof i4.I18nModule, typeof i4.UrlModule, typeof UserDetailsCellComponent], [typeof UserDetailsCellComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserDetailsCellModule>;
}

declare class UserPermissionListService extends SubListService<Permission> {
    protected tableService: TableService;
    protected userService: B2BUserService;
    protected permissionService: PermissionService;
    protected tableType: OrganizationTableType;
    protected _domainType: OrganizationTableType;
    constructor(tableService: TableService, userService: B2BUserService, permissionService: PermissionService);
    protected load(pagination: PaginationModel, code: string): Observable<EntitiesModel<B2BUser> | undefined>;
    /**
     * @override
     * Assign permission to the user.
     */
    assign(userCode: string, code: string): Observable<OrganizationItemStatus<Permission>>;
    /**
     * @override
     * Unassign the permission from the user.
     */
    unassign(userCode: string, code: string): Observable<OrganizationItemStatus<Permission>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserPermissionListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserPermissionListService>;
}

declare class UserAssignedPermissionListService extends UserPermissionListService {
    protected tableType: OrganizationTableType;
    protected load(pagination: PaginationModel, code: string): Observable<EntitiesModel<B2BUser> | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAssignedPermissionListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserAssignedPermissionListService>;
}

/**
 * The UI model for the cost center, which is a slightly flattened version
 * of the core cost center model.
 */
interface UserModel {
    uid?: string;
    name?: string;
    orgUnit?: any;
    roles?: string[];
}
/**
 * Service to populate User data to `Table` data. The user
 * data is driven by the table configuration, using the `OrganizationTables.USER`.
 */
declare class UserListService extends ListService<UserModel> {
    protected tableService: TableService;
    protected userService: B2BUserService;
    protected tableType: OrganizationTableType;
    private featureToggles;
    constructor(tableService: TableService, userService: B2BUserService);
    key(): string;
    protected load(pagination: PaginationModel): Observable<EntitiesModel<UserModel>>;
    /**
     * Populates the cost center data to a convenient table data model, so that we
     * can skip specific conversion in the view logic where possible.
     */
    protected convertUsers({ pagination, sorts, values, }: EntitiesModel<B2BUser>): EntitiesModel<UserModel>;
    /**
     * Enable search functionality for user list based on feature toggle.
     */
    isSearchEnabled(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserListService>;
}

declare class UserUserGroupListService extends SubListService<UserGroup> {
    protected tableService: TableService;
    protected userService: B2BUserService;
    protected userGroupService: UserGroupService;
    protected tableType: OrganizationTableType;
    protected _domainType: OrganizationTableType;
    constructor(tableService: TableService, userService: B2BUserService, userGroupService: UserGroupService);
    protected load(pagination: PaginationModel, code: string): Observable<EntitiesModel<UserGroup> | undefined>;
    /**
     * @override
     * Assign user group to the user.
     */
    assign(userCode: string, userGroupCode: string): Observable<OrganizationItemStatus<UserGroup>>;
    /**
     * @override
     * Unassign the user group from the user.
     */
    unassign(userCode: string, userGroupCode: string): Observable<OrganizationItemStatus<UserGroup>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserUserGroupListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserUserGroupListService>;
}

declare class UserAssignedUserGroupListService extends UserUserGroupListService {
    protected tableType: OrganizationTableType;
    protected load(pagination: PaginationModel, code: string): Observable<EntitiesModel<UserGroup> | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAssignedUserGroupListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserAssignedUserGroupListService>;
}

declare const userCmsConfig: CmsConfig;
declare function userTableConfigFactory(): TableConfig;
declare const userTableConfig: TableConfig;
/**
 * @deprecated Use `userTableConfig` instead.
 */
declare const newUserTableConfig: TableConfig;

export { ActiveLinkCellComponent, AdministrationComponentsModule, AmountCellComponent, AssignCellComponent, BaseMessageComponent, BudgetComponentsModule, BudgetCostCenterListComponent, BudgetCostCenterListModule, BudgetCostCenterListService, BudgetDetailsCellComponent, BudgetDetailsCellModule, BudgetDetailsComponent, BudgetDetailsModule, BudgetFormComponent, BudgetFormModule, BudgetFormService, BudgetItemService, BudgetListService, CardComponent, CardModule, CellComponent, CellModule, ConfirmationMessageComponent, ConfirmationMessageModule, CostCenterAssignedBudgetListComponent, CostCenterAssignedBudgetListService, CostCenterBudgetListComponent, CostCenterBudgetListModule, CostCenterBudgetListService, CostCenterComponentsModule, CostCenterDetailsCellComponent, CostCenterDetailsCellModule, CostCenterDetailsComponent, CostCenterDetailsModule, CostCenterFormComponent, CostCenterFormModule, CostCenterFormService, CostCenterListService, CreateButtonType, CurrentBudgetService, CurrentCostCenterService, CurrentItemService, CurrentPermissionService, CurrentUnitAddressService, CurrentUnitChildService, CurrentUnitService, CurrentUnitUserService, CurrentUserGroupService, CurrentUserService, DateRangeCellComponent, DeleteItemComponent, DeleteItemModule, DisableInfoComponent, DisableInfoModule, DisableInfoService, FormComponent, FormModule, FormService, ItemActiveDirective, ItemExistsDirective, ItemService, LimitCellComponent, LinkCellComponent, ListComponent, ListModule, ListService, MessageComponent, MessageData, MessageModule, MessageRenderService, MessageService, NotificationMessageComponent, NotificationMessageModule, OrganizationTableType, PermissionComponentsModule, PermissionDetailsCellComponent, PermissionDetailsCellModule, PermissionDetailsComponent, PermissionDetailsModule, PermissionFormComponent, PermissionFormModule, PermissionFormService, PermissionItemService, PermissionListService, PermissionType, RolesCellComponent, SharedOrganizationModule, StatusCellComponent, SubListComponent, SubListModule, SubListService, ToggleLinkCellComponent, ToggleStatusComponent, ToggleStatusModule, UnitAddressDetailsComponent, UnitAddressDetailsModule, UnitAddressFormComponent, UnitAddressFormModule, UnitAddressFormService, UnitAddressItemService, UnitAddressListComponent, UnitAddressListModule, UnitAddressListService, UnitAddressModule, UnitApproverListComponent, UnitApproverListModule, UnitApproverListService, UnitAssignedApproverListComponent, UnitAssignedApproverListService, UnitCellComponent, UnitChildCreateComponent, UnitChildCreateModule, UnitChildItemService, UnitChildrenComponent, UnitChildrenModule, UnitChildrenService, UnitCostCenterCreateComponent, UnitCostCenterCreateModule, UnitCostCenterItemService, UnitCostCenterListComponent, UnitCostCenterListModule, UnitCostCenterListService, UnitDetailsCellComponent, UnitDetailsCellModule, UnitDetailsComponent, UnitDetailsModule, UnitFormComponent, UnitFormModule, UnitFormService, UnitItemService, UnitListComponent, UnitListModule, UnitListService, UnitTreeService, UnitUserCreateComponent, UnitUserCreateModule, UnitUserListComponent, UnitUserListModule, UnitUserListService, UnitUserRolesCellComponent, UnitUserRolesFormComponent, UnitUserRolesFormService, UnitUserRolesItemService, UnitUserRolesModule, UnitUsersModule, UnitsComponentsModule, UserApproverListComponent, UserApproverListModule, UserApproverListService, UserAssignedApproverListComponent, UserAssignedApproverListService, UserAssignedPermissionListComponent, UserAssignedPermissionListService, UserAssignedUserGroupListComponent, UserAssignedUserGroupListService, UserChangePasswordFormComponent, UserChangePasswordFormModule, UserChangePasswordFormService, UserComponentsModule, UserDetailsCellComponent, UserDetailsCellModule, UserDetailsComponent, UserDetailsModule, UserFormComponent, UserFormModule, UserFormService, UserGroupAssignedPermissionListComponent, UserGroupAssignedPermissionsListService, UserGroupAssignedUserListComponent, UserGroupAssignedUserListService, UserGroupComponentsModule, UserGroupDetailsCellComponent, UserGroupDetailsCellModule, UserGroupDetailsComponent, UserGroupDetailsModule, UserGroupFormComponent, UserGroupFormModule, UserGroupFormService, UserGroupItemService, UserGroupListService, UserGroupPermissionListComponent, UserGroupPermissionListService, UserGroupPermissionModule, UserGroupUserListComponent, UserGroupUserListService, UserGroupUserModule, UserItemService, UserListService, UserPermissionListComponent, UserPermissionListModule, UserPermissionListService, UserUserGroupListComponent, UserUserGroupListService, UserUserGroupsModule, budgetCmsConfig, budgetTableConfig, budgetTableConfigFactory, costCenterCmsConfig, costCenterTableConfig, costCenterTableConfigFactory, newBudgetTableConfig, newCostCenterTableConfig, newPermissionTableConfig, newUnitsTableConfig, newUserGroupTableConfig, newUserTableConfig, permisionTableConfig, permissionCmsConfig, permissionTableConfigFactory, unitsCmsConfig, unitsTableConfig, unitsTableConfigFactory, userCmsConfig, userGroupCmsConfig, userGroupTableConfig, userGroupTableConfigFactory, userTableConfig, userTableConfigFactory };
export type { BaseItem, ConfirmationMessageData, CostCenterModel, MessageEventData, PermissionModel, SearchablePaginationModel, UserGroupModel, UserModel };
