import { Currency, Address, Language, EventService, UserIdService, CmsConfig } from '@spartacus/core';
import * as i0 from '@angular/core';
import { OnDestroy } from '@angular/core';
import { User, UserAccountConfig } from '@spartacus/user/account/root';
import { Observable, Subscription } from 'rxjs';

declare module '@spartacus/user/account/root' {
    interface User {
        currency?: Currency;
        customerId?: string;
        deactivationDate?: Date;
        defaultAddress?: Address;
        defaultPointOfServiceName?: string;
        displayUid?: string;
        firstName?: string;
        language?: Language;
        lastName?: string;
        name?: string;
        title?: string;
        titleCode?: string;
        uid?: string;
        roles?: string[];
    }
}
interface Title {
    code?: string;
    name?: string;
}
interface UserSignUp {
    firstName?: string;
    lastName?: string;
    password?: string;
    titleCode?: string;
    uid?: string;
    verificationTokenId?: string;
    verificationTokenCode?: string;
}

declare abstract class UserProfileFacade {
    abstract get(): Observable<User | undefined>;
    /**
     * Updates the user's details.
     *
     * @param details User details to be updated.
     */
    abstract update(details: User): Observable<unknown>;
    /**
     * Closes the user account.
     */
    abstract close(): Observable<unknown>;
    /**
     * Returns titles that can be used for the user profiles.
     */
    abstract getTitles(): Observable<Title[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserProfileFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserProfileFacade>;
}

declare class UserCurrencyPreferenceSaverService implements OnDestroy {
    protected eventService: EventService;
    protected userProfileFacade: UserProfileFacade;
    protected userIdService: UserIdService;
    protected userAccountConfig: UserAccountConfig;
    protected subscription: Subscription;
    constructor();
    protected onCurrencyChange(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserCurrencyPreferenceSaverService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserCurrencyPreferenceSaverService>;
}

declare function defaultUserProfileComponentsConfig(): CmsConfig;
declare class UserProfileRootModule {
    protected _userCurrencyPreferenceSaverService: UserCurrencyPreferenceSaverService;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserProfileRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserProfileRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserProfileRootModule>;
}

declare const USER_PROFILE_FEATURE = "userProfile";
declare const USER_PROFILE_CORE_FEATURE = "userProfileCore";

declare abstract class UserEmailFacade {
    /**
     * Updates the user's email.
     *
     * @param password to users password to confirm the users
     * @param newUid the new proposed email address.
     */
    abstract update(password: string, newUid: string): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserEmailFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserEmailFacade>;
}

declare abstract class UserPasswordFacade {
    /**
     * Updates the password for the user
     *
     * The method returns an observable with `LoaderState` information, including the
     * actual user data.
     *
     * @param oldPassword the current password that will be changed
     * @param newPassword the new password
     */
    abstract update(oldPassword: string, newPassword: string): Observable<unknown>;
    /**
     * Reset new password. Part of the forgot password flow.
     *
     * @param token
     * @param password
     */
    abstract reset(token: string, password: string): Observable<unknown>;
    abstract requestForgotPasswordEmail(email: string): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserPasswordFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserPasswordFacade>;
}

declare abstract class UserRegisterFacade {
    /**
     * Register a new user.
     *
     * @param submitFormData as UserRegisterFormData
     */
    abstract register(user: UserSignUp): Observable<User>;
    /**
     * Register a new user from guest.
     *
     * @param guid
     * @param password
     */
    abstract registerGuest(guid: string, password: string): Observable<User>;
    /**
     * Returns titles that can be used for the user profiles.
     */
    abstract getTitles(): Observable<Title[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserRegisterFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserRegisterFacade>;
}

declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        CLOSE_ACCOUNT = "CLOSE_ACCOUNT"
    }
}

export { USER_PROFILE_CORE_FEATURE, USER_PROFILE_FEATURE, UserCurrencyPreferenceSaverService, UserEmailFacade, UserPasswordFacade, UserProfileFacade, UserProfileRootModule, UserRegisterFacade, defaultUserProfileComponentsConfig };
export type { Title, UserSignUp };
