import * as i0 from '@angular/core';
import { ViewContainerRef, ElementRef, OnInit, OnDestroy, InjectionToken, ChangeDetectorRef, EventEmitter } from '@angular/core';
import * as i1 from '@angular/common';
import * as i5 from '@angular/router';
import * as i4 from '@spartacus/core';
import { RoutingService, AuthService, GlobalMessageService, TranslationService, AuthConfigService, User, Title, ConsentTemplate, AnonymousConsentsService, AnonymousConsentsConfig, AnonymousConsent, AuthRedirectService, PageMetaService, GlobalMessageType, HttpErrorModel, UserAddressService, LanguageService, HierarchicalAddressConfig, Country, Region, City, CityDistrict, Address, AddressValidation, ClientAuthenticationTokenService } from '@spartacus/core';
import * as i3 from '@spartacus/storefront';
import { LaunchDialogService, ICON_TYPE, FocusConfig, CustomFormValidators, FocusFirstInvalidFieldDirective, Card } from '@spartacus/storefront';
import { UserProfileFacade, UserPasswordFacade, UserRegisterFacade, UserSignUp, Title as Title$1, UserEmailFacade } from '@spartacus/user/profile/root';
import * as rxjs from 'rxjs';
import { Observable, BehaviorSubject, Subject, Subscription } from 'rxjs';
import * as i2 from '@angular/forms';
import { UntypedFormGroup, UntypedFormBuilder, UntypedFormArray, ValidatorFn } from '@angular/forms';
import * as i6 from '@ng-select/ng-select';
import { User as User$1, VerificationTokenFacade, VerificationTokenCreation, VerificationToken } from '@spartacus/user/account/root';

declare class CloseAccountComponent {
    protected launchDialogService: LaunchDialogService;
    protected vcr: ViewContainerRef;
    element: ElementRef;
    protected routingService: RoutingService | null;
    constructor(launchDialogService: LaunchDialogService, vcr: ViewContainerRef);
    openModal(): void;
    navigateTo(cxRoute: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CloseAccountComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CloseAccountComponent, "cx-close-account", never, {}, {}, never, never, true, never>;
}

declare class CloseAccountModalComponent implements OnInit {
    protected authService: AuthService;
    protected globalMessageService: GlobalMessageService;
    protected routingService: RoutingService;
    protected translationService: TranslationService;
    protected userProfile: UserProfileFacade;
    protected launchDialogService: LaunchDialogService;
    protected el: ElementRef;
    iconTypes: typeof ICON_TYPE;
    focusConfig: FocusConfig;
    isLoggedIn$: Observable<boolean>;
    protected loading$: BehaviorSubject<boolean>;
    handleClick(event: UIEvent): void;
    constructor(authService: AuthService, globalMessageService: GlobalMessageService, routingService: RoutingService, translationService: TranslationService, userProfile: UserProfileFacade, launchDialogService: LaunchDialogService, el: ElementRef);
    get isLoading$(): Observable<boolean>;
    ngOnInit(): void;
    onSuccess(): void;
    onError(): void;
    dismissModal(reason?: any): void;
    closeAccount(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CloseAccountModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CloseAccountModalComponent, "cx-close-account-modal", never, {}, {}, never, never, true, never>;
}

declare class CloseAccountModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CloseAccountModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CloseAccountModule, never, [typeof i1.CommonModule, typeof i5.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i3.IconModule, typeof i3.SpinnerModule, typeof i3.KeyboardFocusModule, typeof i3.BtnLikeLinkModule, typeof CloseAccountComponent, typeof CloseAccountModalComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CloseAccountModule>;
}

declare class ForgotPasswordComponentService {
    protected userPasswordService: UserPasswordFacade;
    protected routingService: RoutingService;
    protected authConfigService: AuthConfigService;
    protected globalMessage: GlobalMessageService;
    constructor(userPasswordService: UserPasswordFacade, routingService: RoutingService, authConfigService: AuthConfigService, globalMessage: GlobalMessageService);
    protected busy$: BehaviorSubject<boolean>;
    isUpdating$: rxjs.Observable<boolean>;
    form: UntypedFormGroup;
    /**
     * Sends an email to the user to reset the password.
     *
     * When the `ResourceOwnerPasswordFlow` is used, the user is routed
     * to the login page.
     */
    requestEmail(): void;
    protected onSuccess(): void;
    protected onError(_error: Error): void;
    /**
     * Redirects the user back to the login page.
     *
     * This only happens in case of the `ResourceOwnerPasswordFlow` OAuth flow  or `AuthorizationCode`  with custom login page enabled.
     */
    protected redirect(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ForgotPasswordComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ForgotPasswordComponentService>;
}

declare class ForgotPasswordComponent {
    protected service: ForgotPasswordComponentService;
    protected routingService: RoutingService | null;
    constructor(service: ForgotPasswordComponentService);
    form: UntypedFormGroup;
    isUpdating$: Observable<boolean>;
    onSubmit(): void;
    navigateTo(cxRoute: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ForgotPasswordComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ForgotPasswordComponent, "cx-forgot-password", never, {}, {}, never, never, true, never>;
}

declare class ForgotPasswordModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ForgotPasswordModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ForgotPasswordModule, never, [typeof i1.CommonModule, typeof i2.ReactiveFormsModule, typeof i5.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i3.FormErrorsModule, typeof i3.SpinnerModule, typeof i4.FeaturesConfigModule, typeof i3.BtnLikeLinkModule, typeof i3.FormRequiredAsterisksComponent, typeof i3.FormRequiredLegendComponent, typeof ForgotPasswordComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ForgotPasswordModule>;
}

declare class RegisterComponentService {
    protected userRegisterFacade: UserRegisterFacade;
    protected globalMessageService: GlobalMessageService;
    protected fb?: UntypedFormBuilder | undefined;
    constructor(userRegisterFacade: UserRegisterFacade, globalMessageService: GlobalMessageService, fb?: UntypedFormBuilder | undefined);
    /**
     * Register a new user.
     *
     * @param user as UserSignUp
     */
    register(user: UserSignUp): Observable<User>;
    /**
     * Returns titles that can be used for the user profiles.
     */
    getTitles(): Observable<Title[]>;
    /**
     * Show the message after successful registration.
     */
    postRegisterMessage(): void;
    /**
     * Get if any additional consents needs to be provided during registration
     * In core feature, no additional consents are necessary during registration.
     * In integration scenarios, eg: cdc, this method will be overridden to return
     * necessary cdc consents
     */
    getAdditionalConsents(): {
        template: ConsentTemplate;
        required: boolean;
    }[];
    /**
     * Generate form control if any additional consents that needs to be provided during registration
     * In core feature, no additional consents are necessary during registration.
     * In integration scenarios, eg: cdc, this method will be overridden to return
     * form controls for necessary cdc consents
     */
    generateAdditionalConsentsFormControl(): UntypedFormArray | undefined;
    collectDataFromRegisterForm(formData: any): UserSignUp;
    static ɵfac: i0.ɵɵFactoryDeclaration<RegisterComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RegisterComponentService>;
}

declare class RegisterComponent implements OnInit, OnDestroy {
    protected globalMessageService: GlobalMessageService;
    protected fb: UntypedFormBuilder;
    protected router: RoutingService;
    protected anonymousConsentsService: AnonymousConsentsService;
    protected anonymousConsentsConfig: AnonymousConsentsConfig;
    protected authConfigService: AuthConfigService;
    protected registerComponentService: RegisterComponentService;
    private featureToggles;
    protected passwordValidators: (typeof CustomFormValidators.minOneDigitValidator)[];
    titles$: Observable<Title$1[]>;
    isLoading$: BehaviorSubject<boolean>;
    private subscription;
    anonymousConsent$: Observable<{
        consent: AnonymousConsent | undefined;
        template: string;
    }>;
    registerForm: UntypedFormGroup;
    additionalRegistrationConsents: {
        template: ConsentTemplate;
        required: boolean;
    }[];
    get additionalConsents(): UntypedFormArray;
    updateAdditionalConsents(event: MouseEvent, index: number): void;
    constructor(globalMessageService: GlobalMessageService, fb: UntypedFormBuilder, router: RoutingService, anonymousConsentsService: AnonymousConsentsService, anonymousConsentsConfig: AnonymousConsentsConfig, authConfigService: AuthConfigService, registerComponentService: RegisterComponentService);
    ngOnInit(): void;
    submitForm(): void;
    registerUser(): void;
    titleSelected(title: Title$1): void;
    collectDataFromRegisterForm(formData: any): UserSignUp;
    isConsentGiven(consent: AnonymousConsent | undefined): boolean;
    private isConsentRequired;
    protected onRegisterUserSuccess(): void;
    toggleAnonymousConsent(): void;
    /**
     * Triggered via CaptchaComponent when a user confirms captcha
     */
    captchaConfirmed(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RegisterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RegisterComponent, "cx-register", never, {}, {}, never, never, true, never>;
}

declare class RegisterComponentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RegisterComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RegisterComponentModule, never, [typeof i3.CaptchaModule, typeof i1.CommonModule, typeof i2.ReactiveFormsModule, typeof i5.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i3.SpinnerModule, typeof i3.FormErrorsModule, typeof i3.FormRequiredAsterisksComponent, typeof i3.FormRequiredLegendComponent, typeof i3.NgSelectA11yModule, typeof i6.NgSelectModule, typeof i3.PasswordVisibilityToggleModule, typeof i4.FeaturesConfigModule, typeof RegisterComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RegisterComponentModule>;
}

declare class ResetPasswordComponentService {
    protected userPasswordService: UserPasswordFacade;
    protected routingService: RoutingService;
    protected globalMessage: GlobalMessageService;
    private featureToggles;
    protected passwordValidators: (typeof CustomFormValidators.minOneDigitValidator)[];
    constructor(userPasswordService: UserPasswordFacade, routingService: RoutingService, globalMessage: GlobalMessageService);
    protected busy$: BehaviorSubject<boolean>;
    isUpdating$: Observable<boolean>;
    resetToken$: Observable<string>;
    form: UntypedFormGroup;
    /**
     * Resets the password by the given token.
     *
     * The token has been provided during the request password flow.
     * The token is not validated on the client.
     */
    resetPassword(token: string): void;
    protected onSuccess(): void;
    protected onError(error: unknown): void;
    /**
     * Redirects the user to the login page.
     */
    protected redirect(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ResetPasswordComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ResetPasswordComponentService>;
}

declare class ResetPasswordComponent {
    protected service: ResetPasswordComponentService;
    form: UntypedFormGroup;
    isUpdating$: Observable<boolean>;
    token$: Observable<string>;
    constructor(service: ResetPasswordComponentService);
    onSubmit(token: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ResetPasswordComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ResetPasswordComponent, "cx-reset-password", never, {}, {}, never, never, true, never>;
}

declare class ResetPasswordModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ResetPasswordModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ResetPasswordModule, never, [typeof i1.CommonModule, typeof i2.FormsModule, typeof i2.ReactiveFormsModule, typeof i5.RouterModule, typeof i4.I18nModule, typeof i3.FormErrorsModule, typeof i3.SpinnerModule, typeof i3.PasswordVisibilityToggleModule, typeof i4.FeaturesConfigModule, typeof i3.FormRequiredAsterisksComponent, typeof i3.FormRequiredLegendComponent, typeof ResetPasswordComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ResetPasswordModule>;
}

declare class UpdateEmailComponentService {
    protected userEmail: UserEmailFacade;
    protected routingService: RoutingService;
    protected globalMessageService: GlobalMessageService;
    protected authService: AuthService;
    protected authRedirectService: AuthRedirectService;
    constructor(userEmail: UserEmailFacade, routingService: RoutingService, globalMessageService: GlobalMessageService, authService: AuthService, authRedirectService: AuthRedirectService);
    protected busy$: BehaviorSubject<boolean>;
    updateSucceed$: Subject<unknown>;
    isUpdating$: rxjs.Observable<boolean>;
    form: UntypedFormGroup;
    save(): void;
    /**
     * Handles successful updating of the user email.
     */
    protected onSuccess(newUid: string): void;
    protected onError(_error: Error): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UpdateEmailComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UpdateEmailComponentService>;
}

declare class UpdateEmailComponent {
    protected service: UpdateEmailComponentService;
    protected pageMetaService: PageMetaService;
    constructor(service: UpdateEmailComponentService);
    form: UntypedFormGroup;
    isUpdating$: Observable<boolean>;
    pageTitle$: Observable<string>;
    onSubmit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UpdateEmailComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UpdateEmailComponent, "cx-update-email", never, {}, {}, never, never, true, never>;
}

declare class MyAccountV2EmailComponent implements OnInit {
    protected emailComponentService: UpdateEmailComponentService;
    protected userProfile: UserProfileFacade;
    protected pageMetaService: PageMetaService;
    form: UntypedFormGroup;
    isUpdating$: Observable<boolean>;
    isEditing: boolean;
    showingAlert: boolean;
    pageTitle$: Observable<string>;
    user$: Observable<User>;
    globalMessageType: typeof GlobalMessageType;
    ngOnInit(): void;
    onSubmit(): void;
    onEdit(): void;
    cancelEdit(): void;
    closeDialogConfirmationAlert(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2EmailComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyAccountV2EmailComponent, "cx-my-account-v2-email", never, {}, {}, never, never, true, never>;
}

declare class UpdateEmailModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UpdateEmailModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UpdateEmailModule, never, [typeof i1.CommonModule, typeof i2.FormsModule, typeof i2.ReactiveFormsModule, typeof i3.SpinnerModule, typeof i4.UrlModule, typeof i5.RouterModule, typeof i4.I18nModule, typeof i3.FormErrorsModule, typeof i3.PasswordVisibilityToggleModule, typeof i4.FeaturesConfigModule, typeof i3.MessageComponentModule, typeof i3.BtnLikeLinkModule, typeof i3.FormRequiredAsterisksComponent, typeof i3.FormRequiredLegendComponent, typeof UpdateEmailComponent, typeof MyAccountV2EmailComponent], [typeof UpdateEmailComponent, typeof MyAccountV2EmailComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UpdateEmailModule>;
}

declare const USE_MY_ACCOUNT_V2_EMAIL: InjectionToken<boolean>;

declare class UpdatePasswordComponentService {
    protected userPasswordService: UserPasswordFacade;
    protected routingService: RoutingService;
    protected globalMessageService: GlobalMessageService;
    protected authRedirectService?: AuthRedirectService | undefined;
    protected authService?: AuthService | undefined;
    private featureToggles;
    protected passwordValidators: (typeof CustomFormValidators.minOneDigitValidator)[];
    constructor(userPasswordService: UserPasswordFacade, routingService: RoutingService, globalMessageService: GlobalMessageService, authRedirectService?: AuthRedirectService | undefined, authService?: AuthService | undefined);
    protected busy$: BehaviorSubject<boolean>;
    private usingV2;
    isUpdating$: rxjs.Observable<boolean>;
    form: UntypedFormGroup;
    /**
     * Updates the password for the user.
     */
    updatePassword(): void;
    protected onSuccess(): void;
    protected onError(_error: HttpErrorModel | Error): void;
    protected getPasswordValidators(): ValidatorFn[];
    static ɵfac: i0.ɵɵFactoryDeclaration<UpdatePasswordComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UpdatePasswordComponentService>;
}

declare class UpdatePasswordComponent {
    protected service: UpdatePasswordComponentService;
    protected routingService: RoutingService | null;
    protected pageMetaService: PageMetaService;
    constructor(service: UpdatePasswordComponentService);
    form: UntypedFormGroup;
    isUpdating$: Observable<boolean>;
    pageTitle$: Observable<string>;
    onSubmit(): void;
    navigateTo(cxRoute: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UpdatePasswordComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UpdatePasswordComponent, "cx-update-password", never, {}, {}, never, never, true, never>;
}

declare class MyAccountV2PasswordComponent {
    protected service: UpdatePasswordComponentService;
    protected pageMetaService: PageMetaService;
    showingAlert: boolean;
    globalMessageType: typeof GlobalMessageType;
    oldPassword: string;
    newPassword: string;
    newPasswordConfirm: string;
    form: UntypedFormGroup;
    isUpdating$: Observable<boolean>;
    pageTitle$: Observable<string>;
    onSubmit(): void;
    onCancel(): void;
    closeDialogConfirmationAlert(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2PasswordComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyAccountV2PasswordComponent, "cx-my-account-v2-password", never, {}, {}, never, never, true, never>;
}

declare class UpdatePasswordModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UpdatePasswordModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UpdatePasswordModule, never, [typeof i1.CommonModule, typeof i2.FormsModule, typeof i2.ReactiveFormsModule, typeof i3.SpinnerModule, typeof i4.I18nModule, typeof i3.FormErrorsModule, typeof i4.UrlModule, typeof i5.RouterModule, typeof i3.PasswordVisibilityToggleModule, typeof i4.FeaturesConfigModule, typeof i3.MessageComponentModule, typeof i3.BtnLikeLinkModule, typeof i3.FormRequiredAsterisksComponent, typeof i3.FormRequiredLegendComponent, typeof UpdatePasswordComponent, typeof MyAccountV2PasswordComponent], [typeof UpdatePasswordComponent, typeof MyAccountV2PasswordComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UpdatePasswordModule>;
}

declare const USE_MY_ACCOUNT_V2_PASSWORD: InjectionToken<boolean>;

declare class UpdateProfileComponentService {
    protected userProfile: UserProfileFacade;
    protected globalMessageService: GlobalMessageService;
    constructor(userProfile: UserProfileFacade, globalMessageService: GlobalMessageService);
    user$: Observable<User$1>;
    protected busy$: BehaviorSubject<boolean>;
    updateSucceed$: Subject<boolean>;
    isUpdating$: Observable<boolean>;
    titles$: Observable<Title$1[]>;
    form: UntypedFormGroup;
    /**
     * Updates the user's details and handles the UI.
     */
    updateProfile(): void;
    protected onSuccess(): void;
    protected onError(_error: Error): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UpdateProfileComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UpdateProfileComponentService>;
}

declare class UpdateProfileComponent {
    protected service: UpdateProfileComponentService;
    protected routingService: RoutingService | null;
    protected pageMetaService: PageMetaService;
    constructor(service: UpdateProfileComponentService);
    form: UntypedFormGroup;
    isUpdating$: Observable<boolean>;
    titles$: Observable<Title$1[]>;
    pageTitle$: Observable<string>;
    onSubmit(): void;
    navigateTo(cxRoute: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UpdateProfileComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UpdateProfileComponent, "cx-update-profile", never, {}, {}, never, never, true, never>;
}

declare class MyAccountV2ProfileComponent implements OnInit {
    protected service: UpdateProfileComponentService;
    protected pageMetaService: PageMetaService;
    ngOnInit(): void;
    form: UntypedFormGroup;
    isUpdating$: Observable<boolean>;
    titles$: Observable<Title$1[]>;
    user$: Observable<User$1>;
    isEditing: boolean;
    originalEditValue: User$1;
    pageTitle$: Observable<string>;
    onSubmit(): void;
    cancelEdit(): void;
    onEdit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2ProfileComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyAccountV2ProfileComponent, "cx-my-account-v2-profile", never, {}, {}, never, never, true, never>;
}

declare class UpdateProfileModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UpdateProfileModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UpdateProfileModule, never, [typeof i1.CommonModule, typeof i2.FormsModule, typeof i2.ReactiveFormsModule, typeof i3.SpinnerModule, typeof i4.I18nModule, typeof i3.FormErrorsModule, typeof i5.RouterModule, typeof i4.UrlModule, typeof i6.NgSelectModule, typeof i3.NgSelectA11yModule, typeof i4.FeaturesConfigModule, typeof i3.BtnLikeLinkModule, typeof i3.FormRequiredAsterisksComponent, typeof i3.FormRequiredLegendComponent, typeof UpdateProfileComponent, typeof MyAccountV2ProfileComponent], [typeof UpdateProfileComponent, typeof MyAccountV2ProfileComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UpdateProfileModule>;
}

declare const USE_MY_ACCOUNT_V2_PROFILE: InjectionToken<boolean>;

declare class AddressFormComponent implements OnInit, OnDestroy {
    protected fb: UntypedFormBuilder;
    protected userAddressService: UserAddressService;
    protected globalMessageService: GlobalMessageService;
    protected translation: TranslationService;
    protected launchDialogService: LaunchDialogService;
    protected userProfileFacade: UserProfileFacade;
    protected languageService: LanguageService;
    protected cdr: ChangeDetectorRef;
    private featureToggles;
    protected hierarchicalAddressConfig: HierarchicalAddressConfig;
    protected elementRef: ElementRef<any>;
    protected get isMaxLengthEnabled(): boolean;
    countries$: Observable<Country[]>;
    titles$: Observable<Title[]>;
    regions$: Observable<Region[]>;
    selectedCountry$: BehaviorSubject<string>;
    selectedRegion$: BehaviorSubject<string>;
    selectedCity$: BehaviorSubject<string>;
    isHierarchicalAddressFormat: boolean;
    cities: City[];
    districts: CityDistrict[];
    addresses$: Observable<Address[]>;
    /**
     * Drives the `cxFocus` autofocus host. Autofocus starts disabled and is
     * enabled (with a `refreshFocus` token to re-trigger the directive) only once
     * the country data has loaded, so focus lands on the country select rather
     * than whichever field wins the async render race.
     */
    focusConfig: FocusConfig;
    addressData: Address;
    actionBtnLabel: string;
    cancelBtnLabel: string;
    setAsDefaultField: boolean;
    showTitleCode: boolean;
    showCancelBtn: boolean;
    countries: Observable<Country[]>;
    submitAddress: EventEmitter<any>;
    backToAddress: EventEmitter<any>;
    element: ElementRef;
    protected firstInvalidFieldFocus?: FocusFirstInvalidFieldDirective;
    subscription: Subscription;
    protected readonly maxFieldLength = 256;
    addressForm: UntypedFormGroup;
    protected buildForm(): UntypedFormGroup;
    constructor(fb: UntypedFormBuilder, userAddressService: UserAddressService, globalMessageService: GlobalMessageService, translation: TranslationService, launchDialogService: LaunchDialogService, userProfileFacade: UserProfileFacade);
    ngOnInit(): void;
    protected initCitiesSubscription(): void;
    protected initDistrictsSubscription(): void;
    protected initLanguageSubscription(): void;
    getTitles(): Observable<Title[]>;
    protected handleAddressVerificationResults(results: AddressValidation): void;
    countrySelected(country: Country | undefined): void;
    regionSelected(region: Region): void;
    citySelected(city: City | undefined): void;
    toggleDefaultAddress(): void;
    back(): void;
    verifyAddress(): void;
    openSuggestedAddress(results: AddressValidation): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddressFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddressFormComponent, "cx-address-form", never, { "addressData": { "alias": "addressData"; "required": false; }; "actionBtnLabel": { "alias": "actionBtnLabel"; "required": false; }; "cancelBtnLabel": { "alias": "cancelBtnLabel"; "required": false; }; "setAsDefaultField": { "alias": "setAsDefaultField"; "required": false; }; "showTitleCode": { "alias": "showTitleCode"; "required": false; }; "showCancelBtn": { "alias": "showCancelBtn"; "required": false; }; "countries": { "alias": "countries"; "required": false; }; }, { "submitAddress": "submitAddress"; "backToAddress": "backToAddress"; }, never, never, true, never>;
}

declare class SuggestedAddressDialogComponent implements OnInit {
    protected launchDialogService: LaunchDialogService;
    protected el: ElementRef;
    iconTypes: typeof ICON_TYPE;
    focusConfig: FocusConfig;
    selectedAddress: Address;
    data$: rxjs.Observable<any>;
    handleClick(event: UIEvent): void;
    constructor(launchDialogService: LaunchDialogService, el: ElementRef);
    ngOnInit(): void;
    closeModal(reason?: any): void;
    setSelectedAddress(data: {
        suggestedAddresses: Address[];
        enteredAddress: Address;
    }): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SuggestedAddressDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SuggestedAddressDialogComponent, "cx-suggested-addresses-dialog", never, {}, {}, never, never, true, never>;
}

declare class AddressFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AddressFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AddressFormModule, never, [typeof i3.NgSelectA11yModule, typeof i1.CommonModule, typeof i2.ReactiveFormsModule, typeof i2.FormsModule, typeof i5.RouterModule, typeof i6.NgSelectModule, typeof i3.IconModule, typeof i4.I18nModule, typeof i3.FormErrorsModule, typeof i3.KeyboardFocusModule, typeof i4.FeaturesConfigModule, typeof i3.FormRequiredAsterisksComponent, typeof i3.FormRequiredLegendComponent, typeof AddressFormComponent, typeof SuggestedAddressDialogComponent], [typeof AddressFormComponent, typeof SuggestedAddressDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AddressFormModule>;
}

declare class AddressBookComponentService {
    protected userAddressService: UserAddressService;
    constructor(userAddressService: UserAddressService);
    getAddresses(): Observable<Address[]>;
    getAddressesStateLoading(): Observable<boolean>;
    getAddressesError(): Observable<boolean>;
    loadAddresses(): void;
    addUserAddress(address: Address): void;
    updateUserAddress(addressId: string, address: Address): void;
    setAddressAsDefault(addressId: string): void;
    deleteUserAddress(addressId: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddressBookComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AddressBookComponentService>;
}

declare class AddressBookComponent implements OnInit, OnDestroy {
    service: AddressBookComponentService;
    protected translation: TranslationService;
    protected globalMessageService: GlobalMessageService;
    addresses$: Observable<Address[]>;
    cards$: Observable<Card[]>;
    addressesStateLoading$: Observable<boolean>;
    currentAddress: Address;
    showAddAddressForm: boolean;
    showEditAddressForm: boolean;
    editCard: string | null;
    protected subscription: Subscription;
    protected languageService: LanguageService;
    private featureToggles;
    protected hierarchicalAddressConfig: HierarchicalAddressConfig;
    constructor(service: AddressBookComponentService, translation: TranslationService, globalMessageService: GlobalMessageService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    addAddressButtonHandle(): void;
    editAddressButtonHandle(address: Address): void;
    addAddressSubmit(address: Address): void;
    addAddressCancel(): void;
    editAddressSubmit(address: Address): void;
    editAddressCancel(): void;
    getCardContent(address: Address): Observable<Card>;
    protected buildLocationLine(address: Address): string;
    protected isHierarchicalAddressFormat(address: Address): boolean;
    setAddressAsDefault(address: Address): void;
    deleteAddress(addressId: string): void;
    setEdit(addressId: string): void;
    cancelCard(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddressBookComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddressBookComponent, "cx-address-book", never, {}, {}, never, never, true, never>;
}

declare class AddressBookModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AddressBookModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AddressBookModule, never, [typeof i1.CommonModule, typeof i3.CardModule, typeof AddressFormModule, typeof i3.SpinnerModule, typeof i4.I18nModule, typeof i4.FeaturesConfigModule, typeof AddressBookComponent], [typeof AddressBookComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AddressBookModule>;
}

declare class OneTimePasswordRegisterComponent implements OnInit, OnDestroy {
    protected globalMessageService: GlobalMessageService;
    protected fb: UntypedFormBuilder;
    protected router: RoutingService;
    protected anonymousConsentsService: AnonymousConsentsService;
    protected anonymousConsentsConfig: AnonymousConsentsConfig;
    protected clientAuthenticationTokenService: ClientAuthenticationTokenService;
    protected registerComponentService: RegisterComponentService;
    protected routingService: RoutingService;
    protected registrationVerificationTokenFacade: VerificationTokenFacade;
    constructor();
    titles$: Observable<Title$1[]>;
    isLoading$: BehaviorSubject<boolean>;
    private subscription;
    anonymousConsent$: Observable<{
        consent: AnonymousConsent | undefined;
        template: string;
    }>;
    registerForm: UntypedFormGroup;
    additionalRegistrationConsents: {
        template: ConsentTemplate;
        required: boolean;
    }[];
    get additionalConsents(): UntypedFormArray;
    updateAdditionalConsents(event: MouseEvent, index: number): void;
    ngOnInit(): void;
    submitForm(): void;
    sendRegistrationVerificationToken(): void;
    protected onCreateRegistrationVerificationTokenComplete(): void;
    collectDataFromRegisterForm(): VerificationTokenCreation;
    protected goToVerificationTokenForm(registrationVerificationToken: VerificationToken): void;
    isConsentGiven(consent: AnonymousConsent | undefined): boolean;
    private isConsentRequired;
    toggleAnonymousConsent(): void;
    /**
     * Triggered via CaptchaComponent when a user confirms captcha
     */
    captchaConfirmed(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OneTimePasswordRegisterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OneTimePasswordRegisterComponent, "cx-otp-register-form", never, {}, {}, never, never, true, never>;
}

declare class OneTimePasswordRegisterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OneTimePasswordRegisterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OneTimePasswordRegisterModule, never, [typeof i1.CommonModule, typeof i5.RouterModule, typeof i4.UrlModule, typeof i3.PageSlotModule, typeof i4.I18nModule, typeof i4.FeaturesConfigModule, typeof i3.BtnLikeLinkModule, typeof i2.ReactiveFormsModule, typeof i6.NgSelectModule, typeof i3.NgSelectA11yModule, typeof i3.CaptchaModule, typeof i3.SpinnerModule, typeof i3.FormErrorsModule, typeof i3.FormRequiredAsterisksComponent, typeof OneTimePasswordRegisterComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OneTimePasswordRegisterModule>;
}

declare class RegistrationVerificationTokenFormComponentService {
    protected globalMessageService: GlobalMessageService;
    protected userRegisterFacade: UserRegisterFacade;
    displayMessage(key: string, params: Object): void;
    register(user: UserSignUp): Observable<User>;
    postRegisterMessage(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RegistrationVerificationTokenFormComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RegistrationVerificationTokenFormComponentService>;
}

declare class RegistrationVerificationTokenFormComponent implements OnInit {
    protected fb: UntypedFormBuilder;
    protected router: RoutingService;
    protected authConfigService: AuthConfigService;
    protected registrationVerificationTokenFacade: VerificationTokenFacade;
    protected service: RegistrationVerificationTokenFormComponentService;
    protected globalMessage: GlobalMessageService;
    protected launchDialogService: LaunchDialogService;
    private featureToggles;
    protected passwordValidators: any;
    getPasswordValidators(): any;
    protected cdr: ChangeDetectorRef;
    waitTime: number;
    waitTimeForRateLimit: number;
    registerForm: UntypedFormGroup;
    ngOnInit(): void;
    isLoading$: BehaviorSubject<boolean>;
    element: ElementRef;
    resendLink: ElementRef;
    tokenId: string;
    tokenCode: string;
    target: string;
    titleCode: string;
    firstName: string;
    lastName: string;
    password: string;
    passwordconf: string;
    errorStatus: number;
    isResendDisabled: boolean;
    upToRateLimit: boolean;
    onSubmit(): void;
    registerUserWithVerificationToken(): void;
    collectDataFromRegisterForm(formData: any): UserSignUp;
    protected onRegisterUserSuccess(): void;
    resendOTP(): void;
    createRegistrationVerificationToken(loginId: string, purpose: string): rxjs.Observable<VerificationToken>;
    startWaitTimeInterval(): void;
    startRateLimitWaitTimeInterval(): void;
    openInfoDailog(): void;
    onOpenInfoDailogKeyDown(event: KeyboardEvent): void;
    goBack(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RegistrationVerificationTokenFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RegistrationVerificationTokenFormComponent, "cx-registration-verification-token-form", never, {}, {}, never, never, true, never>;
}

declare class RegistrationVerificationTokenFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<RegistrationVerificationTokenFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<RegistrationVerificationTokenFormModule, never, [typeof i1.CommonModule, typeof i2.FormsModule, typeof i3.KeyboardFocusModule, typeof i2.ReactiveFormsModule, typeof i5.RouterModule, typeof i4.UrlModule, typeof i3.IconModule, typeof i4.I18nModule, typeof i3.FormErrorsModule, typeof i3.SpinnerModule, typeof i4.FeaturesConfigModule, typeof i3.FormRequiredAsterisksComponent, typeof RegistrationVerificationTokenFormComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<RegistrationVerificationTokenFormModule>;
}

declare class UserProfileComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserProfileComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserProfileComponentsModule, never, [typeof RegisterComponentModule, typeof UpdateProfileModule, typeof UpdateEmailModule, typeof UpdatePasswordModule, typeof ForgotPasswordModule, typeof ResetPasswordModule, typeof CloseAccountModule, typeof AddressBookModule, typeof OneTimePasswordRegisterModule, typeof RegistrationVerificationTokenFormModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserProfileComponentsModule>;
}

export { AddressBookComponent, AddressBookComponentService, AddressBookModule, AddressFormComponent, AddressFormModule, CloseAccountComponent, CloseAccountModalComponent, CloseAccountModule, ForgotPasswordComponent, ForgotPasswordComponentService, ForgotPasswordModule, MyAccountV2EmailComponent, MyAccountV2PasswordComponent, MyAccountV2ProfileComponent, OneTimePasswordRegisterComponent, OneTimePasswordRegisterModule, RegisterComponent, RegisterComponentModule, RegisterComponentService, RegistrationVerificationTokenFormComponent, RegistrationVerificationTokenFormComponentService, RegistrationVerificationTokenFormModule, ResetPasswordComponent, ResetPasswordComponentService, ResetPasswordModule, SuggestedAddressDialogComponent, USE_MY_ACCOUNT_V2_EMAIL, USE_MY_ACCOUNT_V2_PASSWORD, USE_MY_ACCOUNT_V2_PROFILE, UpdateEmailComponent, UpdateEmailComponentService, UpdateEmailModule, UpdatePasswordComponent, UpdatePasswordComponentService, UpdatePasswordModule, UpdateProfileComponent, UpdateProfileComponentService, UpdateProfileModule, UserProfileComponentsModule };
