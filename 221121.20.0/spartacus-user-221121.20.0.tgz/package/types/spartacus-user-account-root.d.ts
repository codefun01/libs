import * as i0 from '@angular/core';
import { OnDestroy } from '@angular/core';
import { WindowRef, EventService, CurrencyService, GlobalMessageService, CmsConfig, CxEvent } from '@spartacus/core';
import { Observable, Subscription } from 'rxjs';

declare abstract class UserAccountConfig {
    userAccount?: {
        /**
         * When enabled, applies the user's preferred currency (from OCC GET /users/{userId})
         * on login, and reverts to the pre-login currency stored in localStorage on logout.
         * Affects: UserLoginCurrencyService
         */
        enableUserCurrencySync?: boolean;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAccountConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserAccountConfig>;
}
declare module '@spartacus/core' {
    interface Config extends UserAccountConfig {
    }
}

declare const defaultUserAccountConfig: UserAccountConfig;

interface User {
    displayUid?: string;
    firstName?: string;
    lastName?: string;
    name?: string;
    uid?: string;
    customerId?: string;
    title?: string;
}

declare abstract class UserAccountFacade {
    abstract get(): Observable<User | undefined>;
    abstract getById(userId: string): Observable<User | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAccountFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserAccountFacade>;
}

declare const PRE_LOGIN_CURRENCY_STORAGE_KEY = "spartacus\u26BF\u26BFpre-login-currency";
declare class UserLoginCurrencyPersistenceService {
    protected winRef: WindowRef;
    savePreLoginCurrency(isocode: string): void;
    getPreLoginCurrency(): string | null;
    clearPreLoginCurrency(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserLoginCurrencyPersistenceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserLoginCurrencyPersistenceService>;
}

declare class UserLoginCurrencyService implements OnDestroy {
    protected eventService: EventService;
    protected currencyService: CurrencyService;
    protected userAccountFacade: UserAccountFacade;
    protected userAccountConfig: UserAccountConfig;
    protected currencyPersistence: UserLoginCurrencyPersistenceService;
    protected subscription: Subscription;
    constructor();
    protected onLoginAndLogout(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserLoginCurrencyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserLoginCurrencyService>;
}

/**
 * User account event listener.
 */
declare class UserAccountEventListener implements OnDestroy {
    protected eventService: EventService;
    protected globalMessageService: GlobalMessageService;
    protected subscriptions: Subscription;
    constructor(eventService: EventService, globalMessageService: GlobalMessageService);
    /**
     * Registers events for the auth events.
     */
    protected onAuth(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAccountEventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserAccountEventListener>;
}

declare class UserAccountEventModule {
    protected _userLoginCurrencyService: UserLoginCurrencyService;
    constructor(_userAccountEventListener: UserAccountEventListener);
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAccountEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserAccountEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserAccountEventModule>;
}

declare function defaultUserAccountComponentsConfig(): CmsConfig;
declare class UserAccountRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UserAccountRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UserAccountRootModule, never, [typeof UserAccountEventModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UserAccountRootModule>;
}

declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        ACCOUNT_VERIFICATION_TOKEN = "ACCOUNT_VERIFICATION_TOKEN"
    }
}

interface VerificationTokenCreation {
    purpose: string;
    loginId: string;
    password?: string;
}
interface VerificationToken {
    expiresIn: string;
    tokenId: string;
}
declare enum VERIFICATION_TOKEN_DIALOG_ACTION {
    OK = "OK"
}

declare abstract class VerificationTokenFacade {
    abstract createVerificationToken(verificationTokenCreation: VerificationTokenCreation): Observable<VerificationToken>;
    static ɵfac: i0.ɵɵFactoryDeclaration<VerificationTokenFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VerificationTokenFacade>;
}

declare abstract class UserAccountEvent extends CxEvent {
    user: User;
}
declare class UserAccountChangedEvent extends UserAccountEvent {
    static readonly type = "UserAccountChangedEvent";
}

declare const USER_ACCOUNT_FEATURE = "userAccount";
declare const USER_ACCOUNT_CORE_FEATURE = "userAccountCore";

export { PRE_LOGIN_CURRENCY_STORAGE_KEY, USER_ACCOUNT_CORE_FEATURE, USER_ACCOUNT_FEATURE, UserAccountChangedEvent, UserAccountConfig, UserAccountEvent, UserAccountEventListener, UserAccountEventModule, UserAccountFacade, UserAccountRootModule, UserLoginCurrencyPersistenceService, UserLoginCurrencyService, VERIFICATION_TOKEN_DIALOG_ACTION, VerificationTokenFacade, defaultUserAccountComponentsConfig, defaultUserAccountConfig };
export type { User, VerificationToken, VerificationTokenCreation };
