import * as i0 from '@angular/core';
import { Injectable, inject, NgModule } from '@angular/core';
import * as i1 from '@spartacus/core';
import { Config, facadeFactory, WindowRef, EventService, CurrencyService, LoginEvent, LogoutEvent, GlobalMessageType, FeatureToggles, provideDefaultConfig, provideDefaultConfigFactory, CxEvent } from '@spartacus/core';
import { Subscription } from 'rxjs';
import { switchMap, take, filter } from 'rxjs/operators';
import { LAUNCH_CALLER } from '@spartacus/storefront';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAccountConfig {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountConfig, providedIn: 'root', useExisting: Config }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useExisting: Config,
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultUserAccountConfig = {
    userAccount: {
        enableUserCurrencySync: false,
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const USER_ACCOUNT_FEATURE = 'userAccount';
const USER_ACCOUNT_CORE_FEATURE = 'userAccountCore';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAccountFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: UserAccountFacade,
            feature: USER_ACCOUNT_CORE_FEATURE,
            methods: ['get', 'getById'],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: UserAccountFacade,
                        feature: USER_ACCOUNT_CORE_FEATURE,
                        methods: ['get', 'getById'],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const PRE_LOGIN_CURRENCY_STORAGE_KEY = 'spartacus⚿⚿pre-login-currency';
class UserLoginCurrencyPersistenceService {
    constructor() {
        this.winRef = inject(WindowRef);
    }
    savePreLoginCurrency(isocode) {
        this.winRef.localStorage?.setItem(PRE_LOGIN_CURRENCY_STORAGE_KEY, JSON.stringify(isocode));
    }
    getPreLoginCurrency() {
        const raw = this.winRef.localStorage?.getItem(PRE_LOGIN_CURRENCY_STORAGE_KEY);
        if (!raw) {
            return null;
        }
        try {
            return JSON.parse(raw);
        }
        catch {
            return null;
        }
    }
    clearPreLoginCurrency() {
        this.winRef.localStorage?.removeItem(PRE_LOGIN_CURRENCY_STORAGE_KEY);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserLoginCurrencyPersistenceService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserLoginCurrencyPersistenceService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserLoginCurrencyPersistenceService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserLoginCurrencyService {
    constructor() {
        this.eventService = inject(EventService);
        this.currencyService = inject(CurrencyService);
        this.userAccountFacade = inject(UserAccountFacade);
        this.userAccountConfig = inject(UserAccountConfig);
        this.currencyPersistence = inject(UserLoginCurrencyPersistenceService);
        this.subscription = new Subscription();
        this.onLoginAndLogout();
    }
    onLoginAndLogout() {
        if (!this.userAccountConfig.userAccount?.enableUserCurrencySync) {
            return;
        }
        this.subscription.add(this.eventService
            .get(LoginEvent)
            .pipe(switchMap(() => this.currencyService.getActive().pipe(take(1))), switchMap((preLoginCurrency) => {
            this.currencyPersistence.savePreLoginCurrency(preLoginCurrency);
            return this.userAccountFacade.get().pipe(filter((user) => {
                const isocode = user?.currency?.isocode;
                return !!isocode && isocode !== preLoginCurrency;
            }), take(1));
        }))
            .subscribe((user) => {
            this.currencyService.setActive(user.currency?.isocode);
        }));
        this.subscription.add(this.eventService.get(LogoutEvent).subscribe(() => {
            const isocode = this.currencyPersistence.getPreLoginCurrency();
            if (isocode) {
                this.currencyService.setActive(isocode);
            }
            this.currencyPersistence.clearPreLoginCurrency();
        }));
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserLoginCurrencyService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserLoginCurrencyService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserLoginCurrencyService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * User account event listener.
 */
class UserAccountEventListener {
    constructor(eventService, globalMessageService) {
        this.eventService = eventService;
        this.globalMessageService = globalMessageService;
        this.subscriptions = new Subscription();
        this.onAuth();
    }
    /**
     * Registers events for the auth events.
     */
    onAuth() {
        this.subscriptions.add(this.eventService.get(LogoutEvent).subscribe(() => {
            this.globalMessageService.add({ key: 'authMessages.signedOutSuccessfully' }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
        }));
    }
    ngOnDestroy() {
        this.subscriptions.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountEventListener, deps: [{ token: i1.EventService }, { token: i1.GlobalMessageService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountEventListener, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountEventListener, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.EventService }, { type: i1.GlobalMessageService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAccountEventModule {
    constructor(_userAccountEventListener) {
        this._userLoginCurrencyService = inject(UserLoginCurrencyService);
        // Intentional empty constructor
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountEventModule, deps: [{ token: UserAccountEventListener }], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: UserAccountEventModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountEventModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountEventModule, decorators: [{
            type: NgModule,
            args: [{}]
        }], ctorParameters: () => [{ type: UserAccountEventListener }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
// TODO: Inline this factory when we start releasing Ivy compiled libraries
function defaultUserAccountComponentsConfig() {
    const { oauthCallbackPage, asyncAuthConfigInitializer, authorizationCodeFlowByDefault, } = inject(FeatureToggles);
    const config = {
        featureModules: {
            [USER_ACCOUNT_FEATURE]: {
                cmsComponents: [
                    'LoginComponent',
                    'OAuthCallbackComponent',
                    'ReturningCustomerLoginComponent',
                    'VerifyOTPTokenComponent',
                    'ReturningCustomerRegisterComponent',
                    'MyAccountViewUserComponent',
                    'ReturningCustomerOTPLoginComponent',
                    'RegisterCustomerWithOTPComponent',
                    'ReturningOrganizationUserRegisterComponent',
                ],
            },
            // by default core is bundled together with components
            [USER_ACCOUNT_CORE_FEATURE]: USER_ACCOUNT_FEATURE,
        },
    };
    if (!(oauthCallbackPage &&
        asyncAuthConfigInitializer &&
        authorizationCodeFlowByDefault)) {
        // remove OAuthCallbackComponent entry
        const cmsComponents = config.featureModules[USER_ACCOUNT_FEATURE].cmsComponents;
        const index = cmsComponents.indexOf('OAuthCallbackComponent');
        cmsComponents.splice(index, 1);
    }
    return config;
}
class UserAccountRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: UserAccountRootModule, imports: [UserAccountEventModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountRootModule, providers: [
            provideDefaultConfig(defaultUserAccountConfig),
            provideDefaultConfigFactory(defaultUserAccountComponentsConfig),
        ], imports: [UserAccountEventModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserAccountRootModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [UserAccountEventModule],
                    providers: [
                        provideDefaultConfig(defaultUserAccountConfig),
                        provideDefaultConfigFactory(defaultUserAccountComponentsConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class VerificationTokenFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: VerificationTokenFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: VerificationTokenFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: VerificationTokenFacade,
            feature: USER_ACCOUNT_CORE_FEATURE,
            methods: ['createVerificationToken'],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: VerificationTokenFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: VerificationTokenFacade,
                        feature: USER_ACCOUNT_CORE_FEATURE,
                        methods: ['createVerificationToken'],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
LAUNCH_CALLER['ACCOUNT_VERIFICATION_TOKEN'] =
    'ACCOUNT_VERIFICATION_TOKEN';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var VERIFICATION_TOKEN_DIALOG_ACTION;
(function (VERIFICATION_TOKEN_DIALOG_ACTION) {
    VERIFICATION_TOKEN_DIALOG_ACTION["OK"] = "OK";
})(VERIFICATION_TOKEN_DIALOG_ACTION || (VERIFICATION_TOKEN_DIALOG_ACTION = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserAccountEvent extends CxEvent {
}
class UserAccountChangedEvent extends UserAccountEvent {
    static { this.type = 'UserAccountChangedEvent'; }
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/** AUGMENTABLE_TYPES_END */

/**
 * Generated bundle index. Do not edit.
 */

export { PRE_LOGIN_CURRENCY_STORAGE_KEY, USER_ACCOUNT_CORE_FEATURE, USER_ACCOUNT_FEATURE, UserAccountChangedEvent, UserAccountConfig, UserAccountEvent, UserAccountEventListener, UserAccountEventModule, UserAccountFacade, UserAccountRootModule, UserLoginCurrencyPersistenceService, UserLoginCurrencyService, VERIFICATION_TOKEN_DIALOG_ACTION, VerificationTokenFacade, defaultUserAccountComponentsConfig, defaultUserAccountConfig };
//# sourceMappingURL=spartacus-user-account-root.mjs.map
