import * as i0 from '@angular/core';
import { Injectable, inject, NgModule } from '@angular/core';
import { facadeFactory, EventService, UserIdService, CurrencySetEvent, OCC_USER_ID_ANONYMOUS, UserProfileFacadeTransitionalToken, provideDefaultConfigFactory } from '@spartacus/core';
import { UserAccountConfig } from '@spartacus/user/account/root';
import { Subscription } from 'rxjs';
import { switchMap, take, filter } from 'rxjs/operators';
import { LAUNCH_CALLER } from '@spartacus/storefront';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const USER_PROFILE_FEATURE = 'userProfile';
const USER_PROFILE_CORE_FEATURE = 'userProfileCore';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserProfileFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserProfileFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserProfileFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: UserProfileFacade,
            feature: USER_PROFILE_CORE_FEATURE,
            methods: ['get', 'update', 'close', 'getTitles'],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserProfileFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: UserProfileFacade,
                        feature: USER_PROFILE_CORE_FEATURE,
                        methods: ['get', 'update', 'close', 'getTitles'],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserCurrencyPreferenceSaverService {
    constructor() {
        this.eventService = inject(EventService);
        this.userProfileFacade = inject(UserProfileFacade);
        this.userIdService = inject(UserIdService);
        this.userAccountConfig = inject(UserAccountConfig);
        this.subscription = new Subscription();
        this.onCurrencyChange();
    }
    onCurrencyChange() {
        if (!this.userAccountConfig.userAccount?.enableUserCurrencySync) {
            return;
        }
        this.subscription.add(this.eventService
            .get(CurrencySetEvent)
            .pipe(switchMap(({ activeCurrency }) => this.userIdService.getUserId().pipe(take(1), filter((userId) => userId !== OCC_USER_ID_ANONYMOUS), switchMap(() => this.userProfileFacade.update({
            currency: { isocode: activeCurrency },
        })))))
            .subscribe());
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserCurrencyPreferenceSaverService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserCurrencyPreferenceSaverService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserCurrencyPreferenceSaverService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
// TODO: Inline this factory when we start releasing Ivy compiled libraries
function defaultUserProfileComponentsConfig() {
    const config = {
        featureModules: {
            [USER_PROFILE_FEATURE]: {
                cmsComponents: [
                    'RegisterCustomerComponent',
                    'UpdateProfileComponent',
                    'UpdateEmailComponent',
                    'UpdatePasswordComponent',
                    'ForgotPasswordComponent',
                    'ResetPasswordComponent',
                    'CloseAccountComponent',
                    'AccountAddressBookComponent',
                    'RegisterCustomerWithOTPComponent',
                    'VerifyOTPForRegistrationComponent',
                ],
            },
            // by default core is bundled together with components
            [USER_PROFILE_CORE_FEATURE]: USER_PROFILE_FEATURE,
        },
    };
    return config;
}
class UserProfileRootModule {
    constructor() {
        this._userCurrencyPreferenceSaverService = inject(UserCurrencyPreferenceSaverService);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserProfileRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: UserProfileRootModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserProfileRootModule, providers: [
            provideDefaultConfigFactory(defaultUserProfileComponentsConfig),
            {
                provide: UserProfileFacadeTransitionalToken,
                useExisting: UserProfileFacade,
            },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserProfileRootModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        provideDefaultConfigFactory(defaultUserProfileComponentsConfig),
                        {
                            provide: UserProfileFacadeTransitionalToken,
                            useExisting: UserProfileFacade,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserEmailFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserEmailFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserEmailFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: UserEmailFacade,
            feature: USER_PROFILE_CORE_FEATURE,
            methods: ['update'],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserEmailFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: UserEmailFacade,
                        feature: USER_PROFILE_CORE_FEATURE,
                        methods: ['update'],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserPasswordFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserPasswordFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserPasswordFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: UserPasswordFacade,
            feature: USER_PROFILE_CORE_FEATURE,
            methods: ['update', 'reset', 'requestForgotPasswordEmail'],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserPasswordFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: UserPasswordFacade,
                        feature: USER_PROFILE_CORE_FEATURE,
                        methods: ['update', 'reset', 'requestForgotPasswordEmail'],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class UserRegisterFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegisterFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegisterFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: UserRegisterFacade,
            feature: USER_PROFILE_CORE_FEATURE,
            methods: ['register', 'registerGuest', 'getTitles'],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: UserRegisterFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: UserRegisterFacade,
                        feature: USER_PROFILE_CORE_FEATURE,
                        methods: ['register', 'registerGuest', 'getTitles'],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
LAUNCH_CALLER['CLOSE_ACCOUNT'] = 'CLOSE_ACCOUNT';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/** AUGMENTABLE_TYPES_END */

/**
 * Generated bundle index. Do not edit.
 */

export { USER_PROFILE_CORE_FEATURE, USER_PROFILE_FEATURE, UserCurrencyPreferenceSaverService, UserEmailFacade, UserPasswordFacade, UserProfileFacade, UserProfileRootModule, UserRegisterFacade, defaultUserProfileComponentsConfig };
//# sourceMappingURL=spartacus-user-profile-root.mjs.map
