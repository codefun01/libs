import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { LoggerService, OccEndpointsService, ConverterService, ADDRESS_SERIALIZER, tryNormalizeHttpError, backOff, isJaloError, ADDRESS_NORMALIZER, provideDefaultConfig } from '@spartacus/core';
import { OpfQuickBuyCartAdapter } from '@spartacus/opf/quick-buy/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { DELIVERY_MODE_NORMALIZER } from '@spartacus/checkout/base/core';
import { catchError, map } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccOpfQuickBuyCartAdapter {
    constructor() {
        this.logger = inject(LoggerService);
        this.http = inject(HttpClient);
        this.occEndpoints = inject(OccEndpointsService);
        this.converter = inject(ConverterService);
    }
    createDeliveryAddress(userId, cartId, address) {
        const serializedAddress = this.converter.convert(address, ADDRESS_SERIALIZER);
        return this.http
            .post(this.getCreateDeliveryAddressEndpoint(userId, cartId), serializedAddress, {
            headers: new HttpHeaders().set('Content-Type', 'application/json'),
        })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({
            shouldRetry: isJaloError,
        }), this.converter.pipeable(ADDRESS_NORMALIZER));
    }
    setBillingAddress(userId, cartId, address) {
        return this.http
            .put(this.getSetBillingAddressEndpoint(userId, cartId), address)
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({
            shouldRetry: isJaloError,
        }));
    }
    getSupportedDeliveryModes(userId, cartId) {
        return this.http
            .get(this.getDeliveryModesEndpoint(userId, cartId))
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({
            shouldRetry: isJaloError,
        }), map((listResponse) => listResponse.deliveryModes ?? []), this.converter.pipeableMany(DELIVERY_MODE_NORMALIZER));
    }
    setDeliveryMode(userId, cartId, deliveryModeId) {
        return this.http
            .put(this.getSetDeliveryModeEndpoint(userId, cartId, deliveryModeId), {})
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({
            shouldRetry: isJaloError,
        }));
    }
    getSelectedDeliveryMode(userId, cartId) {
        return this.http
            .get(this.getSelectedDeliveryModeEndpoint(userId, cartId))
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({
            shouldRetry: isJaloError,
        }), map((cart) => cart.deliveryMode
            ? this.converter.convert(cart.deliveryMode, DELIVERY_MODE_NORMALIZER)
            : undefined));
    }
    getCreateDeliveryAddressEndpoint(userId, cartId) {
        return this.occEndpoints.buildUrl('quickBuyCreateDeliveryAddress', {
            urlParams: {
                userId,
                cartId,
            },
        });
    }
    getSetBillingAddressEndpoint(userId, cartId) {
        return this.occEndpoints.buildUrl('quickBuySetBillingAddress', {
            urlParams: {
                userId,
                cartId,
            },
        });
    }
    getDeliveryModesEndpoint(userId, cartId) {
        return this.occEndpoints.buildUrl('quickBuyDeliveryModes', {
            urlParams: {
                userId,
                cartId,
            },
        });
    }
    getSetDeliveryModeEndpoint(userId, cartId, deliveryModeId) {
        return this.occEndpoints.buildUrl('quickBuySetDeliveryMode', {
            urlParams: {
                userId,
                cartId,
            },
            queryParams: { deliveryModeId },
        });
    }
    getSelectedDeliveryModeEndpoint(userId, cartId) {
        return this.occEndpoints.buildUrl('quickBuySelectedDeliveryMode', {
            urlParams: {
                userId,
                cartId,
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccOpfQuickBuyCartAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccOpfQuickBuyCartAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccOpfQuickBuyCartAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOccOpfQuickBuyCartConfig = {
    backend: {
        occ: {
            endpoints: {
                quickBuyCreateDeliveryAddress: 'users/${userId}/carts/${cartId}/addresses/delivery',
                quickBuySetBillingAddress: 'users/${userId}/carts/${cartId}/addresses/billing',
                quickBuyDeliveryModes: 'users/${userId}/carts/${cartId}/deliverymodes',
                quickBuySetDeliveryMode: 'users/${userId}/carts/${cartId}/deliverymode',
                quickBuySelectedDeliveryMode: 'users/${userId}/carts/${cartId}?fields=deliveryMode(FULL)',
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyOccModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyOccModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyOccModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyOccModule, providers: [
            provideDefaultConfig(defaultOccOpfQuickBuyCartConfig),
            {
                provide: OpfQuickBuyCartAdapter,
                useClass: OccOpfQuickBuyCartAdapter,
            },
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyOccModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        provideDefaultConfig(defaultOccOpfQuickBuyCartConfig),
                        {
                            provide: OpfQuickBuyCartAdapter,
                            useClass: OccOpfQuickBuyCartAdapter,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OccOpfQuickBuyCartAdapter, OpfQuickBuyOccModule, defaultOccOpfQuickBuyCartConfig };
//# sourceMappingURL=spartacus-opf-quick-buy-occ.mjs.map
