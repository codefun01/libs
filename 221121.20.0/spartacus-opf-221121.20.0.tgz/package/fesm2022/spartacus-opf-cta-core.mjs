import * as i0 from '@angular/core';
import { inject, Injectable, NgModule, InjectionToken } from '@angular/core';
import { CommandService, WindowRef, EventService, CurrencyService, LanguageService } from '@spartacus/core';
import { Subject, combineLatest, take, map, tap, merge, filter } from 'rxjs';
import { OpfCtaFacade, OpfCtaEvent, OpfCtaScriptsLocation } from '@spartacus/opf/cta/root';
import { ActiveCartFacade, CartUpdateEntrySuccessEvent, CartAddEntrySuccessEvent, CartRemoveEntrySuccessEvent } from '@spartacus/cart/base/root';
import { OpfGlobalFunctionsFacade, OpfGlobalFunctionsDomain } from '@spartacus/opf/global-functions/root';
import { CurrentProductService } from '@spartacus/storefront';
import { OrderFacade, OrderHistoryFacade } from '@spartacus/order/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCtaAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCtaConnector {
    constructor() {
        this.adapter = inject(OpfCtaAdapter);
    }
    getCtaScripts(opfCtaScriptsRequest) {
        return this.adapter.getCtaScripts(opfCtaScriptsRequest);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCtaService {
    constructor() {
        this.commandService = inject(CommandService);
        this.opfCtaConnector = inject(OpfCtaConnector);
        this._readyForScriptEvent = new Subject();
        this.readyForScriptEvent$ = this._readyForScriptEvent.asObservable();
        this.ctaScriptsCommand = this.commandService.create((payload) => {
            return this.opfCtaConnector.getCtaScripts(payload.opfCtaScriptsRequest);
        });
    }
    getCtaScripts(opfCtaScriptsRequest) {
        return this.ctaScriptsCommand.execute({ opfCtaScriptsRequest });
    }
    emitScriptReadyEvent(scriptIdentifier) {
        this._readyForScriptEvent.next(scriptIdentifier);
    }
    listenScriptReadyEvent() {
        return this.readyForScriptEvent$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const facadeProviders = [
    OpfCtaService,
    {
        provide: OpfCtaFacade,
        useExisting: OpfCtaService,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCtaCoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaCoreModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaCoreModule, providers: [...facadeProviders, OpfCtaConnector] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [...facadeProviders, OpfCtaConnector],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfDynamicCtaService {
    constructor() {
        this.globalFunctionsFacade = inject(OpfGlobalFunctionsFacade);
        this.winRef = inject(WindowRef);
        this.eventService = inject(EventService);
        this.currencyService = inject(CurrencyService);
        this.languageService = inject(LanguageService);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.opfCtaFacade = inject(OpfCtaFacade);
        this.currentProductService = inject(CurrentProductService);
        this.subList = [];
        this.isOnsiteMessagingInit = false;
        this.scriptIdentifiers = [];
    }
    fillCtaRequestforCartPage(scriptLocation, paymentAccountIds) {
        this.isCartPage = true;
        return combineLatest({
            cart: this.activeCartFacade.takeActive(),
            additionalData: this.fillAdditionalData(),
        }).pipe(take(1), map(({ cart, additionalData }) => {
            return {
                paymentAccountIds: paymentAccountIds,
                scriptLocations: [scriptLocation],
                ctaProductItems: cart.entries?.map((entry) => {
                    return {
                        productId: entry.product?.code,
                        quantity: entry.quantity,
                    };
                }),
                additionalData,
            };
        }));
    }
    fillCtaRequestforProductPage(scriptLocation, paymentAccountIds) {
        this.isCartPage = false;
        return combineLatest({
            product: this.currentProductService.getProduct(),
            additionalData: this.fillAdditionalData(),
        }).pipe(take(1), map(({ product, additionalData }) => {
            return {
                ctaProductItems: [{ productId: product?.code, quantity: 1 }],
                paymentAccountIds: paymentAccountIds,
                scriptLocations: [scriptLocation],
                additionalData,
            };
        }));
    }
    fillAdditionalData() {
        return combineLatest({
            language: this.languageService.getActive(),
            currency: this.currencyService.getActive(),
        }).pipe(take(1), map(({ language, currency }) => {
            return [
                {
                    key: 'locale',
                    value: language,
                },
                {
                    key: 'currency',
                    value: currency,
                },
                {
                    key: 'scriptIdentifier',
                    value: this.getNewScriptIdentifier(),
                },
            ];
        }));
    }
    initiateEvents() {
        if (!this.isOnsiteMessagingInit) {
            this.listenScriptReadyEvent();
            this.isCartPage && this.cartChangedListener();
            !this.isCartPage && this.productChangedListener();
            this.isOnsiteMessagingInit = true;
        }
    }
    stopEvents() {
        if (this.isOnsiteMessagingInit) {
            this.subList.forEach((sub) => sub.unsubscribe());
            this.subList = [];
            this.globalFunctionsFacade.unregisterGlobalFunctions(OpfGlobalFunctionsDomain.GLOBAL);
            this.isOnsiteMessagingInit = false;
        }
    }
    getNewScriptIdentifier() {
        this.scriptIdentifiers.push(String(this.scriptIdentifiers.length + 1));
        return String(this.scriptIdentifiers[this.scriptIdentifiers.length - 1]).padStart(4, '0');
    }
    registerScriptReadyEvent() {
        this.globalFunctionsFacade.registerGlobalFunctions({
            paymentSessionId: '',
            domain: OpfGlobalFunctionsDomain.GLOBAL,
        });
    }
    listenScriptReadyEvent() {
        const sub = this.opfCtaFacade.listenScriptReadyEvent().subscribe({
            next: (id) => {
                this.isCartPage && this.dispatchCartEvents([id]);
                !this.isCartPage && this.dispatchProductEvents([id]);
            },
        });
        this.subList.push(sub);
    }
    dispatchCartEvents(scriptIdentifiers) {
        this.activeCartFacade
            .takeActive()
            .pipe(take(1), map((cart) => {
            return { total: cart.totalPrice?.value };
        }), tap((cartTotalPrice) => {
            const window = this.winRef.nativeWindow;
            const dispatchEvent = window?.dispatchEvent;
            if (dispatchEvent) {
                dispatchEvent(new CustomEvent(OpfCtaEvent.OPF_CART_CHANGED, {
                    detail: { cart: cartTotalPrice, scriptIdentifiers },
                }));
            }
        }))
            .subscribe();
    }
    dispatchProductEvents(scriptIdentifiers, quantity = 1) {
        this.currentProductService
            .getProduct()
            .pipe(take(1), map((product) => {
            return [
                {
                    price: {
                        sellingPrice: product?.price?.value,
                    },
                    quantity, // hard-coded until 'pdp counter change' event gets implemented
                },
            ];
        }), tap((productInfo) => {
            const window = this.winRef.nativeWindow;
            const dispatchEvent = window?.dispatchEvent;
            if (dispatchEvent) {
                dispatchEvent(new CustomEvent(OpfCtaEvent.OPF_PRODUCT_AMOUNT_CHANGED, {
                    detail: { productInfo, scriptIdentifiers },
                }));
            }
        }))
            .subscribe();
    }
    productChangedListener() {
        //// need event listener detecting 'pdp counter changed' event and get its qty value.
    }
    cartChangedListener() {
        const sub = merge(this.eventService.get(CartUpdateEntrySuccessEvent), this.eventService.get(CartAddEntrySuccessEvent), this.eventService.get(CartRemoveEntrySuccessEvent)).subscribe({
            next: () => {
                this.dispatchCartEvents(this.scriptIdentifiers);
            },
        });
        this.subList.push(sub);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfDynamicCtaService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfDynamicCtaService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfDynamicCtaService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfStaticCtaService {
    constructor() {
        this.orderDetailsService = inject(OrderFacade);
        this.orderHistoryService = inject(OrderHistoryFacade);
    }
    fillCtaRequestforPagesWithOrder(scriptLocation) {
        return this.getOrderDetails(scriptLocation).pipe(map((order) => {
            if (!order?.paymentInfo?.id) {
                throw new Error('OrderPaymentInfoId missing');
            }
            const opfCtaScriptsRequest = {
                cartId: order?.paymentInfo?.id,
                ctaProductItems: this.getProductItems(order),
                scriptLocations: [scriptLocation],
            };
            return opfCtaScriptsRequest;
        }));
    }
    getOrderDetails(scriptsLocation) {
        const order$ = scriptsLocation === OpfCtaScriptsLocation.ORDER_CONFIRMATION_PAYMENT_GUIDE
            ? this.orderDetailsService.getOrderDetails()
            : this.orderHistoryService.getOrderDetails();
        return order$.pipe(filter((order) => !!order?.entries));
    }
    getProductItems(order) {
        return order.entries
            .filter((item) => {
            return !!item?.product?.code && !!item?.quantity;
        })
            .map((item) => {
            return {
                productId: item.product?.code,
                quantity: item.quantity,
            };
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfStaticCtaService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfStaticCtaService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfStaticCtaService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_CTA_SCRIPTS_NORMALIZER = new InjectionToken('OpfCtaScriptsNormalizer');

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OPF_CTA_SCRIPTS_NORMALIZER, OpfCtaAdapter, OpfCtaConnector, OpfCtaCoreModule, OpfCtaService, OpfDynamicCtaService, OpfStaticCtaService };
//# sourceMappingURL=spartacus-opf-cta-core.mjs.map
