import * as i0 from '@angular/core';
import { inject, Injectable, NgModule, InjectionToken } from '@angular/core';
import { CartItemQuantityService, CartAccessCodeFacade, ActiveCartFacade, CartGuestUserFacade, MultiCartFacade } from '@spartacus/cart/base/root';
import { map, switchMap as switchMap$1, take as take$1, filter as filter$1, tap, skip } from 'rxjs/operators';
import { CommandService, UserIdService, LoggerService, tryNormalizeHttpError, backOff, DEFAULT_AUTHORIZATION_ERROR_RETRIES_COUNT, isAuthorizationError, UserAddressService, AuthService, RoutingService, UnifiedInjector, GlobalMessageService, GlobalMessageType, BaseSiteService } from '@spartacus/core';
import { combineLatest, filter, switchMap, take, concatMap, catchError, of, throwError, defer } from 'rxjs';
import { OpfQuickBuyFacade, OpfQuickBuySingleProductCartOptionsFacade, OpfQuickBuyDeliveryType, OPF_QUICK_BUY_DEFAULT_MERCHANT_NAME, OpfQuickBuyLocation } from '@spartacus/opf/quick-buy/root';
import { CheckoutDeliveryModesFacade, CheckoutDeliveryAddressFacade, CheckoutBillingAddressFacade } from '@spartacus/checkout/base/root';
import { OpfGlobalMessageService } from '@spartacus/opf/base/root';
import { getCartIdByUserId } from '@spartacus/cart/base/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyCartAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyCartConnector {
    constructor() {
        this.adapter = inject(OpfQuickBuyCartAdapter);
    }
    createDeliveryAddress(userId, cartId, address) {
        return this.adapter.createDeliveryAddress(userId, cartId, address);
    }
    setBillingAddress(userId, cartId, address) {
        return this.adapter.setBillingAddress(userId, cartId, address);
    }
    getSupportedDeliveryModes(userId, cartId) {
        return this.adapter.getSupportedDeliveryModes(userId, cartId);
    }
    setDeliveryMode(userId, cartId, deliveryModeId) {
        return this.adapter.setDeliveryMode(userId, cartId, deliveryModeId);
    }
    getSelectedDeliveryMode(userId, cartId) {
        return this.adapter.getSelectedDeliveryMode(userId, cartId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyCartConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyCartConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyCartConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyConnector {
    constructor() {
        this.adapter = inject(OpfQuickBuyAdapter);
    }
    getApplePayWebSession(applePayWebRequest, accessCode) {
        return this.adapter.getApplePayWebSession(applePayWebRequest, accessCode);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyDefaultSingleProductService {
    constructor() {
        this.cartItemQuantityService = inject(CartItemQuantityService);
    }
    getSingleProductCartOptions(_productCode) {
        return this.cartItemQuantityService
            .getQuantity()
            .pipe(map((quantity) => ({ quantity })));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyDefaultSingleProductService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyDefaultSingleProductService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyDefaultSingleProductService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyService {
    constructor() {
        this.commandService = inject(CommandService);
        this.opfQuickBuyConnector = inject(OpfQuickBuyConnector);
        this.cartAccessCodeFacade = inject(CartAccessCodeFacade);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.userIdService = inject(UserIdService);
        this.logger = inject(LoggerService);
        this.applePaySessionCommand = this.commandService.create((payload) => {
            return combineLatest([
                this.userIdService.getUserId(),
                this.activeCartFacade.getActiveCartId(),
            ]).pipe(filter(([userId, activeCartId]) => !!activeCartId && !!userId), switchMap(([userId, activeCartId]) => {
                return this.cartAccessCodeFacade.getCartAccessCode(userId, activeCartId);
            }), filter((response) => Boolean(response?.accessCode)), take(1), concatMap(({ accessCode }) => {
                return this.opfQuickBuyConnector.getApplePayWebSession(payload.applePayWebSessionRequest, accessCode);
            }), catchError((error) => {
                throw tryNormalizeHttpError(error, this.logger);
            }), backOff({
                shouldRetry: isAuthorizationError,
                maxTries: DEFAULT_AUTHORIZATION_ERROR_RETRIES_COUNT,
            }));
        });
    }
    getApplePayWebSession(applePayWebSessionRequest) {
        return this.applePaySessionCommand.execute({ applePayWebSessionRequest });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const facadeProviders = [
    OpfQuickBuyService,
    {
        provide: OpfQuickBuyFacade,
        useExisting: OpfQuickBuyService,
    },
    OpfQuickBuyDefaultSingleProductService,
    {
        provide: OpfQuickBuySingleProductCartOptionsFacade,
        useExisting: OpfQuickBuyDefaultSingleProductService,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyCoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyCoreModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyCoreModule, providers: [
            ...facadeProviders,
            OpfQuickBuyConnector,
            OpfQuickBuyCartConnector,
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [],
                    providers: [
                        ...facadeProviders,
                        OpfQuickBuyConnector,
                        OpfQuickBuyCartConnector,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyActiveCartTransactionService {
    constructor() {
        this.activeCartFacade = inject(ActiveCartFacade);
        this.checkoutDeliveryModesFacade = inject(CheckoutDeliveryModesFacade);
        this.checkoutDeliveryAddressFacade = inject(CheckoutDeliveryAddressFacade);
        this.checkoutBillingAddressFacade = inject(CheckoutBillingAddressFacade);
        this.userAddressService = inject(UserAddressService);
        this.opfGlobalMessageService = inject(OpfGlobalMessageService);
        this.cartGuestUserFacade = inject(CartGuestUserFacade);
        this.authService = inject(AuthService);
        this.userIdService = inject(UserIdService);
        this.multiCartFacade = inject(MultiCartFacade);
    }
    prepareTransactionCart() {
        return this.handleCartGuestUser().pipe(switchMap$1(() => this.getCurrentCart()));
    }
    getTransactionDeliveryType() {
        return this.activeCartFacade.hasDeliveryItems().pipe(take$1(1), map((hasDeliveryItems) => hasDeliveryItems
            ? OpfQuickBuyDeliveryType.SHIPPING
            : OpfQuickBuyDeliveryType.PICKUP));
    }
    getTransactionDeliveryInfo() {
        const deliveryTypeObservable = this.getTransactionDeliveryType().pipe(map((deliveryType) => {
            return {
                type: deliveryType,
            };
        }));
        return deliveryTypeObservable.pipe(take$1(1));
    }
    checkStableCart() {
        return this.activeCartFacade.isStable().pipe(filter$1((isStable) => !!isStable), take$1(1));
    }
    getSupportedDeliveryModes() {
        return this.checkoutDeliveryModesFacade.getSupportedDeliveryModes();
    }
    setDeliveryAddress(address) {
        this.opfGlobalMessageService.disableGlobalMessage([
            'addressForm.userAddressAddSuccess',
        ]);
        return this.checkoutDeliveryAddressFacade.createAndSetAddress(address).pipe(switchMap$1(() => this.checkStableCart()), switchMap$1(() => this.getDeliveryAddress().pipe(map((addr) => addr?.id ?? ''))));
    }
    setBillingAddress(address) {
        return this.checkoutBillingAddressFacade
            .setBillingAddress(address)
            .pipe(switchMap$1(() => this.checkStableCart()));
    }
    getDeliveryAddress() {
        return this.checkoutDeliveryAddressFacade.getDeliveryAddressState().pipe(filter$1((state) => !state.loading), take$1(1), map((state) => {
            return state.data;
        }));
    }
    getCurrentCart() {
        return this.activeCartFacade.takeActive();
    }
    getCurrentCartId() {
        return this.activeCartFacade.takeActiveCartId();
    }
    getCurrentCartTotalPrice() {
        return this.activeCartFacade
            .takeActive()
            .pipe(map((cart) => cart.totalPrice?.value));
    }
    setDeliveryMode(mode) {
        return this.checkoutDeliveryModesFacade.setDeliveryMode(mode).pipe(switchMap$1(() => this.checkoutDeliveryModesFacade.getSelectedDeliveryModeState()), filter$1((state) => !state.error && !state.loading), take$1(1), map((state) => state.data));
    }
    getSelectedDeliveryMode() {
        return this.checkoutDeliveryModesFacade.getSelectedDeliveryModeState().pipe(filter$1((state) => !state.error && !state.loading), take$1(1), map((state) => state.data));
    }
    deleteUserAddresses(addrIds) {
        this.authService
            .isUserLoggedIn()
            .pipe(take$1(1))
            .subscribe((isUserLoggedIn) => {
            if (isUserLoggedIn) {
                this.opfGlobalMessageService.disableGlobalMessage([
                    'addressForm.userAddressDeleteSuccess',
                ]);
                addrIds.forEach((addrId) => {
                    this.userAddressService.deleteUserAddress(addrId);
                });
            }
        });
    }
    createCartGuestUser() {
        return combineLatest([
            this.userIdService.takeUserId(),
            this.activeCartFacade.takeActiveCartId(),
        ]).pipe(take$1(1), switchMap$1(([userId, cartId]) => {
            return this.cartGuestUserFacade
                .createCartGuestUser(userId, cartId)
                .pipe(tap(() => this.multiCartFacade.reloadCart(cartId)), map(() => true));
        }));
    }
    updateCartGuestUser(cartGuestUser) {
        return combineLatest([
            this.userIdService.takeUserId(),
            this.activeCartFacade.takeActiveCartId(),
        ]).pipe(take$1(1), switchMap$1(([userId, cartId]) => {
            return this.cartGuestUserFacade
                .updateCartGuestUser(userId, cartId, cartGuestUser)
                .pipe(tap(() => this.multiCartFacade.reloadCart(cartId)), map(() => true));
        }));
    }
    updateCartGuestUserEmail(email) {
        return this.activeCartFacade.isGuestCart().pipe(take$1(1), switchMap$1((isGuestCart) => {
            return isGuestCart && email
                ? this.updateCartGuestUser({ email })
                : of(false);
        }));
    }
    handleCartGuestUser() {
        return combineLatest([
            this.authService.isUserLoggedIn(),
            this.activeCartFacade.isGuestCart(),
        ]).pipe(take$1(1), switchMap$1(([isUserLoggedIn, isGuestCart]) => {
            if (isUserLoggedIn || isGuestCart) {
                return of(true);
            }
            return this.createCartGuestUser();
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyActiveCartTransactionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyActiveCartTransactionService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyActiveCartTransactionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const SINGLE_PRODUCT_CART_NOT_INITIALIZED_ERROR = 'Single product cart is not initialized';
class OpfQuickBuySingleProductTransactionService {
    constructor() {
        this.multiCartFacade = inject(MultiCartFacade);
        this.userIdService = inject(UserIdService);
        this.routingService = inject(RoutingService);
        this.unifiedInjector = inject(UnifiedInjector);
        this.globalMessageService = inject(GlobalMessageService);
        this.cartGuestUserFacade = inject(CartGuestUserFacade);
        this.authService = inject(AuthService);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.singleProductCartOptions = inject(OpfQuickBuySingleProductCartOptionsFacade);
    }
    getTransactionDeliveryType() {
        if (!this.cartId) {
            return throwError(() => new Error(SINGLE_PRODUCT_CART_NOT_INITIALIZED_ERROR));
        }
        return this.waitForStableCart(this.cartId).pipe(map((cart) => this.hasDeliveryItems(cart)
            ? OpfQuickBuyDeliveryType.SHIPPING
            : OpfQuickBuyDeliveryType.PICKUP));
    }
    getTransactionDeliveryInfo() {
        return this.getTransactionDeliveryType().pipe(map((deliveryType) => ({
            type: deliveryType,
        })), take$1(1));
    }
    checkStableCart() {
        if (!this.cartId) {
            return throwError(() => new Error(SINGLE_PRODUCT_CART_NOT_INITIALIZED_ERROR));
        }
        return this.multiCartFacade.isStable(this.cartId).pipe(filter$1((isStable) => !!isStable), take$1(1));
    }
    getSupportedDeliveryModes() {
        return this.getCartContext().pipe(switchMap$1(({ userId, cartId }) => this.getCartConnector().pipe(switchMap$1((connector) => connector.getSupportedDeliveryModes(userId, cartId)))));
    }
    setDeliveryAddress(address) {
        return this.getCartContext().pipe(switchMap$1(({ userId, cartId }) => this.createDeliveryAddressAndReload(userId, cartId, address)));
    }
    setBillingAddress(address) {
        return this.getCartContext().pipe(switchMap$1(({ userId, cartId }) => this.getCartConnector().pipe(switchMap$1((connector) => connector.setBillingAddress(userId, cartId, address).pipe(switchMap$1(() => this.reloadCartAndWait(userId, cartId)), map(() => true))))));
    }
    getDeliveryAddress() {
        return this.getCart().pipe(map((cart) => cart.deliveryAddress));
    }
    getCurrentCart() {
        return this.getCart();
    }
    getCurrentCartId() {
        if (!this.cartId) {
            return throwError(() => new Error(SINGLE_PRODUCT_CART_NOT_INITIALIZED_ERROR));
        }
        return of(this.cartId);
    }
    getCurrentCartTotalPrice() {
        return this.getCart().pipe(map((cart) => cart.totalPrice?.value));
    }
    setDeliveryMode(mode) {
        return this.getCartContext().pipe(switchMap$1(({ userId, cartId }) => this.getCartConnector().pipe(switchMap$1((connector) => connector.setDeliveryMode(userId, cartId, mode).pipe(switchMap$1(() => this.reloadCartAndWait(userId, cartId)), switchMap$1(() => connector.getSelectedDeliveryMode(userId, cartId)))))));
    }
    getSelectedDeliveryMode() {
        return this.getCartContext().pipe(switchMap$1(({ userId, cartId }) => this.getCartConnector().pipe(switchMap$1((connector) => connector.getSelectedDeliveryMode(userId, cartId)))));
    }
    prepareTransactionCart() {
        return this.createSingleProductCart().pipe(switchMap$1(() => this.handleCartGuestUser()), switchMap$1(() => this.getCurrentCart()));
    }
    createCartGuestUser() {
        return this.getCartContext().pipe(switchMap$1(({ userId, cartId }) => this.cartGuestUserFacade.createCartGuestUser(userId, cartId).pipe(tap(() => this.multiCartFacade.reloadCart(cartId)), map(() => true))));
    }
    updateCartGuestUser(cartGuestUser) {
        return this.getCartContext().pipe(switchMap$1(({ userId, cartId }) => this.cartGuestUserFacade
            .updateCartGuestUser(userId, cartId, cartGuestUser)
            .pipe(tap(() => this.multiCartFacade.reloadCart(cartId)), map(() => true))));
    }
    updateCartGuestUserEmail(email) {
        return this.isGuestCart().pipe(take$1(1), switchMap$1((isGuestCart) => {
            return isGuestCart && email
                ? this.updateCartGuestUser({ email })
                : of(false);
        }));
    }
    handleCartGuestUser() {
        if (!this.cartId) {
            return of(true);
        }
        return combineLatest([
            this.authService.isUserLoggedIn(),
            this.isGuestCart(),
        ]).pipe(take$1(1), switchMap$1(([isUserLoggedIn, isGuestCart]) => {
            if (isUserLoggedIn || isGuestCart) {
                return of(true);
            }
            return this.createCartGuestUser();
        }));
    }
    createSingleProductCart() {
        return this.getProductCodeFromRouting().pipe(switchMap$1((productCode) => this.createCartForProductCode(productCode)));
    }
    createDeliveryAddressAndReload(userId, cartId, address) {
        return this.getCartConnector().pipe(switchMap$1((connector) => connector.createDeliveryAddress(userId, cartId, address)), switchMap$1((createdAddress) => this.mapReloadedCartToAddressId(userId, cartId, createdAddress)));
    }
    mapReloadedCartToAddressId(userId, cartId, createdAddress) {
        return this.reloadCartAndWait(userId, cartId).pipe(map(() => createdAddress.id ?? ''));
    }
    createCartForProductCode(productCode) {
        if (!productCode) {
            return throwError(() => new Error('Product code not found in routing'));
        }
        return this.singleProductCartOptions
            .getSingleProductCartOptions(productCode)
            .pipe(take$1(1), switchMap$1(({ quantity, pickupStore }) => this.createCartWithProductEntry(productCode, quantity, pickupStore)));
    }
    createCartWithProductEntry(productCode, quantity, pickupStore) {
        return this.userIdService.takeUserId().pipe(take$1(1), switchMap$1((userId) => this.initializeCartWithEntry(userId, productCode, quantity, pickupStore)));
    }
    initializeCartWithEntry(userId, productCode, quantity, pickupStore) {
        return this.multiCartFacade
            .createCart({
            userId,
            extraData: { active: false },
        })
            .pipe(
        // `createCart` initially replays the previously created (NEW_CREATED)
        // cart from the store. Skip it so we operate on the freshly created
        // cart instead of adding entries to the previous quick buy cart.
        filter$1((cart) => this.isNewlyCreatedSingleProductCart(cart, userId)), take$1(1), switchMap$1((cart) => this.addProductAndWaitForStableCart(userId, cart, productCode, quantity, pickupStore)));
    }
    isNewlyCreatedSingleProductCart(cart, userId) {
        return getCartIdByUserId(cart, userId) !== this.cartId;
    }
    addProductAndWaitForStableCart(userId, cart, productCode, quantity, pickupStore) {
        const cartId = getCartIdByUserId(cart, userId);
        this.userId = userId;
        this.cartId = cartId;
        this.multiCartFacade.addEntry(userId, cartId, productCode, quantity, pickupStore);
        return this.waitForStableCart(cartId).pipe(tap((stableCart) => this.notifyIfQuantityReduced(stableCart, productCode, quantity)));
    }
    getCartConnector() {
        return this.unifiedInjector.get(OpfQuickBuyCartConnector).pipe(take$1(1));
    }
    getCartContext() {
        if (!this.userId || !this.cartId) {
            return throwError(() => new Error(SINGLE_PRODUCT_CART_NOT_INITIALIZED_ERROR));
        }
        return of({ userId: this.userId, cartId: this.cartId });
    }
    getCart() {
        if (!this.cartId) {
            return throwError(() => new Error(SINGLE_PRODUCT_CART_NOT_INITIALIZED_ERROR));
        }
        return this.multiCartFacade.getCart(this.cartId).pipe(take$1(1));
    }
    isGuestCart() {
        return this.getCart().pipe(switchMap$1((cart) => this.activeCartFacade.isGuestCart(cart)));
    }
    hasDeliveryItems(cart) {
        return cart?.deliveryItemsQuantity
            ? cart?.deliveryItemsQuantity > 0
            : false;
    }
    getProductCodeFromRouting() {
        return this.routingService.getRouterState().pipe(take$1(1), map((routerState) => routerState?.state?.params?.productCode));
    }
    waitForStableCart(cartId) {
        return this.multiCartFacade.isStable(cartId).pipe(filter$1((stable) => stable), take$1(1), switchMap$1(() => this.multiCartFacade.getCart(cartId).pipe(take$1(1))), filter$1((cart) => !!cart));
    }
    /**
     * Informs the user via a global message when the quantity actually added to
     * the single-product cart is lower than requested (e.g. due to insufficient
     * stock). Quick buy skips the standard add-to-cart dialog, so without this
     * the reduction would go unnoticed.
     */
    notifyIfQuantityReduced(cart, productCode, requestedQuantity) {
        const addedQuantity = cart.entries?.find((entry) => entry.product?.code === productCode)?.quantity;
        if (addedQuantity != null && addedQuantity < requestedQuantity) {
            this.globalMessageService.add({
                key: 'validation.lowStock',
                params: { quantity: addedQuantity },
            }, GlobalMessageType.MSG_TYPE_WARNING);
        }
    }
    reloadCartAndWait(userId, cartId) {
        return defer(() => {
            const cartReloaded$ = this.multiCartFacade.getCartEntity(cartId).pipe(skip(1), filter$1((entity) => !entity.loading && entity.processesCount === 0 && !!entity.value), take$1(1), map((entity) => entity.value));
            this.multiCartFacade.loadCart({ userId, cartId });
            return cartReloaded$;
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuySingleProductTransactionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuySingleProductTransactionService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuySingleProductTransactionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyTransactionService {
    constructor() {
        this.routingService = inject(RoutingService);
        this.baseSiteService = inject(BaseSiteService);
        this.activeCartTransactionService = inject(OpfQuickBuyActiveCartTransactionService);
        this.singleProductTransactionService = inject(OpfQuickBuySingleProductTransactionService);
    }
    getTransactionLocationContext() {
        return this.routingService.getRouterState().pipe(take$1(1), map((routerState) => routerState?.state?.semanticRoute?.toLocaleUpperCase()), tap((context) => {
            this.transactionContext = context;
        }));
    }
    getMerchantName() {
        return this.baseSiteService.get().pipe(take$1(1), map((baseSite) => baseSite?.name ?? OPF_QUICK_BUY_DEFAULT_MERCHANT_NAME));
    }
    prepareTransactionCart() {
        return this.delegate(() => this.singleProductTransactionService.prepareTransactionCart(), () => this.activeCartTransactionService.prepareTransactionCart());
    }
    getTransactionDeliveryType() {
        return this.delegate(() => this.singleProductTransactionService.getTransactionDeliveryType(), () => this.activeCartTransactionService.getTransactionDeliveryType());
    }
    getTransactionDeliveryInfo() {
        return this.delegate(() => this.singleProductTransactionService.getTransactionDeliveryInfo(), () => this.activeCartTransactionService.getTransactionDeliveryInfo());
    }
    checkStableCart() {
        return this.delegate(() => this.singleProductTransactionService.checkStableCart(), () => this.activeCartTransactionService.checkStableCart());
    }
    getSupportedDeliveryModes() {
        return this.delegate(() => this.singleProductTransactionService.getSupportedDeliveryModes(), () => this.activeCartTransactionService.getSupportedDeliveryModes());
    }
    setDeliveryAddress(address) {
        return this.delegate(() => this.singleProductTransactionService.setDeliveryAddress(address), () => this.activeCartTransactionService.setDeliveryAddress(address));
    }
    setBillingAddress(address) {
        return this.delegate(() => this.singleProductTransactionService.setBillingAddress(address), () => this.activeCartTransactionService.setBillingAddress(address));
    }
    getDeliveryAddress() {
        return this.delegate(() => this.singleProductTransactionService.getDeliveryAddress(), () => this.activeCartTransactionService.getDeliveryAddress());
    }
    getCurrentCart() {
        return this.delegate(() => this.singleProductTransactionService.getCurrentCart(), () => this.activeCartTransactionService.getCurrentCart());
    }
    getCurrentCartId() {
        return this.delegate(() => this.singleProductTransactionService.getCurrentCartId(), () => this.activeCartTransactionService.getCurrentCartId());
    }
    getCurrentCartTotalPrice() {
        return this.delegate(() => this.singleProductTransactionService.getCurrentCartTotalPrice(), () => this.activeCartTransactionService.getCurrentCartTotalPrice());
    }
    setDeliveryMode(mode) {
        return this.delegate(() => this.singleProductTransactionService.setDeliveryMode(mode), () => this.activeCartTransactionService.setDeliveryMode(mode));
    }
    getSelectedDeliveryMode() {
        return this.delegate(() => this.singleProductTransactionService.getSelectedDeliveryMode(), () => this.activeCartTransactionService.getSelectedDeliveryMode());
    }
    deleteUserAddresses(addrIds) {
        this.activeCartTransactionService.deleteUserAddresses(addrIds);
    }
    createCartGuestUser() {
        return this.delegate(() => this.singleProductTransactionService.createCartGuestUser(), () => this.activeCartTransactionService.createCartGuestUser());
    }
    updateCartGuestUserEmail(email) {
        return this.delegate(() => this.singleProductTransactionService.updateCartGuestUserEmail(email), () => this.activeCartTransactionService.updateCartGuestUserEmail(email));
    }
    handleCartGuestUser() {
        return this.delegate(() => this.singleProductTransactionService.handleCartGuestUser(), () => this.activeCartTransactionService.handleCartGuestUser());
    }
    resolveContext() {
        if (this.transactionContext) {
            return of(this.transactionContext);
        }
        return this.getTransactionLocationContext();
    }
    isSingleProductContext(context) {
        return context === OpfQuickBuyLocation.PRODUCT;
    }
    delegate(singleProductFn, activeCartFn) {
        return this.resolveContext().pipe(take$1(1), switchMap$1((context) => this.isSingleProductContext(context)
            ? singleProductFn()
            : activeCartFn()));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyTransactionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyTransactionService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyTransactionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_APPLE_PAY_WEB_SESSION_NORMALIZER = new InjectionToken('OpfApplePayWebSession');

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OPF_APPLE_PAY_WEB_SESSION_NORMALIZER, OpfQuickBuyActiveCartTransactionService, OpfQuickBuyAdapter, OpfQuickBuyCartAdapter, OpfQuickBuyCartConnector, OpfQuickBuyConnector, OpfQuickBuyCoreModule, OpfQuickBuyDefaultSingleProductService, OpfQuickBuyService, OpfQuickBuySingleProductTransactionService, OpfQuickBuyTransactionService };
//# sourceMappingURL=spartacus-opf-quick-buy-core.mjs.map
