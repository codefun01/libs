import * as i0 from '@angular/core';
import { Injectable, inject, Input, ChangeDetectionStrategy, Component, NgModule, ViewContainerRef, DestroyRef, signal, Optional } from '@angular/core';
import { facadeFactory, GlobalMessageService, GlobalMessageType, TranslatePipe, RoutingService, I18nModule, provideDefaultConfig, FeatureToggles, TranslationService, AuthGuard, provideDefaultConfigFactory } from '@spartacus/core';
import { OpfMetadataStoreService } from '@spartacus/opf/base/root';
import { OpfPaymentEventsService } from '@spartacus/opf/payment/root';
import { ActiveCartFacade, CartOutlets, CART_NORMALIZER } from '@spartacus/cart/base/root';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { OrderFacade, ORDER_NORMALIZER } from '@spartacus/order/root';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i3 from '@angular/forms';
import { Validators, UntypedFormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i1$1 from '@spartacus/storefront';
import { OutletModule, LaunchDialogService, LAUNCH_CALLER, DIALOG_TYPE, SpinnerComponent, FormErrorsComponent, provideOutlet, OutletPosition, CardComponent } from '@spartacus/storefront';
import { isObservable, map, Subscription, BehaviorSubject, combineLatest, throwError } from 'rxjs';
import { take, finalize, map as map$1, shareReplay, catchError } from 'rxjs/operators';
import * as i1 from '@angular/common';
import { NgIf, NgFor, CommonModule, AsyncPipe } from '@angular/common';
import { OPF_PAYMENT_AND_REVIEW_SEMANTIC_ROUTE, OpfCheckoutOutlets } from '@spartacus/opf/checkout/root';
import { AppliedCouponsComponent } from '@spartacus/cart/base/components';
import { CheckoutStepService } from '@spartacus/checkout/base/components';
import { Router } from '@angular/router';
import { OrderConfirmationGuard, OrderDetailsService } from '@spartacus/order/components';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_GIFT_CARD_FEATURE = 'opfGiftCard';

class OpfGiftCardFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: OpfGiftCardFacade,
            feature: OPF_GIFT_CARD_FEATURE,
            methods: [
                'getGiftCardConfiguration',
                'isGiftCardEnabled',
                'isGiftCardCoveredTotalAmount',
                'applyGiftCard',
                'removeGiftCard',
            ],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: OpfGiftCardFacade,
                        feature: OPF_GIFT_CARD_FEATURE,
                        methods: [
                            'getGiftCardConfiguration',
                            'isGiftCardEnabled',
                            'isGiftCardCoveredTotalAmount',
                            'applyGiftCard',
                            'removeGiftCard',
                        ],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOpfGiftCardCartConfig = {
    cart: {
        validation: {
            enabled: true,
        },
        selectiveCart: {
            enabled: false,
        },
        showRealTimeStockInPDP: {
            enabled: false,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const giftCardCartEndpoints = {
    carts: 'users/${userId}/carts?fields=carts(DEFAULT,sapGiftCards(FULL,balance(value,formattedValue),remainingBalance(value,formattedValue), appliedAmount(value,formattedValue)),sapGiftCardSummary(FULL,totalAppliedAmount(value,formattedValue),totalRemainingBalance(value,formattedValue), totalBalance(value,formattedValue)),potentialProductPromotions,appliedProductPromotions,potentialOrderPromotions,appliedOrderPromotions,entries(totalPrice(formattedValue),product(images(FULL),stock(FULL)),basePrice(formattedValue,value),updateable),totalPrice(formattedValue),totalItems,totalPriceWithTax(formattedValue),totalDiscounts(value,formattedValue),subTotal(formattedValue),totalUnitCount,deliveryItemsQuantity,deliveryCost(formattedValue),totalTax(formattedValue, value),pickupItemsQuantity,net,appliedVouchers,productDiscounts(formattedValue),user,saveTime,name,description,_availableOperations)',
    cart: 'users/${userId}/carts/${cartId}?fields=DEFAULT,sapGiftCards(FULL,balance(value,formattedValue),remainingBalance(value,formattedValue), appliedAmount(value,formattedValue)),sapGiftCardSummary(FULL,totalAppliedAmount(value,formattedValue),totalRemainingBalance(value,formattedValue), totalBalance(value,formattedValue)),potentialProductPromotions,appliedProductPromotions,potentialOrderPromotions,appliedOrderPromotions,entries(totalPrice(formattedValue),product(images(FULL),stock(FULL)),basePrice(formattedValue,value),updateable),totalPrice(formattedValue),totalItems,totalPriceWithTax(formattedValue),totalDiscounts(value,formattedValue),subTotal(formattedValue),totalUnitCount,deliveryItemsQuantity,deliveryCost(formattedValue),totalTax(formattedValue, value),pickupItemsQuantity,net,appliedVouchers,productDiscounts(formattedValue),user,saveTime,name,description,_availableOperations',
};
const defaultOccOpfGiftCardCartEndpointsConfig = {
    backend: {
        occ: {
            endpoints: {
                ...giftCardCartEndpoints,
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const giftCardOrderEndpoints = {
    orderDetail: 'users/${userId}/orders/${orderId}?fields=FULL,sapGiftCardSummary(FULL,totalAppliedAmount(value,formattedValue),totalRemainingBalance(value,formattedValue),totalBalance(value,formattedValue))',
    placePaymentAuthorizedOrder: 'users/${userId}/orders/paymentAuthorizedOrderPlacement?fields=FULL,sapGiftCardSummary(FULL,totalAppliedAmount(value,formattedValue),totalRemainingBalance(value,formattedValue),totalBalance(value,formattedValue))',
};
const defaultOccOpfGiftCardOrderEndpointsConfig = {
    backend: {
        occ: {
            endpoints: {
                ...giftCardOrderEndpoints,
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardAppliedComponent {
    constructor() {
        this.globalMessageService = inject(GlobalMessageService);
        this.giftCardFacade = inject(OpfGiftCardFacade);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.opfPaymentEventsService = inject(OpfPaymentEventsService);
    }
    removeGiftCard(giftCardId) {
        this.giftCardFacade.removeGiftCard(giftCardId).subscribe({
            next: () => {
                this.activeCartFacade.reloadActiveCart();
                this.globalMessageService.add({ key: 'opfGiftCard.removedSuccessfully' }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
                this.opfPaymentEventsService.emitReinitiatePaymentEvent();
                this.opfPaymentEventsService.emitRefreshActiveConfigurationsEvent();
            },
            error: (error) => {
                const message = error.details?.[0]?.message;
                this.globalMessageService.add({ raw: message }, GlobalMessageType.MSG_TYPE_ERROR);
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardAppliedComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfGiftCardAppliedComponent, isStandalone: true, selector: "cx-opf-gift-card-applied", inputs: { opfGiftCards: "opfGiftCards" }, ngImport: i0, template: "<div class=\"cx-opf-gift-card-applied-list\" *ngIf=\"opfGiftCards.length > 0\">\n  <div class=\"cx-opf-gift-card-applied-item\" *ngFor=\"let card of opfGiftCards\">\n    <div class=\"cx-opf-gift-card-applied-content\">\n      <div class=\"cx-opf-gift-card-applied-header\">\n        <p class=\"cx-opf-gift-card-applied-number\">{{ card.maskedNumber }}</p>\n        <button\n          type=\"button\"\n          class=\"btn btn-tertiary cx-opf-gift-card-applied-remove-btn\"\n          [attr.aria-label]=\"'opfGiftCard.remove' | cxTranslate\"\n          (click)=\"removeGiftCard(card.id)\"\n        >\n          {{ 'opfGiftCard.remove' | cxTranslate }}\n        </button>\n      </div>\n\n      <div class=\"cx-opf-gift-card-applied-balance\">\n        <p class=\"cx-opf-gift-card-applied-balance-info\">\n          {{ 'opfGiftCard.currentBalance' | cxTranslate }}:\n          {{ card.balance?.formattedValue }}.\n          {{ 'opfGiftCard.balanceAfterPurchase' | cxTranslate }}:\n          {{ card.remainingBalance?.formattedValue }}\n        </p>\n      </div>\n    </div>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: OutletModule }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardAppliedComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-gift-card-applied', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, NgFor, CommonModule, TranslatePipe, OutletModule], template: "<div class=\"cx-opf-gift-card-applied-list\" *ngIf=\"opfGiftCards.length > 0\">\n  <div class=\"cx-opf-gift-card-applied-item\" *ngFor=\"let card of opfGiftCards\">\n    <div class=\"cx-opf-gift-card-applied-content\">\n      <div class=\"cx-opf-gift-card-applied-header\">\n        <p class=\"cx-opf-gift-card-applied-number\">{{ card.maskedNumber }}</p>\n        <button\n          type=\"button\"\n          class=\"btn btn-tertiary cx-opf-gift-card-applied-remove-btn\"\n          [attr.aria-label]=\"'opfGiftCard.remove' | cxTranslate\"\n          (click)=\"removeGiftCard(card.id)\"\n        >\n          {{ 'opfGiftCard.remove' | cxTranslate }}\n        </button>\n      </div>\n\n      <div class=\"cx-opf-gift-card-applied-balance\">\n        <p class=\"cx-opf-gift-card-applied-balance-info\">\n          {{ 'opfGiftCard.currentBalance' | cxTranslate }}:\n          {{ card.balance?.formattedValue }}.\n          {{ 'opfGiftCard.balanceAfterPurchase' | cxTranslate }}:\n          {{ card.remainingBalance?.formattedValue }}\n        </p>\n      </div>\n    </div>\n  </div>\n</div>\n" }]
        }], propDecorators: { opfGiftCards: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardAppliedModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardAppliedModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardAppliedModule, imports: [OpfGiftCardAppliedComponent], exports: [OpfGiftCardAppliedComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardAppliedModule, imports: [OpfGiftCardAppliedComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardAppliedModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OpfGiftCardAppliedComponent],
                    exports: [OpfGiftCardAppliedComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardCheckoutPlaceOrderComponent {
    constructor() {
        this.activeCartFacade = inject(ActiveCartFacade);
        this.globalMessageService = inject(GlobalMessageService);
        this.opfPaymentEventsService = inject(OpfPaymentEventsService);
        this.orderFacade = inject(OrderFacade);
        this.routingService = inject(RoutingService);
        this.launchDialogService = inject(LaunchDialogService);
        this.vcr = inject(ViewContainerRef);
        this.termsAndConditionsChecked = true;
        this.isPlacingOrder = false;
    }
    ngOnInit() {
        this.cart$ = this.activeCartFacade.getActive();
    }
    placeOrderWithGiftCard() {
        if (!this.termsAndConditionsChecked || this.isPlacingOrder) {
            return;
        }
        this.isPlacingOrder = true;
        this.placedOrder = this.launchDialogService.launch(LAUNCH_CALLER.PLACE_ORDER_SPINNER, this.vcr);
        this.orderFacade
            .placePaymentAuthorizedOrder(this.termsAndConditionsChecked)
            .pipe(take(1), finalize(() => (this.isPlacingOrder = false)))
            .subscribe({
            next: (order) => {
                if (!order?.code) {
                    this.onPlaceOrderError();
                    return;
                }
                this.stopPlaceOrderSpinner();
                this.onSuccess();
            },
            error: () => this.onPlaceOrderError(),
        });
    }
    onPlaceOrderError() {
        this.stopPlaceOrderSpinner();
        this.globalMessageService.add({ key: 'opfGiftCard.errors.placeOrderFailed' }, GlobalMessageType.MSG_TYPE_ERROR);
        this.routingService.go({ cxRoute: OPF_PAYMENT_AND_REVIEW_SEMANTIC_ROUTE });
    }
    stopPlaceOrderSpinner() {
        const placedOrder = this.placedOrder;
        if (!placedOrder) {
            this.launchDialogService.clear(LAUNCH_CALLER.PLACE_ORDER_SPINNER);
            return;
        }
        if (!isObservable(placedOrder)) {
            this.launchDialogService.clear(LAUNCH_CALLER.PLACE_ORDER_SPINNER);
            return;
        }
        placedOrder
            .pipe(take(1))
            .subscribe((component) => {
            this.launchDialogService.clear(LAUNCH_CALLER.PLACE_ORDER_SPINNER);
            if (component) {
                component.destroy();
            }
        })
            .unsubscribe();
    }
    onSuccess() {
        this.routingService.go({ cxRoute: 'orderConfirmation' });
    }
    ngOnDestroy() {
        this.stopPlaceOrderSpinner();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardCheckoutPlaceOrderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfGiftCardCheckoutPlaceOrderComponent, isStandalone: true, selector: "cx-opf-gift-card-checkout-place-order", ngImport: i0, template: "<ng-container *ngIf=\"cart$ | async as cart\">\n  <div\n    class=\"cx-opf-gift-card-place-order-container\"\n    *ngIf=\"cart.opfGiftCardSummary?.giftCardsCoverFullAmount\"\n  >\n    <button\n      type=\"button\"\n      class=\"btn btn-primary\"\n      (click)=\"placeOrderWithGiftCard()\"\n    >\n      {{ 'opfGiftCard.proceedPayment' | cxTranslate }}\n    </button>\n  </div>\n</ng-container>\n", dependencies: [{ kind: "ngmodule", type: OutletModule }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: i1.AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardCheckoutPlaceOrderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-gift-card-checkout-place-order', changeDetection: ChangeDetectionStrategy.OnPush, imports: [TranslatePipe, OutletModule, CommonModule], template: "<ng-container *ngIf=\"cart$ | async as cart\">\n  <div\n    class=\"cx-opf-gift-card-place-order-container\"\n    *ngIf=\"cart.opfGiftCardSummary?.giftCardsCoverFullAmount\"\n  >\n    <button\n      type=\"button\"\n      class=\"btn btn-primary\"\n      (click)=\"placeOrderWithGiftCard()\"\n    >\n      {{ 'opfGiftCard.proceedPayment' | cxTranslate }}\n    </button>\n  </div>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardOrderSummaryComponent {
    constructor() {
        this.checkoutStepService = inject(CheckoutStepService);
        this.router = inject(Router);
        this.routingService = inject(RoutingService);
        this.isPaymentAndReviewStep$ = this.routingService
            .getRouterState()
            .pipe(map(({ state }) => !['checkoutDeliveryAddress', 'checkoutDeliveryMode'].includes(state?.semanticRoute ?? '')));
    }
    get giftCardCartTotal() {
        return Math.abs((this.cart?.totalPriceWithTax?.value ?? 0) -
            (this.cart?.opfGiftCardSummary?.totalAppliedAmount?.value ?? 0));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderSummaryComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfGiftCardOrderSummaryComponent, isStandalone: true, selector: "cx-opf-gift-card-order-summary", inputs: { cart: "cart" }, ngImport: i0, template: "<ng-container *ngIf=\"cart\">\n  <h3 class=\"cx-summary-heading\">\n    {{ 'orderCost.orderSummary' | cxTranslate }}\n  </h3>\n  <div class=\"cx-summary-partials\">\n    <div class=\"cx-summary-row\">\n      <div class=\"col-6 cx-summary-label\">\n        {{ 'orderCost.subtotal' | cxTranslate }}\n      </div>\n      <div class=\"col-6 cx-summary-amount\">\n        {{ cart.subTotal?.formattedValue }}\n      </div>\n    </div>\n    <div class=\"cx-summary-row\">\n      <div class=\"col-6 cx-summary-label\">\n        {{\n          (cart.deliveryCost?.formattedValue\n            ? 'orderCost.shipping'\n            : 'orderCost.estimatedShipping'\n          ) | cxTranslate\n        }}\n      </div>\n      <div class=\"col-6 cx-summary-amount\">\n        {{\n          cart.deliveryCost?.formattedValue\n            ? cart.deliveryCost?.formattedValue\n            : ('orderCost.toBeDetermined' | cxTranslate)\n        }}\n      </div>\n    </div>\n    <div *ngIf=\"isPaymentAndReviewStep$ | async\">\n      <div\n        class=\"cx-gift-card-order-summary\"\n        *ngIf=\"cart?.opfGiftCardSummary?.totalAppliedAmount?.value\"\n      >\n        <div class=\"cx-summary-row\">\n          <div class=\"col-6 cx-summary-label\">\n            {{ 'opfGiftCard.title' | cxTranslate }}\n          </div>\n          <div class=\"col-6 cx-summary-amount cx-gift-card-discount\">\n            -\n            {{ cart?.opfGiftCardSummary?.totalAppliedAmount?.formattedValue }}\n          </div>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"cx-summary-row\" *ngIf=\"cart.net; else cartWithoutNet\">\n      <div class=\"col-6 cx-summary-label\">\n        {{ 'orderCost.salesTax' | cxTranslate }}\n      </div>\n      <div class=\"col-6 cx-summary-amount\">\n        {{ cart.totalTax?.formattedValue }}\n      </div>\n    </div>\n    <div class=\"cx-summary-row cx-summary-total\">\n      <div class=\"col-6 cx-summary-label\">\n        {{ 'orderCost.total' | cxTranslate }}\n      </div>\n      <div class=\"col-6 cx-summary-amount\">\n        {{\n          (isPaymentAndReviewStep$ | async)\n            ? (giftCardCartTotal\n              | currency: cart.totalPriceWithTax?.currencyIso)\n            : cart.totalPriceWithTax?.formattedValue\n        }}\n      </div>\n    </div>\n    <div class=\"cx-summary-row\" *ngIf=\"(cart.totalDiscounts?.value ?? 0) > 0\">\n      {{ 'orderCost.discount' | cxTranslate }}\n      {{ cart.totalDiscounts?.formattedValue }}\n    </div>\n    <ng-template #cartWithoutNet>\n      <div class=\"cx-summary-row\">\n        {{\n          cart.totalPriceWithTax?.value !== cart.totalPrice?.value\n            ? ('orderCost.grossTax' | cxTranslate)\n            : ('orderCost.grossIncludeTax' | cxTranslate)\n        }}\n        {{ cart.totalTax?.formattedValue }}.\n      </div>\n    </ng-template>\n  </div>\n  <cx-applied-coupons\n    [vouchers]=\"cart.appliedVouchers || []\"\n    [isReadOnly]=\"true\"\n  />\n</ng-container>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: I18nModule }, { kind: "component", type: AppliedCouponsComponent, selector: "cx-applied-coupons", inputs: ["vouchers", "cartIsLoading", "isReadOnly"] }, { kind: "pipe", type: i1.AsyncPipe, name: "async" }, { kind: "pipe", type: i1.CurrencyPipe, name: "currency" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderSummaryComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-gift-card-order-summary', imports: [
                        CommonModule,
                        NgIf,
                        TranslatePipe,
                        I18nModule,
                        AppliedCouponsComponent,
                    ], template: "<ng-container *ngIf=\"cart\">\n  <h3 class=\"cx-summary-heading\">\n    {{ 'orderCost.orderSummary' | cxTranslate }}\n  </h3>\n  <div class=\"cx-summary-partials\">\n    <div class=\"cx-summary-row\">\n      <div class=\"col-6 cx-summary-label\">\n        {{ 'orderCost.subtotal' | cxTranslate }}\n      </div>\n      <div class=\"col-6 cx-summary-amount\">\n        {{ cart.subTotal?.formattedValue }}\n      </div>\n    </div>\n    <div class=\"cx-summary-row\">\n      <div class=\"col-6 cx-summary-label\">\n        {{\n          (cart.deliveryCost?.formattedValue\n            ? 'orderCost.shipping'\n            : 'orderCost.estimatedShipping'\n          ) | cxTranslate\n        }}\n      </div>\n      <div class=\"col-6 cx-summary-amount\">\n        {{\n          cart.deliveryCost?.formattedValue\n            ? cart.deliveryCost?.formattedValue\n            : ('orderCost.toBeDetermined' | cxTranslate)\n        }}\n      </div>\n    </div>\n    <div *ngIf=\"isPaymentAndReviewStep$ | async\">\n      <div\n        class=\"cx-gift-card-order-summary\"\n        *ngIf=\"cart?.opfGiftCardSummary?.totalAppliedAmount?.value\"\n      >\n        <div class=\"cx-summary-row\">\n          <div class=\"col-6 cx-summary-label\">\n            {{ 'opfGiftCard.title' | cxTranslate }}\n          </div>\n          <div class=\"col-6 cx-summary-amount cx-gift-card-discount\">\n            -\n            {{ cart?.opfGiftCardSummary?.totalAppliedAmount?.formattedValue }}\n          </div>\n        </div>\n      </div>\n    </div>\n\n    <div class=\"cx-summary-row\" *ngIf=\"cart.net; else cartWithoutNet\">\n      <div class=\"col-6 cx-summary-label\">\n        {{ 'orderCost.salesTax' | cxTranslate }}\n      </div>\n      <div class=\"col-6 cx-summary-amount\">\n        {{ cart.totalTax?.formattedValue }}\n      </div>\n    </div>\n    <div class=\"cx-summary-row cx-summary-total\">\n      <div class=\"col-6 cx-summary-label\">\n        {{ 'orderCost.total' | cxTranslate }}\n      </div>\n      <div class=\"col-6 cx-summary-amount\">\n        {{\n          (isPaymentAndReviewStep$ | async)\n            ? (giftCardCartTotal\n              | currency: cart.totalPriceWithTax?.currencyIso)\n            : cart.totalPriceWithTax?.formattedValue\n        }}\n      </div>\n    </div>\n    <div class=\"cx-summary-row\" *ngIf=\"(cart.totalDiscounts?.value ?? 0) > 0\">\n      {{ 'orderCost.discount' | cxTranslate }}\n      {{ cart.totalDiscounts?.formattedValue }}\n    </div>\n    <ng-template #cartWithoutNet>\n      <div class=\"cx-summary-row\">\n        {{\n          cart.totalPriceWithTax?.value !== cart.totalPrice?.value\n            ? ('orderCost.grossTax' | cxTranslate)\n            : ('orderCost.grossIncludeTax' | cxTranslate)\n        }}\n        {{ cart.totalTax?.formattedValue }}.\n      </div>\n    </ng-template>\n  </div>\n  <cx-applied-coupons\n    [vouchers]=\"cart.appliedVouchers || []\"\n    [isReadOnly]=\"true\"\n  />\n</ng-container>\n" }]
        }], propDecorators: { cart: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardOrderSummaryModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderSummaryModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderSummaryModule, imports: [OpfGiftCardOrderSummaryComponent], exports: [OpfGiftCardOrderSummaryComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderSummaryModule, imports: [OpfGiftCardOrderSummaryComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderSummaryModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OpfGiftCardOrderSummaryComponent],
                    exports: [OpfGiftCardOrderSummaryComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardCheckoutOrderSummaryComponent {
    constructor() {
        this.activeCartFacade = inject(ActiveCartFacade);
        this.cartOutlets = CartOutlets;
    }
    ngOnInit() {
        this.cart$ = this.activeCartFacade.getActive();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardCheckoutOrderSummaryComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfGiftCardCheckoutOrderSummaryComponent, isStandalone: true, selector: "cx-opf-gift-card-checkout-order-summary", ngImport: i0, template: "<ng-container *ngIf=\"cart$ | async as cart\">\n  <cx-opf-gift-card-order-summary [cart]=\"cart\" />\n</ng-container>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: I18nModule }, { kind: "component", type: OpfGiftCardOrderSummaryComponent, selector: "cx-opf-gift-card-order-summary", inputs: ["cart"] }, { kind: "pipe", type: i1.AsyncPipe, name: "async" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardCheckoutOrderSummaryComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-gift-card-checkout-order-summary', imports: [CommonModule, I18nModule, OpfGiftCardOrderSummaryComponent], template: "<ng-container *ngIf=\"cart$ | async as cart\">\n  <cx-opf-gift-card-order-summary [cart]=\"cart\" />\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultPlaceOrderSpinnerLayoutConfig = {
    launch: {
        PLACE_ORDER_SPINNER: {
            inline: true,
            component: SpinnerComponent,
            dialogType: DIALOG_TYPE.POPOVER_CENTER_BACKDROP,
        },
    },
};
class OpfGiftCardCheckoutModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardCheckoutModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardCheckoutModule, imports: [OpfGiftCardCheckoutPlaceOrderComponent,
            OpfGiftCardCheckoutOrderSummaryComponent], exports: [OpfGiftCardCheckoutPlaceOrderComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardCheckoutModule, providers: [
            provideDefaultConfig(defaultPlaceOrderSpinnerLayoutConfig),
            provideDefaultConfig({
                cmsComponents: {
                    CheckoutOrderSummary: {
                        component: OpfGiftCardCheckoutOrderSummaryComponent,
                    },
                },
            }),
        ], imports: [OpfGiftCardCheckoutPlaceOrderComponent,
            OpfGiftCardCheckoutOrderSummaryComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardCheckoutModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        OpfGiftCardCheckoutPlaceOrderComponent,
                        OpfGiftCardCheckoutOrderSummaryComponent,
                    ],
                    providers: [
                        provideDefaultConfig(defaultPlaceOrderSpinnerLayoutConfig),
                        provideDefaultConfig({
                            cmsComponents: {
                                CheckoutOrderSummary: {
                                    component: OpfGiftCardCheckoutOrderSummaryComponent,
                                },
                            },
                        }),
                    ],
                    exports: [OpfGiftCardCheckoutPlaceOrderComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardApplyComponent {
    buildForm() {
        this.giftCardForm = this.formBuilder.group({
            cardNumber: [
                '',
                [
                    Validators.required,
                    Validators.minLength(8),
                    Validators.maxLength(64),
                ],
            ],
            pin: [
                '',
                [
                    Validators.required,
                    Validators.minLength(3),
                    Validators.maxLength(28),
                ],
            ],
        });
    }
    constructor(outlet) {
        this.outlet = outlet;
        this.globalMessageService = inject(GlobalMessageService);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.giftCardFacade = inject(OpfGiftCardFacade);
        this.formBuilder = inject(UntypedFormBuilder);
        this.opfPaymentEventsService = inject(OpfPaymentEventsService);
        this.opfMetadataStoreService = inject(OpfMetadataStoreService);
        this.destroyRef = inject(DestroyRef);
        this.featureToggles = inject(FeatureToggles);
        this.subscription = new Subscription();
        this.showGiftCardForm = signal(false, ...(ngDevMode ? [{ debugName: "showGiftCardForm" }] : /* istanbul ignore next */ []));
        this.loadingSubject = new BehaviorSubject(false);
        this.loading$ = this.loadingSubject.asObservable();
        this.cart$ = this.activeCartFacade.getActive();
        this.appliedGiftCards$ = this.cart$.pipe(map$1((cart) => cart?.opfGiftCards ?? []));
        this.isGiftCardEnabled$ = this.giftCardFacade
            .isGiftCardEnabled()
            .pipe(shareReplay(1));
        this.isAddGiftCard$ = this.cart$.pipe(map$1((cart) => {
            return (cart?.availableOperations?.find((operations) => operations.key === 'applyGiftCard')?.value?.available ?? true);
        }));
    }
    addGiftCard() {
        if (this.giftCardForm.invalid) {
            this.giftCardForm.markAllAsTouched();
            return;
        }
        const { cardNumber, pin } = this.giftCardForm.value;
        this.loadingSubject.next(true);
        this.giftCardFacade
            .applyGiftCard({
            number: cardNumber,
            securityCode: pin,
        })
            .subscribe({
            next: () => {
                this.activeCartFacade.reloadActiveCart();
                this.globalMessageService.add({ key: 'opfGiftCard.appliedSuccessfully' }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
                this.resetForm();
                this.toggleGiftCardForm();
                this.loadingSubject.next(false);
                this.opfPaymentEventsService.emitReinitiatePaymentEvent();
                this.opfPaymentEventsService.emitRefreshActiveConfigurationsEvent();
            },
            error: (error) => this.handleGiftCardError(error),
        });
    }
    handleGiftCardError(error) {
        const message = error?.details?.[0]?.message ||
            error?.message ||
            'opfGiftCard.errors.applyFailed';
        this.globalMessageService.add({ raw: message }, GlobalMessageType.MSG_TYPE_ERROR);
        this.loadingSubject.next(false);
    }
    toggleGiftCardForm() {
        this.showGiftCardForm.set(!this.showGiftCardForm());
    }
    resetForm() {
        this.giftCardForm.reset();
    }
    ngOnInit() {
        if (this.featureToggles.opfUseDestroyRef) {
            this.giftCardFacade
                .isGiftCardCoveredTotalAmount(this.cart$)
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe((isCovered) => {
                this.opfPaymentEventsService.emitIsGiftCardCoveredTotalAmountEvent(isCovered);
            });
            // Close gift card form when other payment options are selected
            // selectedPaymentOptionId is -1 for saved payment details.
            this.opfMetadataStoreService
                .getOpfMetadataState()
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe((x) => {
                if ((x.selectedPaymentOptionId ?? 0) >= -1 &&
                    this.showGiftCardForm()) {
                    this.giftCardForm.reset();
                    this.toggleGiftCardForm();
                }
            });
            if (this.outlet?.context$) {
                this.outlet.context$
                    .pipe(takeUntilDestroyed(this.destroyRef))
                    .subscribe((context) => {
                    this.isBillingAddressPresent$ = context?.disabled;
                });
            }
        }
        else {
            this.subscription.add(this.giftCardFacade
                .isGiftCardCoveredTotalAmount(this.cart$)
                .subscribe((isCovered) => {
                this.opfPaymentEventsService.emitIsGiftCardCoveredTotalAmountEvent(isCovered);
            }));
            // Close gift card form when other payment options are selected
            // selectedPaymentOptionId is -1 for saved payment details.
            this.subscription.add(this.opfMetadataStoreService.getOpfMetadataState().subscribe((x) => {
                if ((x.selectedPaymentOptionId ?? 0) >= -1 &&
                    this.showGiftCardForm()) {
                    this.giftCardForm.reset();
                    this.toggleGiftCardForm();
                }
            }));
            if (this.outlet?.context$) {
                this.subscription.add(this.outlet.context$.subscribe((context) => {
                    this.isBillingAddressPresent$ = context?.disabled;
                }));
            }
        }
        this.buildForm();
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardApplyComponent, deps: [{ token: i1$1.OutletContextData, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfGiftCardApplyComponent, isStandalone: true, selector: "cx-opf-gift-card-apply", ngImport: i0, template: "<ng-container *ngIf=\"isGiftCardEnabled$ | async\">\n  <ng-container *ngIf=\"cart$ | async as cart\">\n    <div\n      class=\"cx-opf-gift-card-apply\"\n      [ngClass]=\"{ 'cx-disabled': (isBillingAddressPresent$ | async) }\"\n    >\n      <!-- Header -->\n      <div class=\"cx-opf-gift-card-apply-header\">\n        <div class=\"cx-opf-gift-card-apply-title\">\n          <span class=\"gift-card-icon\"></span>\n          <div class=\"title\">\n            <span>{{ 'opfGiftCard.haveGiftCard' | cxTranslate }}</span>\n          </div>\n        </div>\n        <div>\n          <button\n            type=\"button\"\n            class=\"cx-opf-gift-card-apply-add-link\"\n            [disabled]=\"!(isAddGiftCard$ | async)\"\n            (click)=\"toggleGiftCardForm()\"\n          >\n            {{ 'opfGiftCard.addGiftCard' | cxTranslate }}\n          </button>\n        </div>\n      </div>\n\n      <!-- Gift Card Form -->\n      <form\n        *ngIf=\"showGiftCardForm()\"\n        [formGroup]=\"giftCardForm\"\n        (ngSubmit)=\"addGiftCard()\"\n        class=\"cx-opf-gift-card-apply-form\"\n      >\n        <div class=\"cx-opf-gift-card-apply-form-wrapper\">\n          <div class=\"form-group\">\n            <label>\n              {{ 'opfGiftCard.cardNumber' | cxTranslate }}\n            </label>\n            <input\n              type=\"text\"\n              class=\"form-control\"\n              formControlName=\"cardNumber\"\n              [attr.aria-label]=\"'opfGiftCard.cardNumber' | cxTranslate\"\n            />\n            <cx-form-errors\n              [prefix]=\"'opfGiftCard.common.formErrors.labeled'\"\n              [fallbackPrefix]=\"'opfGiftCard.common.formErrors'\"\n              [translationParams]=\"{\n                label: 'opfGiftCard.cardNumber' | cxTranslate,\n              }\"\n              [control]=\"giftCardForm.get('cardNumber')\"\n            />\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              {{ 'opfGiftCard.pin' | cxTranslate }}\n            </label>\n            <input\n              type=\"text\"\n              class=\"form-control\"\n              formControlName=\"pin\"\n              [attr.aria-label]=\"'opfGiftCard.pin' | cxTranslate\"\n            />\n            <cx-form-errors\n              [prefix]=\"'opfGiftCard.common.formErrors.labeled'\"\n              [fallbackPrefix]=\"'opfGiftCard.common.formErrors'\"\n              [translationParams]=\"{\n                label: 'opfGiftCard.pin' | cxTranslate,\n              }\"\n              [control]=\"giftCardForm.get('pin')\"\n            />\n          </div>\n\n          <button\n            type=\"submit\"\n            class=\"btn btn-secondary cx-opf-gift-card-apply-button\"\n            [disabled]=\"giftCardForm.invalid || (loading$ | async)\"\n          >\n            {{ 'opfGiftCard.apply' | cxTranslate }}\n          </button>\n        </div>\n      </form>\n\n      <!-- Applied Gift Cards -->\n      <cx-opf-gift-card-applied\n        [opfGiftCards]=\"(appliedGiftCards$ | async) || []\"\n      />\n      <cx-opf-gift-card-checkout-place-order />\n    </div>\n  </ng-container>\n</ng-container>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: OutletModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i3.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i3.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "component", type: OpfGiftCardAppliedComponent, selector: "cx-opf-gift-card-applied", inputs: ["opfGiftCards"] }, { kind: "component", type: OpfGiftCardCheckoutPlaceOrderComponent, selector: "cx-opf-gift-card-checkout-place-order" }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: i1.AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardApplyComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-gift-card-apply', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        TranslatePipe,
                        CommonModule,
                        OutletModule,
                        FormsModule,
                        ReactiveFormsModule,
                        OpfGiftCardAppliedComponent,
                        OpfGiftCardCheckoutPlaceOrderComponent,
                        FormErrorsComponent,
                    ], template: "<ng-container *ngIf=\"isGiftCardEnabled$ | async\">\n  <ng-container *ngIf=\"cart$ | async as cart\">\n    <div\n      class=\"cx-opf-gift-card-apply\"\n      [ngClass]=\"{ 'cx-disabled': (isBillingAddressPresent$ | async) }\"\n    >\n      <!-- Header -->\n      <div class=\"cx-opf-gift-card-apply-header\">\n        <div class=\"cx-opf-gift-card-apply-title\">\n          <span class=\"gift-card-icon\"></span>\n          <div class=\"title\">\n            <span>{{ 'opfGiftCard.haveGiftCard' | cxTranslate }}</span>\n          </div>\n        </div>\n        <div>\n          <button\n            type=\"button\"\n            class=\"cx-opf-gift-card-apply-add-link\"\n            [disabled]=\"!(isAddGiftCard$ | async)\"\n            (click)=\"toggleGiftCardForm()\"\n          >\n            {{ 'opfGiftCard.addGiftCard' | cxTranslate }}\n          </button>\n        </div>\n      </div>\n\n      <!-- Gift Card Form -->\n      <form\n        *ngIf=\"showGiftCardForm()\"\n        [formGroup]=\"giftCardForm\"\n        (ngSubmit)=\"addGiftCard()\"\n        class=\"cx-opf-gift-card-apply-form\"\n      >\n        <div class=\"cx-opf-gift-card-apply-form-wrapper\">\n          <div class=\"form-group\">\n            <label>\n              {{ 'opfGiftCard.cardNumber' | cxTranslate }}\n            </label>\n            <input\n              type=\"text\"\n              class=\"form-control\"\n              formControlName=\"cardNumber\"\n              [attr.aria-label]=\"'opfGiftCard.cardNumber' | cxTranslate\"\n            />\n            <cx-form-errors\n              [prefix]=\"'opfGiftCard.common.formErrors.labeled'\"\n              [fallbackPrefix]=\"'opfGiftCard.common.formErrors'\"\n              [translationParams]=\"{\n                label: 'opfGiftCard.cardNumber' | cxTranslate,\n              }\"\n              [control]=\"giftCardForm.get('cardNumber')\"\n            />\n          </div>\n\n          <div class=\"form-group\">\n            <label>\n              {{ 'opfGiftCard.pin' | cxTranslate }}\n            </label>\n            <input\n              type=\"text\"\n              class=\"form-control\"\n              formControlName=\"pin\"\n              [attr.aria-label]=\"'opfGiftCard.pin' | cxTranslate\"\n            />\n            <cx-form-errors\n              [prefix]=\"'opfGiftCard.common.formErrors.labeled'\"\n              [fallbackPrefix]=\"'opfGiftCard.common.formErrors'\"\n              [translationParams]=\"{\n                label: 'opfGiftCard.pin' | cxTranslate,\n              }\"\n              [control]=\"giftCardForm.get('pin')\"\n            />\n          </div>\n\n          <button\n            type=\"submit\"\n            class=\"btn btn-secondary cx-opf-gift-card-apply-button\"\n            [disabled]=\"giftCardForm.invalid || (loading$ | async)\"\n          >\n            {{ 'opfGiftCard.apply' | cxTranslate }}\n          </button>\n        </div>\n      </form>\n\n      <!-- Applied Gift Cards -->\n      <cx-opf-gift-card-applied\n        [opfGiftCards]=\"(appliedGiftCards$ | async) || []\"\n      />\n      <cx-opf-gift-card-checkout-place-order />\n    </div>\n  </ng-container>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: i1$1.OutletContextData, decorators: [{
                    type: Optional
                }] }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardApplyModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardApplyModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardApplyModule, imports: [OpfGiftCardApplyComponent], exports: [OpfGiftCardApplyComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardApplyModule, providers: [
            provideOutlet({
                id: OpfCheckoutOutlets.OPF_CHECKOUT_BEFORE_SAVED_PAYMENT_OPTIONS,
                position: OutletPosition.BEFORE,
                component: OpfGiftCardApplyComponent,
            }),
        ], imports: [OpfGiftCardApplyComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardApplyModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OpfGiftCardApplyComponent],
                    providers: [
                        provideOutlet({
                            id: OpfCheckoutOutlets.OPF_CHECKOUT_BEFORE_SAVED_PAYMENT_OPTIONS,
                            position: OutletPosition.BEFORE,
                            component: OpfGiftCardApplyComponent,
                        }),
                    ],
                    exports: [OpfGiftCardApplyComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Normalizer for Cart that maps backend gift card data:
 * - sapGiftCards -> opfGiftCards
 * - sapGiftCardSummary -> opfGiftCardSummary
 */
class OpfGiftCardCartOccNormalizer {
    convert(source, target) {
        target ??= { ...source };
        // Map sapGiftCards to opfGiftCards
        const sapGiftCards = source.sapGiftCards;
        if (sapGiftCards && Array.isArray(sapGiftCards)) {
            target.opfGiftCards = sapGiftCards.map((card) => this.convertGiftCard(card));
        }
        // Map sapGiftCardSummary to opfGiftCardSummary
        const sapGiftCardSummary = source.sapGiftCardSummary;
        if (sapGiftCardSummary) {
            target.opfGiftCardSummary =
                this.convertGiftCardSummary(sapGiftCardSummary);
        }
        // Map _availableOperations to availableOperations
        const _availableOperations = source._availableOperations;
        if (Array.isArray(_availableOperations)) {
            target.availableOperations = _availableOperations.map((operation) => ({
                key: operation.key,
                value: {
                    available: operation.value?.available,
                    name: operation.value?.name,
                },
            }));
        }
        return target;
    }
    convertGiftCard(source) {
        return {
            id: source.id,
            maskedNumber: source.maskedNumber,
            balance: source.balance,
            appliedAmount: source.appliedAmount,
            remainingBalance: source.remainingBalance,
        };
    }
    convertGiftCardSummary(source) {
        return {
            totalBalance: source.totalBalance,
            totalAppliedAmount: source.totalAppliedAmount,
            totalRemainingBalance: source.totalRemainingBalance,
            giftCardsCoverFullAmount: source.giftCardsCoverFullAmount ?? false,
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardCartOccNormalizer, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardCartOccNormalizer, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardCartOccNormalizer, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/**
 * Normalizer for Order that maps backend gift card data:
 * - sapGiftCardSummary -> opfGiftCardSummary
 */
class OpfGiftCardOrderOccNormalizer {
    convert(source, target) {
        target ??= { ...source };
        // Map sapGiftCardSummary to opfGiftCardSummary
        const sapGiftCardSummary = source.sapGiftCardSummary;
        if (sapGiftCardSummary) {
            target.opfGiftCardSummary =
                this.convertGiftCardSummary(sapGiftCardSummary);
        }
        return target;
    }
    convertGiftCardSummary(source) {
        return {
            totalBalance: source.totalBalance,
            totalAppliedAmount: source.totalAppliedAmount,
            totalRemainingBalance: source.totalRemainingBalance,
            giftCardsCoverFullAmount: source.giftCardsCoverFullAmount ?? false,
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderOccNormalizer, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderOccNormalizer, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderOccNormalizer, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardOrderConfirmationTotalsComponent {
    constructor() {
        this.orderFacade = inject(OrderFacade);
        this.cartOutlets = CartOutlets;
        this.order$ = this.orderFacade.getOrderDetails();
    }
    ngOnDestroy() {
        this.orderFacade.clearPlacedOrder();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderConfirmationTotalsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfGiftCardOrderConfirmationTotalsComponent, isStandalone: true, selector: "cx-opf-gift-card-order-confirmation-totals", ngImport: i0, template: "<div\n  class=\"cx-opf-gift-card-order-confirmation-totals container\"\n  *ngIf=\"order$ | async as order\"\n>\n  <div class=\"row justify-content-end\">\n    <div class=\"col-sm-12 col-md-6 col-lg-5 col-xl-4\">\n      <cx-opf-gift-card-order-summary [cart]=\"order\" />\n    </div>\n  </div>\n</div>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: OutletModule }, { kind: "component", type: OpfGiftCardOrderSummaryComponent, selector: "cx-opf-gift-card-order-summary", inputs: ["cart"] }, { kind: "pipe", type: i1.AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderConfirmationTotalsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-gift-card-order-confirmation-totals', changeDetection: ChangeDetectionStrategy.OnPush, imports: [CommonModule, OutletModule, NgIf, OpfGiftCardOrderSummaryComponent], template: "<div\n  class=\"cx-opf-gift-card-order-confirmation-totals container\"\n  *ngIf=\"order$ | async as order\"\n>\n  <div class=\"row justify-content-end\">\n    <div class=\"col-sm-12 col-md-6 col-lg-5 col-xl-4\">\n      <cx-opf-gift-card-order-summary [cart]=\"order\" />\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardOrderConfirmationModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderConfirmationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderConfirmationModule, imports: [OpfGiftCardOrderConfirmationTotalsComponent], exports: [OpfGiftCardOrderConfirmationTotalsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderConfirmationModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    OrderConfirmationTotalsComponent: {
                        component: OpfGiftCardOrderConfirmationTotalsComponent,
                        guards: [OrderConfirmationGuard],
                    },
                },
            }),
        ], imports: [OpfGiftCardOrderConfirmationTotalsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderConfirmationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OpfGiftCardOrderConfirmationTotalsComponent],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                OrderConfirmationTotalsComponent: {
                                    component: OpfGiftCardOrderConfirmationTotalsComponent,
                                    guards: [OrderConfirmationGuard],
                                },
                            },
                        }),
                    ],
                    exports: [OpfGiftCardOrderConfirmationTotalsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardOrderDetailBillingComponent {
    constructor(orderOutlet) {
        this.orderOutlet = orderOutlet;
        this.translationService = inject(TranslationService);
        this.destroyRef = inject(DestroyRef);
        this.featureToggles = inject(FeatureToggles);
        this.subscription = new Subscription();
        this.routingService = inject(RoutingService);
        this.isOrderDetailsPage$ = this.routingService
            .getRouterState()
            .pipe(map(({ state }) => ['orderDetails'].includes(state?.semanticRoute ?? '')));
    }
    ngOnInit() {
        if (this.orderOutlet?.context$) {
            if (this.featureToggles.opfUseDestroyRef) {
                this.orderOutlet.context$
                    .pipe(takeUntilDestroyed(this.destroyRef))
                    .subscribe((context) => (this.order = context));
            }
            else {
                this.subscription.add(this.orderOutlet.context$.subscribe((context) => (this.order = context)));
            }
        }
    }
    getPaymentMethodCardContent() {
        return combineLatest([
            this.translationService.translate('paymentForm.payment'),
            this.translationService.translate('opfGiftCard.giftCardPayment'),
        ]).pipe(map(([translatedTitle, translatedText]) => {
            return {
                title: translatedTitle,
                text: [translatedText],
            };
        }));
    }
    get isGiftCardPayment() {
        const totalAppliedAmount = this.order?.opfGiftCardSummary?.totalAppliedAmount?.value ?? 0;
        return totalAppliedAmount > 0;
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderDetailBillingComponent, deps: [{ token: i1$1.OutletContextData, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfGiftCardOrderDetailBillingComponent, isStandalone: true, selector: "cx-opf-gift-card-order-detail-billing", inputs: { order: "order" }, ngImport: i0, template: "<div\n  *ngIf=\"isOrderDetailsPage$ | async\"\n  class=\"cx-review-summary-card cx-review-summary-payment-card\"\n>\n  <ng-container *ngIf=\"isGiftCardPayment\">\n    <div class=\"cx-opf-gift-card-order-detail-billing-card\">\n      <ng-container\n        *ngIf=\"!order.paymentInfo?.cardNumber; else partialGiftCardPayment\"\n      >\n        <cx-card [content]=\"getPaymentMethodCardContent() | async\" />\n      </ng-container>\n\n      <ng-template #partialGiftCardPayment>\n        <cx-card\n          [content]=\"{ text: ['opfGiftCard.giftCardPayment' | cxTranslate] }\"\n        />\n      </ng-template>\n    </div>\n  </ng-container>\n</div>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CardComponent, selector: "cx-card", inputs: ["border", "editMode", "isDefault", "content", "fitToContainer", "truncateText", "truncateParagraphText", "charactersLimit", "index", "role"], outputs: ["deleteCard", "setDefaultCard", "sendCard", "editCard", "cancelCard"] }, { kind: "ngmodule", type: CommonModule }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderDetailBillingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-gift-card-order-detail-billing', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, CardComponent, AsyncPipe, CommonModule, TranslatePipe], standalone: true, template: "<div\n  *ngIf=\"isOrderDetailsPage$ | async\"\n  class=\"cx-review-summary-card cx-review-summary-payment-card\"\n>\n  <ng-container *ngIf=\"isGiftCardPayment\">\n    <div class=\"cx-opf-gift-card-order-detail-billing-card\">\n      <ng-container\n        *ngIf=\"!order.paymentInfo?.cardNumber; else partialGiftCardPayment\"\n      >\n        <cx-card [content]=\"getPaymentMethodCardContent() | async\" />\n      </ng-container>\n\n      <ng-template #partialGiftCardPayment>\n        <cx-card\n          [content]=\"{ text: ['opfGiftCard.giftCardPayment' | cxTranslate] }\"\n        />\n      </ng-template>\n    </div>\n  </ng-container>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1$1.OutletContextData, decorators: [{
                    type: Optional
                }] }], propDecorators: { order: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardOrderDetailTotalsComponent {
    constructor() {
        this.activeCartFacade = inject(ActiveCartFacade);
        this.orderDetailsService = inject(OrderDetailsService);
        this.cartOutlets = CartOutlets;
    }
    ngOnInit() {
        this.order$ = this.orderDetailsService.getOrderDetails();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderDetailTotalsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfGiftCardOrderDetailTotalsComponent, isStandalone: true, selector: "cx-opf-gift-card-order-detail-totals", ngImport: i0, template: "<ng-container *ngIf=\"order$ | async as order\">\n  <div class=\"row justify-content-end\">\n    <div class=\"cx-summary col-sm-12 col-md-6 col-lg-5 col-xl-4\">\n      <cx-opf-gift-card-order-summary [cart]=\"order\" />\n    </div>\n  </div>\n</ng-container>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: OutletModule }, { kind: "component", type: OpfGiftCardOrderSummaryComponent, selector: "cx-opf-gift-card-order-summary", inputs: ["cart"] }, { kind: "pipe", type: i1.AsyncPipe, name: "async" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderDetailTotalsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-gift-card-order-detail-totals', imports: [CommonModule, OutletModule, NgIf, OpfGiftCardOrderSummaryComponent], template: "<ng-container *ngIf=\"order$ | async as order\">\n  <div class=\"row justify-content-end\">\n    <div class=\"cx-summary col-sm-12 col-md-6 col-lg-5 col-xl-4\">\n      <cx-opf-gift-card-order-summary [cart]=\"order\" />\n    </div>\n  </div>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardPaymentMethodDetailComponent {
    constructor(orderOutlet) {
        this.orderOutlet = orderOutlet;
        this.translationService = inject(TranslationService);
        this.destroyRef = inject(DestroyRef);
        this.featureToggles = inject(FeatureToggles);
        this.subscription = new Subscription();
        this.routingService = inject(RoutingService);
    }
    ngOnInit() {
        if (this.orderOutlet?.context$) {
            if (this.featureToggles.opfUseDestroyRef) {
                this.orderOutlet.context$
                    .pipe(takeUntilDestroyed(this.destroyRef))
                    .subscribe((context) => (this.order = context));
            }
            else {
                this.subscription.add(this.orderOutlet.context$.subscribe((context) => (this.order = context)));
            }
        }
    }
    getPaymentMethodCardContent() {
        return combineLatest([
            this.translationService.translate('opfCheckout.paymentOption'),
            this.translationService.translate('opfGiftCard.giftCardPayment'),
        ]).pipe(map(([translatedTitle, translatedText]) => {
            return {
                title: translatedTitle,
                text: [translatedText],
            };
        }));
    }
    get isGiftCardPayment() {
        const totalAppliedAmount = this.order?.opfGiftCardSummary?.totalAppliedAmount?.value ?? 0;
        return totalAppliedAmount > 0;
    }
    //if sapPaymentMethod is present, it means that gift card doesn't cover full amount,
    get isPaymentMethodDetailsInfoPresent() {
        return Boolean(this.order?.paymentInfo?.sapPaymentMethod?.name);
    }
    ngOnDestroy() {
        this.subscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardPaymentMethodDetailComponent, deps: [{ token: i1$1.OutletContextData, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfGiftCardPaymentMethodDetailComponent, isStandalone: true, selector: "cx-opf-gift-card-payment-method-detail", inputs: { order: "order" }, ngImport: i0, template: "<ng-container *ngIf=\"order\">\n  <ng-container *ngIf=\"isGiftCardPayment\">\n    <div class=\"cx-opf-gift-card-payment-method-detail\">\n      <ng-container\n        *ngIf=\"!isPaymentMethodDetailsInfoPresent; else giftCardPartialPayment\"\n      >\n        <div class=\"cx-gift-card-full-payment\">\n          <cx-card [content]=\"getPaymentMethodCardContent() | async\" />\n        </div>\n      </ng-container>\n\n      <ng-template #giftCardPartialPayment>\n        <div class=\"cx-gift-card-partial-payment\">\n          <cx-card\n            [content]=\"{ text: ['opfGiftCard.giftCardPayment' | cxTranslate] }\"\n          />\n        </div>\n      </ng-template>\n    </div>\n  </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CardComponent, selector: "cx-card", inputs: ["border", "editMode", "isDefault", "content", "fitToContainer", "truncateText", "truncateParagraphText", "charactersLimit", "index", "role"], outputs: ["deleteCard", "setDefaultCard", "sendCard", "editCard", "cancelCard"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardPaymentMethodDetailComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-gift-card-payment-method-detail', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, CardComponent, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"order\">\n  <ng-container *ngIf=\"isGiftCardPayment\">\n    <div class=\"cx-opf-gift-card-payment-method-detail\">\n      <ng-container\n        *ngIf=\"!isPaymentMethodDetailsInfoPresent; else giftCardPartialPayment\"\n      >\n        <div class=\"cx-gift-card-full-payment\">\n          <cx-card [content]=\"getPaymentMethodCardContent() | async\" />\n        </div>\n      </ng-container>\n\n      <ng-template #giftCardPartialPayment>\n        <div class=\"cx-gift-card-partial-payment\">\n          <cx-card\n            [content]=\"{ text: ['opfGiftCard.giftCardPayment' | cxTranslate] }\"\n          />\n        </div>\n      </ng-template>\n    </div>\n  </ng-container>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: i1$1.OutletContextData, decorators: [{
                    type: Optional
                }] }], propDecorators: { order: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardOrderDetailsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderDetailsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderDetailsModule, imports: [OpfGiftCardOrderDetailBillingComponent,
            OpfGiftCardOrderDetailTotalsComponent,
            OpfGiftCardPaymentMethodDetailComponent], exports: [OpfGiftCardOrderDetailBillingComponent,
            OpfGiftCardOrderDetailTotalsComponent,
            OpfGiftCardPaymentMethodDetailComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderDetailsModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    AccountOrderDetailsTotalsComponent: {
                        component: OpfGiftCardOrderDetailTotalsComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
            provideOutlet({
                id: CartOutlets.ORDER_DETAILS_AFTER_PAYMENT_METHOD,
                component: OpfGiftCardOrderDetailBillingComponent,
            }),
            provideOutlet({
                id: OpfCheckoutOutlets.ORDER_DETAILS_AFTER_PAYMENT_OPTIONS,
                component: OpfGiftCardPaymentMethodDetailComponent,
            }),
        ], imports: [OpfGiftCardOrderDetailBillingComponent,
            OpfGiftCardOrderDetailTotalsComponent,
            OpfGiftCardPaymentMethodDetailComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardOrderDetailsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        OpfGiftCardOrderDetailBillingComponent,
                        OpfGiftCardOrderDetailTotalsComponent,
                        OpfGiftCardPaymentMethodDetailComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                AccountOrderDetailsTotalsComponent: {
                                    component: OpfGiftCardOrderDetailTotalsComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                        provideOutlet({
                            id: CartOutlets.ORDER_DETAILS_AFTER_PAYMENT_METHOD,
                            component: OpfGiftCardOrderDetailBillingComponent,
                        }),
                        provideOutlet({
                            id: OpfCheckoutOutlets.ORDER_DETAILS_AFTER_PAYMENT_OPTIONS,
                            component: OpfGiftCardPaymentMethodDetailComponent,
                        }),
                    ],
                    exports: [
                        OpfGiftCardOrderDetailBillingComponent,
                        OpfGiftCardOrderDetailTotalsComponent,
                        OpfGiftCardPaymentMethodDetailComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * HTTP Interceptor for Gift Card payment flow in split payment scenarios.
 *
 * Reloads cart ONLY when placePaymentAuthorizedOrder API fails.
 * When payment auth fails, the backend automatically removes the gift card.
 * Cart is reloaded to reflect the updated state with gift card removed.
 *
 * Intercepts: POST /orders/paymentAuthorizedOrderPlacement
 */
class OpfGiftCardPaymentApiInterceptor {
    constructor() {
        this.activeCartService = inject(ActiveCartFacade);
    }
    intercept(request, next) {
        // Only intercept placePaymentAuthorizedOrder API calls
        if (!request.url.includes('/orders/paymentAuthorizedOrderPlacement')) {
            return next.handle(request);
        }
        return next.handle(request).pipe(
        // Reload cart only on placePaymentAuthorizedOrder failure
        catchError((error) => {
            this.activeCartService.reloadActiveCart();
            return throwError(() => error);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardPaymentApiInterceptor, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardPaymentApiInterceptor }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardPaymentApiInterceptor, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_GIFT_CARD_FEATURE_CMS_COMPONENTS = [
    'CheckoutOrderSummary',
    'OrderConfirmationTotalsComponent',
    'AccountOrderDetailsTotalsComponent',
];
function defaultOpfGiftCardComponentsConfig() {
    const config = {
        featureModules: {
            [OPF_GIFT_CARD_FEATURE]: {
                cmsComponents: OPF_GIFT_CARD_FEATURE_CMS_COMPONENTS,
            },
        },
    };
    return config;
}
class OpfGiftCardRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardRootModule, imports: [OpfGiftCardApplyModule,
            OpfGiftCardCheckoutModule,
            OpfGiftCardOrderDetailsModule,
            OpfGiftCardOrderConfirmationModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardRootModule, providers: [
            {
                provide: ORDER_NORMALIZER,
                useExisting: OpfGiftCardOrderOccNormalizer,
                multi: true,
            },
            {
                provide: CART_NORMALIZER,
                useExisting: OpfGiftCardCartOccNormalizer,
                multi: true,
            },
            {
                provide: HTTP_INTERCEPTORS,
                useClass: OpfGiftCardPaymentApiInterceptor,
                multi: true,
            },
            provideDefaultConfigFactory(defaultOpfGiftCardComponentsConfig),
        ], imports: [OpfGiftCardApplyModule,
            OpfGiftCardCheckoutModule,
            OpfGiftCardOrderDetailsModule,
            OpfGiftCardOrderConfirmationModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardRootModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        OpfGiftCardApplyModule,
                        OpfGiftCardCheckoutModule,
                        OpfGiftCardOrderDetailsModule,
                        OpfGiftCardOrderConfirmationModule,
                    ],
                    providers: [
                        {
                            provide: ORDER_NORMALIZER,
                            useExisting: OpfGiftCardOrderOccNormalizer,
                            multi: true,
                        },
                        {
                            provide: CART_NORMALIZER,
                            useExisting: OpfGiftCardCartOccNormalizer,
                            multi: true,
                        },
                        {
                            provide: HTTP_INTERCEPTORS,
                            useClass: OpfGiftCardPaymentApiInterceptor,
                            multi: true,
                        },
                        provideDefaultConfigFactory(defaultOpfGiftCardComponentsConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OPF_GIFT_CARD_FEATURE, OPF_GIFT_CARD_FEATURE_CMS_COMPONENTS, OpfGiftCardCartOccNormalizer, OpfGiftCardFacade, OpfGiftCardOrderOccNormalizer, OpfGiftCardPaymentApiInterceptor, OpfGiftCardRootModule, defaultOccOpfGiftCardCartEndpointsConfig, defaultOccOpfGiftCardOrderEndpointsConfig, defaultOpfGiftCardCartConfig, defaultOpfGiftCardComponentsConfig };
//# sourceMappingURL=spartacus-opf-gift-card-root.mjs.map
