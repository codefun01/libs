import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { OpfGiftCardFacade } from '@spartacus/opf/gift-card/root';
import { ActiveCartFacade } from '@spartacus/cart/base/root';
import { combineLatest, filter, take, switchMap } from 'rxjs';
import { OpfBaseFacade, OpfPaymentProviderType } from '@spartacus/opf/base/root';
import { map, startWith } from 'rxjs/operators';
import { UserIdService } from '@spartacus/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardConnector {
    constructor() {
        this.adapter = inject(OpfGiftCardAdapter);
    }
    applyGiftCard(userId, cartId, opfGiftCardBalanceRequest) {
        return this.adapter.applyGiftCard(userId, cartId, opfGiftCardBalanceRequest);
    }
    removeGiftCard(userId, cartId, giftCardId) {
        return this.adapter.removeGiftCard(userId, cartId, giftCardId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardConnector, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardConnector, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardService {
    constructor() {
        this.opfBaseFacade = inject(OpfBaseFacade);
        this.opfGiftCardConnector = inject(OpfGiftCardConnector);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.userIdService = inject(UserIdService);
    }
    /**
     * Get gift card payment configuration from active configurations.
     * Filters by providerType: "STORED_VALUE_PAYMENT".
     *
     * @returns Observable of gift card configuration or undefined if not found
     */
    getGiftCardConfiguration() {
        return this.opfBaseFacade
            .getActiveConfigurationsState()
            .pipe(map((config) => (config?.data?.value || []).find((item) => item?.providerType === OpfPaymentProviderType.STORED_VALUE_PAYMENT)));
    }
    isGiftCardEnabled() {
        return this.getGiftCardConfiguration().pipe(map((config) => !!config), startWith(false));
    }
    isGiftCardCoveredTotalAmount(cart$) {
        return cart$.pipe(map((cart) => cart?.opfGiftCardSummary?.giftCardsCoverFullAmount ?? false));
    }
    /**
     * Apply a gift card to the active cart.
     *
     * @param request Gift card balance request with card number and security code
     * @returns Observable of the applied gift card response
     */
    applyGiftCard(request) {
        return combineLatest([
            this.userIdService.getUserId(),
            this.activeCartFacade.getActiveCartId(),
        ]).pipe(filter(([userId, cartId]) => Boolean(userId && cartId)), take(1), switchMap(([userId, cartId]) => this.opfGiftCardConnector.applyGiftCard(userId, cartId, request)));
    }
    /**
     * Remove a previously applied gift card from the active cart.
     *
     * @param giftCardId The ID of the gift card to remove
     */
    removeGiftCard(giftCardId) {
        return combineLatest([
            this.userIdService.getUserId(),
            this.activeCartFacade.getActiveCartId(),
        ]).pipe(filter(([userId, cartId]) => Boolean(userId && cartId)), take(1), switchMap(([userId, cartId]) => this.opfGiftCardConnector.removeGiftCard(userId, cartId, giftCardId)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const facadeProviders = [
    OpfGiftCardService,
    {
        provide: OpfGiftCardFacade,
        useExisting: OpfGiftCardService,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGiftCardCoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardCoreModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardCoreModule, providers: [...facadeProviders, OpfGiftCardConnector] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGiftCardCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [...facadeProviders, OpfGiftCardConnector],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfGiftCardAdapter, OpfGiftCardConnector, OpfGiftCardCoreModule, OpfGiftCardService };
//# sourceMappingURL=spartacus-opf-gift-card-core.mjs.map
