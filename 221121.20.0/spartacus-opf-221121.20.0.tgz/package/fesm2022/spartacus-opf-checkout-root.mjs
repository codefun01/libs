import { CheckoutStepType } from '@spartacus/checkout/base/root';
import '@spartacus/cart/base/root';
import * as i0 from '@angular/core';
import { InjectionToken, inject, Injectable, provideAppInitializer, NgModule } from '@angular/core';
import { CheckoutAuthGuard, CheckoutFlowOrchestratorService } from '@spartacus/checkout/base/components';
import { ConverterService, OccEndpointsService, LoggerService, tryNormalizeHttpError, backOff, isServerError, UserIdService, provideDefaultConfig, provideDefaultConfigFactory } from '@spartacus/core';
import { HttpClient } from '@angular/common/http';
import { catchError, map, filter, switchMap, combineLatest } from 'rxjs';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOccOpfCheckoutConfig = {
    backend: {
        occ: {
            endpoints: {
                cartUserEmail: 'users/${userId}/carts/${cartId}?fields=sapCustomerEmail',
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const opfCheckoutSteps = [
    {
        id: 'deliveryAddress',
        name: 'opfCheckout.tabs.shipping',
        routeName: 'checkoutDeliveryAddress',
        type: [CheckoutStepType.DELIVERY_ADDRESS],
        nameMultiLine: true,
    },
    {
        id: 'deliveryMode',
        name: 'opfCheckout.tabs.deliveryMethod',
        routeName: 'checkoutDeliveryMode',
        type: [CheckoutStepType.DELIVERY_MODE],
        nameMultiLine: true,
    },
    {
        id: 'opfPaymentAndReview',
        name: 'opfCheckout.tabs.paymentAndReview',
        routeName: 'opfCheckoutPaymentAndReview',
        type: [CheckoutStepType.PAYMENT_DETAILS],
        nameMultiLine: true,
    },
];
const defaultOpfCheckoutConfig = {
    checkout: {
        flows: {
            OPF: {
                steps: opfCheckoutSteps,
                guest: false,
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_CHECKOUT_FEATURE = 'opfCheckout';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_PAYMENT_AND_REVIEW_SEMANTIC_ROUTE = 'opfCheckoutPaymentAndReview';
const OPF_EXPLICIT_TERMS_AND_CONDITIONS_COMPONENT = 'OpfExplicitTermsAndConditionsComponent';
const OPF_CHECKOUT_FLOW_NAME = 'OPF';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var OpfCheckoutOutlets;
(function (OpfCheckoutOutlets) {
    OpfCheckoutOutlets["OPF_CHECKOUT_BEFORE_PAYMENT_OPTIONS"] = "cx-opf-checkout-before-payment-options";
    OpfCheckoutOutlets["OPF_CHECKOUT_BEFORE_SAVED_PAYMENT_OPTIONS"] = "cx-opf-checkout-before-saved-payment-options";
    OpfCheckoutOutlets["ORDER_DETAILS_AFTER_PAYMENT_OPTIONS"] = "cx-opf-after-payment-options";
})(OpfCheckoutOutlets || (OpfCheckoutOutlets = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
// Imported for side effects (module augmentation)

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_GET_CART_USER_EMAIL_NORMALIZER = new InjectionToken('OpfGetCartUserEmailNormalizer');

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfApiCheckoutAdapter {
    constructor() {
        this.http = inject(HttpClient);
        this.converter = inject(ConverterService);
        this.occEndpointsService = inject(OccEndpointsService);
        this.logger = inject(LoggerService);
    }
    /**
     * Retrieves the email associated with a specific cart for a given user.
     *
     * @param {string} userId - The unique identifier of the user.
     * @param {string} cartId - The unique identifier of the cart.
     * @returns {Observable<CartUserEmailResponse>} - An observable containing the cart user email response.
     */
    getCartUserEmail(userId, cartId) {
        return this.http
            .get(this.occEndpointsService.buildUrl('cartUserEmail', {
            urlParams: { userId, cartId },
        }))
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({
            shouldRetry: isServerError,
            maxTries: 2,
        }), this.converter.pipeable(OPF_GET_CART_USER_EMAIL_NORMALIZER));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiCheckoutAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiCheckoutAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiCheckoutAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutConnector {
    constructor() {
        this.adapter = inject(OpfCheckoutAdapter);
    }
    /**
     * Retrieves the email associated with a specific cart for a given user.
     * Delegates the request to the underlying adapter.
     *
     * @param {string} userId - The unique identifier of the user.
     * @param {string} cartId - The unique identifier of the cart.
     * @returns {Observable<CartUserEmailResponse>} - An observable containing the cart user email response.
     */
    getCartUserEmail(userId, cartId) {
        return this.adapter.getCartUserEmail(userId, cartId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutConnector, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutConnector }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutConnector, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Service responsible for checking whether a cart user has a valid email.
 */
class OpfCartUserEmailCheckerService {
    constructor() {
        this.opfCheckoutConnector = inject(OpfCheckoutConnector);
    }
    /**
     * Checks if the user associated with a cart has an email.
     *
     * @param {string} userId - The unique identifier of the user.
     * @param {string} cartId - The unique identifier of the cart.
     * @returns {Observable<boolean>} - An observable that emits `true` if the user has an email assigned, otherwise `false`.
     */
    isCartUserHasEmail(userId, cartId) {
        return this.opfCheckoutConnector
            .getCartUserEmail(userId, cartId)
            .pipe(map((value) => !!value.sapCustomerEmail));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCartUserEmailCheckerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCartUserEmailCheckerService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCartUserEmailCheckerService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * A checkout authentication guard that extends `CheckoutAuthGuard` and applies additional logic for guest carts.
 * If the cart belongs to a guest user, it verifies whether the user has a valid email before allowing access.
 */
class OpfCheckoutAuthGuard extends CheckoutAuthGuard {
    constructor() {
        super(...arguments);
        this.userIdService = inject(UserIdService);
        this.opfCartUserEmailChecker = inject(OpfCartUserEmailCheckerService);
    }
    /**
     * Determines whether the user can activate the checkout route.
     * - If the cart is **not a guest cart**, it defers to the parent `CheckoutAuthGuard`.
     * - If the cart **belongs to a guest user**, it checks whether the guest user has a valid email.
     * - If the guest user **does not have an email**, they are redirected to the OPF checkout email update page.
     *
     * @returns {Observable<GuardResult>} - An observable that emits `true` to allow navigation, or a `UrlTree` to redirect the user.
     */
    canActivate() {
        return this.activeCartFacade.isStable().pipe(filter((isStable) => isStable), switchMap(() => this.activeCartFacade.isGuestCart()), switchMap((isGuestCart) => {
            if (!isGuestCart) {
                return super.canActivate();
            }
            return combineLatest([
                this.userIdService.getUserId(),
                this.activeCartFacade.getActiveCartId(),
            ]).pipe(switchMap(([userId, cartId]) => this.opfCartUserEmailChecker.isCartUserHasEmail(userId, cartId)), map((isCartUserHasEmail) => isCartUserHasEmail || this.handleGuestUserWithoutEmail()));
        }));
    }
    handleGuestUserWithoutEmail() {
        return this.router.createUrlTree([
            this.semanticPathService.get('opfCheckoutEmail'),
        ]);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutAuthGuard, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutAuthGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutAuthGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOpfCheckoutRoutingConfig = {
    routing: {
        routes: {
            opfCheckoutPaymentType: {
                paths: ['checkout/opf-payment-type'],
            },
            opfCheckoutDeliveryAddress: {
                paths: ['checkout/opf-delivery-address'],
            },
            opfCheckoutPaymentAndReview: {
                paths: ['checkout/opf-payment-and-review'],
            },
            opfCheckoutReview: {
                paths: ['checkout/opf-review'],
            },
            opfCheckoutEmail: {
                paths: ['opf-checkout-email'],
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const CHECKOUT_OPF_CMS_COMPONENTS = [
    'OpfCheckoutPaymentAndReview',
    'OpfCheckoutEmailUpdateComponent',
];
function defaultOpfCheckoutComponentsConfig() {
    const config = {
        featureModules: {
            [OPF_CHECKOUT_FEATURE]: {
                cmsComponents: CHECKOUT_OPF_CMS_COMPONENTS,
            },
        },
    };
    return config;
}
class OpfCheckoutRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutRootModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutRootModule, providers: [
            {
                provide: CheckoutAuthGuard,
                useClass: OpfCheckoutAuthGuard,
            },
            {
                provide: OpfCheckoutAdapter,
                useClass: OpfApiCheckoutAdapter,
            },
            OpfCheckoutConnector,
            OpfCartUserEmailCheckerService,
            provideDefaultConfig(defaultOpfCheckoutRoutingConfig),
            provideDefaultConfig(defaultOccOpfCheckoutConfig),
            provideDefaultConfig(defaultOpfCheckoutConfig),
            provideDefaultConfigFactory(defaultOpfCheckoutComponentsConfig),
            provideAppInitializer(() => {
                inject(CheckoutFlowOrchestratorService);
            }),
        ] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutRootModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [
                        {
                            provide: CheckoutAuthGuard,
                            useClass: OpfCheckoutAuthGuard,
                        },
                        {
                            provide: OpfCheckoutAdapter,
                            useClass: OpfApiCheckoutAdapter,
                        },
                        OpfCheckoutConnector,
                        OpfCartUserEmailCheckerService,
                        provideDefaultConfig(defaultOpfCheckoutRoutingConfig),
                        provideDefaultConfig(defaultOccOpfCheckoutConfig),
                        provideDefaultConfig(defaultOpfCheckoutConfig),
                        provideDefaultConfigFactory(defaultOpfCheckoutComponentsConfig),
                        provideAppInitializer(() => {
                            inject(CheckoutFlowOrchestratorService);
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CHECKOUT_OPF_CMS_COMPONENTS, OPF_CHECKOUT_FEATURE, OPF_CHECKOUT_FLOW_NAME, OPF_EXPLICIT_TERMS_AND_CONDITIONS_COMPONENT, OPF_PAYMENT_AND_REVIEW_SEMANTIC_ROUTE, OpfCartUserEmailCheckerService, OpfCheckoutOutlets, OpfCheckoutRootModule, defaultOccOpfCheckoutConfig, defaultOpfCheckoutComponentsConfig, defaultOpfCheckoutConfig };
//# sourceMappingURL=spartacus-opf-checkout-root.mjs.map
