import * as i0 from '@angular/core';
import { Injectable, NgModule } from '@angular/core';
import { facadeFactory, provideDefaultConfigFactory } from '@spartacus/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_CTA_FEATURE = 'opfCta';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCtaFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: OpfCtaFacade,
            feature: OPF_CTA_FEATURE,
            methods: [
                'getCtaScripts',
                'listenScriptReadyEvent',
                'emitScriptReadyEvent',
            ],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: OpfCtaFacade,
                        feature: OPF_CTA_FEATURE,
                        methods: [
                            'getCtaScripts',
                            'listenScriptReadyEvent',
                            'emitScriptReadyEvent',
                        ],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var OpfCtaScriptsLocation;
(function (OpfCtaScriptsLocation) {
    OpfCtaScriptsLocation["CART_MESSAGING"] = "CART_MESSAGING";
    OpfCtaScriptsLocation["PDP_MESSAGING"] = "PDP_MESSAGING";
    OpfCtaScriptsLocation["CART_QUICK_BUY"] = "CART_QUICK_BUY";
    OpfCtaScriptsLocation["PDP_QUICK_BUY"] = "PDP_QUICK_BUY";
    OpfCtaScriptsLocation["ORDER_CONFIRMATION_PAYMENT_GUIDE"] = "ORDER_CONFIRMATION_PAYMENT_GUIDE";
    OpfCtaScriptsLocation["ORDER_HISTORY_PAYMENT_GUIDE"] = "ORDER_HISTORY_PAYMENT_GUIDE";
})(OpfCtaScriptsLocation || (OpfCtaScriptsLocation = {}));
var OpfCtaCmsPageLocation;
(function (OpfCtaCmsPageLocation) {
    OpfCtaCmsPageLocation["ORDER_CONFIRMATION_PAGE"] = "orderConfirmationPage";
    OpfCtaCmsPageLocation["ORDER_PAGE"] = "order";
    OpfCtaCmsPageLocation["PDP_PAGE"] = "productDetails";
    OpfCtaCmsPageLocation["CART_PAGE"] = "cartPage";
})(OpfCtaCmsPageLocation || (OpfCtaCmsPageLocation = {}));
var OpfCtaEvent;
(function (OpfCtaEvent) {
    OpfCtaEvent["OPF_CART_CHANGED"] = "opfCartChanged";
    OpfCtaEvent["OPF_PRODUCT_AMOUNT_CHANGED"] = "opfProductAmountChanged";
})(OpfCtaEvent || (OpfCtaEvent = {}));
const OpfCtaDynamicLocations = [
    OpfCtaScriptsLocation.CART_MESSAGING,
    OpfCtaScriptsLocation.PDP_MESSAGING,
    OpfCtaScriptsLocation.CART_QUICK_BUY,
    OpfCtaScriptsLocation.PDP_QUICK_BUY,
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
function defaultOpfCtaCmsComponentsConfig() {
    const config = {
        featureModules: {
            [OPF_CTA_FEATURE]: {
                cmsComponents: ['OpfCtaScriptsComponent', 'OpfCtaQuickBuyButtons'],
            },
        },
    };
    return config;
}
class OpfCtaRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaRootModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaRootModule, providers: [provideDefaultConfigFactory(defaultOpfCtaCmsComponentsConfig)] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaRootModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [provideDefaultConfigFactory(defaultOpfCtaCmsComponentsConfig)],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OPF_CTA_FEATURE, OpfCtaCmsPageLocation, OpfCtaDynamicLocations, OpfCtaEvent, OpfCtaFacade, OpfCtaRootModule, OpfCtaScriptsLocation, defaultOpfCtaCmsComponentsConfig };
//# sourceMappingURL=spartacus-opf-cta-root.mjs.map
