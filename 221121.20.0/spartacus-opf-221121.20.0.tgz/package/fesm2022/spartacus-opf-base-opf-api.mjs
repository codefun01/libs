import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { ConverterService, LoggerService, UserIdService, tryNormalizeHttpError, provideDefaultConfig } from '@spartacus/core';
import { OpfEndpointsService, OPF_ACTIVE_CONFIGURATIONS_NORMALIZER, OpfBaseAdapter } from '@spartacus/opf/base/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActiveCartFacade, CartAccessCodeFacade } from '@spartacus/cart/base/root';
import { OpfConfig, OpfMetadataStatePersistanceService, OPF_CC_PUBLIC_KEY_HEADER, OPF_CC_ACCESS_CODE_HEADER } from '@spartacus/opf/base/root';
import { of } from 'rxjs';
import { switchMap, catchError, map } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfApiBaseAdapter {
    constructor() {
        this.http = inject(HttpClient);
        this.converter = inject(ConverterService);
        this.opfEndpointsService = inject(OpfEndpointsService);
        this.config = inject(OpfConfig);
        this.opfMetadataStatePersistanceService = inject(OpfMetadataStatePersistanceService);
        this.logger = inject(LoggerService);
        this.userIdService = inject(UserIdService);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.cartAccessCodeFacade = inject(CartAccessCodeFacade);
        this.headerWithNoLanguage = {
            accept: 'application/json',
            'Content-Type': 'application/json',
        };
        this.header = {
            ...this.headerWithNoLanguage,
            'Accept-Language': this.opfMetadataStatePersistanceService.getActiveLanguage(),
        };
        this.headerWithContentLanguage = {
            ...this.headerWithNoLanguage,
            'Content-Language': this.opfMetadataStatePersistanceService.getActiveLanguage(),
        };
    }
    getActiveConfigurations(query) {
        return this.getHeaders().pipe(switchMap((headers) => this.http.get(this.getActiveConfigurationsEndpoint(query), { headers })), catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), this.converter.pipeable(OPF_ACTIVE_CONFIGURATIONS_NORMALIZER));
    }
    getActiveConfigurationsEndpoint(query) {
        return this.opfEndpointsService.buildUrl('getActiveConfigurations', {
            queryParams: query,
        });
    }
    getHeaders() {
        const headers = new HttpHeaders(this.header).set(OPF_CC_PUBLIC_KEY_HEADER, this.config.opf?.commerceCloudPublicKey || '');
        if (this.config.opf?.enableGetActiveConfigurationsAccessCodeHeader) {
            return this.getAccessCode().pipe(map((accessCode) => headers.set(OPF_CC_ACCESS_CODE_HEADER, accessCode)));
        }
        return of(headers);
    }
    getAccessCode() {
        return this.userIdService.takeUserId().pipe(switchMap((userId) => this.activeCartFacade
            .takeActiveCartId()
            .pipe(switchMap((cartId) => this.cartAccessCodeFacade.getCartAccessCode(userId, cartId)))), map((response) => response?.accessCode ?? ''));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiBaseAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiBaseAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiBaseAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOpfApiBaseConfig = {
    backend: {
        opfApi: {
            endpoints: {
                getActiveConfigurations: 'active-configurations',
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfApiBaseModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiBaseModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfApiBaseModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiBaseModule, providers: [
            provideDefaultConfig(defaultOpfApiBaseConfig),
            {
                provide: OpfBaseAdapter,
                useClass: OpfApiBaseAdapter,
            },
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiBaseModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [
                        provideDefaultConfig(defaultOpfApiBaseConfig),
                        {
                            provide: OpfBaseAdapter,
                            useClass: OpfApiBaseAdapter,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfApiBaseModule };
//# sourceMappingURL=spartacus-opf-base-opf-api.mjs.map
