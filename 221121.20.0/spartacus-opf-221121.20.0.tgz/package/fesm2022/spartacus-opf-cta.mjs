import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { OpfCtaComponentsModule } from '@spartacus/opf/cta/components';
import { OpfCtaCoreModule } from '@spartacus/opf/cta/core';
import { OpfApiCtaModule } from '@spartacus/opf/cta/opf-api';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCtaModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaModule, imports: [OpfCtaCoreModule, OpfApiCtaModule, OpfCtaComponentsModule], exports: [OpfCtaComponentsModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaModule, imports: [OpfCtaCoreModule, OpfApiCtaModule, OpfCtaComponentsModule, OpfCtaComponentsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCtaModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OpfCtaCoreModule, OpfApiCtaModule, OpfCtaComponentsModule],
                    exports: [OpfCtaComponentsModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfCtaModule };
//# sourceMappingURL=spartacus-opf-cta.mjs.map
