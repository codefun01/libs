import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { OpfTokenisationComponentsModule } from '@spartacus/opf/tokenisation/components';
import { OpfTokenisationCoreModule } from '@spartacus/opf/tokenisation/core';
import { OpfTokenisationRootModule } from '@spartacus/opf/tokenisation/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfTokenisationModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationModule, imports: [OpfTokenisationComponentsModule,
            OpfTokenisationCoreModule,
            OpfTokenisationRootModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationModule, imports: [OpfTokenisationComponentsModule,
            OpfTokenisationCoreModule,
            OpfTokenisationRootModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        OpfTokenisationComponentsModule,
                        OpfTokenisationCoreModule,
                        OpfTokenisationRootModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfTokenisationModule };
//# sourceMappingURL=spartacus-opf-tokenisation.mjs.map
