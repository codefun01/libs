import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { CheckoutPaymentTypeSetEvent, B2BPaymentTypeEnum, CheckoutPaymentTypeFacade } from '@spartacus/checkout/b2b/root';
import * as i2 from '@spartacus/core';
import { CommandStrategy, OCC_USER_ID_ANONYMOUS } from '@spartacus/core';
import { combineLatest, of } from 'rxjs';
import { switchMap, tap, take, map } from 'rxjs/operators';
import { OpfPaymentFacade } from '@spartacus/opf/payment/root';
import * as i1 from '@spartacus/cart/base/root';
import * as i3 from '@spartacus/checkout/base/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfB2bCheckoutPaymentTypeService {
    constructor(activeCartFacade, userIdService, queryService, commandService, eventService, checkoutQueryFacade) {
        this.activeCartFacade = activeCartFacade;
        this.userIdService = userIdService;
        this.queryService = queryService;
        this.commandService = commandService;
        this.eventService = eventService;
        this.checkoutQueryFacade = checkoutQueryFacade;
        this.opfPaymentFacade = inject(OpfPaymentFacade);
        this.setPaymentTypeCommand = this.commandService.create(({ paymentTypeCode, purchaseOrderNumber }) => this.checkoutPreconditions().pipe(switchMap(([userId, cartId]) => this.opfPaymentFacade
            .setCartPaymentOption(userId, cartId, paymentTypeCode, purchaseOrderNumber)
            .pipe(tap(() => this.eventService.dispatch({
            userId,
            cartId,
            paymentTypeCode,
            purchaseOrderNumber,
        }, CheckoutPaymentTypeSetEvent))))), {
            strategy: CommandStrategy.CancelPrevious,
        });
    }
    checkoutPreconditions() {
        return combineLatest([
            this.userIdService.takeUserId(),
            this.activeCartFacade.takeActiveCartId(),
            this.activeCartFacade.isGuestCart(),
        ]).pipe(take(1), map(([userId, cartId, isGuestCart]) => {
            if (!userId ||
                !cartId ||
                (userId === OCC_USER_ID_ANONYMOUS && !isGuestCart)) {
                throw new Error('Checkout conditions not met');
            }
            return [userId, cartId];
        }));
    }
    getPaymentTypesState() {
        return of();
    }
    getPaymentTypes() {
        return this.getPaymentTypesState().pipe(map((state) => state.data ?? []));
    }
    setPaymentType(paymentTypeCode, purchaseOrderNumber) {
        return this.setPaymentTypeCommand.execute({
            paymentTypeCode,
            purchaseOrderNumber,
        });
    }
    getSelectedPaymentTypeState() {
        return this.activeCartFacade.getActive().pipe(take(1), map((cart) => ({
            data: cart.paymentType,
            loading: false,
            error: false,
        })));
    }
    isAccountPayment() {
        return this.activeCartFacade.getActive().pipe(take(1), map((cart) => cart.paymentType?.code === B2BPaymentTypeEnum.ACCOUNT_PAYMENT));
    }
    getPurchaseOrderNumberState() {
        return this.activeCartFacade.getActive().pipe(take(1), map((cart) => ({
            data: cart.purchaseOrderNumber,
            loading: false,
            error: false,
        })));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPaymentTypeService, deps: [{ token: i1.ActiveCartFacade }, { token: i2.UserIdService }, { token: i2.QueryService }, { token: i2.CommandService }, { token: i2.EventService }, { token: i3.CheckoutQueryFacade }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPaymentTypeService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutPaymentTypeService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.ActiveCartFacade }, { type: i2.UserIdService }, { type: i2.QueryService }, { type: i2.CommandService }, { type: i2.EventService }, { type: i3.CheckoutQueryFacade }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const facadeProviders = [
    OpfB2bCheckoutPaymentTypeService,
    {
        provide: CheckoutPaymentTypeFacade,
        useExisting: OpfB2bCheckoutPaymentTypeService,
    },
];

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfB2bCheckoutCoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutCoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutCoreModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutCoreModule, providers: [...facadeProviders] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutCoreModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [...facadeProviders],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfB2bCheckoutCoreModule, OpfB2bCheckoutPaymentTypeService };
//# sourceMappingURL=spartacus-opf-b2b-checkout-core.mjs.map
