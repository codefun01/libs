import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { OpfQuickBuyModule } from '@spartacus/opf/quick-buy';
import { OpfQuickBuySingleProductCartOptionsFacade } from '@spartacus/opf/quick-buy/root';
import { OpfQuickBuyDefaultSingleProductService } from '@spartacus/opf/quick-buy/core';
import { IntendedPickupLocationFacade } from '@spartacus/pickup-in-store/root';
import { combineLatest } from 'rxjs';
import { switchMap, map } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyPickupInStoreSingleProductService {
    constructor() {
        this.defaultSingleProductService = inject(OpfQuickBuyDefaultSingleProductService);
        this.intendedPickupLocation = inject(IntendedPickupLocationFacade);
    }
    getSingleProductCartOptions(productCode) {
        return this.defaultSingleProductService
            .getSingleProductCartOptions(productCode)
            .pipe(switchMap((baseOptions) => combineLatest([
            this.intendedPickupLocation.getPickupOption(productCode),
            this.intendedPickupLocation.getIntendedLocation(productCode),
        ]).pipe(map(([pickupOption, intendedLocation]) => ({
            ...baseOptions,
            ...(pickupOption === 'pickup' && intendedLocation?.name
                ? { pickupStore: intendedLocation.name }
                : {}),
        })))));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyPickupInStoreSingleProductService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyPickupInStoreSingleProductService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyPickupInStoreSingleProductService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfQuickBuyPickupInStoreModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyPickupInStoreModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyPickupInStoreModule, imports: [OpfQuickBuyModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyPickupInStoreModule, providers: [
            OpfQuickBuyPickupInStoreSingleProductService,
            {
                provide: OpfQuickBuySingleProductCartOptionsFacade,
                useExisting: OpfQuickBuyPickupInStoreSingleProductService,
            },
        ], imports: [OpfQuickBuyModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfQuickBuyPickupInStoreModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OpfQuickBuyModule],
                    providers: [
                        OpfQuickBuyPickupInStoreSingleProductService,
                        {
                            provide: OpfQuickBuySingleProductCartOptionsFacade,
                            useExisting: OpfQuickBuyPickupInStoreSingleProductService,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfQuickBuyPickupInStoreModule, OpfQuickBuyPickupInStoreSingleProductService };
//# sourceMappingURL=spartacus-opf-quick-buy-pickup-in-store.mjs.map
