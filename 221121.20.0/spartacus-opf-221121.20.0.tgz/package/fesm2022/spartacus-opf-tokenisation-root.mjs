import * as i0 from '@angular/core';
import { Injectable, inject, ChangeDetectionStrategy, Component, Optional, ChangeDetectorRef, NgModule, EventEmitter, Output, Input } from '@angular/core';
import * as i2 from '@spartacus/core';
import { facadeFactory, UserPaymentService, TranslatePipe, RoutingService, GlobalMessageService, TranslationService, WindowRef, getLastValueSync, GlobalMessageType, I18nModule, FeaturesConfigModule, provideDefaultConfig, AuthGuard, OccUserPaymentAdapter, LoggerService, tryNormalizeHttpError, PAYMENT_DETAILS_NORMALIZER, UserPaymentAdapter, provideDefaultConfigFactory } from '@spartacus/core';
import { OutletContextData, ICON_TYPE, IconComponent, SelectFocusUtility, CardComponent, SpinnerComponent, CardModule, SpinnerModule, FormRequiredLegendComponent, provideOutlet, OutletPosition } from '@spartacus/storefront';
import { OpfCheckoutOutlets } from '@spartacus/opf/checkout/root';
import { NgIf, AsyncPipe, NgFor, SlicePipe, CommonModule } from '@angular/common';
import { OpfMetadataStoreService } from '@spartacus/opf/base/root';
import { Subscription, BehaviorSubject, combineLatest, of } from 'rxjs';
import { map, distinctUntilChanged, pairwise, filter, take, switchMap, withLatestFrom, tap, catchError } from 'rxjs/operators';
import { CheckoutPaymentFacade, CheckoutDeliveryAddressFacade } from '@spartacus/checkout/base/root';
import { OrderFacade } from '@spartacus/order/root';
import { CheckoutStepService, CheckoutPaymentFormModule, CheckoutAuthGuard, CartNotEmptyGuard } from '@spartacus/checkout/base/components';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { ActiveCartFacade } from '@spartacus/cart/base/root';
import * as i1 from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_TOKENISATION_FEATURE = 'opfTokenisation';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfTokenisationFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: OpfTokenisationFacade,
            feature: OPF_TOKENISATION_FEATURE,
            methods: [
                'getPaymentMethods',
                'getPaymentMethodsLoading',
                'loadPaymentMethods',
                'deletePaymentMethod',
                'setPaymentMethodAsDefault',
            ],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: OpfTokenisationFacade,
                        feature: OPF_TOKENISATION_FEATURE,
                        methods: [
                            'getPaymentMethods',
                            'getPaymentMethodsLoading',
                            'loadPaymentMethods',
                            'deletePaymentMethod',
                            'setPaymentMethodAsDefault',
                        ],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const SAVED_CARDS_ID = -1;
/**
 * Manages saved cards selection state and payment method transitions.
 * Reactively triggers deletion of saved payment details when the user
 * switches from saved cards to an active payment provider.
 */
class OpfTokenisationSavedCardsService {
    constructor() {
        this.checkoutPaymentFacade = inject(CheckoutPaymentFacade);
        this.opfMetadataStoreService = inject(OpfMetadataStoreService);
        this.subscription = new Subscription();
        /**
         * Tracks whether a card was selected from the saved cards list.
         * Used to distinguish between "just selecting saved cards" vs "selecting a card for payment"
         */
        this.cardSelected$ = new BehaviorSubject(false);
        /**
         * Persists the ID of the last saved card the user selected for payment.
         * Survives component destruction so selection is retained when navigating back.
         */
        this.selectedPaymentMethodId$ = new BehaviorSubject(undefined);
        this.listenForPaymentTransitions();
    }
    /**
     * Marks saved cards as the selected payment option
     * by writing SAVED_CARDS_ID to the metadata store.
     */
    selectSavedCards() {
        // Reset card selection flag when user selects saved cards option
        this.cardSelected$.next(false);
        this.opfMetadataStoreService.updateOpfMetadata({
            selectedPaymentOptionId: SAVED_CARDS_ID,
        });
    }
    /**
     * Marks that a specific card has been selected from the saved cards list
     * and persists its ID so it can be restored after navigation.
     */
    markCardAsSelected(id) {
        this.cardSelected$.next(true);
        if (id !== undefined) {
            this.selectedPaymentMethodId$.next(id);
        }
    }
    /**
     * Clears the persisted selected card ID.
     * Call this when the user fully leaves saved-cards mode.
     */
    clearSelectedPaymentMethodId() {
        this.selectedPaymentMethodId$.next(undefined);
    }
    /**
     * Returns whether saved cards are currently selected
     * based on the metadata store value.
     */
    areSavedCardsSelected() {
        return (this.opfMetadataStoreService.opfMetadataState.value
            .selectedPaymentOptionId === SAVED_CARDS_ID);
    }
    /**
     * Determines if user is transitioning away from saved cards to a specific payment method.
     * Checks that:
     * - Previous payment was SAVED_CARDS_ID
     * - Current payment is not SAVED_CARDS_ID
     * - Current payment is defined
     * - A card was actually selected from saved cards list
     */
    isTransitioningFromSavedCardsWithCardSelected(prev, curr) {
        return (prev === SAVED_CARDS_ID &&
            curr !== SAVED_CARDS_ID &&
            curr !== undefined &&
            this.cardSelected$.value);
    }
    /**
     * Watches the metadata store for transitions from SAVED_CARDS_ID
     * to any other payment option. When detected and a card was previously selected,
     * deletes the saved payment details from the backend.
     */
    listenForPaymentTransitions() {
        this.subscription.add(this.opfMetadataStoreService
            .getOpfMetadataState()
            .pipe(map((state) => state.selectedPaymentOptionId), distinctUntilChanged(), pairwise())
            .subscribe(([prev, curr]) => {
            if (this.isTransitioningFromSavedCardsWithCardSelected(prev, curr)) {
                this.checkoutPaymentFacade.deletePaymentDetails().subscribe();
                // Reset the flag after deleting
                this.cardSelected$.next(false);
            }
        }));
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationSavedCardsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationSavedCardsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationSavedCardsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfTokenisationSavedCardsToggleComponent {
    constructor() {
        this.outletContextData = inject(OutletContextData, { optional: true });
        this.savedCardsService = inject(OpfTokenisationSavedCardsService, {
            optional: true,
        });
        this.opfMetadataStoreService = inject(OpfMetadataStoreService);
        this.userPaymentService = inject(UserPaymentService);
        this.iconTypes = ICON_TYPE;
        this.SAVED_CARDS_ID = SAVED_CARDS_ID;
        this.context$ = combineLatest([
            this.outletContextData?.context$ ?? of({}),
            this.userPaymentService.getPaymentMethods(),
        ]).pipe(map(([ctx, paymentMethods]) => ({
            ...ctx,
            hasSavedCards: Boolean(paymentMethods?.length),
        })));
        /**
         * Whether the saved cards radio should be checked.
         * Reads selectedPaymentOptionId from the metadata store reactively.
         */
        this.isSavedCardsChecked$ = this.opfMetadataStoreService
            .getOpfMetadataState()
            .pipe(map((state) => state.selectedPaymentOptionId === SAVED_CARDS_ID));
    }
    onSavedCardsSelected() {
        this.savedCardsService?.selectSavedCards();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationSavedCardsToggleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfTokenisationSavedCardsToggleComponent, isStandalone: true, selector: "cx-opf-tokenisation-saved-cards-toggle", ngImport: i0, template: "<ng-container *ngIf=\"context$ | async as ctx\">\n  <ng-container *ngIf=\"ctx.hasSavedCards === true\">\n    <div\n      class=\"cx-payment-options-section\"\n      [attr.aria-label]=\"\n        ctx.savedPaymentHeading ||\n        ('opfCheckout.savedPaymentHeading' | cxTranslate)\n      \"\n    >\n      <h3 class=\"cx-payment-section-heading\">\n        {{\n          ctx.savedPaymentHeading ||\n            ('opfCheckout.savedPaymentHeading' | cxTranslate)\n        }}\n      </h3>\n    </div>\n\n    <div class=\"form-check cx-saved-cards-option\">\n      <input\n        id=\"paymentId-saved-cards\"\n        class=\"form-check-input\"\n        role=\"radio\"\n        type=\"radio\"\n        name=\"paymentId\"\n        [value]=\"ctx.savedCardsId ?? SAVED_CARDS_ID\"\n        [checked]=\"(isSavedCardsChecked$ | async) === true\"\n        [disabled]=\"ctx.disabled\"\n        (change)=\"onSavedCardsSelected()\"\n      />\n\n      <label\n        class=\"cx-payment-type-label form-check-label form-radio-label\"\n        for=\"paymentId-saved-cards\"\n      >\n        <div class=\"cx-payment-type\">\n          <cx-icon [type]=\"iconTypes.CREDIT_CARD\" class=\"cx-payment-icon\" />\n          <span>{{\n            ctx.savedCardsHeading || ('opfCheckout.cards' | cxTranslate)\n          }}</span>\n        </div>\n      </label>\n    </div>\n  </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationSavedCardsToggleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-tokenisation-saved-cards-toggle', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, IconComponent, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"context$ | async as ctx\">\n  <ng-container *ngIf=\"ctx.hasSavedCards === true\">\n    <div\n      class=\"cx-payment-options-section\"\n      [attr.aria-label]=\"\n        ctx.savedPaymentHeading ||\n        ('opfCheckout.savedPaymentHeading' | cxTranslate)\n      \"\n    >\n      <h3 class=\"cx-payment-section-heading\">\n        {{\n          ctx.savedPaymentHeading ||\n            ('opfCheckout.savedPaymentHeading' | cxTranslate)\n        }}\n      </h3>\n    </div>\n\n    <div class=\"form-check cx-saved-cards-option\">\n      <input\n        id=\"paymentId-saved-cards\"\n        class=\"form-check-input\"\n        role=\"radio\"\n        type=\"radio\"\n        name=\"paymentId\"\n        [value]=\"ctx.savedCardsId ?? SAVED_CARDS_ID\"\n        [checked]=\"(isSavedCardsChecked$ | async) === true\"\n        [disabled]=\"ctx.disabled\"\n        (change)=\"onSavedCardsSelected()\"\n      />\n\n      <label\n        class=\"cx-payment-type-label form-check-label form-radio-label\"\n        for=\"paymentId-saved-cards\"\n      >\n        <div class=\"cx-payment-type\">\n          <cx-icon [type]=\"iconTypes.CREDIT_CARD\" class=\"cx-payment-icon\" />\n          <span>{{\n            ctx.savedCardsHeading || ('opfCheckout.cards' | cxTranslate)\n          }}</span>\n        </div>\n      </label>\n    </div>\n  </ng-container>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfTokenisationNewPaymentsHeadingComponent {
    constructor() {
        this.outletContextData = inject(OutletContextData, { optional: true });
        this.userPaymentService = inject(UserPaymentService);
        this.context$ = combineLatest([
            this.outletContextData?.context$ ?? of({}),
            this.userPaymentService.getPaymentMethods(),
        ]).pipe(map(([ctx, paymentMethods]) => ({
            ...ctx,
            hasSavedCards: Boolean(paymentMethods?.length),
        })));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationNewPaymentsHeadingComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfTokenisationNewPaymentsHeadingComponent, isStandalone: true, selector: "cx-opf-tokenisation-new-payments-heading", ngImport: i0, template: "<ng-container *ngIf=\"context$ | async as ctx\">\n  <ng-container *ngIf=\"ctx.hasSavedCards === true\">\n    <div\n      class=\"cx-payment-options-section\"\n      [attr.aria-label]=\"\n        ctx.newPaymentHeading || ('opfCheckout.newPaymentHeading' | cxTranslate)\n      \"\n    >\n      <h3 class=\"cx-payment-section-heading\">\n        {{\n          ctx.newPaymentHeading ||\n            ('opfCheckout.newPaymentHeading' | cxTranslate)\n        }}\n      </h3>\n    </div>\n  </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationNewPaymentsHeadingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-tokenisation-new-payments-heading', standalone: true, imports: [NgIf, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"context$ | async as ctx\">\n  <ng-container *ngIf=\"ctx.hasSavedCards === true\">\n    <div\n      class=\"cx-payment-options-section\"\n      [attr.aria-label]=\"\n        ctx.newPaymentHeading || ('opfCheckout.newPaymentHeading' | cxTranslate)\n      \"\n    >\n      <h3 class=\"cx-payment-section-heading\">\n        {{\n          ctx.newPaymentHeading ||\n            ('opfCheckout.newPaymentHeading' | cxTranslate)\n        }}\n      </h3>\n    </div>\n  </ng-container>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
function sortPaymentMethodsForDisplay(paymentDetails) {
    const defaultPayments = [];
    const activeNonDefaultPayments = [];
    const expiredNonDefaultPayments = [];
    paymentDetails.forEach((paymentDetail) => {
        if (paymentDetail.defaultPayment) {
            defaultPayments.push(paymentDetail);
        }
        else if (isTokenisationCardExpired(paymentDetail)) {
            expiredNonDefaultPayments.push(paymentDetail);
        }
        else {
            activeNonDefaultPayments.push(paymentDetail);
        }
    });
    return [
        ...defaultPayments,
        ...activeNonDefaultPayments,
        ...expiredNonDefaultPayments,
    ];
}
function isTokenisationCardExpired(paymentMethod) {
    const { expiryMonth, expiryYear } = paymentMethod;
    if (!expiryMonth || !expiryYear) {
        return false;
    }
    const now = new Date();
    const currentMonth = now.getMonth() + 1;
    const currentYear = now.getFullYear();
    const parsedMonth = parseInt(expiryMonth, 10);
    const normalizedYear = normalizeExpiryYear(expiryYear);
    if (Number.isNaN(parsedMonth) ||
        parsedMonth < 1 ||
        parsedMonth > 12 ||
        Number.isNaN(normalizedYear)) {
        return false;
    }
    return (normalizedYear < currentYear ||
        (normalizedYear === currentYear && parsedMonth < currentMonth));
}
function normalizeExpiryYear(expiryYear) {
    const parsed = parseInt(expiryYear, 10);
    if (parsed < 100) {
        return 2000 + parsed;
    }
    return parsed;
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfTokenisationPaymentMethodService {
    constructor() {
        this.userPaymentService = inject(UserPaymentService);
        this.checkoutPaymentFacade = inject(CheckoutPaymentFacade);
        this.opfMetadataStoreService = inject(OpfMetadataStoreService);
        this.savedCardsService = inject(OpfTokenisationSavedCardsService);
        this.orderFacade = inject(OrderFacade);
        this.routingService = inject(RoutingService);
        this.checkoutStepService = inject(CheckoutStepService);
        this.activatedRoute = inject(ActivatedRoute);
        this.globalMessageService = inject(GlobalMessageService);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.translationService = inject(TranslationService);
        this.checkoutDeliveryAddressFacade = inject(CheckoutDeliveryAddressFacade);
        this.outletContextData = inject(OutletContextData, { optional: true });
        this.windowRef = inject(WindowRef);
        this.focusService = inject(SelectFocusUtility);
        this.busy$ = new BehaviorSubject(false);
        this.subscriptions = new Subscription();
        this.isGuestCheckout = false;
        this.showSavedCards$ = this.opfMetadataStoreService
            .getOpfMetadataState()
            .pipe(map((state) => state?.selectedPaymentOptionId === SAVED_CARDS_ID), distinctUntilChanged());
        this.isUpdating$ = combineLatest([
            this.busy$,
            this.userPaymentService.getPaymentMethodsLoading(),
            this.checkoutPaymentFacade
                .getPaymentDetailsState()
                .pipe(map((state) => state.loading)),
        ]).pipe(map(([busy, userPaymentLoading, paymentMethodLoading]) => busy || userPaymentLoading || paymentMethodLoading), distinctUntilChanged());
        this.selectedPaymentMethod$ = new BehaviorSubject(undefined);
    }
    get existingPaymentMethods$() {
        return this.userPaymentService.getPaymentMethods();
    }
    // instead of reading from checkoutPaymentFacade (which depends on the backend returning paymentInfo), we are using the local subject
    get selectedMethod$() {
        return this.selectedPaymentMethod$.asObservable();
    }
    initialize() {
        if (!getLastValueSync(this.activeCartFacade.isGuestCart())) {
            this.userPaymentService.loadPaymentMethods();
        }
        else {
            this.isGuestCheckout = true;
        }
        this.checkoutDeliveryAddressFacade
            .getDeliveryAddressState()
            .pipe(filter((state) => !state.loading), take(1), map((state) => state.data))
            .subscribe((address) => {
            this.deliveryAddress = address;
        });
        // Clear only local selected card when switching away from saved cards.
        // Keep persisted selected ID so we can restore it when user returns.
        this.subscriptions.add(this.opfMetadataStoreService
            .getOpfMetadataState()
            .pipe(map((state) => state?.selectedPaymentOptionId), distinctUntilChanged())
            .subscribe((selectedId) => {
            // If we're no longer in saved cards mode, clear local selected card
            if (selectedId !== SAVED_CARDS_ID) {
                this.selectedPaymentMethod$.next(undefined);
            }
        }));
        // Auto-select the default non-expired card once when saved cards become visible.
        // If the user navigated back with a previously selected card, restore it from the
        // root-level savedCardsService (which survives component destruction).
        // Otherwise fall back to the default-card logic.
        this.subscriptions.add(this.showSavedCards$
            .pipe(filter((show) => show), switchMap(() => this.existingPaymentMethods$.pipe(filter((methods) => !!methods?.length), take(1), withLatestFrom(this.selectedMethod$, this.savedCardsService.selectedPaymentMethodId$))))
            .subscribe(([methods, selectedMethod, persistedId]) => {
            // Restore previously selected card when navigating back
            if (persistedId && !selectedMethod?.id) {
                const previouslySelected = methods.find((m) => m.id === persistedId);
                if (previouslySelected && !this.isCardExpired(previouslySelected)) {
                    this.selectedPaymentMethod$.next(previouslySelected);
                    this.savePaymentMethod(previouslySelected);
                    return;
                }
            }
            this.selectDefaultPaymentMethod(methods, selectedMethod);
        }));
    }
    getCards$() {
        return combineLatest([
            this.existingPaymentMethods$.pipe(switchMap((methods) => {
                const sortedMethods = sortPaymentMethodsForDisplay(methods ?? []);
                return !methods?.length
                    ? of([])
                    : combineLatest(sortedMethods.map((method) => combineLatest([
                        of(method),
                        this.translationService.translate('paymentCard.expires', {
                            month: method.expiryMonth,
                            year: method.expiryYear,
                        }),
                    ]).pipe(map(([payment, translation]) => ({
                        payment,
                        expiryTranslation: translation,
                    })))));
            })),
            this.selectedMethod$,
            this.translationService.translate('paymentForm.useThisCard'),
            this.translationService.translate('paymentCard.selected'),
            this.translationService.translate('paymentCard.setAsDefault'),
            this.translationService.translate('paymentCard.defaultLabelOnCheckout'),
        ]).pipe(map(([paymentMethods, selectedMethod, textUseThisPayment, textSelected, textSetAsDefault, textDefaultLabelOnCheckout,]) => paymentMethods.map((payment) => ({
            content: this.createCard(payment.payment, {
                textExpires: payment.expiryTranslation,
                textUseThisPayment,
                textSelected,
                textSetAsDefault,
                textDefaultLabelOnCheckout,
            }, selectedMethod),
            paymentMethod: payment.payment,
        }))));
    }
    isCardExpired(paymentDetails) {
        return isTokenisationCardExpired(paymentDetails);
    }
    selectDefaultPaymentMethod(paymentMethods, selectedMethod) {
        if (paymentMethods?.length &&
            (!selectedMethod || Object.keys(selectedMethod).length === 0)) {
            const defaultPaymentMethod = paymentMethods.find((paymentMethod) => paymentMethod.defaultPayment && !this.isCardExpired(paymentMethod));
            if (defaultPaymentMethod) {
                this.selectedPaymentMethod$.next(defaultPaymentMethod);
                this.savePaymentMethod(defaultPaymentMethod);
                return;
            }
            const singleNonExpiredCard = paymentMethods.length === 1 && !this.isCardExpired(paymentMethods[0])
                ? paymentMethods[0]
                : undefined;
            if (singleNonExpiredCard) {
                this.setDefaultPaymentMethod(singleNonExpiredCard, false);
                this.selectedPaymentMethod$.next(singleNonExpiredCard);
                this.savePaymentMethod(singleNonExpiredCard);
            }
        }
    }
    setDefaultPaymentMethod(paymentDetails, notify = true) {
        this.userPaymentService.setPaymentMethodAsDefault(paymentDetails.id ?? '');
        if (notify) {
            this.globalMessageService.add({ key: 'paymentMessages.setAsDefaultSuccessfully' }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
        }
    }
    savePaymentMethod(paymentDetails) {
        this.busy$.next(true);
        this.subscriptions.add(this.checkoutPaymentFacade.setPaymentDetails(paymentDetails).subscribe({
            complete: () => this.onSuccess(),
            error: () => this.onError(),
        }));
    }
    /**
     * Restores the focus to the Card component after it has been selected and the checkout has finished updating.
     * The focus is lost due to DOM changes making it otherwise impossible to target elements that have been removed.
     */
    focusCardAfterSelecting() {
        const cardNodes = Array.from(this.windowRef?.document.querySelectorAll('cx-card'));
        const triggeredCard = this.windowRef?.document.activeElement?.closest('cx-card');
        if (triggeredCard) {
            const selectedCardIndex = cardNodes.indexOf(triggeredCard);
            this.isUpdating$
                .pipe(filter((isUpdating) => !isUpdating), take(1))
                .subscribe(() => {
                requestAnimationFrame(() => {
                    const selectedCard = this.windowRef?.document.querySelectorAll('cx-card')[selectedCardIndex];
                    this.focusService.findFirstFocusable(selectedCard)?.focus();
                });
            });
        }
    }
    setPaymentDetails({ paymentDetails, billingAddress, }) {
        this.paymentDetails = paymentDetails;
        const details = { ...paymentDetails };
        details.billingAddress = billingAddress ?? this.deliveryAddress;
        this.busy$.next(true);
        this.subscriptions.add(this.checkoutPaymentFacade.createPaymentDetails(details).subscribe({
            complete: () => {
                // we don't call onSuccess here, because it can cause a spinner flickering
                this.next();
            },
            error: () => {
                this.onError();
            },
        }));
    }
    createCard(paymentDetails, cardLabels, selected) {
        const isSelected = selected?.id === paymentDetails.id;
        const role = !isSelected ? 'button' : 'application';
        const isExpired = this.isCardExpired(paymentDetails);
        const actions = [];
        if (!paymentDetails.defaultPayment && !isExpired) {
            actions.push({ name: cardLabels.textSetAsDefault, event: 'default' });
        }
        if (!isSelected && !isExpired) {
            actions.push({ name: cardLabels.textUseThisPayment, event: 'send' });
        }
        const cardTitle = paymentDetails.defaultPayment
            ? cardLabels.textDefaultLabelOnCheckout
            : '';
        return {
            role,
            title: cardTitle,
            textBold: paymentDetails.cardType?.name,
            text: [paymentDetails.cardNumber ?? '', cardLabels.textExpires],
            actions,
            header: isSelected ? cardLabels.textSelected : undefined,
            label: paymentDetails.defaultPayment
                ? 'paymentCard.defaultPaymentLabel'
                : 'paymentCard.additionalPaymentLabel',
        };
    }
    selectPaymentMethod(paymentDetails) {
        if (this.isCardExpired(paymentDetails)) {
            return;
        }
        if (paymentDetails?.id === this.selectedPaymentMethod$.getValue()?.id) {
            return;
        }
        // Mark that a saved card was selected (used to trigger delete only on provider switch)
        // Also persists the ID for restoration when navigating back
        this.savedCardsService.markCardAsSelected(paymentDetails.id);
        this.globalMessageService.add({
            key: 'paymentMethods.paymentMethodSelected',
        }, GlobalMessageType.MSG_TYPE_INFO);
        this.selectedPaymentMethod$.next(paymentDetails);
        this.savePaymentMethod(paymentDetails);
        this.focusCardAfterSelecting();
    }
    next() {
        this.busy$.next(true);
        this.subscriptions.add(this.orderFacade
            .placePaymentAuthorizedOrder(true)
            .pipe(tap((order) => {
            if (order) {
                this.busy$.next(false);
                this.routingService.go({ cxRoute: 'orderConfirmation' });
            }
        }))
            .subscribe({
            error: () => {
                this.busy$.next(false);
            },
        }));
    }
    back() {
        this.checkoutStepService.back(this.activatedRoute);
    }
    onSuccess() {
        this.busy$.next(false);
    }
    onError() {
        this.busy$.next(false);
        this.selectedPaymentMethod$.next(undefined);
    }
    destroy() {
        this.subscriptions.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationPaymentMethodService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationPaymentMethodService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationPaymentMethodService, decorators: [{
            type: Injectable
        }], propDecorators: { windowRef: [{
                type: Optional
            }], focusService: [{
                type: Optional
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfTokenisationPaymentMethodComponent {
    constructor() {
        this.OpfTokenisationPaymentMethodService = inject(OpfTokenisationPaymentMethodService);
        this.cdr = inject(ChangeDetectorRef);
        this.iconTypes = ICON_TYPE;
        this.showAll = false;
        this.VISIBLE_CARDS_COUNT = 2;
    }
    ngOnInit() {
        this.OpfTokenisationPaymentMethodService.initialize();
        this.cards$ = this.OpfTokenisationPaymentMethodService.getCards$();
        this.isUpdating$ = this.OpfTokenisationPaymentMethodService.isUpdating$;
        this.selectedMethod$ =
            this.OpfTokenisationPaymentMethodService.selectedMethod$;
        this.showSavedCards$ =
            this.OpfTokenisationPaymentMethodService.showSavedCards$;
        // Auto-expand "show all" if the restored/selected card is beyond the initially
        // visible limit (e.g. when navigating back with a 3rd-or-later card selected).
        combineLatest([this.cards$, this.selectedMethod$])
            .pipe(filter(([cards, selected]) => cards.length > this.VISIBLE_CARDS_COUNT && !!selected?.id), take(1))
            .subscribe(([cards, selected]) => {
            const selectedIndex = cards.findIndex((c) => c.paymentMethod.id === selected?.id);
            if (selectedIndex >= this.VISIBLE_CARDS_COUNT) {
                this.showAll = true;
                this.cdr.markForCheck();
            }
        });
    }
    selectPaymentMethod(paymentDetails) {
        this.OpfTokenisationPaymentMethodService.selectPaymentMethod(paymentDetails);
    }
    onCardClick(event, paymentDetails) {
        if (this.isCardExpired(paymentDetails)) {
            return;
        }
        const target = event.target;
        if (target?.closest('button, a, cx-generic-link')) {
            return;
        }
        this.selectPaymentMethod(paymentDetails);
    }
    setDefaultPaymentMethod(paymentDetails) {
        this.OpfTokenisationPaymentMethodService.setDefaultPaymentMethod(paymentDetails);
    }
    isCardExpired(paymentDetails) {
        return this.OpfTokenisationPaymentMethodService.isCardExpired(paymentDetails);
    }
    setPaymentDetails({ paymentDetails, billingAddress, }) {
        this.OpfTokenisationPaymentMethodService.setPaymentDetails({
            paymentDetails,
            billingAddress,
        });
    }
    next() {
        this.OpfTokenisationPaymentMethodService.next();
    }
    back() {
        this.OpfTokenisationPaymentMethodService.back();
    }
    ngOnDestroy() {
        this.OpfTokenisationPaymentMethodService.destroy();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationPaymentMethodComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfTokenisationPaymentMethodComponent, isStandalone: true, selector: "cx-opf-tokenisation-payment-method", providers: [OpfTokenisationPaymentMethodService], ngImport: i0, template: "<section [attr.aria-label]=\"'paymentForm.payment' | cxTranslate\">\n  <ng-container *ngIf=\"showSavedCards$ | async\">\n    <ng-container *ngIf=\"cards$ | async as cards\">\n      <ng-container *ngIf=\"!(isUpdating$ | async); else loading\">\n        <ng-container *ngIf=\"cards?.length; then hasExistingPaymentMethods\" />\n      </ng-container>\n\n      <ng-template #hasExistingPaymentMethods>\n        <div class=\"cx-checkout-body row\">\n          <div\n            class=\"cx-payment-card col-md-12 col-lg-6\"\n            *ngFor=\"\n              let card of showAll\n                ? cards\n                : (cards | slice: 0 : VISIBLE_CARDS_COUNT);\n              let i = index\n            \"\n          >\n            <div\n              class=\"cx-payment-card-inner\"\n              (click)=\"onCardClick($event, card.paymentMethod)\"\n            >\n              <div class=\"cx-expired-error-slot\">\n                <div\n                  *ngIf=\"isCardExpired(card.paymentMethod)\"\n                  class=\"cx-expired-error\"\n                  role=\"alert\"\n                >\n                  <cx-icon\n                    class=\"cx-expired-error-icon\"\n                    [type]=\"iconTypes.ERROR\"\n                    aria-hidden=\"true\"\n                  />\n                  <span class=\"cx-expired-error-message\">\n                    {{ 'paymentCard.expiredMessage' | cxTranslate }}\n                  </span>\n                </div>\n              </div>\n              <cx-card\n                [border]=\"true\"\n                [fitToContainer]=\"true\"\n                [content]=\"card.content\"\n                [index]=\"i\"\n                (setDefaultCard)=\"setDefaultPaymentMethod(card.paymentMethod)\"\n                (sendCard)=\"\n                  !isCardExpired(card.paymentMethod) &&\n                    selectPaymentMethod(card.paymentMethod)\n                \"\n              />\n            </div>\n          </div>\n        </div>\n\n        <div class=\"row cx-checkout-btns\">\n          <div class=\"col-md-12 col-lg-6\">\n            <button\n              class=\"btn btn-block btn-primary\"\n              [disabled]=\"\n                !(selectedMethod$ | async)?.id || (isUpdating$ | async)\n              \"\n              (click)=\"next()\"\n            >\n              {{ 'checkoutReview.placeOrder' | cxTranslate }}\n            </button>\n          </div>\n        </div>\n\n        <ng-container *ngIf=\"cards.length > VISIBLE_CARDS_COUNT\">\n          <hr class=\"cx-show-more-divider\" />\n          <div class=\"cx-show-more-cards\">\n            <ng-container *ngIf=\"!showAll\">\n              <button class=\"btn btn-link\" (click)=\"showAll = true\">\n                {{ 'paymentCard.showAll' | cxTranslate }}\n              </button>\n              <span class=\"cx-card-count\"\n                >[ {{ VISIBLE_CARDS_COUNT }} / {{ cards.length }} ]</span\n              >\n            </ng-container>\n            <ng-container *ngIf=\"showAll\">\n              <span class=\"btn btn-link cx-show-all-expanded\">\n                {{ 'paymentCard.showAll' | cxTranslate }}\n              </span>\n              <span class=\"cx-card-count cx-card-count--expanded\"\n                >[ {{ cards.length }} / {{ cards.length }} ]</span\n              >\n            </ng-container>\n          </div>\n        </ng-container>\n      </ng-template>\n    </ng-container>\n  </ng-container>\n</section>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\">\n    <cx-spinner />\n  </div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: CardComponent, selector: "cx-card", inputs: ["border", "editMode", "isDefault", "content", "fitToContainer", "truncateText", "truncateParagraphText", "charactersLimit", "index", "role"], outputs: ["deleteCard", "setDefaultCard", "sendCard", "editCard", "cancelCard"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: SlicePipe, name: "slice" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationPaymentMethodComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-tokenisation-payment-method', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        NgFor,
                        SlicePipe,
                        CardComponent,
                        IconComponent,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], providers: [OpfTokenisationPaymentMethodService], template: "<section [attr.aria-label]=\"'paymentForm.payment' | cxTranslate\">\n  <ng-container *ngIf=\"showSavedCards$ | async\">\n    <ng-container *ngIf=\"cards$ | async as cards\">\n      <ng-container *ngIf=\"!(isUpdating$ | async); else loading\">\n        <ng-container *ngIf=\"cards?.length; then hasExistingPaymentMethods\" />\n      </ng-container>\n\n      <ng-template #hasExistingPaymentMethods>\n        <div class=\"cx-checkout-body row\">\n          <div\n            class=\"cx-payment-card col-md-12 col-lg-6\"\n            *ngFor=\"\n              let card of showAll\n                ? cards\n                : (cards | slice: 0 : VISIBLE_CARDS_COUNT);\n              let i = index\n            \"\n          >\n            <div\n              class=\"cx-payment-card-inner\"\n              (click)=\"onCardClick($event, card.paymentMethod)\"\n            >\n              <div class=\"cx-expired-error-slot\">\n                <div\n                  *ngIf=\"isCardExpired(card.paymentMethod)\"\n                  class=\"cx-expired-error\"\n                  role=\"alert\"\n                >\n                  <cx-icon\n                    class=\"cx-expired-error-icon\"\n                    [type]=\"iconTypes.ERROR\"\n                    aria-hidden=\"true\"\n                  />\n                  <span class=\"cx-expired-error-message\">\n                    {{ 'paymentCard.expiredMessage' | cxTranslate }}\n                  </span>\n                </div>\n              </div>\n              <cx-card\n                [border]=\"true\"\n                [fitToContainer]=\"true\"\n                [content]=\"card.content\"\n                [index]=\"i\"\n                (setDefaultCard)=\"setDefaultPaymentMethod(card.paymentMethod)\"\n                (sendCard)=\"\n                  !isCardExpired(card.paymentMethod) &&\n                    selectPaymentMethod(card.paymentMethod)\n                \"\n              />\n            </div>\n          </div>\n        </div>\n\n        <div class=\"row cx-checkout-btns\">\n          <div class=\"col-md-12 col-lg-6\">\n            <button\n              class=\"btn btn-block btn-primary\"\n              [disabled]=\"\n                !(selectedMethod$ | async)?.id || (isUpdating$ | async)\n              \"\n              (click)=\"next()\"\n            >\n              {{ 'checkoutReview.placeOrder' | cxTranslate }}\n            </button>\n          </div>\n        </div>\n\n        <ng-container *ngIf=\"cards.length > VISIBLE_CARDS_COUNT\">\n          <hr class=\"cx-show-more-divider\" />\n          <div class=\"cx-show-more-cards\">\n            <ng-container *ngIf=\"!showAll\">\n              <button class=\"btn btn-link\" (click)=\"showAll = true\">\n                {{ 'paymentCard.showAll' | cxTranslate }}\n              </button>\n              <span class=\"cx-card-count\"\n                >[ {{ VISIBLE_CARDS_COUNT }} / {{ cards.length }} ]</span\n              >\n            </ng-container>\n            <ng-container *ngIf=\"showAll\">\n              <span class=\"btn btn-link cx-show-all-expanded\">\n                {{ 'paymentCard.showAll' | cxTranslate }}\n              </span>\n              <span class=\"cx-card-count cx-card-count--expanded\"\n                >[ {{ cards.length }} / {{ cards.length }} ]</span\n              >\n            </ng-container>\n          </div>\n        </ng-container>\n      </ng-template>\n    </ng-container>\n  </ng-container>\n</section>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\">\n    <cx-spinner />\n  </div>\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfTokenisationPaymentMethodModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationPaymentMethodModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationPaymentMethodModule, imports: [CommonModule,
            RouterModule,
            CheckoutPaymentFormModule,
            CardModule,
            SpinnerModule,
            I18nModule,
            FeaturesConfigModule,
            OpfTokenisationPaymentMethodComponent], exports: [OpfTokenisationPaymentMethodComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationPaymentMethodModule, providers: [
            OpfTokenisationPaymentMethodService,
            provideDefaultConfig({
                cmsComponents: {
                    CheckoutPaymentDetails: {
                        component: OpfTokenisationPaymentMethodComponent,
                        guards: [CheckoutAuthGuard, CartNotEmptyGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            RouterModule,
            CheckoutPaymentFormModule,
            CardModule,
            SpinnerModule,
            I18nModule,
            FeaturesConfigModule,
            OpfTokenisationPaymentMethodComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationPaymentMethodModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        CheckoutPaymentFormModule,
                        CardModule,
                        SpinnerModule,
                        I18nModule,
                        FeaturesConfigModule,
                        OpfTokenisationPaymentMethodComponent,
                    ],
                    providers: [
                        OpfTokenisationPaymentMethodService,
                        provideDefaultConfig({
                            cmsComponents: {
                                CheckoutPaymentDetails: {
                                    component: OpfTokenisationPaymentMethodComponent,
                                    guards: [CheckoutAuthGuard, CartNotEmptyGuard],
                                },
                            },
                        }),
                    ],
                    exports: [OpfTokenisationPaymentMethodComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfTokenisationDeletePaymentDialogComponent {
    constructor() {
        this.showDialog = false;
        this.confirmDelete = new EventEmitter();
        this.cancelDelete = new EventEmitter();
    }
    onConfirm() {
        this.confirmDelete.emit();
    }
    onCancel() {
        this.cancelDelete.emit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationDeletePaymentDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfTokenisationDeletePaymentDialogComponent, isStandalone: true, selector: "cx-opf-tokenisation-delete-payment-dialog", inputs: { showDialog: "showDialog" }, outputs: { confirmDelete: "confirmDelete", cancelDelete: "cancelDelete" }, ngImport: i0, template: "<div\n  *ngIf=\"showDialog\"\n  class=\"modal fade show\"\n  tabindex=\"-1\"\n  role=\"dialog\"\n  aria-modal=\"true\"\n  style=\"display: block\"\n  (click)=\"onCancel()\"\n>\n  <div\n    class=\"modal-dialog modal-dialog-centered\"\n    style=\"max-width: 560px; width: 90vw\"\n    (click)=\"$event.stopPropagation()\"\n  >\n    <div class=\"modal-content rounded-0\">\n      <div class=\"modal-header border-0 px-5 pb-2\">\n        <h3 class=\"modal-title text-start mb-0\">\n          {{ 'paymentCard.deletePaymentMethod' | cxTranslate }}\n        </h3>\n        <button\n          type=\"button\"\n          class=\"close\"\n          [attr.aria-label]=\"'common.close' | cxTranslate\"\n          (click)=\"onCancel()\"\n        >\n          <span aria-hidden=\"true\">&times;</span>\n        </button>\n      </div>\n      <div class=\"modal-body px-5 pt-0\">\n        <p class=\"cx-confirmation text-start mt-0 mb-0\">\n          {{ 'paymentCard.deleteConfirmation' | cxTranslate }}\n        </p>\n      </div>\n      <div class=\"cx-modal-footer d-flex flex-column gap-2\">\n        <button class=\"btn btn-primary btn-block\" (click)=\"onConfirm()\">\n          {{ 'common.delete' | cxTranslate }}\n        </button>\n        <button class=\"btn btn-secondary btn-block\" (click)=\"onCancel()\">\n          {{ 'common.cancel' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n  </div>\n</div>\n<div *ngIf=\"showDialog\" class=\"modal-backdrop fade show\"></div>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationDeletePaymentDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-tokenisation-delete-payment-dialog', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, TranslatePipe], template: "<div\n  *ngIf=\"showDialog\"\n  class=\"modal fade show\"\n  tabindex=\"-1\"\n  role=\"dialog\"\n  aria-modal=\"true\"\n  style=\"display: block\"\n  (click)=\"onCancel()\"\n>\n  <div\n    class=\"modal-dialog modal-dialog-centered\"\n    style=\"max-width: 560px; width: 90vw\"\n    (click)=\"$event.stopPropagation()\"\n  >\n    <div class=\"modal-content rounded-0\">\n      <div class=\"modal-header border-0 px-5 pb-2\">\n        <h3 class=\"modal-title text-start mb-0\">\n          {{ 'paymentCard.deletePaymentMethod' | cxTranslate }}\n        </h3>\n        <button\n          type=\"button\"\n          class=\"close\"\n          [attr.aria-label]=\"'common.close' | cxTranslate\"\n          (click)=\"onCancel()\"\n        >\n          <span aria-hidden=\"true\">&times;</span>\n        </button>\n      </div>\n      <div class=\"modal-body px-5 pt-0\">\n        <p class=\"cx-confirmation text-start mt-0 mb-0\">\n          {{ 'paymentCard.deleteConfirmation' | cxTranslate }}\n        </p>\n      </div>\n      <div class=\"cx-modal-footer d-flex flex-column gap-2\">\n        <button class=\"btn btn-primary btn-block\" (click)=\"onConfirm()\">\n          {{ 'common.delete' | cxTranslate }}\n        </button>\n        <button class=\"btn btn-secondary btn-block\" (click)=\"onCancel()\">\n          {{ 'common.cancel' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n  </div>\n</div>\n<div *ngIf=\"showDialog\" class=\"modal-backdrop fade show\"></div>\n" }]
        }], propDecorators: { showDialog: [{
                type: Input
            }], confirmDelete: [{
                type: Output
            }], cancelDelete: [{
                type: Output
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfTokenisationAccountPaymentMethodsComponent {
    constructor() {
        this.showDeleteDialog = false;
        this.showHeader = true;
        this.autoDefaultRequested = false;
        this.iconTypes = ICON_TYPE;
        this.tokenisationFacade = inject(OpfTokenisationFacade);
        this.translation = inject(TranslationService);
        this.globalMessageService = inject(GlobalMessageService, {
            optional: true,
        });
    }
    ngOnInit() {
        this.paymentMethods$ = this.tokenisationFacade.getPaymentMethods().pipe(map((paymentDetails) => sortPaymentMethodsForDisplay(paymentDetails)), tap((paymentDetails) => {
            const hasDefault = paymentDetails.some((paymentDetail) => paymentDetail.defaultPayment);
            const hasPaymentMethods = paymentDetails.length > 0;
            const firstNonExpired = paymentDetails.find((paymentDetail) => !isTokenisationCardExpired(paymentDetail));
            // Set first non-expired payment method to DEFAULT if none is set
            if (!this.autoDefaultRequested &&
                hasPaymentMethods &&
                !hasDefault &&
                firstNonExpired) {
                this.autoDefaultRequested = true;
                this.setDefaultPaymentMethod(firstNonExpired);
            }
        }));
        this.editCard = undefined;
        this.loading$ = this.tokenisationFacade.getPaymentMethodsLoading();
        this.tokenisationFacade.loadPaymentMethods();
    }
    getCardContent(paymentMethod) {
        const { defaultPayment, expiryMonth, expiryYear, cardNumber, cardType } = paymentMethod;
        return combineLatest([
            this.translation.translate('paymentCard.setAsDefault'),
            this.translation.translate('common.delete'),
            this.translation.translate('paymentCard.expires', {
                month: expiryMonth,
                year: expiryYear,
            }),
            this.translation.translate('paymentCard.defaultPaymentMethodTokenisation'),
        ]).pipe(map(([textSetAsDefault, textDelete, textExpires, textDefaultPaymentMethod,]) => {
            const actions = [];
            if (!defaultPayment && !isTokenisationCardExpired(paymentMethod)) {
                actions.push({ name: textSetAsDefault, event: 'default' });
            }
            actions.push({ name: textDelete, event: 'delete' });
            const card = {
                role: 'application',
                header: defaultPayment ? textDefaultPaymentMethod : undefined,
                textBold: cardType?.name,
                text: [cardNumber ?? '', textExpires],
                actions,
                label: defaultPayment
                    ? 'paymentCard.defaultPaymentLabel'
                    : 'paymentCard.additionalPaymentLabel',
            };
            return card;
        }));
    }
    isCardExpired(paymentMethod) {
        return isTokenisationCardExpired(paymentMethod);
    }
    deletePaymentMethod(paymentMethod) {
        if (paymentMethod.id) {
            this.paymentMethodToDelete = paymentMethod;
            this.showDeleteDialog = true;
            this.editCard = undefined;
        }
    }
    confirmDeletePaymentMethod() {
        if (this.paymentMethodToDelete?.id) {
            this.tokenisationFacade.deletePaymentMethod(this.paymentMethodToDelete.id);
        }
        this.closeDeleteDialog();
    }
    closeDeleteDialog() {
        this.showDeleteDialog = false;
        this.paymentMethodToDelete = undefined;
    }
    setEdit(paymentMethod) {
        this.editCard = paymentMethod.id;
    }
    cancelCard() {
        this.editCard = undefined;
    }
    setDefaultPaymentMethod(paymentMethod) {
        this.tokenisationFacade.setPaymentMethodAsDefault(paymentMethod.id ?? '');
        this.globalMessageService?.add({ key: 'paymentMessages.setAsDefaultSuccessfully' }, GlobalMessageType.MSG_TYPE_CONFIRMATION);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationAccountPaymentMethodsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfTokenisationAccountPaymentMethodsComponent, isStandalone: true, selector: "cx-opf-tokenisation-account-payment-methods", inputs: { showHeader: "showHeader" }, ngImport: i0, template: "<ng-container *ngIf=\"paymentMethods$ | async as paymentMethods\">\n  <div class=\"cx-payment container\">\n    <div *ngIf=\"showHeader\" class=\"cx-header\">\n      <h2>\n        {{ 'paymentMethods.paymentMethods' | cxTranslate }}\n      </h2>\n    </div>\n\n    <div class=\"cx-body\">\n      <div *ngIf=\"showHeader\" class=\"cx-msg\">\n        {{\n          'paymentMethods.newPaymentMethodsAreAddedDuringCheckout' | cxTranslate\n        }}\n      </div>\n      <div *ngIf=\"loading$ | async; else cards\"><cx-spinner /></div>\n      <ng-template #cards>\n        <div class=\"cx-existing row\">\n          <div\n            class=\"cx-payment-card col-sm-12 col-md-12 col-lg-6\"\n            *ngFor=\"let paymentMethod of paymentMethods; let i = index\"\n          >\n            <div class=\"cx-payment-inner\">\n              <div\n                *ngIf=\"isCardExpired(paymentMethod)\"\n                class=\"cx-expired-error\"\n                role=\"alert\"\n              >\n                <cx-icon\n                  class=\"cx-expired-error-icon\"\n                  [type]=\"iconTypes.ERROR\"\n                  aria-hidden=\"true\"\n                />\n                <span class=\"cx-expired-error-message\">\n                  {{ 'paymentCard.expiredMessage' | cxTranslate }}\n                </span>\n              </div>\n              <div class=\"cx-card-with-expired-pill\">\n                <div\n                  *ngIf=\"\n                    paymentMethod.defaultPayment && isCardExpired(paymentMethod)\n                  \"\n                  class=\"cx-expired-pill-container\"\n                >\n                  <span class=\"cx-expired-pill\">\n                    {{ 'paymentCard.expired' | cxTranslate }}\n                  </span>\n                </div>\n                <cx-card\n                  [index]=\"i\"\n                  [border]=\"true\"\n                  [fitToContainer]=\"true\"\n                  [content]=\"getCardContent(paymentMethod) | async\"\n                  (deleteCard)=\"deletePaymentMethod(paymentMethod)\"\n                  (setDefaultCard)=\"setDefaultPaymentMethod(paymentMethod)\"\n                  (editCard)=\"setEdit(paymentMethod)\"\n                  [editMode]=\"editCard === paymentMethod.id\"\n                  (cancelCard)=\"cancelCard()\"\n                />\n              </div>\n            </div>\n          </div>\n        </div>\n      </ng-template>\n    </div>\n  </div>\n</ng-container>\n\n<cx-opf-tokenisation-delete-payment-dialog\n  [showDialog]=\"showDeleteDialog\"\n  (confirmDelete)=\"confirmDeletePaymentMethod()\"\n  (cancelDelete)=\"closeDeleteDialog()\"\n/>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: CardComponent, selector: "cx-card", inputs: ["border", "editMode", "isDefault", "content", "fitToContainer", "truncateText", "truncateParagraphText", "charactersLimit", "index", "role"], outputs: ["deleteCard", "setDefaultCard", "sendCard", "editCard", "cancelCard"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "component", type: OpfTokenisationDeletePaymentDialogComponent, selector: "cx-opf-tokenisation-delete-payment-dialog", inputs: ["showDialog"], outputs: ["confirmDelete", "cancelDelete"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationAccountPaymentMethodsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-tokenisation-account-payment-methods', imports: [
                        NgIf,
                        SpinnerComponent,
                        NgFor,
                        CardComponent,
                        IconComponent,
                        AsyncPipe,
                        TranslatePipe,
                        OpfTokenisationDeletePaymentDialogComponent,
                    ], template: "<ng-container *ngIf=\"paymentMethods$ | async as paymentMethods\">\n  <div class=\"cx-payment container\">\n    <div *ngIf=\"showHeader\" class=\"cx-header\">\n      <h2>\n        {{ 'paymentMethods.paymentMethods' | cxTranslate }}\n      </h2>\n    </div>\n\n    <div class=\"cx-body\">\n      <div *ngIf=\"showHeader\" class=\"cx-msg\">\n        {{\n          'paymentMethods.newPaymentMethodsAreAddedDuringCheckout' | cxTranslate\n        }}\n      </div>\n      <div *ngIf=\"loading$ | async; else cards\"><cx-spinner /></div>\n      <ng-template #cards>\n        <div class=\"cx-existing row\">\n          <div\n            class=\"cx-payment-card col-sm-12 col-md-12 col-lg-6\"\n            *ngFor=\"let paymentMethod of paymentMethods; let i = index\"\n          >\n            <div class=\"cx-payment-inner\">\n              <div\n                *ngIf=\"isCardExpired(paymentMethod)\"\n                class=\"cx-expired-error\"\n                role=\"alert\"\n              >\n                <cx-icon\n                  class=\"cx-expired-error-icon\"\n                  [type]=\"iconTypes.ERROR\"\n                  aria-hidden=\"true\"\n                />\n                <span class=\"cx-expired-error-message\">\n                  {{ 'paymentCard.expiredMessage' | cxTranslate }}\n                </span>\n              </div>\n              <div class=\"cx-card-with-expired-pill\">\n                <div\n                  *ngIf=\"\n                    paymentMethod.defaultPayment && isCardExpired(paymentMethod)\n                  \"\n                  class=\"cx-expired-pill-container\"\n                >\n                  <span class=\"cx-expired-pill\">\n                    {{ 'paymentCard.expired' | cxTranslate }}\n                  </span>\n                </div>\n                <cx-card\n                  [index]=\"i\"\n                  [border]=\"true\"\n                  [fitToContainer]=\"true\"\n                  [content]=\"getCardContent(paymentMethod) | async\"\n                  (deleteCard)=\"deletePaymentMethod(paymentMethod)\"\n                  (setDefaultCard)=\"setDefaultPaymentMethod(paymentMethod)\"\n                  (editCard)=\"setEdit(paymentMethod)\"\n                  [editMode]=\"editCard === paymentMethod.id\"\n                  (cancelCard)=\"cancelCard()\"\n                />\n              </div>\n            </div>\n          </div>\n        </div>\n      </ng-template>\n    </div>\n  </div>\n</ng-container>\n\n<cx-opf-tokenisation-delete-payment-dialog\n  [showDialog]=\"showDeleteDialog\"\n  (confirmDelete)=\"confirmDeletePaymentMethod()\"\n  (cancelDelete)=\"closeDeleteDialog()\"\n/>\n" }]
        }], propDecorators: { showHeader: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfTokenisationAccountPaymentMethodsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationAccountPaymentMethodsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationAccountPaymentMethodsModule, imports: [CommonModule,
            CardModule,
            SpinnerModule,
            I18nModule,
            FeaturesConfigModule,
            FormRequiredLegendComponent,
            OpfTokenisationAccountPaymentMethodsComponent], exports: [OpfTokenisationAccountPaymentMethodsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationAccountPaymentMethodsModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    AccountPaymentDetailsComponent: {
                        component: OpfTokenisationAccountPaymentMethodsComponent,
                        guards: [AuthGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            CardModule,
            SpinnerModule,
            I18nModule,
            FeaturesConfigModule,
            FormRequiredLegendComponent,
            OpfTokenisationAccountPaymentMethodsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationAccountPaymentMethodsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        CardModule,
                        SpinnerModule,
                        I18nModule,
                        FeaturesConfigModule,
                        FormRequiredLegendComponent,
                        OpfTokenisationAccountPaymentMethodsComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                AccountPaymentDetailsComponent: {
                                    component: OpfTokenisationAccountPaymentMethodsComponent,
                                    guards: [AuthGuard],
                                },
                            },
                        }),
                    ],
                    exports: [OpfTokenisationAccountPaymentMethodsComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const CONTENT_TYPE_JSON_HEADER = { 'Content-Type': 'application/json' };
class OccOpfTokenisationUserPaymentAdapter extends OccUserPaymentAdapter {
    constructor(http, occEndpoints, converter) {
        super(http, occEndpoints, converter);
        this.http = http;
        this.occEndpoints = occEndpoints;
        this.converter = converter;
        this.logger = inject(LoggerService);
        this.translationService = inject(TranslationService);
        this.rawPaymentDetailsById = new Map();
    }
    loadAll(userId) {
        const url = this.occEndpoints.buildUrl('paymentDetailsAll', {
            urlParams: { userId },
            queryParams: { saved: true },
        });
        const headers = new HttpHeaders({
            ...CONTENT_TYPE_JSON_HEADER,
        });
        return this.http.get(url, { headers }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), map((methodList) => methodList.payments ?? []), map((payments) => {
            this.rawPaymentDetailsById.clear();
            payments.forEach((payment) => {
                if (payment.id) {
                    this.rawPaymentDetailsById.set(payment.id, payment);
                }
            });
            return payments;
        }), this.converter.pipeableMany(PAYMENT_DETAILS_NORMALIZER));
    }
    // TO DO: Unify this adapter with Core once Core fixes the paymentDetail PATCH request payload handling.
    setDefault(userId, paymentMethodID) {
        const patchUrl = this.occEndpoints.buildUrl('paymentDetail', {
            urlParams: { userId, paymentDetailId: paymentMethodID },
        });
        const headers = new HttpHeaders({ ...CONTENT_TYPE_JSON_HEADER });
        const paymentDetail = this.rawPaymentDetailsById.get(paymentMethodID);
        const payload = {
            ...paymentDetail,
            id: paymentMethodID,
            accountHolderName: this.getAccountHolderName(paymentDetail),
            billingAddress: this.buildBillingAddress(paymentDetail),
            defaultPayment: true,
        };
        return this.http.patch(patchUrl, payload, { headers }).pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    getAccountHolderName(paymentDetail) {
        const value = paymentDetail?.accountHolderName?.trim();
        if (value) {
            return value;
        }
        const firstName = paymentDetail?.billingAddress?.firstName?.trim() ?? '';
        const lastName = paymentDetail?.billingAddress?.lastName?.trim() ?? '';
        const fullName = `${firstName} ${lastName}`.trim();
        const translatedAccountHolderName = getLastValueSync(this.translationService.translate('paymentForm.accountHolderName.label'));
        const defaultAccountHolderName = translatedAccountHolderName &&
            translatedAccountHolderName !== 'paymentForm.accountHolderName.label'
            ? translatedAccountHolderName
            : 'Account Holder';
        return fullName || defaultAccountHolderName;
    }
    buildBillingAddress(paymentDetail) {
        const source = paymentDetail?.billingAddress;
        return {
            ...source,
            firstName: source?.firstName?.trim() || 'N/A',
            lastName: source?.lastName?.trim() || 'N/A',
            line1: source?.line1?.trim() || 'N/A',
            town: source?.town?.trim() || 'N/A',
            postalCode: source?.postalCode?.trim() || '00000',
            country: {
                ...source?.country,
                isocode: source?.country?.isocode?.trim() || 'US',
            },
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccOpfTokenisationUserPaymentAdapter, deps: [{ token: i1.HttpClient }, { token: i2.OccEndpointsService }, { token: i2.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccOpfTokenisationUserPaymentAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccOpfTokenisationUserPaymentAdapter, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: i2.OccEndpointsService }, { type: i2.ConverterService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
function defaultOpfTokenisationCmsComponentsConfig() {
    const config = {
        featureModules: {
            [OPF_TOKENISATION_FEATURE]: {
                cmsComponents: ['AccountPaymentDetailsComponent'],
            },
        },
    };
    return config;
}
class OpfTokenisationRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationRootModule, imports: [OpfTokenisationAccountPaymentMethodsModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationRootModule, providers: [
            provideDefaultConfigFactory(defaultOpfTokenisationCmsComponentsConfig),
            {
                provide: UserPaymentAdapter,
                useClass: OccOpfTokenisationUserPaymentAdapter,
            },
            provideOutlet({
                id: OpfCheckoutOutlets.OPF_CHECKOUT_BEFORE_PAYMENT_OPTIONS,
                component: OpfTokenisationSavedCardsToggleComponent,
                position: OutletPosition.BEFORE,
            }),
            provideOutlet({
                id: OpfCheckoutOutlets.OPF_CHECKOUT_BEFORE_PAYMENT_OPTIONS,
                component: OpfTokenisationPaymentMethodComponent,
                position: OutletPosition.AFTER,
            }),
            provideOutlet({
                id: OpfCheckoutOutlets.OPF_CHECKOUT_BEFORE_PAYMENT_OPTIONS,
                component: OpfTokenisationNewPaymentsHeadingComponent,
                position: OutletPosition.AFTER,
            }),
        ], imports: [OpfTokenisationAccountPaymentMethodsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfTokenisationRootModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OpfTokenisationAccountPaymentMethodsModule],
                    providers: [
                        provideDefaultConfigFactory(defaultOpfTokenisationCmsComponentsConfig),
                        {
                            provide: UserPaymentAdapter,
                            useClass: OccOpfTokenisationUserPaymentAdapter,
                        },
                        provideOutlet({
                            id: OpfCheckoutOutlets.OPF_CHECKOUT_BEFORE_PAYMENT_OPTIONS,
                            component: OpfTokenisationSavedCardsToggleComponent,
                            position: OutletPosition.BEFORE,
                        }),
                        provideOutlet({
                            id: OpfCheckoutOutlets.OPF_CHECKOUT_BEFORE_PAYMENT_OPTIONS,
                            component: OpfTokenisationPaymentMethodComponent,
                            position: OutletPosition.AFTER,
                        }),
                        provideOutlet({
                            id: OpfCheckoutOutlets.OPF_CHECKOUT_BEFORE_PAYMENT_OPTIONS,
                            component: OpfTokenisationNewPaymentsHeadingComponent,
                            position: OutletPosition.AFTER,
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OPF_TOKENISATION_FEATURE, OpfTokenisationFacade, OpfTokenisationNewPaymentsHeadingComponent, OpfTokenisationRootModule, OpfTokenisationSavedCardsService, OpfTokenisationSavedCardsToggleComponent, SAVED_CARDS_ID, defaultOpfTokenisationCmsComponentsConfig };
//# sourceMappingURL=spartacus-opf-tokenisation-root.mjs.map
