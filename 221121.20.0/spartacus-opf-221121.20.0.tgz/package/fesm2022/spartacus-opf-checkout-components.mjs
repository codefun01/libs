import * as i0 from '@angular/core';
import { Pipe, inject, Injectable, ViewContainerRef, ChangeDetectorRef, DestroyRef, ViewChild, Input, ChangeDetectionStrategy, Component, NgModule, EventEmitter, Output } from '@angular/core';
import { NgIf, NgTemplateOutlet, NgFor, NgClass, AsyncPipe, CommonModule } from '@angular/common';
import * as i1 from '@angular/forms';
import { ReactiveFormsModule, UntypedFormGroup, UntypedFormControl, Validators, FormsModule, UntypedFormBuilder } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { UserIdService, RoutingService, GlobalMessageService, WindowRef, FeatureToggles, backOff, DEFAULT_AUTHORIZATION_ERROR_RETRIES_COUNT, isAuthorizationError, HttpResponseStatus, GlobalMessageType, LanguageService, CurrencyService, TranslatePipe, I18nModule, UserPaymentService, UserAddressService, SemanticPathService, provideDefaultConfig, TranslationService, UrlPipe, UrlModule, CmsService } from '@spartacus/core';
import * as i1$1 from '@spartacus/storefront';
import { SpinnerComponent, SpinnerModule, ICON_TYPE, CardComponent, IconComponent, NgSelectA11yModule, CardModule, IconModule, FormErrorsModule, CustomFormValidators, FormErrorsComponent, PaginationComponent, OutletModule, PaginationModule, PromotionsComponent, OutletDirective, PromotionsModule } from '@spartacus/storefront';
import { AddressFormComponent, AddressFormModule } from '@spartacus/user/profile/components';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ActivatedRoute, RouterLink, RouterModule } from '@angular/router';
import { ActiveCartFacade, CartAccessCodeFacade, CartGuestUserFacade, MultiCartFacade, PromotionLocation, CartOutlets } from '@spartacus/cart/base/root';
import { CheckoutStepService, CheckoutReviewSubmitComponent, CheckoutAuthGuard, CartNotEmptyGuard } from '@spartacus/checkout/base/components';
import { BehaviorSubject, combineLatest, of, throwError, Subscription, merge, Subject, EMPTY, switchMap as switchMap$1, tap as tap$1, take as take$1, filter as filter$1, map as map$1 } from 'rxjs';
import { take, filter, tap, switchMap, map, catchError, skip, distinctUntilChanged, shareReplay, withLatestFrom, finalize } from 'rxjs/operators';
import { CheckoutDeliveryAddressFacade, CheckoutBillingAddressFacade, CheckoutPaymentFacade, CheckoutDeliveryModesFacade } from '@spartacus/checkout/base/root';
import { DomSanitizer } from '@angular/platform-browser';
import { OpfResourceLoaderService, OpfMetadataStoreService, OpfHtmlContentMode, OpfConfig, OpfBaseFacade, OpfPaymentProviderType } from '@spartacus/opf/base/root';
import { OpfGlobalFunctionsFacade, OpfGlobalFunctionsDomain } from '@spartacus/opf/global-functions/root';
import { OpfPaymentFacade, OpfPaymentRenderPattern, OpfPaymentChannel, OpfPaymentEventsService } from '@spartacus/opf/payment/root';
import { OPF_PAYMENT_AND_REVIEW_SEMANTIC_ROUTE, OpfCheckoutOutlets, OPF_EXPLICIT_TERMS_AND_CONDITIONS_COMPONENT } from '@spartacus/opf/checkout/root';
import { getBrowserInfo } from '@spartacus/opf/payment/core';
import { OrderFacade } from '@spartacus/order/root';
import { SAVED_CARDS_ID } from '@spartacus/opf/tokenisation/root';
import { CheckoutPaymentTypeFacade } from '@spartacus/checkout/b2b/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class GetAddressCardContent {
    transform(address) {
        if (!address) {
            return {};
        }
        return {
            textBold: `${address.firstName} ${address.lastName}`,
            text: [
                address.line1,
                address.line2,
                this.getTownLine(address),
                address.postalCode,
                address.phone,
            ],
        };
    }
    getTownLine(address) {
        const region = address.region?.isocode || '';
        const town = address.town || '';
        const countryIsocode = address.country?.isocode || '';
        const townLineParts = [];
        if (town) {
            townLineParts.push(town);
        }
        if (region) {
            if (town) {
                townLineParts.push(', ');
            }
            townLineParts.push(region);
        }
        if (countryIsocode) {
            if (town || region) {
                townLineParts.push(', ');
            }
            townLineParts.push(countryIsocode);
        }
        return townLineParts.join('');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: GetAddressCardContent, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: GetAddressCardContent, isStandalone: true, name: "cxGetAddressCardContent" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: GetAddressCardContent, decorators: [{
            type: Pipe,
            args: [{ name: 'cxGetAddressCardContent' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutPaymentWrapperService {
    constructor() {
        this.opfPaymentFacade = inject(OpfPaymentFacade);
        this.opfResourceLoaderService = inject(OpfResourceLoaderService);
        this.userIdService = inject(UserIdService);
        this.activeCartService = inject(ActiveCartFacade);
        this.routingService = inject(RoutingService);
        this.globalMessageService = inject(GlobalMessageService);
        this.orderFacade = inject(OrderFacade);
        this.opfMetadataStoreService = inject(OpfMetadataStoreService);
        this.cartAccessCodeFacade = inject(CartAccessCodeFacade);
        this.winRef = inject(WindowRef);
        this.featureToggles = inject(FeatureToggles);
        this.renderPaymentMethodEvent$ = new BehaviorSubject({
            isLoading: false,
            isError: false,
        });
    }
    executeScriptFromHtml(html) {
        /**
         * Verify first if customer is still on the payment and review page.
         * Then execute script extracted from HTML to render payment provider gateway.
         */
        this.routingService
            .getRouterState()
            .pipe(take(1), filter((route) => route.state.semanticRoute === OPF_PAYMENT_AND_REVIEW_SEMANTIC_ROUTE))
            .subscribe(() => {
            setTimeout(() => {
                this.opfResourceLoaderService.executeScriptFromHtml(html);
            });
        });
    }
    getRenderPaymentMethodEvent() {
        return this.renderPaymentMethodEvent$.asObservable();
    }
    removePaymentProviderResources() {
        this.opfResourceLoaderService.clearAllResources();
    }
    initiatePayment(paymentOptionId) {
        const useUpdatePaymentTransaction = this.featureToggles.opfCheckoutUseUpdatePaymentTransaction;
        this.lastPaymentOptionId = paymentOptionId;
        this.renderPaymentMethodEvent$.next({
            isLoading: true,
            isError: false,
        });
        this.opfResourceLoaderService.clearAllResources();
        return combineLatest([
            this.userIdService.getUserId(),
            this.activeCartService.getActiveCartId(),
        ]).pipe(tap(() => this.opfMetadataStoreService.updateOpfMetadata({
            isPaymentInProgress: true,
        })), switchMap(([userId, cartId]) => this.cartAccessCodeFacade.getCartAccessCode(userId, cartId).pipe(filter((response) => Boolean(response?.accessCode)), map(({ accessCode: otpKey }) => this.getPaymentInitiationConfig(otpKey, paymentOptionId, getBrowserInfo(this.winRef?.nativeWindow))))), switchMap((params) => {
            if (useUpdatePaymentTransaction) {
                const paymentSessionId = this.getStoredPaymentSessionId(params.config?.configurationId);
                if (paymentSessionId) {
                    return this.opfPaymentFacade.updatePaymentTransaction({
                        paymentSessionId,
                        otpKey: params.otpKey,
                        config: {
                            configurationId: params.config?.configurationId,
                            browserInfo: params.config?.browserInfo,
                            channel: params.config?.channel,
                            resultURL: params.config?.resultURL,
                            cancelURL: params.config?.cancelURL,
                        },
                    });
                }
            }
            return this.opfPaymentFacade.initiatePayment(params);
        }), tap((paymentOptionConfig) => {
            if (!(paymentOptionConfig instanceof Error)) {
                this.storePaymentSessionId(paymentOptionConfig, useUpdatePaymentTransaction, String(paymentOptionId));
                this.renderPaymentGateway(paymentOptionConfig);
            }
        }), catchError((err) => this.handlePaymentInitiationError(err)), backOff({
            /**
             * We should retry this sequence only if the error is an authorization error.
             * It means that `accessCode` (OTP signature) is not valid or expired and we need to refresh it.
             */
            shouldRetry: isAuthorizationError,
            maxTries: DEFAULT_AUTHORIZATION_ERROR_RETRIES_COUNT,
        }), take(1));
    }
    storePaymentSessionId(paymentOptionConfig, useUpdatePaymentTransaction = false, paymentConfigurationId) {
        let paymentSessionId;
        if (useUpdatePaymentTransaction ||
            (paymentOptionConfig.pattern === OpfPaymentRenderPattern.FULL_PAGE &&
                paymentOptionConfig.paymentSessionId)) {
            paymentSessionId = paymentOptionConfig.paymentSessionId;
        }
        this.updatePaymentSessionMetadata(paymentSessionId, paymentConfigurationId);
    }
    getOrCreatePaymentSessionId(paymentConfig) {
        const paymentSessionId = this.getStoredPaymentSessionId(paymentConfig.config?.configurationId);
        if (paymentSessionId) {
            return of(paymentSessionId);
        }
        return this.opfPaymentFacade.initiatePayment(paymentConfig).pipe(map((response) => response?.paymentSessionId), switchMap((generatedPaymentSessionId) => {
            if (!generatedPaymentSessionId) {
                return throwError(() => new Error('Missing payment session ID'));
            }
            this.updatePaymentSessionMetadata(generatedPaymentSessionId, paymentConfig.config?.configurationId);
            return of(generatedPaymentSessionId);
        }));
    }
    getStoredPaymentSessionId(paymentConfigurationId) {
        const metadata = this.opfMetadataStoreService.opfMetadataState.value;
        if (!metadata?.opfPaymentSessionId) {
            return undefined;
        }
        if (!paymentConfigurationId) {
            return undefined;
        }
        return metadata.opfPaymentSessionConfigurationId === paymentConfigurationId
            ? metadata.opfPaymentSessionId
            : undefined;
    }
    updatePaymentSessionMetadata(paymentSessionId, paymentConfigurationId) {
        this.opfMetadataStoreService.updateOpfMetadata({
            opfPaymentSessionId: paymentSessionId,
            opfPaymentSessionConfigurationId: paymentSessionId
                ? paymentConfigurationId
                : undefined,
        });
    }
    reloadPaymentMode() {
        if (this.lastPaymentOptionId) {
            this.initiatePayment(this.lastPaymentOptionId).subscribe();
        }
    }
    /**
     * Render payment option covering the three patterns: IFRAME, FULL_PAGE, HOSTED_FIELDS.
     * Context to explain this method logic:
     * All three patterns can contains `dynamicScript` value.
     * IFRAME and FULL_PAGE patterns can also have `destination` value.
     * if `dynamicScript` and `destination` are present in same config, dynamicScript takes precendence.
     * @param config
     * @returns : none, OpfPaymentRenderMethodEvent gets emitted
     */
    renderPaymentGateway(config) {
        if (config?.dynamicScript) {
            const html = config?.dynamicScript?.html;
            const paymentOptionId = config?.paymentOptionId ?? this.lastPaymentOptionId;
            this.opfResourceLoaderService
                .loadResources(config.dynamicScript.jsUrls, config.dynamicScript.cssUrls, paymentOptionId, config.dynamicScript)
                .then(() => {
                this.renderPaymentMethodEvent$.next({
                    isLoading: false,
                    isError: false,
                    renderType: config?.pattern,
                    html,
                    paymentOptionId,
                });
                if (html &&
                    config?.dynamicScript?.htmlContentMode !==
                        OpfHtmlContentMode.SEPARATE) {
                    this.executeScriptFromHtml(html);
                }
            })
                .catch(() => {
                this.handleGeneralPaymentError().pipe(take(1)).subscribe();
            });
            return;
        }
        if (config?.destination) {
            this.renderPaymentMethodEvent$.next({
                isLoading: false,
                isError: false,
                renderType: config?.pattern,
                destination: config?.destination,
                paymentOptionId: config?.paymentOptionId ?? this.lastPaymentOptionId,
            });
            return;
        }
        this.handleGeneralPaymentError().pipe(take(1)).subscribe();
    }
    handlePaymentInitiationError(err) {
        if (isAuthorizationError(err)) {
            return this.handleGeneralPaymentError();
        }
        return Number(err.status) === HttpResponseStatus.CONFLICT
            ? this.handlePaymentAlreadyDoneError()
            : this.handleGeneralPaymentError();
    }
    handlePaymentAlreadyDoneError() {
        return this.orderFacade.placePaymentAuthorizedOrder(true).pipe(catchError(() => {
            this.onPlaceOrderError();
            // If place order will fail after two attempts, we wan't to stop stream and show error message
            return of();
        }), switchMap(() => {
            this.onPlaceOrderSuccess();
            return throwError(() => 'Payment already done');
        }));
    }
    onPlaceOrderSuccess() {
        this.routingService.go({ cxRoute: 'orderConfirmation' });
    }
    onPlaceOrderError() {
        this.renderPaymentMethodEvent$.next({
            ...this.renderPaymentMethodEvent$.value,
            isError: true,
        });
        this.showErrorMessage('opfCheckout.errors.unknown');
        this.routingService.go({ cxRoute: OPF_PAYMENT_AND_REVIEW_SEMANTIC_ROUTE });
    }
    handleGeneralPaymentError() {
        this.renderPaymentMethodEvent$.next({
            ...this.renderPaymentMethodEvent$.value,
            isError: true,
        });
        this.showErrorMessage('opfPayment.errors.proceedPayment');
        return throwError(() => 'Payment failed');
    }
    showErrorMessage(errorMessage) {
        this.globalMessageService.add({
            key: errorMessage,
        }, GlobalMessageType.MSG_TYPE_ERROR);
    }
    getPaymentInitiationConfig(otpKey, paymentOptionId, browserInfo) {
        return {
            otpKey,
            config: {
                browserInfo,
                channel: OpfPaymentChannel.BROWSER,
                configurationId: String(paymentOptionId),
                resultURL: this.routingService.getFullUrl({
                    cxRoute: 'paymentVerificationResult',
                }),
                cancelURL: this.routingService.getFullUrl({
                    cxRoute: 'paymentVerificationCancel',
                }),
            },
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentWrapperService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentWrapperService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentWrapperService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutPaymentWrapperComponent {
    constructor() {
        this.service = inject(OpfCheckoutPaymentWrapperService);
        this.sanitizer = inject(DomSanitizer);
        this.globalFunctionsService = inject(OpfGlobalFunctionsFacade);
        this.opfPaymentEventsService = inject(OpfPaymentEventsService);
        this.languageService = inject(LanguageService);
        this.currencyService = inject(CurrencyService);
        this.activeCartService = inject(ActiveCartFacade);
        this.vcr = inject(ViewContainerRef);
        this.cdr = inject(ChangeDetectorRef);
        this.opfConfig = inject(OpfConfig);
        this.destroyRef = inject(DestroyRef);
        this.featureToggles = inject(FeatureToggles);
        this.isPaymentDataReady = false;
        this.PAYMENT_IFRAME_NAME = 'cx-payment-iframe';
        this.renderPaymentMethodEvent$ = this.service.getRenderPaymentMethodEvent();
        this.RENDER_PATTERN = OpfPaymentRenderPattern;
        this.sub = new Subscription();
    }
    bypassSecurityTrustHtml(html) {
        return this.sanitizer.bypassSecurityTrustHtml(html);
    }
    bypassSecurityTrustResourceUrl(url) {
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    }
    getIframeSandbox(paymentOptionId) {
        const sandboxMap = this.opfConfig?.opf?.paymentOption?.iframeSandboxMap;
        if (paymentOptionId && sandboxMap && sandboxMap[paymentOptionId]) {
            return sandboxMap[paymentOptionId];
        }
        return undefined;
    }
    ngOnInit() {
        this.initiatePaymentMode();
        this.listenForReinitiatePaymentEvent();
        this.listenForSiteContextChanges();
    }
    ngOnDestroy() {
        this.globalFunctionsService.unregisterGlobalFunctions(OpfGlobalFunctionsDomain.CHECKOUT);
        this.service.removePaymentProviderResources();
        this.sub.unsubscribe();
    }
    retryInitiatePayment() {
        this.service.reloadPaymentMode();
    }
    submitFormToIframe() {
        if (this.isPaymentDataReady && this.formElement?.nativeElement) {
            const form = this.formElement.nativeElement;
            if (this.formElement.nativeElement?.target === this.PAYMENT_IFRAME_NAME) {
                form.submit();
            }
        }
    }
    listenForReinitiatePaymentEvent() {
        if (this.featureToggles.opfUseDestroyRef) {
            this.opfPaymentEventsService.reinitiatePaymentEvent$
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe((paymentOptionId) => {
                this.handleReinitiatePayment(paymentOptionId);
            });
        }
        else {
            this.sub.add(this.opfPaymentEventsService.reinitiatePaymentEvent$.subscribe((paymentOptionId) => {
                this.handleReinitiatePayment(paymentOptionId);
            }));
        }
    }
    listenForSiteContextChanges() {
        const merged$ = merge(this.languageService.getActive().pipe(skip(1), // Skip the initial value
        distinctUntilChanged()), this.currencyService.getActive().pipe(skip(1), // Skip the initial value
        distinctUntilChanged())).pipe(switchMap(() => 
        // Wait for cart to be stable before proceeding
        this.activeCartService.isStable().pipe(filter((isStable) => isStable), take(1))));
        if (this.featureToggles.opfUseDestroyRef) {
            merged$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => {
                this.opfPaymentEventsService.emitReinitiatePaymentEvent(this.selectedPaymentId);
            });
        }
        else {
            this.sub.add(merged$.subscribe(() => {
                this.opfPaymentEventsService.emitReinitiatePaymentEvent(this.selectedPaymentId);
            }));
        }
    }
    handleReinitiatePayment(paymentOptionId) {
        const idToUse = paymentOptionId ?? this.selectedPaymentId;
        if (idToUse) {
            this.initiatePaymentMode(idToUse);
        }
    }
    initiatePaymentMode(paymentOptionId) {
        const idToUse = paymentOptionId ?? this.selectedPaymentId;
        this.isPaymentDataReady = false;
        const payment$ = this.service.initiatePayment(idToUse);
        const observer = {
            next: (paymentSessionData) => {
                if (this.isHostedFields(paymentSessionData)) {
                    this.globalFunctionsService.registerGlobalFunctions({
                        domain: OpfGlobalFunctionsDomain.CHECKOUT,
                        paymentSessionId: paymentSessionData
                            .paymentSessionId,
                        vcr: this.vcr,
                    });
                }
                else {
                    this.globalFunctionsService.unregisterGlobalFunctions(OpfGlobalFunctionsDomain.CHECKOUT);
                }
                this.isPaymentDataReady = true;
                this.cdr.detectChanges();
                this.submitFormToIframe();
            },
            error: () => {
                this.isPaymentDataReady = false;
            },
        };
        if (this.featureToggles.opfUseDestroyRef) {
            payment$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(observer);
        }
        else {
            this.sub.add(payment$.subscribe(observer));
        }
    }
    isHostedFields(paymentSessionData) {
        return !!(!(paymentSessionData instanceof Error) &&
            paymentSessionData?.paymentSessionId &&
            paymentSessionData?.pattern === OpfPaymentRenderPattern.HOSTED_FIELDS);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentWrapperComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfCheckoutPaymentWrapperComponent, isStandalone: true, selector: "cx-opf-checkout-payment-wrapper", inputs: { selectedPaymentId: "selectedPaymentId" }, viewQueries: [{ propertyName: "formElement", first: true, predicate: ["paymentForm"], descendants: true }], ngImport: i0, template: "<div\n  class=\"cx-payment-option-container\"\n  *ngIf=\"renderPaymentMethodEvent$ | async as paymentLink\"\n>\n  <ng-container\n    *ngTemplateOutlet=\"\n      !paymentLink?.isLoading ? paymentData : noPaymentData;\n      context: { paymentLink: paymentLink }\n    \"\n  />\n</div>\n\n<ng-template #paymentData let-paymentLink=\"paymentLink\">\n  <div>\n    <ng-container *ngIf=\"paymentLink?.destination?.url\">\n      <div\n        *ngIf=\"\n          paymentLink.renderType === RENDER_PATTERN.FULL_PAGE &&\n          !paymentLink.destination?.form?.length\n        \"\n        class=\"cx-payment-link\"\n      >\n        <a\n          class=\"btn btn-primary\"\n          [href]=\"paymentLink.destination.url\"\n          [attr.title]=\"'opfCheckout.proceedPayment' | cxTranslate\"\n          [attr.aria-label]=\"\n            'opfCheckout.proceedPaymentButtonLabel' | cxTranslate\n          \"\n          >{{ 'opfCheckout.proceedPayment' | cxTranslate }}</a\n        >\n      </div>\n      <ng-container\n        *ngIf=\"\n          paymentLink.renderType === RENDER_PATTERN.IFRAME &&\n          !paymentLink?.destination?.form?.length\n        \"\n      >\n        <iframe\n          class=\"cx-payment-iframe\"\n          [src]=\"bypassSecurityTrustResourceUrl(paymentLink.destination?.url)\"\n          [attr.sandbox]=\"\n            getIframeSandbox(paymentLink?.paymentOptionId || selectedPaymentId)\n          \"\n        ></iframe>\n      </ng-container>\n      <div\n        *ngIf=\"paymentLink?.destination?.form?.length\"\n        class=\"cx-payment-link\"\n      >\n        <iframe\n          *ngIf=\"paymentLink.renderType === RENDER_PATTERN.IFRAME\"\n          class=\"cx-payment-iframe\"\n          name=\"cx-payment-iframe\"\n          [attr.sandbox]=\"\n            getIframeSandbox(paymentLink?.paymentOptionId || selectedPaymentId)\n          \"\n        ></iframe>\n        <form\n          [action]=\"paymentLink.destination?.url\"\n          [method]=\"paymentLink.destination?.method\"\n          [enctype]=\"paymentLink.destination?.contentType\"\n          [target]=\"\n            paymentLink.renderType === RENDER_PATTERN.FULL_PAGE\n              ? '_self'\n              : this.PAYMENT_IFRAME_NAME\n          \"\n          #paymentForm\n        >\n          <fieldset>\n            <input\n              *ngFor=\"let field of paymentLink.destination?.form\"\n              type=\"hidden\"\n              [name]=\"field?.name\"\n              [value]=\"field?.value\"\n            />\n          </fieldset>\n          <input\n            *ngIf=\"paymentLink.renderType === RENDER_PATTERN.FULL_PAGE\"\n            class=\"btn btn-primary\"\n            type=\"submit\"\n            [value]=\"'opfCheckout.proceedPayment' | cxTranslate\"\n          />\n        </form>\n      </div>\n    </ng-container>\n    <ng-container *ngIf=\"paymentLink?.html\">\n      <div [innerHTML]=\"bypassSecurityTrustHtml(paymentLink.html)\"></div>\n    </ng-container>\n  </div>\n</ng-template>\n\n<ng-template #noPaymentData let-paymentLink=\"paymentLink\">\n  <ng-container *ngIf=\"paymentLink?.isError; else loading\">\n    <div class=\"cx-payment-option-container\">\n      <div class=\"cx-payment-link\">\n        <button\n          [ngClass]=\"'btn btn-primary'\"\n          type=\"button\"\n          (click)=\"retryInitiatePayment()\"\n          [attr.title]=\"'opfCheckout.retryPayment' | cxTranslate\"\n          [attr.aria-label]=\"'opfCheckout.retryPayment' | cxTranslate\"\n        >\n          {{ 'opfCheckout.retryPayment' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n  </ng-container>\n\n  <ng-template #loading>\n    <cx-spinner />\n  </ng-template>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentWrapperComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-checkout-payment-wrapper', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        NgTemplateOutlet,
                        NgFor,
                        NgClass,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<div\n  class=\"cx-payment-option-container\"\n  *ngIf=\"renderPaymentMethodEvent$ | async as paymentLink\"\n>\n  <ng-container\n    *ngTemplateOutlet=\"\n      !paymentLink?.isLoading ? paymentData : noPaymentData;\n      context: { paymentLink: paymentLink }\n    \"\n  />\n</div>\n\n<ng-template #paymentData let-paymentLink=\"paymentLink\">\n  <div>\n    <ng-container *ngIf=\"paymentLink?.destination?.url\">\n      <div\n        *ngIf=\"\n          paymentLink.renderType === RENDER_PATTERN.FULL_PAGE &&\n          !paymentLink.destination?.form?.length\n        \"\n        class=\"cx-payment-link\"\n      >\n        <a\n          class=\"btn btn-primary\"\n          [href]=\"paymentLink.destination.url\"\n          [attr.title]=\"'opfCheckout.proceedPayment' | cxTranslate\"\n          [attr.aria-label]=\"\n            'opfCheckout.proceedPaymentButtonLabel' | cxTranslate\n          \"\n          >{{ 'opfCheckout.proceedPayment' | cxTranslate }}</a\n        >\n      </div>\n      <ng-container\n        *ngIf=\"\n          paymentLink.renderType === RENDER_PATTERN.IFRAME &&\n          !paymentLink?.destination?.form?.length\n        \"\n      >\n        <iframe\n          class=\"cx-payment-iframe\"\n          [src]=\"bypassSecurityTrustResourceUrl(paymentLink.destination?.url)\"\n          [attr.sandbox]=\"\n            getIframeSandbox(paymentLink?.paymentOptionId || selectedPaymentId)\n          \"\n        ></iframe>\n      </ng-container>\n      <div\n        *ngIf=\"paymentLink?.destination?.form?.length\"\n        class=\"cx-payment-link\"\n      >\n        <iframe\n          *ngIf=\"paymentLink.renderType === RENDER_PATTERN.IFRAME\"\n          class=\"cx-payment-iframe\"\n          name=\"cx-payment-iframe\"\n          [attr.sandbox]=\"\n            getIframeSandbox(paymentLink?.paymentOptionId || selectedPaymentId)\n          \"\n        ></iframe>\n        <form\n          [action]=\"paymentLink.destination?.url\"\n          [method]=\"paymentLink.destination?.method\"\n          [enctype]=\"paymentLink.destination?.contentType\"\n          [target]=\"\n            paymentLink.renderType === RENDER_PATTERN.FULL_PAGE\n              ? '_self'\n              : this.PAYMENT_IFRAME_NAME\n          \"\n          #paymentForm\n        >\n          <fieldset>\n            <input\n              *ngFor=\"let field of paymentLink.destination?.form\"\n              type=\"hidden\"\n              [name]=\"field?.name\"\n              [value]=\"field?.value\"\n            />\n          </fieldset>\n          <input\n            *ngIf=\"paymentLink.renderType === RENDER_PATTERN.FULL_PAGE\"\n            class=\"btn btn-primary\"\n            type=\"submit\"\n            [value]=\"'opfCheckout.proceedPayment' | cxTranslate\"\n          />\n        </form>\n      </div>\n    </ng-container>\n    <ng-container *ngIf=\"paymentLink?.html\">\n      <div [innerHTML]=\"bypassSecurityTrustHtml(paymentLink.html)\"></div>\n    </ng-container>\n  </div>\n</ng-template>\n\n<ng-template #noPaymentData let-paymentLink=\"paymentLink\">\n  <ng-container *ngIf=\"paymentLink?.isError; else loading\">\n    <div class=\"cx-payment-option-container\">\n      <div class=\"cx-payment-link\">\n        <button\n          [ngClass]=\"'btn btn-primary'\"\n          type=\"button\"\n          (click)=\"retryInitiatePayment()\"\n          [attr.title]=\"'opfCheckout.retryPayment' | cxTranslate\"\n          [attr.aria-label]=\"'opfCheckout.retryPayment' | cxTranslate\"\n        >\n          {{ 'opfCheckout.retryPayment' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n  </ng-container>\n\n  <ng-template #loading>\n    <cx-spinner />\n  </ng-template>\n</ng-template>\n" }]
        }], propDecorators: { selectedPaymentId: [{
                type: Input
            }], formElement: [{
                type: ViewChild,
                args: ['paymentForm']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutPaymentWrapperModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentWrapperModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentWrapperModule, imports: [CommonModule,
            I18nModule,
            SpinnerModule,
            OpfCheckoutPaymentWrapperComponent], exports: [OpfCheckoutPaymentWrapperComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentWrapperModule, providers: [OpfCheckoutPaymentWrapperService], imports: [CommonModule,
            I18nModule,
            SpinnerModule,
            OpfCheckoutPaymentWrapperComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentWrapperModule, decorators: [{
            type: NgModule,
            args: [{
                    providers: [OpfCheckoutPaymentWrapperService],
                    exports: [OpfCheckoutPaymentWrapperComponent],
                    imports: [
                        CommonModule,
                        I18nModule,
                        SpinnerModule,
                        OpfCheckoutPaymentWrapperComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutBillingAddressFormService {
    constructor() {
        this.checkoutDeliveryAddressFacade = inject(CheckoutDeliveryAddressFacade);
        this.checkoutBillingAddressFacade = inject(CheckoutBillingAddressFacade);
        this.userPaymentService = inject(UserPaymentService);
        this.checkoutPaymentService = inject(CheckoutPaymentFacade);
        this.activeCartService = inject(ActiveCartFacade);
        this.globalMessageService = inject(GlobalMessageService);
        this.opfCheckoutPaymentWrapperService = inject(OpfCheckoutPaymentWrapperService);
        this.userAddressService = inject(UserAddressService);
        this._noDefaultAddressFoundForPickupMode$ = new Subject();
        this._$billingAddressSub = new BehaviorSubject(undefined);
        this._$isLoadingAddress = new BehaviorSubject(false);
        this._$isSameAsDelivery = new BehaviorSubject(true);
        this.billingAddress$ = this._$billingAddressSub.asObservable();
        this.isLoadingAddress$ = this._$isLoadingAddress.asObservable();
        this.isSameAsDelivery$ = this._$isSameAsDelivery.asObservable();
        this._$paymentOptionsDisabled = new BehaviorSubject(false);
        this.paymentOptionsDisabled$ = this._$paymentOptionsDisabled.asObservable();
        this.opfPaymentEventsService = inject(OpfPaymentEventsService);
    }
    get pickupNoDefaultAddress$() {
        return this._noDefaultAddressFoundForPickupMode$.asObservable();
    }
    setPaymentOptionsDisabled(value) {
        this._$paymentOptionsDisabled.next(value);
    }
    handleNoDefaultAddress() {
        this.setIsSameAsDeliveryValue(false);
        this._noDefaultAddressFoundForPickupMode$.next();
        this.setPaymentOptionsDisabled(true);
    }
    getCountries() {
        return this.userPaymentService.getAllBillingCountries().pipe(tap((countries) => {
            if (Object.keys(countries).length === 0) {
                this.userPaymentService.loadBillingCountries();
            }
        }), 
        // we want to share data with the address form and prevent loading data twice
        shareReplay(1));
    }
    setDefaultBillingAddress() {
        this._$isLoadingAddress.next(true);
        this.activeCartService
            .hasDeliveryItems()
            .pipe(take(1), filter((hasDeliveryItems) => !hasDeliveryItems), switchMap(() => this.userAddressService.getDefaultAddress()), tap((defaultAddress) => {
            if (!defaultAddress) {
                this.handleNoDefaultAddress();
            }
        }), filter((addr) => !!addr), switchMap((defaultAddress) => {
            this.setPaymentOptionsDisabled(false);
            return this.setBillingAddress(defaultAddress);
        }), catchError(() => {
            this.globalMessageService.add({ key: 'opfCheckout.errors.loadDefaultAddress' }, GlobalMessageType.MSG_TYPE_ERROR);
            return of(undefined);
        }))
            .subscribe();
        this._$isLoadingAddress.next(false);
    }
    getAddresses() {
        this._$isLoadingAddress.next(true);
        combineLatest([this.getDeliveryAddress(), this.getPaymentAddress()])
            .pipe(take(1))
            .subscribe(([deliveryAddress, sapBillingAddress]) => {
            if (sapBillingAddress) {
                this.billingAddressId = sapBillingAddress.id;
                this._$billingAddressSub.next(sapBillingAddress);
                this.setIsSameAsDeliveryValue(false);
            }
            else if (deliveryAddress) {
                // Saves delivery as billing on the cart (subject gets updated again when PUT completes).
                this.setBillingAddress(deliveryAddress);
                // Without this the address card goes blank for a bit — we hide loading before PUT is done.
                this._$billingAddressSub.next(deliveryAddress);
                this.setIsSameAsDeliveryValue(true);
            }
            this._$isLoadingAddress.next(false);
        });
    }
    setDeliveryAddressAsPaymentAddress() {
        this.getDeliveryAddress()
            .pipe(switchMap((address) => !!address ? this.setBillingAddress(address) : EMPTY), take(1))
            .subscribe({
            next: () => this.setIsSameAsDeliveryValue(true),
            complete: () => { },
            error: () => this.setIsSameAsDeliveryValue(false),
            // Method is responsible for placing delivery address as a payment address,
            // so if was not successful, we know for sure that checkbox 'Same as delivery' should be unchecked
        });
    }
    setBillingAddress(address) {
        this._$isLoadingAddress.next(true);
        const submittedAddress = this.getAddressWithId(address);
        return this.checkoutBillingAddressFacade
            .setBillingAddress(submittedAddress)
            .pipe(switchMap(() => {
            this.activeCartService.reloadActiveCart();
            return this.activeCartService.isStable();
        }), filter((isStable) => isStable), switchMap(() => this.getPaymentAddress().pipe(map((sapBillingAddress) => sapBillingAddress ?? submittedAddress))), withLatestFrom(this.opfPaymentEventsService.isGiftCardCoveredTotalAmountEvent$), tap(([billingAddress, isGiftCardCovered]) => {
            if (billingAddress) {
                if (billingAddress.id) {
                    this.billingAddressId = billingAddress.id;
                }
                this._$billingAddressSub.next(billingAddress);
                if (!isGiftCardCovered) {
                    this.opfCheckoutPaymentWrapperService.reloadPaymentMode();
                }
            }
        }), map(([billingAddress]) => billingAddress), catchError((error) => {
            this.globalMessageService.add({ key: 'opfCheckout.errors.updateBillingAddress' }, GlobalMessageType.MSG_TYPE_ERROR);
            return throwError(() => error);
        }), finalize(() => {
            this._$isLoadingAddress.next(false);
        }), take(1));
    }
    get isSameAsDeliveryValue() {
        return this._$isSameAsDelivery.value;
    }
    setIsSameAsDeliveryValue(value) {
        this._$isSameAsDelivery.next(value);
    }
    getDeliveryAddress() {
        return this.checkoutDeliveryAddressFacade.getDeliveryAddressState().pipe(filter((state) => !state.loading), map((state) => state.data));
    }
    getPaymentAddress() {
        return this.activeCartService
            .getActive()
            .pipe(map((cart) => cart.sapBillingAddress));
    }
    getAddressWithId(address) {
        return { ...address, id: this.billingAddressId };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutBillingAddressFormService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutBillingAddressFormService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutBillingAddressFormService, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutBillingAddressFormComponent {
    constructor() {
        this.service = inject(OpfCheckoutBillingAddressFormService);
        this.userAddressService = inject(UserAddressService);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.checkoutStepService = inject(CheckoutStepService);
        this.activatedRoute = inject(ActivatedRoute);
        this.destroyRef = inject(DestroyRef);
        this.featureToggles = inject(FeatureToggles);
        this.cart = null;
        this.iconTypes = ICON_TYPE;
        this.subscription = new Subscription();
        this.billingAddress$ = this.service.billingAddress$;
        this.isLoadingAddress$ = this.service.isLoadingAddress$;
        this.isSameAsDelivery$ = this.service.isSameAsDelivery$;
        this.isEditBillingAddress = false;
        this.isAddingBillingAddressInProgress = false;
    }
    ngOnInit() {
        if (this.featureToggles.opfUseDestroyRef) {
            this.activeCartFacade
                .getActive()
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe((cart) => (this.cart = cart));
        }
        else {
            this.subscription.add(this.activeCartFacade
                .getActive()
                .subscribe((cart) => (this.cart = cart)));
        }
        this.countries$ = this.service.getCountries();
        this.userAddressService.loadAddresses();
        this.service.setDefaultBillingAddress();
        this.service.getAddresses();
        if (this.featureToggles.opfUseDestroyRef) {
            this.service.pickupNoDefaultAddress$
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe(() => {
                this.isEditBillingAddress = true;
                this.isAddingBillingAddressInProgress = true;
            });
        }
        else {
            this.subscription.add(this.service.pickupNoDefaultAddress$.subscribe(() => {
                this.isEditBillingAddress = true;
                this.isAddingBillingAddressInProgress = true;
            }));
        }
    }
    cancelAndHideForm() {
        this.isEditBillingAddress = false;
        if (this.isAddingBillingAddressInProgress) {
            this.service.setIsSameAsDeliveryValue(true);
            this.isAddingBillingAddressInProgress = false;
        }
    }
    back() {
        this.checkoutStepService.back(this.activatedRoute);
    }
    onBackToAddress() {
        if (this.featureToggles.opfUseDestroyRef) {
            this.service.paymentOptionsDisabled$
                .pipe(take(1))
                .subscribe((isDisabled) => isDisabled ? this.back() : this.cancelAndHideForm());
        }
        else {
            this.subscription.add(this.service.paymentOptionsDisabled$.subscribe((isDisabled) => isDisabled ? this.back() : this.cancelAndHideForm()));
        }
    }
    editCustomBillingAddress() {
        this.isEditBillingAddress = true;
    }
    toggleSameAsDeliveryAddress(event) {
        const checked = event.target.checked;
        this.service.setIsSameAsDeliveryValue(checked);
        if (checked) {
            this.service.setDeliveryAddressAsPaymentAddress();
            this.isEditBillingAddress = false;
        }
        else {
            this.isAddingBillingAddressInProgress = true;
            this.isEditBillingAddress = true;
        }
    }
    getAddressData(billingAddress) {
        return !!billingAddress?.id && !this.isAddingBillingAddressInProgress
            ? billingAddress
            : {};
    }
    onSubmitAddress(address) {
        this.isEditBillingAddress = false;
        this.isAddingBillingAddressInProgress = false;
        if (!address) {
            return;
        }
        this.service.setIsSameAsDeliveryValue(false);
        this.service.setBillingAddress(address).subscribe({
            next: () => {
                this.service.setPaymentOptionsDisabled(false);
            },
            error: () => {
                this.service.setPaymentOptionsDisabled(true);
            },
        });
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutBillingAddressFormComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfCheckoutBillingAddressFormComponent, isStandalone: true, selector: "cx-opf-checkout-billing-address-form", ngImport: i0, template: "<section [attr.aria-label]=\"'opfCheckout.billingAddress' | cxTranslate\">\n  <h3>{{ 'opfCheckout.billingAddress' | cxTranslate }}</h3>\n  <ng-container *ngIf=\"!(isLoadingAddress$ | async); else loading\">\n    <ng-container\n      *ngIf=\"{\n        billingAddress: billingAddress$ | async,\n        isSameAsDelivery: isSameAsDelivery$ | async,\n      } as addressData\"\n    >\n      <div class=\"form-group\">\n        <div class=\"form-check\" *ngIf=\"cart?.deliveryItemsQuantity\">\n          <label>\n            <input\n              type=\"checkbox\"\n              class=\"form-check-input\"\n              [checked]=\"addressData.isSameAsDelivery\"\n              (change)=\"toggleSameAsDeliveryAddress($event)\"\n              [attr.aria-label]=\"\n                'paymentForm.billingAddressSameAsShipping' | cxTranslate\n              \"\n            />\n            <span class=\"form-check-label\">{{\n              'paymentForm.sameAsDeliveryAddress' | cxTranslate\n            }}</span>\n          </label>\n        </div>\n      </div>\n\n      <ng-container *ngIf=\"!isEditBillingAddress && addressData.billingAddress\">\n        <div class=\"cx-custom-address-info\">\n          <cx-card\n            [content]=\"addressData.billingAddress | cxGetAddressCardContent\"\n          />\n\n          <button\n            *ngIf=\"!addressData.isSameAsDelivery\"\n            [attr.aria-label]=\"'paymentForm.editBillingAddress' | cxTranslate\"\n            [attr.title]=\"'paymentForm.editBillingAddress' | cxTranslate\"\n            (click)=\"editCustomBillingAddress()\"\n          >\n            <cx-icon [type]=\"iconTypes.PENCIL\" />\n          </button>\n        </div>\n      </ng-container>\n\n      <ng-container *ngIf=\"isEditBillingAddress\">\n        <cx-address-form\n          [addressData]=\"getAddressData(addressData.billingAddress)\"\n          class=\"cx-form\"\n          [showTitleCode]=\"true\"\n          [showCancelBtn]=\"true\"\n          actionBtnLabel=\"{{ 'common.save' | cxTranslate }}\"\n          [cancelBtnLabel]=\"\n            (service.paymentOptionsDisabled$ | async)\n              ? ('common.back' | cxTranslate)\n              : ('common.cancel' | cxTranslate)\n          \"\n          (submitAddress)=\"onSubmitAddress($event)\"\n          (backToAddress)=\"onBackToAddress()\"\n          [setAsDefaultField]=\"false\"\n          [countries]=\"countries$\"\n        />\n      </ng-container>\n    </ng-container>\n  </ng-container>\n\n  <ng-template #loading>\n    <cx-spinner />\n  </ng-template>\n</section>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CardComponent, selector: "cx-card", inputs: ["border", "editMode", "isDefault", "content", "fitToContainer", "truncateText", "truncateParagraphText", "charactersLimit", "index", "role"], outputs: ["deleteCard", "setDefaultCard", "sendCard", "editCard", "cancelCard"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "component", type: AddressFormComponent, selector: "cx-address-form", inputs: ["addressData", "actionBtnLabel", "cancelBtnLabel", "setAsDefaultField", "showTitleCode", "showCancelBtn", "countries"], outputs: ["submitAddress", "backToAddress"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: GetAddressCardContent, name: "cxGetAddressCardContent" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutBillingAddressFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-checkout-billing-address-form', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        CardComponent,
                        IconComponent,
                        AddressFormComponent,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                        GetAddressCardContent,
                    ], template: "<section [attr.aria-label]=\"'opfCheckout.billingAddress' | cxTranslate\">\n  <h3>{{ 'opfCheckout.billingAddress' | cxTranslate }}</h3>\n  <ng-container *ngIf=\"!(isLoadingAddress$ | async); else loading\">\n    <ng-container\n      *ngIf=\"{\n        billingAddress: billingAddress$ | async,\n        isSameAsDelivery: isSameAsDelivery$ | async,\n      } as addressData\"\n    >\n      <div class=\"form-group\">\n        <div class=\"form-check\" *ngIf=\"cart?.deliveryItemsQuantity\">\n          <label>\n            <input\n              type=\"checkbox\"\n              class=\"form-check-input\"\n              [checked]=\"addressData.isSameAsDelivery\"\n              (change)=\"toggleSameAsDeliveryAddress($event)\"\n              [attr.aria-label]=\"\n                'paymentForm.billingAddressSameAsShipping' | cxTranslate\n              \"\n            />\n            <span class=\"form-check-label\">{{\n              'paymentForm.sameAsDeliveryAddress' | cxTranslate\n            }}</span>\n          </label>\n        </div>\n      </div>\n\n      <ng-container *ngIf=\"!isEditBillingAddress && addressData.billingAddress\">\n        <div class=\"cx-custom-address-info\">\n          <cx-card\n            [content]=\"addressData.billingAddress | cxGetAddressCardContent\"\n          />\n\n          <button\n            *ngIf=\"!addressData.isSameAsDelivery\"\n            [attr.aria-label]=\"'paymentForm.editBillingAddress' | cxTranslate\"\n            [attr.title]=\"'paymentForm.editBillingAddress' | cxTranslate\"\n            (click)=\"editCustomBillingAddress()\"\n          >\n            <cx-icon [type]=\"iconTypes.PENCIL\" />\n          </button>\n        </div>\n      </ng-container>\n\n      <ng-container *ngIf=\"isEditBillingAddress\">\n        <cx-address-form\n          [addressData]=\"getAddressData(addressData.billingAddress)\"\n          class=\"cx-form\"\n          [showTitleCode]=\"true\"\n          [showCancelBtn]=\"true\"\n          actionBtnLabel=\"{{ 'common.save' | cxTranslate }}\"\n          [cancelBtnLabel]=\"\n            (service.paymentOptionsDisabled$ | async)\n              ? ('common.back' | cxTranslate)\n              : ('common.cancel' | cxTranslate)\n          \"\n          (submitAddress)=\"onSubmitAddress($event)\"\n          (backToAddress)=\"onBackToAddress()\"\n          [setAsDefaultField]=\"false\"\n          [countries]=\"countries$\"\n        />\n      </ng-container>\n    </ng-container>\n  </ng-container>\n\n  <ng-template #loading>\n    <cx-spinner />\n  </ng-template>\n</section>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutBillingAddressFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutBillingAddressFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutBillingAddressFormModule, imports: [NgSelectA11yModule,
            CommonModule,
            ReactiveFormsModule,
            NgSelectModule,
            CardModule,
            I18nModule,
            IconModule,
            FormErrorsModule,
            SpinnerModule,
            AddressFormModule,
            OpfCheckoutBillingAddressFormComponent,
            GetAddressCardContent], exports: [OpfCheckoutBillingAddressFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutBillingAddressFormModule, providers: [OpfCheckoutBillingAddressFormService], imports: [NgSelectA11yModule,
            CommonModule,
            ReactiveFormsModule,
            NgSelectModule,
            CardModule,
            I18nModule,
            IconModule,
            FormErrorsModule,
            SpinnerModule,
            AddressFormModule,
            OpfCheckoutBillingAddressFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutBillingAddressFormModule, decorators: [{
            type: NgModule,
            args: [{
                    exports: [OpfCheckoutBillingAddressFormComponent],
                    imports: [
                        NgSelectA11yModule,
                        CommonModule,
                        ReactiveFormsModule,
                        NgSelectModule,
                        CardModule,
                        I18nModule,
                        IconModule,
                        FormErrorsModule,
                        SpinnerModule,
                        AddressFormModule,
                        OpfCheckoutBillingAddressFormComponent,
                        GetAddressCardContent,
                    ],
                    providers: [OpfCheckoutBillingAddressFormService],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutEmailUpdateComponent {
    constructor() {
        this.cartGuestUserFacade = inject(CartGuestUserFacade);
        this.multiCartFacade = inject(MultiCartFacade);
        this.userIdService = inject(UserIdService);
        this.router = inject(RoutingService);
        this.semanticPathService = inject(SemanticPathService);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.checkoutLoginForm = new UntypedFormGroup({
            email: new UntypedFormControl('', [
                Validators.required,
                CustomFormValidators.emailValidator,
            ]),
            emailConfirmation: new UntypedFormControl('', [Validators.required]),
        }, {
            validators: CustomFormValidators.emailsMustMatch('email', 'emailConfirmation'),
        });
    }
    onSubmit() {
        const email = this.checkoutLoginForm.get('email')?.value;
        this.updateCartGuestUserEmail(email);
    }
    updateCartGuestUserEmail(email) {
        combineLatest([
            this.userIdService.takeUserId(),
            this.activeCartFacade.takeActiveCartId(),
        ])
            .pipe(switchMap$1(([userId, cartId]) => {
            return this.cartGuestUserFacade
                .updateCartGuestUser(userId, cartId, { email })
                .pipe(tap$1(() => this.multiCartFacade.reloadCart(cartId)));
        }), take$1(1))
            .subscribe(() => this.router.go(this.semanticPathService.get('checkoutDeliveryAddress')));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutEmailUpdateComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfCheckoutEmailUpdateComponent, isStandalone: true, selector: "cx-opf-checkout-email-update", ngImport: i0, template: "<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"checkoutLoginForm\">\n  <p class=\"form-legend\">\n    {{ 'formLegend.required' | cxTranslate }}\n  </p>\n  <div class=\"form-group\">\n    <label>\n      <span class=\"label-content\">\n        {{ 'checkoutLogin.emailAddress.label' | cxTranslate }}\n        <ng-template [ngTemplateOutlet]=\"requiredAsterisk\" />\n      </span>\n      <input\n        required=\"true\"\n        type=\"email\"\n        name=\"email\"\n        class=\"form-control\"\n        formControlName=\"email\"\n        placeholder=\"{{\n          'checkoutLogin.emailAddress.placeholder' | cxTranslate\n        }}\"\n        [attr.aria-describedby]=\"'emailError'\"\n      />\n\n      <cx-form-errors\n        id=\"emailError\"\n        aria-live=\"off\"\n        [translationParams]=\"{\n          label: 'checkoutLogin.emailAddress.label' | cxTranslate,\n        }\"\n        [control]=\"checkoutLoginForm.get('email')\"\n      />\n    </label>\n  </div>\n\n  <div class=\"form-group\">\n    <label>\n      <span class=\"label-content\">\n        {{ 'checkoutLogin.confirmEmail.label' | cxTranslate }}\n        <ng-template [ngTemplateOutlet]=\"requiredAsterisk\" />\n      </span>\n      <input\n        required=\"true\"\n        type=\"email\"\n        name=\"emailConfirmation\"\n        class=\"form-control\"\n        formControlName=\"emailConfirmation\"\n        placeholder=\"{{\n          'checkoutLogin.confirmEmail.placeholder' | cxTranslate\n        }}\"\n        [attr.aria-describedby]=\"'emailConfirmationError'\"\n      />\n\n      <cx-form-errors\n        id=\"emailConfirmationError\"\n        aria-live=\"off\"\n        [translationParams]=\"{\n          label: 'checkoutLogin.confirmEmail.label' | cxTranslate,\n        }\"\n        [control]=\"checkoutLoginForm.get('emailConfirmation')\"\n      />\n    </label>\n  </div>\n\n  <button type=\"submit\" class=\"btn btn-block btn-primary\">\n    {{ 'checkoutLogin.continue' | cxTranslate }}\n  </button>\n</form>\n\n<ng-template #requiredAsterisk>\n  <abbr\n    class=\"text-decoration-none required-asterisk\"\n    aria-hidden=\"true\"\n    title=\"{{ 'common.required' | cxTranslate }}\"\n    >*</abbr\n  >\n</ng-template>\n", dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: FormErrorsComponent, selector: "cx-form-errors", inputs: ["prefix", "fallbackPrefix", "translationParams", "control"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutEmailUpdateComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-checkout-email-update', imports: [
                        FormsModule,
                        ReactiveFormsModule,
                        NgTemplateOutlet,
                        FormErrorsComponent,
                        TranslatePipe,
                    ], template: "<form (ngSubmit)=\"onSubmit()\" [formGroup]=\"checkoutLoginForm\">\n  <p class=\"form-legend\">\n    {{ 'formLegend.required' | cxTranslate }}\n  </p>\n  <div class=\"form-group\">\n    <label>\n      <span class=\"label-content\">\n        {{ 'checkoutLogin.emailAddress.label' | cxTranslate }}\n        <ng-template [ngTemplateOutlet]=\"requiredAsterisk\" />\n      </span>\n      <input\n        required=\"true\"\n        type=\"email\"\n        name=\"email\"\n        class=\"form-control\"\n        formControlName=\"email\"\n        placeholder=\"{{\n          'checkoutLogin.emailAddress.placeholder' | cxTranslate\n        }}\"\n        [attr.aria-describedby]=\"'emailError'\"\n      />\n\n      <cx-form-errors\n        id=\"emailError\"\n        aria-live=\"off\"\n        [translationParams]=\"{\n          label: 'checkoutLogin.emailAddress.label' | cxTranslate,\n        }\"\n        [control]=\"checkoutLoginForm.get('email')\"\n      />\n    </label>\n  </div>\n\n  <div class=\"form-group\">\n    <label>\n      <span class=\"label-content\">\n        {{ 'checkoutLogin.confirmEmail.label' | cxTranslate }}\n        <ng-template [ngTemplateOutlet]=\"requiredAsterisk\" />\n      </span>\n      <input\n        required=\"true\"\n        type=\"email\"\n        name=\"emailConfirmation\"\n        class=\"form-control\"\n        formControlName=\"emailConfirmation\"\n        placeholder=\"{{\n          'checkoutLogin.confirmEmail.placeholder' | cxTranslate\n        }}\"\n        [attr.aria-describedby]=\"'emailConfirmationError'\"\n      />\n\n      <cx-form-errors\n        id=\"emailConfirmationError\"\n        aria-live=\"off\"\n        [translationParams]=\"{\n          label: 'checkoutLogin.confirmEmail.label' | cxTranslate,\n        }\"\n        [control]=\"checkoutLoginForm.get('emailConfirmation')\"\n      />\n    </label>\n  </div>\n\n  <button type=\"submit\" class=\"btn btn-block btn-primary\">\n    {{ 'checkoutLogin.continue' | cxTranslate }}\n  </button>\n</form>\n\n<ng-template #requiredAsterisk>\n  <abbr\n    class=\"text-decoration-none required-asterisk\"\n    aria-hidden=\"true\"\n    title=\"{{ 'common.required' | cxTranslate }}\"\n    >*</abbr\n  >\n</ng-template>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutEmailUpdateModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutEmailUpdateModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutEmailUpdateModule, imports: [CommonModule,
            I18nModule,
            FormsModule,
            ReactiveFormsModule,
            FormErrorsModule,
            OpfCheckoutEmailUpdateComponent], exports: [OpfCheckoutEmailUpdateComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutEmailUpdateModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    OpfCheckoutEmailUpdateComponent: {
                        component: OpfCheckoutEmailUpdateComponent,
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            FormsModule,
            ReactiveFormsModule,
            FormErrorsModule,
            OpfCheckoutEmailUpdateComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutEmailUpdateModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        FormsModule,
                        ReactiveFormsModule,
                        FormErrorsModule,
                        OpfCheckoutEmailUpdateComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                OpfCheckoutEmailUpdateComponent: {
                                    component: OpfCheckoutEmailUpdateComponent,
                                },
                            },
                        }),
                    ],
                    exports: [OpfCheckoutEmailUpdateComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutTermsAndConditionsAlertComponent {
    constructor() {
        this.opfMetadataStoreService = inject(OpfMetadataStoreService);
        this.opfCheckoutBillingAddressFormService = inject(OpfCheckoutBillingAddressFormService);
        this.iconTypes = ICON_TYPE;
        this.paymentDisabled$ = this.opfCheckoutBillingAddressFormService.paymentOptionsDisabled$;
    }
    close() {
        this.isVisible = false;
        this.opfMetadataStoreService.updateOpfMetadata({
            isTermsAndConditionsAlertClosed: true,
        });
    }
    ngOnInit() {
        this.opfMetadataStoreService
            .getOpfMetadataState()
            .pipe(take$1(1), filter$1(({ isTermsAndConditionsAlertClosed }) => isTermsAndConditionsAlertClosed))
            .subscribe(() => {
            this.isVisible = false;
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutTermsAndConditionsAlertComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfCheckoutTermsAndConditionsAlertComponent, isStandalone: true, selector: "cx-opf-checkout-terms-and-conditions-alert", inputs: { isDismissible: "isDismissible", isVisible: "isVisible", isExplicit: "isExplicit" }, ngImport: i0, template: "<div *ngIf=\"isVisible\" class=\"cx-opf-checkout-terms-and-conditions-alert\">\n  <ng-container *ngIf=\"paymentDisabled$ | async; else termsConditions\">\n    <div class=\"alert alert-danger\">\n      <span class=\"alert-icon\" aria-hidden=\"true\">\n        <cx-icon [type]=\"iconTypes.ERROR\" />\n      </span>\n      <p class=\"message\" tabindex=\"0\" role=\"alert\" aria-live=\"polite\">\n        {{ 'opfCheckout.errors.noBillingAddress' | cxTranslate }}\n      </p>\n    </div>\n  </ng-container>\n  <ng-template #termsConditions>\n    <div class=\"alert alert-info\">\n      <span class=\"alert-icon\" aria-hidden=\"true\">\n        <cx-icon [type]=\"iconTypes.INFO\" />\n      </span>\n      <p class=\"message\" tabindex=\"0\" role=\"alert\" aria-live=\"polite\">\n        {{\n          (isExplicit\n            ? 'opfCheckout.checkTermsAndConditionsExplicit'\n            : 'opfCheckout.checkTermsAndConditionsImplicit'\n          ) | cxTranslate\n        }}\n      </p>\n      <button\n        *ngIf=\"isDismissible\"\n        class=\"close\"\n        type=\"button\"\n        (click)=\"close()\"\n        [attr.aria-label]=\"\n          'opfCheckout.closeTermsAndConditionsAlert' | cxTranslate\n        \"\n        [attr.title]=\"'opfCheckout.closeTermsAndConditionsAlert' | cxTranslate\"\n      >\n        <cx-icon [type]=\"iconTypes.CLOSE\" />\n      </button>\n    </div>\n  </ng-template>\n</div>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutTermsAndConditionsAlertComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-checkout-terms-and-conditions-alert', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, IconComponent, TranslatePipe, AsyncPipe], template: "<div *ngIf=\"isVisible\" class=\"cx-opf-checkout-terms-and-conditions-alert\">\n  <ng-container *ngIf=\"paymentDisabled$ | async; else termsConditions\">\n    <div class=\"alert alert-danger\">\n      <span class=\"alert-icon\" aria-hidden=\"true\">\n        <cx-icon [type]=\"iconTypes.ERROR\" />\n      </span>\n      <p class=\"message\" tabindex=\"0\" role=\"alert\" aria-live=\"polite\">\n        {{ 'opfCheckout.errors.noBillingAddress' | cxTranslate }}\n      </p>\n    </div>\n  </ng-container>\n  <ng-template #termsConditions>\n    <div class=\"alert alert-info\">\n      <span class=\"alert-icon\" aria-hidden=\"true\">\n        <cx-icon [type]=\"iconTypes.INFO\" />\n      </span>\n      <p class=\"message\" tabindex=\"0\" role=\"alert\" aria-live=\"polite\">\n        {{\n          (isExplicit\n            ? 'opfCheckout.checkTermsAndConditionsExplicit'\n            : 'opfCheckout.checkTermsAndConditionsImplicit'\n          ) | cxTranslate\n        }}\n      </p>\n      <button\n        *ngIf=\"isDismissible\"\n        class=\"close\"\n        type=\"button\"\n        (click)=\"close()\"\n        [attr.aria-label]=\"\n          'opfCheckout.closeTermsAndConditionsAlert' | cxTranslate\n        \"\n        [attr.title]=\"'opfCheckout.closeTermsAndConditionsAlert' | cxTranslate\"\n      >\n        <cx-icon [type]=\"iconTypes.CLOSE\" />\n      </button>\n    </div>\n  </ng-template>\n</div>\n" }]
        }], propDecorators: { isDismissible: [{
                type: Input
            }], isVisible: [{
                type: Input
            }], isExplicit: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutTermsAndConditionsAlertModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutTermsAndConditionsAlertModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutTermsAndConditionsAlertModule, imports: [CommonModule,
            I18nModule,
            IconModule,
            OpfCheckoutTermsAndConditionsAlertComponent], exports: [OpfCheckoutTermsAndConditionsAlertComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutTermsAndConditionsAlertModule, imports: [CommonModule,
            I18nModule,
            IconModule,
            OpfCheckoutTermsAndConditionsAlertComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutTermsAndConditionsAlertModule, decorators: [{
            type: NgModule,
            args: [{
                    exports: [OpfCheckoutTermsAndConditionsAlertComponent],
                    imports: [
                        CommonModule,
                        I18nModule,
                        IconModule,
                        OpfCheckoutTermsAndConditionsAlertComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutPaymentsComponent {
    constructor() {
        this.opfBaseService = inject(OpfBaseFacade);
        this.opfConfig = inject(OpfConfig);
        this.translation = inject(TranslationService);
        this.opfMetadataStoreService = inject(OpfMetadataStoreService);
        this.globalMessageService = inject(GlobalMessageService);
        this.opfCheckoutBillingAddressFormService = inject(OpfCheckoutBillingAddressFormService);
        this.opfPaymentEventsService = inject(OpfPaymentEventsService);
        this.userPaymentService = inject(UserPaymentService);
        this.destroyRef = inject(DestroyRef);
        this.featureToggles = inject(FeatureToggles);
        this.subscription = new Subscription();
        this.paginationIndex = 0;
        this.isHeadingDisplayed = true;
        this.isPaymentRenderBelow = true;
        this.isPaymentInfoMessageEnabled = true;
        this.disabled = true;
        this.onlyPaymentWrapperMode = false;
        this.showBeforePaymentOptionsOutlet = true;
        this.hideOnlyOnePaymentProviderLabel = false;
        this.forceRadioInputsView = false;
        this.forceDefaultPaymentOptionInputSelection = false;
        this.renderPaymentWrapper = true;
        this.opfCheckoutOutlets = OpfCheckoutOutlets;
        this.outletContext$ = new Subject();
        this.isOnlyOnePaymentOptionAvailable = false;
        this.iconTypes = ICON_TYPE;
        this.paymentChange = new EventEmitter();
        this.selectedPaymentProviderName = new EventEmitter();
        this.paymentDisabled$ = this.opfCheckoutBillingAddressFormService.paymentOptionsDisabled$;
    }
    isStateEmpty(state) {
        return !state?.loading && !state?.data?.value?.length;
    }
    handleDefaultPaymentOptionInputSelection(state) {
        const firstPaymentOption = state.data?.value?.[0];
        if (this.isOnlyOnePaymentOptionAvailable) {
            this.selectedPaymentId = firstPaymentOption?.id;
            const providerName = firstPaymentOption?.displayName;
            if (providerName) {
                this.selectedPaymentProviderName.emit(providerName);
            }
        }
        this.opfMetadataStoreService.updateOpfMetadata({
            defaultSelectedPaymentOptionId: firstPaymentOption?.id,
        });
        if (this.forceDefaultPaymentOptionInputSelection &&
            !this.selectedPaymentId) {
            this.selectedPaymentId = firstPaymentOption?.id;
        }
    }
    checkIfOnlyOnePaymentOptionAvailable(state) {
        return (state.data?.value?.length === 1 && state.data?.page?.totalPages === 1);
    }
    getActiveConfigurations() {
        return this.opfBaseService
            .getActiveConfigurationsState({
            pageSize: this.elementsPerPage,
            pageNumber: this.paginationIndex + 1,
        })
            .pipe(tap((state) => {
            if (state.error) {
                this.displayError('loadActiveConfigurations');
            }
            else if (this.isStateEmpty(state)) {
                this.displayError('noActiveConfigurations');
            }
            if (state.data?.value && !state.error && !state.loading) {
                this.paginationModel = this.getPaginationModel(state.data?.page);
                state.data.value = state.data?.value.filter((x) => x.providerType !== OpfPaymentProviderType.STORED_VALUE_PAYMENT);
                if (this.onlyPaymentWrapperMode && this.selectedPaymentId) {
                    state.data.value = state.data.value.filter((config) => config.id === this.selectedPaymentId);
                }
                this.isOnlyOnePaymentOptionAvailable =
                    this.checkIfOnlyOnePaymentOptionAvailable(state);
                this.handleDefaultPaymentOptionInputSelection(state);
            }
        }));
    }
    updateActiveConfiguration() {
        this.activeConfigurations$ = this.getActiveConfigurations();
    }
    getPaymentInfoMessage(paymentId) {
        const defaultMessage = 'opfCheckout.defaultPaymentInfoMessage';
        const translationKey = paymentId && this.opfConfig?.opf?.paymentOption?.paymentInfoMessagesMap
            ? (this.opfConfig.opf.paymentOption.paymentInfoMessagesMap[paymentId] ??
                defaultMessage)
            : defaultMessage;
        return this.translation.translate(translationKey);
    }
    get isPaymentInfoMessageVisible() {
        return Boolean(this.opfConfig?.opf?.paymentOption?.enableInfoMessage &&
            this.isPaymentInfoMessageEnabled);
    }
    /**
     * Method pre-selects (based on terms and conditions state)
     * previously selected payment option ID by customer.
     */
    preselectPaymentOption() {
        let isPreselected = false;
        const metadataSubscription = (state) => {
            if (this.shouldResolvePreselection(state, isPreselected)) {
                const resolvedId = state.selectedPaymentOptionId ?? state.defaultSelectedPaymentOptionId;
                if (resolvedId !== undefined) {
                    isPreselected = true;
                }
                this.selectedPaymentId = resolvedId;
                if (resolvedId !== undefined &&
                    resolvedId !== state.selectedPaymentOptionId) {
                    this.opfMetadataStoreService.updateOpfMetadata({
                        selectedPaymentOptionId: resolvedId,
                    });
                }
                this.emitOutletContext();
            }
            else if (!state.termsAndConditionsChecked &&
                this.explicitTermsAndConditions) {
                isPreselected = false;
                this.selectedPaymentId = undefined;
                this.emitOutletContext();
            }
            else if (isPreselected) {
                this.selectedPaymentId = state.selectedPaymentOptionId;
                this.emitOutletContext();
            }
        };
        if (this.featureToggles.opfUseDestroyRef) {
            this.opfMetadataStoreService
                .getOpfMetadataState()
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe(metadataSubscription);
        }
        else {
            this.subscription.add(this.opfMetadataStoreService
                .getOpfMetadataState()
                .subscribe(metadataSubscription));
        }
    }
    shouldResolvePreselection(state, isPreselected) {
        return (!isPreselected &&
            (state.termsAndConditionsChecked || !this.explicitTermsAndConditions));
    }
    displayError(errorKey) {
        this.globalMessageService.add({ key: `opfCheckout.errors.${errorKey}` }, GlobalMessageType.MSG_TYPE_ERROR);
    }
    emitOutletContext() {
        this.outletContext$.next({
            selectedPaymentId: this.selectedPaymentId,
            savedCardsId: SAVED_CARDS_ID,
            showSavedCardsList: this.selectedPaymentId === SAVED_CARDS_ID,
            disabled: this.disabled && this.explicitTermsAndConditions,
            savedCardsSelected: this.onSavedCardsSelected.bind(this),
        });
    }
    onSavedCardsSelected() {
        this.selectedPaymentId = SAVED_CARDS_ID;
        this.opfMetadataStoreService.updateOpfMetadata({
            selectedPaymentOptionId: SAVED_CARDS_ID,
        });
        this.emitOutletContext();
    }
    changePayment(payment) {
        this.selectedPaymentId = payment.id;
        this.opfMetadataStoreService.updateOpfMetadata({
            selectedPaymentOptionId: this.selectedPaymentId,
        });
        this.emitOutletContext();
        this.paymentChange.emit(payment);
    }
    getPaginationModel(pagination) {
        if (pagination?.number !== undefined) {
            this.paginationIndex = pagination.number - 1;
        }
        return {
            currentPage: this.paginationIndex,
            pageSize: pagination?.size,
            totalPages: pagination?.totalPages,
            totalResults: pagination?.totalElements,
        };
    }
    pageChange(page) {
        this.paginationIndex = page;
        this.updateActiveConfiguration();
    }
    ngOnInit() {
        this.userPaymentService.loadPaymentMethods();
        this.updateActiveConfiguration();
        this.preselectPaymentOption();
        this.emitOutletContext();
        this.subscription.add(this.opfPaymentEventsService.refreshActiveConfigurationsEvent$.subscribe(() => this.updateActiveConfiguration()));
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfCheckoutPaymentsComponent, isStandalone: true, selector: "cx-opf-checkout-payments", inputs: { isHeadingDisplayed: "isHeadingDisplayed", headingTranslationKey: "headingTranslationKey", isPaymentRenderBelow: "isPaymentRenderBelow", isPaymentInfoMessageEnabled: "isPaymentInfoMessageEnabled", elementsPerPage: "elementsPerPage", disabled: "disabled", explicitTermsAndConditions: "explicitTermsAndConditions", onlyPaymentWrapperMode: "onlyPaymentWrapperMode", showBeforePaymentOptionsOutlet: "showBeforePaymentOptionsOutlet", customPaymentTemplate: "customPaymentTemplate", hideOnlyOnePaymentProviderLabel: "hideOnlyOnePaymentProviderLabel", forceRadioInputsView: "forceRadioInputsView", forceDefaultPaymentOptionInputSelection: "forceDefaultPaymentOptionInputSelection", renderPaymentWrapper: "renderPaymentWrapper", noRenderPaymentWrapperMessage: "noRenderPaymentWrapperMessage" }, outputs: { paymentChange: "paymentChange", selectedPaymentProviderName: "selectedPaymentProviderName" }, ngImport: i0, template: "<section [attr.aria-label]=\"'opfCheckout.paymentOption' | cxTranslate\">\n  <h3 *ngIf=\"isHeadingDisplayed\">\n    {{ headingTranslationKey || 'opfCheckout.paymentOption' | cxTranslate }}\n  </h3>\n\n  <ng-container\n    *ngIf=\"activeConfigurations$ | async as activeConfigurationsState\"\n  >\n    <ng-container *ngIf=\"!activeConfigurationsState?.loading; else loading\">\n      <div class=\"cx-payment-options-list\">\n        <ng-content />\n        <div\n          *ngIf=\"\n            !(\n              opfPaymentEventsService.isGiftCardCoveredTotalAmountEvent$ | async\n            )\n          \"\n        >\n          <ng-template\n            *ngIf=\"showBeforePaymentOptionsOutlet\"\n            [cxOutlet]=\"opfCheckoutOutlets.OPF_CHECKOUT_BEFORE_PAYMENT_OPTIONS\"\n            [cxOutletContext]=\"outletContext$\"\n          />\n\n          <div\n            *ngFor=\"let configuration of activeConfigurationsState?.data?.value\"\n          >\n            <ng-container>\n              <ng-container\n                *ngIf=\"!isOnlyOnePaymentOptionAvailable || forceRadioInputsView\"\n              >\n                <div class=\"form-check\">\n                  <input\n                    id=\"paymentId-{{ configuration.id }}\"\n                    class=\"form-check-input\"\n                    role=\"radio\"\n                    type=\"radio\"\n                    name=\"paymentId\"\n                    [attr.aria-checked]=\"\n                      (paymentDisabled$ | async) &&\n                      configuration.id === selectedPaymentId\n                    \"\n                    (change)=\"changePayment(configuration)\"\n                    [value]=\"configuration.id\"\n                    [checked]=\"\n                      !(paymentDisabled$ | async) &&\n                      configuration.id === selectedPaymentId\n                    \"\n                    formControlName=\"paymentId\"\n                    [disabled]=\"\n                      (paymentDisabled$ | async) ||\n                      (disabled && explicitTermsAndConditions)\n                    \"\n                  />\n                  <label\n                    class=\"cx-payment-type-label form-check-label form-radio-label\"\n                    for=\"paymentId-{{ configuration.id }}\"\n                  >\n                    <div class=\"cx-payment-type\">\n                      {{ configuration.displayName }}\n                      <img\n                        *ngIf=\"configuration?.logoUrl\"\n                        [src]=\"configuration.logoUrl\"\n                        [alt]=\"configuration.displayName\"\n                        class=\"cx-payment-logo\"\n                      />\n                    </div>\n                  </label>\n                </div>\n              </ng-container>\n            </ng-container>\n            <ng-container\n              *ngIf=\"!renderPaymentWrapper && !(paymentDisabled$ | async)\"\n            >\n              <div class=\"cx-payment-info-box\">\n                <span class=\"alert-icon\" aria-hidden=\"true\">\n                  <cx-icon [type]=\"iconTypes.INFO\" />\n                </span>\n                <p\n                  class=\"cx-payment-info-box-message\"\n                  tabindex=\"0\"\n                  role=\"alert\"\n                  aria-live=\"polite\"\n                >\n                  {{ noRenderPaymentWrapperMessage }}\n                </p>\n              </div>\n            </ng-container>\n            <ng-container\n              *ngIf=\"renderPaymentWrapper && !(paymentDisabled$ | async)\"\n            >\n              <ng-container *ngIf=\"isPaymentInfoMessageVisible\">\n                <ng-container\n                  *ngIf=\"\n                    getPaymentInfoMessage(configuration.id)\n                      | async as paymentInfoMessage\n                  \"\n                >\n                  <div\n                    *ngIf=\"configuration.id === selectedPaymentId\"\n                    class=\"cx-payment-info-box\"\n                  >\n                    <span class=\"alert-icon\" aria-hidden=\"true\">\n                      <cx-icon [type]=\"iconTypes.INFO\" />\n                    </span>\n                    <p\n                      class=\"cx-payment-info-box-message\"\n                      tabindex=\"0\"\n                      role=\"alert\"\n                      aria-live=\"polite\"\n                    >\n                      {{ paymentInfoMessage }}\n                    </p>\n                  </div>\n                </ng-container>\n              </ng-container>\n\n              <ng-container *ngIf=\"customPaymentTemplate\">\n                <ng-container *ngTemplateOutlet=\"customPaymentTemplate\" />\n              </ng-container>\n\n              <cx-opf-checkout-payment-wrapper\n                *ngIf=\"\n                  !customPaymentTemplate &&\n                  isPaymentRenderBelow &&\n                  selectedPaymentId &&\n                  configuration.id === selectedPaymentId\n                \"\n                [selectedPaymentId]=\"selectedPaymentId\"\n              />\n            </ng-container>\n          </div>\n\n          <cx-pagination\n            class=\"cx-payment-options-list-pagination\"\n            [pagination]=\"paginationModel\"\n            (viewPageEvent)=\"pageChange($event)\"\n          />\n        </div>\n      </div>\n    </ng-container>\n  </ng-container>\n\n  <ng-template #loading>\n    <cx-spinner />\n  </ng-template>\n</section>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: OpfCheckoutPaymentWrapperComponent, selector: "cx-opf-checkout-payment-wrapper", inputs: ["selectedPaymentId"] }, { kind: "component", type: PaginationComponent, selector: "cx-pagination", inputs: ["pageRoute", "queryParam", "defaultPage", "pagination", "paginationID"], outputs: ["viewPageEvent"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "ngmodule", type: OutletModule }, { kind: "directive", type: i1$1.OutletDirective, selector: "[cxOutlet]", inputs: ["cxOutlet", "cxOutletContext", "cxOutletDefer", "cxComponentRef"], outputs: ["loaded", "cxComponentRefChange"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-checkout-payments', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        NgFor,
                        IconComponent,
                        NgTemplateOutlet,
                        OpfCheckoutPaymentWrapperComponent,
                        PaginationComponent,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                        OutletModule,
                    ], template: "<section [attr.aria-label]=\"'opfCheckout.paymentOption' | cxTranslate\">\n  <h3 *ngIf=\"isHeadingDisplayed\">\n    {{ headingTranslationKey || 'opfCheckout.paymentOption' | cxTranslate }}\n  </h3>\n\n  <ng-container\n    *ngIf=\"activeConfigurations$ | async as activeConfigurationsState\"\n  >\n    <ng-container *ngIf=\"!activeConfigurationsState?.loading; else loading\">\n      <div class=\"cx-payment-options-list\">\n        <ng-content />\n        <div\n          *ngIf=\"\n            !(\n              opfPaymentEventsService.isGiftCardCoveredTotalAmountEvent$ | async\n            )\n          \"\n        >\n          <ng-template\n            *ngIf=\"showBeforePaymentOptionsOutlet\"\n            [cxOutlet]=\"opfCheckoutOutlets.OPF_CHECKOUT_BEFORE_PAYMENT_OPTIONS\"\n            [cxOutletContext]=\"outletContext$\"\n          />\n\n          <div\n            *ngFor=\"let configuration of activeConfigurationsState?.data?.value\"\n          >\n            <ng-container>\n              <ng-container\n                *ngIf=\"!isOnlyOnePaymentOptionAvailable || forceRadioInputsView\"\n              >\n                <div class=\"form-check\">\n                  <input\n                    id=\"paymentId-{{ configuration.id }}\"\n                    class=\"form-check-input\"\n                    role=\"radio\"\n                    type=\"radio\"\n                    name=\"paymentId\"\n                    [attr.aria-checked]=\"\n                      (paymentDisabled$ | async) &&\n                      configuration.id === selectedPaymentId\n                    \"\n                    (change)=\"changePayment(configuration)\"\n                    [value]=\"configuration.id\"\n                    [checked]=\"\n                      !(paymentDisabled$ | async) &&\n                      configuration.id === selectedPaymentId\n                    \"\n                    formControlName=\"paymentId\"\n                    [disabled]=\"\n                      (paymentDisabled$ | async) ||\n                      (disabled && explicitTermsAndConditions)\n                    \"\n                  />\n                  <label\n                    class=\"cx-payment-type-label form-check-label form-radio-label\"\n                    for=\"paymentId-{{ configuration.id }}\"\n                  >\n                    <div class=\"cx-payment-type\">\n                      {{ configuration.displayName }}\n                      <img\n                        *ngIf=\"configuration?.logoUrl\"\n                        [src]=\"configuration.logoUrl\"\n                        [alt]=\"configuration.displayName\"\n                        class=\"cx-payment-logo\"\n                      />\n                    </div>\n                  </label>\n                </div>\n              </ng-container>\n            </ng-container>\n            <ng-container\n              *ngIf=\"!renderPaymentWrapper && !(paymentDisabled$ | async)\"\n            >\n              <div class=\"cx-payment-info-box\">\n                <span class=\"alert-icon\" aria-hidden=\"true\">\n                  <cx-icon [type]=\"iconTypes.INFO\" />\n                </span>\n                <p\n                  class=\"cx-payment-info-box-message\"\n                  tabindex=\"0\"\n                  role=\"alert\"\n                  aria-live=\"polite\"\n                >\n                  {{ noRenderPaymentWrapperMessage }}\n                </p>\n              </div>\n            </ng-container>\n            <ng-container\n              *ngIf=\"renderPaymentWrapper && !(paymentDisabled$ | async)\"\n            >\n              <ng-container *ngIf=\"isPaymentInfoMessageVisible\">\n                <ng-container\n                  *ngIf=\"\n                    getPaymentInfoMessage(configuration.id)\n                      | async as paymentInfoMessage\n                  \"\n                >\n                  <div\n                    *ngIf=\"configuration.id === selectedPaymentId\"\n                    class=\"cx-payment-info-box\"\n                  >\n                    <span class=\"alert-icon\" aria-hidden=\"true\">\n                      <cx-icon [type]=\"iconTypes.INFO\" />\n                    </span>\n                    <p\n                      class=\"cx-payment-info-box-message\"\n                      tabindex=\"0\"\n                      role=\"alert\"\n                      aria-live=\"polite\"\n                    >\n                      {{ paymentInfoMessage }}\n                    </p>\n                  </div>\n                </ng-container>\n              </ng-container>\n\n              <ng-container *ngIf=\"customPaymentTemplate\">\n                <ng-container *ngTemplateOutlet=\"customPaymentTemplate\" />\n              </ng-container>\n\n              <cx-opf-checkout-payment-wrapper\n                *ngIf=\"\n                  !customPaymentTemplate &&\n                  isPaymentRenderBelow &&\n                  selectedPaymentId &&\n                  configuration.id === selectedPaymentId\n                \"\n                [selectedPaymentId]=\"selectedPaymentId\"\n              />\n            </ng-container>\n          </div>\n\n          <cx-pagination\n            class=\"cx-payment-options-list-pagination\"\n            [pagination]=\"paginationModel\"\n            (viewPageEvent)=\"pageChange($event)\"\n          />\n        </div>\n      </div>\n    </ng-container>\n  </ng-container>\n\n  <ng-template #loading>\n    <cx-spinner />\n  </ng-template>\n</section>\n" }]
        }], propDecorators: { isHeadingDisplayed: [{
                type: Input
            }], headingTranslationKey: [{
                type: Input
            }], isPaymentRenderBelow: [{
                type: Input
            }], isPaymentInfoMessageEnabled: [{
                type: Input
            }], elementsPerPage: [{
                type: Input
            }], disabled: [{
                type: Input
            }], explicitTermsAndConditions: [{
                type: Input
            }], onlyPaymentWrapperMode: [{
                type: Input
            }], showBeforePaymentOptionsOutlet: [{
                type: Input
            }], customPaymentTemplate: [{
                type: Input
            }], hideOnlyOnePaymentProviderLabel: [{
                type: Input
            }], forceRadioInputsView: [{
                type: Input
            }], forceDefaultPaymentOptionInputSelection: [{
                type: Input
            }], renderPaymentWrapper: [{
                type: Input
            }], noRenderPaymentWrapperMessage: [{
                type: Input
            }], paymentChange: [{
                type: Output
            }], selectedPaymentProviderName: [{
                type: Output
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutPaymentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentsModule, imports: [CommonModule,
            I18nModule,
            SpinnerModule,
            PaginationModule,
            IconModule,
            OpfCheckoutPaymentWrapperModule,
            OpfCheckoutTermsAndConditionsAlertModule,
            OpfCheckoutPaymentsComponent], exports: [OpfCheckoutPaymentsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentsModule, imports: [CommonModule,
            I18nModule,
            SpinnerModule,
            PaginationModule,
            IconModule,
            OpfCheckoutPaymentWrapperModule,
            OpfCheckoutTermsAndConditionsAlertModule,
            OpfCheckoutPaymentsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentsModule, decorators: [{
            type: NgModule,
            args: [{
                    exports: [OpfCheckoutPaymentsComponent],
                    imports: [
                        CommonModule,
                        I18nModule,
                        SpinnerModule,
                        PaginationModule,
                        IconModule,
                        OpfCheckoutPaymentWrapperModule,
                        OpfCheckoutTermsAndConditionsAlertModule,
                        OpfCheckoutPaymentsComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutReviewCardComponent {
    constructor() {
        this.iconTypes = ICON_TYPE;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutReviewCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfCheckoutReviewCardComponent, isStandalone: true, selector: "cx-opf-checkout-review-card", inputs: { cardContent$: "cardContent$", editConfig: "editConfig" }, ngImport: i0, template: "<ng-container *ngIf=\"cardContent$ | async as content\">\n  <cx-card [content]=\"content\" />\n  <button\n    *ngIf=\"editConfig?.route\"\n    class=\"cx-opf-card-review-edit-button\"\n    [routerLink]=\"{ cxRoute: editConfig.route } | cxUrl\"\n    [attr.aria-label]=\"\n      editConfig.ariaLabelKey || 'opfCheckout.editCardDefaultLabel'\n        | cxTranslate\n    \"\n  >\n    <cx-icon [type]=\"iconTypes.PENCIL\" />\n  </button>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CardComponent, selector: "cx-card", inputs: ["border", "editMode", "isDefault", "content", "fitToContainer", "truncateText", "truncateParagraphText", "charactersLimit", "index", "role"], outputs: ["deleteCard", "setDefaultCard", "sendCard", "editCard", "cancelCard"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutReviewCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-checkout-review-card', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        CardComponent,
                        RouterLink,
                        IconComponent,
                        AsyncPipe,
                        TranslatePipe,
                        UrlPipe,
                    ], template: "<ng-container *ngIf=\"cardContent$ | async as content\">\n  <cx-card [content]=\"content\" />\n  <button\n    *ngIf=\"editConfig?.route\"\n    class=\"cx-opf-card-review-edit-button\"\n    [routerLink]=\"{ cxRoute: editConfig.route } | cxUrl\"\n    [attr.aria-label]=\"\n      editConfig.ariaLabelKey || 'opfCheckout.editCardDefaultLabel'\n        | cxTranslate\n    \"\n  >\n    <cx-icon [type]=\"iconTypes.PENCIL\" />\n  </button>\n</ng-container>\n" }]
        }], propDecorators: { cardContent$: [{
                type: Input
            }], editConfig: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutReviewCardModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutReviewCardModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutReviewCardModule, imports: [CommonModule,
            RouterModule,
            I18nModule,
            CardModule,
            IconModule,
            UrlModule,
            OpfCheckoutReviewCardComponent], exports: [OpfCheckoutReviewCardComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutReviewCardModule, imports: [CommonModule,
            RouterModule,
            I18nModule,
            CardModule,
            IconModule,
            UrlModule,
            OpfCheckoutReviewCardComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutReviewCardModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        I18nModule,
                        CardModule,
                        IconModule,
                        UrlModule,
                        OpfCheckoutReviewCardComponent,
                    ],
                    exports: [OpfCheckoutReviewCardComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutReviewCartDetailsComponent extends CheckoutReviewSubmitComponent {
    constructor() {
        super(...arguments);
        this.isAddressCardVisible = false;
        this.promotionLocation = PromotionLocation.Checkout;
        this.cartOutlets = CartOutlets;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutReviewCartDetailsComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfCheckoutReviewCartDetailsComponent, isStandalone: true, selector: "cx-opf-checkout-review-cart-details", inputs: { cart: "cart", entries: "entries", isAddressCardVisible: "isAddressCardVisible" }, usesInheritance: true, ngImport: i0, template: "<div class=\"cx-review-cart-total d-none d-lg-block d-xl-block\">\n  {{\n    'cartItems.cartTotal'\n      | cxTranslate\n        : {\n            count: cart?.totalItems ?? 0,\n          }\n  }}:\n  {{ cart?.totalPrice?.formattedValue }}\n</div>\n<div class=\"cx-review-cart-item col-md-12\">\n  <cx-promotions\n    [promotions]=\"\n      (cart?.appliedOrderPromotions || []).concat(\n        cart?.potentialOrderPromotions || []\n      )\n    \"\n  />\n\n  <ng-template [cxOutlet]=\"cartOutlets.OPF_CHECKOUT_PICKUP_ITEMS\" />\n\n  <ng-container *ngIf=\"cart?.deliveryItemsQuantity\">\n    <div class=\"cx-items-to-ship-label\">\n      {{ 'opfCheckout.itemsToBeShipped' | cxTranslate }}\n    </div>\n    <div class=\"cx-opf-review-card-wrapper\" *ngIf=\"isAddressCardVisible\">\n      <cx-opf-checkout-review-card\n        *ngIf=\"deliveryAddress$ | async as deliveryAddress\"\n        [cardContent$]=\"getDeliveryAddressCard(deliveryAddress)\"\n        [editConfig]=\"{\n          route: getCheckoutStepUrl(checkoutStepTypeDeliveryAddress),\n          ariaLabelKey: 'checkoutReview.editDeliveryAddressDetails',\n        }\"\n      />\n\n      <cx-opf-checkout-review-card\n        *ngIf=\"deliveryMode$ | async as deliveryMode\"\n        [cardContent$]=\"getDeliveryModeCard(deliveryMode)\"\n        [editConfig]=\"{\n          route: getCheckoutStepUrl(checkoutStepTypeDeliveryMode),\n          ariaLabelKey: 'checkoutReview.editDeliveryMode',\n        }\"\n      />\n    </div>\n\n    <ng-template\n      [cxOutlet]=\"cartOutlets.CART_ITEM_LIST\"\n      [cxOutletContext]=\"{\n        items: activeCartFacade.getDeliveryEntries() | async,\n        readonly: true,\n        promotionLocation: promotionLocation,\n      }\"\n    />\n  </ng-container>\n</div>\n", dependencies: [{ kind: "component", type: PromotionsComponent, selector: "cx-promotions", inputs: ["promotions"] }, { kind: "directive", type: OutletDirective, selector: "[cxOutlet]", inputs: ["cxOutlet", "cxOutletContext", "cxOutletDefer", "cxComponentRef"], outputs: ["loaded", "cxComponentRefChange"] }, { kind: "component", type: OpfCheckoutReviewCardComponent, selector: "cx-opf-checkout-review-card", inputs: ["cardContent$", "editConfig"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutReviewCartDetailsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-checkout-review-cart-details', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        PromotionsComponent,
                        OutletDirective,
                        TranslatePipe,
                        AsyncPipe,
                        OpfCheckoutReviewCardComponent,
                        NgIf,
                    ], template: "<div class=\"cx-review-cart-total d-none d-lg-block d-xl-block\">\n  {{\n    'cartItems.cartTotal'\n      | cxTranslate\n        : {\n            count: cart?.totalItems ?? 0,\n          }\n  }}:\n  {{ cart?.totalPrice?.formattedValue }}\n</div>\n<div class=\"cx-review-cart-item col-md-12\">\n  <cx-promotions\n    [promotions]=\"\n      (cart?.appliedOrderPromotions || []).concat(\n        cart?.potentialOrderPromotions || []\n      )\n    \"\n  />\n\n  <ng-template [cxOutlet]=\"cartOutlets.OPF_CHECKOUT_PICKUP_ITEMS\" />\n\n  <ng-container *ngIf=\"cart?.deliveryItemsQuantity\">\n    <div class=\"cx-items-to-ship-label\">\n      {{ 'opfCheckout.itemsToBeShipped' | cxTranslate }}\n    </div>\n    <div class=\"cx-opf-review-card-wrapper\" *ngIf=\"isAddressCardVisible\">\n      <cx-opf-checkout-review-card\n        *ngIf=\"deliveryAddress$ | async as deliveryAddress\"\n        [cardContent$]=\"getDeliveryAddressCard(deliveryAddress)\"\n        [editConfig]=\"{\n          route: getCheckoutStepUrl(checkoutStepTypeDeliveryAddress),\n          ariaLabelKey: 'checkoutReview.editDeliveryAddressDetails',\n        }\"\n      />\n\n      <cx-opf-checkout-review-card\n        *ngIf=\"deliveryMode$ | async as deliveryMode\"\n        [cardContent$]=\"getDeliveryModeCard(deliveryMode)\"\n        [editConfig]=\"{\n          route: getCheckoutStepUrl(checkoutStepTypeDeliveryMode),\n          ariaLabelKey: 'checkoutReview.editDeliveryMode',\n        }\"\n      />\n    </div>\n\n    <ng-template\n      [cxOutlet]=\"cartOutlets.CART_ITEM_LIST\"\n      [cxOutletContext]=\"{\n        items: activeCartFacade.getDeliveryEntries() | async,\n        readonly: true,\n        promotionLocation: promotionLocation,\n      }\"\n    />\n  </ng-container>\n</div>\n" }]
        }], propDecorators: { cart: [{
                type: Input
            }], entries: [{
                type: Input
            }], isAddressCardVisible: [{
                type: Input
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutReviewCartDetailsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutReviewCartDetailsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutReviewCartDetailsModule, imports: [CommonModule,
            I18nModule,
            UrlModule,
            PromotionsModule,
            OutletModule,
            OpfCheckoutReviewCardModule,
            OpfCheckoutReviewCartDetailsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutReviewCartDetailsModule, imports: [CommonModule,
            I18nModule,
            UrlModule,
            PromotionsModule,
            OutletModule,
            OpfCheckoutReviewCardModule,
            OpfCheckoutReviewCartDetailsComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutReviewCartDetailsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        UrlModule,
                        PromotionsModule,
                        OutletModule,
                        OpfCheckoutReviewCardModule,
                        OpfCheckoutReviewCartDetailsComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutPaymentAndReviewComponent extends CheckoutReviewSubmitComponent {
    constructor() {
        super(...arguments);
        this.fb = inject(UntypedFormBuilder);
        this.opfMetadataStoreService = inject(OpfMetadataStoreService);
        this.cmsService = inject(CmsService);
        this.checkoutPaymentTypeFacade = inject(CheckoutPaymentTypeFacade);
        this.opfBaseFacade = inject(OpfBaseFacade);
        this.checkoutDeliveryModesFacade = inject(CheckoutDeliveryModesFacade);
        this.activeCartFacade = inject(ActiveCartFacade);
        this.opfCheckoutBillingAddressFormService = inject(OpfCheckoutBillingAddressFormService);
        this.defaultTermsAndConditionsFieldValue = false;
        this.selectedPaymentProviderName$ = new BehaviorSubject(undefined);
        this.opfCheckoutOutlets = OpfCheckoutOutlets;
        this.paymentOptionsDisabled$ = this.opfCheckoutBillingAddressFormService.paymentOptionsDisabled$;
        this.explicitTermsAndConditions$ = this.cmsService
            .getCurrentPage()
            .pipe(map$1((page) => {
            return this.isCmsComponentInPage(OPF_EXPLICIT_TERMS_AND_CONDITIONS_COMPONENT, page);
        }));
        this.checkoutSubmitForm = this.fb.group({
            termsAndConditions: [
                this.defaultTermsAndConditionsFieldValue,
                Validators.requiredTrue,
            ],
        });
        this.getSelectedPayment$ = this.opfBaseFacade.getActiveConfigurationsState();
        this.getSelectedPaymentId$ = this.opfMetadataStoreService
            .getOpfMetadataState()
            .pipe(take$1(1), map$1((data) => data?.selectedPaymentOptionId));
    }
    get termsAndConditionInvalid() {
        return this.checkoutSubmitForm.invalid;
    }
    get termsAndConditionsFieldValue() {
        return Boolean(this.checkoutSubmitForm.get('termsAndConditions')?.value);
    }
    isCmsComponentInPage(cmsComponentUid, page) {
        return !!page && JSON.stringify(page).includes(cmsComponentUid);
    }
    updateTermsAndConditionsState() {
        this.opfMetadataStoreService.updateOpfMetadata({
            termsAndConditionsChecked: this.termsAndConditionsFieldValue,
        });
    }
    toggleTermsAndConditions() {
        this.updateTermsAndConditionsState();
    }
    onPaymentProviderSelected(providerName) {
        this.selectedPaymentProviderName$.next(providerName);
    }
    setPickupDeliveryMode() {
        this.activeCartFacade
            .hasDeliveryItems()
            .pipe(take$1(1))
            .subscribe((hasDeliveryItems) => {
            if (!hasDeliveryItems) {
                this.checkoutDeliveryAddressFacade.clearCheckoutDeliveryAddress();
                this.checkoutDeliveryModesFacade.setDeliveryMode('pickup');
            }
        });
    }
    ngOnInit() {
        this.updateTermsAndConditionsState();
        this.setPickupDeliveryMode();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentAndReviewComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: OpfCheckoutPaymentAndReviewComponent, isStandalone: true, selector: "cx-opf-checkout-payment-and-review", usesInheritance: true, ngImport: i0, template: "<ng-container\n  *ngIf=\"{\n    value: explicitTermsAndConditions$ | async,\n  } as explicitTermsAndConditions\"\n>\n  <cx-opf-checkout-terms-and-conditions-alert\n    *ngIf=\"!explicitTermsAndConditions.value\"\n    [isVisible]=\"termsAndConditionInvalid\"\n    [isExplicit]=\"explicitTermsAndConditions.value\"\n    [isDismissible]=\"false\"\n    [ngClass]=\"['for-mobile']\"\n  />\n\n  <div\n    *ngIf=\"explicitTermsAndConditions.value\"\n    class=\"cx-opf-terms-and-conditions\"\n    [attr.aria-label]=\"'opfCheckout.termsAndConditions' | cxTranslate\"\n  >\n    <h3>{{ 'opfCheckout.termsAndConditions' | cxTranslate }}</h3>\n\n    <form\n      class=\"cx-place-order-form form-check\"\n      [formGroup]=\"checkoutSubmitForm\"\n    >\n      <div class=\"form-group\">\n        <label>\n          <input\n            formControlName=\"termsAndConditions\"\n            class=\"scaled-input form-check-input\"\n            type=\"checkbox\"\n            (change)=\"toggleTermsAndConditions()\"\n          />\n          <span class=\"form-check-label\">\n            {{ 'checkoutReview.confirmThatRead' | cxTranslate }}\n            <a\n              [routerLink]=\"{ cxRoute: 'termsAndConditions' } | cxUrl\"\n              class=\"cx-tc-link\"\n              target=\"_blank\"\n              rel=\"noopener noreferrer\"\n            >\n              {{ 'checkoutReview.termsAndConditions' | cxTranslate }}\n            </a>\n          </span>\n        </label>\n      </div>\n    </form>\n  </div>\n\n  <cx-opf-checkout-billing-address-form />\n\n  <cx-opf-checkout-payments\n    [elementsPerPage]=\"10\"\n    [explicitTermsAndConditions]=\"explicitTermsAndConditions.value\"\n    [disabled]=\"termsAndConditionInvalid\"\n  >\n    <cx-opf-checkout-terms-and-conditions-alert\n      *ngIf=\"!explicitTermsAndConditions.value\"\n      [isDismissible]=\"true\"\n      [isVisible]=\"termsAndConditionInvalid\"\n      [isExplicit]=\"explicitTermsAndConditions.value\"\n      [ngClass]=\"['for-desktop']\"\n    />\n    <ng-template\n      [cxOutlet]=\"opfCheckoutOutlets.OPF_CHECKOUT_BEFORE_SAVED_PAYMENT_OPTIONS\"\n      [cxOutletContext]=\"{ disabled: paymentOptionsDisabled$ }\"\n    />\n  </cx-opf-checkout-payments>\n\n  <cx-opf-checkout-review-cart-details\n    [cart]=\"cart$ | async\"\n    [entries]=\"entries$ | async\"\n    [isAddressCardVisible]=\"true\"\n  />\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: OpfCheckoutReviewCartDetailsModule }, { kind: "component", type: OpfCheckoutTermsAndConditionsAlertComponent, selector: "cx-opf-checkout-terms-and-conditions-alert", inputs: ["isDismissible", "isVisible", "isExplicit"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: OpfCheckoutBillingAddressFormComponent, selector: "cx-opf-checkout-billing-address-form" }, { kind: "component", type: OpfCheckoutPaymentsComponent, selector: "cx-opf-checkout-payments", inputs: ["isHeadingDisplayed", "headingTranslationKey", "isPaymentRenderBelow", "isPaymentInfoMessageEnabled", "elementsPerPage", "disabled", "explicitTermsAndConditions", "onlyPaymentWrapperMode", "showBeforePaymentOptionsOutlet", "customPaymentTemplate", "hideOnlyOnePaymentProviderLabel", "forceRadioInputsView", "forceDefaultPaymentOptionInputSelection", "renderPaymentWrapper", "noRenderPaymentWrapperMessage"], outputs: ["paymentChange", "selectedPaymentProviderName"] }, { kind: "component", type: OpfCheckoutReviewCartDetailsComponent, selector: "cx-opf-checkout-review-cart-details", inputs: ["cart", "entries", "isAddressCardVisible"] }, { kind: "ngmodule", type: OutletModule }, { kind: "directive", type: i1$1.OutletDirective, selector: "[cxOutlet]", inputs: ["cxOutlet", "cxOutletContext", "cxOutletDefer", "cxComponentRef"], outputs: ["loaded", "cxComponentRefChange"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentAndReviewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-opf-checkout-payment-and-review', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        OpfCheckoutReviewCartDetailsModule,
                        OpfCheckoutTermsAndConditionsAlertComponent,
                        NgClass,
                        FormsModule,
                        ReactiveFormsModule,
                        RouterLink,
                        OpfCheckoutBillingAddressFormComponent,
                        OpfCheckoutPaymentsComponent,
                        AsyncPipe,
                        TranslatePipe,
                        UrlPipe,
                        OpfCheckoutReviewCartDetailsComponent,
                        OutletModule,
                    ], template: "<ng-container\n  *ngIf=\"{\n    value: explicitTermsAndConditions$ | async,\n  } as explicitTermsAndConditions\"\n>\n  <cx-opf-checkout-terms-and-conditions-alert\n    *ngIf=\"!explicitTermsAndConditions.value\"\n    [isVisible]=\"termsAndConditionInvalid\"\n    [isExplicit]=\"explicitTermsAndConditions.value\"\n    [isDismissible]=\"false\"\n    [ngClass]=\"['for-mobile']\"\n  />\n\n  <div\n    *ngIf=\"explicitTermsAndConditions.value\"\n    class=\"cx-opf-terms-and-conditions\"\n    [attr.aria-label]=\"'opfCheckout.termsAndConditions' | cxTranslate\"\n  >\n    <h3>{{ 'opfCheckout.termsAndConditions' | cxTranslate }}</h3>\n\n    <form\n      class=\"cx-place-order-form form-check\"\n      [formGroup]=\"checkoutSubmitForm\"\n    >\n      <div class=\"form-group\">\n        <label>\n          <input\n            formControlName=\"termsAndConditions\"\n            class=\"scaled-input form-check-input\"\n            type=\"checkbox\"\n            (change)=\"toggleTermsAndConditions()\"\n          />\n          <span class=\"form-check-label\">\n            {{ 'checkoutReview.confirmThatRead' | cxTranslate }}\n            <a\n              [routerLink]=\"{ cxRoute: 'termsAndConditions' } | cxUrl\"\n              class=\"cx-tc-link\"\n              target=\"_blank\"\n              rel=\"noopener noreferrer\"\n            >\n              {{ 'checkoutReview.termsAndConditions' | cxTranslate }}\n            </a>\n          </span>\n        </label>\n      </div>\n    </form>\n  </div>\n\n  <cx-opf-checkout-billing-address-form />\n\n  <cx-opf-checkout-payments\n    [elementsPerPage]=\"10\"\n    [explicitTermsAndConditions]=\"explicitTermsAndConditions.value\"\n    [disabled]=\"termsAndConditionInvalid\"\n  >\n    <cx-opf-checkout-terms-and-conditions-alert\n      *ngIf=\"!explicitTermsAndConditions.value\"\n      [isDismissible]=\"true\"\n      [isVisible]=\"termsAndConditionInvalid\"\n      [isExplicit]=\"explicitTermsAndConditions.value\"\n      [ngClass]=\"['for-desktop']\"\n    />\n    <ng-template\n      [cxOutlet]=\"opfCheckoutOutlets.OPF_CHECKOUT_BEFORE_SAVED_PAYMENT_OPTIONS\"\n      [cxOutletContext]=\"{ disabled: paymentOptionsDisabled$ }\"\n    />\n  </cx-opf-checkout-payments>\n\n  <cx-opf-checkout-review-cart-details\n    [cart]=\"cart$ | async\"\n    [entries]=\"entries$ | async\"\n    [isAddressCardVisible]=\"true\"\n  />\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutPaymentAndReviewModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentAndReviewModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentAndReviewModule, imports: [CommonModule,
            I18nModule,
            OpfCheckoutPaymentsModule,
            UrlModule,
            ReactiveFormsModule,
            RouterModule,
            OpfCheckoutBillingAddressFormModule,
            AddressFormModule,
            OutletModule,
            PromotionsModule,
            IconModule,
            CardModule,
            OpfCheckoutTermsAndConditionsAlertModule,
            OpfCheckoutPaymentWrapperModule,
            OpfCheckoutReviewCardModule,
            OpfCheckoutReviewCartDetailsModule,
            OpfCheckoutPaymentAndReviewComponent], exports: [OpfCheckoutPaymentAndReviewComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentAndReviewModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    OpfCheckoutPaymentAndReview: {
                        component: OpfCheckoutPaymentAndReviewComponent,
                        guards: [CheckoutAuthGuard, CartNotEmptyGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            I18nModule,
            OpfCheckoutPaymentsModule,
            UrlModule,
            ReactiveFormsModule,
            RouterModule,
            OpfCheckoutBillingAddressFormModule,
            AddressFormModule,
            OutletModule,
            PromotionsModule,
            IconModule,
            CardModule,
            OpfCheckoutTermsAndConditionsAlertModule,
            OpfCheckoutPaymentWrapperModule,
            OpfCheckoutReviewCardModule,
            OpfCheckoutReviewCartDetailsModule,
            OpfCheckoutPaymentAndReviewComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutPaymentAndReviewModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        OpfCheckoutPaymentsModule,
                        UrlModule,
                        ReactiveFormsModule,
                        RouterModule,
                        OpfCheckoutBillingAddressFormModule,
                        AddressFormModule,
                        OutletModule,
                        PromotionsModule,
                        IconModule,
                        CardModule,
                        OpfCheckoutTermsAndConditionsAlertModule,
                        OpfCheckoutPaymentWrapperModule,
                        OpfCheckoutReviewCardModule,
                        OpfCheckoutReviewCartDetailsModule,
                        OpfCheckoutPaymentAndReviewComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                OpfCheckoutPaymentAndReview: {
                                    component: OpfCheckoutPaymentAndReviewComponent,
                                    guards: [CheckoutAuthGuard, CartNotEmptyGuard],
                                },
                            },
                        }),
                    ],
                    exports: [OpfCheckoutPaymentAndReviewComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfCheckoutComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutComponentsModule, imports: [OpfCheckoutPaymentAndReviewModule,
            OpfCheckoutPaymentsModule,
            OpfCheckoutBillingAddressFormModule,
            OpfCheckoutPaymentWrapperModule,
            OpfCheckoutReviewCardModule,
            OpfCheckoutEmailUpdateModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutComponentsModule, imports: [OpfCheckoutPaymentAndReviewModule,
            OpfCheckoutPaymentsModule,
            OpfCheckoutBillingAddressFormModule,
            OpfCheckoutPaymentWrapperModule,
            OpfCheckoutReviewCardModule,
            OpfCheckoutEmailUpdateModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfCheckoutComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        OpfCheckoutPaymentAndReviewModule,
                        OpfCheckoutPaymentsModule,
                        OpfCheckoutBillingAddressFormModule,
                        OpfCheckoutPaymentWrapperModule,
                        OpfCheckoutReviewCardModule,
                        OpfCheckoutEmailUpdateModule,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { GetAddressCardContent, OpfCheckoutBillingAddressFormComponent, OpfCheckoutBillingAddressFormModule, OpfCheckoutBillingAddressFormService, OpfCheckoutComponentsModule, OpfCheckoutEmailUpdateComponent, OpfCheckoutEmailUpdateModule, OpfCheckoutPaymentAndReviewComponent, OpfCheckoutPaymentAndReviewModule, OpfCheckoutPaymentWrapperComponent, OpfCheckoutPaymentWrapperModule, OpfCheckoutPaymentWrapperService, OpfCheckoutPaymentsComponent, OpfCheckoutPaymentsModule, OpfCheckoutReviewCardComponent, OpfCheckoutReviewCardModule, OpfCheckoutReviewCartDetailsComponent, OpfCheckoutReviewCartDetailsModule, OpfCheckoutTermsAndConditionsAlertComponent, OpfCheckoutTermsAndConditionsAlertModule };
//# sourceMappingURL=spartacus-opf-checkout-components.mjs.map
