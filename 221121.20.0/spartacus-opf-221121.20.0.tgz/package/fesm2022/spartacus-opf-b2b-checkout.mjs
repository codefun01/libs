import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { OpfB2bCheckoutCoreModule } from '@spartacus/opf/b2b-checkout/core';
import { OpfB2bCheckoutComponentsModule } from '@spartacus/opf/b2b-checkout/components';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfB2bCheckoutModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutModule, imports: [OpfB2bCheckoutCoreModule, OpfB2bCheckoutComponentsModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutModule, imports: [OpfB2bCheckoutCoreModule, OpfB2bCheckoutComponentsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfB2bCheckoutModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OpfB2bCheckoutCoreModule, OpfB2bCheckoutComponentsModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfB2bCheckoutModule };
//# sourceMappingURL=spartacus-opf-b2b-checkout.mjs.map
