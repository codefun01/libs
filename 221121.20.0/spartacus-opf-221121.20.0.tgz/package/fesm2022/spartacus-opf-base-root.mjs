import * as i0 from '@angular/core';
import { Injectable, inject, DOCUMENT, PLATFORM_ID, NgZone, NgModule, provideAppInitializer } from '@angular/core';
import { Config, GlobalMessageService, StatePersistenceService, LANGUAGE_CONTEXT_ID, ScriptLoader, WindowRef, LoggerService, EventService, LoginEvent, facadeFactory, provideDefaultConfig } from '@spartacus/core';
import { CreateCartEvent } from '@spartacus/cart/base/root';
import { OrderPlacedEvent } from '@spartacus/order/root';
import { timer, BehaviorSubject, Subscription, merge } from 'rxjs';
import { take, map } from 'rxjs/operators';
import { isPlatformServer } from '@angular/common';
import { LAUNCH_CALLER } from '@spartacus/storefront';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_CC_PUBLIC_KEY_HEADER = 'sap-commerce-cloud-public-key';
const OPF_CC_ACCESS_CODE_HEADER = 'sap-commerce-cloud-access-code';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOpfConfig = {
    opf: {
        opfBaseUrl: '',
        paymentOption: {
            enableInfoMessage: true,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfApiConfig extends Config {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiConfig, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiConfig, providedIn: 'root', useExisting: Config }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useExisting: Config,
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfConfig {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfConfig, providedIn: 'root', useExisting: Config }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useExisting: Config,
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfGlobalMessageService extends GlobalMessageService {
    constructor() {
        super(...arguments);
        this.isGlobalMessageDisabled = false;
        this.disabledKeys = [];
        this.defaultTimeout = 2000;
    }
    /**
     * Add one message into store
     * @param text: string | Translatable
     * @param type: GlobalMessageType object
     * @param timeout: number
     */
    add(text, type, timeout) {
        if (this.isGlobalMessageDisabled &&
            this.disabledKeys?.length &&
            text?.key &&
            this.disabledKeys.includes(text.key)) {
            return;
        }
        super.add(text, type, timeout);
    }
    /**
     * disable specific keys for a period of time
     * @param keys: string[]
     * @param timeout: number
     */
    disableGlobalMessage(keys, timeout) {
        this.isGlobalMessageDisabled = true;
        this.disabledKeys = keys;
        timer(timeout ?? this.defaultTimeout)
            .pipe(take(1))
            .subscribe(() => {
            this.isGlobalMessageDisabled = false;
            this.disabledKeys = [];
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGlobalMessageService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGlobalMessageService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfGlobalMessageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfMetadataStoreService {
    constructor() {
        this.INITIAL_STATE = Object.freeze({
            termsAndConditionsChecked: false,
            selectedPaymentOptionId: undefined,
            isPaymentInProgress: false,
            opfPaymentSessionId: undefined,
            isTermsAndConditionsAlertClosed: false,
            is3DSRedirect: false,
            opf3DSRedirectReturnPath: undefined,
        });
        this.opfMetadataState = new BehaviorSubject(this.INITIAL_STATE);
    }
    getOpfMetadataState() {
        return this.opfMetadataState.asObservable();
    }
    updateOpfMetadata(payload) {
        this.opfMetadataState.next({
            ...this.opfMetadataState.value,
            ...payload,
        });
    }
    clearOpfMetadata() {
        this.opfMetadataState.next(this.INITIAL_STATE);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfMetadataStoreService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfMetadataStoreService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfMetadataStoreService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Responsible for storing OPF state in the browser storage.
 * Uses `StatePersistenceService` mechanism.
 */
class OpfMetadataStatePersistanceService {
    constructor() {
        this.statePersistenceService = inject(StatePersistenceService);
        this.opfMetadataStoreService = inject(OpfMetadataStoreService);
        this.subscription = new Subscription();
        /**
         * Identifier used for storage key.
         */
        this.key = 'opf';
    }
    /**
     * Initializes the synchronization between state and browser storage.
     */
    initSync() {
        this.subscription.add(this.statePersistenceService.syncWithStorage({
            key: this.key,
            state$: this.getOpfState(),
            onRead: (state) => this.onRead(state),
        }));
    }
    /**
     * Gets an active content language from the browser local storage.
     */
    getActiveLanguage() {
        return this.statePersistenceService.readStateFromStorage({
            key: LANGUAGE_CONTEXT_ID,
        });
    }
    /**
     * Gets and transforms state from different sources into the form that should
     * be saved in storage.
     */
    getOpfState() {
        return this.opfMetadataStoreService.getOpfMetadataState().pipe(map((metadata) => {
            return {
                metadata,
            };
        }));
    }
    /**
     * Function called on each browser storage read.
     * Used to update state from browser -> state.
     */
    onRead(state) {
        if (state && state.metadata) {
            this.opfMetadataStoreService.updateOpfMetadata(state.metadata);
        }
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfMetadataStatePersistanceService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfMetadataStatePersistanceService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfMetadataStatePersistanceService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
LAUNCH_CALLER['OPF_ERROR'] = 'OPF_ERROR';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var OpfHtmlContentMode;
(function (OpfHtmlContentMode) {
    OpfHtmlContentMode["SEPARATE"] = "SEPARATE";
    OpfHtmlContentMode["MIXED"] = "MIXED";
})(OpfHtmlContentMode || (OpfHtmlContentMode = {}));
var OpfPage;
(function (OpfPage) {
    OpfPage["CHECKOUT_REVIEW_PAGE"] = "opfCheckoutPaymentAndReview";
    OpfPage["CONFIRMATION_PAGE"] = "orderConfirmation";
    OpfPage["RESULT_PAGE"] = "paymentVerificationResult";
    OpfPage["CANCEL_PAGE"] = "paymentVerificationCancel";
    OpfPage["CART_PAGE"] = "cart";
})(OpfPage || (OpfPage = {}));
var OpfDynamicScriptResourceType;
(function (OpfDynamicScriptResourceType) {
    OpfDynamicScriptResourceType["SCRIPT"] = "SCRIPT";
    OpfDynamicScriptResourceType["STYLES"] = "STYLES";
})(OpfDynamicScriptResourceType || (OpfDynamicScriptResourceType = {}));
var OpfPaymentProviderType;
(function (OpfPaymentProviderType) {
    OpfPaymentProviderType["PAYMENT_GATEWAY"] = "PAYMENT_GATEWAY";
    OpfPaymentProviderType["PAYMENT_METHOD"] = "PAYMENT_METHOD";
    OpfPaymentProviderType["STORED_VALUE_PAYMENT"] = "STORED_VALUE_PAYMENT";
})(OpfPaymentProviderType || (OpfPaymentProviderType = {}));

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOpfErrorDialogOptions = {
    messageKey: 'opfPayment.errors.proceedPayment',
    confirmKey: 'common.continue',
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfResourceLoaderService {
    constructor() {
        this.scriptLoader = inject(ScriptLoader);
        this.document = inject(DOCUMENT);
        this.platformId = inject(PLATFORM_ID);
        this.config = inject(Config);
        this.windowRef = inject(WindowRef);
        this.ngZone = inject(NgZone);
        this.logger = inject(LoggerService);
        this.CORS_DEFAULT_VALUE = 'anonymous';
        this.OPF_RESOURCE_LOAD_ONCE_ATTRIBUTE_KEY = 'opf-load-once';
        this.OPF_RESOURCE_ATTRIBUTE_KEY = 'data-opf-resource';
    }
    embedStyles(embedOptions) {
        const { attributes, src, sri, callback, errorCallback } = embedOptions;
        const link = this.document.createElement('link');
        link.href = src;
        link.rel = 'stylesheet';
        link.type = 'text/css';
        if (sri) {
            link.integrity = sri;
            link.crossOrigin = attributes?.['crossorigin'] ?? this.CORS_DEFAULT_VALUE;
            delete attributes?.['crossorigin'];
        }
        attributes &&
            Object.keys(attributes)?.forEach((key) => {
                if (!(key in link)) {
                    link.setAttribute(key, attributes[key]);
                }
            });
        if (callback) {
            link.addEventListener('load', callback);
        }
        if (errorCallback) {
            link.addEventListener('error', errorCallback);
        }
        this.document.head.appendChild(link);
    }
    hasStyles(src) {
        return !!this.document.querySelector(`link[href="${src}"]`);
    }
    hasScript(src) {
        return this.scriptLoader.hasScript(src);
    }
    /**
     * Create attributes intended to script and link elements.
     *
     * Return attributes list including keyValueList and OPF specific attribute with below logic:
     *
     * 1. Resource loads only once: 'opf-load-once' key detected, no additional attribute added.
     * 2. Resource deleted at page/payment change: 'data-opf-resource' attribute is added.
     */
    createAttributesList(keyValueList) {
        const attributes = {};
        keyValueList?.forEach((keyValue) => {
            attributes[keyValue.key] = keyValue.value;
        });
        if (!attributes?.[this.OPF_RESOURCE_LOAD_ONCE_ATTRIBUTE_KEY] ||
            attributes[this.OPF_RESOURCE_LOAD_ONCE_ATTRIBUTE_KEY] !== 'true') {
            attributes[this.OPF_RESOURCE_ATTRIBUTE_KEY] = 'true';
        }
        delete attributes?.[this.OPF_RESOURCE_LOAD_ONCE_ATTRIBUTE_KEY];
        return attributes;
    }
    /**
     * Loads a script specified in the resource object.
     *
     * The returned Promise is resolved when the script is loaded or already present.
     * The returned Promise is rejected when a loading error occurs.
     */
    loadScript(resource) {
        return new Promise((resolve, reject) => {
            const attributes = {
                type: 'text/javascript',
                ...this.createAttributesList(resource.attributes),
            };
            if (resource?.sri) {
                attributes['integrity'] = resource.sri;
                attributes['crossOrigin'] =
                    attributes?.['crossorigin'] ?? this.CORS_DEFAULT_VALUE;
                delete attributes?.['crossorigin'];
            }
            if (resource?.url && !this.hasScript(resource.url)) {
                this.scriptLoader.embedScript({
                    attributes,
                    src: resource.url,
                    callback: () => resolve(),
                    errorCallback: () => reject(),
                    disableKeyRestriction: true,
                });
            }
            else {
                resolve();
            }
        });
    }
    /**
     * Loads a stylesheet specified in the resource object.
     *
     * The returned Promise is resolved when the stylesheet is loaded or already present.
     * The returned Promise is rejected when a loading error occurs.
     */
    loadStyles(resource) {
        return new Promise((resolve, reject) => {
            if (resource.url && !this.hasStyles(resource.url)) {
                this.embedStyles({
                    attributes: this.createAttributesList(resource?.attributes),
                    src: resource.url,
                    sri: resource?.sri,
                    callback: () => resolve(),
                    errorCallback: () => reject(),
                });
            }
            else {
                resolve();
            }
        });
    }
    executeScriptFromHtml(html) {
        // SSR mode not supported for security concerns
        if (!isPlatformServer(this.platformId) && html) {
            const element = new DOMParser().parseFromString(html, 'text/html');
            const script = element.getElementsByTagName('script');
            if (!script?.[0]?.innerText) {
                return;
            }
            Function(script[0].innerText)();
        }
    }
    clearAllResources() {
        this.document
            .querySelectorAll(`[${this.OPF_RESOURCE_ATTRIBUTE_KEY}]`)
            .forEach((resource) => {
            if (resource) {
                resource.remove();
            }
        });
    }
    /**
     * Parses jsContext JSON string and nested JSON strings (e.g., responseBody)
     * Returns empty object if parsing fails to allow graceful degradation
     */
    parseContext(jsContext) {
        if (!jsContext) {
            return {};
        }
        try {
            const parsed = JSON.parse(jsContext);
            if (parsed.responseBody && typeof parsed.responseBody === 'string') {
                try {
                    parsed.responseBody = JSON.parse(parsed.responseBody);
                }
                catch (error) {
                    this.logger.warn('Failed to parse nested responseBody as JSON, keeping as string:', error);
                }
            }
            return parsed;
        }
        catch (error) {
            this.logger.warn('Failed to parse jsContext as JSON, using empty object:', error);
            return {};
        }
    }
    /**
     * Execute script with context passed via global variable (no wrapping)
     * This allows using the original script hash from jsHash without modification
     * Context is set in window.OpfContext before script execution
     */
    executeScriptWithContext(originalScript, contextData) {
        // Run outside Angular zone since script execution doesn't need change detection
        this.ngZone.runOutsideAngular(() => {
            if (this.windowRef.isBrowser() && this.windowRef.nativeWindow) {
                const nativeWindow = this.windowRef.nativeWindow;
                if (nativeWindow.OpfContext) {
                    delete nativeWindow.OpfContext;
                }
                nativeWindow.OpfContext = contextData ?? {};
                nativeWindow.OpfContext.additionalData ??= {};
            }
            const scriptElement = this.document.createElement('script');
            scriptElement.type = 'text/javascript';
            scriptElement.textContent = originalScript;
            scriptElement.setAttribute('data-opf-script', 'true');
            this.document.head.appendChild(scriptElement);
            // Clean up after execution
            setTimeout(() => {
                if (scriptElement.parentNode) {
                    scriptElement.parentNode.removeChild(scriptElement);
                }
            }, 100);
        });
    }
    /**
     * Checks if local PSP resources are available from the storefront configuration
     */
    hasLocalPspResources(paymentOptionId) {
        if (!paymentOptionId) {
            return false;
        }
        const localPspResources = this.config.opf?.localPspResources;
        return localPspResources ? paymentOptionId in localPspResources : false;
    }
    /**
     * Extracts script content and context from dynamic script if in SEPARATE mode
     */
    extractDynamicScriptContext(dynamicScript) {
        if (dynamicScript?.htmlContentMode === OpfHtmlContentMode.SEPARATE &&
            dynamicScript.jsContent) {
            return {
                originalScript: dynamicScript.jsContent,
                contextData: this.parseContext(dynamicScript.jsContext),
            };
        }
        return {};
    }
    /**
     * Adds CSS from dynamic script to styles array if in SEPARATE mode
     */
    addDynamicScriptCss(dynamicScript, styles = []) {
        if (dynamicScript?.htmlContentMode === OpfHtmlContentMode.SEPARATE &&
            dynamicScript.cssUrl &&
            dynamicScript.cssHash) {
            styles.push({
                url: dynamicScript.cssUrl,
                sri: dynamicScript.cssHash,
                type: OpfDynamicScriptResourceType.STYLES,
            });
        }
    }
    /**
     * Gets local PSP resources if available for the given payment option ID
     */
    getLocalResources(paymentOptionId) {
        if (!paymentOptionId || !this.hasLocalPspResources(paymentOptionId)) {
            return [];
        }
        const localPspResources = this.config.opf?.localPspResources;
        const localResources = localPspResources?.[paymentOptionId];
        if (!localResources) {
            return [];
        }
        const localScripts = localResources.jsFiles.map((url) => ({
            url,
            type: OpfDynamicScriptResourceType.SCRIPT,
        }));
        const localStyles = localResources.cssFiles.map((url) => ({
            url,
            type: OpfDynamicScriptResourceType.STYLES,
        }));
        return [...localScripts, ...localStyles];
    }
    /**
     * Converts external scripts and styles to resource format
     */
    getExternalResources(scripts = [], styles = []) {
        return [
            ...scripts.map((script) => ({
                ...script,
                type: OpfDynamicScriptResourceType.SCRIPT,
            })),
            ...styles.map((style) => ({
                ...style,
                type: OpfDynamicScriptResourceType.STYLES,
            })),
        ];
    }
    /**
     * Loads a single resource based on its type
     */
    loadResource(resource) {
        if (!resource.url) {
            return Promise.resolve();
        }
        switch (resource.type) {
            case OpfDynamicScriptResourceType.SCRIPT:
                return this.loadScript(resource);
            case OpfDynamicScriptResourceType.STYLES:
                return this.loadStyles(resource);
            default:
                return Promise.resolve();
        }
    }
    /**
     * Loads scripts and stylesheets specified in the lists of resource objects (scripts and styles).
     * The method automatically selects local or external resources based on the presence of localPspResources
     * in the storefront configuration.
     * If localPspResources are present, the method uses local resources.
     * If localPspResources are not present, the method uses external resources.
     *
     * When htmlContentMode is SEPARATE, the method uses jsContent/jsHash and cssUrl/cssHash properties
     * to load resources with specific URLs and SRI hashes.
     *
     * The returned Promise is resolved when all resources are loaded.
     * The returned Promise is also resolved (not rejected!) immediately when any loading error occurs.
     */
    loadResources(scripts = [], styles = [], paymentOptionId, dynamicScript) {
        // SSR mode not supported for security concerns
        if (isPlatformServer(this.platformId)) {
            return Promise.resolve();
        }
        const { originalScript, contextData } = this.extractDynamicScriptContext(dynamicScript);
        this.addDynamicScriptCss(dynamicScript, styles);
        const localResources = this.getLocalResources(paymentOptionId);
        const resources = localResources.length > 0
            ? localResources
            : this.getExternalResources(scripts, styles);
        if (!resources.length) {
            if (originalScript) {
                this.executeScriptWithContext(originalScript, contextData);
            }
            return Promise.resolve();
        }
        const resourcesPromises = resources.map((resource) => this.loadResource(resource));
        return Promise.all(resourcesPromises).then(() => {
            if (originalScript) {
                setTimeout(() => {
                    this.executeScriptWithContext(originalScript, contextData);
                });
            }
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfResourceLoaderService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfResourceLoaderService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfResourceLoaderService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfEventListenerService {
    constructor() {
        this.eventService = inject(EventService);
        this.opfMetadataStoreService = inject(OpfMetadataStoreService);
        this.subscriptions = new Subscription();
        this.onOpfPaymentMetadataResetConditionsMet();
    }
    onOpfPaymentMetadataResetConditionsMet() {
        this.subscriptions.add(merge(this.eventService.get(LoginEvent), this.eventService.get(OrderPlacedEvent), this.eventService.get(CreateCartEvent)).subscribe(() => this.opfMetadataStoreService.clearOpfMetadata()));
    }
    ngOnDestroy() {
        this.subscriptions.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfEventListenerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfEventListenerService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfEventListenerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const OPF_BASE_FEATURE = 'opfBase';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfBaseFacade {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfBaseFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfBaseFacade, providedIn: 'root', useFactory: () => facadeFactory({
            facade: OpfBaseFacade,
            feature: OPF_BASE_FEATURE,
            methods: ['getActiveConfigurationsState'],
        }) }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfBaseFacade, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useFactory: () => facadeFactory({
                        facade: OpfBaseFacade,
                        feature: OPF_BASE_FEATURE,
                        methods: ['getActiveConfigurationsState'],
                    }),
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfEventModule {
    constructor(_opfEventListenerService) {
        // Intentional empty constructor
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfEventModule, deps: [{ token: OpfEventListenerService }], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfEventModule }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfEventModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfEventModule, decorators: [{
            type: NgModule,
            args: [{}]
        }], ctorParameters: () => [{ type: OpfEventListenerService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfBaseRootModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfBaseRootModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfBaseRootModule, imports: [OpfEventModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfBaseRootModule, providers: [
            provideAppInitializer(() => {
                const opfStatePersistenceService = inject(OpfMetadataStatePersistanceService);
                opfStatePersistenceService.initSync();
            }),
            {
                provide: GlobalMessageService,
                useExisting: OpfGlobalMessageService,
            },
            provideDefaultConfig(defaultOpfConfig),
        ], imports: [OpfEventModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfBaseRootModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OpfEventModule],
                    providers: [
                        provideAppInitializer(() => {
                            const opfStatePersistenceService = inject(OpfMetadataStatePersistanceService);
                            opfStatePersistenceService.initSync();
                        }),
                        {
                            provide: GlobalMessageService,
                            useExisting: OpfGlobalMessageService,
                        },
                        provideDefaultConfig(defaultOpfConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OPF_BASE_FEATURE, OPF_CC_ACCESS_CODE_HEADER, OPF_CC_PUBLIC_KEY_HEADER, OpfApiConfig, OpfBaseFacade, OpfBaseRootModule, OpfConfig, OpfDynamicScriptResourceType, OpfEventListenerService, OpfGlobalMessageService, OpfHtmlContentMode, OpfMetadataStatePersistanceService, OpfMetadataStoreService, OpfPage, OpfPaymentProviderType, OpfResourceLoaderService, defaultOpfConfig, defaultOpfErrorDialogOptions };
//# sourceMappingURL=spartacus-opf-base-root.mjs.map
