import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { ConverterService, LoggerService, tryNormalizeHttpError, backOff, isServerError, provideDefaultConfig } from '@spartacus/core';
import { OPF_PAYMENT_VERIFICATION_NORMALIZER, OPF_PAYMENT_SUBMIT_NORMALIZER, OPF_PAYMENT_SUBMIT_COMPLETE_NORMALIZER, OPF_AFTER_REDIRECT_SCRIPTS_NORMALIZER, OPF_PAYMENT_CONFIG_SERIALIZER, OpfPaymentAdapter } from '@spartacus/opf/payment/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { OpfEndpointsService } from '@spartacus/opf/base/core';
import { OpfConfig, OpfMetadataStatePersistanceService, OPF_CC_PUBLIC_KEY_HEADER, OPF_CC_ACCESS_CODE_HEADER } from '@spartacus/opf/base/root';
import { catchError } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfApiPaymentAdapter {
    constructor() {
        this.http = inject(HttpClient);
        this.converter = inject(ConverterService);
        this.opfEndpointsService = inject(OpfEndpointsService);
        this.config = inject(OpfConfig);
        this.opfMetadataStatePersistanceService = inject(OpfMetadataStatePersistanceService);
        this.logger = inject(LoggerService);
    }
    get headerWithNoLanguage() {
        return {
            accept: 'application/json',
            'Content-Type': 'application/json',
        };
    }
    get header() {
        return {
            ...this.headerWithNoLanguage,
            'Accept-Language': this.opfMetadataStatePersistanceService.getActiveLanguage(),
        };
    }
    get headerWithContentLanguage() {
        return {
            ...this.headerWithNoLanguage,
            'Content-Language': this.opfMetadataStatePersistanceService.getActiveLanguage(),
        };
    }
    verifyPayment(paymentSessionId, payload) {
        const headers = new HttpHeaders(this.headerWithNoLanguage).set(OPF_CC_PUBLIC_KEY_HEADER, this.config.opf?.commerceCloudPublicKey || '');
        return this.http
            .post(this.verifyPaymentEndpoint(paymentSessionId), JSON.stringify(payload), {
            headers,
        })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({
            shouldRetry: isServerError,
            maxTries: 2,
        }), this.converter.pipeable(OPF_PAYMENT_VERIFICATION_NORMALIZER));
    }
    submitPayment(submitRequest, otpKey, paymentSessionId) {
        const headers = new HttpHeaders(this.header)
            .set(OPF_CC_PUBLIC_KEY_HEADER, this.config.opf?.commerceCloudPublicKey || '')
            .set(OPF_CC_ACCESS_CODE_HEADER, otpKey || '');
        const url = this.getSubmitPaymentEndpoint(paymentSessionId);
        return this.http
            .post(url, submitRequest, { headers })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({
            shouldRetry: isServerError,
            maxTries: 2,
        }), this.converter.pipeable(OPF_PAYMENT_SUBMIT_NORMALIZER));
    }
    submitCompletePayment(submitCompleteRequest, otpKey, paymentSessionId) {
        const headers = new HttpHeaders(this.headerWithContentLanguage)
            .set(OPF_CC_PUBLIC_KEY_HEADER, this.config.opf?.commerceCloudPublicKey || '')
            .set(OPF_CC_ACCESS_CODE_HEADER, otpKey || '');
        const url = this.getSubmitCompletePaymentEndpoint(paymentSessionId);
        return this.http
            .post(url, submitCompleteRequest, {
            headers,
        })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({
            shouldRetry: isServerError,
            maxTries: 2,
        }), this.converter.pipeable(OPF_PAYMENT_SUBMIT_COMPLETE_NORMALIZER));
    }
    getAfterRedirectScripts(paymentSessionId) {
        const headers = new HttpHeaders(this.header).set(OPF_CC_PUBLIC_KEY_HEADER, this.config.opf?.commerceCloudPublicKey || '');
        const url = this.getAfterRedirectScriptsEndpoint(paymentSessionId);
        return this.http
            .get(url, { headers })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({
            shouldRetry: isServerError,
            maxTries: 2,
        }), this.converter.pipeable(OPF_AFTER_REDIRECT_SCRIPTS_NORMALIZER));
    }
    initiatePayment(paymentConfig) {
        const headers = new HttpHeaders({
            'Accept-Language': this.opfMetadataStatePersistanceService.getActiveLanguage(),
        })
            .set(OPF_CC_PUBLIC_KEY_HEADER, this.config.opf?.commerceCloudPublicKey || '')
            .set(OPF_CC_ACCESS_CODE_HEADER, paymentConfig?.otpKey || '');
        const url = this.getInitiatePaymentEndpoint();
        paymentConfig = this.converter.convert(paymentConfig, OPF_PAYMENT_CONFIG_SERIALIZER);
        return this.http
            .post(url, paymentConfig?.config, { headers })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    updatePaymentTransaction(updatePaymentConfig) {
        const headers = new HttpHeaders({
            'Accept-Language': this.opfMetadataStatePersistanceService.getActiveLanguage(),
        })
            .set(OPF_CC_PUBLIC_KEY_HEADER, this.config.opf?.commerceCloudPublicKey || '')
            .set(OPF_CC_ACCESS_CODE_HEADER, updatePaymentConfig?.otpKey || '');
        const url = this.getUpdatePaymentTransactionEndpoint(updatePaymentConfig.paymentSessionId);
        updatePaymentConfig = this.converter.convert(updatePaymentConfig, OPF_PAYMENT_CONFIG_SERIALIZER);
        return this.http
            .put(url, updatePaymentConfig?.config, {
            headers,
        })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }));
    }
    verifyPaymentEndpoint(paymentSessionId) {
        return this.opfEndpointsService.buildUrl('verifyPayment', {
            urlParams: { paymentSessionId },
        });
    }
    getSubmitPaymentEndpoint(paymentSessionId) {
        return this.opfEndpointsService
            .buildUrl('submitPayment', {
            urlParams: { paymentSessionId },
        })
            .replace('//submit', '/submit');
    }
    getSubmitCompletePaymentEndpoint(paymentSessionId) {
        return this.opfEndpointsService.buildUrl('submitCompletePayment', {
            urlParams: { paymentSessionId },
        });
    }
    getAfterRedirectScriptsEndpoint(paymentSessionId) {
        return this.opfEndpointsService.buildUrl('getAfterRedirectScripts', {
            urlParams: { paymentSessionId },
        });
    }
    getInitiatePaymentEndpoint() {
        return this.opfEndpointsService.buildUrl('initiatePayment');
    }
    getUpdatePaymentTransactionEndpoint(paymentSessionId) {
        return this.opfEndpointsService.buildUrl('updatePaymentTransaction', {
            urlParams: { paymentSessionId },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiPaymentAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiPaymentAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiPaymentAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOpfApiPaymentConfig = {
    backend: {
        opfApi: {
            endpoints: {
                verifyPayment: 'payments/${paymentSessionId}/verify',
                submitPayment: 'payments/${paymentSessionId}/submit',
                submitCompletePayment: 'payments/${paymentSessionId}/submit-complete',
                getAfterRedirectScripts: 'payments/${paymentSessionId}/after-redirect-scripts',
                initiatePayment: 'payments',
                updatePaymentTransaction: 'payments/${paymentSessionId}',
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfApiPaymentModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiPaymentModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfApiPaymentModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiPaymentModule, providers: [
            provideDefaultConfig(defaultOpfApiPaymentConfig),
            {
                provide: OpfPaymentAdapter,
                useClass: OpfApiPaymentAdapter,
            },
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiPaymentModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [
                        provideDefaultConfig(defaultOpfApiPaymentConfig),
                        {
                            provide: OpfPaymentAdapter,
                            useClass: OpfApiPaymentAdapter,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfApiPaymentModule };
//# sourceMappingURL=spartacus-opf-payment-opf-api.mjs.map
