import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { inject, Injectable, NgModule } from '@angular/core';
import { ConverterService, LoggerService, tryNormalizeHttpError, backOff, isServerError, provideDefaultConfig } from '@spartacus/core';
import { OPF_APPLE_PAY_WEB_SESSION_NORMALIZER, OpfQuickBuyAdapter } from '@spartacus/opf/quick-buy/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { OpfEndpointsService } from '@spartacus/opf/base/core';
import { OpfConfig, OpfMetadataStatePersistanceService, OPF_CC_PUBLIC_KEY_HEADER, OPF_CC_ACCESS_CODE_HEADER } from '@spartacus/opf/base/root';
import { catchError } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfApiQuickBuyAdapter {
    constructor() {
        this.http = inject(HttpClient);
        this.converter = inject(ConverterService);
        this.opfEndpointsService = inject(OpfEndpointsService);
        this.config = inject(OpfConfig);
        this.opfMetadataStatePersistanceService = inject(OpfMetadataStatePersistanceService);
        this.logger = inject(LoggerService);
        this.headerWithNoLanguage = {
            accept: 'application/json',
            'Content-Type': 'application/json',
        };
        this.headerWithContentLanguage = {
            ...this.headerWithNoLanguage,
            'Content-Language': this.opfMetadataStatePersistanceService.getActiveLanguage(),
        };
    }
    getApplePayWebSession(applePayWebSessionRequest, accessCode) {
        const headers = new HttpHeaders(this.headerWithContentLanguage)
            .set(OPF_CC_PUBLIC_KEY_HEADER, this.config.opf?.commerceCloudPublicKey || '')
            .set(OPF_CC_ACCESS_CODE_HEADER, accessCode || '');
        const url = this.getApplePayWebSessionEndpoint();
        return this.http
            .post(url, applePayWebSessionRequest, { headers })
            .pipe(catchError((error) => {
            throw tryNormalizeHttpError(error, this.logger);
        }), backOff({
            shouldRetry: isServerError,
            maxTries: 2,
        }), this.converter.pipeable(OPF_APPLE_PAY_WEB_SESSION_NORMALIZER));
    }
    getApplePayWebSessionEndpoint() {
        return this.opfEndpointsService.buildUrl('getApplePayWebSession');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiQuickBuyAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiQuickBuyAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiQuickBuyAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultOpfApiQuickBuyConfig = {
    backend: {
        opfApi: {
            endpoints: {
                getApplePayWebSession: 'payments/apple-pay-web-sessions',
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfApiQuickBuyModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiQuickBuyModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfApiQuickBuyModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiQuickBuyModule, providers: [
            provideDefaultConfig(defaultOpfApiQuickBuyConfig),
            {
                provide: OpfQuickBuyAdapter,
                useClass: OpfApiQuickBuyAdapter,
            },
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfApiQuickBuyModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [
                        provideDefaultConfig(defaultOpfApiQuickBuyConfig),
                        {
                            provide: OpfQuickBuyAdapter,
                            useClass: OpfApiQuickBuyAdapter,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfApiQuickBuyModule };
//# sourceMappingURL=spartacus-opf-quick-buy-opf-api.mjs.map
