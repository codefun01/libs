import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { OpfBaseComponentsModule } from '@spartacus/opf/base/components';
import { OpfBaseCoreModule } from '@spartacus/opf/base/core';
import { OpfApiBaseModule } from '@spartacus/opf/base/opf-api';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfBaseModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfBaseModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfBaseModule, imports: [OpfApiBaseModule, OpfBaseCoreModule, OpfBaseComponentsModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfBaseModule, imports: [OpfApiBaseModule, OpfBaseCoreModule, OpfBaseComponentsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfBaseModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OpfApiBaseModule, OpfBaseCoreModule, OpfBaseComponentsModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfBaseModule };
//# sourceMappingURL=spartacus-opf-base.mjs.map
