import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { OpfPaymentCoreModule } from '@spartacus/opf/payment/core';
import { OpfApiPaymentModule } from '@spartacus/opf/payment/opf-api';
import { OpfPaymentOccModule } from '@spartacus/opf/payment/occ';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OpfPaymentModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfPaymentModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: OpfPaymentModule, imports: [OpfPaymentCoreModule, OpfApiPaymentModule, OpfPaymentOccModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfPaymentModule, imports: [OpfPaymentCoreModule, OpfApiPaymentModule, OpfPaymentOccModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OpfPaymentModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OpfPaymentCoreModule, OpfApiPaymentModule, OpfPaymentOccModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { OpfPaymentModule };
//# sourceMappingURL=spartacus-opf-payment.mjs.map
