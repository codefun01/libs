import { Cart } from '@spartacus/cart/base/root';
import { PointOfService, Product, CmsConfig } from '@spartacus/core';
import * as i0 from '@angular/core';
import { Observable } from 'rxjs';

interface OpfQuickBuyDigitalWallet {
    description?: string;
    provider?: OpfQuickBuyProviderType;
    enabled?: boolean;
    merchantId?: string;
    merchantName?: string;
    countryCode?: string;
    googlePayGateway?: string;
}
interface OpfQuickBuyDeliveryInfo {
    type: OpfQuickBuyDeliveryType;
    pickupDetails?: PointOfService;
}
interface OpfQuickBuySingleProductCartOptions {
    quantity: number;
    pickupStore?: string;
}
interface QuickBuyTransactionDetails {
    context?: OpfQuickBuyLocation;
    cart?: Cart;
    product?: Product;
    quantity?: number;
    deliveryInfo?: OpfQuickBuyDeliveryInfo;
    addressIds: string[];
    total: {
        amount: string;
        label: string;
        currency: string;
    };
}
declare enum OpfQuickBuyLocation {
    CART = "CART",
    PRODUCT = "PRODUCT"
}
declare enum OpfQuickBuyDeliveryType {
    SHIPPING = "SHIPPING",
    PICKUP = "PICKUP"
}
declare enum OpfQuickBuyProviderType {
    APPLE_PAY = "APPLE_PAY",
    GOOGLE_PAY = "GOOGLE_PAY"
}
declare const OPF_GOOGLE_PAY_PROVIDER_NAME = "googlePay";
type OpfGooglePayPaymentRequestConfig = Pick<google.payments.api.PaymentDataRequest, 'apiVersion' | 'apiVersionMinor' | 'merchantInfo' | 'emailRequired' | 'shippingAddressRequired' | 'shippingOptionRequired' | 'shippingAddressParameters' | 'callbackIntents'>;
type OpfGooglePayCardParametersConfig = Pick<google.payments.api.CardParameters, 'allowedAuthMethods' | 'allowedCardNetworks' | 'billingAddressRequired' | 'billingAddressParameters'>;
interface OpfQuickBuyGooglePayProvider {
    resourceUrl?: string;
    environment?: google.payments.api.Environment;
    paymentRequest?: OpfGooglePayPaymentRequestConfig;
    cardParameters?: OpfGooglePayCardParametersConfig;
}
type OpfApplePayCardParametersConfig = Pick<ApplePayJS.ApplePayPaymentRequest, 'merchantCapabilities' | 'supportedNetworks' | 'requiredShippingContactFields' | 'requiredBillingContactFields' | 'shippingMethods'>;
interface OpfQuickBuyApplePayProvider {
    resourceUrl: string;
    cardParameters: OpfApplePayCardParametersConfig;
}

declare module '@spartacus/opf/base/root' {
    interface OpfActiveConfiguration {
        digitalWalletQuickBuy?: OpfQuickBuyDigitalWallet[];
    }
}

declare const OPF_QUICK_BUY_DEFAULT_MERCHANT_NAME: string;
declare const OPF_QUICK_BUY_ADDRESS_FIELD_PLACEHOLDER = "[FIELD_NOT_SET]";

interface ApplePaySessionVerificationRequest {
    /** @deprecated Property no longer used. Cart ID is currently derived from the OTP access code header. */
    cartId?: string;
    validationUrl: string;
    initiative: 'web';
    initiativeContext: string;
}
interface ApplePaySessionVerificationResponse {
    epochTimestamp: number;
    expiresAt: number;
    merchantSessionIdentifier: string;
    nonce: string;
    merchantIdentifier: string;
    domainName: string;
    displayName: string;
    signature: string;
}
interface ApplePayAuthorizationResult {
    authResult: any;
    payment: any;
}
interface ApplePayTransactionInput {
    product?: Product;
    cart?: Cart;
    quantity?: number;
    countryCode?: string;
}
/**
 * Configuration needed for starting an ApplePaySession
 */
interface ApplePaySessionConfig {
    request: any;
    onValidateMerchant: (event: any) => Observable<any>;
    onShippingContactSelected: (event: any) => Observable<any>;
    onPaymentMethodSelected: (event: any) => Observable<any>;
    onShippingMethodSelected: (event: any) => Observable<any>;
    onPaymentAuthorized: (event: any) => Observable<any>;
}
declare enum ApplePayEvent {
    VALIDATE_MERCHANT = "validatemerchant",
    CANCEL = "cancel",
    PAYMENT_METHOD_SELECTED = "paymentmethodselected",
    SHIPPING_CONTACT_SELECTED = "shippingcontactselected",
    SHIPPING_METHOD_SELECTED = "shippingmethodselected",
    PAYMENT_AUTHORIZED = "paymentauthorized"
}
declare enum ApplePayShippingType {
    SHIPPING = "shipping",
    DELIVERY = "delivery",
    STORE_PICKUP = "storePickup",
    SERVICE_PICKUP = "servicePickup"
}

declare abstract class OpfQuickBuyConfig {
    providers?: {
        googlePay: OpfQuickBuyGooglePayProvider;
        applePay: OpfQuickBuyApplePayProvider;
        [key: string]: unknown;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfQuickBuyConfig>;
}
declare module '@spartacus/core' {
    interface Config extends OpfQuickBuyConfig {
    }
}

declare const defaultOpfQuickBuyConfig: OpfQuickBuyConfig;

declare abstract class OpfQuickBuyFacade {
    /**
     * Abstract method to get ApplePay session for QuickBuy.
     *
     * @param applePayWebSessionRequest
     */
    abstract getApplePayWebSession(applePayWebSessionRequest: ApplePaySessionVerificationRequest): Observable<ApplePaySessionVerificationResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfQuickBuyFacade>;
}

declare abstract class OpfQuickBuySingleProductCartOptionsFacade {
    abstract getSingleProductCartOptions(productCode: string): Observable<OpfQuickBuySingleProductCartOptions>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuySingleProductCartOptionsFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfQuickBuySingleProductCartOptionsFacade>;
}

declare const OPF_QUICK_BUY_FEATURE = "opfQuickBuy";

declare function defaultOpfQuickBuyCmsComponentsConfig(): CmsConfig;
declare class OpfQuickBuyRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfQuickBuyRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfQuickBuyRootModule>;
}

export { ApplePayEvent, ApplePayShippingType, OPF_GOOGLE_PAY_PROVIDER_NAME, OPF_QUICK_BUY_ADDRESS_FIELD_PLACEHOLDER, OPF_QUICK_BUY_DEFAULT_MERCHANT_NAME, OPF_QUICK_BUY_FEATURE, OpfQuickBuyConfig, OpfQuickBuyDeliveryType, OpfQuickBuyFacade, OpfQuickBuyLocation, OpfQuickBuyProviderType, OpfQuickBuyRootModule, OpfQuickBuySingleProductCartOptionsFacade, defaultOpfQuickBuyCmsComponentsConfig, defaultOpfQuickBuyConfig };
export type { ApplePayAuthorizationResult, ApplePaySessionConfig, ApplePaySessionVerificationRequest, ApplePaySessionVerificationResponse, ApplePayTransactionInput, OpfApplePayCardParametersConfig, OpfGooglePayCardParametersConfig, OpfGooglePayPaymentRequestConfig, OpfQuickBuyApplePayProvider, OpfQuickBuyDeliveryInfo, OpfQuickBuyDigitalWallet, OpfQuickBuyGooglePayProvider, OpfQuickBuySingleProductCartOptions, QuickBuyTransactionDetails };
