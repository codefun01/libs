import * as i0 from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DeliveryMode } from '@spartacus/cart/base/root';
import { LoggerService, OccEndpointsService, ConverterService, Address, OccConfig, OccEndpoint } from '@spartacus/core';
import { OpfQuickBuyCartAdapter } from '@spartacus/opf/quick-buy/core';
import { Observable } from 'rxjs';

declare class OpfQuickBuyOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfQuickBuyOccModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfQuickBuyOccModule>;
}

declare class OccOpfQuickBuyCartAdapter implements OpfQuickBuyCartAdapter {
    protected logger: LoggerService;
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    createDeliveryAddress(userId: string, cartId: string, address: Address): Observable<Address>;
    setBillingAddress(userId: string, cartId: string, address: Address): Observable<unknown>;
    getSupportedDeliveryModes(userId: string, cartId: string): Observable<DeliveryMode[]>;
    setDeliveryMode(userId: string, cartId: string, deliveryModeId: string): Observable<unknown>;
    getSelectedDeliveryMode(userId: string, cartId: string): Observable<DeliveryMode | undefined>;
    protected getCreateDeliveryAddressEndpoint(userId: string, cartId: string): string;
    protected getSetBillingAddressEndpoint(userId: string, cartId: string): string;
    protected getDeliveryModesEndpoint(userId: string, cartId: string): string;
    protected getSetDeliveryModeEndpoint(userId: string, cartId: string, deliveryModeId?: string): string;
    protected getSelectedDeliveryModeEndpoint(userId: string, cartId: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOpfQuickBuyCartAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOpfQuickBuyCartAdapter>;
}

declare const defaultOccOpfQuickBuyCartConfig: OccConfig;

interface OccOpfQuickBuyCartEndpoints {
    /**
     * Endpoint for creating a delivery address on a cart
     */
    quickBuyCreateDeliveryAddress?: string | OccEndpoint;
    /**
     * Endpoint for setting a billing address on a cart
     */
    quickBuySetBillingAddress?: string | OccEndpoint;
    /**
     * Endpoint for getting supported delivery modes for a cart
     */
    quickBuyDeliveryModes?: string | OccEndpoint;
    /**
     * Endpoint for setting a delivery mode on a cart
     */
    quickBuySetDeliveryMode?: string | OccEndpoint;
    /**
     * Endpoint for getting the selected delivery mode on a cart
     */
    quickBuySelectedDeliveryMode?: string | OccEndpoint;
}
declare module '@spartacus/core' {
    interface OccEndpoints extends OccOpfQuickBuyCartEndpoints {
    }
}

export { OccOpfQuickBuyCartAdapter, OpfQuickBuyOccModule, defaultOccOpfQuickBuyCartConfig };
export type { OccOpfQuickBuyCartEndpoints };
