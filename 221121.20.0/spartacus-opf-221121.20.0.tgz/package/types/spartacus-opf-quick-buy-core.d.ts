import { ApplePaySessionVerificationRequest, ApplePaySessionVerificationResponse, OpfQuickBuySingleProductCartOptionsFacade, OpfQuickBuySingleProductCartOptions, OpfQuickBuyFacade, OpfQuickBuyDeliveryType, OpfQuickBuyDeliveryInfo, OpfQuickBuyLocation } from '@spartacus/opf/quick-buy/root';
import * as rxjs from 'rxjs';
import { Observable } from 'rxjs';
import { DeliveryMode, CartItemQuantityService, CartAccessCodeFacade, ActiveCartFacade, CartGuestUserFacade, MultiCartFacade, Cart, CartGuestUser } from '@spartacus/cart/base/root';
import { Address, CommandService, UserIdService, LoggerService, Command, UserAddressService, AuthService, RoutingService, UnifiedInjector, GlobalMessageService, BaseSiteService, Converter } from '@spartacus/core';
import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import { CheckoutDeliveryModesFacade, CheckoutDeliveryAddressFacade, CheckoutBillingAddressFacade } from '@spartacus/checkout/base/root';
import { OpfGlobalMessageService } from '@spartacus/opf/base/root';

declare abstract class OpfQuickBuyAdapter {
    /**
     * Abstract method used to request an ApplePay session, used by QuickBuy functionality
     */
    abstract getApplePayWebSession(applePayRequest: ApplePaySessionVerificationRequest, otpKey: string): Observable<ApplePaySessionVerificationResponse>;
}

declare abstract class OpfQuickBuyCartAdapter {
    abstract createDeliveryAddress(userId: string, cartId: string, address: Address): Observable<Address>;
    abstract setBillingAddress(userId: string, cartId: string, address: Address): Observable<unknown>;
    abstract getSupportedDeliveryModes(userId: string, cartId: string): Observable<DeliveryMode[]>;
    abstract setDeliveryMode(userId: string, cartId: string, deliveryModeId: string): Observable<unknown>;
    abstract getSelectedDeliveryMode(userId: string, cartId: string): Observable<DeliveryMode | undefined>;
}

declare class OpfQuickBuyCartConnector {
    protected adapter: OpfQuickBuyCartAdapter;
    createDeliveryAddress(userId: string, cartId: string, address: Address): Observable<Address>;
    setBillingAddress(userId: string, cartId: string, address: Address): Observable<unknown>;
    getSupportedDeliveryModes(userId: string, cartId: string): Observable<DeliveryMode[]>;
    setDeliveryMode(userId: string, cartId: string, deliveryModeId: string): Observable<unknown>;
    getSelectedDeliveryMode(userId: string, cartId: string): Observable<DeliveryMode | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyCartConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfQuickBuyCartConnector>;
}

declare class OpfQuickBuyConnector {
    protected adapter: OpfQuickBuyAdapter;
    getApplePayWebSession(applePayWebRequest: ApplePaySessionVerificationRequest, accessCode: string): Observable<ApplePaySessionVerificationResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfQuickBuyConnector>;
}

declare class OpfQuickBuyDefaultSingleProductService implements OpfQuickBuySingleProductCartOptionsFacade {
    protected cartItemQuantityService: CartItemQuantityService;
    getSingleProductCartOptions(_productCode: string): Observable<OpfQuickBuySingleProductCartOptions>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyDefaultSingleProductService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfQuickBuyDefaultSingleProductService>;
}

declare class OpfQuickBuyService implements OpfQuickBuyFacade {
    protected commandService: CommandService;
    protected opfQuickBuyConnector: OpfQuickBuyConnector;
    protected cartAccessCodeFacade: CartAccessCodeFacade;
    protected activeCartFacade: ActiveCartFacade;
    protected userIdService: UserIdService;
    protected logger: LoggerService;
    protected applePaySessionCommand: Command<{
        applePayWebSessionRequest: ApplePaySessionVerificationRequest;
    }, ApplePaySessionVerificationResponse>;
    getApplePayWebSession(applePayWebSessionRequest: ApplePaySessionVerificationRequest): rxjs.Observable<ApplePaySessionVerificationResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfQuickBuyService>;
}

declare class OpfQuickBuyCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfQuickBuyCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfQuickBuyCoreModule>;
}

declare class OpfQuickBuyActiveCartTransactionService {
    protected activeCartFacade: ActiveCartFacade;
    protected checkoutDeliveryModesFacade: CheckoutDeliveryModesFacade;
    protected checkoutDeliveryAddressFacade: CheckoutDeliveryAddressFacade;
    protected checkoutBillingAddressFacade: CheckoutBillingAddressFacade;
    protected userAddressService: UserAddressService;
    protected opfGlobalMessageService: OpfGlobalMessageService;
    protected cartGuestUserFacade: CartGuestUserFacade;
    protected authService: AuthService;
    protected userIdService: UserIdService;
    protected multiCartFacade: MultiCartFacade;
    prepareTransactionCart(): Observable<Cart>;
    getTransactionDeliveryType(): Observable<OpfQuickBuyDeliveryType>;
    getTransactionDeliveryInfo(): Observable<OpfQuickBuyDeliveryInfo>;
    checkStableCart(): Observable<boolean>;
    getSupportedDeliveryModes(): Observable<DeliveryMode[]>;
    setDeliveryAddress(address: Address): Observable<string>;
    setBillingAddress(address: Address): Observable<boolean>;
    getDeliveryAddress(): Observable<Address | undefined>;
    getCurrentCart(): Observable<Cart>;
    getCurrentCartId(): Observable<string>;
    getCurrentCartTotalPrice(): Observable<number | undefined>;
    setDeliveryMode(mode: string): Observable<DeliveryMode | undefined>;
    getSelectedDeliveryMode(): Observable<DeliveryMode | undefined>;
    deleteUserAddresses(addrIds: string[]): void;
    createCartGuestUser(): Observable<boolean>;
    protected updateCartGuestUser(cartGuestUser: CartGuestUser): Observable<boolean>;
    updateCartGuestUserEmail(email: string): Observable<boolean>;
    handleCartGuestUser(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyActiveCartTransactionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfQuickBuyActiveCartTransactionService>;
}

declare class OpfQuickBuySingleProductTransactionService {
    protected multiCartFacade: MultiCartFacade;
    protected userIdService: UserIdService;
    protected routingService: RoutingService;
    protected unifiedInjector: UnifiedInjector;
    protected globalMessageService: GlobalMessageService;
    protected cartGuestUserFacade: CartGuestUserFacade;
    protected authService: AuthService;
    protected activeCartFacade: ActiveCartFacade;
    protected singleProductCartOptions: OpfQuickBuySingleProductCartOptionsFacade;
    protected userId?: string;
    protected cartId?: string;
    getTransactionDeliveryType(): Observable<OpfQuickBuyDeliveryType>;
    getTransactionDeliveryInfo(): Observable<OpfQuickBuyDeliveryInfo>;
    checkStableCart(): Observable<boolean>;
    getSupportedDeliveryModes(): Observable<DeliveryMode[]>;
    setDeliveryAddress(address: Address): Observable<string>;
    setBillingAddress(address: Address): Observable<boolean>;
    getDeliveryAddress(): Observable<Address | undefined>;
    getCurrentCart(): Observable<Cart>;
    getCurrentCartId(): Observable<string>;
    getCurrentCartTotalPrice(): Observable<number | undefined>;
    setDeliveryMode(mode: string): Observable<DeliveryMode | undefined>;
    getSelectedDeliveryMode(): Observable<DeliveryMode | undefined>;
    prepareTransactionCart(): Observable<Cart>;
    createCartGuestUser(): Observable<boolean>;
    protected updateCartGuestUser(cartGuestUser: CartGuestUser): Observable<boolean>;
    updateCartGuestUserEmail(email: string): Observable<boolean>;
    handleCartGuestUser(): Observable<boolean>;
    createSingleProductCart(): Observable<Cart>;
    protected createDeliveryAddressAndReload(userId: string, cartId: string, address: Address): Observable<string>;
    protected mapReloadedCartToAddressId(userId: string, cartId: string, createdAddress: Address): Observable<string>;
    protected createCartForProductCode(productCode: string | undefined): Observable<Cart>;
    protected createCartWithProductEntry(productCode: string, quantity: number, pickupStore?: string): Observable<Cart>;
    protected initializeCartWithEntry(userId: string, productCode: string, quantity: number, pickupStore?: string): Observable<Cart>;
    protected isNewlyCreatedSingleProductCart(cart: Cart, userId: string): boolean;
    protected addProductAndWaitForStableCart(userId: string, cart: Cart, productCode: string, quantity: number, pickupStore?: string): Observable<Cart>;
    protected getCartConnector(): Observable<OpfQuickBuyCartConnector>;
    protected getCartContext(): Observable<{
        userId: string;
        cartId: string;
    }>;
    protected getCart(): Observable<Cart>;
    protected isGuestCart(): Observable<boolean>;
    protected hasDeliveryItems(cart: Cart): boolean;
    protected getProductCodeFromRouting(): Observable<string | undefined>;
    protected waitForStableCart(cartId: string): Observable<Cart>;
    /**
     * Informs the user via a global message when the quantity actually added to
     * the single-product cart is lower than requested (e.g. due to insufficient
     * stock). Quick buy skips the standard add-to-cart dialog, so without this
     * the reduction would go unnoticed.
     */
    protected notifyIfQuantityReduced(cart: Cart, productCode: string, requestedQuantity: number): void;
    protected reloadCartAndWait(userId: string, cartId: string): Observable<Cart>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuySingleProductTransactionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfQuickBuySingleProductTransactionService>;
}

declare class OpfQuickBuyTransactionService {
    protected routingService: RoutingService;
    protected baseSiteService: BaseSiteService;
    protected activeCartTransactionService: OpfQuickBuyActiveCartTransactionService;
    protected singleProductTransactionService: OpfQuickBuySingleProductTransactionService;
    protected transactionContext?: OpfQuickBuyLocation;
    getTransactionLocationContext(): Observable<OpfQuickBuyLocation>;
    getMerchantName(): Observable<string>;
    prepareTransactionCart(): Observable<Cart>;
    getTransactionDeliveryType(): Observable<OpfQuickBuyDeliveryType>;
    getTransactionDeliveryInfo(): Observable<OpfQuickBuyDeliveryInfo>;
    checkStableCart(): Observable<boolean>;
    getSupportedDeliveryModes(): Observable<DeliveryMode[]>;
    setDeliveryAddress(address: Address): Observable<string>;
    setBillingAddress(address: Address): Observable<boolean>;
    getDeliveryAddress(): Observable<Address | undefined>;
    getCurrentCart(): Observable<Cart>;
    getCurrentCartId(): Observable<string>;
    getCurrentCartTotalPrice(): Observable<number | undefined>;
    setDeliveryMode(mode: string): Observable<DeliveryMode | undefined>;
    getSelectedDeliveryMode(): Observable<DeliveryMode | undefined>;
    deleteUserAddresses(addrIds: string[]): void;
    createCartGuestUser(): Observable<boolean>;
    updateCartGuestUserEmail(email: string): Observable<boolean>;
    handleCartGuestUser(): Observable<boolean>;
    protected resolveContext(): Observable<OpfQuickBuyLocation>;
    protected isSingleProductContext(context?: OpfQuickBuyLocation): boolean;
    protected delegate<T>(singleProductFn: () => Observable<T>, activeCartFn: () => Observable<T>): Observable<T>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyTransactionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfQuickBuyTransactionService>;
}

declare const OPF_APPLE_PAY_WEB_SESSION_NORMALIZER: InjectionToken<Converter<any, ApplePaySessionVerificationResponse>>;

export { OPF_APPLE_PAY_WEB_SESSION_NORMALIZER, OpfQuickBuyActiveCartTransactionService, OpfQuickBuyAdapter, OpfQuickBuyCartAdapter, OpfQuickBuyCartConnector, OpfQuickBuyConnector, OpfQuickBuyCoreModule, OpfQuickBuyDefaultSingleProductService, OpfQuickBuyService, OpfQuickBuySingleProductTransactionService, OpfQuickBuyTransactionService };
