import { RoutingConfig, Address, HttpErrorModel, RoutingService, GlobalMessageService, WindowRef, RoutingConfigService, TranslationService } from '@spartacus/core';
import { Observable, Subject, BehaviorSubject, Subscription } from 'rxjs';
import { Cart, DeliveryMode } from '@spartacus/cart/base/root';
import { OpfKeyValueMap, OpfDynamicScript, OpfErrorDialogOptions, OpfMetadataStoreService, OpfResourceLoaderService } from '@spartacus/opf/base/root';
import * as i0 from '@angular/core';
import { ViewContainerRef, OnInit, OnDestroy, DestroyRef } from '@angular/core';
import * as i2$1 from '@angular/router';
import { Params, ActivatedRoute } from '@angular/router';
import { OpfGlobalFunctionsFacade } from '@spartacus/opf/global-functions/root';
import { OrderFacade, Order } from '@spartacus/order/root';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/storefront';
import { OutletContextData, Card } from '@spartacus/storefront';
import { OpfCheckoutOutlets } from '@spartacus/opf/checkout/root';

declare const defaultOpfPaymentRoutingConfig: RoutingConfig;

interface OpfPaymentVerificationPayload {
    responseMap: Array<OpfKeyValueMap>;
}
interface OpfPaymentVerificationResponse {
    result: string;
}
declare enum OpfPaymentVerificationResult {
    AUTHORIZED = "AUTHORIZED",
    UNAUTHORIZED = "UNAUTHORIZED",
    CANCELLED = "CANCELLED",
    DELAYED = "DELAYED"
}
declare enum OpfPaymentVerificationUrlInput {
    OPF_AFTER_REDIRECT_SCRIPT_FLAG = "opfAfterRedirectScriptFlag",
    OPF_PAYMENT_SESSION_ID = "opfPaymentSessionId"
}

type OpfPaymentMerchantCallback = (response?: OpfPaymentSubmitResponse | OpfPaymentSubmitCompleteResponse) => void | Promise<void>;
interface OpfPaymentGlobalMethods {
    getRedirectParams?(): Array<OpfKeyValueMap>;
    submit?(options: {
        /** @deprecated Property no longer used. Cart ID is currently derived from the OTP access code header. */
        cartId?: string;
        additionalData: Array<OpfKeyValueMap>;
        submitSuccess: OpfPaymentMerchantCallback;
        submitPending: OpfPaymentMerchantCallback;
        submitFailure: OpfPaymentMerchantCallback;
        submitCancel?: OpfPaymentMerchantCallback;
        paymentMethod: OpfPaymentMethod;
        paymentSessionId?: string;
    }): Promise<boolean>;
    submitComplete?(options: {
        /** @deprecated Property no longer used. Cart ID is currently derived from the OTP access code header. */
        cartId?: string;
        additionalData: Array<OpfKeyValueMap>;
        submitSuccess: OpfPaymentMerchantCallback;
        submitPending: OpfPaymentMerchantCallback;
        submitFailure: OpfPaymentMerchantCallback;
        submitCancel?: OpfPaymentMerchantCallback;
        paymentSessionId?: string;
    }): Promise<boolean>;
    submitCompleteRedirect?(options: {
        /** @deprecated Property no longer used. Cart ID is currently derived from the OTP access code header. */
        cartId?: string;
        additionalData: Array<OpfKeyValueMap>;
        submitSuccess: OpfPaymentMerchantCallback;
        submitPending: OpfPaymentMerchantCallback;
        submitFailure: OpfPaymentMerchantCallback;
        submitCancel?: OpfPaymentMerchantCallback;
        savePaymentMethod?: boolean;
    }): Promise<boolean>;
    throwPaymentError?(errorOptions?: OpfErrorDialogOptions): void;
    startLoadIndicator?(): void;
    stopLoadIndicator?(): void;
    scriptReady?(scriptIdentifier: string): void;
    reinitiatePaymentForm?(paymentOptionId?: number): Promise<boolean>;
    getCart?(cartId?: string): Promise<Cart | undefined>;
    setBillingAddress?(address: Address): Promise<unknown>;
    getBillingAddress?(): Promise<Address | undefined>;
    setDeliveryAddress?(address: Address): Promise<string>;
    getDeliveryAddress?(): Promise<Address | undefined>;
    setDeliveryMode?(mode: string): Promise<DeliveryMode | undefined>;
    getDeliveryMode?(): Promise<DeliveryMode | undefined>;
    deleteAddress?(addressId: string): Promise<void>;
    /**
     * Starts a new payment session for a configuration.
     *
     * Should be used when no payment session exists yet,
     * or when they intentionally want to bootstrap a fresh session.
     */
    initiatePayment?(configurationIdOrPaymentConfig: string | number | OpfPaymentConfig): Promise<OpfPaymentSessionData>;
    /**
     * Updates an existing payment transaction/session.
     *
     * Should be used for subsequent updates once a
     * payment session ID is available.
     */
    updatePaymentTransaction?(updatePaymentConfig: OpfPaymentUpdateConfig): Promise<OpfPaymentSessionData>;
    verifyPayment?(paymentSessionId: string, paymentVerificationPayload: OpfPaymentVerificationPayload): Promise<OpfPaymentVerificationResponse>;
    updateCartGuestUserEmail?(email: string): Promise<boolean>;
    createCartGuestUser?(): Promise<boolean>;
    handle3DSRedirect?(threeDsURL: string): Promise<void>;
}
interface OpfPaymentBrowserInfo {
    acceptHeader?: string;
    colorDepth?: number;
    javaEnabled?: boolean;
    javaScriptEnabled?: boolean;
    language?: string;
    screenHeight?: number;
    screenWidth?: number;
    userAgent?: string;
    timeZoneOffset?: number;
    ipAddress?: string;
    originUrl?: string;
}
interface OpfPaymentSubmitRequest {
    browserInfo?: OpfPaymentBrowserInfo;
    paymentMethod?: string;
    encryptedToken?: string;
    channel?: string;
    additionalData?: Array<OpfKeyValueMap>;
    savePaymentMethod?: boolean;
}
interface OpfPaymentSubmitInput {
    additionalData: Array<OpfKeyValueMap>;
    paymentSessionId?: string;
    callbacks: {
        onSuccess: OpfPaymentMerchantCallback;
        onPending: OpfPaymentMerchantCallback;
        onFailure: OpfPaymentMerchantCallback;
    };
    returnPath?: string;
    paymentMethod: OpfPaymentMethod;
    encryptedToken?: string;
    savePaymentMethod?: boolean;
    /**
     * Optional cart ID used to resolve the cart access code.
     * When omitted, the active cart ID is used.
     */
    cartId?: string;
}
declare enum OpfPaymentChannel {
    BROWSER = "BROWSER"
}
declare enum OpfPaymentSubmitStatus {
    REJECTED = "REJECTED",
    ACCEPTED = "ACCEPTED",
    PENDING = "PENDING",
    DELAYED = "DELAYED",
    CANCELLED = "CANCELLED"
}
declare enum OpfPaymentMethod {
    CREDIT_CARD = "CREDIT_CARD"
}
interface OpfPaymentSubmitResponse {
    cartId: string;
    status: OpfPaymentSubmitStatus;
    reasonCode: string;
    paymentMethod: OpfPaymentMethod;
    authorizedAmount: number;
    customFields: Array<OpfKeyValueMap>;
}
interface OpfPaymentSubmitCompleteResponse {
    cartId: string;
    status: OpfPaymentSubmitStatus;
    reasonCode: number;
    customFields: Array<OpfKeyValueMap>;
}
interface OpfPaymentSubmitCompleteRequest {
    paymentSessionId?: string;
    additionalData?: Array<OpfKeyValueMap>;
    savePaymentMethod?: boolean;
}
interface OpfPaymentSubmitCompleteInput {
    additionalData: Array<OpfKeyValueMap>;
    paymentSessionId: string;
    callbacks: {
        onSuccess: OpfPaymentMerchantCallback;
        onPending: OpfPaymentMerchantCallback;
        onFailure: OpfPaymentMerchantCallback;
    };
    returnPath?: string;
    savePaymentMethod?: boolean;
    /**
     * Optional cart ID used to resolve the cart access code.
     * When omitted, the active cart ID is used.
     */
    cartId?: string;
}
interface OpfPaymentAfterRedirectScriptResponse {
    afterRedirectScript: OpfDynamicScript;
}
interface OpfPaymentInitiationConfig {
    otpKey?: string;
    config?: OpfPaymentConfig;
}
interface OpfPaymentUpdateConfig {
    paymentSessionId: string;
    otpKey?: string;
    config?: OpfPaymentUpdatePayload;
}
interface OpfPaymentUpdatePayload {
    configurationId?: string;
    channel?: string;
    browserInfo?: OpfPaymentBrowserInfo;
    additionalData?: Array<OpfKeyValueMap>;
    resultURL?: string;
    cancelURL?: string;
}
interface OpfPaymentConfig {
    configurationId?: string;
    /** @deprecated Property no longer used. Cart ID is currently derived from the OTP access code header. */
    cartId?: string;
    resultURL?: string;
    cancelURL?: string;
    channel?: string;
    browserInfo?: OpfPaymentBrowserInfo;
}
interface OpfPaymentSessionFormField {
    name?: string;
    value?: string;
}
interface OpfPaymentSessionData {
    paymentSessionId?: string;
    relayResultUrl?: string;
    relayCancelUrl?: string;
    paymentIntent?: string;
    pattern?: OpfPaymentRenderPattern;
    destination?: OpfPaymentDestination;
    dynamicScript?: OpfDynamicScript;
    paymentOptionId?: number;
}
interface OpfPaymentDestination {
    url?: string;
    method?: string;
    contentType?: string;
    body?: string;
    authenticationIds?: number[];
    form?: OpfPaymentSessionFormField[];
}
declare enum OpfPaymentRenderPattern {
    IFRAME = "IFRAME",
    FULL_PAGE = "FULL_PAGE",
    HOSTED_FIELDS = "HOSTED_FIELDS"
}
interface OpfPaymentRenderMethodEvent {
    isLoading: boolean;
    isError: boolean;
    renderType?: OpfPaymentRenderPattern;
    html?: string | null;
    destination?: OpfPaymentDestination;
    paymentOptionId?: number;
}
interface OpfPaymentMethodDetails {
    code?: string;
    name?: string;
}

declare module '@spartacus/core' {
    interface PaymentDetails {
        sapPaymentMethod?: OpfPaymentMethodDetails;
    }
}

declare const opfDefaultPaymentError: OpfPaymentError;
interface OpfPaymentError extends HttpErrorModel {
    /**
     * The type of error message for further clarity, lower case with underscore eg validation_failure
     */
    type?: string;
    /**
     * The description of the error and, in some cases, a solution to the API consumer to resolve the issue.
     */
    message: string;
    /**
     * An error can occur for multiple reasons, or it can be specified in more detail using a more precise error.
     */
    details?: Array<OpfPaymentErrorDetails>;
    moreInfo?: string;
    checkoutValidationMessage?: string;
}
interface OpfPaymentErrorValidationFailedProduct {
    productId?: string;
    quantity?: number;
    maxQuantity?: number;
    minQuantity?: number;
}
interface OpfPaymentErrorMoreInfo {
    validationFailedProducts?: Array<OpfPaymentErrorValidationFailedProduct>;
    maxQuantity?: number;
    currentOrderAmount?: number;
    minOrderAmount?: number;
}
interface OpfPaymentErrorDetails {
    /**
     * The specific payload attribute or query parameter causing the error.
     */
    field?: string;
    /**
     * Classification of the error detail type, lower case with underscore eg missing_value,
     * this value must be always interpreted in context of the general error type.
     */
    type: string;
    /**
     * The description of the error and, in some cases, a solution to the API consumer to resolve the issue.
     */
    message?: string;
    moreInfo?: string | OpfPaymentErrorMoreInfo;
}
declare enum OpfPaymentErrorType {
    EXPIRED = "EXPIRED",
    INSUFFICIENT_FUNDS = "INSUFFICIENT_FUNDS",
    CREDIT_LIMIT = "CREDIT_LIMIT",
    INVALID_CARD = "INVALID_CARD",
    INVALID_CVV = "INVALID_CVV",
    LOST_CARD = "LOST_CARD",
    PAYMENT_REJECTED = "PAYMENT_REJECTED",
    PAYMENT_CANCELLED = "PAYMENT_CANCELLED",
    STATUS_NOT_RECOGNIZED = "STATUS_NOT_RECOGNIZED"
}

declare abstract class OpfPaymentFacade {
    /**
     * Abstract method to verify a response from PSP for Full Page Redirect
     * and iframe integration patterns.
     *
     * @param {string} paymentSessionId
     * @param {OpfPaymentVerificationPayload} paymentVerificationPayload
     *
     */
    abstract verifyPayment(paymentSessionId: string, paymentVerificationPayload: OpfPaymentVerificationPayload): Observable<OpfPaymentVerificationResponse>;
    /**
     * Abstract method to submit payment for Hosted Fields pattern.
     *
     * @param {OpfPaymentSubmitInput} submitInput
     *
     */
    abstract submitPayment(submitInput: OpfPaymentSubmitInput): Observable<boolean>;
    /**
     * Abstract method to submit-complete payment
     * for Hosted Fields pattern.
     *
     * @param {OpfPaymentSubmitCompleteInput} submitCompleteInput
     *
     */
    abstract submitCompletePayment(submitCompleteInput: OpfPaymentSubmitCompleteInput): Observable<boolean>;
    /**
     * Abstract method to retrieve the dynamic scripts after redirect
     * used in hosted-fields pattern.
     *
     * @param {string} paymentSessionId
     *
     */
    abstract getAfterRedirectScripts(paymentSessionId: string): Observable<OpfPaymentAfterRedirectScriptResponse>;
    /**
     * Abstract method used to initiate payment session
     * or call the PSP to initiate.
     *
     * @param {OpfPaymentInitiationConfig} paymentConfig
     *
     */
    abstract initiatePayment(paymentConfig: OpfPaymentInitiationConfig): Observable<OpfPaymentSessionData>;
    /**
     * Abstract method used to update an existing payment transaction/session.
     *
     * @param {OpfPaymentUpdateConfig} updatePaymentConfig
     */
    abstract updatePaymentTransaction(updatePaymentConfig: OpfPaymentUpdateConfig): Observable<OpfPaymentSessionData>;
    /**
     * Abstract method to set the payment option for the cart
     *
     * @param {string} userId
     * @param {string} cartId
     * @param {string} sapPaymentOptionId
     * @param {string} purchaseOrderNumber
     */
    abstract setCartPaymentOption(userId: string, cartId: string, sapPaymentOptionId: string, purchaseOrderNumber?: string): Observable<Cart>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfPaymentFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfPaymentFacade>;
}

declare const OPF_PAYMENT_FEATURE = "opfPayment";

declare class OpfPaymentEventsService {
    protected reinitiatePaymentEvent: Subject<number | undefined>;
    reinitiatePaymentEvent$: Observable<number | undefined>;
    /**
     * Emits an event to re-initiate payment form
     * @param paymentOptionId Optional payment option ID to use for re-initiation
     */
    emitReinitiatePaymentEvent(paymentOptionId?: number): void;
    protected refreshActiveConfigurationsEvent: Subject<void>;
    refreshActiveConfigurationsEvent$: Observable<void>;
    /**
     * Emits an event to refresh the active payment configurations list
     */
    emitRefreshActiveConfigurationsEvent(): void;
    protected isGiftCardCoveredTotalAmountEvent: BehaviorSubject<boolean>;
    isGiftCardCoveredTotalAmountEvent$: Observable<boolean>;
    /**
     * Emits an event to indicate if the gift card covers the total amount
     * @param isCovered Boolean indicating if the gift card covers the total amount
     */
    emitIsGiftCardCoveredTotalAmountEvent(isCovered: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfPaymentEventsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfPaymentEventsService>;
}

declare class OpfPaymentVerificationService {
    protected orderFacade: OrderFacade;
    protected routingService: RoutingService;
    protected globalMessageService: GlobalMessageService;
    protected opfPaymentFacade: OpfPaymentFacade;
    protected opfMetadataStoreService: OpfMetadataStoreService;
    protected opfResourceLoaderService: OpfResourceLoaderService;
    protected globalFunctionsService: OpfGlobalFunctionsFacade;
    protected winRef: WindowRef;
    protected routingConfigService: RoutingConfigService;
    opfDefaultPaymentError: HttpErrorModel;
    protected getParamsMap(params: Params): Array<OpfKeyValueMap>;
    /**
     * Stores the redirect query string before OAuth bootstrap mutates `location.search`.
     */
    captureRedirectQueryString(): void;
    protected findInParamsMap(key: string, list: Array<OpfKeyValueMap>): string | undefined;
    goToPage(cxRoute: string): void;
    clearPaymentSessionForReinitiation(): void;
    verifyResultUrl(route: ActivatedRoute): Observable<{
        paymentSessionId: string;
        paramsMap: Array<OpfKeyValueMap>;
        afterRedirectScriptFlag: string | undefined;
        is3DSRedirect?: boolean;
    }>;
    protected getRedirectQueryParams(): Params;
    protected getPaymentSessionId(paramMap: Array<OpfKeyValueMap>): Observable<string | undefined>;
    protected getPaymentSessionIdFromStorage(): Observable<string | undefined>;
    protected placeOrder(): Observable<Order>;
    protected verifyPayment(paymentSessionId: string, responseMap: Array<OpfKeyValueMap>): Observable<boolean>;
    protected isPaymentSuccessful(response: OpfPaymentVerificationResponse): Observable<boolean>;
    displayError(error: HttpErrorModel | undefined): void;
    checkIfProcessingCartIdExist(): void;
    runHostedPagePattern(paymentSessionId: string, paramsMap: OpfKeyValueMap[]): Observable<boolean>;
    runHostedFieldsPattern(paymentSessionId: string, vcr: ViewContainerRef, paramsMap: Array<OpfKeyValueMap>): Observable<boolean>;
    protected renderAfterRedirectScripts(script: OpfDynamicScript): Promise<boolean>;
    removeResourcesAndGlobalFunctions(): void;
    protected check3DSRedirectState(): boolean;
    protected get3DSRedirectState(): {
        paymentSessionId: string;
        returnPath: string;
    } | null;
    protected clear3DSRedirectState(): void;
    run3DSRedirectPattern(paymentSessionId: string, paramsMap: Array<OpfKeyValueMap>, vcr: ViewContainerRef): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfPaymentVerificationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfPaymentVerificationService>;
}
declare function captureOpfPaymentVerificationQueryFactory(): () => void;

declare class OpfPaymentVerificationComponent implements OnInit, OnDestroy {
    protected route: ActivatedRoute;
    protected opfPaymentVerificationService: OpfPaymentVerificationService;
    protected vcr: ViewContainerRef;
    protected winRef: WindowRef;
    private featureToggles;
    protected subscription?: Subscription;
    protected isHostedFieldPattern: boolean;
    ngOnInit(): void;
    /**
     * Ensures the verification page is displayed in the top-level window.
     * Some PSPs render verification/success pages inside an iframe; in such cases
     * we reload the current URL in the top window to preserve full-page UX.
     *
     * Reference: https://docs.saferpay.com/home/integration-guide/general-information/iframe-integration-and-css
     */
    protected breakOutOfIframeIfNeeded(): void;
    protected runPaymentPattern({ paymentSessionId, paramsMap, afterRedirectScriptFlag, is3DSRedirect, }: {
        paymentSessionId: string;
        paramsMap: OpfKeyValueMap[];
        afterRedirectScriptFlag?: string;
        is3DSRedirect?: boolean;
    }): Observable<boolean>;
    onError(error: HttpErrorModel | undefined): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfPaymentVerificationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfPaymentVerificationComponent, "cx-opf-verify-payment", never, {}, {}, never, never, true, never>;
}

declare class OpfPaymentVerificationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfPaymentVerificationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfPaymentVerificationModule, never, [typeof i1.CommonModule, typeof i2.SpinnerModule, typeof OpfPaymentVerificationComponent], [typeof OpfPaymentVerificationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfPaymentVerificationModule>;
}

declare class OpfPaymentMethodDetailsComponent implements OnInit, OnDestroy {
    protected translationService: TranslationService;
    protected destroyRef: DestroyRef;
    private featureToggles;
    protected orderOutlet: OutletContextData<any>;
    readonly opfCheckoutOutlets: typeof OpfCheckoutOutlets;
    protected subscription: Subscription;
    order: Order;
    ngOnInit(): void;
    getPaymentMethodDetailsCardContent(paymentMethodDetails?: OpfPaymentMethodDetails): Observable<Card>;
    isPaymentMethodDetailsInfoPresent(order: Order): boolean;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfPaymentMethodDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfPaymentMethodDetailsComponent, "cx-opf-payment-method-details", never, {}, {}, never, never, true, never>;
}

declare class OpfPaymentMethodDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfPaymentMethodDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfPaymentMethodDetailsModule, never, [typeof i1.CommonModule, typeof i2.CardModule, typeof OpfPaymentMethodDetailsComponent], [typeof OpfPaymentMethodDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfPaymentMethodDetailsModule>;
}

declare class OpfPaymentRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfPaymentRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfPaymentRootModule, never, [typeof OpfPaymentMethodDetailsModule, typeof i2$1.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfPaymentRootModule>;
}

export { OPF_PAYMENT_FEATURE, OpfPaymentChannel, OpfPaymentErrorType, OpfPaymentEventsService, OpfPaymentFacade, OpfPaymentMethod, OpfPaymentMethodDetailsComponent, OpfPaymentMethodDetailsModule, OpfPaymentRenderPattern, OpfPaymentRootModule, OpfPaymentSubmitStatus, OpfPaymentVerificationComponent, OpfPaymentVerificationModule, OpfPaymentVerificationResult, OpfPaymentVerificationService, OpfPaymentVerificationUrlInput, captureOpfPaymentVerificationQueryFactory, defaultOpfPaymentRoutingConfig, opfDefaultPaymentError };
export type { OpfPaymentAfterRedirectScriptResponse, OpfPaymentBrowserInfo, OpfPaymentConfig, OpfPaymentDestination, OpfPaymentError, OpfPaymentErrorDetails, OpfPaymentErrorMoreInfo, OpfPaymentErrorValidationFailedProduct, OpfPaymentGlobalMethods, OpfPaymentInitiationConfig, OpfPaymentMerchantCallback, OpfPaymentMethodDetails, OpfPaymentRenderMethodEvent, OpfPaymentSessionData, OpfPaymentSessionFormField, OpfPaymentSubmitCompleteInput, OpfPaymentSubmitCompleteRequest, OpfPaymentSubmitCompleteResponse, OpfPaymentSubmitInput, OpfPaymentSubmitRequest, OpfPaymentSubmitResponse, OpfPaymentUpdateConfig, OpfPaymentUpdatePayload, OpfPaymentVerificationPayload, OpfPaymentVerificationResponse };
