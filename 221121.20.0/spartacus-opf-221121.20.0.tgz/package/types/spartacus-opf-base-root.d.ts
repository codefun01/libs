import * as i0 from '@angular/core';
import { OnDestroy, NgZone } from '@angular/core';
import { Config, GlobalMessageService, Translatable, GlobalMessageType, StatePersistenceService, ScriptLoader, WindowRef, LoggerService, EventService, QueryState } from '@spartacus/core';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';

declare const OPF_CC_PUBLIC_KEY_HEADER = "sap-commerce-cloud-public-key";
declare const OPF_CC_ACCESS_CODE_HEADER = "sap-commerce-cloud-access-code";

declare abstract class OpfConfig {
    opf?: {
        opfBaseUrl?: string;
        commerceCloudPublicKey?: string;
        paymentOption?: {
            /**
             * The map of info message translation keys for specific payment configuration IDs
             * @example
             * ```ts
             * const opfConfig = {
             *   opf: {
             *     paymentInfoMessagesMap: {
             *       213: 'opfCheckout.payPalPaymentInfoMessage' // Message key for payment method ID 213
             *     }
             *   }
             * };
             * ```
             */
            paymentInfoMessagesMap?: Record<number, string>;
            /**
             * Enables the payment info message section within the payment options
             */
            enableInfoMessage?: boolean;
            /**
             * Iframe sandbox permissions per payment option id.
             * Useful when specific PSPs require different sandbox flags.
             * @example
             * ```ts
             * const opfConfig = {
             *   opf: {
             *     paymentOption: {
             *       iframeSandboxMap: {
             *         123: 'allow-scripts allow-same-origin', // PSP 1
             *         456: 'allow-scripts allow-same-origin allow-forms' // PSP 2
             *       }
             *     }
             *   }
             * };
             * ```
             */
            iframeSandboxMap?: Record<number, string>;
        };
        /**
         * Local PSP resource configuration for faster loading
         * @example
         * ```ts
         * const opfConfig = {
         *   opf: {
         *     localPspResources: {
         *       213: { // paymentOptionId for Adyen
         *         jsFiles: ['/assets/adyen-payment.js'],
         *         cssFiles: ['/assets/adyen-styles.css']
         *       },
         *       456: { // paymentOptionId for Stripe
         *         jsFiles: ['/assets/stripe-payment.js'],
         *         cssFiles: ['/assets/stripe-styles.css']
         *       }
         *     }
         *   }
         * };
         * ```
         */
        localPspResources?: Record<number, {
            jsFiles: string[];
            cssFiles: string[];
        }>;
        /**
         * When enabled, a cart access code is generated and sent as the
         * `sap-commerce-cloud-access-code` header on the `getActiveConfigurations` request.
         * This is required for Intelligent Routing.
         */
        enableGetActiveConfigurationsAccessCodeHeader?: boolean;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfConfig>;
}
declare module '@spartacus/core' {
    interface Config extends OpfConfig {
    }
}

declare const defaultOpfConfig: OpfConfig;

interface OpfApiEndpoints {
}

interface OpfApiBackendConfig {
    opfApi?: {
        endpoints?: OpfApiEndpoints;
    };
}

declare abstract class OpfApiConfig extends Config {
    backend?: OpfApiBackendConfig;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfApiConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfApiConfig>;
}
declare module '@spartacus/core' {
    interface BackendConfig extends OpfApiBackendConfig {
    }
}

declare class OpfGlobalMessageService extends GlobalMessageService {
    protected isGlobalMessageDisabled: boolean;
    protected disabledKeys: string[];
    protected defaultTimeout: number;
    /**
     * Add one message into store
     * @param text: string | Translatable
     * @param type: GlobalMessageType object
     * @param timeout: number
     */
    add(text: string | Translatable, type: GlobalMessageType, timeout?: number): void;
    /**
     * disable specific keys for a period of time
     * @param keys: string[]
     * @param timeout: number
     */
    disableGlobalMessage(keys: string[], timeout?: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGlobalMessageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfGlobalMessageService>;
}

interface OpfMetadataModel {
    termsAndConditionsChecked: boolean;
    selectedPaymentOptionId: number | undefined;
    defaultSelectedPaymentOptionId?: number;
    isPaymentInProgress: boolean;
    opfPaymentSessionId: string | undefined;
    opfPaymentSessionConfigurationId?: string;
    isTermsAndConditionsAlertClosed: boolean;
    is3DSRedirect?: boolean;
    opf3DSRedirectReturnPath?: string;
}

declare class OpfMetadataStoreService {
    protected readonly INITIAL_STATE: OpfMetadataModel;
    opfMetadataState: BehaviorSubject<OpfMetadataModel>;
    getOpfMetadataState(): Observable<OpfMetadataModel>;
    updateOpfMetadata(payload: Partial<OpfMetadataModel>): void;
    clearOpfMetadata(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfMetadataStoreService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfMetadataStoreService>;
}

/**
 * OPF state synced to browser storage.
 */
interface SyncedOpfState {
    metadata?: OpfMetadataModel;
}
/**
 * Responsible for storing OPF state in the browser storage.
 * Uses `StatePersistenceService` mechanism.
 */
declare class OpfMetadataStatePersistanceService implements OnDestroy {
    protected statePersistenceService: StatePersistenceService;
    protected opfMetadataStoreService: OpfMetadataStoreService;
    protected subscription: Subscription;
    /**
     * Identifier used for storage key.
     */
    protected key: string;
    /**
     * Initializes the synchronization between state and browser storage.
     */
    initSync(): void;
    /**
     * Gets an active content language from the browser local storage.
     */
    getActiveLanguage(): string;
    /**
     * Gets and transforms state from different sources into the form that should
     * be saved in storage.
     */
    protected getOpfState(): Observable<SyncedOpfState>;
    /**
     * Function called on each browser storage read.
     * Used to update state from browser -> state.
     */
    protected onRead(state: SyncedOpfState | undefined): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfMetadataStatePersistanceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfMetadataStatePersistanceService>;
}

declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        OPF_ERROR = "OPF_ERROR"
    }
}

interface OpfApiEndpoint {
    default?: string;
    [scope: string]: string | undefined;
}

interface OpfActiveConfigurationsResponse {
    value?: OpfActiveConfiguration[];
    page?: OpfActiveConfigurationsPagination;
}
interface OpfActiveConfiguration {
    description?: string;
    id?: number;
    merchantId?: string;
    providerType?: OpfPaymentProviderType;
    paymentType?: string;
    displayName?: string;
    acquirerCountryCode?: string;
    logoUrl?: string;
    code?: string;
    dynamicScript?: OpfDynamicScript;
}
interface OpfActiveConfigurationsPagination {
    number?: number;
    size?: number;
    totalElements?: number;
    totalPages?: number;
}
interface OpfActiveConfigurationsQuery {
    /**
     * The page number to be retrieved based on the total number of pages.
     */
    pageNumber?: number;
    /**
     * The number of records retrieved at one time.
     */
    pageSize?: number;
}
declare enum OpfHtmlContentMode {
    SEPARATE = "SEPARATE",
    MIXED = "MIXED"
}
interface OpfDynamicScript {
    cssUrls?: OpfDynamicScriptResource[];
    jsUrls?: OpfDynamicScriptResource[];
    html?: string;
    htmlContentMode?: OpfHtmlContentMode;
    jsContent?: string;
    jsHash?: string;
    jsContext?: string;
    cssUrl?: string;
    cssHash?: string;
}
interface OpfKeyValueMap {
    key: string;
    value: string;
}
interface OpfDynamicScriptResource {
    url?: string;
    sri?: string;
    attributes?: OpfKeyValueMap[];
    type?: OpfDynamicScriptResourceType;
}
declare enum OpfPage {
    CHECKOUT_REVIEW_PAGE = "opfCheckoutPaymentAndReview",
    CONFIRMATION_PAGE = "orderConfirmation",
    RESULT_PAGE = "paymentVerificationResult",
    CANCEL_PAGE = "paymentVerificationCancel",
    CART_PAGE = "cart"
}
declare enum OpfDynamicScriptResourceType {
    SCRIPT = "SCRIPT",
    STYLES = "STYLES"
}
declare enum OpfPaymentProviderType {
    PAYMENT_GATEWAY = "PAYMENT_GATEWAY",
    PAYMENT_METHOD = "PAYMENT_METHOD",
    STORED_VALUE_PAYMENT = "STORED_VALUE_PAYMENT"
}

type OpfErrorDialogOptions = {
    confirmString?: string;
    confirmKey?: string;
    confirmReplacements?: any;
    messageString?: string;
    messageKey?: string;
    messageReplacements?: any;
};
declare const defaultOpfErrorDialogOptions: OpfErrorDialogOptions;

declare class OpfResourceLoaderService {
    protected scriptLoader: ScriptLoader;
    protected document: Document;
    protected platformId: Object;
    protected config: Config;
    protected windowRef: WindowRef;
    protected ngZone: NgZone;
    protected logger: LoggerService;
    protected readonly CORS_DEFAULT_VALUE = "anonymous";
    protected readonly OPF_RESOURCE_LOAD_ONCE_ATTRIBUTE_KEY = "opf-load-once";
    protected readonly OPF_RESOURCE_ATTRIBUTE_KEY = "data-opf-resource";
    protected embedStyles(embedOptions: {
        attributes?: {
            [key: string]: string;
        };
        src: string;
        sri?: string;
        callback?: EventListener;
        errorCallback: EventListener;
    }): void;
    protected hasStyles(src?: string): boolean;
    protected hasScript(src?: string): boolean;
    /**
     * Create attributes intended to script and link elements.
     *
     * Return attributes list including keyValueList and OPF specific attribute with below logic:
     *
     * 1. Resource loads only once: 'opf-load-once' key detected, no additional attribute added.
     * 2. Resource deleted at page/payment change: 'data-opf-resource' attribute is added.
     */
    protected createAttributesList(keyValueList?: OpfKeyValueMap[] | undefined): {
        [key: string]: string;
    };
    /**
     * Loads a script specified in the resource object.
     *
     * The returned Promise is resolved when the script is loaded or already present.
     * The returned Promise is rejected when a loading error occurs.
     */
    protected loadScript(resource: OpfDynamicScriptResource): Promise<void>;
    /**
     * Loads a stylesheet specified in the resource object.
     *
     * The returned Promise is resolved when the stylesheet is loaded or already present.
     * The returned Promise is rejected when a loading error occurs.
     */
    protected loadStyles(resource: OpfDynamicScriptResource): Promise<void>;
    executeScriptFromHtml(html: string | undefined): void;
    clearAllResources(): void;
    /**
     * Parses jsContext JSON string and nested JSON strings (e.g., responseBody)
     * Returns empty object if parsing fails to allow graceful degradation
     */
    protected parseContext(jsContext?: string): any;
    /**
     * Execute script with context passed via global variable (no wrapping)
     * This allows using the original script hash from jsHash without modification
     * Context is set in window.OpfContext before script execution
     */
    protected executeScriptWithContext(originalScript: string, contextData: any): void;
    /**
     * Checks if local PSP resources are available from the storefront configuration
     */
    hasLocalPspResources(paymentOptionId?: number): boolean;
    /**
     * Extracts script content and context from dynamic script if in SEPARATE mode
     */
    protected extractDynamicScriptContext(dynamicScript?: OpfDynamicScript): {
        originalScript?: string;
        contextData?: any;
    };
    /**
     * Adds CSS from dynamic script to styles array if in SEPARATE mode
     */
    protected addDynamicScriptCss(dynamicScript?: OpfDynamicScript, styles?: OpfDynamicScriptResource[]): void;
    /**
     * Gets local PSP resources if available for the given payment option ID
     */
    protected getLocalResources(paymentOptionId?: number): OpfDynamicScriptResource[];
    /**
     * Converts external scripts and styles to resource format
     */
    protected getExternalResources(scripts?: OpfDynamicScriptResource[], styles?: OpfDynamicScriptResource[]): OpfDynamicScriptResource[];
    /**
     * Loads a single resource based on its type
     */
    protected loadResource(resource: OpfDynamicScriptResource): Promise<void>;
    /**
     * Loads scripts and stylesheets specified in the lists of resource objects (scripts and styles).
     * The method automatically selects local or external resources based on the presence of localPspResources
     * in the storefront configuration.
     * If localPspResources are present, the method uses local resources.
     * If localPspResources are not present, the method uses external resources.
     *
     * When htmlContentMode is SEPARATE, the method uses jsContent/jsHash and cssUrl/cssHash properties
     * to load resources with specific URLs and SRI hashes.
     *
     * The returned Promise is resolved when all resources are loaded.
     * The returned Promise is also resolved (not rejected!) immediately when any loading error occurs.
     */
    loadResources(scripts?: OpfDynamicScriptResource[], styles?: OpfDynamicScriptResource[], paymentOptionId?: number, dynamicScript?: OpfDynamicScript): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfResourceLoaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfResourceLoaderService>;
}

declare class OpfEventListenerService implements OnDestroy {
    protected eventService: EventService;
    protected opfMetadataStoreService: OpfMetadataStoreService;
    protected subscriptions: Subscription;
    constructor();
    protected onOpfPaymentMetadataResetConditionsMet(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfEventListenerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfEventListenerService>;
}

declare abstract class OpfBaseFacade {
    /**
     * Get payment active configurations
     */
    abstract getActiveConfigurationsState(query?: OpfActiveConfigurationsQuery): Observable<QueryState<OpfActiveConfigurationsResponse | undefined>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfBaseFacade, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfBaseFacade>;
}

declare const OPF_BASE_FEATURE = "opfBase";

declare class OpfEventModule {
    constructor(_opfEventListenerService: OpfEventListenerService);
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfEventModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfEventModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfEventModule>;
}

declare class OpfBaseRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfBaseRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfBaseRootModule, never, [typeof OpfEventModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfBaseRootModule>;
}

export { OPF_BASE_FEATURE, OPF_CC_ACCESS_CODE_HEADER, OPF_CC_PUBLIC_KEY_HEADER, OpfApiConfig, OpfBaseFacade, OpfBaseRootModule, OpfConfig, OpfDynamicScriptResourceType, OpfEventListenerService, OpfGlobalMessageService, OpfHtmlContentMode, OpfMetadataStatePersistanceService, OpfMetadataStoreService, OpfPage, OpfPaymentProviderType, OpfResourceLoaderService, defaultOpfConfig, defaultOpfErrorDialogOptions };
export type { OpfActiveConfiguration, OpfActiveConfigurationsPagination, OpfActiveConfigurationsQuery, OpfActiveConfigurationsResponse, OpfApiBackendConfig, OpfApiEndpoint, OpfApiEndpoints, OpfDynamicScript, OpfDynamicScriptResource, OpfErrorDialogOptions, OpfKeyValueMap, OpfMetadataModel, SyncedOpfState };
