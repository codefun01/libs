import * as i0 from '@angular/core';
import * as i1 from '@spartacus/opf/quick-buy';
import { OpfQuickBuyDefaultSingleProductService } from '@spartacus/opf/quick-buy/core';
import { OpfQuickBuySingleProductCartOptionsFacade, OpfQuickBuySingleProductCartOptions } from '@spartacus/opf/quick-buy/root';
import { IntendedPickupLocationFacade } from '@spartacus/pickup-in-store/root';
import { Observable } from 'rxjs';

declare class OpfQuickBuyPickupInStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyPickupInStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfQuickBuyPickupInStoreModule, never, [typeof i1.OpfQuickBuyModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfQuickBuyPickupInStoreModule>;
}

declare class OpfQuickBuyPickupInStoreSingleProductService implements OpfQuickBuySingleProductCartOptionsFacade {
    protected defaultSingleProductService: OpfQuickBuyDefaultSingleProductService;
    protected intendedPickupLocation: IntendedPickupLocationFacade;
    getSingleProductCartOptions(productCode: string): Observable<OpfQuickBuySingleProductCartOptions>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyPickupInStoreSingleProductService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfQuickBuyPickupInStoreSingleProductService>;
}

export { OpfQuickBuyPickupInStoreModule, OpfQuickBuyPickupInStoreSingleProductService };
