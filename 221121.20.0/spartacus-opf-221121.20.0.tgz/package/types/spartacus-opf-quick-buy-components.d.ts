import * as i0 from '@angular/core';
import { OnInit, ElementRef, ChangeDetectorRef } from '@angular/core';
import * as i1 from '@angular/common';
import { OpfActiveConfiguration, OpfBaseFacade, OpfResourceLoaderService } from '@spartacus/opf/base/root';
import { OpfQuickBuyTransactionService } from '@spartacus/opf/quick-buy/core';
import { ApplePaySessionConfig, OpfQuickBuyFacade, OpfQuickBuyConfig, OpfQuickBuyApplePayProvider, QuickBuyTransactionDetails, ApplePayTransactionInput, OpfQuickBuyDigitalWallet, OpfQuickBuyProviderType, OpfQuickBuyGooglePayProvider, OpfQuickBuyDeliveryType, OpfQuickBuyDeliveryInfo } from '@spartacus/opf/quick-buy/root';
import { CurrentProductService } from '@spartacus/storefront';
import { Observable, BehaviorSubject } from 'rxjs';
import { WindowRef, AuthService, UserIdService, TranslationService } from '@spartacus/core';
import { OpfPaymentFacade } from '@spartacus/opf/payment/root';
import { CartGuestUserFacade, ActiveCartFacade, MultiCartFacade, DeliveryMode, Cart } from '@spartacus/cart/base/root';
import { CheckoutConfig } from '@spartacus/checkout/base/root';

/**
 * Wrapper of the native `ApplePaySession` API.
 *
 * It can tell whether the native `ApplePaySession` is supported,
 * create a new instance of `ApplePaySession` object (for starting a new payment process),
 * or expose some of the static constants of the native `ApplePaySession` API.
 */
declare class ApplePaySessionWrapperService {
    protected winRef: WindowRef;
    protected isDeviceSupported: boolean;
    private applePaySession;
    protected applePayApiVersion: number;
    protected initialize(): void;
    constructor();
    private getApplePaySession;
    get statusSuccess(): number;
    get statusFailure(): number;
    isApplePaySupported(merchantIdentifier: string): Observable<boolean>;
    protected supportsVersion(version: number): boolean;
    protected canMakePayments(): boolean;
    protected canMakePaymentsWithActiveCard(merchantId: string): Observable<boolean>;
    /**
     * Creates and returns a new instance of `ApplePaySession` object (for a new payment process).
     */
    createSession(paymentRequest: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApplePaySessionWrapperService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ApplePaySessionWrapperService>;
}

/**
 * Orchestrates a payment process using the native `ApplePaySession` API.
 */
declare class ApplePaySessionOrchestrator {
    protected applePaySessionWrapperService: ApplePaySessionWrapperService;
    /**
     * Starts a new payment process using the native `ApplePaySession` API
     *
     * It creates a new `ApplePaySession` instance and binds the provided
     * handlers (callbacks) for the `ApplePaySession` instance events.
     *
     * It returns an Observable that:
     * a) emits the payment result. Then the observable is immediately completed.
     * b) OR emits an RxJS error if any error occurs during the process
     *    (e.g. a merchant validation fails, the user cancels the payment, etc.)
     */
    start(config: ApplePaySessionConfig): Observable<any>;
    protected isShippingTypePickup(config: any): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApplePaySessionOrchestrator, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ApplePaySessionOrchestrator>;
}

declare class ApplePayService {
    protected opfPaymentFacade: OpfPaymentFacade;
    protected applePaySessionWrapperService: ApplePaySessionWrapperService;
    protected applePaySessionOrchestrator: ApplePaySessionOrchestrator;
    protected winRef: WindowRef;
    protected opfQuickBuyTransactionService: OpfQuickBuyTransactionService;
    protected opfQuickBuyFacade: OpfQuickBuyFacade;
    protected opfQuickBuyConfig: OpfQuickBuyConfig;
    protected paymentInProgress: boolean;
    protected get applePayProviderConfig(): OpfQuickBuyApplePayProvider;
    protected readonly defaultApplePayCardParameters: any;
    protected initialTransactionDetails: QuickBuyTransactionDetails;
    protected transactionDetails: QuickBuyTransactionDetails;
    protected initTransactionDetails(transactionInput: ApplePayTransactionInput): QuickBuyTransactionDetails;
    start(transactionInput: ApplePayTransactionInput): any;
    isApplePaySupported(merchantId: string): Observable<boolean>;
    protected deleteUserAddresses(): void;
    private handleValidation;
    protected setApplePayRequestConfig(transactionInput: ApplePayTransactionInput): Observable<ApplePayJS.ApplePayPaymentRequest>;
    private validateOpfAppleSession;
    private convertAppleToOpfAddress;
    private handleShippingContactSelected;
    private handlePaymentMethodSelected;
    private handleShippingMethodSelected;
    private handlePaymentAuthorized;
    private verifyApplePaySession;
    protected recordDeliveryAddress(addrId: string): void;
    private placeOrderAfterPayment;
    protected updateApplePayForm(total: {
        amount: string;
        label: string;
    }): {
        newTotal: {
            amount: string;
            label: string;
        };
    };
    protected getApplePayFormWithError(message: string, code?: string): {
        code: string;
        message: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<ApplePayService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ApplePayService>;
}

declare class ApplePayComponent implements OnInit {
    activeConfiguration: OpfActiveConfiguration | OpfActiveConfiguration[];
    protected applePayService: ApplePayService;
    protected currentProductService: CurrentProductService;
    protected opfQuickBuyTransactionService: OpfQuickBuyTransactionService;
    isApplePaySupported$: Observable<boolean>;
    applePayDigitalWallet?: OpfQuickBuyDigitalWallet;
    ngOnInit(): void;
    initActiveCartTransaction(): Observable<unknown>;
    initTransaction(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApplePayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ApplePayComponent, "cx-opf-apple-pay", never, { "activeConfiguration": { "alias": "activeConfiguration"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OpfApplePayModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfApplePayModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfApplePayModule, never, [typeof i1.CommonModule, typeof ApplePayComponent], [typeof ApplePayComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfApplePayModule>;
}

declare class OpfQuickBuyButtonsService {
    protected opfBaseFacade: OpfBaseFacade;
    protected checkoutConfig: CheckoutConfig;
    protected authService: AuthService;
    protected userIdService: UserIdService;
    protected cartGuestUserFacade: CartGuestUserFacade;
    protected activeCartFacade: ActiveCartFacade;
    protected multiCartFacade: MultiCartFacade;
    getPaymentGatewayConfiguration(): Observable<OpfActiveConfiguration | OpfActiveConfiguration[]>;
    getQuickBuyProviderConfig(provider: OpfQuickBuyProviderType, activeConfiguration: OpfActiveConfiguration | OpfActiveConfiguration[]): OpfQuickBuyDigitalWallet | undefined;
    isQuickBuyProviderEnabled(provider: OpfQuickBuyProviderType, activeConfiguration: OpfActiveConfiguration | OpfActiveConfiguration[]): boolean;
    getActiveConfigurationForProvider(provider: OpfQuickBuyProviderType, activeConfiguration: OpfActiveConfiguration | OpfActiveConfiguration[]): OpfActiveConfiguration | undefined;
    /**
     * Normalizes ActiveConfiguration to always return an array.
     * Returns empty array if configurations are null/undefined.
     */
    protected normalizeConfigurations(activeConfiguration: OpfActiveConfiguration | OpfActiveConfiguration[]): OpfActiveConfiguration[] | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyButtonsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfQuickBuyButtonsService>;
}

declare class OpfGooglePayService {
    protected opfResourceLoaderService: OpfResourceLoaderService;
    protected currentProductService: CurrentProductService;
    protected opfPaymentFacade: OpfPaymentFacade;
    protected opfQuickBuyTransactionService: OpfQuickBuyTransactionService;
    protected opfQuickBuyButtonsService: OpfQuickBuyButtonsService;
    protected opfQuickBuyConfig: OpfQuickBuyConfig;
    protected translationService: TranslationService;
    private googlePaymentClient;
    protected get googlePayProviderConfig(): OpfQuickBuyGooglePayProvider;
    private googlePaymentClientOptions;
    private initialGooglePaymentRequest;
    protected readonly defaultGooglePayCardParameters: any;
    private initialTransactionInfo;
    protected initialTransactionDetails: QuickBuyTransactionDetails;
    private googlePaymentRequest;
    protected transactionDetails: QuickBuyTransactionDetails;
    protected updateGooglePaymentClient(): void;
    protected setGooglePaymentRequestConfig(deliveryType: OpfQuickBuyDeliveryType, merchantName: string): void;
    loadResources(): Promise<void>;
    initClient(activeConfiguration: OpfActiveConfiguration | OpfActiveConfiguration[]): void;
    private getClient;
    isReadyToPay(): any;
    private updateTransactionInfo;
    private getShippingOptionParameters;
    private getNewTransactionInfo;
    private buildDisplayItems;
    private setDeliveryAddress;
    private setBillingAddress;
    setDeliveryMode(mode?: string, type?: OpfQuickBuyDeliveryType): Observable<DeliveryMode | undefined>;
    private convertAddress;
    handleActiveCartTransaction(): Observable<Cart>;
    protected loadActiveCartTransactionContext(): Observable<Cart>;
    protected configureActiveCartTransaction(deliveryInfo: OpfQuickBuyDeliveryInfo, merchantName: string): Observable<Cart>;
    protected updateActiveCartTransactionInfo(cart: Cart): Observable<Cart>;
    initTransaction(): void;
    renderPaymentButton(container: ElementRef): void;
    private handlePaymentCallbacks;
    protected authorizeGooglePayPayment(paymentDataResponse: any): Observable<boolean>;
    protected updateGuestUserEmailIfProvided(email?: string): Observable<boolean>;
    protected submitAuthorizedGooglePayPayment(paymentDataResponse: any): Observable<boolean>;
    private handleIntermediatePaymentDataChange;
    private updatePaymentDataForShippingChange;
    private mapCartToPaymentDataRequestUpdate;
    private buildPaymentDataRequestUpdate;
    protected verifyShippingOption(mode: string | undefined): string | undefined;
    protected associateAddressId(addressId: string): void;
    protected isAddressIdAssociated(addressId: string): boolean;
    protected resetAssociatedAddresses(): void;
    protected deleteAssociatedAddresses(): void;
    protected getFirstAndLastName(name: string): {
        firstName: string;
        lastName: string;
    };
    protected setAllowedPaymentMethodsConfig(activeConfiguration: OpfActiveConfiguration): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGooglePayService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfGooglePayService>;
}

declare class OpfGooglePayComponent implements OnInit {
    protected opfGooglePayService: OpfGooglePayService;
    protected changeDetectionRef: ChangeDetectorRef;
    activeConfiguration: OpfActiveConfiguration | OpfActiveConfiguration[];
    googlePayButtonContainer: ElementRef;
    isReadyToPayState$: BehaviorSubject<boolean>;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGooglePayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfGooglePayComponent, "cx-opf-google-pay", never, { "activeConfiguration": { "alias": "activeConfiguration"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OpfGooglePayModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfGooglePayModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfGooglePayModule, never, [typeof i1.CommonModule, typeof OpfGooglePayComponent], [typeof OpfGooglePayComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfGooglePayModule>;
}

declare class OpfQuickBuyButtonsComponent implements OnInit {
    protected opfQuickBuyButtonsService: OpfQuickBuyButtonsService;
    protected paymentGatewayConfig$: Observable<OpfActiveConfiguration | OpfActiveConfiguration[]>;
    PAYMENT_METHODS: typeof OpfQuickBuyProviderType;
    ngOnInit(): void;
    isPaymentMethodEnabled(provider: OpfQuickBuyProviderType, activeConfiguration: OpfActiveConfiguration | OpfActiveConfiguration[]): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyButtonsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpfQuickBuyButtonsComponent, "cx-opf-quick-buy-buttons", never, {}, {}, never, never, true, never>;
}

declare class OpfQuickBuyButtonsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyButtonsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfQuickBuyButtonsModule, never, [typeof i1.CommonModule, typeof OpfApplePayModule, typeof OpfGooglePayModule, typeof OpfQuickBuyButtonsComponent], [typeof OpfQuickBuyButtonsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfQuickBuyButtonsModule>;
}

declare class OpfQuickBuyComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfQuickBuyComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfQuickBuyComponentsModule, never, [typeof OpfQuickBuyButtonsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfQuickBuyComponentsModule>;
}

export { OpfQuickBuyComponentsModule };
