import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import { Converter, GlobalMessageService, RoutingService, WindowRef, UserIdService, QueryService, CommandService, Command } from '@spartacus/core';
import { OpfPaymentInitiationConfig, OpfPaymentVerificationPayload, OpfPaymentVerificationResponse, OpfPaymentSubmitRequest, OpfPaymentSubmitResponse, OpfPaymentSubmitCompleteResponse, OpfPaymentAfterRedirectScriptResponse, OpfPaymentSessionData, OpfPaymentUpdateConfig, OpfPaymentSubmitCompleteRequest, OpfPaymentError, OpfPaymentMerchantCallback, OpfPaymentSubmitInput, OpfPaymentSubmitCompleteInput, OpfPaymentFacade, OpfPaymentBrowserInfo } from '@spartacus/opf/payment/root';
import { Observable } from 'rxjs';
import { Cart, CartAccessCodeFacade, ActiveCartFacade } from '@spartacus/cart/base/root';
import { OrderFacade, Order } from '@spartacus/order/root';
import { OpfGlobalFunctionsFacade } from '@spartacus/opf/global-functions/root';

declare const OPF_PAYMENT_CONFIG_SERIALIZER: InjectionToken<Converter<OpfPaymentInitiationConfig, any>>;

declare abstract class OpfPaymentAdapter {
    /**
     * Abstract method to verify a response from PSP for Full Page Redirect
     * and iframe integration patterns.
     *
     */
    abstract verifyPayment(paymentSessionId: string, payload: OpfPaymentVerificationPayload): Observable<OpfPaymentVerificationResponse>;
    /**
     * Abstract method used to submit payment for hosted-fields pattern.
     *
     */
    abstract submitPayment(submitRequest: OpfPaymentSubmitRequest, otpKey: string, paymentSessionId: string): Observable<OpfPaymentSubmitResponse>;
    /**
     * Abstract method to submit-complete payment
     * for Hosted Fields pattern.
     *
     */
    abstract submitCompletePayment(submitRequest: OpfPaymentSubmitRequest, otpKey: string, paymentSessionId: string): Observable<OpfPaymentSubmitCompleteResponse>;
    /**
     * Abstract method to retrieve the dynamic scripts after redirect
     * used in hosted-fields pattern.
     *
     */
    abstract getAfterRedirectScripts(paymentSessionId: string): Observable<OpfPaymentAfterRedirectScriptResponse>;
    /**
     * Abstract method used to initiate payment session
     * or call the PSP to initiate.
     *
     */
    abstract initiatePayment(paymentConfig: OpfPaymentInitiationConfig): Observable<OpfPaymentSessionData>;
    /**
     * Abstract method used to update an existing payment transaction/session.
     *
     */
    abstract updatePaymentTransaction(updatePaymentConfig: OpfPaymentUpdateConfig): Observable<OpfPaymentSessionData>;
}

/**
 * Connector that facilitates communication between Spartacus Storefront and the OPF Commerce Cloud Adapter.
 * Handles payment session management, payment request submission, and payment flow orchestration
 * including redirects and verification processes required by the OPF payment system.
 */
declare class OpfPaymentConnector {
    protected adapter: OpfPaymentAdapter;
    verifyPayment(paymentSessionId: string, payload: OpfPaymentVerificationPayload): Observable<OpfPaymentVerificationResponse>;
    submitPayment(submitRequest: OpfPaymentSubmitRequest, otpKey: string, paymentSessionId: string): Observable<OpfPaymentSubmitResponse>;
    submitCompletePayment(submitCompleteRequest: OpfPaymentSubmitCompleteRequest, otpKey: string, paymentSessionId: string): Observable<OpfPaymentSubmitCompleteResponse>;
    getAfterRedirectScripts(paymentSessionId: string): Observable<OpfPaymentAfterRedirectScriptResponse>;
    initiatePayment(paymentConfig: OpfPaymentInitiationConfig): Observable<OpfPaymentSessionData>;
    updatePaymentTransaction(updatePaymentConfig: OpfPaymentUpdateConfig): Observable<OpfPaymentSessionData>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfPaymentConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfPaymentConnector>;
}

declare abstract class OpfPaymentOccAdapter {
    /**
     * Abstract method used to set payment option.
     *
     */
    abstract setCartPaymentOption(userId: string, cartId: string, sapPaymentOptionId: string, purchaseOrderNumber?: string): Observable<Cart>;
}

/**
 * This connector communicates with the OCC layer
 * to perform payment-related operations for a cart in SAP Commerce.
 * It acts as a bridge between Spartacus frontend and the backend OCC API
 * specifically for setting payment options on a cart.
 */
declare class OpfPaymentOccConnector {
    protected adapter: OpfPaymentOccAdapter;
    setCartPaymentOption(userId: string, cartId: string, sapPaymentOptionId: string, purchaseOrderNumber?: string): Observable<Cart>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfPaymentOccConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfPaymentOccConnector>;
}

declare class OpfPaymentErrorHandlerService {
    protected globalMessageService: GlobalMessageService;
    protected routingService: RoutingService;
    protected displayError(error: OpfPaymentError | undefined): void;
    protected handleBadRequestError(errorType?: string): string;
    handlePaymentError(error: OpfPaymentError | undefined, returnPath?: string, onFailureCallback?: OpfPaymentMerchantCallback): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfPaymentErrorHandlerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfPaymentErrorHandlerService>;
}

declare class OpfPaymentHostedFieldsService {
    protected opfPaymentConnector: OpfPaymentConnector;
    protected winRef: WindowRef;
    protected cartAccessCodeFacade: CartAccessCodeFacade;
    protected activeCartFacade: ActiveCartFacade;
    protected userIdService: UserIdService;
    protected routingService: RoutingService;
    protected orderFacade: OrderFacade;
    protected globalMessageService: GlobalMessageService;
    protected opfPaymentErrorHandlerService: OpfPaymentErrorHandlerService;
    protected globalFunctionsFacade: OpfGlobalFunctionsFacade;
    submitPayment(submitInput: OpfPaymentSubmitInput): Observable<boolean>;
    submitCompletePayment(submitCompleteInput: OpfPaymentSubmitCompleteInput): Observable<boolean>;
    protected paymentResponseHandler(response: OpfPaymentSubmitResponse | OpfPaymentSubmitCompleteResponse, callbacks: {
        onSuccess: OpfPaymentMerchantCallback;
        onPending: OpfPaymentMerchantCallback;
        onFailure: OpfPaymentMerchantCallback;
        onCancel?: OpfPaymentMerchantCallback;
    }, cartId?: string): Observable<Order>;
    protected getCartAccessCode(submitRequest: OpfPaymentSubmitRequest | OpfPaymentSubmitCompleteRequest, cartId?: string): Observable<[
        OpfPaymentSubmitRequest | OpfPaymentSubmitCompleteRequest,
        {
            accessCode: string;
        }
    ]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfPaymentHostedFieldsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfPaymentHostedFieldsService>;
}

declare class OpfPaymentService implements OpfPaymentFacade {
    protected queryService: QueryService;
    protected commandService: CommandService;
    protected opfPaymentConnector: OpfPaymentConnector;
    protected opfPaymentOccConnector: OpfPaymentOccConnector;
    protected opfPaymentHostedFieldsService: OpfPaymentHostedFieldsService;
    protected verifyPaymentCommand: Command<{
        paymentSessionId: string;
        paymentVerificationPayload: OpfPaymentVerificationPayload;
    }, OpfPaymentVerificationResponse>;
    protected submitPaymentCommand: Command<{
        submitInput: OpfPaymentSubmitInput;
    }, boolean>;
    protected submitCompletePaymentCommand: Command<{
        submitCompleteInput: OpfPaymentSubmitCompleteInput;
    }, boolean>;
    protected getAfterRedirectScriptsCommand: Command<{
        paymentSessionId: string;
    }, OpfPaymentAfterRedirectScriptResponse>;
    protected initiatePaymentCommand: Command<{
        paymentConfig: OpfPaymentInitiationConfig;
    }, OpfPaymentSessionData>;
    protected updatePaymentTransactionCommand: Command<{
        updatePaymentConfig: OpfPaymentUpdateConfig;
    }, OpfPaymentSessionData>;
    protected setCartPaymentOptionCommand: Command<{
        userId: string;
        cartId: string;
        sapPaymentOptionId: string;
        purchaseOrderNumber?: string;
    }, Cart>;
    verifyPayment(paymentSessionId: string, paymentVerificationPayload: OpfPaymentVerificationPayload): Observable<OpfPaymentVerificationResponse>;
    submitPayment(submitInput: OpfPaymentSubmitInput): Observable<boolean>;
    submitCompletePayment(submitCompleteInput: OpfPaymentSubmitCompleteInput): Observable<boolean>;
    getAfterRedirectScripts(paymentSessionId: string): Observable<OpfPaymentAfterRedirectScriptResponse>;
    initiatePayment(paymentConfig: OpfPaymentInitiationConfig): Observable<OpfPaymentSessionData>;
    updatePaymentTransaction(updatePaymentConfig: OpfPaymentUpdateConfig): Observable<OpfPaymentSessionData>;
    setCartPaymentOption(userId: string, cartId: string, sapPaymentOptionId: string, purchaseOrderNumber?: string): Observable<Cart>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfPaymentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpfPaymentService>;
}

declare class OpfPaymentCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpfPaymentCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpfPaymentCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpfPaymentCoreModule>;
}

declare const OPF_PAYMENT_VERIFICATION_NORMALIZER: InjectionToken<Converter<any, OpfPaymentVerificationResponse>>;
declare const OPF_PAYMENT_SUBMIT_NORMALIZER: InjectionToken<Converter<any, OpfPaymentSubmitResponse>>;
declare const OPF_PAYMENT_SUBMIT_COMPLETE_NORMALIZER: InjectionToken<Converter<any, OpfPaymentSubmitCompleteResponse>>;
declare const OPF_AFTER_REDIRECT_SCRIPTS_NORMALIZER: InjectionToken<Converter<any, OpfPaymentAfterRedirectScriptResponse>>;

declare function getBrowserInfo(nativeWindow: Window | undefined): OpfPaymentBrowserInfo;

export { OPF_AFTER_REDIRECT_SCRIPTS_NORMALIZER, OPF_PAYMENT_CONFIG_SERIALIZER, OPF_PAYMENT_SUBMIT_COMPLETE_NORMALIZER, OPF_PAYMENT_SUBMIT_NORMALIZER, OPF_PAYMENT_VERIFICATION_NORMALIZER, OpfPaymentAdapter, OpfPaymentConnector, OpfPaymentCoreModule, OpfPaymentErrorHandlerService, OpfPaymentHostedFieldsService, OpfPaymentOccAdapter, OpfPaymentOccConnector, OpfPaymentService, getBrowserInfo };
