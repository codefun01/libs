import { Config, VariantOptionQualifier, Image, Product, VariantMatrixElement } from '@spartacus/core';
import * as i0 from '@angular/core';

declare class ProductMultiDimensionalSelectorImagesService {
    protected config: Config;
    /**
     * Retrieves the image for variant option qualifiers that match the specified format.
     */
    getVariantOptionImage(variantOptionQualifiers: VariantOptionQualifier[], variantOptionValue: string): Image | undefined;
    protected getBaseUrl(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductMultiDimensionalSelectorImagesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductMultiDimensionalSelectorImagesService>;
}

type VariantCategoryOption = {
    value: string;
    code: string;
    image?: Image;
};
type VariantCategoryGroup = {
    name: string;
    variantOptions: VariantCategoryOption[];
    hasImages: boolean;
};

declare class ProductMultiDimensionalSelectorService {
    protected imagesService: ProductMultiDimensionalSelectorImagesService;
    /**
     * Retrieves variant categories for a given product, extracting options recursively
     * from the variant matrix and adjusting for currently selected elements.
     *
     * @param {Product} product - The product object containing variant data.
     * @returns {VariantCategoryGroup[]} - An array of variant categories with their options.
     *
     * @description
     * This method processes a product's variant matrix to create an array of variant categories,
     * each containing its respective options. It handles model conversions to ensure that the
     * returned data is structured appropriately for the UI. Without these conversions, the UI
     * would not be able to display the variant options correctly, and some attributes required
     * for navigation would be missing.
     *
     * @example
     * Given initially selected option "Blue 2 L":
     * Color:        Red             (Blue)
     * Size:      1     2         1      (2)
     * Fit:     M  L  M   L     M   L   M   (L)
     *
     * The method extracts all available colors (e.g., Red and Blue) and recursively retrieves options
     * until all variant options are exhausted, based on the currently selected options. For example the second row
     * contains multiple sizes of the same value, representing different products. Since the user can change
     * only one variant at a time, we need to identify only the products that reflect the current selections,
     * as shown in the tree with rows like (Blue), (2), (L).
     *
     * Color:        Red             (Blue)
     * Size:                       1      (2)
     * Fit:                              M   (L)
     *
     * @see checkIfEveryOptionHasImages
     * @see imagesService.getVariantOptionImage
     */
    getVariants(product: Product): VariantCategoryGroup[];
    /**
     * Checks if every variant option in the category has images.
     *
     * @param {VariantCategoryGroup[]} variantCategories - An array of variant categories.
     * @returns {VariantCategoryGroup[]} - An array of variant categories with updated image information.
     */
    protected checkIfEveryOptionHasImages(variantCategories: VariantCategoryGroup[]): VariantCategoryGroup[];
    /**
     * Creates a variant option category from a variant matrix element.
     *
     * @param {VariantMatrixElement} element - The variant matrix element.
     * @returns {VariantCategoryOption} - The variant category option.
     *
     * @description
     * This method converts a variant matrix element into a variant category option.
     * It extracts the variant category name, option qualifiers, and images to create
     * the appropriate data structure for the UI.
     *
     * @see imagesService.getVariantOptionImage
     */
    protected createVariantOptionCategory(element: VariantMatrixElement): VariantCategoryOption;
    /**
     * Creates a variant category group from a variant matrix.
     *
     * @param {VariantMatrixElement[]} elements - The variant matrix elements.
     * @returns {VariantCategoryGroup} - The variant category.
     *
     * @description
     * This method creates a variant category from the first element of a variant matrix.
     * The category name and image presence status (`hasImages`) are consistent for each
     * element in the array. It initializes the category's name, option list, and image presence status.
     */
    protected createVariantCategoryGroup(elements: VariantMatrixElement[]): VariantCategoryGroup;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductMultiDimensionalSelectorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductMultiDimensionalSelectorService>;
}

export { ProductMultiDimensionalSelectorImagesService, ProductMultiDimensionalSelectorService };
export type { VariantCategoryGroup, VariantCategoryOption };
