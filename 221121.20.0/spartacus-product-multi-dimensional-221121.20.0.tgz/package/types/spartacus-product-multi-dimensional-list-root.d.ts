import * as i0 from '@angular/core';
import * as i1 from '@spartacus/core';
import { Product } from '@spartacus/core';
import * as i2 from '@angular/common';
import * as i3 from '@spartacus/storefront';
import { ProductListItemContext } from '@spartacus/storefront';
import { Observable } from 'rxjs';

declare const PRODUCT_MULTI_DIMENSIONAL_LIST_FEATURE = "productMultiDimensionalList";

declare class ProductMultiDimensionalListItemDetailsComponent {
    productListItemContext?: ProductListItemContext;
    readonly product$: Observable<Product>;
    getProductPrice(product: Product): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductMultiDimensionalListItemDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductMultiDimensionalListItemDetailsComponent, "cx-product-multi-dimensional-list-item-details", never, {}, {}, never, never, true, never>;
}

declare class ProductMultiDimensionalListItemDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductMultiDimensionalListItemDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductMultiDimensionalListItemDetailsModule, never, [typeof i1.I18nModule, typeof i2.NgIf, typeof i2.AsyncPipe, typeof i3.StarRatingModule, typeof ProductMultiDimensionalListItemDetailsComponent], [typeof ProductMultiDimensionalListItemDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductMultiDimensionalListItemDetailsModule>;
}

declare function defaultProductMultiDimensionalListConfig(): {
    featureModules: {
        productMultiDimensionalList: {
            cmsComponents: string[];
        };
    };
};
declare class ProductMultiDimensionalListRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductMultiDimensionalListRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductMultiDimensionalListRootModule, never, [typeof ProductMultiDimensionalListItemDetailsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductMultiDimensionalListRootModule>;
}

export { PRODUCT_MULTI_DIMENSIONAL_LIST_FEATURE, ProductMultiDimensionalListItemDetailsComponent, ProductMultiDimensionalListItemDetailsModule, ProductMultiDimensionalListRootModule, defaultProductMultiDimensionalListConfig };
