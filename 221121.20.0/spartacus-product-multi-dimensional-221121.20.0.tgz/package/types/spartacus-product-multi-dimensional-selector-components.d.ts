import * as i2 from '@angular/router';
import { Router, ActivatedRouteSnapshot, GuardResult, ActivatedRoute } from '@angular/router';
import * as i3 from '@spartacus/core';
import { ProductService, SemanticPathService, Product, RoutingService, TranslationService } from '@spartacus/core';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';
import * as i4 from '@spartacus/storefront';
import { CurrentProductService } from '@spartacus/storefront';
import * as i5 from '@ng-select/ng-select';
import * as i6 from '@angular/forms';
import { ProductMultiDimensionalSelectorService, VariantCategoryGroup, VariantCategoryOption } from '@spartacus/product-multi-dimensional/selector/core';

/**
 * Guard that ensures a product is valid and navigable within a multi-dimensional context.
 *
 * This guard manages navigation and access control for products in a multi-dimensional product catalog.
 * It verifies that the product specified in the route is valid and has the necessary attributes for display.
 * If the product is not purchasable and has variant options, the guard attempts to find a valid product code
 * from the available variants and redirects to the appropriate variant product URL.
 *
 * Without this guard, users could access a product detail page (PDP) for products that are not available for purchase.
 */
declare class ProductMultiDimensionalSelectorGuard {
    protected productService: ProductService;
    protected semanticPathService: SemanticPathService;
    protected router: Router;
    canActivate(activatedRoute: ActivatedRouteSnapshot): Observable<GuardResult>;
    /**
     * Finds a valid product code from variant options and returns a URL tree for redirection.
     *
     * @param {Product} product - The product with variant options.
     * @returns {Observable<GuardResult>} - An observable that resolves to a `UrlTree` for
     * redirection if a valid product code is found, or `false` if no valid code is available.
     *
     * @description
     * This method examines the product's variant options to find one with available stock. If a valid
     * variant is found, it fetches the corresponding product and generates a URL for redirection. If
     * no valid variant code is found, it resolves to `false`.
     */
    protected findValidProductCodeAndReturnUrlTree(product: Product): Observable<GuardResult>;
    protected getValidVariantCode(product: Product): string | undefined;
    protected getFallbackProductCode(product: Product): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductMultiDimensionalSelectorGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductMultiDimensionalSelectorGuard>;
}

declare class ProductMultiDimensionalSelectorComponent {
    protected multiDimensionalService: ProductMultiDimensionalSelectorService;
    protected productService: ProductService;
    protected routingService: RoutingService;
    protected route: ActivatedRoute;
    protected currentProductService: CurrentProductService;
    protected translationService: TranslationService;
    selectedProductCode: string;
    categories: VariantCategoryGroup[];
    product$: Observable<Product>;
    changeVariant(code: string | undefined): void;
    getSelectedValue(categoryName: string): string;
    onAriaLabel(option: VariantCategoryOption, categoryName: string): Observable<string>;
    getCategoryName(category: VariantCategoryGroup): string;
    protected isSelected(code: string): boolean;
    protected getVariants(product: Product): VariantCategoryGroup[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductMultiDimensionalSelectorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductMultiDimensionalSelectorComponent, "cx-product-multi-dimensional-selector", never, {}, {}, never, never, true, never>;
}

declare class ProductMultiDimensionalSelectorComponentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductMultiDimensionalSelectorComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductMultiDimensionalSelectorComponentModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i3.UrlModule, typeof i4.MediaModule, typeof i4.KeyboardFocusModule, typeof i5.NgSelectModule, typeof i6.FormsModule, typeof i4.NgSelectA11yModule, typeof i3.I18nModule, typeof ProductMultiDimensionalSelectorComponent], [typeof ProductMultiDimensionalSelectorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductMultiDimensionalSelectorComponentModule>;
}

declare class ProductMultiDimensionalSelectorComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductMultiDimensionalSelectorComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductMultiDimensionalSelectorComponentsModule, never, [typeof ProductMultiDimensionalSelectorComponentModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductMultiDimensionalSelectorComponentsModule>;
}

export { ProductMultiDimensionalSelectorComponent, ProductMultiDimensionalSelectorComponentModule, ProductMultiDimensionalSelectorComponentsModule, ProductMultiDimensionalSelectorGuard };
