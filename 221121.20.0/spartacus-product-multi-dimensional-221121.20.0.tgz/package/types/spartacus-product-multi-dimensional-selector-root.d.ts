import * as i0 from '@angular/core';
import { VariantQualifier } from '@spartacus/core';

declare function defaultProductMultiDimensionalSelectorComponentsConfig(): {
    featureModules: {
        productMultiDimensionalSelector: {
            cmsComponents: string[];
        };
    };
};
declare class ProductMultiDimensionalSelectorRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductMultiDimensionalSelectorRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductMultiDimensionalSelectorRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductMultiDimensionalSelectorRootModule>;
}

declare const PRODUCT_MULTI_DIMENSIONAL_SELECTOR_FEATURE = "productMultiDimensionalSelector";

declare class ProductMultiDimensionalConfig {
    multiDimensional?: {
        imageFormat?: VariantQualifier;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductMultiDimensionalConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProductMultiDimensionalConfig>;
}
declare module '@spartacus/core' {
    interface Config extends ProductMultiDimensionalConfig {
    }
}

declare const defaultProductMultiDimensionalConfig: ProductMultiDimensionalConfig;

export { PRODUCT_MULTI_DIMENSIONAL_SELECTOR_FEATURE, ProductMultiDimensionalConfig, ProductMultiDimensionalSelectorRootModule, defaultProductMultiDimensionalConfig, defaultProductMultiDimensionalSelectorComponentsConfig };
