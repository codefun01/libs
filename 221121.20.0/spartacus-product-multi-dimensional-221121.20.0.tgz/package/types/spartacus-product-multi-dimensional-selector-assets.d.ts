import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    multiDimensionalSelector: {
        multiDimensionalSelector: {
            variantThumbnailTitle: string;
            selectedVariant: string;
        };
    };
};

declare const de: {
    multiDimensionalSelector: {
        multiDimensionalSelector: {
            variantThumbnailTitle: string;
            selectedVariant: string;
        };
    };
};

declare const en: {
    multiDimensionalSelector: {
        multiDimensionalSelector: {
            variantThumbnailTitle: string;
            selectedVariant: string;
        };
    };
};

declare const es: {
    multiDimensionalSelector: {
        multiDimensionalSelector: {
            variantThumbnailTitle: string;
            selectedVariant: string;
        };
    };
};

declare const es_CO: {
    multiDimensionalSelector: {
        multiDimensionalSelector: {
            variantThumbnailTitle: string;
            selectedVariant: string;
        };
    };
};

declare const fr: {
    multiDimensionalSelector: {
        multiDimensionalSelector: {
            variantThumbnailTitle: string;
            selectedVariant: string;
        };
    };
};

declare const hi: {
    multiDimensionalSelector: {
        multiDimensionalSelector: {
            variantThumbnailTitle: string;
            selectedVariant: string;
        };
    };
};

declare const hu: {
    multiDimensionalSelector: {
        multiDimensionalSelector: {
            variantThumbnailTitle: string;
            selectedVariant: string;
        };
    };
};

declare const id: {
    multiDimensionalSelector: {
        multiDimensionalSelector: {
            variantThumbnailTitle: string;
            selectedVariant: string;
        };
    };
};

declare const it: {
    multiDimensionalSelector: {
        multiDimensionalSelector: {
            variantThumbnailTitle: string;
            selectedVariant: string;
        };
    };
};

declare const ja: {
    multiDimensionalSelector: {
        multiDimensionalSelector: {
            variantThumbnailTitle: string;
            selectedVariant: string;
        };
    };
};

declare const ko: {
    multiDimensionalSelector: {
        multiDimensionalSelector: {
            variantThumbnailTitle: string;
            selectedVariant: string;
        };
    };
};

declare const pl: {
    multiDimensionalSelector: {
        multiDimensionalSelector: {
            variantThumbnailTitle: string;
            selectedVariant: string;
        };
    };
};

declare const pt: {
    multiDimensionalSelector: {
        multiDimensionalSelector: {
            variantThumbnailTitle: string;
            selectedVariant: string;
        };
    };
};

declare const ru: {
    multiDimensionalSelector: {
        multiDimensionalSelector: {
            variantThumbnailTitle: string;
            selectedVariant: string;
        };
    };
};

declare const zh: {
    multiDimensionalSelector: {
        multiDimensionalSelector: {
            variantThumbnailTitle: string;
            selectedVariant: string;
        };
    };
};

declare const zh_TW: {
    multiDimensionalSelector: {
        multiDimensionalSelector: {
            variantThumbnailTitle: string;
            selectedVariant: string;
        };
    };
};

declare const multiDimensionalSelectorTranslationChunksConfig: TranslationChunksConfig;

export { multiDimensionalSelectorTranslationChunksConfig, cs as multiDimensionalSelectorTranslationsCs, de as multiDimensionalSelectorTranslationsDe, en as multiDimensionalSelectorTranslationsEn, es as multiDimensionalSelectorTranslationsEs, es_CO as multiDimensionalSelectorTranslationsEs_CO, fr as multiDimensionalSelectorTranslationsFr, hi as multiDimensionalSelectorTranslationsHi, hu as multiDimensionalSelectorTranslationsHu, id as multiDimensionalSelectorTranslationsId, it as multiDimensionalSelectorTranslationsIt, ja as multiDimensionalSelectorTranslationsJa, ko as multiDimensionalSelectorTranslationsKo, pl as multiDimensionalSelectorTranslationsPl, pt as multiDimensionalSelectorTranslationsPt, ru as multiDimensionalSelectorTranslationsRu, zh as multiDimensionalSelectorTranslationsZh, zh_TW as multiDimensionalSelectorTranslationsZh_TW };
