import * as i0 from '@angular/core';
import * as i1 from '@angular/common';
import * as i2 from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import * as i3 from '@spartacus/core';
import { ProductService, RoutingService, TranslationService, Product } from '@spartacus/core';
import * as i4 from '@spartacus/storefront';
import { CurrentProductService } from '@spartacus/storefront';
import * as i5 from '@ng-select/ng-select';
import * as i6 from '@angular/forms';
import { ProductMultiDimensionalSelectorService, VariantCategoryGroup, VariantCategoryOption } from '@spartacus/product-multi-dimensional/selector/core';
import { Observable } from 'rxjs';

declare class ProductMultiDimensionalSelectorOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductMultiDimensionalSelectorOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductMultiDimensionalSelectorOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductMultiDimensionalSelectorOccModule>;
}

declare class ProductMultiDimensionalSelectorComponent {
    protected multiDimensionalService: ProductMultiDimensionalSelectorService;
    protected productService: ProductService;
    protected routingService: RoutingService;
    protected route: ActivatedRoute;
    protected currentProductService: CurrentProductService;
    protected translationService: TranslationService;
    selectedProductCode: string;
    categories: VariantCategoryGroup[];
    product$: Observable<Product>;
    changeVariant(code: string | undefined): void;
    getSelectedValue(categoryName: string): string;
    onAriaLabel(option: VariantCategoryOption, categoryName: string): Observable<string>;
    getCategoryName(category: VariantCategoryGroup): string;
    protected isSelected(code: string): boolean;
    protected getVariants(product: Product): VariantCategoryGroup[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductMultiDimensionalSelectorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProductMultiDimensionalSelectorComponent, "cx-product-multi-dimensional-selector", never, {}, {}, never, never, true, never>;
}

declare class ProductMultiDimensionalSelectorComponentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductMultiDimensionalSelectorComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductMultiDimensionalSelectorComponentModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i3.UrlModule, typeof i4.MediaModule, typeof i4.KeyboardFocusModule, typeof i5.NgSelectModule, typeof i6.FormsModule, typeof i4.NgSelectA11yModule, typeof i3.I18nModule, typeof ProductMultiDimensionalSelectorComponent], [typeof ProductMultiDimensionalSelectorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductMultiDimensionalSelectorComponentModule>;
}

declare class ProductMultiDimensionalSelectorComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductMultiDimensionalSelectorComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductMultiDimensionalSelectorComponentsModule, never, [typeof ProductMultiDimensionalSelectorComponentModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductMultiDimensionalSelectorComponentsModule>;
}

declare class ProductMultiDimensionalSelectorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductMultiDimensionalSelectorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductMultiDimensionalSelectorModule, never, [typeof ProductMultiDimensionalSelectorOccModule, typeof ProductMultiDimensionalSelectorComponentsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductMultiDimensionalSelectorModule>;
}

export { ProductMultiDimensionalSelectorModule };
