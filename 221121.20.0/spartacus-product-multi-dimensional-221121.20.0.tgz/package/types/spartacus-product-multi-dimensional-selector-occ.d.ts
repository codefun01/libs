import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare class ProductMultiDimensionalSelectorOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProductMultiDimensionalSelectorOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProductMultiDimensionalSelectorOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProductMultiDimensionalSelectorOccModule>;
}

export { ProductMultiDimensionalSelectorOccModule };
