import * as i0 from '@angular/core';
import { inject, Injectable, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { ProductService, SemanticPathService, ProductScope, isNotUndefined, RoutingService, TranslationService, isNotNullable, TranslatePipe, UrlModule, I18nModule, provideDefaultConfig } from '@spartacus/core';
import { of } from 'rxjs';
import { filter, switchMap, take, map, distinctUntilChanged, shareReplay, tap } from 'rxjs/operators';
import { NgIf, NgFor, NgClass, AsyncPipe, CommonModule } from '@angular/common';
import * as i1 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { NgSelectComponent, NgSelectModule } from '@ng-select/ng-select';
import { CurrentProductService, FocusDirective, MediaComponent, NgSelectA11yDirective, MediaModule, KeyboardFocusModule, NgSelectA11yModule } from '@spartacus/storefront';
import { ProductMultiDimensionalSelectorService } from '@spartacus/product-multi-dimensional/selector/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Guard that ensures a product is valid and navigable within a multi-dimensional context.
 *
 * This guard manages navigation and access control for products in a multi-dimensional product catalog.
 * It verifies that the product specified in the route is valid and has the necessary attributes for display.
 * If the product is not purchasable and has variant options, the guard attempts to find a valid product code
 * from the available variants and redirects to the appropriate variant product URL.
 *
 * Without this guard, users could access a product detail page (PDP) for products that are not available for purchase.
 */
class ProductMultiDimensionalSelectorGuard {
    constructor() {
        this.productService = inject(ProductService);
        this.semanticPathService = inject(SemanticPathService);
        this.router = inject(Router);
    }
    canActivate(activatedRoute) {
        const productCode = activatedRoute.params?.productCode;
        if (!productCode) {
            // Refuse entry unless it is within a SmartEdit environment
            return of(!!activatedRoute.queryParams?.cmsTicketId);
        }
        return this.productService
            .get(productCode, ProductScope.MULTI_DIMENSIONAL_AVAILABILITY)
            .pipe(filter(isNotUndefined), switchMap((multiDimensionalProduct) => {
            const isNotPurchasableAndHasVariantOptions = !multiDimensionalProduct.purchasable &&
                !!multiDimensionalProduct.variantOptions?.length;
            return isNotPurchasableAndHasVariantOptions
                ? this.findValidProductCodeAndReturnUrlTree(multiDimensionalProduct)
                : of(!!multiDimensionalProduct.purchasable);
        }));
    }
    /**
     * Finds a valid product code from variant options and returns a URL tree for redirection.
     *
     * @param {Product} product - The product with variant options.
     * @returns {Observable<GuardResult>} - An observable that resolves to a `UrlTree` for
     * redirection if a valid product code is found, or `false` if no valid code is available.
     *
     * @description
     * This method examines the product's variant options to find one with available stock. If a valid
     * variant is found, it fetches the corresponding product and generates a URL for redirection. If
     * no valid variant code is found, it resolves to `false`.
     */
    findValidProductCodeAndReturnUrlTree(product) {
        const validVariantCode = this.getValidVariantCode(product);
        const fallbackProductCode = this.getFallbackProductCode(product);
        const productCode = validVariantCode ?? fallbackProductCode;
        if (productCode) {
            return this.productService.get(productCode, ProductScope.LIST).pipe(filter(isNotUndefined), take(1), map((multiDimensionalProduct) => this.router.createUrlTree(this.semanticPathService.transform({
                cxRoute: 'product',
                params: multiDimensionalProduct,
            }))));
        }
        return of(false);
    }
    getValidVariantCode(product) {
        return product.variantOptions?.find((variant) => variant.stock && variant.stock.stockLevel)?.code;
    }
    getFallbackProductCode(product) {
        return product.variantOptions?.length
            ? product.variantOptions[0]?.code
            : '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorGuard, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ProductMultiDimensionalSelectorComponent {
    constructor() {
        this.multiDimensionalService = inject(ProductMultiDimensionalSelectorService);
        this.productService = inject(ProductService);
        this.routingService = inject(RoutingService);
        this.route = inject(ActivatedRoute);
        this.currentProductService = inject(CurrentProductService);
        this.translationService = inject(TranslationService);
        this.categories = [];
        this.product$ = this.currentProductService
            .getProduct(ProductScope.MULTI_DIMENSIONAL)
            .pipe(filter(isNotNullable), filter((product) => !!product.multidimensional), distinctUntilChanged(), shareReplay(1), tap((product) => {
            this.categories = this.getVariants(product);
            this.selectedProductCode = product.code ?? '';
        }));
    }
    changeVariant(code) {
        if (code) {
            this.productService
                .get(code, ProductScope.LIST)
                .pipe(filter(Boolean), take(1))
                .subscribe((product) => {
                this.routingService.go({
                    cxRoute: 'product',
                    params: product,
                });
            });
        }
    }
    getSelectedValue(categoryName) {
        const category = this.categories.find((cat) => cat.name === categoryName);
        if (category && this.selectedProductCode) {
            const selectedOption = category.variantOptions.find((option) => option.code === this.selectedProductCode);
            return selectedOption ? selectedOption.value : '';
        }
        return '';
    }
    onAriaLabel(option, categoryName) {
        const isSelected = this.isSelected(option.code);
        if (isSelected) {
            return this.translationService
                .translate('multiDimensionalSelector.selectedVariant')
                .pipe(map((text) => `${text}, ${option.value} ${categoryName}`));
        }
        return this.translationService
            .translate('multiDimensionalSelector.variantThumbnailTitle', {
            value: option.value,
            category: categoryName,
        })
            .pipe(map((text) => `${text}`));
    }
    getCategoryName(category) {
        const label = `${category.name}: `;
        if (category.hasImages) {
            const selectedValue = this.getSelectedValue(category.name);
            return `${label}${selectedValue ?? ''}`;
        }
        return label;
    }
    isSelected(code) {
        return code === this.selectedProductCode;
    }
    getVariants(product) {
        return this.multiDimensionalService.getVariants(product);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: ProductMultiDimensionalSelectorComponent, isStandalone: true, selector: "cx-product-multi-dimensional-selector", ngImport: i0, template: "<ng-container *ngIf=\"product$ | async as product\">\n  <div class=\"variant-generic-selector\">\n    <ng-container *ngFor=\"let category of categories\">\n      <label>\n        <span>\n          {{ getCategoryName(category) }}\n        </span>\n\n        <div\n          *ngIf=\"category.hasImages; else noImages\"\n          role=\"list\"\n          [attr.aria-label]=\"category.name\"\n          class=\"image-variant-container\"\n        >\n          <div *ngFor=\"let option of category.variantOptions\" role=\"listitem\">\n            <button\n              type=\"button\"\n              class=\"image-variant\"\n              [ngClass]=\"{ active: option?.code === product.code }\"\n              [attr.aria-label]=\"onAriaLabel(option, category.name) | async\"\n              (click)=\"changeVariant(option.code)\"\n              [cxFocus]=\"{ key: option.code }\"\n            >\n              <cx-media [container]=\"option.image\" role=\"img\" />\n            </button>\n          </div>\n        </div>\n      </label>\n\n      <ng-template #noImages>\n        <div class=\"select-variant-container\">\n          <ng-select\n            [clearable]=\"false\"\n            [searchable]=\"false\"\n            [items]=\"category.variantOptions\"\n            [(ngModel)]=\"selectedProductCode\"\n            (change)=\"changeVariant($event.code)\"\n            ariaLabelDropdown=\"{{\n              'common.ngSelectDropdownOptionsList' | cxTranslate\n            }}\"\n            [cxNgSelectA11y]=\"{\n              ariaLabel:\n                ('multiDimensionalSelector.variantThumbnailTitle'\n                | cxTranslate\n                  : {\n                      category: category.name,\n                    }),\n            }\"\n            bindValue=\"code\"\n            bindLabel=\"value\"\n          />\n        </div>\n      </ng-template>\n    </ng-container>\n  </div>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "component", type: MediaComponent, selector: "cx-media", inputs: ["container", "format", "alt", "role", "loading", "fetchPriority", "elementType", "sizesForImgElement"], outputs: ["loaded"] }, { kind: "component", type: NgSelectComponent, selector: "ng-select", inputs: ["ariaLabelDropdown", "ariaLabel", "markFirst", "placeholder", "fixedPlaceholder", "notFoundText", "typeToSearchText", "preventToggleOnRightClick", "addTagText", "loadingText", "clearAllText", "dropdownPosition", "appendTo", "outsideClickEvent", "loading", "closeOnSelect", "hideSelected", "selectOnTab", "openOnEnter", "maxSelectedItems", "groupBy", "groupValue", "bufferAmount", "virtualScroll", "selectableGroup", "tabFocusOnClearButton", "selectableGroupAsModel", "searchFn", "trackByFn", "clearOnBackspace", "labelForId", "inputAttrs", "tabIndex", "readonly", "searchWhileComposing", "minTermLength", "editableSearchTerm", "ngClass", "typeahead", "multiple", "addTag", "searchable", "clearable", "clearKeepsDisabledOptions", "deselectOnClick", "clearSearchOnAdd", "compareWith", "keyDownFn", "popover", "bindLabel", "bindValue", "appearance", "isOpen", "items"], outputs: ["bindLabelChange", "bindValueChange", "appearanceChange", "isOpenChange", "itemsChange", "blur", "focus", "change", "open", "close", "search", "clear", "add", "remove", "scroll", "scrollToEnd"], exportAs: ["ngSelect"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: NgSelectA11yDirective, selector: "[cxNgSelectA11y]", inputs: ["cxNgSelectA11y"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-product-multi-dimensional-selector', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        NgFor,
                        NgClass,
                        FocusDirective,
                        MediaComponent,
                        NgSelectComponent,
                        FormsModule,
                        NgSelectA11yDirective,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<ng-container *ngIf=\"product$ | async as product\">\n  <div class=\"variant-generic-selector\">\n    <ng-container *ngFor=\"let category of categories\">\n      <label>\n        <span>\n          {{ getCategoryName(category) }}\n        </span>\n\n        <div\n          *ngIf=\"category.hasImages; else noImages\"\n          role=\"list\"\n          [attr.aria-label]=\"category.name\"\n          class=\"image-variant-container\"\n        >\n          <div *ngFor=\"let option of category.variantOptions\" role=\"listitem\">\n            <button\n              type=\"button\"\n              class=\"image-variant\"\n              [ngClass]=\"{ active: option?.code === product.code }\"\n              [attr.aria-label]=\"onAriaLabel(option, category.name) | async\"\n              (click)=\"changeVariant(option.code)\"\n              [cxFocus]=\"{ key: option.code }\"\n            >\n              <cx-media [container]=\"option.image\" role=\"img\" />\n            </button>\n          </div>\n        </div>\n      </label>\n\n      <ng-template #noImages>\n        <div class=\"select-variant-container\">\n          <ng-select\n            [clearable]=\"false\"\n            [searchable]=\"false\"\n            [items]=\"category.variantOptions\"\n            [(ngModel)]=\"selectedProductCode\"\n            (change)=\"changeVariant($event.code)\"\n            ariaLabelDropdown=\"{{\n              'common.ngSelectDropdownOptionsList' | cxTranslate\n            }}\"\n            [cxNgSelectA11y]=\"{\n              ariaLabel:\n                ('multiDimensionalSelector.variantThumbnailTitle'\n                | cxTranslate\n                  : {\n                      category: category.name,\n                    }),\n            }\"\n            bindValue=\"code\"\n            bindLabel=\"value\"\n          />\n        </div>\n      </ng-template>\n    </ng-container>\n  </div>\n</ng-container>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ProductMultiDimensionalSelectorComponentModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorComponentModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorComponentModule, imports: [CommonModule,
            RouterModule,
            UrlModule,
            MediaModule,
            KeyboardFocusModule,
            NgSelectModule,
            FormsModule,
            NgSelectA11yModule,
            I18nModule,
            ProductMultiDimensionalSelectorComponent], exports: [ProductMultiDimensionalSelectorComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorComponentModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    ProductMultiDimensionalSelectorComponent: {
                        component: ProductMultiDimensionalSelectorComponent,
                        guards: [ProductMultiDimensionalSelectorGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            RouterModule,
            UrlModule,
            MediaModule,
            KeyboardFocusModule,
            NgSelectModule,
            FormsModule,
            NgSelectA11yModule,
            I18nModule,
            ProductMultiDimensionalSelectorComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorComponentModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        UrlModule,
                        MediaModule,
                        KeyboardFocusModule,
                        NgSelectModule,
                        FormsModule,
                        NgSelectA11yModule,
                        I18nModule,
                        ProductMultiDimensionalSelectorComponent,
                    ],
                    exports: [ProductMultiDimensionalSelectorComponent],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                ProductMultiDimensionalSelectorComponent: {
                                    component: ProductMultiDimensionalSelectorComponent,
                                    guards: [ProductMultiDimensionalSelectorGuard],
                                },
                            },
                        }),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ProductMultiDimensionalSelectorComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorComponentsModule, imports: [ProductMultiDimensionalSelectorComponentModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorComponentsModule, imports: [ProductMultiDimensionalSelectorComponentModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [ProductMultiDimensionalSelectorComponentModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ProductMultiDimensionalSelectorComponent, ProductMultiDimensionalSelectorComponentModule, ProductMultiDimensionalSelectorComponentsModule, ProductMultiDimensionalSelectorGuard };
//# sourceMappingURL=spartacus-product-multi-dimensional-selector-components.mjs.map
