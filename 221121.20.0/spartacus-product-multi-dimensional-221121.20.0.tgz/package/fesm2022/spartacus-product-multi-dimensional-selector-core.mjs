import * as i0 from '@angular/core';
import { inject, Injectable } from '@angular/core';
import { Config } from '@spartacus/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ProductMultiDimensionalSelectorImagesService {
    constructor() {
        this.config = inject(Config);
    }
    /**
     * Retrieves the image for variant option qualifiers that match the specified format.
     */
    getVariantOptionImage(variantOptionQualifiers, variantOptionValue) {
        const format = this.config
            .multiDimensional?.imageFormat;
        const optionImage = variantOptionQualifiers.find((optionQualifier) => optionQualifier.image?.format === format);
        const altText = optionImage?.image?.altText ?? variantOptionValue;
        return optionImage
            ? {
                altText,
                url: this.getBaseUrl() + optionImage?.image?.url,
            }
            : undefined;
    }
    getBaseUrl() {
        return (this.config.backend?.media?.baseUrl ??
            this.config.backend?.occ?.baseUrl ??
            '');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorImagesService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorImagesService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorImagesService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ProductMultiDimensionalSelectorService {
    constructor() {
        this.imagesService = inject(ProductMultiDimensionalSelectorImagesService);
    }
    /**
     * Retrieves variant categories for a given product, extracting options recursively
     * from the variant matrix and adjusting for currently selected elements.
     *
     * @param {Product} product - The product object containing variant data.
     * @returns {VariantCategoryGroup[]} - An array of variant categories with their options.
     *
     * @description
     * This method processes a product's variant matrix to create an array of variant categories,
     * each containing its respective options. It handles model conversions to ensure that the
     * returned data is structured appropriately for the UI. Without these conversions, the UI
     * would not be able to display the variant options correctly, and some attributes required
     * for navigation would be missing.
     *
     * @example
     * Given initially selected option "Blue 2 L":
     * Color:        Red             (Blue)
     * Size:      1     2         1      (2)
     * Fit:     M  L  M   L     M   L   M   (L)
     *
     * The method extracts all available colors (e.g., Red and Blue) and recursively retrieves options
     * until all variant options are exhausted, based on the currently selected options. For example the second row
     * contains multiple sizes of the same value, representing different products. Since the user can change
     * only one variant at a time, we need to identify only the products that reflect the current selections,
     * as shown in the tree with rows like (Blue), (2), (L).
     *
     * Color:        Red             (Blue)
     * Size:                       1      (2)
     * Fit:                              M   (L)
     *
     * @see checkIfEveryOptionHasImages
     * @see imagesService.getVariantOptionImage
     */
    getVariants(product) {
        let variantMatrix = product.variantMatrix ?? [];
        /** Levels determines the depth of the variantMatrix  */
        const levels = product.categories ?? [];
        const code = product.code ?? '';
        const variantCategories = [];
        levels.forEach((_) => {
            const variantCategoryGroup = this.createVariantCategoryGroup(variantMatrix);
            variantMatrix.forEach((element) => {
                const variantOptionCategory = this.createVariantOptionCategory(element);
                variantCategoryGroup.variantOptions.push(variantOptionCategory);
                /** Check if the current element has child elements and is in the currently selected branch */
                if (element.variantOption?.code === code && element.elements?.length) {
                    /**
                     * Update the variantMatrix to reflect the currently selected elements.
                     * For example, when navigating through the Color category,
                     * adjust the matrix to represent the Size options
                     * available within the Blue branch. The left branch (Red) is discarded as
                     * it does not contain the currently selected product.
                     *
                     * Color:        Red             (Blue)
                     * Size:      _1_     _2_      1      (2)
                     */
                    variantMatrix = element.elements;
                }
            });
            variantCategories.push(variantCategoryGroup);
        });
        return this.checkIfEveryOptionHasImages(variantCategories);
    }
    /**
     * Checks if every variant option in the category has images.
     *
     * @param {VariantCategoryGroup[]} variantCategories - An array of variant categories.
     * @returns {VariantCategoryGroup[]} - An array of variant categories with updated image information.
     */
    checkIfEveryOptionHasImages(variantCategories) {
        return variantCategories.map((variantCategoryGroup) => {
            const variantOptions = variantCategoryGroup.variantOptions;
            const hasImages = variantCategoryGroup.hasImages &&
                variantOptions.every((option) => !!option.image);
            return {
                ...variantCategoryGroup,
                variantOptions,
                hasImages,
            };
        });
    }
    /**
     * Creates a variant option category from a variant matrix element.
     *
     * @param {VariantMatrixElement} element - The variant matrix element.
     * @returns {VariantCategoryOption} - The variant category option.
     *
     * @description
     * This method converts a variant matrix element into a variant category option.
     * It extracts the variant category name, option qualifiers, and images to create
     * the appropriate data structure for the UI.
     *
     * @see imagesService.getVariantOptionImage
     */
    createVariantOptionCategory(element) {
        const variantCategoryName = element.variantValueCategory?.name ?? '';
        const variantOptionQualifiers = element.variantOption?.variantOptionQualifiers ?? [];
        const image = this.imagesService.getVariantOptionImage(variantOptionQualifiers, variantCategoryName);
        return {
            image,
            value: variantCategoryName,
            code: element.variantOption?.code ?? '',
        };
    }
    /**
     * Creates a variant category group from a variant matrix.
     *
     * @param {VariantMatrixElement[]} elements - The variant matrix elements.
     * @returns {VariantCategoryGroup} - The variant category.
     *
     * @description
     * This method creates a variant category from the first element of a variant matrix.
     * The category name and image presence status (`hasImages`) are consistent for each
     * element in the array. It initializes the category's name, option list, and image presence status.
     */
    createVariantCategoryGroup(elements) {
        const parentVariantCategory = elements.length
            ? elements[0]?.parentVariantCategory
            : undefined;
        return {
            name: parentVariantCategory?.name ?? '',
            variantOptions: [],
            hasImages: !!parentVariantCategory?.hasImage,
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ProductMultiDimensionalSelectorImagesService, ProductMultiDimensionalSelectorService };
//# sourceMappingURL=spartacus-product-multi-dimensional-selector-core.mjs.map
