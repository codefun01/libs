import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { provideDefaultConfig } from '@spartacus/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const elements = 'variantOption(code,variantOptionQualifiers(image(url,format))),variantValueCategory(name),parentVariantCategory(hasImage,name)';
const variantMatrix = `variantMatrix(${elements},elements(${elements},elements(${elements},elements)))`;
const defaultOccProductMultiDimensionalSelectorConfig = {
    backend: {
        occ: {
            endpoints: {
                product: {
                    multi_dimensional: 'products/${productCode}?fields=multidimensional,categories,' +
                        variantMatrix,
                    multi_dimensional_availability: 'products/${productCode}?fields=variantOptions(stock(stockLevel),code),purchasable',
                },
            },
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ProductMultiDimensionalSelectorOccModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorOccModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorOccModule, imports: [CommonModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorOccModule, providers: [
            provideDefaultConfig(defaultOccProductMultiDimensionalSelectorConfig),
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductMultiDimensionalSelectorOccModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [
                        provideDefaultConfig(defaultOccProductMultiDimensionalSelectorConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ProductMultiDimensionalSelectorOccModule };
//# sourceMappingURL=spartacus-product-multi-dimensional-selector-occ.mjs.map
