import * as i0 from '@angular/core';

declare class OmfRootModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OmfRootModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OmfRootModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OmfRootModule>;
}

declare abstract class OmfConfiguration {
    guidHttpHeaderName: string;
}

export { OmfConfiguration, OmfRootModule };
