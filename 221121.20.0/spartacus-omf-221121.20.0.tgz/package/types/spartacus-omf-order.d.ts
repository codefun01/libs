import * as i0 from '@angular/core';
import { OccOrderHistoryAdapter } from '@spartacus/order/occ';
import { Order, OrderHistoryFacade } from '@spartacus/order/root';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { OmfConfiguration } from '@spartacus/omf';
import { ActivatedRoute, Params } from '@angular/router';
import { OrderHistoryService } from '@spartacus/order/core';

declare class OmfOrderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OmfOrderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OmfOrderModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OmfOrderModule>;
}

declare abstract class OmfConfig {
    omf?: OmfConfiguration;
    static ɵfac: i0.ɵɵFactoryDeclaration<OmfConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OmfConfig>;
}
declare module '@spartacus/core' {
    interface Config extends OmfConfig {
    }
}

declare class OccOmfOrderHistoryAdapter extends OccOrderHistoryAdapter {
    protected route: ActivatedRoute;
    protected store: Store<any>;
    protected config: OmfConfig;
    protected getOrderDetailsValue(code: string): Observable<Order | undefined>;
    getOrderGuid(orderCode: string): Observable<string | undefined>;
    getRequestHeader(guid: string | undefined): HttpHeaders;
    load(userId: string, orderCode: string): Observable<Order>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccOmfOrderHistoryAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccOmfOrderHistoryAdapter>;
}

declare class OmfOrderHistoryService extends OrderHistoryService implements OrderHistoryFacade {
    getQueryParams(order: Order): Params | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<OmfOrderHistoryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OmfOrderHistoryService>;
}

export { OccOmfOrderHistoryAdapter, OmfOrderHistoryService, OmfOrderModule };
