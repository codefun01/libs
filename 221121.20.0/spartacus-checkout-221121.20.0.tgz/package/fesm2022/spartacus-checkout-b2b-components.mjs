import { NgIf, NgFor, AsyncPipe, CommonModule, NgSwitch, NgSwitchCase, NgTemplateOutlet } from '@angular/common';
import * as i0 from '@angular/core';
import { HostBinding, ChangeDetectionStrategy, Component, NgModule, inject, ViewChild, Injectable, isDevMode } from '@angular/core';
import * as i2 from '@spartacus/checkout/base/components';
import { CheckoutAuthGuard, CartNotEmptyGuard, CheckoutDeliveryAddressComponent, CheckoutReviewSubmitComponent, CheckoutStepsSetGuard } from '@spartacus/checkout/base/components';
import { CartValidationGuard } from '@spartacus/cart/base/core';
import * as i1 from '@spartacus/core';
import { TranslatePipe, I18nModule, ConfigModule, FeatureToggles, FeaturesConfigModule, provideDefaultConfig, OccHttpErrorType, GlobalMessageType, isNotUndefined, getLastValueSync, UrlPipe, UrlModule, B2BUserRole, LoggerService } from '@spartacus/core';
import { Subscription, combineLatest, of, BehaviorSubject } from 'rxjs';
import { filter, distinctUntilChanged, map, take, tap, switchMap, catchError } from 'rxjs/operators';
import * as i5 from '@spartacus/checkout/b2b/root';
import { B2BPaymentTypeEnum } from '@spartacus/checkout/b2b/root';
import * as i3 from '@angular/router';
import { RouterModule, RouterLink } from '@angular/router';
import { CardComponent, SpinnerComponent, CardModule, SpinnerModule, IconComponent, OutletDirective, PromotionsComponent, PromotionsModule, IconModule, OutletModule } from '@spartacus/storefront';
import { AddressFormComponent, AddressFormModule } from '@spartacus/user/profile/components';
import * as i1$1 from '@spartacus/checkout/base/root';
import { CheckoutStepType } from '@spartacus/checkout/base/root';
import * as i4 from '@spartacus/cart/base/root';
import { ActiveCartFacade } from '@spartacus/cart/base/root';
import * as i5$1 from '@spartacus/user/account/root';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CheckoutCostCenterComponent {
    get disabled() {
        return !this.isAccountPayment;
    }
    constructor(userCostCenterService, checkoutCostCenterFacade, checkoutPaymentTypeFacade) {
        this.userCostCenterService = userCostCenterService;
        this.checkoutCostCenterFacade = checkoutCostCenterFacade;
        this.checkoutPaymentTypeFacade = checkoutPaymentTypeFacade;
        this.subscription = new Subscription();
        this.userCostCenters$ = this.userCostCenterService
            .getActiveCostCenters()
            .pipe(filter((costCenters) => !!costCenters));
    }
    ngOnInit() {
        this.subscription.add(this.checkoutPaymentTypeFacade
            .isAccountPayment()
            .pipe(distinctUntilChanged())
            .subscribe((isAccountPayment) => {
            this.isAccountPayment = isAccountPayment;
        }));
        this.costCenters$ = combineLatest([
            this.userCostCenters$,
            this.checkoutCostCenterFacade.getCostCenterState().pipe(filter((state) => !state.loading), map((state) => state.data), distinctUntilChanged()),
        ]).pipe(take(1), tap(([costCenters, costCenter]) => {
            if (!costCenter) {
                this.setCostCenter(costCenters[0].code);
            }
            else {
                this.costCenterId = costCenter.code;
            }
        }), map(([costCenters]) => costCenters));
    }
    setCostCenter(selectCostCenter) {
        this.costCenterId = selectCostCenter;
        this.checkoutCostCenterFacade.setCostCenter(this.costCenterId);
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutCostCenterComponent, deps: [{ token: i1.UserCostCenterService }, { token: i5.CheckoutCostCenterFacade }, { token: i5.CheckoutPaymentTypeFacade }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CheckoutCostCenterComponent, isStandalone: true, selector: "cx-cost-center", host: { properties: { "class.hidden": "this.disabled" } }, ngImport: i0, template: "<ng-container *ngIf=\"isAccountPayment\">\n  <div class=\"row\">\n    <div class=\"col-md-12 col-xl-10\">\n      <ng-container *ngIf=\"costCenters$ | async as costCenters\">\n        <div *ngIf=\"costCenters.length !== 0\">\n          <label>\n            <span class=\"label-content required\">{{\n              'checkoutB2B.costCenter' | cxTranslate\n            }}</span>\n            <select (change)=\"setCostCenter($event.target.value)\">\n              <option\n                *ngFor=\"let costCenter of costCenters\"\n                value=\"{{ costCenter.code }}\"\n                [selected]=\"costCenterId === costCenter.code\"\n              >\n                {{ costCenter.name }}\n              </option>\n            </select>\n            <span class=\"label-content\">{{\n              'checkoutB2B.availableLabel' | cxTranslate\n            }}</span>\n          </label>\n        </div>\n      </ng-container>\n    </div>\n  </div>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutCostCenterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-cost-center', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, NgFor, AsyncPipe, TranslatePipe], template: "<ng-container *ngIf=\"isAccountPayment\">\n  <div class=\"row\">\n    <div class=\"col-md-12 col-xl-10\">\n      <ng-container *ngIf=\"costCenters$ | async as costCenters\">\n        <div *ngIf=\"costCenters.length !== 0\">\n          <label>\n            <span class=\"label-content required\">{{\n              'checkoutB2B.costCenter' | cxTranslate\n            }}</span>\n            <select (change)=\"setCostCenter($event.target.value)\">\n              <option\n                *ngFor=\"let costCenter of costCenters\"\n                value=\"{{ costCenter.code }}\"\n                [selected]=\"costCenterId === costCenter.code\"\n              >\n                {{ costCenter.name }}\n              </option>\n            </select>\n            <span class=\"label-content\">{{\n              'checkoutB2B.availableLabel' | cxTranslate\n            }}</span>\n          </label>\n        </div>\n      </ng-container>\n    </div>\n  </div>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: i1.UserCostCenterService }, { type: i5.CheckoutCostCenterFacade }, { type: i5.CheckoutPaymentTypeFacade }], propDecorators: { disabled: [{
                type: HostBinding,
                args: ['class.hidden']
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CheckoutCostCenterModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutCostCenterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CheckoutCostCenterModule, imports: [CommonModule,
            I18nModule, i1.ConfigModule, CheckoutCostCenterComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutCostCenterModule, imports: [CommonModule,
            I18nModule,
            ConfigModule.withConfig({
                cmsComponents: {
                    CheckoutCostCenterComponent: {
                        component: CheckoutCostCenterComponent,
                        guards: [CheckoutAuthGuard, CartNotEmptyGuard, CartValidationGuard],
                    },
                },
            })] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutCostCenterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        ConfigModule.withConfig({
                            cmsComponents: {
                                CheckoutCostCenterComponent: {
                                    component: CheckoutCostCenterComponent,
                                    guards: [CheckoutAuthGuard, CartNotEmptyGuard, CartValidationGuard],
                                },
                            },
                        }),
                        CheckoutCostCenterComponent,
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class B2BCheckoutDeliveryAddressComponent extends CheckoutDeliveryAddressComponent {
    constructor(userAddressService, checkoutDeliveryAddressFacade, activatedRoute, translationService, activeCartFacade, checkoutStepService, checkoutDeliveryModesFacade, globalMessageService, checkoutCostCenterFacade, checkoutPaymentTypeFacade, userCostCenterService) {
        super(userAddressService, checkoutDeliveryAddressFacade, activatedRoute, translationService, activeCartFacade, checkoutStepService, checkoutDeliveryModesFacade, globalMessageService);
        this.userAddressService = userAddressService;
        this.checkoutDeliveryAddressFacade = checkoutDeliveryAddressFacade;
        this.activatedRoute = activatedRoute;
        this.translationService = translationService;
        this.activeCartFacade = activeCartFacade;
        this.checkoutStepService = checkoutStepService;
        this.checkoutDeliveryModesFacade = checkoutDeliveryModesFacade;
        this.globalMessageService = globalMessageService;
        this.checkoutCostCenterFacade = checkoutCostCenterFacade;
        this.checkoutPaymentTypeFacade = checkoutPaymentTypeFacade;
        this.userCostCenterService = userCostCenterService;
        this.subscriptions = new Subscription();
        this.featureToggles = inject(FeatureToggles);
        this.isAccountPayment$ = this.checkoutPaymentTypeFacade
            .isAccountPayment()
            .pipe(distinctUntilChanged());
        this.costCenterAddresses$ = this.checkoutCostCenterFacade.getCostCenterState().pipe(filter((state) => !state.loading), map((state) => state.data), distinctUntilChanged((prev, curr) => prev?.code === curr?.code), switchMap((costCenter) => {
            this.doneAutoSelect = false;
            return costCenter?.code
                ? this.userCostCenterService
                    .getCostCenterAddresses(costCenter.code)
                    .pipe(map((addresses) => this.featureToggles.b2bCheckoutShippingAddressFilter
                    ? addresses.filter((a) => a.shippingAddress === true)
                    : addresses))
                : of([]);
        }));
        this.creditCardAddressLoading$ = super.getAddressLoading();
        this.accountAddressLoading$ = combineLatest([
            this.creditCardAddressLoading$,
            this.checkoutCostCenterFacade
                .getCostCenterState()
                .pipe(map((state) => state.loading)),
        ]).pipe(map(([creditCardAddressLoading, costCenterLoading]) => creditCardAddressLoading || costCenterLoading), distinctUntilChanged());
        this.isAccountPayment = false;
    }
    ngOnInit() {
        this.subscriptions.add(this.isAccountPayment$.subscribe((isAccount) => (this.isAccountPayment = isAccount)));
        super.ngOnInit();
    }
    loadAddresses() {
        if (!this.isAccountPayment) {
            super.loadAddresses();
        }
        // else: do nothing, as we don't need to load user addresses for account payment
    }
    getAddressLoading() {
        return this.isAccountPayment$.pipe(switchMap((isAccountPayment) => isAccountPayment
            ? this.accountAddressLoading$
            : this.creditCardAddressLoading$));
    }
    getSupportedAddresses() {
        return this.isAccountPayment$.pipe(switchMap((isAccountPayment) => isAccountPayment
            ? this.costCenterAddresses$
            : super.getSupportedAddresses()));
    }
    selectDefaultAddress(addresses, selected) {
        if (!this.doneAutoSelect &&
            addresses?.length &&
            (!selected || Object.keys(selected).length === 0)) {
            if (this.isAccountPayment) {
                if (addresses.length === 1) {
                    this.setAddress(addresses[0]);
                }
            }
            else {
                super.selectDefaultAddress(addresses, selected);
            }
            this.doneAutoSelect = true;
        }
    }
    ngOnDestroy() {
        this.subscriptions.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: B2BCheckoutDeliveryAddressComponent, deps: [{ token: i1.UserAddressService }, { token: i1$1.CheckoutDeliveryAddressFacade }, { token: i3.ActivatedRoute }, { token: i1.TranslationService }, { token: i4.ActiveCartFacade }, { token: i2.CheckoutStepService }, { token: i1$1.CheckoutDeliveryModesFacade }, { token: i1.GlobalMessageService }, { token: i5.CheckoutCostCenterFacade }, { token: i5.CheckoutPaymentTypeFacade }, { token: i1.UserCostCenterService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: B2BCheckoutDeliveryAddressComponent, isStandalone: true, selector: "cx-delivery-address", usesInheritance: true, ngImport: i0, template: "<h2 class=\"cx-checkout-title d-none d-lg-block d-xl-block\">\n  {{ 'checkoutAddress.shippingAddress' | cxTranslate }}\n</h2>\n\n<ng-container *ngIf=\"cards$ | async as cards\">\n  <ng-container *ngIf=\"!(isUpdating$ | async); else loading\">\n    <ng-container\n      *ngIf=\"\n        isAccountPayment || (cards?.length && !addressFormOpened);\n        then showExistingAddresses;\n        else newAddressForm\n      \"\n    />\n\n    <ng-template #showExistingAddresses>\n      <p class=\"cx-checkout-text\">\n        {{ 'checkoutAddress.selectYourDeliveryAddress' | cxTranslate }}\n      </p>\n      <div class=\"cx-checkout-btns row\" *ngIf=\"!isAccountPayment\">\n        <div class=\"col-sm-12 col-md-12 col-lg-6\">\n          <button\n            class=\"btn btn-block btn-secondary\"\n            (click)=\"showNewAddressForm()\"\n          >\n            {{ 'checkoutAddress.addNewAddress' | cxTranslate }}\n          </button>\n        </div>\n      </div>\n\n      <div class=\"cx-checkout-body row\">\n        <div\n          class=\"cx-delivery-address-card col-md-12 col-lg-6\"\n          *ngFor=\"let card of cards; let i = index\"\n        >\n          <div\n            class=\"cx-delivery-address-card-inner\"\n            (click)=\"selectAddress(card.address)\"\n          >\n            <cx-card\n              [border]=\"true\"\n              [index]=\"i\"\n              [fitToContainer]=\"true\"\n              [content]=\"card.card\"\n              (sendCard)=\"selectAddress(card.address)\"\n              [role]=\"'group'\"\n            />\n          </div>\n        </div>\n      </div>\n\n      <div class=\"cx-checkout-btns row\">\n        <div class=\"col-md-12 col-lg-6\">\n          <button class=\"cx-btn btn btn-block btn-secondary\" (click)=\"back()\">\n            {{ backBtnText | cxTranslate }}\n          </button>\n        </div>\n        <div class=\"col-md-12 col-lg-6\">\n          <button\n            class=\"cx-btn btn btn-block btn-primary\"\n            [disabled]=\"!(selectedAddress$ | async)?.id\"\n            (click)=\"next()\"\n          >\n            {{ 'common.continue' | cxTranslate }}\n          </button>\n        </div>\n      </div>\n    </ng-template>\n\n    <ng-template #newAddressForm>\n      <cx-address-form\n        *ngIf=\"cards.length; else initialAddressForm\"\n        [showTitleCode]=\"true\"\n        (backToAddress)=\"hideNewAddressForm(false)\"\n        (submitAddress)=\"addAddress($event)\"\n      />\n      <ng-template #initialAddressForm>\n        <cx-address-form\n          [showTitleCode]=\"true\"\n          [setAsDefaultField]=\"!isGuestCheckout\"\n          cancelBtnLabel=\"{{ backBtnText | cxTranslate }}\"\n          (backToAddress)=\"hideNewAddressForm(true)\"\n          (submitAddress)=\"addAddress($event)\"\n        />\n      </ng-template>\n    </ng-template>\n  </ng-container>\n</ng-container>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\">\n    <cx-spinner />\n  </div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: CardComponent, selector: "cx-card", inputs: ["border", "editMode", "isDefault", "content", "fitToContainer", "truncateText", "truncateParagraphText", "charactersLimit", "index", "role"], outputs: ["deleteCard", "setDefaultCard", "sendCard", "editCard", "cancelCard"] }, { kind: "component", type: AddressFormComponent, selector: "cx-address-form", inputs: ["addressData", "actionBtnLabel", "cancelBtnLabel", "setAsDefaultField", "showTitleCode", "showCancelBtn", "countries"], outputs: ["submitAddress", "backToAddress"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: B2BCheckoutDeliveryAddressComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-delivery-address', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        NgFor,
                        CardComponent,
                        AddressFormComponent,
                        SpinnerComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<h2 class=\"cx-checkout-title d-none d-lg-block d-xl-block\">\n  {{ 'checkoutAddress.shippingAddress' | cxTranslate }}\n</h2>\n\n<ng-container *ngIf=\"cards$ | async as cards\">\n  <ng-container *ngIf=\"!(isUpdating$ | async); else loading\">\n    <ng-container\n      *ngIf=\"\n        isAccountPayment || (cards?.length && !addressFormOpened);\n        then showExistingAddresses;\n        else newAddressForm\n      \"\n    />\n\n    <ng-template #showExistingAddresses>\n      <p class=\"cx-checkout-text\">\n        {{ 'checkoutAddress.selectYourDeliveryAddress' | cxTranslate }}\n      </p>\n      <div class=\"cx-checkout-btns row\" *ngIf=\"!isAccountPayment\">\n        <div class=\"col-sm-12 col-md-12 col-lg-6\">\n          <button\n            class=\"btn btn-block btn-secondary\"\n            (click)=\"showNewAddressForm()\"\n          >\n            {{ 'checkoutAddress.addNewAddress' | cxTranslate }}\n          </button>\n        </div>\n      </div>\n\n      <div class=\"cx-checkout-body row\">\n        <div\n          class=\"cx-delivery-address-card col-md-12 col-lg-6\"\n          *ngFor=\"let card of cards; let i = index\"\n        >\n          <div\n            class=\"cx-delivery-address-card-inner\"\n            (click)=\"selectAddress(card.address)\"\n          >\n            <cx-card\n              [border]=\"true\"\n              [index]=\"i\"\n              [fitToContainer]=\"true\"\n              [content]=\"card.card\"\n              (sendCard)=\"selectAddress(card.address)\"\n              [role]=\"'group'\"\n            />\n          </div>\n        </div>\n      </div>\n\n      <div class=\"cx-checkout-btns row\">\n        <div class=\"col-md-12 col-lg-6\">\n          <button class=\"cx-btn btn btn-block btn-secondary\" (click)=\"back()\">\n            {{ backBtnText | cxTranslate }}\n          </button>\n        </div>\n        <div class=\"col-md-12 col-lg-6\">\n          <button\n            class=\"cx-btn btn btn-block btn-primary\"\n            [disabled]=\"!(selectedAddress$ | async)?.id\"\n            (click)=\"next()\"\n          >\n            {{ 'common.continue' | cxTranslate }}\n          </button>\n        </div>\n      </div>\n    </ng-template>\n\n    <ng-template #newAddressForm>\n      <cx-address-form\n        *ngIf=\"cards.length; else initialAddressForm\"\n        [showTitleCode]=\"true\"\n        (backToAddress)=\"hideNewAddressForm(false)\"\n        (submitAddress)=\"addAddress($event)\"\n      />\n      <ng-template #initialAddressForm>\n        <cx-address-form\n          [showTitleCode]=\"true\"\n          [setAsDefaultField]=\"!isGuestCheckout\"\n          cancelBtnLabel=\"{{ backBtnText | cxTranslate }}\"\n          (backToAddress)=\"hideNewAddressForm(true)\"\n          (submitAddress)=\"addAddress($event)\"\n        />\n      </ng-template>\n    </ng-template>\n  </ng-container>\n</ng-container>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\">\n    <cx-spinner />\n  </div>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i1.UserAddressService }, { type: i1$1.CheckoutDeliveryAddressFacade }, { type: i3.ActivatedRoute }, { type: i1.TranslationService }, { type: i4.ActiveCartFacade }, { type: i2.CheckoutStepService }, { type: i1$1.CheckoutDeliveryModesFacade }, { type: i1.GlobalMessageService }, { type: i5.CheckoutCostCenterFacade }, { type: i5.CheckoutPaymentTypeFacade }, { type: i1.UserCostCenterService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class B2BCheckoutDeliveryAddressModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: B2BCheckoutDeliveryAddressModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: B2BCheckoutDeliveryAddressModule, imports: [CommonModule,
            RouterModule,
            AddressFormModule,
            CardModule,
            SpinnerModule,
            I18nModule,
            FeaturesConfigModule,
            B2BCheckoutDeliveryAddressComponent], exports: [B2BCheckoutDeliveryAddressComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: B2BCheckoutDeliveryAddressModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    CheckoutDeliveryAddress: {
                        component: B2BCheckoutDeliveryAddressComponent,
                        guards: [CheckoutAuthGuard, CartNotEmptyGuard, CartValidationGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            RouterModule,
            AddressFormModule,
            CardModule,
            SpinnerModule,
            I18nModule,
            FeaturesConfigModule,
            B2BCheckoutDeliveryAddressComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: B2BCheckoutDeliveryAddressModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        AddressFormModule,
                        CardModule,
                        SpinnerModule,
                        I18nModule,
                        FeaturesConfigModule,
                        B2BCheckoutDeliveryAddressComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                CheckoutDeliveryAddress: {
                                    component: B2BCheckoutDeliveryAddressComponent,
                                    guards: [CheckoutAuthGuard, CartNotEmptyGuard, CartValidationGuard],
                                },
                            },
                        }),
                    ],
                    exports: [B2BCheckoutDeliveryAddressComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CheckoutPaymentTypeComponent {
    constructor(checkoutPaymentTypeFacade, checkoutStepService, activatedRoute, globalMessageService) {
        this.checkoutPaymentTypeFacade = checkoutPaymentTypeFacade;
        this.checkoutStepService = checkoutStepService;
        this.activatedRoute = activatedRoute;
        this.globalMessageService = globalMessageService;
        this.busy$ = new BehaviorSubject(false);
        this.paymentTypesError = false;
        this.isUpdating$ = combineLatest([
            this.busy$,
            this.checkoutPaymentTypeFacade
                .getSelectedPaymentTypeState()
                .pipe(map((state) => state.loading)),
        ]).pipe(map(([busy, loading]) => busy || loading), distinctUntilChanged());
        this.paymentTypes$ = this.checkoutPaymentTypeFacade
            .getPaymentTypes()
            .pipe(tap(() => (this.paymentTypesError = false)), catchError((error) => {
            if (error.details?.[0]?.type === OccHttpErrorType.CLASS_MISMATCH_ERROR) {
                this.globalMessageService.add({ key: 'httpHandlers.forbidden' }, GlobalMessageType.MSG_TYPE_ERROR);
                this.paymentTypesError = true;
            }
            return of([]);
        }));
        this.typeSelected$ = combineLatest([
            this.checkoutPaymentTypeFacade.getSelectedPaymentTypeState().pipe(filter((state) => !state.loading), map((state) => state.data)),
            this.paymentTypes$,
        ]).pipe(map(([selectedPaymentType, availablePaymentTypes]) => {
            if (selectedPaymentType &&
                availablePaymentTypes.find((availablePaymentType) => {
                    return availablePaymentType.code === selectedPaymentType.code;
                })) {
                return selectedPaymentType;
            }
            if (availablePaymentTypes.length) {
                this.busy$.next(true);
                this.checkoutPaymentTypeFacade
                    .setPaymentType(availablePaymentTypes[0].code, this.poNumberInputElement?.nativeElement?.value)
                    .subscribe({
                    complete: () => this.onSuccess(),
                    error: () => this.onError(),
                });
                return availablePaymentTypes[0];
            }
            return undefined;
        }), filter(isNotUndefined), distinctUntilChanged(), tap((selected) => {
            this.typeSelected = selected?.code;
            this.checkoutStepService.disableEnableStep(CheckoutStepType.PAYMENT_DETAILS, selected?.code === B2BPaymentTypeEnum.ACCOUNT_PAYMENT);
        }));
        this.cartPoNumber$ = this.checkoutPaymentTypeFacade
            .getPurchaseOrderNumberState()
            .pipe(filter((state) => !state.loading), map((state) => state.data), filter(isNotUndefined), distinctUntilChanged());
        this.activeCartFacade = inject(ActiveCartFacade);
        this.isPONumberEditable$ = this.activeCartFacade
            .getActive()
            .pipe(map((cart) => !cart?.quotePurchaseOrderNumber));
    }
    changeType(code) {
        this.busy$.next(true);
        this.typeSelected = code;
        this.checkoutPaymentTypeFacade
            .setPaymentType(code, this.poNumberInputElement.nativeElement.value)
            .subscribe({
            complete: () => this.onSuccess(),
            error: (error) => {
                if (error.details?.[0]?.message) {
                    this.globalMessageService.add(error.details?.[0]?.message, GlobalMessageType.MSG_TYPE_ERROR);
                }
                this.onError();
            },
        });
    }
    next() {
        if (!this.typeSelected) {
            return;
        }
        const poNumberInput = this.poNumberInputElement.nativeElement.value;
        // if the PO number didn't change
        if (poNumberInput === getLastValueSync(this.cartPoNumber$)) {
            this.checkoutStepService.next(this.activatedRoute);
            return;
        }
        this.busy$.next(true);
        this.checkoutPaymentTypeFacade
            .setPaymentType(this.typeSelected, poNumberInput)
            .subscribe({
            // we don't call onSuccess here, because it can cause a spinner flickering
            complete: () => this.checkoutStepService.next(this.activatedRoute),
            error: (error) => {
                if (error.details?.[0]?.message) {
                    this.globalMessageService.add(error.details?.[0]?.message, GlobalMessageType.MSG_TYPE_ERROR);
                }
                this.onError();
            },
        });
    }
    back() {
        this.checkoutStepService.back(this.activatedRoute);
    }
    onSuccess() {
        this.busy$.next(false);
    }
    onError() {
        this.busy$.next(false);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutPaymentTypeComponent, deps: [{ token: i5.CheckoutPaymentTypeFacade }, { token: i2.CheckoutStepService }, { token: i3.ActivatedRoute }, { token: i1.GlobalMessageService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: CheckoutPaymentTypeComponent, isStandalone: true, selector: "cx-payment-type", viewQueries: [{ propertyName: "poNumberInputElement", first: true, predicate: ["poNumber"], descendants: true }], ngImport: i0, template: "<h2 class=\"cx-checkout-title d-none d-lg-block d-xl-block\">\n  {{ 'checkoutB2B.methodOfPayment.paymentType' | cxTranslate }}\n</h2>\n\n<ng-container *ngIf=\"paymentTypes$ | async as paymentTypes\">\n  <ng-container\n    *ngIf=\"\n      !!paymentTypes.length &&\n        (typeSelected$ | async) &&\n        !(isUpdating$ | async);\n      else loading\n    \"\n  >\n    <div class=\"row\">\n      <div class=\"col-md-12 col-lg-6\">\n        <label>\n          <span class=\"label-content\">{{\n            'checkoutB2B.poNumber' | cxTranslate\n          }}</span>\n          <input\n            #poNumber\n            class=\"form-control\"\n            id=\"poNumberInput\"\n            formControlName=\"poNumber\"\n            type=\"text\"\n            placeholder=\"{{ 'checkoutB2B.placeholder' | cxTranslate }}\"\n            value=\"{{ cartPoNumber$ | async }}\"\n            [disabled]=\"!(isPONumberEditable$ | async)\"\n          />\n        </label>\n      </div>\n    </div>\n\n    <div class=\"row\">\n      <div class=\"col-md-12 col-lg-6\">\n        <label class=\"cx-payment-type-container\">\n          <span class=\"label-content\">{{\n            'paymentTypes.title' | cxTranslate\n          }}</span>\n          <div class=\"form-check\" *ngFor=\"let type of paymentTypes\">\n            <input\n              id=\"paymentType-{{ type.code }}\"\n              class=\"form-check-input\"\n              role=\"radio\"\n              type=\"radio\"\n              aria-checked=\"true\"\n              (change)=\"changeType(type.code)\"\n              [value]=\"type.code\"\n              [checked]=\"type.code === typeSelected\"\n              formControlName=\"paymentType\"\n            />\n            <label\n              class=\"cx-payment-type-label form-check-label form-radio-label\"\n              for=\"paymentType-{{ type.code }}\"\n            >\n              <div class=\"cx-payment-type\">\n                {{ 'paymentTypes.paymentType_' + type?.code | cxTranslate }}\n              </div>\n            </label>\n          </div>\n        </label>\n      </div>\n    </div>\n\n    <div class=\"cx-checkout-btns row\">\n      <div class=\"col-md-12 col-lg-6\">\n        <button class=\"btn btn-block btn-secondary\" (click)=\"back()\">\n          {{ 'checkout.backToCart' | cxTranslate }}\n        </button>\n      </div>\n      <div class=\"col-md-12 col-lg-6\">\n        <button class=\"btn btn-block btn-primary\" (click)=\"next()\">\n          {{ 'common.continue' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n  </ng-container>\n</ng-container>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\" *ngIf=\"!paymentTypesError\">\n    <cx-spinner />\n  </div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutPaymentTypeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-payment-type', changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgIf, NgFor, SpinnerComponent, AsyncPipe, TranslatePipe], template: "<h2 class=\"cx-checkout-title d-none d-lg-block d-xl-block\">\n  {{ 'checkoutB2B.methodOfPayment.paymentType' | cxTranslate }}\n</h2>\n\n<ng-container *ngIf=\"paymentTypes$ | async as paymentTypes\">\n  <ng-container\n    *ngIf=\"\n      !!paymentTypes.length &&\n        (typeSelected$ | async) &&\n        !(isUpdating$ | async);\n      else loading\n    \"\n  >\n    <div class=\"row\">\n      <div class=\"col-md-12 col-lg-6\">\n        <label>\n          <span class=\"label-content\">{{\n            'checkoutB2B.poNumber' | cxTranslate\n          }}</span>\n          <input\n            #poNumber\n            class=\"form-control\"\n            id=\"poNumberInput\"\n            formControlName=\"poNumber\"\n            type=\"text\"\n            placeholder=\"{{ 'checkoutB2B.placeholder' | cxTranslate }}\"\n            value=\"{{ cartPoNumber$ | async }}\"\n            [disabled]=\"!(isPONumberEditable$ | async)\"\n          />\n        </label>\n      </div>\n    </div>\n\n    <div class=\"row\">\n      <div class=\"col-md-12 col-lg-6\">\n        <label class=\"cx-payment-type-container\">\n          <span class=\"label-content\">{{\n            'paymentTypes.title' | cxTranslate\n          }}</span>\n          <div class=\"form-check\" *ngFor=\"let type of paymentTypes\">\n            <input\n              id=\"paymentType-{{ type.code }}\"\n              class=\"form-check-input\"\n              role=\"radio\"\n              type=\"radio\"\n              aria-checked=\"true\"\n              (change)=\"changeType(type.code)\"\n              [value]=\"type.code\"\n              [checked]=\"type.code === typeSelected\"\n              formControlName=\"paymentType\"\n            />\n            <label\n              class=\"cx-payment-type-label form-check-label form-radio-label\"\n              for=\"paymentType-{{ type.code }}\"\n            >\n              <div class=\"cx-payment-type\">\n                {{ 'paymentTypes.paymentType_' + type?.code | cxTranslate }}\n              </div>\n            </label>\n          </div>\n        </label>\n      </div>\n    </div>\n\n    <div class=\"cx-checkout-btns row\">\n      <div class=\"col-md-12 col-lg-6\">\n        <button class=\"btn btn-block btn-secondary\" (click)=\"back()\">\n          {{ 'checkout.backToCart' | cxTranslate }}\n        </button>\n      </div>\n      <div class=\"col-md-12 col-lg-6\">\n        <button class=\"btn btn-block btn-primary\" (click)=\"next()\">\n          {{ 'common.continue' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n  </ng-container>\n</ng-container>\n\n<ng-template #loading>\n  <div class=\"cx-spinner\" *ngIf=\"!paymentTypesError\">\n    <cx-spinner />\n  </div>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: i5.CheckoutPaymentTypeFacade }, { type: i2.CheckoutStepService }, { type: i3.ActivatedRoute }, { type: i1.GlobalMessageService }], propDecorators: { poNumberInputElement: [{
                type: ViewChild,
                args: ['poNumber', { static: false }]
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CheckoutPaymentTypeModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutPaymentTypeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CheckoutPaymentTypeModule, imports: [CommonModule,
            I18nModule,
            SpinnerModule, i1.ConfigModule, FeaturesConfigModule,
            CheckoutPaymentTypeComponent], exports: [CheckoutPaymentTypeComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutPaymentTypeModule, imports: [CommonModule,
            I18nModule,
            SpinnerModule,
            ConfigModule.withConfig({
                cmsComponents: {
                    CheckoutPaymentType: {
                        component: CheckoutPaymentTypeComponent,
                        guards: [CheckoutAuthGuard, CartNotEmptyGuard, CartValidationGuard],
                    },
                },
            }),
            FeaturesConfigModule,
            CheckoutPaymentTypeComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutPaymentTypeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        SpinnerModule,
                        ConfigModule.withConfig({
                            cmsComponents: {
                                CheckoutPaymentType: {
                                    component: CheckoutPaymentTypeComponent,
                                    guards: [CheckoutAuthGuard, CartNotEmptyGuard, CartValidationGuard],
                                },
                            },
                        }),
                        FeaturesConfigModule,
                        CheckoutPaymentTypeComponent,
                    ],
                    exports: [CheckoutPaymentTypeComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class B2BCheckoutReviewSubmitComponent extends CheckoutReviewSubmitComponent {
    constructor(checkoutDeliveryAddressFacade, checkoutPaymentFacade, activeCartFacade, translationService, checkoutStepService, checkoutDeliveryModesFacade, checkoutPaymentTypeFacade, checkoutCostCenterFacade, userCostCenterService) {
        super(checkoutDeliveryAddressFacade, checkoutPaymentFacade, activeCartFacade, translationService, checkoutStepService, checkoutDeliveryModesFacade);
        this.checkoutDeliveryAddressFacade = checkoutDeliveryAddressFacade;
        this.checkoutPaymentFacade = checkoutPaymentFacade;
        this.activeCartFacade = activeCartFacade;
        this.translationService = translationService;
        this.checkoutStepService = checkoutStepService;
        this.checkoutDeliveryModesFacade = checkoutDeliveryModesFacade;
        this.checkoutPaymentTypeFacade = checkoutPaymentTypeFacade;
        this.checkoutCostCenterFacade = checkoutCostCenterFacade;
        this.userCostCenterService = userCostCenterService;
        this.checkoutStepTypePaymentType = CheckoutStepType.PAYMENT_TYPE;
    }
    get poNumber$() {
        return this.checkoutPaymentTypeFacade.getPurchaseOrderNumberState().pipe(filter((state) => !state.loading && !state.error), map((state) => state.data));
    }
    get paymentType$() {
        return this.checkoutPaymentTypeFacade.getSelectedPaymentTypeState().pipe(filter((state) => !state.loading && !state.error), map((state) => state.data));
    }
    get isAccountPayment$() {
        return this.checkoutPaymentTypeFacade.isAccountPayment();
    }
    get costCenter$() {
        return this.checkoutCostCenterFacade.getCostCenterState().pipe(filter((state) => !state.loading && !state.error), map((state) => state.data));
    }
    getCheckoutPaymentSteps() {
        return [
            CheckoutStepType.PAYMENT_DETAILS,
            CheckoutStepType.PAYMENT_TYPE,
            CheckoutStepType.DELIVERY_ADDRESS,
        ];
    }
    getCostCenterCard(costCenter) {
        return combineLatest([
            this.translationService.translate('checkoutB2B.costCenter'),
        ]).pipe(map(([textTitle]) => {
            return {
                title: textTitle,
                textBold: costCenter?.name,
                text: ['(' + costCenter?.unit?.name + ')'],
            };
        }));
    }
    getPoNumberCard(poNumber) {
        return combineLatest([
            this.translationService.translate('checkoutB2B.review.poNumber'),
            this.translationService.translate('checkoutB2B.noPoNumber'),
        ]).pipe(map(([textTitle, noneTextTitle]) => {
            return {
                title: textTitle,
                textBold: poNumber ? poNumber : noneTextTitle,
            };
        }));
    }
    getPaymentTypeCard(paymentType) {
        return combineLatest([
            this.translationService.translate('checkoutB2B.progress.methodOfPayment'),
            this.translationService.translate('paymentTypes.paymentType_' + paymentType.code),
        ]).pipe(map(([textTitle, paymentTypeTranslation]) => {
            return {
                title: textTitle,
                textBold: paymentTypeTranslation,
            };
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: B2BCheckoutReviewSubmitComponent, deps: [{ token: i1$1.CheckoutDeliveryAddressFacade }, { token: i1$1.CheckoutPaymentFacade }, { token: i4.ActiveCartFacade }, { token: i1.TranslationService }, { token: i2.CheckoutStepService }, { token: i1$1.CheckoutDeliveryModesFacade }, { token: i5.CheckoutPaymentTypeFacade }, { token: i5.CheckoutCostCenterFacade }, { token: i1.UserCostCenterService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: B2BCheckoutReviewSubmitComponent, isStandalone: true, selector: "cx-review-submit", usesInheritance: true, ngImport: i0, template: "<div class=\"cx-review\">\n  <!-- TITLE -->\n  <h2 class=\"cx-review-title d-none d-lg-block d-xl-block\">\n    {{ 'checkoutReview.review' | cxTranslate }}\n  </h2>\n\n  <div class=\"cx-review-summary row\">\n    <ng-container *ngIf=\"(steps$ | async)?.slice(0, -1) as steps\">\n      <div class=\"col-md-12 col-lg-6 col-xl-6 cx-review-payment-col\">\n        <ng-container *ngFor=\"let step of paymentSteps(steps)\">\n          <ng-container [ngSwitch]=\"step.type[0]\">\n            <ng-container *ngSwitchCase=\"checkoutStepTypePaymentType\">\n              <ng-container *ngTemplateOutlet=\"poNumber\" />\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypePaymentType\">\n              <ng-container *ngTemplateOutlet=\"paymentType\" />\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypePaymentDetails\">\n              <ng-container *ngTemplateOutlet=\"paymentMethod\" />\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypeDeliveryAddress\">\n              <ng-container *ngTemplateOutlet=\"costCenter\" />\n            </ng-container>\n          </ng-container>\n        </ng-container>\n      </div>\n      <div class=\"col-md-12 col-lg-6 col-xl-6 cx-review-shipping-col\">\n        <ng-container *ngFor=\"let step of deliverySteps(steps)\">\n          <ng-container [ngSwitch]=\"step.type[0]\">\n            <ng-container *ngSwitchCase=\"checkoutStepTypeDeliveryAddress\">\n              <ng-container *ngTemplateOutlet=\"deliveryAddress\" />\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypeDeliveryMode\">\n              <ng-container *ngTemplateOutlet=\"deliveryMode\" />\n            </ng-container>\n          </ng-container>\n        </ng-container>\n      </div>\n    </ng-container>\n  </div>\n\n  <!-- PO NUMBER SECTION -->\n  <ng-template #poNumber>\n    <div class=\"cx-review-summary-card\">\n      <cx-card [content]=\"getPoNumberCard(poNumber$ | async) | async\" />\n      <div class=\"cx-review-summary-edit-step\">\n        <a\n          [attr.title]=\"'checkoutReview.editPaymentType' | cxTranslate\"\n          [routerLink]=\"\n            {\n              cxRoute: getCheckoutStepUrl(checkoutStepTypePaymentType),\n            } | cxUrl\n          \"\n          ><cx-icon aria-hidden=\"true\" [type]=\"iconTypes.PENCIL\"\n        /></a>\n      </div>\n    </div>\n  </ng-template>\n\n  <!-- PAYMENT TYPE SECTION -->\n  <ng-template #paymentType>\n    <div class=\"cx-review-summary-card\">\n      <cx-card\n        *ngIf=\"paymentType$ | async as paymentType\"\n        [content]=\"getPaymentTypeCard(paymentType) | async\"\n      />\n      <div class=\"cx-review-summary-edit-step\">\n        <a\n          [attr.title]=\"'checkoutReview.editPaymentType' | cxTranslate\"\n          [routerLink]=\"\n            {\n              cxRoute: getCheckoutStepUrl(checkoutStepTypePaymentType),\n            } | cxUrl\n          \"\n          ><cx-icon aria-hidden=\"true\" [type]=\"iconTypes.PENCIL\"\n        /></a>\n      </div>\n    </div>\n  </ng-template>\n\n  <!-- COST CENTER SECTION -->\n  <ng-template #costCenter>\n    <ng-container *ngIf=\"isAccountPayment$ | async\">\n      <div class=\"cx-review-summary-card\">\n        <cx-card\n          *ngIf=\"costCenter$ | async as costCenter\"\n          [content]=\"getCostCenterCard(costCenter) | async\"\n        />\n        <div class=\"cx-review-summary-edit-step\">\n          <a\n            [attr.title]=\"\n              'checkoutReview.editDeliveryAddressDetails' | cxTranslate\n            \"\n            [routerLink]=\"\n              {\n                cxRoute: getCheckoutStepUrl(checkoutStepTypeDeliveryAddress),\n              } | cxUrl\n            \"\n            ><cx-icon aria-hidden=\"true\" [type]=\"iconTypes.PENCIL\"\n          /></a>\n        </div>\n      </div>\n    </ng-container>\n  </ng-template>\n\n  <!-- DELIVERY ADDRESS SECTION -->\n  <ng-template #deliveryAddress>\n    <div\n      *ngIf=\"deliveryAddress$ | async as deliveryAddress\"\n      class=\"cx-review-summary-card cx-review-card-address\"\n    >\n      <cx-card [content]=\"getDeliveryAddressCard(deliveryAddress) | async\" />\n      <div class=\"cx-review-summary-edit-step\">\n        <a\n          [attr.title]=\"\n            'checkoutReview.editDeliveryAddressDetails' | cxTranslate\n          \"\n          [routerLink]=\"\n            {\n              cxRoute: getCheckoutStepUrl(checkoutStepTypeDeliveryAddress),\n            } | cxUrl\n          \"\n          ><cx-icon aria-hidden=\"true\" [type]=\"iconTypes.PENCIL\"\n        /></a>\n      </div>\n    </div>\n  </ng-template>\n\n  <!-- DELIVERY MODE SECTION -->\n  <ng-template #deliveryMode>\n    <div class=\"cx-review-summary-card cx-review-card-shipping\">\n      <div>\n        <cx-card\n          *ngIf=\"deliveryMode$ | async as deliveryMode\"\n          [content]=\"getDeliveryModeCard(deliveryMode) | async\"\n        />\n        <ng-template\n          [cxOutlet]=\"cartOutlets.DELIVERY_MODE\"\n          [cxOutletContext]=\"{\n            item: cart$ | async,\n            readonly: true,\n          }\"\n        />\n      </div>\n\n      <div class=\"cx-review-summary-edit-step\">\n        <a\n          [attr.title]=\"'checkoutReview.editDeliveryMode' | cxTranslate\"\n          [routerLink]=\"\n            { cxRoute: getCheckoutStepUrl(checkoutStepTypeDeliveryMode) }\n              | cxUrl\n          \"\n        >\n          <cx-icon aria-hidden=\"true\" [type]=\"iconTypes.PENCIL\" />\n        </a>\n      </div>\n    </div>\n  </ng-template>\n\n  <!-- PAYMENT METHOD SECTION -->\n  <ng-template #paymentMethod>\n    <div class=\"cx-review-summary-card cx-review-card-payment\">\n      <div>\n        <cx-card\n          *ngIf=\"paymentDetails$ | async as paymentDetails\"\n          [content]=\"getPaymentMethodCard(paymentDetails) | async\"\n        />\n      </div>\n      <div class=\"cx-review-summary-edit-step\">\n        <a\n          [attr.title]=\"'checkoutReview.editPaymentDetails' | cxTranslate\"\n          [routerLink]=\"\n            { cxRoute: getCheckoutStepUrl(checkoutStepTypePaymentDetails) }\n              | cxUrl\n          \"\n        >\n          <cx-icon aria-hidden=\"true\" [type]=\"iconTypes.PENCIL\" />\n        </a>\n      </div>\n    </div>\n  </ng-template>\n\n  <!-- CART ITEM SECTION -->\n  <ng-container *ngIf=\"cart$ | async as cart\">\n    <div class=\"cx-review-cart-total d-none d-lg-block d-xl-block\">\n      {{\n        'cartItems.cartTotal'\n          | cxTranslate: { count: cart.deliveryItemsQuantity }\n      }}:\n      {{ cart.totalPrice?.formattedValue }}\n    </div>\n    <div class=\"cx-review-cart-heading d-block d-lg-none d-xl-none\">\n      {{ 'checkoutReview.placeOrder' | cxTranslate }}\n    </div>\n    <div class=\"cx-review-cart-item\" *ngIf=\"entries$ | async as entries\">\n      <cx-promotions\n        [promotions]=\"\n          (cart.appliedOrderPromotions || []).concat(\n            cart.potentialOrderPromotions || []\n          )\n        \"\n      />\n\n      <ng-template\n        [cxOutlet]=\"cartOutlets.CART_ITEM_LIST\"\n        [cxOutletContext]=\"{\n          items: entries,\n          readonly: true,\n          promotionLocation: promotionLocation,\n        }\"\n      />\n    </div>\n  </ng-container>\n</div>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: CardComponent, selector: "cx-card", inputs: ["border", "editMode", "isDefault", "content", "fitToContainer", "truncateText", "truncateParagraphText", "charactersLimit", "index", "role"], outputs: ["deleteCard", "setDefaultCard", "sendCard", "editCard", "cancelCard"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "directive", type: OutletDirective, selector: "[cxOutlet]", inputs: ["cxOutlet", "cxOutletContext", "cxOutletDefer", "cxComponentRef"], outputs: ["loaded", "cxComponentRefChange"] }, { kind: "component", type: PromotionsComponent, selector: "cx-promotions", inputs: ["promotions"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: B2BCheckoutReviewSubmitComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-review-submit', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        NgFor,
                        NgSwitch,
                        NgSwitchCase,
                        NgTemplateOutlet,
                        CardComponent,
                        RouterLink,
                        IconComponent,
                        OutletDirective,
                        PromotionsComponent,
                        AsyncPipe,
                        TranslatePipe,
                        UrlPipe,
                    ], template: "<div class=\"cx-review\">\n  <!-- TITLE -->\n  <h2 class=\"cx-review-title d-none d-lg-block d-xl-block\">\n    {{ 'checkoutReview.review' | cxTranslate }}\n  </h2>\n\n  <div class=\"cx-review-summary row\">\n    <ng-container *ngIf=\"(steps$ | async)?.slice(0, -1) as steps\">\n      <div class=\"col-md-12 col-lg-6 col-xl-6 cx-review-payment-col\">\n        <ng-container *ngFor=\"let step of paymentSteps(steps)\">\n          <ng-container [ngSwitch]=\"step.type[0]\">\n            <ng-container *ngSwitchCase=\"checkoutStepTypePaymentType\">\n              <ng-container *ngTemplateOutlet=\"poNumber\" />\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypePaymentType\">\n              <ng-container *ngTemplateOutlet=\"paymentType\" />\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypePaymentDetails\">\n              <ng-container *ngTemplateOutlet=\"paymentMethod\" />\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypeDeliveryAddress\">\n              <ng-container *ngTemplateOutlet=\"costCenter\" />\n            </ng-container>\n          </ng-container>\n        </ng-container>\n      </div>\n      <div class=\"col-md-12 col-lg-6 col-xl-6 cx-review-shipping-col\">\n        <ng-container *ngFor=\"let step of deliverySteps(steps)\">\n          <ng-container [ngSwitch]=\"step.type[0]\">\n            <ng-container *ngSwitchCase=\"checkoutStepTypeDeliveryAddress\">\n              <ng-container *ngTemplateOutlet=\"deliveryAddress\" />\n            </ng-container>\n            <ng-container *ngSwitchCase=\"checkoutStepTypeDeliveryMode\">\n              <ng-container *ngTemplateOutlet=\"deliveryMode\" />\n            </ng-container>\n          </ng-container>\n        </ng-container>\n      </div>\n    </ng-container>\n  </div>\n\n  <!-- PO NUMBER SECTION -->\n  <ng-template #poNumber>\n    <div class=\"cx-review-summary-card\">\n      <cx-card [content]=\"getPoNumberCard(poNumber$ | async) | async\" />\n      <div class=\"cx-review-summary-edit-step\">\n        <a\n          [attr.title]=\"'checkoutReview.editPaymentType' | cxTranslate\"\n          [routerLink]=\"\n            {\n              cxRoute: getCheckoutStepUrl(checkoutStepTypePaymentType),\n            } | cxUrl\n          \"\n          ><cx-icon aria-hidden=\"true\" [type]=\"iconTypes.PENCIL\"\n        /></a>\n      </div>\n    </div>\n  </ng-template>\n\n  <!-- PAYMENT TYPE SECTION -->\n  <ng-template #paymentType>\n    <div class=\"cx-review-summary-card\">\n      <cx-card\n        *ngIf=\"paymentType$ | async as paymentType\"\n        [content]=\"getPaymentTypeCard(paymentType) | async\"\n      />\n      <div class=\"cx-review-summary-edit-step\">\n        <a\n          [attr.title]=\"'checkoutReview.editPaymentType' | cxTranslate\"\n          [routerLink]=\"\n            {\n              cxRoute: getCheckoutStepUrl(checkoutStepTypePaymentType),\n            } | cxUrl\n          \"\n          ><cx-icon aria-hidden=\"true\" [type]=\"iconTypes.PENCIL\"\n        /></a>\n      </div>\n    </div>\n  </ng-template>\n\n  <!-- COST CENTER SECTION -->\n  <ng-template #costCenter>\n    <ng-container *ngIf=\"isAccountPayment$ | async\">\n      <div class=\"cx-review-summary-card\">\n        <cx-card\n          *ngIf=\"costCenter$ | async as costCenter\"\n          [content]=\"getCostCenterCard(costCenter) | async\"\n        />\n        <div class=\"cx-review-summary-edit-step\">\n          <a\n            [attr.title]=\"\n              'checkoutReview.editDeliveryAddressDetails' | cxTranslate\n            \"\n            [routerLink]=\"\n              {\n                cxRoute: getCheckoutStepUrl(checkoutStepTypeDeliveryAddress),\n              } | cxUrl\n            \"\n            ><cx-icon aria-hidden=\"true\" [type]=\"iconTypes.PENCIL\"\n          /></a>\n        </div>\n      </div>\n    </ng-container>\n  </ng-template>\n\n  <!-- DELIVERY ADDRESS SECTION -->\n  <ng-template #deliveryAddress>\n    <div\n      *ngIf=\"deliveryAddress$ | async as deliveryAddress\"\n      class=\"cx-review-summary-card cx-review-card-address\"\n    >\n      <cx-card [content]=\"getDeliveryAddressCard(deliveryAddress) | async\" />\n      <div class=\"cx-review-summary-edit-step\">\n        <a\n          [attr.title]=\"\n            'checkoutReview.editDeliveryAddressDetails' | cxTranslate\n          \"\n          [routerLink]=\"\n            {\n              cxRoute: getCheckoutStepUrl(checkoutStepTypeDeliveryAddress),\n            } | cxUrl\n          \"\n          ><cx-icon aria-hidden=\"true\" [type]=\"iconTypes.PENCIL\"\n        /></a>\n      </div>\n    </div>\n  </ng-template>\n\n  <!-- DELIVERY MODE SECTION -->\n  <ng-template #deliveryMode>\n    <div class=\"cx-review-summary-card cx-review-card-shipping\">\n      <div>\n        <cx-card\n          *ngIf=\"deliveryMode$ | async as deliveryMode\"\n          [content]=\"getDeliveryModeCard(deliveryMode) | async\"\n        />\n        <ng-template\n          [cxOutlet]=\"cartOutlets.DELIVERY_MODE\"\n          [cxOutletContext]=\"{\n            item: cart$ | async,\n            readonly: true,\n          }\"\n        />\n      </div>\n\n      <div class=\"cx-review-summary-edit-step\">\n        <a\n          [attr.title]=\"'checkoutReview.editDeliveryMode' | cxTranslate\"\n          [routerLink]=\"\n            { cxRoute: getCheckoutStepUrl(checkoutStepTypeDeliveryMode) }\n              | cxUrl\n          \"\n        >\n          <cx-icon aria-hidden=\"true\" [type]=\"iconTypes.PENCIL\" />\n        </a>\n      </div>\n    </div>\n  </ng-template>\n\n  <!-- PAYMENT METHOD SECTION -->\n  <ng-template #paymentMethod>\n    <div class=\"cx-review-summary-card cx-review-card-payment\">\n      <div>\n        <cx-card\n          *ngIf=\"paymentDetails$ | async as paymentDetails\"\n          [content]=\"getPaymentMethodCard(paymentDetails) | async\"\n        />\n      </div>\n      <div class=\"cx-review-summary-edit-step\">\n        <a\n          [attr.title]=\"'checkoutReview.editPaymentDetails' | cxTranslate\"\n          [routerLink]=\"\n            { cxRoute: getCheckoutStepUrl(checkoutStepTypePaymentDetails) }\n              | cxUrl\n          \"\n        >\n          <cx-icon aria-hidden=\"true\" [type]=\"iconTypes.PENCIL\" />\n        </a>\n      </div>\n    </div>\n  </ng-template>\n\n  <!-- CART ITEM SECTION -->\n  <ng-container *ngIf=\"cart$ | async as cart\">\n    <div class=\"cx-review-cart-total d-none d-lg-block d-xl-block\">\n      {{\n        'cartItems.cartTotal'\n          | cxTranslate: { count: cart.deliveryItemsQuantity }\n      }}:\n      {{ cart.totalPrice?.formattedValue }}\n    </div>\n    <div class=\"cx-review-cart-heading d-block d-lg-none d-xl-none\">\n      {{ 'checkoutReview.placeOrder' | cxTranslate }}\n    </div>\n    <div class=\"cx-review-cart-item\" *ngIf=\"entries$ | async as entries\">\n      <cx-promotions\n        [promotions]=\"\n          (cart.appliedOrderPromotions || []).concat(\n            cart.potentialOrderPromotions || []\n          )\n        \"\n      />\n\n      <ng-template\n        [cxOutlet]=\"cartOutlets.CART_ITEM_LIST\"\n        [cxOutletContext]=\"{\n          items: entries,\n          readonly: true,\n          promotionLocation: promotionLocation,\n        }\"\n      />\n    </div>\n  </ng-container>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1$1.CheckoutDeliveryAddressFacade }, { type: i1$1.CheckoutPaymentFacade }, { type: i4.ActiveCartFacade }, { type: i1.TranslationService }, { type: i2.CheckoutStepService }, { type: i1$1.CheckoutDeliveryModesFacade }, { type: i5.CheckoutPaymentTypeFacade }, { type: i5.CheckoutCostCenterFacade }, { type: i1.UserCostCenterService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class B2BCheckoutReviewSubmitModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: B2BCheckoutReviewSubmitModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: B2BCheckoutReviewSubmitModule, imports: [CommonModule,
            CardModule,
            I18nModule,
            UrlModule,
            RouterModule,
            PromotionsModule,
            IconModule,
            OutletModule,
            B2BCheckoutReviewSubmitComponent], exports: [B2BCheckoutReviewSubmitComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: B2BCheckoutReviewSubmitModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    CheckoutReviewOrder: {
                        component: B2BCheckoutReviewSubmitComponent,
                        guards: [CheckoutAuthGuard, CartNotEmptyGuard],
                    },
                },
            }),
        ], imports: [CommonModule,
            CardModule,
            I18nModule,
            UrlModule,
            RouterModule,
            PromotionsModule,
            IconModule,
            OutletModule,
            B2BCheckoutReviewSubmitComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: B2BCheckoutReviewSubmitModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        CardModule,
                        I18nModule,
                        UrlModule,
                        RouterModule,
                        PromotionsModule,
                        IconModule,
                        OutletModule,
                        B2BCheckoutReviewSubmitComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                CheckoutReviewOrder: {
                                    component: B2BCheckoutReviewSubmitComponent,
                                    guards: [CheckoutAuthGuard, CartNotEmptyGuard],
                                },
                            },
                        }),
                    ],
                    exports: [B2BCheckoutReviewSubmitComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CheckoutB2BAuthGuard extends CheckoutAuthGuard {
    constructor(authService, authRedirectService, checkoutConfigService, activeCartFacade, semanticPathService, router, userAccountFacade, globalMessageService) {
        super(authService, authRedirectService, checkoutConfigService, activeCartFacade, semanticPathService, router);
        this.authService = authService;
        this.authRedirectService = authRedirectService;
        this.checkoutConfigService = checkoutConfigService;
        this.activeCartFacade = activeCartFacade;
        this.semanticPathService = semanticPathService;
        this.router = router;
        this.userAccountFacade = userAccountFacade;
        this.globalMessageService = globalMessageService;
    }
    canActivate() {
        return combineLatest([
            this.authService.isUserLoggedIn(),
            this.activeCartFacade.isGuestCart(),
            this.userAccountFacade.get(),
            this.activeCartFacade.isStable(),
        ]).pipe(map(([isLoggedIn, isGuestCart, user, isStable]) => ({
            isLoggedIn,
            isGuestCart,
            user,
            isStable,
        })), filter((data) => data.isStable), 
        // if the user is authenticated and we have their data, OR if the user is anonymous
        filter((data) => (!!data.user && data.isLoggedIn) || !data.isLoggedIn), map((data) => {
            if (!data.isLoggedIn) {
                return data.isGuestCart ? true : this.handleAnonymousUser();
            }
            else if (data.user && 'roles' in data.user) {
                return this.handleUserRole(data.user);
            }
            return data.isLoggedIn;
        }));
    }
    handleUserRole(user) {
        const roles = user.roles;
        if (roles?.includes(B2BUserRole.CUSTOMER)) {
            return true;
        }
        this.globalMessageService.add({ key: 'checkoutB2B.invalid.accountType' }, GlobalMessageType.MSG_TYPE_WARNING);
        return this.router.parseUrl(this.semanticPathService.get('home') ?? '');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutB2BAuthGuard, deps: [{ token: i1.AuthService }, { token: i1.AuthRedirectService }, { token: i2.CheckoutConfigService }, { token: i4.ActiveCartFacade }, { token: i1.SemanticPathService }, { token: i3.Router }, { token: i5$1.UserAccountFacade }, { token: i1.GlobalMessageService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutB2BAuthGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutB2BAuthGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.AuthService }, { type: i1.AuthRedirectService }, { type: i2.CheckoutConfigService }, { type: i4.ActiveCartFacade }, { type: i1.SemanticPathService }, { type: i3.Router }, { type: i5$1.UserAccountFacade }, { type: i1.GlobalMessageService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CheckoutB2BStepsSetGuard extends CheckoutStepsSetGuard {
    constructor(checkoutStepService, routingConfigService, checkoutDeliveryAddressFacade, checkoutPaymentFacade, checkoutDeliveryModesFacade, router, checkoutPaymentTypeFacade, checkoutCostCenterFacade, activeCartFacade) {
        super(checkoutStepService, routingConfigService, checkoutDeliveryAddressFacade, checkoutPaymentFacade, checkoutDeliveryModesFacade, router, activeCartFacade);
        this.checkoutStepService = checkoutStepService;
        this.routingConfigService = routingConfigService;
        this.checkoutDeliveryAddressFacade = checkoutDeliveryAddressFacade;
        this.checkoutPaymentFacade = checkoutPaymentFacade;
        this.checkoutDeliveryModesFacade = checkoutDeliveryModesFacade;
        this.router = router;
        this.checkoutPaymentTypeFacade = checkoutPaymentTypeFacade;
        this.checkoutCostCenterFacade = checkoutCostCenterFacade;
        this.activeCartFacade = activeCartFacade;
        this.logger = inject(LoggerService);
    }
    canActivate(route) {
        let currentIndex = -1;
        const currentRouteUrl = '/' + route.url.join('/');
        // check whether the previous step is set
        return combineLatest([
            this.checkoutStepService.steps$,
            this.checkoutPaymentTypeFacade.isAccountPayment(),
        ]).pipe(tap(([, isAccount]) => {
            this.checkoutStepService.disableEnableStep(CheckoutStepType.PAYMENT_DETAILS, isAccount);
        }), take(1), switchMap(([steps, isAccount]) => {
            currentIndex = steps.findIndex((step) => {
                const stepRouteUrl = `/${this.routingConfigService.getRouteConfig(step.routeName)?.paths?.[0]}`;
                return stepRouteUrl === currentRouteUrl;
            });
            // get current step
            let currentStep;
            if (currentIndex >= 0) {
                currentStep = steps[currentIndex];
            }
            if (currentStep) {
                return this.isB2BStepSet(steps[currentIndex - 1], isAccount);
            }
            else {
                if (isDevMode()) {
                    this.logger.warn(`Missing step with route '${currentRouteUrl}' in checkout configuration or this step is disabled.`);
                }
                return of(this.getUrl('checkout'));
            }
        }));
    }
    isB2BStepSet(step, isAccountPayment) {
        if (step && !step.disabled) {
            switch (step.type[0]) {
                case CheckoutStepType.PAYMENT_TYPE: {
                    return this.isPaymentTypeSet(step);
                }
                case CheckoutStepType.DELIVERY_ADDRESS: {
                    return this.isDeliveryAddressAndCostCenterSet(step, isAccountPayment);
                }
                case CheckoutStepType.DELIVERY_MODE: {
                    return this.isDeliveryModeSet(step);
                }
                case CheckoutStepType.PAYMENT_DETAILS: {
                    return this.isPaymentDetailsSet(step);
                }
                case CheckoutStepType.REVIEW_ORDER: {
                    break;
                }
            }
        }
        return of(true);
    }
    isPaymentTypeSet(step) {
        return this.checkoutPaymentTypeFacade.getSelectedPaymentTypeState().pipe(filter((state) => !state.loading), map((state) => state.data), map((paymentType) => {
            if (paymentType) {
                return true;
            }
            else {
                return this.getUrl(step.routeName);
            }
        }));
    }
    isDeliveryAddressAndCostCenterSet(step, isAccountPayment) {
        return combineLatest([
            this.checkoutDeliveryAddressFacade.getDeliveryAddressState().pipe(filter((state) => !state.loading), map((state) => state.data)),
            this.checkoutCostCenterFacade.getCostCenterState().pipe(filter((state) => !state.loading), map((state) => state.data)),
        ]).pipe(map(([deliveryAddress, costCenter]) => {
            if (isAccountPayment) {
                if (deliveryAddress &&
                    Object.keys(deliveryAddress).length &&
                    !!costCenter) {
                    return true;
                }
                else {
                    return this.getUrl(step.routeName);
                }
            }
            else {
                if (deliveryAddress &&
                    Object.keys(deliveryAddress).length &&
                    costCenter === undefined) {
                    return true;
                }
                else {
                    return this.getUrl(step.routeName);
                }
            }
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutB2BStepsSetGuard, deps: [{ token: i2.CheckoutStepService }, { token: i1.RoutingConfigService }, { token: i1$1.CheckoutDeliveryAddressFacade }, { token: i1$1.CheckoutPaymentFacade }, { token: i1$1.CheckoutDeliveryModesFacade }, { token: i3.Router }, { token: i5.CheckoutPaymentTypeFacade }, { token: i5.CheckoutCostCenterFacade }, { token: i4.ActiveCartFacade }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutB2BStepsSetGuard, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutB2BStepsSetGuard, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i2.CheckoutStepService }, { type: i1.RoutingConfigService }, { type: i1$1.CheckoutDeliveryAddressFacade }, { type: i1$1.CheckoutPaymentFacade }, { type: i1$1.CheckoutDeliveryModesFacade }, { type: i3.Router }, { type: i5.CheckoutPaymentTypeFacade }, { type: i5.CheckoutCostCenterFacade }, { type: i4.ActiveCartFacade }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CheckoutB2BComponentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutB2BComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CheckoutB2BComponentsModule, imports: [CommonModule,
            CheckoutCostCenterModule,
            CheckoutPaymentTypeModule,
            B2BCheckoutDeliveryAddressModule,
            B2BCheckoutReviewSubmitModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutB2BComponentsModule, providers: [
            {
                provide: CheckoutAuthGuard,
                useExisting: CheckoutB2BAuthGuard,
            },
            {
                provide: CheckoutStepsSetGuard,
                useExisting: CheckoutB2BStepsSetGuard,
            },
        ], imports: [CommonModule,
            CheckoutCostCenterModule,
            CheckoutPaymentTypeModule,
            B2BCheckoutDeliveryAddressModule,
            B2BCheckoutReviewSubmitModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutB2BComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        CheckoutCostCenterModule,
                        CheckoutPaymentTypeModule,
                        B2BCheckoutDeliveryAddressModule,
                        B2BCheckoutReviewSubmitModule,
                    ],
                    providers: [
                        {
                            provide: CheckoutAuthGuard,
                            useExisting: CheckoutB2BAuthGuard,
                        },
                        {
                            provide: CheckoutStepsSetGuard,
                            useExisting: CheckoutB2BStepsSetGuard,
                        },
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { B2BCheckoutDeliveryAddressComponent, B2BCheckoutDeliveryAddressModule, B2BCheckoutReviewSubmitComponent, B2BCheckoutReviewSubmitModule, CheckoutB2BAuthGuard, CheckoutB2BComponentsModule, CheckoutB2BStepsSetGuard, CheckoutCostCenterComponent, CheckoutCostCenterModule, CheckoutPaymentTypeComponent, CheckoutPaymentTypeModule };
//# sourceMappingURL=spartacus-checkout-b2b-components.mjs.map
