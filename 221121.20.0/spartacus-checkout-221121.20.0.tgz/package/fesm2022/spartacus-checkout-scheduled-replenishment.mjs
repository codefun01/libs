import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { CheckoutScheduledReplenishmentComponentsModule } from '@spartacus/checkout/scheduled-replenishment/components';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class CheckoutScheduledReplenishmentModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutScheduledReplenishmentModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: CheckoutScheduledReplenishmentModule, imports: [CheckoutScheduledReplenishmentComponentsModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutScheduledReplenishmentModule, imports: [CheckoutScheduledReplenishmentComponentsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: CheckoutScheduledReplenishmentModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CheckoutScheduledReplenishmentComponentsModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/*
 * Public API Surface of checkout
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CheckoutScheduledReplenishmentModule };
//# sourceMappingURL=spartacus-checkout-scheduled-replenishment.mjs.map
