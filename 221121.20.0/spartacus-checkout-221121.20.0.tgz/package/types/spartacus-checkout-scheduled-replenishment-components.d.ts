import * as i0 from '@angular/core';
import { OnDestroy, OnInit, ViewContainerRef } from '@angular/core';
import * as i5 from '@angular/forms';
import { UntypedFormBuilder } from '@angular/forms';
import { CheckoutPlaceOrderComponent } from '@spartacus/checkout/base/components';
import * as i4 from '@spartacus/core';
import { EventService, RoutingService } from '@spartacus/core';
import { ScheduleReplenishmentForm, ORDER_TYPE, OrderFacade, ScheduledReplenishmentOrderFacade, DaysOfWeek } from '@spartacus/order/root';
import * as i1 from '@spartacus/storefront';
import { LaunchDialogService, ICON_TYPE } from '@spartacus/storefront';
import { Subscription, Observable, BehaviorSubject } from 'rxjs';
import * as i1$1 from '@angular/common';
import * as i3 from '@angular/router';

declare class CheckoutReplenishmentFormService implements OnDestroy {
    protected eventService: EventService;
    protected subscriptions: Subscription;
    /**
     * Default form data
     */
    readonly defaultFormData: ScheduleReplenishmentForm;
    private scheduleReplenishmentFormData$;
    protected orderType$: Observable<ORDER_TYPE>;
    constructor(eventService: EventService);
    protected registerOrderTypeEventListers(): void;
    /**
     * Get replenishment form data
     */
    getScheduleReplenishmentFormData(): Observable<ScheduleReplenishmentForm>;
    /**
     * Set replenishment form data
     * @param formData : an object containing the data for scheduling a replenishment order
     */
    setScheduleReplenishmentFormData(formData: ScheduleReplenishmentForm): void;
    /**
     * Clears the existing replenishment form data to include the default replenishment form data
     */
    resetScheduleReplenishmentFormData(): void;
    /**
     * Get current checkout order type
     */
    getOrderType(): Observable<ORDER_TYPE>;
    /**
     * Set checkout order type
     * @param orderType : an enum of types of order we are placing
     */
    setOrderType(orderType: ORDER_TYPE): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutReplenishmentFormService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CheckoutReplenishmentFormService>;
}

declare class CheckoutScheduledReplenishmentPlaceOrderComponent extends CheckoutPlaceOrderComponent implements OnInit, OnDestroy {
    protected orderFacade: OrderFacade;
    protected routingService: RoutingService;
    protected fb: UntypedFormBuilder;
    protected launchDialogService: LaunchDialogService;
    protected vcr: ViewContainerRef;
    protected checkoutReplenishmentFormService: CheckoutReplenishmentFormService;
    protected scheduledReplenishmentOrderFacade: ScheduledReplenishmentOrderFacade;
    private featureTogglesService;
    protected subscriptions: Subscription;
    currentOrderType: ORDER_TYPE;
    scheduleReplenishmentFormData: ScheduleReplenishmentForm;
    daysOfWeekNotChecked$: BehaviorSubject<boolean>;
    constructor(orderFacade: OrderFacade, routingService: RoutingService, fb: UntypedFormBuilder, launchDialogService: LaunchDialogService, vcr: ViewContainerRef, checkoutReplenishmentFormService: CheckoutReplenishmentFormService, scheduledReplenishmentOrderFacade: ScheduledReplenishmentOrderFacade);
    submitForm(): void;
    protected launchScheduledReplenishmentOrder(): void;
    ngOnInit(): void;
    onSuccess(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutScheduledReplenishmentPlaceOrderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutScheduledReplenishmentPlaceOrderComponent, "cx-place-order", never, {}, {}, never, never, true, never>;
}

declare class CheckoutScheduledReplenishmentPlaceOrderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutScheduledReplenishmentPlaceOrderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutScheduledReplenishmentPlaceOrderModule, never, [typeof i1.AtMessageModule, typeof i1$1.CommonModule, typeof i3.RouterModule, typeof i4.UrlModule, typeof i4.I18nModule, typeof i5.ReactiveFormsModule, typeof CheckoutScheduledReplenishmentPlaceOrderComponent], [typeof CheckoutScheduledReplenishmentPlaceOrderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutScheduledReplenishmentPlaceOrderModule>;
}

declare class CheckoutScheduleReplenishmentOrderComponent implements OnInit, OnDestroy {
    protected checkoutReplenishmentFormService: CheckoutReplenishmentFormService;
    protected subscription: Subscription;
    iconTypes: typeof ICON_TYPE;
    orderTypes: typeof ORDER_TYPE;
    daysOfWeek: DaysOfWeek[];
    recurrencePeriodType: string[];
    selectedOrderType$: Observable<ORDER_TYPE>;
    isMonthly: Boolean;
    isWeekly: Boolean;
    currentDaysOfWeek: DaysOfWeek[];
    numberOfDays: string[];
    numberOfWeeks: string[];
    currentDate: string | undefined;
    scheduleReplenishmentFormData: ScheduleReplenishmentForm;
    constructor(checkoutReplenishmentFormService: CheckoutReplenishmentFormService);
    ngOnInit(): void;
    changeOrderType(orderType: ORDER_TYPE): void;
    changeNumberOfDays(nDays: string): void;
    changeNumberOfWeeks(nWeeks: string): void;
    changeRecurrencePeriodType(type: string): void;
    changeDayOfTheMonth(dayOfMonth: string): void;
    changeReplenishmentStartDate(date: string): void;
    changeRepeatDays(day: DaysOfWeek, isChecked: boolean): void;
    hasDaysOfWeekChecked(day: DaysOfWeek): boolean;
    private initConfig;
    private createNumberStringArray;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutScheduleReplenishmentOrderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckoutScheduleReplenishmentOrderComponent, "cx-schedule-replenishment-order", never, {}, {}, never, never, true, never>;
}

declare class CheckoutScheduleReplenishmentOrderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutScheduleReplenishmentOrderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutScheduleReplenishmentOrderModule, never, [typeof i1$1.CommonModule, typeof i3.RouterModule, typeof i4.I18nModule, typeof i1.IconModule, typeof CheckoutScheduleReplenishmentOrderComponent], [typeof CheckoutScheduleReplenishmentOrderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutScheduleReplenishmentOrderModule>;
}

declare class CheckoutScheduledReplenishmentComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckoutScheduledReplenishmentComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CheckoutScheduledReplenishmentComponentsModule, never, [typeof i1$1.CommonModule, typeof CheckoutScheduleReplenishmentOrderModule, typeof CheckoutScheduledReplenishmentPlaceOrderModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CheckoutScheduledReplenishmentComponentsModule>;
}

export { CheckoutReplenishmentFormService, CheckoutScheduleReplenishmentOrderComponent, CheckoutScheduleReplenishmentOrderModule, CheckoutScheduledReplenishmentComponentsModule, CheckoutScheduledReplenishmentPlaceOrderComponent, CheckoutScheduledReplenishmentPlaceOrderModule };
