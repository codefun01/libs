import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    dpPaymentForm: {
        dpPaymentForm: {
            redirect: string;
            callback: string;
            cancelledOrFailed: string;
            error: {
                redirect: string;
                paymentFetch: string;
                unknown: string;
            };
            confirmation: {
                heading: string;
                text: string;
            };
        };
    };
};

declare const de: {
    dpPaymentForm: {
        dpPaymentForm: {
            redirect: string;
            callback: string;
            cancelledOrFailed: string;
            error: {
                redirect: string;
                paymentFetch: string;
                unknown: string;
            };
            confirmation: {
                heading: string;
                text: string;
            };
        };
    };
};

declare const en: {
    dpPaymentForm: {
        dpPaymentForm: {
            redirect: string;
            callback: string;
            cancelledOrFailed: string;
            error: {
                redirect: string;
                paymentFetch: string;
                unknown: string;
            };
            confirmation: {
                heading: string;
                text: string;
            };
        };
    };
};

declare const es: {
    dpPaymentForm: {
        dpPaymentForm: {
            redirect: string;
            callback: string;
            cancelledOrFailed: string;
            error: {
                redirect: string;
                paymentFetch: string;
                unknown: string;
            };
            confirmation: {
                heading: string;
                text: string;
            };
        };
    };
};

declare const es_CO: {
    dpPaymentForm: {
        dpPaymentForm: {
            redirect: string;
            callback: string;
            cancelledOrFailed: string;
            error: {
                redirect: string;
                paymentFetch: string;
                unknown: string;
            };
            confirmation: {
                heading: string;
                text: string;
            };
        };
    };
};

declare const fr: {
    dpPaymentForm: {
        dpPaymentForm: {
            redirect: string;
            callback: string;
            cancelledOrFailed: string;
            error: {
                redirect: string;
                paymentFetch: string;
                unknown: string;
            };
            confirmation: {
                heading: string;
                text: string;
            };
        };
    };
};

declare const hi: {
    dpPaymentForm: {
        dpPaymentForm: {
            redirect: string;
            callback: string;
            cancelledOrFailed: string;
            error: {
                redirect: string;
                paymentFetch: string;
                unknown: string;
            };
            confirmation: {
                heading: string;
                text: string;
            };
        };
    };
};

declare const hu: {
    dpPaymentForm: {
        dpPaymentForm: {
            redirect: string;
            callback: string;
            cancelledOrFailed: string;
            error: {
                redirect: string;
                paymentFetch: string;
                unknown: string;
            };
            confirmation: {
                heading: string;
                text: string;
            };
        };
    };
};

declare const id: {
    dpPaymentForm: {
        dpPaymentForm: {
            redirect: string;
            callback: string;
            cancelledOrFailed: string;
            error: {
                redirect: string;
                paymentFetch: string;
                unknown: string;
            };
            confirmation: {
                heading: string;
                text: string;
            };
        };
    };
};

declare const it: {
    dpPaymentForm: {
        dpPaymentForm: {
            redirect: string;
            callback: string;
            cancelledOrFailed: string;
            error: {
                redirect: string;
                paymentFetch: string;
                unknown: string;
            };
            confirmation: {
                heading: string;
                text: string;
            };
        };
    };
};

declare const ja: {
    dpPaymentForm: {
        dpPaymentForm: {
            redirect: string;
            callback: string;
            cancelledOrFailed: string;
            error: {
                redirect: string;
                paymentFetch: string;
                unknown: string;
            };
            confirmation: {
                heading: string;
                text: string;
            };
        };
    };
};

declare const ko: {
    dpPaymentForm: {
        dpPaymentForm: {
            redirect: string;
            callback: string;
            cancelledOrFailed: string;
            error: {
                redirect: string;
                paymentFetch: string;
                unknown: string;
            };
            confirmation: {
                heading: string;
                text: string;
            };
        };
    };
};

declare const pl: {
    dpPaymentForm: {
        dpPaymentForm: {
            redirect: string;
            callback: string;
            cancelledOrFailed: string;
            error: {
                redirect: string;
                paymentFetch: string;
                unknown: string;
            };
            confirmation: {
                heading: string;
                text: string;
            };
        };
    };
};

declare const pt: {
    dpPaymentForm: {
        dpPaymentForm: {
            redirect: string;
            callback: string;
            cancelledOrFailed: string;
            error: {
                redirect: string;
                paymentFetch: string;
                unknown: string;
            };
            confirmation: {
                heading: string;
                text: string;
            };
        };
    };
};

declare const ru: {
    dpPaymentForm: {
        dpPaymentForm: {
            redirect: string;
            callback: string;
            cancelledOrFailed: string;
            error: {
                redirect: string;
                paymentFetch: string;
                unknown: string;
            };
            confirmation: {
                heading: string;
                text: string;
            };
        };
    };
};

declare const zh: {
    dpPaymentForm: {
        dpPaymentForm: {
            redirect: string;
            callback: string;
            cancelledOrFailed: string;
            error: {
                redirect: string;
                paymentFetch: string;
                unknown: string;
            };
            confirmation: {
                heading: string;
                text: string;
            };
        };
    };
};

declare const zh_TW: {
    dpPaymentForm: {
        dpPaymentForm: {
            redirect: string;
            callback: string;
            cancelledOrFailed: string;
            error: {
                redirect: string;
                paymentFetch: string;
                unknown: string;
            };
            confirmation: {
                heading: string;
                text: string;
            };
        };
    };
};

declare const dpTranslationChunksConfig: TranslationChunksConfig;

export { dpTranslationChunksConfig, cs as dpTranslationsCs, de as dpTranslationsDe, en as dpTranslationsEn, es as dpTranslationsEs, es_CO as dpTranslationsEs_CO, fr as dpTranslationsFr, hi as dpTranslationsHi, hu as dpTranslationsHu, id as dpTranslationsId, it as dpTranslationsIt, ja as dpTranslationsJa, ko as dpTranslationsKo, pl as dpTranslationsPl, pt as dpTranslationsPt, ru as dpTranslationsRu, zh as dpTranslationsZh, zh_TW as dpTranslationsZh_TW };
