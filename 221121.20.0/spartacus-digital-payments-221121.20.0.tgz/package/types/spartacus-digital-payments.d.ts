import * as i0 from '@angular/core';
import { OnDestroy, OnInit, EventEmitter } from '@angular/core';
import * as i4 from '@spartacus/checkout/base/components';
import { CheckoutBillingAddressFormService, CheckoutPaymentMethodComponent, CheckoutStepService, CheckoutPaymentMethodModule } from '@spartacus/checkout/base/components';
import * as i1 from '@angular/common';
import * as i2 from '@angular/forms';
import * as i3 from '@ng-select/ng-select';
import * as i5 from '@spartacus/core';
import { Address, PaymentDetails, CommandService, QueryService, UserIdService, Query, Command, StatePersistenceService, GlobalMessageService, WindowRef, UserPaymentService, TranslationService } from '@spartacus/core';
import * as i3$1 from '@spartacus/storefront';
import { FocusConfig, ICON_TYPE, LaunchDialogService } from '@spartacus/storefront';
import { Observable, Subscription } from 'rxjs';
import { ActiveCartFacade } from '@spartacus/cart/base/root';
import * as i3$2 from '@angular/router';
import { ActivatedRoute, Router } from '@angular/router';
import { CheckoutDeliveryAddressService, CheckoutPaymentService } from '@spartacus/checkout/base/core';

interface DpPaymentRequest {
    url?: string;
    sessionId?: string;
    signature?: string;
}

declare module '@spartacus/storefront' {
    enum LAUNCH_CALLER {
        DP_SHOW_CONFIRMATION_DIALOG = "DP_SHOW_CONFIRMATION_DIALOG"
    }
}

declare abstract class DigitalPaymentsAdapter {
    abstract createPaymentRequest(userId?: string, cartId?: string): Observable<DpPaymentRequest>;
    abstract createPaymentDetails(sessionId: string, signature: string, userId?: string, cartId?: string, billingAddress?: Address): Observable<PaymentDetails>;
}

declare class DpCheckoutPaymentService {
    protected dpAdapter: DigitalPaymentsAdapter;
    protected command: CommandService;
    protected query: QueryService;
    protected userIdService: UserIdService;
    constructor(dpAdapter: DigitalPaymentsAdapter, command: CommandService, query: QueryService, userIdService: UserIdService);
    protected activeCartFacade: ActiveCartFacade;
    protected RequestUrlQuery: Query<DpPaymentRequest>;
    getCardRegistrationDetails(): Observable<DpPaymentRequest | undefined>;
    protected createPaymentDetailsCommand: Command<{
        sessionId: string;
        signature: string;
        billingAddress?: Address;
    }, PaymentDetails>;
    createPaymentDetails(sessionId: string, signature: string, billingAddress?: Address): Observable<PaymentDetails>;
    /**
     * Performs the necessary checkout preconditions.
     */
    protected checkoutPreconditions(): Observable<[string, string]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DpCheckoutPaymentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DpCheckoutPaymentService>;
}

declare class DpLocalStorageService implements OnDestroy {
    protected statePersistenceService: StatePersistenceService;
    constructor(statePersistenceService: StatePersistenceService);
    protected subscription: Subscription;
    syncCardRegistrationState(request: DpPaymentRequest): void;
    readCardRegistrationState(): DpPaymentRequest;
    protected clearDpStorage(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DpLocalStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DpLocalStorageService>;
}

declare class DpPaymentFormComponent implements OnInit {
    private dpPaymentService;
    private dpStorageService;
    private globalMsgService;
    private winRef;
    closeForm: EventEmitter<any>;
    constructor(dpPaymentService: DpCheckoutPaymentService, dpStorageService: DpLocalStorageService, globalMsgService: GlobalMessageService, winRef: WindowRef);
    ngOnInit(): void;
    redirect(url: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DpPaymentFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DpPaymentFormComponent, "cx-dp-payment-form", never, {}, { "closeForm": "closeForm"; }, never, never, true, never>;
}

declare class DpPaymentFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DpPaymentFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DpPaymentFormModule, never, [typeof i1.CommonModule, typeof i2.ReactiveFormsModule, typeof i3.NgSelectModule, typeof i5.I18nModule, typeof i3$1.SpinnerModule, typeof DpPaymentFormComponent], [typeof DpPaymentFormComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DpPaymentFormModule>;
}

declare class DpConfirmationDialogComponent {
    focusConfig: FocusConfig;
    iconTypes: typeof ICON_TYPE;
    protected launchDialogService: LaunchDialogService;
    protected activatedRoute: ActivatedRoute;
    protected router: Router;
    cardSaveCancelled: boolean;
    dismissDialog(reason?: any): void;
    continue(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DpConfirmationDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DpConfirmationDialogComponent, "cx-dp-confirmation-dialog", never, {}, {}, never, never, true, never>;
}

declare class DpConfirmationDialogModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DpConfirmationDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DpConfirmationDialogModule, never, [typeof i1.CommonModule, typeof i5.I18nModule, typeof i3$1.KeyboardFocusModule, typeof i3$1.IconModule, typeof i5.FeaturesConfigModule, typeof DpConfirmationDialogComponent], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DpConfirmationDialogModule>;
}

declare class DpPaymentCallbackComponent implements OnInit {
    protected dpPaymentService: DpCheckoutPaymentService;
    protected dpStorageService: DpLocalStorageService;
    protected globalMsgService: GlobalMessageService;
    protected route: ActivatedRoute;
    closeCallback: EventEmitter<any>;
    paymentDetailsAdded: EventEmitter<any>;
    protected billingAddressService: CheckoutBillingAddressFormService;
    protected launchDialogService: LaunchDialogService;
    showBillingAddressForm: boolean;
    constructor(dpPaymentService: DpCheckoutPaymentService, dpStorageService: DpLocalStorageService, globalMsgService: GlobalMessageService, route: ActivatedRoute);
    ngOnInit(): void;
    back(): void;
    next(): void;
    private fetchPaymentDetails;
    static ɵfac: i0.ɵɵFactoryDeclaration<DpPaymentCallbackComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DpPaymentCallbackComponent, "cx-dp-payment-callback", never, {}, { "closeCallback": "closeCallback"; "paymentDetailsAdded": "paymentDetailsAdded"; }, never, never, true, never>;
}

declare class DpPaymentCallbackModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DpPaymentCallbackModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DpPaymentCallbackModule, never, [typeof i1.CommonModule, typeof i3$1.SpinnerModule, typeof i5.I18nModule, typeof i4.CheckoutBillingAddressFormModule, typeof i5.FeaturesConfigModule, typeof DpConfirmationDialogModule, typeof DpPaymentCallbackComponent], [typeof DpPaymentCallbackComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DpPaymentCallbackModule>;
}

declare class DpPaymentMethodComponent extends CheckoutPaymentMethodComponent {
    protected userPaymentService: UserPaymentService;
    protected checkoutDeliveryAddressFacade: CheckoutDeliveryAddressService;
    protected checkoutPaymentFacade: CheckoutPaymentService;
    protected activatedRoute: ActivatedRoute;
    protected translationService: TranslationService;
    protected activeCartFacade: ActiveCartFacade;
    protected checkoutStepService: CheckoutStepService;
    protected globalMessageService: GlobalMessageService;
    showCallbackScreen: boolean;
    isDpCallback(): boolean;
    hideCallbackScreen(): void;
    paymentDetailsAdded(paymentDetails: PaymentDetails): void;
    protected onSuccess(): void;
    constructor(userPaymentService: UserPaymentService, checkoutDeliveryAddressFacade: CheckoutDeliveryAddressService, checkoutPaymentFacade: CheckoutPaymentService, activatedRoute: ActivatedRoute, translationService: TranslationService, activeCartFacade: ActiveCartFacade, checkoutStepService: CheckoutStepService, globalMessageService: GlobalMessageService);
    static ɵfac: i0.ɵɵFactoryDeclaration<DpPaymentMethodComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DpPaymentMethodComponent, "cx-payment-method", never, {}, {}, never, never, true, never>;
}

declare class DpPaymentMethodModule extends CheckoutPaymentMethodModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DpPaymentMethodModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DpPaymentMethodModule, never, [typeof i1.CommonModule, typeof DpPaymentFormModule, typeof i3$2.RouterModule, typeof i3$1.CardModule, typeof i3$1.SpinnerModule, typeof i5.I18nModule, typeof DpPaymentCallbackModule, typeof i5.ConfigModule, typeof i5.FeaturesConfigModule, typeof DpPaymentMethodComponent], [typeof DpPaymentMethodComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DpPaymentMethodModule>;
}

declare class DpCheckoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DpCheckoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DpCheckoutModule, never, [typeof DpPaymentMethodModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DpCheckoutModule>;
}

declare class DigitalPaymentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DigitalPaymentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DigitalPaymentsModule, never, [typeof DpCheckoutModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DigitalPaymentsModule>;
}

export { DigitalPaymentsModule, DpCheckoutModule, DpCheckoutPaymentService };
export type { DpPaymentRequest };
