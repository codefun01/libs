import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, ChangeDetectionStrategy, Component, NgModule, EventEmitter, Output } from '@angular/core';
import * as i2 from '@spartacus/core';
import { Config, HttpParamsURIEncoder, TranslatePipe, I18nModule, FeaturesConfigModule, provideDefaultConfig, CommandStrategy, OCC_USER_ID_ANONYMOUS, GlobalMessageType, ConfigModule } from '@spartacus/core';
import * as i1 from '@angular/common/http';
import { HttpParams } from '@angular/common/http';
import { CommonModule, NgIf, NgFor, AsyncPipe } from '@angular/common';
import * as i4 from '@angular/router';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import * as i5 from '@spartacus/checkout/base/components';
import { CheckoutBillingAddressFormService, CheckoutBillingAddressFormComponent, CheckoutBillingAddressFormModule, CheckoutPaymentMethodComponent, CheckoutPaymentMethodModule } from '@spartacus/checkout/base/components';
import { ICON_TYPE, LaunchDialogService, FocusDirective, IconComponent, DIALOG_TYPE, KeyboardFocusModule, IconModule, LAUNCH_CALLER, SpinnerComponent, SpinnerModule, CardComponent, CardModule } from '@spartacus/storefront';
import { combineLatest, Subscription, of, take as take$1 } from 'rxjs';
import { switchMap, map, take } from 'rxjs/operators';
import * as i4$1 from '@spartacus/cart/base/root';
import { ActiveCartFacade } from '@spartacus/cart/base/root';
import { ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import * as i2$1 from '@spartacus/checkout/base/core';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const occDigitalPaymentsEndpoints = {
    paymentRequest: 'users/${userId}/carts/${cartId}/payment/digitalPayments/request',
    paymentDetails: 'users/${userId}/carts/${cartId}/payment/digitalPayments/response',
};
const occDigitalPaymentsConfig = {
    backend: {
        occ: {
            endpoints: {
                ...occDigitalPaymentsEndpoints,
            },
        },
    },
};
class DigitalPaymentsConfig {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DigitalPaymentsConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DigitalPaymentsConfig, providedIn: 'root', useExisting: Config }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DigitalPaymentsConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                    useExisting: Config,
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const DP_DETAILS_NORMALIZER = new InjectionToken('DpDetailsNormalizer');
const DP_REQUEST_NORMALIZER = new InjectionToken('DpRequestNormalizer');

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DigitalPaymentsAdapter {
}

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccDpDetailsNormalizer {
    convert(source, target) {
        if (target === undefined) {
            target = { ...source };
        }
        return target;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccDpDetailsNormalizer, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccDpDetailsNormalizer, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccDpDetailsNormalizer, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccDpRequestNormalizer {
    convert(source, target) {
        if (target === undefined) {
            target = { ...source };
        }
        target.url = source.postUrl;
        target.sessionId = source?.parameters?.entry?.find((it) => it.key === 'session_id')?.value;
        target.signature = source?.parameters?.entry?.find((it) => it.key === 'signature')?.value;
        return target;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccDpRequestNormalizer, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccDpRequestNormalizer, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccDpRequestNormalizer, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const CURRENT_CART = 'current';
const DP_CARD_REGISTRATION_STATUS = 'x-card-registration-status';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class OccDigitalPaymentsAdapter {
    constructor(http, occEndpoints, converter) {
        this.http = http;
        this.occEndpoints = occEndpoints;
        this.converter = converter;
        this.paramEncoder = new HttpParamsURIEncoder();
        this.config = inject(DigitalPaymentsConfig);
    }
    createPaymentRequest(userId, cartId = CURRENT_CART) {
        const url = this.occEndpoints.buildUrl('paymentRequest', {
            urlParams: { userId, cartId },
        });
        return this.http
            .post(url, null)
            .pipe(this.converter.pipeable(DP_REQUEST_NORMALIZER));
    }
    createPaymentDetails(sessionId, signature, userId, cartId = CURRENT_CART, billingAddress) {
        const params = this.getDpHttpParams(sessionId, signature, billingAddress);
        const url = this.occEndpoints.buildUrl('paymentDetails', {
            urlParams: { userId, cartId },
        });
        return this.http
            .post(url, null, { params: params })
            .pipe(this.converter.pipeable(DP_DETAILS_NORMALIZER));
    }
    getDpHttpParams(sessionId, signature, billingAddress) {
        let params = new HttpParams({ encoder: this.paramEncoder });
        const paramName = this.config.digitalPayments?.occQueryParams;
        params = this.appendParam(params, paramName?.sessionId, sessionId);
        params = this.appendParam(params, paramName?.signature, signature);
        if (billingAddress && paramName) {
            params = this.appendBillingAddressParams(params, paramName, billingAddress);
        }
        return params;
    }
    appendParam(params, paramName, paramValue) {
        if (paramName && paramValue) {
            params = params.append(paramName, paramValue);
        }
        return params;
    }
    appendBillingAddressParams(params, paramName, billingAddress) {
        params = this.appendParam(params, paramName.billingAddress, 'true');
        params = this.appendParam(params, paramName.country, billingAddress.country?.isocode);
        params = this.appendParam(params, paramName.firstName, billingAddress.firstName);
        params = this.appendParam(params, paramName.lastName, billingAddress.lastName);
        params = this.appendParam(params, paramName.line1, billingAddress.line1);
        params = this.appendParam(params, paramName.line2, billingAddress.line2);
        params = this.appendParam(params, paramName.town, billingAddress.town);
        params = this.appendParam(params, paramName.region, billingAddress.region?.isocodeShort);
        params = this.appendParam(params, paramName.postalCode, billingAddress.postalCode);
        return params;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccDigitalPaymentsAdapter, deps: [{ token: i1.HttpClient }, { token: i2.OccEndpointsService }, { token: i2.ConverterService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccDigitalPaymentsAdapter }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: OccDigitalPaymentsAdapter, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: i2.OccEndpointsService }, { type: i2.ConverterService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultDigitalPaymentsConfig = {
    digitalPayments: {
        occQueryParams: {
            sessionId: 'sid',
            signature: 'sign',
            billingAddress: 'billingAddress',
            country: 'country',
            firstName: 'firstName',
            lastName: 'lastName',
            line1: 'line1',
            line2: 'line2',
            town: 'town',
            region: 'region',
            postalCode: 'postalCode',
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DpConfirmationDialogComponent {
    constructor() {
        this.focusConfig = {
            trap: true,
            block: true,
            autofocus: 'button',
            focusOnEscape: true,
        };
        this.iconTypes = ICON_TYPE;
        this.launchDialogService = inject(LaunchDialogService);
        this.activatedRoute = inject(ActivatedRoute);
        this.router = inject(Router);
        this.cardSaveCancelled = false;
    }
    dismissDialog(reason) {
        this.launchDialogService.closeDialog(reason);
    }
    continue() {
        const queryParams = { ...this.activatedRoute.snapshot.queryParams };
        delete queryParams[DP_CARD_REGISTRATION_STATUS];
        this.router.navigate([], {
            queryParams,
            relativeTo: this.activatedRoute,
        });
        this.cardSaveCancelled = true;
        this.launchDialogService.closeDialog('continue clicked');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpConfirmationDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: DpConfirmationDialogComponent, isStandalone: true, selector: "cx-dp-confirmation-dialog", ngImport: i0, template: "<div\n  class=\"cx-modal-container\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"dismissDialog('Escape clicked')\"\n  role=\"dialog\"\n  aria-modal=\"true\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <div class=\"cx-modal-content\">\n    <!-- Modal Header -->\n    <div class=\"cx-dialog-header modal-header\">\n      <h3 id=\"dialogTitle\" class=\"cx-dialog-title modal-title\">\n        {{ 'dpPaymentForm.confirmation.heading' | cxTranslate }}\n      </h3>\n      <button\n        type=\"button\"\n        class=\"close\"\n        title=\"{{ 'common.close' | cxTranslate }}\"\n        [attr.aria-label]=\"'common.close' | cxTranslate\"\n        (click)=\"dismissDialog('Cross click')\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\" />\n        </span>\n      </button>\n    </div>\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\">\n      <div class=\"cx-dialog-row\">\n        {{ 'dpPaymentForm.confirmation.text' | cxTranslate }}\n      </div>\n    </div>\n    <div class=\"cx-dialog-actions col-sm-12 col-md-6\">\n      <div class=\"cx-dialog-buttons\">\n        <button (click)=\"continue()\" class=\"btn btn-primary\" autofocus>\n          {{ 'common.continue' | cxTranslate }}\n        </button>\n        <button\n          class=\"link cx-action-link\"\n          (click)=\"dismissDialog('cancel clicked')\"\n          autofocus\n        >\n          {{ 'common.cancel' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n  </div>\n</div>\n", dependencies: [{ kind: "directive", type: FocusDirective, selector: "[cxFocus]", inputs: ["cxFocus"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpConfirmationDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-dp-confirmation-dialog', changeDetection: ChangeDetectionStrategy.OnPush, imports: [FocusDirective, IconComponent, TranslatePipe], template: "<div\n  class=\"cx-modal-container\"\n  [cxFocus]=\"focusConfig\"\n  (esc)=\"dismissDialog('Escape clicked')\"\n  role=\"dialog\"\n  aria-modal=\"true\"\n  aria-labelledby=\"dialogTitle\"\n>\n  <div class=\"cx-modal-content\">\n    <!-- Modal Header -->\n    <div class=\"cx-dialog-header modal-header\">\n      <h3 id=\"dialogTitle\" class=\"cx-dialog-title modal-title\">\n        {{ 'dpPaymentForm.confirmation.heading' | cxTranslate }}\n      </h3>\n      <button\n        type=\"button\"\n        class=\"close\"\n        title=\"{{ 'common.close' | cxTranslate }}\"\n        [attr.aria-label]=\"'common.close' | cxTranslate\"\n        (click)=\"dismissDialog('Cross click')\"\n      >\n        <span aria-hidden=\"true\">\n          <cx-icon [type]=\"iconTypes.CLOSE\" />\n        </span>\n      </button>\n    </div>\n    <!-- Modal Body -->\n    <div class=\"cx-dialog-body modal-body\">\n      <div class=\"cx-dialog-row\">\n        {{ 'dpPaymentForm.confirmation.text' | cxTranslate }}\n      </div>\n    </div>\n    <div class=\"cx-dialog-actions col-sm-12 col-md-6\">\n      <div class=\"cx-dialog-buttons\">\n        <button (click)=\"continue()\" class=\"btn btn-primary\" autofocus>\n          {{ 'common.continue' | cxTranslate }}\n        </button>\n        <button\n          class=\"link cx-action-link\"\n          (click)=\"dismissDialog('cancel clicked')\"\n          autofocus\n        >\n          {{ 'common.cancel' | cxTranslate }}\n        </button>\n      </div>\n    </div>\n  </div>\n</div>\n" }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const defaultDpConfirmationDialogConfig = {
    launch: {
        DP_SHOW_CONFIRMATION_DIALOG: {
            inlineRoot: true,
            component: DpConfirmationDialogComponent,
            dialogType: DIALOG_TYPE.DIALOG,
        },
    },
};

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DpConfirmationDialogModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpConfirmationDialogModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: DpConfirmationDialogModule, imports: [CommonModule,
            I18nModule,
            KeyboardFocusModule,
            IconModule,
            FeaturesConfigModule,
            DpConfirmationDialogComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpConfirmationDialogModule, providers: [provideDefaultConfig(defaultDpConfirmationDialogConfig)], imports: [CommonModule,
            I18nModule,
            KeyboardFocusModule,
            IconModule,
            FeaturesConfigModule,
            DpConfirmationDialogComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpConfirmationDialogModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        I18nModule,
                        KeyboardFocusModule,
                        IconModule,
                        FeaturesConfigModule,
                        DpConfirmationDialogComponent,
                    ],
                    providers: [provideDefaultConfig(defaultDpConfirmationDialogConfig)],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DpCheckoutPaymentService {
    constructor(dpAdapter, command, query, userIdService) {
        this.dpAdapter = dpAdapter;
        this.command = command;
        this.query = query;
        this.userIdService = userIdService;
        this.activeCartFacade = inject(ActiveCartFacade);
        this.RequestUrlQuery = this.query.create(() => {
            return this.checkoutPreconditions().pipe(switchMap(([userId, cartId]) => this.dpAdapter.createPaymentRequest(userId, cartId)));
        });
        this.createPaymentDetailsCommand = this.command.create((payload) => this.checkoutPreconditions().pipe(switchMap(([userId, cartId]) => {
            return this.dpAdapter.createPaymentDetails(payload.sessionId, payload.signature, userId, cartId, payload?.billingAddress);
        })), {
            strategy: CommandStrategy.Queue,
        });
    }
    getCardRegistrationDetails() {
        return this.RequestUrlQuery.getState().pipe(map((state) => {
            if (state.loading === false && state.error !== false) {
                throw new Error(state.error.message);
            }
            else {
                return state.data;
            }
        }));
    }
    createPaymentDetails(sessionId, signature, billingAddress) {
        return this.createPaymentDetailsCommand.execute({
            sessionId,
            signature,
            billingAddress,
        });
    }
    /**
     * Performs the necessary checkout preconditions.
     */
    checkoutPreconditions() {
        return combineLatest([
            this.userIdService.takeUserId(),
            this.activeCartFacade.takeActiveCartId(),
            this.activeCartFacade.isGuestCart(),
        ]).pipe(take(1), map(([userId, cartId, isGuestCart]) => {
            if (!userId ||
                !cartId ||
                (userId === OCC_USER_ID_ANONYMOUS && !isGuestCart)) {
                throw new Error('Checkout conditions not met');
            }
            return [userId, cartId];
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpCheckoutPaymentService, deps: [{ token: DigitalPaymentsAdapter }, { token: i2.CommandService }, { token: i2.QueryService }, { token: i2.UserIdService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpCheckoutPaymentService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpCheckoutPaymentService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: DigitalPaymentsAdapter }, { type: i2.CommandService }, { type: i2.QueryService }, { type: i2.UserIdService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
const KEY = 'digital-payment.checkout.request';
class DpLocalStorageService {
    constructor(statePersistenceService) {
        this.statePersistenceService = statePersistenceService;
        this.subscription = new Subscription();
    }
    syncCardRegistrationState(request) {
        this.subscription.add(this.statePersistenceService.syncWithStorage({
            key: KEY,
            state$: of(request),
        }));
    }
    readCardRegistrationState() {
        const paymentRequest = this.statePersistenceService.readStateFromStorage({
            key: KEY,
        });
        this.clearDpStorage();
        return paymentRequest;
    }
    clearDpStorage() {
        this.statePersistenceService.syncWithStorage({
            key: KEY,
            state$: of({}),
        });
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpLocalStorageService, deps: [{ token: i2.StatePersistenceService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpLocalStorageService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpLocalStorageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i2.StatePersistenceService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DpPaymentCallbackComponent {
    constructor(dpPaymentService, dpStorageService, globalMsgService, route) {
        this.dpPaymentService = dpPaymentService;
        this.dpStorageService = dpStorageService;
        this.globalMsgService = globalMsgService;
        this.route = route;
        this.closeCallback = new EventEmitter();
        this.paymentDetailsAdded = new EventEmitter();
        this.billingAddressService = inject(CheckoutBillingAddressFormService);
        this.launchDialogService = inject(LaunchDialogService);
        this.showBillingAddressForm = false;
    }
    ngOnInit() {
        const dpResponse = this.route.snapshot.queryParamMap.get(DP_CARD_REGISTRATION_STATUS);
        if (dpResponse?.toLowerCase() === 'successful') {
            this.showBillingAddressForm = true;
        }
        else {
            this.globalMsgService.add({ key: 'dpPaymentForm.cancelledOrFailed' }, GlobalMessageType.MSG_TYPE_WARNING);
            this.closeCallback.emit();
        }
    }
    back() {
        const dialog = this.launchDialogService.openDialog(LAUNCH_CALLER.DP_SHOW_CONFIRMATION_DIALOG, undefined, undefined);
        if (dialog) {
            dialog.pipe(take$1(1)).subscribe((result) => {
                if (result.instance.cardSaveCancelled === true) {
                    this.globalMsgService.add({ key: 'dpPaymentForm.cancelledOrFailed' }, GlobalMessageType.MSG_TYPE_WARNING);
                    this.closeCallback.emit();
                }
            });
        }
    }
    next() {
        if (this.billingAddressService.isBillingAddressSameAsDeliveryAddress() ||
            this.billingAddressService.isBillingAddressFormValid()) {
            const billingAddress = this.billingAddressService.getBillingAddress();
            this.fetchPaymentDetails(billingAddress);
        }
        else {
            this.billingAddressService.markAllAsTouched();
        }
    }
    fetchPaymentDetails(billingAddress) {
        const paymentRequest = this.dpStorageService.readCardRegistrationState();
        if (paymentRequest?.sessionId && paymentRequest?.signature) {
            this.dpPaymentService
                .createPaymentDetails(paymentRequest.sessionId, paymentRequest.signature, billingAddress)
                .subscribe((details) => {
                if (details?.id) {
                    this.paymentDetailsAdded.emit(details);
                }
                else if (details) {
                    this.globalMsgService.add({ key: 'dpPaymentForm.error.paymentFetch' }, GlobalMessageType.MSG_TYPE_ERROR);
                    this.closeCallback.emit();
                }
            });
        }
        else {
            this.globalMsgService.add({ key: 'dpPaymentForm.error.unknown' }, GlobalMessageType.MSG_TYPE_ERROR);
            this.closeCallback.emit();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentCallbackComponent, deps: [{ token: DpCheckoutPaymentService }, { token: DpLocalStorageService }, { token: i2.GlobalMessageService }, { token: i4.ActivatedRoute }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: DpPaymentCallbackComponent, isStandalone: true, selector: "cx-dp-payment-callback", outputs: { closeCallback: "closeCallback", paymentDetailsAdded: "paymentDetailsAdded" }, ngImport: i0, template: "<ng-container *ngIf=\"this.showBillingAddressForm; else showSpinner\">\n  <cx-checkout-billing-address-form />\n\n  <!-- BUTTON SECTION -->\n  <div class=\"cx-checkout-btns row\">\n    <div class=\"col-md-12 col-lg-6\">\n      <button class=\"btn btn-block btn-secondary\" (click)=\"back()\">\n        {{ 'common.back' | cxTranslate }}\n      </button>\n    </div>\n    <div class=\"col-md-12 col-lg-6\">\n      <button class=\"btn btn-block btn-primary\" (click)=\"next()\">\n        {{ 'common.continue' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</ng-container>\n\n<ng-template #showSpinner>\n  <div class=\"text-center\">{{ 'dpPaymentForm.callback' | cxTranslate }}</div>\n  <div class=\"cx-spinner\"><cx-spinner /></div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CheckoutBillingAddressFormComponent, selector: "cx-checkout-billing-address-form" }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentCallbackComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-dp-payment-callback', imports: [
                        NgIf,
                        CheckoutBillingAddressFormComponent,
                        SpinnerComponent,
                        TranslatePipe,
                    ], template: "<ng-container *ngIf=\"this.showBillingAddressForm; else showSpinner\">\n  <cx-checkout-billing-address-form />\n\n  <!-- BUTTON SECTION -->\n  <div class=\"cx-checkout-btns row\">\n    <div class=\"col-md-12 col-lg-6\">\n      <button class=\"btn btn-block btn-secondary\" (click)=\"back()\">\n        {{ 'common.back' | cxTranslate }}\n      </button>\n    </div>\n    <div class=\"col-md-12 col-lg-6\">\n      <button class=\"btn btn-block btn-primary\" (click)=\"next()\">\n        {{ 'common.continue' | cxTranslate }}\n      </button>\n    </div>\n  </div>\n</ng-container>\n\n<ng-template #showSpinner>\n  <div class=\"text-center\">{{ 'dpPaymentForm.callback' | cxTranslate }}</div>\n  <div class=\"cx-spinner\"><cx-spinner /></div>\n</ng-template>\n" }]
        }], ctorParameters: () => [{ type: DpCheckoutPaymentService }, { type: DpLocalStorageService }, { type: i2.GlobalMessageService }, { type: i4.ActivatedRoute }], propDecorators: { closeCallback: [{
                type: Output
            }], paymentDetailsAdded: [{
                type: Output
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DpPaymentCallbackModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentCallbackModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentCallbackModule, imports: [CommonModule,
            SpinnerModule,
            I18nModule,
            CheckoutBillingAddressFormModule,
            FeaturesConfigModule,
            DpConfirmationDialogModule,
            DpPaymentCallbackComponent], exports: [DpPaymentCallbackComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentCallbackModule, imports: [CommonModule,
            SpinnerModule,
            I18nModule,
            CheckoutBillingAddressFormModule,
            FeaturesConfigModule,
            DpConfirmationDialogModule,
            DpPaymentCallbackComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentCallbackModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        SpinnerModule,
                        I18nModule,
                        CheckoutBillingAddressFormModule,
                        FeaturesConfigModule,
                        DpConfirmationDialogModule,
                        DpPaymentCallbackComponent,
                    ],
                    exports: [DpPaymentCallbackComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DpPaymentFormComponent {
    constructor(dpPaymentService, dpStorageService, globalMsgService, winRef) {
        this.dpPaymentService = dpPaymentService;
        this.dpStorageService = dpStorageService;
        this.globalMsgService = globalMsgService;
        this.winRef = winRef;
        this.closeForm = new EventEmitter();
    }
    ngOnInit() {
        this.dpPaymentService
            .getCardRegistrationDetails()
            .subscribe((dpPaymentRequest) => {
            if (dpPaymentRequest?.url) {
                this.dpStorageService.syncCardRegistrationState(dpPaymentRequest);
                this.redirect(dpPaymentRequest.url);
            }
            else if (dpPaymentRequest) {
                this.globalMsgService.add({ key: 'dpPaymentForm.error.redirect' }, GlobalMessageType.MSG_TYPE_ERROR);
                this.closeForm.emit();
            }
        });
    }
    redirect(url) {
        const window = this.winRef.nativeWindow;
        if (window?.location) {
            window.location.href = url;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentFormComponent, deps: [{ token: DpCheckoutPaymentService }, { token: DpLocalStorageService }, { token: i2.GlobalMessageService }, { token: i2.WindowRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: DpPaymentFormComponent, isStandalone: true, selector: "cx-dp-payment-form", outputs: { closeForm: "closeForm" }, ngImport: i0, template: "<div class=\"text-center\">{{ 'dpPaymentForm.redirect' | cxTranslate }}</div>\n<div class=\"cx-spinner\"><cx-spinner /></div>\n", dependencies: [{ kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-dp-payment-form', imports: [SpinnerComponent, TranslatePipe], template: "<div class=\"text-center\">{{ 'dpPaymentForm.redirect' | cxTranslate }}</div>\n<div class=\"cx-spinner\"><cx-spinner /></div>\n" }]
        }], ctorParameters: () => [{ type: DpCheckoutPaymentService }, { type: DpLocalStorageService }, { type: i2.GlobalMessageService }, { type: i2.WindowRef }], propDecorators: { closeForm: [{
                type: Output
            }] } });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DpPaymentFormModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentFormModule, imports: [CommonModule,
            ReactiveFormsModule,
            NgSelectModule,
            I18nModule,
            SpinnerModule,
            DpPaymentFormComponent], exports: [DpPaymentFormComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentFormModule, imports: [CommonModule,
            ReactiveFormsModule,
            NgSelectModule,
            I18nModule,
            SpinnerModule,
            DpPaymentFormComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentFormModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        ReactiveFormsModule,
                        NgSelectModule,
                        I18nModule,
                        SpinnerModule,
                        DpPaymentFormComponent,
                    ],
                    exports: [DpPaymentFormComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DpPaymentMethodComponent extends CheckoutPaymentMethodComponent {
    isDpCallback() {
        const queryParams = this.activatedRoute.snapshot.queryParamMap.get(DP_CARD_REGISTRATION_STATUS);
        return !!queryParams;
    }
    hideCallbackScreen() {
        this.showCallbackScreen = false;
    }
    paymentDetailsAdded(paymentDetails) {
        this.savePaymentMethod(paymentDetails);
    }
    onSuccess() {
        super.onSuccess();
        this.next();
    }
    // TODO:#checkout - handle breaking changes
    constructor(userPaymentService, checkoutDeliveryAddressFacade, checkoutPaymentFacade, activatedRoute, translationService, activeCartFacade, checkoutStepService, globalMessageService) {
        super(userPaymentService, checkoutDeliveryAddressFacade, checkoutPaymentFacade, activatedRoute, translationService, activeCartFacade, checkoutStepService, globalMessageService);
        this.userPaymentService = userPaymentService;
        this.checkoutDeliveryAddressFacade = checkoutDeliveryAddressFacade;
        this.checkoutPaymentFacade = checkoutPaymentFacade;
        this.activatedRoute = activatedRoute;
        this.translationService = translationService;
        this.activeCartFacade = activeCartFacade;
        this.checkoutStepService = checkoutStepService;
        this.globalMessageService = globalMessageService;
        this.showCallbackScreen = false;
        this.showCallbackScreen = this.isDpCallback();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentMethodComponent, deps: [{ token: i2.UserPaymentService }, { token: i2$1.CheckoutDeliveryAddressService }, { token: i2$1.CheckoutPaymentService }, { token: i4.ActivatedRoute }, { token: i2.TranslationService }, { token: i4$1.ActiveCartFacade }, { token: i5.CheckoutStepService }, { token: i2.GlobalMessageService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: DpPaymentMethodComponent, isStandalone: true, selector: "cx-payment-method", usesInheritance: true, ngImport: i0, template: "<!-- Copied from core module except #newPaymentForm -->\n<ng-container *ngIf=\"cards$ | async as cards\">\n  <h3 class=\"cx-checkout-title d-none d-lg-block d-xl-block\">\n    {{ 'paymentForm.payment' | cxTranslate }}\n  </h3>\n  <ng-container *ngIf=\"!showCallbackScreen; else loadingPaymentDetails\">\n    <ng-container *ngIf=\"!(isUpdating$ | async); else loading\">\n      <ng-container\n        *ngIf=\"\n          cards?.length && !newPaymentFormManuallyOpened;\n          else newPaymentForm\n        \"\n      >\n        <p class=\"cx-checkout-text\">\n          {{ 'paymentForm.choosePaymentMethod' | cxTranslate }}\n        </p>\n        <div class=\"cx-checkout-btns row\">\n          <div class=\"col-md-12 col-lg-6\">\n            <button\n              class=\"btn btn-block btn-secondary\"\n              (click)=\"showNewPaymentForm()\"\n            >\n              {{ 'paymentForm.addNewPayment' | cxTranslate }}\n            </button>\n          </div>\n        </div>\n\n        <div class=\"cx-checkout-body row\">\n          <div\n            class=\"cx-payment-card col-md-12 col-lg-6\"\n            *ngFor=\"let card of cards; let i = index\"\n          >\n            <div class=\"cx-payment-card-inner\">\n              <cx-card\n                [border]=\"true\"\n                [fitToContainer]=\"true\"\n                [content]=\"card.content\"\n                (sendCard)=\"selectPaymentMethod(card.paymentMethod)\"\n              />\n            </div>\n          </div>\n        </div>\n\n        <div class=\"row cx-checkout-btns\">\n          <div class=\"col-md-12 col-lg-6\">\n            <button class=\"btn btn-block btn-secondary\" (click)=\"back()\">\n              {{ backBtnText | cxTranslate }}\n            </button>\n          </div>\n          <div class=\"col-md-12 col-lg-6\">\n            <button\n              class=\"btn btn-block btn-primary\"\n              [disabled]=\"!(selectedMethod$ | async)?.id\"\n              (click)=\"next()\"\n            >\n              {{ 'common.continue' | cxTranslate }}\n            </button>\n          </div>\n        </div>\n      </ng-container>\n    </ng-container>\n\n    <ng-template #newPaymentForm>\n      <cx-dp-payment-form\n        (setPaymentDetails)=\"setPaymentDetails($event)\"\n        (closeForm)=\"hideNewPaymentForm()\"\n      />\n    </ng-template>\n  </ng-container>\n\n  <ng-template #loading>\n    <div class=\"cx-spinner\"><cx-spinner /></div>\n  </ng-template>\n\n  <ng-template #loadingPaymentDetails>\n    <cx-dp-payment-callback\n      (paymentDetailsAdded)=\"paymentDetailsAdded($event)\"\n      (closeCallback)=\"hideCallbackScreen()\"\n    />\n  </ng-template>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: CardComponent, selector: "cx-card", inputs: ["border", "editMode", "isDefault", "content", "fitToContainer", "truncateText", "truncateParagraphText", "charactersLimit", "index", "role"], outputs: ["deleteCard", "setDefaultCard", "sendCard", "editCard", "cancelCard"] }, { kind: "component", type: DpPaymentFormComponent, selector: "cx-dp-payment-form", outputs: ["closeForm"] }, { kind: "component", type: SpinnerComponent, selector: "cx-spinner" }, { kind: "component", type: DpPaymentCallbackComponent, selector: "cx-dp-payment-callback", outputs: ["closeCallback", "paymentDetailsAdded"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentMethodComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-payment-method', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        NgFor,
                        CardComponent,
                        DpPaymentFormComponent,
                        SpinnerComponent,
                        DpPaymentCallbackComponent,
                        AsyncPipe,
                        TranslatePipe,
                    ], template: "<!-- Copied from core module except #newPaymentForm -->\n<ng-container *ngIf=\"cards$ | async as cards\">\n  <h3 class=\"cx-checkout-title d-none d-lg-block d-xl-block\">\n    {{ 'paymentForm.payment' | cxTranslate }}\n  </h3>\n  <ng-container *ngIf=\"!showCallbackScreen; else loadingPaymentDetails\">\n    <ng-container *ngIf=\"!(isUpdating$ | async); else loading\">\n      <ng-container\n        *ngIf=\"\n          cards?.length && !newPaymentFormManuallyOpened;\n          else newPaymentForm\n        \"\n      >\n        <p class=\"cx-checkout-text\">\n          {{ 'paymentForm.choosePaymentMethod' | cxTranslate }}\n        </p>\n        <div class=\"cx-checkout-btns row\">\n          <div class=\"col-md-12 col-lg-6\">\n            <button\n              class=\"btn btn-block btn-secondary\"\n              (click)=\"showNewPaymentForm()\"\n            >\n              {{ 'paymentForm.addNewPayment' | cxTranslate }}\n            </button>\n          </div>\n        </div>\n\n        <div class=\"cx-checkout-body row\">\n          <div\n            class=\"cx-payment-card col-md-12 col-lg-6\"\n            *ngFor=\"let card of cards; let i = index\"\n          >\n            <div class=\"cx-payment-card-inner\">\n              <cx-card\n                [border]=\"true\"\n                [fitToContainer]=\"true\"\n                [content]=\"card.content\"\n                (sendCard)=\"selectPaymentMethod(card.paymentMethod)\"\n              />\n            </div>\n          </div>\n        </div>\n\n        <div class=\"row cx-checkout-btns\">\n          <div class=\"col-md-12 col-lg-6\">\n            <button class=\"btn btn-block btn-secondary\" (click)=\"back()\">\n              {{ backBtnText | cxTranslate }}\n            </button>\n          </div>\n          <div class=\"col-md-12 col-lg-6\">\n            <button\n              class=\"btn btn-block btn-primary\"\n              [disabled]=\"!(selectedMethod$ | async)?.id\"\n              (click)=\"next()\"\n            >\n              {{ 'common.continue' | cxTranslate }}\n            </button>\n          </div>\n        </div>\n      </ng-container>\n    </ng-container>\n\n    <ng-template #newPaymentForm>\n      <cx-dp-payment-form\n        (setPaymentDetails)=\"setPaymentDetails($event)\"\n        (closeForm)=\"hideNewPaymentForm()\"\n      />\n    </ng-template>\n  </ng-container>\n\n  <ng-template #loading>\n    <div class=\"cx-spinner\"><cx-spinner /></div>\n  </ng-template>\n\n  <ng-template #loadingPaymentDetails>\n    <cx-dp-payment-callback\n      (paymentDetailsAdded)=\"paymentDetailsAdded($event)\"\n      (closeCallback)=\"hideCallbackScreen()\"\n    />\n  </ng-template>\n</ng-container>\n" }]
        }], ctorParameters: () => [{ type: i2.UserPaymentService }, { type: i2$1.CheckoutDeliveryAddressService }, { type: i2$1.CheckoutPaymentService }, { type: i4.ActivatedRoute }, { type: i2.TranslationService }, { type: i4$1.ActiveCartFacade }, { type: i5.CheckoutStepService }, { type: i2.GlobalMessageService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DpPaymentMethodModule extends CheckoutPaymentMethodModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentMethodModule, deps: null, target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentMethodModule, imports: [CommonModule,
            DpPaymentFormModule,
            RouterModule,
            CardModule,
            SpinnerModule,
            I18nModule,
            DpPaymentCallbackModule, i2.ConfigModule, FeaturesConfigModule,
            DpPaymentMethodComponent], exports: [DpPaymentMethodComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentMethodModule, providers: [provideDefaultConfig(defaultDigitalPaymentsConfig)], imports: [CommonModule,
            DpPaymentFormModule,
            RouterModule,
            CardModule,
            SpinnerModule,
            I18nModule,
            DpPaymentCallbackModule,
            ConfigModule.withConfig({
                cmsComponents: {
                    CheckoutPaymentDetails: {
                        component: DpPaymentMethodComponent,
                    },
                },
            }),
            FeaturesConfigModule,
            DpPaymentMethodComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpPaymentMethodModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        DpPaymentFormModule,
                        RouterModule,
                        CardModule,
                        SpinnerModule,
                        I18nModule,
                        DpPaymentCallbackModule,
                        ConfigModule.withConfig({
                            cmsComponents: {
                                CheckoutPaymentDetails: {
                                    component: DpPaymentMethodComponent,
                                },
                            },
                        }),
                        FeaturesConfigModule,
                        DpPaymentMethodComponent,
                    ],
                    exports: [DpPaymentMethodComponent],
                    providers: [provideDefaultConfig(defaultDigitalPaymentsConfig)],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DpCheckoutModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpCheckoutModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: DpCheckoutModule, imports: [DpPaymentMethodModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpCheckoutModule, providers: [
            {
                provide: DigitalPaymentsAdapter,
                useClass: OccDigitalPaymentsAdapter,
            },
            {
                provide: DP_DETAILS_NORMALIZER,
                useExisting: OccDpDetailsNormalizer,
                multi: true,
            },
            {
                provide: DP_REQUEST_NORMALIZER,
                useExisting: OccDpRequestNormalizer,
                multi: true,
            },
            DpCheckoutPaymentService,
            provideDefaultConfig(occDigitalPaymentsConfig),
        ], imports: [DpPaymentMethodModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DpCheckoutModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [DpPaymentMethodModule],
                    providers: [
                        {
                            provide: DigitalPaymentsAdapter,
                            useClass: OccDigitalPaymentsAdapter,
                        },
                        {
                            provide: DP_DETAILS_NORMALIZER,
                            useExisting: OccDpDetailsNormalizer,
                            multi: true,
                        },
                        {
                            provide: DP_REQUEST_NORMALIZER,
                            useExisting: OccDpRequestNormalizer,
                            multi: true,
                        },
                        DpCheckoutPaymentService,
                        provideDefaultConfig(occDigitalPaymentsConfig),
                    ],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class DigitalPaymentsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DigitalPaymentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: DigitalPaymentsModule, imports: [DpCheckoutModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DigitalPaymentsModule, imports: [DpCheckoutModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: DigitalPaymentsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [DpCheckoutModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/*
 * Public API Surface for Digital-Payments
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DigitalPaymentsModule, DpCheckoutModule, DpCheckoutPaymentService };
//# sourceMappingURL=spartacus-digital-payments.mjs.map
