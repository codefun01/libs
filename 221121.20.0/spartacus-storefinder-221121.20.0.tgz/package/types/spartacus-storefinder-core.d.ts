import * as i0 from '@angular/core';
import { InjectionToken, OnDestroy, Provider } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { PaginationModel, SortModel, PointOfService, SearchConfig, GeoPoint, Converter, StateUtils, WindowRef, GlobalMessageService, RoutingService, ScriptLoader, LoggerService, ErrorAction } from '@spartacus/core';
import * as i2 from '@ngrx/store';
import { Store, Action, MemoizedSelector } from '@ngrx/store';
import { StoreEntities } from '@spartacus/storefinder/root';
import * as i1 from '@angular/common';
import * as i3 from '@ngrx/effects';

declare abstract class StoreFinderConfig {
    googleMaps?: {
        apiUrl?: string;
        apiKey?: string;
        scale?: number;
        selectedMarkerScale?: number;
        radius?: number;
        mapId?: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StoreFinderConfig>;
}
declare module '@spartacus/core' {
    interface Config extends StoreFinderConfig {
    }
}

interface StoreFinderSearchPage {
    boundEastLongitude?: number;
    boundNorthLatitude?: number;
    boundSouthLatitude?: number;
    boundWestLongitude?: number;
    locationText?: string;
    pagination?: PaginationModel;
    sorts?: SortModel[];
    sourceLatitude?: number;
    sourceLongitude?: number;
    stores?: PointOfService[];
}
interface StoreCount {
    count?: number;
    isoCode?: string;
    name?: string;
    type?: string;
}

declare abstract class StoreFinderAdapter {
    abstract search(query: string, searchConfig: SearchConfig, longitudeLatitude?: GeoPoint, radius?: number): Observable<StoreFinderSearchPage>;
    abstract loadCounts(): Observable<StoreCount[]>;
    abstract load(storeId: string): Observable<PointOfService>;
}

declare class StoreFinderConnector {
    protected adapter: StoreFinderAdapter;
    constructor(adapter: StoreFinderAdapter);
    search(query: string, searchConfig: SearchConfig, longitudeLatitude?: GeoPoint, radius?: number): Observable<StoreFinderSearchPage>;
    getCounts(): Observable<StoreCount[]>;
    get(storeId: string): Observable<PointOfService>;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StoreFinderConnector>;
}

declare const STORE_FINDER_SEARCH_PAGE_NORMALIZER: InjectionToken<Converter<any, StoreFinderSearchPage>>;
declare const STORE_COUNT_NORMALIZER: InjectionToken<Converter<any, StoreCount>>;

declare const STORE_FINDER_FEATURE = "stores";
declare const STORE_FINDER_DATA = "[StoreFinder] Store Finder Data";
interface StateWithStoreFinder {
    [STORE_FINDER_FEATURE]: StoresState;
}
interface StoresState {
    findStores: StateUtils.LoaderState<FindStoresState>;
    viewAllStores: StateUtils.LoaderState<ViewAllStoresState>;
}
interface FindStoresState {
    findStoresEntities: StoreEntities;
    findStoreEntityById: StoreEntities;
}
interface ViewAllStoresState {
    viewAllStoresEntities: StoreEntities;
}

declare class StoreFinderService implements OnDestroy {
    protected store: Store<StateWithStoreFinder>;
    protected winRef: WindowRef;
    protected globalMessageService: GlobalMessageService;
    protected routingService: RoutingService;
    protected platformId: any;
    private geolocationWatchId;
    protected subscription: Subscription;
    constructor(store: Store<StateWithStoreFinder>, winRef: WindowRef, globalMessageService: GlobalMessageService, routingService: RoutingService, platformId: any);
    /**
     * Returns boolean observable for store's loading state
     */
    getStoresLoading(): Observable<boolean>;
    /**
     * Returns boolean observable for store's success state
     */
    getStoresLoaded(): Observable<boolean>;
    /**
     * Returns observable for store's entities
     * CXSPA-4871: The return value of this method signature is wrong, should be StoreFinderSearchPage.
     */
    getFindStoresEntities(): Observable<StoreEntities>;
    /**
     * Returns observable for a single store by Id
     */
    getFindStoreEntityById(): Observable<StoreEntities>;
    /**
     * Returns boolean observable for view all store's loading state
     */
    getViewAllStoresLoading(): Observable<boolean>;
    /**
     * Returns observable for view all store's entities
     */
    getViewAllStoresEntities(): Observable<StoreEntities>;
    /**
     * Store finding action functionality
     * @param queryText text query
     * @param searchConfig search configuration
     * @param longitudeLatitude longitude and latitude coordinates
     * @param countryIsoCode country ISO code
     * @param useMyLocation current location coordinates
     * @param radius radius of the scope from the center point
     */
    findStoresAction(queryText: string, searchConfig?: SearchConfig, longitudeLatitude?: GeoPoint, countryIsoCode?: string, useMyLocation?: boolean, radius?: number): void;
    /**
     * View all stores
     */
    viewAllStores(): void;
    /**
     * View all stores by id
     * @param storeId store id
     */
    viewStoreById(storeId: string): void;
    private clearWatchGeolocation;
    private isEmpty;
    /**
     * Reload store data when store entities are empty because of the context change
     */
    protected reloadStoreEntitiesOnContextChange(): void;
    callFindStoresAction(routeParams: {
        [key: string]: string;
    }): void;
    ngOnDestroy(): void;
    /**
     * @deprecated Please use StoreLocationService instead,
     * Returns store latitude
     * @param location store location
     */
    getStoreLatitude(location: PointOfService): number | undefined;
    /**
     * @deprecated Please use StoreLocationService instead,
     * Returns store longitude
     * @param location store location
     */
    getStoreLongitude(location: PointOfService): number | undefined;
    /**
     * @deprecated Please use StoreLocationService instead,
     * Generates a link leading to the directions of the given store location
     * @param location store location
     * @returns URL for directions to the store
     */
    getDirections(location: PointOfService): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StoreFinderService>;
}

declare const facadeProviders: Provider[];

interface StoreFinderSearchQuery {
    queryText?: string;
    longitudeLatitude?: GeoPoint;
    useMyLocation?: boolean;
    radius?: number;
}

declare class StoreLocationService {
    /**
     * Returns store latitude
     * @param location store location
     */
    getStoreLatitude(location: PointOfService): number | undefined;
    /**
     * Returns store longitude
     * @param location store location
     */
    getStoreLongitude(location: PointOfService): number | undefined;
    /**
     * Generates a link leading to the directions of the given store location
     * @param location store location
     * @returns URL for directions to the store
     */
    getDirections(location: PointOfService): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreLocationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StoreLocationService>;
}

declare class GoogleMapRendererService {
    protected config: StoreFinderConfig;
    protected storeFinderService: StoreFinderService;
    protected scriptLoader: ScriptLoader;
    private googleMap;
    private markers;
    private advancedMarkers;
    private static callbackCounter;
    protected logger: LoggerService;
    protected storeLocationService: StoreLocationService;
    protected document: Document;
    private featureToggles;
    constructor(config: StoreFinderConfig, storeFinderService: StoreFinderService, scriptLoader: ScriptLoader);
    /**
     * Renders google map on the given element and draws markers on it.
     * If map already exists it will use an existing map otherwise it will create one
     * @param mapElement HTML element inside of which the map will be displayed
     * @param locations array of geo data to be displayed on the map
     * @param selectMarkerHandler function to handle whenever a marker on a map is clicked
     */
    renderMap(mapElement: HTMLElement, locations: any[], selectMarkerHandler?: Function): void;
    /**
     * Loads the Google Maps API script and arranges for the map to be drawn once
     * the API is ready.
     * @param mapElement HTML element inside of which the map will be displayed
     * @param locations array of geo data to be displayed on the map
     * @param selectMarkerHandler function to handle whenever a marker on a map is clicked
     */
    private embedMapScript;
    /**
     * Registers a uniquely-named global callback that Google's async loader
     * invokes once the API is ready, then returns its name for the `callback`
     * URL param. The callback draws the map and removes itself so it can't leak
     * or fire twice.
     */
    private registerMapCallback;
    /**
     * Centers the map to the given point
     * @param latitute latitude of the new center
     * @param longitude longitude of the new center
     */
    centerMap(latitute: number, longitude: number): void;
    /**
     * Defines and returns {@link google.maps.LatLng} representing a point where the map will be centered
     * @param locations list of locations
     */
    private defineMapCenter;
    /**
     * Creates google map inside if the given HTML element centered to the given point
     * @param mapElement {@link HTMLElement} inside of which the map will be created
     * @param mapCenter {@link google.maps.LatLng} the point where the map will be centered
     */
    private initMap;
    /**
     * Erases the current map's markers and create a new one based on the given locations
     * @param locations array of locations to be displayed on the map
     * @param selectMarkerHandler function to handle whenever a marker on a map is clicked
     */
    private createMarkers;
    /**
     * Initialize and draw the map
     * @param mapElement {@link HTMLElement} inside of which the map will be drawn
     * @param locations array of locations to be displayed on the map
     * @param selectMarkerHandler function to handle whenever a marker on a map is clicked
     */
    private drawMap;
    static ɵfac: i0.ɵɵFactoryDeclaration<GoogleMapRendererService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GoogleMapRendererService>;
}

declare class StoreFinderStoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderStoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StoreFinderStoreModule, never, [typeof i1.CommonModule, typeof i2.StoreFeatureModule, typeof i3.EffectsFeatureModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StoreFinderStoreModule>;
}

declare class StoreFinderCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<StoreFinderCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<StoreFinderCoreModule, never, [typeof StoreFinderStoreModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<StoreFinderCoreModule>;
}

declare const FIND_STORES_ON_HOLD = "[StoreFinder] On Hold";
declare const FIND_STORES = "[StoreFinder] Find Stores";
declare const FIND_STORES_FAIL = "[StoreFinder] Find Stores Fail";
declare const FIND_STORES_SUCCESS = "[StoreFinder] Find Stores Success";
declare const FIND_STORE_BY_ID = "[StoreFinder] Find a Store by Id";
declare const FIND_STORE_BY_ID_FAIL = "[StoreFinder] Find a Store by Id Fail";
declare const FIND_STORE_BY_ID_SUCCESS = "[StoreFinder] Find a Store by Id Success";
declare class FindStoresOnHold extends StateUtils.LoaderLoadAction {
    readonly type = "[StoreFinder] On Hold";
    constructor();
}
declare class FindStores extends StateUtils.LoaderLoadAction {
    payload: {
        queryText: string;
        searchConfig?: SearchConfig;
        longitudeLatitude?: GeoPoint;
        useMyLocation?: boolean;
        countryIsoCode?: string;
        radius?: number;
    };
    readonly type = "[StoreFinder] Find Stores";
    constructor(payload: {
        queryText: string;
        searchConfig?: SearchConfig;
        longitudeLatitude?: GeoPoint;
        useMyLocation?: boolean;
        countryIsoCode?: string;
        radius?: number;
    });
}
declare class FindStoresFail extends StateUtils.LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[StoreFinder] Find Stores Fail";
    constructor(payload: any);
}
declare class FindStoresSuccess extends StateUtils.LoaderSuccessAction {
    payload: any;
    readonly type = "[StoreFinder] Find Stores Success";
    constructor(payload: any);
}
declare class FindStoreById extends StateUtils.LoaderLoadAction {
    payload: {
        storeId: string;
    };
    readonly type = "[StoreFinder] Find a Store by Id";
    constructor(payload: {
        storeId: string;
    });
}
declare class FindStoreByIdFail extends StateUtils.LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[StoreFinder] Find a Store by Id Fail";
    constructor(payload: any);
}
declare class FindStoreByIdSuccess extends StateUtils.LoaderSuccessAction {
    payload: any;
    readonly type = "[StoreFinder] Find a Store by Id Success";
    constructor(payload: any);
}
type FindStoresAction = FindStoresOnHold | FindStores | FindStoresFail | FindStoresSuccess | FindStoreById | FindStoreByIdFail | FindStoreByIdSuccess;

declare const VIEW_ALL_STORES = "[StoreFinder] View All Stores";
declare const VIEW_ALL_STORES_FAIL = "[StoreFinder] View All Stores Fail";
declare const VIEW_ALL_STORES_SUCCESS = "[StoreFinder] View All Stores Success";
declare const CLEAR_STORE_FINDER_DATA = "[StoreFinder] Clear Data";
declare class ViewAllStores extends StateUtils.LoaderLoadAction {
    readonly type = "[StoreFinder] View All Stores";
    constructor();
}
declare class ViewAllStoresFail extends StateUtils.LoaderFailAction implements ErrorAction {
    payload: any;
    readonly type = "[StoreFinder] View All Stores Fail";
    constructor(payload: any);
}
declare class ViewAllStoresSuccess extends StateUtils.LoaderSuccessAction {
    payload: any;
    readonly type = "[StoreFinder] View All Stores Success";
    constructor(payload: any);
}
declare class ClearStoreFinderData implements Action {
    readonly type = "[StoreFinder] Clear Data";
}
type ViewAllStoresAction = ViewAllStores | ViewAllStoresFail | ViewAllStoresSuccess | ClearStoreFinderData;

declare const storeFinderGroup_actions_d_CLEAR_STORE_FINDER_DATA: typeof CLEAR_STORE_FINDER_DATA;
type storeFinderGroup_actions_d_ClearStoreFinderData = ClearStoreFinderData;
declare const storeFinderGroup_actions_d_ClearStoreFinderData: typeof ClearStoreFinderData;
declare const storeFinderGroup_actions_d_FIND_STORES: typeof FIND_STORES;
declare const storeFinderGroup_actions_d_FIND_STORES_FAIL: typeof FIND_STORES_FAIL;
declare const storeFinderGroup_actions_d_FIND_STORES_ON_HOLD: typeof FIND_STORES_ON_HOLD;
declare const storeFinderGroup_actions_d_FIND_STORES_SUCCESS: typeof FIND_STORES_SUCCESS;
declare const storeFinderGroup_actions_d_FIND_STORE_BY_ID: typeof FIND_STORE_BY_ID;
declare const storeFinderGroup_actions_d_FIND_STORE_BY_ID_FAIL: typeof FIND_STORE_BY_ID_FAIL;
declare const storeFinderGroup_actions_d_FIND_STORE_BY_ID_SUCCESS: typeof FIND_STORE_BY_ID_SUCCESS;
type storeFinderGroup_actions_d_FindStoreById = FindStoreById;
declare const storeFinderGroup_actions_d_FindStoreById: typeof FindStoreById;
type storeFinderGroup_actions_d_FindStoreByIdFail = FindStoreByIdFail;
declare const storeFinderGroup_actions_d_FindStoreByIdFail: typeof FindStoreByIdFail;
type storeFinderGroup_actions_d_FindStoreByIdSuccess = FindStoreByIdSuccess;
declare const storeFinderGroup_actions_d_FindStoreByIdSuccess: typeof FindStoreByIdSuccess;
type storeFinderGroup_actions_d_FindStores = FindStores;
declare const storeFinderGroup_actions_d_FindStores: typeof FindStores;
type storeFinderGroup_actions_d_FindStoresAction = FindStoresAction;
type storeFinderGroup_actions_d_FindStoresFail = FindStoresFail;
declare const storeFinderGroup_actions_d_FindStoresFail: typeof FindStoresFail;
type storeFinderGroup_actions_d_FindStoresOnHold = FindStoresOnHold;
declare const storeFinderGroup_actions_d_FindStoresOnHold: typeof FindStoresOnHold;
type storeFinderGroup_actions_d_FindStoresSuccess = FindStoresSuccess;
declare const storeFinderGroup_actions_d_FindStoresSuccess: typeof FindStoresSuccess;
declare const storeFinderGroup_actions_d_VIEW_ALL_STORES: typeof VIEW_ALL_STORES;
declare const storeFinderGroup_actions_d_VIEW_ALL_STORES_FAIL: typeof VIEW_ALL_STORES_FAIL;
declare const storeFinderGroup_actions_d_VIEW_ALL_STORES_SUCCESS: typeof VIEW_ALL_STORES_SUCCESS;
type storeFinderGroup_actions_d_ViewAllStores = ViewAllStores;
declare const storeFinderGroup_actions_d_ViewAllStores: typeof ViewAllStores;
type storeFinderGroup_actions_d_ViewAllStoresAction = ViewAllStoresAction;
type storeFinderGroup_actions_d_ViewAllStoresFail = ViewAllStoresFail;
declare const storeFinderGroup_actions_d_ViewAllStoresFail: typeof ViewAllStoresFail;
type storeFinderGroup_actions_d_ViewAllStoresSuccess = ViewAllStoresSuccess;
declare const storeFinderGroup_actions_d_ViewAllStoresSuccess: typeof ViewAllStoresSuccess;
declare namespace storeFinderGroup_actions_d {
  export { storeFinderGroup_actions_d_CLEAR_STORE_FINDER_DATA as CLEAR_STORE_FINDER_DATA, storeFinderGroup_actions_d_ClearStoreFinderData as ClearStoreFinderData, storeFinderGroup_actions_d_FIND_STORES as FIND_STORES, storeFinderGroup_actions_d_FIND_STORES_FAIL as FIND_STORES_FAIL, storeFinderGroup_actions_d_FIND_STORES_ON_HOLD as FIND_STORES_ON_HOLD, storeFinderGroup_actions_d_FIND_STORES_SUCCESS as FIND_STORES_SUCCESS, storeFinderGroup_actions_d_FIND_STORE_BY_ID as FIND_STORE_BY_ID, storeFinderGroup_actions_d_FIND_STORE_BY_ID_FAIL as FIND_STORE_BY_ID_FAIL, storeFinderGroup_actions_d_FIND_STORE_BY_ID_SUCCESS as FIND_STORE_BY_ID_SUCCESS, storeFinderGroup_actions_d_FindStoreById as FindStoreById, storeFinderGroup_actions_d_FindStoreByIdFail as FindStoreByIdFail, storeFinderGroup_actions_d_FindStoreByIdSuccess as FindStoreByIdSuccess, storeFinderGroup_actions_d_FindStores as FindStores, storeFinderGroup_actions_d_FindStoresFail as FindStoresFail, storeFinderGroup_actions_d_FindStoresOnHold as FindStoresOnHold, storeFinderGroup_actions_d_FindStoresSuccess as FindStoresSuccess, storeFinderGroup_actions_d_VIEW_ALL_STORES as VIEW_ALL_STORES, storeFinderGroup_actions_d_VIEW_ALL_STORES_FAIL as VIEW_ALL_STORES_FAIL, storeFinderGroup_actions_d_VIEW_ALL_STORES_SUCCESS as VIEW_ALL_STORES_SUCCESS, storeFinderGroup_actions_d_ViewAllStores as ViewAllStores, storeFinderGroup_actions_d_ViewAllStoresFail as ViewAllStoresFail, storeFinderGroup_actions_d_ViewAllStoresSuccess as ViewAllStoresSuccess };
  export type { storeFinderGroup_actions_d_FindStoresAction as FindStoresAction, storeFinderGroup_actions_d_ViewAllStoresAction as ViewAllStoresAction };
}

declare const getFindStoresState: MemoizedSelector<StateWithStoreFinder, StateUtils.LoaderState<FindStoresState>>;
declare const getFindStoresEntities: MemoizedSelector<StateWithStoreFinder, FindStoresState>;
declare const getStoresLoading: MemoizedSelector<StateWithStoreFinder, boolean>;
declare const getStoresSuccess: MemoizedSelector<StateWithStoreFinder, boolean>;

declare const getViewAllStoresState: MemoizedSelector<StateWithStoreFinder, StateUtils.LoaderState<ViewAllStoresState>>;
declare const getViewAllStoresEntities: MemoizedSelector<StateWithStoreFinder, ViewAllStoresState>;
declare const getViewAllStoresLoading: MemoizedSelector<StateWithStoreFinder, boolean>;

declare const storeFinderGroup_selectors_d_getFindStoresEntities: typeof getFindStoresEntities;
declare const storeFinderGroup_selectors_d_getFindStoresState: typeof getFindStoresState;
declare const storeFinderGroup_selectors_d_getStoresLoading: typeof getStoresLoading;
declare const storeFinderGroup_selectors_d_getStoresSuccess: typeof getStoresSuccess;
declare const storeFinderGroup_selectors_d_getViewAllStoresEntities: typeof getViewAllStoresEntities;
declare const storeFinderGroup_selectors_d_getViewAllStoresLoading: typeof getViewAllStoresLoading;
declare const storeFinderGroup_selectors_d_getViewAllStoresState: typeof getViewAllStoresState;
declare namespace storeFinderGroup_selectors_d {
  export {
    storeFinderGroup_selectors_d_getFindStoresEntities as getFindStoresEntities,
    storeFinderGroup_selectors_d_getFindStoresState as getFindStoresState,
    storeFinderGroup_selectors_d_getStoresLoading as getStoresLoading,
    storeFinderGroup_selectors_d_getStoresSuccess as getStoresSuccess,
    storeFinderGroup_selectors_d_getViewAllStoresEntities as getViewAllStoresEntities,
    storeFinderGroup_selectors_d_getViewAllStoresLoading as getViewAllStoresLoading,
    storeFinderGroup_selectors_d_getViewAllStoresState as getViewAllStoresState,
  };
}

export { GoogleMapRendererService, STORE_COUNT_NORMALIZER, STORE_FINDER_DATA, STORE_FINDER_FEATURE, STORE_FINDER_SEARCH_PAGE_NORMALIZER, storeFinderGroup_actions_d as StoreFinderActions, StoreFinderAdapter, StoreFinderConfig, StoreFinderConnector, StoreFinderCoreModule, storeFinderGroup_selectors_d as StoreFinderSelectors, StoreFinderService, StoreLocationService, facadeProviders };
export type { FindStoresState, StateWithStoreFinder, StoreCount, StoreFinderSearchPage, StoreFinderSearchQuery, StoresState, ViewAllStoresState };
