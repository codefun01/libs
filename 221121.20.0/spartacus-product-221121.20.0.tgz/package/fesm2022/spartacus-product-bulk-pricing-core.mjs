import * as i1 from '@spartacus/core';
import { ProductScope } from '@spartacus/core';
import * as i0 from '@angular/core';
import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { switchMap } from 'rxjs/operators';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
ProductScope['BULK_PRICES'] = 'bulkPrices';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class BulkPricingService {
    constructor(productService) {
        this.productService = productService;
        this.PRODUCT_SCOPE = ProductScope.BULK_PRICES;
    }
    getBulkPrices(productCode) {
        return this.productService.get(productCode, this.PRODUCT_SCOPE).pipe(switchMap((productPriceScope) => {
            return of(this.convert(productPriceScope));
        }));
    }
    convert(productPriceScope) {
        let bulkPrices = [];
        if (productPriceScope) {
            const basePrice = productPriceScope.price?.value;
            const volumePrices = productPriceScope.volumePrices;
            bulkPrices = volumePrices?.map((volumePrice) => this.parsePrice(volumePrice, basePrice));
        }
        return bulkPrices;
    }
    parsePrice(priceTier, basePrice) {
        const bulkPriceTemplate = {
            currencyIso: priceTier.currencyIso,
            formattedValue: priceTier.formattedValue,
            maxQuantity: priceTier.maxQuantity,
            minQuantity: priceTier.minQuantity,
            priceType: priceTier.priceType,
            value: priceTier.value,
            formattedDiscount: '',
            discount: 0,
        };
        return this.calculateDiscount(bulkPriceTemplate, basePrice);
    }
    calculateDiscount(bulkPriceTemplate, basePrice) {
        const bulkPrice = Object.assign({}, bulkPriceTemplate);
        const tierPrice = bulkPriceTemplate.value;
        if (tierPrice && basePrice) {
            const discount = Math.round(100 - (tierPrice / basePrice) * 100);
            const formatted = discount === 0 ? `${discount}%` : `-${discount}%`;
            bulkPrice.formattedDiscount = formatted;
            bulkPrice.discount = discount;
        }
        return bulkPrice;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: BulkPricingService, deps: [{ token: i1.ProductService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: BulkPricingService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: BulkPricingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.ProductService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { BulkPricingService };
//# sourceMappingURL=spartacus-product-bulk-pricing-core.mjs.map
