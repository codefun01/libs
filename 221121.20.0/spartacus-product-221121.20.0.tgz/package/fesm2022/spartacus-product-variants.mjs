import * as i0 from '@angular/core';
import { NgModule } from '@angular/core';
import { ProductVariantsOccModule } from '@spartacus/product/variants/occ';
import { ProductVariantsComponentsModule } from '@spartacus/product/variants/components';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class ProductVariantsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductVariantsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: ProductVariantsModule, imports: [ProductVariantsOccModule, ProductVariantsComponentsModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductVariantsModule, imports: [ProductVariantsOccModule, ProductVariantsComponentsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: ProductVariantsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [ProductVariantsOccModule, ProductVariantsComponentsModule],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ProductVariantsModule };
//# sourceMappingURL=spartacus-product-variants.mjs.map
