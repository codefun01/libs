import * as i0 from '@angular/core';
import { inject, Injectable, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import * as i1 from '@spartacus/cart/base/root';
import { CreateCartEvent } from '@spartacus/cart/base/root';
import * as i2 from '@spartacus/core';
import { FeatureToggles, BASE_SITE_CONTEXT_ID, StorageSyncType, FeatureDirective, UrlPipe, TranslatePipe, UrlModule, I18nModule, provideDefaultConfig } from '@spartacus/core';
import { of, combineLatest } from 'rxjs';
import { switchMap, startWith, map, debounceTime, distinctUntilChanged, takeWhile } from 'rxjs/operators';
import { NgIf, AsyncPipe, CommonModule } from '@angular/common';
import { RouterLink, RouterModule } from '@angular/router';
import { ICON_TYPE, IconComponent, IconModule } from '@spartacus/storefront';

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Debounce window applied to the mini-cart "updating" indicator. Short bursts
 * of cart activity on a fast network can flip `isStable()` false→true→false in
 * a few hundred ms; without a debounce the indicator strobes. 250ms is long
 * enough to swallow that flicker and short enough that a slow-network user
 * still sees feedback well within their reaction window.
 */
const MINI_CART_UPDATING_DEBOUNCE_MS = 250;
class MiniCartComponentService {
    constructor(activeCartFacade, authService, statePersistenceService, siteContextParamsService, eventService) {
        this.activeCartFacade = activeCartFacade;
        this.authService = authService;
        this.statePersistenceService = statePersistenceService;
        this.siteContextParamsService = siteContextParamsService;
        this.eventService = eventService;
        this.featureToggles = inject(FeatureToggles);
    }
    /**
     * This function supports lazy loading of the cart functionality's code. We only call
     * the activeCartFacade if we know there is actually a cart.
     * Without a cart, we can return a default value and
     * avoid loading the cart library code.
     */
    getQuantity() {
        return this.activeCartRequired().pipe(switchMap((activeCartRequired) => {
            if (activeCartRequired) {
                return this.activeCartFacade.getActive().pipe(startWith({ totalUnitCount: 0 }), map((cart) => cart.totalUnitCount || 0));
            }
            else {
                return of(0);
            }
        }));
    }
    /**
     * This function supports lazy loading of the cart functionality's code. We only call
     * the activeCartFacade if we know there is actually a cart.
     * Without a cart, we can return a default value and
     * avoid loading the cart library code.
     */
    getTotalPrice() {
        return this.activeCartRequired().pipe(switchMap((activeCartRequired) => {
            if (activeCartRequired) {
                return this.activeCartFacade
                    .getActive()
                    .pipe(map((cart) => cart.totalPrice?.formattedValue ?? ''));
            }
            else {
                return of('');
            }
        }));
    }
    /**
     * Emits true while the active cart has pending writes (an entry POST is in
     * flight, processesCount > 0, or the cart entity is loading). Drives the
     * mini-cart's loading affordance so users get feedback that their click
     * registered, without waiting for the round-trip GET reconcile.
     *
     * Lazy in the same way as getQuantity/getTotalPrice: when no active cart is
     * required (anonymous, no cart in storage, no CreateCart event) we don't
     * touch ActiveCartFacade — keeps the cart code chunk out of the initial
     * load.
     *
     * Gated by `enableCartSlowNetworkResilience`; emits constant `false` when
     * the toggle is OFF so an extending client sees pre-CXSPA-10582 behaviour
     * (no indicator).
     */
    getUpdating() {
        if (!this.featureToggles.enableCartSlowNetworkResilience) {
            return of(false);
        }
        return this.activeCartRequired().pipe(switchMap((activeCartRequired) => {
            if (!activeCartRequired) {
                return of(false);
            }
            return this.activeCartFacade.isStable().pipe(map((stable) => !stable), debounceTime(MINI_CART_UPDATING_DEBOUNCE_MS), startWith(false), distinctUntilChanged());
        }));
    }
    /**
     * This function determines if it is required to get active cart data from ActiveCartFacade.
     * It is required to call the ActiveCartFacade if one of these criteria is met:
     * - There is an active cart id in the browser local storage
     * - A user is authenticated
     * - The cart library code chunk with the ActiveCartFacade implementation is already loaded.
     *
     * Once the observable returned by activeCartRequired emits true, it completes.
     * activeCartRequired helps to make the mini cart compatible with some level of lazy loading.
     */
    activeCartRequired() {
        return combineLatest([
            this.hasActiveCartInStorage(),
            this.authService.isUserLoggedIn(),
            this.isCartCreated(),
        ]).pipe(map(([hasCartInStorage, isUserLoggedIn, isCartCreated]) => hasCartInStorage || isUserLoggedIn || isCartCreated), distinctUntilChanged(), takeWhile((hasCart) => !hasCart, true));
    }
    hasActiveCartInStorage() {
        return this.getCartStateFromBrowserStorage().pipe(map((state) => Boolean(state?.active)));
    }
    isCartCreated() {
        return this.eventService.get(CreateCartEvent).pipe(map((_) => true), startWith(false));
    }
    getCartStateFromBrowserStorage() {
        return this.siteContextParamsService.getValues([BASE_SITE_CONTEXT_ID]).pipe(map((context) => {
            return this.statePersistenceService.readStateFromStorage({
                key: 'cart',
                context: context,
                storageType: StorageSyncType.LOCAL_STORAGE,
            });
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MiniCartComponentService, deps: [{ token: i1.ActiveCartFacade }, { token: i2.AuthService }, { token: i2.StatePersistenceService }, { token: i2.SiteContextParamsService }, { token: i2.EventService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MiniCartComponentService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MiniCartComponentService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.ActiveCartFacade }, { type: i2.AuthService }, { type: i2.StatePersistenceService }, { type: i2.SiteContextParamsService }, { type: i2.EventService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class MiniCartComponent {
    constructor(miniCartComponentService) {
        this.miniCartComponentService = miniCartComponentService;
        this.iconTypes = ICON_TYPE;
        this.quantity$ = this.miniCartComponentService.getQuantity();
        this.total$ = this.miniCartComponentService.getTotalPrice();
        /**
         * True while the active cart has pending writes. Drives the mini-cart's
         * loading affordance.
         */
        this.updating$ = this.miniCartComponentService.getUpdating();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MiniCartComponent, deps: [{ token: MiniCartComponentService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.23", type: MiniCartComponent, isStandalone: true, selector: "cx-mini-cart", ngImport: i0, template: "<a\n  *ngIf=\"{ quantity: quantity$ | async, updating: updating$ | async } as data\"\n  [attr.aria-label]=\"'miniCart.item' | cxTranslate: { count: data.quantity }\"\n  [title]=\"'miniCart.item' | cxTranslate: { count: data.quantity }\"\n  [class.is-updating]=\"data.updating\"\n  [routerLink]=\"{ cxRoute: 'cart' } | cxUrl\"\n>\n  <cx-icon [type]=\"iconTypes.CART\" />\n\n  <ng-container *cxFeature=\"'enableCartSlowNetworkResilience'\">\n    <span\n      *ngIf=\"data.updating\"\n      class=\"cx-mini-cart-updating\"\n      role=\"status\"\n      aria-live=\"polite\"\n      [attr.aria-label]=\"'miniCart.updating' | cxTranslate\"\n    >\n      <span class=\"loader-container\" aria-hidden=\"true\">\n        <span class=\"loader\">{{ 'spinner.loading' | cxTranslate }}</span>\n      </span>\n    </span>\n\n    <span *ngIf=\"!data.updating\" class=\"total\">\n      {{ 'miniCart.total' | cxTranslate: { total: total$ | async } }}\n    </span>\n\n    <span *ngIf=\"!data.updating\" class=\"count\">\n      {{ 'miniCart.count' | cxTranslate: { count: quantity$ | async } }}\n    </span>\n  </ng-container>\n\n  <ng-container *cxFeature=\"'!enableCartSlowNetworkResilience'\">\n    <span class=\"total\">\n      {{ 'miniCart.total' | cxTranslate: { total: total$ | async } }}\n    </span>\n\n    <span class=\"count\">\n      {{ 'miniCart.count' | cxTranslate: { count: quantity$ | async } }}\n    </span>\n  </ng-container>\n</a>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: FeatureDirective, selector: "[cxFeature]", inputs: ["cxFeature"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: IconComponent, selector: "cx-icon,[cxIcon]", inputs: ["cxIcon", "type"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: UrlPipe, name: "cxUrl" }, { kind: "pipe", type: TranslatePipe, name: "cxTranslate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MiniCartComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cx-mini-cart', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgIf,
                        FeatureDirective,
                        RouterLink,
                        IconComponent,
                        AsyncPipe,
                        UrlPipe,
                        TranslatePipe,
                    ], template: "<a\n  *ngIf=\"{ quantity: quantity$ | async, updating: updating$ | async } as data\"\n  [attr.aria-label]=\"'miniCart.item' | cxTranslate: { count: data.quantity }\"\n  [title]=\"'miniCart.item' | cxTranslate: { count: data.quantity }\"\n  [class.is-updating]=\"data.updating\"\n  [routerLink]=\"{ cxRoute: 'cart' } | cxUrl\"\n>\n  <cx-icon [type]=\"iconTypes.CART\" />\n\n  <ng-container *cxFeature=\"'enableCartSlowNetworkResilience'\">\n    <span\n      *ngIf=\"data.updating\"\n      class=\"cx-mini-cart-updating\"\n      role=\"status\"\n      aria-live=\"polite\"\n      [attr.aria-label]=\"'miniCart.updating' | cxTranslate\"\n    >\n      <span class=\"loader-container\" aria-hidden=\"true\">\n        <span class=\"loader\">{{ 'spinner.loading' | cxTranslate }}</span>\n      </span>\n    </span>\n\n    <span *ngIf=\"!data.updating\" class=\"total\">\n      {{ 'miniCart.total' | cxTranslate: { total: total$ | async } }}\n    </span>\n\n    <span *ngIf=\"!data.updating\" class=\"count\">\n      {{ 'miniCart.count' | cxTranslate: { count: quantity$ | async } }}\n    </span>\n  </ng-container>\n\n  <ng-container *cxFeature=\"'!enableCartSlowNetworkResilience'\">\n    <span class=\"total\">\n      {{ 'miniCart.total' | cxTranslate: { total: total$ | async } }}\n    </span>\n\n    <span class=\"count\">\n      {{ 'miniCart.count' | cxTranslate: { count: quantity$ | async } }}\n    </span>\n  </ng-container>\n</a>\n" }]
        }], ctorParameters: () => [{ type: MiniCartComponentService }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
class MiniCartModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MiniCartModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: MiniCartModule, imports: [CommonModule,
            RouterModule,
            UrlModule,
            IconModule,
            I18nModule,
            MiniCartComponent], exports: [MiniCartComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MiniCartModule, providers: [
            provideDefaultConfig({
                cmsComponents: {
                    MiniCartComponent: {
                        component: MiniCartComponent,
                    },
                },
            }),
        ], imports: [CommonModule,
            RouterModule,
            UrlModule,
            IconModule,
            I18nModule,
            MiniCartComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MiniCartModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        RouterModule,
                        UrlModule,
                        IconModule,
                        I18nModule,
                        MiniCartComponent,
                    ],
                    providers: [
                        provideDefaultConfig({
                            cmsComponents: {
                                MiniCartComponent: {
                                    component: MiniCartComponent,
                                },
                            },
                        }),
                    ],
                    exports: [MiniCartComponent],
                }]
        }] });

/*
 * SPDX-FileCopyrightText: 2026 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MiniCartComponent, MiniCartComponentService, MiniCartModule };
//# sourceMappingURL=spartacus-cart-base-components-mini-cart.mjs.map
