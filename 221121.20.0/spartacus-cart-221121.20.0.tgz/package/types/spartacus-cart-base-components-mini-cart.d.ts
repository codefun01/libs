import { ActiveCartFacade } from '@spartacus/cart/base/root';
import * as i3 from '@spartacus/core';
import { AuthService, StatePersistenceService, SiteContextParamsService, EventService } from '@spartacus/core';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import * as i4 from '@spartacus/storefront';
import { ICON_TYPE } from '@spartacus/storefront';
import * as i1 from '@angular/common';
import * as i2 from '@angular/router';

declare class MiniCartComponentService {
    protected activeCartFacade: ActiveCartFacade;
    protected authService: AuthService;
    protected statePersistenceService: StatePersistenceService;
    protected siteContextParamsService: SiteContextParamsService;
    protected eventService: EventService;
    private featureToggles;
    constructor(activeCartFacade: ActiveCartFacade, authService: AuthService, statePersistenceService: StatePersistenceService, siteContextParamsService: SiteContextParamsService, eventService: EventService);
    /**
     * This function supports lazy loading of the cart functionality's code. We only call
     * the activeCartFacade if we know there is actually a cart.
     * Without a cart, we can return a default value and
     * avoid loading the cart library code.
     */
    getQuantity(): Observable<number>;
    /**
     * This function supports lazy loading of the cart functionality's code. We only call
     * the activeCartFacade if we know there is actually a cart.
     * Without a cart, we can return a default value and
     * avoid loading the cart library code.
     */
    getTotalPrice(): Observable<string>;
    /**
     * Emits true while the active cart has pending writes (an entry POST is in
     * flight, processesCount > 0, or the cart entity is loading). Drives the
     * mini-cart's loading affordance so users get feedback that their click
     * registered, without waiting for the round-trip GET reconcile.
     *
     * Lazy in the same way as getQuantity/getTotalPrice: when no active cart is
     * required (anonymous, no cart in storage, no CreateCart event) we don't
     * touch ActiveCartFacade — keeps the cart code chunk out of the initial
     * load.
     *
     * Gated by `enableCartSlowNetworkResilience`; emits constant `false` when
     * the toggle is OFF so an extending client sees pre-CXSPA-10582 behaviour
     * (no indicator).
     */
    getUpdating(): Observable<boolean>;
    /**
     * This function determines if it is required to get active cart data from ActiveCartFacade.
     * It is required to call the ActiveCartFacade if one of these criteria is met:
     * - There is an active cart id in the browser local storage
     * - A user is authenticated
     * - The cart library code chunk with the ActiveCartFacade implementation is already loaded.
     *
     * Once the observable returned by activeCartRequired emits true, it completes.
     * activeCartRequired helps to make the mini cart compatible with some level of lazy loading.
     */
    protected activeCartRequired(): Observable<boolean>;
    protected hasActiveCartInStorage(): Observable<boolean>;
    protected isCartCreated(): Observable<boolean>;
    protected getCartStateFromBrowserStorage(): Observable<{
        active: string;
    } | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MiniCartComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MiniCartComponentService>;
}

declare class MiniCartComponent {
    protected miniCartComponentService: MiniCartComponentService;
    iconTypes: typeof ICON_TYPE;
    quantity$: Observable<number>;
    total$: Observable<string>;
    /**
     * True while the active cart has pending writes. Drives the mini-cart's
     * loading affordance.
     */
    updating$: Observable<boolean>;
    constructor(miniCartComponentService: MiniCartComponentService);
    static ɵfac: i0.ɵɵFactoryDeclaration<MiniCartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MiniCartComponent, "cx-mini-cart", never, {}, {}, never, never, true, never>;
}

declare class MiniCartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MiniCartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MiniCartModule, never, [typeof i1.CommonModule, typeof i2.RouterModule, typeof i3.UrlModule, typeof i4.IconModule, typeof i3.I18nModule, typeof MiniCartComponent], [typeof MiniCartComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MiniCartModule>;
}

export { MiniCartComponent, MiniCartComponentService, MiniCartModule };
