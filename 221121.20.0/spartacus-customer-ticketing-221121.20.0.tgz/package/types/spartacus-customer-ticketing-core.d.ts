import { TicketDetails, TicketList, Category, AssociatedObject, TicketStarter, TicketEvent, CustomerTicketingFacade } from '@spartacus/customer-ticketing/root';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import { InjectionToken } from '@angular/core';
import { Converter, QueryService, CommandService, UserIdService, RoutingService, EventService, QueryNotifier, Command, Query, QueryState, PageMetaResolver, PageHeadingResolver, PageBreadcrumbResolver, PageTitleResolver, PageDescriptionResolver, PageRobotsResolver, TranslationService, BasePageMetaResolver, SemanticPathService, PageRobotsMeta, BreadcrumbMeta, ErrorModel, HttpErrorHandler, GlobalMessageService, HttpResponseStatus, Priority } from '@spartacus/core';
import { ActiveCartFacade } from '@spartacus/cart/base/root';
import { HttpErrorResponse, HttpRequest } from '@angular/common/http';

declare abstract class CustomerTicketingAdapter {
    abstract getTicket(customerId: string, ticketId: string): Observable<TicketDetails>;
    abstract getTickets(customerId: string, pageSize?: number, currentPage?: number, sort?: string): Observable<TicketList>;
    abstract getTicketCategories(): Observable<Category[]>;
    abstract getTicketAssociatedObjects(customerId: string): Observable<AssociatedObject[]>;
    abstract createTicket(customerId: string, ticket: TicketStarter): Observable<TicketStarter>;
    abstract createTicketEvent(customerId: string, ticketId: string, ticketEvent: TicketEvent): Observable<TicketEvent>;
    abstract uploadAttachment(customerId: string, ticketId: string, eventCode: string, file: File): Observable<unknown>;
    abstract downloadAttachment(customerId: string, ticketId: string, eventCode: string, attachmentId: string): Observable<unknown>;
}

declare class CustomerTicketingConnector {
    protected adapter: CustomerTicketingAdapter;
    constructor(adapter: CustomerTicketingAdapter);
    getTicket(customerId: string, ticketId: string): Observable<TicketDetails>;
    getTickets(customerId: string, pageSize?: number, currentPage?: number, sort?: string): Observable<TicketList>;
    getTicketCategories(): Observable<Category[]>;
    getTicketAssociatedObjects(customerId: string): Observable<AssociatedObject[]>;
    createTicket(customerId: string, ticket: TicketStarter): Observable<TicketStarter>;
    createTicketEvent(customerId: string, ticketId: string, ticketEvent: TicketEvent): Observable<TicketEvent>;
    uploadAttachment(customerId: string, ticketId: string, eventCode: string, file: File): Observable<unknown>;
    downloadAttachment(customerId: string, ticketId: string, eventCode: string, attachmentId: string): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingConnector, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomerTicketingConnector>;
}

declare const CUSTOMER_TICKETING_DETAILS_NORMALIZER: InjectionToken<Converter<any, TicketDetails>>;
declare const CUSTOMER_TICKETING_EVENT_NORMALIZER: InjectionToken<Converter<any, TicketEvent>>;
declare const CUSTOMER_TICKETING_FILE_NORMALIZER: InjectionToken<Converter<any, File>>;
declare const CUSTOMER_TICKETING_LIST_NORMALIZER: InjectionToken<Converter<any, TicketList>>;
declare const CUSTOMER_TICKETING_CATEGORY_NORMALIZER: InjectionToken<Converter<any, Category>>;
declare const CUSTOMER_TICKETING_ASSOCIATED_OBJECTS_NORMALIZER: InjectionToken<Converter<any, AssociatedObject>>;
declare const CUSTOMER_TICKETING_CREATE_NORMALIZER: InjectionToken<Converter<any, TicketStarter>>;

declare class CustomerTicketingCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CustomerTicketingCoreModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CustomerTicketingCoreModule>;
}

declare class CustomerTicketingService implements CustomerTicketingFacade {
    protected queryService: QueryService;
    protected commandService: CommandService;
    protected userIdService: UserIdService;
    protected customerTicketingConnector: CustomerTicketingConnector;
    protected routingService: RoutingService;
    protected eventService: EventService;
    protected getTicketCategoriesQueryReloadEvents(): QueryNotifier[];
    protected getTicketCategoriesQueryResetEvents(): QueryNotifier[];
    protected getTicketAssociatedObjectsQueryReloadEvents(): QueryNotifier[];
    protected getTicketAssociatedObjectsQueryResetEvents(): QueryNotifier[];
    protected getTicketQueryReloadEvents(): QueryNotifier[];
    protected getTicketQueryResetEvents(): QueryNotifier[];
    protected getTicketsQueryReloadEvents(): QueryNotifier[];
    protected getTicketsQueryResetEvents(): QueryNotifier[];
    protected createTicketCommand: Command<TicketStarter, TicketDetails>;
    protected createTicketEventCommand: Command<{
        ticketEvent: TicketEvent;
        containsAttachment?: boolean;
    }, TicketEvent>;
    protected uploadAttachmentCommand: Command<{
        file: File;
        eventCode: string;
        ticketId?: string;
    }>;
    protected downloadAttachmentCommand: Command<{
        eventCode: string;
        attachmentId: string;
    }>;
    protected getTicketQuery$: Query<TicketDetails | undefined>;
    protected getTicketsQuery$(pageSize: number, currentPage: number, sort: string): Query<TicketList | undefined>;
    protected getTicketCategoriesQuery: Query<Category[]>;
    protected getTicketAssociatedObjectsQuery: Query<AssociatedObject[]>;
    protected customerTicketingPreConditions(): Observable<[string, string]>;
    protected customerTicketingListPreConditions(): Observable<string>;
    constructor(queryService: QueryService, commandService: CommandService, userIdService: UserIdService, customerTicketingConnector: CustomerTicketingConnector, routingService: RoutingService, eventService: EventService);
    getTicketAssociatedObjectsState(): Observable<QueryState<AssociatedObject[]>>;
    getTicketAssociatedObjects(): Observable<AssociatedObject[]>;
    getTicketCategoriesState(): Observable<QueryState<Category[]>>;
    getTicketCategories(): Observable<Category[]>;
    getTicketState(): Observable<QueryState<TicketDetails | undefined>>;
    getTicket(): Observable<TicketDetails | undefined>;
    createTicket(ticketStarted: TicketStarter): Observable<TicketStarter | TicketDetails>;
    getTicketsState(pageSize: number, currentPage: number, sort: string): Observable<QueryState<TicketList | undefined>>;
    getTickets(pageSize: number, currentPage: number, sort: string): Observable<TicketList | undefined>;
    createTicketEvent(ticketEvent: TicketEvent, containsAttachment?: boolean): Observable<TicketEvent>;
    uploadAttachment(file: File, eventCode: string, ticketId?: string): Observable<unknown>;
    downloadAttachment(eventCode: string, attachmentId: string): Observable<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomerTicketingService>;
}

declare class CustomerTicketingPageMetaResolver extends PageMetaResolver implements PageHeadingResolver, PageBreadcrumbResolver, PageTitleResolver, PageDescriptionResolver, PageRobotsResolver {
    protected translationService: TranslationService;
    protected activeCartFacade: ActiveCartFacade;
    protected basePageMetaResolver: BasePageMetaResolver;
    protected customerTicketingFacade: CustomerTicketingFacade;
    protected translation: TranslationService;
    protected semanticPath: SemanticPathService;
    protected readonly CUSTOMER_SERVICE_TRANSLATION_KEY = "customerTicketing.customerService";
    protected readonly CUSTOMER_SERVICE_SEMANTIC_ROUTE = "supportTickets";
    constructor(translationService: TranslationService, activeCartFacade: ActiveCartFacade, basePageMetaResolver: BasePageMetaResolver, customerTicketingFacade: CustomerTicketingFacade, translation: TranslationService, semanticPath: SemanticPathService);
    resolveTitle(): Observable<string | undefined>;
    /**
     * @override
     * Resolves the page heading for the Customer Ticket Details Page.
     * The page heading is used in the UI (`<h1>`), where as the page
     * title is used by the browser and crawlers.
     */
    resolveHeading(): Observable<string | undefined>;
    resolveDescription(): Observable<string | undefined>;
    resolveRobots(): Observable<PageRobotsMeta[]>;
    resolveBreadcrumbs(): Observable<BreadcrumbMeta[]>;
    protected customerServiceBreadCrumb$: Observable<BreadcrumbMeta[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingPageMetaResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomerTicketingPageMetaResolver>;
}

/**
 * Check if the returned error is of type notFound.
 */
declare function isNotFoundError(error: ErrorModel): boolean;

declare class NotFoundTicketRequestHandler extends HttpErrorHandler {
    protected globalMessageService: GlobalMessageService;
    protected routingService: RoutingService;
    protected platformId?: Object | undefined;
    responseStatus: HttpResponseStatus;
    constructor(globalMessageService: GlobalMessageService, routingService: RoutingService, platformId?: Object | undefined);
    getPriority(): Priority;
    hasMatch(errorResponse: HttpErrorResponse): boolean;
    handleError(request: HttpRequest<any>, response: HttpErrorResponse): void;
    protected isCustomerTicketingDetailsRoute(): boolean;
    protected handleTicketNotFoundError(_request: HttpRequest<any>, response: HttpErrorResponse): void;
    protected getErrors(response: HttpErrorResponse): ErrorModel[];
    static ɵfac: i0.ɵɵFactoryDeclaration<NotFoundTicketRequestHandler, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NotFoundTicketRequestHandler>;
}

export { CUSTOMER_TICKETING_ASSOCIATED_OBJECTS_NORMALIZER, CUSTOMER_TICKETING_CATEGORY_NORMALIZER, CUSTOMER_TICKETING_CREATE_NORMALIZER, CUSTOMER_TICKETING_DETAILS_NORMALIZER, CUSTOMER_TICKETING_EVENT_NORMALIZER, CUSTOMER_TICKETING_FILE_NORMALIZER, CUSTOMER_TICKETING_LIST_NORMALIZER, CustomerTicketingAdapter, CustomerTicketingConnector, CustomerTicketingCoreModule, CustomerTicketingPageMetaResolver, CustomerTicketingService, NotFoundTicketRequestHandler, isNotFoundError };
