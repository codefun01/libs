import * as i0 from '@angular/core';
import { OnDestroy, ViewContainerRef, ElementRef, OnInit } from '@angular/core';
import * as i4 from '@angular/forms';
import { FormGroup } from '@angular/forms';
import * as i3 from '@spartacus/storefront';
import { Card, LaunchDialogService, FilesFormValidators, ICON_TYPE, FocusConfig, MessagingComponent, MessageEvent, MessagingConfigs, LayoutConfig } from '@spartacus/storefront';
import * as i1 from '@angular/common';
import * as i2 from '@spartacus/core';
import { TranslationService, RoutingService, EventService, GlobalMessageService } from '@spartacus/core';
import { CustomerTicketingFacade, TicketDetails, CustomerTicketingConfig, TicketEvent, Category, AssociatedObject, TicketStarter, TicketList } from '@spartacus/customer-ticketing/root';
import { Subscription, Observable, BehaviorSubject } from 'rxjs';
import * as i5 from '@ng-select/ng-select';
import * as i5$1 from '@angular/router';

declare class CustomerTicketingDetailsComponent implements OnDestroy {
    protected translation: TranslationService;
    protected customerTicketingFacade: CustomerTicketingFacade;
    protected routingService: RoutingService;
    protected eventService: EventService;
    dateFormat: string;
    subscription: Subscription;
    ticketDetails$: Observable<TicketDetails | undefined>;
    constructor(translation: TranslationService, customerTicketingFacade: CustomerTicketingFacade, routingService: RoutingService, eventService: EventService);
    prepareCardContent(entity: string | undefined, titleTranslation: string, id?: string | undefined): Observable<Card>;
    getStatusClass(id?: string | undefined): string;
    protected reloadOnRedirection(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerTicketingDetailsComponent, "cx-customer-ticketing-details", never, {}, {}, never, never, true, never>;
}

declare class CustomerTicketingDetailsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingDetailsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CustomerTicketingDetailsModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i2.UrlModule, typeof i3.CardModule, typeof i3.SpinnerModule, typeof CustomerTicketingDetailsComponent], [typeof CustomerTicketingDetailsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CustomerTicketingDetailsModule>;
}

declare class CustomerTicketingCloseComponentService {
    protected customerTicketingFacade: CustomerTicketingFacade;
    enableCloseButton(): Observable<boolean | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingCloseComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomerTicketingCloseComponentService>;
}

declare class CustomerTicketingCloseComponent implements OnDestroy {
    protected customerTicketingFacade: CustomerTicketingFacade;
    protected launchDialogService: LaunchDialogService;
    protected vcr: ViewContainerRef;
    protected subscription: Subscription;
    protected customerTicketingCloseComponentService: CustomerTicketingCloseComponentService;
    element: ElementRef;
    enableCloseButton$: Observable<boolean | undefined>;
    constructor(customerTicketingFacade: CustomerTicketingFacade, launchDialogService: LaunchDialogService, vcr: ViewContainerRef);
    openDialog(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingCloseComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerTicketingCloseComponent, "cx-customer-ticketing-close", never, {}, {}, never, never, true, never>;
}

declare abstract class CustomerTicketingDialogComponent {
    protected launchDialogService: LaunchDialogService;
    protected el: ElementRef;
    protected customerTicketingConfig: CustomerTicketingConfig;
    protected filesFormValidators: FilesFormValidators;
    protected customerTicketingFacade: CustomerTicketingFacade;
    protected routingService: RoutingService;
    iconTypes: typeof ICON_TYPE;
    form: FormGroup;
    inputCharactersLimit: number;
    inputCharactersForSubject: number;
    isDataLoading$: BehaviorSubject<boolean>;
    focusConfig: FocusConfig;
    get messagesCharacterLeft(): number;
    get subjectCharacterLeft(): number;
    get allowedTypes(): string[] | undefined;
    get getInputCharactersLimit(): number;
    get getInputCharactersForSubject(): number;
    get maxSize(): number;
    handleClick(event: UIEvent): void;
    constructor(launchDialogService: LaunchDialogService, el: ElementRef, customerTicketingConfig: CustomerTicketingConfig, filesFormValidators: FilesFormValidators, customerTicketingFacade: CustomerTicketingFacade, routingService: RoutingService);
    protected buildForm(): void;
    close(reason: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingDialogComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CustomerTicketingDialogComponent, never, never, {}, {}, never, never, true, never>;
}

declare class CustomerTicketingCloseDialogComponent extends CustomerTicketingDialogComponent implements OnInit, OnDestroy {
    subscription: Subscription;
    ngOnInit(): void;
    closeRequest(): void;
    protected prepareTicketEvent(): TicketEvent;
    protected onComplete(): void;
    protected onError(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingCloseDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerTicketingCloseDialogComponent, "cx-customer-ticketing-close-dialog", never, {}, {}, never, never, true, never>;
}

declare class CustomerTicketingCloseModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingCloseModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CustomerTicketingCloseModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof i3.KeyboardFocusModule, typeof i4.ReactiveFormsModule, typeof i3.FormErrorsModule, typeof i3.FileUploadModule, typeof i3.SpinnerModule, typeof i2.FeaturesConfigModule, typeof i3.FormRequiredAsterisksComponent, typeof CustomerTicketingCloseComponent, typeof CustomerTicketingCloseDialogComponent], [typeof CustomerTicketingCloseComponent, typeof CustomerTicketingCloseDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CustomerTicketingCloseModule>;
}

declare class CustomerTicketingReopenComponentService {
    protected customerTicketingFacade: CustomerTicketingFacade;
    enableReopenButton(): Observable<boolean | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingReopenComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomerTicketingReopenComponentService>;
}

declare class CustomerTicketingReopenComponent implements OnDestroy {
    protected customerTicketingFacade: CustomerTicketingFacade;
    protected launchDialogService: LaunchDialogService;
    protected vcr: ViewContainerRef;
    protected subscription: Subscription;
    protected CustomerTicketingReopenComponentService: CustomerTicketingReopenComponentService;
    element: ElementRef;
    enableReopenButton$: Observable<boolean | undefined>;
    constructor(customerTicketingFacade: CustomerTicketingFacade, launchDialogService: LaunchDialogService, vcr: ViewContainerRef);
    openDialog(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingReopenComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerTicketingReopenComponent, "cx-customer-ticketing-reopen", never, {}, {}, never, never, true, never>;
}

declare class CustomerTicketingReopenDialogComponent extends CustomerTicketingDialogComponent implements OnInit, OnDestroy {
    subscription: Subscription;
    ngOnInit(): void;
    reopenRequest(): void;
    protected onComplete(): void;
    protected onError(): void;
    protected prepareTicketEvent(): TicketEvent;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingReopenDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerTicketingReopenDialogComponent, "cx-customer-ticketing-reopen-dialog", never, {}, {}, never, never, true, never>;
}

declare class CustomerTicketingReopenModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingReopenModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CustomerTicketingReopenModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof i3.KeyboardFocusModule, typeof i4.ReactiveFormsModule, typeof i3.FormErrorsModule, typeof i3.FileUploadModule, typeof i3.SpinnerModule, typeof CustomerTicketingReopenComponent, typeof CustomerTicketingReopenDialogComponent], [typeof CustomerTicketingReopenComponent, typeof CustomerTicketingReopenDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CustomerTicketingReopenModule>;
}

declare class CustomerTicketingCreateComponent implements OnDestroy {
    protected launchDialogService: LaunchDialogService;
    protected vcr: ViewContainerRef;
    protected subscription: Subscription;
    element: ElementRef;
    constructor(launchDialogService: LaunchDialogService, vcr: ViewContainerRef);
    openCreateNewTicketDialog(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingCreateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerTicketingCreateComponent, "cx-customer-ticketing-create", never, {}, {}, never, never, true, never>;
}

declare class CustomerTicketingCreateDialogComponent extends CustomerTicketingDialogComponent implements OnInit, OnDestroy {
    ticketCategories$: Observable<Category[] | undefined>;
    ticketAssociatedObjects$: Observable<AssociatedObject[]>;
    subscription: Subscription;
    selectedCategory: Category;
    selectedAssociatedObject: AssociatedObject;
    attachment: File;
    protected globalMessage: GlobalMessageService;
    protected translationService: TranslationService;
    protected getCreateTicketPayload(form: FormGroup): TicketStarter;
    ngOnInit(): void;
    protected buildForm(): void;
    createTicketRequest(): void;
    protected handleError(error: any): void;
    protected manageCategoryValidation(categories: Category[] | undefined): void;
    protected onComplete(): void;
    protected onError(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingCreateDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerTicketingCreateDialogComponent, "cx-customer-ticketing-create-dialog", never, { "selectedCategory": { "alias": "selectedCategory"; "required": false; }; "selectedAssociatedObject": { "alias": "selectedAssociatedObject"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CustomerTicketingCreateModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingCreateModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CustomerTicketingCreateModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i3.IconModule, typeof i3.KeyboardFocusModule, typeof i4.ReactiveFormsModule, typeof i3.FormErrorsModule, typeof i3.FileUploadModule, typeof i2.FeaturesConfigModule, typeof i5.NgSelectModule, typeof i3.NgSelectA11yModule, typeof i3.FormRequiredAsterisksComponent, typeof i3.FormRequiredLegendComponent, typeof CustomerTicketingCreateComponent, typeof CustomerTicketingCreateDialogComponent], [typeof CustomerTicketingCreateComponent, typeof CustomerTicketingCreateDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CustomerTicketingCreateModule>;
}

declare class CustomerTicketingListComponent {
    protected customerTicketingFacade: CustomerTicketingFacade;
    protected routingService: RoutingService;
    protected translationService: TranslationService;
    protected customerTicketingConfig: CustomerTicketingConfig;
    constructor(customerTicketingFacade: CustomerTicketingFacade, routingService: RoutingService, translationService: TranslationService, customerTicketingConfig: CustomerTicketingConfig);
    PAGE_SIZE: number;
    sortType: string;
    iconTypes: typeof ICON_TYPE;
    tickets$: Observable<TicketList | undefined>;
    goToTicketDetail(ticketId: string | undefined): void;
    getSortLabels(): Observable<{
        byTicketId: string;
        byDate: string;
    }>;
    changeSortCode(sortCode: string): void;
    pageChange(page: number): void;
    createTicketListEvent(sortCode: string, currentPage: number): {
        currentPage: number;
        sortCode: string;
    };
    private fetchTicketList;
    getStatusClass: (status: string) => string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerTicketingListComponent, "cx-customer-ticketing-list", never, {}, {}, never, never, true, never>;
}

declare class CustomerTicketingListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CustomerTicketingListModule, never, [typeof CustomerTicketingCreateModule, typeof i1.CommonModule, typeof i2.I18nModule, typeof i2.UrlModule, typeof i3.CardModule, typeof i3.IconModule, typeof i3.ListNavigationModule, typeof i5$1.RouterModule, typeof i3.SpinnerModule, typeof CustomerTicketingListComponent], [typeof CustomerTicketingListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CustomerTicketingListModule>;
}

declare class CustomerTicketingMessagesComponentService {
    displayAddMessageSection(ticket: TicketDetails | undefined): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingMessagesComponentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomerTicketingMessagesComponentService>;
}

declare class CustomerTicketingMessagesComponent implements OnDestroy {
    protected customerTicketingConfig: CustomerTicketingConfig;
    protected customerTicketingFacade: CustomerTicketingFacade;
    protected eventService: EventService;
    messagingComponent: MessagingComponent;
    protected customerTicketingMessagesComponentService: CustomerTicketingMessagesComponentService;
    private featureToggles;
    ticketDetails$: Observable<TicketDetails | undefined>;
    constructor(customerTicketingConfig: CustomerTicketingConfig, customerTicketingFacade: CustomerTicketingFacade, eventService: EventService);
    subscription: Subscription;
    messageEvents$: Observable<Array<MessageEvent>>;
    messagingConfigs: MessagingConfigs;
    onSend(event: {
        files: FileList | undefined;
        message: string;
    }): void;
    downloadAttachment(event: {
        messageCode: string | undefined;
        attachmentId: string | undefined;
        fileName: string | undefined;
    }): void;
    protected prepareMessageEvents(): Observable<Array<MessageEvent>>;
    protected prepareMessagingConfigs(): MessagingConfigs;
    protected prepareTicketEvent(messageText: string): TicketEvent;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingMessagesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerTicketingMessagesComponent, "cx-customer-ticketing-messages", never, {}, {}, never, never, true, never>;
}

declare class CustomerTicketingMessagesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingMessagesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CustomerTicketingMessagesModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i2.UrlModule, typeof i3.ChatMessagingModule, typeof i4.ReactiveFormsModule, typeof i4.FormsModule, typeof CustomerTicketingMessagesComponent], [typeof CustomerTicketingMessagesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CustomerTicketingMessagesModule>;
}

declare class MyAccountV2CustomerTicketingComponent {
    protected readonly PAGE_SIZE = 1;
    protected customerTicketingFacade: CustomerTicketingFacade;
    tickets$: Observable<TicketList | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2CustomerTicketingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MyAccountV2CustomerTicketingComponent, "cx-my-account-v2-customer-ticketing", never, {}, {}, never, never, true, never>;
}

declare class MyAccountV2CustomerTicketingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MyAccountV2CustomerTicketingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MyAccountV2CustomerTicketingModule, never, [typeof i1.CommonModule, typeof i2.I18nModule, typeof i2.UrlModule, typeof i3.SpinnerModule, typeof i5$1.RouterModule, typeof MyAccountV2CustomerTicketingComponent], [typeof MyAccountV2CustomerTicketingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MyAccountV2CustomerTicketingModule>;
}

declare class CustomerTicketingComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CustomerTicketingComponentsModule, never, [typeof i4.ReactiveFormsModule, typeof i3.FormErrorsModule, typeof CustomerTicketingDetailsModule, typeof CustomerTicketingCloseModule, typeof CustomerTicketingReopenModule, typeof CustomerTicketingListModule, typeof CustomerTicketingMessagesModule, typeof CustomerTicketingCreateModule, typeof MyAccountV2CustomerTicketingModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CustomerTicketingComponentsModule>;
}

declare const defaultCustomerTicketingFormLayoutConfig: LayoutConfig;

export { CustomerTicketingCloseComponent, CustomerTicketingCloseComponentService, CustomerTicketingCloseDialogComponent, CustomerTicketingCloseModule, CustomerTicketingComponentsModule, CustomerTicketingCreateComponent, CustomerTicketingCreateDialogComponent, CustomerTicketingCreateModule, CustomerTicketingDetailsComponent, CustomerTicketingDetailsModule, CustomerTicketingDialogComponent, CustomerTicketingListComponent, CustomerTicketingListModule, CustomerTicketingMessagesComponent, CustomerTicketingMessagesComponentService, CustomerTicketingMessagesModule, CustomerTicketingReopenComponent, CustomerTicketingReopenComponentService, CustomerTicketingReopenDialogComponent, CustomerTicketingReopenModule, MyAccountV2CustomerTicketingComponent, MyAccountV2CustomerTicketingModule, defaultCustomerTicketingFormLayoutConfig };
