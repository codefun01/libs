import { TranslationChunksConfig } from '@spartacus/core';

declare const cs: {
    customerTicketing: {
        customerTicketing: {
            mainLogoLabel: string;
            mainTitle: string;
            ticketId: string;
            createdOn: string;
            changedOn: string;
            status: string;
            message: string;
            cancel: string;
            submit: string;
            uploadFile: string;
            fileSizeLimit: string;
            maximumAttachment: string;
            errorMessage: string;
            charactersLeft: string;
            customerService: string;
        };
        customerTicketingList: {
            subject: string;
            ticketCategory: string;
            sortSubtitle: string;
            sortOrders: string;
            noTickets: string;
            requestTitle: string;
            mobile: {
                ticketIdFull: string;
            };
        };
        createCustomerTicket: {
            createNewTicket: string;
            addNewRequest: string;
            addRequest: string;
            subject: string;
            category: string;
            associateTo: string;
            ticketCreated: string;
            optionallySelectAssociatedObject: string;
            selectCategory: string;
        };
        customerTicketingDetails: {
            requestReopened: string;
            requestClosed: string;
            reopenRequest: string;
            closeRequest: string;
            ticketNotFound: string;
        };
    };
    myAccountV2CustomerTicketing: {
        myAccountV2CustomerTicketing: {
            heading: string;
            showMore: string;
            showMoreLabel: string;
            changedOn: string;
            ticketId: string;
            subjectLabel: string;
            idLabel: string;
        };
    };
};

declare const de: {
    customerTicketing: {
        customerTicketing: {
            mainLogoLabel: string;
            mainTitle: string;
            ticketId: string;
            createdOn: string;
            changedOn: string;
            status: string;
            message: string;
            cancel: string;
            submit: string;
            uploadFile: string;
            fileSizeLimit: string;
            maximumAttachment: string;
            errorMessage: string;
            charactersLeft: string;
            customerService: string;
        };
        customerTicketingList: {
            subject: string;
            ticketCategory: string;
            sortSubtitle: string;
            sortOrders: string;
            noTickets: string;
            requestTitle: string;
            mobile: {
                ticketIdFull: string;
            };
        };
        createCustomerTicket: {
            createNewTicket: string;
            addNewRequest: string;
            addRequest: string;
            subject: string;
            category: string;
            associateTo: string;
            ticketCreated: string;
            optionallySelectAssociatedObject: string;
            selectCategory: string;
        };
        customerTicketingDetails: {
            requestReopened: string;
            requestClosed: string;
            reopenRequest: string;
            closeRequest: string;
            ticketNotFound: string;
        };
    };
    myAccountV2CustomerTicketing: {
        myAccountV2CustomerTicketing: {
            heading: string;
            showMore: string;
            showMoreLabel: string;
            changedOn: string;
            ticketId: string;
            subjectLabel: string;
            idLabel: string;
        };
    };
};

declare const en: {
    customerTicketing: {
        customerTicketing: {
            mainLogoLabel: string;
            mainTitle: string;
            ticketId: string;
            createdOn: string;
            changedOn: string;
            status: string;
            message: string;
            cancel: string;
            submit: string;
            uploadFile: string;
            fileSizeLimit: string;
            maximumAttachment: string;
            errorMessage: string;
            charactersLeft: string;
            customerService: string;
        };
        customerTicketingList: {
            subject: string;
            ticketCategory: string;
            sortSubtitle: string;
            sortOrders: string;
            noTickets: string;
            requestTitle: string;
            mobile: {
                ticketIdFull: string;
            };
        };
        createCustomerTicket: {
            createNewTicket: string;
            addNewRequest: string;
            addRequest: string;
            subject: string;
            category: string;
            associateTo: string;
            ticketCreated: string;
            optionallySelectAssociatedObject: string;
            selectCategory: string;
        };
        customerTicketingDetails: {
            requestReopened: string;
            requestClosed: string;
            reopenRequest: string;
            closeRequest: string;
            ticketNotFound: string;
            a11y: {
                ticketDetailsRegion: string;
            };
        };
    };
    myAccountV2CustomerTicketing: {
        myAccountV2CustomerTicketing: {
            heading: string;
            showMore: string;
            showMoreLabel: string;
            changedOn: string;
            ticketId: string;
            subjectLabel: string;
            idLabel: string;
        };
    };
};

declare const es: {
    customerTicketing: {
        customerTicketing: {
            mainLogoLabel: string;
            mainTitle: string;
            ticketId: string;
            createdOn: string;
            changedOn: string;
            status: string;
            message: string;
            cancel: string;
            submit: string;
            uploadFile: string;
            fileSizeLimit: string;
            maximumAttachment: string;
            errorMessage: string;
            charactersLeft: string;
            customerService: string;
        };
        customerTicketingList: {
            subject: string;
            ticketCategory: string;
            sortSubtitle: string;
            sortOrders: string;
            noTickets: string;
            requestTitle: string;
            mobile: {
                ticketIdFull: string;
            };
        };
        createCustomerTicket: {
            createNewTicket: string;
            addNewRequest: string;
            addRequest: string;
            subject: string;
            category: string;
            associateTo: string;
            ticketCreated: string;
            optionallySelectAssociatedObject: string;
            selectCategory: string;
        };
        customerTicketingDetails: {
            requestReopened: string;
            requestClosed: string;
            reopenRequest: string;
            closeRequest: string;
            ticketNotFound: string;
        };
    };
    myAccountV2CustomerTicketing: {
        myAccountV2CustomerTicketing: {
            heading: string;
            showMore: string;
            showMoreLabel: string;
            changedOn: string;
            ticketId: string;
            subjectLabel: string;
            idLabel: string;
        };
    };
};

declare const es_CO: {
    customerTicketing: {
        customerTicketing: {
            mainLogoLabel: string;
            mainTitle: string;
            ticketId: string;
            createdOn: string;
            changedOn: string;
            status: string;
            message: string;
            cancel: string;
            submit: string;
            uploadFile: string;
            fileSizeLimit: string;
            maximumAttachment: string;
            errorMessage: string;
            charactersLeft: string;
            customerService: string;
        };
        customerTicketingList: {
            subject: string;
            ticketCategory: string;
            sortSubtitle: string;
            sortOrders: string;
            noTickets: string;
            requestTitle: string;
            mobile: {
                ticketIdFull: string;
            };
        };
        createCustomerTicket: {
            createNewTicket: string;
            addNewRequest: string;
            addRequest: string;
            subject: string;
            category: string;
            associateTo: string;
            ticketCreated: string;
            optionallySelectAssociatedObject: string;
            selectCategory: string;
        };
        customerTicketingDetails: {
            requestReopened: string;
            requestClosed: string;
            reopenRequest: string;
            closeRequest: string;
            ticketNotFound: string;
        };
    };
    myAccountV2CustomerTicketing: {
        myAccountV2CustomerTicketing: {
            heading: string;
            showMore: string;
            showMoreLabel: string;
            changedOn: string;
            ticketId: string;
            subjectLabel: string;
            idLabel: string;
        };
    };
};

declare const fr: {
    customerTicketing: {
        customerTicketing: {
            mainLogoLabel: string;
            mainTitle: string;
            ticketId: string;
            createdOn: string;
            changedOn: string;
            status: string;
            message: string;
            cancel: string;
            submit: string;
            uploadFile: string;
            fileSizeLimit: string;
            maximumAttachment: string;
            errorMessage: string;
            charactersLeft: string;
            customerService: string;
        };
        customerTicketingList: {
            subject: string;
            ticketCategory: string;
            sortSubtitle: string;
            sortOrders: string;
            noTickets: string;
            requestTitle: string;
            mobile: {
                ticketIdFull: string;
            };
        };
        createCustomerTicket: {
            createNewTicket: string;
            addNewRequest: string;
            addRequest: string;
            subject: string;
            category: string;
            associateTo: string;
            ticketCreated: string;
            optionallySelectAssociatedObject: string;
            selectCategory: string;
        };
        customerTicketingDetails: {
            requestReopened: string;
            requestClosed: string;
            reopenRequest: string;
            closeRequest: string;
            ticketNotFound: string;
        };
    };
    myAccountV2CustomerTicketing: {
        myAccountV2CustomerTicketing: {
            heading: string;
            showMore: string;
            showMoreLabel: string;
            changedOn: string;
            ticketId: string;
            subjectLabel: string;
            idLabel: string;
        };
    };
};

declare const hi: {
    customerTicketing: {
        customerTicketing: {
            mainLogoLabel: string;
            mainTitle: string;
            ticketId: string;
            createdOn: string;
            changedOn: string;
            status: string;
            message: string;
            cancel: string;
            submit: string;
            uploadFile: string;
            fileSizeLimit: string;
            maximumAttachment: string;
            errorMessage: string;
            charactersLeft: string;
            customerService: string;
        };
        customerTicketingList: {
            subject: string;
            ticketCategory: string;
            sortSubtitle: string;
            sortOrders: string;
            noTickets: string;
            requestTitle: string;
            mobile: {
                ticketIdFull: string;
            };
        };
        createCustomerTicket: {
            createNewTicket: string;
            addNewRequest: string;
            addRequest: string;
            subject: string;
            category: string;
            associateTo: string;
            ticketCreated: string;
            optionallySelectAssociatedObject: string;
            selectCategory: string;
        };
        customerTicketingDetails: {
            requestReopened: string;
            requestClosed: string;
            reopenRequest: string;
            closeRequest: string;
            ticketNotFound: string;
        };
    };
    myAccountV2CustomerTicketing: {
        myAccountV2CustomerTicketing: {
            heading: string;
            showMore: string;
            showMoreLabel: string;
            changedOn: string;
            ticketId: string;
            subjectLabel: string;
            idLabel: string;
        };
    };
};

declare const hu: {
    customerTicketing: {
        customerTicketing: {
            mainLogoLabel: string;
            mainTitle: string;
            ticketId: string;
            createdOn: string;
            changedOn: string;
            status: string;
            message: string;
            cancel: string;
            submit: string;
            uploadFile: string;
            fileSizeLimit: string;
            maximumAttachment: string;
            errorMessage: string;
            charactersLeft: string;
            customerService: string;
        };
        customerTicketingList: {
            subject: string;
            ticketCategory: string;
            sortSubtitle: string;
            sortOrders: string;
            noTickets: string;
            requestTitle: string;
            mobile: {
                ticketIdFull: string;
            };
        };
        createCustomerTicket: {
            createNewTicket: string;
            addNewRequest: string;
            addRequest: string;
            subject: string;
            category: string;
            associateTo: string;
            ticketCreated: string;
            optionallySelectAssociatedObject: string;
            selectCategory: string;
        };
        customerTicketingDetails: {
            requestReopened: string;
            requestClosed: string;
            reopenRequest: string;
            closeRequest: string;
            ticketNotFound: string;
        };
    };
    myAccountV2CustomerTicketing: {
        myAccountV2CustomerTicketing: {
            heading: string;
            showMore: string;
            showMoreLabel: string;
            changedOn: string;
            ticketId: string;
            subjectLabel: string;
            idLabel: string;
        };
    };
};

declare const id: {
    customerTicketing: {
        customerTicketing: {
            mainLogoLabel: string;
            mainTitle: string;
            ticketId: string;
            createdOn: string;
            changedOn: string;
            status: string;
            message: string;
            cancel: string;
            submit: string;
            uploadFile: string;
            fileSizeLimit: string;
            maximumAttachment: string;
            errorMessage: string;
            charactersLeft: string;
            customerService: string;
        };
        customerTicketingList: {
            subject: string;
            ticketCategory: string;
            sortSubtitle: string;
            sortOrders: string;
            noTickets: string;
            requestTitle: string;
            mobile: {
                ticketIdFull: string;
            };
        };
        createCustomerTicket: {
            createNewTicket: string;
            addNewRequest: string;
            addRequest: string;
            subject: string;
            category: string;
            associateTo: string;
            ticketCreated: string;
            optionallySelectAssociatedObject: string;
            selectCategory: string;
        };
        customerTicketingDetails: {
            requestReopened: string;
            requestClosed: string;
            reopenRequest: string;
            closeRequest: string;
            ticketNotFound: string;
        };
    };
    myAccountV2CustomerTicketing: {
        myAccountV2CustomerTicketing: {
            heading: string;
            showMore: string;
            showMoreLabel: string;
            changedOn: string;
            ticketId: string;
            subjectLabel: string;
            idLabel: string;
        };
    };
};

declare const it: {
    customerTicketing: {
        customerTicketing: {
            mainLogoLabel: string;
            mainTitle: string;
            ticketId: string;
            createdOn: string;
            changedOn: string;
            status: string;
            message: string;
            cancel: string;
            submit: string;
            uploadFile: string;
            fileSizeLimit: string;
            maximumAttachment: string;
            errorMessage: string;
            charactersLeft: string;
            customerService: string;
        };
        customerTicketingList: {
            subject: string;
            ticketCategory: string;
            sortSubtitle: string;
            sortOrders: string;
            noTickets: string;
            requestTitle: string;
            mobile: {
                ticketIdFull: string;
            };
        };
        createCustomerTicket: {
            createNewTicket: string;
            addNewRequest: string;
            addRequest: string;
            subject: string;
            category: string;
            associateTo: string;
            ticketCreated: string;
            optionallySelectAssociatedObject: string;
            selectCategory: string;
        };
        customerTicketingDetails: {
            requestReopened: string;
            requestClosed: string;
            reopenRequest: string;
            closeRequest: string;
            ticketNotFound: string;
        };
    };
    myAccountV2CustomerTicketing: {
        myAccountV2CustomerTicketing: {
            heading: string;
            showMore: string;
            showMoreLabel: string;
            changedOn: string;
            ticketId: string;
            subjectLabel: string;
            idLabel: string;
        };
    };
};

declare const ja: {
    customerTicketing: {
        customerTicketing: {
            mainLogoLabel: string;
            mainTitle: string;
            ticketId: string;
            createdOn: string;
            changedOn: string;
            status: string;
            message: string;
            cancel: string;
            submit: string;
            uploadFile: string;
            fileSizeLimit: string;
            maximumAttachment: string;
            errorMessage: string;
            charactersLeft: string;
            customerService: string;
        };
        customerTicketingList: {
            subject: string;
            ticketCategory: string;
            sortSubtitle: string;
            sortOrders: string;
            noTickets: string;
            requestTitle: string;
            mobile: {
                ticketIdFull: string;
            };
        };
        createCustomerTicket: {
            createNewTicket: string;
            addNewRequest: string;
            addRequest: string;
            subject: string;
            category: string;
            associateTo: string;
            ticketCreated: string;
            optionallySelectAssociatedObject: string;
            selectCategory: string;
        };
        customerTicketingDetails: {
            requestReopened: string;
            requestClosed: string;
            reopenRequest: string;
            closeRequest: string;
            ticketNotFound: string;
        };
    };
    myAccountV2CustomerTicketing: {
        myAccountV2CustomerTicketing: {
            heading: string;
            showMore: string;
            showMoreLabel: string;
            changedOn: string;
            ticketId: string;
            subjectLabel: string;
            idLabel: string;
        };
    };
};

declare const ko: {
    customerTicketing: {
        customerTicketing: {
            mainLogoLabel: string;
            mainTitle: string;
            ticketId: string;
            createdOn: string;
            changedOn: string;
            status: string;
            message: string;
            cancel: string;
            submit: string;
            uploadFile: string;
            fileSizeLimit: string;
            maximumAttachment: string;
            errorMessage: string;
            charactersLeft: string;
            customerService: string;
        };
        customerTicketingList: {
            subject: string;
            ticketCategory: string;
            sortSubtitle: string;
            sortOrders: string;
            noTickets: string;
            requestTitle: string;
            mobile: {
                ticketIdFull: string;
            };
        };
        createCustomerTicket: {
            createNewTicket: string;
            addNewRequest: string;
            addRequest: string;
            subject: string;
            category: string;
            associateTo: string;
            ticketCreated: string;
            optionallySelectAssociatedObject: string;
            selectCategory: string;
        };
        customerTicketingDetails: {
            requestReopened: string;
            requestClosed: string;
            reopenRequest: string;
            closeRequest: string;
            ticketNotFound: string;
        };
    };
    myAccountV2CustomerTicketing: {
        myAccountV2CustomerTicketing: {
            heading: string;
            showMore: string;
            showMoreLabel: string;
            changedOn: string;
            ticketId: string;
            subjectLabel: string;
            idLabel: string;
        };
    };
};

declare const pl: {
    customerTicketing: {
        customerTicketing: {
            mainLogoLabel: string;
            mainTitle: string;
            ticketId: string;
            createdOn: string;
            changedOn: string;
            status: string;
            message: string;
            cancel: string;
            submit: string;
            uploadFile: string;
            fileSizeLimit: string;
            maximumAttachment: string;
            errorMessage: string;
            charactersLeft: string;
            customerService: string;
        };
        customerTicketingList: {
            subject: string;
            ticketCategory: string;
            sortSubtitle: string;
            sortOrders: string;
            noTickets: string;
            requestTitle: string;
            mobile: {
                ticketIdFull: string;
            };
        };
        createCustomerTicket: {
            createNewTicket: string;
            addNewRequest: string;
            addRequest: string;
            subject: string;
            category: string;
            associateTo: string;
            ticketCreated: string;
            optionallySelectAssociatedObject: string;
            selectCategory: string;
        };
        customerTicketingDetails: {
            requestReopened: string;
            requestClosed: string;
            reopenRequest: string;
            closeRequest: string;
            ticketNotFound: string;
        };
    };
    myAccountV2CustomerTicketing: {
        myAccountV2CustomerTicketing: {
            heading: string;
            showMore: string;
            showMoreLabel: string;
            changedOn: string;
            ticketId: string;
            subjectLabel: string;
            idLabel: string;
        };
    };
};

declare const pt: {
    customerTicketing: {
        customerTicketing: {
            mainLogoLabel: string;
            mainTitle: string;
            ticketId: string;
            createdOn: string;
            changedOn: string;
            status: string;
            message: string;
            cancel: string;
            submit: string;
            uploadFile: string;
            fileSizeLimit: string;
            maximumAttachment: string;
            errorMessage: string;
            charactersLeft: string;
            customerService: string;
        };
        customerTicketingList: {
            subject: string;
            ticketCategory: string;
            sortSubtitle: string;
            sortOrders: string;
            noTickets: string;
            requestTitle: string;
            mobile: {
                ticketIdFull: string;
            };
        };
        createCustomerTicket: {
            createNewTicket: string;
            addNewRequest: string;
            addRequest: string;
            subject: string;
            category: string;
            associateTo: string;
            ticketCreated: string;
            optionallySelectAssociatedObject: string;
            selectCategory: string;
        };
        customerTicketingDetails: {
            requestReopened: string;
            requestClosed: string;
            reopenRequest: string;
            closeRequest: string;
            ticketNotFound: string;
        };
    };
    myAccountV2CustomerTicketing: {
        myAccountV2CustomerTicketing: {
            heading: string;
            showMore: string;
            showMoreLabel: string;
            changedOn: string;
            ticketId: string;
            subjectLabel: string;
            idLabel: string;
        };
    };
};

declare const ru: {
    customerTicketing: {
        customerTicketing: {
            mainLogoLabel: string;
            mainTitle: string;
            ticketId: string;
            createdOn: string;
            changedOn: string;
            status: string;
            message: string;
            cancel: string;
            submit: string;
            uploadFile: string;
            fileSizeLimit: string;
            maximumAttachment: string;
            errorMessage: string;
            charactersLeft: string;
            customerService: string;
        };
        customerTicketingList: {
            subject: string;
            ticketCategory: string;
            sortSubtitle: string;
            sortOrders: string;
            noTickets: string;
            requestTitle: string;
            mobile: {
                ticketIdFull: string;
            };
        };
        createCustomerTicket: {
            createNewTicket: string;
            addNewRequest: string;
            addRequest: string;
            subject: string;
            category: string;
            associateTo: string;
            ticketCreated: string;
            optionallySelectAssociatedObject: string;
            selectCategory: string;
        };
        customerTicketingDetails: {
            requestReopened: string;
            requestClosed: string;
            reopenRequest: string;
            closeRequest: string;
            ticketNotFound: string;
        };
    };
    myAccountV2CustomerTicketing: {
        myAccountV2CustomerTicketing: {
            heading: string;
            showMore: string;
            showMoreLabel: string;
            changedOn: string;
            ticketId: string;
            subjectLabel: string;
            idLabel: string;
        };
    };
};

declare const zh: {
    customerTicketing: {
        customerTicketing: {
            mainLogoLabel: string;
            mainTitle: string;
            ticketId: string;
            createdOn: string;
            changedOn: string;
            status: string;
            message: string;
            cancel: string;
            submit: string;
            uploadFile: string;
            fileSizeLimit: string;
            maximumAttachment: string;
            errorMessage: string;
            charactersLeft: string;
            customerService: string;
        };
        customerTicketingList: {
            subject: string;
            ticketCategory: string;
            sortSubtitle: string;
            sortOrders: string;
            noTickets: string;
            requestTitle: string;
            mobile: {
                ticketIdFull: string;
            };
        };
        createCustomerTicket: {
            createNewTicket: string;
            addNewRequest: string;
            addRequest: string;
            subject: string;
            category: string;
            associateTo: string;
            ticketCreated: string;
            optionallySelectAssociatedObject: string;
            selectCategory: string;
        };
        customerTicketingDetails: {
            requestReopened: string;
            requestClosed: string;
            reopenRequest: string;
            closeRequest: string;
            ticketNotFound: string;
        };
    };
    myAccountV2CustomerTicketing: {
        myAccountV2CustomerTicketing: {
            heading: string;
            showMore: string;
            showMoreLabel: string;
            changedOn: string;
            ticketId: string;
            subjectLabel: string;
            idLabel: string;
        };
    };
};

declare const zh_TW: {
    customerTicketing: {
        customerTicketing: {
            mainLogoLabel: string;
            mainTitle: string;
            ticketId: string;
            createdOn: string;
            changedOn: string;
            status: string;
            message: string;
            cancel: string;
            submit: string;
            uploadFile: string;
            fileSizeLimit: string;
            maximumAttachment: string;
            errorMessage: string;
            charactersLeft: string;
            customerService: string;
        };
        customerTicketingList: {
            subject: string;
            ticketCategory: string;
            sortSubtitle: string;
            sortOrders: string;
            noTickets: string;
            requestTitle: string;
            mobile: {
                ticketIdFull: string;
            };
        };
        createCustomerTicket: {
            createNewTicket: string;
            addNewRequest: string;
            addRequest: string;
            subject: string;
            category: string;
            associateTo: string;
            ticketCreated: string;
            optionallySelectAssociatedObject: string;
            selectCategory: string;
        };
        customerTicketingDetails: {
            requestReopened: string;
            requestClosed: string;
            reopenRequest: string;
            closeRequest: string;
            ticketNotFound: string;
        };
    };
    myAccountV2CustomerTicketing: {
        myAccountV2CustomerTicketing: {
            heading: string;
            showMore: string;
            showMoreLabel: string;
            changedOn: string;
            ticketId: string;
            subjectLabel: string;
            idLabel: string;
        };
    };
};

declare const customerTicketingTranslationChunksConfig: TranslationChunksConfig;

export { customerTicketingTranslationChunksConfig, cs as customerTicketingTranslationsCs, de as customerTicketingTranslationsDe, en as customerTicketingTranslationsEn, es as customerTicketingTranslationsEs, es_CO as customerTicketingTranslationsEs_CO, fr as customerTicketingTranslationsFr, hi as customerTicketingTranslationsHi, hu as customerTicketingTranslationsHu, id as customerTicketingTranslationsId, it as customerTicketingTranslationsIt, ja as customerTicketingTranslationsJa, ko as customerTicketingTranslationsKo, pl as customerTicketingTranslationsPl, pt as customerTicketingTranslationsPt, ru as customerTicketingTranslationsRu, zh as customerTicketingTranslationsZh, zh_TW as customerTicketingTranslationsZh_TW };
