import { HttpClient } from '@angular/common/http';
import { OccEndpointsService, ConverterService, LoggerService, OccEndpoint } from '@spartacus/core';
import { CustomerTicketingAdapter } from '@spartacus/customer-ticketing/core';
import { AssociatedObject, Category, TicketDetails, TicketStarter, TicketList, TicketEvent } from '@spartacus/customer-ticketing/root';
import { Observable } from 'rxjs';
import * as i0 from '@angular/core';
import * as i1 from '@angular/common';

declare class OccCustomerTicketingAdapter implements CustomerTicketingAdapter {
    protected http: HttpClient;
    protected occEndpoints: OccEndpointsService;
    protected converter: ConverterService;
    protected logger: LoggerService;
    constructor(http: HttpClient, occEndpoints: OccEndpointsService, converter: ConverterService);
    getTicketAssociatedObjects(customerId: string): Observable<AssociatedObject[]>;
    protected getTicketAssociatedObjectsEndpoint(customerId: string): string;
    getTicketCategories(): Observable<Category[]>;
    protected getTicketCategoriesEndpoint(): string;
    getTicket(customerId: string, ticketId: string): Observable<TicketDetails>;
    protected getTicketEndpoint(customerId: string, ticketId: string): string;
    createTicket(customerId: string, ticket: TicketStarter): Observable<TicketStarter>;
    protected getCreateTicketEndpoint(customerId: string): string;
    getTickets(customerId: string, pageSize?: number, currentPage?: number, sort?: string): Observable<TicketList>;
    protected getTicketsEndpoint(customerId: string, pageSize?: number, currentPage?: number, sort?: string): string;
    createTicketEvent(customerId: string, ticketId: string, ticketEvent: TicketEvent): Observable<TicketEvent>;
    protected getCreateTicketEventEndpoint(customerId: string, ticketId: string): string;
    uploadAttachment(customerId: string, ticketId: string, eventCode: string, file: File): Observable<unknown>;
    protected getUploadAttachmentEndpoint(customerId: string, ticketId: string, eventCode: string): string;
    downloadAttachment(customerId: string, ticketId: string, eventCode: string, attachmentId: string): Observable<unknown>;
    protected getDownloadAttachmentEndpoint(customerId: string, ticketId: string, eventCode: string, attachmentId: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OccCustomerTicketingAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OccCustomerTicketingAdapter>;
}

declare class CustomerTicketingOccModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerTicketingOccModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CustomerTicketingOccModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CustomerTicketingOccModule>;
}

declare module '@spartacus/core' {
    interface OccEndpoints {
        /**
         * Endpoint to get ticket details by ticket id
         * @member {string}
         */
        getTicket?: string | OccEndpoint;
        /**
         * Endpoint to get ticket list by customer id
         * @member {string}
         */
        getTickets?: string | OccEndpoint;
        /**
         * Endpoint to create a ticket event
         *
         * * @member {string}
         */
        createTicketEvent?: string | OccEndpoint;
        /**
         * Endpoint to get ticket categories
         *
         * * @member {string}
         */
        getTicketCategories?: string | OccEndpoint;
        /**
         * Endpoint to get ticket associated objects
         *
         * * @member {string}
         */
        getTicketAssociatedObjects?: string | OccEndpoint;
        createTicket?: string | OccEndpoint;
        uploadAttachment?: string | OccEndpoint;
        /**
         * Endpoint to download an attachment
         *
         * * @member {string}
         */
        downloadAttachment?: string | OccEndpoint;
    }
}

export { CustomerTicketingOccModule, OccCustomerTicketingAdapter };
